using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Edit page for an Enrollment record in the system.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ENROLLMENTS_MAINT)]

	[MainLanguageClass("ActiveAdvice.Messages.OrgMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Enrollment,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(EnrollmentsForm))]
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@ENROLLMENTPAGETITLE@")]
	public class EnrollmentForm : BasePage
	{
		private Enrollment enrollment;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEnrollment;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternateEnrollmentID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateEnrollmentID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateEnrollmentID;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				enrollment = (Enrollment)this.LoadObject(typeof(Enrollment));  // load object from cache
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Details")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				toolbar.AddButton(OrgMessages.MessageIDs.ADDNEWRECORD, "NewRecord");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Enrollment Enrollment
		{
			get { return enrollment; }
			set
			{
				enrollment = value;
				try
				{
					this.UpdateFromObject(pnlEnrollment.Controls, enrollment);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Enrollment), enrollment);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlEnrollment.Controls, enrollment);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewEnrollment()
		{
			bool result = true;
			Enrollment enrollment = null; // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				enrollment = new Enrollment(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Enrollment = enrollment;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			Enrollment enrollment = null;
			try
			{	// use any load method here
				enrollment = (Enrollment)GetParam("Enrollment");
				if (enrollment == null) 
					return NewEnrollment();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//enrollment.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Enrollment = enrollment;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Enrollment enrollment)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Enrollment", enrollment);
			BasePage.Redirect("EnrollmentForm.aspx");

		}

		/// <summary>
		/// Load the given enrollment by id and open the page.
		/// </summary>
		/// <param name="enrollmentID"></param>
		public static void Redirect(int enrollmentID)
		{
			Enrollment enrollment = new Enrollment();
			if (!enrollment.Load(enrollmentID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@ENROLLMENT@");
			Redirect(enrollment);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				enrollment.Save(); // update or insert to db 
				EnrollmentCollection.ClearAllEnrollmentsByValidDateRange();		// the change from UI will clear cached enrollments in the memory.
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@ENROLLMENT@");
				this.Enrollment = this.Enrollment;	// just update the ui
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.RenderClientFunctions(pnlEnrollment.Controls, enrollment, "OnCalculateEnrollment");
		}


	}
}
