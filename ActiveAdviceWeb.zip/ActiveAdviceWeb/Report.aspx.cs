using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using NetsoftUSA.WebForms;
using ActiveAdvice.DataLayer;
using NetsoftUSA.InfragisticsWeb;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for Report.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ReportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MReports")]
	[PageTitle("@REPORTTITLE@")]
	public class Report : BasePage
	{


		
		private string repName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReport;
		protected System.Web.UI.WebControls.Button btnExportPDF;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.WebControls.DropDownList lstMIME;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		private ReportParameters reportParameters;
		private ReportDocument repDocCache;
	



		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@CANCEL@", "Cancel", false, true);
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BasePage.Redirect("ReportMaintenance.aspx",true);
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				// get objects
				this.repName = (string)this.GetParamOrGetFromCache("ReportNameR","ReportNameR");
				this.reportParameters = this.GetParamOrGetFromCache("ReportParameters", typeof(ReportParameters)) as ActiveAdvice.DataLayer.ReportParameters;
				// cache the parameters so iframe can use it.
				this.CacheObject("ReportName", RepName);
				this.CacheObject("ReportParameters",this.reportParameters);
			}
			else
			{
				this.repName = this.LoadObject("ReportName") as string;
				this.reportParameters = this.LoadObject(typeof(ReportParameters)) as ReportParameters;
			}
			
		
		
			#region " OLD "
			// Put user code to initialize the page here
			/*try
			{
				
				if(!Page.IsPostBack)
				{
					this.RepName = (string)BasePage.PullParam("ReportName");
					this.reportParameters = this.GetParamOrGetFromCache("ReportParameters", typeof(ReportParameters)) as ActiveAdvice.DataLayer.ReportParameters;
					//this.CacheObject(typeof(ReportParameters),reportParameters);
				}
				else
				{
					this.repName = this.LoadObject("ReportName") as string;
					this.reportParameters = this.LoadObject(typeof(ReportParameters)) as ReportParameters;
				}
				
				this.CacheObject(typeof(ReportParameters),reportParameters);
				ReportDocument repDoc = new ReportDocument();					
				repDoc.Load(Server.MapPath("Reports\\"+this.RepFileName));
				
				ParameterFields paramFields = new ParameterFields ();
				SetLoginInfo(repDoc);
				#region "Set Report Parameters"
				if(reportParameters.MorgName != null)
                    AddParameter("MorgName",this.reportParameters.MorgName,paramFields);
				else
					AddParameter("MorgName","",paramFields);


				if(reportParameters.SorgName != null)
					AddParameter("SorgName",this.reportParameters.SorgName,paramFields);
				else
					AddParameter("SorgName","",paramFields);


				if(reportParameters.OrgName != null)
					AddParameter("OrgName",this.reportParameters.OrgName,paramFields);
				else
					AddParameter("OrgName","",paramFields);

				if (reportParameters.SubtotalBy != null && reportParameters.SubtotalBy != ReportItem.NoSubTotals)
					AddParameter("SubtotalBy",this.reportParameters.SubtotalBy, paramFields);
				else
					AddParameter("SubtotalBy","", paramFields);


				if(reportParameters.TeamName != null)
					AddParameter("Team",this.reportParameters.TeamName,paramFields);
				else
					AddParameter("Team","",paramFields);

				if(reportParameters.UserName != null)
					AddParameter("User",this.reportParameters.UserName,paramFields);
				else
					AddParameter("User","",paramFields);


				if(reportParameters.PlanName != null)
					AddParameter("Plan",this.reportParameters.PlanName,paramFields);
				else
					AddParameter("Plan","",paramFields);


				if(reportParameters.StateName != null)
					AddParameter("State",this.reportParameters.StateName,paramFields);
				else
					AddParameter("State","",paramFields);


				if(reportParameters.CmsTypeName != null)
					AddParameter("CMSType",this.reportParameters.CmsTypeName,paramFields);
				else
					AddParameter("CMSType","",paramFields);


				if(reportParameters.Outliers != null)
					AddParameter("Outliers",this.reportParameters.Outliers,paramFields);
				else
					AddParameter("Outliers","",paramFields);


				
				AddParameter("NewbornsDischargedwithMom",this.reportParameters.NewBornDischargedWithMother,paramFields);
		

				if(reportParameters.CodeTable != null)
					AddParameter("TableName",this.reportParameters.CodeTable,paramFields);
				else
					AddParameter("TableName","",paramFields);

				if(reportParameters.SubGroup != null)
					AddParameter("SubGroup",this.reportParameters.SubGroup,paramFields);
				else
					AddParameter("SubGroup","",paramFields);


				if(reportParameters.MajorGroup != null)
					AddParameter("MajorGroup",this.reportParameters.MajorGroup,paramFields);
				else
					AddParameter("MajorGroup","",paramFields);


				AddParameter("ReadmitDays",this.reportParameters.ReadmitDays,paramFields);

				if(reportParameters.SortBy != null)
					AddParameter("SortBy",this.reportParameters.SortBy,paramFields);
				else
					AddParameter("SortBy","",paramFields);

				if(reportParameters.SubSubGroup != null)
					AddParameter("SubSubGroup",this.reportParameters.SubSubGroup,paramFields);
				else
					AddParameter("SubSubGroup","",paramFields);

				AddParameter("ShowDetails",(this.reportParameters.ShowDetails ? 1 : 0),paramFields);
				ParameterField paramField = new ParameterField();
				paramField.ParameterFieldName = "Date";
				if(this.reportParameters.DateType == 0)
				{
					ParameterDiscreteValue	discreteVal = new ParameterDiscreteValue();
					discreteVal.Value = this.reportParameters.EndDate;
					paramField.CurrentValues.Add(discreteVal);
				}
				else
				{
					ParameterRangeValue rangeVal = new ParameterRangeValue();
					rangeVal.StartValue = this.reportParameters.FromDate;
					rangeVal.EndValue = this.reportParameters.EndDate;
					paramField.CurrentValues.Add(rangeVal);
				}
				paramFields.Add(paramField);
				rep.ParameterFieldInfo = paramFields;
				#endregion
				rep.ReportSource = repDoc;
				rep.DisplayGroupTree = false; // hide the group tree on the left
				this.CacheObject(typeof(ReportDocument),repDoc);
				this.CacheObject(typeof(ParameterFields),paramFields);
				rep.DataBind();
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(new Exception("Error running report!", ex));
			}*/
			#endregion
		}

		private void SetReportParameters()
		{
		}

		private bool IsMultiplAdmissionReport
		{
			get { return (this.RepFileName == "TestCursorMultipleAdmission.rpt" || this.RepFileName == "MultipleAdmissionRpt.rpt" || this.RepFileName == "MultipleAdmissionRptSumAll.rpt"); }
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			#region " OLD "
			/*try
			{
				if(!Page.IsPostBack)
				{
					this.RepName = (string)BasePage.PullParam("ReportName");
					this.reportParameters = this.GetParamOrGetFromCache("ReportParameters", typeof(ReportParameters)) as ActiveAdvice.DataLayer.ReportParameters;
					//this.CacheObject(typeof(ReportParameters),reportParameters);
				}
				else
				{
					this.repName = this.LoadObject("ReportName") as string;
					this.reportParameters = this.LoadObject(typeof(ReportParameters)) as ReportParameters;
				}
				


				this.CacheObject(typeof(ReportParameters),reportParameters);
				ReportDocument repDoc = new ReportDocument();					
				
				
				
				repDoc.Load(Server.MapPath("Reports\\"+this.RepFileName));
				
				ParameterFields paramFields = new ParameterFields ();
				SetLoginInfo(repDoc);
				#region "Set Report Parameters"

				AddParameter("@Dates",this.reportParameters.Dates, paramFields);
				
				
				
				if (IsMultiplAdmissionReport)
				{
					AddParameter("@FirstDate",this.reportParameters.FromDate,paramFields);
					AddParameter("@LastDate",this.reportParameters.EndDate, paramFields);
					
				}

				if(reportParameters.MorgName != null)
				{
					AddParameter("MorgName",this.reportParameters.MorgName,paramFields);
					if (IsMultiplAdmissionReport)
						AddParameter("@MorgName",this.reportParameters.MorgName,paramFields);
				}
				else
				{
					AddParameter("MorgName","",paramFields);
					if (IsMultiplAdmissionReport)
						AddParameter("@MorgName","",paramFields);
				}


				if(reportParameters.SorgName != null)
				{
					AddParameter("SorgName",this.reportParameters.SorgName,paramFields);
					if (IsMultiplAdmissionReport)
						AddParameter("@SorgName",this.reportParameters.SorgName,paramFields);
				}
				else
				{
					AddParameter("SorgName","",paramFields);
					if (IsMultiplAdmissionReport)
						AddParameter("@SorgName","",paramFields);
				}


				if(reportParameters.OrgName != null)
				{
					AddParameter("OrgName",this.reportParameters.OrgName,paramFields);
					if (IsMultiplAdmissionReport)
						AddParameter("@OrgName",this.reportParameters.OrgName,paramFields);
				}	
				else
				{
					AddParameter("OrgName","",paramFields);
					if (IsMultiplAdmissionReport)
						AddParameter("@OrgName","",paramFields);
				}

				if (reportParameters.SubtotalBy != null && reportParameters.SubtotalBy != ReportItem.NoSubTotals)
					AddParameter("SubtotalBy",this.reportParameters.SubtotalBy, paramFields);
				else
					AddParameter("SubtotalBy","", paramFields);


				if(reportParameters.TeamName != null)
					AddParameter("Team",this.reportParameters.TeamName,paramFields);
				else
					AddParameter("Team","",paramFields);

				if(reportParameters.UserName != null)
					AddParameter("User",this.reportParameters.UserName,paramFields);
				else
					AddParameter("User","",paramFields);


				if(reportParameters.PlanName != null)
				{
					AddParameter("Plan",this.reportParameters.PlanName,paramFields);
					if (IsMultiplAdmissionReport)
						AddParameter("@Plan",this.reportParameters.PlanName,paramFields);
				}
				else
				{
					AddParameter("Plan","",paramFields);
					if (IsMultiplAdmissionReport)
						AddParameter("@Plan","",paramFields);
				}


				if(reportParameters.StateName != null)
					AddParameter("State",this.reportParameters.StateName,paramFields);
				else
					AddParameter("State","",paramFields);


				if(reportParameters.CmsTypeName != null)
					AddParameter("CMSType",this.reportParameters.CmsTypeName,paramFields);
				else
					AddParameter("CMSType","",paramFields);


				if(reportParameters.Outliers != null)
				{
					if (reportParameters.Outliers == "Exclude") // exclude -> i
						AddParameter("Outliers","I",paramFields);
					else if (reportParameters.Outliers == "Include") // Include -> ""
						AddParameter("Outliers","",paramFields);
					else // has to be O since not null.
						AddParameter("Outliers","O",paramFields);
				}
				else
					AddParameter("Outliers","",paramFields);


				
				AddParameter("NewbornsDischargedwithMom",this.reportParameters.NewBornDischargedWithMother,paramFields);
		

				if(reportParameters.CodeTable != null)
					AddParameter("TableName",this.reportParameters.CodeTable,paramFields);
				else
					AddParameter("TableName","",paramFields);

				if(reportParameters.SubGroup != null)
					AddParameter("SubGroup",this.reportParameters.SubGroup,paramFields);
				else
					AddParameter("SubGroup","",paramFields);


				if(reportParameters.MajorGroup != null)
					AddParameter("MajorGroup",this.reportParameters.MajorGroup,paramFields);
				else
					AddParameter("MajorGroup","",paramFields);


				AddParameter("ReadmitDays",this.reportParameters.ReadmitDays,paramFields);

				if(reportParameters.SortBy != null)
					AddParameter("SortBy",this.reportParameters.SortBy,paramFields);
				else
					AddParameter("SortBy","",paramFields);

				if(reportParameters.SubSubGroup != null)
					AddParameter("SubSubGroup",this.reportParameters.SubSubGroup,paramFields);
				else
					AddParameter("SubSubGroup","",paramFields);

				AddParameter("ShowDetails",(this.reportParameters.ShowDetails ? 1 : 0),paramFields);

				
				if (!IsMultiplAdmissionReport)
				{
					ParameterField paramField = new ParameterField();
					paramField.ParameterFieldName = "Date";
					if(this.reportParameters.DateType == 0)
					{
						ParameterDiscreteValue	discreteVal = new ParameterDiscreteValue();
						discreteVal.Value = this.reportParameters.EndDate;
						paramField.CurrentValues.Add(discreteVal);
					}
					else
					{
						ParameterRangeValue rangeVal = new ParameterRangeValue();
						rangeVal.StartValue = this.reportParameters.FromDate;
						rangeVal.EndValue = this.reportParameters.EndDate;
						paramField.CurrentValues.Add(rangeVal);
					}
					paramFields.Add(paramField);
				}
				

				rep.ParameterFieldInfo = paramFields;
				#endregion
				rep.ReportSource = repDoc;
				rep.DisplayGroupTree = false; // hide the group tree on the left
				this.CacheObject(typeof(ReportDocument),repDoc);
				this.CacheObject(typeof(ParameterFields),paramFields);
				rep.DataBind();
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}*/
			#endregion
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnExportPDF.Click += new System.EventHandler(this.btnExportPDF_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		
		public string RepName
		{
			get { return repName; }
			set 
			{ 
				if(value!=null)
					repName = value;
			}
		}

		public string RepFileName
		{
			get
			{
				if(repName==Language.TranslateSingle("BYTEAMMORGORGSORGUSER"))
					return "DailyWorklistbyTOrgU.rpt";
				else if(repName == Language.TranslateSingle("BYUSERFACMORGORGSORG"))
					return "DailyWorklistbyUFOrg.rpt";
				else if(repName == Language.TranslateSingle("RPTCLOSEDIPEVENT"))
					return "GeneralEdit_1.rpt";
				else if(repName == Language.TranslateSingle("RPTOPENEVENT"))
					return "GeneralEdit_2.rpt";
				else if(repName == Language.TranslateSingle("RPTCLOSEDEVENT"))
					return "GeneralEdit_3.rpt";
				else if(repName == Language.TranslateSingle("RPTCLOSEDCMSEVENT"))
					return "GeneralEdit_4.rpt";
				else if(repName == Language.TranslateSingle("RPTREFERRALS"))
					return "GeneralEdit_5.rpt";
				else if(repName == Language.TranslateSingle("RPTACTPATIENTSUBSC"))
					return "GeneralEdit_6.rpt";
				else if(repName==Language.TranslateSingle("SUMMARYBYMORGORGSORG"))
					return "PatientCensusSumbyOrg.rpt";
				else if(repName==Language.TranslateSingle("SUMMARYBYUSERFACMORGORGSORG"))
					return "PatientCensusSumbyUFOrg.rpt";
				else if(repName==Language.TranslateSingle("SUMMARYBYFACMORGORGSORG"))
					return "PatientCensusSumbyFOrg.rpt";
				else if(repName==	Language.TranslateSingle("OPENEVENTSPAGEBREAKAFTERSORG"))
					return "OpenEventsPBSorg.rpt";
				else if(repName==	Language.TranslateSingle("OPENEVENTSPAGEBRAFTEREVENT"))
					return "OpenEventsPBEvent.rpt";
				else if(repName==	Language.TranslateSingle("CLOSEDEVENTSPAGEBRAFTERSORG"))
					return "ClosedEventsPBSorg.rpt";
				else if(repName == Language.TranslateSingle("CLOSEDEVENTSPAGEBRAFTEREVENT"))
					return "ClosedEventsPBEvent.rpt";
				else if(repName==	Language.TranslateSingle("UTILWITHNOAGGBYSUBGRP"))
				{
					if (reportParameters.SubtotalBy == ReportItem.NoSubTotals)
						return "IPUtilization.rpt";
					else
						return "IPUtilizationSumByAll.rpt";
				}
				else if(repName==	Language.TranslateSingle("ACTUTILWITHNOAGGBYSUBGRP"))
				{
					if (reportParameters.SubtotalBy != null && reportParameters.SubtotalBy != ReportItem.NoSubTotals)
					{
						// Either A or B No Sum
						if ( (reportParameters.SubtotalBy != null && reportParameters.SubtotalBy == ReportItem.NoSubTotals) &&
							((reportParameters.MajorGroup != null && reportParameters.SubGroup == null) || 
							(reportParameters.MajorGroup == null && reportParameters.SubGroup != null)))
							return "IPActualUtilizationNoSumbyAorB.rpt";
							// Both A and B No Sum
						else if ((reportParameters.SubtotalBy != null && reportParameters.SubtotalBy == ReportItem.NoSubTotals ) &&
							reportParameters.MajorGroup != null && reportParameters.SubGroup != null)
							return "IPActualUtilizationNoSumbyAandB.rpt";
							// Morg  A or B
						else if ((reportParameters.SubtotalBy == ReportItem.MasterOrg )&&
							((reportParameters.MajorGroup != null && reportParameters.SubGroup == null) || 
							(reportParameters.MajorGroup == null && reportParameters.SubGroup != null)))
							return "IPActualUtilizationSumMorgbyAorB.rpt";
							// Morg A and B
						else if ((reportParameters.SubtotalBy == ReportItem.MasterOrg ) &&
							(reportParameters.MajorGroup != null && reportParameters.SubGroup != null))
							return "IPActualUtilizationSumMorgbyAandB.rpt";
							// Org A or B
						else if ((reportParameters.SubtotalBy == ReportItem.Organization ) &&
							((reportParameters.MajorGroup != null && reportParameters.SubGroup == null) || 
							(reportParameters.MajorGroup == null && reportParameters.SubGroup != null)))
							return "IPActualUtilizationSumOrgbyAorB.rpt";
							// Org A and B
						else if ((reportParameters.SubtotalBy == ReportItem.Organization) &&
							(reportParameters.MajorGroup != null && reportParameters.SubGroup != null))
							return "IPActualUtilizationSumOrgbyAandB.rpt";
							// Sorg A or B
						else if ((reportParameters.SubtotalBy == ReportItem.SubOrganization) &&
							((reportParameters.MajorGroup != null && reportParameters.SubGroup == null) || 
							(reportParameters.MajorGroup == null && reportParameters.SubGroup != null)))
							return "IPActualUtilizationSumSorgbyAorB.rpt";
							// Sorg A and B
						else if ((reportParameters.SubtotalBy == ReportItem.SubOrganization) &&
							(reportParameters.MajorGroup != null && reportParameters.SubGroup != null))
							return "IPActualUtilizationSumSorgbyAandB.rpt";
							// Plan A or B
						else if ((reportParameters.SubtotalBy == ReportItem.Plan) &&
							((reportParameters.MajorGroup != null && reportParameters.SubGroup == null) || 
							(reportParameters.MajorGroup == null && reportParameters.SubGroup != null)))
							return "IPActualUtilizationSumPlanbyAorB.rpt";
							// Plan A and B
						else if ((reportParameters.SubtotalBy == ReportItem.Plan) &&
							(reportParameters.MajorGroup != null && reportParameters.SubGroup != null))
							return "IPActualUtilizationSumPlanbyAandB.rpt";
						else
							return "IPActualUtilizationByAll.rpt";
					}
					else
						return "IPActualUtilization.rpt";
				}
				else if(repName==	Language.TranslateSingle("IPAUTHORIZATIONSBYSTATE"))
				{
					if (this.reportParameters.SubtotalBy != null && this.reportParameters.SubtotalBy != ReportItem.NoSubTotals)
						return "IPAuthorizationsSumByAll.rpt";
					else
						return "IPAuthorizations.rpt";
				}
				else if(repName==	Language.TranslateSingle("OUTPATIENTUTILWITHNOAGGBYSUBGRP"))
				{
					if (reportParameters.SubtotalBy == ReportItem.NoSubTotals)
						return "OutpatientProcedures.rpt";
					else
						return "OutpatientProceduresSumbyAll.rpt";
				}
				else if(repName==	Language.TranslateSingle("SUMMARYOFINPATINETOUTPATIENTSAVINGS"))
				{
					if (reportParameters.SubtotalBy != null && reportParameters.SubtotalBy != ReportItem.NoSubTotals)
					{
						// Morg 
						if (reportParameters.SubtotalBy == ReportItem.MasterOrg )							
							return "SumofIPOutPSavingsSumMorg.rpt";
						else if(reportParameters.SubtotalBy == ReportItem.Organization )							
							return "SumofIPOutPSavingsSumOrg.rpt";
						else if(reportParameters.SubtotalBy == ReportItem.SubOrganization )							
							return "SumofIPOutPSavingsSumSorg.rpt";
						else if(reportParameters.SubtotalBy == ReportItem.Plan )							
							return "SumofIPOutPSavingsSumPlan.rpt";
						else
							return "SumofIPOutPSavings.rpt";
					}
					else
						return "SumofIPOutPSavings.rpt";						
				}
				else if(repName==	Language.TranslateSingle("COSTCOMPDETAILS"))
				{
					if (reportParameters.SubtotalBy == ReportItem.NoSubTotals)
						return "CostComparisonDetail.rpt";	
					else
						return "CostComparisonDetailSumbyAll.rpt";
				}
				else if(repName==	Language.TranslateSingle("COSTCOMPSUMMARY"))
				{
					if (reportParameters.SubtotalBy == ReportItem.NoSubTotals)
						return "CostComparisonSummary.rpt";
					else
						return "CostComparisonSummarySumbyAll.rpt";
				}

				else if(repName==	Language.TranslateSingle("REFERRALSUMMARYWITHNOAGGRBYSUBGRP"))
				{
					if (reportParameters.SubtotalBy != null && reportParameters.SubtotalBy != ReportItem.NoSubTotals)
					{
						// Either A or B No Sum
						if ( (reportParameters.SubtotalBy != null && reportParameters.SubtotalBy == ReportItem.NoSubTotals) &&
							((reportParameters.MajorGroup != null && reportParameters.SubGroup == null) || 
							(reportParameters.MajorGroup == null && reportParameters.SubGroup != null)))
							return "SumofReferralsNoSumbyAorB.rpt";
							// Both A and B No Sum
						else if ((reportParameters.SubtotalBy != null && reportParameters.SubtotalBy == ReportItem.NoSubTotals ) &&
							reportParameters.MajorGroup != null && reportParameters.SubGroup != null)
							return "SumofReferralsNoSumbyAandB.rpt";
							// Morg  A or B
						else if ((reportParameters.SubtotalBy == ReportItem.MasterOrg )&&
							((reportParameters.MajorGroup != null && reportParameters.SubGroup == null) || 
							(reportParameters.MajorGroup == null && reportParameters.SubGroup != null)))
							return "SumofReferralsSumMorgbyAorB.rpt";
							// Morg A and B
						else if ((reportParameters.SubtotalBy == ReportItem.MasterOrg ) &&
							(reportParameters.MajorGroup != null && reportParameters.SubGroup != null))
							return "SumofReferralsSumMorgbyAandB.rpt";
							// Org A or B
						else if ((reportParameters.SubtotalBy == ReportItem.Organization ) &&
							((reportParameters.MajorGroup != null && reportParameters.SubGroup == null) || 
							(reportParameters.MajorGroup == null && reportParameters.SubGroup != null)))
							return "SumofReferralsSumOrgbyAorB.rpt";						
							// Org A and B
						else if ((reportParameters.SubtotalBy == ReportItem.Organization) &&
							(reportParameters.MajorGroup != null && reportParameters.SubGroup != null))
							return "SumofReferralsSumOrgbyAandB.rpt";
							// Sorg A or B
						else if ((reportParameters.SubtotalBy == ReportItem.SubOrganization) &&
							((reportParameters.MajorGroup != null && reportParameters.SubGroup == null) || 
							(reportParameters.MajorGroup == null && reportParameters.SubGroup != null)))
							return "SumofReferralsSumSorgbyAorB.rpt";
							// Sorg A and B
						else if ((reportParameters.SubtotalBy == ReportItem.SubOrganization) &&
							(reportParameters.MajorGroup != null && reportParameters.SubGroup != null))
							return "SumofReferralsSumSorgbyAandB.rpt";
							// Plan A or B
						else if ((reportParameters.SubtotalBy == ReportItem.Plan) &&
							((reportParameters.MajorGroup != null && reportParameters.SubGroup == null) || 
							(reportParameters.MajorGroup == null && reportParameters.SubGroup != null)))
							return "SumofReferralsSumPlanbyAorB.rpt";
							// Plan A and B
						else if ((reportParameters.SubtotalBy == ReportItem.Plan) &&
							(reportParameters.MajorGroup != null && reportParameters.SubGroup != null))
							return "SumofReferralsSumPlanbyAandB.rpt";
						else
							return "SumOfReferrals.rpt";
					}
					else
						return "SumOfReferrals.rpt";
				}
				else if(repName==	Language.TranslateSingle("FACILITYNETWORKANALYSIS"))
					return "FacilityNetworkAnalysis.rpt";
				else if(repName==	Language.TranslateSingle("PROVIDERNETWORKANALYSIS"))
					return "ProviderNetworkAnalysis.rpt";
				else if(repName==	Language.TranslateSingle("SUMMARYOFCLOSEDCASES"))
				{
					if (reportParameters.SubtotalBy != null && reportParameters.SubtotalBy != ReportItem.NoSubTotals)
					{
						// Morg 
						if (reportParameters.SubtotalBy == ReportItem.MasterOrg )							
							return "SumofClosedCasesSumMorg.rpt";
						else if(reportParameters.SubtotalBy == ReportItem.Organization )							
							return "SumofClosedCasesSumOrg.rpt";
						else if(reportParameters.SubtotalBy == ReportItem.SubOrganization )							
							return "SumofClosedCasesSumSorg.rpt";
						else if(reportParameters.SubtotalBy == ReportItem.Plan )							
							return "SumofClosedCasesSumPlan.rpt";
						else
							return "SumofClosedCases.rpt";
					}
					else
						return "SumofClosedCases.rpt";
				}
				else if(repName==	Language.TranslateSingle("OPENCMLOGBYUSER"))
					return "OpenCMLogbyUser.rpt";
				else if(repName==	Language.TranslateSingle("OPENCMLOGBYORGLEVELS"))
					return "OpenCMLogbyOrgLevels.rpt";
				else if(repName== Language.TranslateSingle("NEWCMLOGBYORGLEVELS"))
					return "NewCMLogbyOrgLevels.rpt";
				else if(repName== Language.TranslateSingle("NEWCMLOGBYUSER"))
					return "NewCMLogbyUser.rpt";
				else if(repName== Language.TranslateSingle("CLOSEDCMLOGBYORGLEVELS"))
					return "ClosedCMLogbyOrgLevels.rpt";
				else if(repName== Language.TranslateSingle("CLOSEDCMLOGBYUSER"))
					return "ClosedCMLogbyUser.rpt";
				else if(repName==	Language.TranslateSingle("OPENMATERNICHEKLOGBYUSER"))
					return "OpenMCLogbyUser.rpt";
				else if(repName==	Language.TranslateSingle("OPENMATERNICHEKLOGBYORGLEVELS"))
					return "OpenMCLogbyOrgLevels.rpt";
				else if(repName == Language.TranslateSingle("NEWMATERNICHEKLOGBYUSER"))
					return "NewMCLogbyUser.rpt";
				else if(repName == Language.TranslateSingle("NEWMATERNICHEKLOGBYORGLEVELS"))
					return "NewMCLogbyOrgLevels.rpt";
				else if(repName == Language.TranslateSingle("CLOSEDMATERNICHEKLOGBYUSER"))
					return "ClosedMCLogbyUser.rpt";
				else if(repName == Language.TranslateSingle("CLOSEDMATERNICHEKLOGBYORGLEVELS"))
					return "ClosedMCLogbyOrgLevels.rpt";
				else if(repName == Language.TranslateSingle("MATERNICHEKRISKTYPESTATISTICS"))
					return "MaternichekStatistics.rpt";
				else if(repName==	Language.TranslateSingle("POTENTIALLARGECASES"))
					return "PotentialLargeCases.rpt";
				else if(repName==	Language.TranslateSingle("MULTIPLEADMISSIONREPORT"))
				{   
					if (reportParameters.SubtotalBy == ReportItem.NoSubTotals)
						return "MultipleAdmissionRpt.rpt";
					else
						return "MultipleAdmissionRptSumAll.rpt";
					
				}					
				else if(repName==	Language.TranslateSingle("GENERALEDIT"))
					return "GeneralEdit.rpt";
				else if(repName==	Language.TranslateSingle("ACTIVITYEDIT"))
					return "ActivityEdit.rpt";
				else if(repName==	Language.TranslateSingle("INVOICEOFBILLABLEACTIVITY"))
					return "InvoiceofBillableActivities.rpt";
				else if(repName==	Language.TranslateSingle("CODETABLEREPORT"))
					return "CodeTables.rpt";
				else if(repName==	Language.TranslateSingle("INTAKELOGWITHNOAGG"))
				{
					if (reportParameters.SubtotalBy == ReportItem.NoSubTotals)
						return "IntakeLog.rpt";
					else
						return "IntakeLogSumbyAll.rpt";
				}						
				else if(repName == Language.TranslateSingle("EVENTSTATISTICS"))
				{
					if (reportParameters.SubtotalBy == ReportItem.NoSubTotals)
						return "EventStatistics.rpt";
					else
						return "EventStatisticsSumbyAll.rpt";
				}
				
				else
					throw new ActiveAdviceException("Invalid report name");
			}
		}
	
		private void SetLoginInfo(ReportDocument repDoc)
		{
			
			try
			{
				
				// set connection information for all tables
				foreach (CrystalDecisions.CrystalReports.Engine.Table table in repDoc.Database.Tables)
				{
					
					CrystalDecisions.Shared.TableLogOnInfo login = table.LogOnInfo;
						string servername ="";
					string dbname="";
					string uid="";
					string pwd="";
					NetsoftUSA.DataLayer.NSGlobal.GetConnectionAttributes(ref servername,
								ref dbname,
								ref uid,
								ref pwd);
	
					
					login.ConnectionInfo.ServerName=servername;
					login.ConnectionInfo.DatabaseName=dbname;
					login.ConnectionInfo.UserID =uid;
					login.ConnectionInfo.Password =pwd;
					table.ApplyLogOnInfo(login);
					
					string tableLocation = table.Location;
					
						
					if (!(tableLocation.LastIndexOf(";1") > 0))
						table.Location = dbname +".dbo." +tableLocation.Substring(tableLocation.LastIndexOf(".") + 1);
					
					
				}

				

			

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
	

		public static void Redirect(ReportParameters reportParameters,string reportName)
		{
			BasePage.PushParam("ReportParameters", reportParameters);
			BasePage.PushParam("ReportNameR",reportName);
			BasePage.Redirect("Report.aspx");
		}

		private void AddParameter(string paratmeterName,object paramValue,ParameterFields parameterFields)
		{
			ParameterField paramField = new ParameterField();
			ParameterDiscreteValue discreteVal = new ParameterDiscreteValue();
			paramField.ParameterFieldName = paratmeterName;
			discreteVal.Value = paramValue;
			paramField.CurrentValues.Add(discreteVal);
			parameterFields.Add(paramField);
		}

		private void SetReportParam(ReportDocument repDoc, string paramName,object paramValue)
		{	
			try
			{
				ParameterValues paramValues = repDoc.DataDefinition.ParameterFields[paramName].CurrentValues;
				paramValues.Clear();
				ParameterDiscreteValue paramDiscreteValue = new ParameterDiscreteValue ();
				paramDiscreteValue.Value = (paramValue == null ? "" : paramValue);
				paramValues.Add (paramDiscreteValue);
				repDoc.DataDefinition.ParameterFields[paramName].ApplyCurrentValues(paramValues);
			}
			catch
			{
				this.SetPageMessage("Could not set report parameter.  Ignoring.", EnumPageMessageType.Warning);
			}
		}
		
	

		private void btnExportPDF_Click(object sender, System.EventArgs e)
		{
			ExportToPDF(this.lstMIME.SelectedValue);
		}

		/// <summary>
		///  Exports the report to a pdf file and then redirects user.
		/// </summary>
		private void ExportToPDF(string mimeType)
		{
			string expFile = Server.MapPath("Reports\\" + this.RepFileName);
			string apptype = "";
			ReportDocument repDoc = new ReportDocument();
			repDoc.Load(expFile);
			SetLoginInfo(repDoc);

			#region " ------- Set Params ---------- "

				
			SetReportParam(repDoc,"@Dates",this.reportParameters.Dates);
				
				
				
			if (IsMultiplAdmissionReport)
			{
				SetReportParam(repDoc,"@FirstDate",this.reportParameters.FromDate);
				SetReportParam(repDoc,"@LastDate",this.reportParameters.EndDate);
					
			}

			SetReportParam(repDoc,"MorgName",this.reportParameters.MorgName);
			SetReportParam(repDoc,"SorgName",this.reportParameters.SorgName);
			SetReportParam(repDoc,"OrgName",this.reportParameters.OrgName);
			SetReportParam(repDoc,"SubtotalBy",reportParameters.SubtotalBy);
			SetReportParam(repDoc,"Team",this.reportParameters.TeamName);
			SetReportParam(repDoc,"User",this.reportParameters.UserName);
			SetReportParam(repDoc,"Plan",this.reportParameters.PlanName);
			SetReportParam(repDoc,"State",this.reportParameters.StateName);
			SetReportParam(repDoc,"CMSType",this.reportParameters.CmsTypeName);
			SetReportParam(repDoc,"Outliers",this.reportParameters.Outliers);
			SetReportParam(repDoc,"NewbornsDischargedwithMom",this.reportParameters.NewBornDischargedWithMother);
			SetReportParam(repDoc,"TableName",this.reportParameters.CodeTable);			
			SetReportParam(repDoc,"SubGroup",this.reportParameters.SubGroup);
			SetReportParam(repDoc,"MajorGroup",this.reportParameters.MajorGroup);
			SetReportParam(repDoc,"ReadmitDays",this.reportParameters.ReadmitDays);
			SetReportParam(repDoc,"SortBy",this.reportParameters.SortBy);
			SetReportParam(repDoc,"SubSubGroup",this.reportParameters.SubSubGroup);
			SetReportParam(repDoc,"ShowDetails",this.reportParameters.ShowDetails);
				
			if (!IsMultiplAdmissionReport)
			{
				if(this.reportParameters.DateType == 0)
				{
					SetReportParam(repDoc,"Date",this.reportParameters.EndDate);
				}
				else
				{
					ParameterValues paramValues = repDoc.DataDefinition.ParameterFields["Date"].CurrentValues;
					paramValues.Clear();
					ParameterRangeValue rangeVal = new ParameterRangeValue();
					rangeVal.StartValue = this.reportParameters.FromDate;
					rangeVal.EndValue = this.reportParameters.EndDate;
					paramValues.Add (rangeVal);
					repDoc.DataDefinition.ParameterFields["Date"].ApplyCurrentValues(paramValues);
				}
			}
			#endregion

			
			
			ExportFormatType expType = ExportFormatType.NoFormat;
			string           extension = null;
			#region "Set MIME Type"
			switch( mimeType )
			{
				case "xls":
					expType		= ExportFormatType.Excel;
					extension	= "xls";
					apptype		= "application/vnd.ms-excel";
					break;
				case "word":
					expType		= ExportFormatType.WordForWindows;
					extension   = "doc";
					apptype		= "application/msword";
					break;
				default:
					expType		= ExportFormatType.PortableDocFormat;
					extension	= "pdf";
					apptype		= "application/pdf";
					break;		
			}
			#endregion 
			MemoryStream oStream; // using System.IO

			oStream = (MemoryStream)
				repDoc.ExportToStream(
				expType);
			Response.Clear();
			Response.Buffer= true;
			Response.ContentType = apptype;
			Response.BinaryWrite(oStream.ToArray());
			Response.End();
			
			
			/*
			DiskFileDestinationOptions diskFileDestOpt = new DiskFileDestinationOptions();
			string outFile = "Login_" + ActiveAdvice.DataLayer.AASecurityHelper.GetUserId + "_report." + extension;
			diskFileDestOpt.DiskFileName = Server.MapPath("Reports\\" + outFile);
			ExportOptions expOptions = repDoc.ExportOptions;
			expOptions.DestinationOptions = diskFileDestOpt;
			expOptions.ExportDestinationType = ExportDestinationType.DiskFile;
			expOptions.ExportFormatType = expType;
		
			
			repDoc.Export();
			repDoc.Close();
		

			BasePage.Redirect("Reports\\" + outFile);*/

		
		}


	
		
	}
}
