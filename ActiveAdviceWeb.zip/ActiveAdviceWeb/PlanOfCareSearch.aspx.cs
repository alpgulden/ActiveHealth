using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for PlanOfCareSearch.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.CMSMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("CMS,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("Summary")]
	[SelectedMainMenuItem("MPatient")]
	[PageTitle("@DGIPAGETITLE@")]
	public class PlanOfCareSearch : PatientBasePage
	{
		private POCInterventionFilter pOCInterventionFilter;
		private CMS cMS;
		private POCInterventionCollection pOCInterventions;

		private Patient patient;
		private PatientCoverage patientCoverage;
		private Problem problem;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFilter;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnReset;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInterventionTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInterventionTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompletionID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOpenWithAll;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompletedBy;
		protected NetsoftUSA.WebForms.OBCheckBox IsBillable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIsBillable;
		protected System.Web.UI.WebControls.RadioButtonList rblDateFilter;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFilterDateFrom;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FilterDateFrom;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFilterDateFrom;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFilterDateTo;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FilterDateTo;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFilterDateTo;
		protected NetsoftUSA.WebForms.OBComboBox InterventionTypeID;
		protected NetsoftUSA.WebForms.OBComboBox CompletedBy;
		protected NetsoftUSA.WebForms.OBComboBox CompletionID;
		protected NetsoftUSA.WebForms.OBComboBox OpenWithAll;
		protected NetsoftUSA.WebForms.OBButton wbtnFilter;
		
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.wbtnFilter.Click += new System.EventHandler(this.wbtnFilter_Click);
			this.wbtnReset.Click += new System.EventHandler(this.wbtnReset_Click);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
			{
				LoadDataForCMS();
				NewPOCInterventionFilter();
				BindDateFilterOptions();
			}
			else
			{
				cMS = (CMS)this.LoadObject(typeof(CMS));	// This would reload from cache
				if (cMS != null)
					pOCInterventions = cMS.POCInterventions;
				//pOCInterventions = (POCInterventionCollection)this.LoadObject(typeof(POCInterventionCollection));  // load object from cache
				pOCInterventionFilter = (POCInterventionFilter)this.LoadObject(typeof(POCInterventionFilter));  // load object from cache
			}

			problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
			patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
			patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
		}	

		#region CMS
		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForCMS()
		{
			bool result = true;
			CMS cMS = null;
			try
			{	// use any load method here
				cMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;
				if (cMS == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a CMS");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//cMS.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.cMS = cMS;
			LoadDataForPOCInterventions();
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(CMS cMS)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CMS", cMS);
			PushTargetTab("POC_PlanOfCareSearch");
			BasePage.Redirect("PlanOfCareSearch.aspx");

		}
		#endregion

		#region POCInterventions
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public POCInterventionCollection POCInterventions
		{
			get { return pOCInterventions; }
			set
			{
				pOCInterventions = value;
				try
				{
					grid.UpdateFromCollection(pOCInterventions);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// don't cache it, get it from cMS.POCIntervetions in the page load.
				//this.CacheObject(typeof(POCInterventionCollection), pOCInterventions);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForPOCInterventions()
		{
			bool result = true;
			POCInterventionCollection pOCInterventions = new POCInterventionCollection();
			try
			{	// use any load method here
				this.cMS.LoadPOCInterventions(true); // always load from DB
				pOCInterventions = this.cMS.POCInterventions;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//pOCInterventions.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.POCInterventions = pOCInterventions;
			return result;
		}


		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			POCInterventionCollection pOCInterventions = new POCInterventionCollection();
			try
			{
//				if (!this.ReadControlsForSearcherObject()) // Use appropriate read controls method to read the searcher object from controls 
//					return false;
//					pOCInterventions.FilterElement(index);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//pOCInterventions.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.POCInterventions = pOCInterventions;
			return result;
		}
		#endregion

		#region POCInterventionFilter
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public POCInterventionFilter POCInterventionFilter
		{
			get { return pOCInterventionFilter; }
			set
			{
				pOCInterventionFilter = value;
				try
				{
					this.UpdateFromObject(this.pnlFilter.Controls, pOCInterventionFilter);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(POCInterventionFilter), pOCInterventionFilter);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPOCInterventionFilter()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlFilter.Controls, pOCInterventionFilter);	// controls-to-object
				// other control-to-object methods if any
				pOCInterventionFilter.DateType = SelectedDateFilter;
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPOCInterventionFilter()
		{
			bool result = true;
			POCInterventionFilter pOCInterventionFilter = null; //new POCInterventionFilter(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				pOCInterventionFilter = new POCInterventionFilter();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.POCInterventionFilter = pOCInterventionFilter;
			return result;
		}

		private void FilterDataForPOCInterventions(bool reset)
		{
			try
			{
				if(reset)
				{
					NewPOCInterventionFilter();
					this.pOCInterventions.FilterObject = null;
				}
				else
				{
					if(!this.ReadControlsForPOCInterventionFilter())
						FilterDataForPOCInterventions(true); 	// If can't read controls for filter object show everything = reset
					this.pOCInterventions.FilterObject = this.pOCInterventionFilter;
				}
				POCInterventions = this.pOCInterventions;
				grid.SelectedRowIndex = 0;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
		}
		#endregion

		#region UI Initializations and Events
		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.cMS);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			/*
			 * PlanOfCareForm.aspx is not fully implemented and
			 * not part of this release. So no redirections to that page should occur.
			if(tab.Key == "POC_PlanOfCareSearch")
				toolbar.AddButton("@ADDINTERVENTION@", "AddNewIntervention");
				*/
		}

//		public void OnToolbarButtonClick_AddNewIntervention(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
//		{
//			POCIntervention intv = new POCIntervention(true);
//			PlanOfCareForm.Redirect(intv);
//		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.Cancel);
		}

		new public void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			DGIForm.Redirect(this.cMS);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.SetERCTabVisibilities();
			SetPageTabItemActive(TargetTabKey);

			this.RenderClientFunctions(this.pnlFilter.Controls, this.pOCInterventionFilter, "DateCheck");
		}

		private void wbtnFilter_Click(object sender, System.EventArgs e)
		{
			FilterDataForPOCInterventions(false);
		}

		private void wbtnReset_Click(object sender, System.EventArgs e)
		{
			FilterDataForPOCInterventions(true);
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{	
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			if (e.Cell.Key == "Edit")
			{
				//PlanOfCareForm.Redirect(POCInterventions[index]);
				DGIForm.Redirect(POCInterventions[index]);
			}
		}

		private void BindDateFilterOptions()
		{
			rblDateFilter.Items.Clear();
			rblDateFilter.Items.Add(new ListItem("Due Date", POCIntervention.DateType.Due.ToString()));
			rblDateFilter.Items.Add(new ListItem("Completion Date", POCIntervention.DateType.Completion.ToString()));
			rblDateFilter.SelectedIndex = 0;
		}

		private POCIntervention.DateType SelectedDateFilter
		{
			get { return (POCIntervention.DateType)Enum.Parse(typeof(POCIntervention.DateType), this.rblDateFilter.SelectedValue, true); }
		}
		#endregion

		
	}
}
