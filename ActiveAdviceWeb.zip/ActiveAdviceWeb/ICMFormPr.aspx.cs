using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for ICMFormPr.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterScoringLoadParagraphTrigger,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("IcmPR")]
	public class ICMFormPr : AssessmentMaintenanceBasePage
	{
		private LetterScoringLoadParagraphTrigger letterScoringLoadParagraphTrigger;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.WebForms.OBCheckBox IncludeNoCCOnLetter;
		protected NetsoftUSA.WebForms.OBCheckBox IncludeCCOnLetter;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAttributeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo AttributeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAttributeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAssessmentParagraphID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo AssessmentParagraphID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAssessmentParagraphID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAssessmentCategoryID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo AssessmentCategoryID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAssessmentCategoryID;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSORGId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationId;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganizationSearch;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtOrganizationPath;
		protected System.Web.UI.WebControls.Label lblOrganizationName;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.AssessmentCategoryID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.AssessmentCategoryID_SelectedRowChanged);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				LoadDataForLetterScoringLoadParagraphTrigger();
			else
				letterScoringLoadParagraphTrigger = (LetterScoringLoadParagraphTrigger)this.LoadObject(typeof(LetterScoringLoadParagraphTrigger));  // load object from cache

		}

		#region LetterScoringLoadParagraphTrigger
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterScoringLoadParagraphTrigger LetterScoringLoadParagraphTrigger
		{
			get { return letterScoringLoadParagraphTrigger; }
			set
			{
				letterScoringLoadParagraphTrigger = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, letterScoringLoadParagraphTrigger);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterScoringLoadParagraphTrigger), letterScoringLoadParagraphTrigger);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLetterScoringLoadParagraphTrigger()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, letterScoringLoadParagraphTrigger);	// controls-to-object
				// other control-to-object methods if any
				this.lblOrganizationName.Text = letterScoringLoadParagraphTrigger.OrganizationPath;
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewLetterScoringLoadParagraphTrigger()
		{
			bool result = true;
			LetterScoringLoadParagraphTrigger letterScoringLoadParagraphTrigger = null; //new LetterScoringLoadParagraphTrigger(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				letterScoringLoadParagraphTrigger = new LetterScoringLoadParagraphTrigger(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.LetterScoringLoadParagraphTrigger = letterScoringLoadParagraphTrigger;
			this.lblOrganizationName.Text = "All";
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForLetterScoringLoadParagraphTrigger()
		{
			bool result = true;
			LetterScoringLoadParagraphTrigger letterScoringLoadParagraphTrigger = null;
			try
			{	// use any load method here
				letterScoringLoadParagraphTrigger = (LetterScoringLoadParagraphTrigger)this.GetParam("LetterScoringLoadParagraphTrigger", null);
				if(letterScoringLoadParagraphTrigger == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an LetterScoringLoadParagraphTrigger");
				if(letterScoringLoadParagraphTrigger.OrganizationId > 0)
				{
					Organization o = new Organization();
					if (o.Load(letterScoringLoadParagraphTrigger.OrganizationId))
						this.lblOrganizationName.Text = CreateOrgPathHTML(null, o);
				}
				else
					this.lblOrganizationName.Text = "All";
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterScoringLoadParagraphTrigger.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterScoringLoadParagraphTrigger = letterScoringLoadParagraphTrigger;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(LetterScoringLoadParagraphTrigger letterScoringLoadParagraphTrigger)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("LetterScoringLoadParagraphTrigger", letterScoringLoadParagraphTrigger);
			BasePage.Redirect("ICMFormPr.aspx");

		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForLetterScoringLoadParagraphTrigger()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForLetterScoringLoadParagraphTrigger())
					return false;
				letterScoringLoadParagraphTrigger.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region UI Initialization and Events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			//pageSummary.RenderObjects(this.patient, this.erc);
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForLetterScoringLoadParagraphTrigger())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Trigger ");
			}
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Details":
					toolbar.AddButton(Messages.BaseMessages.MessageIDs.ADDNEWRECORD, "AddNewTrigger");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewTrigger(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewLetterScoringLoadParagraphTrigger();
		}

		private void AssessmentCategoryID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			// use this event to refresh Paragraphs combo
			this.AssessmentParagraphID.ClearRows();
			this.UpdateToObject(this.AssessmentCategoryID, this.letterScoringLoadParagraphTrigger);
			this.UpdateFromObject(this.AssessmentParagraphID, this.letterScoringLoadParagraphTrigger);
		}
		#endregion
	}
}
