using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Clinical Review summary page.
	/// Displays Request/Decision totals grouped by either Approved/Denied status or Decision Type.
	/// </summary>
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.EVENTS)]

	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("ClinicalReviewTotal,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[PageTitle("@CLINICALREVIEWSUMMARY@")]
	public class ClinicalReviewSummary : BasePage
	{
		private ClinicalReviewTotalCollection clinicalReviewTotals;
		private Event eventObj;

		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBLabel lbPrompt;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel GridTitle;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGroupBy;
		protected NetsoftUSA.WebForms.OBRadioButtonBox GroupBy;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;

		private int lastReqUOMID = -1;		// tracks the change in ReqUOMID.  we display ReqAmount only once for the same ReqUOMID group

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			// Always get the e/r/c from context.
			eventObj = (Event)this.LoadObject(typeof(Event));
			if (!this.IsPostBack)
			{
				BindCoverageFilterOptions();
				SearchForClinicalReviewTotals();
			}
			else
			{
			}

		}

		private void BindCoverageFilterOptions()
		{
			GroupBy.Items.Clear();
			GroupBy.AddItemAndTranslate("@DECISIONTYPE@", ClinicalReviewTotal.GROUPBYDECISIONTYPE);
			GroupBy.AddItemAndTranslate("@APPROVEDDENIED@", ClinicalReviewTotal.GROUPBYDECISIONCODETYPE);
			GroupBy.SelectedIndex = 1;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();

			GroupBy.SelectedIndexChanged +=new EventHandler(GroupBy_SelectedIndexChanged);
			grid.BeforeColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_BeforeColumnsBoundToDataClass);
			grid.RowBoundToDataObject +=new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(grid_RowBoundToDataObject);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.PrintablePage = true;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@CLOSE@", "Close", false).Item.TargetURL = "javascript:window.close()";
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ClinicalReviewTotalCollection ClinicalReviewTotals
		{
			get { return clinicalReviewTotals; }
			set
			{
				clinicalReviewTotals = value;
				try
				{
					grid.KeepCollectionIndices = false;  // update given grid from the collection
					grid.KeepPKs = false;
					grid.UpdateFromCollection(clinicalReviewTotals);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(ClinicalReviewTotalCollection), clinicalReviewTotals);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool SearchForClinicalReviewTotals()
		{
			bool result = true;
			ClinicalReviewTotalCollection clinicalReviewTotals = new ClinicalReviewTotalCollection();
			try
			{
				clinicalReviewTotals.CalculateClinicalReviewTotals(eventObj.EventID, GroupBy.SelectedValue);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//clinicalReviewTotals.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.ClinicalReviewTotals = clinicalReviewTotals;
			return result;
		}

		/* Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMORGSearch();
		}
		*/

		private void GroupBy_SelectedIndexChanged(object sender, EventArgs e)
		{
			SearchForClinicalReviewTotals();
		}

		private void grid_BeforeColumnsBoundToDataClass(object sender, EventArgs e)
		{
			lastReqUOMID = -1;
			grid.Columns.Clear();
			grid.AddColumn("ReqAmount", "@REQAMOUNT@", true);
			grid.AddColumn("ReqUOMID", "@REQUOMID@", true);
			if (this.GroupBy.SelectedValue == ClinicalReviewTotal.GROUPBYDECISIONTYPE)
				grid.AddColumn("DecisionTypeID", "@DECISIONTYPE@", true);
			else
				grid.AddColumn("DecisionTypeCodeID", "@APPROVEDDENIED@", true);
			grid.AddColumn("DecAmount", "@DECAMOUNT@", true);
			grid.AddColumn("DecUOMID", "@DECUOMID@", true);
			grid.AddColumn("ActualAmount", "@ACTUALAMOUNT@", true);
		}

		private void grid_RowBoundToDataObject(object sender, RowBindingEventArgs e)
		{
			ClinicalReviewTotal totalRow = (ClinicalReviewTotal)e.data;
			if (totalRow.ReqUOMID == lastReqUOMID)
			{
				// The RequUOMID repeats, we don't display the total for ReqAmount
				e.row.Cells.FromKey("ReqAmount").Text = "";
			}
			lastReqUOMID = totalRow.ReqUOMID;
		}
	}
}
