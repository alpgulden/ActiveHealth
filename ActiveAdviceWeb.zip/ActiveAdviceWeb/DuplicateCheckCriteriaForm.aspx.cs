using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;
namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.DuplicateCheckCriteriaMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("ReferralDuplicateCheckCriteria,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu	
	[SelectedMainMenuItem("MMaintenance")]
	public class DuplicateCheckCriteriaForm : BasePage
	{
		private EventDuplicateCheckCriteria eventDuplicateCheckCriteria;
		private ReferralDuplicateCheckCriteria referralDuplicateCheckCriteria;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.	
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;	
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder6;
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder7;
		protected NetsoftUSA.WebForms.WindowOpener wo;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.WebForms.OBCheckBox TreatingProvFacGroup;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTreatingProvFacGroup;
		protected NetsoftUSA.WebForms.OBCheckBox ServiceType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbServiceType;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBCheckBox ReferringProvider;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferringProvider;
		protected System.Web.UI.HtmlControls.HtmlTableRow rowExactMatch;
		protected System.Web.UI.HtmlControls.HtmlTableRow rowServiceType;
		protected System.Web.UI.HtmlControls.HtmlTableRow rowTreatingGroup;
		protected System.Web.UI.HtmlControls.HtmlTableRow rowReferringProvider;
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbExactMatch;
		protected NetsoftUSA.WebForms.OBCheckBox ExactMatch;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDays;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Days;
		protected System.Web.UI.WebControls.RadioButtonList rdButton;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected System.Web.UI.HtmlControls.HtmlTableRow rowDays;
		protected Type	objType;
	
		


		private void Page_Load(object sender, System.EventArgs e)
		{				
			if (!this.IsPostBack)
			{							
				this.LoadData();			// Load data is the actual data loading method		
			}
			else
			{
				eventDuplicateCheckCriteria = (EventDuplicateCheckCriteria)this.LoadObject(typeof(EventDuplicateCheckCriteria));  // load object from cache
				referralDuplicateCheckCriteria = (ReferralDuplicateCheckCriteria)this.LoadObject(typeof(ReferralDuplicateCheckCriteria));  // load object from cache					
			}
		}


		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);
			listbar.AddItem(true,"Event Duplicate Check Criteria","Event",false);
			listbar.AddItem(true,"Referral Duplicate Check Criteria","Referral",false);
		}

		public void OnSubNavigationItemClick_Event(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			DuplicateCheckCriteriaForm.Redirect(typeof(EventDuplicateCheckCriteria));
		}

		public void OnSubNavigationItemClick_Referral(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			DuplicateCheckCriteriaForm.Redirect(typeof(ReferralDuplicateCheckCriteria));
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);

			this.SetPageToolbarItemVisible("Save", (this.EventDuplicateCheckCriteria != null || this.ReferralDuplicateCheckCriteria != null));
			this.SetPageToolbarItemVisible("Cancel",!(this.objType == null));

			if(rdButton.SelectedIndex==0)
			{
				rowExactMatch.Visible=true;				
				rowDays.Visible=false;
				//Days.Value=0;
			}
			else
			{
				rowDays.Visible=true;
				rowExactMatch.Visible=false;
				//ExactMatch.Checked=false;
			}
		}

		/// <summary>
		/// Redirect to current referral
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("DuplicateCheckCriteriaForm.aspx");
		}

		public static void Redirect(Type type)
		{
			if (typeof(EventDuplicateCheckCriteria) == type)
			{
				BasePage.PushParam("criteriaType", type);
				Redirect();
			}
			else if (typeof(ReferralDuplicateCheckCriteria) == type)
			{
				BasePage.PushParam("criteriaType", type);
				Redirect();
			}
			else
				throw new Exception("Unexpected type");
		
		
			
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;

			// set page properties to null
			objType								= null;
			this.referralDuplicateCheckCriteria = null;
			this.eventDuplicateCheckCriteria	= null;
			this.SetPageToolbarItemVisible("Save",false);
			//this.SetPageToolbarItemVisible("Cancel",false);
			
			// get objType
			objType = this.GetParam("criteriaType",null) as Type;
		
			if (objType != null)
			{
				if (objType == typeof(EventDuplicateCheckCriteria))
				{
					this.eventDuplicateCheckCriteria	= new EventDuplicateCheckCriteria();
					this.eventDuplicateCheckCriteria.LoadCriteria(); // load from DB
					this.EventDuplicateCheckCriteria	= this.eventDuplicateCheckCriteria;
					this.ReferralDuplicateCheckCriteria = null;
					setradioitems(typeof(EventDuplicateCheckCriteria));
					
				}
				else if (objType == typeof(ReferralDuplicateCheckCriteria))
				{
					// set page obj to referralduplicate criteria
					this.referralDuplicateCheckCriteria = new ReferralDuplicateCheckCriteria();
					this.referralDuplicateCheckCriteria.LoadCriteria();
					this.ReferralDuplicateCheckCriteria	= this.referralDuplicateCheckCriteria;
					this.EventDuplicateCheckCriteria	= null;
					setradioitems(typeof(ReferralDuplicateCheckCriteria));
				}
			}				
				return result;
		}

	
		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			
			// check the type first.
			if (this.ReferralDuplicateCheckCriteria != null)
			{
				if (this.ReadControlsForReferralDuplicateCheckCriteria())
					this.ReferralDuplicateCheckCriteria.Save();
				else 
					return false;
			}
			else if (this.EventDuplicateCheckCriteria != null)
			{
				if (this.ReadControlsForEventDuplicateCheckCriteria())
					this.EventDuplicateCheckCriteria.Save();
				else
					return false;
			}
			return true;
		}

		


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
 
		private void InitializeComponent()
		{   
			this.rdButton.SelectedIndexChanged += new System.EventHandler(this.rdButton_SelectedIndexChanged);
			this.ExactMatch.CheckedChanged += new System.EventHandler(this.ExactMatch_CheckedChanged);
			this.Days.ValueChange += new Infragistics.WebUI.WebDataInput.ValueChangeHandler(this.Days_ValueChange);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}

		#endregion

		


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
	
			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@SAVERECORD@", "Save").Visible = false;
			toolbar.AddButton("@CANCEL@", "Cancel").Visible  = false;
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info,"@SETTINGS@");
			}
		}

		public void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			DuplicateCheckCriteriaForm.Redirect();
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ReferralDuplicateCheckCriteria ReferralDuplicateCheckCriteria
		{
			get { return referralDuplicateCheckCriteria; }
			set
			{
				referralDuplicateCheckCriteria = value;
				try
				{
					if (value != null)
					{
						this.ContentPanel1.Visible = this.rowReferringProvider.Visible = true;
						OBLabel2.Text = "REFERRAL" + " " + OBLabel2.Text;
						this.SetPageToolbarItemVisible("Save",true);
						this.UpdateFromObject(this.rowExactMatch.Controls, referralDuplicateCheckCriteria);  // update controls for the given control collection
						this.UpdateFromObject(this.rowDays.Controls, referralDuplicateCheckCriteria);  // update controls for the given control collection
						this.UpdateFromObject(this.rowReferringProvider.Controls, referralDuplicateCheckCriteria);  // update controls for the given control collection
						this.UpdateFromObject(this.rowServiceType.Controls, referralDuplicateCheckCriteria);  // update controls for the given control collection
						this.UpdateFromObject(this.rowTreatingGroup.Controls, referralDuplicateCheckCriteria);  // update controls for the given control collection
						this.setradioitems(typeof(ReferralDuplicateCheckCriteria));
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(ReferralDuplicateCheckCriteria), referralDuplicateCheckCriteria);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForReferralDuplicateCheckCriteria()
		{
			try
			{	//customize this method for this specific page
				if (this.rdButton.SelectedIndex == 0)
					referralDuplicateCheckCriteria.ExactMatch = true;
				else
					referralDuplicateCheckCriteria.ExactMatch = false;
				
				this.UpdateToObject(this.rowReferringProvider.Controls, referralDuplicateCheckCriteria);	// controls-to-object
				this.UpdateToObject(this.rowServiceType.Controls, referralDuplicateCheckCriteria);	// controls-to-object
				this.UpdateToObject(this.rowDays.Controls, referralDuplicateCheckCriteria);
				this.UpdateToObject(this.rowTreatingGroup.Controls, referralDuplicateCheckCriteria);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EventDuplicateCheckCriteria EventDuplicateCheckCriteria
		{
			get { return eventDuplicateCheckCriteria; }
			set
			{
				eventDuplicateCheckCriteria = value;
				try
				{
					if (value != null)
					{
						this.ContentPanel1.Visible = true;
						this.rowReferringProvider.Visible = false;
						OBLabel2.Text = "EVENT" + " " + OBLabel2.Text;
						this.SetPageToolbarItemVisible("Save",true);
						this.UpdateFromObject(this.rowExactMatch.Controls, eventDuplicateCheckCriteria);  // update controls for the given control collection
						this.UpdateFromObject(this.rowDays.Controls, eventDuplicateCheckCriteria);  // update controls for the given control collection
						this.UpdateFromObject(this.rowServiceType.Controls, eventDuplicateCheckCriteria);  // update controls for the given control collection
						this.UpdateFromObject(this.rowTreatingGroup.Controls, eventDuplicateCheckCriteria);  // update controls for the given control collection
						this.setradioitems(typeof(EventDuplicateCheckCriteria));

					}
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(EventDuplicateCheckCriteria), eventDuplicateCheckCriteria);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForEventDuplicateCheckCriteria()
		{
			try
			{	//customize this method for this specific page
				if (this.rdButton.SelectedIndex == 0)
					eventDuplicateCheckCriteria.ExactMatch = true;
				else
					eventDuplicateCheckCriteria.ExactMatch = false;
				
				this.UpdateToObject(this.rowServiceType.Controls, eventDuplicateCheckCriteria);	// controls-to-object
				this.UpdateToObject(this.rowDays.Controls, eventDuplicateCheckCriteria);
				this.UpdateToObject(this.rowTreatingGroup.Controls, eventDuplicateCheckCriteria);	// controls-to-object
				
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private void setradioitems(Type objType)
		{
			rdButton.Items.Clear();
			rdButton.Items.Add(this.Language.TranslateSingle("EXACTMATCH"));
			rdButton.Items.Add(this.Language.TranslateSingle("DAYS"));
			if (objType == typeof(EventDuplicateCheckCriteria))
			{				
				if(eventDuplicateCheckCriteria.ExactMatch)
					rdButton.Items[0].Selected=true;
				else
					rdButton.Items[1].Selected=true;
			}
			else
			{
				if(referralDuplicateCheckCriteria.ExactMatch)
					rdButton.Items[0].Selected=true;
				else
					rdButton.Items[1].Selected=true;
			}
		}

		private void rdButton_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private void ExactMatch_CheckedChanged(object sender, System.EventArgs e)
		{
			Days.Value=0;
		}

		private void Days_ValueChange(object sender, Infragistics.WebUI.WebDataInput.ValueChangeEventArgs e)
		{
			ExactMatch.Checked=false;
		}
	}
}
