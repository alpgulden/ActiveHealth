using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterMatrixSearch.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.LETTER_SETUP)]
	
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterMatrix,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("LetterMatrix")]
	[PageTitle("@LETTERMATRIXSEARCHPAGETITLE@")]
	public class LetterMatrixSearch : LetterMaintenanceBasePage
	{
		private LetterMatrixExceptionCollection letterMatrixExceptions;
		private LetterMatrixCollection letterMatrixes;
		private LetterMatrix letterMatrixSearcher;
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActiveWithTerminatedAndAll;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActiveWithTerminatedAndAll;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActiveWithTerminatedAndAll;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlExceptions;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridExceptions;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddException;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.wbtnSearch.Click += new System.EventHandler(this.wbtnSearch_Click);
			this.gridExceptions.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridExceptions_ClickCellButton);
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grid_ColumnsBoundToDataClass);
			this.wbtnAddException.Click += new System.EventHandler(this.wbtnAddException_Click);
			
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			
			if (!IsPostBack)
				NewLetterMatrixSearcher();
			else
			{
				letterMatrixSearcher = (LetterMatrix)this.LoadObject("LetterMatrixSearcher");  // load object from cache
				letterMatrixes = (LetterMatrixCollection)this.LoadObject(typeof(LetterMatrixCollection));  // load object from cache
				letterMatrixExceptions = (LetterMatrixExceptionCollection)this.LoadObject(typeof(LetterMatrixExceptionCollection));  // load object from cache
			}
		}

		#region Data Objects
		#region LetterMatrixSearcher
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterMatrix LetterMatrixSearcher
		{
			get { return letterMatrixSearcher; }
			set
			{
				letterMatrixSearcher = value;
				try
				{
					this.UpdateFromObject(this.pnlSearch.Controls, letterMatrixSearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("LetterMatrixSearcher", letterMatrixSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLetterMatrixSearcher()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSearch.Controls, letterMatrixSearcher);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewLetterMatrixSearcher()
		{
			bool result = true;
			LetterMatrix letterMatrixSearcher = null; //new LetterMatrix(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				letterMatrixSearcher = new LetterMatrix();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.LetterMatrixSearcher = letterMatrixSearcher;
			this.ActiveWithTerminatedAndAll.SelectedRow = this.ActiveWithTerminatedAndAll.Rows[0];
			return result;
		}
		#endregion

		#region LetterMatrixes
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterMatrixCollection LetterMatrixes
		{
			get { return letterMatrixes; }
			set
			{
				letterMatrixes = value;
				try
				{
					grid.UpdateFromCollection(letterMatrixes);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(LetterMatrixCollection), letterMatrixes);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			LetterMatrixCollection letterMatrixes = new LetterMatrixCollection();
			try
			{
				if (!this.ReadControlsForLetterMatrixSearcher()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				letterMatrixes = LetterMatrixCollection.GetFromSearch(this.letterMatrixSearcher);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterMatrixes.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterMatrixes = letterMatrixes;
			return result;
		}
		#endregion

		#region LetterMatrixExceptions
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterMatrixExceptionCollection LetterMatrixExceptions
		{
			get { return letterMatrixExceptions; }
			set
			{
				letterMatrixExceptions = value;
				try
				{
					this.gridExceptions.UpdateFromCollection(letterMatrixExceptions);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterMatrixExceptionCollection), letterMatrixExceptions);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForLetterMatrixExceptions()
		{
			bool result = true;
			LetterMatrixExceptionCollection letterMatrixExceptions = new LetterMatrixExceptionCollection();
			try
			{	// use any load method here
				int index = this.grid.SelectedRowIndex; // Selected LetterMatrix
				if(index < -1 && this.grid.Rows.Count < 1)
					return false;
				index = (index == -1 ? 0 : index); // if no row was selected use first row
				
				this.LetterMatrixes[index].LoadLetterMatrixExceptions(false);
				letterMatrixExceptions = LetterMatrixes[index].LetterMatrixExceptions;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterMatrixExceptions.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterMatrixExceptions = letterMatrixExceptions;
			return result;
		}
		#endregion
		#endregion

		#region UI Events and Initialization
		private void wbtnSearch_Click(object sender, System.EventArgs e)
		{
			Search();
			if(this.LetterMatrixes.Count > 0)
			{
				grid.SelectedRowIndex = 0;
				this.LoadDataForLetterMatrixExceptions();
			}
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
				LetterMatrixMaintenance.Redirect(LetterMatrixes[index]);
			else if(e.Cell.Key == "Select")
			{
				LetterMatrixes[index].LoadLetterMatrixExceptions(false);
				LetterMatrixExceptions = LetterMatrixes[index].LetterMatrixExceptions;
			}
		}

		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			grid.AddButtonColumn("Select", "@SELECT@", 0);
		}

		private void gridExceptions_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridExceptions.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			if (e.Cell.Key == "Edit")
				LetterMatrixExceptionMaintenance.Redirect(this.LetterMatrixExceptions[index]);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Search":
					toolbar.AddButton(Messages.BaseMessages.MessageIDs.ADDNEWRECORD, "AddNewLetterMatrix");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewLetterMatrix(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			LetterMatrix lm = new LetterMatrix(true);
			LetterMatrixMaintenance.Redirect(lm);
		}

		private void wbtnAddException_Click(object sender, System.EventArgs e)
		{
			LetterMatrixException lme = new LetterMatrixException(true);
			lme.MatrixID = LetterMatrixes[this.grid.SelectedRowIndex].MatrixID;
			LetterMatrixExceptionMaintenance.Redirect(lme);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			wbtnAddException.Visible = (this.grid.SelectedRowIndex >= 0);
		}


		#endregion

		
	}
}
