using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Text;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ProviderMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Provider,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MProviderFacility")]
	[SelectedMenuItem("Providers")]
	[PageTitle("@PROVIDERSEATCHTITLE@")]
	public class ProviderSearch : ProviderBasePage
	{
		private NetworkPlanLink searchNetworkPlanLink;
		private ProviderLocationNetworkLink searchProviderNetworkLink;
		private Location providerLocationSearch;
		private ProviderLocationCollection locationSearchResults;
		private ProviderCollection providerSearchResults;
		private ProviderLanguage searchLanguage;
		private ProviderLocationService searchProviderService;
		private ProviderSpecialty searchSpecialty;
		private ProviderFocus searchProviderFocus;
		private Address searchProviderAddress;
		private Provider searchProviderInfo;

		// variables used in paging.
		private int startProviderId = 0;
		private string startLastName = "";
		private string startFirstName = "";
		
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBValidator vldEmail;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Email;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEmail;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGender;
		protected NetsoftUSA.WebForms.OBValidator vldFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCounty;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit County;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCounty;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldZip;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit Zip;
		protected NetsoftUSA.WebForms.OBFieldLabel lbZip;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldState;
		protected NetsoftUSA.WebForms.OBComboBox State;
		protected NetsoftUSA.WebForms.OBFieldLabel lbState;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCity;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit City;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCity;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProviderFocusTypeID;
		protected NetsoftUSA.WebForms.OBComboBox ProviderFocusTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProviderFocusTypeID;
		protected System.Web.UI.HtmlControls.HtmlTable tblFocus;
		protected System.Web.UI.HtmlControls.HtmlTable tblAddress;
		protected System.Web.UI.HtmlControls.HtmlTable tblBasicInfo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGender;
		protected NetsoftUSA.WebForms.OBComboBox Gender;	
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLanguageID;
		protected NetsoftUSA.WebForms.OBComboBox LanguageID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProviderServiceTypeID;
		protected NetsoftUSA.WebForms.OBComboBox ProviderServiceTypeID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected System.Web.UI.HtmlControls.HtmlTable tblServices;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSpecialtyID;
		protected NetsoftUSA.WebForms.OBComboBox SpecialtyID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected System.Web.UI.HtmlControls.HtmlTable tblSpecialties;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSearchName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearchName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResults;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviders;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviderLocations;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MedicareID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMedicareID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FederalTaxID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit UPIN;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUPIN;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ProviderID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProviderID;
		protected System.Web.UI.WebControls.RadioButton rdBtnName;
		protected System.Web.UI.WebControls.RadioButton rdBtnID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected System.Web.UI.WebControls.RadioButtonList rdSearchBy;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected System.Web.UI.HtmlControls.HtmlTable tblIDs;
		protected System.Web.UI.HtmlControls.HtmlTable tblLanguage;
		protected System.Web.UI.HtmlControls.HtmlTable tblIDs2;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResults2;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBCheckBox Primary;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNetworksSpecialties;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
		protected NetsoftUSA.WebForms.OBLabel OBLabel11;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSpecialties;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridNetworks;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnSpecialtyID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnLocationID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnProviderID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnProviderName;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnLocationDescription;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnSpecialtyDescription;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkDescription;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnPhone;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatus;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatusDescriptionIn;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatusDescriptionOut;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnFlag;

		private PatientCoverage patCov;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchNameNext;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnPrevious;
		//private BaseForEventCMSReferral baseEventCmsReferral;
		private   int  selectWidth = 65;
		protected NetsoftUSA.WebForms.OBFieldLabel lblPhysicianReview;
		protected NetsoftUSA.WebForms.OBCheckBox PhysicianReview;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhysicianReview;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkInfo2;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkInfo1;
		protected NetsoftUSA.WebForms.OBComboBox NetwokSearchID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNetwokSearchID;
		protected System.Web.UI.WebControls.RadioButtonList lstNetworkSearch;
		protected NetsoftUSA.WebForms.OBLabel Oblabel12;

		// The page start stack is implemented diferently from patient/subsriber search pages.
		// We keep the pageSartStack in the session directly and set it to the grid each time
		// the page is created.
		private ArrayList pageStartStack;	// page start stack for this page

		public ArrayList PageStartStack
		{
			get
			{
				if (pageStartStack == null)
				{
					string key = "ProviderSearchPageStartStack";
					pageStartStack = (ArrayList)this.LoadObject(key);
					if (pageStartStack == null)
					{
						pageStartStack = new ArrayList();
						this.CacheObject(key, pageStartStack);
					}
				}
				return pageStartStack;
			}
		}

		public override void NavigateAway(string targetURL)
		{
			// Push the current start page before navigating away, so that we know where to start from when returned.
			gridProviders.PushValuesForPageStart();	// push the page start values for this page.
			
			// since there's no single search object, we save these into the session directly.
			this.CacheObject("rdSearchBy", rdSearchBy.SelectedValue);
			this.CacheObject("lstNetworkSearch", lstNetworkSearch.SelectedValue);
			base.NavigateAway ();
		}

		public void LoadSearcherFromCache()
		{
			searchProviderInfo = (Provider)this.LoadObject("BasicInfo");  // load object from cache
			searchProviderAddress = (Address)this.LoadObject("AddressInfo");  // load object from cache
			searchProviderFocus = (ProviderFocus)this.LoadObject("FocusInfo");  // load object from cache
			searchSpecialty = (ProviderSpecialty)this.LoadObject("SpecialtyInfo");  // load object from cache
			searchProviderService = (ProviderLocationService)this.LoadObject("ServiceInfo");  // load object from cache
			searchLanguage = (ProviderLanguage)this.LoadObject("LanguageInfo");  // load object from cache
				
			patCov = (PatientCoverage)this.LoadObject(typeof(PatientCoverage), false);  // load object from cache
			//baseEventCmsReferral = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache

			providerSearchResults = (ProviderCollection)this.LoadObject("ProviderSearchResults");  // load object from cache
			locationSearchResults = (ProviderLocationCollection)this.LoadObject("LocationSearchResults");  // load object from cache
			providerLocationSearch = (Location)this.LoadObject("objProviderLocationSearch");  // load object from cache
			searchProviderNetworkLink = (ProviderLocationNetworkLink)this.LoadObject(typeof(ProviderLocationNetworkLink));  // load object from cache
			searchNetworkPlanLink = (NetworkPlanLink)this.LoadObject(typeof(NetworkPlanLink));  // load object from cache
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			gridProviders.PageStartStack = this.PageStartStack;	// Let the new instance know about the common page start stack instance

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				// translate manually added text's
				TranslateNames();
				this.LoadData();
				
			}
			else
			{				
				LoadSearcherFromCache();				
			}			
			
			if (this.HasCallbackFunction)
			{
				if (Request.QueryString["Flag"] == "1")
					hdnFlag.Value = "1";
				else
					hdnFlag.Value = "0";
			}

			CheckNetworkStatus();
		}

	
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			if(!this.IsClientScriptBlockRegistered("formLoad"))
			{
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){}\n");
				s.Append("function getGridVals1(){}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
			}
		}

		private void BindForm()
		{
			//this.UpdateFromObject(this.pnlSearchName.Controls, this.searchProviderInfo);
			this.UpdateFromObject(this.tblBasicInfo.Controls , this.searchProviderInfo);			
			this.UpdateFromObject(this.tblAddress.Controls, this.searchProviderAddress);
		}

		private void LoadData()
		{
			bool excludeAddress = false;
			bool excludeNetwork = false;

			this.pnlResults.Visible = false;
			this.pnlResults2.Visible = false;
			this.pnlNetworksSpecialties.Visible = false;

			this.ClearProviderContext();

			if (this.HasCallbackFunction)
			{
				patCov = this.GetParamOrGetFromCache("PatCov", typeof(PatientCoverage)) as PatientCoverage ;
				
				// -- Get state information from Patient Address through PatientCoverage and initialize state on search form.
				if (patCov != null)
				{
					Address addr				= new Address();
					addr.State					= patCov.Patient.Address.State;
					this.SearchProviderAddress	= addr;
					excludeAddress				= true;
				}

				// Network Info				
				if (patCov != null && patCov.PlanID != 0)
				{
					NetworkPlanLink networkPlanLink = new  NetworkPlanLink();
					ProviderLocationNetworkLink provNetLink = new ProviderLocationNetworkLink();
					 
					
					networkPlanLink.PlanId = patCov.PlanID;
					provNetLink.FilterPlanID = patCov.PlanID;
					provNetLink.NetwokSearchID = patCov.GetPlanRelatedNetworkID();
					if (Request.QueryString["StartDate"] != null && Request.QueryString["StartDate"] != "")
					{
						networkPlanLink.StartDate = DateTime.Parse(Request.QueryString["StartDate"].ToString());
						provNetLink.EffectiveDate = networkPlanLink.StartDate; 
					}

					this.SearchProviderNetworkLink = provNetLink;
					this.SearchNetworkPlanLink = networkPlanLink;
					
					/*if (provNetLink.NetwokSearchID != 0) // if there's a network that's linked
						this.lstNetworkSearch.SelectedIndex = 1;
					else
						this.lstNetworkSearch.SelectedIndex = 0;*/
					// if there's a network that has this plan linked select network search otherwise select all networks.
					this.lstNetworkSearch.SelectedIndex = (provNetLink.NetwokSearchID == 0) ? 0 : 1;
					if (provNetLink.NetwokSearchID == 0)
					{
						networkPlanLink.PlanId = -1;
						excludeNetwork = true;
					}
					if (lstNetworkSearch.SelectedIndex == 1)
						excludeNetwork = true;
				}				
			}
			
			/*if (this.WasCancelled)		// If cancelled, re-use the existing context
			{
				// refresh
				this.SearchProviderInfo = this.SearchProviderInfo;
				this.SearchProviderAddress = this.SearchProviderAddress;
				this.SearchProviderFocus = this.SearchProviderFocus;
				this.SearchSpecialty = this.SearchSpecialty;
				this.SearchProviderService = this.SearchProviderService;
				this.SearchLanguage = this.SearchLanguage;
				this.ProviderLocationSearch = this.ProviderLocationSearch;
				this.SearchProviderNetworkLink = this.SearchProviderNetworkLink;
				this.SearchNetworkPlanLink = this.SearchNetworkPlanLink;

				rdSearchBy.SelectedValue = (string)this.LoadObject("rdSearchBy");
				lstNetworkSearch.SelectedValue = (string)this.LoadObject("lstNetworkSearch");
				this.SearchNext(false);		// go to previous page (the current page before navigation)
			}
			else
			{*/
				NewSearch(excludeNetwork, excludeAddress); // Initialize the search form
				this.SetSearchFormVisibility(0);	// Search By Name enabled by default
			//}

		}

		/// <summary>
		///  Call this method before updating to object for ID search.
		/// </summary>
		private void ClearCriteriaForIDSearch( )
		{
			this.searchLanguage = new ProviderLanguage();
			this.SearchProviderAddress = new Address();
			this.searchProviderInfo = new Provider();
			this.searchProviderService = new ProviderLocationService();
			this.searchSpecialty = new ProviderSpecialty();
			this.ProviderLocationSearch = new Location();
			this.searchProviderFocus = new ProviderFocus();
			this.searchProviderNetworkLink = new ProviderLocationNetworkLink();
			
		}

		private void NewSearch(bool excludeNetwork, bool excludeAddress)
		{
			this.NewSearchLanguage();
			if (!excludeAddress) // if address is already populated skip
				this.NewSearchProviderAddress();
			this.NewSearchProviderInfo();
			this.NewSearchProviderService();
			this.NewSearchSpecialty();
			this.NewSearchProviderFocus();
			this.NewProviderLocationSearch(); 
			if (!excludeNetwork) // if network info is already populated skip
			{
				// When we re-set the network set the RadioButton to AllNetworks
				this.lstNetworkSearch.SelectedIndex = 0;

				this.NewProviderNetworkSearch();
				this.SearchNetworkPlanLink = new NetworkPlanLink();
			}
		}

		private void TranslateNames()
		{
			this.rdSearchBy.Items[0].Text = this.Language.TranslateSingle("NAME");
			this.rdSearchBy.Items[1].Text = this.Language.TranslateSingle("ID");
			this.lstNetworkSearch.Items[0].Text = this.Language.TranslateSingle("ALLNETWORKS");
			this.lstNetworkSearch.Items[1].Text = this.Language.TranslateSingle("SPECIFIEDNETWORK");
			//this.hdnNetworkStatusDescriptionIn.Value = this.Language.TranslateSingle("IN");
			//this.hdnNetworkStatusDescriptionOut.Value = this.Language.TranslateSingle("OUT");
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			Redirect("ProviderSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			gridProviders.PagingColumns = new string[] { "PKInt", "FirstName", "LastName" };
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.rdSearchBy.SelectedIndexChanged += new System.EventHandler(this.rdSearchBy_SelectedIndexChanged);
			this.btnSearchName.Click += new System.EventHandler(this.btnSearchName_Click);
			this.gridProviders.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridProviders_ClickCellButton);
			this.gridProviders.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridProviders_ColumnsBoundToDataClass);
			this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
			this.butSearchNameNext.Click += new System.EventHandler(this.butSearchNameNext_Click);
			this.gridProviderLocations.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridProviderLocations_ClickCellButton);
			this.gridProviderLocations.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.gridProviderLocations_RowBoundToDataObject);
			this.gridProviderLocations.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridProviderLocations_ColumnsBoundToDataClass);
			this.gridNetworks.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.gridNetworks_RowBoundToDataObject);
			this.gridNetworks.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridNetworks_ColumnsBoundToDataClass);
			this.gridSpecialties.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.gridSpecialties_RowBoundToDataObject);
			this.gridSpecialties.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridSpecialties_ColumnsBoundToDataClass);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("@NEWSEARCH@", "NewSearch");
			toolbar.AddButton("@ADDNEWRECORD@", "AddNew");
		}

		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// Don't exlude anything start w/ a blank form.
			if (this.IsPopup) // if we are in Pop-up mode
			{
				if (this.patCov != null) // If current patient's coverage exists.
					NewSearch(true,false);
				else
					NewSearch(false,false); // There is no Patient Coverage so re-set everything including network.
			}
			else
				NewSearch(false,false);// Don't exclude anything re-set everything.
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{

			// add new 
			ProviderForm.Redirect(0);
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			//toolbar.AddPreset(ToolbarButtons.Cancel);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Provider SearchProviderInfo
		{
			get { return searchProviderInfo; }
			set
			{
				searchProviderInfo = value;
				try
				{
					this.UpdateFromObject(this.tblBasicInfo.Controls, searchProviderInfo);  // update controls for the given control collection
					this.UpdateFromObject(this.tblIDs.Controls, searchProviderInfo);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("BasicInfo", searchProviderInfo);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearchProviderInfo()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblBasicInfo.Controls, searchProviderInfo);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchProviderInfo()
		{
			bool result = true;
			Provider searchProviderInfo = new Provider(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchProviderInfo.New(/* parameters */);

				if (Request.QueryString["PR"] != null && Request.QueryString["PR"] != "")
					searchProviderInfo.PhysicianReview = true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchProviderInfo = searchProviderInfo;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Address SearchProviderAddress
		{
			get {return searchProviderAddress; }
			set
			{
				searchProviderAddress = value;
				try
				{
					this.UpdateFromObject(this.tblAddress.Controls, searchProviderAddress);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("AddressInfo", searchProviderAddress);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearchProviderAddress()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblAddress.Controls, searchProviderAddress);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchProviderAddress()
		{
			bool result = true;
			Address searchProviderAddress = new Address(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchProviderAddress.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchProviderAddress = searchProviderAddress;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ProviderFocus SearchProviderFocus
		{
			get { return searchProviderFocus; }
			set
			{
				searchProviderFocus = value;
				try
				{
					this.UpdateFromObject(this.tblFocus.Controls, searchProviderFocus);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("FocusInfo", searchProviderFocus);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearchProviderFocus()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblFocus.Controls, searchProviderFocus);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchProviderFocus()
		{
			bool result = true;
			ProviderFocus searchProviderFocus = new ProviderFocus(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchProviderFocus.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchProviderFocus = searchProviderFocus;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ProviderSpecialty SearchSpecialty
		{
			get { return searchSpecialty; }
			set
			{
				searchSpecialty = value;
				try
				{
					this.UpdateFromObject(this.tblSpecialties.Controls, searchSpecialty);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("SpecialtyInfo", searchSpecialty);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearchSpecialty()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblSpecialties.Controls, searchSpecialty);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchSpecialty()
		{
			bool result = true;
			ProviderSpecialty searchSpecialty = new ProviderSpecialty(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchSpecialty.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchSpecialty = searchSpecialty;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ProviderLocationService SearchProviderService
		{
			get { return searchProviderService; }
			set
			{
				searchProviderService = value;
				try
				{
					this.UpdateFromObject(this.tblServices.Controls, searchProviderService);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("ServiceInfo", searchProviderService);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearchProviderService()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblServices.Controls, searchProviderService);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchProviderService()
		{
			bool result = true;
			ProviderLocationService searchProviderService = new ProviderLocationService(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchProviderService.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchProviderService = searchProviderService;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ProviderLanguage SearchLanguage
		{
			get { return searchLanguage; }
			set
			{
				searchLanguage = value;
				try
				{
					this.UpdateFromObject(this.tblLanguage.Controls, searchLanguage);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}

				this.CacheObject("LanguageInfo", searchLanguage);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearchLanguage()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblLanguage.Controls, searchLanguage);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchLanguage()
		{
			bool result = true;
			ProviderLanguage searchLanguage = new ProviderLanguage(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchLanguage.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchLanguage = searchLanguage;
			return result;
		}


		private void btnSearchName_Click(object sender, System.EventArgs e)
		{
			// new search
			this.gridProviders.ClearValuesForPageStart();
			ReadForm(this.rdSearchBy.SelectedIndex);
		}


		private void rdSearchBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			// Added by V 2/2/6
			 
			SetSearchFormVisibility(rdSearchBy.SelectedIndex);
			if (rdSearchBy.SelectedIndex == 0)
				LoadData();
			CheckNetworkStatus();
		}


		private void ReadForm(int searchBy)
		{
			if (searchBy == 1) // Searching by ID, re-set all others to new.
			{	
				this.ClearCriteriaForIDSearch();
				this.UpdateToObject(this.tblIDs.Controls, this.searchProviderInfo, false);				
				this.lstNetworkSearch.SelectedIndex = 0;
			}
			else
			{
				// Read To Controls
				this.UpdateToObject(this.tblBasicInfo.Controls, this.searchProviderInfo, false); // basic info
				this.UpdateToObject(this.tblAddress.Controls, this.searchProviderAddress, false);  // address info
				this.UpdateToObject(this.tblLanguage.Controls, this.searchLanguage, false);		// language
				this.UpdateToObject(this.tblServices.Controls, this.searchProviderService, false);	// services
				this.UpdateToObject(this.tblSpecialties.Controls, this.searchSpecialty, false);	// specialties
				this.UpdateToObject(this.tblFocus.Controls, this.searchProviderFocus, false);		// focuses
				this.UpdateToObject(this.tblNetworkInfo1.Controls, this.SearchProviderNetworkLink, false); // network
				this.UpdateToObject(this.tblNetworkInfo2.Controls, this.SearchProviderNetworkLink, false); // network

			}
			this.searchProviderFocus.ProviderID = this.searchLanguage.ProviderID = searchSpecialty.ProviderID = searchProviderInfo.ProviderID;
			// if in pop-up mode send planID
			if (this.HasCallbackFunction)
			{
				if (lstNetworkSearch.SelectedValue == "0") // Search All Networks
				{
					searchProviderNetworkLink = new ProviderLocationNetworkLink();
					searchNetworkPlanLink	  = new NetworkPlanLink();
				}
				this.Search(this.searchProviderInfo, this.searchProviderAddress, this.SearchNetworkPlanLink,this.SearchProviderNetworkLink, this.SearchLanguage, this.searchProviderService, this.searchSpecialty, this.searchProviderFocus);
			}
			else
			{
				if (lstNetworkSearch.SelectedValue == "0") // search all networks
					searchProviderNetworkLink = new ProviderLocationNetworkLink();
				this.Search(this.searchProviderInfo, this.searchProviderAddress, this.SearchProviderNetworkLink, this.SearchLanguage, this.searchProviderService, this.searchSpecialty, this.searchProviderFocus);
			}
			
		}

		private void Search(Provider provider, Address address, NetworkPlanLink netPlan, ProviderLocationNetworkLink network, ProviderLanguage lang, ProviderLocationService service, ProviderSpecialty specialty, ProviderFocus focus)
		{
			ProviderCollection providerCol		= new ProviderCollection();

			providerCol.SearchProviders(startProviderId, startLastName, startFirstName, provider, network, netPlan, lang, focus, service, specialty, address);
			
			this.ProviderSearchResults = providerCol;
		}


		private void Search(Provider provider, Address address, NetworkPlanLink netPlan, ProviderLanguage lang, ProviderLocationService service, ProviderSpecialty specialty, ProviderFocus focus)
		{
			// reuse the method above.
			Search(provider, address, netPlan, new ProviderLocationNetworkLink(), lang, service, specialty, focus);
		}

		private void Search(Provider provider, Address address, ProviderLocationNetworkLink network, ProviderLanguage lang, ProviderLocationService service, ProviderSpecialty specialty, ProviderFocus focus)
		{
			// reuse the method above.
			Search(provider, address, new NetworkPlanLink(), network, lang, service, specialty, focus);
		}

		private void SetSearchFormVisibility(int selectedIndex)
		{
			switch (selectedIndex)
			{
				default:
				case 0:
					
					this.tblIDs.Visible				= this.tblIDs2.Visible			= false;
					this.tblAddress.Visible			= true;					
					this.tblBasicInfo.Visible		= true;
					this.tblFocus.Visible			= true;
					this.tblServices.Visible		= true;
					this.tblSpecialties.Visible		= true;
					this.tblLanguage.Visible		= true;
					this.tblNetworkInfo1.Visible	= true;
					this.tblNetworkInfo2.Visible	= true;
					//ClearSearchFields();
					
					break;
				case 1:
					
					// We are searching by ID, so reset the network selection to All networks.
					
					this.tblIDs.Visible 			= this.tblIDs2.Visible  = true;
					this.tblAddress.Visible 		= false;
					this.tblBasicInfo.Visible		= false;
					this.tblFocus.Visible			= false;
					this.tblServices.Visible		= false;
					this.tblSpecialties.Visible 	= false;
					this.tblLanguage.Visible		= false;
					this.tblNetworkInfo1.Visible     = false;
					this.tblNetworkInfo2.Visible     = false;
					break;
			}
		}


		private void ClearSearchFields()
		{
			NewSearch(true,true);
		}


		private void BindProviderLocations(int providerID)
		{
			#region Obsolete
			/*
			 * Replaced by LoadProviderLocationsWithFilter(bool loadWithFilter);
			 * 
			 * ProviderLocationCollection provLocCol = new ProviderLocationCollection();
			if (this.lstNetworkSearch.SelectedIndex == 1) // Network Info Sent
				provLocCol.LoadLocationsWithFilter(this.SearchNetworkPlanLink.NetworkID,providerID, this.SearchProviderAddress, this.SearchProviderNetworkLink.FilterPlanID, this.SearchProviderNetworkLink.EffectiveDate);
			else
				provLocCol.LoadLocationsWithFilter(providerID, this.searchProviderAddress);			
				
			
			*/
			#endregion			
			this.LocationSearchResults = this.LoadProviderLocationsWithFilter(this.lstNetworkSearch.SelectedIndex == 1,providerID);//provLocCol;
			this.pnlResults2.Visible   = true;
		}

		private ProviderLocationCollection LoadProviderLocationsWithFilter(bool loadWithFilter, int providerID)
		{
			ProviderLocationCollection provLocCol = new ProviderLocationCollection();
			if (loadWithFilter)
				provLocCol.LoadLocationsWithFilter(this.SearchNetworkPlanLink.NetworkID,providerID, this.SearchProviderAddress, this.SearchProviderNetworkLink.FilterPlanID, this.SearchProviderNetworkLink.EffectiveDate);
			else
				provLocCol.LoadLocationsWithFilter(providerID, this.searchProviderAddress);
			return provLocCol;
		}

		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ProviderCollection ProviderSearchResults
		{
			get { return providerSearchResults; }
			set
			{
				providerSearchResults = value;
				try
				{
					this.gridProviders.KeepCollectionIndices = false;
					this.gridProviders.UpdateFromCollection(providerSearchResults);
					this.pnlResults.Visible				= true;			

					// If there are results then show the first result's Locations
					if (this.providerSearchResults.Count > 0)
					{
						butSearchNameNext.Enabled = providerSearchResults.Count >= ProviderCollection.MAXRECORDS;
						btnPrevious.Enabled = gridProviders.HasAnyPreviousPages;

						this.gridProviders.SelectedRowIndex = 0;
						this.BindProviderLocations(gridProviders.SelectedRowPKInt);

					}
					else
					{
						pnlResults2.Visible = false;
					}

					butSearchNameNext.Enabled = providerSearchResults.Count >= ProviderCollection.MAXRECORDS;
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject("ProviderSearchResults", providerSearchResults);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ProviderLocationCollection LocationSearchResults
		{
			get { return locationSearchResults; }
			set
			{
				locationSearchResults = value;
				try
				{
					this.gridProviderLocations.KeepCollectionIndices = false;
					this.gridProviderLocations.UpdateFromCollection(locationSearchResults);
					if (this.gridProviderLocations.Rows.Count > 0)
						gridProviderLocations.SelectedRowIndex = 0;
					
					
					gridProviderLocations.Visible = true;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// Don't cache it. Search results should not be cached.
				//this.CacheObject("LocationSearchResults", locationSearchResults);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Location ProviderLocationSearch
		{
			get { return providerLocationSearch; }
			set
			{
				providerLocationSearch = value;
				try
				{
					this.UpdateFromObject(this.tblIDs2.Controls, providerLocationSearch);  // update controls for the given control collection
				
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject("objProviderLocationSearch", providerLocationSearch);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForProviderLocationSearch()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblIDs2.Controls, providerLocationSearch);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewProviderLocationSearch()
		{
			bool result = true;
			Location providerLocationSearch = new Location(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				providerLocationSearch.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.ProviderLocationSearch = providerLocationSearch;
			return result;
		}
		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewProviderNetworkSearch()
		{
			bool result = true;
			ProviderLocationNetworkLink providerNetworkLink = new  ProviderLocationNetworkLink(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				providerNetworkLink.New();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			this.SearchProviderNetworkLink = providerNetworkLink;
			return result;
		}
		

		private void gridProviders_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				// update selected index
				this.gridProviders.SelectedRowIndex = e.Cell.Row.Index;
				SelectProvider((int)gridProviders.SelectedRowPK[0]);
			}
			else if(e.Cell.Key == "Pick")
			{
				Provider provider = new Provider();
				ProviderLocation providerLoc = null;
				object[] pk = gridProviders.GetPKFromCellEvent(e);

				provider.Load((int)pk[0]);
				provider.LoadLocations(false);
				if((provider.Locations.Count != 0)&&(provider.Locations[0] !=null))
					provider.Locations[0].LoadNetworks(false);
					
				provider.LoadSpecialties(false);
				
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){\n");
				s.Append("window.opener.");
				s.Append(this.CallbackFunction);
				s.Append("(getGridVals1());\nwindow.close();\nreturn false;\n}\n");
				s.Append("\n function getGridVals1(){\n");
				s.Append("var o = new Object();\n");
				s.Append("o.ProviderID = \"");
				s.Append(provider.ProviderID.ToString());
				s.Append("\";\n o.ProviderName =\"");
				s.Append(provider.FullName);
				s.Append("\";\n o.FaxNo	= \"");
				s.Append(provider.FaxNumber);
                
				// -- Check if there is a selected ProviderLocation, and make sure that the 
				// -- the loaded provider locations belong to the currently selected provider
				// -- if not, use the first Location 
				// -- 01/27/06 that meets the specified criteria.
				
				if((provider.Locations.Count != 0)&&(provider.Locations[0] !=null)) // at least one Location exists
				{
					string startDate;

					if (Request.QueryString["StartDate"]=="")
					{
						startDate = Convert.ToString(DateTime.Now);
					}
					else
						startDate = Request.QueryString["StartDate"];
				
					
					int status = 0;
					

					if (this.gridProviderLocations.SelectedRowIndex > 0) // A different location then 1st is selected.
					{
						providerLoc = new ProviderLocation();
						providerLoc.Load(this.gridProviderLocations.SelectedRowPKInt);
						//providerLoc  = this.LocationSearchResults[this.gridProviderLocations.SelectedColectionIndex];
						if (providerLoc.ProviderID != provider.ProviderID) // if the location doesn't belong to currently selected provider
							providerLoc = provider.Locations[0]; // Set the location to first location.
					}
					else // -- No provider location selected, load locations with filter.
					{
						ProviderLocationCollection provLocCol = this.LoadProviderLocationsWithFilter(this.lstNetworkSearch.SelectedIndex == 1,provider.ProviderID);
						if (provLocCol != null && provLocCol.Count > 0)
							providerLoc = provLocCol[0];
							//providerLoc = provider.Locations[0];
					}

					if(patCov !=null)
					{
						//status  = (int)provider.Locations[0].GetStatusForProviderLocationNetworks(patCov.PlanID, Convert.ToDateTime(startDate),provider.Locations[0].LocationID);
						status = (int)providerLoc.GetStatusForProviderLocationNetworks(patCov.PlanID, Convert.ToDateTime(startDate),providerLoc.LocationID);
						if (patCov.GetPlanRelatedNetworkID() == 0) // Patient Coverage has no networks.
							s.Append("\";\n o.PatCov = \"0");
						else 
							s.Append("\";\n o.PatCov = \"1");
					}
					else
					{
						status = 0;
						s.Append("\";\n o.PatCov = \"0");
					}
					
					s.Append("\";\n o.LocationID = \"");
					s.Append(providerLoc.LocationID.ToString());
					s.Append("\";\n o.LocationDescription = \"");					
					s.Append(providerLoc.ServiceLocation);
					s.Append("\";\n o.PhoneNo	= \"");				
					s.Append(providerLoc.Phone);
					s.Append("\";\n o.NetworkStatus	= \"");
					s.Append(status.ToString());
					s.Append("\";\n o.NetworkStatusDesc=\"");
					if(status == 1)
						s.Append("In");
					else if(status == 0)
						s.Append("Out");
					s.Append("\";\n o.ResourceContactName	=  \"");					
					s.Append(Contact.GetLatestContactNameByProviderLocationId(providerLoc.ProviderLocationID));
				}
				else
				{
					
					s.Append("\";\n o.LocationDescription=\"");
				
					s.Append("\";\n o.PhoneNo	= \"");
					
					s.Append("\";\no.NetworkStatus=\"");
					s.Append("\";\no.NetworkStatusDesc= \"");
					s.Append("\";\no.ResourceContactName=  \"");
				
				}
				//				if (o.NetworkStatus == "1")
				//				{
				//					o.NetworkStatusDesc	= document.getElementById("hdnNetworkStatusDescriptionIn").value;
				//				}
				//				else if (o.NetworkStatus == "0")
				//				{
				//					o.NetworkStatusDesc	= document.getElementById("hdnNetworkStatusDescriptionOut").value;
				//				}
				if( (provider.Specialties.Count != 0) && (provider.Specialties[0] != null))
				{
					s.Append("\";\n o.SpecialtyID = \"");
					s.Append(provider.Specialties[0].SpecialtyID.ToString());
					s.Append("\";\n o.SpecialtyDescription = \"");
					s.Append(provider.Specialties[0].Description);
				}
				else
				{
					s.Append("\";\n o.SpecialtyID = \"");
					s.Append("\";\n o.SpecialtyDescription = \"");
				}	
				if((provider.Locations.Count !=0) &&(provider.Locations[0] != null) && (providerLoc != null))
				{
					//if((provider.Locations[0].Networks.Count !=0) && (provider.Locations[0].Networks[0] != null))
					if (providerLoc.Networks == null)
						providerLoc.LoadNetworks(false);
					if((providerLoc.Networks.Count !=0) && (providerLoc.Networks[0] != null))
					{
						s.Append("\";\n o.NetworkID = \"");
						//s.Append(provider.Locations[0].Networks[0].NetworkID.ToString());
						s.Append(providerLoc.Networks[0].NetworkID.ToString());
						s.Append("\";\n o.NetworkDescription = \"");
						//s.Append(provider.Locations[0].Networks[0].Description);
						s.Append(providerLoc.Networks[0].Description);
					
					}
					else
					{
						s.Append("\";\n o.NetworkID = \"");
						s.Append("\";\n o.NetworkDescription = \"");
					}
				}
				else
				{
					s.Append("\";\n o.NetworkID = \"");
					s.Append("\";\n o.NetworkDescription = \"");
				}
				s.Append("\";\n return o;}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
			}
		}

		private void SelectProvider(int providerID)
		{
			if (providerID != -1)
			{
				try
				{
					Provider prov = new Provider();
					prov.Load(providerID);

					ProviderSpecialty provSpecialty = prov.GetPrimarySpecialty();
					if (provSpecialty != null)
					{
						hdnSpecialtyID.Value  =  provSpecialty.ProviderSpecialtyID.ToString();
						hdnSpecialtyDescription.Value = (provSpecialty.Description == null) ? null : provSpecialty.Description.ToString();
					}
					hdnProviderID.Value = providerID.ToString();
					hdnProviderName.Value = prov.FullName;
					
					if (gridProviders.Rows.Count > 0)
					{
						BindProviderLocations(providerID);
					}
					else
					{
						pnlResults2.Visible = false;
					}
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void gridProviderLocations_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (this.HasCallbackFunction) // pop-up mode
			{
				ProviderLocation providerloc = new ProviderLocation();						
				providerloc.Load(gridProviderLocations.GetPKIntFromCellEvent(e));
				
				if (providerloc == null || providerloc.LocationID == 0)
					return;
				
				hdnLocationID.Value = providerloc.LocationID.ToString();
				hdnLocationDescription.Value = providerloc.ServiceLocation.ToString();
				
				Provider prov = null;
				
				if (providerloc.LocationID != 0 )
				{
					prov= new Provider();
					prov.Load(providerloc.ProviderID);
					hdnProviderID.Value = providerloc.ProviderID.ToString();
					hdnProviderName.Value = prov.FullName;
					hdnPhone.Value = providerloc.Phone;		
				}

				string startDate;

				if (Request.QueryString["StartDate"]=="")
				{
					startDate = Convert.ToString(DateTime.Now);
				}
				else
					startDate = Request.QueryString["StartDate"];
			
				int status = 0;

				int patCovStatus = 0;
				if(patCov !=null)
				{
					status  = (int)providerloc.GetStatusForProviderLocationNetworks(patCov.PlanID, Convert.ToDateTime(startDate),providerloc.LocationID);
					patCovStatus = patCov.GetPlanRelatedNetworkID(); //Does  Patient Coverage have networks?
				}
				else
				{
					status = 0;
				}
				hdnNetworkStatus.Value = status.ToString();

				if(e.Cell.Key == "SelectLocation")
				{
						BindNetworkSpecialties(gridProviderLocations.GetPKIntFromCellEvent(e));
				}
				else if(e.Cell.Key == "Pick")
				{
					providerloc.LoadNetworks(false);				
					prov.LoadSpecialties(false);				
					StringBuilder s = new StringBuilder();
					s.Append("<SCRIPT>\n");
					s.Append("function formLoad(){\n");
					s.Append("window.opener.");
					s.Append(this.CallbackFunction);
					s.Append("(getGridVals1());\nwindow.close();\nreturn false;\n}\n");
					s.Append("\n function getGridVals1(){\n");
					s.Append("var o = new Object();\n");
					s.Append("o.ProviderID = \"");
					s.Append(prov.ProviderID.ToString());
					s.Append("\";\n o.ProviderName =\"");
					s.Append(prov.FullName);
					s.Append("\";\n o.PatCov = \"");
					s.Append(patCovStatus.ToString());
					s.Append("\";\n o.LocationID = \"");
					
					s.Append(providerloc.LocationID.ToString());
					s.Append("\";\n o.LocationDescription = \"");
					s.Append(providerloc.ServiceLocation);
					s.Append("\";\n o.PhoneNo	= \"");
					s.Append(providerloc.Phone);
					s.Append("\";\no.NetworkStatus	=  \"");
					s.Append(status.ToString());
					s.Append("\";\no.NetworkStatusDesc	=  \"");
					if(status == 1)
						s.Append("In");
					else if(status == 0)
						s.Append("Out");
					
					if( (prov.Specialties.Count != 0) && (prov.Specialties[0] != null))
					{
						s.Append("\";\n o.SpecialtyID = \"");
						s.Append(prov.Specialties[0].SpecialtyID.ToString());
						s.Append("\";\n o.SpecialtyDescription = \"");
						s.Append(prov.Specialties[0].Description);
					}
					else
					{
						s.Append("\";\n o.SpecialtyID = \"");
						s.Append("\";\n o.SpecialtyDescription = \"");
					}	
					if((providerloc.Networks.Count !=0) && (providerloc.Networks[0] != null))
						{
							s.Append("\";\n o.NetworkID = \"");
							s.Append(providerloc.Networks[0].NetworkID.ToString());
							s.Append("\";\n o.NetworkDescription = \"");
							s.Append(providerloc.Networks[0].Description);
					
						}
						else
						{
							s.Append("\";\n o.NetworkID = \"");
							s.Append("\";\n o.NetworkDescription = \"");
						}
					
					s.Append("\";\n return o;}\n");
					s.Append("</SCRIPT>\n");
					this.RegisterClientScriptBlock("formLoad",  s.ToString());
		
				}
				
			}
			else
			{
				if (e.Cell.Key == "Edit")
					SelectProviderLocation((int)gridProviderLocations.SelectedRowPK[0]);
			}
		}

		private void BindNetworkSpecialties(int providerLocationID)
		{
			if (providerLocationID != -1)
				this.pnlNetworksSpecialties.Visible = true;

			// Load ProviderLocation / Provider
			ProviderLocation pl = new ProviderLocation();
			Provider p = new Provider();
			pl.Load(providerLocationID);
			p.Load(pl.ProviderID);
						
			// Load Networks/Specialties
			pl.LoadNetworks(false);
			//pl.LoadNetworkStatus(false,patCov.PlanId,patCov.Plan.EffectiveDate);
			p.LoadSpecialties(false);

			this.gridNetworks.UpdateFromCollection(pl.Networks);
			if (gridNetworks.Rows.Count > 0)
				gridNetworks.SelectedRowIndex = 0;
			this.gridSpecialties.UpdateFromCollection(p.Specialties);			
			if (gridSpecialties.Rows.Count > 0)
				gridSpecialties.SelectedRowIndex = 0;
		}

		private void SelectProviderLocation(int providerLocationID)
		{
			if (providerLocationID != -1)
			{
				ProviderLocation provLoc = new  ProviderLocation();
				provLoc.Load(providerLocationID);
				ProviderForm.Redirect(provLoc.ProviderID);
			}
		}


		private void gridProviders_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			this.gridProviders.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;
			//if popup mode add pick button
			if(this.HasCallbackFunction) 
			{
				if(Request.QueryString["Flag"] != "1")
				this.gridProviders.AddButtonColumn("Pick","@PICK@",1).Width = 45;
			}
		}



		private void gridProviderLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction)
			{
				if (Request.QueryString["Flag"] == "1")
				{
					this.gridProviderLocations.AddColumnWithButtonLook("Pick", "@PICK@", 0).Width = 45;
						this.gridNetworks.ClickEventCommand = null;
				}
				else
				{
					this.gridProviderLocations.AddButtonColumn("SelectLocation", "@SELECT@", 0).Width = selectWidth;
					this.gridProviderLocations.ClickEventCommand = "SelectLocation";
					this.gridProviderLocations.AddButtonColumn("Pick", "@PICK@", 1).Width = 45;
				}
			}
			else
			{
				//this.gridProviderLocations.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;
			}
		}

		private void BindNetworkDropDown()
		{
			
			if (lstNetworkSearch.SelectedValue == "0")
			{
				this.searchProviderNetworkLink.FilterPlanID = 0;
			}
			else if (lstNetworkSearch.SelectedValue != "0" && this.patCov != null)
			{
				this.searchProviderNetworkLink.FilterPlanID = this.patCov.PlanID;
				this.searchProviderNetworkLink.NetwokSearchID = 0;
				this.SearchProviderNetworkLink = this.searchProviderNetworkLink;
			}

			this.UpdateFromObject(this.tblNetworkInfo1.Controls, searchProviderNetworkLink);
			this.UpdateFromObject(this.tblNetworkInfo2.Controls, searchProviderNetworkLink);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ProviderLocationNetworkLink SearchProviderNetworkLink
		{
			get { return searchProviderNetworkLink; }
			set
			{
				searchProviderNetworkLink = value;
				try
				{
					// Changed By V 2/2/6
					this.UpdateFromObject(this.tblNetworkInfo1.Controls, searchProviderNetworkLink);
					this.UpdateFromObject(this.tblNetworkInfo2.Controls, searchProviderNetworkLink);
					//BindNetworkDropDown(); // Bind Network Information.
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(ProviderLocationNetworkLink), searchProviderNetworkLink);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearchProviderNetworkLink()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblNetworkInfo1.Controls, searchProviderNetworkLink);	// controls-to-object
				this.UpdateToObject(this.tblNetworkInfo2.Controls, searchProviderNetworkLink);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private void gridNetworks_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction) // if in pop-up mode
			{
				this.gridNetworks.AddColumnWithButtonLook("Pick","@PICK@",0);
			
			}

		}

		private void gridSpecialties_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction) // if in pop-up mode
			{
				this.gridSpecialties.AddColumnWithButtonLook("Pick","@PICK@",0);
			}
		}

		private void gridSpecialties_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{

			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			
			if (cell != null)
			{
				if (this.SearchNetworkPlanLink.PlanId == 0)
				{
					ProviderSpecialty ps = e.data as ProviderSpecialty;
					Infragistics.WebUI.UltraWebGrid.CellsCollection cells = this.gridProviderLocations.DisplayLayout.ActiveRow.Cells;
					Infragistics.WebUI.UltraWebGrid.UltraGridCell activepCell = null;
					Infragistics.WebUI.UltraWebGrid.UltraGridCell activeplCell = null;
					for (int i = 0; i < cells.Count; i++)
					{
						if (cells[i].Key == "ProviderID")
							activepCell = cells[i];
						else if (cells[i].Key == "Edit")
							activeplCell = cells[i];					
					}
					int providerID = int.Parse(activepCell.Value.ToString());
					int providerLocID = int.Parse(activeplCell.Value.ToString());
					Provider prov = new Provider();
					prov.Load(providerID);
					
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
					//e.row.Cells.FromKey("Pick").Text = GetCallbackFunctionHyperLink("Pick", providerID, prov.FullName, providerLocID, ps.ProviderSpecialtyID, ps.SpecialtyID);
				}
				else
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
			}		
		}

		private string GetPickAllScript(string linkCaption)
		{
			return "<a href='#' onclick=\"window.opener." + this.CallbackFunction + "(getGridVals());window.close();return false;\">" + Language.Translate(linkCaption) + "</a>";
		}

		private void gridNetworks_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			if (cell != null)
			{
				ProviderLocationNetworkLink link = e.data as  ProviderLocationNetworkLink;
				if (this.SearchNetworkPlanLink.PlanId == 0)
				{
					Infragistics.WebUI.UltraWebGrid.CellsCollection cells = this.gridProviderLocations.DisplayLayout.ActiveRow.Cells;
					Infragistics.WebUI.UltraWebGrid.UltraGridCell activepCell = null;
					Infragistics.WebUI.UltraWebGrid.UltraGridCell activeplCell = null;
					for (int i = 0; i < cells.Count; i++)
					{
						if (cells[i].Key == "ProviderID")
							activepCell = cells[i];
						else if (cells[i].Key == "Edit")
							activeplCell = cells[i];					
					}
					int providerID = int.Parse(activepCell.Value.ToString());
					int providerLocID = int.Parse(activeplCell.Value.ToString());
					Provider prov = new Provider();
					prov.Load(providerID);

					hdnNetworkID.Value = link.ProviderLocationNetworkID.ToString();
					hdnNetworkDescription.Value = link.NetworkName.ToString(); 

					//e.row.Cells.FromKey("Pick").Text = GetCallbackFunctionHyperLink("Pick", providerID, providerLocID, prov.FullName, link.ProviderLocationNetworkID, link.NetworkID, link.NetworkName);
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
				}
				else
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
			}			
		}

		private void gridProviderLocations_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			if (Request.QueryString["Flag"] =="1")
			{
				try
				{
					UltraGridCell cell = e.row.Cells.FromKey("Pick");
					
							Provider prov = new Provider();
							prov.Load((int)gridProviders.SelectedRowPK[0]);
							
							hdnProviderID.Value = prov.ProviderID.ToString();
							hdnProviderName.Value = prov.FullName ;

							e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			else
			{
//				UltraGridCell cell = e.row.Cells.FromKey("Pick");
//				if ( cell != null)
//				{
//					if (this.SearchNetworkPlanLink.PlanId == 0)
//					{
//						ProviderLocation providerloc = e.data as ProviderLocation;
//						Provider prov = new Provider();
//						prov.Load(providerloc.ProviderID);
//					
//						hdnLocationID.Value = providerloc.ProviderLocationID.ToString();
//						hdnLocationDescription.Value = providerloc.ServiceLocation.ToString();
//					
//						e.row.Cells.FromKey("Pick").Text = GetCallbackFunctionHyperLink("Pick", providerloc.ProviderID,prov.FullName,providerloc.ProviderLocationID,providerloc.ServiceAddress,searchSpecialty.SpecialtyID,SearchSpecialty.Description);
//					}
//					else
//						e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
//				}
			}

			
		}

		private void lstNetworkSearch_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			CheckNetworkStatus();			
			BindNetworkDropDown();
		}
		
		private void CheckNetworkStatus()
		{
			if (lstNetworkSearch.SelectedValue == "0") // search all networks
			{
				lbNetwokSearchID.Enabled = false;
				NetwokSearchID.Enabled = false;
				NetwokSearchID.DisableBinding = true;
			}
			else
			{
				lbNetwokSearchID.Enabled = true;
				NetwokSearchID.Enabled = true;
				NetwokSearchID.DisableBinding = false;
			}
			// Modified By V 2/2/6
			//BindNetworkDropDown();

		}

		private void butSearchNameNext_Click(object sender, System.EventArgs e)
		{
			SearchNext(true);/*
			if (gridProviders.Rows.Count > 0)
			{
				startProviderId = gridProviders.GetPKIntFromRowIndex(gridProviders.Rows.Count - 1); 
				startLastName = gridProviders.Rows[gridProviders.Rows.Count - 1].Cells.FromKey("LastName").Text;
				startFirstName = gridProviders.Rows[gridProviders.Rows.Count - 1].Cells.FromKey("FirstName").Text;
			}
			ReadForm(this.rdSearchBy.SelectedIndex);*/
		}

		private void btnPrevious_Click(object sender, System.EventArgs e)
		{
			SearchNext(false);
		}

		private bool SearchNext(bool nextPage)
		{
			bool result = true;
			try
			{
				//gridProviders.PageStartStack = 
				object [] valuesForNextPageStart = gridProviders.GetStartValuesForPrevOrNextPage(nextPage);
				if (valuesForNextPageStart == null)	// no more pages.
					return false;
				// use page start to load this set of records.
				startProviderId = (int)valuesForNextPageStart[0];
				startLastName   = (string)valuesForNextPageStart[2];
				startFirstName  = (string)valuesForNextPageStart[1];
				ReadForm(this.rdSearchBy.SelectedIndex);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patients.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
				
			}
			return result;

		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public NetworkPlanLink SearchNetworkPlanLink
		{
			get { return searchNetworkPlanLink; }
			set
			{
				searchNetworkPlanLink = value;
				try
				{
					//this.UpdateFromObject(this.Controls, searchNetworkPlanLink);  // update controls for the given control collection
					// other object-to-control methods if any
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(NetworkPlanLink), searchNetworkPlanLink);  // cache object using the caching method declared on the page
			}
		}
	}
}
