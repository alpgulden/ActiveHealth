using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// The data entry page for a new or an existing Event of a patient's problem.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.EVENTS)]

	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Event,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(PatientSummaryForm))]
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[PageTitle("@EVENTPAGETITLE@")]
	public class EventForm : PatientBasePage
	{
		private Patient babyPatient;						// used only when a baby patient is to be created for a new born from the Mother tab
		private Event babyEvent;							// used only when a baby patient is to be created for a new born from the Mother tab
		private EventCollection possibleDuplicateEvents;
		//private ClinicalReviewDecision clinicalReviewDecision;
		//private ClinicalReviewRequest clinicalReviewRequest;
		//private ClinicalReviewDecisionCollection clinicalReviewDecisions;
		//private ClinicalReviewRequestCollection clinicalReviewRequests;
		private Patient patient;
		private Problem problem;
		private PatientCoverage patientCoverage;
		private Event eventObj;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit EventID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AltEventID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAltEventID;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusChangedDisplay;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit StatusChangedDisplay;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLateCallIn;
		protected NetsoftUSA.WebForms.OBCheckBox LateCallIn;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNotifyDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit NotifyDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusID;
		protected NetsoftUSA.WebForms.OBComboBox StatusID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimaryProblemID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventSourceID;
		protected NetsoftUSA.WebForms.OBComboBox EventSourceID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbResolution;
		protected NetsoftUSA.WebForms.OBComboBox Resolution;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacility;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProvider;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderGroupPractice;
		protected NetsoftUSA.WebForms.OBComboBox StartDateAP;
		protected NetsoftUSA.WebForms.OBComboBox EndDateAP;
		protected NetsoftUSA.WebForms.OBComboBox PrimaryProblemID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBButton butAddClinicalRequest;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlClinicalReview;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlConsultingPr;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel CONTENTPANEL1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPCPDetail;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPCPSelect;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPCPGroupSelect;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlRefProviderSelect;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlRefProviderGroupSelect;

		protected ProviderSelect PCPSelect;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDuplicates;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAdministration;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MaternityEDCDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternityEDCDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MaternityLMPDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternityLMPDate;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MaternityCalcGestation;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternityCalcGestation;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MaternityNumBabiesExp;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternityNumBabiesExp;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MaternityPara;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternityPara;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MaternityGravida;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternityGravida;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MaternityAB;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternityAB;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MaternityEctopic;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternityEctopic;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Maternity1stPreVisit;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternity1stPreVisit;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MaternityPostpartumVisit;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternityPostpartumVisit;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMomMaternity;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMomOBHistory;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMomProviderVisits;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NewbornGestate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNewbornGestate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NewbornOz;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNewbornOz;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NewbornLBS;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNewbornLBS;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NewbornLength;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNewbornLength;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NewbornGrams;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNewbornGrams;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NewbornAPGAR5Mins;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNewbornAPGAR5Mins;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NewbornAPGAR1Min;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNewbornAPGAR1Min;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlBabyDetails;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlBabyBirthSize;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDischargeStatus;
		protected NetsoftUSA.WebForms.OBLabel OBLabel11;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMiddleInitial;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.WebForms.OBComboBox Gender;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGender;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DateOfBirth;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateOfBirth;
		protected NetsoftUSA.WebForms.OBLabel OBLabel12;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlBabyPatient;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlBabyEvent;
		protected NetsoftUSA.WebForms.OBButton butCreateBaby;
		protected NetsoftUSA.WebForms.OBButton butCancelCreateBaby;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBComboBox CrEventTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CrEventStartDate;
		protected NetsoftUSA.WebForms.OBComboBox EventTypeID;
		protected TeamUserSelect Usel;
		protected ProviderSelect FSel;
		protected ProviderSelect PSel;
		protected ProviderSelect GPSel;
		protected ClinicalReviewControl CRev;
		protected ProviderSelect RGPSel;
		protected ProviderSelect RPSel;
		protected AdministrationControl Admn;
		protected UserDefined Ud1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LengthOfStayDisplay;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLengthOfStayDisplay;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gDup;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vAID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vDes;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vStD;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vStDAP;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vEnD;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vEnDAP;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vETI;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vStI;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vPPI;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vESI;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vRs;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vNtD;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vLMPD;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vEDCD;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vNBE;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vMCG;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vMGr;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vMPa;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vMEc;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vMAB;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vM1PV;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vPoV;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vNBG;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vNBLB;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vNBOz;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vNBGr;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vNBL;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vNBAPG;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vNBA5;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vFN;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vLN;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vMI;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vDOB;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vG;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vCrET;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vCrStD;
		protected ProviderSelect PGSel;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDummySaveAndPrintLetters;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDummySave;

		private void Page_Load(object sender, System.EventArgs e)
		{
			this.Usel.RebindControls(typeof(Event), "AssignedTeamID", "AssignedUserID");
			Ud1.ReloadContext("Event",eventObj,true);
			if(!Ud1.HasFields())
				this.PageTab.GetTab("EVE_UserDefined").Visible= false;

			//clinicalReviewDecision.Ud1.ReloadContext("ClinicalReview",eventObj,true);
			// Facility select
			this.FSel.RebindControls(typeof(Event), "@FACILITY@", 
				ProviderSearcherType.Facility, null,
				"FacilityID", "FacilityLocationID", "FacilityTypeID", "FacilityNetworkID", "FacilityNetworkStatus", "StartDate", true);

			// Provider select
			this.PSel.RebindControls(typeof(Event), "@PROVIDER@", 
				ProviderSearcherType.Provider, null,
				"ProviderID", "ProviderLocationID", "ProviderSpecialtyID", "ProviderNetworkID", "ProviderNetworkStatus", "StartDate", true);

			// ProviderGroupPractice select
			this.GPSel.RebindControls(typeof(Event), "@PROVIDERGROUPPRACTICE@", 
				ProviderSearcherType.GroupPractice, null,
				"ProviderGroupID", "ProviderGroupLocationID", "ProviderGroupTypeID", "ProviderGroupNetworkID", "ProviderGroupNetworkStatus");
			
			// PCP/Ref Pr------

			// PCP select
			this.PCPSelect.RebindControls(typeof(Event), "@PCP@", 
				ProviderSearcherType.Provider, null,
				"PCPID", "PCPLocationID", "PCPSpecialtyID", "PCPNetworkID", "PCPNetworkStatus");

			// PCP Group select
			this.PGSel.RebindControls(typeof(Event), "@PCPGROUP@", 
				ProviderSearcherType.GroupPractice, null,
				"PCPGroupID", "PCPGroupLocationID", "PCPGroupTypeID", "PCPGroupNetworkID", "PCPGroupNetworkStatus");

			// Ref Provider select
			this.RPSel.RebindControls(typeof(Event), "@REFPROVIDER@", 
				ProviderSearcherType.Provider, null,
				"RefProviderID", "RefProviderLocationID", "RefProviderSpecialtyID", "RefProviderNetworkID", "RefProviderNetworkStatus");

			// Ref Provider Group select
			this.RGPSel.RebindControls(typeof(Event), "@REFPROVIDERGROUP@", 
				ProviderSearcherType.GroupPractice, null,
				"RefProviderGroupID", "RefProviderGroupLocationID", "RefProviderGroupTypeID", "RefProviderGroupNetworkID", "RefProviderGroupNetworkStatus");

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				eventObj = (Event)this.LoadObject(typeof(Event));  // load object from cache
				
				babyPatient = (Patient)this.LoadObject("BabyPatient");  // load object from cache
				babyEvent = (Event)this.LoadObject("BabyEvent");  // load object from cache

				//clinicalReviewRequests = eventObj.ClinicalReviewRequests;
				//clinicalReviewDecisions = (ClinicalReviewDecisionCollection)this.LoadObject(typeof(ClinicalReviewDecisionCollection));  // load object from cache
				//clinicalReviewRequest = (ClinicalReviewRequest)this.LoadObject(typeof(ClinicalReviewRequest));  // load object from cache
				//clinicalReviewDecision = (ClinicalReviewDecision)this.LoadObject(typeof(ClinicalReviewDecision));  // load object from cache
				possibleDuplicateEvents = (EventCollection)this.LoadObject("possibleDuplicateEvents");  // load object from cache
				CRev.ReloadContext();

			}

		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject("BabyPatient", null);
			this.CacheObject("BabyEvent", null);
			this.CacheObject("possibleDuplicateEvents", null);
			base.NavigateAway ();
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			//fork 1.1
			this.wbtnDummySave.Click += new System.EventHandler(this.wbtnDummySave_Click);
			this.wbtnDummySaveAndPrintLetters.Click += new System.EventHandler(this.wbtnDummySaveAndPrintLetters_Click);
			base.OnInit(e);

			//gridClinicalRequests.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridClinicalRequests_ColumnsBoundToDataClass);
			//gridClinicalRequests.ClickCellButton +=new ClickCellButtonEventHandler(gridClinicalRequests_ClickCellButton);

			//gridClinicalDecisions.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridClinicalDecisions_ColumnsBoundToDataClass);
			//gridClinicalDecisions.ClickCellButton += new ClickCellButtonEventHandler(gridClinicalDecisions_ClickCellButton);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.ViewStateOnServer = true;
			this.Load += new System.EventHandler(this.Page_Load);			
		}
		#endregion

		//FORK 1.1
		// added by Alp Gulden 1/20/06
		// To generate leter we are using dummysave button
		private void wbtnDummySaveAndPrintLetters_Click(object sender, System.EventArgs e)
		{	
			ClinicalReviewDecision selecteDCRev = new ClinicalReviewDecision();
			CRev.ClinicalReviewDecision.GenerateLetter = true;
			selecteDCRev = CRev.ClinicalReviewDecision;
			if (SaveData())
			{
				if (!this.PageError)
				{
					//this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@EVENT@");
					//this.Event = this.Event;		// just refresh
				}
				CRev.GenerateLetterClinicalReview(selecteDCRev);
			}
			selecteDCRev= null;
		}

		private void wbtnDummySave_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				if (!this.PageError)
				{
					//this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@EVENT@");
					//this.Event = this.Event;		// just refresh
				}
			}
		}

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "EVE_Details")
			{
				WindowOpener woProblemLink = new WindowOpener();
				woProblemLink.ID = "ProblemLinkForm";
				woProblemLink.NavigateURL = "ProblemLinkForm.aspx";
				woProblemLink.registerClientScripts(this);

				toolbar.AddButton("@LINKPROBLEM@", "LinkProblem").Item.TargetURL = "javascript:" + woProblemLink.getWindowOpenScript(); 
				
				toolbar.AddButton("@CLONE@", "Clone");

				toolbar.AddButton(PatientMessages.MessageIDs.ADDNEWRECORD, "AddNew");
				//toolbar.AddButton(PatientMessages.MessageIDs.PHYSICIANREVIEW, "PhysicianReview");
				//toolbar.AddButton(PatientMessages.MessageIDs.CONSULTINGPR, "ConsultingPr");
				//toolbar.AddButton(PatientMessages.MessageIDs.OUTCOMES, "Outcomes");
				//toolbar.AddButton(PatientMessages.MessageIDs.DIAGNOSES, "Diagnoses");
				//toolbar.AddButton(PatientMessages.MessageIDs.PROCEDURES, "Procedures");

				this.AddClinicalSummaryButton(toolbar);
			}
			else if (tab.Key == "EVE_Administration")
			{
				toolbar.AddButton(PatientMessages.MessageIDs.CHANGECOVERAGE, "EVE_ChangeCoverage", true, true);
			}
			else if (tab.Key == "EVE_Mother")
			{
				toolbar.AddButton(PatientMessages.MessageIDs.CREATEBABY, "CreateBaby", false, false);
			}

			// Menu items to be displayed on all tabs
			toolbar.AddButton("@EVENTRPT@","EventRpt");
			toolbar.AddButton("@COSTRPT@","CostRpt");
		}

		public void OnToolbarButtonClick_Clone(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.ReadControls())
			{
				try
				{
					this.Event = eventObj.CreateCopyOfEvent();
					this.SetPageMessage("Event has been cloned.", EnumPageMessageType.Info);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public void OnToolbarButtonClick_EVE_ChangeCoverage(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// data from controls to object
			if (!this.ReadControls())
				return;
			RedirectToSelectCoverage(this.patient, this.patientCoverage, this.problem, this.eventObj);			
		}

		public void OnToolbarButtonClick_CreateBaby(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewBabyPatient();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewEvent();
		}

		/*public void OnToolbarButtonClick_PhysicianReview(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PhysicianReviewForm.Redirect(this.patient, this.patientCoverage, this.problem, this.eventObj);
		}*/

		/*
		public void OnToolbarButtonClick_ConsultingPr(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			EventConsultingProviderForm.Redirect(this.patient, this.patientCoverage, this.problem, this.eventObj);
		}*/

		/*public void OnToolbarButtonClick_Outcomes(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			OutcomesForm.Redirect(this.patient, this.patientCoverage, this.problem, this.eventObj);
		}*/

		/*public void OnToolbarButtonClick_Diagnoses(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			try
			{
				ZippyCoderForm.Redirect(this.eventObj, eventObj.CreateDiagnosticSelectionCollection());
							}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}*/

		/*public void OnToolbarButtonClick_Procedures(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			try
			{
				ZippyCoderForm.Redirect(this.eventObj, eventObj.CreateProcedureSelectionCollection());
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}*/

		public void OnToolbarButtonClick_EventRpt(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BasePage.PushCallingPage(this);
			object[] val = new object[] {this.patient.PatientId,this.eventObj.EventID};
			FormSpecificReport.Redirect(val,"SINGLEEVENT");
		}
		public void OnToolbarButtonClick_CostRpt(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BasePage.PushCallingPage(this);
			object[] val = new object[]{this.patient.PatientId,this.eventObj.PrimaryProblemID};
			FormSpecificReport.Redirect(val,"COSTCOMPSINGLEPATIENTPROB");
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				if (!this.PageError)
				{
					//this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@EVENT@");
					//this.Event = this.Event;		// just refresh
				}
			}
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			bool exitWithOutCancel=false;
			if (this.PageTab.SelectedTabKey == "EVE_Reviews")
			{
				if(CRev.ReadControlsForClinicalReviewRequestNoValidation())
					if(CRev.ClinicalReviewRequest!=null && CRev.ClinicalReviewRequest.IsNewOrDirty)
					{
						CRev.ClinicalReviewRequest = null;					
						CRev.ReloadContext();
							//LoadDataForClinicalReviewRequests();
						exitWithOutCancel = true;
					}
				if(CRev.ReadControlsForClinicalReviewDecisionNoValidation())
					if(CRev.ClinicalReviewDecision!=null && CRev.ClinicalReviewDecision.IsNewOrDirty)
					{
						CRev.ClinicalReviewDecision = null;		
						CRev.ReloadContext();
						//CRev.LoadDataForClinicalReviewRequests();
						exitWithOutCancel = true;
					}
			}

			if (this.possibleDuplicateEvents == null)
			{
				if(!exitWithOutCancel)
					base.OnToolbarButtonClick_Cancel(toolbar, button);
			}
			else
				// duplicates display mode.  just go out of this mode.
				this.PossibleDuplicateEvents = null;
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public bool IsMom
		{
			get
			{
				return eventObj != null && eventObj.IsMom;
			}
		}

		public bool IsBaby
		{
			get
			{
				return eventObj != null && eventObj.IsBaby;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Event Event
		{
			get { return eventObj; }
			set
			{
				eventObj = value;
				try
				{
					this.UpdateFromObject(pnlDetails.Controls, eventObj);  // update controls for the given control collection
					this.UpdateFromObject(pnlFacility.Controls, eventObj);
					this.UpdateFromObject(pnlProvider.Controls, eventObj);
					this.UpdateFromObject(pnlProviderGroupPractice.Controls, eventObj);

					this.UpdateFromObject(pnlPCPSelect.Controls, eventObj);
					this.UpdateFromObject(pnlPCPGroupSelect.Controls, eventObj);
					this.UpdateFromObject(pnlRefProviderSelect.Controls, eventObj);
					this.UpdateFromObject(pnlRefProviderGroupSelect.Controls, eventObj);

					// first cache then reload context
					this.CacheObject(typeof(Event), eventObj);  // cache object using the caching method declared on the page
					this.CacheObject(typeof(BaseForEventCMSReferral), eventObj);  // cache object using the caching method declared on the page

					Admn.ReloadContext();
					Admn.UpdateData(false);

					// other object-to-control methods if any
					this.Ud1.ReloadContext("Event",this.eventObj,false);

					this.BabyPatient = null;		// automatically go out of baby patient create mode
					this.BabyEvent = null;

					// Mom tab
					if (this.IsMom)
					{
						this.UpdateFromObject(pnlMomMaternity.Controls, eventObj);
						this.UpdateFromObject(pnlMomOBHistory.Controls, eventObj);
						this.UpdateFromObject(pnlMomProviderVisits.Controls, eventObj);
					}

					// Baby tab
					if (this.IsBaby)
					{
						this.UpdateFromObject(pnlBabyDetails.Controls, eventObj);
						this.UpdateFromObject(pnlBabyBirthSize.Controls, eventObj);
						this.UpdateFromObject(pnlDischargeStatus.Controls, eventObj);
					}

					// go out of duplicates mode.
					this.PossibleDuplicateEvents = null;

					CRev.ReloadContext();		// must be called after caching the context
					CRev.LoadDataForClinicalReviewRequests();

					//AdministrationControl.ReloadContext();
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlDetails.Controls, eventObj);	// controls-to-object
				this.UpdateToObject(pnlFacility.Controls, eventObj);
				this.UpdateToObject(pnlProvider.Controls, eventObj);
				this.UpdateToObject(pnlProviderGroupPractice.Controls, eventObj);

				this.UpdateToObject(pnlPCPSelect.Controls, eventObj);
				this.UpdateToObject(pnlPCPGroupSelect.Controls, eventObj);
				this.UpdateToObject(pnlRefProviderSelect.Controls, eventObj);
				this.UpdateToObject(pnlRefProviderGroupSelect.Controls, eventObj);

				Admn.ReloadContext();
				Admn.UpdateData(true);

				// Mom tab
				if (this.IsMom)
				{
					this.UpdateToObject(pnlMomMaternity.Controls, eventObj);
					this.UpdateToObject(pnlMomOBHistory.Controls, eventObj);
					this.UpdateToObject(pnlMomProviderVisits.Controls, eventObj);
				}

				// Baby tab
				if (this.IsBaby)
				{
					this.UpdateToObject(pnlBabyDetails.Controls, eventObj);
					this.UpdateToObject(pnlBabyBirthSize.Controls, eventObj);
					this.UpdateToObject(pnlDischargeStatus.Controls, eventObj);
				}

				Ud1.UserDefinedValue = eventObj.UserDefined;
				Ud1.ReadControls();

				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewEvent()
		{
			bool result = true;
			Event eventObj = new Event(this.patient, true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				if (problem != null)
					eventObj.PrimaryProblemID = problem.ProblemID;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Event = eventObj;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			Event eventObj = null;
			CoverageSelectionContext covSelContext = null;
			try
			{	
				PageTab.SelectedTabKey = this.TargetTabKey;		// navigate to target tab.

				// if a coverage selection context was passed, the user has selected a coverage and returned back to the problem page
				// to save the problem.
				// continue with saving.
				covSelContext = this.GetParam("CoverageSelectionContext") as CoverageSelectionContext;
				if (covSelContext != null)
				{
					#region Back from Coverage Selection

					// Back from Coverage Selection
					// Get all the context objects from the coverage selection context.
					patient = covSelContext.Patient;
					problem = covSelContext.Problem;
					patientCoverage = covSelContext.PatientCoverage;		// Newly selected coverage is here.
					eventObj = covSelContext.ERC as Event;
					if (eventObj == null)
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Returned from coverage selection with null Event!");
					
					this.CacheObject(typeof(Patient), patient);
					this.CacheObject(typeof(PatientCoverage), patientCoverage);
					this.CacheObject(typeof(Problem), problem);

					// dump the coverage selection steps performed.  will be disabled at deployment.
					this.DumpCoverageSelectionContext(covSelContext);

					eventObj.ChangeCoverage(patientCoverage);

					if (covSelContext.IsSaving)
					{
						covSelContext.SaveERC();		// save in the coverage selection context.
						this.DumpAutoActivity(eventObj, true);
						this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@EVENT@");
					}

					#endregion
				}
				else
				{
					patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
					if (patient == null)
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
					// get the passed patient subscriber coverage (link to patient)
					patientCoverage = GetParamOrGetFromCache("PatCov", typeof(PatientCoverage)) as PatientCoverage;
					if (patientCoverage == null)	
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-subscriber-coverage");
					problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
					//if (problem == null)	
					//	throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");					

					// if event was not passed, create a new one
					this.CacheObject(typeof(Patient), patient);
					this.CacheObject(typeof(PatientCoverage), patientCoverage);
					this.CacheObject(typeof(Problem), problem);

					eventObj = this.GetParamOrGetFromCache("Event", typeof(Event)) as Event;
					if (eventObj == null)
					{
						if (problem == null)	
							throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");
						NewEvent();
						return PerDayCoverageValidation(covSelContext, this.patientCoverage, this.problem);
					}

				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//eventObj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			this.Event = eventObj;

			if (covSelContext == null)		// if not returning from coverage selection
				PerDayCoverageValidation(covSelContext, this.patientCoverage, this.problem);			

			return result;
		}

		#region Per-Day Coverage Validation

		//		public bool PerDayCoverageValidation(CoverageSelectionContext covSelContext)
		//		{
		//			if (this.eventObj == null)
		//				return false;
		//
		//			// Validate coverage for an existing event.
		//			if (covSelContext == null) // && !eventObj.IsNew)
		//			{
		//				if (eventObj.RequiresCoverageValidationForToday())
		//				{
		//					// if the event is open.
		//					// validate coverage once a day.
		//					// Select a valid coverage
		//					covSelContext = new CoverageSelectionContext(false, this.patient, this.patientCoverage, this.problem, this.eventObj);
		//					covSelContext.CoverageSelectionPrompt = "@SELECTVALIDCOVERAGE@";
		//					EnumSelectValidCoverageResult aresult = this.SelectValidCoverage(covSelContext);
		//					switch (aresult)
		//					{
		//						case EnumSelectValidCoverageResult.NoCoverageFound:
		//							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "@NOVALIDCOVERAGE@"));
		//							return false;
		//						case EnumSelectValidCoverageResult.CoverageValid:
		//						case EnumSelectValidCoverageResult.SingleCoverageAutoSelected:
		//							break;
		//						case EnumSelectValidCoverageResult.UserMustSelectFromMultiple:
		//							return false;		// user was redirected to coverage selection page.
		//						default:
		//							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "Unknown selection result"));
		//							return false;
		//					}					
		//				}
		//			}
		//			return true;
		//		}

		#endregion

		#region Redirect with CoverageSelectionContext

		/// <summary>
		/// This is called when the user returns from Coverage Selection.
		/// The coverage selection context will contain the newly selected PatientCoverage.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		public static void Redirect(CoverageSelectionContext coverageSelectionContext)
		{
			// BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CoverageSelectionContext", coverageSelectionContext);
			BasePage.Redirect("EventForm.aspx");
		}

		#endregion

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, Event eventObj)
		{
			if (patient == null || patCov == null)
				throw new ActiveAdviceException("You can open an event only when patient and coverage are selected"); 

			//BasePage.PushCurrentCallingPage();
			
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("Event", eventObj);
			BasePage.Redirect("EventForm.aspx");
		}

		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, int eventID)
		{
			Event eventObj = new Event();
			if (!eventObj.Load(patient, eventID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@EVENT@");
			Redirect(patient, patCov, problem, eventObj);
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			//if (this.eventObj.IsNew)
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.eventObj);
			//else
			//	pageSummary.RenderObjects(this.patient);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;

				if (possibleDuplicateEvents == null)		// check if the possible duplicates are already being presented to the user.
				{
					// if not, check duplicates and load possible duplicates and let the user decide
					if (eventObj.DuplicateCheck())
					{
						LoadPossibleDuplicateEvents();
						return false;  // let the user decide
					}
				}

				if (this.PossibleDuplicateEvents != null)
					this.PossibleDuplicateEvents = null;	// go out of the duplicates mode.

				if (this.eventObj.IsNew || this.eventObj.StartDateChanged)
				{
					#region Validate/Select Coverage before save

					// Select a valid coverage and save the event
					CoverageSelectionContext covSelContext = new CoverageSelectionContext(true, this.patient, this.patientCoverage, this.problem, this.eventObj);
					EnumSelectValidCoverageResult result = this.SelectValidCoverage(covSelContext);
					this.DumpCoverageSelectionContext(covSelContext);
					switch (result)
					{
						case EnumSelectValidCoverageResult.NoCoverageFound:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "@NOVALIDCOVERAGE@"));
							return false;
						case EnumSelectValidCoverageResult.CoverageValid:
						case EnumSelectValidCoverageResult.SingleCoverageAutoSelected:
						{
							// save the event in the context of coverage selection
							covSelContext.SaveERC();
							this.DumpAutoActivity(this.eventObj, true);
							break;
						}
						case EnumSelectValidCoverageResult.UserMustSelectFromMultiple:
							return false;		// user was redirected to coverage selection page.
						default:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "Unknown selection result"));
							return false;
					}
					// End of Select a valid coverage and save the problem

					#endregion
				}
				else
				{
					// start date didn't change.  just save directly.
					//if (this.eventObj.IsNew)
					//{
					//	this.eventObj.Save(this.patientCoverage, this.problem);
					//	this.DumpAutoActivityLog(this.eventObj, true);
					//}
					//else

					//FORK 1.1
					// Added by Alp Gulden 01/18/06
					// Check if save button clicked for Clinical Review
					// Call saveitem button code from request or decision.

					//get latest request values
					if (this.PageTab.SelectedTabKey == "EVE_Reviews")
					{
							if(!CRev.ReadControlsForClinicalReviewRequest())
								return false;
							// check if request update or inserted
							if(CRev.ClinicalReviewRequest!=null && CRev.ClinicalReviewRequest.IsNewOrDirty)
							{
								if (CRev.SaveDataForClinicalReviewRequest())
									CRev.ReloadContext();
								
								this.eventObj.SaveClinicalReviewRequests();
								
								//CRev.LoadDataForClinicalReviewRequests();
								CRev.NewClinicalReviewDecision();
								this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@REVIEWREQUEST@");
								return true;
							}
							// check if decision update or inserted
							//get latest decision values
							if(!CRev.ReadControlsForClinicalReviewDecision())
								return false;
							if(CRev.ClinicalReviewDecision!=null && CRev.ClinicalReviewDecision.IsNewOrDirty)
							{
								ClinicalReviewDecision selecteDCRev = new ClinicalReviewDecision();
								selecteDCRev = CRev.ClinicalReviewDecision;
								if (CRev.SaveDataForClinicalReviewDecision())
									CRev.ReloadContext();
								this.eventObj.SaveClinicalReviewRequests();					

								if(CRev.GeneratePhysicianReview(selecteDCRev))
									CRev.ReloadContext();

								//CRev.LoadDataForClinicalReviewRequests();
								this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@REVIEWDECISION@");
								return true;
							}
						}
						this.eventObj.Save();
						this.DumpAutoActivity(this.eventObj, true);
						CRev.LoadDataForClinicalReviewRequests();
						this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@EVENT@");
						this.Event = this.Event;		// just refresh	
					//
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}

			//FORK 1.1
			// Added by Alp Gulden 01/18/06
			// GenerateLetter process moved under Clinical Review Save
			//GenerateLetters();		// generate letters after the save is successfull
			//

			//this.Event = this.Event;	// refresh
			return true;
		}

		/// <summary>
		/// Generate letters for the event's request-decisions.
		/// </summary>
		public void GenerateLetters()
		{
			try
			{
				if (eventObj.GenerateLetters(true))	// generate leters and always check for LetterDecision
					//Event request-decision letters have been generated successfully.
					this.SetPageMessage("@EVENTLETTERSGEN@", EnumPageMessageType.AddInfo);
				else
					//There are no request-decision letters to be generated.
					this.SetPageMessage("@NOEVENTLETTERSGEN@", EnumPageMessageType.AddInfo);
			}
			catch(Exception ex)
			{
				this.RaisePageException(new Exception("An error occured while generating letters.", ex));
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EventCollection PossibleDuplicateEvents
		{
			get { return possibleDuplicateEvents; }
			set
			{
				if (possibleDuplicateEvents != null && value == null)	// switching back to normal
					this.PageTab.SelectedTabKey = "EVE_Details";
				possibleDuplicateEvents = value;
				try
				{
					gDup.UpdateFromCollection(possibleDuplicateEvents);  // update given grid from the collection
					// other object-to-control methods if any
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("possibleDuplicateEvents", possibleDuplicateEvents);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadPossibleDuplicateEvents()
		{
			bool result = true;
			EventCollection possibleDuplicateEvents = null;
			try
			{	// use any load method here
				possibleDuplicateEvents = eventObj.GetPossibleDuplicateEvents();
				if (possibleDuplicateEvents == null || possibleDuplicateEvents.Count == 0)
					this.SetPageMessage("No duplicate events found", EnumPageMessageType.Info);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//possibleDuplicateEvents.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.PossibleDuplicateEvents = possibleDuplicateEvents;
			return result;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			
			bool duplicatesMode = this.possibleDuplicateEvents != null;
			bool isNew = eventObj.IsNew;

			this.SetPageTabItemVisible("EVE_Duplicates", duplicatesMode);
			this.SetPageTabItemVisible("EVE_Details", !duplicatesMode);
			this.SetPageTabItemVisible("EVE_Reviews", !duplicatesMode && AASecurityHelper.HasFullAccessRole(AASecurityHelper.REVIEWS) );
			SetPageTabItemEnabled("EVE_Reviews",!(eventObj!=null && eventObj.IsNew));
			this.SetPageTabItemVisible("EVE_PCPRefPr", !duplicatesMode);
			this.SetPageTabItemVisible("EVE_Administration", !duplicatesMode);
			this.SetPageTabItemVisible("EVE_UserDefined", !duplicatesMode);
			this.SetPageTabItemVisible("EVE_Mother", !duplicatesMode && this.IsMom);
			this.SetPageTabItemVisible("EVE_Baby", !duplicatesMode && this.IsBaby);

			this.SetPageTabItemVisible("PHYREV_PhysicianReview", !duplicatesMode);
			this.SetPageTabItemVisible("CONSPR_ConsultingPr", !duplicatesMode);
			this.SetPageTabItemVisible("OUT_Outcomes", !duplicatesMode);
			this.SetPageTabItemVisible("DXPX_DXPX", !duplicatesMode);

			// Common tabs that are redirected are available only when the event is not new!
			this.SetPageTabItemEnabled("PHYREV_PhysicianReview", !isNew);
			this.SetPageTabItemEnabled("CONSPR_ConsultingPr", !isNew);
			this.SetPageTabItemEnabled("OUT_Outcomes", !isNew);
			this.SetPageTabItemEnabled("DXPX_DXPX", !isNew);

			// Tab toolbar buttons
			this.SetPageTabToolbarItemEnabled("LinkProblem", !isNew);

			NetsoftUSA.InfragisticsWeb.ContentPanel panel;
			panel= (ContentPanel)this.FindControl("CRev_pnlClinicalRequest");

//			bool isSaveEnabled = ((CRev.ClinicalReviewRequest!=null && CRev.ClinicalReviewRequest.IsNewOrDirty) || (CRev.ClinicalReviewDecision!=null && CRev.ClinicalReviewDecision.IsNewOrDirty))? false : true;
//			bool isSaveEnabled = (panel!=null || panel.Visible)? false : true;
//			this.SetPageToolbarItemEnabled("Save", isSaveEnabled);

			if (duplicatesMode)
				if (!this.PageError)
					this.SetPageMessage("@EVENTPOSSIBDUP@", EnumPageMessageType.Warning);

			this.RenderClientFunctions(pnlDetails.Controls, this.eventObj, "OnCalcDetails");
			this.SetPageToolbarItemEnabled("CostRpt",(!isNew) && (patient!= null && patient.PatientId != 0));
			this.SetPageToolbarItemEnabled("EventRpt",(!isNew) && (patient != null && patient.PatientId != 0));
	
			//FORK 1.1
			// added by alp gulden 1/18/06
			// popup appears only when decision save to generate letter
			if(this.pnlClinicalReview.Visible)			
				if(CRev.ClinicalReviewDecision!=null && CRev.ClinicalReviewDecision.IsNewOrDirty)
						this.SetPageToolbarItemTargetURL("Save", "javascript:AskForLetterGenAndSave();");
				
			this.RegisterClientScriptBlock("AskForLetterGenAndSave", @"
			<script language=""javascript"">
			function AskForLetterGenAndSave()
			{
				ret = confirm(""Would you like to generate letters (if any) after the saving the decision?"");
				if (ret)
					GetElem('" + this.wbtnDummySaveAndPrintLetters.ClientID + @"').click();
				else
					GetElem('" + this.wbtnDummySave.ClientID + @"').click();
			}
			</script>
			");
			//

		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Patient BabyPatient
		{
			get { return babyPatient; }
			set
			{
				babyPatient = value;
				try
				{
					bool createBabyMode = babyPatient != null;
					this.pnlBabyDetails.Visible = !createBabyMode;
					this.pnlBabyBirthSize.Visible = !createBabyMode;
					this.pnlDischargeStatus.Visible = !createBabyMode;
					this.pnlBabyPatient.Visible = createBabyMode;
					this.pnlBabyEvent.Visible = createBabyMode;

					this.UpdateFromObject(pnlBabyPatient.Controls, babyPatient);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("BabyPatient", babyPatient);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Event BabyEvent
		{
			get { return babyEvent; }
			set
			{
				babyEvent = value;
				try
				{
					this.UpdateFromObject(pnlBabyEvent.Controls, babyEvent);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("BabyEvent", babyEvent);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForBabyPatient()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlBabyPatient.Controls, babyPatient);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForBabyEvent()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlBabyEvent.Controls, babyEvent);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewBabyPatient()
		{
			bool result = true;
			try
			{	// or use an initialization method here
				babyPatient = Patient.CreateBaby();
				babyEvent = new Event(babyPatient, true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.BabyPatient = babyPatient;
			this.BabyEvent = babyEvent;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForBabyPatient()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForBabyPatient())
					return false;
				if (!this.ReadControlsForBabyEvent())
					return false;
				//babyPatient.Save(); // update or insert to db 
				this.SetPageMessage("A new baby has been created.  PatientID={0}", EnumPageMessageType.Info, 
					new object[] { this.babyPatient.PatientId } );
				this.BabyPatient = null;
				this.BabyEvent = null;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void butCreateBaby_Click(object sender, System.EventArgs e)
		{
			SaveDataForBabyPatient();
		}

		private void butCancelCreateBaby_Click(object sender, System.EventArgs e)
		{
			this.BabyPatient = null;
			this.BabyEvent = null;
		}
	
		public void OnSubNavigationItemClick_Activities(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ActivitiesForm.Redirect(EnumActivityContext.Activity, EnumActivityAndNoteContext.ERC);
		}

		public void OnSubNavigationItemClick_Images(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			// make sure active event is selected.
			ImageSearch.Redirect(this.patient,this.patientCoverage, this.problem, this.eventObj, null);
		}

		public new void OnSubNavigationItemClick_Notes(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			NoteSearch.Redirect(EnumActivityAndNoteContext.ERC);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();

			this.CheckForDirty(this.eventObj, this.eventObj.UserDefined, this.eventObj.ClinicalReviewRequests );	// no need to pass ClinicalReviewDecisions.
		}

	

	}
}
