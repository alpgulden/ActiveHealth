using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterQueueMaintanence.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseLetterQueue,DataLayer")]	
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@LETTERBATCHPAGETITLE@")]
	public class LetterBatch : BasePage
	{
		private BaseLetterQueue baseLetterQueueSearcher;
		private LetterPrintedQueue reRunLetterQueueSearcher;
				
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;

		object isEnvelope = null;
		object isDuplex = null;

		Printer printerTo;

		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnResetSelection;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSendToPrinter;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnViewLog;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBFieldLabel lblBatchNumber;
		protected NetsoftUSA.WebForms.OBLabel lblNumberOfRecords;

		private int totalNumInBatch = 0;
		private int batchNumber = 0;
		protected System.Web.UI.HtmlControls.HtmlAnchor aPrintLog;
		protected NetsoftUSA.InfragisticsWeb.WebCombo BatchNumberCombo;
		protected NetsoftUSA.WebForms.OBLabel lblBatchNumberValue;

		private enum BatchMode
		{
			Run,
			ReRun
		}

		private BatchMode batchMode;


		public int BatchNumber
		{
			get { if (ViewState["batchNumber"] == null) ViewState["batchNumber"] = -1; return (int)ViewState["batchNumber"];}
			set { ViewState["batchNumber"] = value; }
		}

		public int TotalNumInBatch
		{
			get { if (ViewState["totalNumInBatch"] == null) ViewState["totalNumInBatch"] = -1; return (int)ViewState["totalNumInBatch"];}
			set { ViewState["totalNumInBatch"] = value; }
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
			this.wbtnSendToPrinter.Click += new System.EventHandler(this.wbtnSendToPrinter_Click);
			this.BatchNumberCombo.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.BatchNumberCombo_SelectedRowChanged);
			this.wbtnViewLog.Click += new EventHandler(wbtnViewLog_Click);
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;
		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			reRunLetterQueueSearcher = (LetterPrintedQueue)this.LoadObject("ReRunLetterQueueSearcher");  // load object from cache
			baseLetterQueueSearcher = (BaseLetterQueue)this.LoadObject("LetterQueueSearcher");  // load object from cache
				
			isDuplex = this.LoadObject("IsDuplex");
			isEnvelope = this.LoadObject("IsEnvelope");

			if(Request.QueryString["ReRunBatch"] != null)
				this.batchMode = BatchMode.ReRun;
			else
				this.batchMode = BatchMode.Run;

			// load printer settings
			
			this.printerTo = (Printer)this.LoadObject("PrinterTo");

			if (!this.IsPostBack)
			{
				if (this.batchMode == BatchMode.ReRun)
				{
					NewReRunLetterQueueSearcher();
				}
				else
				{
					this.BatchNumber = baseLetterQueueSearcher.GetNewBatchNumber();
					SearchForBatch();
				}
			}
			else
			{
//				if (this.batchMode == BatchMode.Run)
//					this.BatchNumber = (int)this.LoadObject("BatchNumber");
			}
			

			this.lblNumberOfRecords.Text = "";

		}

		public void NewReRunLetterQueueSearcher()
		{
			LetterPrintedQueue reRunLetterQueueSearcher = null;
			try
			{
				// We shouldn't even be here if this is not a ReRun
				if (this.batchMode == BatchMode.ReRun)
					reRunLetterQueueSearcher = (LetterPrintedQueue)LetterQueueClassFactory.CreateLetterQueue(LetterQueueType.Printed, false);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
			this.ReRunLetterQueueSearcher = reRunLetterQueueSearcher;
		}

		
		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect()
		{
			BasePage.PushCurrentCallingPage();
			BasePage.Redirect("This page is designed to be a PopUp.");
		}

		#region UI initialization and events

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			this.RenderClientFunctions(pnlGridHolder.Controls, this.baseLetterQueueSearcher, "DateVerification");

		
			if (this.batchMode == BatchMode.ReRun)
			{
				if (this.lblNumberOfRecords.Text == "")
					this.lblNumberOfRecords.Text = this.Language.Translate("@TOTALNUMBERTOBEREPRINTED@", this.TotalNumInBatch);
				this.lblNumberOfRecords.Visible = this.TotalNumInBatch > 0;
				this.wbtnSendToPrinter.Enabled = this.TotalNumInBatch > 0;
				this.wbtnViewLog.Enabled = this.TotalNumInBatch > 0;
				
				lblBatchNumberValue.Text = this.BatchNumber.ToString();

				lblBatchNumber.Visible = true; 
				BatchNumberCombo.Visible = true;
				lblBatchNumberValue.Visible = false;
			} 
			else if (this.batchMode == BatchMode.Run)
			{
				if (baseLetterQueueSearcher is LetterPrintedQueue)
				{
					if (this.lblNumberOfRecords.Text == "")
						this.lblNumberOfRecords.Text = this.Language.Translate("@TOTALNUMBERTOBEREPRINTED@", this.TotalNumInBatch);
					this.wbtnSendToPrinter.Enabled = this.TotalNumInBatch > 0;
					this.wbtnViewLog.Enabled = this.TotalNumInBatch > 0;

					lblBatchNumberValue.Text = this.BatchNumber.ToString();

					lblBatchNumber.Visible = true;
					BatchNumberCombo.Visible = false;
					lblBatchNumberValue.Visible = true;
				}
				else
				{
					if (this.lblNumberOfRecords.Text == "")
						this.lblNumberOfRecords.Text = this.Language.Translate("@TOTALNUMBERTOBEPRINTED@", this.TotalNumInBatch);
					this.wbtnSendToPrinter.Enabled = this.TotalNumInBatch > 0;
					this.wbtnViewLog.Enabled = this.TotalNumInBatch > 0;

					lblBatchNumberValue.Text = this.BatchNumber.ToString();

					lblBatchNumber.Visible = true;
					BatchNumberCombo.Visible = false;
					lblBatchNumberValue.Visible = true;
				}
			}

			this.SetPageToolbarItemTargetURL("Cancel", "javascript: window.close();");
			
		}


		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.Cancel);
		}
		
		#endregion

		#region ReRunLetterQueueSearcher
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterPrintedQueue ReRunLetterQueueSearcher
		{
			get { return reRunLetterQueueSearcher; }
			set
			{
				reRunLetterQueueSearcher = value;
				try
				{
					this.UpdateFromObject(pnlGridHolder.Controls, reRunLetterQueueSearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("ReRunLetterQueueSearcher", reRunLetterQueueSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForReRunLetterQueueSearcher()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlGridHolder.Controls, reRunLetterQueueSearcher);	// controls-to-object
				// other control-to-object methods if any

				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		#endregion



		private void wbtnSendToPrinter_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (this.batchMode == BatchMode.Run)
				{
					if (baseLetterQueueSearcher is LetterNonPrintedQueue)
						this.TotalNumInBatch = ((LetterNonPrintedQueue)baseLetterQueueSearcher).CreateBatch(this.isDuplex, this.isEnvelope, this.BatchNumber, this.printerTo.PrinterID);
					else
						this.TotalNumInBatch = ((LetterPrintedQueue)baseLetterQueueSearcher).CreateBatch(this.isDuplex, this.isEnvelope, this.BatchNumber, this.printerTo.PrinterID);
					this.lblNumberOfRecords.Text = this.Language.Translate("@TOTALNUMBERBATCHED@", this.TotalNumInBatch);	
				}
				else if (this.batchMode == BatchMode.ReRun)
				{
					if (this.ReadControlsForReRunLetterQueueSearcher())
					{
						this.TotalNumInBatch = this.reRunLetterQueueSearcher.ReRunBatch(this.reRunLetterQueueSearcher.BatchNumber, this.printerTo.PrinterID);
						this.lblNumberOfRecords.Text = this.Language.Translate("@TOTALNUMBERRERUN@", this.TotalNumInBatch);	
					}
				}

				ReloadMainWindow();
			}
			catch(Exception ex)
			{	this.RaisePageException(ex); }
		}


		private void BatchNumberCombo_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			SearchForReRunBatch();
		}

		private void SearchForBatch()
		{
			if (baseLetterQueueSearcher is LetterPrintedQueue)
				this.TotalNumInBatch = ((LetterPrintedQueue)this.baseLetterQueueSearcher).GetLetterCount(isDuplex, isEnvelope);
			else
				this.TotalNumInBatch = ((LetterNonPrintedQueue)this.baseLetterQueueSearcher).GetLetterCount(isDuplex, isEnvelope);
		}

		private void SearchForReRunBatch()
		{
			if (!this.ReadControlsForReRunLetterQueueSearcher())
				return;

			if (this.reRunLetterQueueSearcher.BatchNumber > 0)
			{
				this.TotalNumInBatch = this.reRunLetterQueueSearcher.GetLetterCount(null, null);
			}
			else
				this.TotalNumInBatch = 0;

		}


		private void BatchReport()
		{
			this.CacheObject("ReportName", "RPTLETTERBATCHLOG");
		
//			ReportParameters reportParameters = new ReportParameters();
//			
//			if (this.batchMode == BatchMode.Run)
//			{
//				reportParameters.BatchLetterQueue = this.baseLetterQueueSearcher;
//				if (baseLetterQueueSearcher is LetterPrintedQueue)
//					reportParameters.ReportAction = 2; /* Letter Printed Queue*/
//				else
//					reportParameters.ReportAction = 1; /* Letter Non-Printed Queue*/
//			}
//			else
//			{
//				reportParameters.BatchLetterQueue = this.reRunLetterQueueSearcher;
//				reportParameters.ReportAction = 2; /* Letter Printed Queue*/
//			}
//
//			reportParameters.IsEnvelope = this.isEnvelope;
//			reportParameters.IsDuplex = this.isDuplex;
//			
//			this.CacheObject(typeof(ReportParameters), reportParameters);

			if (this.batchMode == BatchMode.Run)
			{
				if (baseLetterQueueSearcher is LetterPrintedQueue)
					baseLetterQueueSearcher.CreateBatchLogParameters(2, isDuplex, isEnvelope); /* Letter Printed Queue*/
				else
					baseLetterQueueSearcher.CreateBatchLogParameters(1, isDuplex, isEnvelope); /* Letter Non-Printed Queue*/
			}
			else
				this.reRunLetterQueueSearcher.CreateBatchLogParameters(2, isDuplex, isEnvelope);

			this.RegisterStartupScript("letterbatchlog",  "<script>ViewLetterBatchLog();\n</script>");
		}

		private void wbtnViewLog_Click(object sender, EventArgs e)
		{
			BatchReport();
		}


		private void ReloadMainWindow()
		{
			this.RegisterStartupScript("reloadmain",  "<script>window.opener.__doPostBack('wbtnSearch',''); window.close();\n</script>");
		}
	}
}
