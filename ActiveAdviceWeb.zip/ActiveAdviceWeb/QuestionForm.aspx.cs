using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Question,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(QuestionSearch))]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("Questions")]
	[PageTitle("@QUESTIONPAGETITLE@")]
	public class QuestionForm : AssessmentMaintenanceBasePage
	{
		// AnswerContextModes
		public const string MasterAnswersMode = "MasterAnswers";
		public const string SubQuestionAnswersMode = "SubAnswers";

		private AssessmentRisk assessmentRisk;
		private AssessmentLevelOfDisease assessmentLevelOfDisease;
		private AssessmentMeasurement assessmentMeasurement;
		private Question subQuestion;
		private QuestionCollection subQuestions;
		private AnswerRangeCollection answerRanges;
		private AnswerRange answerRange;
		private AnswerCollection answers;
		private Answer answer;
		private Question question;
		
		// This can be the main question or any of its subquestions
		private Question currentQuestion;

		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel3;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.WebControls.Button butClearSharedCache;
		protected NetsoftUSA.InfragisticsWeb.WebValidator OBValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator OBValidator2;
		protected System.Web.UI.WebControls.Button butNewFocus;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlQuestionContent;
		protected NetsoftUSA.WebForms.OBTextBox OBTextBox2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNote;
		protected NetsoftUSA.InfragisticsWeb.WebCombo QuestionControlTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionControlTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebLinkID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbWebLinkID;
		protected NetsoftUSA.WebForms.OBTextBox OBTextBox1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlQuestionContent2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionIndexID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit QuestionIndexID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionIndexID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContentOwnerID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ContentOwnerID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContentOwnerID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit QuestionID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetail;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlContent;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlContent2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSubQuestions;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSubQuestions;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridAnswers;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAnswerIndexID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit AnswerIndexID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAnswerIndexID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAnswerID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit AnswerID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAnswerID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMaxValue;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MaxValue;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaxValue;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMinValue;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MinValue;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMinValue;
		protected NetsoftUSA.WebForms.OBCheckBox OBCheckBox1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.WebForms.OBTextBox OBTextBox4;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel5;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridAnswerRanges;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHighOp;
		protected NetsoftUSA.InfragisticsWeb.WebCombo HighOp;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLowOp;
		protected NetsoftUSA.InfragisticsWeb.WebCombo LowOp;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAnswerRangeID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit AnswerRangeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAnswerRangeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHighValue;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit HighValue;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLowValue;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit LowValue;
		protected NetsoftUSA.WebForms.OBCheckBox OBCheckBox2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel7;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator3;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit WebNumericEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit WebNumericEdit3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel8;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInstructionText;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit InstructionText;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInstructionText;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator4;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel9;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSubQuestion;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLogic;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSubQuestionDetail;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAnswerDetail;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAnswers;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAnswerRangeDetail;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAnswerRanges;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlQuestionDetail;
		protected NetsoftUSA.InfragisticsWeb.WebButton butCancelSubQuestion;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSaveSubQuestion;
		protected NetsoftUSA.InfragisticsWeb.WebCombo LevelOfDiseaseTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLevelOfDiseaseTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebCombo RiskTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRiskTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel11;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MeasurementTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMeasurementTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel10;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelAnswerRange;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveAnswerRange;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelAnswer;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveAnswer;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel13;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Webcombo2;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel14;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Webcombo3;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel15;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Webtextedit4;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel16;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Webtextedit5;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Webtextedit6;
		protected System.Web.UI.HtmlControls.HtmlTable tblAnswerRisk;
		protected System.Web.UI.HtmlControls.HtmlTable tblAnswerRangeLevelOfDisease;
		protected System.Web.UI.HtmlControls.HtmlTable tblAnswerRangeRisk;
		protected System.Web.UI.HtmlControls.HtmlTable tblAnswerRangeMeasurement;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNewAnswer;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNewAnswerRange;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAnswerTriggers;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAnswerRangeTriggers;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAnswerContext;
		protected NetsoftUSA.WebForms.OBRadioButtonBox AnswerContext;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveAnswer;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveAnswerRange;
		protected NetsoftUSA.WebForms.OBLabel OBLabel11;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel18;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ParentQuestionID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldParentQuestionID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ParentQuestionDescription;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForParentQuestionID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAnswerControlTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo AnswerControlTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAnswerControlTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAnswerTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo AnswerTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAnswerTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel6;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit WebNumericEdit1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCCSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CCSourceID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCCSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCCAnswerID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CCAnswerID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCCAnswerID;
		protected System.Web.UI.HtmlControls.HtmlTable Table29;
		protected System.Web.UI.WebControls.Button butSave;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel12;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Webcombo1;
		protected System.Web.UI.HtmlControls.HtmlTable tblAnswerMeasurement;
		protected System.Web.UI.HtmlControls.HtmlTable tblAnswerLevelOfDisease;
		protected NetsoftUSA.WebForms.OBLabel OBLabel12;
		protected NetsoftUSA.WebForms.OBLabel OBLabel13;
		protected System.Web.UI.WebControls.Image butClearParent;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBLabel Oblabel14;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionText;
		protected NetsoftUSA.WebForms.OBTextBox QuestionText;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionText;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel17;

		protected System.Web.UI.HtmlControls.HtmlTable tblCCDropDown;
		protected LogicSelect LogicSelect1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			LogicSelect1.RebindControls(typeof(Question), "LogicID", "LogicDescription");

			if (!this.IsPostBack)
			{
				this.LoadData(); // Load data is the actual data loading method
			}
			else
			{
				question = (Question)this.LoadObject(typeof(Question));	// This would reload from cache
				subQuestion = (Question)this.LoadObject("SubQuestion");  // load object from cache
				subQuestions = (QuestionCollection)this.LoadObject(typeof(QuestionCollection));  // load object from cache
				answer = (Answer)this.LoadObject(typeof(Answer));  // load object from cache
				answers = (AnswerCollection)this.LoadObject(typeof(AnswerCollection));  // load object from cache
				answerRange = (AnswerRange)this.LoadObject(typeof(AnswerRange));  // load object from cache
				answerRanges = (AnswerRangeCollection)this.LoadObject(typeof(AnswerRangeCollection));  // load object from cache

				assessmentLevelOfDisease = (AssessmentLevelOfDisease)this.LoadObject(typeof(AssessmentLevelOfDisease));  // load object from cache
				// Feature removed
				// assessmentPOCDeficit = (AssessmentPOCDeficit)this.LoadObject(typeof(AssessmentPOCDeficit));  // load object from cache
				assessmentRisk = (AssessmentRisk)this.LoadObject(typeof(AssessmentRisk));  // load object from cache
				assessmentMeasurement = (AssessmentMeasurement)this.LoadObject(typeof(AssessmentMeasurement));  // load object from cache

			}
		}

		private void BindAnswerContext()
		{
			AnswerContext.Items.Clear();
			AnswerContext.Items.Add(new ListItem("Answers of this question", QuestionForm.MasterAnswersMode));
			AnswerContext.Items.Add(new ListItem("Subquestions", QuestionForm.SubQuestionAnswersMode));
			AnswerContext.SelectedIndex = 0;
		}

		public bool InMasterAnswersMode
		{
			get { return AnswerContext.SelectedValue == QuestionForm.MasterAnswersMode; }
			set 
			{ 
				if (value) 
					AnswerContext.SelectedValue = QuestionForm.MasterAnswersMode;
			}
		}

		public bool InSubQuestionAnswersMode
		{
			get { return AnswerContext.SelectedValue == QuestionForm.SubQuestionAnswersMode; }
			set 
			{ 
				if (value) 
					AnswerContext.SelectedValue = QuestionForm.SubQuestionAnswersMode;
			}
		}

		public static void Redirect(Question question)
		{
			BasePage.PushParam("Question", question);
			BasePage.Redirect("QuestionForm.aspx");
		}

		public static void Redirect(int questionID)
		{
			Question question = new Question();
			if (!question.Load(questionID))
				throw new ActiveAdviceException("Can't find Question");
			BasePage.PushParam("Question", question);
			BasePage.Redirect("QuestionForm.aspx");
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			Question question = null;
			try
			{	// use any load method here
				question = this.GetParam("Question") as Question;
				if (question == null)
				{
					question = new Question(true);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//question.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Question = question;		// When you set the object to the property, controls are automatically populated
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				if (question.IsNew || question.NeedsRebuild)
				{
					question.Save(); // update or insert to db 
					
					ResetAnswersMode();		// refresh the mode for questions and answers
					LoadDataForMode();
				}
				else
					question.Save();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		#region Question

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Question Question
		{
			get { return question; }
			set
			{
				question = value;
				try
				{
					// add all object-to-control population code here
					this.UpdateFromObject(pnlQuestionDetail.Controls, question);  // update controls for the given control/collection
					this.UpdateFromObject(pnlNote.Controls, question); 
					this.UpdateFromObject(pnlContent.Controls, question); 
					this.UpdateFromObject(pnlContent2.Controls, question); 
                    this.UpdateFromObject(pnlLogic.Controls, question); 

					ResetAnswersMode();
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Question), question);  // cache object using the caching method declared on the page
			}
		}

		

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	// add all control-to-object population code here
				this.UpdateToObject(pnlQuestionDetail.Controls, question);  // controls-to-object
				this.UpdateToObject(pnlNote.Controls, question);
				this.UpdateToObject(pnlContent.Controls, question);
				this.UpdateToObject(pnlContent2.Controls, question);
				this.UpdateToObject(pnlLogic.Controls, question);

				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}

		}

		#endregion 

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.gridSubQuestions.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridSubQuestions_ClickCellButton);
			this.gridSubQuestions.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridSubQuestions_ColumnsBoundToDataClass);
			this.gridSubQuestions.SelectedRowIndexChanged+=new EventHandler(gridSubQuestions_SelectedRowIndexChanged);
			this.gridAnswers.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridAnswers_ClickCellButton);
			this.gridAnswers.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridAnswers_ColumnsBoundToDataClass);
			this.gridAnswers.SelectedRowIndexChanged +=new EventHandler(gridAnswers_SelectedRowIndexChanged);
			this.gridAnswerRanges.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridAnswerRanges_ClickCellButton);
			this.gridAnswerRanges.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridAnswerRanges_ColumnsBoundToDataClass);
			
			this.ContentOwnerID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(ContentOwnerID_SelectedRowChanged);
			this.QuestionControlTypeID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.QuestionControlTypeID_SelectedRowChanged);
			this.AnswerContext.SelectedIndexChanged += new System.EventHandler(this.AnswerContext_SelectedIndexChanged);
			this.butSaveSubQuestion.Click += new System.EventHandler(this.butSaveSubQuestion_Click);
			this.butCancelSubQuestion.Click += new System.EventHandler(this.butCancelSubQuestion_Click);
			this.btnSaveAnswer.Click += new System.EventHandler(this.btnSaveAnswer_Click);
			this.btnCancelAnswer.Click += new System.EventHandler(this.btnCancelAnswer_Click);
			this.btnAddNewAnswer.Click += new System.EventHandler(this.btnAddNewAnswer_Click);
			this.btnRemoveAnswer.Click += new System.EventHandler(this.btnRemoveAnswer_Click);
			this.btnSaveAnswerRange.Click += new System.EventHandler(this.btnSaveAnswerRange_Click);
			this.btnCancelAnswerRange.Click += new System.EventHandler(this.btnCancelAnswerRange_Click);
			this.btnAddNewAnswerRange.Click += new System.EventHandler(this.btnAddNewAnswerRange_Click);
			this.btnRemoveAnswerRange.Click += new System.EventHandler(this.btnRemoveAnswerRange_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}


		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@QUESTION@");
			}
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Details":
					toolbar.AddButton("@ADDNEWRECORD@", "AddNew");
					break;
				case "Notes":
					break;
			}
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.Question = new Question(true);
		}

		public void OnTabClick_B_Answers(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			if (newTab.Key == "sometihng")
			{

			}
		}

		#region Answer

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Answer Answer
		{
			get { return answer; }
			set
			{
				answer = value;
				try
				{
					tblCCDropDown.Visible = (question.QuestionControlType == QuestionControlTypeEnum.CCDropDown);
					this.UpdateFromObject(pnlAnswerDetail.Controls, answer);  // update controls for the given control collection
					
					if (answer != null)
					{
							this.AssessmentLevelOfDisease = answer.AssessmentLevelOfDisease;
							this.AssessmentRisk = answer.AssessmentRisk;
							this.AssessmentMeasurement = answer.AssessmentMeasurement;
					}

				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Answer), answer);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAnswer()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlAnswerDetail.Controls, answer);	// controls-to-object
				this.UpdateToObject(tblAnswerLevelOfDisease.Controls, assessmentLevelOfDisease);
				this.UpdateToObject(tblAnswerRisk.Controls, assessmentRisk);
				this.UpdateToObject(tblAnswerMeasurement.Controls, assessmentMeasurement);
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAnswer()
		{
			bool result = true;
			Answer answer = null; // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				answer = new Answer(true);

				// Get the next answerindexid from the collection.
				// The user can change it later
				if (this.answers != null && this.answers.ParentQuestion != null)
					answer.AnswerIndexID = this.answers.GetNextIndexID();

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Answer = answer;
			return result;
		}


		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForAnswer()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForAnswer())
					return false;
				if (answer.IsNew && answer.ParentAnswerCollection == null)
				{
					answers.AddRecord(answer);
				}

				if (this.answers != null && this.answers.ParentQuestion != null)
					this.answers.ParentQuestion.MarkDirty();
				if (this.subQuestions != null && this.subQuestions.ParentQuestion != null)
					this.subQuestions.ParentQuestion.MarkDirty();
			
				this.Answer = null;
				this.Answers = this.answers;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		#endregion

		#region Answers

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AnswerCollection Answers
		{
			get { return answers; }
			set
			{
				answers = value;
				try
				{
					gridAnswers.UpdateFromCollection(answers);  // update given grid from the collection
					this.Answer = null;		// go out of edit mode
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AnswerCollection), answers);  // cache object using the caching method declared on the page
			}
		}

		public int SelectedAnswerIndex
		{
			get { return gridAnswers.SelectedRowIndex; }
			set
			{
				gridAnswers.SelectedRowIndex = (value < 0) ? 0 : value;;
				Answer = null;		// go out of edit mode
			}
		}

		/// <summary>
		/// Returns the selected answer
		/// </summary>
		/// <returns></returns>
		public Answer GetSelectedAnswer()
		{
			if (SelectedAnswerIndex < 0)
				return null;
			else
				return this.answers[ SelectedAnswerIndex ];
		}

		/// <summary>
		/// Load answers
		/// </summary>
		public bool LoadAnswers()
		{
			try
			{
				if (InMasterAnswersMode)
					this.Answers = this.question.Answers;		// also loads
				else
				{
					Question q = this.GetSelectedSubQuestion();
					if (q != null)
						this.Answers = q.Answers;		// also loads
				}
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private void gridAnswers_SelectedRowIndexChanged(object sender, EventArgs e)
		{
			LoadAnswerRanges();
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAnswers()
		{
			try
			{	//customize this method for this specific page
				gridAnswers.UpdateToCollection(answers);	// grid-to-collection
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}


		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForAnswers()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForAnswers())
					return false;
				this.SubQuestions = this.SubQuestions;  // refresh
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		#endregion

		#region AnswerRange

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AnswerRange AnswerRange
		{
			get { return answerRange; }
			set
			{
				answerRange = value;
				try
				{
					this.UpdateFromObject(pnlAnswerRangeDetail.Controls, answerRange);  // update controls for the given control collection
					
					if (answerRange != null)
					{
							this.AssessmentLevelOfDisease = answerRange.AssessmentLevelOfDisease;
							this.AssessmentRisk = answerRange.AssessmentRisk;
							this.AssessmentMeasurement = answerRange.AssessmentMeasurement;
					}

				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AnswerRange), answerRange);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAnswerRange()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlAnswerRangeDetail.Controls, answerRange);	// controls-to-object
				this.UpdateToObject(tblAnswerRangeLevelOfDisease.Controls, assessmentLevelOfDisease);
				this.UpdateToObject(tblAnswerRangeRisk.Controls, assessmentRisk);
				this.UpdateToObject(tblAnswerRangeMeasurement.Controls, assessmentMeasurement);

				// If neither low nor high values are there
				if (!((answerRange.LowOp != null && !double.IsNaN(answerRange.LowValue)) || (answerRange.HighOp != null && !double.IsNaN(answerRange.HighValue))))
				{
					this.SetPageMessage("At least one of the high or low values must be defined in order to save the answerrange.", EnumPageMessageType.AddError);
					return false;
				}

				if (answerRange.LowOp == null || double.IsNaN(answerRange.LowValue)) {answerRange.LowOp = null; answerRange.LowValue = double.NaN;}
				if (answerRange.HighOp == null || double.IsNaN(answerRange.HighValue)) {answerRange.HighOp = null; answerRange.HighValue = double.NaN;}

				if (!double.IsNaN(answerRange.LowValue) && !double.IsNaN(answerRange.HighValue))
				{
					if (answerRange.LowValue > answerRange.HighValue)
					{
						this.SetPageMessage("Low value must be less than high value.", EnumPageMessageType.AddError);
						return false;
					}
				}

				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}


		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForAnswerRange()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForAnswerRange())
					return false;
				
				if (answerRange.ParentAnswerRangeCollection == null)
				{
					answerRanges.AddRecord(answerRange);
				}

				if (this.answerRanges != null && this.answerRanges.ParentAnswer != null)
					this.answerRanges.ParentAnswer.MarkDirty();
				if (this.answers != null && this.answers.ParentQuestion != null)
					this.answers.ParentQuestion.MarkDirty();
				if (this.subQuestions != null && this.subQuestions.ParentQuestion != null)
					this.subQuestions.ParentQuestion.MarkDirty();

				this.AnswerRange = null;
				this.AnswerRanges = this.answerRanges;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAnswerRange()
		{
			bool result = true;
			AnswerRange answerRange = null; // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				answerRange = new AnswerRange(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.AnswerRange = answerRange;
			return result;
		}

		#endregion

		#region AnswerRanges

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AnswerRangeCollection AnswerRanges
		{
			get { return answerRanges; }
			set
			{
				answerRanges = value;
				try
				{
					gridAnswerRanges.UpdateFromCollection(answerRanges);  // update given grid from the collection
					this.AnswerRange = null;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AnswerRangeCollection), answerRanges);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAnswerRanges()
		{
			try
			{	//customize this method for this specific page
				gridAnswerRanges.UpdateToCollection(answerRanges);	// grid-to-collection
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		public int SelectedAnswerRangeIndex
		{
			get { return gridAnswerRanges.SelectedRowIndex; }
			set
			{
				gridAnswerRanges.SelectedRowIndex = (value < 0) ? 0 : value;;
				AnswerRange = null;		// go out of edit mode
			}
		}

		/// <summary>
		/// Returns the selected answer range
		/// </summary>
		/// <returns></returns>
		public AnswerRange GetSelectedAnswerRange()
		{
			if (SelectedAnswerRangeIndex < 0)
				return null;
			else
				return this.answerRanges[ SelectedAnswerRangeIndex ];
		}

		/// <summary>
		/// Load answer ranges
		/// </summary>
		public bool LoadAnswerRanges()
		{
			try
			{
				Answer a = this.GetSelectedAnswer();
				if (a != null)
					this.AnswerRanges = a.AnswerRanges;		// also loads
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		#endregion

		#region SubQuestions

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public QuestionCollection SubQuestions
		{
			get { return subQuestions; }
			set
			{
				subQuestions = value;
				try
				{
					gridSubQuestions.UpdateFromCollection(subQuestions);  // update given grid from the collection
					SubQuestion = null;		// go out of edit mode
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(QuestionCollection), subQuestions);  // cache object using the caching method declared on the page
			}
		}

		public int SelectedSubQuestionIndex
		{
			get { return gridSubQuestions.SelectedRowIndex; }
			set
			{
				gridSubQuestions.SelectedRowIndex = (value < 0) ? 0 : value;;
				SubQuestion = null;		// go out of edit mode
			}
		}

		/// <summary>
		/// Returns the selected sub-question
		/// </summary>
		/// <returns></returns>
		public Question GetSelectedSubQuestion()
		{
			if (SelectedSubQuestionIndex < 0)
				return null;
			else
				return this.subQuestions[ SelectedSubQuestionIndex ];
		}

		/// <summary>
		/// Load sub-questions
		/// </summary>
		public bool LoadSubQuestions()
		{
			try
			{
				this.SubQuestions = question.SubQuestions;		// also loads
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		public void ResetAnswersMode()
		{
			BindAnswerContext();
			this.InMasterAnswersMode = true;		// switch to master answers mode
			LoadDataForMode();
		}

		public bool LoadDataForMode()
		{
			if (question.IsComplex)
			{
				if (this.InMasterAnswersMode)
					return LoadSubQuestions();
				else
					return LoadAnswers();
			}
			else
			{
				this.SubQuestions = null;
				this.Answers = question.Answers;
				return true;
			}
			
		}

		private void gridSubQuestions_SelectedRowIndexChanged(object sender, EventArgs e)
		{
			LoadAnswers();
		}

		#endregion

		#region SubQuestion

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Question SubQuestion
		{
			get { return subQuestion; }
			set
			{
				subQuestion = value;
				try
				{
					this.UpdateFromObject(pnlSubQuestionDetail.Controls, subQuestion);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("SubQuestion", subQuestion);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSubQuestion()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlSubQuestionDetail.Controls, subQuestion);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForSubQuestion()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForSubQuestion())
					return false;
				// we must do this to mark the parent as dirty
				if (subQuestion.ParentQuestionCollection != null)
					this.subQuestions.ParentQuestion.MarkDirty();
				this.SubQuestions = this.SubQuestions;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}


		#endregion

		#region LOD

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentLevelOfDisease AssessmentLevelOfDisease
		{
			get { return assessmentLevelOfDisease; }
			set
			{
				assessmentLevelOfDisease = value;
				try
				{
					this.UpdateFromObject(tblAnswerLevelOfDisease.Controls, assessmentLevelOfDisease);
					this.UpdateFromObject(tblAnswerRangeLevelOfDisease.Controls, assessmentLevelOfDisease);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AssessmentLevelOfDisease), assessmentLevelOfDisease);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAssessmentLevelOfDisease()
		{
			bool result = true;
			AssessmentLevelOfDisease assessmentLevelOfDisease = null; // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				assessmentLevelOfDisease = new AssessmentLevelOfDisease(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.AssessmentLevelOfDisease = assessmentLevelOfDisease;
			return result;
		}

		#endregion

		#region Risk

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentRisk AssessmentRisk
		{
			get { return assessmentRisk; }
			set
			{
				assessmentRisk = value;
				try
				{
					this.UpdateFromObject(tblAnswerRisk.Controls, assessmentRisk);
					this.UpdateFromObject(tblAnswerRangeRisk.Controls, assessmentRisk);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AssessmentRisk), assessmentRisk);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAssessmentRisk()
		{
			bool result = true;
			AssessmentRisk assessmentRisk = null; // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				assessmentRisk = new AssessmentRisk(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.AssessmentRisk = assessmentRisk;
			return result;
		}

		#endregion	

		#region Measurement

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentMeasurement AssessmentMeasurement
		{
			get { return assessmentMeasurement; }
			set
			{
				assessmentMeasurement = value;
				try
				{
					this.UpdateFromObject(tblAnswerMeasurement.Controls, assessmentMeasurement);
					this.UpdateFromObject(tblAnswerRangeMeasurement.Controls, assessmentMeasurement);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AssessmentMeasurement), assessmentMeasurement);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAssessmentMeasurement()
		{
			bool result = true;
			AssessmentMeasurement assessmentMeasurement = null; // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				assessmentMeasurement = new AssessmentMeasurement(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.AssessmentMeasurement = assessmentMeasurement;
			return result;
		}

		#endregion

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			bool inMasterAnswersMode = this.InMasterAnswersMode;
			bool inSubQuestionAnswersMode = this.InSubQuestionAnswersMode;

			this.pnlSubQuestionDetail.Visible = this.subQuestion != null;
			this.pnlAnswerDetail.Visible = this.answer != null;
			this.pnlAnswerRangeDetail.Visible = this.answerRange != null;

			this.pnlAnswerTriggers.Visible = this.pnlAnswerDetail.Visible; //&& answer.AnswerControlType == AnswerControlTypeEnum.Numeric;
			this.pnlAnswerRangeTriggers.Visible = this.pnlAnswerRangeDetail.Visible;

			bool editMode = (this.subQuestion != null) || (this.answer != null) || (this.answerRange != null);
			pnlAnswerContext.Visible = !editMode && question.IsComplex;		// AnswerContext radiobutton available only for complex questions

			bool addRemoveAvail = /*question.IsNew &&*/ !question.IsComplex;		// no new answers can be added to complex questions
			btnAddNewAnswer.Visible = addRemoveAvail;
			btnRemoveAnswer.Visible = addRemoveAvail;

			bool showAnswerRanges = (gridAnswers.SelectedRowIndex >= 0 && this.AnswerRanges.ParentAnswer.AnswerControlType == AnswerControlTypeEnum.Numeric);

			this.pnlAnswerRanges.Visible = showAnswerRanges;
			btnAddNewAnswerRange.Visible = showAnswerRanges;
			btnRemoveAnswerRange.Visible = showAnswerRanges;

			// grids display only when not in edit mode.
			this.pnlSubQuestions.Visible = inSubQuestionAnswersMode && this.subQuestions != null && !editMode;
			this.pnlAnswers.Visible = !editMode;
			this.pnlAnswerRanges.Visible = (showAnswerRanges && !editMode);

			this.AnswerControlTypeID.ReadOnly = false;
			if (question != null && this.answer != null)
			{
				if ((this.question.QuestionControlType == QuestionControlTypeEnum.RadioList) 
					|| (this.question.QuestionControlType == QuestionControlTypeEnum.CheckList)
					|| (this.question.QuestionControlType == QuestionControlTypeEnum.CCDropDown)
					|| (this.question.QuestionControlType == QuestionControlTypeEnum.DropDownList)
					)
				{
					this.AnswerControlTypeID.ReadOnly = true;
					if (this.answer.AnswerControlType != AnswerControlTypeEnum.Auto)
					{
						this.answer.AnswerControlType = AnswerControlTypeEnum.Auto;
						this.UpdateFromObject(this.AnswerControlTypeID, this.answer);
					}
				}
			}

            
			this.SetPageTabItemEnabled("Answers", !question.IsNew && !question.NeedsRebuild && !(this.question.QuestionControlType == QuestionControlTypeEnum.Medication));

			this.ContentOwnerID.ReadOnly = !question.IsNew;

		}



		private void gridSubQuestions_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridSubQuestions.AddButtonColumn("Select", "@SELECT@", 0);
			gridSubQuestions.AddButtonColumn("Edit", "@EDIT@", 0);
		}
			
		private void gridSubQuestions_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridSubQuestions.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			if (e.Cell.Key == "Edit")
			{
				this.SubQuestion = this.subQuestions[index];
			}
			if (e.Cell.Key == "Select")
			{
				this.Answers = this.subQuestions[index].Answers;
			}
		}


		private void gridAnswers_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridAnswers.AddButtonColumn("Select", "@SELECT@", 0);
			gridAnswers.AddButtonColumn("Edit", "@EDIT@", 0);
		}
			
		private void gridAnswers_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridAnswers.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			if (e.Cell.Key == "Edit")
			{
				this.Answer = this.answers[index];
			}
			if (e.Cell.Key == "Select")
			{
				this.AnswerRanges = this.answers[index].AnswerRanges;
			}
		}

		private void gridAnswerRanges_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridAnswerRanges.AddButtonColumn("Edit", "@EDIT@", 0);
		}
			
		private void gridAnswerRanges_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridAnswerRanges.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			if (e.Cell.Key == "Edit")
			{
				this.AnswerRange = this.answerRanges[index];
			}
		}

		private void QuestionControlTypeID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			this.UpdateToObject(QuestionControlTypeID, this.question);
			question.NeedsRebuild = true;				
		}

		private void btnSaveAnswer_Click(object sender, System.EventArgs e)
		{
			SaveDataForAnswer();
		}

		private void btnCancelAnswer_Click(object sender, System.EventArgs e)
		{
			this.Answer = null;
		}

		private void btnSaveAnswerRange_Click(object sender, System.EventArgs e)
		{
			SaveDataForAnswerRange();
		}

		private void btnCancelAnswerRange_Click(object sender, System.EventArgs e)
		{
			this.AnswerRange = null;
		}

		private void butSaveSubQuestion_Click(object sender, System.EventArgs e)
		{
			SaveDataForSubQuestion();
		}

		private void butCancelSubQuestion_Click(object sender, System.EventArgs e)
		{
			this.SubQuestion = null;
		}

		private void btnAddNewAnswerRange_Click(object sender, System.EventArgs e)
		{
			NewAnswerRange();
		}

		private void btnAddNewAnswer_Click(object sender, System.EventArgs e)
		{
			NewAnswer();
		}

		private void AnswerContext_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			LoadDataForMode();
		}

		private void btnRemoveAnswer_Click(object sender, System.EventArgs e)
		{
			Answer answer = this.GetSelectedAnswer();
			if (answer != null)
			{
				answer.MarkDel();
				this.Answers = this.Answers;
			}
		}

		private void btnRemoveAnswerRange_Click(object sender, System.EventArgs e)
		{
			AnswerRange answerRange = this.GetSelectedAnswerRange();
			if (answerRange != null)
			{
				answerRange.MarkDel();
				this.AnswerRanges = this.AnswerRanges;
			}
		}

		private void ContentOwnerID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			this.UpdateToObject(ContentOwnerID, this.question);
			this.UpdateToObject(QuestionControlTypeID, this.question);
			this.UpdateToObject(QuestionIndexID, this.question);

			if (question.IsNew && question.QuestionIndexID == -1)  // new question and user did not enter a questionIndexID
			{
				question.GetNextQuestionIndexID(); // Question gets the next available indexIDfrom the DB
				this.UpdateFromObject(QuestionIndexID, this.question);
			}
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(question, answers, subQuestions, answerRanges, assessmentLevelOfDisease, assessmentRisk, assessmentMeasurement);
		}

	}
}
