using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("QuestionnaireOrganizationSearcher,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("QROrganizations")]
	[PageTitle("@QRORGSPAGETITLE@")]
	public class QuestionnaireOrganizations : AssessmentMaintenanceBasePage
	{
		private QuestionnaireOrganizationCollection selectedQuestionnaires;
		private QuestionnaireCollection availableQuestionnaires;
		private QuestionnaireOrganizationSearcher searcher; 
		
		
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridPicker;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnShowQR;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlQuestionnairePicker;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlQuestionnaires;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCMSTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContentOwnerID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ContentOwnerID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContentOwnerID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrganizationId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationId;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganizationSearch;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtOrganizationPath;
		protected System.Web.UI.WebControls.Label lblOrganizationName;
		protected System.Web.UI.HtmlControls.HtmlTable tblOrganizationPicker;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				NewSearch();
			}
			else
			{
				searcher = (QuestionnaireOrganizationSearcher)this.LoadObject(typeof(QuestionnaireOrganizationSearcher));  // load object from cache
				availableQuestionnaires = (QuestionnaireCollection)this.LoadObject(typeof(QuestionnaireCollection));  // load object from cache
				selectedQuestionnaires = (QuestionnaireOrganizationCollection)this.LoadObject(typeof(QuestionnaireOrganizationCollection));  // load object from cache				

			}


		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("QuestionnaireOrganizations.aspx");
		}
		
		private void NewSearch()
		{
			NewSearcher();
			NewSelectedQuestionnaires();
			LoadDataForAvailableQuestionnaires();
		}
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			
			this.btnShowQR.Click += new System.EventHandler(this.btnShowQR_Click);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region UI Initialization and Events
		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			// Menu items to be displayed on specific tabs
			if (tab.Key == "Link")
			{
				toolbar.AddButton("@RESETUSERBUTTON@", "Reset");
			}
		}

		public void OnToolbarButtonClick_Reset(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewSearch(); 
			gridPicker.SelectedRowIndex = -1;
		}

		private void btnShowQR_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForSearcher())
			{	
				if(Searcher.OrganizationId > 0)
				{
					LoadDataForSelectedQuestionnaires(); // using Search
					SelectedQuestionnaires = SelectedQuestionnaires;
					AvailableQuestionnaires.SetSelectedQuestionnairesFromCollection(SelectedQuestionnaires);
					AvailableQuestionnaires = AvailableQuestionnaires;
				}
				else
					LoadDataForAvailableQuestionnaires();
			}
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if(SaveDataForSelectedQuestionnaires())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Organization Questionnaire Linkage(s) "); 
			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			if(searcher != null && searcher.OrganizationId > 0)
			{
				Organization o = new Organization();
				if (o.Load(searcher.OrganizationId))
					this.lblOrganizationName.Text = CreateOrgPathHTML(null, o);
			}
			else
				this.lblOrganizationName.Text = "";
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(selectedQuestionnaires);
		}


		#endregion

		#region Searcher
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public QuestionnaireOrganizationSearcher Searcher
		{
			get { return searcher; }
			set
			{
				searcher = value;
				try
				{
					this.UpdateFromObject(this.pnlSearch.Controls, searcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(QuestionnaireOrganizationSearcher), searcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearcher()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSearch.Controls, searcher);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearcher()
		{
			bool result = true;
			QuestionnaireOrganizationSearcher searcher = null; //new QuestionnaireOrganizationSearcher(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searcher = new QuestionnaireOrganizationSearcher();
				searcher.ActiveWithAll = 1;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.Searcher = searcher;
			return result;
		}
		#endregion

		#region Available Questionnaires
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public QuestionnaireCollection AvailableQuestionnaires
		{
			get { return availableQuestionnaires; }
			set
			{
				availableQuestionnaires = value;
				try
				{
					//gridPicker.KeepCollectionIndices = false;  // update given grid from the collection
					gridPicker.UpdateFromCollection(availableQuestionnaires);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(QuestionnaireCollection), availableQuestionnaires);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAvailableQuestionnaires()
		{
			try
			{	//customize this method for this specific page
				gridPicker.UpdateToCollection(availableQuestionnaires);	// grid-to-collection
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForAvailableQuestionnaires()
		{
			bool result = true;
			QuestionnaireCollection availableQuestionnaires = new QuestionnaireCollection();
			try
			{	
				// Load Available Questionnaires by using Searcher object
				Questionnaire questionnaire = new Questionnaire();
						questionnaire.CMSTypeID = Searcher.CMSTypeID;
						questionnaire.ContentOwnerID = Searcher.ContentOwnerID;
				availableQuestionnaires = QuestionnaireCollection.GetQuestionnairesForSelection(questionnaire);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.AvailableQuestionnaires = availableQuestionnaires;
			return result;
		}
		#endregion

		#region Selected Questionnaires
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public QuestionnaireOrganizationCollection SelectedQuestionnaires
		{
			get { return selectedQuestionnaires; }
			set
			{
				selectedQuestionnaires = value;
				try
				{
					grid.UpdateFromCollection(selectedQuestionnaires);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(QuestionnaireOrganizationCollection), selectedQuestionnaires);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSelectedQuestionnaires()
		{
			bool result = true;
			QuestionnaireOrganizationCollection selectedQuestionnaires = null; //new QuestionnaireOrganizationCollection(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				selectedQuestionnaires = new QuestionnaireOrganizationCollection();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.SelectedQuestionnaires = selectedQuestionnaires;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForSelectedQuestionnaires()
		{
			bool result = true;
			QuestionnaireOrganizationCollection selectedQuestionnaires = new QuestionnaireOrganizationCollection();
			try
			{	// use any load method here
				selectedQuestionnaires = QuestionnaireOrganizationCollection.SearchQuestionnaireOrganization(Searcher);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.SelectedQuestionnaires = selectedQuestionnaires;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForSelectedQuestionnaires()
		{
			try
			{
				if(!ReadControlsForSearcher())
					return false;
				if(!ReadControlsForAvailableQuestionnaires())
					return false;
			
				if (Searcher.OrganizationId == 0)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Organization must be selected in order to link");
			
				SelectedQuestionnaires.SynchronizeQuestionnairesFromSelectableCollection(availableQuestionnaires, Searcher.MORGId, Searcher.ORGId, Searcher.SORGId);
				SelectedQuestionnaires.Save();
				SelectedQuestionnaires = SelectedQuestionnaires;
				return true;	
			}
			catch(Exception ex)
			{
				AvailableQuestionnaires = availableQuestionnaires;
				this.RaisePageException(ex);
				return false;
			}
			return false;
		}
		#endregion
	
	}
}
