using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Globalization;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for DatePicker.
	/// </summary>
	public class DatePicker : System.Web.UI.Page
	{

		protected System.Web.UI.WebControls.Calendar Calendar1;
		protected DropDownList DropDownMonth;
		protected DropDownList DropDownYear;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				DateTimeFormatInfo df = new DateTimeFormatInfo();

				DropDownMonth.Items.Clear();
				for (int idx = 1; idx <= 12; idx++)
				{
					DropDownMonth.Items.Add(new ListItem(df.GetMonthName(idx), idx.ToString()));
				}


				DropDownYear.Items.Clear();
				for (int idx = (DateTime.Now.Year - 100); idx < (DateTime.Now.Year + 20); idx++)
				{
					DropDownYear.Items.Add(idx.ToString());
				}

				DropDownMonth.SelectedValue = DateTime.Now.Month.ToString();
				DropDownYear.SelectedValue = DateTime.Now.Year.ToString();

			}

		}

		private void Calendar1_DayRender(object sender, System.Web.UI.WebControls.DayRenderEventArgs e)
		{
			// Clear the link from this day
			e.Cell.Controls.Clear();

			// Add the custom link
			System.Web.UI.HtmlControls.HtmlGenericControl Link = new System.Web.UI.HtmlControls.HtmlGenericControl();
			e.Cell.Controls.Add(Link);
			Link.TagName = "a";
			Link.InnerText = e.Day.DayNumberText;
			//Link.Attributes.Add("href", String.Format("JavaScript:window.opener.document.{0}.value = \'{1:d}\'; if (typeof(window.opener.document.{0}.onchange) == 'function') window.opener.document.{0}.onchange(); window.close();", Request.QueryString["textbox"], e.Day.Date));
			Link.Attributes.Add("href", String.Format("JavaScript:window.opener.document.{0}.value = \'{1}\'; window.opener.__doPostBack(window.opener.document.{0}.name.replace(':', '$'),''); window.close();", Request.QueryString["textbox"], e.Day.Date.ToString("MM/dd/yyyy")));

			
			if(e.Day.IsOtherMonth)
			{
				Link.Attributes.Add("style", "display:none;");
			}
			else if (e.Day.IsSelected)
			{
				Link.Attributes.Add("style", this.Calendar1.SelectedDayStyle.ToString());
			}
			else
			{
				Link.Attributes.Add("style", this.Calendar1.DayStyle.ToString());
			}

		}



		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.Load += new System.EventHandler(this.Page_Load);
			this.Calendar1.DayRender += new System.Web.UI.WebControls.DayRenderEventHandler(this.Calendar1_DayRender);
			this.DropDownMonth.SelectedIndexChanged += new EventHandler(DropDownMonth_SelectedIndexChanged);
			this.DropDownYear.SelectedIndexChanged += new EventHandler(DropDownYear_SelectedIndexChanged);
			this.Calendar1.VisibleMonthChanged += new MonthChangedEventHandler(Calendar1_VisibleMonthChanged);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
		}
		#endregion

		private void DropDownMonth_SelectedIndexChanged(object sender, EventArgs e)
		{
			Calendar1.VisibleDate = new DateTime(int.Parse(DropDownYear.SelectedValue), int.Parse(DropDownMonth.SelectedValue),  Calendar1.VisibleDate.Day);
		}

		private void DropDownYear_SelectedIndexChanged(object sender, EventArgs e)
		{
			Calendar1.VisibleDate = new DateTime(int.Parse(DropDownYear.SelectedValue), int.Parse(DropDownMonth.SelectedValue),  Calendar1.VisibleDate.Day);
		}

		private void Calendar1_VisibleMonthChanged(object sender, MonthChangedEventArgs e)
		{
			DropDownMonth.SelectedValue = e.NewDate.Month.ToString();
			DropDownYear.SelectedValue = e.NewDate.Year.ToString();
		}
	}
}
