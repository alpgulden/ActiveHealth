using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for ICMMaintenancePr.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterScoringLoadParagraphTrigger,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("IcmPR")]
	public class ICMMaintenancePr : AssessmentMaintenanceBasePage
	{
		private LetterScoringLoadParagraphTriggerCollection letterScoringLoadParagraphTriggers;
		private LetterScoringLoadParagraphTrigger searchObject;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActiveWithAll;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSearch;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.wbtnSearch.Click += new System.EventHandler(this.wbtnSearch_Click);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				NewSearchObject();
			else
			{
				searchObject = (LetterScoringLoadParagraphTrigger)this.LoadObject("LetterScoringLoadParagraphTriggerSearchObject");  // load object from cache
				letterScoringLoadParagraphTriggers = (LetterScoringLoadParagraphTriggerCollection)this.LoadObject(typeof(LetterScoringLoadParagraphTriggerCollection));  // load object from cache
			}
		}

		#region SearchObject
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterScoringLoadParagraphTrigger SearchObject
		{
			get { return searchObject; }
			set
			{
				searchObject = value;
				try
				{
					this.UpdateFromObject(this.pnlSearch.Controls, searchObject);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("LetterScoringLoadParagraphTriggerSearchObject", searchObject);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearchObject()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSearch.Controls, searchObject);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchObject()
		{
			bool result = true;
			LetterScoringLoadParagraphTrigger searchObject = null;
			try
			{	// or use an initialization method here
				searchObject = new LetterScoringLoadParagraphTrigger();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchObject = searchObject;
			this.ActiveWithAll.SelectedRow = this.ActiveWithAll.Rows[0];
			return result;
		}
		#endregion

		#region LetterScoringLoadParagraphTriggers
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterScoringLoadParagraphTriggerCollection LetterScoringLoadParagraphTriggers
		{
			get { return letterScoringLoadParagraphTriggers; }
			set
			{
				letterScoringLoadParagraphTriggers = value;
				try
				{
					grid.UpdateFromCollection(letterScoringLoadParagraphTriggers);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterScoringLoadParagraphTriggerCollection), letterScoringLoadParagraphTriggers);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLetterScoringLoadParagraphTriggers()
		{
			try
			{	//customize this method for this specific page
				grid.UpdateToCollection(letterScoringLoadParagraphTriggers);	// grid-to-collection
				// other control-to-object methods if any
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForLetterScoringLoadParagraphTriggers()
		{
			bool result = true;
			LetterScoringLoadParagraphTriggerCollection letterScoringLoadParagraphTriggers = new LetterScoringLoadParagraphTriggerCollection();
			try
			{	// use any load method here
				letterScoringLoadParagraphTriggers = LetterScoringLoadParagraphTriggerCollection.GetFromSearch(this.searchObject);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterScoringLoadParagraphTriggers.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterScoringLoadParagraphTriggers = letterScoringLoadParagraphTriggers;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForLetterScoringLoadParagraphTriggers()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForLetterScoringLoadParagraphTriggers())
					return false;
				letterScoringLoadParagraphTriggers.Save(); // update or insert to db 
				LoadDataForLetterScoringLoadParagraphTriggers();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region UI Initialization and Events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			this.SetPageToolbarItemEnabled("Save", this.grid.Rows.Count > 0);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForLetterScoringLoadParagraphTriggers())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Triggers ");
			}
		}

		private void wbtnSearch_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForSearchObject())
				this.LoadDataForLetterScoringLoadParagraphTriggers();
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			if (tab.Key == "Search")
			{
				toolbar.AddButton(OrgMessages.MessageIDs.ADDNEWRECORD, "AddNewTrigger");
			}
		}

		public void OnToolbarButtonClick_AddNewTrigger(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// redirect to Trigger detail page
			LetterScoringLoadParagraphTrigger trigger = new LetterScoringLoadParagraphTrigger(true);
			try
			{
				ICMFormPr.Redirect(trigger);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
			{
				try
				{
					ICMFormPr.Redirect(LetterScoringLoadParagraphTriggers[index]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}
		#endregion

	}
}
