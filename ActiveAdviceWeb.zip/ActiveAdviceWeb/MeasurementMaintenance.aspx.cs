using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for MeasurementMaintenance.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.CMS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.MeasurementMessages,DataLayer")]	
	[MainDataClass("MeasurementType,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]						//defines active menu item in main navigation
	[SelectedMenuItem("Measurements")]
	public class MeasurementMaintenance : CMSMaintenanceBasePage
	{
		private MeasurementTypePickList measurementTypePickList;
		private MeasurementTypePickListCollection measurementTypePickLists;
		private MeasurementLevelOfDisease measurementLevelOfDisease;
		private MeasurementLevelOfDiseaseCollection measurementLevelOfDiseases;
		private MeasurementType measurementType;
		private MeasurementTypeCollection measurementTypes;
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSortOrder;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit SortOrder;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSortOrder;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFormula;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Formula;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFormula;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldUnitOfMeasureText;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit UnitOfMeasureText;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUnitOfMeasureText;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNormalHigh;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNormalLow;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRangeHigh;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRangeLow;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCode;
		protected NetsoftUSA.WebForms.OBCheckBox PickList;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.WebForms.OBTextBox txbNotePad;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridLODHolder;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLODDetails;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridLOD;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLevelOfDiseaseTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo LevelOfDiseaseTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLevelOfDiseaseTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLevelOfDisease;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LevelOfDisease;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLevelOfDisease;
		protected NetsoftUSA.WebForms.OBFieldLabel lbThreshholdHigh;
		protected NetsoftUSA.WebForms.OBFieldLabel lbThreshholdLow;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDeleteLOD;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddLOD;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnUpdateLOD;
		protected System.Web.UI.HtmlControls.HtmlTable tblPickingList;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPLValue;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridPLItems;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddPLItem;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnUpdatePLItem;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDeletePLItem;
		protected System.Web.UI.HtmlControls.HtmlTable tblDetails;
		protected System.Web.UI.HtmlControls.HtmlTable tblNormalValues;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCode;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPLValue;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PLValue;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRangeLow;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit RangeLow;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRangeHigh;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit RangeHigh;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNormalLow;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NormalLow;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNormalHigh;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NormalHigh;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldThreshholdLow;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ThreshholdLow;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldThreshholdHigh;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ThreshholdHigh;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Code;
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.wbtnDeleteLOD.Click += new System.EventHandler(this.wbtnDeleteLOD_Click);
			this.wbtnAddLOD.Click += new System.EventHandler(this.wbtnAddLOD_Click);
			this.wbtnUpdateLOD.Click += new System.EventHandler(this.wbtnUpdateLOD_Click);
			this.gridLOD.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridLOD_ClickCellButton);
			this.PickList.CheckedChanged += new System.EventHandler(this.PickList_CheckedChanged);
			this.wbtnAddPLItem.Click += new System.EventHandler(this.wbtnAddPLItem_Click);
			this.wbtnUpdatePLItem.Click += new System.EventHandler(this.wbtnUpdatePLItem_Click);
			this.wbtnDeletePLItem.Click += new System.EventHandler(this.wbtnDeletePLItem_Click);
			this.gridPLItems.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridPLItems_ClickCellButton); 

			this.Load += new System.EventHandler(this.Page_Load);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
			{
				LoadData();
				SetVisibilityAddPLItemButton(true);
			}
			else
			{
				measurementTypes = (MeasurementTypeCollection)this.LoadObject(typeof(MeasurementTypeCollection));  // load object from cache
				measurementType = (MeasurementType)this.LoadObject(typeof(MeasurementType));  // load object from cache			
				measurementLevelOfDiseases = (MeasurementLevelOfDiseaseCollection)this.LoadObject(typeof(MeasurementLevelOfDiseaseCollection));  // load object from cache
				measurementLevelOfDisease = (MeasurementLevelOfDisease)this.LoadObject(typeof(MeasurementLevelOfDisease));  // load object from cache
				measurementTypePickLists = (MeasurementTypePickListCollection)this.LoadObject(typeof(MeasurementTypePickListCollection));  // load object from cache
				measurementTypePickList = (MeasurementTypePickList)this.LoadObject(typeof(MeasurementTypePickList));  // load object from cache
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MeasurementTypeCollection MeasurementTypes
		{
			get { return measurementTypes; }
			set
			{
				measurementTypes = value;
				try
				{
					//grid.KeepCollectionIndices = false;  // update given grid from the collection
					measurementTypes.DisplayOnlyActive = false;
					grid.UpdateFromCollection(measurementTypes);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(MeasurementTypeCollection), measurementTypes);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			MeasurementTypeCollection measurementTypes = null;
			try
			{	// use any load method here
				measurementTypes = MeasurementTypeCollection.AllMeasurementTypes;
				// or pull from the parameter passed to this page via PushParam
				if (measurementTypes.Count > 0)
				{
					MeasurementType = measurementTypes[0];
					grid.SelectedRowIndex = 0;
				}
				else
					NewMeasurementType();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//measurementTypes.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.MeasurementTypes = measurementTypes;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				bool isNew = MeasurementType.IsNew;
				
				if(isNew)
					MeasurementTypes.Add(MeasurementType);
				MeasurementType.Save();
				if(!this.PickList.Checked /* false results in pick list*/ && this.measurementTypePickLists.Count == 0)
					this.SetPageMessage("@NOPICKLISTVALUES@", EnumPageMessageType.AddWarning); 
				grid.UpdateFromCollection(MeasurementTypes);
				gridLOD.UpdateFromCollection(MeasurementType.MeasurementLevelOfDiseases);
				if(isNew)  // If new item was added adjust Selected Row Index
				{
					grid.SelectedRowIndex = grid.Rows.Count - 1;
					MeasurementType = MeasurementType;
				}
				NSGlobal.ClearCache(typeof(MeasurementTypeCollection), false);
				NSGlobal.ClearCache("ActiveMeasurementTypes");
				NSGlobal.ClearCache("AllMeasurementTypes");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MeasurementType MeasurementType
		{
			get { return measurementType; }
			set
			{
				measurementType = value;
				try
				{
					this.UpdateFromObject(this.tblDetails.Controls, measurementType);  // update controls for the given control collection
					this.UpdateFromObject(this.tblNormalValues.Controls, measurementType);  // update controls for the given control collection
					// other object-to-control methods if any

					measurementType.LoadMeasurementLevelOfDiseases(false);
					MeasurementLevelOfDiseases = measurementType.MeasurementLevelOfDiseases;
//					if(MeasurementLevelOfDiseases.Count > 0)
//					{
//						MeasurementLevelOfDisease = MeasurementLevelOfDiseases[0];
//						gridLOD.SelectedRowIndex = 0;
//					}
//					else
//						NewMeasurementLevelOfDisease();

					measurementType.LoadMeasurementTypePickLists(false);
					MeasurementTypePickLists = measurementType.MeasurementTypePickLists;
					NewMeasurementTypePickList();						
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(MeasurementType), measurementType);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForMeasurementType()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblDetails.Controls, measurementType);  // update controls for the given control collection
				this.UpdateToObject(this.tblNormalValues.Controls, measurementType);  // update controls for the given control collection
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewMeasurementType()
		{
			bool result = true;
			MeasurementType measurementType = null;
			try
			{	// or use an initialization method here
				measurementType = new MeasurementType(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.MeasurementType = measurementType;
			return result;
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}
		
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			SetValuesMode(this.PickList.Checked /* false results in pick list*/);
			this.SetPageTabItemVisible("LOD", !MeasurementType.IsNew);
			this.RenderClientFunctions(this.pnlLODDetails.Controls, measurementLevelOfDisease, "LODTHValidation");
			this.RenderClientFunctions(this.pnlDetails.Controls, measurementType, "RangeNormalValidation");
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Details":
					toolbar.AddButton("@ADDMEASUREMENTTYPE@", "AddNewMeasurementType");
					break;
				case "LOD":
					toolbar.AddButton("@ADDMEASUREMENTLOD@", "AddNewLOD");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewMeasurementType(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMeasurementType();
			grid.SelectedRowIndex = -1;
		}

		public void OnToolbarButtonClick_AddNewLOD(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMeasurementLevelOfDisease();
			gridLOD.SelectedRowIndex = -1;
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
			{
				MeasurementType = MeasurementTypes[index];
			}
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if(ReadControlsForMeasurementLevelOfDisease() && ReadControlsForMeasurementType())
			{
				if (SaveData())
				{
					this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Measurement Type "); 
					grid.UpdateFromCollection(MeasurementTypes);
				}
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MeasurementLevelOfDiseaseCollection MeasurementLevelOfDiseases
		{
			get { return measurementLevelOfDiseases; }
			set
			{
				measurementLevelOfDiseases = value;
				try
				{
					//grid.KeepCollectionIndices = false;  // update given grid from the collection
					gridLOD.UpdateFromCollection(measurementLevelOfDiseases);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(MeasurementLevelOfDiseaseCollection), measurementLevelOfDiseases);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MeasurementLevelOfDisease MeasurementLevelOfDisease
		{
			get { return measurementLevelOfDisease; }
			set
			{
				measurementLevelOfDisease = value;
				try
				{
					this.pnlLODDetails.Visible = true;
					this.UpdateFromObject(this.pnlLODDetails.Controls, measurementLevelOfDisease);  // update controls for the given control collection
					// other object-to-control methods if any
					if(measurementLevelOfDisease.LevelOfDisease == null & measurementLevelOfDisease.IsNew) //check for new Item
					{
						this.wbtnAddLOD.Visible = true;
						this.wbtnUpdateLOD.Visible = false;
						this.wbtnDeleteLOD.Visible = false;
					}
					else
					{
						this.wbtnAddLOD.Visible = false;
						this.wbtnUpdateLOD.Visible = true;
						this.wbtnDeleteLOD.Visible = true;
					}				
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(MeasurementLevelOfDisease), measurementLevelOfDisease);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForMeasurementLevelOfDisease()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlLODDetails.Controls, measurementLevelOfDisease);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewMeasurementLevelOfDisease()
		{
			bool result = true;
			MeasurementLevelOfDisease measurementLevelOfDisease = null;
			try
			{	// or use an initialization method here
				measurementLevelOfDisease = new MeasurementLevelOfDisease(true);
				measurementLevelOfDisease.ParentMeasurementLevelOfDiseaseCollection = MeasurementLevelOfDiseases;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.MeasurementLevelOfDisease = measurementLevelOfDisease;
			return result;
		}

		private void gridLOD_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridLOD.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
			{
				MeasurementLevelOfDisease = MeasurementLevelOfDiseases[index];
			}
		}

		private void wbtnUpdateLOD_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForMeasurementLevelOfDisease())
			{
				MeasurementLevelOfDisease.MarkDirty();
				MeasurementType.MarkDirty(); // parent object
				gridLOD.UpdateFromCollection(MeasurementLevelOfDiseases);
				this.pnlLODDetails.Visible = false;
			}
		}

		private void wbtnAddLOD_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForMeasurementLevelOfDisease())
			{
				if(MeasurementLevelOfDisease.LevelOfDisease == null 
					&& MeasurementLevelOfDisease.MeasurementTypeID == 0
					&& MeasurementLevelOfDisease.ThreshholdHigh == 0
					&& MeasurementLevelOfDisease.ThreshholdLow == 0)
					return;
				MeasurementLevelOfDisease.MeasurementTypeID =
					MeasurementType.CodeId;
				MeasurementLevelOfDiseases.Add(MeasurementLevelOfDisease);	
		
				gridLOD.UpdateFromCollection(MeasurementLevelOfDiseases);
				gridLOD.SelectedRowIndex = gridLOD.Rows.Count - 1;
				MeasurementLevelOfDisease = MeasurementLevelOfDisease;
				MeasurementType.MarkDirty(); // parent object
				this.pnlLODDetails.Visible = false;
			}
		}

		private void wbtnDeleteLOD_Click(object sender, System.EventArgs e)
		{
			MeasurementLevelOfDisease.MarkDel();
			MeasurementType.MarkDirty(); // parent object
			gridLOD.UpdateFromCollection(MeasurementLevelOfDiseases);
			this.pnlLODDetails.Visible = false;
		}

		private void PickList_CheckedChanged(object sender, System.EventArgs e)
		{
		}

		private void SetValuesMode(bool mode)
		{
			this.tblPickingList.Visible = !mode;
			this.tblNormalValues.Visible = mode;
		}

		private void gridPLItems_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridPLItems.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
			{
				MeasurementTypePickList = MeasurementTypePickLists[index];
				SetVisibilityAddPLItemButton(false);
			}
		}

		private void SetVisibilityAddPLItemButton(bool state)
		{
			wbtnAddPLItem.Visible = state;
			wbtnUpdatePLItem.Visible = 	wbtnDeletePLItem.Visible = !state;
		}

		private void wbtnAddPLItem_Click(object sender, System.EventArgs e)
		{
			if (ReadControlsForMeasurementTypePickList() && ReadControlsForMeasurementType())
			{
				if(MeasurementTypePickList.PLValue == null)
					return;

				MeasurementTypePickList.MeasurementTypeId = MeasurementType.CodeId;
				MeasurementTypePickLists.Add(MeasurementTypePickList);
				gridPLItems.UpdateFromCollection(MeasurementTypePickLists);
				gridPLItems.SelectedRowIndex = gridPLItems.Rows.Count - 1;
				MeasurementTypePickList = MeasurementTypePickList;
				MeasurementType.MarkDirty(); // parent object
				NewMeasurementTypePickList();
			}
			SetVisibilityAddPLItemButton(true);
		}

		private void wbtnUpdatePLItem_Click(object sender, System.EventArgs e)
		{
			if (ReadControlsForMeasurementTypePickList() && ReadControlsForMeasurementType())
			{
				MeasurementTypePickList.MarkDirty();
				MeasurementType.MarkDirty(); // parent object
				gridPLItems.UpdateFromCollection(MeasurementTypePickLists);
				NewMeasurementTypePickList();
			}
			SetVisibilityAddPLItemButton(true);
		}

		private void wbtnDeletePLItem_Click(object sender, System.EventArgs e)
		{
			if (!ReadControlsForMeasurementType())
				return;
			MeasurementTypePickList.MarkDel();
			MeasurementType.MarkDirty(); // parent object
			gridPLItems.UpdateFromCollection(MeasurementTypePickLists);
			NewMeasurementTypePickList();
			SetVisibilityAddPLItemButton(true);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(this.measurementTypes, this.measurementTypePickLists, this.measurementLevelOfDiseases);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MeasurementTypePickListCollection MeasurementTypePickLists
		{
			get { return measurementTypePickLists; }
			set
			{
				measurementTypePickLists = value;
				try
				{
					this.gridPLItems.UpdateFromCollection(measurementTypePickLists);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(MeasurementTypePickListCollection), measurementTypePickLists);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MeasurementTypePickList MeasurementTypePickList
		{
			get { return measurementTypePickList; }
			set
			{
				measurementTypePickList = value;
				try
				{
					this.UpdateFromObject(this.tblPickingList.Controls, measurementTypePickList);  // update controls for the given control collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(MeasurementTypePickList), measurementTypePickList);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForMeasurementTypePickList()
		{
			try
			{	//customize this method for this specific page
				// Verify if new value already exists in the collection
				MeasurementTypePickLists.IndexBy_PLValue.Rebuild();
				MeasurementTypePickList obj = MeasurementTypePickLists.FindBy(this.PLValue.Text);
				if(obj != null)
				{
					this.RaisePageException( new ActiveAdviceException(AAExceptionAction.DisableUI, "Pick List Item already exists "));
					return false;
				}

				this.UpdateToObject(this.tblPickingList.Controls, measurementTypePickList);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewMeasurementTypePickList()
		{
			bool result = true;
			MeasurementTypePickList measurementTypePickList = null;
			try
			{	// or use an initialization method here
				measurementTypePickList = new MeasurementTypePickList(true);
				measurementTypePickList.ParentMeasurementTypePickListCollection = MeasurementTypePickLists;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.MeasurementTypePickList = measurementTypePickList;
			return result;
		}		
	}
}
