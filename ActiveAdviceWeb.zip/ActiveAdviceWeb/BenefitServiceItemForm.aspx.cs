using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Benefit Service Item data entry form with its own tabs.
	/// Although this is a child table of BenefitServices, the records in this
	/// table are managed independently.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PlanMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BenefitServiceItem,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(BenefitServiceItemsSearch))]
	[SelectedMenuItem("BenefitServices")]						//define the active menu item in side menu
	[SelectedMainMenuItem("MPlan")]						//defines active menu item in main navigation
	[PageTitle("@BENEFITSERVICEPAGETITLE@")]
	public class BenefitServiceItemForm : PlanBasePage
	{
		private BenefitService benefitService;
		private BenefitServiceItem data;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldBenefitServiceTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo BenefitServiceTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBenefitServiceTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit BenefitServiceItemId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBenefitServiceItemId;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.WebForms.OBValidator vldNote;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNote;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetPenalty;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit InNetPenalty;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetPenalty;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetOutOfPocketFamily;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit InNetOutOfPocketFamily;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetOutOfPocketFamily;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetDeductibleFamily;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit InNetDeductibleFamily;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetDeductibleFamily;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetCoPay;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit InNetCoPay;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetCoPay;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetPercent;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit InNetPercent;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetPercent;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetVisitAnnual;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetVisitAnnual;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetDaysAnnual;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit InNetDaysAnnual;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetDaysAnnual;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetDollarsAnnual;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit InNetDollarsAnnual;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetDollarsAnnual;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetNetworkId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit InNetNetworkId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetNetworkId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetCoveredId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetOutOfPocketIndividual;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit InNetOutOfPocketIndividual;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetOutOfPocketIndividual;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetDeductibleIndividual;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit InNetDeductibleIndividual;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetDeductibleIndividual;
		protected NetsoftUSA.WebForms.OBCheckBox InNetExcluded;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetExcluded;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetVisitsLife;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit InNetVisitsLife;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetVisitsLife;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetDaysLife;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit InNetDaysLife;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetDaysLife;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetDollarsLife;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit InNetDollarsLife;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInNetDollarsLife;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetPenalty;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetOutOfPocketFamily;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit OutNetOutOfPocketFamily;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetOutOfPocketFamily;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetDeductibleFamily;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit OutNetDeductibleFamily;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetDeductibleFamily;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetCoPay;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit OutNetCoPay;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetCoPay;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetPercent;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OutNetPercent;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetPercent;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetVisitsAnnual;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OutNetVisitsAnnual;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetVisitsAnnual;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetDaysAnnual;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OutNetDaysAnnual;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetDaysAnnual;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetDollarsAnnual;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit OutNetDollarsAnnual;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetDollarsAnnual;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetNetworkId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OutNetNetworkId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetNetworkId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetCoveredId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetOutOfPocketIndividual;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit OutNetOutOfPocketIndividual;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetOutOfPocketIndividual;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetDeductibleIndividual;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit OutNetDeductibleIndividual;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetDeductibleIndividual;
		protected NetsoftUSA.WebForms.OBCheckBox OutNetExcluded;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetExcluded;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetVisitsLife;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OutNetVisitsLife;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetVisitsLife;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetDaysLife;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OutNetDaysLife;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetDaysLife;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetDollarsLife;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit OutNetDollarsLife;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutNetDollarsLife;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlInNetDetails;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlOutNetDetails;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInNetCoveredId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo InNetCoveredId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetCoveredId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo OutNetCoveredId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit InNetVisitsAnnual;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutNetPenalty;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit OutNetPenalty;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected UserDefined UserDefined1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			UserDefined1.ReloadContext("BenefitServiceItem", data, true /*createcontrols*/); // short usage - always call
			// Put user code to initialize the page here
			if(!UserDefined1.HasFields())
				this.PageTab.GetTab("UserDefined").Visible = false;
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
				//this.NewMORGSearch();		// Use such a method for search pages
			}
			else
			{
				// always load all server side objects from the cache
				//col = (MORGCollection)this.LoadObject(typeof(MORGCollection));	// This would reload from cache
				// searchers must cache and read from a different key than the class name
				//morgSearcher = (MORG)this.LoadObject("MORGSearcher");
				data = (BenefitServiceItem)this.LoadObject(typeof(BenefitServiceItem));  // load object from cache
				benefitService = (BenefitService)this.LoadObject(typeof(BenefitService));
			}
			
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject(typeof(BenefitServiceItem), null);
			base.NavigateAway ();
		}


		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("Redirect method must redirect to its own page.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			if(this.IsPopup)
				return;
			// Menu items to be displayed on specific tabs
			if (tab.Key == "Details")
			{
				toolbar.AddButton(PlanMessages.MessageIDs.ADDNEWRECORD, "AddNew");
				toolbar.AddButton("@CLONE@", "Clone");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewData();
		}

		public void OnToolbarButtonClick_Clone(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.ReadControls())
			{
				this.BenefitServiceItem = data.CreateCopyOfSpecialBenefitServiceItem();
			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			if(!this.IsPopup)
				toolbar.AddButton("@SAVERECORD@", "Save");
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@BENEFITSERVICEITEM@");
				BasePage.PushPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@BENEFITSERVICEITEM@");
				this.RedirectBack();
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BenefitServiceItem BenefitServiceItem
		{
			get { return data; }
			set
			{
				data = value;
				try
				{
					this.UpdateFromObject(pnlDetails.Controls, data);  // update controls for the given control collection
					this.UpdateFromObject(pnlNote.Controls, data);  // update controls for the given control collection
					this.UpdateFromObject(pnlInNetDetails.Controls, data);  // update controls for the given control collection
					this.UpdateFromObject(pnlOutNetDetails.Controls, data);  // update controls for the given control collection
					// other object-to-control methods if any
					
					UserDefined1.ReloadContext("BenefitServiceItem", data, false /*createcontrols*/); // short usage - always call
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(BenefitServiceItem), data);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlDetails.Controls, data);	// controls-to-object
				this.UpdateToObject(pnlNote.Controls, data);	// controls-to-object
				this.UpdateToObject(pnlInNetDetails.Controls, data);	// controls-to-object
				this.UpdateToObject(pnlOutNetDetails.Controls, data);	// controls-to-object
				// other control-to-object methods if any
				UserDefined1.UserDefinedValue=data.UserDefined;
				UserDefined1.ReadControls();
				
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewData()
		{
			bool result = true;
			BenefitServiceItem data = new BenefitServiceItem(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				data.BenefitServiceId = benefitService.BenefitServiceId;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.BenefitServiceItem = data;
			return result;
		}

		/// <summary>
		/// Passes the given parent benefitService and the benefit item to the page.
		/// </summary>
		public static void Redirect(BenefitService benefitService, BenefitServiceItem benefitServiceItem)
		{
			BasePage.PushParam("BenefitService", benefitService);
			BasePage.PushParam("BenefitServiceItem", benefitServiceItem);

			BasePage.Redirect("BenefitServiceItemForm.aspx");
		}

		public static void Redirect(BenefitService benefitService, int benefitServiceItemId)
		{
			BenefitServiceItem benefitServiceItem = new BenefitServiceItem();
			if (!benefitServiceItem.Load(benefitServiceItemId))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@BENEFITSERVICEITEM@");
			Redirect(benefitService, benefitServiceItem);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;

				data.Save(); // update or insert to db 
				benefitService.BenefitServiceItems = null;	// force delayed reload
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			BenefitServiceItem benefitServiceItem = null;
			try
			{	// use any load method here
				// result = benefitServiceItem.Load();
				// pull from the parameter passed to this page via PushParam
				
				benefitService = GetParam("BenefitService") as BenefitService;
				if (benefitService == null)
				{
					SetPageMessage("This page must be called within the context of a Benefit Service", EnumPageMessageType.Error);
					return false;
				}

				benefitServiceItem = GetParamOrGetFromCache("BenefitServiceItem", typeof(BenefitServiceItem) ) as BenefitServiceItem;
				if (benefitServiceItem == null) 
					return NewData();
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//benefitServiceItem.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.BenefitServiceItem = benefitServiceItem;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BenefitServiceItem Data
		{
			get { return data; }
			set
			{
				data = value;
				try
				{
					this.UpdateFromObject(pnlDetails.Controls, data);  // update controls for the given control collection
					this.UpdateFromObject(pnlNote.Controls, data);  // update controls for the given control collection
					this.UpdateFromObject(pnlInNetDetails.Controls, data);  // update controls for the given control collection
					this.UpdateFromObject(pnlOutNetDetails.Controls, data);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(BenefitServiceItem), data);  // cache object using the caching method declared on the page
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.benefitService, this.BenefitServiceItem);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.RenderClientFunctions(pnlDetails.Controls, this.data, "OnCalcBenefitSvcItem");

			this.SetPageTabToolbarItemEnabled("Clone", !data.IsNew);
		}

		
	}
}
