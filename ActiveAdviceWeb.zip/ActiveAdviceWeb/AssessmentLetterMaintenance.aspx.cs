using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for AssessmentLetterMaintenance.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.LETTER_SETUP)]
	
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("AssessmentCategory,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("AssessmentLetterMaintenance")]
	[PageTitle("@ASMTCATEGORYPAGETITLE@")]
	public class AssessmentLetterMaintenance : LetterMaintenanceBasePage
	{
		private AssessmentParagraph assessmentParagraphSearcher;
		private AssessmentParagraph assessmentParagraph;
		private AssessmentParagraphCollection assessmentParagraphs;
		private AssessmentCategory assessmentCategory;

		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCategoryDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHeaderText;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit HeaderText;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHeaderText;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit AssessmentCategoryID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAssessmentCategoryID;
		//protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddCategory;
		//protected NetsoftUSA.InfragisticsWeb.WebButton wbtnUpdateCategory;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCMSTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnParagraphSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlParagraphSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlParagraphsGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridParagraphs;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnShowAddParagraph;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActiveWithAllParagraph;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCancelCategory;
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			
			this.wbtnParagraphSearch.Click += new System.EventHandler(this.wbtnParagraphSearch_Click);
			this.gridParagraphs.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridParagraphs_ClickCellButton);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

			if (!IsPostBack)
			{
				LoadDataForAssessmentCategory();
				if(this.assessmentCategory != null)
				{
					LoadDataForAssessmentParagraphs();
					NewAssessmentParagraphSearcher();
				}
			}
			else
			{
				assessmentCategory = (AssessmentCategory)this.LoadObject("AssessmentCategoryObject");  // load object from cache
				assessmentParagraphs = (AssessmentParagraphCollection)this.LoadObject("AssessmentParagraphs");  // load object from cache
				assessmentParagraph = (AssessmentParagraph)this.LoadObject("AssessmentParagraph");  // load object from cache
				assessmentParagraphSearcher = (AssessmentParagraph)this.LoadObject("AssessmentParagraphSearcher");  // load object from cache
			}
		}
		

		#region AssessmentCategory Object
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentCategory AssessmentCategory
		{
			get { return assessmentCategory; }
			set
			{
				assessmentCategory = value;
				try
				{
					this.UpdateFromObject(this.pnlCategoryDetails.Controls, assessmentCategory);  // update controls for the given control collection
					// other object-to-control methods if any

					this.AssessmentParagraphs = assessmentCategory.AssessmentParagraphs;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("AssessmentCategoryObject", assessmentCategory);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForAssessmentCategory()
		{
			bool result = true;
			AssessmentCategory assessmentCategory = new AssessmentCategory();
			try
			{	// use any load method here
				assessmentCategory = GetParamOrGetFromCache("AssessmentCategoryObject", typeof(AssessmentCategory)) as AssessmentCategory;
				if (assessmentCategory == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an Assessment Category");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//assessmentCategory.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.AssessmentCategory = assessmentCategory;
			return result;
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAssessmentCategory()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlCategoryDetails.Controls, assessmentCategory);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(AssessmentCategory assessmentCategory)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("AssessmentCategoryObject", assessmentCategory);
			BasePage.Redirect("AssessmentLetterMaintenance.aspx");

		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAssessmentCategory()
		{
			bool result = true;
			AssessmentCategory assessmentCategory = null;
			try
			{	// or use an initialization method here
				assessmentCategory = new AssessmentCategory(true);
				assessmentCategory.Active = true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.AssessmentCategory = assessmentCategory;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForAssessmentCategory()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForAssessmentCategory())
					return false;
				this.assessmentCategory.Save();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region Paragraphs
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentParagraphCollection AssessmentParagraphs
		{
			get { return assessmentParagraphs; }
			set
			{
				assessmentParagraphs = value;
				try
				{
					this.gridParagraphs.UpdateFromCollection(assessmentParagraphs);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("AssessmentParagraphs", assessmentParagraphs);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForAssessmentParagraphs()
		{
			bool result = true;
			AssessmentParagraphCollection assessmentParagraphs = new AssessmentParagraphCollection();
			try
			{	// use any load method here
				AssessmentCategory.LoadAssessmentParagraphs(true);	// load from DB because could've been modifed at AssessmentParagraphMaintenance.aspx
				assessmentParagraphs = AssessmentCategory.AssessmentParagraphs;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//assessmentParagraphs.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.AssessmentParagraphs = assessmentParagraphs;
			return result;
		}
		#endregion

		#region AssessmentParagraph
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentParagraph AssessmentParagraph
		{
			get { return assessmentParagraph; }
			set
			{
				assessmentParagraph = value;
				this.CacheObject("AssessmentParagraph", assessmentParagraph);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAssessmentParagraph()
		{
			bool result = true;
			AssessmentParagraph assessmentParagraph = null;
			try
			{	// or use an initialization method here
				assessmentParagraph = new AssessmentParagraph(true);
				assessmentParagraph.Active = true;
				assessmentParagraph.AssessmentCategoryID = AssessmentCategory.AssessmentCategoryID;
				assessmentParagraph.ParentAssessmentCategory = AssessmentCategory;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.AssessmentParagraph = assessmentParagraph;
			return result;
		}
		#endregion

		#region AssessmentParagraphSearcher
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentParagraph AssessmentParagraphSearcher
		{
			get { return assessmentParagraphSearcher; }
			set
			{
				assessmentParagraphSearcher = value;
				try
				{
					this.UpdateFromObject(this.pnlParagraphSearch.Controls, assessmentParagraphSearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("AssessmentParagraphSearcher", assessmentParagraphSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAssessmentParagraphSearcher()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlParagraphSearch.Controls, assessmentParagraphSearcher);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAssessmentParagraphSearcher()
		{
			bool result = true;
			AssessmentParagraph assessmentParagraphSearcher = null; //new AssessmentParagraph(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				assessmentParagraphSearcher = new AssessmentParagraph();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.AssessmentParagraphSearcher = assessmentParagraphSearcher;
			this.ActiveWithAllParagraph.SelectedRow = this.ActiveWithAllParagraph.Rows[0];
			return result;
		}
		#endregion

		#region UI Initialization
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			SetPageTabItemActive(TargetTabKey);
			bool isNew = AssessmentCategory.IsNew;
			SetPageTabItemEnabled("Paragraphs", !isNew);
			this.pnlParagraphSearch.Visible = this.pnlParagraphsGridHolder.Visible = !isNew;
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@CANCEL@", "Back", false);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Category":
					toolbar.AddButton("@ADDCATEGORY@", "AddNewCategory");
					break;
				case "Paragraphs":
					toolbar.AddButton("@ADDPARAGRAPH@", "AddNewParagraph");
					break;
			}
		}
		#endregion

		#region Events
		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForAssessmentCategory())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Assessment Category");
				AssessmentCategory = AssessmentCategory;
			}
		}

		public void OnToolbarButtonClick_Back(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{	
			BasePage.Redirect("AssessmentLetterSearch.aspx");
		}

		public void OnToolbarButtonClick_AddNewCategory(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewAssessmentCategory();
		}

		public void OnToolbarButtonClick_AddNewParagraph(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewAssessmentParagraph();
			AssessmentParagraphMaintenance.Redirect(AssessmentParagraph, AssessmentCategory);
		}

		private void wbtnParagraphSearch_Click(object sender, System.EventArgs e)
		{
			if(this.ReadControlsForAssessmentParagraphSearcher())
			{
				AssessmentParagraphs.FilterByActiveWithAll = AssessmentParagraphSearcher.ActiveWithAll;
				AssessmentParagraphs = AssessmentParagraphs;
			}
		}

		private void gridParagraphs_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridParagraphs.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			AssessmentParagraph = AssessmentParagraphs[index];
			if (e.Cell.Key == "Edit")
			{
				AssessmentParagraphMaintenance.Redirect(AssessmentParagraph, AssessmentCategory);
			}
		
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(assessmentCategory, assessmentParagraph, assessmentParagraphs);
		}

		#endregion
	}
}
