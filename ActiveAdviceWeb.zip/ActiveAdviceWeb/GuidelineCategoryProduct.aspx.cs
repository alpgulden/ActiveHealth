using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ActiveAdvice.DataLayer;
using NetsoftUSA.DataLayer;
using ActiveAdvice.Messages;
using NetsoftUSA.WebForms;
using NetsoftUSA.InfragisticsWeb;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for GuidelineCategoryProduct.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.GUIDELINES),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.GUIDELINES_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.GuidelineMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Guideline,DataLayer")]
	[PageTitle("@GUIDELINEPRODUCTTITLE@")]
	public class GuidelineCategoryProduct:  BasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGuidelineSourceSetID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GuidelineSourceSetID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGuidelineSourceSetID;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCategory;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuideline;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProduct;
		protected System.Web.UI.WebControls.CheckBox chkGuideline;
		protected System.Web.UI.WebControls.CheckBox chkCategory;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddNew;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNew2;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNew1;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnLink;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator3;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProduct1;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNew3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator4;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo4;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid4;
		protected System.Web.UI.WebControls.CheckBox chkProduct;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNew4;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator5;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo5;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel5;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid5;
		protected System.Web.UI.WebControls.CheckBox chkProduct1;
		protected System.Web.UI.WebControls.CheckBox chkCategory1;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNew5;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnLink1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCategory1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuideline1;
		protected System.Web.UI.WebControls.CheckBox chkGuideline1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
	
	
		private GuidelineMaintenance guidelineMaintenance1;
		private GuidelineMaintenance guidelineMaintenance2;
		private GuidelineMaintenance guidelineMaintenance3;
		private GuidelineMaintenance guidelineMaintenance4;
		private GuidelineMaintenance guidelineMaintenance5;
		private GuidelineMaintenance guidelineMaintenance6;

		private GuidelineCollection guidelineCollectionGCP;
		private GuidelineCategoryCollection categoryCollectionGCP;
		private GuidelineProductCollection productCollectionGCP;
		private GuidelineCollection guidelineCollectionPCG;
		private GuidelineCategoryCollection categoryCollectionPCG;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		private GuidelineProductCollection productCollectionPCG;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
				LoadData();
			else
			{
				guidelineMaintenance1 = this.LoadObject("GuidelineMaintenance1") as GuidelineMaintenance;
				guidelineMaintenance2 = this.LoadObject("GuidelineMaintenance2") as GuidelineMaintenance;
				guidelineMaintenance3 = this.LoadObject("GuidelineMaintenance3") as GuidelineMaintenance;
				guidelineMaintenance4 = this.LoadObject("GuidelineMaintenance4") as GuidelineMaintenance;
				guidelineMaintenance5 = this.LoadObject("GuidelineMaintenance5") as GuidelineMaintenance;
				guidelineMaintenance6 = this.LoadObject("GuidelineMaintenance6") as GuidelineMaintenance;
			}
		}

		private void LoadData()
		{
			NewGuidelineMaintenance1();
			NewGuidelineMaintenance2();
			NewGuidelineMaintenance3();
			NewGuidelineMaintenance4();
			NewGuidelineMaintenance5();
			NewGuidelineMaintenance6();
//			GuidelineSourceSetID.Rows.Add(new Infragistics.WebUI.UltraWebGrid.UltraGridRow(new object[]{ -1,"ALL"}));
//			WebCombo1.Rows.Add(new Infragistics.WebUI.UltraWebGrid.UltraGridRow(new object[]{ -1,"ALL"}));
//			WebCombo2.Rows.Add(new Infragistics.WebUI.UltraWebGrid.UltraGridRow(new object[]{ -1,"ALL"}));
//			WebCombo3.Rows.Add(new Infragistics.WebUI.UltraWebGrid.UltraGridRow(new object[]{ -1,"ALL"}));
//			WebCombo4.Rows.Add(new Infragistics.WebUI.UltraWebGrid.UltraGridRow(new object[]{ -1,"ALL"}));
//			WebCombo5.Rows.Add(new Infragistics.WebUI.UltraWebGrid.UltraGridRow(new object[]{ -1,"ALL"}));
			GuidelineCollection guidelineCol = new GuidelineCollection();
			guidelineCol.LoadAllGuidelines(-1);
			GuidelineCollectionGCP = guidelineCol;
			
			GuidelineCategoryCollection categoryCol = new GuidelineCategoryCollection();
			categoryCol.LoadAllGuidelineCategories(-1);
			CategoryCollectionGCP = categoryCol;
			
			GuidelineProductCollection productCol = new GuidelineProductCollection();
			productCol.LoadAllGuidelineProducts(-1);
			ProductCollectionGCP = productCol;

			GuidelineProductCollection productCol1 = new GuidelineProductCollection();
			productCol1.LoadAllGuidelineProducts(-1);
			ProductCollectionPCG = productCol1;

			GuidelineCategoryCollection categoryCol1 = new GuidelineCategoryCollection();
			categoryCol1.LoadAllGuidelineCategories(-1);
			CategoryCollectionPCG = categoryCol1;

			GuidelineCollection guidelineCol1 = new GuidelineCollection();
			guidelineCol1.LoadAllGuidelines(-1);
			GuidelineCollectionPCG = guidelineCol1;
			
			}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.GuidelineSourceSetID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.GuidelineSourceSetID_SelectedRowChanged);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grid_ColumnsBoundToDataClass);
			this.butAddNew.Click += new System.EventHandler(this.butAddNew_Click);
			this.WebCombo1.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo1_SelectedRowChanged);
			this.chkGuideline.CheckedChanged += new System.EventHandler(this.chkGuideline_CheckedChanged);
			this.Webgrid1.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.Webgrid1_ClickCellButton);
			this.Webgrid1.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.Webgrid1_ColumnsBoundToDataClass);
			this.btnAddNew1.Click += new System.EventHandler(this.btnAddNew1_Click);
			this.WebCombo2.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo2_SelectedRowChanged);
			this.chkGuideline1.CheckedChanged += new System.EventHandler(this.chkGuideline1_CheckedChanged);
			this.chkCategory.CheckedChanged += new System.EventHandler(this.chkCategory_CheckedChanged);
			this.Webgrid2.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.Webgrid2_ClickCellButton);
			this.btnAddNew2.Click += new System.EventHandler(this.btnAddNew2_Click);
			this.btnLink.Click += new System.EventHandler(this.btnLink_Click);
			this.WebCombo3.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo3_SelectedRowChanged);
			this.Webgrid3.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.Webgrid3_ClickCellButton);
			this.Webgrid3.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.Webgrid3_ColumnsBoundToDataClass);
			this.btnAddNew3.Click += new System.EventHandler(this.btnAddNew3_Click);
			this.WebCombo4.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo4_SelectedRowChanged);
			this.chkProduct.CheckedChanged += new System.EventHandler(this.chkProduct_CheckedChanged);
			this.Webgrid4.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.Webgrid4_ClickCellButton);
			this.Webgrid4.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.Webgrid4_ColumnsBoundToDataClass);
			this.btnAddNew4.Click += new System.EventHandler(this.btnAddNew4_Click);
			this.WebCombo5.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo5_SelectedRowChanged);
			this.chkProduct1.CheckedChanged += new System.EventHandler(this.chkProduct1_CheckedChanged);
			this.chkCategory1.CheckedChanged += new System.EventHandler(this.chkCategory1_CheckedChanged);
			this.Webgrid5.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.Webgrid5_ClickCellButton);
			this.btnAddNew5.Click += new System.EventHandler(this.btnAddNew5_Click);
			this.btnLink1.Click += new System.EventHandler(this.btnLink1_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		
		private void GuidelineSourceSetID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			GuidelineCollection col = new GuidelineCollection();
			try
			{
				this.UpdateToObject(this.pnlGuideline.Controls,guidelineMaintenance1);
				if(guidelineMaintenance1.GuidelineSourceSetID != 0)
				{
					col.LoadGuidelinesForSourceSet(-1,guidelineMaintenance1.GuidelineSourceSetID);
				}
				else
				{
					col.LoadAllGuidelines(-1);
				}
				this.GuidelineCollectionGCP = col;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		private void WebCombo1_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			UpdateCategoryCollectionGCP();
		}
		private void UpdateCategoryCollectionGCP()
		{
			GuidelineCategoryCollection col = new GuidelineCategoryCollection();
			try
			{
				this.UpdateToObject(this.pnlCategory.Controls,guidelineMaintenance2);
				if(guidelineMaintenance2.GuidelineSourceSetID != 0)
				{
					if(this.chkGuideline.Checked)
					{
						int guidelineID=this.grid.SelectedRowPKInt;
						if(guidelineID == 0)
						{
							this.SetPageMessage("@SELECTGUIDELINE@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadGuidelineCategoriesForGuidelineSS(-1,guidelineMaintenance2.GuidelineSourceSetID,guidelineID);
						}
					}
					else
					{
						col.LoadGuidelineCategoriesForSS(-1,guidelineMaintenance2.GuidelineSourceSetID);
					}
				}
				else
				{
					if(this.chkGuideline.Checked)
					{
						int guidelineID=this.grid.SelectedRowPKInt;
						if(guidelineID == 0)
						{
							this.SetPageMessage("@SELECTGUIDELINE@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadGuidelineCategoriesForGuideline(-1,guidelineID);
						}
					}
					else
					{
						col.LoadAllGuidelineCategories(-1);
					}
				}
				this.CategoryCollectionGCP= col;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
			
		}

		private void WebCombo2_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			UpdateProductCollectionGCP();
		}
		private void UpdateProductCollectionGCP()
		{
			GuidelineProductCollection col = new GuidelineProductCollection();
			try
			{
				this.UpdateToObject(this.pnlProduct.Controls,guidelineMaintenance3);
				if(guidelineMaintenance3 != null && guidelineMaintenance3.GuidelineSourceSetID != 0)
				{
					if(this.chkGuideline1.Checked && this.chkCategory.Checked)
					{
						int guidelineID=this.grid.SelectedRowPKInt;
						if(guidelineID == 0)
						{
							this.SetPageMessage("@SELECTGUIDELINE@",EnumPageMessageType.Error);
							return;
						}
						int categoryID = this.Webgrid1.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadGuidelineProductsForCatGuidelineSS(-1,guidelineMaintenance3.GuidelineSourceSetID,categoryID,guidelineID);
						}
					}
					else if(this.chkGuideline1.Checked)
					{
						int guidelineID=this.grid.SelectedRowPKInt;
						if(guidelineID == 0)
						{
							this.SetPageMessage("@SELECTGUIDELINE@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadGuidelineProductsForGuidelineSS(-1,guidelineMaintenance3.GuidelineSourceSetID,guidelineID);
					}
					else if(this.chkCategory.Checked)
					{
						int categoryID = this.Webgrid1.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadGuidelineProductForCategorySS(-1,guidelineMaintenance3.GuidelineSourceSetID,categoryID);
					}
					else
					{
						col.LoadGuidelineProductsForSourceSet(-1,guidelineMaintenance3.GuidelineSourceSetID);
					}
				}
				else
				{
					if(this.chkGuideline1.Checked && this.chkCategory.Checked)
					{
						int guidelineID=this.grid.SelectedRowPKInt;
						if(guidelineID == 0)
						{
							this.SetPageMessage("@SELECTGUIDELINE@",EnumPageMessageType.Error);
							return;
						}
						int categoryID = this.Webgrid1.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadGuidelineProductsForCategoryGuideline(-1,categoryID,guidelineID);
						}
					}
					else if(this.chkGuideline1.Checked)
					{
						int guidelineID=this.grid.SelectedRowPKInt;
						if(guidelineID == 0)
						{
							this.SetPageMessage("@SELECTGUIDELINE@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadGuidelineProductForGuideline(-1,guidelineID);
					}
					else if(this.chkCategory.Checked)
					{
						int categoryID = this.Webgrid1.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadGuidelineProductForCategory(-1,categoryID);
					}
					else
					{
						col.LoadAllGuidelineProducts(-1);
					}
				}
				this.ProductCollectionGCP= col;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
			
		}

		private void WebCombo3_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			GuidelineProductCollection col = new GuidelineProductCollection();
			try
			{
				this.UpdateToObject(this.pnlProduct1.Controls,guidelineMaintenance4);
				if(guidelineMaintenance4.GuidelineSourceSetID != 0)
				{
					col.LoadGuidelineProductsForSourceSet(-1,guidelineMaintenance4.GuidelineSourceSetID);
		
				}
				else
				{
					col.LoadAllGuidelineProducts(-1);
				}
				this.ProductCollectionPCG= col;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
			
		}


		private void WebCombo4_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			UpdateCategoryCollectionPCG();
		}
		private void UpdateCategoryCollectionPCG()
		{
			GuidelineCategoryCollection col = new GuidelineCategoryCollection();
			try
			{
				this.UpdateToObject(this.pnlCategory1.Controls,guidelineMaintenance5);
				if(guidelineMaintenance5.GuidelineSourceSetID != 0)
				{
					if(this.chkProduct.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadGuidelineCategoriesForProductSS(-1,guidelineMaintenance5.GuidelineSourceSetID,productID);
						}
					}
					else
					{
						col.LoadGuidelineCategoriesForSS(-1,guidelineMaintenance5.GuidelineSourceSetID);
					}
				}
				else
				{
					if(this.chkProduct.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadGuidelineCategoriesForProduct(-1,productID);
						}
					}
					else
					{
						col.LoadAllGuidelineCategories(-1);
					}
				}
				this.CategoryCollectionPCG= col;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
			
		}

		private void WebCombo5_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			UpdateGuidelineCollectionPCG();
		}
		private void UpdateGuidelineCollectionPCG()
		{
			GuidelineCollection col = new GuidelineCollection();
			try
			{
				this.UpdateToObject(this.pnlGuideline1.Controls,guidelineMaintenance6);
				if(guidelineMaintenance6.GuidelineSourceSetID != 0)
				{
					if(this.chkProduct1.Checked && this.chkCategory1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadLinkedGuidelinesForProductCategorySS(-1,guidelineMaintenance6.GuidelineSourceSetID,productID,categoryID);
						}
					}
					else if(this.chkProduct1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadGuidelinesForProductSourceSet(-1,productID,guidelineMaintenance6.GuidelineSourceSetID);
					}
					else if(this.chkCategory1.Checked)
					{
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadGuidelinesForCategorySourceSet(-1,categoryID,guidelineMaintenance6.GuidelineSourceSetID);
					}
					else
					{
						col.LoadGuidelinesForSourceSet(-1,guidelineMaintenance6.GuidelineSourceSetID);
					}
				}
				else
				{
					if(this.chkProduct1.Checked && this.chkCategory1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadLinkedGuidelinesForProductCategory(-1,productID,categoryID);
						}
					}
					else if(this.chkProduct1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadLinkedGuidelinesForProduct(-1,productID);
					}
					else if(this.chkCategory1.Checked)
					{
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadLinkedGuidelinesForCategory(-1,categoryID);
					}
					else
					{
						col.LoadAllGuidelines(-1);
					}
				}
				this.GuidelineCollectionPCG= col;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
			
		}

		private void chkProduct1_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateGuidelineCollectionPCG();
		}

		private void chkProduct_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateCategoryCollectionPCG();
		}

		private void chkCategory_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateProductCollectionGCP();
		}

		private void chkGuideline_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateCategoryCollectionGCP();
		}

		private void chkGuideline1_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateProductCollectionGCP();
		}

		private void chkCategory1_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateGuidelineCollectionPCG();
		}

		public void NewGuidelineMaintenance1()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance1 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		public void NewGuidelineMaintenance2()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance2 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		public void NewGuidelineMaintenance3()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance3 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		public void NewGuidelineMaintenance4()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance4 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		public void NewGuidelineMaintenance5()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance5 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		public void NewGuidelineMaintenance6()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance6 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void butAddNew_Click(object sender, System.EventArgs e)
		{
			Guideline guideline = new Guideline(true);
			guideline.Active= true;
			RedirectGuideline(guideline);
		}

		private void btnAddNew1_Click(object sender, System.EventArgs e)
		{
			GuidelineCategory category = new GuidelineCategory(true);
			category.Active = true;
			RedirectCategory(category);
		}

		private void btnAddNew2_Click(object sender, System.EventArgs e)
		{
			GuidelineProduct product = new GuidelineProduct(true);
			product.Active = true;
			RedirectProduct(product);
		}

		private void btnAddNew3_Click(object sender, System.EventArgs e)
		{
			GuidelineProduct product = new GuidelineProduct(true);
			product.Active = true;
			RedirectProduct(product);
			
		}

		private void btnAddNew4_Click(object sender, System.EventArgs e)
		{
			GuidelineCategory category = new GuidelineCategory(true);
			category.Active = true;
			RedirectCategory(category);
		}

		private void btnAddNew5_Click(object sender, System.EventArgs e)
		{
			Guideline guideline = new Guideline(true);
			guideline.Active = true;
			RedirectGuideline(guideline);
		}

		private void btnLink1_Click(object sender, System.EventArgs e)
		{
			if(CreateLink(Webgrid3,Webgrid4,Webgrid5))
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@GUIDELINEPRODUCTCATEGORYLINK@");
		}

		private void btnLink_Click(object sender, System.EventArgs e)
		{
			if(CreateLink(grid,Webgrid1,Webgrid2))
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@GUIDELINEPRODUCTCATEGORYLINK@");
		}

		private bool CreateLink(NetsoftUSA.InfragisticsWeb.WebGrid guidelineGrid, NetsoftUSA.InfragisticsWeb.WebGrid categoryGrid, NetsoftUSA.InfragisticsWeb.WebGrid productGrid)
		{
			try
			{
				if(guidelineGrid.SelectedRowPKInt == 0)
				{
					this.SetPageMessage("@SELECTGUIDELINE@",NetsoftUSA.WebForms.EnumPageMessageType.Error);
					return false;
				}
				int guidelineID = (int) guidelineGrid.SelectedRowPKInt;
				if(categoryGrid.SelectedRowPKInt == 0)
				{
					this.SetPageMessage("@SELECTGUIDELINE@",NetsoftUSA.WebForms.EnumPageMessageType.Error);
					return false;
				}
				int categoryID = (int) categoryGrid.SelectedRowPKInt;
				if(productGrid.SelectedRowPKInt == 0)
				{
					this.SetPageMessage("@SELECTPRODUCT@",NetsoftUSA.WebForms.EnumPageMessageType.Error);
					return false;
				}
				int productID = (int) productGrid.SelectedRowPKInt;
				GuidelineProductCategoryLink link = new GuidelineProductCategoryLink(true);
				link.Active = true;
				link.GuidelineID = guidelineID;
				link.GuidelineCategoryID = categoryID;
				link.GuidelineProductID = productID;
				link.Save();
					
			}
			catch(Exception ex)
			{
				RaisePageException(ex);
				return false;
			}
			return true;
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);
			listbar.AddItem("@GUIDELINESOURCESET@", "GuidelineSourceset");
		}

		public void OnSubNavigationItemClick_GuidelineSourceset(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("GuidelineSourceset.aspx");
		}

		public static void RedirectGuideline(Guideline guideline)
		{
			BasePage.PushParam("Guideline",guideline);
			BasePage.Redirect("GuidelineForm.aspx");
		}

		public static void RedirectCategory(GuidelineCategory category)
		{
			BasePage.PushParam("GuidelineCategory",category);
			BasePage.Redirect("GuidelineCategoryForm.aspx");
		}
		
		public static void RedirectProduct(GuidelineProduct product)
		{
			BasePage.PushParam("GuidelineProduct",product);
			BasePage.Redirect("GuidelineProductForm.aspx");
		}

		public static void RedirectGuideline(int id)
		{
			Guideline guideline = new Guideline();
			guideline.Load(id);
			RedirectGuideline(guideline);
		}
		
		public static void RedirectCategory(int id)
		{
			GuidelineCategory category = new GuidelineCategory();
			category.Load(id);
			RedirectCategory(category);
		}

		public static void RedirectProduct(int id)
		{
			GuidelineProduct product = new GuidelineProduct();
			product.Load(id);
			RedirectProduct(product);
		}

		

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = grid.GetPKFromCellEvent(e);
			if (e.Cell.Key == "Edit")
			{
				try
				{
					RedirectGuideline((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			else if(e.Cell.Key =="Select")
			{
				if(this.chkGuideline.Checked)
					this.UpdateCategoryCollectionGCP();
				if(this.chkGuideline1.Checked)
					this.UpdateProductCollectionGCP();
			}
		}

		private void Webgrid1_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = Webgrid1.GetPKFromCellEvent(e);
			if (e.Cell.Key == "Edit")
			{
				try
				{
					RedirectCategory((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			else if(e.Cell.Key =="Select")
			{
				if(this.chkCategory.Checked)
					this.UpdateProductCollectionGCP();
			}
		}

		

		
		private void Webgrid2_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = Webgrid2.GetPKFromCellEvent(e);
			if (e.Cell.Key == "Edit")
			{
				try
				{
					RedirectProduct((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void Webgrid3_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = Webgrid3.GetPKFromCellEvent(e);
			if (e.Cell.Key == "Edit")
			{
				try
				{
					RedirectProduct((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			else if(e.Cell.Key == "Select")
			{
				if(this.chkProduct.Checked)
					UpdateCategoryCollectionPCG();
				if(this.chkProduct1.Checked)
					UpdateGuidelineCollectionPCG();
			}
		}

		


		private void Webgrid4_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = Webgrid4.GetPKFromCellEvent(e);
			if (e.Cell.Key == "Edit")
			{
				try
				{
					RedirectCategory((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			else if(e.Cell.Key == "Select")
			{
				if(this.chkCategory1.Checked)
					UpdateGuidelineCollectionPCG();
				
			}
		}

		private void Webgrid5_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = Webgrid5.GetPKFromCellEvent(e);
			if (e.Cell.Key == "Edit")
			{
				try
				{
					RedirectGuideline((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

	

		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			grid.AddButtonColumn("Select","@SELECT@");
		}

		private void Webgrid1_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			Webgrid1.AddButtonColumn("Select","@SELECT@");
		}

		private void Webgrid3_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			Webgrid3.AddButtonColumn("Select","@SELECT@");
		}

		private void Webgrid4_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			Webgrid4.AddButtonColumn("Select","@SELECT@");
		}

		
	
		public ActiveAdvice.DataLayer.GuidelineCollection GuidelineCollectionGCP
		{
			get { return this.guidelineCollectionGCP; }
			set { this.guidelineCollectionGCP = value; 
				try
				{
					this.grid.UpdateFromCollection(guidelineCollectionGCP);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineCategoryCollection CategoryCollectionGCP
		{
			get { return this.categoryCollectionGCP; }
			set { this.categoryCollectionGCP = value; 
				try
				{
					this.Webgrid1.UpdateFromCollection(categoryCollectionGCP);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineProductCollection ProductCollectionGCP
		{
			get { return this.productCollectionGCP; }
			set { this.productCollectionGCP = value;
				try
				{
					this.Webgrid2.UpdateFromCollection(productCollectionGCP);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineCollection GuidelineCollectionPCG
		{
			get { return this.guidelineCollectionPCG; }
			set { this.guidelineCollectionPCG = value;
				try
				{
					this.Webgrid5.UpdateFromCollection(guidelineCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineCategoryCollection CategoryCollectionPCG
		{
			get { return this.categoryCollectionPCG; }
			set { this.categoryCollectionPCG = value;
				try
				{
					this.Webgrid4.UpdateFromCollection(categoryCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineProductCollection ProductCollectionPCG
		{
			get { return this.productCollectionPCG; }
			set { this.productCollectionPCG = value; 
				try
				{
					this.Webgrid3.UpdateFromCollection(productCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}


		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance1
		{
			set 
			{
				this.guidelineMaintenance1 = value; 
				try
				{
					this.UpdateFromObject(this.pnlGuideline.Controls,guidelineMaintenance1);
					this.CacheObject("GuidelineMaintenance1",guidelineMaintenance1);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance2
		{
			get { return this.guidelineMaintenance2; }
			set { this.guidelineMaintenance2 = value; 
				try
				{
					this.UpdateFromObject(this.pnlCategory.Controls,guidelineMaintenance2);
					this.CacheObject("GuidelineMaintenance2",guidelineMaintenance2);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				}
		}

		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance3
		{
			get { return this.guidelineMaintenance3; }
			set { this.guidelineMaintenance3 = value;
				try
				{
					this.UpdateFromObject(this.pnlProduct.Controls,guidelineMaintenance3);
					this.CacheObject("GuidelineMaintenance3",guidelineMaintenance3);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				}
		}

		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance4
		{
			get { return this.guidelineMaintenance4; }
			set { this.guidelineMaintenance4 = value;
				try
				{
					this.UpdateFromObject(this.pnlProduct1.Controls,guidelineMaintenance4);
					this.CacheObject("GuidelineMaintenance4",guidelineMaintenance4);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				}
		}

		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance5
		{
			get { return this.guidelineMaintenance5; }
			set { this.guidelineMaintenance5 = value; 
				try
				{
					this.UpdateFromObject(this.pnlCategory1.Controls,guidelineMaintenance5);
					this.CacheObject("GuidelineMaintenance5",guidelineMaintenance5);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance6
		{
			get { return this.guidelineMaintenance6; }
			set { this.guidelineMaintenance6 = value;
				try
				{
					this.UpdateFromObject(this.pnlGuideline1.Controls,guidelineMaintenance6);
					this.CacheObject("GuidelineMaintenance6",guidelineMaintenance6);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

	}
}
