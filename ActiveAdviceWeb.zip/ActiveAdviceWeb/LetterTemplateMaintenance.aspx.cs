using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterTemplateMaintenance.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.LETTER_SETUP)]
	
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterTemplate,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("LetterTemplate")]
	[PageTitle("@LETTERTEMPLATEPAGETITLE@")]
	public class LetterTemplateMaintenance : LetterMaintenanceBasePage
	{
		private LetterTemplate letterTemplate;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFormTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FormTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFormTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReceiverTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ReceiverTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReceiverTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLetterSetID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo LetterSetID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLetterSetID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMatrixTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MatrixTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMatrixTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldIntroLetterNumber;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit IntroLetterNumber;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIntroLetterNumber;
		protected NetsoftUSA.WebForms.OBCheckBox Duplex;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDuplex;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.WebForms.OBCheckBox Envelope;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEnvelope;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlTextControl;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected TextControl txTextControl;
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.MatrixTypeID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.MatrixTypeID_SelectedRowChanged);
			this.FormTypeID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.FormTypeID_SelectedRowChanged);
			this.IntroLetterNumber.ValueChange += new Infragistics.WebUI.WebDataInput.ValueChangeHandler(this.IntroLetterNumber_ValueChange);
			this.AutoScroll = true;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
			{
				this.LoadData();
			}
			else
				letterTemplate = (LetterTemplate)this.LoadObject(typeof(LetterTemplate));  // load object from cache

		}

		#region LetterTemplate
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterTemplate LetterTemplate
		{
			get { return letterTemplate; }
			set
			{
				letterTemplate = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, letterTemplate);  // update controls for the given control collection
					
					// Load the body
					txTextControl.IsMaintenanceMode = true;
					txTextControl.Text = letterTemplate.LetterTemplateBody.Body;
					txTextControl.MatrixTypeID = letterTemplate.MatrixTypeID;
					txTextControl.FormTypeID = letterTemplate.FormTypeID;
					txTextControl.IntroLetterNumber = letterTemplate.IntroLetterNumber;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterTemplate), letterTemplate);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, letterTemplate);	// controls-to-object

				// Save the body
				letterTemplate.LetterTemplateBody.Body = txTextControl.Text;
				
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewData()
		{
			bool result = true;
			LetterTemplate letterTemplate = null; //new LetterTemplate(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				letterTemplate = new LetterTemplate(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.LetterTemplate = letterTemplate;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			LetterTemplate letterTemplate = new LetterTemplate();
			try
			{	// use any load method here
				letterTemplate = GetParamOrGetFromCache("LetterTemplate", typeof(LetterTemplate)) as LetterTemplate;
				if (letterTemplate == null) 
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a LetterTemplate");
				//this.MatrixTypeID.SelectedRow = this.MatrixTypeID.Rows[0];
				//this.FormTypeID.SelectedRow = this.FormTypeID.Rows[0];
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterTemplate.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterTemplate = letterTemplate;
			ChangeUIState(false, true);
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(LetterTemplate letterTemplate)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("LetterTemplate", letterTemplate);
			BasePage.Redirect("LetterTemplateMaintenance.aspx");
		}

		public static void Redirect(int letterTemplateID)
		{
			LetterTemplate letterTemplate = new LetterTemplate();
			if (!letterTemplate.LoadLatestVersion(letterTemplateID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@LETTERTEMPLATE@");
			Redirect(letterTemplate);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				letterTemplate.Save(); // update or insert to db 
				txTextControl.IsDirty = false;
			}
			catch(SqlException sqlex)
			{
				SetPageMessage("This record already exists in the database.", EnumPageMessageType.Error);
				this.ScrollToTop();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				this.ScrollToTop();
				return false;
			}
			return true;
		}


		public override void OnSetDirty()
		{
			base.OnSetDirty();
			this.IsDirty = letterTemplate.IsDirty || txTextControl.IsDirty;
		}

		#endregion

		#region UI Initialization and Events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e); 

			ChangeUIState(false, true);

			this.RenderClientFunctions(this.pnlDetails.Controls, this.LetterTemplate, "TerminationDateValidator");
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.LetterTemplate);
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "LetterTemplate":
					toolbar.AddButton(Messages.BaseMessages.MessageIDs.ADDNEWRECORD, "AddNewLetterTemplate");
					//toolbar.AddButton("Test Envelope", "TestEnvelope");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewLetterTemplate(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewData();
		}

		public void OnToolbarButtonClick_TestEnvelope(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			Printer printer = new Printer();
			printer.PrinterShareName = "Laserjet 8100";
			printer.ServerName = "ns1dc002";

			printer.PrinterShareName = "HPLaserJ";
			printer.ServerName = "volkansavasan2";

			this.txTextControl.TxHelper.Print(printer, "test envelope", false, true);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "LetterTemplate "); 
				this.ScrollToTop();
			}
		}

		private void MatrixTypeID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			//ChangeUIState(false, true);
		}
		
		private void FormTypeID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			//ChangeUIState(false, true);
		}

		

		/// <summary>
		/// Alters visible GUI controls depending on selected MatrixType
		/// </summary>
		private void ChangeUIState(bool defaultUI, bool checkforChange)
		{
			bool matrixTypeChanged = false;
			bool formTypeChanged = false;
			bool updateMergeFields = false;

//			if (defaultUI)
//			{
//				this.MatrixTypeID.SelectedRow = this.MatrixTypeID.Rows[0];
//				this.FormTypeID.SelectedRow = this.FormTypeID.Rows[0];
//			}
 			
			if (checkforChange)
			{
				if (this.MatrixTypeID.Value == null || (int)this.MatrixTypeID.Value !=  letterTemplate.MatrixTypeID)
				{
					matrixTypeChanged = true; 
					if (this.txTextControl.HasMergeFields)
					{
						// Restore the old values
						this.UpdateFromObject(this.MatrixTypeID, letterTemplate);
						this.SetPageMessage("@CANNOTCHANGEMATRIXTYPEMFL@", EnumPageMessageType.Error); 
						this.ScrollToTop();
						return;
					}
					else if (this.txTextControl.HasComplexFields)
					{
						// Restore the old values
						this.UpdateFromObject(this.MatrixTypeID, letterTemplate);
						this.SetPageMessage("@CANNOTCHANGEMATRIXTYPECOMP@", EnumPageMessageType.Error); 
						this.ScrollToTop();
						return;
					}

					this.UpdateToObject(this.MatrixTypeID, letterTemplate);
					this.UpdateFromObject(this.FormTypeID, letterTemplate);

				}

				if (this.FormTypeID.Value == null || (int)this.FormTypeID.Value != letterTemplate.FormTypeID)
				{
					formTypeChanged = true; 

					if (this.txTextControl.HasMergeFields)
					{
						// Restore the old values
						this.UpdateFromObject(this.FormTypeID, letterTemplate);
						this.SetPageMessage("@CANNOTCHANGEFORMTYPEMFL@", EnumPageMessageType.Error); 
						this.ScrollToTop();
						return;
					}
					else if (this.txTextControl.HasComplexFields)
					{
						// Restore the old values
						this.UpdateFromObject(this.FormTypeID, letterTemplate);
						this.SetPageMessage("@CANNOTCHANGEFORMTYPECOMP@", EnumPageMessageType.Error); 
						this.ScrollToTop();
						return;
					}

					this.UpdateToObject(this.FormTypeID, letterTemplate);
				}

			}


			if (this.IntroLetterNumber.Value == null || (int)this.IntroLetterNumber.Value != letterTemplate.IntroLetterNumber)
			{
				this.UpdateToObject(this.IntroLetterNumber, letterTemplate);
				updateMergeFields = true;
			}

			
			if (matrixTypeChanged)
			{
				letterTemplate.ReceiverTypeID = 0;
				letterTemplate.LetterSetID = 0;
				letterTemplate.FormTypeID = 0;

				this.UpdateFromObject(this.ReceiverTypeID, letterTemplate);
				this.UpdateFromObject(this.LetterSetID, letterTemplate);
				this.UpdateFromObject(this.FormTypeID, letterTemplate);

				updateMergeFields = true;
			}
			else if (formTypeChanged)
			{
				this.UpdateFromObject(this.FormTypeID, letterTemplate);
				updateMergeFields = true;
			}


			if (letterTemplate.MatrixTypeID > 0)
			{
				// Matrix Type trigger
				string matrixType = MatrixTypeCollection.ActiveMatrixTypes.Lookup_CodeByMatrixTypeID(letterTemplate.MatrixTypeID);
				string formType = LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_CodeByFormTypeID(letterTemplate.FormTypeID);
				switch(matrixType)
				{
					case MatrixType.CASEMANAGEMENT:
					case MatrixType.DISEASEMANAGEMENT:
					case MatrixType.MATERNICHEK:
						if (formType == LetterFormType.FORM)
						{
							this.IntroLetterNumber.Visible = true; this.lbIntroLetterNumber.Visible = true; this.vldIntroLetterNumber.Visible = true;
						}
						else
						{
							this.IntroLetterNumber.Visible = false; this.lbIntroLetterNumber.Visible = false; this.vldIntroLetterNumber.Visible = false;
						}
						break;
					case MatrixType.EVENT_CLINICALREVIEW:
					case MatrixType.REFERRAL:
					default:
						letterTemplate.IntroLetterNumber = 0;
						this.UpdateFromObject(this.IntroLetterNumber, letterTemplate);
						this.IntroLetterNumber.Visible = false; this.lbIntroLetterNumber.Visible = false; this.vldIntroLetterNumber.Visible = false;
						break;
				}
			}
			else
			{
				letterTemplate.IntroLetterNumber = 0;
				this.UpdateFromObject(this.IntroLetterNumber, letterTemplate);
				this.IntroLetterNumber.Visible = false; this.lbIntroLetterNumber.Visible = false; this.vldIntroLetterNumber.Visible = false;
			}
			
			
			if (letterTemplate.FormTypeID > 0)
			{
				// LetterForm Type trigger
				string code = LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_CodeByFormTypeID(letterTemplate.FormTypeID);
				switch(code)
				{
					case LetterFormType.ENVELOPE:
						this.Duplex.Visible = false; this.lbDuplex.Visible = false; 
						this.Envelope.Visible = true; this.lbEnvelope.Visible = true;
						break;
					case LetterFormType.FORM:
					case LetterFormType.STANDARD:
					case LetterFormType.ASSESSMENT:
						this.Duplex.Visible = true; this.lbDuplex.Visible = true; 
						this.Envelope.Visible = false; this.lbEnvelope.Visible = false;
						break;
					default:
						letterTemplate.Duplex = false;
						letterTemplate.Envelope = false;
						this.UpdateFromObject(this.Duplex, letterTemplate);
						this.UpdateFromObject(this.Envelope, letterTemplate);
						this.Duplex.Visible = false; this.lbDuplex.Visible = false; 
						this.Envelope.Visible = false; this.lbEnvelope.Visible = false;
						break;
				}
			}
			else
			{
				letterTemplate.Duplex = false;
				letterTemplate.Envelope = false;
				this.UpdateFromObject(this.Duplex, letterTemplate);
				this.UpdateFromObject(this.Envelope, letterTemplate);
				this.Duplex.Visible = false; this.lbDuplex.Visible = false; 
				this.Envelope.Visible = false; this.lbEnvelope.Visible = false;
			}

			if (updateMergeFields)
			{
				this.txTextControl.MatrixTypeID = letterTemplate.MatrixTypeID;
				this.txTextControl.FormTypeID = letterTemplate.FormTypeID;
				this.txTextControl.IntroLetterNumber = letterTemplate.IntroLetterNumber;
			}

            this.CacheObject(typeof(LetterTemplate), letterTemplate);
		}
		#endregion

		private void IntroLetterNumber_ValueChange(object sender, Infragistics.WebUI.WebDataInput.ValueChangeEventArgs e)
		{
			//ChangeUIState(false, true);
		}
		
	}
}
