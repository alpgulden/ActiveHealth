using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Sub-Organization's linked plans are managed in this page
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.OrgMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("PlanSORG,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MOrganizations")]
	[SelectedMenuItem("Details")]
	public class OrganizationLinkedPlans : OrganizationBasePage
	{
		private MemberLive memberLive;
		private MemberLiveCollection memberLives;
		private PlanSORG planSORG;
		private Organization org;
		private PlanSORGCollection planSORGs;
		private PlanSearcher planSearcher;
		private PlanCollection plans;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGrid;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAltPlanName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AltPlanName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAltPlanName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAltPlanID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AltPlanID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAltPlanID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAltGroupID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AltGroupID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAltGroupID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PlanName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.WebForms.OBCheckBox CheckEligibility;
		protected NetsoftUSA.WebForms.OBCheckBox EligibilityAddAnyway;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPayorGroupID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PayorGroupID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPayorGroupID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLOSYear;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LOSYear;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLOSYear;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDRGType;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DRGType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDRGType;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGuidelineSourceSet;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GuidelineSourceSet;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGuidelineSourceSet;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLOSRegion;
		protected NetsoftUSA.InfragisticsWeb.WebCombo LOSRegion;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLOSRegion;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLinkedPlanDetails1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDRGVersion;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit DRGVersion;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDRGVersion;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected System.Web.UI.WebControls.CheckBox chkEffectiveOnly;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHEDISTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo HEDISTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHEDISTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PlanTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContractEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ContractEffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContractEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternatePlanId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternatePlanId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternatePlanId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridPlans;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLinkedPlanDetails2;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit SearchEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel SorgPlanLivesGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSorgPlanLives;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTotalMembers;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit TotalMembers;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTotalMembers;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDependentsRatio;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit DependentsRatio;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDependentsRatio;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNumberOfInsured;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NumberOfInsured;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNumberOfInsured;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberLivesSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MemberLivesSourceID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberLivesSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSaveMemberLivesItem;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSorgPlanLivesDetails;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDeleteMemberLivesItem;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCancelMemberLivesItem;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBLabel orgPlanSelectMsg;
		Infragistics.WebUI.UltraWebToolbar.TBarButton CancelButton;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				org = (Organization)this.LoadObject(typeof(Organization));  // load object from cache
				planSORGs = org.PlanSORGs;
				planSORG = (PlanSORG)this.LoadObject(typeof(PlanSORG), false);  // load object from cache
				planSearcher = (PlanSearcher)this.LoadObject("PlanSearcher");
				memberLives = (MemberLiveCollection)this.LoadObject(typeof(MemberLiveCollection));  // load object from cache
				memberLive = (MemberLive)this.LoadObject(typeof(MemberLive));  // load object from cache
			}
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject(typeof(PlanSORG), null);
			this.CacheObject(typeof(MemberLiveCollection), null);
			this.CacheObject(typeof(MemberLive), null);
			this.org.PlanSORGs = null;
			base.NavigateAway ();
		}


		/*private void butSaveServiceItem_Click(object sender, System.EventArgs e)
		{
			SaveDataForPlanSORG();
		}*/

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			this.grid.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.grid_DblClick);
			this.grid.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.grid_RowBoundToDataObject);
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grid_ColumnsBoundToDataClass);
			this.grid.ClickCellButton +=new ClickCellButtonEventHandler(grid_ClickCellButton);
			this.gridPlans.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridPlans_ClickCellButton);
			this.gridPlans.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridPlans_ColumnsBoundToDataClass);
			this.gridSorgPlanLives.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridSorgPlanLives_ClickCellButton);
			this.wbtnSaveMemberLivesItem.Click += new System.EventHandler(this.wbtnSaveMemberLivesItem_Click);
			this.wbtnDeleteMemberLivesItem.Click += new System.EventHandler(this.wbtnDeleteMemberLivesItem_Click);
			this.wbtnCancelMemberLivesItem.Click += new System.EventHandler(this.wbtnCancelMemberLivesItem_Click);
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			Organization org = null;
			try
			{	// use any load method here
				if (this.HasCallbackFunction)
				{
					// if popup then check the given org
					string orgid = Request.QueryString["OrganizationID"];
					if (orgid == null || orgid == "")
						throw new Exception("No Organization ID was passed!");
					int id = Convert.ToInt32(orgid);
					org = new Organization();
					if (!org.Load(id))
						throw new Exception("Organization not found!");
					org.LoadPlanSORGs(true);
					this.Organization = org;

					this.PageTitle = this.Language.Translate("@SELECTPLANFOR@", this.org.OrganizationID + "-" + this.org.Name);
					this.orgPlanSelectMsg.Visible = true;

					return true;
				}

				org = GetParamOrGetFromCache("Organization", typeof(Organization) ) as Organization;
				if (org == null || !org.IsSubOrganization)
				{
					RaisePageException(new Exception("You must come to this page from an sub-organization's context"));
					return false;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//org.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Organization = org;		// When you set the object to the property, controls are automatically populated
			return result;
		}

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Details")
			{
				if (!this.IsPopup)
					toolbar.AddButton("@LINKPLAN@", "LinkPlan");
			}
			else if(tab.Key == "SorgPlanLives")
			{
				if (!this.IsPopup)
					toolbar.AddButton("@ADDNEWRECORD@", "AddNewMemberLive", false, true);
			}

			// Menu items to be displayed on all tabs
		}

		public void OnToolbarButtonClick_LinkPlan(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PlanSORG = null;	// remove the currently edited
			this.NewPlanSearcher();
		}

		public void OnToolbarButtonClick_AddNewMemberLive(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMemberLive();
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			toolbar.AddButton("@SAVERECORD@", "Save");
			CancelButton = toolbar.AddButton("@CANCEL@", "Cancel").Item;

			if (this.IsPopup)
			{
				CancelButton.Text = this.BaseMessages.CLOSE;
				CancelButton.TargetURL = "javascript:window.close();";
			}
		}

		public new void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (pnlSearch.Visible)	// if search mode
				this.PlanSORG = null;
			else if (pnlLinkedPlanDetails1.Visible)	// if edit mode
				this.PlanSORG = null;
			else	// otherwise
				OrganizationForm.Redirect(this.org);		// continue editing parent
		}

		public new void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForPlanSORG())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "@LINKEDPLAN@");
				org.LoadPlanSORGs(true);
				this.PlanSORGs = org.PlanSORGs;
				this.PlanSORG = null;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PlanSORGCollection PlanSORGs
		{
			get { return planSORGs; }
			set
			{
				planSORGs = value;
				try
				{
					//grid.KeepCollectionIndices = false;  // update given grid from the collection
					grid.UpdateFromCollection(planSORGs);  // update given grid from the collection
					// other object-to-control methods if any

					this.PlanSORG = null;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(PlanSORGCollection), planSORGs);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Organization Organization
		{
			get { return org; }
			set
			{
				org = value;
				try
				{
					if (org != null)
					{
						this.org.LoadPlanSORGs(false);
						this.PlanSORGs = org.PlanSORGs; 
					}
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Organization), org);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Organization org)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Organization", org);
			BasePage.Redirect("OrganizationLinkedPlans.aspx");

		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PlanSORG PlanSORG
		{
			get { return planSORG; }
			set
			{
				planSORG = value;
				try
				{
					pnlGrid.Visible = planSORG == null;
					pnlLinkedPlanDetails1.Visible = !pnlGrid.Visible;
					pnlLinkedPlanDetails2.Visible = !pnlGrid.Visible;
					pnlSearch.Visible = false;
					pnlResult.Visible = false;

					if (this.planSORG == null)
						this.PageType = EnumPageType.SearchPage;
					else
						this.PageType = EnumPageType.DataEntryPage;

					//pnlLinkedPlanDetails3.Visible = !pnlGrid.Visible;

					this.UpdateFromObject(pnlLinkedPlanDetails1.Controls, planSORG);  // update controls for the given control collection
					this.UpdateFromObject(pnlLinkedPlanDetails2.Controls, planSORG);  // update controls for the given control collection
					//this.UpdateFromObject(pnlLinkedPlanDetails3.Controls, planSORG);  // update controls for the given control collection
					// other object-to-control methods if any

					LoadDataForMemberLives();
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PlanSORG), planSORG);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPlanSORG()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlLinkedPlanDetails1.Controls, planSORG);	// controls-to-object
				this.UpdateToObject(pnlLinkedPlanDetails2.Controls, planSORG);	// controls-to-object
				//this.UpdateToObject(pnlLinkedPlanDetails3.Controls, planSORG);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPlanSORG(int planId)
		{
			bool result = true;
			PlanSORG planSORG = null;
			try
			{	// or use an initialization method here
				planSORG = new PlanSORG(this.org, planId); // use a parameterized constructor which also initializes the data object
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PlanSORG = planSORG;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPlanSORG()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPlanSORG())
					return false;
				
				// first commit changes to plansorg if it's being edited
				if (this.memberLive != null)
					if (SaveDataForMemberLive())
					{
						MemberLives = MemberLives;	// refresh 
						this.MemberLive = null;		// exit edit mode
					}
					else
						return false;

				// we must save directly, because the memberlives must also be saved
				this.planSORG.Save();
				if (!SaveDataForMemberLives())
					return false;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void grid_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			int index = grid.GetColIndexFromClickEvent(e);
			if (index < 0)
				return;
			this.PlanSORG = planSORGs[index];
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.RenderClientFunctions(pnlLinkedPlanDetails1.Controls, planSORG, "OnCalculatePlanSORG");

			//this.SetPageToolbarItemEnabled("Save", this.);
			
			/*if (this.IsPopup)
			{
				CancelButton.Text = this.BaseMessages.CLOSE;
				CancelButton.TargetURL = "javascript:window.close();";
			}*/
			bool editMode = !this.gridPlans.Visible && PlanSORG != null;
			SetPageToolbarItemVisible("Save", editMode);
			SetPageTabItemVisible("SorgPlanLives", editMode);

			//this.RenderClientFunctions(this.pnlSorgPlanLivesDetails.Controls, this.memberLive, "SetTotalMembers");
			//this.SetPageToolbarItemEnabled("Save", !this.pnlSorgPlanLivesDetails.Visible);
			
			
		}

		private void gridPlans_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridPlans.AddButtonColumn("LinkPlan", "@LINKPLAN@");
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PlanSearcher PlanSearcher
		{
			get { return planSearcher; }
			set
			{
				planSearcher = value;
				try
				{
					PlanSORG = null;
					pnlSearch.Visible = planSearcher != null;
					pnlResult.Visible = pnlSearch.Visible;
					pnlGrid.Visible = !pnlSearch.Visible;
					this.UpdateFromObject(this.pnlSearch.Controls, planSearcher);  // update controls for the given control collection
					if (planSearcher != null)
						chkEffectiveOnly.Checked = planSearcher.EffectiveOnly;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("PlanSearcher", planSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPlan()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSearch.Controls, planSearcher);	// controls-to-object
				// other control-to-object methods if any
				if (planSearcher != null)
					planSearcher.EffectiveOnly = chkEffectiveOnly.Checked;
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPlanSearcher()
		{
			bool result = true;
			PlanSearcher plan = new PlanSearcher(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				plan.SetMembersNull(true, true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PlanSearcher = plan;
			return result;
		}

		public bool SearchPlans()
		{
			PlanCollection plans = new PlanCollection();
			try
			{	// data from controls to object
				if (!this.ReadControlsForPlan())
					return false;
				plans.SearchPlans(-1, planSearcher);
				this.Plans = plans;
				//PageTab.SelectedTab = 1;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PlanCollection Plans
		{
			get { return plans; }
			set
			{
				plans = value;
				try
				{
					gridPlans.KeepCollectionIndices = false;
					gridPlans.UpdateFromCollection(plans);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject(typeof(PlanCollection), plans);  // cache object using the caching method declared on the page
			}
		}

		private void gridPlans_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell != null && e.Cell.Key == "LinkPlan")
			{
				object[] pk = gridPlans.GetPKFromCellEvent(e);
				try
				{
					NewPlanSORG((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			SearchPlans();
		}

		/*private void butCancelServiceItem_Click(object sender, System.EventArgs e)
		{
			PlanSORG = null;
		}*/

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.org, this.planSORG);
		}

		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction)
			{
				grid.AddColumnWithButtonLook("Detail", "@DETAIL@", 0);
				grid.AddColumnWithButtonLook("Pick", "@PICK@", 0);
			}
			else
			{
				grid.AddButtonColumn("Edit", "@EDIT@", 0).Width = 60;
			}
		}

		private void grid_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			PlanSORG planSORG = e.data as PlanSORG;
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			if (cell != null)
				cell.Text = GetCallbackFunctionHyperLink("@PICK@", planSORG.PlanId, planSORG.PlanName);

			cell = e.row.Cells.FromKey("Detail");
			if (cell != null)
				cell.Text = String.Format("<a href='#' onclick='return OpenPlan({0});'>{1}</a>", planSORG.PlanId, "Detail");
		}

		/* Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMORGSearch();
		}
		*/

		private void grid_ClickCellButton(object sender, CellEventArgs e)
		{
			switch (e.Cell.Key)
			{
				case "Edit":
				{
					int index = grid.GetColIndexFromCellEvent(e);
					if (index < 0)
						return;
					this.PlanSORG = planSORGs[index];
					
					break;
				}
			}
		}
	
		public override void OnSetDirty()
		{
			base.OnSetDirty ();

			this.CheckForDirty(this.planSORGs, this.MemberLives);
		}

		#region MemberLives
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MemberLiveCollection MemberLives
		{
			get { return memberLives; }
			set
			{
				memberLives = value;
				try
				{
					gridSorgPlanLives.UpdateFromCollection(memberLives);  // update given grid from the collection
					this.MemberLive = null;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(MemberLiveCollection), memberLives);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForMemberLives()
		{
			bool result = true;
			MemberLiveCollection memberLives = new MemberLiveCollection();
			try
			{	// use any load method here
				if(this.PlanSORG != null)
				{
					memberLives.SearchBySorgPlan(-1, PlanSORG.SORGID, PlanSORG.PlanId);
					//this.pnlSorgPlanLivesDetails.Visible = false;
				}
				else
					memberLives = null;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//memberLives.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.MemberLives = memberLives;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForMemberLives()
		{
			try
			{	// data from controls to object
				if (memberLives == null)
					return true;
				bool wasChanged = this.memberLives.IsChanged;
				memberLives.Save(); // update or insert to db 
				gridSorgPlanLives.UpdatePKsFromCollection(memberLives);

				if (wasChanged)
					this.SetPageMessage("@MEMBERLIVESSAVED@", EnumPageMessageType.AddInfo);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			MemberLives = MemberLives;
			return true;
		}
		#endregion

		#region MemberLive
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MemberLive MemberLive
		{
			get { return memberLive; }
			set
			{
				memberLive = value;
				try
				{
					this.pnlSorgPlanLivesDetails.Visible = memberLive != null;
					this.UpdateFromObject(this.pnlSorgPlanLivesDetails.Controls, memberLive);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(MemberLive), memberLive);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForMemberLive()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSorgPlanLivesDetails.Controls, memberLive);	// controls-to-object
				// other control-to-object methods if any
				if(!this.memberLives.IsEffectiveDateExist(memberLive))
				{
					return this.IsValid;	// Return validation result
				}
				else
				{
					this.SetPageMessage("Record for this Month already exists. No changes made.", EnumPageMessageType.AddWarning);
					return false;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewMemberLive()
		{
			bool result = true;
			MemberLive memberLive = null; //new MemberLive(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				memberLive = new MemberLive(true);
				memberLive.EffectiveDate = DateTime.Now;
				this.wbtnDeleteMemberLivesItem.Visible = false;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.MemberLive = memberLive;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForMemberLive()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForMemberLive())
					return false;
				this.memberLive.TotalMembers = (int)Math.Ceiling(this.memberLive.NumberOfInsured * this.memberLive.DependentsRatio);
				this.memberLive.MarkDirty();
				if(memberLive.ParentMemberLiveCollection == null)
				{
					memberLive.OrganizationId = this.PlanSORG.SORGID;
					memberLive.PlanID = this.PlanSORG.PlanId;
					MemberLives.Add(memberLive);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		private void wbtnSaveMemberLivesItem_Click(object sender, System.EventArgs e)
		{
			SaveDataForMemberLive();
			MemberLives = MemberLives;
			this.MemberLive = null;
		}

		private void wbtnDeleteMemberLivesItem_Click(object sender, System.EventArgs e)
		{
			int index = this.gridSorgPlanLives.SelectedRowIndex;
			if(index < 0)
				return;
			MemberLives[index].MarkDel();
			MemberLives = MemberLives;
			this.pnlSorgPlanLivesDetails.Visible = false;
		}

		private void wbtnCancelMemberLivesItem_Click(object sender, System.EventArgs e)
		{
			this.MemberLive = null;
		}

		private void gridSorgPlanLives_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			this.gridSorgPlanLives.SelectedRowIndex = index;
			switch (e.Cell.Key)
			{
				case "Edit":
				{
					MemberLive = MemberLives[index];
					this.wbtnDeleteMemberLivesItem.Visible = true;
					break;
				}
			}
		
		}
	}
}
