using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using Infragistics.WebUI.UltraWebToolbar;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// The Intake Log module is the typical initial entry point for Patient information into the ActiveAdvice system. 
	/// All incoming calls or requests are handled by the Intake staff and are entered into the Intake Log. 
	/// Every entry into the Intake log must have a resolution, a resolution being an Event, Note or Activity.
	/// </summary>
	/// 

	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.INTAKE)]

	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("IntakeLog,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(IntakeLogSearch))]
	[SelectedMainMenuItem("MIntake")]
	[PageTitle("@INTAKELOGPAGETITLE@")]
	public class IntakeForm : BasePage
	{
		private IntakeLog intakeLog;
		private bool forDisplay = false;

		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCallerInfo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldIntakeCallSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo IntakeCallSourceID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIntakeCallSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCallerPhone;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCallerPhone;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCallerFName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CallerFName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCallerFName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldIntakeCallReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo IntakeCallReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIntakeCallReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCallerOrganization;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CallerOrganization;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCallerOrganization;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCallerLName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CallerLName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCallerLName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPatSubsInfo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientFName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PatientFName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientFName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientLName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PatientLName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientLName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientSSN;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit PatientSSN;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientSSN;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSubscriberFname;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSubscriberLName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit SubscriberLName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSubscriberLName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSubscriberSSN;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit SubscriberSSN;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSubscriberSSN;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldServiceDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ServiceDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbServiceDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientMemberID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PatientMemberID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientMemberID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit SORGId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSORGId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtSorgPath;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForSORG;
		protected System.Web.UI.WebControls.Literal sorgPath;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSORGID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPlanInfo;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit CallerPhoneExt;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchPatSubs;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSubscriberFName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit SubscriberFName;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlERCs;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridERCs;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected TBarButton tbbCancel;
		protected NetsoftUSA.WebForms.OBTextBox Notepad;
		protected NetsoftUSA.WebForms.OBTextBox txtNewNote;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNotes;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddNote;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProblemID;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit CallerPhone;
		protected NetsoftUSA.InfragisticsWeb.WebButton butClearPatient;
		protected NetsoftUSA.InfragisticsWeb.WebButton butClearSubscriber;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebButton butClearPlan;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnEditPatient;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnEditSubscriber;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIntakeResolutionID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldIntakeResolutionID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo IntakeResolutionID;
		protected NetsoftUSA.WebForms.OBLabel lblNotePadText;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIntakeLogID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit IntakeLogID;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDateOfBirth;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DateOfBirth;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateOfBirth;
		protected NetsoftUSA.WebForms.OBCheckBox Eligible;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSearchBy;
		protected NetsoftUSA.WebForms.OBRadioButtonBox SearchByInt;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddPatient;
		protected System.Web.UI.WebControls.Image butClearSORG;
		protected NetsoftUSA.InfragisticsWeb.WebButton butClearCaller;
		protected NetsoftUSA.InfragisticsWeb.WebButton butViewLog;
		protected NetsoftUSA.InfragisticsWeb.WebButton butNewIntake;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBLabel lbPlanEligibility;
		protected PlanSelect PlanSelect;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			//PlanSelect.RebindControls(typeof(IntakeLog), "PlanID", "PlanName", "MORGId", "ORGId", "SORGId");
			PlanSelect.RebindControls(typeof(IntakeLog), "PlanID", "PlanName", this.SORGId);
			PlanSelect.AfterPlanIDSetScript = "afterPlanIDSet";
			PlanSelect.OpenPlanComponents = true;

			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				intakeLog = (IntakeLog)this.LoadObject(typeof(IntakeLog));  // load object from cache
				
				// check if the plan and sorg was set and find/cache the add anyway flag.

				int planID = intakeLog.PlanID;
				int sorgID = intakeLog.SORGId;
				if (this.ReadControlForPlanInfo())
				{
					if (planID != intakeLog.PlanID || sorgID != intakeLog.SORGId)
					{
						CacheEligibilityAddAnyway(intakeLog.PlanID, intakeLog.SORGId);	// find/cache the new flag
						intakeLog.DoCoverageCheck();
						Eligible.Checked = intakeLog.Eligible;
					}
				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.butClearCaller.Click += new System.EventHandler(this.butClearCaller_Click);
			this.butClearPatient.Click += new System.EventHandler(this.butClearPatient_Click);
			this.butClearSubscriber.Click += new System.EventHandler(this.butClearSubscriber_Click);
			this.butSearchPatSubs.Click += new System.EventHandler(this.butSearchPatSubs_Click);
			this.butClearPlan.Click += new System.EventHandler(this.butClearPlan_Click);
			this.butAddNote.Click += new System.EventHandler(this.butAddNote_Click);
			this.wbtnEditPatient.Click += new System.EventHandler(this.wbtnEditPatient_Click);
			this.wbtnEditSubscriber.Click += new System.EventHandler(this.wbtnEditSubscriber_Click);
			this.butViewLog.Click += new System.EventHandler(this.butViewLog_Click);
			this.butNewIntake.Click += new System.EventHandler(this.butNewIntake_Click);
			this.butAddPatient.Click += new EventHandler(butAddPatient_Click);
			gridERCs.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridERCs_ColumnsBoundToDataClass);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			switch (tab.Key)
			{
				case "CallerInfo":
					//toolbar.AddButton(PatientMessages.MessageIDs.NEWINTAKE, "NewIntake", false, true);
					//toolbar.AddButton(PatientMessages.MessageIDs.VIEWLOG, "ViewLog", false, true);
					break;
				case "PatientInfo":
					//toolbar.AddButton(PatientMessages.MessageIDs.CLEARALL, "ClearAll", false, true);
					//if(EligibilityAddAnyway)	
					//{	// always add but change visibility
					//toolbar.AddButton(PatientMessages.MessageIDs.ADDPATIENT, "AddPatient", false, false);
					//}
					break;
				case "Details":
					break;
				default:
					break;
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}
			

			// Menu items to be displayed on all tabs
		}

		public void OnToolbarButtonClick_ClearAll(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			ClearAll();
		}

		/*public void OnToolbarButtonClick_ViewLog(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			IntakeLogSearch.Redirect();
		}

		public void OnToolbarButtonClick_NewIntake(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewIntake();
		}*/

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save");
			//tbbCancel = toolbar.AddButton("@CANCEL@", "Cancel").Item;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public IntakeLog IntakeLog
		{
			get { return intakeLog; }
			set
			{
				intakeLog = value;
				try
				{
					intakeLog.DoCoverageCheck();

					this.RequiredValidationsEnabled = intakeLog.ValidateForSave();

					this.UpdateFromObject(pnlCallerInfo.Controls, intakeLog);
					this.UpdateFromObject(pnlPatSubsInfo.Controls, intakeLog);
					//this.UpdateFromObject(pnlMemberSearch.Controls, intakeLog);
					this.UpdateFromObject(pnlPlanInfo.Controls, intakeLog);
					this.UpdateFromObject(pnlNotes.Controls, intakeLog);
					// other object-to-control methods if any

					LoadPatientERC();

					txtSorgPath.Text = this.CreateOrgPathHTML(null, this.intakeLog.SORG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(IntakeLog), intakeLog);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{
				//customize this method for this specific page
				this.UpdateToObject(pnlCallerInfo.Controls, intakeLog, false);
				this.UpdateToObject(pnlPatSubsInfo.Controls, intakeLog, false);
				//this.UpdateToObject(pnlMemberSearch.Controls, intakeLog, false);
				this.UpdateToObject(pnlPlanInfo.Controls, intakeLog, false);
				this.UpdateToObject(pnlNotes.Controls, intakeLog, false);

				// other control-to-object methods if any
				return !this.PageError;
				//return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlForPlanInfo()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlPlanInfo.Controls, intakeLog, false);
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewIntake()
		{
			bool result = true;
			IntakeLog intakeLog = null; // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				intakeLog = new IntakeLog(true);
				this.ClearEligibilityAddAnyway();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.IntakeLog = intakeLog;
			this.forDisplay = false;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			IntakeLog intakeLog = null;
			try
			{	
				forDisplay = this.GetParamBool("ForDisplay", false);

				PageTab.SelectedTabKey = this.TargetTabKey;		// navigate to target tab.
				this.SetPageMessageFromParam();					// display the message sent by the calling page.

				// if an intake log object was passed, use it.
				intakeLog = this.GetParamOrGetFromCache("IntakeLog", typeof(IntakeLog)) as IntakeLog;
				if (intakeLog == null)
					return NewIntake();

				// the coverage selection context is passed when the page is back from SelectAvailableCoverages.
				CoverageSelectionContext coverageSelectionContext = this.GetParam("CoverageSelectionContext") as CoverageSelectionContext;
				if (coverageSelectionContext != null)
				{
					this.DumpCoverageSelectionContext(coverageSelectionContext);
					intakeLog.Import(coverageSelectionContext);
					base.CacheEligibilityAddAnyway(intakeLog.PlanID, intakeLog.SORGId);
				}

				if (intakeLog != null)
				{
					this.DumpAutoActivity(intakeLog.Patient, true);
				}

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//intakeLog.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.IntakeLog = intakeLog;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(IntakeLog intakeLog, bool gotoPatientInfoTab)
		{
			if (intakeLog != null && gotoPatientInfoTab)
				PushTargetTab("PatientInfo");
			BasePage.PushParam("IntakeLog", intakeLog);
			BasePage.Redirect("IntakeForm.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(CoverageSelectionContext coverageSelectionContext, bool gotoPatientInfoTab)
		{
			BasePage.PushParam("CoverageSelectionContext", coverageSelectionContext);
			Redirect(coverageSelectionContext.IntakeLog, gotoPatientInfoTab);
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(IntakeLog intakeLog)
		{
			Redirect(intakeLog, true);
		}

		/// <summary>
		/// Load the given intake log and redirect to intake form.
		/// </summary>
		public static void Redirect(int intakeLogID, bool gotoPatientInfoTab)
		{
			IntakeLog intakeLog = new IntakeLog();
			if (!intakeLog.Load(intakeLogID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@INTAKELOG@");
			Redirect(intakeLog, gotoPatientInfoTab);
		}

		public static void Redirect()
		{
			BasePage.PushCurrentCallingPage();
			BasePage.Redirect("IntakeForm.aspx");
		}

		public static void RedirectForDisplay(int intakeLogID, bool gotoPatientInfoTab)
		{
			BasePage.PushParam("ForDisplay", true);
			Redirect(intakeLogID, false);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData(bool readControls)
		{
			try
			{	// data from controls to object
				if (readControls)
				{
					 AddNoteIfEntered();
					if (!this.ReadControls())
						return false;
				}

				if (this.intakeLog.Patient != null)
				{
					// If a patient is selected, the coverage must be selected too.
					/*this.SetPageMessage("@NOPATIENTSELECTED@", EnumPageMessageType.Error);
					return false;
					}*/
					if (this.intakeLog.Subscriber == null)
					{
						this.SetPageMessage("@NOSUBSCRIBERSELECTED@", EnumPageMessageType.Error);
						return false;
					}
					if (this.intakeLog.SORG == null)
					{
						this.SetPageMessage("@NOSORGSELECTED@", EnumPageMessageType.Error);
						return false;
					}
					if (this.intakeLog.Plan == null)
					{
						this.SetPageMessage("@NOPLANSELECTED@", EnumPageMessageType.Error);
						return false;
					}
				}
				if (this.intakeLog.ServiceDate == DateTime.MinValue)
				{
					this.SetPageMessage("@NOSERVICEDATE@", EnumPageMessageType.Error);
					return false;
				}

				if (this.intakeLog.IntakeResolutionCode == IntakeResolution.OTNA)	// if no action, require note
				{
					if (this.intakeLog.Notepad == null || this.intakeLog.Notepad == "")
					{
						this.SetPageMessage("@NOTEREQUIRED@", EnumPageMessageType.Error);
						return false;
					}
				}


				intakeLog.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/* Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMORGSearch();
		}
		*/

		protected override void OnPreRender(EventArgs e)
		{
			if (!this.IsPostBack)
			{
				this.RegisterOnLoadScript("setfocus", "setFocusForTab('CallerInfo');");
			}

			base.OnPreRender (e);
			sorgPath.Text = "<span id='sorgPath'>" + txtSorgPath.Text + "</span>";
			this.butClearSORG.Attributes["OnClick"] = "setSORGID(null)";

			this.SetPageToolbarItemEnabled("Save", !this.forDisplay);// intakeLog.ValidateForSave());

			bool eligibilityAddAnyway = this.EligibilityAddAnyway;
			bool checkEligibility = this.CheckEligibility;

			butAddPatient.Enabled = 
				this.intakeLog.PatientSearched 
				&& (!checkEligibility || checkEligibility && this.intakeLog.EligibilitySearched)
				&& this.intakeLog.Patient == null;
			butAddPatient.Visible = 
				this.intakeLog.IsNew && !this.forDisplay && this.EligibilityAddAnyway;

			this.SetPageTabToolbarItemVisible("ClearAll", !this.forDisplay);

			this.butClearCaller.Enabled = !this.forDisplay;
			this.butClearPatient.Enabled = !this.forDisplay;
			this.butClearPlan.Enabled = !this.forDisplay;
			this.butClearSubscriber.Enabled = !this.forDisplay;
			this.butAddNote.Enabled = !this.forDisplay;
			//this.butSearchEligibility.Enabled = !this.forDisplay;
			SearchByInt.Enabled = !this.forDisplay;
			this.butSearchPatSubs.Enabled = !this.forDisplay;

			//bool isValidForSave = intakeLog.ValidateForSave();
			//this.RequiredValidationsEnabled = isValidForSave;
			//vldServiceDate.Visible = isValidForSave;		// validate service date only when saving is made available.

			SetPatientSubscriberButtons();

			WindowOpenerForSORG.NavigateURL = "OrganizationSearch.aspx?CallBackFunction=setSORGID&Level=-1&PickLevel=-1";
			if (SORGId.ValueInt == 0 && PlanSelect.PlanID != 0)
				WindowOpenerForSORG.NavigateURL += "&PlanID=" + PlanSelect.PlanID.ToString();

			if (SORGId.ValueInt == 0 || PlanSelect.PlanID == 0)
				lbPlanEligibility.TextToTranslate = "";
			else
				lbPlanEligibility.TextToTranslate = eligibilityAddAnyway ? "@NOTREQUIRED@" : "@REQUIRED@";
		}

		private void butSearchPatSubs_Click(object sender, System.EventArgs e)
		{
			if (ReadControls())
			{
				if (intakeLog.SearchBy == EnumIntakeSearchBy.Patient)
					SearchPatSubs();
				else
					SearchEligibility();
			}
		}

		public void SearchPatSubs()
		{
			if (ReadControls())
			{
				this.intakeLog.PatientSearched = true;
				// redirect to patient search with intake-log context.
				PatientSearch.Redirect(this.intakeLog);
			}

		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.intakeLog);			// display intake-log information when the patient-search is in called from intake form.
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (!this.ReadControls())
				return;

			if (!IntakeCheckBeforeSaveAndRedirect(intakeLog))
				return;

			bool gotoSubscriberForm = false;

			intakeLog.SaveWithPatient = false;
			if (intakeLog.Patient != null)
			{
				if (intakeLog.Patient.IsNew || intakeLog.Patient.IsDirty)
				{
					// a new unsaved patient is in the context.  delay the save of intake until patient is saved.
					intakeLog.SaveWithPatient = true;
					PatientForm.Redirect(intakeLog);
					return;
				}

				if (intakeLog.PatientCoverage == null || intakeLog.PatientCoverage.IsNew || intakeLog.PatientCoverage.IsDirty)
					gotoSubscriberForm = true;
				if (intakeLog.Subscriber == null || intakeLog.Subscriber.IsNew || intakeLog.Subscriber.IsDirty)
					gotoSubscriberForm = true;
			}

			if (gotoSubscriberForm)
			{
				intakeLog.SaveWithPatient = true;
				//SubscriberForm.Redirect(this.intakeLog);	// We never redirct to subsriber form, instead we go to patient and it'll save all.
				SubscriberForm.Redirect(intakeLog);
				return;
			}

			// everything is ok, just save and redirect to the page depending on the resolution
			if (!SaveData(false))
				return;
			this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@INTAKELOG@");
			IntakeRedirectByResolution(intakeLog);
		}

		

		/// <summary>
		/// Load events associated with the current patient
		/// </summary>
		public bool LoadPatientERC()
		{
			Patient patient = this.intakeLog.Patient;
			if (patient == null)
			{
				this.gridERCs.UpdateFromCollection(null); // clear rows
				return false;
			}
			bool result = true;
			BaseCollectionForEventCMSReferral ercs = null; 
			Problem problem = null;
			//EnumERCType ercFilter = EnumERCType.All;
			bool filterLinkedOnly = false;
			try
			{	
				// load all to the same grid
				gridERCs.KeepCollectionIndices = false;
				// load events
				ercs = patient.GetLinkedERCs(EnumERCType.Event);
				// Determine the linked events for the selected problem
				if (problem != null)
					ercs.DetermineElementsLinkedToProblem(problem);
				ercs.FilterLinkedOnly = filterLinkedOnly;
				gridERCs.UpdateFromCollection(ercs);
				// load referrals
				ercs = patient.GetLinkedERCs(EnumERCType.Referral);
				// Determine the linked events for the selected problem
				if (problem != null)
					ercs.DetermineElementsLinkedToProblem(problem);
				ercs.FilterLinkedOnly = filterLinkedOnly;
				gridERCs.UpdateFromCollection(ercs, true);		// append
				// load CMSs
				ercs = patient.GetLinkedERCs(EnumERCType.CMS);
				// Determine the linked events for the selected problem
				if (problem != null)
					ercs.DetermineElementsLinkedToProblem(problem);
				//ercs.FilterLinkedOnly = filterLinkedOnly;
				
				gridERCs.UpdateFromCollection(ercs, true);		// append
				return true;

				//ercs = patient.GetLinkedERCs(ercFilter);
				// Determine the linked events for the selected problem
				//if (problem != null)
				//	ercs.DetermineElementsLinkedToProblem(problem);
				//ercs.FilterLinkedOnly = filterLinkedOnly;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patient.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			gridERCs.UpdateFromCollection(ercs);
			return result;
		}

		private void gridERCs_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			gridERCs.SetColumnTranslate("ERCTypeDisplay", true);
		}

		private void butAddNote_Click(object sender, System.EventArgs e)
		{
			AddNoteIfEntered();
		}

		private void AddNoteIfEntered()
		{
			string txt = txtNewNote.Text.Trim();
			if (txt != "")
			{
				// !!! get the current user
				int userId = DataLayer.AASecurityHelper.GetUserId;
				string userName = BaseData.FormatUserForDisplay(userId, false);
				Notepad.Text = 
					this.Language.Translate("@INTAKENOTEMODIFIED@", DateTime.Now, userName) +
					"\r\n" + txtNewNote.Text + "\r\n\r\n"
					+ Notepad.Text;
				txtNewNote.Text = "";
			}
		}

		public void RedirectEligibilitySearchForNewPatientCoverage(DateTime serviceDate, Patient patient, PatientCoverage patientCoverage, string msg)
		{
			//this.intakeLog = new IntakeLog(true);
			//intakeLog.ServiceDate = serviceDate;
			// clear context except patient

			/*
			intakeLog.PatientCoverage = null;
			intakeLog.SORG = null;
			intakeLog.Plan = null;
			intakeLog.Subscriber = null;
			*/

			if (patient != null)
			{
				this.intakeLog.Patient = patient;
				this.intakeLog.PatientFName = patient.FirstName;
				this.intakeLog.PatientLName = patient.LastName;
				this.intakeLog.PatientSSN =  patient.SocialSecurityNumber;
			}

			//if (patientCoverage != null)
			//{
			//	this.intakeLog.PatientMemberID = patientCoverage.AlternatePatientID;
			//}

			// search the eligibility by patient fields
			PushPageMessage(msg, EnumPageMessageType.Warning);
			EligibilitySearch.Redirect(intakeLog);
		}


		public void SearchEligibility()
		{
			if (this.intakeLog.ServiceDate == DateTime.MinValue)
			{
				this.SetPageMessage("@SERVICEDATENOTGIVEN@", EnumPageMessageType.Error);
				return;
			}

			if (this.intakeLog.Patient != null && !this.intakeLog.Patient.IsNew)
			{
				// an existing patient
				// get matching eligibility records
				EligibilityMatchForCoverageCollection eligMatches = new EligibilityMatchForCoverageCollection();
				eligMatches.LoadEligibilityRecordsForPatient(intakeLog.ServiceDate, this.intakeLog.Patient);
				if (eligMatches.Count == 0)
				{
					RedirectEligibilitySearchForNewPatientCoverage(this.intakeLog.ServiceDate, this.intakeLog.Patient, this.intakeLog.PatientCoverage,
						"No eligibility record found for this patient.  Select a coverage from eligibility.");
					return;
				}

				if (this.intakeLog.PatientCoverage != null && !this.intakeLog.IsNew)
				{
					// an existing coverage was selected,
					// try to find a match for the existing coverage by PatientEligibilityID or SSN
					EligibilityMatchForCoverage eligMatch = eligMatches.FindMatchingValidEligibilityForCoverage(this.intakeLog.PatientCoverage.PatientCoverageID);
					if (eligMatch != null)
					{
						// a match was found.  notify the user that an eligibility record with valid covarage was found.
						this.SetPageMessage("Eligibility verified.  Coverage valid for this Patient.", EnumPageMessageType.Info);
						// update the link if not already updated.
						if (this.intakeLog.PatientCoverage.PatientEligibilityID == 0)
						{
							this.intakeLog.PatientCoverage.PatientEligibilityID = eligMatch.PatientEligibilityID;
							this.intakeLog.PatientCoverage.IsDirty = true;
							// must save when intake is saved
						}
						return;
					}
					else
					{
						// No eligibility record with valid coverage was found for this patient and coverage.
						RedirectEligibilitySearchForNewPatientCoverage(this.intakeLog.ServiceDate, this.intakeLog.Patient, this.intakeLog.PatientCoverage,
							"No eligibility record with valid coverage was found for this patient and coverage.  Select a coverage from eligibility.");
						return;
					}
				}
				else
				{
					// There was no patient coverage, just search for coverages in eligibility
					RedirectEligibilitySearchForNewPatientCoverage(this.intakeLog.ServiceDate, this.intakeLog.Patient, null,
						"Select a coverage from eligibility.");
					return;
				}
				// 
			}

			// either there's no patient selected, or the patient is new.  Create a new context
			// without clearing search fields.
			// clear the patient context to select new record from eligibility
			// search by the user specified intake fields
			this.intakeLog.Patient = null;		
			this.intakeLog.PatientCoverage = null;
			this.intakeLog.Subscriber = null;
			//this.intakeLog.SORG = null;
			//this.intakeLog.Plan = null;
			this.intakeLog.EligibilitySearched = true;
			EligibilitySearch.Redirect(intakeLog);
		}

		public void ClearAll()
		{
			//this.ReadControls();
			intakeLog.ClearPatient();
			this.intakeLog.ClearSubscriber();
			this.intakeLog.ClearSORGPlan();
			//this.intakeLog.ClearMemberSearch();
			ClearEligibilityAddAnyway();

			this.IntakeLog = this.intakeLog;		// refresh
		}

		private void butClearCaller_Click(object sender, System.EventArgs e)
		{
			this.ReadControls();
			intakeLog.ClearCaller();
			this.IntakeLog = this.intakeLog;		// refresh
		}

		private void butClearPatient_Click(object sender, System.EventArgs e)
		{
			this.ReadControls();
			intakeLog.ClearPatient();
			this.IntakeLog = this.intakeLog;		// refresh
		}

		private void butClearSubscriber_Click(object sender, System.EventArgs e)
		{
			this.ReadControls();
			this.intakeLog.ClearSubscriber();
			this.IntakeLog = this.intakeLog;		// refresh		
		}

		private void butClearPlan_Click(object sender, System.EventArgs e)
		{
			this.ReadControls();
			this.intakeLog.ClearSORGPlan();
			this.IntakeLog = this.intakeLog;		// refresh		
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();

			this.CheckForDirty(this.intakeLog);
		}

		private void SetPatientSubscriberButtons()
		{
			if(this.forDisplay || this.intakeLog.Patient == null)
			{
				this.wbtnEditPatient.Visible = false;
				this.wbtnEditSubscriber.Visible = false;
				return;
			}
			else
			{
				this.wbtnEditPatient.Visible = true;
				this.wbtnEditSubscriber.Visible = true;
			}
			if(!EligibilityAddAnyway)
			{
				this.wbtnEditPatient.TextToTranslate = "@VIEW@";
				this.wbtnEditSubscriber.TextToTranslate = "@VIEW@";
			}
			else
			{
				this.wbtnEditPatient.TextToTranslate = "@EDIT@";
				this.wbtnEditSubscriber.TextToTranslate = "@EDIT@";
			}
		}

		private void wbtnEditPatient_Click(object sender, System.EventArgs e)
		{
			if(!ReadControls())
				return;
			//intakeLog.SaveWithPatient = true;
			PatientForm.Redirect(intakeLog);
		}

		private void wbtnEditSubscriber_Click(object sender, System.EventArgs e)
		{
			if(!ReadControls())
				return;
			intakeLog.SaveWithPatient = false;  // no need to save patient
			SubscriberForm.Redirect(intakeLog);
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
			this.forDisplay = (bool)this.ViewState["forDisplay"];
		}


		protected override object SaveViewState()
		{
			this.ViewState["forDisplay"] = this.forDisplay;
			return base.SaveViewState ();
		}

		private void butAddPatient_Click(object sender, System.EventArgs e)
		{
			if (this.ReadControls())
			{
				try
				{
					intakeLog.CreateNewPatientWithThisCoverage();
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
					return;
				}
				PatientForm.Redirect(intakeLog);
			}
		}

		private void butViewLog_Click(object sender, System.EventArgs e)
		{
			IntakeLogSearch.Redirect();		
		}

		private void butNewIntake_Click(object sender, System.EventArgs e)
		{
			NewIntake();
		}


	}
}
