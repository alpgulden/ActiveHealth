using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LogOut.
	/// </summary>
	[PageTitle("@LOGGEDOUT@")]
	public class LogOut : BasePage
	{
		protected System.Web.UI.WebControls.ImageButton dummyImage;
		protected System.Web.UI.WebControls.Label PageHeader;
		protected System.Web.UI.WebControls.HyperLink lnkReturnTo;
		protected NetsoftUSA.WebForms.OBLabel lblMessage;
	
		private string logOutMessage = "";

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Request["NewWindow"] == "true")
				lnkReturnTo.Attributes["onClick"] = "ReturnToAAInNewWindow();";
			else
				lnkReturnTo.Attributes["onClick"] = "ReturnToAA();";
			
			if (!this.IsPostBack)
			{
				logOutMessage = this.GetParam("LogOutMessage") as string;
				if (logOutMessage != null)
					this.CacheObject("LogOutMessage", logOutMessage);
			}
			else
				logOutMessage = this.LoadObject("LogOutMessage") as string;

			if (logOutMessage != null)
				lblMessage.Text = this.Language.Translate(logOutMessage);

			AASecurityHelper.Logout();
		}   

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.enableAutoLogout = false;
			this.enableClientTimeout = false;
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.EnableAutoLogout = false;
			this.EnableClientTimeout = false;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		 
		public static void Redirect()
		{
			BasePage.Redirect("Logout.aspx");
		}

		public static void Redirect(string logOutMessage)
		{
			BasePage.PushParam("LogOutMessage", logOutMessage);
			Redirect();
		}
		
	}
}
