using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// This is the patient summary form.  It displays brief read-only
	/// information about patient and also provides access to some of patient's
	/// child tables like: Subscribers, Problems, CMS/Events
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.PATIENT_SUMMARY)]

	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Patient,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[PageTitle("@PATIENTSUMMARY@")]
	public class PatientSummaryForm : PatientBasePage
	{
		private PatientCoverage patientCoverage;		// the currently selected patient subscriber coverage
		private Patient patient;
		private PatientCoverageCollection patientCoverages;
		private Problem problem;		// the selected problem
		private BaseForEventCMSReferral erc;		// the selected erc
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProblems;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProblems;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCMSEvents;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCMSEvents;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridPatCovs;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPatCovs;
		protected System.Web.UI.WebControls.Table tblPatSubsInfo;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddNewSubs;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddProblem;
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder ContentPlaceHolder1;
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder ContentPlaceHolder2;
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder3;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddNewEvent;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddCMS;
		protected NetsoftUSA.WebForms.OBRadioButtonBox ercFilterOption;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddMaternichek;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddExistingSubs;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddReferral;
		protected NetsoftUSA.WebForms.OBRadioButtonBox ercFilterForProblem;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSaveProblemLinkages;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.WebForms.OBComboBox PatientCoverageSelection;
		protected System.Web.UI.HtmlControls.HtmlTable tblPatientCoverageSelection;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit EventID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.InfragisticsWeb.WebButton butFindEvent;
		protected NetsoftUSA.WebForms.OBLabel Oblabel8;
		protected NetsoftUSA.WebForms.OBLabel Oblabel9;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit CMSID;
		protected NetsoftUSA.InfragisticsWeb.WebButton butFindCMS;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ReferralID;
		protected NetsoftUSA.InfragisticsWeb.WebButton butFindReferral;
		protected NetsoftUSA.InfragisticsWeb.WebButton butEditCoverage;
		protected System.Web.UI.HtmlControls.HtmlTable tblFindByIDs;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddCovFromElig;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			tblFindByIDs.Visible = false;	// Find ERC by ID's feature is not wanted.  Keep the implementation so that we can enable if requested.

			//tblPatientCoverageSelection.Visible = false;
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				BindERCFilterOptions();
				BindERCFilterForProblem();
				this.LoadDataForPatient();			// Use load data method for data entry forms
			}
			else
			{
				patient = (Patient)this.LoadRequiredObject(typeof(Patient));  // load object from cache
				patientCoverages = (PatientCoverageCollection)this.LoadObject(typeof(PatientCoverageCollection), false);  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage), false);  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));

				gridCMSEvents.SelectedRowIndex = gridCMSEvents.SelectedRowIndex;
			}
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject(typeof(PatientCoverageCollection), null);
			base.NavigateAway (targetURL);
		}


		private void BindERCFilterOptions()
		{
			ercFilterOption.Items.Clear();
			ercFilterOption.Items.Add(new ListItem(PatientMessages.ALL, EnumERCType.All.ToString()));
			ercFilterOption.Items.Add(new ListItem(PatientMessages.EVENT, EnumERCType.Event.ToString()));
			ercFilterOption.Items.Add(new ListItem(PatientMessages.CMS, EnumERCType.CMS.ToString()));
			ercFilterOption.Items.Add(new ListItem(PatientMessages.REFERRAL, EnumERCType.Referral.ToString()));
			ercFilterOption.SelectedIndex = 0;
		}

		private void BindERCFilterForProblem()
		{
			ercFilterForProblem.Items.Clear();
			ercFilterForProblem.Items.Add(new ListItem(PatientMessages.ALL, "All"));
			ercFilterForProblem.Items.Add(new ListItem(PatientMessages.HIGHLIGHTEDPROBLEM, "OfProblem"));
			ercFilterForProblem.SelectedIndex = 0;
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("PatientSummaryForm.aspx");
		}

		private void butAddExistingSubs_Click(object sender, System.EventArgs e)
		{
			SubscriberSearch.Redirect(this.patient);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			this.gridPatCovs.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridPatCovs_ClickCellButton);
			this.gridPatCovs.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridPatCovs_ColumnsBoundToDataClass);
			this.gridPatCovs.DblClick +=new ClickEventHandler(gridPatCovs_DblClick);
			this.gridProblems.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridProblems_ClickCellButton);
			this.gridProblems.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridProblems_ColumnsBoundToDataClass);
			this.gridProblems.SelectedRowIndexChanged +=new EventHandler(gridProblems_SelectedRowIndexChanged);
			this.gridCMSEvents.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridCMSEvents_ClickCellButton);
			this.gridCMSEvents.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridCMSEvents_ColumnsBoundToDataClass);
			this.gridCMSEvents.SelectedRowIndexChanged +=new EventHandler(gridCMSEvents_SelectedRowIndexChanged);
			this.gridCMSEvents.RowBoundToDataObject +=new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(gridCMSEvents_RowBoundToDataObject);

			this.ercFilterOption.SelectedIndexChanged +=new EventHandler(ercFilterOption_SelectedIndexChanged);
			this.ercFilterForProblem.SelectedIndexChanged +=new EventHandler(ercFilterForProblem_SelectedIndexChanged);

			this.PatientCoverageSelection.SelectedIndexChanged +=new EventHandler(PatientCoverageSelection_SelectedIndexChanged);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{ 
			this.butAddCovFromElig.Click += new EventHandler(butAddCovFromElig_Click);
			this.butAddExistingSubs.Click += new System.EventHandler(this.butAddExistingSubs_Click);
			this.butAddNewSubs.Click += new System.EventHandler(this.butAddNewSubs_Click);
			this.butEditCoverage.Click += new System.EventHandler(this.butEditCoverage_Click);
			this.butAddProblem.Click += new System.EventHandler(this.butAddProblem_Click);
			this.butAddNewEvent.Click += new System.EventHandler(this.butAddNewEvent_Click);
			this.butAddCMS.Click += new System.EventHandler(this.butAddCMS_Click);
			this.butAddReferral.Click += new System.EventHandler(this.butAddReferral_Click);
			this.butAddMaternichek.Click += new System.EventHandler(this.butAddMaternichek_Click);
			this.butFindEvent.Click += new System.EventHandler(this.butFindEvent_Click);
			this.butFindCMS.Click += new System.EventHandler(this.butFindCMS_Click);
			this.butFindReferral.Click += new System.EventHandler(this.butFindReferral_Click);
			this.butSaveProblemLinkages.Click += new System.EventHandler(this.butSaveProblemLinkages_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Summary")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}

		private void gridPatCovs_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridPatCovs.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			if (e.Cell.Key == "Select")
			{
				SelectedPatCovsIndex = index;
				return;
			}
			if (e.Cell.Key == "Edit")
			{
				this.PatientCoverage = this.patientCoverages[index];
				SubscriberForm.Redirect(this.patient, this.patientCoverage, this.patientCoverage.Subscriber);
				return;
			}
		}

		// Issue 1465: When in Patient Summary, redirected guideline page should not have the selection tab.
		public void OnSubNavigationItemClick_Guidelines(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.PushCurrentCallingPage();
			GuidelineForRef.Redirect();
		}

		/// <summary>
		/// Returns the index into patient coverage collection.
		/// If no coverage is selected, sets NULL to the current patient coverage.
		/// </summary>
		public int SelectedPatCovsIndex
		{
			get
			{
				return this.PatientCoverageSelection.SelectedIndex - 1;
				//return gridPatCovs.SelectedRowIndex;
			}
			set
			{
				//if (gridPatCovs.Rows.Count > 0)
				//	gridPatCovs.SelectedRowIndex = value;
				this.PatientCoverageSelection.SelectedIndex = value + 1;
				if (value < 0)
					this.PatientCoverage = null;
				else
					this.PatientCoverage = this.patientCoverages[value];
			}
		}

		public int SelectedProblemIndex
		{
			get
			{
				return gridProblems.SelectedRowIndex;
			}
			set
			{
				gridProblems.SelectedRowIndex = value;
				/*if (gridProblems.Rows.Count > 0)
				{
					gridProblems.SelectedRowIndex = value;
					//this.patient.SelectedPatientProblem = this.patient.PatientProblems[value];
					this.Problem = GetSelectedProblem();
				}
				else
					this.Problem = null;

				LoadPatientERC();*/
			}
		}

		public Problem Problem
		{
			get { return this.problem; }
			set 
			{ 
				this.problem = value;
				this.CacheObject(typeof(Problem), problem);
			}
		}

		public BaseForEventCMSReferral ERC
		{
			get { return this.erc; }
			set 
			{ 
				this.erc = value; 
				this.CacheObject(typeof(BaseForEventCMSReferral), erc);
			}
		}

		public Problem GetSelectedProblem()
		{
			try
			{
				int problemID = (int)gridProblems.SelectedRowPK[0];
				Problem problem = new Problem();
				if (problem.Load(this.patient, problemID))
					return problem;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}

			return null;
		}

		private void gridPatCovs_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridPatCovs.AddButtonColumn("Select", "@SELECT@").Width = 50;
			gridPatCovs.AddButtonColumn("Edit", "@EDIT@", 0).Width = 50;
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientCoverageCollection PatientCoverages
		{
			get { return patientCoverages; }
			set
			{
				patientCoverages = value;
				try
				{
					PatientCoverageSelection.FillComboFromCollection(patientCoverages, "PatientCoverageID", "Description");
					//gridPatCovs.UpdateFromCollection(patientCoverages);  // update given grid from the collection

					if (this.patientCoverage != null)
					{
						// there's a coverage selected in the context
						// make it selected
						//gridPatCovs.SelectedRowPKInt = this.patientCoverage.PatientCoverageID;
						this.PatientCoverageSelection.SelectedValue = this.patientCoverage.PatientCoverageID.ToString();
					}
					else
					{
						// no selected coverage in the context.
						if (patientCoverages == null || patientCoverages.Count == 0)
						{
							SelectedPatCovsIndex = -1;
							//PatientCoverage = null;	// no pat-subs-cov selected
						}
						else
							SelectedPatCovsIndex = patientCoverages.GetPrimaryCoverageIndex();	/* FORK 1.0 */

					}
					//PatientCoverage = patientCoverages[0];	// select the first
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(PatientCoverageCollection), patientCoverages);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Patient Patient
		{
			get { return patient; }
			set
			{
				patient = value;
				try
				{
					//this.UpdateFromObject(this.Controls, patient);  // update controls for the given control collection

					// fill the patient subscriber coverages grid.
					// patient.LoadPatientCoverages(true);	// always reload the subscriber coverages
					PatientCoverages = patient.GetPatientCoverages();

					// Load problems linked to this patient.
					LoadPatientProblems();		// this will also trigger loading the events

					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				if (patient != null)
					patient.UnloadParts(false);	// unload all child collections to make sure they don't take unnecessary memory.
				this.CacheObject(typeof(Patient), patient);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForPatient()
		{
			bool result = true;
			Patient patient = null;
			try
			{	// use any load method here
				// or pull from the parameter passed to this page via PushParam
				patient = GetParamOrGetFromCache("Patient", typeof(Patient) ) as Patient;
				if (patient == null)
				{
					this.RaisePageException(new Exception("You must hit this page in the context of a patient"));
					return false;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patient.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Patient = patient;
			return result;
		}
		
		/// <summary>
		/// Load problems associated with the current patient
		/// </summary>
		public bool LoadPatientProblems()
		{
			bool result = true;
			ProblemCollection problems = null; 
			try
			{	// use any load method here
				// or pull from the parameter passed to this page via PushParam
				this.patient.LoadPatientProblems(true);
				problems = patient.GetLinkedProblems();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patient.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			// fill the problems collection and keep the PKs..
			gridProblems.KeepCollectionIndices = false;
			gridProblems.UpdateFromCollection(problems);
			//this.SelectedProblemIndex = 0;			// unnecessary..  UpdateFromCollection already does it.
			return result;
		}

		private EnumERCType SelectedERCFilter
		{
			get { return (EnumERCType)Enum.Parse(typeof(EnumERCType), this.ercFilterOption.SelectedValue, true); }
		}

		private void SetLinkCheckboxUpdatable()
		{
			bool coverageSelected = this.patientCoverage != null;
			bool covAndProblemSelected = coverageSelected && SelectedProblemIndex >= 0;

			gridCMSEvents.Columns.FromKey("IsLinkedToProblem").AllowUpdate = covAndProblemSelected ? AllowUpdate.Yes : AllowUpdate.No;
		}

		/// <summary>
		/// Load events associated with the current patient
		/// </summary>
		public bool LoadPatientERC()
		{
			bool result = true;
			BaseCollectionForEventCMSReferral ercs = null; 
			EnumERCType ercFilter = SelectedERCFilter;

			// filter linked to problem only?
			bool filterLinkedOnly = ercFilterForProblem.SelectedIndex == 1;

			try
			{	// use any load method here
				// or pull from the parameter passed to this page via PushParam
				if (ercFilter == EnumERCType.All)
				{
					ERCContainerCollection allERC = new ERCContainerCollection();
					allERC.FilterLinkedOnly = filterLinkedOnly;
					SetLinkCheckboxUpdatable();
					// load all to the same grid
					gridCMSEvents.KeepCollectionIndices = false;
					// load events
					ercs = patient.GetLinkedERCs(EnumERCType.Event);
					// Determine the linked events for the selected problem
					if (problem != null)
						ercs.DetermineElementsLinkedToProblem(problem);
					///ercs.FilterLinkedOnly = filterLinkedOnly;
					///gridCMSEvents.UpdateFromCollection(ercs);
					allERC.AppendToCollection(ercs);
					// load referrals
					ercs = patient.GetLinkedERCs(EnumERCType.Referral);
					// Determine the linked events for the selected problem
					if (problem != null)
						ercs.DetermineElementsLinkedToProblem(problem);
					///ercs.FilterLinkedOnly = filterLinkedOnly;
					///gridCMSEvents.UpdateFromCollection(ercs, true);		// append
					allERC.AppendToCollection(ercs);
					// load CMSs
					ercs = patient.GetLinkedERCs(EnumERCType.CMS);
					// Determine the linked events for the selected problem
					if (problem != null)
						ercs.DetermineElementsLinkedToProblem(problem);
					///ercs.FilterLinkedOnly = filterLinkedOnly;
					///gridCMSEvents.UpdateFromCollection(ercs, true);		// append
					allERC.AppendToCollection(ercs);

					// now update from union of all ERC collections
					allERC.SortByStartDate(false, false);	// sort by ID in descending order
					gridCMSEvents.UpdateFromCollection(allERC);		// append

					// get rid of unnecessary child collections of problem
					if (problem != null)
						problem.UnloadParts(false);

					return true;
				}

				ercs = patient.GetLinkedERCs(ercFilter);
				// Determine the linked events for the selected problem
				if (problem != null)
					ercs.DetermineElementsLinkedToProblem(problem);
				ercs.FilterLinkedOnly = filterLinkedOnly;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patient.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			// fill the problems collection and keep the PKs..
			gridCMSEvents.KeepCollectionIndices = false;
			SetLinkCheckboxUpdatable();
			gridCMSEvents.UpdateFromCollection(ercs);

			// get rid of unnecessary child collections of problem
			if (problem != null)
				problem.UnloadParts(false);
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.Redirect("PatientSummaryForm.aspx");
		}

		public static void Redirect(int patientId)
		{
			Patient patient = new Patient();
			if (!patient.Load(patientId))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@PATIENT@");
			Redirect(patient);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// This is the currently selected PatientCoverage
		/// </summary>
		public PatientCoverage PatientCoverage
		{
			get { return patientCoverage; }
			set
			{
				patientCoverage = value;
				try
				{
					tblPatSubsInfo.Visible = patientCoverage != null;

					/*if (patientCoverage != null)
					{
						tblPatSubsInfo.ClearRows();
						FillNameValueInTable("@PLAN@", patientCoverage.PlanName, tblPatSubsInfo);
						FillNameValueInTable("@SUBSCRIBER@", patientCoverage.SubscriberFullName, tblPatSubsInfo);
						//pnlPatCovs.UpdateFromObject(this.Controls, patientCoverage);  // update controls for the given control collection
					}*/

					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(PatientCoverage), patientCoverage);  // cache object using the caching method declared on the page
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			if (patientCoverage != null)
			{
				tblPatSubsInfo.Rows.Clear();

				WindowOpener wo = new WindowOpener();
				wo.ID = "wo_Plan";
				wo.NavigateURL = "PlanForm.aspx?WindowMode=NewWindow&PlanID=" + patientCoverage.PlanID;
				wo.registerClientScripts(this);

				// FORK 1.0
				FillNameValueInTable("@PLAN@", patientCoverage.PlanID + "-" + HttpUtility.HtmlEncode( patientCoverage.PlanName )
					, "<input type=checkbox " + (patientCoverage.IsPrimary ? "checked" : "") + " disabled>" + this.Language.TranslateSingle("ISPRIMARY") + "</input>"
					, "javascript:" + wo.getWindowOpenScript(), tblPatSubsInfo);
				// END FORK 1.0

				wo = new WindowOpener();
				wo.ID = "wo_Subscriber";
				wo.NavigateURL = "SubscriberForm.aspx?WindowMode=NewWindow&PatientCoverageID=" + patientCoverage.PatientCoverageID;
				wo.registerClientScripts(this);

				FillNameValueInTable("@SUBSCRIBER@", patientCoverage.SubscriberID + "-" + patientCoverage.SubscriberFullName, "javascript:" + wo.getWindowOpenScript(), tblPatSubsInfo);

				FillOrganizationPathInTable(patientCoverage.SORG, tblPatSubsInfo);
				this.butAddMaternichek.Visible = IsMaternichekButtonVisible;
			}

			bool coverageSelected = this.patientCoverage != null;
			bool covAndProblemSelected = coverageSelected && this.problem != null; // SelectedProblemIndex >= 0;
			butAddProblem.Enabled = coverageSelected;
			butAddNewEvent.Enabled = covAndProblemSelected;
			butAddCMS.Enabled = covAndProblemSelected;
			butAddReferral.Enabled = covAndProblemSelected;
			butAddMaternichek.Enabled = covAndProblemSelected;
			butSaveProblemLinkages.Enabled = covAndProblemSelected;
			butEditCoverage.Enabled = this.SelectedPatCovsIndex >= 0;
		}


		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage);
		}

		private void gridPatCovs_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			int index = gridPatCovs.GetColIndexFromClickEvent(e);
			if (index < 0)
				return;
			this.PatientCoverage = this.patientCoverages[index];
			SubscriberForm.Redirect(this.patient, this.patientCoverage, this.patientCoverage.Subscriber);
		}

		private void butAddNewSubs_Click(object sender, System.EventArgs e)
		{
			SubscriberForm.Redirect(this.patient, null, null);
		}

		private void gridProblems_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridProblems.AddButtonColumn("Select", "@SELECT@", 0).Width = 60;
			gridProblems.AddButtonColumn("Edit", "@EDIT@", 0).Width = 60;
		}

		/// <summary>
		/// First check if a coverage has been selected by the user.
		/// </summary>
		/// <returns></returns>
		public bool CheckCoverageFirst()
		{
			if (this.patientCoverage == null)
			{
				this.SetPageMessage("@FIRSTSELECTPATSUBSCOV@", EnumPageMessageType.Warning);
				return false;
			}
			else
				return true;
		}

		/// <summary>
		/// Checks if a problem was selected
		/// </summary>
		/// <returns></returns>
		public bool CheckProblemFirst()
		{
			if (this.problem == null)
			{
				this.SetPageMessage("@FIRSTSELECTPROBLEM@", EnumPageMessageType.Warning);
				return false;
			}
			else
				return true;
		}

		/// <summary>
		/// Check if both coverage and a problem are selected or not.
		/// Returns false if one is not selected.  Also sets page message.
		/// </summary>
		/// <returns></returns>
		public bool CheckCoverageAndProblemFirst()
		{
			if (!this.CheckCoverageFirst())
				return false;
			if (!this.CheckProblemFirst())
				return false;
			return true;
		}

		private void butAddProblem_Click(object sender, System.EventArgs e)
		{
			if (CheckCoverageFirst())
				ProblemForm.Redirect(this.patient, this.patientCoverage, null);		// create a new problem under this patient
		}

		private void gridProblems_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			try
			{
				switch (e.Cell.Key)
				{
					case "Edit":
					{
						int problemId = gridProblems.GetPKIntFromCellEvent(e);
						Problem problem = new Problem();
						if (!problem.Load(patient, problemId))
							throw new ActiveAdviceException("@CANTFINDRECORD@", "@PROBLEM@");

						// If not a new ERC, switch to the linked patientcoverage
						if (!problem.IsNew)
							if (problem.PatientSubscriberLog != null)
								if (problem.PatientSubscriberLog.PatientCoverage != null)
									this.PatientCoverage = problem.PatientSubscriberLog.PatientCoverage;
									//this.CacheObject(typeof(PatientCoverage), problem.PatientSubscriberLog.PatientCoverage);

						ProblemForm.Redirect(this.patient, this.patientCoverage, problem);
						break;
					}
					case "Select":
					{
						int index = gridProblems.GetColIndexFromCellEvent(e);
						if (index < 0)
							return;
						SelectedProblemIndex = index;
						break;
					}
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void butAddNewEvent_Click(object sender, System.EventArgs e)
		{
			if (!this.CheckCoverageAndProblemFirst())
				return;		// both coverage and a problem must be selected

			try
			{
				EventForm.Redirect(this.patient, this.patientCoverage, this.problem, null);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void butAddCMS_Click(object sender, System.EventArgs e)
		{
			if (!this.CheckCoverageAndProblemFirst())
				return;		// both coverage and a problem must be selected

			try
			{
				CaseManagementForm.Redirect(this.patient, this.patientCoverage, this.problem, null);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void butAddReferral_Click(object sender, System.EventArgs e)
		{
			if (!this.CheckCoverageAndProblemFirst())
				return;		// both coverage and a problem must be selected

			try
			{
				ReferralForm.Redirect(this.patient, this.patientCoverage, this.problem, null);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void gridCMSEvents_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridCMSEvents.AddButtonColumn("Edit", "@EDIT@", 0).Width = 70;
			gridCMSEvents.SetColumnTranslate("ERCTypeDisplay", true);
			//gridProblems.AddButtonColumn("Select", "@SELECT@").Width = 70;
		}

		private void gridCMSEvents_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			// EditERC uses row indices not collection indices.
			// Since the ERC grid contains data from 3 different collections, we need to work on rowIndices.
			int rowIndex = e.Cell.Row.Index;	// gridCMSEvents.GetColIndexFromCellEvent(e);
			if (rowIndex < 0)
				return;

			switch (e.Cell.Key)
			{
				case "Edit":
				{
					EditERC(rowIndex);
					break;
				}
			}
		}

		public void EditERC(int rowIndex)
		{
			if (rowIndex < 0)
				return;
			int ID = gridCMSEvents.GetPKIntFromRowIndex(rowIndex);
			EnumERCType ercType = (EnumERCType)gridCMSEvents.Rows[rowIndex].Cells.FromKey("ERCType").Value;

			EditERC(ercType, ID);
		}

		public void EditERC(EnumERCType ercType, int ID)
		{
			if(erc.ID != ID) // this.erc is already Loaded from gridCMSEvents.SelectedRowIndexChanged event, which occurs before gridCMSEvents.ClickCellButton
				erc = ERCClassFactory.CreateERCAndLoad(ercType, this.patient, ID);
			EditERC(erc);
		}

		public void EditERCAnyPatient(EnumERCType ercType, int ID)
		{
			BaseForEventCMSReferral erc = ERCClassFactory.CreateERCAndLoad(ercType, null, ID);
			this.patient = erc.ParentPatient;
			this.CacheObject(typeof(Patient), this.patient);
			EditERC(erc);
		}

		public void EditERC(BaseForEventCMSReferral erc)
		{
			try
			{
				if (erc == null)
				{
					this.RaisePageException( new ActiveAdviceException("@CANTFINDRECORD@", "Event/Referral/CMS") );
					return;
				}

				if (!CheckUserDxPxPermission(erc))
				{
					this.SetPageMessage("User has no Dx Or Px permission to view this {0}", EnumPageMessageType.Error, erc.ERCTypeDisplay);
					return;
				}

				// If not a new ERC, switch to the linked patientcoverage
				if (!erc.IsNew)
				{
					if (erc.PatientSubscriberLog != null)
						if (erc.PatientSubscriberLog.PatientCoverage != null)
						{
							this.PatientCoverage = erc.PatientSubscriberLog.PatientCoverage;
							//this.CacheObject(typeof(PatientCoverage), erc.PatientSubscriberLog.PatientCoverage);
						}

					Problem primaryProblem = erc.GetPrimaryProblem();
					if (primaryProblem != null)
					{
						this.Problem = primaryProblem;
					}
				
				}

				// we get rid of all ERC objects in the session
				this.CacheObject(typeof(BaseForEventCMSReferral), null);
				this.CacheObject(typeof(Event), null);
				this.CacheObject(typeof(Referral), null);
				this.CacheObject(typeof(CMS), null);

				switch (erc.ERCType)
				{
					case EnumERCType.Event:
					{
						EventForm.Redirect(this.patient, this.patientCoverage, this.problem, (Event)erc);
						break;
					}
					case EnumERCType.CMS:
					{
						CaseManagementForm.Redirect(this.patient, this.patientCoverage, this.problem, (CMS)erc);
						//this.SetPageMessage("CaseManagementForm.Redirect not implemented", EnumPageMessageType.Info);
						break;
					}
					case EnumERCType.Referral:
					{
						ReferralForm.Redirect(this.patient, this.patientCoverage, this.problem, (Referral)erc);
						//this.SetPageMessage("ReferralForm.Redirect not implemented", EnumPageMessageType.Info);
						break;
					}
					default:
						this.SetPageMessage("Unknown ERC type", EnumPageMessageType.Error);
						break;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void ercFilterOption_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			LoadPatientERC();
		}

		private void ercFilterForProblem_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			LoadPatientERC();
		}

		private void butAddMaternichek_Click(object sender, System.EventArgs e)
		{
			if (!this.CheckCoverageAndProblemFirst())
				return;		// both coverage and a problem must be selected

			try
			{
				CaseManagementForm.Redirect(this.patient, this.patientCoverage, this.problem, true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		public void OnSubNavigationItemClick_Activities(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			// make sure active event is selected.
			gridCMSEvents.SelectedRowIndex = gridCMSEvents.SelectedRowIndex;
			EnumActivityAndNoteContext ctx = EnumActivityAndNoteContext.Patient;
			if (this.problem != null)
				ctx = EnumActivityAndNoteContext.Problem;
			if (this.erc != null)
				ctx = EnumActivityAndNoteContext.ERC;
			ActivitiesForm.Redirect(EnumActivityContext.Activity, ctx);
		}

		public void OnSubNavigationItemClick_Images(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			// make sure active event is selected.
			gridCMSEvents.SelectedRowIndex = gridCMSEvents.SelectedRowIndex;
			ImageSearch.Redirect(this.patient, this.patientCoverage, this.problem, this.erc, null,EnumActivityAndNoteContext.Patient);
		}

		private void gridCMSEvents_SelectedRowIndexChanged(object sender, EventArgs e)
		{
			if (this.patient == null)
				return;			// the patient context may have been removed
			int rowIndex = gridCMSEvents.SelectedRowIndex;
			if (rowIndex < 0)
			{
				this.ERC = null;
				return;
			}
			int ercID = gridCMSEvents.GetPKIntFromRowIndex(rowIndex);
			EnumERCType ercType = (EnumERCType)gridCMSEvents.Rows[rowIndex].Cells.FromKey("ERCType").Value;
			this.ERC = ERCClassFactory.CreateERCAndLoad(ercType, this.patient, ercID);
		}

		private void butSaveProblemLinkages_Click(object sender, System.EventArgs e)
		{
			// the event/referral/cms collection is not always loaded in memory. 
			// iterate on all the grid items and link/unlink them.

			// each row can contain a different type of erc (Event/Referral or CMS).
			// we first load the erc and let it do the actual linking/unlinking.

			try
			{

				for (int i = 0; i < this.gridCMSEvents.Rows.Count; i++)
				{
				
					UltraGridRow row = this.gridCMSEvents.Rows[i];

					if (row.DataChanged == DataChanged.Modified)		// linked checkbox may have been changed
					{
						UltraGridCell linkedCell = row.Cells.FromKey("IsLinkedToProblem");
						if (linkedCell.DataChanged)						// linked or unlinked
						{
							int ercID = this.gridCMSEvents.GetPKIntFromRowIndex(i);			// ERC ID
							EnumERCType ercType = (EnumERCType)Enum.Parse(typeof(EnumERCType), row.Cells.FromKey("ERCType").Text);		// ERC Type
							bool isLinked = (bool)linkedCell.Value;	// ERC Is Linked?
							// Debug.WriteLine( String.Format( "Changed ERCID:{0}, ERCType:{1}, IsLinked:{2}", ercID, ercType, isLinked) );

							// load the erc and link or unlink it.
							BaseForEventCMSReferral erc = ERCClassFactory.CreateERCAndLoad(ercType, this.patient, ercID);
							if (erc != null)
							{
								erc.LinkToProblem(this.problem, isLinked);
							}
						}
					}
				}

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}

			// invalidate the problem's loaded links
			this.problem.ProblemEvents = null;		// invalidate in-memory problem-events
			this.problem.ProblemCMSes = null;		// invalidate in-memory problem-events
			this.problem.ProblemReferrals = null;		// invalidate in-memory problem-events

			LoadPatientERC();
		}

		private void gridProblems_SelectedRowIndexChanged(object sender, EventArgs e)
		{
			if (this.patient == null)
				return;			// the patient context may have been removed
			this.Problem = GetSelectedProblem();
			LoadPatientERC();
		}

		private void gridCMSEvents_RowBoundToDataObject(object sender, RowBindingEventArgs e)
		{
			BaseForEventCMSReferral erc = (BaseForEventCMSReferral)e.data;
			if (!CheckUserDxPxPermission(erc))
			{
				e.row.Cells.FromKey("ERCDescription").Value = "*";	// user not permitted
				e.row.Cells.FromKey("ERCStartDate").Value = null;
				e.row.Cells.FromKey("ERCEndDate").Value = null;
				e.row.Cells.FromKey("ERCStatusDisplay").Value = "*";
			}
		}

		private void butFindEvent_Click(object sender, System.EventArgs e)
		{
			if ((EventID.Value == null) || (EventID.Text == ""))
			{
				this.SetPageMessage("No Event ID specified", EnumPageMessageType.Warning);
				return;
			}
			EditERCAnyPatient(EnumERCType.Event, EventID.ValueInt);		
		}

		private void butFindCMS_Click(object sender, System.EventArgs e)
		{
			if ((CMSID.Value == null) || (CMSID.Text == ""))
			{
				this.SetPageMessage("No CMS ID specified", EnumPageMessageType.Warning);
				return;
			}
			EditERCAnyPatient(EnumERCType.CMS, CMSID.ValueInt);
		}

		private void butFindReferral_Click(object sender, System.EventArgs e)
		{
			if ((ReferralID.Value == null) || (ReferralID.Text == ""))
			{
				this.SetPageMessage("No Referral ID specified", EnumPageMessageType.Warning);
				return;
			}
			EditERCAnyPatient(EnumERCType.Referral, ReferralID.ValueInt);
		}

		private void PatientCoverageSelection_SelectedIndexChanged(object sender, EventArgs e)
		{
			int index = PatientCoverageSelection.SelectedIndex;
			//if (index < 0)
			//	return;
			SelectedPatCovsIndex = index - 1;
		}

		private void butEditCoverage_Click(object sender, System.EventArgs e)
		{
			int index = this.SelectedPatCovsIndex;
			if (index < 0)
				return;
			this.PatientCoverage = this.patientCoverages[index];
			SubscriberForm.Redirect(this.patient, this.patientCoverage, this.patientCoverage.Subscriber);
			return;		
		}

		// FORK 1.0

		private void butAddCovFromElig_Click(object sender, System.EventArgs e)
		{
			EligibilitySearch.RedirectForLinkToPatient(this.patient);		// create a new coverage from eligibility for the given patient
		}

		// END FORK 1.0
	}
}


