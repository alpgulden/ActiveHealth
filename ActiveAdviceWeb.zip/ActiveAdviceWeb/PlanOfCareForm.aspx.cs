using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for PlanOfCareForm.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.CMSMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("CMS,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("Summary")]
	[SelectedMainMenuItem("MPatient")]
	[PageTitle("@DGIPAGETITLE@")]
	public class PlanOfCareForm : PatientBasePage
	{
		private POCDeficit pOCDeficit;
		private POCGoal pOCGoal;
		private POCIntervention pOCIntervention;

		private Patient patient;
		private PatientCoverage patientCoverage;
		private Problem problem;
		private CMS cMS;

		protected TeamUserSelect TUSel;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGoal;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDeficit;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DeficitTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeficitTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DeficitStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeficitStatusId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitPriorityId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DeficitPriorityId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeficitPriorityId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitSourceId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit DeficitSourceDisplayOnly;
		protected NetsoftUSA.WebForms.OBFieldLabel lbComment;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Comment;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldComment;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCreateActivity;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInterventionTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo InterventionTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInterventionTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivitySubTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivitySubTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivitySubTypeID;
		protected NetsoftUSA.WebForms.OBLabel AssignedUser;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCompletionID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CompletionID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbICompletionID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityPrimaryTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityPrimaryTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityPrimaryTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DueDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDueDate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlIntervention;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCalculate;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit BillableAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBillableAmount;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fmt_BaseUOMID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBaseUOMID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit BaseAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBaseAmount;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fmt_ConversionUnitOfMeasureDescriptionByID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbConversionUnitOfMeasureID;
		protected NetsoftUSA.WebForms.OBCheckBox IsBillable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInterventionAmount;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit InterventionAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInterventionAmount;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldManagementServiceItemID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ManagementServiceItemID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbManagementServiceItemID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlInterventionBilling;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.CompletionID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.CompletionID_SelectedRowChanged);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			
			throw new ActiveAdviceException(AAExceptionAction.DisableUI, "This page is not implemented in this Release");


			// Put user code to initialize the page here
			this.TUSel.RebindControls(typeof(POCIntervention), "AssignedTeamID", "AssignedUserID");

			if (!IsPostBack)
				LoadDataForPOCIntervention();
			else
			{
				pOCGoal = (POCGoal)this.LoadObject(typeof(POCGoal));  // load object from cache
				pOCIntervention = (POCIntervention)this.LoadObject(typeof(POCIntervention));  // load object from cache
				pOCDeficit = (POCDeficit)this.LoadObject(typeof(POCDeficit));  // load object from cache
			}
			
			problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
			patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
			patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
			cMS = (CMS)this.LoadObject(typeof(CMS));  // load object from cache		
		}

		#region POCIntervention
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public POCIntervention POCIntervention
		{
			get { return pOCIntervention; }
			set
			{
				pOCIntervention = value;
				try
				{
					#region  Issue 1140
					bool completed = pOCIntervention.IsInterventionCompleted;
					CompletionDateVisibility = SubtypeVisibility = completed;
					if(completed && pOCIntervention.CompletionDate == DateTime.MinValue)
						pOCIntervention.CompletionDate = DateTime.Now;
					#endregion

					this.UpdateFromObject(this.pnlIntervention.Controls, pOCIntervention);  // update controls for the given control collection
					if(completed)
						this.UpdateFromObject(this.pnlInterventionBilling.Controls, pOCIntervention);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(POCIntervention), pOCIntervention);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPOCIntervention()
		{
			try
			{	//customize this method for this specific page
				POCIntervention tmp = new POCIntervention();
				tmp = POCIntervention;
				this.UpdateToObject(this.pnlIntervention.Controls, pOCIntervention);	// controls-to-object
				this.UpdateToObject(this.pnlInterventionBilling.Controls, pOCIntervention);
				if(this.cMS.POCInterventions.IsPOCInterventionTypeInCollection(POCIntervention, pOCIntervention.InterventionTypeID))
				{
					pOCIntervention = tmp;
					this.SetPageMessage(Messages.CMSMessages.MessageIDs.POCINTERVENTIONDUPLICATE, EnumPageMessageType.Error);
					return false;
				}
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPOCIntervention()
		{
			bool result = true;
			POCIntervention pOCIntervention = null; //new POCIntervention(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				pOCIntervention = new POCIntervention(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.POCIntervention = pOCIntervention;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForPOCIntervention()
		{
			bool result = true;
			POCIntervention pOCIntervention = null;
			try
			{	// use any load method here
				
				// or pull from the parameter passed to this page via PushParam
				 pOCIntervention = this.GetParam("POCIntervention") as POCIntervention;
				 if (pOCIntervention == null) 
					 //pOCIntervention = new POCIntervention(true); // if not passed, create a new data object and init as new
					 throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an Intervention");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//pOCIntervention.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.POCIntervention = pOCIntervention;
			//this.POCGoal = ;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(POCIntervention pOCIntervention)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("POCIntervention", pOCIntervention);
			BasePage.Redirect("PlanOfCareForm.aspx");

		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPOCIntervention()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPOCIntervention())
					return false;
				
				pOCIntervention.Save(); // update or insert to db
				this.cMS.POCInterventions = null; // will force reload
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region POCGoal
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public POCGoal POCGoal
		{
			get { return pOCGoal; }
			set
			{
				pOCGoal = value;
				try
				{
					this.UpdateFromObject(this.Controls, pOCGoal);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(POCGoal), pOCGoal);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPOCGoal()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.Controls, pOCGoal);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPOCGoal()
		{
			bool result = true;
			POCGoal pOCGoal = null; //new POCGoal(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				pOCGoal = new POCGoal();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.POCGoal = pOCGoal;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPOCGoal()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPOCGoal())
					return false;
				pOCGoal.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region POCDeficit
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public POCDeficit POCDeficit
		{
			get { return pOCDeficit; }
			set
			{
				pOCDeficit = value;
				try
				{
					this.UpdateFromObject(this.pnlDeficit.Controls, pOCDeficit);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(POCDeficit), pOCDeficit);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPOCDeficit()
		{
			try
			{	//customize this method for this specific page
				POCDeficit tmp = new POCDeficit();
				tmp = POCDeficit;
				this.UpdateToObject(this.pnlDeficit.Controls, pOCDeficit);	// controls-to-object
				// other control-to-object methods if any
				
				if (this.cMS.POCDeficits.IsPOCDeficitTypeInCollection(POCDeficit, pOCDeficit.DeficitTypeID))
				{
					pOCDeficit = tmp;
					this.SetPageMessage(Messages.CMSMessages.MessageIDs.POCDEFICITDUPLICATE, EnumPageMessageType.Error);
					return false;
				}
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPOCDeficit()
		{
			bool result = true;
			POCDeficit pOCDeficit = null; //new POCDeficit(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				pOCDeficit = new POCDeficit();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.POCDeficit = pOCDeficit;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPOCDeficit()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPOCDeficit())
					return false;
				//pOCDeficit.Save(); // update or insert to db 
				

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region UI Initialization and Events
		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.cMS);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			if(tab.Key == "POC_PlanOfCareForm")
				toolbar.AddButton("@ADDINTERVENTION@", "AddNewIntervention");
		}

		public void OnToolbarButtonClick_AddNewIntervention(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewPOCIntervention();
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.SetERCTabVisibilities();
			SetPageTabItemActive("POC_PlanOfCareForm");

			CompletionDateVisibility = pnlInterventionBilling.Visible = POCIntervention.IsInterventionCompleted;
				
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			try
			{
				if(SaveDGI())
					this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, Messages.CMSMessages.MessageIDs.PLANOFCARE); 
			}
			catch(Exception ex)
			{
				RaisePageException(ex);
			}
		}

//		public void OnTabClick_POC_PlanOfCareForm(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
//		{
//			PushTargetTab("POC_PlanOfCare");
//			PlanOfCareSearch.Redirect(this.cMS);
//		}	

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PushTargetTab("POC_PlanOfCare");
			// null collections to force reload
			//this.cMS.POCInterventions = this.cMS.POCDeficits = null;
			PlanOfCareSearch.Redirect(this.cMS);
		}
		#endregion

		private bool SaveDGI()
		{
			bool result = SaveDataForPOCDeficit() && SaveDataForPOCGoal() && SaveDataForPOCIntervention();
			if(result)
			{
				this.cMS.SavePOCDeficits();
			}
			return result;
		}

		private void CompletionID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			if(ReadControlsForPOCIntervention())
				UpdateBillableControls();
		}

		private void UpdateBillableControls()
		{
			InterventionTypeID.UpdateData(false);
			Fmt_BaseUOMID.UpdateData(false);
			Fmt_ConversionUnitOfMeasureDescriptionByID.UpdateData(false);
			IsBillable.UpdateData(false);
		}

		private bool CompletionDateVisibility
		{
			set { this.lbCompletionDate.Visible = this.CompletionDate.Visible = this.vldCompletionDate.Visible = value; }
		}

		private bool SubtypeVisibility
		{
			set { this.lbActivitySubTypeID.Visible = this.ActivitySubTypeID.Visible = this.vldActivitySubTypeID.Visible = value; }
		}

	}
}
