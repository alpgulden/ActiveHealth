using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using System.Diagnostics;
using System.Data.SqlTypes;
using Tx4oleLib;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterSearch.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseFaxQueue,DataLayer")]
	public class FaxPreview2Form : Page
	{
		private static string faxCoverDirName = ConfigHelper.GetConfigValue("FaxCoverDirName");
		private static string faxTempDirName = ConfigHelper.GetConfigValue("FaxCoverTempDirName");

		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label LabelQueueID;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;


		private static string MODE_RTF = "RTFFILE";
		private static string MODE_OBJECT = "OBJECT";

		private string mode = "";
		private string fileName = "";
		private int queueID = 0;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
			{
				if (this.Request.QueryString["Mode"] != "") 
					mode = this.Request.QueryString["Mode"];

				if (mode == MODE_RTF)
				{
					fileName = this.Request.QueryString["PARAM1"];
					LoadFileData();
				}
				else if (mode == MODE_OBJECT)
				{
					try 
					{
						queueID = int.Parse(this.Request.QueryString["PARAM1"]);
					}
					catch(Exception exp)
					{
						queueID = -1;
					}
					if (queueID <= 0)
					{
							Response.Write("Error: custom letter cannot be loaded");
							return;
					}
					LoadObjectData();
				}
				else
					return;

			}
			else
			{
			}
		}

		
		private const string strClosing = @"</html>";
		private const string strOpening = @"</head>";

		private const string strBlock2 = @"
<SCRIPT type=""text/JScript"">
<!--
	SwapStylesForP();
//--></SCRIPT>
			";

		private const string strBlock1 = @"
<script language=""javascript""><!--
		function SwapStylesForP()
		{
			var allSPANs = document.getElementsByTagName(""SPAN"");
			for (i=0;i<allSPANs.length;i++)
			{
				if (allSPANs(i).innerText.length > 80)
				{
					var parentElem = allSPANs(i).parentElement;
					if (parentElem.tagName == ""P"")
						parentElem.style.lineHeight = ""normal"";
				}
			}
		}
--></script>		
			";

		private void LoadObjectData()
		{


			string strTempHTML = faxTempDirName + "\\" + this.queueID + ".html";

			LetterCustomText lct = new LetterCustomText(true);			
			bool bRet = lct.Load(this.queueID);
			if (!bRet || lct.CustomText == null)
			{
				Response.Write("Error: custom letter cannot be loaded");
				return;
			}

			TXLicenseManagerClass txLicenceManager = null;
			Tx4oleLib.TXTextControlClass tx = null;
			try
			{
				txLicenceManager = new TXLicenseManagerClass();
				tx = new TXTextControlClass();
				tx.EnableAutomationServer();
				
				byte[] barr = new byte[lct.CustomText.Length];
				for (int i=0; i<lct.CustomText.Length;i++)
					barr[i] = (byte)lct.CustomText[i];

				bRet = tx.LoadFromMemory(barr,5, false);
				if (!bRet || lct.CustomText == null)
				{
					Response.Write("Error: custom letter cannot be loaded by Text Control");
					return;
				}

				tx.Save(strTempHTML,0,4,false);
				StreamReader sr = new StreamReader(new FileStream(strTempHTML,  FileMode.Open));
				string s = sr.ReadToEnd();
				sr.Close();
				//File.Delete(strTempHTML);

				AddScriptBlockPatch(s);
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				Response.Write(msg);
			}
			finally
			{

				if (txLicenceManager != null)
				{
					Marshal.ReleaseComObject(txLicenceManager);
				}
				if (tx != null)
				{
					Marshal.ReleaseComObject(tx);
				}
			}
		}


		private void AddScriptBlockPatch(string strHTML)
		{
			StringBuilder sb = new StringBuilder(strHTML);

			// find where end tag is
			int iPos2 = strHTML.IndexOf(strClosing);
			int iPos1 = strHTML.IndexOf(strOpening);
			if (iPos1 > 0 && iPos2 > 0)
			{
				sb.Insert(iPos2-1, strBlock2);
				sb.Insert(iPos1-1, strBlock1);
			}
			else
				throw new ApplicationException("Error: custom letter cannot be loaded: HTML error");

			Response.Write(sb.ToString());
		}

		private void LoadFileData()
		{
			string strTempHTML = faxTempDirName + "\\" + fileName + ".html";
			{
				fileName = faxCoverDirName + "\\" + fileName;

				TXLicenseManagerClass txLicenceManager = null;
				Tx4oleLib.TXTextControlClass tx = null;
				try
				{
					txLicenceManager = new TXLicenseManagerClass();
					tx = new TXTextControlClass();
					tx.EnableAutomationServer();
				
					long lRet = tx.Load(fileName,0,5, false);
					tx.Save(strTempHTML,0,4,false);
					StreamReader sr = new StreamReader(new FileStream(strTempHTML,  FileMode.Open));
					string s = sr.ReadToEnd();
					sr.Close();
					//File.Delete(strTempHTML);
					
					AddScriptBlockPatch(s);
				}
				catch(Exception ex)
				{
					string msg = ex.Message;
					Response.Write(msg);
				}
				finally
				{

					if (txLicenceManager != null)
					{
						Marshal.ReleaseComObject(txLicenceManager);
					}
					if (tx != null)
					{
						Marshal.ReleaseComObject(tx);
					}
				}
			}

		}

		
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion

		
	}
}
