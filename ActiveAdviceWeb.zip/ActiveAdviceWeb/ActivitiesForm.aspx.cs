using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// This page manages the activities of a given patient.
	/// A patient-subscriber-coverage must also be passed to this page to allow the creation
	/// of new activities.  When a new activity is created, the plan of the pat-subs-coverage is used.
	/// 
	/// The Active Advice System utilizes Activities to allow users to schedule and assign tasks to users or teams. 
	/// Activities are used to track the status of work assignments and to record the time used to complete them. 
	/// The information captured by an activity can be used to provide billing information to clients.
	/// Activities organized in Work Lists are utilized by Users to structure their daily workflow. The Activity 
	/// provides a method of encapsulating a unit of work, and can be used to track the billable time expended on a task.
	/// Activities can be created manually by Users, automatically by the System in response to stimuli, or copied from 
	/// Interventions (see Plan of Care, section 1.26).
	/// Examples of how Activities are used within the Active Advice System
	/// 	�	Intake Staff assigning work to the Utilization Review (UR) Staff personnel
	/// 	�	UR staff personnel scheduling future tasks
	/// 	�	Case Management personnel copying an Intervention as a future task to follow up patient care
	/// Activities are used principally to track issues relating to a patient�s course of care. 
	/// An important attribute of an Activity is its Due Date. The Due Date can be used to schedule an Activity for 
	/// work at a future time; this feature is frequently used in the existing Active Advice system. 
	/// 
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ACTIVITIES)]
	
	[MainLanguageClass("ActiveAdvice.Messages.ActivityMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("ActivitySearcher,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(PatientSummaryForm))]
	[SelectedMenuItem("Activities")]						//define the active menu item in side menu
	[PageTitle("@ACTIVITIESPAGETITLE@")]
	public class ActivitiesForm : PatientBasePage
	{
		private ActivitySummaryCollection activities;
		private EnumActivityAndNoteContext activityAndNoteContext;
		private ActivitySearcher activitySearcher;
		private Patient patient;
		private PatientCoverage patientCoverage;
		private Problem problem;
		private BaseForEventCMSReferral erc;			// any one of these:  Event, CMS, Referral
		private bool userCurrentContext = false;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityPriority;
		//protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityPriority;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityPriority;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityTypeID;
		//protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityTypeID;
		protected NetsoftUSA.WebForms.OBCheckBox IsBillable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIsBillable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityCompletionID;
		//protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityCompletionID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityCompletionID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSortField;
		//protected NetsoftUSA.InfragisticsWeb.WebCombo SortField;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSortField;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFromDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FromDueDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFromDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldToDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ToDueDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbToDueDate;
		protected NetsoftUSA.WebForms.OBFieldLabel CompletedByUserID;

		protected TeamUserSelect TeamUserSelect1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFromCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FromCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFromCompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbToCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ToCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldToCompletionDate;
		protected NetsoftUSA.WebForms.OBRadioButtonBox primaryTypeFilter;
		protected NetsoftUSA.WebForms.OBLabel lbSearchTitle;
		protected NetsoftUSA.InfragisticsWeb.WebButton butCalculateTotal;
		protected NetsoftUSA.WebForms.OBLabel lbActivityTotal;
		protected NetsoftUSA.WebForms.OBLabel lbGridTitle;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBComboBox ActivityTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityPriority;
		protected NetsoftUSA.WebForms.OBComboBox ActivityCompletionID;
		protected NetsoftUSA.WebForms.OBComboBox SortField;
		//protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit RescheduleDate;
		protected NetsoftUSA.WebForms.OBTextBox txtRowIndex;
		protected NetsoftUSA.WebForms.OBTextBox txtRescheduleDate;
		protected NetsoftUSA.WebForms.OBTextBox txtReassignTeam;
		protected NetsoftUSA.WebForms.OBTextBox txtReassignUser;
		protected UserSelect CompletedBy;
		protected NetsoftUSA.WebForms.SimpleRecordNavigator navBottom;
		protected NetsoftUSA.WebForms.OBLabel lbSearchStats;		
		protected NetsoftUSA.InfragisticsWeb.WebButton btnPrintReport;
		int maxRows = 100;	

		private void Page_Load(object sender, System.EventArgs e)
		{
			this.TeamUserSelect1.RebindControls(typeof(ActivitySearcher), "AssignedTeamID", "AssignedUserID");
			this.CompletedBy.RebindControls(typeof(ActivitySearcher), "CompletedByUserID");

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				//BindPrimaryTypeFilter();
				LoadData();
				if (userCurrentContext)
				{
					activities = (ActivitySummaryCollection)this.LoadObject(typeof(ActivitySummaryCollection));  // load object from cache
					if (activities != null)
					{
						Activity activity = (Activity)this.LoadObject(typeof(Activity));
						activities.SearchActivities(maxRows, activitySearcher);			// loads the ids only
						if (activity != null)
						{
							// Go to the last edited activity
							bool pageChanged = false;
							if (activities.Pager.GotoAbsoluteRecord(activity, ref pageChanged))
							{
								activities.LoadPagedGroup(activities.Pager.CurrentPageIndex);
							}
						}
						this.Activities = activities;
						this.grid.SelectedColectionIndex = activities.Pager.CurrentCollectionIndex; 
					}
				}
				else
					Search(false);
			}
			else
			{
				activities = (ActivitySummaryCollection)this.LoadObject(typeof(ActivitySummaryCollection));  // load object from cache
				activityAndNoteContext = (EnumActivityAndNoteContext)this.LoadObject("ActivityAndNoteContext");
				activitySearcher = (ActivitySearcher)this.LoadObject(typeof(ActivitySearcher));  // load object from cache
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache
			}

			// display the context in title
			switch (activitySearcher.Context)
			{
				case EnumActivityContext.WorkList:
					lbSearchTitle.TextToTranslateParameters = "@WORKLIST@";
					lbGridTitle.TextToTranslate = "@WORKLIST@";
					this.SelectedMainMenuItem = "MActivities";
					break;
				default:
					lbSearchTitle.TextToTranslateParameters = "@ACTIVITIES@";
					lbGridTitle.TextToTranslate = "@ACTIVITIES@";
					this.SelectedMainMenuItem = "MPatient";
					break;
			}

			// When the Reassign or Reschedule dialogs invoke the callback function
			// the hidden textboxes are filled and the page is posted back.
			if (this.IsPostBack && txtRowIndex.Text != null && txtRowIndex.Text != "")
			{
				if (txtRescheduleDate.Text != null && txtRescheduleDate.Text != "")
				{
					// Rescheduling ..
					RescheduleActivity();
				}
				else if (txtReassignTeam.Text != null && txtReassignTeam.Text != "")
				{
					// Reassigning ..
					ReassignActivity();
				}
				else if (txtReassignUser.Text != null && txtReassignUser.Text != "")
				{
					// Reassigning ..
					ReassignActivity();
				}
			}
		}

		/// <summary>
		/// Rescheduling an Activity involves following steps:
		/// 1) Update and Save ActivityCompletionID for OLD activity to represent record with code "RSCH" - ActivityCompletion.RSCH
		///		a. Completion Note = Rescheduled to (new date)
		///		b. Completion ID = User who did the rescheduling
		///	2) Create a NEW Activity to be a clone of an old one.
		///	3) ActivityCompletionID for NEW activity to represent record with code "FUTU" - ActivityCompletion.FUTU (default for all new Activities)
		///	    a. DueDate to be of newly selected value.
		///	4) Save newly created Activity.
		/// </summary>
		public void RescheduleActivity()
		{
			string sindex = txtRowIndex.Text;
			int index = int.Parse( sindex );
			if (index < 0)
				return;
			try
			{
				int activityID = grid.GetPKIntFromRowIndex(index);
				Activity activity = PrepareActivity(activityID);
				if (activity == null)
					return;		// not found

				Activity newActivity = activity.CreateCopy();
	
					activity.CompletionDate = DateTime.Now;
					activity.CompletedByUserID = AASecurityHelper.GetUserId;
					activity.ActivityCompletionCode = ActivityCompletion.RSCH;
					activity.CompletionNote = string.Format("Rescheduled to {0}", txtRescheduleDate.Text);
				activity.Save();

					newActivity.ActivityCompletionCode = ActivityCompletion.FUTU;
					newActivity.DueDateStr = txtRescheduleDate.Text;
					newActivity.PrimaryTypeCode = ActivityPrimaryType.ALL;
				newActivity.Save();

				Search(false); // refresh grid to have newly added Activity
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
			finally
			{
				txtRowIndex.Text = "";
				txtRescheduleDate.Text = "";
			}
		}

		/// <summary>
		/// Following steps are to be conducted when Activity is reassinged:
		/// 1) Update and Save ActivityCompletionID for OLD activity to represent record with code "RASS" - ActivityCompletion.RASS
		///		a. Completion Note = Reassigned to ?(whomever)
		///		b. Completion ID = User who did the reassigning
		/// 2) Create a NEW Activity to be a clone of an old one, with newly selected assigned Team/User.
		/// 3) ActivityCompletionID for NEW activity to represent record with code "FUTU" - ActivityCompletion.FUTU (default for all new Activities)
		/// 4) Save newly created Activity
		/// </summary>
		public void ReassignActivity()
		{
			string sindex = txtRowIndex.Text;
			int index = int.Parse( sindex );
			if (index < 0)
				return;
			try
			{
				int activityID = grid.GetPKIntFromRowIndex(index);
				Activity activity = PrepareActivity(activityID);
				if (activity == null)
					return;		// not found

				int userId = Formatting.ParseInt(txtReassignUser.Text, 0);
				Activity newActivity = activity.CreateCopy();

					activity.ActivityCompletionCode = ActivityCompletion.RASS;
					activity.CompletionNote = string.Format("Reassigned to {0} ID: {1}", AAUserCollection.AllUsers.Lookup_LoginNameByUserId(userId), userId);
					activity.CompletedByUserID = AASecurityHelper.GetUserId;
					activity.CompletionDate = DateTime.Now;
				activity.Save();
				
					newActivity.AssignedTeamID = Formatting.ParseInt(txtReassignTeam.Text, 0);
					newActivity.AssignedUserID = userId;
					newActivity.ActivityCompletionCode = ActivityCompletion.FUTU;
					newActivity.PrimaryTypeCode = ActivityPrimaryType.ALL;
				newActivity.Save(false/*no changes are made to related(if exists) intervetion*/);

				Search(false); // refresh grid to have newly added Activity
			}

			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
			finally
			{
				txtRowIndex.Text = "";
				txtReassignTeam.Text = "";
				txtReassignUser.Text = "";
			}
		}

		/*
		private void BindPrimaryTypeFilter()
		{
			primaryTypeFilter.Items.Clear();
			primaryTypeFilter.Items.Add(new ListItem("Activities", "1"));
			primaryTypeFilter.Items.Add(new ListItem("Interventions", "2"));
			primaryTypeFilter.Items.Add(new ListItem("All", "0"));
			primaryTypeFilter.SelectedIndex = 2;
		}*/

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			
			this.navBottom.ClickNext += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(this.navBottom_ClickNext);
			this.navBottom.ClickPreviousPage += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(this.navBottom_ClickPreviousPage);
			this.navBottom.ClickPrevious += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(this.navBottom_ClickPrevious);
			this.navBottom.ClickFirst += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(this.navBottom_ClickFirst);
			this.navBottom.ClickNextPage += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(this.navBottom_ClickNextPage);
			this.navBottom.ClickLast += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(navBottom_ClickLast);

			grid.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
			grid.BeforeColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_BeforeColumnsBoundToDataClass);
			grid.ClickCellButton +=new ClickCellButtonEventHandler(grid_ClickCellButton);
			primaryTypeFilter.SelectedIndexChanged +=new EventHandler(primaryTypeFilter_SelectedIndexChanged);
			butCalculateTotal.Click +=new EventHandler(butCalculateTotal_Click);
			this.btnPrintReport.Click += new System.EventHandler(this.btnPrintReport_Click);
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.ViewStateOnServer = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		public Activity PrepareActivity(int activityID)
		{
			Activity activity = null;
			if (activityID != 0)
			{
				activity = new Activity();
				if (!activity.Load(activityID))
					return null;
			}

			return activity;
		}

		public Activity PreparePatientProblemERC(int activityID)
		{
			Activity activity = null;
			if (activityID != 0)
			{
				activity = new Activity();
				activity.Load(activityID);
			}

			PreparePatientProblemERC(activity);
			return activity;
		}

		/// <summary>
		/// Before calling any other page, call this to prepare the appropriate
		/// patient, problem, event/cms/referral context.
		/// In worklist mode, each row may have different patient context.
		/// </summary>
		/// <param name="activity"></param>
		public void PreparePatientProblemERC(Activity activity)
		{
			// detect the context objects from activity in the worklist mode.
			if (activitySearcher.Context == EnumActivityContext.WorkList && activity != null)
			{
				this.patient = activity.Patient;
				this.problem = activity.GetProblem();
				this.patientCoverage = null;
				if (activity.EventID != 0)
				{
					this.erc = activity.GetEvent();
					this.CacheObject(typeof(Event), (Event)erc);
				}
				if (activity.CMSID != 0)
				{
					this.erc = activity.GetCMS();
					this.CacheObject(typeof(CMS), (CMS)erc);
				}
				if (activity.ReferralID != 0)
				{
					this.erc = activity.GetReferral();
					this.CacheObject(typeof(Referral), (Referral)erc);
				}
				if (this.erc != null)
				{
					if (this.erc.PatientSubscriberLog != null)
                        this.patientCoverage = this.erc.PatientSubscriberLog.PatientCoverage;
				}

				this.CacheObject(typeof(Patient), patient);
				this.CacheObject(typeof(PatientCoverage), patientCoverage);
				this.CacheObject(typeof(Problem), problem);
				this.CacheObject(typeof(BaseForEventCMSReferral), erc);
			}
		}

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				toolbar.AddButton(PatientMessages.MessageIDs.NEWSEARCH, "NewSearch"); //.Item.TargetURL ="javascript:window.alert('hi')";
				toolbar.AddButton(ActivityMessages.MessageIDs.ADDNEWRECORD, "AddNew");
				toolbar.AddButton(ActivityMessages.MessageIDs.RESCHEDULE, "Reschedule").Item.TargetURL = "javascript:openRescheduler();";
				toolbar.AddButton(ActivityMessages.MessageIDs.REASSIGN, "Reassign").Item.TargetURL = "javascript:openReassign();";
				toolbar.AddButton(ActivityMessages.MessageIDs.COMPLETE, "Complete");
				toolbar.AddButton(ActivityMessages.MessageIDs.PATIENT, "Patient");
				toolbar.AddButton(ActivityMessages.MessageIDs.CONTACTS, "Contacts");

				WindowOpener woSummary = new WindowOpener();
				woSummary.ID = "ActivitySummaryWindowOpener";
				woSummary.NavigateURL = "ActivitySummary.aspx?WindowMode=NewWindow";
				woSummary.WindowWidth = Unit.Pixel(1000);
				//woSummary.WindowHeight = 1000;
				woSummary.registerClientScripts(this);
				toolbar.AddButton(ActivityMessages.MessageIDs.TOTALS, "Totals").Item.TargetURL = "javascript:" + woSummary.getWindowOpenScript();
			}

			// Menu items to be displayed on all tabs
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			// Addnew displays only in the activity context, not in worklist context
			bool activityContext = this.activitySearcher.Context == EnumActivityContext.Activity;
			bool workListContext = this.activitySearcher.Context == EnumActivityContext.WorkList;
			if (workListContext)
				this.PageTitle = "@WORKLISTPAGETITLE@";
			SetPageTabToolbarItemVisible("AddNew", activityContext);
			SetPageTabToolbarItemVisible("Patient", workListContext);

			navBottom.Visible = activities != null && activities.Pager.HasRecords;
			navBottom.LastButtonEnabled = navBottom.NextPageButtonEnabled = activities != null && activities.Pager.HasNextPage;
			navBottom.FirstButtonEnabled = navBottom.PreviousPageButtonEnabled = activities != null && activities.Pager.HasPreviousPage;

			/*
			if (!navBottom.PreviousPageButtonEnabled)
				navBottom.FirstButtonScript = "if (FirstWebGridRow(grid)) return false;";
			else
				navBottom.FirstButtonScript = "";	// postback
			*/

			if (activities == null)
				lbSearchStats.TextToTranslate = "";
			else
				lbSearchStats.TextToTranslate = 
					String.Format("Page {0} of {1} / Total Records: {2}", 
					activities.Pager.CurrentPageIndex + 1,
					activities.Pager.NumberOfPages,
					activities.Pager.TotalRecords);

		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.activitySearcher.Context == EnumActivityContext.WorkList)
				return;
			else
				base.OnToolbarButtonClick_Cancel(toolbar, button);
		}

		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewActivitySearcher();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// Create a new activity and open the activity data entry page
			PreparePatientProblemERC(0);
			ActivityForm.Redirect(this.patient, null);
		}

		/*
		public void OnToolbarButtonClick_Contacts(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// Reassign activity
			int id = grid.SelectedRowPKInt;
			if (id <= 0)
				return;
			try
			{
				PreparePatientProblemERC(id);
				ContactSearch.Redirect(this.patient);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}*/

		public void OnToolbarButtonClick_Complete(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// Reassign activity
			int id = grid.SelectedRowPKInt;
			if (id <= 0)
				return;
			try
			{
				PushTargetTab("Completion");
				ActivityForm.Redirect(this.patient, PreparePatientProblemERC(id));
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		public void OnToolbarButtonClick_Patient(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.activitySearcher.Context == EnumActivityContext.Activity)
			{
				PatientSummaryForm.Redirect(this.patient);
				return;
			}

			// Go to the patient of the selected activity
			int id = grid.SelectedRowPKInt;
			if (id <= 0)
				return;
			try
			{
				PreparePatientProblemERC(id);
				PatientSummaryForm.Redirect(this.patient);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.Cancel);
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			
			try
			{	// use any load method here
				
				object context = this.GetParam("ActivityContext");
				EnumActivityContext acontext = EnumActivityContext.WorkList;
				if (context != null)		// use given context
				{
					acontext = (EnumActivityContext)context;
					
				}
				else
				{		// use current context
					this.userCurrentContext = true;
					this.activitySearcher = this.LoadObject(typeof(ActivitySearcher)) as ActivitySearcher;
					if (this.activitySearcher != null)
					{
						acontext = this.activitySearcher.Context;
						
						if (acontext == EnumActivityContext.WorkList)
						{
							// Clear the patient context for worklist
							this.CacheObject(typeof(Patient), null);
							this.CacheObject(typeof(PatientCoverage), null);
							this.CacheObject(typeof(Problem), null);
							this.CacheObject(typeof(BaseForEventCMSReferral), null);
						}
					}
				}
				object activityContext = this.GetParamOrGetFromCache("ActivityAndNoteContext", "ActivityAndNoteContext");
				if (activityContext == null && acontext == EnumActivityContext.Activity)
					throw new ActiveAdviceException(AAExceptionAction.None, "No ActivityAndNoteContext passed");
 
				if (acontext == EnumActivityContext.Activity)
					activityAndNoteContext = (EnumActivityAndNoteContext)Convert.ToInt32(activityContext);
				this.CacheObject("ActivityAndNoteContext", activityContext);

				patient = (Patient)this.LoadObject(typeof(Patient));
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));
				problem = (Problem)this.LoadObject(typeof(Problem));
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));

				if (context == null)		// use current context
				{
					if (this.activitySearcher == null)
						NewActivitySearcher(EnumActivityContext.WorkList);
					else
						this.ActivitySearcher = this.activitySearcher;
				}
				else
				{
					result = NewActivitySearcher(acontext);
					if (!result)
						return false;
				}

				if (this.activitySearcher.Context == EnumActivityContext.WorkList)
				{	
					this.ActivitySearcher = this.activitySearcher;	// refresh
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//activity.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(EnumActivityContext activityContext, EnumActivityAndNoteContext activityAndNoteContext)
		{
			//BasePage.PushCurrentCallingPage();

			BasePage.PushParam("ActivityContext", activityContext);
			BasePage.PushParam("ActivityAndNoteContext", activityAndNoteContext);
			BasePage.Redirect("ActivitiesForm.aspx");
		}

		public static void RedirectWorklist()
		{
			BasePage.PushParam("ActivityContext", EnumActivityContext.WorkList);
			BasePage.Redirect("ActivitiesForm.aspx");
		}

		public static void RedirectCurrentContext()
		{
			//BasePage.PushCurrentCallingPage();
			BasePage.PushParam("ActivityContext", null);
			BasePage.Redirect("ActivitiesForm.aspx");
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search(false);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ActivitySearcher ActivitySearcher
		{
			get { return activitySearcher; }
			set
			{
				activitySearcher = value;
				try
				{
					this.UpdateFromObject(pnlSearch.Controls, activitySearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(ActivitySearcher), activitySearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlSearch.Controls, activitySearcher);	// controls-to-object

				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// New activity in the same activity context (activity/worklist)
		/// </summary>
		/// <returns></returns>
		public bool NewActivitySearcher()
		{
			if (this.activitySearcher != null)
				return NewActivitySearcher( this.activitySearcher.Context );		// keep activity/worklist context
			else
				return NewActivitySearcher(EnumActivityContext.Activity);
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewActivitySearcher(EnumActivityContext context)
		{
			bool result = true;
			ActivitySearcher activitySearcher = new ActivitySearcher(); // use a parameterized constructor which also initializes the data object
			activitySearcher.PrimaryTypeCode = ActivityPrimaryType.ACTIVITY;
			try
			{	// or use an initialization method here
				activitySearcher.Context = context;
				if (context == EnumActivityContext.Activity)
					activitySearcher.PatientId = this.patient.PatientId;
				else
				{
					// worklist
					activitySearcher.AssignedUserID = AASecurityHelper.GetUserId;	// currently logged in user
					activityAndNoteContext = EnumActivityAndNoteContext.ERC;	// always event context.  use everything down to event.
					this.CacheObject("ActivityAndNoteContext", activityAndNoteContext);
					this.erc = null;
					this.CacheObject(typeof(BaseForEventCMSReferral), this.erc);
					this.problem = null;
					this.CacheObject(typeof(Problem), this.problem);
					this.patient = null;
					this.CacheObject(typeof(Patient), this.patient);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.ActivitySearcher = activitySearcher;
			this.Activities = null;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ActivitySummaryCollection Activities
		{
			get { return activities; }
			set
			{
				activities = value;
				try
				{
					if (this.activitySearcher.Context == EnumActivityContext.WorkList)
					{
						// Completion related info not visible in worklis mode
						grid.Columns.FromKey("CompletionDate").IsBound = false;
						grid.Columns.FromKey("CompletionDate").Hidden = true;
						grid.Columns.FromKey("ActivityCompletionID").IsBound = false;
						grid.Columns.FromKey("ActivityCompletionID").Hidden = true;
					}

					grid.KeepCollectionIndices = false;  // update given grid from the collection
					grid.UpdateFromCollection(activities);  // update given grid from the collection


					EnumActivityContext ctx = activitySearcher.Context;

					if (ctx == EnumActivityContext.Activity && !AASecurityHelper.HasFullAccessRole(AASecurityHelper.ACTIVITIES)
						|| ctx == EnumActivityContext.WorkList && !AASecurityHelper.HasFullAccessRole(AASecurityHelper.WORKLISTS))
					{
						PageTab.Visible = false;
						PageToolbar.Visible = false;
						this.SetPageMessage("@NOTAUTHORIZED@", EnumPageMessageType.Error);
					}
					
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(ActivitySummaryCollection), activities);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search(bool calculateTotal)
		{
			bool result = true;
			ActivitySummaryCollection activities = new ActivitySummaryCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				activities.SearchActivities(maxRows, activitySearcher);			// loads the ids only
				activities.LoadPagedGroup(0);	// load first page

				if (calculateTotal)
				{
					activities.SearchActivities(maxRows, activitySearcher);
					lbActivityTotal.TextToTranslate = 
						this.Language.Translate("@TOTALBILLABLEAMOUNT@ = {0}",
						activitySearcher.CalculatedTotalBillableAmount);
				}

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//activities.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Activities = activities;
			grid.SelectedRowIndex = 0;
			return result;
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool SearchNext(PagingDirection direction)
		{
			bool result = true;
			try
			{
				if (direction == PagingDirection.NextPage)
				{
					if (!activities.Pager.NextPage())
						return false;
				}
				else if (direction == PagingDirection.PreviousPage)
				{
					if (!activities.Pager.PreviousPage())
						return false;
				}
				else if (direction == PagingDirection.LastPage)
				{
					if (!activities.Pager.LastPage())
						return false;
				}
				else if (direction == PagingDirection.FirstPage)
				{
					if (!activities.Pager.FirstPage())
						return false;
				}

				activities.LoadPagedGroup(activities.Pager.CurrentPageIndex);	// load first page

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//activities.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Activities = activities;
			if (direction == PagingDirection.NextPage || direction == PagingDirection.FirstPage)
				grid.SelectedRowIndex = 0;
			else
				grid.SelectedRowIndex = grid.Rows.Count - 1;
			return result;
		}

		private void grid_BeforeColumnsBoundToDataClass(object sender, EventArgs e)
		{
			if (this.activitySearcher.Context == EnumActivityContext.WorkList)
			{
				// FORK1.1
				grid.AddColumn("PatientFirstName", "@FIRSTNAME@", 6, false, true);
				grid.AddColumn("PatientLastName", "@LASTNAME@", 6, false, true);
				grid.AddColumn("ProviderPhone", "@PROVIDERPHONE@", 12, false, true);
				grid.AddColumn("ProviderName", "@PROVIDERNAME@", 12, false, true);
			}
			// FORK1.1
			else
			{
				grid.AddColumn("ProviderPhone", "@PROVIDERPHONE@", 10, false, true);
				grid.AddColumn("ProviderName", "@PROVIDERNAME@", 10, false, true);
			}
		}

		private void grid_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			grid.AddEditButton("Edit", "@EDIT@", 0).Width = 60;
		}

		private void grid_ClickCellButton(object sender, CellEventArgs e)
		{
			if (e.Cell.Key == "Edit")
			{
				int id = grid.GetPKIntFromCellEvent(e);
				try
				{
					ActivityForm.Redirect(this.patient, PreparePatientProblemERC(id));
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}

		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.erc);
		}

		private void butCalculateTotal_Click(object sender, System.EventArgs e)
		{
			Search(true);
		}

		private void primaryTypeFilter_SelectedIndexChanged(object sender, EventArgs e)
		{
			Search(false);
		}

		// FORK1.1
		private void btnPrintReport_Click(object sender, System.EventArgs e)
		{
			ReportParameters reportParameters= new ReportParameters();
			reportParameters.RowCount = 100;
			reportParameters.SortField = activitySearcher.SortField.ToString();

			DateTime nullDate = new DateTime(1,1,1);

			if (activitySearcher.FromDueDate == nullDate)
				reportParameters.FromDueDate = "";
			else
				reportParameters.FromDueDate = activitySearcher.FromDueDate.ToString();

			if (activitySearcher.ToDueDate == nullDate)
				reportParameters.ToDueDate = "";
			else
				reportParameters.ToDueDate = activitySearcher.ToDueDate.ToString();

			if (activitySearcher.FromCompletionDate == nullDate)
				reportParameters.FromCompletionDate = "";
			else
				reportParameters.FromCompletionDate = activitySearcher.FromCompletionDate.ToString();

			if (activitySearcher.ToCompletionDate == nullDate)
				reportParameters.ToCompletionDate = "";
			else
				reportParameters.ToCompletionDate = activitySearcher.ToCompletionDate.ToString();
			reportParameters.PatientId = activitySearcher.PatientId;
			reportParameters.CMSID = activitySearcher.CMSID;
			reportParameters.PlanID = activitySearcher.PlanId;
			reportParameters.ProblemId = activitySearcher.ProblemId;
			reportParameters.EventID = activitySearcher.EventID;
			reportParameters.ReferralID = activitySearcher.ReferralID;
			reportParameters.ReferralDetailID = activitySearcher.ReferralDetailID;
			reportParameters.ReviewID = activitySearcher.ReviewID;
			reportParameters.PRRequestID = activitySearcher.PRRequestID;
			reportParameters.PRReviewID = activitySearcher.PRReviewID;
			reportParameters.PRProviderDecisionID = activitySearcher.PRProviderDecisionID;
			reportParameters.ActivityTypeID = activitySearcher.ActivityTypeID;			
			reportParameters.ActivityPriority = activitySearcher.ActivityPriority;
			reportParameters.ActivityCompletionID = activitySearcher.ActivityCompletionID;
			reportParameters.IsBillable = activitySearcher.IsBillable;
			reportParameters.AssignedTeamID = activitySearcher.AssignedTeamID;
			reportParameters.AssignedUserID = activitySearcher.AssignedUserID;
			reportParameters.CompletedByUserID = activitySearcher.CompletedByUserID;
			reportParameters.ActivityPrimaryTypeID = 1;
			reportParameters.CodeStatus = activitySearcher.CodeStatus;

//			if(reportParameters.FromDueDate!=System.DateTime.MinValue)
//				reportParameters.FromDueDate = activitySearcher.FromCompletionDate;
//
//			if(reportParameters.PatientId!=0)
//				reportParameters.PatientId = activitySearcher.PatientId;

			this.CacheObject("ReportParameters",reportParameters);
			this.CacheObject("ReportName", "RPTWORKLISTNONPRINTEDTEST");
			this.RegisterStartupScript("rptworklistnonprinted",  "<script>ViewWorklistnonprinted();\n</script>");
		}

		private void navBottom_ClickNextPage(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			SearchNext(PagingDirection.NextPage);			
		}

		private void navBottom_ClickPreviousPage(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			SearchNext(PagingDirection.PreviousPage);
		}

		private void navBottom_ClickFirst(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			SearchNext(PagingDirection.FirstPage);
		}

		private void navBottom_ClickNext(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			SearchNext(PagingDirection.NextPage);	// record prev/next handled in the client.
		}

		private void navBottom_ClickPrevious(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			SearchNext(PagingDirection.PreviousPage);	// record prev/next handled in the client.
		}

		private void navBottom_ClickLast(object sender, SimpleRecordNavigatorButtonEventArgs e)
		{
			SearchNext(PagingDirection.LastPage);
		}
	}
}
