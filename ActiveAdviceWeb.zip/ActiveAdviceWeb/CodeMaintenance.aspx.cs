using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	/// 

	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.CODE_TABLES)]

	[MainLanguageClass("ActiveAdvice.Messages.BaseMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	public class CodeMaintenance : CodeBasePage
	{
		protected NetsoftUSA.WebForms.OBLabel selection;
		protected NetsoftUSA.WebForms.OBLabel selectionheader;
		protected System.Web.UI.WebControls.Repeater AltMenuList;		
		protected System.Web.UI.WebControls.LinkButton menulink;

		private string menuheader;
	

		private void Page_Load(object sender, System.EventArgs e)
		{
			menuheader = this.GetParamOrGetFromCache("menuheader", typeof(string)) as string;
			if(menuheader!=null) 
			{
				this.selection.Visible=false;
				this.selectionheader.Visible=true;
				selectionheader.TextToTranslate = "@" + menuheader + "@";
				GenerateAltMenu(menuheader);
			}
			else
			{
				this.selection.Visible=true;
				this.selectionheader.Visible=false;
			}
		}

		public static void Redirect(string type)
		{
			BasePage.PushParam("menuheader",type);
			BasePage.Redirect("CodeMaintenance.aspx");
		}

		private void GenerateAltMenu(string menuheader)
		{
			ArrayList menuitems= new ArrayList();

			switch(menuheader)
			{
				case("ORGANIZATION"):
					menuitems.Add(this.Language.TranslateSingle("ORGANIZATIONTYPE"));
					menuitems.Add(this.Language.TranslateSingle("ORGANIZATIONFOCUS"));
					menuitems.Add(this.Language.TranslateSingle("ORGANIZATIONCONTACTROLE"));
					this.SelectedSideMenuItem = "grpOrganization";
					break;
				case("PLAN"):
					menuitems.Add(this.Language.TranslateSingle("PLANTYPE"));
					menuitems.Add(this.Language.TranslateSingle("PLANHEDISTYPE"));
					menuitems.Add(this.Language.TranslateSingle("PLANHEDISPAYORTYPE"));
					menuitems.Add(this.Language.TranslateSingle("PLANPRECERTNOTIFYUOFM"));
					menuitems.Add(this.Language.TranslateSingle("PLANNOTETYPE"));
					menuitems.Add(this.Language.TranslateSingle("PLANBENEFITSERVICETYPE"));
					menuitems.Add(this.Language.TranslateSingle("PLANBENEFITSERVICECOVERAGE"));
					menuitems.Add(this.Language.TranslateSingle("MATERNICHECKINCENTIVE"));
					menuitems.Add(this.Language.TranslateSingle("MANAGEMENTSERVICESRATETYPE"));
					menuitems.Add(this.Language.TranslateSingle("MANAGEMENTSERVICESRATEUOFM"));
					menuitems.Add(this.Language.TranslateSingle("MANAGEMENTSERVICESTYPE"));
					menuitems.Add(this.Language.TranslateSingle("NETWORKFOCUS"));
					menuitems.Add(this.Language.TranslateSingle("NETWORKTYPE"));
					menuitems.Add(this.Language.TranslateSingle("MEMBERLIVESSOURCE"));
					menuitems.Add(this.Language.TranslateSingle("CONVERSIONUNITOFMEASURE"));
					
					this.SelectedSideMenuItem = "grpPlan";
					break;
				case("INTAKE"):
					menuitems.Add(this.Language.TranslateSingle("CALLSOURCE"));
					menuitems.Add(this.Language.TranslateSingle("CALLREASON"));
					menuitems.Add(this.Language.TranslateSingle("CALLRESOLUTION"));
					this.SelectedSideMenuItem = "grpIntake";
					break;
				case("PATIENT"):
					//menuitems.Add(this.Language.TranslateSingle("NOTSUBSCRIBEREXCEPTION"));
					menuitems.Add(this.Language.TranslateSingle("OTHERINSURANCETYPE"));
					//menuitems.Add(this.Language.TranslateSingle("LANGUAGE"));
					menuitems.Add(this.Language.TranslateSingle("SUBSCRIBERPATIENTRELATIONSHIP"));
					menuitems.Add(this.Language.TranslateSingle("COVERAGESTATUS"));
					//menuitems.Add(this.Language.TranslateSingle("PANELTYPE"));
					menuitems.Add(this.Language.TranslateSingle("PATIENTFOCUS"));
					//menuitems.Add(this.Language.TranslateSingle("HEALTHCENTER"));
					menuitems.Add(this.Language.TranslateSingle("UB92DISPOSION"));
					menuitems.Add(this.Language.TranslateSingle("UB92SOURCE"));
					menuitems.Add(this.Language.TranslateSingle("PATIENTCONTACTROLE"));
					this.SelectedSideMenuItem = "grpPatient";
					break;
				case("PROVIDER"):
					menuitems.Add(this.Language.TranslateSingle("PROVIDERFOCUS"));
					//menuitems.Add(this.Language.TranslateSingle("PROVIDERLANGUAGE"));
					menuitems.Add(this.Language.TranslateSingle("PROVIDERSERVICE"));
					menuitems.Add(this.Language.TranslateSingle("PROVIDERSPECIALITY"));
					menuitems.Add(this.Language.TranslateSingle("PROVIDERCONSULTINGROLE"));
					menuitems.Add(this.Language.TranslateSingle("FACILITYFOCUS"));
					menuitems.Add(this.Language.TranslateSingle("FACILITYSERVICE"));
					menuitems.Add(this.Language.TranslateSingle("FACILITYTYPE"));
					menuitems.Add(this.Language.TranslateSingle("GROUPPRACTICEFOCUS"));
					menuitems.Add(this.Language.TranslateSingle("GROUPPRACTICESERVICE"));
					menuitems.Add(this.Language.TranslateSingle("GROUPPRACTICETYPE"));
					menuitems.Add(this.Language.TranslateSingle("CONTACTROLE"));
					this.SelectedSideMenuItem = "grpProvider";
					break;
				case("SYSTEM"):
					menuitems.Add(this.Language.TranslateSingle("NAMEPREFIX"));
					menuitems.Add(this.Language.TranslateSingle("STATE"));
					this.SelectedSideMenuItem = "grpSystem";
					break;
				case("RDPARTY"):
					menuitems.Add(this.Language.TranslateSingle("LOSPAYORGROUP"));
					menuitems.Add(this.Language.TranslateSingle("LOSPAYORREGION"));
					menuitems.Add(this.Language.TranslateSingle("DRGTYPE"));
					//menuitems.Add(this.Language.TranslateSingle("MAJORDIAGNOSTICCATEGORY"));
					menuitems.Add(this.Language.TranslateSingle("SERVICECLASS"));
					//menuitems.Add(this.Language.TranslateSingle("DIAGNOSTICGROUP"));
					this.SelectedSideMenuItem = "grp3rdParty";
					break;
				case("ACTIVITIES"):
					menuitems.Add(this.Language.TranslateSingle("ACTIVITYCOMPLETIONCODE"));
					menuitems.Add(this.Language.TranslateSingle("ACTIVITYTYPE"));
					menuitems.Add(this.Language.TranslateSingle("ACTIVITYPRIMARYTYPE"));					
					menuitems.Add(this.Language.TranslateSingle("ACTIVITYTYPESUBTYPE"));
					menuitems.Add(this.Language.TranslateSingle("ACTIVITYSUBTYPE"));
					menuitems.Add(this.Language.TranslateSingle("NOTETYPE"));
					menuitems.Add(this.Language.TranslateSingle("NOTETERMINATIONREASON"));
					this.SelectedSideMenuItem = "grpActivity";
					break;
				case("CLINICALREVIEW"):					
					menuitems.Add(this.Language.TranslateSingle("CLINICALREVIEWDECISIONTYPE"));
					menuitems.Add(this.Language.TranslateSingle("REVIEWDECISIONTYPE"));
					menuitems.Add(this.Language.TranslateSingle("REVIEWDECISIONREASON"));
					menuitems.Add(this.Language.TranslateSingle("REVIEWDESCRIPTION"));
					menuitems.Add(this.Language.TranslateSingle("REVIEWDURATIONUNITS"));
					menuitems.Add(this.Language.TranslateSingle("REVIEWFREQUENCYUNITS"));
					menuitems.Add(this.Language.TranslateSingle("REVIEWTYPE"));
					menuitems.Add(this.Language.TranslateSingle("REVIEWUNITS"));
					this.SelectedSideMenuItem = "grpClinicalReview";
					break;
				case("CLINICALMANAGEMENTSERVICE"):
					menuitems.Add(this.Language.TranslateSingle("CMSACUITY"));
					menuitems.Add(this.Language.TranslateSingle("CMSCATAGORY"));
					menuitems.Add(this.Language.TranslateSingle("CMSINTENSITY"));
					menuitems.Add(this.Language.TranslateSingle("CMSPHASE"));
					menuitems.Add(this.Language.TranslateSingle("CMSREASONFORCLOSING"));
					menuitems.Add(this.Language.TranslateSingle("CMSREASONFOROPENING"));
					menuitems.Add(this.Language.TranslateSingle("CMSREASONFORCONTINUING"));
					menuitems.Add(this.Language.TranslateSingle("CMSSOURCE"));
					menuitems.Add(this.Language.TranslateSingle("CMSTYPE"));
					//menuitems.Add(this.Language.TranslateSingle("CMSPROGRAM"));
					//menuitems.Add(this.Language.TranslateSingle("CMSACTIONTYPE"));
					menuitems.Add(this.Language.TranslateSingle("CMSRISKTYPE"));
					menuitems.Add(this.Language.TranslateSingle("CMSLEVELOFDISEASETYPE"));
					this.SelectedSideMenuItem = "grpClinicalMS";
					break;					
				case("CAREMANAGEMENT"):
					menuitems.Add(this.Language.TranslateSingle("APPROVALPATIENTTYPE"));
					menuitems.Add(this.Language.TranslateSingle("OTHERAPPROVALTYPE"));
					//menuitems.Add(this.Language.TranslateSingle("ASSESSMENTGOALS"));
					menuitems.Add(this.Language.TranslateSingle("ASSESSMENTLEVELOFDISEASE"));
					menuitems.Add(this.Language.TranslateSingle("ASSESSMENTQUESTIONNAIRETYPE"));
					//menuitems.Add(this.Language.TranslateSingle("ASSESSMENTRISK"));
					menuitems.Add(this.Language.TranslateSingle("PLANOFCAREOUTCOME"));
					//menuitems.Add(this.Language.TranslateSingle("PLANOFCAREINTERVENTIONS"));
					menuitems.Add(this.Language.TranslateSingle("PLANOFCARESETTING"));
					menuitems.Add(this.Language.TranslateSingle("PLANOFCAREPROVIDER"));
					menuitems.Add(this.Language.TranslateSingle("PLANOFCAREFREQUENCYUNIT"));
					//menuitems.Add(this.Language.TranslateSingle("PLANOFCAREDURATIONUNIT"));
					menuitems.Add(this.Language.TranslateSingle("PLANOFCAREDEFICITTYPE"));
					menuitems.Add(this.Language.TranslateSingle("PLANOFCAREDEFICITPRIORITY"));
					menuitems.Add(this.Language.TranslateSingle("PLANOFCAREDEFICITSTATUS"));
					menuitems.Add(this.Language.TranslateSingle("PLANOFCAREGOALREASON"));
					menuitems.Add(this.Language.TranslateSingle("PLANOFCAREGOALTEAM"));
					menuitems.Add(this.Language.TranslateSingle("PLANOFCAREGOALTYPE"));
					menuitems.Add(this.Language.TranslateSingle("DATATRIGGERSCOMPONENTCODES"));
					menuitems.Add(this.Language.TranslateSingle("DATATRIGGERSATTRIBUTECODES"));
					menuitems.Add(this.Language.TranslateSingle("DATATRIGGERSVALUECODES"));
					this.SelectedSideMenuItem = "grpCareManagement";
					break;
				case("DISEASEMANAGEMENT"):
					//menuitems.Add(this.Language.TranslateSingle("DISEASEMANAGEMENTTYPE"));
					this.SelectedSideMenuItem = "grpDiseaseManagement";
					break;
				case("MATERNICHECK"):
					menuitems.Add(this.Language.TranslateSingle("COMPLICATIONS"));
					this.SelectedSideMenuItem = "grpMaternicheck";
					break;
				case("MEDICATION"):
					menuitems.Add(this.Language.TranslateSingle("MEDICATIONSTATUS"));
					menuitems.Add(this.Language.TranslateSingle("NOTTAKINGREASON"));
					menuitems.Add(this.Language.TranslateSingle("TERMINATINGREASON"));					
					this.SelectedSideMenuItem = "grpMedications";
					break;
				case("WORKERSCOMPENSATION"):
					menuitems.Add(this.Language.TranslateSingle("BODYPART"));
					menuitems.Add(this.Language.TranslateSingle("INJURYTYPE"));
					menuitems.Add(this.Language.TranslateSingle("CLAIMSTATUS"));
					menuitems.Add(this.Language.TranslateSingle("CLAIMSUBSTATUS"));
					//menuitems.Add(this.Language.TranslateSingle("LAWTYPE"));
					this.SelectedSideMenuItem = "grpWorkersCompensation";
					break;
				case("CMSDMEQUIPMENT"):
					menuitems.Add(this.Language.TranslateSingle("EQUIPMENT"));
					menuitems.Add(this.Language.TranslateSingle("STATUS"));
					this.SelectedSideMenuItem = "grpCMSDMEquipment";
					break;
				case("ERCOUTCOME"):
					menuitems.Add(this.Language.TranslateSingle("OUTCOMETYPE"));
					menuitems.Add(this.Language.TranslateSingle("OUTCOMEINDICATOR"));
					menuitems.Add(this.Language.TranslateSingle("OUTCOMESUBINDICATOR"));
					menuitems.Add(this.Language.TranslateSingle("OUTCOMEREASON"));
					menuitems.Add(this.Language.TranslateSingle("OUTCOMEINDICATORSUBINDICATOR"));
					menuitems.Add(this.Language.TranslateSingle("OUTCOMECODE"));
					menuitems.Add(this.Language.TranslateSingle("OUTCOMERESULTFROM"));
					this.SelectedSideMenuItem = "grpERCOutcome";
					break;
				case("PHYSICIANREVIEW"):
					menuitems.Add(this.Language.TranslateSingle("PHYSICIANREVIEWDECISION"));
					menuitems.Add(this.Language.TranslateSingle("PHYSICIANREVIEWDECISIONRESAON"));
					menuitems.Add(this.Language.TranslateSingle("PHYSICIANREVIEWREQUESTREASON"));
					menuitems.Add(this.Language.TranslateSingle("PHYSICIANREVIEWREQUESTEDBY"));
					menuitems.Add(this.Language.TranslateSingle("PHYSICIANREVIEWROLE"));
					menuitems.Add(this.Language.TranslateSingle("PHYSICIANREVIEWTYPE"));
					menuitems.Add(this.Language.TranslateSingle("PHYSICIANREVIEWREQUESTSTATUS"));
					this.SelectedSideMenuItem = "grpPhysicianReview";
					break;
				case("PROBLEMEVENTREFERRAL"):
					menuitems.Add(this.Language.TranslateSingle("EVENTRESOLUTION"));
					menuitems.Add(this.Language.TranslateSingle("EVENTSOURCE"));
					menuitems.Add(this.Language.TranslateSingle("EVENTTYPE"));
					menuitems.Add(this.Language.TranslateSingle("REFERRALSCHEDULEDBY"));
					menuitems.Add(this.Language.TranslateSingle("REFERRALTYPE"));
					menuitems.Add(this.Language.TranslateSingle("REFERRALUNIT"));
					menuitems.Add(this.Language.TranslateSingle("REFERRALURGENCY"));
					menuitems.Add(this.Language.TranslateSingle("REFERRALAUTHORIZATIONDECISION"));
					menuitems.Add(this.Language.TranslateSingle("REFERRALROLE"));
					menuitems.Add(this.Language.TranslateSingle("REFERTOTYPE"));
					menuitems.Add(this.Language.TranslateSingle("PROBEVTREFCMSSTATUS"));
					menuitems.Add(this.Language.TranslateSingle("PROBLEMDESCRIPTION"));
					this.SelectedSideMenuItem = "grpProblemER";
					break;
				case("LETTERS"):
					menuitems.Add(this.Language.TranslateSingle("LETTERRECIPIENTTYPE"));
					menuitems.Add(this.Language.TranslateSingle("MATRIXTYPE"));
					this.SelectedSideMenuItem = "grpLetters";
					break;
				case("REPORTCRITERIA"):
					menuitems.Add(this.Language.TranslateSingle("REPORTCRITERIATYPE"));
					this.SelectedSideMenuItem = "grpReportCriteria";
					break;
				case("ADDITIONALS"):					
					menuitems.Add(this.Language.TranslateSingle("USERDEFINEDFIELDPRESENTATIONTYPE"));
					menuitems.Add(this.Language.TranslateSingle("MOMBABYCODES"));
					menuitems.Add(this.Language.TranslateSingle("REPORTUNIT"));
					menuitems.Add(this.Language.TranslateSingle("DMEUSEOPTION"));
					this.SelectedSideMenuItem = "grpAdditional";
					break;
			}			
 
			AltMenuList.DataSource = menuitems;
			AltMenuList.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{   
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion


		protected void AltMenuList_ItemDataBound(Object Sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem) 
			{  			
					LinkButton a = (LinkButton)e.Item.FindControl("menulink");
				try
				{
					a.Text = e.Item.DataItem.ToString();
				}
				catch(Exception ex)
				{
					string msg = ex.Message;
					a.Text = "error with message";
				}
			}
		}

		protected void menulink_click(object sender, System.EventArgs e)
		{
			this.CacheObject("SelectedSideMenuItem",this.SelectedSideMenuItem);
			if(this.Language.TranslateSingle("ORGANIZATIONTYPE") == (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(OrganizationType),this.Language.TranslateSingle("ORGANIZATIONTYPE"));
			else if((this.Language.TranslateSingle("ORGANIZATIONFOCUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(OrgFocusCode),this.Language.TranslateSingle("ORGANIZATIONFOCUS"));
			else if((this.Language.TranslateSingle("ORGANIZATIONCONTACTROLE"))== (((LinkButton)sender).Text))				
				CodeTypeFormForCodeWithNote.Redirect(typeof(Role),this.Language.TranslateSingle("ORGANIZATIONCONTACTROLE"));
		
			else if((this.Language.TranslateSingle("PLANTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PlanType),this.Language.TranslateSingle("PLANTYPE"));
			else if((this.Language.TranslateSingle("PLANHEDISTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PlanHEDISType),this.Language.TranslateSingle("PLANHEDISTYPE"));
			else if((this.Language.TranslateSingle("PLANHEDISPAYORTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PlanPayorHEDISType),this.Language.TranslateSingle("PLANHEDISPAYORTYPE"));
			else if((this.Language.TranslateSingle("PLANPRECERTNOTIFYUOFM"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PlanUnitOfMeasure),this.Language.TranslateSingle("PLANPRECERTNOTIFYUOFM"));
			else if((this.Language.TranslateSingle("PLANNOTETYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PlanNoteType),this.Language.TranslateSingle("PLANNOTETYPE"));
			else if((this.Language.TranslateSingle("PLANBENEFITSERVICETYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(BenefitServiceType),this.Language.TranslateSingle("PLANBENEFITSERVICETYPE"));
			else if((this.Language.TranslateSingle("PLANBENEFITSERVICECOVERAGE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CoveredType),this.Language.TranslateSingle("PLANBENEFITSERVICECOVERAGE"));
			else if((this.Language.TranslateSingle("MATERNICHECKINCENTIVE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PlanMaternichekIncentive),this.Language.TranslateSingle("MATERNICHECKINCENTIVE"));				
			else if((this.Language.TranslateSingle("MANAGEMENTSERVICESRATETYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ManagementServicesRateType),this.Language.TranslateSingle("MANAGEMENTSERVICESRATETYPE"));
			else if((this.Language.TranslateSingle("MANAGEMENTSERVICESRATEUOFM"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(BaseUnitOfMeasure),this.Language.TranslateSingle("MANAGEMENTSERVICESRATEUOFM"));
			else if((this.Language.TranslateSingle("MANAGEMENTSERVICESTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ManagementServiceType),this.Language.TranslateSingle("MANAGEMENTSERVICESTYPE"));
			else if((this.Language.TranslateSingle("NETWORKFOCUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(NetworkFocusType),this.Language.TranslateSingle("NETWORKFOCUS"));
			else if((this.Language.TranslateSingle("NETWORKTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(NetworkType),this.Language.TranslateSingle("NETWORKTYPE"));
			else if((this.Language.TranslateSingle("MEMBERLIVESSOURCE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(MemberLivesSource),this.Language.TranslateSingle("MEMBERLIVESSOURCE"));
			else if((this.Language.TranslateSingle("CONVERSIONUNITOFMEASURE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ConversionUnitOfMeasure),this.Language.TranslateSingle("CONVERSIONUNITOFMEASURE"));
				
//
			else if((this.Language.TranslateSingle("CALLSOURCE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(IntakeCallSource),this.Language.TranslateSingle("CALLSOURCE"));
			else if((this.Language.TranslateSingle("CALLREASON"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(IntakeCallReason),this.Language.TranslateSingle("CALLREASON"));
			else if((this.Language.TranslateSingle("CALLRESOLUTION"))== (((LinkButton)sender).Text))
				CodeTypeFormForStrLoopUp.Redirect(typeof(IntakeResolution),this.Language.TranslateSingle("CALLRESOLUTION"));

//			else if((this.Language.TranslateSingle("NOTSUBSCRIBEREXCEPTION"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof(),this.Language.TranslateSingle("NOTSUBSCRIBEREXCEPTION"));
			else if((this.Language.TranslateSingle("OTHERINSURANCETYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(InsuranceType),this.Language.TranslateSingle("OTHERINSURANCETYPE"));
			else if((this.Language.TranslateSingle("LANGUAGE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect("Language",this.Language.TranslateSingle("LANGUAGE"));
			else if((this.Language.TranslateSingle("SUBSCRIBERPATIENTRELATIONSHIP"))== (((LinkButton)sender).Text))
				CodeTypeWithOutNote.Redirect(typeof(RelationshipType),this.Language.TranslateSingle("SUBSCRIBERPATIENTRELATIONSHIP"));
			else if((this.Language.TranslateSingle("COVERAGESTATUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CoverageStatus),this.Language.TranslateSingle("COVERAGESTATUS"));
//			else if((this.Language.TranslateSingle("PANELTYPE"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof());
			else if((this.Language.TranslateSingle("PATIENTFOCUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PatientFocus),this.Language.TranslateSingle("PATIENTFOCUS"));
//			else if((this.Language.TranslateSingle("HEALTHCENTER"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof());
			else if((this.Language.TranslateSingle("UB92DISPOSION"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(UB92Disposition),this.Language.TranslateSingle("UB92DISPOSION"));
			else if((this.Language.TranslateSingle("UB92SOURCE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(UB92Source),this.Language.TranslateSingle("UB92SOURCE"));
			else if((this.Language.TranslateSingle("PATIENTCONTACTROLE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(Role),this.Language.TranslateSingle("PATIENTCONTACTROLE"));

			else if((this.Language.TranslateSingle("PROVIDERFOCUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ProviderFocusType),this.Language.TranslateSingle("PROVIDERFOCUS"));
//			else if((this.Language.TranslateSingle("PROVIDERLANGUAGE"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof());
			else if((this.Language.TranslateSingle("PROVIDERSERVICE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ProviderServiceType),this.Language.TranslateSingle("PROVIDERSERVICE"));
			else if((this.Language.TranslateSingle("PROVIDERSPECIALITY"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(Specialty),this.Language.TranslateSingle("PROVIDERSPECIALITY"));
			else if((this.Language.TranslateSingle("PROVIDERCONSULTINGROLE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(Role),this.Language.TranslateSingle("PROVIDERCONSULTINGROLE"));
			else if((this.Language.TranslateSingle("FACILITYFOCUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(FacilityFocusType),this.Language.TranslateSingle("FACILITYFOCUS"));
			else if((this.Language.TranslateSingle("FACILITYSERVICE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(FacilityLocationServiceType),this.Language.TranslateSingle("FACILITYSERVICE"));
			else if((this.Language.TranslateSingle("FACILITYTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(FacilityType),this.Language.TranslateSingle("FACILITYTYPE"));
			else if((this.Language.TranslateSingle("GROUPPRACTICEFOCUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(GroupPracticeFocusType),this.Language.TranslateSingle("GROUPPRACTICEFOCUS"));
			else if((this.Language.TranslateSingle("GROUPPRACTICESERVICE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(GroupPracticeServiceType),this.Language.TranslateSingle("GROUPPRACTICESERVICE"));
			else if((this.Language.TranslateSingle("GROUPPRACTICETYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(GroupPracticeType),this.Language.TranslateSingle("GROUPPRACTICETYPE"));
			else if((this.Language.TranslateSingle("CONTACTROLE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(Role),this.Language.TranslateSingle("CONTACTROLE"));

			else if((this.Language.TranslateSingle("NAMEPREFIX"))== (((LinkButton)sender).Text))
				CodeTypeWithOutNote.Redirect(typeof(NamePrefix),this.Language.TranslateSingle("NAMEPREFIX"));
			else if((this.Language.TranslateSingle("STATE"))== (((LinkButton)sender).Text))
				CodeTypeWithOutNote.Redirect(typeof(State),this.Language.TranslateSingle("STATE"));

			else if((this.Language.TranslateSingle("LOSPAYORGROUP"))== (((LinkButton)sender).Text))
				CodeTypeFormForStrLoopUp.Redirect(typeof(LengthOfStayPayorGroup),this.Language.TranslateSingle("LOSPAYORGROUP"));
			else if((this.Language.TranslateSingle("LOSPAYORREGION"))== (((LinkButton)sender).Text))
				CodeTypeFormForStrLoopUp.Redirect(typeof(LengthOfStayRegion),this.Language.TranslateSingle("LOSPAYORREGION"));
			else if((this.Language.TranslateSingle("DRGTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForStrLoopUp.Redirect(typeof(DRGType),this.Language.TranslateSingle("DRGTYPE"));
//			else if((this.Language.TranslateSingle("MAJORDIAGNOSTICCATEGORY"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof(DXType),this.Language.TranslateSingle("MAJORDIAGNOSTICCATEGORY"));
			else if((this.Language.TranslateSingle("SERVICECLASS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(DRGServiceClass),this.Language.TranslateSingle("SERVICECLASS"));
//			else if((this.Language.TranslateSingle("DIAGNOSTICGROUP"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof());

			else if((this.Language.TranslateSingle("ACTIVITYCOMPLETIONCODE"))== (((LinkButton)sender).Text))				
				CodeTypeFormForStrLoopUp.Redirect(typeof(ActivityCompletion),this.Language.TranslateSingle("ACTIVITYCOMPLETIONCODE"));
			else if((this.Language.TranslateSingle("ACTIVITYTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeTwoLoopUp.Redirect(typeof(ActivityType),this.Language.TranslateSingle("ACTIVITYTYPE"));
			else if((this.Language.TranslateSingle("ACTIVITYPRIMARYTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ActivityPrimaryType),this.Language.TranslateSingle("ACTIVITYPRIMARYTYPE"));
			else if((this.Language.TranslateSingle("ACTIVITYSUBTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ActivitySubType),this.Language.TranslateSingle("ACTIVITYSUBTYPE"));
			else if((this.Language.TranslateSingle("ACTIVITYTYPESUBTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeBraket.Redirect(typeof(ActivityTypeSubType),this.Language.TranslateSingle("ACTIVITYTYPESUBTYPE"),this.Language.TranslateSingle("ACTIVITYTYPE"),this.Language.TranslateSingle("ACTIVITYSUBTYPE"));
			else if((this.Language.TranslateSingle("NOTETYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(NoteType),this.Language.TranslateSingle("NOTETYPE"));
			else if((this.Language.TranslateSingle("NOTETERMINATIONREASON"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(NoteTerminationReason),this.Language.TranslateSingle("NOTETERMINATIONREASON"));

				
			else if((this.Language.TranslateSingle("CLINICALREVIEWDECISIONTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ClinicalReviewDecisionTypeCode),this.Language.TranslateSingle("CLINICALREVIEWDECISIONTYPE"));
			else if((this.Language.TranslateSingle("REVIEWDECISIONTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(ClinicalReviewDecisionType),this.Language.TranslateSingle("REVIEWDECISIONTYPE"));
			else if((this.Language.TranslateSingle("REVIEWDECISIONREASON"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ClinicalReviewDecisionReason),this.Language.TranslateSingle("REVIEWDECISIONREASON"));
			else if((this.Language.TranslateSingle("REVIEWDESCRIPTION"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ClinicalReviewDescription),this.Language.TranslateSingle("REVIEWDESCRIPTION"));
			else if((this.Language.TranslateSingle("REVIEWDURATIONUNITS"))== (((LinkButton)sender).Text))
				CodeTypeFormForStrLoopUp.Redirect(typeof(ClinicalReviewDurUnit),this.Language.TranslateSingle("REVIEWDURATIONUNITS"));
			else if((this.Language.TranslateSingle("REVIEWFREQUENCYUNITS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ClinicalReviewFreqUnit),this.Language.TranslateSingle("REVIEWFREQUENCYUNITS"));
			else if((this.Language.TranslateSingle("REVIEWTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ClinicalReviewType),this.Language.TranslateSingle("REVIEWTYPE"));
			else if((this.Language.TranslateSingle("REVIEWUNITS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeTwoLoopUp.Redirect(typeof(ClinicalReviewUnit),this.Language.TranslateSingle("REVIEWUNITS"));

			else if((this.Language.TranslateSingle("CMSACUITY"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CMSAcuity),this.Language.TranslateSingle("CMSACUITY"));
			else if((this.Language.TranslateSingle("CMSCATAGORY"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CMSCategory),this.Language.TranslateSingle("CMSCATAGORY"));
			else if((this.Language.TranslateSingle("CMSINTENSITY"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CMSIntensity),this.Language.TranslateSingle("CMSINTENSITY"));
			else if((this.Language.TranslateSingle("CMSPHASE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CMSPhase),this.Language.TranslateSingle("CMSPHASE"));
			else if((this.Language.TranslateSingle("CMSREASONFORCLOSING"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CaseClosedReason),this.Language.TranslateSingle("CMSREASONFORCLOSING"));
			else if((this.Language.TranslateSingle("CMSREASONFOROPENING"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CaseOpenReason),this.Language.TranslateSingle("CMSREASONFOROPENING"));
			else if((this.Language.TranslateSingle("CMSREASONFORCONTINUING"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CaseContinuedReason),this.Language.TranslateSingle("CMSREASONFORCONTINUING"));
			else if((this.Language.TranslateSingle("CMSSOURCE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CaseSource),this.Language.TranslateSingle("CMSSOURCE"));
			else if((this.Language.TranslateSingle("CMSTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CMSType),this.Language.TranslateSingle("CMSTYPE"));
//			else if((this.Language.TranslateSingle("CMSPROGRAM"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof());
//			else if((this.Language.TranslateSingle("CMSACTIONTYPE"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof());
			else if((this.Language.TranslateSingle("CMSRISKTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(CMSRisk),this.Language.TranslateSingle("CMSRISKTYPE"));
			else if((this.Language.TranslateSingle("CMSLEVELOFDISEASETYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(LevelOfDiseaseType),this.Language.TranslateSingle("CMSLEVELOFDISEASETYPE"));

			else if((this.Language.TranslateSingle("APPROVALPATIENTTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PatientAuthorizer),this.Language.TranslateSingle("APPROVALPATIENTTYPE"));
			else if((this.Language.TranslateSingle("OTHERAPPROVALTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ClientAuthorizer),this.Language.TranslateSingle("OTHERAPPROVALTYPE"));
//			else if((this.Language.TranslateSingle("ASSESSMENTGOALS"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof());
			else if((this.Language.TranslateSingle("ASSESSMENTLEVELOFDISEASE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(LevelOfDiseaseType),this.Language.TranslateSingle("ASSESSMENTLEVELOFDISEASE"));
			else if((this.Language.TranslateSingle("ASSESSMENTQUESTIONNAIRETYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(QuestionnaireType),this.Language.TranslateSingle("ASSESSMENTQUESTIONNAIRETYPE"));
//			else if((this.Language.TranslateSingle("ASSESSMENTRISK"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof(Risk),this.Language.TranslateSingle("ASSESSMENTRISK"));
			else if((this.Language.TranslateSingle("PLANOFCAREOUTCOME"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(POCGoalOutcome),this.Language.TranslateSingle("PLANOFCAREOUTCOME"));
//			else if((this.Language.TranslateSingle("PLANOFCAREINTERVENTIONS"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof(POCInterventionType),this.Language.TranslateSingle("PLANOFCAREINTERVENTIONS"));
			else if((this.Language.TranslateSingle("PLANOFCARESETTING"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(WCSetting),this.Language.TranslateSingle("PLANOFCARESETTING"));
			else if((this.Language.TranslateSingle("PLANOFCAREPROVIDER"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(WCProvider),this.Language.TranslateSingle("PLANOFCAREPROVIDER"));
			else if((this.Language.TranslateSingle("PLANOFCAREFREQUENCYUNIT"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ClinicalReviewFreqUnit),this.Language.TranslateSingle("PLANOFCAREFREQUENCYUNIT"));
//			else if((this.Language.TranslateSingle("PLANOFCAREDURATIONUNIT"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof());
			else if((this.Language.TranslateSingle("PLANOFCAREDEFICITTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(POCDeficitType),this.Language.TranslateSingle("PLANOFCAREDEFICITTYPE"));
			else if((this.Language.TranslateSingle("PLANOFCAREDEFICITPRIORITY"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithExtCode.Redirect(typeof(POCDeficitPriority),this.Language.TranslateSingle("PLANOFCAREDEFICITPRIORITY"));
			else if((this.Language.TranslateSingle("PLANOFCAREDEFICITSTATUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForStrLoopUp.Redirect(typeof(POCDeficitStatus),this.Language.TranslateSingle("PLANOFCAREDEFICITSTATUS"));
			else if((this.Language.TranslateSingle("PLANOFCAREGOALREASON"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(POCGoalReason),this.Language.TranslateSingle("PLANOFCAREGOALREASON"));
			else if((this.Language.TranslateSingle("PLANOFCAREGOALTEAM"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(POCGoalTerm),this.Language.TranslateSingle("PLANOFCAREGOALTEAM"));
			else if((this.Language.TranslateSingle("PLANOFCAREGOALTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(POCGoalType),this.Language.TranslateSingle("PLANOFCAREGOALTYPE"));				
			else if((this.Language.TranslateSingle("DATATRIGGERSCOMPONENTCODES"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ScoringLoadComponent),this.Language.TranslateSingle("DATATRIGGERSCOMPONENTCODES"));
			else if((this.Language.TranslateSingle("DATATRIGGERSATTRIBUTECODES"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(ScoringLoadAttribute),this.Language.TranslateSingle("DATATRIGGERSATTRIBUTECODES"));
			else if((this.Language.TranslateSingle("DATATRIGGERSVALUECODES"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ScoringLoadValue),this.Language.TranslateSingle("DATATRIGGERSVALUECODES"));

//			else if((this.Language.TranslateSingle("DISEASEMANAGEMENTTYPE"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof());

			else if((this.Language.TranslateSingle("COMPLICATIONS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(MaternichekComplication));

			else if((this.Language.TranslateSingle("MEDICATIONSTATUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(MedicationStatus),this.Language.TranslateSingle("MEDICATIONSTATUS"));
			else if((this.Language.TranslateSingle("NOTTAKINGREASON"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(MedicationStatusReason),this.Language.TranslateSingle("NOTTAKINGREASON"));
			else if((this.Language.TranslateSingle("TERMINATINGREASON"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(MedicationTerminationReason),this.Language.TranslateSingle("TERMINATINGREASON"));

			else if((this.Language.TranslateSingle("BODYPART"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(WCInjuryBodyPart),this.Language.TranslateSingle("BODYPART"));
			else if((this.Language.TranslateSingle("INJURYTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(WCInjuryType),this.Language.TranslateSingle("INJURYTYPE"));
			else if((this.Language.TranslateSingle("CLAIMSTATUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(InsuranceStatus),this.Language.TranslateSingle("CLAIMSTATUS"));
			else if((this.Language.TranslateSingle("CLAIMSUBSTATUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(InsuranceType),this.Language.TranslateSingle("CLAIMSUBSTATUS"));
//			else if((this.Language.TranslateSingle("LAWTYPE"))== (((LinkButton)sender).Text))
//				CodeTypeFormForCodeWithNote.Redirect(typeof());

			else if((this.Language.TranslateSingle("EQUIPMENT"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(WCDurableMedicalEquipment),this.Language.TranslateSingle("EQUIPMENT"));
			else if((this.Language.TranslateSingle("STATUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(CMSStatusType),this.Language.TranslateSingle("STATUS"));			

			else if((this.Language.TranslateSingle("OUTCOMETYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(OutcomeType),this.Language.TranslateSingle("OUTCOMETYPE"));
			else if((this.Language.TranslateSingle("OUTCOMEINDICATOR"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(OutcomeIndicator),this.Language.TranslateSingle("OUTCOMEINDICATOR"));
			else if((this.Language.TranslateSingle("OUTCOMESUBINDICATOR"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(OutcomeSubIndicator),this.Language.TranslateSingle("OUTCOMESUBINDICATOR"));
			else if((this.Language.TranslateSingle("OUTCOMEINDICATORSUBINDICATOR"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeBraket.Redirect(typeof(OutcomeIndicatorSubIndicator),this.Language.TranslateSingle("OUTCOMEINDICATORSUBINDICATOR"),this.Language.TranslateSingle("OUTCOMEINDICATOR"),this.Language.TranslateSingle("OUTCOMESUBINDICATOR"));				
			else if((this.Language.TranslateSingle("OUTCOMEREASON"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(OutcomeReason),this.Language.TranslateSingle("OUTCOMEREASON"));
			else if((this.Language.TranslateSingle("OUTCOMECODE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(OutcomeCode),this.Language.TranslateSingle("OUTCOMECODE"));
			else if((this.Language.TranslateSingle("OUTCOMERESULTFROM"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(OutcomeResultFrom),this.Language.TranslateSingle("OUTCOMERESULTFROM"));


			else if((this.Language.TranslateSingle("PHYSICIANREVIEWDECISION"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PhysicianReviewDecision),this.Language.TranslateSingle("PHYSICIANREVIEWDECISION"));
			else if((this.Language.TranslateSingle("PHYSICIANREVIEWDECISIONRESAON"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PhysicianDecisionReason),this.Language.TranslateSingle("PHYSICIANREVIEWDECISIONRESAON"));
			else if((this.Language.TranslateSingle("PHYSICIANREVIEWREQUESTREASON"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PhysicianReviewRequestReason),this.Language.TranslateSingle("PHYSICIANREVIEWREQUESTREASON"));
			else if((this.Language.TranslateSingle("PHYSICIANREVIEWREQUESTEDBY"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PhysicianReviewAppealRequestByType),this.Language.TranslateSingle("PHYSICIANREVIEWREQUESTEDBY"));
			else if((this.Language.TranslateSingle("PHYSICIANREVIEWROLE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(PhysicianDecisionRole),this.Language.TranslateSingle("PHYSICIANREVIEWROLE"));
			// FORK1.1
			else if((this.Language.TranslateSingle("PHYSICIANREVIEWTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForTwoStrLoopUp.Redirect(typeof(PhysicianReviewRequestDetailType),this.Language.TranslateSingle("PHYSICIANREVIEWTYPE"));
			else if((this.Language.TranslateSingle("PHYSICIANREVIEWREQUESTSTATUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForStrLoopUp.Redirect(typeof(PhysicianReviewRequestStatus),this.Language.TranslateSingle("PHYSICIANREVIEWREQUESTSTATUS"));
			//

			else if((this.Language.TranslateSingle("EVENTRESOLUTION"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(EventResolution),this.Language.TranslateSingle("EVENTRESOLUTION"));
			else if((this.Language.TranslateSingle("EVENTSOURCE"))== (((LinkButton)sender).Text))
				CodeTypeFormForStrLoopUp.Redirect(typeof(EventSource),this.Language.TranslateSingle("EVENTSOURCE"));
			else if((this.Language.TranslateSingle("EVENTTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForTwoStrLoopUp.Redirect(typeof(EventType),this.Language.TranslateSingle("EVENTTYPE"));
			else if((this.Language.TranslateSingle("REFERRALSCHEDULEDBY"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ReferralScheduledBy),this.Language.TranslateSingle("REFERRALSCHEDULEDBY"));
			else if((this.Language.TranslateSingle("REFERRALTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ReferralType),this.Language.TranslateSingle("REFERRALTYPE"));
			else if((this.Language.TranslateSingle("REFERRALUNIT"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(ReferralUnitType),this.Language.TranslateSingle("REFERRALUNIT"));
			else if((this.Language.TranslateSingle("REFERRALURGENCY"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ReferralUrgency),this.Language.TranslateSingle("REFERRALURGENCY"));
			else if((this.Language.TranslateSingle("REFERRALAUTHORIZATIONDECISION"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(ReferralAuthorizationDecision),this.Language.TranslateSingle("REFERRALAUTHORIZATIONDECISION"));
			else if((this.Language.TranslateSingle("REFERRALROLE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ReferralRole),this.Language.TranslateSingle("REFERRALROLE"));
			else if((this.Language.TranslateSingle("REFERTOTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ReferToType),this.Language.TranslateSingle("REFERTOTYPE"));
			else if((this.Language.TranslateSingle("PROBEVTREFCMSSTATUS"))== (((LinkButton)sender).Text))
				CodeTypeFormForStrLoopUp.Redirect(typeof(SystemStatus),this.Language.TranslateSingle("PROBEVTREFCMSSTATUS"));
			else if((this.Language.TranslateSingle("PROBLEMDESCRIPTION"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ProblemDescription),this.Language.TranslateSingle("PROBLEMDESCRIPTION"));

			else if((this.Language.TranslateSingle("LETTERRECIPIENTTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(LetterReceiverType),this.Language.TranslateSingle("LETTERRECIPIENTTYPE"));
			else if((this.Language.TranslateSingle("MATRIXTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeLoopUp.Redirect(typeof(MatrixType),this.Language.TranslateSingle("MATRIXTYPE"));


			else if((this.Language.TranslateSingle("REPORTCRITERIATYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(ReportCriteriaType),this.Language.TranslateSingle("REPORTCRITERIATYPE"));
			
			else if((this.Language.TranslateSingle("USERDEFINEDFIELDPRESENTATIONTYPE"))== (((LinkButton)sender).Text))
				CodeTypeFormForCodeWithNote.Redirect(typeof(UserDefinedFieldPresentationType),this.Language.TranslateSingle("USERDEFINEDFIELDPRESENTATIONTYPE"));
			else if(this.Language.TranslateSingle("MOMBABYCODES")== ((LinkButton)sender).Text)
				MomBabyCodeSearch.Redirect();
			else if(this.Language.TranslateSingle("REPORTUNIT")== ((LinkButton)sender).Text)
				CodeTypeFormForCodeWithNote.Redirect(typeof(ReportUnit),this.Language.TranslateSingle("REPORTUNIT"));
			else if(this.Language.TranslateSingle("DMEUSEOPTION")== ((LinkButton)sender).Text)
				CodeTypeFormForCodeWithNote.Redirect(typeof(DMEUseOption),this.Language.TranslateSingle("DMEUSEOPTION"));

		}
		protected override object SaveViewState()
		{
			ViewState["SelectedSideMenuItem"] = this.SelectedSideMenuItem;
			return base.SaveViewState ();
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
			this.SelectedSideMenuItem = (string)ViewState["SelectedSideMenuItem"];
		}
	}
}
