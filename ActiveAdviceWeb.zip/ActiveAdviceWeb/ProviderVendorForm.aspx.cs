using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for ProviderVendorForm.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.CMSMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("CMS,DataLayer")]
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	public class ProviderVendorForm : PatientBasePage
	{
		private CMSFacility cMSFacility;
		private CMSProvider cMSProvider;
		private CMSProviderCollection cMSProviders;
		private CMS cMS;
		private CMSFacilityCollection cMSFacilities;
		protected ProviderSelect FacilitySelect;
		protected ProviderSelect ProviderSelect1;
		private Problem problem;
		private PatientCoverage patientCoverage;
		private Patient patient;


		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProvider;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderGridHolder;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacility;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviders;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacilityGridHolder;
		protected NetsoftUSA.WebForms.OBButton wbtnAddProvider;
		protected NetsoftUSA.WebForms.OBButton wbtnAddVendor;
		protected NetsoftUSA.WebForms.OBButton wbtnSaveFacility;
		protected NetsoftUSA.WebForms.OBButton wbtnCancelFacility;
		protected NetsoftUSA.WebForms.OBButton wbtnCancelProvider;
		protected NetsoftUSA.WebForms.OBButton wbtnSaveProvider;
		protected NetsoftUSA.WebForms.OBButton wbtnDeleteProvider;
		protected NetsoftUSA.WebForms.OBButton wbtnDeleteFacility;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridFacilities;
		
		
		
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.wbtnSaveProvider.Click += new System.EventHandler(this.wbtnSaveProvider_Click);
			this.wbtnCancelProvider.Click += new System.EventHandler(this.wbtnCancelProvider_Click);
			this.wbtnAddProvider.Click += new System.EventHandler(this.wbtnAddProvider_Click);
			this.wbtnSaveFacility.Click += new System.EventHandler(this.wbtnSaveFacility_Click);
			this.wbtnCancelFacility.Click += new System.EventHandler(this.wbtnCancelFacility_Click);
			this.wbtnAddVendor.Click += new System.EventHandler(this.wbtnAddVendor_Click);
			this.wbtnDeleteProvider.Click += new System.EventHandler(this.wbtnDeleteProvider_Click);
			this.wbtnDeleteFacility.Click += new System.EventHandler(this.wbtnDeleteFacility_Click);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here

			// Facility select
			this.FacilitySelect.RebindControls(typeof(CMSFacility), "@FACILITY@", 
				ProviderSearcherType.Facility, null,
				"FacilityID", "FacilityLocationID", "FacilityTypeID", "FacilityLocationNetworkID", "FacilityNetworkStatusInt");

			
			//Provider select
			this.ProviderSelect1.RebindControls(typeof(CMSProvider), "@PROVIDER@", 
				ProviderSearcherType.Provider, null,
				"ProviderID", "ProviderLocationID", "ProviderSpecialtyID", "ProviderLocationNetworkID", "ProviderNetworkStatusInt");
		
			if (!IsPostBack)
				LoadData();
			else
			{
				cMS = (CMS)this.LoadObject(typeof(CMS));  // load object from cache
				cMSFacilities = (CMSFacilityCollection)this.LoadObject(typeof(CMSFacilityCollection));  // load object from cache
				cMSProviders = (CMSProviderCollection)this.LoadObject(typeof(CMSProviderCollection));  // load object from cache
				cMSProvider = (CMSProvider)this.LoadObject(typeof(CMSProvider));  // load object from cache
				cMSFacility = (CMSFacility)this.LoadObject(typeof(CMSFacility));  // load object from cache
				StartDate.Value = cMS.CaseStartDate;
			}
			problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
			patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
			patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
		}

		private void LoadData()
		{
			this.pnlFacility.Visible = false;
			this.pnlProvider.Visible = false;
			LoadDataForCMS();
			LoadDataForCMSFacilities();
			LoadDataForCMSProviders();
		}

		#region CMS
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMS CMS
		{
			get { return cMS; }
			set
			{
				cMS = value;
				this.CacheObject(typeof(CMS), cMS);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForCMS()
		{
			bool result = true;
			CMS cMS = null;
			//CMS cMS = new CMS(); // Use for quick debugging
			try
			{	// use any load method here
				cMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;
				if (cMS == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a CMS");
				//cMS.Load(16); // Use for quick debugging
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//cMS.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CMS = cMS;
			StartDate.Value = cMS.CaseStartDate;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(CMS cMS)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CMS", cMS);
			BasePage.Redirect("ProviderVendorForm.aspx");

		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForCMS()
		{
			try
			{	// data from controls to object
				
				cMS.SaveCMSFacilities();
				cMS.SaveCMSProviders();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			CMSFacilities = CMSFacilities;
			CMSProviders = CMSProviders;
			return true;
		}
		#endregion

		#region CMSFacilities
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMSFacilityCollection CMSFacilities
		{
			get { return cMSFacilities; }
			set
			{
				cMSFacilities = value;
				try
				{
					this.gridFacilities.UpdateFromCollection(cMSFacilities);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(CMSFacilityCollection), cMSFacilities);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForCMSFacilities()
		{
			bool result = true;
			CMSFacilityCollection cMSFacilities = new CMSFacilityCollection();
			try
			{	// use any load method here
				cMS.LoadCMSFacilities(false);
				cMSFacilities = cMS.CMSFacilities;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//cMSFacilities.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CMSFacilities = cMSFacilities;
			return result;
		}
		#endregion

		#region CMSProviders
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMSProviderCollection CMSProviders
		{
			get { return cMSProviders; }
			set
			{
				cMSProviders = value;
				try
				{
					gridProviders.UpdateFromCollection(cMSProviders);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(CMSProviderCollection), cMSProviders);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForCMSProviders()
		{
			bool result = true;
			CMSProviderCollection cMSProviders = new CMSProviderCollection();
			try
			{	// use any load method here
				cMS.LoadCMSProviders(false);
				cMSProviders = cMS.CMSProviders;	
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//cMSProviders.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CMSProviders = cMSProviders;
			return result;
		}
		#endregion

		#region CMSProvider
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMSProvider CMSProvider
		{
			get { return cMSProvider; }
			set
			{
				cMSProvider = value;
				try
				{
					this.UpdateFromObject(this.pnlProvider.Controls, cMSProvider);  // update controls for the given control collection
					// other object-to-control methods if any
					this.pnlProvider.Visible = true;
					this.pnlProviderGridHolder.Visible = false;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(CMSProvider), cMSProvider);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForCMSProvider()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlProvider.Controls, cMSProvider);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewCMSProvider()
		{
			bool result = true;
			CMSProvider cMSProvider = null; //new CMSProvider(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				cMSProvider = new CMSProvider(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.CMSProvider = cMSProvider;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForCMSProvider()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForCMSProvider())
					return false;
				CMSProviders.Add(this.cMSProvider);
				this.pnlProvider.Visible = false;
				this.pnlProviderGridHolder.Visible = true;
				CMSProviders = CMSProviders;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region CMSFacility
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMSFacility CMSFacility
		{
			get { return cMSFacility; }
			set
			{
				cMSFacility = value;
				try
				{
					this.UpdateFromObject(this.pnlFacility.Controls, cMSFacility);  // update controls for the given control collection
					// other object-to-control methods if any
					this.pnlFacility.Visible = true;
					this.pnlFacilityGridHolder.Visible = false;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(CMSFacility), cMSFacility);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForCMSFacility()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlFacility.Controls, cMSFacility);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewCMSFacility()
		{
			bool result = true;
			CMSFacility cMSFacility = null; //new CMSFacility(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				cMSFacility = new CMSFacility(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.CMSFacility = cMSFacility;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForCMSFacility()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForCMSFacility())
					return false;
				CMSFacilities.Add(this.cMSFacility); 
				this.pnlFacility.Visible = false;
				this.pnlFacilityGridHolder.Visible = true;
				CMSFacilities = CMSFacilities;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region UI Initialization and Events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.SetERCTabVisibilities();
			SetPageTabItemActive(TargetTabKey);
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.cMS);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@BACK@", "Cancel", false);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if(SaveDataForCMS())
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@PROVIDERVENDORS@");
		}

		private void wbtnAddProvider_Click(object sender, System.EventArgs e)
		{
			NewCMSProvider();
		}

		private void wbtnAddVendor_Click(object sender, System.EventArgs e)
		{
			NewCMSFacility();
		}

		private void wbtnSaveFacility_Click(object sender, System.EventArgs e)
		{
			SaveDataForCMSFacility();
		}

		private void wbtnCancelFacility_Click(object sender, System.EventArgs e)
		{
			this.pnlFacility.Visible = false;
			this.pnlFacilityGridHolder.Visible = true;
		}

		private void wbtnSaveProvider_Click(object sender, System.EventArgs e)
		{
			SaveDataForCMSProvider();
		}

		private void wbtnCancelProvider_Click(object sender, System.EventArgs e)
		{
			this.pnlProvider.Visible = false;
			this.pnlProviderGridHolder.Visible = true;
		}

		private void wbtnDeleteProvider_Click(object sender, System.EventArgs e)
		{
			if(this.gridProviders.SelectedRowIndex < 0)
				return;
			CMSProviders[gridProviders.SelectedRowIndex].MarkDel();
			CMSProviders = CMSProviders;
		}

		private void wbtnDeleteFacility_Click(object sender, System.EventArgs e)
		{
			if(this.gridFacilities.SelectedRowIndex < 0)
				return;
			CMSFacilities[gridFacilities.SelectedRowIndex].MarkDel();
			CMSFacilities = CMSFacilities;
		}
		#endregion
	}
}
