using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;


namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterQueueMaintanence.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseFaxQueue,DataLayer")]	
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@FAXLOGTITLE@")]
	public class FaxLogMaintenance : PatientBasePage
	{
		private BaseFaxQueueCollection faxQueues;
		private ArrayList pageStartStack = new ArrayList() ;

		BaseFaxQueue.FaxQueueType queueType = BaseFaxQueue.FaxQueueType.All;
		BaseFaxQueue.FaxQueueUserFilterType queueUserType = BaseFaxQueue.FaxQueueUserFilterType.ForUser;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;

		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDeleteSelection;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnRefresh;
		protected System.Web.UI.WebControls.RadioButtonList rblLogTypeFilter;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchPrevious;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchNext;
		protected System.Web.UI.WebControls.RadioButtonList rblUserFilter;

		#region Web Form Designer generated code
		override protected void OnInit(System.EventArgs e)
		{
			this.rblLogTypeFilter.SelectedIndexChanged += new System.EventHandler(this.rblLogTypeFilter_SelectedIndexChanged);
			this.rblUserFilter.SelectedIndexChanged += new System.EventHandler(this.rblUserFilter_SelectedIndexChanged);
			this.wbtnRefresh.Click += new System.EventHandler(this.wbtnRefresh_Click);
			this.wbtnDeleteSelection.Click += new System.EventHandler(this.wbtnDeleteSelection_Click);
			this.butSearchPrevious.Click += new System.EventHandler(this.butSearchPrevious_Click);
			this.butSearchNext.Click += new System.EventHandler(this.butSearchNext_Click);


			//this.grid.DisplayLayout.StationaryMargins = StationaryMargins.HeaderAndFooter;
			this.grid.PagingColumns = new string[] { "TimeUpdated", "User"};
			this.grid.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(grid_RowBoundToDataObject);
			this.grid.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);

			// finally add bind event for client
			InitializeComponent();

			this.Load += new System.EventHandler(this.Page_Load);

			base.OnInit(e);
		}
		

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{

			if (!this.IsPostBack)
			{
				InitBindQueueLogTypeFilterOptions();
				InitBindQueueUserTypeFilterOptions();
				LoadDataForFaxQueues();
				SetUIState(); 
				this.pageStartStack = null;			// no paging if first access
			}
			else
			{
				this.pageStartStack = (ArrayList)(this.LoadObject("FaxPageStartStack"));
			}		
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect()
		{
			BasePage.PushCurrentCallingPage();
			BasePage.Redirect("FaxLogMaintenance.aspx");
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			listbar.AddItem("@LETTERS@", "Letters");
		}

		public void OnSubNavigationItemClick_Letters(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("LetterMaintenance.aspx");
		}


		#region UI initialization and events
		private void SetUIState()
		{
			this.wbtnRefresh.Visible = true;
			this.wbtnDeleteSelection.Visible = true;
			this.wbtnRefresh.Enabled = true;
			this.wbtnDeleteSelection.Enabled = this.grid.Rows.Count > 0?  true:false;
			this.butSearchNext.Enabled = faxQueues != null && faxQueues.Count >= BaseFaxQueueCollection.MAXRECORDS;
			this.butSearchPrevious.Enabled = this.grid.HasAnyPreviousPages;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			this.wbtnRefresh.Visible = grid.Rows.Count > 0;
			this.wbtnDeleteSelection.Visible = grid.Rows.Count > 0;

			//Debug.WriteLine(this.wbtnDeleteSelection.Attributes["onclick"]);
			//this.wbtnDeleteSelection.Attributes["onclick"] = "OnDeleteBtnSubmit();";
		}


		private void grid_RowBoundToDataObject(object sender, RowBindingEventArgs e)
		{
			BaseFaxQueue qItem = e.data as BaseFaxQueue;
			UltraGridCell cell = null;
			cell = e.row.Cells.FromKey("Review");
			if (cell != null)
			{
						string strRFTFile = "";
						char[] token1 = {'.'};
						string[] s1 = qItem.LogFile.Split(token1);
						if (s1.Length >= 2) 
						{
							strRFTFile = s1[0] + ".rtf";
						}
						cell.Text = String.Format("<a href=\"#\" onclick=\"javascript:ReviewLetterInFaxQueue('{0}'); return false;\">{1}</a>", 
									strRFTFile, Language.Translate("Review"));
			}

		}


		private void InitBindQueueLogTypeFilterOptions()
		{
			rblLogTypeFilter.Items.Clear();

			rblLogTypeFilter.Items.Add(new ListItem("All", SelectableFaxQueue.FaxQueueType.All.ToString()));
			rblLogTypeFilter.Items.Add(new ListItem("Success", SelectableFaxQueue.FaxQueueType.Succesful.ToString()));
			rblLogTypeFilter.Items.Add(new ListItem("Error", SelectableFaxQueue.FaxQueueType.Error.ToString()));
			rblLogTypeFilter.SelectedIndex = 0;
		}

		private void InitBindQueueUserTypeFilterOptions()
		{
			rblUserFilter.Items.Clear();

			rblUserFilter.Items.Add(new ListItem("User", SelectableFaxQueue.FaxQueueUserFilterType.ForUser.ToString()));
			rblUserFilter.Items.Add(new ListItem("All", SelectableFaxQueue.FaxQueueUserFilterType.ForAll.ToString()));
			rblUserFilter.SelectedIndex = 0;
		}


		private BaseFaxQueue.FaxQueueType SelectedQueueTypeFilter
		{
			get { return (BaseFaxQueue.FaxQueueType)Enum.Parse(typeof(BaseFaxQueue.FaxQueueType), this.rblLogTypeFilter.SelectedValue, true); }
		}

		private BaseFaxQueue.FaxQueueUserFilterType SelectedUserTypeFilter
		{
			get { return (BaseFaxQueue.FaxQueueUserFilterType)Enum.Parse(typeof(BaseFaxQueue.FaxQueueUserFilterType), this.rblUserFilter.SelectedValue, true); }
		}
		

		#region event handlers

		private void rblLogTypeFilter_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			LoadDataForFaxQueues();
			SetUIState(); 
		}

		private void rblUserFilter_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			LoadDataForFaxQueues();
			SetUIState(); 
		}


		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (!((WebGrid)sender).Columns.Exists("Review"))
				((WebGrid)sender).AddColumnWithButtonLook("Review", "Review", 2);
		}


		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			string colName = e.Cell.Key;
			switch (colName)
			{
				case "ViewLog":
				{
					//object[] pk = grid.GetPKFromCellEvent(e);
					break;
				}
				case "Review":
				{
					break;
				}
				default:
					break;
			}
		}
		#endregion


		
		/// <summary>
		/// 1) Creates sorted collection of letters to be printed from selected letters
		/// 2) Saves collection into [LetterPrintedQueue] table with assigned BatchNumber & BatchRunDate
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// 
		private void wbtnRefresh_Click(object sender, System.EventArgs e)
		{
			LoadDataForFaxQueues();
			SetUIState(); 
		}

		private void wbtnDeleteSelection_Click(object sender, System.EventArgs e)
		{
			// load from cache
			faxQueues = (BaseFaxQueueCollection)this.LoadObject(typeof(BaseFaxQueueCollection));  // load object from cache

			// read controls first
			if (!ReadControlsForFaxQueue())
				return;

			try 
			{
				this.faxQueues.DeleteSelected();
			}
			catch (Exception exp)
			{
				this.RaisePageException(exp);  // notify the page about the error
			}
			this.FaxQueues = this.faxQueues;

			bool bEnabled = this.butSearchNext.Enabled;
			SetUIState();
			this.butSearchNext.Enabled = bEnabled;
		}


		private void butSearchNext_Click(object sender, System.EventArgs e)
		{
			SearchNext(PagingDirection.NextPage);
			SetUIState();
		}

		private void butSearchPrevious_Click(object sender, System.EventArgs e)
		{
			SearchNext(PagingDirection.PreviousPage);
			SetUIState();
		}


		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
		}
		
		#endregion

		/// <summary>
		///  read collection from grid
		/// </summary>
		/// <returns></returns>
		private bool ReadControlsForFaxQueue()
		{
			try
			{	//customize this method for this specific page
				this.grid.UpdateToCollection(this.faxQueues);	// grid-to-collection
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}
		
		#region faxQueues
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BaseFaxQueueCollection FaxQueues
		{
			get { return faxQueues; }
			set
			{
				faxQueues = value;
				try
				{
					this.grid.KeepPKs = false;
					grid.UpdateFromCollection(faxQueues);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject(typeof(BaseFaxQueueCollection), faxQueues);
				this.CacheObject("FaxPageStartStack",this.pageStartStack);
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForFaxQueues()
		{
			try
			{	//customize this method for this specific page
				grid.UpdateToCollection(faxQueues);	// grid-to-collection
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}


		/// <summary>
		///  create new empty fax queues
		/// </summary>
		/// 
		public void NewFaxQueues()
		{
			BaseFaxQueueCollection faxQueues = null;
			try
			{
				faxQueues = FaxQueueClassFactory.CreateFaxQueueCollection();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
			this.FaxQueues = faxQueues;
		}
		

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForFaxQueues()
		{
			bool result = true;
			BaseFaxQueueCollection faxQueues = null;
			grid.PageStartStack = this.pageStartStack;
			grid.ClearValuesForPageStart();
			try
			{	// use any load method here
				faxQueues = FaxQueueClassFactory.CreateFaxQueueCollectionAndLoad(
							DateTime.Now, "",
							SelectedQueueTypeFilter, 
							SelectedUserTypeFilter, 
							AASecurityHelper.UserName);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
			}
			this.FaxQueues = faxQueues;
			return result;
		}


		public bool SearchNext(PagingDirection direction)
		{
			bool result = true;
			grid.PageStartStack = this.pageStartStack;
			BaseFaxQueueCollection faxQueues = null;
			try
			{	// use any load method here
				object [] valuesForNextPageStart = grid.GetStartValuesForPrevOrNextPage(direction);
				if (valuesForNextPageStart == null)	// no more pages.
					return false;
				faxQueues = FaxQueueClassFactory.CreateFaxQueueCollectionAndLoad(
					(DateTime)(valuesForNextPageStart[0]), (string)(valuesForNextPageStart[1]),
					SelectedQueueTypeFilter, 
					SelectedUserTypeFilter, 
					AASecurityHelper.UserName);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
			}

			this.FaxQueues = faxQueues;
			return result;
		}


		#endregion

	}
}

