using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{

	/// <summary>
	/// Benefit Service List data entry form.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PlanMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BenefitService,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(BenefitServicesSearch))]
	[SelectedMenuItem("BenefitServices")]						//define the active menu item in side menu
	[SelectedMainMenuItem("MPlan")]						//defines active menu item in main navigation
	[PageTitle("@BENEFITSERVICEPAGETITLE@")]
	public class BenefitServicesForm : PlanBasePage
	{
		private BenefitService benefitService;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldListId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ListId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbListId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanDenyNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlBenefSvc;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlBenefSvcNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlBenefSvcItem;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBValidator vldNote;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSaveBenefSvcItem;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBenefitServiceTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo BenefitServiceTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldBenefitServiceTypeId;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadDataForBenefitService();			// Use load data method for data entry forms
			}
			else
			{
				// always load all server side objects from the cache
				//col = (MORGCollection)this.LoadObject(typeof(MORGCollection));	// This would reload from cache
				// searchers must cache and read from a different key than the class name
				//morgSearcher = (MORG)this.LoadObject("MORGSearcher");
				benefitService = (BenefitService)this.LoadObject(typeof(BenefitService));
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		//public static void Redirect()
		//{
		//	BasePage.Redirect("BenefitServicesForm.aspx");
		//}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Details")
			{
				if(!this.IsPopup)
				{
					toolbar.AddButton(PlanMessages.MessageIDs.ADDNEWRECORD, "AddNewBenefSvc");
					toolbar.AddButton("@CLONE@", "Clone");
				}
				toolbar.AddButton(PlanMessages.MessageIDs.ITEMS /* BENEFITSERVICEITEMS */, "BenefitSvcItems");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			if(!this.IsPopup)
				toolbar.AddButton("@SAVERECORD@", "Save");
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		public void OnToolbarButtonClick_Clone(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.ReadControlsForBenefitService())
			{
				this.BenefitService = benefitService.CreateCopyOfBenefitService();
			}
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForBenefitService())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@BENEFITSERVICE@");
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BenefitService BenefitService
		{
			get { return benefitService; }
			set
			{
				benefitService = value;
				try
				{
					this.UpdateFromObject(pnlBenefSvc.Controls, benefitService);  // update controls for the given control collection
					this.UpdateFromObject(pnlBenefSvcNote.Controls, benefitService);  // update controls for the given control collection
					
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(BenefitService), benefitService);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForBenefitService()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlBenefSvc.Controls, benefitService);  // update controls for the given control collection
				this.UpdateToObject(pnlBenefSvcNote.Controls, benefitService);  // update controls for the given control collection
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewBenefitService()
		{
			bool result = true;
			BenefitService benefitService = new BenefitService(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				//benefitService.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.BenefitService = benefitService;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForBenefitService()
		{
			bool result = true;
			BenefitService benefitService = null;
			try
			{	// use any load method here
				//result = benefitService.Load();
				benefitService = GetParamOrGetFromCache("BenefitService", typeof(BenefitService) ) as BenefitService;
				if (benefitService == null)
					return NewBenefitService();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//benefitService.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.BenefitService = benefitService;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(BenefitService benefitService)
		{
			BasePage.PushParam("BenefitService", benefitService);

			BasePage.Redirect("BenefitServicesForm.aspx");
		}

		public static void Redirect(int benefitServiceId)
		{
			BenefitService benefitService = new BenefitService();
			if (!benefitService.Load(benefitServiceId))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@BENEFITSERVICE@");
			Redirect(benefitService);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForBenefitService()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForBenefitService())
					return false;
				benefitService.Save(); // update or insert to db
				BenefitServiceCollection.ClearFromCache();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		// Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_AddNewBenefSvc(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewBenefitService();
		}

		public void OnToolbarButtonClick_BenefitSvcItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BenefitServiceItemsSearch.Redirect(benefitService);	// new
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.benefitService);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.RenderClientFunctions(pnlBenefSvc.Controls, benefitService, "OnCalcBenefitSvc");

			this.SetPageTabToolbarItemEnabled("BenefitSvcItems", !benefitService.IsNew);
			this.SetPageTabToolbarItemEnabled("Clone", !benefitService.IsNew);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			
			if(!this.IsPopup)
				this.CheckForDirty(this.benefitService);
		}
	}
}
