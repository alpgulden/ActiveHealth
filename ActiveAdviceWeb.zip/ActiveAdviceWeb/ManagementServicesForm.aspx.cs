using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PlanMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("ManagementService,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(PlanComponents))]
	[SelectedMenuItem("Details")]
	[PageTitle("@MANAGEMENTSVCPAGETITLE@")]
	public class ManagementServicesForm : PlanBasePage
	{
		private ManagementServiceItem managementServiceItem;
		private ManagementService managementService;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel3;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNote;
		protected System.Web.UI.WebControls.Button butClearSharedCache;
		protected NetsoftUSA.InfragisticsWeb.WebValidator OBValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator OBValidator2;
		protected System.Web.UI.WebControls.Button butNewFocus;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridServiceItems;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlServiceItems;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbManagementServicesRateTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbManagementServiceTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbManagementServiceItemId;
		protected NetsoftUSA.WebForms.OBCheckBox Spouses;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSpouses;
		protected NetsoftUSA.WebForms.OBCheckBox Retirees;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRetirees;
		protected NetsoftUSA.WebForms.OBCheckBox Insurers;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInsurers;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlServiceItemDetails;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlServiceItemConversion;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBaseUnitOfMeasureId;
		protected NetsoftUSA.WebForms.OBCheckBox Billable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBillable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRate;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Rate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDivider;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Divider;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDivider;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMultiplier;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Multiplier;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMultiplier;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldConversionUnitOfMeasureId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ConversionUnitOfMeasureId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbConversionUnitOfMeasureId;
		protected NetsoftUSA.InfragisticsWeb.WebButton butCancelServiceItem;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSaveServiceItem;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldManagementServiceItemId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ManagementServiceItemId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldManagementServiceTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ManagementServiceTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldManagementServicesRateTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ManagementServicesRateTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldBaseUnitOfMeasureId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo BaseUnitOfMeasureId;
		protected NetsoftUSA.WebForms.OBTextBox OBTextBox1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlServiceItemNote;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.WebForms.OBCheckBox Dependents;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDependents;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected System.Web.UI.WebControls.Button butSave;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected UserDefined UserDefined1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			UserDefined1.ReloadContext("ManagementServiceItem", managementServiceItem, true /*createcontrols*/); // short usage - always call
			if(!UserDefined1.HasFields())
				this.pnlUserDefined.Visible = false;
			// Put user code to initialize the page here
			if (!this.IsPostBack)
				this.LoadData();			// Load data is the actual data loading method
			else
			{
				managementService = (ManagementService)this.LoadObject(typeof(ManagementService));	// This would reload from cache
				managementServiceItem = (ManagementServiceItem)this.LoadObject(typeof(ManagementServiceItem));	// This would reload from cache
			}
				
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject(typeof(ManagementService), null);
			this.CacheObject(typeof(ManagementServiceItem), null);
			base.NavigateAway ();
		}


		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(ManagementService managementService)
		{
			BasePage.PushParam("ManagementService", managementService);
			BasePage.Redirect("ManagementServicesForm.aspx");
		}

		/*public static void Redirect(int organizationID)
		{
			MORG morg = new MORG();
			if (!morg.Load(organizationID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@ORGANIZATION@");
			BasePage.PushParam("MORG", morg);
			BasePage.Redirect("MORGForm.aspx");
		}*/


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			this.gridServiceItems.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridServiceItems_DblClick);
			gridServiceItems.ClickCellButton +=new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(gridServiceItems_ClickCellButton);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSaveServiceItem.Click += new System.EventHandler(this.butSaveServiceItem_Click);
			this.butCancelServiceItem.Click += new System.EventHandler(this.butCancelServiceItem_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		/*private void RenderSummary()
		{
			this.RenderSummaryForObjects(this.obj, this.obj2);
		}*/

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			if (!this.IsPopup)
				toolbar.AddButton("@SAVERECORD@", "Save");
			toolbar.AddButton("@CANCEL@", "Cancel");

		}


		public override void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick (toolbar, button);

			// if (button.Key == "Save")
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@MANAGEMENTSVCS@");
			}
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			if (this.IsPopup)
				return;

			switch (tab.Key)
			{
				case "ServiceItems":
					toolbar.AddButton("@ADDNEWRECORD@", "AddNewServiceItem", false, false);
					toolbar.AddButton("@CLONE@", "Clone");
					break;
				case "Note":
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewServiceItem(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			ManagementServiceItem serviceItem = new ManagementServiceItem(true);
			this.ManagementServiceItem = serviceItem;
		}

		public void OnToolbarButtonClick_Clone(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.ReadControlsForManagementServiceItem())
			{
				this.ManagementServiceItem = managementServiceItem.CreateCopyOfManagementServiceItem();
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.RenderClientFunctions(pnlServiceItemDetails.Controls, this.managementServiceItem, "OnCalcServiceItemDetails");
			this.SetPageTabToolbarItemEnabled("Clone", managementServiceItem != null && !managementServiceItem.IsNew);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ManagementService ManagementService
		{
			get { return managementService; }
			set
			{
				managementService = value;
				try
				{
					this.UpdateFromObject(pnlNote.Controls, managementService);  // update controls for the given control collection

					// service items
					managementService.LoadManagementServiceItems(false);
					managementService.ManagementServiceItems.FilterActive = false;
					gridServiceItems.UpdateFromCollection(managementService.ManagementServiceItems);

					ManagementServiceItem = null;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(ManagementService), managementService);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlNote.Controls, managementService);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewManagementService()
		{
			bool result = true;
			ManagementService managementService = new ManagementService(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				//managementService.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.ManagementService = managementService;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			ManagementService managementService = null;
			try
			{	// use any load method here
				Plan plan = this.GetParamOrGetFromCache("Plan", typeof(Plan)) as Plan;
				managementService = this.GetParam("ManagementService") as ManagementService;
				if (managementService == null && plan != null)	// get from current plan's context
					managementService = plan.ManagementService;
				if (managementService == null)
					this.SetPageMessage("A management service must have been given to this page for edit!", EnumPageMessageType.Error);
					//managementService = new ManagementService(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//managementService.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.ManagementService = managementService;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				if (managementService.IsNew)
				{
					// we have to do it like this here. because some management plans were imported with managementservice id = null
					//managementService.Save(); // save the management service and it's items
					//managementService.ParentPlan.ManagementServiceId = managementService.ManagementServiceId;
					managementService.ParentPlan.Save();	// update the plan too
				}
				else
					managementService.Save(); // save the management service and it's items

				gridServiceItems.UpdatePKsFromCollection(managementService.ManagementServiceItems);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ManagementServiceItem ManagementServiceItem
		{
			get { return managementServiceItem; }
			set
			{
				managementServiceItem = value;
				try
				{
					pnlServiceItemDetails.Visible = managementServiceItem != null;
					pnlServiceItemNote.Visible = pnlServiceItemDetails.Visible;
					pnlServiceItemConversion.Visible = managementServiceItem != null;
					pnlServiceItems.Visible = managementServiceItem == null;
					if(UserDefined1.HasFields())
						pnlUserDefined.Visible = managementServiceItem != null;
					this.UpdateFromObject(pnlServiceItemDetails.Controls, managementServiceItem);  // update controls for the given control collection
					this.UpdateFromObject(pnlServiceItemNote.Controls, managementServiceItem);  // update controls for the given control collection
					this.UpdateFromObject(pnlServiceItemConversion.Controls, managementServiceItem);  // update controls for the given control collection
					
					UserDefined1.ReloadContext("ManagementServiceItem",managementServiceItem,false);
					
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(ManagementServiceItem), managementServiceItem);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForManagementServiceItem()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlServiceItemDetails.Controls, managementServiceItem);  // update controls for the given control collection
				this.UpdateToObject(pnlServiceItemNote.Controls, managementServiceItem);  // update controls for the given control collection
				this.UpdateToObject(pnlServiceItemConversion.Controls, managementServiceItem);  // update controls for the given control collection
				// other control-to-object methods if any
				UserDefined1.UserDefinedValue = managementServiceItem.UserDefined;
				UserDefined1.ReadControls();
			
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewManagementServiceItem()
		{
			bool result = true;
			ManagementServiceItem managementServiceItem = new ManagementServiceItem(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				//managementServiceItem.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.ManagementServiceItem = managementServiceItem;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForManagementServiceItem()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForManagementServiceItem())
					return false;
				if (managementServiceItem.ParentManagementServiceItemCollection == null)
				{
					managementService.ManagementServiceItems.Add(managementServiceItem);
				}
				ManagementServiceItem = null;
				gridServiceItems.UpdateFromCollection(managementService.ManagementServiceItems);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void butSaveServiceItem_Click(object sender, System.EventArgs e)
		{
			SaveDataForManagementServiceItem();
		}

		private void butCancelServiceItem_Click(object sender, System.EventArgs e)
		{
			ManagementServiceItem = null;
		}

		private void gridServiceItems_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			int index = gridServiceItems.GetColIndexFromClickEvent(e);
			if (index < 0)
				return;
			ManagementServiceItem mgmtSvcItem = managementService.ManagementServiceItems[index];
			this.ManagementServiceItem = mgmtSvcItem;
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.managementService.ParentPlan, this.managementServiceItem);
		}

		private void gridServiceItems_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Edit")
			{
				int index = gridServiceItems.GetColIndexFromCellEvent(e);
				if (index < 0)
					return;

				ManagementServiceItem mgmtSvcItem = managementService.ManagementServiceItems[index];
				this.ManagementServiceItem = mgmtSvcItem;
			}
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();

			this.CheckForDirty(this.managementService, this.managementService.ManagementServiceItems);
		}


	}
}
