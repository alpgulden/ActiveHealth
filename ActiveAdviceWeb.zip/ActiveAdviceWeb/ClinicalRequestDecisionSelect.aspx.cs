using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Clinical Review summary page.
	/// Displays Request/Decision totals grouped by either Approved/Denied status or Decision Type.
	/// </summary>
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.EVENTS)]

	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("ClinicalReviewRequest,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[PageTitle("@CLINICALREQDECSEL@")]
	public class ClinicalRequestDecisionSelect : BasePage
	{
		//private Event eventObj;

		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlClinicalReview;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected ClinicalReviewControl CRev;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			// Always get the e/r/c from context.
			//eventObj = (Event)this.LoadObject(typeof(Event));
			CRev.SelectMode = true;
			if (!this.IsPostBack)
			{
				LoadData();
			}
			else
			{
				CRev.ReloadContext();
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();

			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.PrintablePage = true;
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		public bool LoadData()
		{
			bool result = true;

			try
			{	
				CRev.ReloadContext();		// must be called after caching the context
				CRev.LoadDataForClinicalReviewRequests();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//clinicalReviewRequests.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			
			return result;
		}

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Select")
			{
				// Select tab specific toolbar buttons
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@CLOSE@", "Close", false).Item.TargetURL = "javascript:window.close()";
			toolbar.AddButton("@SELECT@", "Select", false).Item.TargetURL = "javascript:selectAndClose()";
		}

	}
}
