using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for PackingListSummary.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.CMSMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("PackingListItemSent,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[PageTitle("@PLISUMMARYPAGETITLE@")]
	public class PackingListSummary : BasePage
	{
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSummary;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFooter;
		protected NetsoftUSA.WebForms.OBLabel lbFooterInfo;

		private CMS parentCMS;
		private DateTime dtPrintedDate;

		private void Page_Load(object sender, System.EventArgs e)
		{		
			LoadDataForCMS();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModelessDialog;
			this.Load += new System.EventHandler(this.Page_Load);
			this.PrintPreviewMode = true;

		}
		#endregion

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			
			toolbar.AddButton("@PRINT@", "Printing", false).Item.TargetURL = "javascript:window.print();";
			toolbar.AddButton("@CLOSE@", "Close", false).Item.TargetURL = "javascript:window.close()";
			
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public void LoadDataForCMS()
		{
			try
			{	
				parentCMS  = (CMS)this.LoadObject(typeof(CMS));
				if (parentCMS != null)
				{
					// Load Sent Items of Latest Date only
					PackingListItemSentCollection col = new PackingListItemSentCollection();
					col = (PackingListItemSentCollection)this.LoadObject("RecentlyPrintedItems");  // load object from cache
					dtPrintedDate = col[0].CreationTime;
					grid.UpdateFromCollection(col);		
				}
				else 
					throw new ActiveAdviceException("CMS Object is required");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			if(this.parentCMS == null)
				return;
	
			this.parentCMS.Patient.displaySummaryForPLI = true;		//alters execution of	FillSummaryText(SummaryWriter writer)
			pageSummary.RenderObjects(this.parentCMS.Patient);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.lbFooterInfo.Text = "This list was printed on:    " + dtPrintedDate.ToLongDateString() + " by " + AASecurityHelper.UserName +
									 "<br><br>&nbsp;  Materials mailed on:    _____/______/_______ ";
		}
	}
}
