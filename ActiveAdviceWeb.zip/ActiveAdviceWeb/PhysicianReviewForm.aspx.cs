using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("PRRequest,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[PageTitle("@PHYSICIANREVIEWPAGETITLE@")]
	public class PhysicianReviewForm : PatientBasePage
	{
		protected ProviderSelect ProviderSelect;
		protected ProviderSelect RequestLiteProviderSelect;
		protected UserDefined UserDefined1;
		protected UserDefined UserDefined2;
		protected UserDefined UserDefined3;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBRadioButtonBox radAllOrSpecific;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlRequests;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBButton butAddNewReview;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderDecisions;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator4;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel6;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlRequestLite;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel lbNumRequest;
		protected NetsoftUSA.WebForms.OBTextBox txtNumRequest;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPRRequestID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PRRequestID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhysicianReviewRequestReasonID;
		protected NetsoftUSA.WebForms.OBComboBox PhysicianReviewRequestReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPhysicianReviewRequestReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhysicianReviewRequestStatusID;
		protected NetsoftUSA.WebForms.OBComboBox PhysicianReviewRequestStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPhysicianReviewRequestStatusID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit EventID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEndDate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhysicianReviewRequestDetailTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PhysicianReviewRequestDetailTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPhysicianReviewRequestDetailTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel8;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator7;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel7;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator6;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel11;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator10;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel10;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator9;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel9;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator8;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel14;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator13;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel13;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator12;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel12;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator11;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReview;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderSelect;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhysicianDecisionRoleID;
		protected NetsoftUSA.WebForms.OBComboBox PhysicianDecisionRoleID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPhysicianDecisionRoleID;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.WebForms.OBComboBox DecPhysicianReviewDecisionID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDecPhysicianReviewDecisionID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhysicianDecisionReasonID;
		protected NetsoftUSA.WebForms.OBComboBox PhysicianDecisionReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPhysicianDecisionReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DecStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDecStartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DecEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDecEndDate;
		protected NetsoftUSA.WebForms.OBCheckBox SpokeToProvider;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit SpokeToProviderDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.WebForms.OBCheckBox ExplainedAppealsProcess;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ExplainedAppealsProcessDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator3;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMinutesSpent;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MinutesSpent;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMinutesSpent;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDecisionConfirmation;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTransactionNumber;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit TransactionNumber;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTransactionNumber;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCheckNumber;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CheckNumber;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCheckNumber;
		protected NetsoftUSA.WebForms.OBCheckBox GeneratePayable;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit GeneratePayableDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGeneratePayableDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCheckAmount;
		protected NetsoftUSA.InfragisticsWeb.WebCurrencyEdit CheckAmount;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCheckAmount;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPayment;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviderDecisions;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridRequests;
		protected NetsoftUSA.WebForms.OBLabel lbNumProviderDecisions;
		protected NetsoftUSA.WebForms.OBTextBox txtNumProviderDecisions;

		private PRRequest pRRequest;
		private PRRequestCollection pRRequests;
		private PRReview pRReview;
		private PRReviewCollection pRReviews;
		private PRProviderDecision pRProviderDecision;
		private Patient patient;
		private Problem problem;
		private PatientCoverage patientCoverage;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlRequestLiteProviderSelect;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlRequest;
		protected System.Web.UI.HtmlControls.HtmlTable tblRequestLite1;
		protected System.Web.UI.HtmlControls.HtmlTable tblRequestLite2;
		protected System.Web.UI.HtmlControls.HtmlTable tblAppeal1;
		protected System.Web.UI.HtmlControls.HtmlTable tblAppeal2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhysicianReviewDecisionDisplay;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PhysicianReviewDecisionDisplay;
		protected NetsoftUSA.WebForms.OBTextBox txtNumProviderDecision;
		protected NetsoftUSA.WebForms.OBLabel lbNumProviderDecision;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit AppealEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit AppealStartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbParentReviewID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ParentReviewID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldParentReviewID;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit AuthFormReceivedDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MedRecordReleaseSentDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MedRecordReceivedDate;
		protected NetsoftUSA.InfragisticsWeb.WebCombo AppealRequestedByTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ClientRequestInformationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ClientReceivedInformationDate;
		protected NetsoftUSA.WebForms.OBRadioButtonBox radActive;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBButton butAddNewRequest;
		protected NetsoftUSA.WebForms.OBLabel lbNumRequests;
		protected NetsoftUSA.WebForms.OBTextBox txtNumRequests;

		private BaseForEventCMSReferral erc;			// any one of these:  Event, CMS, Referral

//		private enum Mode
//		{
//			Grids,
//			RequestLite,
//			Request,
//			Review
//		}
//
//		private Mode PageMode
//		{
//			get { if (ViewState["PageMode"] == null) ViewState["PageMode"] = PageMode.Grids; return (PageMode)ViewState["PageMode"];} 
//			set { ViewState["PageMode"] = value; }
//		}

		private void Page_Load(object sender, System.EventArgs e)
		{

			// Bind Provider Selectors
			this.ProviderSelect.IsPhoneVisible = true;
			this.ProviderSelect.RebindControls(typeof(PRProviderDecision), "@PROVIDER@", 
				ProviderSearcherType.Provider, "PR=1", // Physician Review must be checked
				"ProviderID", "ProviderLocationID", "ProviderSpecialtyID", null, null, "DecStartDate");

			this.RequestLiteProviderSelect.IsPhoneVisible = true;
			this.RequestLiteProviderSelect.RebindControls(typeof(PRProviderDecision), "@PROVIDER@", 
				ProviderSearcherType.Provider, "PR=1", // Physician Review must be checked
				"ProviderID", "ProviderLocationID", "ProviderSpecialtyID", null, null, "DecStartDate");

			// Bind UDFs
			UserDefined1.ReloadContext("PRRequest", pRRequest, true);
			UserDefined2.ReloadContext("PRReview", pRReview, true);
			UserDefined2.ReloadContext("PRProviderDecision", pRProviderDecision, true);
			if(!UserDefined1.HasFields())
				this.UserDefined1.Visible = false;
			if(!UserDefined2.HasFields())
				this.UserDefined2.Visible = false;
			if(!UserDefined3.HasFields())
				this.UserDefined3.Visible = false;


			if (!this.IsPostBack)
			{
				BindERCOrPatientOptions();
				BindActiveOptions();
				this.LoadData();			// Use load data method for data entry forms
				radAllOrSpecific.Items[0].Text = this.Language.Translate( erc.ERCTypeDisplay );
			}
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache

				pRRequests = (PRRequestCollection)this.LoadObject(typeof(PRRequestCollection));  // load object from cache
				pRRequest = (PRRequest)this.LoadObject(typeof(PRRequest));  // load object from cache
				pRReview = (PRReview)this.LoadObject(typeof(PRReview));  // load object from cache
				pRReviews = (PRReviewCollection)this.LoadObject(typeof(PRReviewCollection));  // load object from cache
				pRProviderDecision = (PRProviderDecision)this.LoadObject(typeof(PRProviderDecision));  // load object from cache
			}
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject(typeof(PRRequestCollection), null);
			this.CacheObject(typeof(PRReviewCollection), null);
			this.CacheObject(typeof(PRProviderDecisionCollection), null);
			this.CacheObject(typeof(PRRequest), null);
			this.CacheObject(typeof(PRReview), null);
			this.CacheObject(typeof(PRProviderDecision), null);

			
			// Make sure the collection does not contain any left overs
			this.CacheObject(typeof(BaseForEventCMSReferral), this.erc); 

			base.NavigateAway (targetURL);
		}


		public void BindERCOrPatientOptions()
		{
			radAllOrSpecific.Items.Clear();
			radAllOrSpecific.Items.Add(new ListItem("ERC", "ERC" ));
			radAllOrSpecific.Items.Add(new ListItem(PatientMessages.ALL, "ALL" ));
			radAllOrSpecific.SelectedIndex = 0;
		}

		public void BindActiveOptions()
		{
			radActive.Items.Clear();
			radActive.Items.Add(new ListItem("All", "" ));
			radActive.Items.Add(new ListItem("Active", "1" ));
			radActive.Items.Add(new ListItem("Inactive", "0" ));
			radActive.SelectedIndex = 0;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			PRRequest prrToEdit = null;
			try
			{	
				PageTab.SelectedTabKey = this.TargetTabKey;		// navigate to target tab.

				// use any load method here
				// or pull from the parameter passed to this page via PushParam
				patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
				// get the passed patient subscriber coverage (link to patient)
				patientCoverage = GetParamOrGetFromCache("PatientCoverage", typeof(PatientCoverage)) as PatientCoverage;
				if (patientCoverage == null)	
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-subscriber-coverage");
				problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
				//if (problem == null)	
				//	throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");					

				erc = this.GetParamOrGetFromCache("ERC", typeof(BaseForEventCMSReferral)) as BaseForEventCMSReferral;
				if (erc == null)
				{
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an event/referral/CMS");
				}

				prrToEdit = this.GetParam("PRRequest") as PRRequest;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
			finally
			{
				//eventObj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CacheObject(typeof(Patient), patient);
			this.CacheObject(typeof(PatientCoverage), patientCoverage);
			this.CacheObject(typeof(Problem), problem);
			this.CacheObject(typeof(BaseForEventCMSReferral), erc);

			bool result = LoadDataForPRRequests();
			if (prrToEdit != null)
				this.PRRequest = prrToEdit;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, BaseForEventCMSReferral erc)
		{
			Redirect(patient, patCov, problem, erc, null);
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, BaseForEventCMSReferral erc, PRRequest prr)
		{
			if (patient == null || patCov == null)
				throw new ActiveAdviceException("You can open physician-reviews only in the context of patient and coverage and event/referral/cms"); 

			//BasePage.PushCurrentCallingPage();

			BasePage.PushTargetTab("PHYREV_PhysicianReview");
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("ERC", erc);
			BasePage.PushParam("PRRequest", prr);
			BasePage.Redirect("PhysicianReviewForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			gridRequests.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridRequests_ColumnsBoundToDataClass);
			gridRequests.ClickCellButton += new ClickCellButtonEventHandler(gridRequests_ClickCellButton);
			gridRequests.SelectedRowIndexChanged += new EventHandler(gridRequests_SelectedRowIndexChanged);

			gridProviderDecisions.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridProviderDecisions_ColumnsBoundToDataClass);
			gridProviderDecisions.ClickCellButton += new ClickCellButtonEventHandler(gridProviderDecisions_ClickCellButton);

			this.butAddNewRequest.Click += new EventHandler(butAddNewRequest_Click);
			this.butAddNewReview.Click += new EventHandler(butAddNewReview_Click);

			this.radActive.SelectedIndexChanged += new EventHandler(radActive_SelectedIndexChanged);
			this.radAllOrSpecific.SelectedIndexChanged += new EventHandler(radAllOrSpecific_SelectedIndexChanged);

			this.PhysicianReviewRequestDetailTypeID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(PhysicianReviewRequestDetailTypeID_SelectedRowChanged);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "PHYREV_PhysicianReview")
			{
				this.AddClinicalSummaryButton(toolbar);
			}


			// Menu items to be displayed on all tabs
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@ADDNEWPR@", "AddNewPR", true, false);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData(true))
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@PHYSICIANREVIEWS@");
			}
		}

		public void OnToolbarButtonClick_AddNewPR(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData(false))
			{
				CreateNewPR();
			}
		}

		private void CreateNewPR()
		{
			PRRequest request = this.PRRequest;
			PRReview review = null;
			PRProviderDecision decision = null;

			if (request == null)
				request = this.PRRequests[SelectedPRRequestIndex];

			this.PRRequest = request;
			this.PRRequest.CreateNewPR(ref review, ref decision);

            this.PRRequest.PRReviews.InsertRecord(0, review); 
			this.PRRequest = this.PRRequest;
			this.PRReview = review;
			this.PRProviderDecision = decision;
		}


		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			RefreshFromDB();
		}

		private void RefreshFromDB()
		{
			this.LoadDataForPRRequests();
			this.PRRequest = null;
			this.PRReview = null;
			this.PRProviderDecision = null;
		}

		public void UpdatePKs()
		{
			this.gridRequests.UpdatePKsFromCollection(this.PRRequests);
			// This does not work, because essentially we're appending more than one collection to the grid
			// this.gridProviderDecisions.UpdatePKsFromCollection(this.pRProviderDecisions);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData(bool refresh)
		{
			try
			{	
				bool saveReview = (this.PRReview !=  null);
				bool saveRequest = !(saveReview) && (this.PRRequest != null);

				if (saveRequest)
				{
					if (!SaveDataForPRRequest())
						return false;

					if (refresh)
					{
						LoadDataForPRRequests();
						LoadDataForPRReviews();
                    
						// this.PRRequests = this.PRRequests;
						// this.PRReviews = this.PRReviews;
					}
				}
				else if (saveReview)
				{
					if (!SaveDataForPRReview())
						return false;

					if (refresh)
					{
						LoadDataForPRRequests();
						LoadDataForPRReviews();

						//this.PRRequests = this.PRRequests;
						//this.PRReviews = this.PRReviews;
						this.SelectedPRReviewIndex = 0;
					}
				}

				this.DumpAutoActivity(pRRequests, true);
				if (refresh)
					UpdatePKs();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PRRequestCollection PRRequests
		{
			get { return pRRequests; }
			set
			{
				pRRequests = value;
				try
				{
					gridRequests.UpdateFromCollection(pRRequests);  // update given grid from the collection
					
					if (pRRequests != null && pRRequests.RealCount > 0)
					{
						this.txtNumRequests.Text = pRRequests.RealCount.ToString();
						this.txtNumRequest.Text = pRRequests.RealCount.ToString();

						this.SelectedPRRequestIndex = 0; // The latest is always on top
					
						this.PRRequests[SelectedPRRequestIndex].LoadPRReviews(false);
						this.PRReviews = this.PRRequests[SelectedPRRequestIndex].PRReviews;
						this.SelectedPRReviewIndex = 0;
					}
					else
					{
						this.txtNumRequests.Text = "";
						this.txtNumRequest.Text = "";
					}

					// other object-to-control methods if any
					PRRequest = null;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(PRRequestCollection), pRRequests);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForPRRequests()
		{
			bool result = true;
			PRRequestCollection pRRequests = null;
			try
			{	
				if (this.radAllOrSpecific.SelectedValue == "ALL")
				{
					pRRequests = patient.GetPatientPRRequests();
				}
				else
				{
					erc.LoadPRRequests(true);
					pRRequests = erc.PRRequests;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//PRRequests.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.PRRequests = pRRequests;
			return result;
		}

		

			/// <summary>
			/// Call this method from Page_Load or anytime you want to load data
			/// </summary>
		public bool LoadDataForPRReviews()
		{
			bool result = true;
			PRReviewCollection pRReviews = null;
			try
			{	
				PRRequest request = GetSelectedPRRequest();
				if (request != null)
				{
					request.LoadPRReviews(false);
					pRReviews = request.PRReviews;
				}
				else
					pRReviews = null;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//pRReviews.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.PRReviews = pRReviews;
			return result;
		}


		private void butAddNewReview_Click(object sender, System.EventArgs e)
		{
			CreateNewPR();
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PRRequest PRRequest
		{
			get { return pRRequest; }
			set
			{
				pRRequest = value;
				try
				{
					if (pRRequest == null) // If this is a new request, use the lite form.
					{
						this.UpdateFromObject(this.pnlRequestLiteProviderSelect.Controls, null);  // update controls for the given control collection
						this.UpdateFromObject(this.tblRequestLite1, null);
						this.UpdateFromObject(this.tblRequestLite2, null);
					}
					else if (pRRequest.IsNew)
					{
						PRProviderDecision decision = pRRequest.GetMostRecentReview().GetMostRecentProviderDecision();
						this.UpdateFromObject(this.pnlRequestLiteProviderSelect.Controls, decision);  // update controls for the given control collection
						this.UpdateFromObject(this.tblRequestLite1.Controls, pRRequest);
						this.UpdateFromObject(this.tblRequestLite2.Controls, decision);
					}
					else
					{
						this.UpdateFromObject(pnlRequest.Controls, pRRequest);  // update controls for the given control collection
					}
					// other object-to-control methods if any
					UserDefined1.ReloadContext("PRRequest", pRRequest, false);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PRRequest), pRRequest);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPRRequest()
		{
			try
			{	//customize this method for this specific page
				if (pRRequest.IsNew)
				{
					PRProviderDecision decision = pRRequest.GetMostRecentReview().GetMostRecentProviderDecision();
					this.UpdateToObject(this.pnlRequestLiteProviderSelect.Controls, decision);  // update controls for the given control collection
					this.UpdateToObject(this.tblRequestLite1.Controls, pRRequest);
					this.UpdateToObject(this.tblRequestLite2.Controls, decision);
				}
				else
				{
					this.UpdateToObject(pnlRequest.Controls, pRRequest);	// controls-to-object
				}
				// other control-to-object methods if any
				UserDefined1.UserDefinedValue = pRRequest.UserDefined ;
				UserDefined1.ReadControls();
			
				return this.IsValid;	// Return validation result
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPRRequest()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPRRequest())
					return false;

				if (this.pRRequest.ParentPRRequestCollection == null)
					this.pRRequests.InsertRecord(0, this.pRRequest); // Note: We Insert to the top instead of just adding to the bottom

				// Save to the database
				this.erc.SavePRRequests();

//				if (this.pRRequest.PhysicianReviewDecisionID != 0 && this.pRRequest.StatusCode != "CLOS") // If Decision is filled in and status is not closed warn the user.
//				{
//					this.SetPageMessage("@WHENDECISIONSELECTEDSTATUSMUSTBECLOSED@", EnumPageMessageType.AddWarning);
//				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void gridRequests_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			UltraGridColumn col = gridRequests.AddButtonColumn("Edit", "@EDIT@", 0);
			col.Width = 70;
			col.Hidden = radAllOrSpecific.SelectedValue == "ALL";

			//col.Hidden = rbERCorPatient.SelectedValue == "ALL";
			gridRequests.AddButtonColumn("Select", "@SELECT@", 0).Width = 70;

			// Hide eventID if this is an event. This column is used from CMS module where there can be multiple events
			gridRequests.Columns.FromKey("EventID").Hidden = (erc is Event);
		}

		private void gridRequests_ClickCellButton(object sender, CellEventArgs e)
		{
			int index = gridRequests.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			switch (e.Cell.Key)
			{
				case "Edit":
				{
					this.PRRequest = this.pRRequests[index];
					break;
				}
			}
		}

		public int SelectedPRRequestIndex
		{
			get
			{
				return gridRequests.SelectedRowIndex;
			}
			set
			{
				gridRequests.SelectedRowIndex = value;
				PRRequest = null;
			}
		}

		public int SelectedPRReviewIndex
		{
			get
			{
				return gridProviderDecisions.SelectedRowIndex;
			}
			set
			{
				gridProviderDecisions.SelectedRowIndex = value;
				PRReview = null;
			}
		}

		/// <summary>
		/// Returns the selected physician review
		/// </summary>
		/// <returns></returns>
		public PRRequest GetSelectedPRRequest()
		{
			if (SelectedPRRequestIndex < 0)
				return null;
			else
				return this.pRRequests[ SelectedPRRequestIndex ];
		}


		public EnumActivityAndNoteContext PrepareActivityAndNoteContext()
		{
			EnumActivityAndNoteContext ctx = EnumActivityAndNoteContext.ERC;

//?			PRRequest pRRequest = GetSelectedPRRequest();
//			PRReview pRReview = GetSelectedPRReview();
//
//			if (pRRequest != null)
//			{
//				ctx = EnumActivityAndNoteContext.PRRequest;
//				this.CacheObject(typeof(PRRequest), pRRequest);
//			}
//			if (pRReview != null)
//			{
//				this.CacheObject(typeof(PRReview), pRReview);
//				ctx = EnumActivityAndNoteContext.PRReview;
//			}

			return ctx;
		}
		
		public void OnSubNavigationItemClick_Activities(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ActivitiesForm.Redirect(EnumActivityContext.Activity, PrepareActivityAndNoteContext());
		}

		public new void OnSubNavigationItemClick_Notes(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			NoteSearch.Redirect(PrepareActivityAndNoteContext());
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PRReviewCollection PRReviews
		{
			get { return pRReviews; }
			set
			{
				pRReviews = value;
				try
				{
					int num = 0;
					if (pRReviews != null)
					{
						gridProviderDecisions.UpdateFromCollection(null); // Clear
						foreach (PRReview review in pRReviews)
						{
							review.LoadPRProviderDecisions(false);
							review.PRProviderDecisions.ActiveFilter = this.radActive.SelectedValue;
							gridProviderDecisions.UpdateFromCollection(review.PRProviderDecisions, true);  // update given grid from the collection
							review.PRProviderDecisions.ActiveFilter = "";
							num += review.PRProviderDecisions.RealCount;
						}
					}

					if (num > 0)
					{
						this.txtNumProviderDecisions.Text = num.ToString();
						this.txtNumProviderDecision.Text = num.ToString();
					}
					else
					{
						this.txtNumProviderDecisions.Text = "";
						this.txtNumProviderDecision.Text = "";
					}

					// other object-to-control methods if any
					PRReview = null;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(PRReviewCollection), pRReviews);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPRReview()
		{
			bool result = true;
			PRReview pRReview = new PRReview(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PRReview = pRReview;
			return result;
		}


		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			//if (this.eventObj.IsNew)
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.erc);
			//else
			//	pageSummary.RenderObjects(this.patient);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PRReview PRReview
		{
			get { return pRReview; }
			set
			{
				pRReview = value;
				try
				{
					this.UpdateFromObject(pnlReview.Controls, pRReview);  // update controls for the given control collection
					this.UpdateFromObject(this.tblAppeal1.Controls, pRReview);
					this.UpdateFromObject(this.tblAppeal2.Controls, pRReview);
					
//					UserDefined3.ReloadContext("PRReview", pRReview, false);

//					UserDefined2.UserDefinedValue = pRReview.PRReview.UserDefined;
//					UserDefined2.ReadControls();

					if (pRReview != null)
						this.PhysicianReviewRequestDetailTypeID.ReadOnly = !pRReview.CanChangeReviewType();

				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PRReview), pRReview);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PRProviderDecision PRProviderDecision
		{
			get { return pRProviderDecision; }
			set
			{
				pRProviderDecision = value;
				try
				{
					this.UpdateFromObject(pnlDecisionConfirmation.Controls, pRProviderDecision);  // update controls for the given control collection
					this.UpdateFromObject(pnlProviderSelect.Controls, pRProviderDecision);
					this.UpdateFromObject(pnlPayment.Controls, pRProviderDecision);  // update controls for the given control collection
					
					// other object-to-control methods if any
					//UserDefined3.ReloadContext("PRProviderDecision", pRProviderDecision, false);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PRProviderDecision), pRProviderDecision);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPRReview()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlReview.Controls, pRReview);  // update controls for the given control collection

//				UserDefined2.UserDefinedValue = pRReview.PRReview.UserDefined;
//				UserDefined2.ReadControls();
		
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPRProviderDecision()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlDecisionConfirmation.Controls, pRProviderDecision);  // update controls for the given control collection
				this.UpdateToObject(pnlProviderSelect.Controls, pRProviderDecision); 
				this.UpdateToObject(pnlPayment.Controls, pRProviderDecision);  // update controls for the given control collection
				//				UserDefined3.UserDefinedValue = pRReview.UserDefined;
				//				UserDefined3.ReadControls();
		
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPRProviderDecision()
		{
			bool result = true;
			PRProviderDecision pRProviderDecision = null; // use a parameterized constructor which also initializes the data object
			try
			{	
				pRProviderDecision = new PRProviderDecision(true, true); // Init new and default values

//				if (this.pRProviderDecisions.Count == 0) // This is the initial request detail
//				{
//					pRProviderDecision.StartDate = this.pRProviderDecisions.ParentPhysicianReviewRequest.StartDate;	// Get the Start Date from request
//				}

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PRProviderDecision = pRProviderDecision;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPRReview()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPRReview())
					return false;
				if (!this.ReadControlsForPRProviderDecision())
					return false;


				if (this.pRProviderDecision.ParentPRProviderDecisionCollection == null)
				{
					this.pRReview.LoadPRProviderDecisions(false);
					this.pRReview.PRProviderDecisions.InsertRecord(0, this.pRProviderDecision);
				}

				if (this.pRReview.ParentPRReviewCollection == null)
				{
					this.pRRequest.LoadPRReviews(false);
					this.pRRequest.PRReviews.InsertRecord(0, this.pRReview);
				}

				// If decision has changed (and this is the most recent decision) update the parent review and request
				if (this.pRProviderDecision.IsDecisionChanged() && this.pRRequest.IsMostRecentReview(this.pRReview) && this.pRReview.IsMostRecentProviderDecision(this.pRProviderDecision))
				{
					// Update Decision
					this.pRReview.PhysicianReviewDecisionID = this.pRProviderDecision.PhysicianReviewDecisionID;
					this.pRRequest.PhysicianReviewDecisionID = this.pRProviderDecision.PhysicianReviewDecisionID;

					// Update End Date
					this.pRReview.AppealEndDate = this.pRProviderDecision.EndDate;
					this.pRRequest.EndDate = this.pRProviderDecision.EndDate;
					
					// Update Status
                    this.pRRequest.UpdateStatusInfo(this.pRReview);

					this.pRReview.IsDirty = this.pRRequest.IsDirty = true;

					this.pRRequest.Save();
				}
				else
				{
					this.pRReview.Save();
				}


				// Copy over the Decision and End Date values to the parent Request
//				this.pRProviderDecisions.ParentPRRequest.EndDate = this.pRProviderDecision.EndDate;
//				this.pRProviderDecisions.ParentPRRequest.PhysicianReviewDecisionID = this.pRProviderDecision.PhysicianReviewDecisionID;

				// Save both the request and the request detail to the database
//				this.pRReviews.ParentPRRequest.Save();
                
				UpdatePKs();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}


		private void gridProviderDecisions_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			UltraGridColumn col = gridProviderDecisions.AddButtonColumn("Edit", "@EDIT@", 0);
			col.Width = 70;
			col.Hidden = radAllOrSpecific.SelectedValue == "ALL";
		}

		private void gridProviderDecisions_ClickCellButton(object sender, CellEventArgs e)
		{
			object[] pk = gridProviderDecisions.GetPKFromCellEvent(e);
			if (pk == null) return;
            
			int providerDecisionID = (int)pk[0];
            			
			switch (e.Cell.Key)
			{
				case "Edit":
				{
					PRReview review = null;
                    PRProviderDecision decision = null;
					bool found = false;
					foreach (PRReview r in this.pRReviews)
					{
						foreach (PRProviderDecision d in r.PRProviderDecisions)
							if (d.PRProviderDecisionID == providerDecisionID) 
							{
								found = true;
								review = r;
								decision = d;
								break;
							}

						if (found) break;
					}
					
					if (found)
					{
						this.PRRequest = this.GetSelectedPRRequest();
						this.PRReview = review;
						this.PRProviderDecision = decision;
					}
					break;
				}
			}
		}

		private void gridRequests_SelectedRowIndexChanged(object sender, EventArgs e)
		{
			LoadDataForPRReviews();
		}


		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.SetERCTabVisibilities();
			this.SetPageSubMenuItemVisible("Images", this.pRRequest != null || gridRequests.SelectedRowIndex>=0);

			bool visReview = (this.PRReview != null);
			bool visRequestLite = !visReview && (this.PRRequest != null && this.PRRequest.IsNew);
			bool visRequest = !(visReview || visRequestLite) && (this.PRRequest != null);
			bool visGrids = !visRequest && !visReview && !visRequestLite;

			pnlRequest.Visible = visRequest;
			pnlRequestLite.Visible = visRequestLite;
			pnlRequestLiteProviderSelect.Visible = visRequestLite;
			pnlReview.Visible = visReview;
			pnlProviderSelect.Visible = visReview;
			pnlDecisionConfirmation.Visible = visReview;
			pnlPayment.Visible = visReview && SystemControlValue.GetInstance.DisplayPRPaymentInfo; // Display this panel only if the flag is set in global settings

			pnlRequests.Visible = visGrids;
			pnlProviderDecisions.Visible = pnlRequests.Visible;

			// Display Appeal related control only when the review type is one of the appeal types
			tblAppeal1.Visible = tblAppeal2.Visible = visReview && this.pRReview.IsAppeal();

			bool isOKToCreatePR = false; 
			PRRequest pq = null;

			if (visGrids)
				pq = this.GetSelectedPRRequest();
			else if (visReview)
				pq = this.pRRequest;				

			if (pq != null) isOKToCreatePR = pq.CanAddNewPR();

			this.butAddNewReview.Visible = (this.radAllOrSpecific.SelectedValue != "ALL") && isOKToCreatePR;

			this.SetPageToolbarItemVisible("Save", visReview || visRequest || visRequestLite);
			this.SetPageToolbarItemVisible("Cancel", visReview || visRequest || visRequestLite);
			this.SetPageToolbarItemVisible("AddNewPR", visReview && isOKToCreatePR && !this.pRReview.IsNew && !this.pRProviderDecision.IsNew && this.pRProviderDecision.Active);

			if (visRequest)
			{
				this.RenderClientFunctions(this.pnlRequest.Controls, this.PRRequest, "OnCalcRequest");
				//this.RenderClientFunctions(this.tblRequestLite1.Controls, this.PRRequest, "OnCalcRequest1");
				//this.RenderClientFunctions(this.tblRequestLite2.Controls, this.PRRequest, "OnCalcRequest2");
			}
			if (visReview)
			{
				//this.RenderClientFunctions(this.tblAppeal1.Controls, this.PRReview, "OnCalcReview1");
				//this.RenderClientFunctions(this.tblAppeal2.Controls, this.PRReview, "OnCalcReview2");
				this.RenderClientFunctions(this.pnlReview.Controls, this.PRReview, "OnCalcReview");
				this.RenderClientFunctions(this.pnlProviderSelect.Controls, this.PRProviderDecision, "OnCalcDecision");
				this.RenderClientFunctions(this.pnlDecisionConfirmation.Controls, this.PRProviderDecision, "OnCalcDecisionConfirmation");
				this.RenderClientFunctions(this.pnlPayment.Controls, this.PRProviderDecision, "OnCalcPayment");
			}
		}

		public void OnSubNavigationItemClick_Images(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			// make sure active event is selected.			
			if(this.pRRequest == null)
			{
				PRRequest objPRRequest = new PRRequest(false);
				objPRRequest = this.pRRequests[gridRequests.SelectedRowIndex];		
				ImageSearch.Redirect(this.patient, this.patientCoverage, this.problem, this.erc ,objPRRequest);
			}
			else
				ImageSearch.Redirect(this.patient, this.patientCoverage, this.problem, this.erc ,this.pRRequest);
		}

		private void radAllOrSpecific_SelectedIndexChanged(object sender, EventArgs e)
		{
			LoadDataForPRRequests();
		}

		private void radActive_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.LoadDataForPRReviews();
		}
		
		private void PhysicianReviewRequestReasonID_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.UpdateToObject(this.PhysicianReviewRequestReasonID, this.pRRequest);
			this.pRRequest.UpdateStatusInfo();
		}

		private void DecPhysicianReviewDecisionID_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.UpdateToObject(this.DecPhysicianReviewDecisionID, this.pRProviderDecision);
			this.UpdateToObject(this.EndDate, this.pRProviderDecision);

			if (this.pRProviderDecision.PhysicianReviewDecisionID != 0) 
			{
				if (this.PRProviderDecision.EndDate == DateTime.MinValue)
					this.PRProviderDecision.EndDate = DateTime.Now;
			}		
		}

		private void butAddNewRequest_Click(object sender, System.EventArgs e)
		{
			ClinicalReviewDecision dec = new ClinicalReviewDecision();
			dec.LoadLastDecisionForEvent(312); // EventID
			PRRequest prr = PRRequest.CreateNewPRTree(null, null, dec);
			PhysicianReviewForm.Redirect(this.patient, this.patientCoverage, this.problem, this.erc, prr);
		}

		private void PhysicianReviewRequestDetailTypeID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			this.UpdateToObject(this.PhysicianReviewRequestDetailTypeID, this.pRReview);
			this.PRReview = this.PRReview;
		}

	}


}
