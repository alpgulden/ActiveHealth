using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.Security;
using System.Security.Principal;
using System.Security.Permissions;
using System.Web.Security;
using System.Web.Caching;
using ActiveAdvice.DataLayer;
using NetsoftUSA.WebForms;


namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for Login.
	/// </summary>
	public class Login : BasePage
	{
		protected System.Web.UI.WebControls.TextBox txtUserName;
		protected System.Web.UI.HtmlControls.HtmlInputButton btnChangePassword;
		protected System.Web.UI.HtmlControls.HtmlInputButton btnLogin;
		protected System.Web.UI.WebControls.Panel pnlChange;
		protected System.Web.UI.WebControls.Panel pnlVerify;
		protected System.Web.UI.WebControls.TextBox txtUserNameChange;
		protected System.Web.UI.WebControls.TextBox txtOldPassword;
		protected System.Web.UI.WebControls.TextBox txtNewPassword;
		protected System.Web.UI.HtmlControls.HtmlInputButton btnSave;
		protected System.Web.UI.HtmlControls.HtmlInputButton btnCancel;
		protected System.Web.UI.WebControls.TextBox txtConfirmNewPassword;
		protected System.Web.UI.WebControls.TextBox txtPassword;

		protected string m_FocusField = "";	//FocusField

		protected ActiveAdvice.Web.Title ucTitle;


		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			
			if(!this.IsPostBack)			
			{
				//show Login pade
				ShowChangePwdPanel(false);

				//temp: set default user
				txtUserName.Text = "";	

				
			}
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			HtmlGenericControl cBody = null;


			InitializeComponent();
			base.OnInit(e);

			cBody = this.FindBodyControl();
			if(cBody != null)
			{
				//set JS for body onLoad; !!! <body> MUST be with id and runat=server !!!
				cBody.Attributes.Add("onLoad", "LoadPage();");
			}
	
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    			
			this.EnableAutoLogout = false;
			this.EnableClientTimeout = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
			this.PreRender += new System.EventHandler(this.Page_PreRender);

		}
		#endregion

		

		#region Utility methods
		
		public static string GenerateJS(string strMsg)
		{
			string strJS = String.Format("<script language='javascript'>{0}</script>",strMsg);
			return strJS;
		}

		public static string AlertJS(string strMsg)
		{
			string strJS = String.Format("<script language='javascript'> window.alert('{0}');</script>",strMsg);
			return strJS;
		}

		private HtmlGenericControl FindBodyControl()
		{
			foreach(Control c in this.Controls)
			{
				if(c is HtmlGenericControl)
					return (HtmlGenericControl)c;
			}
			return null;
		}

		

		#endregion Utility methods		

		#region Properties

		protected string FocusField
		{set{m_FocusField = value;}}
			
		private string UserNameCntlName
		{
			get
			{				
				if(pnlVerify.Visible)
					return "txtUserName";				
				else
					return "txtUserNameChange";	
			}
		}

		private string PasswordCntlName
		{
			get
			{				
				if(pnlVerify.Visible)
					return "txtPassword";				
				else
					return "txtOldPassword";	
			}
		}

		private TextBox PasswordCntl
		{
			get
			{
				TextBox tb = (TextBox)this.FindControl(PasswordCntlName);
				return tb;
			}
		}

		private TextBox UserNameCntl
		{
			get
			{
				TextBox tb = (TextBox)this.FindControl(UserNameCntlName);
				return tb;
			}
		}


		#endregion Properties
		

		//called from PreRender
		protected void LoadStaticHiddenFields()
		{			
			RegisterHiddenField("FocusField", m_FocusField);
		}

		private void ShowChangePwdPanel( bool bChangePwdPanel)
		{
			//show Login Panel(Login and Change Password btns) 
			//or Change Password Panel (Save, Cancel btns)
			this.pnlChange.Visible = bChangePwdPanel;
			this.pnlVerify.Visible = !bChangePwdPanel;
		}

		private void CreateAuthenticationTicket(int userId)
		{
			// The user is authenticated
			// At this point, create an authentication ticket,
			// Identity and principal objects for .NET authorization purposes

			// Create the authentication ticket
			FormsAuthenticationTicket authTicket = new
				FormsAuthenticationTicket(1, // version
				userId.ToString(), // userId
				DateTime.Now, // creation
				DateTime.Now.AddMinutes(this.Session.Timeout),// Expiration should be equal to session expiration
				false, // Persistent
				"");

			//Create the principal object
			FormsIdentity ID = new FormsIdentity(authTicket);
				
			// Now encrypt the ticket.
			string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
			// Create a cookie and add the encrypted ticket to the
			// cookie as data.
			HttpCookie authCookie =
				new HttpCookie(FormsAuthentication.FormsCookieName,
				encryptedTicket);

			// Add the cookie to the outgoing cookies collection.
			Response.Cookies.Add(authCookie);

			//this is temp, to be on save side: remove Cached principal by UserId (refresh roles)
			AASecurityHelper.RemoveCachedPrincipalByUserId = userId;

		}

		private void Logon(int userId, string userName)
		{
			//create auth ticket with expiration == Session.Timeout !!!
			//with userId as Name, no roles on this time
			CreateAuthenticationTicket(userId);

			//store Login Name as UserName in the Session (future - might store AAUser in Session?) 
			AASecurityHelper.UserName = userName;

			Context.Session["SessionValid"] = true;	// make session valid from this point on

			// Redirect the user to the originally requested page
			string strRedirectUrl = FormsAuthentication.GetRedirectUrl(userId.ToString(),false );
			if(strRedirectUrl.Length == 0) strRedirectUrl = AASecurityHelper.defaultRedirectUrl;
			try
			{
				BasePage.Redirect(strRedirectUrl);
			}
			catch
			{
				BasePage.Redirect(AASecurityHelper.defaultRedirectUrl);
			}
		}

		#region Events

		protected void login_ServerClick(object sender, System.EventArgs e)
		{
			bool passwordVerified = false;
			string errMsg = "";
			int iUserId = -1;
			string userName = txtUserName.Text.Trim();
			string password = txtPassword.Text.Trim();
			string saltFromDb = "";

			if(userName.Length == 0)
			{
				errMsg = "Please enter User Name";
				this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
				return;
			}

			if(password.Length == 0)
			{
				errMsg = "Please enter Password";
				this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
				return;
			}

			try
			{				

				//call verify with return UserId if success
				iUserId = AASecurityHelper.VerifyPasswordWithUserId(userName,password, ref saltFromDb, ref errMsg);
				if(errMsg.Length > 0)
				{
					this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
					return;
				}

				if(iUserId > 0)
				{
					passwordVerified = true;
				}
				else
				{
					errMsg = "Authentication Failed.";
					this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
					return;
				}

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				//errMsg = ex.Message;
				//this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
				return;
			}
			if (passwordVerified == true )
			{
				// The user is authenticated
				// At this point, create an authentication ticket,
				// Identity and principal objects for .NET authorization purposes
		

				//save user credentials in auth ticket and Session;
				//redirect to requested or default page
				Logon(iUserId,  userName);
			}
			else
			{
				errMsg = "Authentication Failed.";
				this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
				return;
			}		
		}

		protected void btnChangePassword_ServerClick(object sender, System.EventArgs e)
		{
		 string test = "Please enter your old and new password";
			this.SetPageMessage( test, NetsoftUSA.WebForms.EnumPageMessageType.Info, null);
			
			string userName = this.UserNameCntl.Text.Trim();
	
			ShowChangePwdPanel(true);

			//copy user name on change screen			
			if(userName.Length > 0)
			{
				this.UserNameCntl.Text = userName;				
			}
			
		}

		protected void btnCancel_ServerClick(object sender, System.EventArgs e)
		{	
			//return to Login page
			this.txtUserNameChange.Text = "";	//clear Login Name
			ShowChangePwdPanel(false);
		}

		
		protected void btnSave_ServerClick(object sender, System.EventArgs e)
		{			
			string errMsg = "";
			//bool passwordVerified = false;
			//check entry 
			string userName = this.txtUserNameChange.Text.Trim();
			string oldPwd = this.txtOldPassword.Text.Trim();
			string newPwd = this.txtNewPassword.Text.Trim();
			string confirmNewPwd = this.txtConfirmNewPassword.Text.Trim();
			int iUserId = -1;
	

			if(userName.Length == 0)
			{
				errMsg = "Please enter User Name";
				this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
				return;
			}

			if(oldPwd.Length == 0)
			{
				errMsg = "Please enter Old Password";
				this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
				return;
			}

			if(newPwd.Length == 0)
			{
				errMsg = "Please enter New Password";
				this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
				return;
			}

			if(confirmNewPwd.Length == 0)
			{
				errMsg = "Please enter Confirm Password";
				this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
				return;
			}

			if(!newPwd.Equals(confirmNewPwd))
			{
				errMsg = "Confirm Password and New Password should be the same";
				this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
				return;

			}

			//call DB to change password
			try
			{				
				iUserId = AASecurityHelper.ChangePasswordWithUserId(userName, oldPwd, newPwd, ref errMsg);

				if(errMsg.Length > 0)
				{
					this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
					return;
				}

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				//errMsg = ex.Message;
				//this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
				return;
			}
			if (iUserId > 0 )
			{
				//save user credentials in auth ticket and Session;
				//redirect to requested or default page
				Logon(iUserId,  userName);

			}
			else
			{
				errMsg = "Authentication Failed.";
				this.SetPageMessage( errMsg, NetsoftUSA.WebForms.EnumPageMessageType.Error, null);
				return;
			}

		}

		private void Page_PreRender(object sender, System.EventArgs e)
		{
			if(this.UserNameCntl.Text.Trim().Length >0)
			{
				//set focus on Pasword
				this.FocusField = this.PasswordCntlName;
			}
			else
			{
				//set focus on password
				this.FocusField = this.UserNameCntlName;
			}

			LoadStaticHiddenFields();
		}

		#endregion Events
	}
}

