using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ActiveAdvice.DataLayer;
using NetsoftUSA.InfragisticsWeb;
using NetsoftUSA.WebForms;
using NetsoftUSA.DataLayer;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for GuidelineForm.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.GUIDELINES)]
	
	[MainLanguageClass("ActiveAdvice.Messages.GuidelineMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Guideline,DataLayer")]
	[BackPage(typeof(GuidelineCategoryProduct))]
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@GUIDELINEFORMTITLE@")]
	public class GuidelineForm : BasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebTab UltraWebTab1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuideline;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGuidelineSourceSetID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GuidelineSourceSetID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGuidelineSourceSetID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldText;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Text;
		protected NetsoftUSA.WebForms.OBFieldLabel lbText;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCodes;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlIndicators;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddNew;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlIndicator;
		protected NetsoftUSA.WebForms.OBCheckBox OBCheckBox1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldType2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Type2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbType2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldType1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Type1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbType1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSortSequence;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit SortSequence;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSortSequence;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDefaultNote;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit DefaultNote;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDefaultNote;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInstruction;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Instruction;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInstruction;
		protected NetsoftUSA.WebForms.OBCheckBox NoteRequired;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNoteRequired;
		protected NetsoftUSA.WebForms.OBCheckBox Selectable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSelectable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHierarchy;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Hierarchy;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHierarchy;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnChangeDxCode;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnChangePxCode;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTip;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Tip;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTip;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuidelineTip;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlIndicatorTip;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCode;
		private Guideline guideline;
		private GuidelineIndicator guidelineIndicator;
		private GuidelineIndicatorCollection guidelineIndicators;
		protected NetsoftUSA.WebForms.OBButton butDelete;
		protected NetsoftUSA.WebForms.OBButton butSave;
		protected NetsoftUSA.WebForms.OBButton butCancel;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		private GuidelineCodeCollection guidelineCodes;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
			{
				LoadData();
			}
			else
			{
				
				guideline =(Guideline) this.LoadObject(typeof(Guideline));
				guideline.LoadGuidelineIndicators(false);
				this.guidelineIndicators = guideline.GuidelineIndicators;
				guideline.LoadGuidelineCodes(false);
				this.guidelineCodes = guideline.GuidelineCodes;
				guidelineIndicator = (GuidelineIndicator) this.LoadObject(typeof(GuidelineIndicator));
			}
		}

		private bool LoadData()
		{
			UltraWebTab1.SelectedTabKey = this.TargetTabKey;		// navigate to target tab.
			bool result = true;
						
			try
			{	// use any load method here
				guideline = this.GetParamOrGetFromCache("Guideline", typeof(Guideline)) as ActiveAdvice.DataLayer.Guideline;
				if (guideline == null)
				{
					return NewGuideline();
				}
				this.Guideline = guideline;		// When you set the object to the property, controls are automatically populated
				guideline.LoadGuidelineCodes(false);
				DiagnosticSelectCollection col = new DiagnosticSelectCollection();
				col = this.LoadObject(typeof(DiagnosticSelectCollection)) as DiagnosticSelectCollection;
				if(col != null)
				{
					this.CacheObject(typeof(DiagnosticSelectCollection),null);
					guideline.GuidelineCodes.SyncFromSelections(col);
				}
				ProcedureSelectCollection col1 = new ProcedureSelectCollection();
				col1 = this.LoadObject(typeof(ProcedureSelectCollection)) as ProcedureSelectCollection;
				if(col1 != null)
				{
					this.CacheObject(typeof(ProcedureSelectCollection),null);
					guideline.GuidelineCodes.SyncFromSelections(col1);
				}
				this.GuidelineCodes = guideline.GuidelineCodes;
				guideline.LoadGuidelineIndicators(false);
				this.GuidelineIndicators = guideline.GuidelineIndicators;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			return result;
		}

		public Guideline Guideline
		{
			get
			{
				return guideline;
			}
			set
			{
				guideline = value;
				try
				{
					this.UpdateFromObject(this.pnlGuideline.Controls,guideline);
					guideline.LoadGuidelineTips(false);
					if(guideline.GuidelineTips == null || guideline.GuidelineTips.Count == 0)
					{
						GuidelineTip tip = new GuidelineTip(true);
						guideline.GuidelineTips.Add(tip);
					}
					this.UpdateFromObject(this.pnlGuidelineTip.Controls,guideline.GuidelineTips[0]);
					guideline.LoadGuidelineIndicators(false);
					grid.UpdateFromCollection(guideline.GuidelineIndicators);
					guideline.LoadGuidelineCodes(false);
					gridCode.UpdateFromCollection(guideline.GuidelineCodes);
					this.GuidelineIndicator = null;
					this.CacheObject(typeof(Guideline),guideline);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public GuidelineCodeCollection GuidelineCodes
		{
			get
			{
				return this.guidelineCodes;
			}
			set
			{
				guidelineCodes = value;
				try
				{
					gridCode.UpdateFromCollection(guidelineCodes);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public GuidelineIndicatorCollection GuidelineIndicators
		{
			get
			{
				return this.guidelineIndicators;
			}
			set
			{
				guidelineIndicators = value;
				try
				{
					grid.UpdateFromCollection(guidelineIndicators);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public GuidelineIndicator GuidelineIndicator
		{
			get
			{
				return this.guidelineIndicator;
			}
			set
			{
				guidelineIndicator = value;
				if(guidelineIndicator == null)
				{
					this.pnlIndicator.Visible = false;
					this.pnlIndicatorTip.Visible = false;
				}
				else
				{
					pnlIndicator.Visible = true;
					pnlIndicatorTip.Visible = true;
					this.UpdateFromObject(pnlIndicator.Controls,guidelineIndicator);
					guidelineIndicator.LoadGuidelineIndicatorTips(false);
					if(guidelineIndicator.GuidelineIndicatorTips == null || guidelineIndicator.GuidelineIndicatorTips.Count == 0)
					{
						GuidelineIndicatorTip tip = new GuidelineIndicatorTip(true);
						guidelineIndicator.GuidelineIndicatorTips.Add(tip);
					}
					this.UpdateFromObject(pnlIndicatorTip.Controls,guidelineIndicator.GuidelineIndicatorTips[0]);
				}
				this.CacheObject(typeof(GuidelineIndicator),guidelineIndicator);
			}
		}

		public bool NewGuideline()
		{
			try
			{
				Guideline guideline = new Guideline(true);
				this.Guideline = guideline;
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@SAVE@", "Save", true);
			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@GUIDELINE@");
			}
		}

		public bool SaveData()
		{
			bool result = true;
			try
			{
				if(!ReadControls())
					return false;
				guideline.Save();
				// Now refresh everything w/ data from DB
				this.Guideline = guideline;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				result = false;
			}
			return result;

		}

		public bool ReadControls()
		{
			try
			{
				this.UpdateToObject(this.pnlGuideline.Controls,this.guideline);
				if(guideline.GuidelineTips.Count == 0 || guideline.GuidelineTips[0] == null)
					guideline.GuidelineTips.AddRecord(new GuidelineTip(true));
				this.UpdateToObject(this.pnlGuidelineTip.Controls,guideline.GuidelineTips[0]);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public bool ReadControlsForIndicator()
		{
			try
			{
				this.UpdateToObject(this.pnlIndicator.Controls,this.guidelineIndicator);
				
				if(guidelineIndicator.GuidelineIndicatorTips.Count == 0 || guidelineIndicator.GuidelineIndicatorTips[0] == null)
					guidelineIndicator.GuidelineIndicatorTips.AddRecord(new GuidelineIndicatorTip(true));
				this.UpdateToObject(this.pnlIndicatorTip.Controls,this.guidelineIndicator.GuidelineIndicatorTips[0]);

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
			#region Web Form Designer generated code
			override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.butAddNew.Click += new System.EventHandler(this.butAddNew_Click);
			this.btnChangeDxCode.Click += new System.EventHandler(this.btnChangeDxCode_Click);
			this.btnChangePxCode.Click += new System.EventHandler(this.btnChangePxCode_Click);
			this.butSave.Click += new System.EventHandler(this.butSave_Click);
			this.butCancel.Click += new System.EventHandler(this.butCancel_Click);
			this.butDelete.Click += new System.EventHandler(this.butDelete_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if(e.Cell.Key == "Edit")
			{
				try
				{
					//object[] pk=grid.GetPKFromCellEvent(e);
					// -- Don't get it from DB since it might be in session !!! -- Aded by Burag.
					// --- obsolete --
					//GuidelineIndicator indicator = new GuidelineIndicator();
					//indicator.Load((int)pk[0]);
					
					//this.GuidelineIndicator = indicator;
					this.GuidelineIndicator = this.GuidelineIndicators[grid.GetColIndexFromCellEvent(e)];
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void butAddNew_Click(object sender, System.EventArgs e)
		{
			this.CacheObject(typeof(Guideline),this.guideline);
			GuidelineIndicator indicator = new GuidelineIndicator(true);
			indicator.Hierarchy = 1;
			indicator.SortSequence =1;
			indicator.Active = true;
			this.GuidelineIndicator = indicator;
        }

		private void btnChangeDxCode_Click(object sender, System.EventArgs e)
		{
			ReadControls();
			this.CacheObject(typeof(Guideline),this.guideline);
			this.CacheObject(typeof(ProcedureSelectCollection),null);
			this.CacheObject(typeof(DiagnosticSelectCollection),null);
			ZippyCoderForm.Redirect(null,(DiagnosticSelectCollection)this.guidelineCodes.CreateDxPxCollection(BaseDxPx.DxPxDiagnostic));
		}

		private void btnChangePxCode_Click(object sender, System.EventArgs e)
		{
			ReadControls();
			this.CacheObject(typeof(Guideline),this.guideline);
			this.CacheObject(typeof(ProcedureSelectCollection),(ProcedureSelectCollection)this.guidelineCodes.CreateDxPxCollection(BaseDxPx.DxPxProcedure));
			this.CacheObject(typeof(DiagnosticSelectCollection),null);
			ZippyCoderForm.Redirect(null,(ProcedureSelectCollection)this.guidelineCodes.CreateDxPxCollection(BaseDxPx.DxPxProcedure));
		}

		private void butSave_Click(object sender, System.EventArgs e)
		{
			try
			{
		
				this.CacheObject(typeof(Guideline),this.guideline);
				this.ReadControlsForIndicator();
				if(this.guidelineIndicator.ParentGuidelineIndicatorCollection == null && this.guidelineIndicator.IsNew)
				{
					this.guidelineIndicators.AddRecord(guidelineIndicator);
				}
				else 
				{
					for (int i=0; i < guidelineIndicators.Count; i++)
					{
						if (this.guidelineIndicators[i].GuidelineIndicatorID == guidelineIndicator.GuidelineIndicatorID)
						{
							this.guidelineIndicators[i] = guidelineIndicator;
							break;
						}
					}
				}
					
				this.pnlIndicator.Visible = false;
				this.pnlIndicatorTip.Visible = false;
				this.GuidelineIndicators = GuidelineIndicators; // update the grid
			
				

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
				
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(this.guideline,this.guideline.GuidelineIndicators,guideline.GuidelineTips,guideline.GuidelineCodes);
		}

		private void butDelete_Click(object sender, System.EventArgs e)
		{
			try
			{
				guidelineIndicator.MarkDel();
				this.GuidelineIndicators = GuidelineIndicators;
				this.pnlIndicator.Visible = false;
				this.pnlIndicatorTip.Visible = false;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void butCancel_Click(object sender, System.EventArgs e)
		{
			this.pnlIndicator.Visible = false;
			this.pnlIndicatorTip.Visible = false;
		}

	}
}
