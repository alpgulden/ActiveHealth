using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for AssessmentParagraphMaintenance.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("AssessmentParagraph,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("AssessmentLetterMaintenance")]
	[PageTitle("@ASMTPARAGRAPHPAGETITLE@")]
	public class AssessmentParagraphMaintenance : LetterMaintenanceBasePage
	{
		private AssessmentParagraph assessmentParagraph;
		private AssessmentCategory assessmentCategory;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSortOrder;
		protected NetsoftUSA.InfragisticsWeb.WebCombo SortOrder;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSortOrder;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlTextControl;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected TextControl txTextControl;
		protected LogicSelect LogicSelect1;

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			LogicSelect1.RebindControls(typeof(AssessmentParagraph), "LogicID", "LogicDescription");

			if (!IsPostBack)
				LoadDataForAssessmentParagraph();
			else
			{
				assessmentParagraph = (AssessmentParagraph)this.LoadObject("AssessmentParagraph");  // load object from cache
				assessmentCategory = (AssessmentCategory)this.LoadObject("AssessmentCategoryObject");  // load object from cache
			}

			this.txTextControl.AutoPostBack = false;
			this.txTextControl.TextControlMode = TextControlModeEnum.Full;
			this.txTextControl.IsParagraphEditor = true;
			this.txTextControl.MatrixTypeID = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCMSTypeID(assessmentCategory.CMSTypeID);
		}

		#region Paragraph
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentParagraph AssessmentParagraph
		{
			get { return assessmentParagraph; }
			set
			{
				assessmentParagraph = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, assessmentParagraph);  // update controls for the given control collection
					// other object-to-control methods if any

					// Load the body
					txTextControl.Text = assessmentParagraph.AssessmentParagraphBody.AssessmentParagraphBodyText;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("AssessmentParagraph", assessmentParagraph);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAssessmentParagraph()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, assessmentParagraph);	// controls-to-object
				// other control-to-object methods if any

				assessmentParagraph.AssessmentParagraphBody.AssessmentParagraphBodyText = txTextControl.Text;
				assessmentParagraph.AssessmentParagraphBrief = txTextControl.GetText(TxHelper.TextFormat.ANSIText);

				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForAssessmentParagraph()
		{
			bool result = true;
			AssessmentParagraph assessmentParagraph = new AssessmentParagraph();
			try
			{	// use any load method here
				assessmentParagraph = GetParamOrGetFromCache("AssessmentParagraph", typeof(AssessmentParagraph)) as AssessmentParagraph;
				if (assessmentParagraph == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an Assessment Paragraph");

				assessmentCategory = GetParamOrGetFromCache("AssessmentCategoryObject", typeof(AssessmentCategory)) as AssessmentCategory;
				if (assessmentCategory == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an Assessment Category");
				this.CacheObject("AssessmentCategoryObject", assessmentCategory);

				assessmentParagraph.ParentAssessmentCategory = assessmentCategory;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//assessmentParagraph.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.AssessmentParagraph = assessmentParagraph;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(AssessmentParagraph assessmentParagraph, AssessmentCategory assessmentCategory)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("AssessmentParagraph", assessmentParagraph);
			BasePage.PushParam("AssessmentCategoryObject", assessmentCategory);
			BasePage.Redirect("AssessmentParagraphMaintenance.aspx");

		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForAssessmentParagraph()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForAssessmentParagraph())
					return false;
				assessmentParagraph.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region UI Initialization and Events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e); 
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@CANCEL@", "Back", false);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForAssessmentParagraph())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Assessment Paragraph "); 
			}
		}

		public void OnToolbarButtonClick_Back(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PushTargetTab("Paragraphs");
			AssessmentLetterMaintenance.Redirect(this.assessmentCategory);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.IsDirty = assessmentParagraph.IsDirty || txTextControl.IsDirty;
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(assessmentCategory);
		}


		#endregion
	}
}
