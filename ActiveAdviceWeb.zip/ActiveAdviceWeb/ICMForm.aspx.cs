using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for ICMForm.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("AssessmentScoringQuestionnaireTrigger,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("IcmQR")]
	public class ICMForm : AssessmentMaintenanceBasePage
	{
		private AssessmentScoringQuestionnaireTrigger assessmentScoringQuestionnaireTrigger;
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldValueID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ValueID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbValueID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAttributeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo AttributeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAttributeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldComponentID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ComponentID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbComponentID;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForPatient;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected QuestionnaireSelect QuestionnaireSelect1;
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			QuestionnaireSelect1.RebindControls(typeof(AssessmentScoringQuestionnaireTrigger), "QuestionnaireID", "QuestionnaireDescription", true);

			if (!IsPostBack)
				LoadData();
			else
				assessmentScoringQuestionnaireTrigger = (AssessmentScoringQuestionnaireTrigger)this.LoadObject(typeof(AssessmentScoringQuestionnaireTrigger));  // load object from cache

		}

		#region AssessmentScoringQuestionnaireTrigger
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentScoringQuestionnaireTrigger AssessmentScoringQuestionnaireTrigger
		{
			get { return assessmentScoringQuestionnaireTrigger; }
			set
			{
				assessmentScoringQuestionnaireTrigger = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, assessmentScoringQuestionnaireTrigger);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AssessmentScoringQuestionnaireTrigger), assessmentScoringQuestionnaireTrigger);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, assessmentScoringQuestionnaireTrigger);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewData()
		{
			bool result = true;
			AssessmentScoringQuestionnaireTrigger assessmentScoringQuestionnaireTrigger = null;
			try
			{	// or use an initialization method here
				assessmentScoringQuestionnaireTrigger = new AssessmentScoringQuestionnaireTrigger(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.AssessmentScoringQuestionnaireTrigger = assessmentScoringQuestionnaireTrigger;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			AssessmentScoringQuestionnaireTrigger assessmentScoringQuestionnaireTrigger = null;
			try
			{	// use any load method here
				Questionnaire questionnaire = (Questionnaire)this.GetParam("Questionnaire", null);
				if(questionnaire != null)
				{
					//create new AssessmentScoringQuestionnaireTrigger from given Questionnaire
					assessmentScoringQuestionnaireTrigger = new AssessmentScoringQuestionnaireTrigger(questionnaire);
				}
				else
				{
					assessmentScoringQuestionnaireTrigger = (AssessmentScoringQuestionnaireTrigger)this.GetParam("AssessmentScoringQuestionnaireTrigger", null);
					if(assessmentScoringQuestionnaireTrigger == null)
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an AssessmentScoringQuestionnaireTrigger");
				}
				this.AssessmentScoringQuestionnaireTrigger = assessmentScoringQuestionnaireTrigger;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//assessmentScoringQuestionnaireTrigger.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.AssessmentScoringQuestionnaireTrigger = assessmentScoringQuestionnaireTrigger;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(AssessmentScoringQuestionnaireTrigger assessmentScoringQuestionnaireTrigger)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("AssessmentScoringQuestionnaireTrigger", assessmentScoringQuestionnaireTrigger);
			BasePage.Redirect("ICMForm.aspx");

		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Questionnaire questionnaire)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Questionnaire", questionnaire);
			BasePage.Redirect("ICMForm.aspx");

		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				assessmentScoringQuestionnaireTrigger.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region UI Initialization and Events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			//pageSummary.RenderObjects(this.patient, this.erc);
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Trigger ");
			}
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "AssmtScoringQRTrigger":
					toolbar.AddButton(Messages.BaseMessages.MessageIDs.ADDNEWRECORD, "AddNewTrigger");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewTrigger(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewData();	
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
		}

		#endregion
	}
}
