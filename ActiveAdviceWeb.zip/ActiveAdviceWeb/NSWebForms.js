
// NETSOFT USA WebForms Library script file

//****************** Custom dropdown functions *********************

function OpenCustomDropDown(exp, targetName)
{
	//var exp = document.all(expanderName)
	exp.targetCtl = document.all(targetName)
	exp.toggleExpand();
}

function SetTargetCtlValue(exp, val)
{
	if (exp.targetCtl)
		if (!exp.targetCtl.disabled && !exp.targetCtl.readOnly)
			exp.targetCtl.value = val;
}

//****************** Table checkbox toggler ************************
	
function toggleAll(selTable, column, obj)
{
	if (obj.checked)
		checkAll(selTable, column, true);
	else
		checkAll(selTable, column, false);
}

function checkAll(selTable, column, checkValue)
{
	//var selTable = document.all("SelectInvoicesTable");
	var len = selTable.rows.length;
	for (var i = 0; i < len; i++)
	{
		if (i != 0)
		{
			var row = selTable.rows(i);
			var e = row.cells(column).firstChild;
			e.checked=checkValue;
		}	
	}
}

//******************    Pop up Window    ****************************


var oPopup;

function OpenPopup(text, width, height, left, top, className)
{
	if (!width) width = 300;
	if (!height) height = 50;
	if (!left) left = (document.body.offsetWidth / 2) - (width / 2);
	if (!top) top = (document.body.offsetHeight / 2) - (height - 2);
	if (!className) className = "PopupMessage";

	oPopup = window.createPopup();
	var oPopBody = oPopup.document.body;
	oPopup.document.createStyleSheet(document.styleSheets[0].href);
	oPopBody.className = "PopupBody";
	oPopBody.innerHTML += "<DIV class=" + className + ">" + text + "</DIV>";
	oPopup.show(left, top, width, height, document.body);
	
	return oPopup;
}

function DisplayLoadingMessage()
{
	try
	{
		var width = 120;
		var height = 20;

		if (!oPopup || !oPopup.isOpen)
			OpenPopup("Please Wait...", width, height, document.body.offsetWidth - (width + 20), 5, "LoadingMessage");
		
		if (Page_IsSubmitted || document.readyState == "interactive")
			window.setTimeout("DisplayLoadingMessage();", 10);
		else
			DisplayCompleteMessage();
	}
	catch(ex)
	{}
}

function DisplayCompleteMessage()
{
	try
	{
		var width = 100;
		var height = 30;

		var popup = OpenPopup("Completed...", width, height, document.body.offsetWidth - (width + 20), 5, "LoadingMessage");
		popup.hide();			
	}
	catch(ex)
	{}
}

window.setTimeout("DisplayLoadingMessage();", 50);
//DisplayLoadingMessage();


//****************** WindowOpener Class ****************************

function WindowOpener(windowName, navigateUrl, windowWidth, windowHeight)
{
	this.windowName = windowName;
	this.navigateUrl = navigateUrl;
	this.windowWidth = windowWidth;
	this.windowHeight = windowHeight;
	//this.pickTarget = null;
	this.toolBar = 1;
	this.statusBar = 1;
	this.menuBar = 1;
	this.scrollBars = 1;
	this.resizable = 1;
	this.copyHistory = 1;
	this.addressBar = 1;
	this.linksBar = 1;
	this.window = null;
	this.afterOpen = null;
	this.beforeOpenFunction = null;
	this.open = WindowOpener_open;
	this.close = WindowOpener_close;
	this.notify = WindowOpener_notify;
	this.windowMode = 0;		// NewWindow = 0, ModalDialog = 1, ModelessDialog = 2
}
	
function WindowOpener_open()
{
	// call the before open function if defined
	if (this.beforeOpenFunction!=null)
		if (!this.beforeOpenFunction(this))	// passes the window opener object
			return;		// if false is returned, doesn't open the window.

	var bopen = false;
	if (this.window==null)
		bopen = true;
	else
		if (this.window.closed)
			bopen = true;
	if (bopen)
	{		
		var url = this.navigateUrl;
		
		var i = 0;
		var l = url.length;
		//window.alert(url);
		
		while (i < l)
		{	
			var origUrl = url;
			var i1 = origUrl.indexOf("@", i);
			if (i1 < 0)
				break;
			var i2 = origUrl.indexOf("@", i1 + 1);
			if (i2 < 0)
				break;
			var key = origUrl.substring(i1 + 1, i2);
			//var val = document.all(key).value.split('-')[0];
			var val = GetElemValue(key);
			i2++;
			url = origUrl.substring(0, i1) + val;
			i = url.length;		// the new i is the position starting from the end of substitution
			url += origUrl.substring(i2, l);
			l = url.length;
			//window.alert(i1 + ': '+ url);
			//i = i2 + 1 + val.length - key.length;
		}
		
		//window.alert(url);
		
		OpenPopup("Please Wait...", 160, 30);
		
		if (this.windowWidth==0 || this.windowWidth=='' || this.windowWidth==null)
			this.windowWidth = '750px';
		if (this.windowHeight==0 || this.windowHeight=='' || this.windowHeight==null)
			this.windowHeight = '750px';
			
		this.windowMode = 2;			// temporarily force modal dialog.
		
		if (this.windowMode == 0)		// new window
		{
			this.window = window.open(url,this.windowName,
			'left='+this.windowLeft+',top='+this.windowTop+
			',width='+this.windowWidth+',height='+this.windowHeight+
			',status='+this.statusBar+',toolbar='+this.toolBar+
			',menubar='+this.menuBar+',scrollbars='+this.scrollBars+
			',resizable='+this.resizable+',copyhistory='+this.copyHistory+
			',location='+this.addressBar+',directories='+this.linksBar);
		}
		else if (this.windowMode == 2)	// modal dialog
		{
		
			if (url.indexOf('?') >= 0)
				url = url + "&rnd=" + new Date().valueOf();
			else
				url = url + "?rnd=" + new Date().valueOf();
				
			this.window = window.showModalDialog(url,window,
			'dialogLeft:'+this.windowLeft+'; dialogTop:'+this.windowTop+
			'; dialogWidth:'+this.windowWidth+'; dialogHeight:'+this.windowHeight+
			';status:'+this.statusBar+'; toolbar:'+this.toolBar+
			'; menubar:'+this.menuBar+'; scroll:'+this.scrollBars+
			'; resizable:'+this.resizable+'; copyhistory:'+this.copyHistory+
			'; location:'+this.addressBar+'; directories:'+this.linksBar+'; unadorned:yes; center:yes;');
		}
		else if (this.windowMode == 3)	// modeless dialog
		{
			this.window = window.open(url,this.windowName,
			'left='+this.windowLeft+',top='+this.windowTop+
			',width='+this.windowWidth+',height='+this.windowHeight+
			',status='+this.statusBar+',toolbar='+this.toolBar+
			',menubar='+this.menuBar+',scroll='+this.scrollBars+
			',resizable='+this.resizable+',copyhistory='+this.copyHistory+
			',location='+this.addressBar+',directories='+this.linksBar);
		}
	}
	// call the window specific after open function if defined
	if (this.afterOpen!=null)
		this.afterOpen();
}

function WindowOpener_close()
{
	if (this.window != null)
		this.window.close();
}

function WindowOpener_notify()
{
}

				
//****************** Expandable Class ****************************
function Expandable(targetCtl, bfloating, bautoHide)
{
	this.ctl = targetCtl;
	this.expand = expandControl;
	this.expandXY = expandControlXY;
	this.isExpanded = isControlExpanded;
	this.toggleExpand = toggleExpandControl;
	this.expandForCheckBox = expandForCheckBox;
	this.controllingCheckBox = null;
	targetCtl.expandableObject = this;		// associate this to the target object
	if (bfloating == null)
		this.bfloating = false;
	else
		this.bfloating = bfloating;
	if (bautoHide == null)
		this.bautoHide = false;
	else
		this.bautoHide = bautoHide;
}

function getObjOrFirstItem(obj)
{
	return (obj.length!=null)?obj[0]:obj;
}

/*function IsContainedIn(obj, container)
{
	while (obj != null)
	{
		if (obj == container)
			return true;
		obj = obj.parentElement;
	}
	return false;
}*/

function GetContainingExpandable(obj)
{
	while (obj != null)
	{
		if (obj.expandableObject != null)
			return obj.expandableObject;
		obj = obj.parentElement;
	}
	return null;
}

function onDocumentMouseDown()
{
	if (document.currentExpandable != null)
		if (event.srcElement ==	document.currentExpandable.controllingCheckBox)
			return;
	var containingExpandable = GetContainingExpandable(event.srcElement);
	if (containingExpandable != document.currentExpandable)
		document.currentExpandable.expand(false);
}

function onDocumentMouseOut()
{
	if (event.toElement != null)
		return;
	var containingExpandable = GetContainingExpandable(event.srcElement);
	if (containingExpandable != document.currentExpandable)
		document.currentExpandable.expand(false);
}

function absEventX()
{
	var ctl = event.srcElement;
	return document.body.scrollLeft + event.clientX - ctl.offsetWidth / 2; // - event.offsetX - ctl.offsetLeft;// - 5;
	//return document.body.clientLeft + ctl.offsetLeft; //document.body.scrollLeft + event.clientX; // - event.offsetX - ctl.offsetLeft;// - 5;
	//document.body.clientLeft + ctl.offsetLeft
}

function absEventY()
{
	var ctl = event.srcElement;
	return document.body.scrollTop + event.clientY + ctl.offsetHeight;// - event.offsetY - ctl.offsetTop + ctl.offsetHeight + ctl.height-25;// - 3 + 20;
	//return document.body.clientTop + ctl.offsetTop ; //document.body.scrollTop + event.clientY + ctl.offsetHeight - 20;// - event.offsetY - ctl.offsetTop + ctl.offsetHeight + ctl.height-25;// - 3 + 20;
	//document.body.clientTop + ctl.offsetTop ; 
}

function isControlExpanded()
{
	if (this.ctl.style.display == "")
		return true;
	else
		return false;
}

function expandForCheckBox()
{
	this.expand(this.controllingCheckBox.checked, this.controllingCheckBox);
}

function expandControl(bexpand, controllingCheckBox)
{
	this.expandXY(bexpand, absEventX(), absEventY(), controllingCheckBox);
}

function toggleExpandControl(controllingCheckBox)
{
	if (this.isExpanded())
		this.expand(false, controllingCheckBox);
	else
		this.expand(true, controllingCheckBox);
}

function expandControlXY(bexpand, x, y, controllingCheckBox)
{
	if (bexpand == this.isExpanded())
		return;
	if (bexpand)
	{
		var objStyle = this.ctl.style;
		objStyle.display = "";
		if (this.bfloating)
		{
			//objStyle.posLeft = x;
			//objStyle.posTop = y;
			objStyle.left = x;
			objStyle.top = y;
			document.all[this.ctl.id + "_abspos"].value = x + "," + y;
		}
		if (this.bautoHide)
		{
			document.currentExpandable = this;
			document.onmouseup = onDocumentMouseDown;
			document.onmouseout = onDocumentMouseOut;
			this.ctl.onmouseout = onDocumentMouseOut;
		}
		if (controllingCheckBox == null)	// if called by checkbox, don't check it
			if (this.controllingCheckBox != null)
				this.controllingCheckBox.checked = true;
	}
	else
	{
		this.ctl.style.display = "none";
		if (this.bautoHide)
		{
			document.currentExpandable = null;
			document.onmouseup = null;
			document.onmouseout = null;
			this.ctl.onmouseout = null;
		}
		if (controllingCheckBox == null)	// if called by checkbox, don't check it
			if (this.controllingCheckBox != null)
				this.controllingCheckBox.checked = false;
	}
}

function NavRollOver(oTd) 
{
	if (!oTd.contains(event.fromElement)) {oTd.bgColor="#FFCC66";}
}

function NavRollOut(oTd) 
{
	if (!oTd.contains(event.toElement)) {oTd.bgColor="#FFFFFF";}
}

//*************** Date time functions ********************
function DiffDays(date1, date2)
{
	return Math.round((date2 - date1) / 864e5);
}

function RemoveChars(s, chars)
{
	var i = 0;
	if (s == null)
		return null;
	var news = "";
	for (i = 0; i < s.length; i++)
	{
		var ch = s.substring(i, i+1);
		if (chars.indexOf(ch) < 0)
			news += ch;	
	}
	return news;
}

function FormatPhone(s)
{
	if (s == null)
		return null;
		
	var sorig = s;
		
	s = RemoveChars(s, " -()");
	/*s = s.replace(" ", "");
	s = s.replace("-", "");
	s = s.replace("(", "");
	s = s.replace(")", "");*/
	
	//2012223344
	if (s.length == 11)
		s = s.substr(1, 10);
		
	if (s.length == 10)
		return s.substr(0, 3) + "-" + s.substr(3, 3) + "-" + s.substr(6, 4);
		
	if (s.length == 7)
		return s.substr(0, 3) + "-" + s.substr(3, 4);

	return sorig;
}

function ThouS(SS) 
{ 
  var X = "", S = String(SS), L // SS >= 0
  while (S != ""){ L = S.length-3
    X = S.substr(L, 3) + (X>"" ? ','+X : '')
    S = S.substr(0, L) }
  return X 
}

function Comma(SS) 
{ 
  var T='', S=String(SS), L=S.length-1, C, j
  for (j=0; j<=L; j++) {
    T+=C=S.charAt(j)
    if ((j < L) && ((L-j)%3 == 0) && (C != '-')) T+=',' }
  return T 
}

function FComma(SS)
{ 
  var T='', S=String(SS), L=S.length-1, C, j, P = S.indexOf('.')-1
  if (P<0) P=L
  for (j=0; j<=L; j++) {
    T+=C=S.charAt(j)
    if ((j < P) && ((P-j)%3 == 0) && (C != '-')) T+=',' }
  return T 
}

function RemoveCommas(s) 
{
  var regEx = /,/g;
  return s.replace(regEx,'');
}

function ReplacePattern(s, pattern, replace) 
{
  var regEx =  new RegExp(pattern, 'gi' );
  return s.replace(regEx, replace);
}

function FormatThousands(s)
{
	return FComma(s);
}

function FormatCurrency(s)
{
	if (s == null)
		return null;
	if (typeof(s)!="string")
		s = s.toString();
	s = RemoveChars(s, " ,");
	/*s = s.replace(" ", "");
	s = s.replace(",", "");*/
	
	//122,22.55
	if (s == "")
		return "";
	var v;
	v = parseFloat(s);
	v = Math.round(v * 100) / 100;
	return FComma(v.toFixed(2));
}

function FormatAllUpperCase(s)
{
	if (s==null)
		return null;
	return s.toUpperCase();
}

function FormatAllLowerCase(s)
{
	if (s==null)
		return null;
	return s.toLowerCase();
}

function ParseFloat(s)
{
	if (s == null)
		return 0;
	s = RemoveChars(s, " ,");
	/*s = s.replace(" ", "");
	s = s.replace(",", "");*/
	if (s == "")
		return 0;
	return parseFloat(s);
}

function ParseCurrency(s)
{
	return ParseFloat(s);
}

function ParseDate(s)
{
	if (Date.parse(s) == 'Nan')
	{
		s = RemoveChars(s, " ");
		//s = s.replace(" ", "");
		if (s == null || s == "")
			return null;
	}
		
	return new Date(Date.parse(s));
}

function ParseDateYear(s)
{
	return ParseDate(s).getFullYear();
}

function ParseInt(s)
{
	if (s == null)
		return 0;
	s = RemoveChars(s, " ,");
	/*s = s.replace(" ", "");
	s = s.replace(",", "");*/
	if (s == "")
		return 0;
	return parseInt(s);
}

/// Validation functions

function ValidateCurrency(s)  
{
  var regEx = /(^\$\d{1,3}(,\d{3})*\.\d{2}$)|(^\(\$\d{1,3}(,\d{3})*\.\d{2}\)$)/;
  return regEx.test(s);
}

function ValidateCurrency(s)  
{
  var regEx = /(^\$\d{1,3}(,\d{3})*\.\d{2}$)|(^\(\$\d{1,3}(,\d{3})*\.\d{2}\)$)/;
  return regEx.test(s);
}

function ValidateTime (s) 
{
  // HH:MM or HH:MM:SS or HH:MM:SS.mmm
  var regEx = /^([1-9]|1[0-2]):[0-5]\d(:[0-5]\d(\.\d{1,3})?)?$/;
  return regEx.test(s);
}

function ValidateState (s) 
{
  var regEx = /^(AK|AL|AR|AZ|CA|CO|CT|DC|DE|FL|GA|HI|IA|ID|IL|IN|KS|KY|LA|MA|MD|ME|MI|MN|MO|MS|MT|NB|NC|ND|NH|NJ|NM|NV|NY|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VA|VT|WA|WI|WV|WY)$/i; 
  return regEx.test(s);
}

function ValidateSSN(s) 
{
  var regEx = /^\d{3}\-\d{2}\-\d{4}$/;
  return regEx.test(s);
}

function ValidateEmail(s) 
{
  var regEx = /^[a-z0-9]([a-z0-9_\-\.]*)@([a-z0-9_\-\.]*)(\.[a-z]{2,3}(\.[a-z]{2}){0,2})$/i;
  return regEx.test(s);
}

function ValidateUSPhone(s) 
{
  // (999) 999-9999 or (999)999-9999
  var regEx = /^\([1-9]\d{2}\)\s?\d{3}\-\d{4}$/;
  return regEx.test(s); 
}

function ValidateNumeric(s) 
{
  var regEx =  /(^-?\d\d*\.\d*$)|(^-?\d\d*$)|(^-?\.\d\d*$)/; 
  return regEx.test(s);
}

function ValidateInteger(s) 
{
  var regEx = /(^-?\d\d*$)/;
  return regEx.test(s);
}

function ValidateUSZip(s) 
{
  // 99999 or 99999-9999
  var regEx  = /(^\d{5}$)|(^\d{5}-\d{4}$)/;
  //check for valid US Zipcode
  return regEx.test(s);
}

function ValidateUSDate(strValue)
{
    //Ex. mm/dd/yyyy or mm-dd-yyyy or mm.dd.yyyy
  var objRegExp = /^\d{1,2}(\-|\/|\.)\d{1,2}\1\d{4}$/
 
  //check to see if in correct format
  if(!objRegExp.test(strValue))
    return false; //doesn't match pattern, bad date
  else{
    var arrayDate = strValue.split(RegExp.$1); //split date into month, day, year
	var intDay = parseInt(arrayDate[1],10); 
	var intYear = parseInt(arrayDate[2],10);
    var intMonth = parseInt(arrayDate[0],10);
	
	//check for valid month
	if(intMonth > 12 || intMonth < 1) {
		return false;
	}
	
    //create a lookup for months not equal to Feb.
    var arrayLookup = { '01' : 31,'03' : 31, '04' : 30,'05' : 31,'06' : 30,'07' : 31,
                        '08' : 31,'09' : 30,'10' : 31,'11' : 30,'12' : 31}
  
    //check if month value and day value agree
    if(arrayLookup[arrayDate[0]] != null) {
      if(intDay <= arrayLookup[arrayDate[0]] && intDay != 0)
        return true; //found in lookup table, good date
    }
		
    //check for February
	var booLeapYear = (intYear % 4 == 0 && (intYear % 100 != 0 || intYear % 400 == 0));
    if( ((booLeapYear && intDay <= 29) || (!booLeapYear && intDay <=28)) && intDay !=0)
      return true; //Feb. had valid number of days
  }
  return false; //any other values, bad date
}

function ValidateRegEx(s, pattern) 
{
  var regEx = new RegExp(pattern);
  return regEx.test(s);
}


///  Element accessors

function GetElem(id)
{
	//return document.getElementById(id)
	return document.getElementById(id);
}

function GetElemValue(id)
{
	if (typeof(ValidatorGetValue) == "function")
	{
		return ValidatorGetValue(id);
	}
	else
	{
		return GetElem(id).value;
	}
}

function SetElemValue(id, value)
{
	var elem = GetElem(id);
	
	if (elem != null)
		elem.value = value;
		
	if (typeof(igedit_getById) == "function")
	{
		var ctl = igedit_getById(id);
		if (ctl != null)
			ctl.setValue(value);		// set textboxes only
	}
}

/*// first parameter is the format, the rest are control names to be substituted
// format string must be something like:    "@control1@/@control2@/@control3@"
// control names are written inside @'s
//     SubstituteControlValues("@control1@/@control2@/@control3@", 
function SubstituteControlValues(format)
{
    var argv = SubstituteControlValues.arguments;
    var argc = argv.length;
    var format = argv[0];		// first param is the format
    for (var i = 1; i < argc; i++) 
    {
		argv[i]);
	}
}*/

function LTrim(str, whitespace)
{
  if (whitespace == null)
    whitespace = new String(" \t\n\r");

  var s = new String(str);

  if (whitespace.indexOf(s.charAt(0)) != -1) {
    // We have a string with leading blank(s)...

    var j=0, i = s.length;

    // Iterate from the far left of string until we
    // don't have any more whitespace...
    while (j < i && whitespace.indexOf(s.charAt(j)) != -1)
    j++;


    // Get the substring from the first non-whitespace
    // character to the end of the string...
    s = s.substring(j, i);
  }

  return s;
}

function RTrim(str, whitespace)
{
  // We don't want to trip JUST spaces, but also tabs,
  // line feeds, etc.  Add anything else you want to
  // "trim" here in Whitespace
  if (whitespace == null)
    whitespace = new String(" \t\n\r");

  var s = new String(str);

  if (whitespace.indexOf(s.charAt(s.length-1)) != -1) {
    // We have a string with trailing blank(s)...

    var i = s.length - 1;       // Get length of string

    // Iterate from the far right of string until we
    // don't have any more whitespace...
    while (i >= 0 && whitespace.indexOf(s.charAt(i)) != -1)
      i--;


    // Get the substring from the front of the string to
    // where the last non-whitespace character is...
    s = s.substring(0, i+1);
  }

  return s;
}

function Trim(str, whitespace)
{
  return RTrim(LTrim(str, whitespace), whitespace);
}


// first parameter is the format
// format string must be something like:    "@control1@/@control2@/@control3@"
// control names are written inside @'s
//     SubstituteControlValues("@control1@/@control2@/@control3@")
function SubstituteControlValues(format)
{
	var regex = /@(\w)+@/;
	
	var arr = format.match(regex);
	var nullValue = true;
	while (arr != null)
    {
		var item = arr[0];
		var ctlName = Trim(item, '@');
		//window.alert(item);
		//window.alert(item + "=" + GetElemValue(ctlName));
		var val = GetElemValue(ctlName);
		if (val != null && val != "")
			nullValue = false;
		format = format.replace(new RegExp(item,"gmi"), val);
		arr = format.match(regex);
	}
	if (nullValue)
		return "";
	else
		return format;
}

function FormatMTB(format)
{
	if (format == null)
		return "";
	if (format.length == 0)
		return "";
	return SubstituteControlValues(format);
}


function findPosY(objID)
{
	//alert('finding pos');
	var obj = GetElem(objID);
	if (obj)
	{
		var curtop = 0;
		if (obj.offsetParent)
		{
			while (obj.offsetParent)
			{
				curtop += obj.offsetTop
				obj = obj.offsetParent;
			}
		}
		else if (obj.y)
			curtop += obj.y;
		
		return curtop;
	}
	else
		return 0;
}

function findPosX(objID)
{
	var curleft = 0;
	var obj = GetElem(objID);	
	if (obj.offsetParent)
	{
		while (obj.offsetParent)
		{
			curleft += obj.offsetLeft
			obj = obj.offsetParent;
		}
	}
	else if (obj.x)
		curleft += obj.x;
	return curleft;
}



function saveScroll() 
{
	//alert('saving');
	var scrollSaver = "scrollSaver";

	if (GetElem(scrollSaver))
	{
		GetElem(scrollSaver).value = document.body.scrollLeft + '&' + document.body.scrollTop;
	}
}

function doScroll(targetX, targetY)
{
	//alert('scrolling');
	window.scrollTo(targetX, targetY);	
}


function doScrollToControl(objID)
{
	doScroll(0, findPosY(objID) / (1.5));
}


function calendar(strTextBox)
{
	var woCalendar = new WindowOpener("Calendar", "DatePicker.aspx?textbox=" + strTextBox, "300px", "250px");
	woCalendar.resizable = 0;
	woCalendar.open();

	//window.open('DatePicker.aspx?textbox=' + strTextBox, 'calendar', 'width=250,height=200,resizable=no');
}



function MaskDate(str, textbox, loc, delim)
{
	str = str.replace(delim, '');
	var locs = loc.split(',');
	for (var i = 0; i <= locs.length; i++)
	{
		for (var k = 0; k <= str.length; k++)
		{ 
			if (k == locs[i])
			{	  
				if (str.substring(k, k+1) != delim)
					str = str.substring(0,k) + delim + str.substring(k, str.length)  
			}	
		} 
	} 
	textbox.value = str; 
}

var numericInput = "01234567890";
var decimalInput = "01234567890.";

function RestrictKeyboard(textbox, validCharacters)
{
	var found = false;
	for(i = 0; i < validCharacters.length; i++)
		if(window.event.keyCode == validCharacters.charCodeAt(i)) 
		{
			found = true;
			break;
		}
	if (!found)
		window.event.returnValue = false;
}






