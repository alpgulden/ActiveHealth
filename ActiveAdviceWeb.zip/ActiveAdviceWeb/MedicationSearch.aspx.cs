using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for MedicationSearch.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]	
	[MainDataClass("Medication,DataLayer")]	
	public class MedicationSearch : /*PatientBasePage*/BasePage
	{
		private MedicationCollection medications;
		private Medication medicationSearcher;
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMedication;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldBrandName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit BrandName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBrandName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNameType;
		protected NetsoftUSA.InfragisticsWeb.WebCombo NameType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNameType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSelectedMedicationNameTypeInt;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSearchName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit SearchName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSearchName;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBComboBox SelectedMedicationNameTypeInt;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			
			if (!this.IsPostBack)
				this.NewMedicationSearch();
			else
				medicationSearcher = (Medication)this.LoadObject("MedicationSearcher");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grid_ColumnsBoundToDataClass);
			this.grid.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.grid_RowBoundToDataObject);

			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		public override EnumPageType PageType
		{
			get
			{
				return base.PageType;
			}
			set
			{
				base.PageType = value;

				// page specific rule:  all data entry pages must check for required field validators
				this.RequiredValidationsEnabled = true;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Medication MedicationSearcher
		{
			get { return medicationSearcher; }
			set
			{
				medicationSearcher = value;
				try
				{
					this.UpdateFromObject(this.pnlMedication.Controls, medicationSearcher);  // update controls for the given control collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("MedicationSearcher", medicationSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlMedication.Controls, medicationSearcher);	// controls-to-object
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewMedicationSearch()
		{
			bool result = true;
			
			Medication medicationSearcher = null; 
			try
			{
				medicationSearcher = new Medication(); // use a parameterized constructor which also initializes the data object
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.MedicationSearcher = medicationSearcher;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MedicationCollection Medications
		{
			get { return medications; }
			set
			{
				medications = value;
				try
				{
					grid.UpdateFromCollection(medications);  // update given grid from the collection
					if(medications.Count >= MedicationCollection.MAXRECORDS)
						this.SetPageMessage("@BIGGERRESULTSET@", EnumPageMessageType.AddInfo, MedicationCollection.MAXRECORDS, Messages.PatientMessages.MessageIDs.MEDICATIONS);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			MedicationCollection medications = new MedicationCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				medications.SearchMedications(medicationSearcher);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.Medications = medications;
			return result;
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{	
			if (this.HasCallbackFunction)                   // only if this is a popup
				grid.AddColumn("Pick", "@PICK@", 0);             // added as a regular column
		}

		private void grid_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
            if (cell != null)
            {
				Medication med = e.data as Medication;
				e.row.Cells.FromKey("Pick").Text = this.GetCallbackFunctionHyperLink("Pick", med.MedicationId, med.BrandName, med.GenericName, med.EtcName, med.NDC);
            }
		}
	}
}
