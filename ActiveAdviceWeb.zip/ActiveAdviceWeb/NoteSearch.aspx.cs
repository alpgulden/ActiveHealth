using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for NoteSearch.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.NOTES)]
	
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Note,DataLayer")]
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Notes")]
	[PageTitle("@NOTEPAGETITLE@")]
	public class NoteSearch : PatientBasePage
	{
		private Note noteTemplate;
		private NoteCollection notes;
		private Note noteSearcher;
		private Patient patient;
		private Problem problem;
		private BaseForEventCMSReferral erc;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSearch;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNoteTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActiveWithAll;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EventID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ReferralId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferralId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProblemId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProblemId;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDateTo;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DateTo;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateTo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDateFrom;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DateFrom;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateFrom;
		protected NetsoftUSA.WebForms.OBRadioButtonBox dateOption;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCreatedBy;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBComboBox NoteTypeID;
		protected NetsoftUSA.WebForms.OBComboBox CreatedBy;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnReset;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.wbtnSearch.Click += new System.EventHandler(this.wbtnSearch_Click);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grid_ColumnsBoundToDataClass);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.wbtnReset.Click += new System.EventHandler(this.wbtnReset_Click);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.ViewStateOnServer = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
			{
				NewNoteSearcher();
				NewNoteTemplate();
				SearchForNotes();	//bring patient's notes by default - enhancement.
			}
			else
			{
				noteSearcher = (Note)this.LoadObject("NoteSearcher");  // load object from cache
				notes = (NoteCollection)this.LoadObject(typeof(NoteCollection));  // load object from cache
				noteTemplate = (Note)this.LoadObject("NoteTemplate");  // load object from cache
			}
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(EnumActivityAndNoteContext context)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("EnumActivityAndNoteContext", context);
			BasePage.Redirect("NoteSearch.aspx");

		}

		public static void Redirect(Note note)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("NoteTemplate", note);
			BasePage.Redirect("NoteSearch.aspx");

		}

		#region NoteSearcher
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Note NoteSearcher
		{
			get { return noteSearcher; }
			set
			{
				noteSearcher = value;
				try
				{
					this.UpdateFromObject(this.pnlSearch.Controls, noteSearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("NoteSearcher", noteSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForNoteSearcher()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSearch.Controls, noteSearcher);	// controls-to-object
				// other control-to-object methods if any
				noteSearcher.DateSelection = Int32.Parse(this.dateOption.SelectedItem.Value);
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewNoteSearcher()
		{
			bool result = true;
			Note noteSearcher = null;
			try
			{	// or use an initialization method here
				Patient patient = null;

				patient = GetParamOrGetFromCache("Patient", typeof(Patient) ) as Patient;
				if (patient == null)
				{
					this.RaisePageException(new Exception("You must hit this page in the context of a patient"));
					return false;
				}

				noteSearcher = new Note(patient, false);
				noteSearcher.ActiveWithAll = 1;		// default to Active records
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.NoteSearcher = noteSearcher;
			return result;
		}
		#endregion

		#region Notes
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public NoteCollection Notes
		{
			get { return notes; }
			set
			{
				notes = value;
				try
				{
					grid.UpdateFromCollection(notes);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(NoteCollection), notes);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool SearchForNotes()
		{
			bool result = true;
			NoteCollection notes = new NoteCollection();
			try
			{
				if (!this.ReadControlsForNoteSearcher()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				notes = NoteCollection.GetFromSearch(this.noteSearcher);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//notes.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Notes = notes;
			return result;
		}
		#endregion

		#region NoteTemplate
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Note NoteTemplate
		{
			get { return noteTemplate; }
			set
			{
				noteTemplate = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, noteTemplate);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("NoteTemplate", noteTemplate);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewNoteTemplate()
		{
			bool result = true;
			Note noteTemplate = null; //new Note(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here

				noteTemplate = (Note)this.GetParam("NoteTemplate");
				if(noteTemplate != null)
				{
					this.NoteTemplate = Note.CreateNoteFromNoteAndSet(noteTemplate);
					return result;
				}
				
				object contextObj = this.GetParam("EnumActivityAndNoteContext");
				if(contextObj == null)
				{
					this.RaisePageException(new Exception("You must hit this page with EnumActivityAndNoteContext set"));
					return false;
				}
				EnumActivityAndNoteContext context = (EnumActivityAndNoteContext)contextObj;

				patient = (Patient)this.LoadObject(typeof(Patient));
				if (patient == null)
				{
					this.RaisePageException(new Exception("You must hit this page in the context of a patient"));
					return false;
				}

				// Create NoteTemplate Object
				noteTemplate = new Note(patient, true);

				if ((context & EnumActivityAndNoteContext.fPRRequest)  == EnumActivityAndNoteContext.fPRRequest)
				{
					PRRequest pRRequest = (PRRequest)this.LoadObject(typeof(PRRequest));
					if(pRRequest != null && pRRequest.PRRequestID > 0)
						noteTemplate.PRRequestID = pRRequest.PRRequestID;
				}
				if ((context & EnumActivityAndNoteContext.fPRReview)  == EnumActivityAndNoteContext.fPRReview)
				{
					PRReview pRReview = (PRReview)this.LoadObject(typeof(PRReview));
					if(pRReview != null && pRReview.PRReviewID> 0)
						noteTemplate.PRReviewID = pRReview.PRReviewID;
				}
				if ((context & EnumActivityAndNoteContext.fPRProviderDecision)  == EnumActivityAndNoteContext.fPRProviderDecision)
				{
					PRProviderDecision pRProviderDecision = (PRProviderDecision)this.LoadObject(typeof(PRProviderDecision));
					if(pRProviderDecision != null && pRProviderDecision.PRProviderDecisionID > 0)
						noteTemplate.PRProviderDecisionID = pRProviderDecision.PRProviderDecisionID; 
				}
				if ((context & EnumActivityAndNoteContext.fReferralDetail)  == EnumActivityAndNoteContext.fReferralDetail)
				{
					ReferralDetail referralDetail = (ReferralDetail)this.LoadObject(typeof(ReferralDetail));
					if(referralDetail != null && referralDetail.ReferralDetailID > 0)
						noteTemplate.ReferralId = referralDetail.ReferralDetailID; 
				}
				if ((context & EnumActivityAndNoteContext.fERC)  == EnumActivityAndNoteContext.fERC)
				{
					erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));
					if(erc != null)
					{
						switch (erc.ERCType)
						{
							case EnumERCType.Event:
								noteTemplate.EventID = erc.ID;
								break;
							case EnumERCType.CMS:
								noteTemplate.CMSId = erc.ID;
								break;
							case EnumERCType.Referral:
								noteTemplate.ReferralId = erc.ID;
								break;
							default:
								this.RaisePageException(new Exception("Unknown ERC type"));
								return false;
						} 
					}
				}
				if ((context & EnumActivityAndNoteContext.fProblem)  == EnumActivityAndNoteContext.fProblem)
				{
					problem = (Problem)this.LoadObject(typeof(Problem));
					if (problem != null)
						noteTemplate.ProblemId = problem.ProblemID;
				}

				this.NoteTemplate = noteTemplate;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}

			return result;
		}
		#endregion


		public override void NavigateAway()
		{
			this.CacheObject(typeof(NoteCollection), null);
			base.NavigateAway ();
		}



		#region UI Initialization and Events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			this.RenderClientFunctions(this.pnlSearch.Controls, this.noteSearcher, "DatesValidation");

			this.SetPageTabToolbarItemVisible("PreviewNotes", (this.notes != null && this.notes.RealCount > 0));
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			LoadObjectsFromNoteTemplate();
			pageSummary.RenderObjects(this.patient, this.problem, this.erc);
		}

		private void LoadObjectsFromNoteTemplate()
		{
			patient = (Patient)this.LoadObject(typeof(Patient));
			if(this.noteTemplate.ProblemId > 0)
				problem = (Problem)this.LoadObject(typeof(Problem));
			if(this.noteTemplate.EventID > 0 ||
				this.noteTemplate.CMSId > 0 ||
				this.noteTemplate.ReferralId > 0)
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int id = grid.GetPKIntFromCellEvent(e);
			if (id == 0)
				return;
			switch (e.Cell.Key)
			{
				case "Edit":
				{
					NoteForm.Redirect(id, EnumPageModes.Edit);
					break;
				}
				case "Select":
				{
					// just update panel without caching-changing template object
					Note note = new Note();
					note.Load(id);
					UpdateFromObject(this.pnlDetails.Controls, note);
					break;
				}
			}
		}

		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			grid.AddButtonColumn("Select", "Select", 1);
		}

		private void wbtnSearch_Click(object sender, System.EventArgs e)
		{
			SearchForNotes();
		}

		private void wbtnReset_Click(object sender, System.EventArgs e)
		{
			Note note = new Note(this.noteSearcher.Patient, false);
			this.dateOption.SelectedValue = "1";	//default: Note Creation Time
			note.ActiveWithAll = 1;
			NoteSearcher = note;
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Search":
					toolbar.AddButton(Messages.BaseMessages.MessageIDs.ADDNEWRECORD, "AddNewNote");
					toolbar.AddButton("@PRINT@", "PreviewNotes", false, false).Item.TargetURL = "javascript:PreviewNotes();";
					break; 
			}
		}

		public void OnToolbarButtonClick_AddNewNote(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// redirect
			if(this.noteTemplate != null)
				NoteForm.Redirect(this.noteTemplate, EnumPageModes.Create);
			else
				this.RaisePageException(new ActiveAdviceException("NoteTemplate was not loaded properly.", AAExceptionAction.DisableUI));
		}
		#endregion

	}
}
