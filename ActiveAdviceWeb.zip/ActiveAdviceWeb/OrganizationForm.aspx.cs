using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>

	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ORGANIZATIONS )]
	
	[MainLanguageClass("ActiveAdvice.Messages.OrgMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Organization,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MOrganizations")]
	[SelectedMenuItem("Details")]
	public class OrganizationForm : OrganizationBasePage
	{
		private OrgSynonym orgSynonym;
		private OrganizationFocus focusToTerminate;
		private Organization org;
		private Organization parentOrganization;
		private OrganizationFocus focus;
		private EnrollmentCollection allEnrollments;	// to show linkages in checkboxes
		private MemberLivesResultDateRange dtRange;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel3;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrganizationID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTermDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TermDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTermDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbType;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Type;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRenewalDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRenewalDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMasterOrg;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAddress;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNote;
		protected System.Web.UI.WebControls.Button butClearSharedCache;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridFocus;
		protected NetsoftUSA.InfragisticsWeb.WebValidator OBValidator1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator OBValidator2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOrgFocusCodeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo OrgFocusCodeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrgFocusCodeID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEditFocus;
		protected System.Web.UI.WebControls.Button butNewFocus;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFocuses;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridAvailFocusCodes;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.WebForms.OBButton butAddFocus;
		protected NetsoftUSA.WebForms.OBButton butOKFocus;
		protected NetsoftUSA.WebForms.OBButton butCancelFocus;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlTerminateFocus;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel5;
		protected NetsoftUSA.WebForms.OBButton butCancelFocusTerminate;
		protected NetsoftUSA.WebForms.OBButton butTerminateFocus;
		protected NetsoftUSA.WebForms.OBButton butTerminate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit RenewalDate;
		protected System.Web.UI.WebControls.Button butSave;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FocusEffDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FocusTermDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TermTermDate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSynonyms;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSynonyms;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOrganizationSynonymID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationSynonymID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrganizationSynonymID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEditSynonym;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSynonymName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit SynonymName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSynonymName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSynonymEffDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit SynonymEffDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSynonymTermDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit SynonymTermDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSynonymTermDate;
		protected NetsoftUSA.WebForms.OBButton butCancelSynonym;
		protected NetsoftUSA.WebForms.OBButton butSaveSynonym;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrimarySynonymID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PrimarySynonymID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimarySynonymID;
		protected System.Web.UI.HtmlControls.HtmlTable tblPrimarySynonym;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContractEffDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ContractEffDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContractEffDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected AddressControl AddressControl;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridEnrollments;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEnrollments;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridAllEnrollments;
		protected NetsoftUSA.WebForms.OBLabel lbEnrollments;
		protected NetsoftUSA.WebForms.OBLabel lbAllEnrollments;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridMemberLives;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMemberLives;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Members;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Ratio;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Insureds;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
		protected NetsoftUSA.WebForms.OBLabel OBLabel11;
		protected System.Web.UI.HtmlControls.HtmlTable tblMemLivesCalcResult;
		protected NetsoftUSA.WebForms.OBButton butCalculateMemLives;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDtStart;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DtStart;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDtStart;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDtEnd;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DtEnd;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDtEnd;
		protected System.Web.UI.HtmlControls.HtmlTable tblMemberLivesDateRange;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldModifiedBy;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ModifiedBy;
		protected NetsoftUSA.WebForms.OBFieldLabel lbModifiedBy;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOrganizationTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo OrganizationTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrganizationTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldICMID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ICMID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbICMID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator4;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator5;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel6;
		protected UserDefined UserDefined1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		
			if (!this.IsPostBack)
				this.LoadData();			// Load data is the actual data loading method
			else
			{
				org = (Organization)this.LoadObject(typeof(Organization));	// This would reload from cache
				if(org != null)
				{
					if(org.IsSubOrganization)
						UserDefined1.ReloadContext("SubOrganization",org,true);
					else if(org.IsMasterOrganization)
						UserDefined1.ReloadContext("MasterOrganization",org,true);
					else
						UserDefined1.ReloadContext("Organization",org,true);
					if(!UserDefined1.HasFields())
						this.PageTab.GetTab("UserDefined").Visible = false;		
				}
				parentOrganization = org.ParentOrganization;
				allEnrollments = (EnrollmentCollection)this.LoadObject(typeof(EnrollmentCollection));
				focus = (OrganizationFocus)this.LoadObject(typeof(OrganizationFocus));	// This would reload from cache
				focusToTerminate = (OrganizationFocus)this.LoadObject("FocusToTerminate");	// This would reload from cache
				orgSynonym = (OrgSynonym)this.LoadObject(typeof(OrgSynonym));  // load object from cache

				if (org != null)
					this.AddressControl.Address = org.Address;
			}
		
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject(typeof(EnrollmentCollection), null);
			this.CacheObject(typeof(OrganizationFocus), null);
			this.CacheObject("FocusToTerminate", null);
			this.CacheObject(typeof(OrgSynonym), null);
			base.NavigateAway (targetURL);
		}



		/// <summary>
		/// edit the given organization
		/// </summary>
		/// <param name="organization"></param>
		/// <param name="parent"></param>
		public static void Redirect(Organization organization)
		{
			BasePage.PushParam("Organization", organization);
			BasePage.Redirect("OrganizationForm.aspx");
		}

		/// <summary>
		/// Make a new organization under the given.
		/// </summary>
		/// <param name="parentOrganization"></param>
		public static void RedirectNew(Organization parentOrganization)
		{
			BasePage.PushParam("ParentOrganization", parentOrganization);
			BasePage.Redirect("OrganizationForm.aspx");
		}

		/// <summary>
		/// Load the given organization by id and open the page.
		/// </summary>
		/// <param name="organizationID"></param>
		public static void Redirect(int organizationID)
		{
			Organization org = new Organization();
			if (!org.Load(organizationID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@ORGANIZATION@");
			Redirect(org);
		}

		/// <summary>
		/// Make a new Organization under the currently selected parent.
		/// The parent was either passed directly using RedirectNew,
		/// or was retrieved from the specified organization.
		/// </summary>
		public bool NewOrganization()
		{
			bool result = true;
			Organization org = new Organization(parentOrganization ); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				//planNote.New(/* parameters */);
				if(org.IsMasterOrganization)
					UserDefined1.ReloadContext("MasterOrganization",org,true);
				else if(org.IsSubOrganization)
					UserDefined1.ReloadContext("SubOrganization",org,true);
				else
					UserDefined1.ReloadContext("Organization",org,true);

				if(!UserDefined1.HasFields())
					this.PageTab.GetTab("UserDefined").Visible = false;		
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Organization = org;
			return result;
		}

		private bool CreateChildOrg(Organization parentOrganization, bool copyFromParent)
		{
			bool result = true;
			Organization org = null;
			
			try
			{	
				if (copyFromParent)
					org = parentOrganization.CopyAsChild();
				else
					org = parentOrganization.CreateChild();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			//this.Organization = org;
			OrganizationForm.Redirect(org);	// hit to this page
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			Organization org = null;
			try
			{	// use any load method here

				allEnrollments = (EnrollmentCollection)EnrollmentCollection.AllEnrollmentsByValidDateRange.Clone(false, false);
				this.CacheObject(typeof(EnrollmentCollection), allEnrollments);

				Organization parentOrganization = null;
				if (HasParam("ParentOrganization"))
				{
					parentOrganization = GetParam("ParentOrganization") as Organization;
					// a parent organization was specified, it is to be edited
					this.parentOrganization = parentOrganization;
					return NewOrganization();
					
				}
				else
				{
					// try getting Organization to be edited
					
					string organizationID = this.Request.QueryString["OrganizationID"];
					if (organizationID != null)
					{
						org = new Organization();
						if (!org.Load(int.Parse(organizationID)))
							throw new ActiveAdviceException("@CANTFINDRECORD@", "@ORGANIZATION@");
					}

					if (org == null)
						org = GetParamOrGetFromCache("Organization", typeof(Organization) ) as Organization;
					if (org == null)
					{
						

						RaisePageException(new Exception("A new organization can be created under a given parent"));
						return false;
					}
					else
					{
						this.parentOrganization = org.ParentOrganization;
						if(org.IsMasterOrganization)
							UserDefined1.ReloadContext("MasterOrganization",org,true);
						else if(org.IsSubOrganization)
							UserDefined1.ReloadContext("SubOrganization",org,true);
						else
							UserDefined1.ReloadContext("Organization",org,true);
						if(!UserDefined1.HasFields())
							this.PageTab.GetTab("UserDefined").Visible = false;
					}
				}
				//result = org.Load(4);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//org.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Organization = org;		// When you set the object to the property, controls are automatically populated
			return result;
		}

		public void UpdatePKs()
		{
			gridSynonyms.UpdatePKsFromCollection(this.org.OrgSynonyms);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				org.Save(); // update or insert to db.  Also saves the synonyms internally
				org.SaveOrganizationFocuses();
				allEnrollments.SynchronizeLinkedEnrollments(org);
				org.SaveOrganizationEnrollments();

				UpdatePKs();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Organization Organization
		{
			get { return org; }
			set
			{
				org = value;
				try
				{
					if (org != null)
						this.AddressControl.Address = org.Address;

					// add all object-to-control population code here
					this.UpdateFromObject(pnlMasterOrg.Controls, org);  // update controls for the given control/collection
					this.UpdateFromObject(pnlNote.Controls, org);  // update controls for the given control/collection
					this.UpdateFromObject(pnlAddress.Controls, org.Address);  // update controls for the given control/collection
					if (org != null && org.IsSubOrganization)
						this.UpdateFromObject(tblPrimarySynonym.Controls, org);  // update controls for the given control/collection

					allEnrollments.MarkLinkedEnrollments(org);
					gridEnrollments.UpdateFromCollection(org.OrganizationEnrollments);
					gridAllEnrollments.UpdateFromCollection(allEnrollments);

					// child tables

					//pnlSynonyms.Visible = org.IsSubOrganization;
					if (true)//org.IsSubOrganization)
					{
						// organization synonyms is a child table
						if (org.IsSubOrganization)
						{
							org.LoadOrgSynonyms(false);
							gridSynonyms.UpdateFromCollection(org.OrgSynonyms);
						}
						this.OrgSynonym = null;	// end editing of synonym
						// organization focuses is a child table
						org.LoadOrganizationFocuses(false);
						gridFocus.UpdateFromCollection(org.OrganizationFocuses);
						// available focus codes (not a child table)
						gridAvailFocusCodes.KeepCollectionIndices = false;
						gridAvailFocusCodes.UpdateFromCollection(OrgFocusCodeCollection.ActiveOrgFocusCodes);
						this.Focus = null;	// end editing of focus
						if(org.IsMasterOrganization)
							UserDefined1.ReloadContext("MasterOrganization",org,false);
						else if(org.IsSubOrganization)
							UserDefined1.ReloadContext("SubOrganization",org,false);
						else
							UserDefined1.ReloadContext("Organization",org,false);
					
					}

					this.DateRange = new MemberLivesResultDateRange();
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
					this.CacheObject(typeof(Organization), org);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	// add all control-to-object population code here
				this.UpdateToObject(pnlMasterOrg.Controls, org);  // controls-to-object
				this.UpdateToObject(pnlNote.Controls, org);  // update controls for the given control/collection
				this.UpdateToObject(pnlAddress.Controls, org.Address);  // controls-to-object
				if (org != null && org.IsSubOrganization)
					this.UpdateToObject(tblPrimarySynonym.Controls, org);  // update controls for the given control/collection

				gridAllEnrollments.UpdateToCollection(allEnrollments);

				UserDefined1.UserDefinedValue = org.UserDefined;
				UserDefined1.ReadControls();
				
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MemberLivesResultDateRange DateRange
		{
			get { return dtRange; }
			set
			{
				dtRange = value;
				try
				{
					// add all object-to-control population code here
					this.UpdateFromObject(tblMemberLivesDateRange.Controls, dtRange);  // update controls for the given control/collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlForDateRange()
		{
			try
			{	// add all control-to-object population code here
				dtRange = new MemberLivesResultDateRange();
				this.UpdateToObject(tblMemberLivesDateRange.Controls, dtRange);  // controls-to-object
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			this.gridSynonyms.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridSynonyms_DblClick);
			this.gridSynonyms.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridSynonyms_ColumnsBoundToDataClass);
			this.gridSynonyms.ClickCellButton +=new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(gridSynonyms_ClickCellButton);

			this.butAddFocus.Click += new System.EventHandler(this.butAddFocus_Click);
			this.butTerminate.Click += new System.EventHandler(this.butTerminate_Click);
			this.butOKFocus.Click += new System.EventHandler(this.butOKFocus_Click);
			this.butCancelFocus.Click += new System.EventHandler(this.butCancelFocus_Click);
			this.butTerminateFocus.Click += new System.EventHandler(this.butTerminateFocus_Click);
			this.butCancelFocusTerminate.Click += new System.EventHandler(this.butCancelFocusTerminate_Click);
			this.butSaveSynonym.Click += new System.EventHandler(this.butSaveSynonym_Click);
			this.butCancelSynonym.Click += new System.EventHandler(this.butCancelSynonym_Click);
			this.butCalculateMemLives.Click +=new EventHandler(butCalculateMemLives_Click);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.PageTab.TabClick += new Infragistics.WebUI.UltraWebTab.TabClickEventHandler(this.PageTab_TabClick);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void butClearSharedCache_Click(object sender, System.EventArgs e)
		{
			NSGlobal.ClearCache();
		}

		private void butOKFocus_Click(object sender, System.EventArgs e)
		{
			this.org.LoadOrganizationFocuses(false);
			this.UpdateToObject(pnlEditFocus.Controls, focus);
			if (focus.IsNew)
			{
				this.org.OrganizationFocuses.Add(focus);
				this.Focus = null;
				gridFocus.UpdateFromCollection(this.org.OrganizationFocuses);
			}
		}

		private void butCancelFocus_Click(object sender, System.EventArgs e)
		{
			this.Focus = null;
		}

		public OrganizationFocus Focus
		{
			get
			{
				return this.focus;
			}
			set
			{
				this.focus = value;
				try
				{
					this.pnlEditFocus.Visible = this.focus != null;
					 
					this.UpdateFromObject(this.pnlEditFocus.Controls, focus);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(OrganizationFocus), focus);
				//this.gridFocus.UpdateFromCollection(org.OrganizationFocuses);
			}
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			if (!this.IsPopup)
				toolbar.AddButton("@SAVERECORD@", "Save");

			TBarButton tbbCancel = toolbar.AddButton("@CANCEL@", "Cancel", false, true).Item;
			if (this.IsPopup)
			{
				tbbCancel.Text = this.BaseMessages.CLOSE;
				tbbCancel.TargetURL = "javascript:window.close()";
			}
		}


		public override void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick (toolbar, button);

			//button.Key == "Save"
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, this.org.OrganizationLevelDescription);
				this.Organization = this.Organization;	// just update the ui
			}
		}

		public new void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			OrganizationSearch.Redirect(this.parentOrganization);		// continue editing parent
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			if (this.IsPopup)
				return;

			if (this.org == null)
				return;

			string createChildOrgText = ((BasePage)Page).Language.Translate("@CREATECHILDORG@", this.org.OrganizationSubLevelCode);
			string searchChildOrgText = ((BasePage)Page).Language.Translate("@SEARCHCHILDORG@", this.org.OrganizationSubLevelCodePlural);
			string copyAsChildOrgText = ((BasePage)Page).Language.Translate("@COPYCHILDORG@", this.org.OrganizationSubLevelCode);

			switch (tab.Key)
			{
				case "Details":
					toolbar.AddButton("@CONTACTS@", "Contacts");
					toolbar.AddButton("@ADDNEWRECORD@", "AddNew");
					if (!org.IsSubOrganization)
					{
						toolbar.AddButton(createChildOrgText, "CreateChildOrg");
						toolbar.AddButton(copyAsChildOrgText, "CopyAsChildOrg");
						toolbar.AddButton(searchChildOrgText, "SearchChildOrgs");
					}
					if (org.IsSubOrganization)
						toolbar.AddButton("@LINKEDPLANS@", "LinkedPlans");
					break;
				case "Notes":
					break;
				case "Focus":
					toolbar.AddButton("@ADDNEWRECORD@", "AddNewFocus", false, false);
					break;
				case "Synonyms":
					if (org.IsSubOrganization)
						toolbar.AddButton("@ADDNEWRECORD@", "AddNewSynonym", false, false);
					break;
				case "MemberLives":
					toolbar.AddButton("@LISTMEMBERLIVES@", "ListMemberLives", false, false);
					break;
			}
		}

		public void OnToolbarButtonClick_ListMemberLives(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			MemberLivesResultCollection mlResult = this.org.GetMemberLivesByYearMonth();
			this.gridMemberLives.UpdateFromCollection(mlResult);
		}

		public void OnToolbarButtonClick_Contacts(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.CacheObject(typeof(Contact), null); // Clear Contact object (Issue 886)
			ContactSearch.Redirect(this.org);
		}

		public void OnToolbarButtonClick_AddNewFocus(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			OrganizationFocus focus = new OrganizationFocus(0);
			this.Focus = focus;
		}

		public void OnToolbarButtonClick_AddNewSynonym(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewOrgSynonym();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewOrganization();
		}

		public void OnToolbarButtonClick_CreateChildOrg(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.org.IsSubOrganization)
				RaisePageException(new Exception("Sub-organization can't have child organizations"));
			else
				CreateChildOrg(this.org, false);		// Create a child of the current organization
		}
		
		public void OnToolbarButtonClick_CopyAsChildOrg(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.org.IsSubOrganization)
				RaisePageException(new Exception("Sub-organization can't have child organizations"));
			else
				CreateChildOrg(this.org, true);		// Create a child of the current organization
		}

		public void OnToolbarButtonClick_SearchChildOrgs(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.org.IsSubOrganization)
				RaisePageException(new Exception("Sub-organization can't have child organizations"));
			else
				OrganizationSearch.Redirect(this.org);
		}

		public void OnToolbarButtonClick_LinkedPlans(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (!this.org.IsSubOrganization)
				RaisePageException(new Exception("Only sub-organization can have linked plans"));
			OrganizationLinkedPlans.Redirect(this.org);
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			//listbar.AddItem("Detail", "MorgDetail");
			//listbar.AddItem("Summary", "MorgSummary");

		}

		public void OnSubNavigationItemClick_MorgSearch(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("MORGSearch.aspx");
		}

		private void butAddFocus_Click(object sender, System.EventArgs e)
		{
			if (gridAvailFocusCodes.SelectedRowIndex >= 0)
			{
				int focusCodeID = (int)gridAvailFocusCodes.GetPKFromRowIndex(gridAvailFocusCodes.SelectedRowIndex)[0];
				OrganizationFocus focus = new OrganizationFocus(focusCodeID);
				this.Focus = focus;
			}
			else
			{
				this.SetPageMessage("First select a focus code", EnumPageMessageType.Warning);
			}
		}

		private void gridAvailFocusCodes_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			object[] pk = gridAvailFocusCodes.GetPKFromClickEvent(e);
			if (pk == null)
				return;
			OrganizationFocus focus = new OrganizationFocus((int)pk[0]);
			this.Focus = focus;
		}

		private void butTerminate_Click(object sender, System.EventArgs e)
		{
			if (gridFocus.SelectedRowIndex >= 0)
			{
				int index = (int)gridFocus.GetColIndexFromRowIndex( gridFocus.SelectedRowIndex );
				OrganizationFocus focus = org.OrganizationFocuses[index];
				this.FocusToTerminate = focus;
			}
			else
			{
				this.SetPageMessage("First select a focus from the focus history", EnumPageMessageType.Warning);
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public OrganizationFocus FocusToTerminate
		{
			get { return focusToTerminate; }
			set
			{
				focusToTerminate = value;
				try
				{
					this.pnlTerminateFocus.Visible = this.focusToTerminate != null;
					this.UpdateFromObject(this.pnlTerminateFocus.Controls, focusToTerminate);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("FocusToTerminate", focusToTerminate);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForFocusToTerminate()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlTerminateFocus.Controls, focusToTerminate);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private void butTerminateFocus_Click(object sender, System.EventArgs e)
		{
			this.org.LoadOrganizationFocuses(false);
			this.UpdateToObject(pnlTerminateFocus.Controls, focusToTerminate);
			if (focusToTerminate.TerminationDate == DateTime.MinValue)
			{
				this.SetPageMessage("@INVALIDTERMDATE@", EnumPageMessageType.Error);
				return;
			}
			else
				this.SetPageMessage("The focus termination date has been set.  It will be saved to DB when you click save button.", EnumPageMessageType.Info);
			gridFocus.UpdateFromCollection(this.org.OrganizationFocuses);
			this.FocusToTerminate = null;
		}

		private void butCancelFocusTerminate_Click(object sender, System.EventArgs e)
		{
			this.FocusToTerminate = null;
		}

		private void gridFocus_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			int index = gridFocus.GetColIndexFromClickEvent(e);
			if (index < 0)
				return;
			OrganizationFocus focus = org.OrganizationFocuses[index];
			this.FocusToTerminate = focus;
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.org);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			if (org != null)
			{
				this.RenderClientFunctions(pnlMasterOrg.Controls, org, "OnCalculateMasterOrg");
				this.SetPageTabItemVisible("Synonyms", org.IsSubOrganization);
				bool childOpsAvail = !org.IsNew;
				this.SetPageTabToolbarItemEnabled("Contacts", childOpsAvail);
				this.SetPageTabToolbarItemEnabled("CreateChildOrg", childOpsAvail);
				this.SetPageTabToolbarItemEnabled("CopyAsChildOrg", childOpsAvail);
				this.SetPageTabToolbarItemEnabled("SearchChildOrgs", childOpsAvail);
				this.SetPageTabToolbarItemEnabled("LinkedPlans", childOpsAvail);
			}
		}

		private void gridSynonyms_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			int index = gridSynonyms.GetColIndexFromClickEvent(e);
			if (index < 0)
				return;
			OrgSynonym synonym = org.OrgSynonyms[index];
			this.OrgSynonym = synonym;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public OrgSynonym OrgSynonym
		{
			get { return orgSynonym; }
			set
			{
				orgSynonym = value;
				try
				{
					pnlSynonyms.Visible = orgSynonym == null && this.org.IsSubOrganization;
					pnlEditSynonym.Visible = orgSynonym != null && this.org.IsSubOrganization;

					this.UpdateFromObject(pnlEditSynonym.Controls, orgSynonym);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(OrgSynonym), orgSynonym);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForOrgSynonym()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlEditSynonym.Controls, orgSynonym);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewOrgSynonym()
		{
			bool result = true;
			OrgSynonym orgSynonym = new OrgSynonym(this.org.OrganizationID); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.OrgSynonym = orgSynonym;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForOrgSynonym()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForOrgSynonym())
					return false;
				if (this.orgSynonym.ParentOrgSynonymCollection == null)
					this.org.OrgSynonyms.Add(this.orgSynonym);
				gridSynonyms.UpdateFromCollection(org.OrgSynonyms);
				this.OrgSynonym = null;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void butSaveSynonym_Click(object sender, System.EventArgs e)
		{
			SaveDataForOrgSynonym();
		}

		private void butCancelSynonym_Click(object sender, System.EventArgs e)
		{
			this.OrgSynonym = null;
		}

		private void gridSynonyms_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			switch (e.Cell.Key)
			{
				case "Edit":
				{
					int index = gridSynonyms.GetColIndexFromCellEvent(e);
					if (index < 0)
						return;
					OrgSynonym synonym = org.OrgSynonyms[index];
					this.OrgSynonym = synonym;
					break;
				}
			}
		}

		private void gridSynonyms_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			//this.gridSynonyms.AddButtonColumn("SetAsPrimary", "@SETASPRIMARY@", 0);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();

			this.CheckForDirty(this.org, this.org.Address, this.org.UserDefined, this.org.OrgSynonyms, this.org.OrganizationFocuses, this.org.OrganizationEnrollments );
		}

		private void butCalculateMemLives_Click(object sender, EventArgs e)
		{
			if (ReadControlForDateRange())
			{
				MemberLivesResult mlResult = this.org.CalculateMemberLivesBetweenDates(dtRange.DtStart, dtRange.DtEnd);
				this.UpdateFromObject(tblMemLivesCalcResult.Controls, mlResult);
				this.SetPageMessage("@MEMBERLIVESCALCULATED@", EnumPageMessageType.AddInfo);
			}
		}

		private void PageTab_TabClick(object sender, Infragistics.WebUI.UltraWebTab.WebTabEvent e)
		{
		
		}
	}
}
