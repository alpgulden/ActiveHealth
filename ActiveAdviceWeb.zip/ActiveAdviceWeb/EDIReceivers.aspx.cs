using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.BaseClassesInterfaces;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.IMPORT_EXPORT_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("EDIReceiver")]
	public class EDIReceiverForm : ImportExportBasePage
	{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEDIControl;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUmoName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit UmoName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldUmoName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ContactName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContactName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUMOIdentificationQualifierID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo UMOIdentificationQualifierID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldUMOIdentificationQualifierID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUMOIdentification;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit UMOIdentification;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldUMOIdentification;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactphone1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Contactphone1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContactphone1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUmoCode;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit UmoCode;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldUmoCode;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactphone2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Contactphone2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContactphone2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLogPath;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LogPath;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLogPath;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactphone3;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Contactphone3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContactphone3;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUMOContactNumberQualifier1ID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo UMOContactNumberQualifier1ID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldUMOContactNumberQualifier1ID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUMOContactNumberQualifier2ID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo UMOContactNumberQualifier2ID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldUMOContactNumberQualifier2ID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUMOContactNumberQualifier3ID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo UMOContactNumberQualifier3ID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldUMOContactNumberQualifier3ID;
		protected NetsoftUSA.WebForms.OBLabel OblblEDIReciever;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridEDIControls;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEDIControls;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				LoadData();
			}
		}

		protected void LoadData()
		{
			UpdateFromObject(this.pnlEDIControl.Controls, this.EDIControl);
			UpdateFromObject(this.pnlEDIControls.Controls, this.EDIControls);
			this.pnlEDIControl.Visible	= false;
			this.pnlEDIControls.Visible	= true;
			this.gridEDIControls.UpdateFromCollection(this.EDIControls);
		}

		protected void SaveData()
		{
			UpdateToObject(this.pnlEDIControl.Controls, this.EDIControl);
			UpdateToObject(this.pnlEDIControls.Controls, this.EDIControls);
			this.gridEDIControls.UpdateToCollection(this.EDIControls);
			if (pnlEDIControl.Visible == true) // we are editing a single item
			{
				// We need to validate our arguments
				EDIControl.Save();
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@EDIRECEIVER@");
				SetPageTabToolbarItemVisible("AddItem", false); // don't display
			}
		}

		EDIControlCollection edicontrols = null;
		protected EDIControlCollection EDIControls
		{
			get
			{
				if (null == edicontrols)
				{
					edicontrols = new EDIControlCollection();
					edicontrols.SelectAllEDIControlByActive(-1, true);
				}
				return edicontrols;
			}
		}
		EDIControl edicontrol = null;
		protected EDIControl EDIControl
		{
			get
			{
				if (null == edicontrol)
				{
					edicontrol = (EDIControl)LoadObject(typeof(EDIControl), false);
					if (null == edicontrol)
					{
						edicontrol = new EDIControl();
						edicontrol.Active = true;
						CacheObject(typeof(EDIControl), edicontrol);
					}
				}
				return edicontrol;
			}
			set
			{
				edicontrol = value;
				CacheObject(typeof(EDIControl), edicontrol);
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("EDIReceiverForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.gridEDIControls.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridEDIControls_DblClick);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("@Add Item@", "AddItem");
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@SAVE@",   "Save");
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SaveData();
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick_Cancel(toolbar, button);
			if (this.pnlEDIControl.Visible == true)
			{
				this.pnlEDIControls.Visible = true;
				this.pnlEDIControl.Visible	= false;
				SetPageTabToolbarItemVisible("AddItem",true);
				CacheObject(typeof(EDIControl), null); // clear out the cache

				// Refresh the grid
				this.EDIControls.SelectAllEDIControlByActive(-1, true);
				this.gridEDIControls.UpdateFromCollection(EDIControls);
			}
		}

		public void OnToolbarButtonClick_AddItem(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.pnlEDIControl.Visible	= true;
			this.pnlEDIControls.Visible	= false;
			this.EDIControl.IsNew		= true;
			SetPageTabToolbarItemVisible("AddItem", false);
		}

		// User wants to edit a specific grid item...
		private void gridEDIControls_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = this.gridEDIControls.GetPKFromClickEvent(e);
				if (pk != null)
				{
					EDIControl ec = EDIControls.FindBy(Convert.ToInt32(pk[0]));
					this.EDIControl = ec;
					UpdateFromObject(this.pnlEDIControl.Controls, this.EDIControl);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}

			this.pnlEDIControl.Visible	= true;
			this.pnlEDIControls.Visible	= false;
			SetPageTabToolbarItemVisible("AddItem", false); // we are editing an item, don't display "AddItem" button
		}

	}
}
