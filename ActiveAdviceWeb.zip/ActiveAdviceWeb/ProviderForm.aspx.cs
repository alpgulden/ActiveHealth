using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;
using Infragistics.WebUI.UltraWebToolbar;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.PROVIDER)]
	
	[MainLanguageClass("ActiveAdvice.Messages.ProviderMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Provider,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MProviderFacility")]
	[SelectedMenuItem("Providers")]
	[PageTitle("@PROVIDERFORMTITLE@")]
	public class ProviderForm : ProviderBasePage
	{
		private GroupPracticeProviderLinkCollection groupPracticeProviderLinks;
		private GroupPracticeProviderLink selectedGroupPracticeProvider;
		private ProviderSpecialty selectedProviderSpecialty;
		private ProviderFocus selectedProviderFocus;
		private Provider provider;
		private GroupPracticeLocationCollection resultGroupPracticeLocations;
		private Address selectedProviderAddress;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlBasicInfo;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusChangedByID;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DateActive;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateActive;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBCheckBox AddedOnTheFly;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAddedOnTheFly;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Gender;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGender;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Email;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEmail;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit Beeper;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBeeper;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFederalTaxID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSuffixId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PrefixId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrefixId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ProviderID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProviderID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLanguages;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.InfragisticsWeb.WebGrid lstLanguages;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddLanguage;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveLanguage;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviderLanguages;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviderFocuses;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveFocus;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddFocus;
		protected NetsoftUSA.InfragisticsWeb.WebGrid lstFocuses;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderFocuses;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderNote;
		protected NetsoftUSA.WebForms.OBLabel OBLabel11;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderSpecialties;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveSpecialty;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddSpecialty;
		protected System.Web.UI.WebControls.ListBox lstProviderSpecialties;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSpecialtySetPrimary;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSpecialtyChangeStatus;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviderSpecialties;
		private   int selectedFocusIndex		= -1;
		private   int selectedSpecialtyIndex	= -1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGroupPractices;
		protected NetsoftUSA.WebForms.OBLabel OBLabel12;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviderGroupPractices;
		protected System.Web.UI.HtmlControls.HtmlTable tblProviderInfo1;
		protected System.Web.UI.HtmlControls.HtmlTable tblProviderInfo2;
		private   int selectedLanguageIndex		= -1;
		private   int selectedGPIndex			= -1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Suffix;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DeliveryMethodStr;
		protected NetsoftUSA.InfragisticsWeb.WebGrid lstSpecialties;
		private   int selectedGPLocIndex		= -1;
		private   int selectedLangTypeIndex		= -1;
		private   int selectedFocusTypeIndex	= -1;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnClose;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnProceed;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFocusDate;
		protected System.Web.UI.HtmlControls.HtmlTable tblMain;
		protected System.Web.UI.HtmlControls.HtmlTable tblEffectiveDate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGPDates;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit AsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelGPDates;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProviderFocusTypeID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel16;
		protected NetsoftUSA.InfragisticsWeb.WebCombo BoardStatus;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBoardStatus;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSpecialtyStatus;
		protected System.Web.UI.HtmlControls.HtmlTable Table9;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelSpecialtyStatus;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnOKSpecialtyStatus;
		protected NetsoftUSA.WebForms.OBLabel OBLabel17;
		protected NetsoftUSA.WebForms.OBLabel lblGPEffDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton WebButton1;
		protected NetsoftUSA.InfragisticsWeb.WebButton WebButton2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGroupPracticeDate;
		protected System.Web.UI.HtmlControls.HtmlTable Table11;
		protected NetsoftUSA.WebForms.OBLabel OBLabel13;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit GroupPracticeID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel14;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit GroupPracticeName;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForSORG;
		protected NetsoftUSA.WebForms.OBLabel OBLabel18;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit GroupPracticeLocationID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeLocationID;
		protected System.Web.UI.HtmlControls.HtmlTable tblProviderGP;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPEffectiveDates;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGroupPracticeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGroupPracticeLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProviderFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldBeeper;
		//protected NetsoftUSA.InfragisticsWeb.WebValidator vldEmail;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit BeeperExtension;
		protected NetsoftUSA.WebForms.OBCheckBox PhysicianReview;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhysicianReview;
		protected System.Web.UI.HtmlControls.HtmlTable tblSpecialtyInfo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGender;
		protected System.Web.UI.HtmlControls.HtmlTable tblProviderAddress;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFax;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fax;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFax;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFaxNumber;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit FaxNumber;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFaxNumber;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		private   int selectWidth				= 65;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGrpLocations;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviderGPLocations;
		protected NetsoftUSA.WebForms.OBLabel lblGPLocs;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPLocations;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGrpDates;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected System.Web.UI.HtmlControls.HtmlTable Table2;
		protected System.Web.UI.HtmlControls.HtmlTable Table10;
		protected UserDefined UserDefined1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEmail;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WEBTEXTEDIT4;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFIELDLABEL6;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFIELDLABEL7;
		protected NetsoftUSA.InfragisticsWeb.WebCombo StateOfLicensure;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeliveryMethodStr;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeliveryMethod;
		protected GroupPracticeProviderHistory newHistory;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			

			this.UserDefined1.ReloadContext("Provider",provider,true);
			if(!UserDefined1.HasFields())
				this.PageTab.GetTab("UserDefined").Visible = false;
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				provider = (Provider)this.LoadObject("providerObj");
				selectedLanguageIndex = (int)this.LoadObject("providerLanguageIndex");
				selectedFocusIndex	  = (int)this.LoadObject("providerFocusIndex");
				selectedSpecialtyIndex = (int)this.LoadObject("providerSpecialtyIndex");
				resultGroupPracticeLocations = (GroupPracticeLocationCollection)this.LoadObject("objResultGPLocations");  // load object from cache
				selectedGPIndex			= (int)this.LoadObject("providerGPIndex");
				selectedGPLocIndex		= (int)this.LoadObject("providerGPLocIndex");
				selectedLangTypeIndex   = (int)this.LoadObject("selectedLangTypeIndex");
				selectedFocusTypeIndex  = (int)this.LoadObject("selectedFocusTypeIndex");
				selectedProviderFocus = (ProviderFocus)this.LoadObject("selectedFocus");  // load object from cache
				selectedProviderSpecialty = (ProviderSpecialty)this.LoadObject("selectedProviderSpecialty");  // load object from cach
				selectedGroupPracticeProvider = (GroupPracticeProviderLink)this.LoadObject("selectedGPProviderLink");  // load object from cache
				groupPracticeProviderLinks = (GroupPracticeProviderLinkCollection)this.LoadObject(typeof(GroupPracticeProviderLinkCollection));  // load object from cache
			}		

		}

		
		public int SelectedFocusTypeIndex
		{
			get { return this.selectedFocusTypeIndex; }
			set 
			{
				this.selectedFocusTypeIndex = value;
				this.CacheObject("selectedFocusTypeIndex", this.selectedFocusTypeIndex);
			}
		}
		public int SelectedLangTypeIndex
		{
			get { return this.selectedLangTypeIndex; }
			set 
			{
				this.selectedLangTypeIndex = value;
				this.CacheObject("selectedLangTypeIndex", this.selectedLangTypeIndex);
			}
		}

		private bool AddGroupPracticeLink()
		{
		
			bool resume = false;
			if (this.SelectedGroupPracticeProvider!= null)
			{
				if (this.SelectedGroupPracticeProvider.EffDate != DateTime.MinValue) // add 
				{
					resume = true;
					SelectedGroupPracticeProvider.CreatedBy  = 1; // Context.UserID
					SelectedGroupPracticeProvider.CreateTime = DateTime.Now;
					SelectedGroupPracticeProvider.ProviderID = this.Provider.ProviderID;
					
					// check if ID already exists if it does then show a message to the user
					for (int i=0; i < Provider.GroupPracticeLinks.Count; i++)
					{
						if (SelectedGroupPracticeProvider.GroupPracticeLocationID == Provider.GroupPracticeLinks[i].GroupPracticeLocationID)
						{
							resume = false;
							break;
						}
					}
					if (resume)
					{
						this.Provider.GroupPracticeLinks.Add(SelectedGroupPracticeProvider);
						this.Provider.GroupPracticeLinks.Save();
						
						this.selectedGroupPracticeProvider.LoadEffectiveDateHistory(true);
					
						GroupPracticeProviderHistory currentDate = new GroupPracticeProviderHistory();
						currentDate.New();
						currentDate.AsOfDate					= DateTime.Now;
						currentDate.EffectiveDate				= this.selectedGroupPracticeProvider.EffDate;
						currentDate.TerminationDate				= this.selectedGroupPracticeProvider.TerminationDate;
						currentDate.Active						= this.selectedGroupPracticeProvider.Active ;
						currentDate.GroupPracticeProviderID		= this.selectedGroupPracticeProvider.GroupPracticeProviderID;
					
						this.selectedGroupPracticeProvider.EffectiveDateHistory.InsertRecord(0,currentDate);
						this.selectedGroupPracticeProvider.EffectiveDateHistory.Save();
			
						this.gridGPDates.ClearRows();
						this.gridGPDates.UpdateFromCollection(this.selectedGroupPracticeProvider.EffectiveDateHistory);
						this.gridProviderGPLocations.UpdateFromCollection (this.Provider.GroupPracticeLinks);
//						this.gridProviderGroupPractices.ClearRows();
//						this.gridProviderGPLocations.ClearRows();

						int oldIndex = this.SelectedGPIndex;
						//this.SelectedGPLocIndex = 0;
						//this.Provider = this.provider; // refresh all grids.
						this.SelectedGPIndex = oldIndex;
						
						bool addGp = true;
						for (int i=0; i < Provider.GroupPractices.Count; i++)
						{
							if (SelectedGroupPracticeProvider.GroupPracticeID == Provider.GroupPractices[i].GroupPracticeID)
								addGp = false;
							else
							{
								addGp = true;
								break;
							}
						}

						if (addGp) // add GP to current group practice col, wont be saved into DB
						{
							GroupPractice gpNew = new GroupPractice();
							gpNew.Load(SelectedGroupPracticeProvider.GroupPracticeID);
							Provider.GroupPractices.Add(gpNew);
							this.gridProviderGroupPractices.UpdateFromCollection(Provider.GroupPractices);
						}

						this.CopyGPLinksToDisplayCollection(SelectedGroupPracticeProvider.GroupPracticeID);
						this.SelectedGroupPracticeProvider = null;
						this.gridProviderGPLocations.UpdateFromCollection(this.Provider.GroupPracticeLinks);
						
						
					}
					else
						this.SetPageMessage("@GPEXISTS@", NetsoftUSA.WebForms.EnumPageMessageType.Error);
				}
			}
			return resume;
		}


		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(int providerID)
		{
			Provider provider = new Provider();
			if (providerID != 0)
				provider.Load(providerID);
			else
			{
				provider.New();
				provider.AddedOnTheFly = true;
			}
			BasePage.PushParam("providerObj",provider);
			BasePage.Redirect("ProviderForm.aspx");
		}

		public static void Redirect(Provider provider)
		{
			BasePage.PushParam("providerObj",provider);
			BasePage.Redirect("ProviderForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			this.btnAddFocus.Click += new System.EventHandler(this.btnAddFocus_Click);
			this.btnRemoveFocus.Click += new System.EventHandler(this.btnRemoveFocus_Click);
			this.gridProviderSpecialties.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridProviderSpecialties_ClickCellButton);
			//this.btnSpecialtySetPrimary.Click += new System.EventHandler(this.btnSpecialtySetPrimary_Click);
			//this.btnSpecialtyChangeStatus.Click += new System.EventHandler(this.btnSpecialtyChangeStatus_Click);
			this.gridProviderGroupPractices.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridProviderGroupPractices_DblClick);
			//this.gridProviderGroupPractices.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridProviderGroupPractices_ClickCellButton);
			
			this.gridProviderGPLocations.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridProviderGPLocations_DblClick);
			
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			this.btnCancelSpecialtyStatus.Click += new System.EventHandler(this.btnCancelSpecialtyStatus_Click);
			this.WebButton1.Click += new System.EventHandler(this.WebButton1_Click);

		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnAddLanguage.Click += new System.EventHandler(this.btnAddLanguage_Click);
			this.btnRemoveLanguage.Click += new System.EventHandler(this.btnRemoveLanguage_Click);
			this.btnAddFocus.Click += new System.EventHandler(this.btnAddFocus_Click);
			this.btnRemoveFocus.Click += new System.EventHandler(this.btnRemoveFocus_Click);
			this.btnAddSpecialty.Click += new System.EventHandler(this.btnAddSpecialty_Click);
			this.btnSpecialtySetPrimary.Click += new System.EventHandler(this.btnSpecialtySetPrimary_Click);
			this.btnSpecialtyChangeStatus.Click += new System.EventHandler(this.btnSpecialtyChangeStatus_Click);
			this.btnSaveGPDates.Click += new System.EventHandler(this.btnSaveGPDates_Click);
			this.btnCancelGPDates.Click += new System.EventHandler(this.btnCancelGPDates_Click);
			this.btnAddGPDates.Click += new System.EventHandler(this.btnAddGPDates_Click);
			this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			this.btnOKSpecialtyStatus.Click += new System.EventHandler(this.btnOKSpecialtyStatus_Click);
			this.btnCancelSpecialtyStatus.Click += new System.EventHandler(this.btnCancelSpecialtyStatus_Click);
			this.WebButton2.Click += new System.EventHandler(this.WebButton2_Click);
			this.WebButton1.Click += new System.EventHandler(this.WebButton1_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void LoadData()
		{
			// get the parameter
			Provider currentProvider = null;
			
			SelectedLanguageIndex			= -1;
			SelectedFocusIndex				= -1;
			SelectedGPIndex					= -1;
			SelectedGPLocIndex				= -1;
			SelectedSpecialtyIndex			= -1;
			SelectedLangTypeIndex			= -1;
			SelectedFocusTypeIndex			= -1;
			
			string sProviderID = Request.QueryString["ProviderID"];
			if (sProviderID != null)
			{
				try
				{
					if(sProviderID == "" || sProviderID == "0")
						throw new ActiveAdviceException("@ISNOTSET@","@PROVIDER@");
					currentProvider = new Provider();
					if (!currentProvider.Load(int.Parse(sProviderID)))
						throw new ActiveAdviceException("@CANTFINDRECORD@","@PROVIDER@");
					this.Provider = currentProvider;
					
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			else
			{
				currentProvider = this.GetParamOrGetFromCache("providerObj","providerObj") as Provider;
				if (currentProvider == null)
				{
					Provider prov = new Provider();
					prov.New();
					prov.LoadFocuses(false);
					prov.LoadProviderLanguages(false);		// fixed
					prov.LoadSpecialties(false);
					this.Provider = prov;
				
				}
				else
				{
					currentProvider.Load(currentProvider.ProviderID);
					if (currentProvider.ProviderID == 0)
						currentProvider.New();
					currentProvider.LoadFocuses(false);
					currentProvider.LoadGroupPracticeLinks(false);
					currentProvider.LoadProviderLanguages(false);			// fixed!
					currentProvider.LoadSpecialties(false);
					this.Provider = currentProvider;
				}
			}
			
				
			
		}

		
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			if(this.provider == null)
				return;

			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.provider);
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			if (!this.IsPopup)
				toolbar.AddButton("@SAVE@", "Save",true, false);
			//toolbar.AddButton("@CANCEL@", "Cancel", false, true);
			// If in pop-up mode Cancel button shouldn't check for dirty.
			TBarButton tbbCancel = toolbar.AddButton("@CANCEL@", "Cancel", false, !this.IsPopup).Item;
			if (this.IsPopup)
			{
				tbbCancel.Text = this.BaseMessages.CLOSE;
				tbbCancel.TargetURL = "javascript:window.close()";
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.RenderClientFunctions(pnlGrpDates.Controls, this.newHistory, "vldTerminationDate");
		}

		public override void OnSetDirty()
		{
			if(this.provider == null)
				return;
			CheckForDirty(this.provider, this.provider.Focuses, this.provider.GroupPractices, this.provider.GroupPracticeLinks, this.provider.ProviderLanguages,
				this.provider.Locations, this.provider.Specialties);	
		}


		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			bool wasNew			= Provider.IsNew;
			bool saveDataResult = SaveData();
			
			if (saveDataResult && wasNew)			
				this.SetPageMessage("@PROVIDERSAVEDMSG@", EnumPageMessageType.Info, "@PROVIDERTPE@","@LOCATIONLOWER@");
			else if (saveDataResult)
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@PROVIDERTPE@");
		}

		public int SelectedLanguageIndex
		{
			get { return this.selectedLanguageIndex; }
			set 
			{ 
				this.selectedLanguageIndex = value;
				this.CacheObject("providerLanguageIndex",selectedLanguageIndex);
			}
		}

		public int SelectedSpecialtyIndex
		{
			get { return this.selectedSpecialtyIndex; }
			set 
			{ 
				this.selectedSpecialtyIndex = value;
				this.CacheObject("providerSpecialtyIndex", selectedSpecialtyIndex);
			}
		}

		public int SelectedGPIndex
		{
			get { return this.selectedGPIndex;}
			set 
			{ 
				this.selectedGPIndex = value;
				this.CacheObject("providerGPIndex", selectedGPIndex);
				if (this.Provider != null && this.SelectedGPIndex >= 0)
				{

					// Clone Links From Actual Collection to Display Collection
					CopyGPLinksToDisplayCollection(selectedGPIndex);
					this.GroupPracticeProviderLinks = this.groupPracticeProviderLinks;
					this.gridProviderGPLocations.ClearRows();
					this.gridProviderGPLocations.UpdateFromCollection(GroupPracticeProviderLinks);
				}
			}
		}
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeLocationCollection ResultGroupPracticeLocations
		{
			get { return resultGroupPracticeLocations ; }
			set
			{
				resultGroupPracticeLocations = value;
				try
				{
					this.gridProviderGPLocations.UpdateFromCollection(resultGroupPracticeLocations );  // update given grid from the collection
					this.gridProviderGPLocations.Visible = true;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objResultGPLocations", resultGroupPracticeLocations);  // cache object using the caching method declared on the page
			}
		}

		private void CopyGPLinksToDisplayCollection(int gpID)
		{
			

			if (this.GroupPracticeProviderLinks != null)
				this.GroupPracticeProviderLinks.Clear();
					
			this.GroupPracticeProviderLinks = new GroupPracticeProviderLinkCollection();
			for (int i=0; i < Provider.GroupPracticeLinks.Count; i++)
			{
				if (!Provider.GroupPracticeLinks[i].IsMarkedForDeletion)
				{
					GroupPracticeProviderLinks.Add((GroupPracticeProviderLink)Provider.GroupPracticeLinks[i].Clone());
					GroupPracticeProviderLinks[i].IsNew = Provider.GroupPracticeLinks[i].IsNew;
					GroupPracticeProviderLinks[i].IsDirty = Provider.GroupPracticeLinks[i].IsDirty;
					//GroupPracticeProviderLinks[i].EffectiveDateHistory = Provider.GroupPracticeLinks[i].EffectiveDateHistory.Clone(false, true) ;
				}
			}
					
			for (int i = 0; i < GroupPracticeProviderLinks.Count; i++)
			{
				if (GroupPracticeProviderLinks[i].GroupPracticeID != gpID)
					GroupPracticeProviderLinks.RemoveAt(i);
			}

			
		}


		private void CopyGPLocDateHistory(GroupPracticeProviderLink copyTo, GroupPracticeProviderLink copyFrom)
		{
			copyTo.LoadEffectiveDateHistory(false);
			copyTo.EffectiveDateHistory.Clear();
			for (int i = 0; i < copyFrom.EffectiveDateHistory.Count; i++)
				copyTo.EffectiveDateHistory.Add(copyFrom.EffectiveDateHistory[i]);
		}


		public int SelectedGPLocIndex
		{
			get { return this.selectedGPLocIndex;}
			set 
			{ 
				this.selectedGPLocIndex = value;
				this.CacheObject("providerGPLocIndex", selectedGPLocIndex);

				
				// Load Date History
				if (Provider != null && this.gridProviderGPLocations.SelectedRowIndex >= 0)
				{
					// Find Group Practice ID from GPLocIndex
					int gpID = 0;
					
					if (this.gridProviderGPLocations.SelectedRowIndex >= 0)
					{
						Infragistics.WebUI.UltraWebGrid.UltraGridCell mcell = null;
						for (int m = 0; m < this.gridProviderGPLocations.DisplayLayout.ActiveRow.Cells.Count; m++)
						{
							if (gridProviderGPLocations.DisplayLayout.ActiveRow.Cells[m].Key == "GroupPracticeID")
							{
								mcell = gridProviderGPLocations.DisplayLayout.ActiveRow.Cells[m];
								break;
							}
						}
						gpID = (int)mcell.Value;	
					}
					
					int gpLocID = (int)gridProviderGPLocations.SelectedRowPK[0];
					
					for (int i = 0; i < GroupPracticeProviderLinks.Count; i++)
					{
						if (GroupPracticeProviderLinks[i].GroupPracticeID != gpID)
							GroupPracticeProviderLinks.RemoveAt(i);
					}
				
					GroupPracticeProviderLink gpLink = Provider.GroupPracticeLinks.FindBy(gpLocID);
					GroupPracticeProviderHistoryCollection gppDates = null;
					CopyGPLocDateHistory(gpLink, Provider.GroupPracticeLinks.FindBy((int)gridProviderGPLocations.SelectedRowPK[0]));
					gppDates = gpLink.EffectiveDateHistory;
					for (int k = 0; k < gppDates.Count; k++)
					{
						if (gppDates[k].Active || (gppDates[k].IsDirty && !gppDates[k].Active))
							gppDates.RemoveAt(k);
					}

					

					// Move current dates into history
					GroupPracticeProviderHistory gppLink = new GroupPracticeProviderHistory();
					gppLink.IsDirty				= true;
					gppLink.AsOfDate			= gpLink.AsOfDate;
					gppLink.EffectiveDate		= gpLink.EffDate;
					gppLink.TerminationDate		= gpLink.TerminationDate;
					gppLink.Active				= ((gpLink.TerminationDate <= gppLink.EffectiveDate) ? false : true);
					
					gppDates.Insert(0,gppLink);

					// refresh grid
					if (this.SelectedGPIndex != -1)
						this.SelectedGPIndex = this.selectedGPIndex;
					this.gridGPDates.UpdateFromCollection(gppDates);

				}
			}
		}

		public int SelectedFocusIndex
		{
			get { return this.selectedFocusIndex;}
			set 
			{ 
				this.selectedFocusIndex = value;
				this.CacheObject("providerFocusIndex", selectedFocusIndex);
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Provider Provider
		{
			get { return provider; }
			set
			{
				provider = value;
				try
				{
					this.pnlGroupPracticeDate.Visible = false;
					this.tblGPDates.Visible = false;
					provider.LoadProviderLanguages(false);
					provider.LoadLocations(false);
					provider.LoadGroupPracticeLinks(false);
					provider.LoadSpecialties(true);
					for (int i=0; i < Provider.GroupPracticeLinks.Count; i++)
						Provider.GroupPracticeLinks[i].LoadEffectiveDateHistory(false);
					this.UpdateFromObject(this.tblProviderInfo1.Controls, provider);  // update controls for the given control collection
					this.UpdateFromObject(this.tblProviderInfo2.Controls, provider);  // update controls for the given control collection
					this.UpdateFromObject(pnlLanguages.Controls, provider.ProviderLanguages);
					
					
					
					// Bind Active Provider Languages
					lstLanguages.UpdateFromCollection(LanguageCollection.ActiveLanguages);
					if (lstLanguages.Rows.Count > 0)
						lstLanguages.SelectedRowIndex = 0;
					this.gridProviderLanguages.UpdateFromCollection(Provider.ProviderLanguages);
					if (gridProviderLanguages.Rows.Count > 0)
						gridProviderLanguages.SelectedRowIndex = 0;
					

					// Bind Available Provider Specialties
					this.lstSpecialties.UpdateFromCollection(SpecialtyCollection.ActiveSpecialties);
					if (lstSpecialties.Rows.Count > 0)
					{
						btnAddSpecialty.Enabled = true;
						lstSpecialties.SelectedRowIndex = 0;
					}
					else
						btnAddSpecialty.Enabled = false;
					this.gridProviderSpecialties.UpdateFromCollection(Provider.Specialties);
					if (gridProviderSpecialties.Rows.Count > 0)
						gridProviderSpecialties.SelectedRowIndex = 0;
					

					// Bind Active Provider Focuses
					this.lstFocuses.UpdateFromCollection(ProviderFocusTypeCollection.ActiveProviderFocusTypes);
					if (lstFocuses.Rows.Count > 0)
						lstFocuses.SelectedRowIndex = 0;
					this.gridProviderFocuses.UpdateFromCollection(Provider.Focuses);
					if (gridProviderFocuses.Rows.Count > 0)
						gridProviderFocuses.SelectedRowIndex = 0;
				

					// group practices
					this.Provider.LoadGroupPractices();
					this.gridProviderGroupPractices.UpdateFromCollection(Provider.GroupPractices);
					if (this.gridProviderGroupPractices.Rows.Count > 0)
					{
						this.SelectedGPIndex = 0;
						GroupPracticeProviderLink groupProviderNetworkLink = Provider.GroupPracticeLinks[gridProviderGroupPractices.SelectedColectionIndex];
						groupProviderNetworkLink.LoadEffectiveDateHistory(true);
						this.gridGPDates.UpdateFromCollection(groupProviderNetworkLink.EffectiveDateHistory);
						this.gridProviderGPLocations.UpdateFromCollection (this.Provider.GroupPracticeLinks);
						this.gridProviderGroupPractices.SelectedRowIndex = 0;
						
					}
					// -- Dont show Add Effective Date button if no GroupPractices linked to current provider.					
					btnAddGPDates.Visible = gridProviderGroupPractices.Rows.Count > 0;

					if (Provider.ProviderID == 0) // if new provider dont show active status fields
					{
						lbDateActive.Visible = false;
						DateActive.Visible = lbActive.Visible = Active.Visible = false;
					}
					
					SetButtonEnabled();
					this.pnlFocusDate.Visible = false;
					this.pnlSpecialtyStatus.Visible = false;

					// Bind Notes
					this.UpdateFromObject(pnlProviderNote.Controls, provider);					
					this.UserDefined1.ReloadContext("Provider",provider,false);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("providerObj", provider);  // cache object using the caching method declared on the page
			}
		}


		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			if (tab.Key == "BasicInfo")
			{
				toolbar.AddButton("@LOCATIONS@", "Locations");
				if (this.Provider != null && this.Provider.ProviderID == 0)
					this.SetPageTabToolbarItemEnabled("Locations", false);
			}
			else if (tab.Key == "GroupPractice")
			{
				toolbar.AddButton("@ADDNEWRECORD@","AddGP");
				if (this.Provider != null && this.Provider.ProviderID == 0)
				{
					this.SetPageTabToolbarItemEnabled("AddGP",false);
					this.pnlGroupPractices.Enabled = false;
				}
			}

		}


		public void OnToolbarButtonClick_Locations(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			LocationForm.PushCurrentCallingPage();
			LocationForm.Redirect(typeof(Provider), this.Provider.ProviderID);
		}

		
		public override void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick (toolbar, button);

			//button.Key == "Save"
		}

		public void OnToolbarButtonClick_DeleteGP(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.selectedGPLocIndex >= 0)
			{
				this.Provider.LoadGroupPracticeLinks(false);
				
				// get current GPPLink obj
				GroupPracticeProviderLink gppLink = new GroupPracticeProviderLink();
				gppLink.Load((int)gridProviderGPLocations.SelectedRowPK[0]);
				int gpID = gppLink.GroupPracticeID;
				for (int j = 0; j < Provider.GroupPracticeLinks.Count; j++)
				{
					if (Provider.GroupPracticeLinks[j].GroupPracticeID != gpID)
						Provider.GroupPracticeLinks.RemoveAt(j);
				}
				
					
				GroupPracticeProviderLink gppLinkCurrent = new GroupPracticeProviderLink();
				Provider.GroupPracticeLinks.MarkDel(gridProviderGPLocations.SelectedRowIndex);
				try
				{
					// delete both history and group practice provider link
					GroupPracticeProviderLink gpLink = Provider.GroupPracticeLinks[gridProviderGPLocations.SelectedColectionIndex];
					gpLink.LoadEffectiveDateHistory(false);
					gpLink.EffectiveDateHistory.MarkAllDel();
					gpLink.MarkDel();

					this.gridProviderGroupPractices.UpdateFromCollection(Provider.GroupPractices);
					
					// clear selected cache
					int oldIndex = this.SelectedGPIndex;
					this.SelectedGPLocIndex = -1;
					this.SelectedGPIndex    = -1;
					// reload grid
					if (this.gridProviderGroupPractices.Rows.Count > oldIndex)
						this.SelectedGPIndex = oldIndex;
					//this.provider.Load(this.Provider.ProviderID);
					//this.Provider = this.provider;
					this.gridGPDates.ClearRows();
					
				}
				catch (SqlException ex)
				{
					this.SetPageMessage("@REFERENCED@", NetsoftUSA.WebForms.EnumPageMessageType.Error);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				
			}
			else
				this.SetPageMessage("@SELECTGROUPPRACTICE@", NetsoftUSA.WebForms.EnumPageMessageType.Warning);
		}
		public void OnToolbarButtonClick_AddGP(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.SelectedGroupPracticeProvider = new GroupPracticeProviderLink();
			this.SelectedGroupPracticeProvider.New();

			//SetGroupPracticeGridsVisible(false); // disable the tabs
			this.pnlGroupPracticeDate.Visible = true;
			this.tblEffectiveDate.Visible = false;

		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForProvider()
		{
			try
			{	//customize this method for this specific page
				
				this.UpdateToObject(this.pnlProviderNote.Controls, this.provider);
				this.UpdateToObject(this.tblProviderInfo1.Controls, this.provider);	// controls-to-object
				this.UpdateToObject(this.tblProviderInfo2.Controls, this.provider);	// controls-to-object
				//this.UpdateToObject(this.tblProviderAddress.Controls,this.selectedProviderAddress);	// controls-to-object
				UserDefined1.UserDefinedValue=provider.UserDefined;
				this.UserDefined1.ReadControls();
				
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private bool SaveData()
		{
			if (this.ReadControlsForProvider())
			{
				try
				{
					if (this.Provider.ProviderID != 0)
						this.Provider.Locations[0].MarkDirty();
					this.Provider.Save();
					
					// Enable Locations and tGP Button
					this.SetPageTabToolbarItemEnabled("Locations", true);
					this.SetPageTabToolbarItemEnabled("AddGP",true);
					this.SetPageTabToolbarItemEnabled("DeleteGP",true);
					this.pnlGroupPractices.Enabled = true;

					this.Provider = provider;
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
					return false;
				}
				return true;
			}
			else
				return false;
				

		}

		private void btnAddLanguage_Click(object sender, System.EventArgs e)
		{
			
			bool resume = true;
			int langID = (int)lstLanguages.SelectedRowPK[0];

			if (langID != 0)
			{
				for (int i=0; i < Provider.ProviderLanguages.Count && resume; i++)
					resume = (langID != Provider.ProviderLanguages[i].LanguageID || (langID == Provider.ProviderLanguages[i].LanguageID && Provider.ProviderLanguages[i].IsMarkedForDeletion)) ? true : false;
				if (resume)
				{
					ProviderLanguage provLang = new ProviderLanguage();
					provLang.New();
					provLang.LanguageID		  = langID;
					provLang.ProviderID		  = Provider.ProviderID;
					provLang.CreateTime		  = DateTime.Now;
					Provider.ModifiedBy		  = 1;
					
			
					provLang.CreatedBy		  = 1;				// this has to be handled by security to get the current ID
					Provider.ProviderLanguages.Add(provLang);
					gridProviderLanguages.UpdateFromCollection(Provider.ProviderLanguages);
					if (gridProviderLanguages.Rows.Count > 0)
						gridProviderLanguages.SelectedRowIndex = 0;
				}
			}
			else
				this.SetPageMessage("@SELECTLANG@", NetsoftUSA.WebForms.EnumPageMessageType.Warning);
		}

		private void btnRemoveLanguage_Click(object sender, System.EventArgs e)
		{
			if (gridProviderLanguages.SelectedRowIndex >= 0)
			{
				try
				{
					Provider.ProviderLanguages[gridProviderLanguages.SelectedColectionIndex].MarkDel();
					// refresh grid
					this.gridProviderLanguages.UpdateFromCollection(this.Provider.ProviderLanguages);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				SetButtonEnabled();
			}
		}


		private void btnAddFocus_Click(object sender, System.EventArgs e)
		{
			
			if (lstFocuses.SelectedRowIndex >= 0)
			{
				bool			resume			= true;
				ProviderFocus	provFocCompare	= null;
				int selectedTypeID = (int)lstFocuses.SelectedRowPK[0];	

				if (selectedTypeID != 0)
				{
					if (Provider.Focuses != null)
					{
						for (int i = 0; i < this.Provider.Focuses.Count; i++)
						{
							provFocCompare		= Provider.Focuses[i];
							if (selectedTypeID == provFocCompare.ProviderFocusTypeID && provFocCompare.TerminationDate == DateTime.MinValue)
							{
								resume = false;
								break;
							}
						}
					}
					else
						Provider.Focuses = new ProviderFocusCollection();

					if (resume)
					{
						ProviderFocus provFoc		= new ProviderFocus();
						provFoc.New();
						provFoc.EffectiveDate		= DateTime.Today.Date;
						provFoc.ProviderFocusTypeID = selectedTypeID;
						provFoc.ProviderID			= this.Provider.ProviderID;
						this.SelectedProviderFocus  = provFoc;
						
						// show the panel
						SetFocusDatesVisible(true, false);
						pnlFocusDate.Visible = true;
					}
				}
			}
			else
				this.SetPageMessage("@SELECTFOCUS@", NetsoftUSA.WebForms.EnumPageMessageType.Warning);
	
		}

		private void SetFocusDatesVisible(bool effAndFocus, bool termDate)
		{
			this.WebDateTimeEdit1.Enabled		= termDate;
			this.OBFieldLabel1.Enabled			= termDate;
			this.WebDateTimeEdit2.Enabled		= effAndFocus;
			this.OBLabel16.Enabled				= effAndFocus;
			this.OBFieldLabel2.Enabled			= effAndFocus;			
			this.ProviderFocusTypeID.Enabled	= effAndFocus;
		}



		private void btnRemoveFocus_Click(object sender, System.EventArgs e)
		{
			if (gridProviderFocuses.SelectedRowIndex >= 0)
			{
				this.SelectedProviderFocus = Provider.Focuses[gridProviderFocuses.SelectedColectionIndex];
				this.SetFocusDatesVisible(false, true);
				this.pnlFocusDate.Visible = true;
				SetButtonEnabled();
			}

		}

		private void btnSpecialtySetPrimary_Click(object sender, System.EventArgs e)
		{
			if (this.gridProviderSpecialties.SelectedRowIndex >= 0)
			{
				ProviderSpecialty currentProviderSpecialty = null;
				// reset all to non - primary
				for (int i = 0; i < this.gridProviderSpecialties.Rows.Count; i++)
				{
					
					currentProviderSpecialty			= Provider.Specialties[gridProviderSpecialties.GetColIndexFromRowIndex(i)];
					currentProviderSpecialty.Primary	= (((int)currentProviderSpecialty.SpecialtyID) == Provider.Specialties[gridProviderSpecialties.SelectedColectionIndex].SpecialtyID) ? true : false;
					currentProviderSpecialty.IsDirty	= true;
				}
				this.gridProviderSpecialties.UpdateFromCollection(Provider.Specialties);
				//Provider = this.provider;
			}
		}

		private void btnSpecialtyChangeStatus_Click(object sender, System.EventArgs e)
		{
			if (gridProviderSpecialties.SelectedRowIndex >= 0)
			{
				SelectedProviderSpecialty = Provider.Specialties[gridProviderSpecialties.SelectedColectionIndex];
				SelectedProviderSpecialty.IsDirty = true;
				this.UpdateFromObject(this.pnlSpecialtyStatus.Controls, SelectedProviderSpecialty);
				this.pnlSpecialtyStatus.Visible = true;		
		
		
			}
		}


		/// <summary>
		///  Adds / Updates a focus based on effective dates.
		/// </summary>
		private void AddFocus()
		{
			if (this.SelectedProviderFocus != null)
			{
				this.Provider.Focuses.Add(this.SelectedProviderFocus);
				this.gridProviderFocuses.UpdateFromCollection(this.Provider.Focuses);
				this.SelectedProviderFocus = null;
				SetButtonEnabled();
			}
		}

		private void TerminateFocus()
		{
			if (SelectedProviderFocus != null)
			{
				try
				{

					// find current focus in collection
					for (int i=0; i < Provider.Focuses.Count; i++)
					{
						if (Provider.Focuses[i].ProviderFocusID == SelectedProviderFocus.ProviderFocusID)
						{
							ProviderFocus currentFocus = Provider.Focuses[i];
							currentFocus.TerminationDate = this.SelectedProviderFocus.TerminationDate;
							currentFocus.MarkDirty();
							
							break;
						}
					}
					
					SelectedProviderFocus = null;
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				finally
				{
					this.gridProviderFocuses.UpdateFromCollection(this.Provider.Focuses);
					SetButtonEnabled();
				}
			}
		}

		private void UpdateSpecialtyStatus()
		{
			
			if (this.SelectedProviderSpecialty != null)
			{
				try
				{
					if (SelectedProviderSpecialty.ParentProviderSpecialtyCollection != null) //!SelectedProviderSpecialty.IsNew) // Update Existing specialty
					{
						if (Provider.Specialties == null)
							Provider.LoadSpecialties(false);
						for (int i=0; i < Provider.Specialties.Count; i++)
						{
							if (Provider.Specialties[i].ProviderSpecialtyID == SelectedProviderSpecialty.ProviderSpecialtyID
								&& Provider.Specialties[i].SpecialtyID == SelectedProviderSpecialty.SpecialtyID)
							{
								Provider.Specialties[i] = SelectedProviderSpecialty;
								Provider.Specialties[i].MarkDirty();
								
								break;
							}
						}
					}
					else // New Specialty
					{
						ProviderSpecialty provSpec = new ProviderSpecialty();

						provSpec.New();
						provSpec.SpecialtyID	= SelectedProviderSpecialty.SpecialtyID ;
						provSpec.CreateTime		= DateTime.Now ;
						provSpec.CreatedBy		= SelectedProviderSpecialty.ProviderID ;
						if (this.Provider.Specialties.Count == 0)
							provSpec.Primary = true;
						else
							provSpec.Primary = false;
						provSpec.ProviderID 	= SelectedProviderSpecialty.ProviderID;
						provSpec.StartDate		= SelectedProviderSpecialty.StartDate;
						provSpec.EndDate		= SelectedProviderSpecialty.EndDate ;

						// add specialty to collection
						this.SelectedProviderSpecialty = provSpec;
						Provider.Specialties.Add(provSpec);
						// refresh grid
						gridProviderSpecialties.UpdateFromCollection(Provider.Specialties);
					}
					SetButtonEnabled();
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				
			}
		}


		private void btnAddSpecialty_Click(object sender, System.EventArgs e)
		{
			int selectedSpecialty = 0;
			ProviderSpecialty providerSpecialty = new ProviderSpecialty();
			try
			{
				selectedSpecialty = (int)lstSpecialties.SelectedRowPK[0];
				providerSpecialty.New();
				providerSpecialty.SpecialtyID	= selectedSpecialty;
				providerSpecialty.StartDate     = DateTime.Now;
				providerSpecialty.ProviderID	= this.Provider.ProviderID;
				
				this.SelectedProviderSpecialty  = providerSpecialty;
				this.UpdateFromObject(pnlSpecialtyStatus.Controls, providerSpecialty);
				
				pnlSpecialtyStatus.Visible = true;
			
					
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}

			
		}

		private void gridProviderSpecialties_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				this.SelectedSpecialtyIndex = this.gridProviderSpecialties.GetColIndexFromCellEvent(e);
			}
		}

		private void btnRemoveSpecialty_Click(object sender, System.EventArgs e)
		{
			if (gridProviderSpecialties.SelectedRowIndex >= 0)
			{
				try
				{
					Provider.Specialties.MarkDel(gridProviderSpecialties.SelectedColectionIndex);
					this.gridProviderSpecialties.UpdateFromCollection(Provider.Specialties);
					if (gridProviderSpecialties.Rows.Count > 0)
						gridProviderSpecialties.SelectedRowIndex = 0;
					SetButtonEnabled();
					
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				
			}
		}

		private void SetButtonEnabled()
		{
			this.btnSpecialtySetPrimary.Enabled = this.btnSpecialtyChangeStatus.Enabled = this.btnRemoveSpecialty.Enabled = (this.gridProviderSpecialties.Rows.Count > 0);
			this.btnRemoveFocus.Enabled = (this.gridProviderFocuses.Rows.Count > 0);
			this.btnRemoveLanguage.Enabled = (this.gridProviderLanguages.Rows.Count > 0);
		}

		private void gridProviderGroupPractices_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				this.SelectedGPIndex = this.gridProviderGroupPractices.GetColIndexFromCellEvent(e);
				LoadGPLocations(Provider.GroupPractices[gridProviderGroupPractices.SelectedColectionIndex].GroupPracticeID);
			}
			
		}

		private void gridProviderGPLocations_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				this.SelectedGPLocIndex = this.gridProviderGPLocations.GetColIndexFromCellEvent(e);
			}
		}


		private void LoadGPLocations(int groupPracticeID)
		{
			
		}

		private void gridProviderGroupPractices_InitializeLayout(object sender, Infragistics.WebUI.UltraWebGrid.LayoutEventArgs e)
		{
		
		}

		private void gridProviderGroupPractices_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			this.SelectedGPIndex = gridProviderGroupPractices.GetColIndexFromClickEvent(e);
		}

		private void gridProviderGPLocations_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			this.SelectedGPLocIndex = gridProviderGPLocations.GetColIndexFromClickEvent(e);
		}

		private void btnAddGPDates_Click(object sender, System.EventArgs e)
		{
			this.newHistory = new GroupPracticeProviderHistory();
			this.UpdateFromObject(this.tblGPDates.Controls, newHistory);
			this.AsOfDate.Value = DateTime.Now.Date;
			btnSaveGPDates.Enabled = btnCancelGPDates.Enabled  = true;
			tblGPDates.Visible = true;
			this.tblGPDates.Disabled = false; 
		}

		private void btnCancelGPDates_Click(object sender, System.EventArgs e)
		{
			this.UpdateFromObject(this.tblGPDates.Controls, new GroupPracticeProviderHistory());
			this.btnSaveGPDates.Enabled = this.btnCancelGPDates.Enabled = false;
			this.tblGPDates.Disabled = true;			
			this.tblGPDates.Visible = false;
		}
		
		
		private void DisableGPDates(bool val)
		{
			
			//lbEffectiveDate.Enabled =  EffectiveDate.Enabled = lbTerminationDate.Enabled	= val;
			//TerminationDate.Enabled = lbAsOfDate.Enabled	=  AsOfDate.Enabled	= val;
			//btnSaveGPDates.Enabled = btnCancelGPDates.Enabled = val;
			tblGPDates.Visible = val;
		}

		private void btnSaveGPDates_Click(object sender, System.EventArgs e)
		{
			GroupPracticeProviderHistory gpLink = new GroupPracticeProviderHistory();
			this.UpdateToObject(this.tblGPDates.Controls, gpLink);
			gpLink.AsOfDate = (DateTime)this.AsOfDate.Value;
			gpLink.Active	= true;

			
			// check all dates for duplicates
			GroupPracticeProviderLink linkCheck = new GroupPracticeProviderLink ();
			linkCheck.Load(this.SelectedGPIndex);
			linkCheck.LoadEffectiveDateHistory(false);
			
			bool resume = true;
			for (int i = 0 ; i < linkCheck.EffectiveDateHistory.Count; i++)
			{
				if 	(((((GroupPracticeProviderHistory)Provider.GroupPracticeLinks.GetAt(i)).EffectiveDate == gpLink.EffectiveDate) && ((GroupPracticeProviderHistory)Provider.GroupPracticeLinks.GetAt(i)).EffectiveDate == gpLink.EffectiveDate))
				{
					resume = false;
					break;
				}
			}
			// check for current date too
			resume = (linkCheck.EffDate == gpLink.EffectiveDate && linkCheck.TerminationDate == gpLink.TerminationDate) ? false : true;
			if (resume)
			{
				try
				{
					GroupPracticeProviderLink provCurrentLink = Provider.GroupPracticeLinks.GetAt(gridProviderGroupPractices.SelectedRowIndex ) as GroupPracticeProviderLink;
					// move current record to archive and mark it Inactive
					provCurrentLink.LoadEffectiveDateHistory(false);
					GroupPracticeProviderHistory provCurrentDates = new GroupPracticeProviderHistory();
					//ProviderLocationNetworkHistory provDate = new ProviderLocationNetworkHistory();

					provCurrentDates.New();
					provCurrentDates.AsOfDate						= gpLink.AsOfDate;
					provCurrentDates.EffectiveDate					= gpLink.EffectiveDate;
					provCurrentDates.TerminationDate				= gpLink.TerminationDate;
					provCurrentDates.Active							= true;
					
					provCurrentLink.EffectiveDateHistory.Add(provCurrentDates);
					
					gpLink.Active = true;
					provCurrentDates.GroupPracticeProviderID  = provCurrentLink.GroupPracticeProviderID;

					GroupPracticeProviderHistoryCollection provColHistoryCol = new GroupPracticeProviderHistoryCollection();
					provColHistoryCol.UpdateStatusForGroupPracticeProviderHistory(-1,gpLink,provCurrentLink.GroupPracticeProviderID);
					
					provCurrentDates.Save();
					this.SelectedGPIndex = 0;
					this.gridGPDates.UpdateFromCollection(provCurrentLink.EffectiveDateHistory);
					this.gridProviderGPLocations.UpdateFromCollection (this.Provider.GroupPracticeLinks);
					
					GroupPracticeProviderHistory blankHistory = new GroupPracticeProviderHistory();
					this.UpdateFromObject(this.tblGPEffectiveDates.Controls, blankHistory);
					DisableGPDates(false);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			else
				this.SetPageMessage("@DUPLICATEDATES@",NetsoftUSA.WebForms.EnumPageMessageType.Error);	
		}

		/*
	
		private void lstLanguages_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell != null && e.Cell.Key == "Select")
			{
				this.SelectedLangTypeIndex = lstLanguages.GetColIndexFromCellEvent(e);
			}
		}

		private void lstFocuses_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell != null && e.Cell.Key == "Select")
			{
				this.SelectedFocusTypeIndex = lstFocuses.GetColIndexFromCellEvent(e);
				
			}
		}

		private void lstSpecialties_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell != null && e.Cell.Key == "Select")
			{
				SelectedSpecialtyIndex = lstSpecialties.GetColIndexFromCellEvent(e);
			}
		}
		*/
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ProviderFocus SelectedProviderFocus
		{
			get { return selectedProviderFocus; }
			set
			{
				selectedProviderFocus = value;
				try
				{
					this.UpdateFromObject(this.tblEffectiveDate.Controls , selectedProviderFocus);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedFocus", selectedProviderFocus);  // cache object using the caching method declared on the page
			}
		}
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Address SelectedProviderAddress
		{
			get { return selectedProviderAddress; }
			set
			{
				selectedProviderAddress = value;
				try
				{
					//this.UpdateFromObject(this.tblProviderAddress.Controls,selectedProviderAddress );  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("providerAddress", selectedProviderAddress);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSelectedProviderFocus()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlFocusDate.Controls, selectedProviderFocus);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private void btnProceed_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.UpdateToObject(this.tblEffectiveDate.Controls, this.SelectedProviderFocus);
				//this.SelectedProviderFocus.CreatedBy = 1;
				//this.SelectedProviderFocus.CreateTime = DateTime.Now;
				if (this.ProviderFocusTypeID.Enabled)
					this.AddFocus();
				else
					this.TerminateFocus();
					
				this.pnlFocusDate.Visible = false;
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}

		}

		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.SelectedProviderFocus = null;
			this.pnlFocusDate.Visible = false;
		}

		private void btnOKSpecialtyStatus_Click(object sender, System.EventArgs e)
		{
			
			this.UpdateToObject(this.pnlSpecialtyStatus.Controls, selectedProviderSpecialty);
			this.SelectedProviderSpecialty = selectedProviderSpecialty;
			this.UpdateSpecialtyStatus();
			this.pnlSpecialtyStatus.Visible = false;
		}

		private void btnCancelSpecialtyStatus_Click(object sender, System.EventArgs e)
		{
			this.pnlSpecialtyStatus.Visible = false;
			this.SelectedProviderSpecialty = null;
		}



		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ProviderSpecialty SelectedProviderSpecialty
		{
			get { return selectedProviderSpecialty; }
			set
			{
				selectedProviderSpecialty = value;
				try
				{
					this.UpdateFromObject(this.pnlSpecialtyStatus.Controls, selectedProviderSpecialty);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedProviderSpecialty", selectedProviderSpecialty);  // cache object using the caching method declared on the page
			}
		}



	
		private void SetGroupPracticeGridsVisible(bool visibility)
		{
			this.lblGPEffDates.Visible = this.gridGPDates.Visible = this.tblGPDates.Visible =  tblGPEffectiveDates.Visible = visibility;
			btnSaveGPDates.Enabled = btnCancelGPDates.Enabled = false; // disable 
			btnAddGPDates.Visible = this.Provider.GroupPractices != null && (this.Provider.GroupPractices.Count > 0);
			//this.lblGPLocs.Visible	= this.gridProviderGPLocations.Visible = tblGPLocations.Visible  = visibility;
		}

		private void WebButton1_Click(object sender, System.EventArgs e)
		{
			this.SelectedGroupPracticeProvider = null;
			this.pnlGroupPracticeDate.Visible = false;
			SetGroupPracticeGridsVisible(true);
		}

		private void WebButton2_Click(object sender, System.EventArgs e)
		{
			this.UpdateToObject(this.pnlGroupPracticeDate.Controls, this.SelectedGroupPracticeProvider);
			this.SelectedGroupPracticeProvider.GroupPracticeID = (int)this.GroupPracticeID.Value;
			this.SelectedGroupPracticeProvider.GroupPracticeLocationID = (int)this.GroupPracticeLocationID.Value;
			if (AddGroupPracticeLink())
			{
				this.pnlGroupPracticeDate.Visible = false;
				this.SetGroupPracticeGridsVisible(true);
			}
			
		}


		private void gridProviderFocuses_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			//gridProviderFocuses.AddButtonColumn("Select", "@SELECT@",0).Width = selectWidth;
		}

		private void gridProviderLanguages_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridProviderLanguages.AddButtonColumn("Select", "@SELECT@",0).Width = selectWidth;
		}

		private void lstLanguages_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			lstLanguages.AddButtonColumn("Select", "@SELECT@",0).Width = selectWidth;
		}

		private void lstSpecialties_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			//lstSpecialties.AddButtonColumn("Select", "@SELECT@",0).Width = selectWidth;
		}

		private void lstFocuses_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			//lstFocuses.AddButtonColumn("Select", "@SELECT@",0).Width = selectWidth;
		}

		private void gridProviderSpecialties_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			//gridProviderSpecialties.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;
		}

		private void gridProviderGroupPractices_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridProviderGroupPractices.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;
		}

		private void lstLanguages_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
				lstLanguages.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void lstFocuses_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			//if (e.Cell.Key == "State")
			//	lstFocuses.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void lstSpecialties_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			//if (e.Cell.Key == "Select")
			//	lstSpecialties.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void gridProviderGroupPractices_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				gridProviderGroupPractices.SelectedRowIndex = e.Cell.Row.Index;
				BindGroupPracticeLocations((int)gridProviderGroupPractices.SelectedRowPK [0]);
			}
		}
		
		private void BindGroupPracticeLocations(int groupPracticeID)
		{
			GroupPractice gp = new GroupPractice();
			gp.Load(groupPracticeID);
			this.gridProviderGPLocations.UpdateFromCollection (this.Provider.GroupPracticeLinks);
			//this.ResultGroupPracticeLocations = gp.Locations;
		}

		private void gridProviderGPLocations_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
				gridProviderGPLocations.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void gridProviderGPLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridProviderGPLocations.AddButtonColumn("Select","@SELECT@",0);
		}



		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeProviderLink SelectedGroupPracticeProvider
		{
			get { return selectedGroupPracticeProvider; }
			set
			{
				selectedGroupPracticeProvider = value;
				try
				{
					this.UpdateFromObject(this.pnlGroupPracticeDate.Controls, selectedGroupPracticeProvider);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedGPProviderLink", selectedGroupPracticeProvider);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeProviderLinkCollection GroupPracticeProviderLinks
		{
			get { return groupPracticeProviderLinks; }
			set
			{
				groupPracticeProviderLinks = value;
				try
				{
					this.gridProviderGPLocations.UpdateFromCollection(groupPracticeProviderLinks);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(GroupPracticeProviderLinkCollection), groupPracticeProviderLinks);  // cache object using the caching method declared on the page
			}
		}
	
	
	}
}
