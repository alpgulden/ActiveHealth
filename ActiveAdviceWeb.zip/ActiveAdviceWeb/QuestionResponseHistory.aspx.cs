using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;


namespace ActiveAdvice.Web
{
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]
	[MainDataClass("Response,DataLayer")]
	[PageTitle("@QUESTIONRESPONSEHISTORYPAGETITLE@")]
	public class QuestionResponseHistory : AssessmentBasePage
	{
		private Question question;
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResponses;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridResponses;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;

		Infragistics.WebUI.UltraWebToolbar.TBarButton CloseButton;


		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();
			}
			else
			{
			}

		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("QuestionResponseHistory.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			try
			{	
				if (this.Request["QID"] != null)
				{
					int questionID = int.Parse(this.Request["QID"].ToString());
					question = assessmentContext.Questions.FindBy(questionID);

					string responseText = "";
					string lastMedications = "";

					gridResponses.Columns[0].Header.Caption = this.Language.TranslateSingle("CREATEDBY");
					gridResponses.Columns[1].Header.Caption = this.Language.TranslateSingle("DATE");
					gridResponses.Columns[2].Header.Caption = this.Language.TranslateSingle("RESPONSE");

					if (question.QuestionControlType == QuestionControlTypeEnum.Medication)
					{
						ArrayList medications = this.assessmentContext.GetLatestMedicationReponses(this.question.QuestionID, false, true, -1);
						if (medications != null && medications.Count > 0)
						{
							for (int i = 0; i < medications.Count; i++)
							{
								lastMedications = MedicationCollection.AllMedications.GetMedicationNamesCombined((ArrayList)medications[i]);
								UltraGridRow row = new UltraGridRow();
								gridResponses.Rows.Add(row);	

								row.Cells[0].Value = ((PatientMedication)((ArrayList)medications[i])[0]).CreatedByString; 
								row.Cells[1].Value = ((PatientMedication)((ArrayList)medications[i])[0]).CreateTime;
								row.Cells[2].Value = lastMedications;
							}
							
						}
					}
					else
					{
						ArrayList responses = this.assessmentContext.GetLatestReponses(this.question.QuestionID, false, true, -1);
						if (responses != null && responses.Count > 0)
						{
							for (int i = 0; i < responses.Count; i++)
							{
								responseText = this.question.GetResponseTextsCombined((ArrayList)responses[i]);
								UltraGridRow row = new UltraGridRow();
								gridResponses.Rows.Add(row);	

								row.Cells[0].Value = ((Response)((ArrayList)responses[i])[0]).CreatedByString; 
								row.Cells[1].Value = ((Response)((ArrayList)responses[i])[0]).CreateTime;
								row.Cells[2].Value = responseText;
							}
						}
					}

				
				}

				this.CacheObject(typeof(Question), question);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//obj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			return result;
		}



		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@CLOSE@", "Close");
		}


		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			this.SetPageToolbarItemTargetURL("Close", "javascript:window.close();");
		}


		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(question);
		}

	}
}
