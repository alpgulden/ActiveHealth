using System;
using System.Web;
using System.Web.UI;
using System.Collections;
using System.IO;
using ActiveAdvice.DataLayer;
using System.Text.RegularExpressions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for PageSummary.
	/// </summary>
	public class PageSummary : System.Web.UI.WebControls.Panel
	{
		SummaryWriter summaryWriter = null;
		
		BasePage currentPage = null;

		string summaryTitle = null;

		public string SummaryTitle
		{
			get {return summaryTitle;}
			set {summaryTitle = value;}
		}

		public BasePage CurrentPage
		{
			get {return currentPage;}
			set {currentPage = value;}
		}

		public PageSummary()
		{
		}


		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			((BasePage)this.Page).RenderPageSummary(this);
		}



		public void RenderObjects(params BaseData[] objects)
		{
			BasePage pg = this.Page as BasePage;
			if (pg == null) pg = this.currentPage;
			if (pg == null) return;

			summaryWriter = new SummaryWriter(pg.Language);

			bool isEmpty = true;
			// Loop through objects passed to be rendered
			summaryWriter.StartNewSection();

			if (this.summaryTitle != null)
				summaryWriter.AddSummaryTitle(this.summaryTitle);

			foreach (BaseData obj in objects)
			{
				if (obj != null)
				{
					obj.FillSummaryText(summaryWriter);
					isEmpty = false;
				}
			}
			summaryWriter.EndSection();

			if (isEmpty)
				summaryWriter = null;
		}


		public string HTMLContent
		{
			get 
			{
				if (summaryWriter != null)
					return summaryWriter.ToString();

				return "";
			}
		}

		public string PlainTextContent
		{
			get 
			{
				if (summaryWriter != null)
				{
					Regex regex = new Regex("<[^>]*>");
					return Regex.Replace(summaryWriter.ToString(), "<[^>]*>", " ");
				}

				return "";
			}
		}

        
		protected override void Render(HtmlTextWriter writer)
		{
			// Output the contents of SummaryWriter to the html stream

			if (this.HTMLContent != null)
			{
				writer.Write(this.HTMLContent);
			}
			base.Render (writer);
		}

		

	}
}
