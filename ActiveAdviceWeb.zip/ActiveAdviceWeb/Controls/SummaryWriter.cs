using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.IO;
using System.Reflection;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Web
{
	
	

	/// <summary>
	/// Summary description for SummaryWriter.
	/// 
	/// 
	///                   sw.AddField("name", "value");
	///                   sw.AddField(this, "name");
	///                   sw.AddField(this, "name", "surname");
	///                   sw.AddHyperlink("asdklfsdaljfj");
	///                   sw.AddCustomInfo("");
	/// 
	/// 
	/// 
	/// 
	/// </summary>
	public class SummaryWriter : HtmlTextWriter
	{

		public SummaryWriter(TextWriter writer) : base (writer)
		{
		}


		public void StartNewSection()
		{
			this.WriteLine("<table class=\"SummarySection\">");
		}

		public void EndSection()
		{
			this.WriteLine("</table>");
		}

		public void StartNewLineInSection()
		{
			this.WriteLine("<tr><td>");
		}
		
		public void EndLineInSection()
		{
			this.WriteLine("</td></tr>");
		}


		public void AddLabelandValue(string fieldName, string fieldValue)
		{
			this.Write("<span class=\"SummaryFieldName\">" + fieldName + "</span>");
			this.Write("&nbsp;");
			this.Write("<span class=\"SummaryFieldValue\">" + fieldValue + "</span>");
		}

		
		public void AddLabelandValueOnNewLine(string fieldName, string fieldValue)
		{
			StartNewLineInSection();
			AddLabelandValue(fieldName, fieldValue);
			EndLineInSection();
		}

		public void AddFieldOnNewLine(NetsoftUSA.DataLayer.BaseDataClass obj, string fieldName)
		{
			StartNewLineInSection();
			AddField(obj, fieldName);
			EndLineInSection();
		}


		public void AddField(NetsoftUSA.DataLayer.BaseDataClass obj, string fieldName)
		{
			MemberInfo member = ReflectionHelper.GetFieldOrProp(obj.GetType(), fieldName);
			string fieldDescription = FieldDescriptionAttribute.GetDescription(member, true);
			string fieldValue = ReflectionHelper.GetMemberValueAsString(obj, fieldName);

			AddLabelandValue(fieldDescription, fieldValue);
		}

		public void AddFieldsOnNewLine(NetsoftUSA.DataLayer.BaseDataClass obj, string[] fieldNames)
		{
			StartNewLineInSection();
			AddFields(obj, fieldNames);
			EndLineInSection();
		}

		public void AddFields(NetsoftUSA.DataLayer.BaseDataClass obj, string[] fieldNames)
		{
			foreach (string fieldName in fieldNames)
			{
				AddField(obj, fieldName);
			}
		}
		
		public void AddHyperlink(string linkText, string URL)
		{
			this.Write(String.Format("<a class=\"SummaryLink\" href=\"{1}\">{0}</a>"), linkText, URL);
		}

		public void AddCustomInfo(string text)
		{
			this.Write("<span class=\"SummaryCustomText\">" + text + "</span>");
		}



		public void AddHyperlinkOnNewLine(string linkText, string URL)
		{
			StartNewLineInSection();
			AddHyperlink(linkText, URL);
			EndLineInSection();
		}		
                

	}
}
