using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using Dundas.Charting.WebControl;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for Chart.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]	
	[MainDataClass("PatientMeasurement,DataLayer")]
	public class Chart : BasePage
	{
		private PatientMeasurementCollection patientMeasurements;
		protected Dundas.Charting.WebControl.Chart chrtMain;
		private Patient patient;

		private const int MAXCHARTWIDTH = 584;
		private const int MAXCHARTHEIGHT = 400;
		private const int WIDTHPERITEM = 20;

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (IsPostBack)
				LoadData();
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));
				patientMeasurements = (PatientMeasurementCollection)this.LoadObject(typeof(PatientMeasurementCollection));  // load object from cache
			}
			Draw();
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientMeasurementCollection PatientMeasurements
		{
			get { return patientMeasurements; }
			set
			{
				patientMeasurements = value;
				this.CacheObject(typeof(PatientMeasurementCollection), patientMeasurements);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			
			patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
			this.CacheObject(typeof(Patient), patient);
			
			PatientMeasurementCollection patientMeasurements = new PatientMeasurementCollection();
			try
			{	
				patient.LoadPatientMeasurements(false);
				patientMeasurements = patient.PatientMeasurements;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.PatientMeasurements = patientMeasurements;
			return result;
		}

		private void Draw()
		{
			ArrayList yValues = new ArrayList();
			ArrayList xValues = new ArrayList();

			if(PatientMeasurements.DrawGraph(PatientMeasurements.SelectedMeasurementTypeID, ref yValues, ref xValues))
			{	
				chrtMain.Titles[0].Text = MeasurementTypeCollection.AllMeasurementTypes.Lookup_DescriptionByCodeId(PatientMeasurements.SelectedMeasurementTypeID);
				
				chrtMain.Series["Measurements"].Points.DataBindXY(xValues, "date", yValues, "values");
				
				int i = 0;
				
				foreach(DataPoint point in chrtMain.Series["Measurements"].Points)
				{
					string date = ((DateTime)xValues[i]).ToShortDateString();
					string val  = yValues[i].ToString();
					point.Label = date;
					LegendItem li = new LegendItem();
						//li.Name =  val + "  " + date;
						li.Name = String.Format("{0} {1}", val, date);
					chrtMain.Legends[0].CustomItems.Add(li);
					i++;
				}
				
				double width = chrtMain.Series["Measurements"].Points.Count * WIDTHPERITEM
					+ chrtMain.Width.Value;
				if (width > MAXCHARTWIDTH)
					chrtMain.Width = MAXCHARTWIDTH;
				else
					chrtMain.Width = (Unit)width;
				
			}
			else
				this.SetPageMessage("Couldn't draw graph for this Measurement Type.", EnumPageMessageType.Error);
		}
	}
}
