using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;


namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("PresentationGroup,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(PresentationGroupSearch))]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("PR")]
	public class PresentationGroupSearch : AssessmentMaintenanceBasePage
	{
		private PresentationGroupCollection presentationGroups;
		private PresentationGroup presentationGroup;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPresentationGroupText;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PresentationGroupText;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPresentationGroupText;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActiveWithAll;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContentOwnerID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ContentOwnerID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContentOwnerID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected Infragistics.WebUI.UltraWebListbar.UltraWebListbar WebListBar1;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.NewSearch();		// Use such a method for search pages
			}
			else
			{
				// always load all server side objects from the cache
				//presentationGroups = (PresentationGroupCollection)this.LoadObject(typeof(PresentationGroupCollection));	// This would reload from cache
				// searchers must cache and read from a different key than the class name
				presentationGroup = (PresentationGroup)this.LoadObject("PresentationGroup");
			}

		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("PresentationGroupSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.grid.DblClick += new ClickEventHandler(grid_DblClick);
			this.grid.ClickCellButton += new ClickCellButtonEventHandler(grid_ClickCellButton);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
				toolbar.AddButton(OrgMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.Cancel);
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewSearch();
		}

		// Handler for 'AddNew' button
		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PresentationGroupForm.Redirect(null);
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PresentationGroupCollection PresentationGroups
		{
			get { return presentationGroups; }
			set
			{
				presentationGroups = value;
				try
				{
					grid.KeepCollectionIndices = false;  // update given grid from the collection
					grid.UpdateFromCollection(presentationGroups);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject(typeof(PresentationGroupCollection), presentationGroups);  // cache object using the caching method declared on the page
			}
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = grid.GetPKFromCellEvent(e);

			switch (e.Cell.Key)
			{
				case "Edit":
					try
					{
						if (pk != null)
						PresentationGroupForm.Redirect((int)pk[0]);
					}
					catch(Exception ex)
					{
						this.RaisePageException(ex);
					}
					break;
			}
		}

		private void grid_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = grid.GetPKFromClickEvent(e);
				if (pk != null)
					PresentationGroupForm.Redirect((int)pk[0]);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}


		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			PresentationGroupCollection presentationGroups = new PresentationGroupCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				// do the search in the contact owners context
				presentationGroups.SearchPresentationGroups(-1, presentationGroup);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//contacts.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.PresentationGroups = presentationGroups;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PresentationGroup PresentationGroup
		{
			get { return presentationGroup; }
			set
			{
				presentationGroup = value;
				try
				{
					this.UpdateFromObject(pnlSearch.Controls, presentationGroup);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("PresentationGroup", presentationGroup);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearch()
		{
			bool result = true;
			PresentationGroup presentationGroup = new PresentationGroup(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				presentationGroup.SetMembersNull(true, true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PresentationGroup = presentationGroup;
			return result;
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	
				this.UpdateToObject(pnlSearch.Controls, presentationGroup);	// controls-to-object				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

	}
}
