using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Data.SqlTypes;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterSearch.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterTemplate,DataLayer")]
	[PageTitle("@LETTERPREVIEWPAGETITLE@")]
	public class LetterPreview : BasePage
	{
		private LetterTemplate letterTemplate;
		private BaseLetterQueue itemToBePreviewed;
		private LetterCustomText letterCustomText;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;

		protected TextControl txTextControl;

		private static string faxCoverDirName = ConfigHelper.GetConfigValue("FaxCoverDirName");
		int queueID = 0;

		private void Page_Load(object sender, System.EventArgs e)
		{
					
			if (!this.IsPostBack)
			{
				int queueID = int.Parse(Request.QueryString["QueueID"]);
				if (queueID > 0)
				{
					LetterQueueType queueType = (LetterQueueType)Enum.Parse(typeof(LetterQueueType), Request.QueryString["QueueType"], true);
					bool print = false;
					if (Request.QueryString["Print"] != null)
						print = bool.Parse(Request.QueryString["Print"]);

					itemToBePreviewed = LetterQueueClassFactory.CreateLetterQueueAndLoad(queueType, queueID);
					itemToBePreviewed.LoadLetterQueue(queueID);

					itemToBePreviewed.LoadLetterCustomText(true);
					this.LetterCustomText = itemToBePreviewed.LetterCustomText;
					this.CacheObject(typeof(LetterCustomText), letterCustomText);

					letterTemplate = new LetterTemplate(itemToBePreviewed.LetterTemplateID, itemToBePreviewed.Version);
					this.CacheObject(typeof(LetterTemplate), letterTemplate);
				}
				else
				{
					string filename = "";
					if (Request.QueryString["FileName"] != null)
						filename = (Request.QueryString["FileName"]);

					if (filename == "") 
					{
						this.SetPageMessage("Cannot locate file...", EnumPageMessageType.Error);
						return;
					}
					
					filename = faxCoverDirName + "\\" + filename;
					StreamReader sr = new StreamReader(new FileStream(filename,  FileMode.Open));
					string s = sr.ReadToEnd();
					sr.Close();
					this.txTextControl.Text = s;

					// no need to post back here
					txTextControl.TextControlMode = TextControlModeEnum.PrintPreview;
					return;
				}
			}
			else
			{
				itemToBePreviewed = (BaseLetterQueue)this.LoadObject("ItemToBePreviewed");  // load object from cache
				letterCustomText = (LetterCustomText)this.LoadObject(typeof(LetterCustomText));  // load object from cache
				letterTemplate = (LetterTemplate)this.LoadObject(typeof(LetterTemplate));  // load object from cache
			}

			txTextControl.TextControlMode = TextControlModeEnum.PrintPreview;

			this.txTextControl.MatrixTypeID = itemToBePreviewed.MatrixTypeID;
			this.txTextControl.FormTypeID = letterTemplate.FormTypeID;

			this.DirtyCheckEnabled = false;
		}

		
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			// May not need to merge all types of letters
			if (queueID > 0 || itemToBePreviewed != null)
				Merge();
		}



		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.itemToBePreviewed);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@CLOSE@", "Close", false, false).Item.TargetURL = "javascript:window.close();";
		}


		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("@PRINT@", "Print", true, false).Item.TargetURL = "javascript:mnu_menu_file_print();";
		}




		public bool Merge()
		{
			try
			{
				MergeContext mergeContext = new MergeContext(itemToBePreviewed.MatrixTypeID);
				mergeContext.LetterQueue = itemToBePreviewed;
				mergeContext.GetMergeFilterValuesFromQueue();

				if (itemToBePreviewed is LetterNonPrintedQueue || itemToBePreviewed is LetterPrintedQueue)
				{
					LetterPrintedQueue lpq = itemToBePreviewed as LetterPrintedQueue;
					LetterNonPrintedQueue lnpq = itemToBePreviewed as LetterNonPrintedQueue;

					bool isICMLetter = false;

					if (lpq != null)
						isICMLetter = (lpq.LetterMatrixTypeID > 0 && lpq.LetterMatrixTypeID == LetterMatrixTypeCollection.ActiveLetterMatrixTypes.Lookup_LetterMatrixTypeIDByCode("ICM"));
					else
						isICMLetter = (lnpq.LetterMatrixTypeID > 0 && lnpq.LetterMatrixTypeID == LetterMatrixTypeCollection.ActiveLetterMatrixTypes.Lookup_LetterMatrixTypeIDByCode("ICM"));
						
					if (isICMLetter)
					{
						isICMLetter = itemToBePreviewed.LetterTemplate.IntroLetterNumber > 0;
					}

					mergeContext.UseICMTriggers = isICMLetter;
				}

				txTextControl.DoMerge(mergeContext);

				this.letterCustomText.CustomText = txTextControl.Text;
				this.LetterCustomText = letterCustomText;

				return true;
			}
			catch (Exception ex)
			{
				//this.SetPageMessage("An error occured while merging...", EnumPageMessageType.Error); 
				this.RaisePageException(ex);
				return false;
			}
		}


		public void OnToolbarButtonClick_Merge(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			Merge();
		}
			

		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.Load += new System.EventHandler(this.Page_Load);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.AutoScroll = true;
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;

		}
		#endregion

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterCustomText LetterCustomText
		{
			get { return letterCustomText; }
			set
			{
				letterCustomText = value;
				try
				{
					txTextControl.Text = letterCustomText.CustomText;  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterCustomText), letterCustomText);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("This page is designed to be run as a popUp");
		}

	}
}
