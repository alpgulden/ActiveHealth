using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for InterventionTemplateSearch.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]	
	[MainDataClass("InterventionTemplate,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("InterventionTemplates")]
	public class InterventionTemplateSearch : AssessmentMaintenanceBasePage
	{
		private InterventionTemplateCollection interventionTemplates;
		private InterventionTemplate interventionTemplate;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGrid;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPOCGoalTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo POCGoalTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPOCGoalTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPOCDeficitTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo POCDeficitTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActiveWithAll;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInterventionTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo InterventionTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInterventionTypeID;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPOCDeficitTypeID;
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);

			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				NewData();
			else
			{
				interventionTemplate = (InterventionTemplate)this.LoadObject("InterventionTemplate");  // load object from cache
				//interventionTemplates = (InterventionTemplateCollection)this.LoadObject(typeof(InterventionTemplateCollection));  // load object from cache
			}
		}
		
		#region Data Objects
		#region Searcher Object
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public InterventionTemplate InterventionTemplate
		{
			get { return interventionTemplate; }
			set
			{
				interventionTemplate = value;
				try
				{
					this.UpdateFromObject(this.pnlSearch.Controls, interventionTemplate);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("InterventionTemplate", interventionTemplate);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSearch.Controls, interventionTemplate);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewData()
		{
			bool result = true;
			InterventionTemplate interventionTemplate = null; //new InterventionTemplate(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				interventionTemplate = new InterventionTemplate();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.InterventionTemplate = interventionTemplate;
			return result;
		}
		#endregion
		
		#region Result Collection
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public InterventionTemplateCollection InterventionTemplates
		{
			get { return interventionTemplates; }
			set
			{
				interventionTemplates = value;
				try
				{
					grid.KeepCollectionIndices = false;  // update given grid from the collection
					grid.UpdateFromCollection(interventionTemplates);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				//this.CacheObject(typeof(InterventionTemplateCollection), interventionTemplates);  // cache object using the caching method declared on the page
			}
		}
		
		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			//InterventionTemplateCollection interventionTemplates = new InterventionTemplateCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
					interventionTemplates = InterventionTemplateCollection.GetInterventionTemplatesFromSearch(InterventionTemplate);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//interventionTemplates.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.InterventionTemplates = interventionTemplates;
			return result;
		}
		#endregion
		#endregion
		
		#region UI Initialization and Events
		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
			{
				object[] pk = grid.GetPKFromCellEvent(e);
				InterventionTemplateForm.Redirect((int)pk[0]);
			}
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}
		
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Search":
					toolbar.AddButton(Messages.BaseMessages.MessageIDs.ADDNEWRECORD, "AddNewInterventionTemplate");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewInterventionTemplate(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			InterventionTemplate it = new InterventionTemplate(true);
			InterventionTemplateForm.Redirect(it);
		}
		#endregion
		
	}
}
