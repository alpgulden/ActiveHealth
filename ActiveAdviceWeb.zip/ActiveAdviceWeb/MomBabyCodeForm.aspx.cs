using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;
namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.DxPxMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("MomBabyCode,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu	
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@MOMBABYCODETITLE@")]
	public class MomBabyCodeForm : CodeBasePage
	{
		private MomBabyCode momBabyCode;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;	
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder6;
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder7;
		protected NetsoftUSA.WebForms.WindowOpener wo;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMomOrBaby;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit StartCode;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartCode;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDiagOrProc;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRangeDescription;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMomBabyCodeID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit EndCode;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndCode;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CodeType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCodeType;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit RangeDescription;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MomBabyCodeID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganizationSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMomOrBabyStr;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MomOrBabyStr;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDiagOrProcStr;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DiagOrProcStr;
		protected System.Web.UI.HtmlControls.HtmlTable tbl1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;

	
	
		


		private void Page_Load(object sender, System.EventArgs e)
		{			
			if (!this.IsPostBack)
			{							
				this.LoadData();			// Load data is the actual data loading method		
			}
			else
				momBabyCode = (MomBabyCode)this.LoadObject(typeof(MomBabyCode));  // load object from cache

		}





		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			this.SetPageToolbarItemVisible("Delete",!this.momBabyCode.IsNew);

			this.RenderClientFunctions(ContentPanel1.Controls, this.momBabyCode, "vldTerminationDate");
		}

		/// <summary>
		/// Redirect to current referral
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("MomBabyCodeForm.aspx");
		}

		public static void Redirect(int codeID)
		{
			if (codeID != 0)
			{
				MomBabyCode mbCode = new MomBabyCode();
				if (codeID > 0)		
					mbCode.Load(codeID);
				else if (codeID == -1)
					mbCode.IsNew = true;
				BasePage.PushParam("MomBabyCode", mbCode);
				BasePage.Redirect("MomBabyCodeForm.aspx");
			}
			else
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Invalid Code");
		}

		
		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;	
			// Get MomBabyCode from Parameter if not there throw an Exception
			this.momBabyCode = this.GetParam("MomBabyCode",null) as MomBabyCode;
			if (this.momBabyCode == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Invalid Context");
			// Bind controls on the page to object
			this.MomBabyCode = this.momBabyCode;
			if (this.momBabyCode.IsNew) // Select Diagnosis as default
				this.DiagOrProcStr.SelectedIndex = 0;
			
			return result;
		}

	
		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			if(this.ReadControlsForMomBabyCode()) 
			{
				try
				{
					this.momBabyCode.Save();
				}
				catch
				{
					return false;
				}
				
				this.MomBabyCode = this.momBabyCode; //refresh page with ID

				#region Clear CodeTable Cache
				// clear cache for DataClassCollection
				MomBabyCodeCollection col =new MomBabyCodeCollection();		
				
				string strType = col.GetType().Name;
				//clear cache for the current server
				NSGlobal.ClearCacheByType(strType);

				//clear cache for other servers 
				// calling WebRequest for every server but current and passing collection type
				// ...
				ClearOtherServersCache(strType, false);
				#endregion Clear CodeTable Cache

				return true;
			}
			else
				return false;		
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
 
		private void InitializeComponent()
		{   
			this.DiagOrProcStr.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.DiagOrProcStr_SelectedRowChanged);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}

		#endregion


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@SAVERECORD@", "Save").Visible = false;
			if (this.momBabyCode != null)
				toolbar.AddButton("@DELETE@","Delete").Visible = !this.momBabyCode.IsNew;
			toolbar.AddButton("@CANCEL@", "Cancel").Visible  = false;
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info,"@MOMBABYCODE@");
			}
			
		}
		public void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BasePage.Redirect("MomBabyCodeSearch.aspx");
			
		}
		public void OnToolbarButtonClick_Delete(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (DeleteData())
			{
				this.SetPageMessage("@DELETEDMSG@", EnumPageMessageType.Info,"@MOMBABYCODE@");
				// reset the form.
				this.MomBabyCode = this.momBabyCode;
			}
			
		}

		private bool DeleteData()
		{
			try
			{
				this.momBabyCode.Delete();
				this.momBabyCode = new MomBabyCode();
				this.momBabyCode.IsNew = true;
			}
			catch (SqlException sqlEx)
			{
				this.SetPageMessage("@DELETEDEPENDENCYMSGC@",EnumPageMessageType.Error);
				return false;
			}
			return true;
		}


	

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MomBabyCode MomBabyCode
		{
			get { return momBabyCode; }
			set
			{
				momBabyCode = value;
				try
				{
					this.UpdateFromObject(this.Controls, momBabyCode);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(MomBabyCode), momBabyCode);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForMomBabyCode()
		{
			try
			{	
				this.UpdateToObject(this.tbl1.Controls, momBabyCode);	// controls-to-object
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private void DiagOrProcStr_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			if (((string)DiagOrProcStr.Value) == "P")
				WindowOpenerForOrganizationSearch.NavigateURL = "ZippyCoderForm.aspx?CallBackFunction=setDiagnosticCode&DiagOrProc=P&SelectionMode=range&Type=@CodeType@&Code1=@StartCode@&Code2=@EndCode";
			else
				WindowOpenerForOrganizationSearch.NavigateURL = "ZippyCoderForm.aspx?CallBackFunction=setDiagnosticCode&DiagOrProc=D&SelectionMode=range&Type=@CodeType@&Code1=@StartCode@&Code2=@EndCode";

			// Clear code fields
			this.StartCode.Text = this.EndCode.Text	= this.CodeType.Text = "";
		}

	


	}
}
