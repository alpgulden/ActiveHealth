using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;


namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for EventLinkForm.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("CMS,DataLayer")]
	public class EventLinkForm : BasePage
	{
		private EventCollection events;
		private CMS cMS;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGrid;
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			
			this.grid.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.grid_RowBoundToDataObject);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				LoadDataForEvents();
			else
			{
				cMS = (CMS)this.LoadObject(typeof(CMS));	// This would reload from cache
				events = (EventCollection)this.LoadObject("PatientEvents");  // load object from cache
			}

		}

		#region Events
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EventCollection PatientEvents
		{
			get { return events; }
			set
			{
				events = value;
				try
				{
					grid.UpdateFromCollection(events);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("PatientEvents", events);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForEvents()
		{
			try
			{	//customize this method for this specific page
				grid.UpdateToCollection(events);	// grid-to-collection
				// other control-to-object methods if any
				//return this.IsValid;	// Return validation resultr
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForEvents()
		{
			bool result = true;
			EventCollection events = new EventCollection();
			try
			{	// use any load method here
				cMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;
				if (cMS == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a CMS");
				
				
				events = EventCollection.LoadAllEventsByPatientID(cMS.PatientId);
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//events.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.PatientEvents = events;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForEvents()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForEvents())
					return false;
				SynchronizeEvents();
				this.events.Save();
				this.cMS.LoadEvents(true);
				this.CacheObject("EventsLinkedToCMS", this.cMS.Events); // updates cache so parent page is in synch.
				this.CacheObject("isReloadCareResourceForm", true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region UI Initialization and Events
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@CLOSE@", "Close", false).Item.TargetURL = "javascript:window.opener.__doPostBack('','');window.close();";
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForEvents())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Events Linked ");
			}
		}

		private void grid_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			UltraGridCell cell = e.row.Cells.FromKey("IsLinked");
			if (cell != null)
			{
				cell.Value = (this.events[e.row.Index].CMSID == this.cMS.CMSID ? true : false);
			}
		}

		private void SynchronizeEvents()
		{
			UltraGridCell cell;
			foreach(UltraGridRow row in this.grid.Rows)
			{
				cell = row.Cells.FromKey("IsLinked");
				if((bool)cell.Value == true)
					this.events[row.Index].CMSID = this.cMS.CMSID;
				else
					this.events[row.Index].CMSID = 0;
			}
		}
		#endregion
	
	}
}
