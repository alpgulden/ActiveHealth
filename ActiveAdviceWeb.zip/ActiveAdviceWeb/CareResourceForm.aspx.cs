using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;


namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for CareResourceForm.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Event,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[PageTitle("@CARERESOURCEPAGETITLE@")]
	public class CareResourceForm : PatientBasePage
	{
		private EventCollection events;
		private CMS cMS;
		private Event eventObj;
		protected ClinicalReviewControl ClinicalReviewCtl;
		private Problem problem;
		private PatientCoverage patientCoverage;
		protected ProviderSelect RefToSelect;
		private Patient patient;
	
		private ClinicalReviewDecision clinicalReviewDecision;
		private ClinicalReviewRequest clinicalReviewRequest;
		private ClinicalReviewDecisionCollection clinicalReviewDecisions;
		private ClinicalReviewRequestCollection clinicalReviewRequests;
		private WindowOpener wo;

		//session wide flag which indicates whether this page should be reloaded. Set TRUE inside SaveDataForEvents() at EventLinkForm.aspx
		bool isReloadCareResourceForm = false; 
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNotifyDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit NotifyDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNotifyDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldResolution;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Resolution;
		protected NetsoftUSA.WebForms.OBFieldLabel lbResolution;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEventSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EventSourceID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrimaryProblemID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PrimaryProblemID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimaryProblemID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo StatusID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAltEventID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AltEventID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAltEventID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit EventID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlClinicalReview;
		protected NetsoftUSA.WebForms.OBRadioButtonBox referredToOption;
		protected NetsoftUSA.WebForms.OBLabel Oblabel12;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReferredTo;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridEvents;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddEvent;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDeleteEvent;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEventsGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSaveEvent;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCancelEvent;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldServiceTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ServiceTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbServiceTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDummySave;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDummySaveAndPrintLetters;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.referredToOption.SelectedIndexChanged += new System.EventHandler(this.referredToOption_SelectedIndexChanged);
			this.gridEvents.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridEvents_ClickCellButton);
			this.gridEvents.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridEvents_ColumnsBoundToDataClass);
			this.wbtnAddEvent.Click += new System.EventHandler(this.wbtnAddEvent_Click);
			this.wbtnSaveEvent.Click += new System.EventHandler(this.wbtnSaveEvent_Click);
			this.wbtnCancelEvent.Click += new System.EventHandler(this.wbtnCancelEvent_Click);

			wo = new WindowOpener();
				wo.ID = "EventLinkForm";
				wo.NavigateURL = "EventLinkForm.aspx";
				wo.registerClientScripts(this);

			this.wbtnDummySave.Click += new System.EventHandler(this.wbtnDummySave_Click);
			this.wbtnDummySaveAndPrintLetters.Click += new System.EventHandler(this.wbtnDummySaveAndPrintLetters_Click);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			ClinicalReviewCtl.CMSMode = true;		// Notify the clinical review control to work in CMS mode.
				
			ReferredToEvaluate(false/*initial binding, nothing to store*/);

			isReloadCareResourceForm = (bool)this.LoadObject("isReloadCareResourceForm", typeof(bool));
			
			if (isReloadCareResourceForm || !IsPostBack)
			{
				if(LoadDataForCMS())
					LoadDataForEvents();
				BindReferredToOption();
				this.CacheObject("isReloadCareResourceForm", false);
			}
			else
			{
				cMS = (CMS)this.LoadObject(typeof(CMS));  // load object from cache
				events = (EventCollection)this.LoadObject("EventsLinkedToCMS");  // load object from cache
				eventObj = (Event)this.LoadObject(typeof(Event));  // load object from cache

				clinicalReviewRequests = eventObj.ClinicalReviewRequests;
				clinicalReviewDecisions = (ClinicalReviewDecisionCollection)this.LoadObject(typeof(ClinicalReviewDecisionCollection));  // load object from cache
				clinicalReviewRequest = (ClinicalReviewRequest)this.LoadObject(typeof(ClinicalReviewRequest));  // load object from cache
				clinicalReviewDecision = (ClinicalReviewDecision)this.LoadObject(typeof(ClinicalReviewDecision));  // load object from cache
				ClinicalReviewCtl.ReloadContext();
			}	
			problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
			patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
			patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
		}

		#region Event
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Event EventObj
		{
			get { return eventObj; }
			set
			{
				eventObj = value;
				eventObj.ParentPatient = (eventObj.ParentPatient == null ? CMS.Patient : eventObj.ParentPatient);
				
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, eventObj);  // update controls for the given control collection
					this.UpdateFromObject(this.pnlReferredTo.Controls, eventObj);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Event), eventObj);  // cache object using the caching method declared on the page
				ClinicalReviewCtl.ReloadContext();		// must be called after caching the context
				ClinicalReviewCtl.LoadDataForClinicalReviewRequests();
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForEventObj()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, eventObj);	// controls-to-object
				this.UpdateToObject(this.pnlReferredTo.Controls, eventObj);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForEventObj()
		{
			try
			{	// data from controls to object
				if(!this.ReadControlsForEventObj())
					return false;
				if(eventObj.ProviderID == 0 & eventObj.FacilityID == 0)
				{
					this.SetPageMessage("Provider or Facility must be set", EnumPageMessageType.AddError);
					return false;
				}

				ReferredToEvaluate(true/*we want to store value of ReferToCode*/);				
				if (this.eventObj.IsNew)
				{
					this.eventObj.Save(this.patientCoverage, problem);
					EventObjs.Add(this.eventObj);
				}
				else
					this.eventObj.Save();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		
		#endregion

		#region EventObjs
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EventCollection EventObjs
		{
			get { return events; }
			set
			{
				events = value;
				try
				{
					this.gridEvents.UpdateFromCollection(events);  // update given grid from the collection
					// other object-to-control methods if any
					this.SetEventGridView();
					if(events.Count > 0)
					{
						this.gridEvents.SelectedRowIndex = 0;
						this.EventObj = events[0];
					}
					else
						EventObj = new Event(this.cMS.CMSID); 
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("EventsLinkedToCMS", events);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForEvents()
		{
			bool result = true;
			EventCollection events = new EventCollection();
			try
			{	// use any load method here
				CMS.LoadEvents(false);
				events = CMS.Events;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//events.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.EventObjs = events;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForEvents()
		{
			try
			{	
				//FORK 1.1
				// Added by Alp Gulden 01/18/06
				// Check if save button clicked for Clinical Review
				// Call saveitem button code from request or decision.

				//get latest request values
				if(!ClinicalReviewCtl.ReadControlsForClinicalReviewRequest())
					return false;
				// check if request update or inserted
				if(ClinicalReviewCtl.ClinicalReviewRequest!=null && ClinicalReviewCtl.ClinicalReviewRequest.IsNewOrDirty)
				{
					if (ClinicalReviewCtl.SaveDataForClinicalReviewRequest())
						ClinicalReviewCtl.ReloadContext();
					
					this.eventObj.Save();
					CMS.Events = EventObjs;	
					
					ClinicalReviewCtl.LoadDataForClinicalReviewRequests();
					
					ClinicalReviewCtl.NewClinicalReviewDecision();
					return true;
				}
				// check if decision update or inserted
				//get latest decision values
				if(!ClinicalReviewCtl.ReadControlsForClinicalReviewDecision())
					return false;
				if(ClinicalReviewCtl.ClinicalReviewDecision!=null && ClinicalReviewCtl.ClinicalReviewDecision.IsNewOrDirty)
				{
					ClinicalReviewDecision selecteDCRev = new ClinicalReviewDecision();
					selecteDCRev = ClinicalReviewCtl.ClinicalReviewDecision;
					if (ClinicalReviewCtl.SaveDataForClinicalReviewDecision())
						ClinicalReviewCtl.ReloadContext();

					this.eventObj.Save();
					CMS.Events = EventObjs;	

					if(ClinicalReviewCtl.GeneratePhysicianReview(selecteDCRev))
						ClinicalReviewCtl.ReloadContext();

					ClinicalReviewCtl.LoadDataForClinicalReviewRequests();
					return true;
				}
				//
							
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region CMS
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMS CMS
		{
			get { return cMS; }
			set
			{
				cMS = value;
				this.CacheObject(typeof(CMS), cMS);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForCMS()
		{
			bool result = true;
			CMS cMS = null;
			
			try
			{	// use any load method here
				cMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;
				if (cMS == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a CMS");

				patientCoverage = GetParamOrGetFromCache("PatCov", typeof(PatientCoverage)) as PatientCoverage;
				if (patientCoverage == null)	
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-subscriber-coverage");
				
				problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
				if (problem == null)	
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");					

				this.CacheObject(typeof(PatientCoverage), patientCoverage);
				this.CacheObject(typeof(Problem), problem);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//cMS.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CMS = cMS;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(CMS cMS, PatientCoverage patCov, Problem problem)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CMS", cMS);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.Redirect("CareResourceForm.aspx");
		}
		#endregion

		#region UI Initialization and Events
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.cMS);
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "CRS_CareResource":
					toolbar.AddButton("@LINKEVENTS@", "LinkEvent").Item.TargetURL = "javascript:" + wo.getWindowOpenScript();
					break;
			}
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if(SaveDataForEvents())
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "Care Resource(s) ");
		}

		public new void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.RedirectToCMS();
		}

		private void Save()
		{
			bool isNew = this.eventObj.IsNew;
			if (SaveDataForEventObj())
			{
				if(isNew)
					this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "Care Resource ");
				LoadDataForEvents();
				EventObjs = EventObjs;
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			bool isNew = this.eventObj.IsNew;
			
			this.SetERCTabVisibilities();
			SetPageTabItemActive(TargetTabKey);

			if(this.pnlDetails.Visible)
				this.pnlClinicalReview.Visible = false;
			else
				this.pnlClinicalReview.Visible = (this.gridEvents.Rows.Count > 0 ? true : false);
			this.PrimaryProblemID.Visible = !isNew; this.vldPrimaryProblemID.Visible = !isNew; this.lbPrimaryProblemID.Visible = !isNew;		
			this.RenderClientFunctions(this.pnlDetails.Controls, this.eventObj, "DateValidation");

			//FORK 1.1
			// added by alp gulden 1/26/06
			// popup appears only when decision save to generate letter

			bool requestDecisionVisible = this.ClinicalReviewCtl.ClinicalReviewRequest != null 
					|| this.ClinicalReviewCtl.ClinicalReviewDecision != null; // determines visibility of ClinicalReviewCtl
			bool isSaveEnabled = ((this.pnlDetails.Visible || this.pnlReferredTo.Visible || requestDecisionVisible) ? false : true);
//			this.SetPageToolbarItemEnabled("Save", isSaveEnabled);
			this.SetPageTabToolbarItemVisible("LinkEvent", isSaveEnabled);

			if(ClinicalReviewCtl.ClinicalReviewDecision!=null && ClinicalReviewCtl.ClinicalReviewDecision.IsNewOrDirty)
				this.SetPageToolbarItemTargetURL("Save", "javascript:AskForLetterGenAndSave();");
				
			this.RegisterClientScriptBlock("AskForLetterGenAndSave", @"
			<script language=""javascript"">
			function AskForLetterGenAndSave()
			{
				ret = confirm(""Would you like to generate letters (if any) after the saving the decision?"");
				if (ret)
					GetElem('" + this.wbtnDummySaveAndPrintLetters.ClientID + @"').click();
				else
					GetElem('" + this.wbtnDummySave.ClientID + @"').click();
			}
			</script>
			");
			//
		}

		private void ReferredToEvaluate(bool storeValue)
		{
			// RefTo select
			int selection;
			if(this.referredToOption.SelectedItem == null)
				selection = 0;
			else
				selection = int.Parse(this.referredToOption.SelectedItem.Value);
			switch(selection)
			{
				case (int)EnumReferredToOption.Provider:
				{
					// Provider select
					if(storeValue)
						this.eventObj.ReferToCode = ReferToType.PROVIDER;
					else
						this.RefToSelect.RebindControls(typeof(Event), "@PROVIDER@", 
							ProviderSearcherType.Provider, null,
							"ProviderID", "ProviderLocationID", "ProviderSpecialtyID", "ProviderNetworkID", "ProviderNetworkStatus", "StartDate", true, true);
					break;
				}
				case (int)EnumReferredToOption.Facilities:
				{
					// Facility select
					if(storeValue)
						this.eventObj.ReferToCode = ReferToType.FACILITY;
					else
						this.RefToSelect.RebindControls(typeof(Event), "@FACILITY@", 
							ProviderSearcherType.Facility, null,
							"FacilityID", "FacilityLocationID", "FacilityTypeID", "FacilityNetworkID", "FacilityNetworkStatus", "StartDate", true, true);
					break;
				}
				case (int)EnumReferredToOption.GroupPractice:
				{
					if(storeValue)
						this.eventObj.ReferToCode = ReferToType.GROUPPRACTICE;
					else
						this.RefToSelect.RebindControls(typeof(Event), "@PROVIDERGROUPPRACTICE@", 
							ProviderSearcherType.GroupPractice, null,
							"ProviderGroupID", "ProviderGroupLocationID", "ProviderGroupTypeID", "ProviderGroupNetworkID", "ProviderGroupNetworkStatus");
					break;
				}
			}
		}

		private void BindReferredToOption()
		{
			referredToOption.Items.Clear();
			referredToOption.Items.Add(new ListItem("Provider",((int)EnumReferredToOption.Provider).ToString()));
			referredToOption.Items.Add(new ListItem("Facilities",((int)EnumReferredToOption.Facilities).ToString()));
			referredToOption.Items.Add(new ListItem("GroupPractice", ((int)EnumReferredToOption.GroupPractice).ToString()));
			referredToOption.SelectedIndex = 0;
		}

		private void referredToOption_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EventObj = EventObj;
		}

		private void gridEvents_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridEvents.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			this.gridEvents.SelectedRowIndex = index;
			if (e.Cell.Key == "Edit")
				SetEventDetailView();
			else if (e.Cell.Key == "Select")
				SetEventGridView();

			EventObj = this.EventObjs[index];
		}

		private void wbtnAddEvent_Click(object sender, System.EventArgs e)
		{
			try
			{
				EventObj = CMS.CreateEventFromCMS(CMS);
				SetEventDetailView();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
		}

		private void gridEvents_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridEvents.AddButtonColumn("Select", "Select", 0);
		}

		private void SetEventDetailView()
		{
			this.pnlEventsGridHolder.Visible = false;
			this.pnlDetails.Visible = true;
			this.pnlReferredTo.Visible = true;
			this.pnlClinicalReview.Visible = false;
		}

		private void SetEventGridView()
		{
			this.pnlEventsGridHolder.Visible = true;
			this.pnlDetails.Visible = false;
			this.pnlReferredTo.Visible = false;
			this.pnlClinicalReview.Visible = true;
		}

		private void wbtnSaveEvent_Click(object sender, System.EventArgs e)
		{
			Save();
		}

		private void wbtnCancelEvent_Click(object sender, System.EventArgs e)
		{
			SetEventGridView();
		}

		public override void OnSetDirty()
		{
			CheckForDirty(this.cMS, this.events, this.clinicalReviewRequests, this.clinicalReviewDecisions);
		}

		//FORK 1.1
		// added by Alp Gulden 1/26/06
		// To generate leter we are using dummysave button
		private void wbtnDummySaveAndPrintLetters_Click(object sender, System.EventArgs e)
		{	
			ClinicalReviewDecision selecteDCRev = new ClinicalReviewDecision();
			ClinicalReviewCtl.ClinicalReviewDecision.GenerateLetter = true;
			selecteDCRev = ClinicalReviewCtl.ClinicalReviewDecision;
			if (SaveDataForEvents())
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "Care Resource(s) ");
			
			ClinicalReviewCtl.GenerateLetterClinicalReview(selecteDCRev);
			selecteDCRev= null;
		}

		private void wbtnDummySave_Click(object sender, System.EventArgs e)
		{
			if (SaveDataForEvents())
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "Care Resource(s) ");
		}


		#endregion		
	
	}
}
