using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for MeasurementSummaryForm.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.MEASUREMENTS)]
	
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]	
	[MainDataClass("PatientMeasurement,DataLayer")]
	[SelectedMainMenuItem("MPatient")]						//defines active menu item in main navigation
	[SelectedMenuItem("Measurements")]
	[PageTitle("@MEASUREMENTPAGETITLE@")]
	public class MeasurementSummaryForm : PatientBasePage
	{
		private PatientMeasurementFilter patientMeasurementFilter;
		private Patient patient;
		private PatientMeasurement patientMeasurement;
		private PatientMeasurementCollection patientMeasurements;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMeasurementDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MeasurementDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMeasurementDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMeasurementTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MeasurementTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMeasurementTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMeasurementValue;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MeasurementValue;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGraph;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Normals;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNormals;
		protected System.Web.UI.WebControls.Image imgGraph;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPickingListValue;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnClone;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCalculate;
		protected NetsoftUSA.WebForms.OBTextBox txbNotePad;
		protected NetsoftUSA.WebForms.OBFieldLabel lblNotePad;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFilter;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBButton wbtnFilter;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MeasurementTypeIDFilter;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMeasurementTypeIDFilter;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMeasurementTypeIDFilter;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnReset;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMeasurementDateFrom;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MeasurementDateFrom;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMeasurementDateFrom;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMeasurementDateTo;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MeasurementDateTo;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMeasurementDateTo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRangeFilter;
		protected NetsoftUSA.InfragisticsWeb.WebCombo RangeFilter;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRangeFilter;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPickingListValue;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PickingListValue;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnRemove;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMeasurementValue;


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.MeasurementTypeID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.MeasurementTypeID_SelectedRowChanged);
			this.wbtnClone.Click += new System.EventHandler(this.wbtnClone_Click);
			this.wbtnCalculate.Click += new System.EventHandler(this.wbtnCalculate_Click);
			this.wbtnFilter.Click += new System.EventHandler(this.wbtnFilter_Click);
			this.wbtnReset.Click += new System.EventHandler(this.wbtnReset_Click);

			this.Load += new System.EventHandler(this.Page_Load);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.wbtnRemove.Click += new System.EventHandler(this.wbtnRemove_Click);
			this.PrintablePage = true;
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
			{
				LoadData();
				NewPatientMeasurementFilter();
			}
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));
				patientMeasurements = (PatientMeasurementCollection)this.LoadObject(typeof(PatientMeasurementCollection));  // load object from cache
				patientMeasurement = (PatientMeasurement)this.LoadObject(typeof(PatientMeasurement));  // load object from cache
				patientMeasurementFilter = (PatientMeasurementFilter)this.LoadObject(typeof(PatientMeasurementFilter));  // load object from cache
			}	
		}

		private void LoadData()
		{
			patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
			this.CacheObject(typeof(Patient), patient);
			if(LoadDataForPatientMeasurements())
				PatientMeasurement = SetSelectedGridItem(grid, this.patientMeasurements, 0, true) as PatientMeasurement;
		}

		#region Data Objects
		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.Redirect("MeasurementSummaryForm.aspx");
		}

		#region PatientMeasurements
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientMeasurementCollection PatientMeasurements
		{
			get { return patientMeasurements; }
			set
			{
				patientMeasurements = value;
				try
				{
					grid.UpdateFromCollection(patientMeasurements);  // update given grid from the collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PatientMeasurementCollection), patientMeasurements);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForPatientMeasurements()
		{
			bool result = true;
			PatientMeasurementCollection patientMeasurements = new PatientMeasurementCollection();
			try
			{	// use any load method here
				patient.LoadPatientMeasurements(false);
				patientMeasurements = patient.PatientMeasurements;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			this.PatientMeasurements = patientMeasurements;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPatientMeasurements()
		{
			if(!ReadControls())
				return false;

			bool wasNew = false;
			if(PatientMeasurement.IsNew)
			{	// New Measurement - Adding
				PatientMeasurement.PatientID = patient.PatientId;
				PatientMeasurements.Add(PatientMeasurement);
				wasNew = true;
			}
			else
			{	// Existing Measurement - Updating
				PatientMeasurement.MarkDirty();
			}
			PatientMeasurement = PatientMeasurement;
			
			try
			{	// data from controls to object
				patientMeasurements.Save(); // update or insert to db
				NewPatientMeasurementFilter();
				PatientMeasurements = patientMeasurements;
				if(wasNew)
					grid.SelectedRowIndex = grid.Rows.Count - 1;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region PatientMeasurement
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientMeasurement PatientMeasurement
		{
			get { return patientMeasurement; }
			set
			{
				patientMeasurement = value;
				if(value == null)
					this.pnlDetails.Visible = false;
				else
				{
					this.pnlDetails.Visible = true;
					this.UpdateFromObject(this.pnlDetails.Controls, patientMeasurement);  // update controls for the given control collection
					try
					{
						bool isDummy = false;
					
						if(patientMeasurement.IsNew 
							& patientMeasurement.MeasurementTypeID == 0 
							& patientMeasurement.MeasurementTypeFFRM == null
							& patientMeasurement.MeasurementDate == DateTime.MinValue)
						{
							SetValueInputMode(false, true); //disable combo - enable numeric input
							isDummy = true; //New Measurement just been created and it is dummy
						}
						if(patientMeasurement.IsNew &	
							patientMeasurement.MeasurementValue == null)
						{	
							this.wbtnClone.Visible = this.wbtnRemove.Visible = false;
						}
						else
						{
							this.wbtnClone.Visible  = this.wbtnRemove.Visible = true;
										
							if(PatientMeasurement.MeasurementTypeFFRM == null)
							{
								if(!PatientMeasurement.MeasurementType.PickList)
									SetValueInputMode(true, false); //enables combo - disables numeric input
								else
								{
									SetValueInputMode(false, true); //disables combo - enables numeric input
									if(patientMeasurement.OutOfRange)
										this.SetPageMessage("Measurement Value is outside of normal range", EnumPageMessageType.AddWarning);
								}
							}
							else
								SetValueInputMode(false, true); //disables combo - enables numeric input
						}
			
						if(!isDummy)
						{	
							imgGraph.Visible = true;
							RenderGraph();
						}
						else
							imgGraph.Visible = false; // Graph can't be created for a dummy measurement
					
						ScrollToControl(this.pnlDetails);
						EvaluateCalculateButton();
					}
					catch(Exception ex)
					{
						this.RaisePageException(ex);  // notify the page about the error
					}
				}
				this.CacheObject(typeof(PatientMeasurement), patientMeasurement);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, patientMeasurement);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPatientMeasurement()
		{
			bool result = true;
			PatientMeasurement patientMeasurement = null;
			try
			{	// or use an initialization method here
				patientMeasurement = new PatientMeasurement(true);
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PatientMeasurement = patientMeasurement;
			return result;
		}
		#endregion

		#region PatientMeasurementFilter
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientMeasurementFilter PatientMeasurementFilter
		{
			get { return patientMeasurementFilter; }
			set
			{
				patientMeasurementFilter = value;
				try
				{
					MeasurementTypeCollection.AllMeasurementTypes.DisplayOnlyActive = false;
					this.UpdateFromObject(this.pnlFilter.Controls, patientMeasurementFilter);  // update controls for the given control collection
					MeasurementTypeCollection.AllMeasurementTypes.DisplayOnlyActive = true;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PatientMeasurementFilter), patientMeasurementFilter);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPatientMeasurementFilter()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlFilter.Controls, patientMeasurementFilter);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPatientMeasurementFilter()
		{
			bool result = true;
			PatientMeasurementFilter patientMeasurementFilter = null;
			try
			{	// or use an initialization method here
				patientMeasurementFilter = new PatientMeasurementFilter();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PatientMeasurementFilter = patientMeasurementFilter;
			if(PatientMeasurements != null)
				PatientMeasurements.FilterObject = null;
			return result;
		}

		private void FilterDataForPatientMeasurement(bool reset)
		{
			try
			{
				if(reset)
					NewPatientMeasurementFilter();
				else
				{
					if(!ReadControlsForPatientMeasurementFilter())
						NewPatientMeasurementFilter();	// If can't read controls for filter object show everything = reset

					PatientMeasurements.FilterObject = this.patientMeasurementFilter;
				}
				PatientMeasurements = PatientMeasurements;
				PatientMeasurement /*if null returned hide details panel*/ 
					= SetSelectedGridItem(grid, this.patientMeasurements, 0, false) as PatientMeasurement;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
		}
		#endregion
		#endregion

		#region UI initialization and events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			if(PatientMeasurement == null)
				return;

			//AddNewMeasurement control should not be visible in PrintPreviewMode
			this.SetPageTabToolbarItemVisible("AddNewMeasurement", !this.PrintPreviewMode);
			this.pnlFilter.Visible = !this.PrintPreviewMode;
			this.txbNotePad.Visible = this.lblNotePad.Visible = this.PatientMeasurement.NotePad != null;
			
			#region [SystemControlValues].FFRMMeasurementDescription
			if(SystemControlValue.GetInstance.FFRMMeasurementDescription == false)
				this.MeasurementTypeID.SourceMemberForFreeText = null;
			else
				this.MeasurementTypeID.SourceMemberForFreeText = "MeasurementTypeFFRM";
			#endregion

			this.RenderClientFunctions(this.pnlFilter.Controls, this.PatientMeasurementFilter, "onDateCheck");
			this.wbtnRemove.OnClickScript = "return confirm('Are you sure you want to delete this item?');";

			
			if(patientMeasurement.MeasurementType.Code == MeasurementType.BMI && this.MeasurementValue.Value.ToString() == "")
			{
				this.SetPageToolbarItemEnabled("Save", false /*can't save without Value, which in this case has to be calculated by pressing 'Calculate'*/);
				this.SetPageMessage("Please calculate result before this measurement can be saved", EnumPageMessageType.AddWarning);
			}
			else
				this.SetPageToolbarItemEnabled("Save", true);
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient);
		}

		private void RenderGraph()
		{
			if(PatientMeasurement.MeasurementTypeID > 0)
			{
				PatientMeasurements.SelectedMeasurementTypeID = PatientMeasurement.MeasurementTypeID;
				imgGraph.ImageUrl = "Chart.aspx";
			}
			else
				this.SetPageMessage("Can't draw graph for not system defined Measurement Type", EnumPageMessageType.Error);
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			
			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Measurements":
					toolbar.AddButton("@ADDMEASUREMENT@", "AddNewMeasurement");
					break;
			}
		}
		
		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForPatientMeasurements())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Measurements "); 
			}
		}																													   

		private void EvaluateCalculateButton()
		{
			if(patientMeasurement.MeasurementType.Code == MeasurementType.BMI)
			{
				this.wbtnCalculate.Visible = true;
				SetValueInputMode(false, true); //disables combo - enables numeric input
				this.MeasurementValue.ReadOnly = true;
				this.vldMeasurementValue.Visible = false;
			}
			else
			{
				this.wbtnCalculate.Visible = false;
				this.MeasurementValue.ReadOnly = false;
			}
		}

		private void SetValueInputMode(bool listMode, bool itemMode)
		{
			this.lbPickingListValue.Visible = this.PickingListValue.Visible = this.vldPickingListValue.Visible = listMode;

			this.lbMeasurementValue.Visible = this.MeasurementValue.Visible =
					this.vldMeasurementValue.Visible = this.lbNormals.Visible = this.Normals.Visible = itemMode;			
		}
		
		private void wbtnCalculate_Click(object sender, System.EventArgs e)
		{
			if(!ReadControls())
				return;
			CalculateBMI();
		}

		private void CalculateBMI()
		{
			try
			{
				/// <summary>
				/// Sort Measurements Collection by Date DESC
				/// Get first pair of Weight and Height 
				/// calculate BMI based on these values
				/// </summary>
				
				double weight = 0, height = 0;
				PatientMeasurements.SortBy_MeasurementDate(false, true);
				foreach(PatientMeasurement pm in PatientMeasurements)
				{
					if(pm.MeasurementType.Code == MeasurementType.WT & !pm.IsMarkedForDeletion)
						weight = pm.MeasurementValueDouble;
					if(pm.MeasurementType.Code == MeasurementType.HT & !pm.IsMarkedForDeletion)
						height = pm.MeasurementValueDouble;
					if(weight > 0 & height > 0) 
						break;
				}
				if(weight == 0)
				{
					this.SetPageMessage("Weight Measurement is not set.", EnumPageMessageType.AddError);
					return;
				}
				if(height == 0)
				{
					this.SetPageMessage("Height Measurement is not set.", EnumPageMessageType.AddError);
					return;
				}
				double result = ( weight * 704 ) / ( height * height );
				//PatientMeasurement.MeasurementValue = result.ToString();
				PatientMeasurement.MeasurementValue = String.Format("{0:0.##}", result); 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);  // notify the page about the error
			}
			PatientMeasurement = PatientMeasurement;
		}

		private void MeasurementTypeID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			try
			{
				PatientMeasurement.MeasurementTypeID = (int)MeasurementTypeID.Value;
				this.UpdateFromObject(this.PickingListValue, patientMeasurement);  // update controls for the given control collection
				this.UpdateFromObject(this.txbNotePad, patientMeasurement);
				PatientMeasurement.MeasurementTypeFFRM = null;	
			}
			catch
			{
				PatientMeasurement.MeasurementTypeID = 0;
				PatientMeasurement.MeasurementTypeFFRM = this.MeasurementTypeID.Text;	
				PatientMeasurement.MeasurementValue = this.MeasurementValue.Text;
			}
			this.Normals.Text = PatientMeasurement.Normals;

			if(PatientMeasurement.MeasurementTypeFFRM == null && !PatientMeasurement.MeasurementType.PickList)
				SetValueInputMode(true, false); //enables combo - disables numeric input
			else
				SetValueInputMode(false, true); //disables combo - enables numeric input
			EvaluateCalculateButton();
			ScrollToControl(this.pnlDetails);
		}

		private void wbtnClone_Click(object sender, System.EventArgs e)
		{
			if (ReadControls())
			{
				if(PatientMeasurement.MeasurementType.Active)
				{
					PatientMeasurement pm = new PatientMeasurement(true);
					pm.CopyMembersFrom(PatientMeasurement, true, true, false);
					pm.PatientMeasurementID = 0; // ID will be assigned by DB
					PatientMeasurement = pm;
					PatientMeasurements = PatientMeasurements;
					grid.SelectedRowIndex = grid.Rows.Count - 1;
				}
				else
					this.SetPageMessage("Selected Measurement Type is no longer Active", EnumPageMessageType.AddError);
			}
		}

		public void OnToolbarButtonClick_AddNewMeasurement(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewPatientMeasurement();
			grid.SelectedRowIndex = -1;
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
			{
				PatientMeasurement = patientMeasurements[index];
			}
		}

		private void wbtnFilter_Click(object sender, System.EventArgs e)
		{
			FilterDataForPatientMeasurement(false);
		}

		private void wbtnReset_Click(object sender, System.EventArgs e)
		{
			FilterDataForPatientMeasurement(true);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(this.patientMeasurements);
		}

		private void wbtnRemove_Click(object sender, System.EventArgs e)
		{
			PatientMeasurement.MarkDel();
			PatientMeasurements = patientMeasurements;
			PatientMeasurement  = SetSelectedGridItem(grid, this.patientMeasurements, 0, true) as PatientMeasurement;
		}
		#endregion	
	}
}
