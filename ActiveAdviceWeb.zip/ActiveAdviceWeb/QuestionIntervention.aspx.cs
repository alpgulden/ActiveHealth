using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]
	[MainDataClass("InterventionTemplate,DataLayer")]
	[SelectedMainMenuItem("MPatient")]
	[PageTitle("@QUESTIONINTERVENTIONPAGETITLE@")]
	public class QuestionIntervention : AssessmentBasePage
	{
		private Question question;
		private InterventionTemplateCollection iTemplates;
		private Hashtable webLinks; 
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlInterventions;
        
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlWebLinks;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected System.Web.UI.WebControls.Repeater rptWebLinks;
		Infragistics.WebUI.UltraWebToolbar.TBarButton CloseButton;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();
			}
			else
			{
				iTemplates = (InterventionTemplateCollection)this.LoadObject("InterventionTemplateCollectionInt");  // load object from cache
				webLinks = (Hashtable)this.LoadObject("WebLinksInt");
				question = (Question)this.LoadObject("QuestionInt");
			}

			grid.DisplayLayout.CellClickActionDefault = Infragistics.WebUI.UltraWebGrid.CellClickAction.Edit;
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("QuestionIntervention.aspx");
		}



		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			grid.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(grid_RowBoundToDataObject);
			rptWebLinks.ItemDataBound += new RepeaterItemEventHandler(rptWebLinks_ItemDataBound);
			
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			InterventionTemplateCollection iTemplates = null;
			webLinks = new Hashtable();
			try
			{	
				if (this.Request["QID"] != null)
				{
					int questionID = int.Parse(this.Request["QID"].ToString());
					question = assessmentContext.Questions.FindBy(questionID);

					iTemplates = this.assessmentContext.ITemplates;
					iTemplates.FilterQuestionID = question.QuestionID;

					ArrayList itls = null;
					InterventionTemplateLogic itl = null;
					foreach (InterventionTemplate iTemplate in iTemplates)
					{
						iTemplate.VisibleInList = false;

						if (iTemplate.QuestionID == question.QuestionID)
						{
							itls = this.assessmentContext.ITemplateLogics.FilterBy(iTemplate.InterventionTemplateID);
							if (itls != null && itls.Count > 0)
							{
								for (int index = 0; index < itls.Count; index++)
								{
									itl = itls[index] as InterventionTemplateLogic;
									if (itl.QuestionID == iTemplate.QuestionID && itl.InterventionTemplateID == iTemplate.InterventionTemplateID)
									{
										iTemplate.VisibleInList = this.assessmentContext.LogicEvaluator.EvaluateExpression(itl.LogicID);
										if (iTemplate.VisibleInList) 
										{
											iTemplate.LoadWebLinks(false);
											foreach (WebLink webLink in iTemplate.WebLinks)
											{
												if (webLink.Active && !webLinks.ContainsKey(webLink.WebLinkID))
												{
													webLinks.Add(webLink.WebLinkID, webLink);
												}
											}
											break; // If it's visible then there's no need to check other logics, in fact it would be a mistake
										}
									}
								}
							}
						}
					}
				}
				
				this.CacheObject("WebLinksInt", webLinks);
				this.CacheObject("QuestionInt", question);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//obj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.ITemplates = iTemplates;
			return result;
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public InterventionTemplateCollection ITemplates
		{
			get { return iTemplates; }
			set
			{
				iTemplates = value;
				try
				{
					grid.UpdateFromCollection(iTemplates);

					if (webLinks.Values.Count > 0)
					{
						this.rptWebLinks.DataSource = webLinks.Values;
						this.rptWebLinks.DataBind();
					}
					else
						pnlWebLinks.Visible = false;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject("InterventionTemplateCollectionInt", iTemplates);  // cache object using the caching method declared on the page
			}
		}


		
		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public void ReadControls()
		{
			try
			{	
				this.grid.UpdateToCollection(iTemplates);
				
				foreach(InterventionTemplate iTemplate in iTemplates)
				{
					if (iTemplate.IsDirty)
					{
						if (iTemplate.DoNowLater == 0)
						{
							this.assessmentContext.CMS.RemoveDGI(iTemplate);
						}
						else
						{
							POCIntervention intervention = this.assessmentContext.CMS.EnsureDGI(iTemplate);
							if (iTemplate.DoNowLater == 1)
								intervention.Fmt_CompletionID = ActivityCompletion.COMP;
							if (iTemplate.DoNowLater == 2)
								intervention.Fmt_CompletionID = ActivityCompletion.FUTU;
						}

						iTemplate.IsDirty = false;
					}
				}
								
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
		}



		private void grid_RowBoundToDataObject(object sender, RowBindingEventArgs e)
		{
			InterventionTemplate iTemplate = (InterventionTemplate)e.data;
			CMS cMS = this.assessmentContext.CMS;
			
			POCIntervention intervention = cMS.CheckForExistingDGI(iTemplate);

			if (intervention != null)
			{
				if(intervention.Fmt_CompletionID == ActivityCompletion.COMP)
					e.row.Cells[1].Value = 1;
				else if (intervention.Fmt_CompletionID == ActivityCompletion.FUTU)
					e.row.Cells[1].Value = 2;
			}

			if (intervention == null || intervention.IsNew)
			{
				e.row.Cells[1].AllowEditing = AllowEditing.Yes;
			}
			else
			{
				e.row.Cells[1].Text = ActivityCompletionCollection.ActiveActivityCompletions.Lookup_DescriptionByActivityCompletionID(intervention.CompletionID);
				e.row.Cells[1].AllowEditing = AllowEditing.No;
			}
						   
		}


		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			
			toolbar.AddButton("@OK@", "Save");
			toolbar.AddButton("@CLOSE@", "Close");
		}


		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.SetPageToolbarItemTargetURL("Close", "javascript:window.close();");
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				//this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@INTERVENTIONS@");

				this.Page.RegisterClientScriptBlock("closeOnLoad", "<script language='Javascript'> window.opener.__doPostBack('','');window.close(); </script>");
			}
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				this.ReadControls();
	
				this.assessmentContext.ITemplates = iTemplates;
				this.AssessmentContext = assessmentContext;

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}



		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(question);
		}

		private void rptWebLinks_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (e.Item.DataItem != null)
			{
				WebLink webLink = (WebLink)e.Item.DataItem;
				HyperLink link = (HyperLink)e.Item.FindControl("lnkWebLink");
				link.Text = webLink.Description;
				link.NavigateUrl = webLink.Address;	
				link.Target = "_blank";
			}
		}
	}
}
