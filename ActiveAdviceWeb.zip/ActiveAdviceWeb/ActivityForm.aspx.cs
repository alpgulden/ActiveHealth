using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// This page handles data entry for an Activity.  A patient and a selected coverage must be 
	/// passed to this page.  When a new activity is created, the plan of the pat-subs-coverage is used.
	/// 
	/// The Active Advice System utilizes Activities to allow users to schedule and assign tasks to users or teams. 
	/// Activities are used to track the status of work assignments and to record the time used to complete them. 
	/// The information captured by an activity can be used to provide billing information to clients.
	/// Activities organized in Work Lists are utilized by Users to structure their daily workflow. The Activity 
	/// provides a method of encapsulating a unit of work, and can be used to track the billable time expended on a task.
	/// Activities can be created manually by Users, automatically by the System in response to stimuli, or copied from 
	/// Interventions (see Plan of Care, section 1.26).
	/// Examples of how Activities are used within the Active Advice System
	/// 	�	Intake Staff assigning work to the Utilization Review (UR) Staff personnel
	/// 	�	UR staff personnel scheduling future tasks
	/// 	�	Case Management personnel copying an Intervention as a future task to follow up patient care
	/// Activities are used principally to track issues relating to a patient�s course of care. 
	/// An important attribute of an Activity is its Due Date. The Due Date can be used to schedule an Activity for 
	/// work at a future time; this feature is frequently used in the existing Active Advice system. 
	/// 
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ACTIVITIES),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.WORKLISTS )]
	
	[MainLanguageClass("ActiveAdvice.Messages.ActivityMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Activity,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("Details")]						//define the active menu item in side menu
	[SelectedMainMenuItem("MActivities")]						//defines active menu item in main navigation
	[PageTitle("@ACTIVITIESPAGETITLE@")]
	public class ActivityForm : PatientBasePage
	{
		private EnumActivityAndNoteContext activityAndNoteContext;
		private Activity activity;
		private ActivitySummaryCollection activities;
		private Patient patient;
		private PatientCoverage patientCoverage;
		private Problem problem;
		private BaseForEventCMSReferral erc;			// any one of these:  Event, CMS, Referral
		private PRRequest pRRequest;
		private PRReview pRReview;
		private PRProviderDecision pRProviderDecision;
		private ReferralDetail referralDetail;
		private EnumActivityContext ctx;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel RecordDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrimaryType;
		protected NetsoftUSA.WebForms.OBComboBox PrimaryType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimaryType;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityTypeID;
		protected NetsoftUSA.WebForms.OBComboBox ActivityTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ActivityDescription;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DueDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityPriority;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityPriority;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityPriority;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCompletion;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityCompletionID;
		protected NetsoftUSA.WebForms.OBComboBox ActivityCompletionID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityCompletionID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivitySubtypeID;
		protected NetsoftUSA.WebForms.OBComboBox ActivitySubtypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivitySubtypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompletionNote;
		protected NetsoftUSA.WebForms.OBValidator vldCompletionNote;
		protected NetsoftUSA.WebForms.OBTextBox CompletionNote;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityAmount;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityAmount;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ActivityAmount;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldManagementServiceRate;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ManagementServiceRate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbManagementServiceRate;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit TotalAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTotalAmount;
		protected NetsoftUSA.WebForms.OBCheckBox IsBillable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIsBillable;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;

		protected TeamUserSelect TeamUserSelect1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralID;
		protected NetsoftUSA.WebForms.OBComboBox ReferralID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferralID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProblemId;
		protected NetsoftUSA.WebForms.OBComboBox ProblemId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProblemId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCMSID;
		protected NetsoftUSA.WebForms.OBComboBox CMSID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEventID;
		protected NetsoftUSA.WebForms.OBComboBox EventID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldManagementServiceItemID;
		protected NetsoftUSA.WebForms.OBComboBox ManagementServiceItemID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbManagementServiceItemID;
		protected System.Web.UI.HtmlControls.HtmlTable tblMgmtSvc2;
		protected System.Web.UI.HtmlControls.HtmlTable tblMgmtSvc1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fmt_ConversionUnitOfMeasureId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fmt_BaseUOMID;
		protected NetsoftUSA.InfragisticsWeb.WebButton butCalculate;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ActivityID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityID;
		protected NetsoftUSA.WebForms.SimpleRecordNavigator nav;
		protected NetsoftUSA.WebForms.OBLabel lbSearchStats;
		protected UserSelect UserSelect1;
		int maxRows = 100;	

		private void Page_Load(object sender, System.EventArgs e)
		{
			// always 
			activities = (ActivitySummaryCollection)this.LoadObject(typeof(ActivitySummaryCollection));
			if (activities != null)
				this.nav.Pager = activities.Pager;

			this.TeamUserSelect1.RebindControls(typeof(Activity), "AssignedTeamID", "AssignedUserID");
			this.UserSelect1.RebindControls(typeof(Activity), "CompletedByUserID"); 

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadDataForActivity();			// Use load data method for data entry forms
			}
			else
			{
				activityAndNoteContext = (EnumActivityAndNoteContext)this.LoadObject("ActivityAndNoteContext");
				activity = (Activity)this.LoadObject(typeof(Activity));  // load object from cache
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache
				pRRequest = (PRRequest)this.LoadObject(typeof(PRRequest));
				pRReview = (PRReview)this.LoadObject(typeof(PRReview));
				pRProviderDecision = (PRProviderDecision)this.LoadObject(typeof(PRProviderDecision));
				referralDetail = (ReferralDetail)this.LoadObject(typeof(ReferralDetail));
			}
			//select main menu item
			if(ctx == ActiveAdvice.DataLayer.EnumActivityContext.Activity)
			{
				this.SelectedMainMenuItem = "MPatient";
			}
			else
				this.SelectedMainMenuItem = "MActivities";
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject(typeof(Activity), null);

			base.NavigateAway ();
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			this.PrimaryType.SelectedIndexChanged += new EventHandler(this.PrimaryType_SelectedRowChanged);
			this.ActivityCompletionID.SelectedIndexChanged += new EventHandler(ActivityCompletionID_SelectedRowChanged);
			this.ManagementServiceItemID.SelectedIndexChanged += new EventHandler(this.ManagementServiceItemID_SelectedRowChanged);
			this.ActivityTypeID.SelectedIndexChanged +=new EventHandler(ActivityTypeID_SelectedRowChanged);

			this.nav.NewPage +=new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(nav_NewPage);
			this.nav.NewRecordIndex +=new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(nav_NewRecordIndex);

		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butCalculate.Click += new System.EventHandler(this.butCalculate_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Details")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				toolbar.AddButton(PatientMessages.MessageIDs.PATIENT, "Patient");
				toolbar.AddButton(PatientMessages.MessageIDs.CLONE, "Clone");
				toolbar.AddButton(PatientMessages.MessageIDs.ADDNEWRECORD, "AddNew");
				toolbar.AddButton(CMSMessages.MessageIDs.INTERVENTION, "Intervention");
			}

			// Menu items to be displayed on all tabs
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewActivity();
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Activity Activity
		{
			get { return activity; }
			set
			{
				activity = value;
				try
				{
					this.UpdateFromObject(pnlDetails.Controls, activity);  // update controls for the given control collection
					this.UpdateFromObject(pnlCompletion.Controls, activity);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Activity), activity);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForActivity()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlDetails.Controls, activity);	// controls-to-object
				this.UpdateToObject(pnlCompletion.Controls, activity);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewActivity()
		{
			bool result = true;
			Activity activity = new Activity(this.patient, this.patientCoverage, null); // use a parameterized constructor which also initializes the data object
			try
			{	
				// or use an initialization method here
				if ((this.activityAndNoteContext & EnumActivityAndNoteContext.fProblem) != 0 && problem != null)
					activity.ProblemId = problem.ProblemID;
				if ((this.activityAndNoteContext & EnumActivityAndNoteContext.fERC) != 0 && erc != null)
				{
					switch (erc.ERCType)
					{
						case EnumERCType.Event:
							activity.EventID = erc.ID;
							break;
						case EnumERCType.CMS:
							activity.CMSID = erc.ID;
							break;
						case EnumERCType.Referral:
							activity.ReferralID = erc.ID;
							break;
					}
				}
				if ((this.activityAndNoteContext & EnumActivityAndNoteContext.fPRRequest) != 0 && pRRequest != null)
					activity.PRRequestID = pRRequest.PRRequestID;

				if ((this.activityAndNoteContext & EnumActivityAndNoteContext.fPRReview) != 0 && pRReview != null)
					activity.PRReviewID = pRReview.PRReviewID;

				if ((this.activityAndNoteContext & EnumActivityAndNoteContext.fPRProviderDecision) != 0 && pRProviderDecision != null)
					activity.PRProviderDecisionID = pRProviderDecision.PRProviderDecisionID;

				if ((this.activityAndNoteContext & EnumActivityAndNoteContext.fReferralDetail) != 0 && referralDetail != null)
					activity.ReferralDetailID = referralDetail.ReferralDetailID;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Activity = activity;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForActivity()
		{
			bool result = true;
			Activity activity = null;
			try
			{	// use any load method here

				ActivitySearcher activitySearcher = (ActivitySearcher)this.LoadObject(typeof(ActivitySearcher));  // load object from cache

				if (activitySearcher == null)
					this.ctx = EnumActivityContext.Activity;
				else
					this.ctx = activitySearcher.Context;
				if (ctx == EnumActivityContext.Activity && !AASecurityHelper.HasFullAccessRole(AASecurityHelper.ACTIVITIES)
					|| ctx == EnumActivityContext.WorkList && !AASecurityHelper.HasFullAccessRole(AASecurityHelper.WORKLISTS))
				{
					PageTab.Visible = false;
					PageToolbar.Visible = false;
					this.SetPageMessage("@NOTAUTHORIZED@", EnumPageMessageType.Error);
				}

				object oactivityAndNoteContext = this.GetParamOrGetFromCache("ActivityAndNoteContext", "ActivityAndNoteContext");
				if (oactivityAndNoteContext == null)
					throw new ActiveAdviceException(AAExceptionAction.None, "No ActivityAndNoteContext passed");
 
				activityAndNoteContext = (EnumActivityAndNoteContext)Convert.ToInt32(oactivityAndNoteContext);
				this.CacheObject("ActivityAndNoteContext", activityAndNoteContext);

				patient = (Patient)this.LoadObject(typeof(Patient));
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));
				problem = (Problem)this.LoadObject(typeof(Problem));
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));
				pRRequest = (PRRequest)this.LoadObject(typeof(PRRequest));
				pRReview = (PRReview)this.LoadObject(typeof(PRReview));
				pRProviderDecision = (PRProviderDecision)this.LoadObject(typeof(PRProviderDecision));
				referralDetail = (ReferralDetail)this.LoadObject(typeof(ReferralDetail));
				
				PageTab.SelectedTabKey = this.TargetTabKey;		// navigate to target tab.

				//patient = GetParam("Patient") as Patient;
				//if (patient == null)
				//	 throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");

				// get the passed patient subscriber coverage (link to patient)
				//patientCoverage = GetParam("PatCov") as PatientCoverage;
				//if (patientCoverage == null)	
				//	throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-coverage");

				//problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
				//erc = this.GetParamOrGetFromCache("ERC", typeof(BaseForEventCMSReferral)) as BaseForEventCMSReferral;

				// if event was not passed, create a new one
				activity = this.GetParamOrGetFromCache("Activity", typeof(Activity)) as Activity;
				if (activity == null)
					return NewActivity();
				else
				{
					// pull the activity related context data if not already passed.
					//if (patient == null)
					patient = activity.Patient;
					//if (patientCoverage == null)
					if (activity.PatientSubscriberLog != null)
						patientCoverage = activity.PatientSubscriberLog.PatientCoverage;
				}

				if (activities != null)
				{
					bool pageChanged = false;
					if (activities.Pager.GotoAbsoluteRecord(activity, ref pageChanged))
					{
						if (pageChanged)
							activities.LoadPagedGroup(activities.Pager.CurrentPageIndex);	// load current page
					}
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//activity.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			this.CacheObject(typeof(Patient), patient);
			this.CacheObject(typeof(PatientCoverage), patientCoverage);
			this.CacheObject(typeof(Problem), problem);
			this.CacheObject(typeof(BaseForEventCMSReferral), erc);

			this.Activity = activity;
			return result;
		}

		protected override object SaveViewState()
		{
			ViewState["ctx"] = (int)ctx;
			return base.SaveViewState ();
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
			ctx = (EnumActivityContext)ViewState["ctx"];
		}



		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, Activity activity)
		{
			BasePage.PushCurrentCallingPage();

			BasePage.PushParam("Activity", activity);
			BasePage.Redirect("ActivityForm.aspx");
		}

		public static void Redirect(Patient patient, int activityID)
		{
			Activity activity = new Activity(patient, false);
			if (!activity.Load(activityID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@ACTIVITY@");
			Redirect(patient, activity);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForActivity()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForActivity())
					return false;
				activity.CalculateTotals();

				// if the acitivity is still open, try to determine it's late or future
				if (activity.ActivityCompletionStatus == ActivityCompletionStatus.OPEN)
				{
					if (DateTime.Today > this.activity.DueDate)
						activity.ActivityCompletionCode = ActivityCompletion.LATE;
					if (DateTime.Today < this.activity.DueDate)
						activity.ActivityCompletionCode = ActivityCompletion.FUTU;
				}

				if (activity.IsNew)
				{
					activity.Save(this.patientCoverage); // update or insert to db 
					ActivitySearcher activitySearcher = (ActivitySearcher)this.LoadObject(typeof(ActivitySearcher));  // load object from cache
					activitySearcher.AssignedUserID = AASecurityHelper.GetUserId;
					if (activitySearcher != null)
					{
						activities.SearchActivities(maxRows, activitySearcher);			// loads the ids only
						// find the record again
						bool pageChanged = false;
						activities.Pager.GotoAbsoluteRecord(activity, ref pageChanged);
					}
				}
				else
					activity.Save();

				if(this.erc is CMS)
					(erc as CMS).POCDeficits = null;

				this.DumpAutoActivity(this.activity, true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}

			this.Activity = this.activity;		// refresh

			return true;
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForActivity())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@ACTIVITY@");
			}
		}

		public void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.CancelNavigateAway = true;
			ActivitiesForm.RedirectCurrentContext();
		}

		public void OnToolbarButtonClick_Patient(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PatientSummaryForm.Redirect(this.patient);
		}

		public void OnToolbarButtonClick_Intervention(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			DGIForm.Redirect(this.activity.InterventionID);
		}

		public void OnToolbarButtonClick_Clone(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			try
			{
				Activity newAct = this.activity.CreateCopy();
				this.Activity = newAct;
				this.SetPageMessage("@ACTIVITYCLONED@", EnumPageMessageType.Info);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.erc);
		}

		private void PrimaryType_SelectedRowChanged(object sender, EventArgs e)
		{
			this.UpdateToObject(PrimaryType, this.activity);
			activity.ActivityTypeID = 0;
			this.UpdateFromObject(ActivityTypeID, this.activity);
			activity.ActivitySubtypeID = 0;
			this.UpdateFromObject(ActivitySubtypeID, this.activity);
		}

		private void ActivityTypeID_SelectedRowChanged(object sender, EventArgs e)
		{
			this.UpdateToObject(ActivityTypeID, this.activity);
			activity.ActivitySubtypeID = 0;
				this.UpdateFromObject(ActivitySubtypeID, this.activity);
			int i = this.activity.PrimaryType;
			this.activity.SyncronizePrimaryTypeByActivityType();
				this.UpdateFromObject(PrimaryType, this.activity);
			if(i != this.activity.PrimaryType /*Primary Type was changed*/)
				this.UpdateFromObject(ActivityTypeID, this.activity/*Filter down drop down selection*/);
		}

		private void ActivityCompletionID_SelectedRowChanged(object sender, System.EventArgs e)
		{
			string oldCompletionCode = this.activity.ActivityCompletionCode;
			this.UpdateToObject(ActivityCompletionID, this.activity);
			if (this.activity.ActivityCompletionCode == ActivityCompletion.COMP)
			{
				if (oldCompletionCode != ActivityCompletion.COMP)
				{
					this.activity.SetCompletingUser();
					this.UpdateFromObject(UserSelect1.Controls, this.activity);
					this.UpdateFromObject(CompletionDate, this.activity);
				}
			}
			//this.UpdateFromObject(ActivityTypeID, this.activity);
		}

		// return true if this activity type has a sub-type mapped to it...
		protected bool RequireSubType()
		{
			ActivityType atype = new ActivityType();
			atype.Load(this.Activity.ActivityTypeID);
			ActivitySubTypeCollection ast = atype.GetActiveSubTypes();
			return (ast.Count > 0);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			bool completed = (this.activity.ActivityCompletionCode == ActivityCompletion.COMP);
			bool wasCompleted = (this.activity.ActivityCompletionCodeWhenLoaded == ActivityCompletion.COMP);
			bool justCompleted = !wasCompleted && completed;
			UserSelect1.Enabled = completed;


			// Only force a sub-type validation if the activity type has
			// related sub-types
			if (completed && RequireSubType())
			{
				vldActivitySubtypeID.ValidatorBehavior = EnumValidatorBehavior.ForceRequired;
				lbActivitySubtypeID.ForceRequiredMark = EnumForceRequiredMark.Required;
			}
			else
			{
				vldActivitySubtypeID.ValidatorBehavior = EnumValidatorBehavior.Default;
				lbActivitySubtypeID.ForceRequiredMark = EnumForceRequiredMark.Default;
			}
			// ActivitySubtypeID.Enabled = !completed;		// change required not enabled.

			//vldActivityAmount.Visible = completed && ActivitySubtypeID.Rows.Count > 0;
			vldActivityAmount.Visible = completed && ActivitySubtypeID.Items.Count > 0;
			CompletionDate.ReadOnly = !justCompleted;
			//ManagementServiceItemID.ReadOnly = !completed;
			ManagementServiceItemID.Enabled = completed;
			//CompletionNote.ReadOnly = !completed;

			if (this.ctx == EnumActivityContext.WorkList)
				this.PageTitle = "@WORKLISTPAGETITLE@";
			this.SetPageTabToolbarItemVisible("AddNew", (this.ctx == EnumActivityContext.Activity));

			ActivityAmount.ReadOnly = !justCompleted && activity.ManagementServiceItemID == 0;

			this.SetPageTabToolbarItemVisible("Patient", this.patient != null);
			this.SetPageTabToolbarItemVisible("Intervention", this.patient != null && this.activity.InterventionID > 0);

			this.RenderClientFunctions(pnlCompletion.Controls, this.activity, "OnCalculateCompletion");

			nav.Visible = lbSearchStats.Visible = activities != null; // && activities.Pager.TotalRecords != 0;

			if (activities != null)
			{
				int index = activities.Pager.CurrentAbsoluteRecordIndex;
				nav.LastButtonEnabled = nav.NextButtonEnabled = activities.Pager.HasRecords && index < activities.Pager.TotalRecords - 1;
				nav.FirstButtonEnabled = nav.PreviousButtonEnabled = activities.Pager.HasRecords && index > 0;
				if (activity.IsNew)
					lbSearchStats.TextToTranslate = String.Format("New Record of {0}", activities.Pager.TotalRecords);
				else
					lbSearchStats.TextToTranslate = String.Format("Record {0} of {1}", activities.Pager.CurrentAbsoluteRecordIndex + 1, activities.Pager.TotalRecords);
			}	
		}

		private void ManagementServiceItemID_SelectedRowChanged(object sender, EventArgs e)
		{
			// populate the management service item fields from the selected management service item
			this.UpdateToObject(this.tblMgmtSvc1.Controls, this.activity);
			this.UpdateToObject(this.tblMgmtSvc2.Controls, this.activity);
			ManagementServiceItem serviceItem = this.activity.PullManagementServiceItemFields();
			/*if (serviceItem != null)
				if (serviceItem.Billable)
					IsBillable.Enabled = true;
				else
					IsBillable.Enabled = false;
					*/
			this.UpdateFromObject(this.tblMgmtSvc1.Controls, this.activity);
			this.UpdateFromObject(this.tblMgmtSvc2.Controls, this.activity);
		}

		private void ActivityTypeID_ValueSet(object sender, EventArgs e)
		{
			// refresh the subtype too
			//this.UpdateFromObject(ActivitySubtypeID, this.activity);
		}

		private void PrimaryType_ValueSet(object sender, EventArgs e)
		{
			// refresh the activity too
			//this.UpdateFromObject(ActivityTypeID, this.activity);
		}

		private void butCalculate_Click(object sender, System.EventArgs e)
		{
			if (this.ReadControlsForActivity())
			{
				this.activity.CalculateTotals();		// calculate
				this.Activity = this.activity;		// refresh
			}
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();

			this.CheckForDirty(this.activity);
		}

		/*
		private void nav_ClickFirst(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			try
			{
				bool pageChanged = false;
				if (!activities.Pager.GotoFirstRecord(ref pageChanged))
					return;
				NavReloadActivity();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void nav_ClickLast(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			try
			{
				bool pageChanged = false;
				if (!activities.Pager.GotoLastRecord(ref pageChanged))
					return;
				NavReloadActivity();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void nav_ClickNext(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			try
			{
				bool pageChanged = false;
				if (!activities.Pager.GotoNextRecord(ref pageChanged))
					return;
				NavReloadActivity();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void nav_ClickPrevious(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			try
			{
				bool pageChanged = false;
				if (!activities.Pager.GotoPreviousRecord(ref pageChanged))
					return;
				NavReloadActivity();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}*/

		private void NavReloadActivity()
		{
			int activityID = Convert.ToInt32( activities.Pager.GetCurrentRecordPK() );
			Activity activity = new Activity(this.patient, this.patientCoverage, null);
			if (activity.Load(activityID))
				this.Activity = activity;
			else
			{
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@ACTIVITY@");
			}
		}

		private void nav_NewPage(object sender, SimpleRecordNavigatorButtonEventArgs e)
		{
			// we can load new page records here.
			// but since this is the detail form, we don't really need them.
		}

		private void nav_NewRecordIndex(object sender, SimpleRecordNavigatorButtonEventArgs e)
		{
			// load the activity
			NavReloadActivity();
		}
	}
}
