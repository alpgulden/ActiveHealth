using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for CaseManagementHistory.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.CLINICAL_MGMT_SERVICE),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.CARE_MANAGEMENT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.CMSMessages,DataLayer")]
	[MainDataClass("ActiveAdvice.DataLayer.CMS,DataLayer")]
	[SelectedMenuItem("Summary")]
	[SelectedMainMenuItem("MPatient")]
	[PageTitle("@CMSPAGETITLE@")]
	public class CaseManagementHistory : BasePage
	{
		private CMSStatusHistory cMSStatusHistoryFilter;
		private CMSStatusHistoryCollection cMSStatusHistories;
		private CMS parentCMS;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlHistory;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFilter;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCreateTimeFrom;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CreateTimeFrom;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCreateTimeFrom;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCreateTimeTo;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CreateTimeTo;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCreateTimeTo;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBButton wbtnReset;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBButton wbtnFilter;
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.wbtnReset.Click += new System.EventHandler(this.wbtnReset_Click);
			this.wbtnFilter.Click += new System.EventHandler(this.wbtnFilter_Click);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.DisplayPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;
			this.Load += new System.EventHandler(this.Page_Load);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;

		}
		#endregion
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				LoadDataForCMSStatusHistories();
				NewCMSStatusHistoryFilter();
			}
			else
			{
				parentCMS = (CMS)this.LoadObject(typeof(CMS));	// This would reload from cache
				cMSStatusHistories = (CMSStatusHistoryCollection)this.LoadObject(typeof(CMSStatusHistoryCollection));  // load object from cache
				cMSStatusHistoryFilter = (CMSStatusHistory)this.LoadObject("CMSStatusHistoryFilter");  // load object from cache
			}	
		}
		
		
		#region UI Initialization and Events
		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}
		
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.parentCMS.Patient, this.parentCMS);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@CLOSE@", "Close", false, false).Item.TargetURL = "javascript:window.close()";
		}

		public void OnToolbarButtonClick_Close(WebToolbar PageToolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BasePage.PushParam("CMS", cMSStatusHistories.ParentCMS);
			BasePage.Redirect("CaseManagementForm.aspx");
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.RenderClientFunctions(this.pnlFilter.Controls, this.cMSStatusHistoryFilter, "onDateCheck");
		}

		private void wbtnFilter_Click(object sender, System.EventArgs e)
		{
			FilterDataForCMSStatusHistories(false);
		}

		private void wbtnReset_Click(object sender, System.EventArgs e)
		{
			FilterDataForCMSStatusHistories(true);
		}
		#endregion
		
		#region CMSStatusHistories
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMSStatusHistoryCollection CMSStatusHistories
		{
			get { return cMSStatusHistories; }
			set
			{
				cMSStatusHistories = value;
				try
				{
					grid.UpdateFromCollection(cMSStatusHistories);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(CMSStatusHistoryCollection), cMSStatusHistories);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForCMSStatusHistories()
		{
			bool result = true;
			CMSStatusHistoryCollection cMSStatusHistories = new CMSStatusHistoryCollection();
			try
			{	// use any load method here
				// or pull from the parameter passed to this page via PushParam
				parentCMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;
				if (parentCMS != null)
				{
					parentCMS.LoadCMSStatusHistories(true);
					cMSStatusHistories = parentCMS.CMSStatusHistories;
				}
				else 
					throw new ActiveAdviceException("CMS Object is required to show its history!");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				cMSStatusHistories.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CMSStatusHistories = cMSStatusHistories;
			return result;
		}

		private void FilterDataForCMSStatusHistories(bool reset)
		{
			try
			{
				if(reset)
				{
					NewCMSStatusHistoryFilter();
					CMSStatusHistories.FilterObject = null;
				}
				else 
				{
					if(!ReadControlsForCMSStatusHistoryFilter())
						 NewCMSStatusHistoryFilter();	// If can't read controls for filter object show everything = reset
					
					CMSStatusHistories.FilterObject = this.cMSStatusHistoryFilter;
				}
				CMSStatusHistories = CMSStatusHistories;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
		}
		#endregion

		#region CMSStatusHistoryFilter
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMSStatusHistory CMSStatusHistoryFilter
		{
			get { return cMSStatusHistoryFilter; }
			set
			{
				cMSStatusHistoryFilter = value;
				try
				{
					this.UpdateFromObject(this.pnlFilter.Controls, cMSStatusHistoryFilter);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("CMSStatusHistoryFilter", cMSStatusHistoryFilter);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewCMSStatusHistoryFilter()
		{
			bool result = true;
			CMSStatusHistory cMSStatusHistoryFilter = null;
			try
			{	// or use an initialization method here
				cMSStatusHistoryFilter = new CMSStatusHistory();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.CMSStatusHistoryFilter = cMSStatusHistoryFilter;
			return result;
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForCMSStatusHistoryFilter()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlFilter.Controls, cMSStatusHistoryFilter);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}
		#endregion

	}
}
