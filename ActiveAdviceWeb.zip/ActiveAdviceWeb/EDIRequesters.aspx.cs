using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.BaseClassesInterfaces;
using System.Text;		// StringBuilder()
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.IMPORT_EXPORT_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("EDIRequester")]
	public class EDIRequestersForm : ImportExportBasePage
	{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel OblblEDIRequester;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRequesterName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit RequesterName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRequesterName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldIDQualifierID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo IDQualifierID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIDQualifierID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldIDCode;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit IDCode;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIDCode;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMAProviderID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MAProviderID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMAProviderID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutboxPath;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit OutboxPath;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutboxPath;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContactName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ContactName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactType1ID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContactphone1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Contactphone1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactphone1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactType2ID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContactphone2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Contactphone2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactphone2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactType3ID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContactphone3;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Contactphone3;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactphone3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContactType1ID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ContactType1ID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContactType2ID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ContactType2ID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContactType3ID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ContactType3ID;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEDIRequesterDetail;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEDIRequesterDetails;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridEDIRequesterDetails;
		protected NetsoftUSA.WebForms.WindowOpener wo;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;

		protected string callbackFunction;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
				LoadData();

			this.RebindControls();
		}

		protected void LoadData()
		{
			UpdateFromObject(this.pnlEDIRequesterDetail.Controls, this.EDIRequesterDetail);
			this.gridEDIRequesterDetails.UpdateFromCollection(this.EDIRequesterDetails);

			this.pnlEDIRequesterDetail.Visible	= false;
			this.pnlEDIRequesterDetails.Visible	= true;
		}

		protected void SaveData()
		{
			UpdateToObject(this.pnlEDIRequesterDetail.Controls, this.EDIRequesterDetail);
			UpdateToObject(this.pnlEDIRequesterDetails.Controls, this.EDIRequesterDetails);
			this.gridEDIRequesterDetails.UpdateToCollection(this.EDIRequesterDetails);
			if (pnlEDIRequesterDetail.Visible == true) // we are editing a single item
			{
				// We need to validate our arguments
				EDIRequesterDetail.Save();
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@EDIREQUESTER@");
				SetPageTabToolbarItemVisible("AddItem", false); // don't display

				// Invalidate our list and re-load since we have a change...
				EDIRequesterDetails = null;
				this.gridEDIRequesterDetails.UpdateFromCollection(this.EDIRequesterDetails);
			}
		}

		protected EDIRequestorDetail edirequesterdetail = null;
		protected EDIRequestorDetail EDIRequesterDetail
		{
			get
			{
				if (null == edirequesterdetail)
				{
					edirequesterdetail = (EDIRequestorDetail)LoadObject(typeof(EDIRequestorDetail), false);
					if (null == edirequesterdetail)
					{
						edirequesterdetail			= new EDIRequestorDetail();
						edirequesterdetail.Active	= true;
						CacheObject(typeof(EDIRequestorDetail), edirequesterdetail);
					}
				}
				return edirequesterdetail;
			}
			set
			{
				edirequesterdetail = value;
				CacheObject(typeof(EDIRequestorDetail), edirequesterdetail);
			}
		}

		protected EDIRequestorDetailCollection edirequesterdetails;
		protected EDIRequestorDetailCollection EDIRequesterDetails
		{
			get
			{
				if (null == edirequesterdetails)
					edirequesterdetails = (EDIRequestorDetailCollection)LoadObject(typeof(EDIRequestorDetailCollection), false);
				if (null == edirequesterdetails)
				{
					edirequesterdetails = new EDIRequestorDetailCollection();
					edirequesterdetails.SelectAllEDIRequesterDetailsByActive(-1, true);
					CacheObject(typeof(EDIRequestorDetailCollection), edirequesterdetails);
				}
				return edirequesterdetails;
			}

			set
			{
				edirequesterdetails = value;
				CacheObject(typeof(EDIRequestorDetailCollection), edirequesterdetails);
			}
		}
		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("EDIRequestersForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.gridEDIRequesterDetails.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridEDIRequesterDetails_DblClick);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVE@",   "Save");
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("@Add Item@", "AddItem");
		}
		public void OnToolbarButtonClick_AddItem(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.EDIRequesterDetail				= null; // make sure we create a new detail record
			this.pnlEDIRequesterDetail.Visible	= true;
			this.pnlEDIRequesterDetails.Visible	= false;
			this.EDIRequesterDetail.IsNew		= true;

			this.UpdateFromObject(this.pnlEDIRequesterDetail.Controls, this.EDIRequesterDetail);
			SetPageTabToolbarItemVisible("AddItem", false);
		}
		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick_Cancel(toolbar, button);
			if (this.pnlEDIRequesterDetail.Visible == true)
			{
				this.pnlEDIRequesterDetails.Visible = true;
				this.pnlEDIRequesterDetail.Visible	= false;
				SetPageTabToolbarItemVisible("AddItem",true);
				CacheObject(typeof(EDIRequestorDetail), null); // clear out the cache

				// Refresh the grid
				this.EDIRequesterDetails.SelectAllEDIRequesterDetailsByActive(-1, true);
				this.gridEDIRequesterDetails.UpdateFromCollection(EDIRequesterDetails);
			}
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SaveData();
		}

		private void gridEDIRequesterDetails_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = this.gridEDIRequesterDetails.GetPKFromClickEvent(e);
				if (pk != null)
				{
					EDIRequestorDetail ec = EDIRequesterDetails.FindBy(Convert.ToInt32(pk[0]));
					this.EDIRequesterDetail = ec;
					UpdateFromObject(this.pnlEDIRequesterDetail.Controls, this.EDIRequesterDetail);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}

			this.pnlEDIRequesterDetail.Visible	= true;
			this.pnlEDIRequesterDetails.Visible	= false;
			SetPageTabToolbarItemVisible("AddItem", false); // we are editing an item, don't display "AddItem" button
		}

		protected override void OnPreRender(EventArgs e)
		{
			string scriptKey = this.ID + "_SelectScript";
			StringBuilder s = new StringBuilder();
			s.Append("function " + callbackFunction + "(info) {\n");
			s.Append("\n");
			s.Append("  igedit_getById('" + this.MAProviderID.ClientID + "').setValue(info.ProviderID);\n");
			s.Append("}\n");
			s.Append("\n");
			this.RegisterOnLoadScript(scriptKey, s.ToString());
			base.OnPreRender (e);
		}
		public void RebindControls()
		{
			string navigateURLforPicker = "ProviderSearch.aspx";
			this.callbackFunction = "set" + "ProviderSelect"; //this.ID;

			wo.WindowName = "wo_" + "ProviderSelect";
			// Flag != 1, then Provider will have 'Pick' hyperlink
			wo.NavigateURL = navigateURLforPicker + "?Flag=0&CallbackFunction=" + this.callbackFunction;
		}

	}

}
