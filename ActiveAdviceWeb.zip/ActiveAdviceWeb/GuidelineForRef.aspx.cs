using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ActiveAdvice.DataLayer;
using NetsoftUSA.DataLayer;
using ActiveAdvice.Messages;
using NetsoftUSA.WebForms;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for GuidelineCategoryProduct.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.GUIDELINES)]
	
	[MainLanguageClass("ActiveAdvice.Messages.GuidelineMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Guideline,DataLayer")]
	[SelectedMainMenuItem("MGuidelines")]
	[PageTitle("@GUIDELINEREFFORMTITLE@")]
	public class GuidelineForRef:  BasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProduct1;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo5;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel5;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid5;
		protected System.Web.UI.WebControls.CheckBox chkProduct1;
		protected System.Web.UI.WebControls.CheckBox chkCategory1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuideline1;
	
	
		
		
		private GuidelineMaintenance guidelineMaintenance6;

		private GuidelineCollection guidelineCollectionPCG;
		private GuidelineCategoryCollection categoryCollectionPCG;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTip;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuidelineTip;
		private GuidelineProductCollection productCollectionPCG;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator5;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReference;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCodeDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CodeDescription;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCodeDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCodeValue;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CodeValue;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCodeValue;
		protected NetsoftUSA.WebForms.OBRadioButtonBox CodeType;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearcher;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuidelineCodes;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCodes;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGuidelines;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCodeType;
		private Guideline guideline;
		protected NetsoftUSA.WebForms.OBFieldLabel DxOrPx;
		protected NetsoftUSA.WebForms.OBRadioButtonBox DiagOrProc;
		private DxPxSearcher searcher;
		private BaseDxPxCollection diagProcs;
		private GuidelineCollection guidelinesForCode;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuidelineTip1;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid3;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid4;
		protected System.Web.UI.WebControls.CheckBox chkProduct;
		protected NetsoftUSA.WebForms.OBTextBox OBTextBox1;
		protected NetsoftUSA.WebForms.OBTextBox Tip;
		private Guideline guidelineForCode;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
				LoadData();
			else
			{
				guidelineMaintenance6 = this.LoadObject("GuidelineMaintenance6") as GuidelineMaintenance;
				guideline = this.LoadObject("Guideline") as Guideline;
				searcher = (DxPxSearcher)this.LoadObject("Searcher");  // load object from cache
				diagProcs = (BaseDxPxCollection)this.LoadObject(typeof(BaseDxPxCollection));  // load object from cache
				guidelineForCode = this.LoadObject("GuidelineForCode") as Guideline;
			}
		}

		private void LoadData()
		{
		
			//NewGuidelineMaintenance6();
			

			GuidelineProductCollection productCol1 = new GuidelineProductCollection();
			productCol1.LoadActiveGuidelineProducts(-1,true);
			ProductCollectionPCG = productCol1;

			GuidelineCategoryCollection categoryCol1 = new GuidelineCategoryCollection();
			categoryCol1.LoadActiveGuidelineCategories(-1,true);
			CategoryCollectionPCG = categoryCol1;

			GuidelineCollection guidelineCol1 = new GuidelineCollection();
			guidelineCol1.LoadActiveGuidelines(-1,true);
			GuidelineCollectionPCG = guidelineCol1;

			guideline = new Guideline();
			if (guidelineCol1.Count > 0)
				Guideline = guidelineCol1[0];
			else
				Guideline = null;
		
			//initiallly set diagnostic selected in search crieteria
			NewSearcher("D");

			NewGuidelineMaintenance6();
			}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.WebCombo5.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo5_SelectedRowChanged);
			this.chkProduct1.CheckedChanged += new System.EventHandler(this.chkProduct1_CheckedChanged);
			this.chkCategory1.CheckedChanged += new System.EventHandler(this.chkCategory1_CheckedChanged);
			this.Webgrid5.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.Webgrid5_ClickCellButton);
			this.Webgrid5.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.Webgrid5_ColumnsBoundToDataClass);
			this.grid.InitializeLayout += new Infragistics.WebUI.UltraWebGrid.InitializeLayoutEventHandler(this.grid_InitializeLayout);
			this.Webgrid3.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.Webgrid3_ClickCellButton);
			this.Webgrid3.InitializeLayout += new Infragistics.WebUI.UltraWebGrid.InitializeLayoutEventHandler(this.Webgrid3_InitializeLayout);
			this.Webgrid3.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.Webgrid3_ColumnsBoundToDataClass);
			this.Webgrid4.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.Webgrid4_ClickCellButton);
			this.Webgrid4.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.Webgrid4_ColumnsBoundToDataClass);
			this.DiagOrProc.SelectedIndexChanged += new System.EventHandler(this.DiagOrProc_SelectedIndexChanged);
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.gridCodes.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridCodes_ClickCellButton);
			this.gridCodes.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridCodes_ColumnsBoundToDataClass);
			this.gridGuidelines.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridGuidelines_ClickCellButton);
			this.gridGuidelines.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridGuidelines_ColumnsBoundToDataClass);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		
		
		

		private void UpdateCategoryCollectionPCG()
		{
			GuidelineCategoryCollection col = new GuidelineCategoryCollection();
			try
			{
			
				if(this.chkProduct.Checked)
				{
					int productID=this.Webgrid3.SelectedRowPKInt;
					if(productID == 0)
					{
						this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
						return;
					}
					else
					{
						col.LoadActiveGuidelineCategoriesForProduct(-1,productID,true);
					}
				}
				else
				{
					col.LoadActiveGuidelineCategories(-1,true);
				}
			
				this.CategoryCollectionPCG= col;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
			
		}

		private void WebCombo5_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			UpdateGuidelineCollectionPCG();
		}
		private void UpdateGuidelineCollectionPCG()
		{
			// GridNames are confusing below are the matches.
			// Product -> WebGrid3
			// SourceSet -> WebCombo5
			// Category  -> WebGrid4
			// SourceSetGrid -> WebGrid5
			// AssociateCodes -> grid
			GuidelineCollection col = new GuidelineCollection();
			try
			{
				this.UpdateToObject(this.pnlGuideline1.Controls,guidelineMaintenance6);
				if(guidelineMaintenance6.GuidelineSourceSetID != 0)
				{
					// Try updating category and product grids.
					// Update Categories filtered by Selected SourceSet
					GuidelineCategoryCollection guidelineCats = new GuidelineCategoryCollection();
					guidelineCats.LoadGuidelineCategoriesForSS(-1, guidelineMaintenance6.GuidelineSourceSetID);
					this.Webgrid4.UpdateFromCollection(guidelineCats);
					// Update Products filtered by Selected SourceSet
					GuidelineProductCollection guidelineProds = new GuidelineProductCollection();
					guidelineProds.LoadGuidelineProductsForSourceSet(-1, guidelineMaintenance6.GuidelineSourceSetID);
					this.Webgrid3.UpdateFromCollection(guidelineProds);

					
					
					
					if(this.chkProduct1.Checked && this.chkCategory1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadActiveGuidelinesForProductCategorySS(-1,productID,categoryID,guidelineMaintenance6.GuidelineSourceSetID,true);
						}
					}
					else if(this.chkProduct1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadActiveGuidelinesForProductSourceSet(-1,productID,guidelineMaintenance6.GuidelineSourceSetID,true);
					}
					else if(this.chkCategory1.Checked)
					{
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadActiveGuidelinesForCategorySourceSet(-1,categoryID,guidelineMaintenance6.GuidelineSourceSetID,true);
					}
					else
					{
						col.LoadActiveGuidelinesForSS(-1,true,guidelineMaintenance6.GuidelineSourceSetID);
					}
				}
				else
				{
					if(this.chkProduct1.Checked && this.chkCategory1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadActiveGuidelinesForProductCategory(-1,productID,categoryID,true);
						}
					}
					else if(this.chkProduct1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadActiveGuidelinesForProduct(-1,productID,true);
					}
					else if(this.chkCategory1.Checked)
					{
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadActiveGuidelinesForCategory(-1,categoryID,true);
					}
					else
					{
						col.LoadActiveGuidelines(-1,true);
					}
				}
				this.GuidelineCollectionPCG= col;
				if (this.GuidelineCollectionPCG != null && this.GuidelineCollectionPCG.Count >= 1)
					this.Guideline = this.GuidelineCollectionPCG[0];
				else
					this.Guideline = null;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
			
		}

		private void chkProduct1_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateGuidelineCollectionPCG();
		}

		private void chkProduct_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateCategoryCollectionPCG();
		}

		

		private void chkCategory1_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateGuidelineCollectionPCG();
		}

	
		public void NewGuidelineMaintenance6()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				maintenance.GuidelineSourceSetID = SystemControlValue.GetInstance.GuidelineSourceSetID;
				this.GuidelineMaintenance6 = maintenance;
				UpdateGuidelineCollectionPCG();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

	

		public ActiveAdvice.DataLayer.GuidelineCollection GuidelineCollectionPCG
		{
			get { return this.guidelineCollectionPCG; }
			set { this.guidelineCollectionPCG = value;
				try
				{
					this.Webgrid5.UpdateFromCollection(guidelineCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineCategoryCollection CategoryCollectionPCG
		{
			get { return this.categoryCollectionPCG; }
			set { this.categoryCollectionPCG = value;
				try
				{
					this.Webgrid4.UpdateFromCollection(categoryCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineProductCollection ProductCollectionPCG
		{
			get { return this.productCollectionPCG; }
			set { this.productCollectionPCG = value; 
				try
				{
					this.Webgrid3.UpdateFromCollection(productCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}



		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance6
		{
			get { return this.guidelineMaintenance6; }
			set { this.guidelineMaintenance6 = value;
				try
				{
					this.UpdateFromObject(this.pnlGuideline1.Controls,guidelineMaintenance6);
					this.CacheObject("GuidelineMaintenance6",guidelineMaintenance6);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public Guideline Guideline
		{
			get
			{
				return this.guideline;
			}
			set
			{
				try
				{
					guideline = value;
					if (guideline != null)
					{
						guideline.LoadGuidelineTips(false);
						guideline.LoadGuidelineCodes(false);
						guideline.LoadGuidelineIndicatorsActiveOnly(false);
						this.UpdateFromObject(this.pnlGuidelineTip.Controls,guideline.GuidelineTips[0]);
						grid.UpdateFromCollection(guideline.GuidelineCodes);
						this.Webgrid1.UpdateFromCollection(guideline.GuidelineIndicators);
					}
					else
					{
						grid.UpdateFromCollection(new GuidelineCodeCollection());
						this.UpdateFromObject(this.pnlGuidelineTip.Controls, null);
						this.Webgrid1.UpdateFromCollection(new GuidelineIndicatorCollection());
					}
					this.CacheObject("Guideline",guideline);
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}

			}
		}

		public DxPxSearcher Searcher
		{
			get { return searcher; }
			set
			{
				searcher = value;
				try
				{
					this.UpdateFromObject(pnlSearcher.Controls, searcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("Searcher", searcher);  // cache object using the caching method declared on the page
			}
		}

		public bool ReadControlsForSearcher()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlSearcher.Controls, searcher);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// </summary>
		public bool Search()
		{
			bool result = true;
			BaseDxPxCollection diagProcs = null;
			try
			{

				if (!this.ReadControlsForSearcher()) // Use appropriate read controls method to read the searcher object from controls 
					return false;

				if (this.searcher.CodeType == null)
				{
					this.SetPageMessage("@FIRSTSELECTCODETYPE@", EnumPageMessageType.Warning);
					return false;
				}

				diagProcs = DxPxCodeClassFactory.CreateDxPxCollection(searcher.CodeType);
//				diagProcs.Patient = this.patient;

				diagProcs.Search(this.searcher.CodeValue, this.searcher.DxOrPx, this.searcher.CodeDescription, true, this.GuidelineMaintenance6.GuidelineSourceSetID);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
			}
			this.DiagProcs = diagProcs;
			return result;
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearcher(string dxOrPx)
		{
			bool result = true;
			DxPxSearcher searcher = new DxPxSearcher(dxOrPx); // use a parameterized constructor which also initializes the data object
			searcher.CodeType = "ICD9";
			try
			{	// or use an initialization method here
			
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Searcher = searcher;
			return result;
		}

		private void DiagOrProc_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.NewSearcher(this.DiagOrProc.SelectedValue);
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		

		

		public BaseDxPxCollection DiagProcs
		{
			get { return diagProcs; }
			set
			{
				diagProcs = value;
				try
				{
					gridCodes.KeepCollectionIndices = false;  // update given grid from the collection
					gridCodes.UpdateFromCollection(diagProcs);  // update given grid from the collection
					// other object-to-control methods if any
					
					if(diagProcs!= null && diagProcs.Count >0)
					{
						GuidelineCollection col = new GuidelineCollection();
						col.LoadActiveGuidelinesForCode(-1,diagProcs[0].CodeType,diagProcs[0].CodeValue,diagProcs[0].DxOrPx,true);
						this.GuidelinesForCode = col;
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(BaseDxPxCollection), diagProcs);  // cache object using the caching method declared on the page
			}
		}

		public ActiveAdvice.DataLayer.GuidelineCollection GuidelinesForCode
		{
			get { return this.guidelinesForCode; }
			set { this.guidelinesForCode = value;
				try
				{
					this.gridGuidelines.UpdateFromCollection(guidelinesForCode);
					if(guidelinesForCode != null && guidelinesForCode.Count >0)
					{
						this.GuidelineForCode = guidelinesForCode[0];
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("GuidelinesForCode",guidelinesForCode);
			}
		}

		public ActiveAdvice.DataLayer.Guideline GuidelineForCode
		{
			get { return this.guidelineForCode; }
			set { this.guidelineForCode = value;
				try
				{
					guidelineForCode.LoadGuidelineIndicatorsActiveOnly(false);
					guidelineForCode.LoadGuidelineTips(false);
					this.UpdateFromObject(this.pnlGuidelineTip1.Controls,guidelineForCode.GuidelineTips[0]);
					this.Webgrid1.UpdateFromCollection(guidelineForCode.GuidelineIndicators);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("GuidelineForCode",guidelineForCode);
			}
		}

		public static void Redirect()
		{
			Redirect("GuidelineForRef.aspx");
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@CANCEL@","Cancel");
		}

		private void Webgrid5_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			Webgrid5.AddButtonColumn("Select", "@SELECT@", 0);
		}

		private void gridCodes_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridCodes.AddButtonColumn("Select", "@SELECT@", 0);
		}



		private void gridGuidelines_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridGuidelines.AddButtonColumn("Select", "@SELECT@", 0);
		}

		private void Webgrid5_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				object[] pk= Webgrid5.SelectedRowPK;
				int guidelineID = (int) pk[0];
				Guideline guideline = new Guideline();
				guideline.Load(guidelineID);
				this.Guideline = guideline;
			}
		}

		private void gridCodes_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				int index = gridCodes.GetColIndexFromCellEvent(e);
				GuidelineCollection col = new GuidelineCollection();
				col.LoadActiveGuidelinesForCode(-1,diagProcs[index].CodeType,this.diagProcs[index].CodeValue,diagProcs[index].DxOrPx,true);
				this.GuidelinesForCode = col;
			}
	
		}

		private void gridGuidelines_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				object[] pk= gridGuidelines.SelectedRowPK;
				int guidelineID = (int) pk[0];
				Guideline guideline = new Guideline();
				guideline.Load(guidelineID);
				this.GuidelineForCode = guideline;
			}
		}

		private void Webgrid3_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if(e.Cell.Key == "Select")
			{
				if(this.chkProduct.Checked)
					UpdateCategoryCollectionPCG();
				if(this.chkProduct1.Checked)
					UpdateGuidelineCollectionPCG();
			}
		}

		private void Webgrid4_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if(e.Cell.Key == "Select")
			{
				if(this.chkCategory1.Checked)
					UpdateGuidelineCollectionPCG();
			}
		}

		private void Webgrid3_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			Webgrid3.AddButtonColumn("Select","@SELECT@");
		}

		private void Webgrid4_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			Webgrid4.AddButtonColumn("Select","@SELECT@");
		}

		private void grid_InitializeLayout(object sender, Infragistics.WebUI.UltraWebGrid.LayoutEventArgs e)
		{
		
		}

		private void Webgrid3_InitializeLayout(object sender, Infragistics.WebUI.UltraWebGrid.LayoutEventArgs e)
		{
		
		}



	}
}
