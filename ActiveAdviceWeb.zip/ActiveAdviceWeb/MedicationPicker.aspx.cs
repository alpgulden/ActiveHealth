using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Medication,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[PageTitle("@MEDICATIONPICKERPAGETITLE@")]
	public class MedicationPicker : AssessmentBasePage
	{	
		private Question question;
		private MedicationCollection medications;
		private Medication medicationSearcher;
		private PatientMedication patientMedication;
		private PatientMedicationCollection patientMedications;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSelectionGrids;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSearchName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit SearchName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSearchName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSelectedMedicationNameTypeInt;
		protected NetsoftUSA.InfragisticsWeb.WebCombo SelectedMedicationNameTypeInt;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSelectedMedicationNameTypeInt;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMedication;
		protected NetsoftUSA.WebForms.OBButton btnAddMedication;
		protected NetsoftUSA.WebForms.OBButton btnRemoveMedication;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSearch;
		protected NetsoftUSA.WebForms.OBButton btnCancelMedication;
		protected NetsoftUSA.WebForms.OBButton btnOKMedication;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridAvailableMedications;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSelectedMedications;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridAvailableCodes;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSelectedCodes;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;

		
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo StatusID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusID;
	
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
				this.LoadData();
			else
			{
				medicationSearcher = (Medication)this.LoadObject("MedicationSearcher");
				patientMedication = (PatientMedication)this.LoadObject(typeof(PatientMedication));
				medications = (MedicationCollection)this.LoadObject(typeof(MedicationCollection));
				patientMedications = (PatientMedicationCollection)this.LoadObject(typeof(PatientMedicationCollection));
				question = (Question)this.LoadObject(typeof(Question));
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.btnAddMedication.Click += new System.EventHandler(this.btnAddMedication_Click);
			this.btnRemoveMedication.Click += new System.EventHandler(this.btnRemoveMedication_Click);
			this.btnOKMedication.Click += new System.EventHandler(this.btnOKMedication_Click);
			this.btnCancelMedication.Click += new System.EventHandler(this.btnCancelMedication_Click);
			this.AutoScroll = true;
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		
		public void LoadData()
		{
			if (this.Request["QID"] != null)
			{
				int questionID = int.Parse(this.Request["QID"].ToString());
				question = assessmentContext.Questions.FindBy(questionID);

				if (this.assessmentContext.CMS.Patient == null)
				{
					Patient patient= new Patient();
					patient.Load(this.assessmentContext.CMS.PatientId);
					this.assessmentContext.CMS.ParentPatient = patient;
				}
				this.assessmentContext.CMS.Patient.LoadPatientMedications(false);

				this.assessmentContext.CMS.Patient.PatientMedications.FilterQuestionID = questionID;
				this.assessmentContext.CMS.Patient.PatientMedications.FilterAssessmentGUID = this.assessmentContext.AssessmentGUID;
				this.PatientMedications = this.assessmentContext.CMS.Patient.PatientMedications;
				this.MedicationSearcher = new Medication();
			}
			else
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an assessment");

			this.CacheObject(typeof(Question), question);
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Medication MedicationSearcher
		{
			get { return medicationSearcher; }
			set
			{
				medicationSearcher = value;
				try
				{
					this.UpdateFromObject(this.pnlSearch.Controls, medicationSearcher);  // update controls for the given control collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("MedicationSearcher", medicationSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSearch.Controls, medicationSearcher);	// controls-to-object
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		public bool ReadControlsForPatientMedication()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlMedication.Controls, patientMedication);	// controls-to-object
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}


		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			MedicationCollection medications = new MedicationCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				medications.SearchMedications(medicationSearcher);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.Medications = medications;
			return result;
		}

		private void btnAddMedication_Click(object sender, System.EventArgs e)
		{
			patientMedications.IndexBy_AssessmentGUID_QuestionID_MedicationID.Rebuild();

			if (gridAvailableMedications.SelectedRowIndex >= 0)
			{
				Medication selectedMedication = medications[gridAvailableMedications.GetColIndexFromRowIndex(gridAvailableMedications.SelectedRowIndex)];

				PatientMedication patientMedication = null;
				patientMedication = patientMedications.FindBy(this.assessmentContext.AssessmentGUID, question.QuestionID, selectedMedication.MedicationId);
				if (patientMedication == null)
				{
					patientMedication = new PatientMedication(true);
					patientMedication.MedicationID = selectedMedication.MedicationId;
					patientMedication.AssessmentGUID = this.assessmentContext.AssessmentGUID;
					patientMedication.QuestionID = question.QuestionID;

					Medication newMedication = new Medication();
					newMedication.Load(selectedMedication.MedicationId);
					patientMedication.Medication = newMedication;
				
					this.PatientMedication = patientMedication;
				}
				else if (patientMedication.IsMarkedForDeletion)
				{
					this.PatientMedication = patientMedication;
				}
				else
				{
					this.SetPageMessage("This medication has already been selected", EnumPageMessageType.Warning);
					return;
				}

			}
			else
			{
				this.SetPageMessage("First select a medication", EnumPageMessageType.Warning);
			}
		}


		private void btnRemoveMedication_Click(object sender, System.EventArgs e)
		{
			int index = gridSelectedMedications.SelectedRowIndex;
			if ( index >= 0)
			{
				index = gridSelectedMedications.GetColIndexFromRowIndex(index);
				patientMedications[index].MarkDel();								
				patientMedications[index].IsDirty = true;

				this.PatientMedications = patientMedications;
			}
			else
			{
				this.SetPageMessage("First select a medication to remove from the list", EnumPageMessageType.Warning);
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientMedicationCollection PatientMedications
		{
			get { return patientMedications; }
			set
			{
				patientMedications = value;
				try
				{
					gridSelectedMedications.UpdateFromCollection(patientMedications);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// activate the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(PatientMedicationCollection), patientMedications);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MedicationCollection Medications
		{
			get { return medications; }
			set
			{
				medications = value;
				try
				{
					gridAvailableMedications.UpdateFromCollection(medications);  // update given grid from the collection
					// other object-to-control methods if any
					if(medications.Count >= MedicationCollection.MAXRECORDS)
						this.SetPageMessage("@BIGGERRESULTSET@", EnumPageMessageType.AddInfo, MedicationCollection.MAXRECORDS, Messages.PatientMessages.MessageIDs.MEDICATIONS);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// activate the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(MedicationCollection), medications);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientMedication PatientMedication
		{
			get { return patientMedication; }
			set
			{
				patientMedication = value;
				try
				{
					this.UpdateFromObject(this.pnlMedication.Controls, patientMedication);  // update given grid from the collection
					this.ScrollToControl(this.pnlMedication);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// activate the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(PatientMedication), patientMedication);  // cache object using the caching method declared on the page
			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@OK@", "OK");
			toolbar.AddButton("@CLOSE@", "Close");
		}


		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.pnlMedication.Visible = patientMedication != null;

			this.SetPageToolbarItemTargetURL("OK", "javascript:window.opener.__doPostBack('','');window.close();");
			this.SetPageToolbarItemTargetURL("Close", "javascript:window.opener.__doPostBack('','');window.close();");
		}

		public bool SaveDataForPatientMedication()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPatientMedication())
					return false;
				if (this.patientMedication.ParentPatientMedicationCollection == null)
					patientMedications.AddRecord(patientMedication);
				
				if (patientMedication.IsMarkedForDeletion)
				{
					patientMedication.IsMarkedForDeletion = false;
					patientMedication.IsDirty = true;
				}

				this.PatientMedications = patientMedications;
				gridSelectedMedications.UpdateFromCollection(patientMedications);
				this.PatientMedication = null;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void btnOKMedication_Click(object sender, System.EventArgs e)
		{
			SaveDataForPatientMedication();
		}

		private void btnCancelMedication_Click(object sender, System.EventArgs e)
		{
			this.PatientMedication = null;
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(question);
		}


	}
}
