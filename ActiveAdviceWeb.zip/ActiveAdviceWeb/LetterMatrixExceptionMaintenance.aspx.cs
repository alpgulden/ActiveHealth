using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterMatrixExceptionMaintenance.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterMatrixException,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("LetterMatrix")]
	[PageTitle("@LETTERMATRIXEXCEPTIONPAGETITLE@")]
	public class LetterMatrixExceptionMaintenance : LetterMaintenanceBasePage
	{
		private LetterMatrixException letterMatrixException;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEnrollmentID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EnrollmentID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEnrollmentID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PlanName;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForPlanID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PlanId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrganizationId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationId;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganization;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtOrganizationPath;
		protected System.Web.UI.WebControls.Label lblOrganizationPath;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				LoadData();
			else
				letterMatrixException = (LetterMatrixException)this.LoadObject(typeof(LetterMatrixException));  // load object from cache

		}

		#region LetterMatrixException
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterMatrixException LetterMatrixException
		{
			get { return letterMatrixException; }
			set
			{
				letterMatrixException = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, letterMatrixException);  // update controls for the given control collection
					// other object-to-control methods if any
					if(letterMatrixException.EnrollmentID == 0)
						this.EnrollmentID.SelectedRow = this.EnrollmentID.Rows[0];
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterMatrixException), letterMatrixException);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, letterMatrixException);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewData()
		{
			bool result = true;
			LetterMatrixException letterMatrixException = null; //new LetterMatrixException(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				letterMatrixException = new LetterMatrixException(true);
				
				letterMatrixException.MatrixID = LetterMatrixException.MatrixID;
				letterMatrixException.PlanName = "All";
				this.lblOrganizationPath.Text = "All";
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.LetterMatrixException = letterMatrixException;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			LetterMatrixException letterMatrixException = new LetterMatrixException();
			try
			{	// use any load method here
				letterMatrixException = GetParamOrGetFromCache("LetterMatrixException", typeof(LetterMatrixException)) as LetterMatrixException;
				if (letterMatrixException == null) 
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a LetterMatrixException ");
				if(letterMatrixException.OrganizationId > 0)
				{
					Organization o = new Organization();
					if (o.Load(letterMatrixException.OrganizationId))
						this.lblOrganizationPath.Text = CreateOrgPathHTML(null, o);
				}
				else
					this.lblOrganizationPath.Text = "All";
				if(letterMatrixException.PlanID > 0 )
				{
					Plan pl = new Plan();
					if(pl.Load(letterMatrixException.PlanID))
						//letterMatrixException.PlanName = pl.Name;	 
						this.PlanName.Text = pl.Name;
				}
				else
					letterMatrixException.PlanName = "All";	 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterMatrixException.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterMatrixException = letterMatrixException;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(LetterMatrixException letterMatrixException)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("LetterMatrixException", letterMatrixException);
			BasePage.Redirect("LetterMatrixExceptionMaintenance.aspx");

		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				letterMatrixException.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region UI Initialization and Events
		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "LetterMatrixException":
					toolbar.AddButton(Messages.BaseMessages.MessageIDs.ADDNEWRECORD, "AddNewLetterMatrixException");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewLetterMatrixException(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewData();
		}
		
		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "LetterMatrixException "); 
			}
		}
		
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.letterMatrixException);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty();
			this.CheckForDirty(letterMatrixException);
		}

		#endregion
	}
}
