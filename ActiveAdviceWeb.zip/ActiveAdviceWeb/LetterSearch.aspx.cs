using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;


namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterSearch.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterTemplate,DataLayer")]
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("CustomLetter")]
	[PageTitle("@LETTERSEARCHPAGETITLE@")]

	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.AD_HOC_LETTERS)]

	public class LetterSearch : PatientBasePage
	{
		private LetterTemplateCollection letterTemplates;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResults;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		private LetterTemplate letterTemplateSearcher;

		private Patient patient;
		private BaseForEventCMSReferral erc;
		private ReferralDetail referralDetail;
				
		public const string Forms = "Forms";
		public const string Envelopes = "Envelopes";
		protected NetsoftUSA.WebForms.OBRadioButtonBox LetterTemplateContext;
		protected NetsoftUSA.WebForms.OBRadioButtonBox MatrixTypeContext;
		public const string Standard = "Standard";

		public const string MatrixTypeEvent = "Event";
		public const string MatrixTypeReferral = "Referral";
		protected NetsoftUSA.WebForms.OBRadioButtonBox LetterTempleteContext;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;

		public enum PageModeEnum 
		{
			CMS,
			Event,
			Referral
		}

		private PageModeEnum pageMode;

		public PageModeEnum PageMode
		{
			get 
			{
				return pageMode;
			}
			set
			{
				pageMode = value;
			}
		}


		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
			{
				LoadData();
				SetPageMode();
				NewLetterTemplateSearcher();
				BindLetterTemplateContext();
				SearchForLetterTemplates();
			}
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache
				referralDetail = (ReferralDetail)this.LoadObject("ReferralDetail");
				letterTemplateSearcher = (LetterTemplate)this.LoadObject("LetterTemplateSearcher");  // load object from cache
				letterTemplates = (LetterTemplateCollection)this.LoadObject(typeof(LetterTemplateCollection));  // load object from cache
				SetPageMode();
			}

		}

		private void SetPageMode()
		{
			if ((erc as Event) != null) this.PageMode = PageModeEnum.Event;
			if ((erc as Referral) != null) this.PageMode = PageModeEnum.Referral;
			if ((erc as CMS) != null) this.PageMode = PageModeEnum.CMS;
		}


		private void LoadData()
		{
			patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
			this.CacheObject(typeof(Patient), patient);

			erc = GetParam("ERC") as BaseForEventCMSReferral;
			if (erc == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page after selecting an event, referral or CMS");

			referralDetail = GetParam("ReferralDetail") as ReferralDetail;
			this.CacheObject("ReferralDetail", referralDetail);
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, BaseForEventCMSReferral erc)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("ERC", erc);
			BasePage.Redirect("LetterSearch.aspx");
		}

		public static void Redirect(Patient patient, BaseForEventCMSReferral erc, ReferralDetail referralDetail)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("ERC", erc);
			BasePage.PushParam("ReferralDetail", referralDetail);
			BasePage.Redirect("LetterSearch.aspx");
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.LetterTemplateContext.SelectedIndexChanged += new System.EventHandler(LetterTemplateContext_SelectedIndexChanged);
			this.MatrixTypeContext.SelectedIndexChanged += new System.EventHandler(MatrixTypeContext_SelectedIndexChanged);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DirtyCheckEnabled = false;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterTemplate LetterTemplateSearcher
		{
			get { return letterTemplateSearcher; }
			set
			{
				letterTemplateSearcher = value;
				try
				{
					// this.UpdateFromObject(pnlSearch.Controls, letterTemplateSearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("LetterTemplateSearcher", letterTemplateSearcher);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewLetterTemplateSearcher()
		{
			bool result = true;
			LetterTemplate letterTemplateSearcher = null; //new LetterTemplate(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				letterTemplateSearcher = new LetterTemplate();
				letterTemplateSearcher.ActiveWithAll = 1; // Active
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.LetterTemplateSearcher = letterTemplateSearcher;
			return result;
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterTemplateCollection LetterTemplates
		{
			get { return letterTemplates; }
			set
			{
				letterTemplates = value;
				try
				{
					grid.UpdateFromCollection(letterTemplates);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterTemplateCollection), letterTemplates);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool SearchForLetterTemplates()
		{
			bool result = true;
			LetterTemplateCollection letterTemplates = new LetterTemplateCollection();
			try
			{
				letterTemplates.SearchCustomLetterTemplates(-1, letterTemplateSearcher);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterTemplates.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterTemplates = letterTemplates;
			return result;
		}




		private void BindLetterTemplateContext()
		{
			LetterTemplateContext.Items.Clear();
			LetterTemplateContext.Items.Add(new ListItem(LetterSearch.Forms, LetterSearch.Forms));
			LetterTemplateContext.Items.Add(new ListItem(LetterSearch.Envelopes, LetterSearch.Envelopes));

			if (PageMode == PageModeEnum.Event || PageMode == PageModeEnum.Referral)
				LetterTemplateContext.Items.Add(new ListItem(LetterSearch.Standard, LetterSearch.Standard));

			LetterTemplateContext.SelectedIndex = 0;
			letterTemplateSearcher.FormTypeID = LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_FormTypeIDByCode(LetterFormType.FORM);

            this.LetterTemplateSearcher = letterTemplateSearcher;

			BindMatrixTypeContext();
		}

		private void BindMatrixTypeContext()
		{
			if ((PageMode == PageModeEnum.Event || PageMode == PageModeEnum.Referral) &&
				(LetterTemplateContext.SelectedValue == LetterSearch.Forms || LetterTemplateContext.SelectedValue == LetterSearch.Envelopes))
			{
				MatrixTypeContext.Enabled = true;
				MatrixTypeContext.Items.Clear();
				MatrixTypeContext.Items.Add(new ListItem(LetterSearch.MatrixTypeEvent, LetterSearch.MatrixTypeEvent));
				MatrixTypeContext.Items.Add(new ListItem(LetterSearch.MatrixTypeReferral, LetterSearch.MatrixTypeReferral));
				
				if (PageMode == PageModeEnum.Event)
				{
					MatrixTypeContext.SelectedIndex = 0;
					letterTemplateSearcher.MatrixTypeID = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCode(MatrixType.EVENT_CLINICALREVIEW);
				}
				else if (PageMode == PageModeEnum.Referral)
				{
					MatrixTypeContext.SelectedIndex = 1;
					letterTemplateSearcher.MatrixTypeID = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCode(MatrixType.REFERRAL);
					
				}

				this.LetterTemplateSearcher = letterTemplateSearcher;
			}
			else if (PageMode == PageModeEnum.CMS)
			{
				MatrixTypeContext.Enabled = false;
				MatrixTypeContext.SelectedValue = null;
				//letterTemplateSearcher.MatrixTypeID = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCode(MatrixType.CASEMANAGEMENT);
				letterTemplateSearcher.MatrixTypeID = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCMSTypeID(((CMS)erc).CMSTypeID);
				
				// If this is a maternichek case, display both cms and maternichek items
				if (((CMS)erc).CMSTypeID == CMSTypeCollection.ActiveCMSTypes.Lookup_CMSTypeIDByCode(CMSType.MATERNICHEK))
					letterTemplateSearcher.MatrixTypeID2 = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCode(MatrixType.CASEMANAGEMENT);
			}
		}

		private void LetterTemplateContext_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			letterTemplateSearcher = new LetterTemplate();
			letterTemplateSearcher.ActiveWithAll = 1; // Active

			switch(LetterTemplateContext.SelectedValue)
			{
				case (LetterSearch.Forms):
					letterTemplateSearcher.FormTypeID = LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_FormTypeIDByCode(LetterFormType.FORM);
					break;
				case (LetterSearch.Envelopes):
					letterTemplateSearcher.FormTypeID = LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_FormTypeIDByCode(LetterFormType.ENVELOPE);
					break;
				case (LetterSearch.Standard):
					letterTemplateSearcher.FormTypeID = LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_FormTypeIDByCode(LetterFormType.STANDARD);
					break;
			}

			this.LetterTemplateSearcher = letterTemplateSearcher;

			BindMatrixTypeContext();

			SearchForLetterTemplates();
		}

		private void MatrixTypeContext_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			switch(MatrixTypeContext.SelectedValue)
			{
				case (LetterSearch.MatrixTypeEvent):
					letterTemplateSearcher.MatrixTypeID = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCode(MatrixType.EVENT_CLINICALREVIEW);
					break;
				case (LetterSearch.MatrixTypeReferral):
					letterTemplateSearcher.MatrixTypeID = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCode(MatrixType.REFERRAL);;
					break;
			}

			this.LetterTemplateSearcher = letterTemplateSearcher;

			SearchForLetterTemplates();
		}



		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Select")
				LetterForm.Redirect(patient, erc, LetterTemplates[index], referralDetail);
			
		}


		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			grid.AddButtonColumn("Select", "@SELECT@", 0);
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.erc);
		}

	}
}
