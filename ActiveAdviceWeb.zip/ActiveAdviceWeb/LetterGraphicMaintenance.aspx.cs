using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.LETTER_SETUP)]
	
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterGraphic,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("LetterGraphics")]
	[PageTitle("@LETTERGRAPHICSPAGETITLE@")]
	public class LetterGraphicMaintenance : LetterMaintenanceBasePage
	{
		private LetterGraphicCollection letterGraphics;
		private LetterGraphic letterGraphic;
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLetterGraphic;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLetterGraphics;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGraphicID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit GraphicID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGraphicID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.WebForms.OBTextBox Description;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFileLocation;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FileLocation;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFileLocation;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				letterGraphic = (LetterGraphic)this.LoadObject("LetterGraphic");  // load object from cache
				letterGraphics = (LetterGraphicCollection)this.LoadObject("LetterGraphics");  // load object from cache
			}

		}

		private void LoadData()
		{
			if(LoadDataForLetterGraphics())
			{
				if(this.letterGraphics.Count > 0)
				{
					this.LetterGraphic = this.letterGraphics[0];
					grid.SelectedRowIndex = 0;
				}
				else
					this.NewLetterGraphic();
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForLetterGraphics()
		{
			bool result = true;
			LetterGraphicCollection letterGraphics = new LetterGraphicCollection();
			try
			{	// use any load method here
				letterGraphics.LoadAllLetterGraphics(-1);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterGraphics.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterGraphics = letterGraphics;
			return result;
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "LetterGraphic")
			{
				toolbar.AddButton(LetterMessages.MessageIDs.ADDNEW, "AddNew");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterGraphic LetterGraphic
		{
			get { return letterGraphic; }
			set
			{
				letterGraphic = value;
				try
				{
					this.UpdateFromObject(this.pnlLetterGraphic.Controls, letterGraphic);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("LetterGraphic", letterGraphic);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLetterGraphic()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlLetterGraphic.Controls, letterGraphic);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewLetterGraphic()
		{
			bool result = true;
			LetterGraphic letterGraphic = null; //new LetterGraphic(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				letterGraphic = new LetterGraphic(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.LetterGraphic = letterGraphic;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForLetterGraphics()
		{
			if(!this.ReadControlsForLetterGraphic())
				return false;

			try
			{	// data from controls to object

				if(this.letterGraphic.GraphicID == 0)
				{	// New Letter Graphic - Adding
					letterGraphics.Add(letterGraphic);
					letterGraphics.Save(); // update or insert to db 
					this.LetterGraphics = letterGraphics;
					grid.SelectedRowIndex = grid.Rows.Count - 1;
					this.LetterGraphic = letterGraphic;
				}
				else
				{	
					// Existing Letter Set - updating
					letterGraphic.MarkDirty();
					letterGraphics.Save(); // update or insert to db 
					this.LetterGraphics = letterGraphics;
					this.LetterGraphic = letterGraphic;
				}
				//NSGlobal.ClearCache(typeof(LetterGraphicCollection), false);

				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterGraphicCollection LetterGraphics
		{
			get { return letterGraphics; }
			set
			{
				letterGraphics = value;
				try
				{
					grid.UpdateFromCollection(letterGraphics);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("LetterGraphics", letterGraphics);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLetterGraphics()
		{
			try
			{	//customize this method for this specific page
				grid.UpdateToCollection(letterGraphics);	// grid-to-collection
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}


		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect()
		{
			BasePage.PushCurrentCallingPage();
			BasePage.Redirect("LetterGraphicMaintenance.aspx");
		}


		public override void OnSetDirty()
		{
			base.OnSetDirty();
			this.CheckForDirty(letterGraphic);
		}


		#region UI events and initialization
		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.NewLetterGraphic();
			grid.SelectedRowIndex = -1;
			this.ScrollToControl(pnlLetterGraphic);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.SaveDataForLetterGraphics())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@LETTERGRAPHIC@"); 
				grid.UpdateFromCollection(LetterGraphics);
			}
			this.ScrollToTop();
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
			{
				this.LetterGraphic = LetterGraphics[index];
				this.ScrollToControl(pnlLetterGraphics);
			}
		}
		#endregion

	}
}

