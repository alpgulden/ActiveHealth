
// Opens the Clinical Request/Decision selection dialog
// If letter generation is referring to request or decision, we use this function to open the request/decision selection dialog.
function openClinicalSelect(ifRequired)
{
	//window.alert(ifRequired);
	var requestID = GetElemValue('LetterContextRequestID');
	var decisionID = GetElemValue('LetterContextDecisionID');
	
	var selectMode = 'D';
	if (ifRequired != null && ifRequired == true)
	{
		selectMode = GetElemValue('ReqDecSelectMode');
		if (selectMode == '')
			return false;
			
	}

	window.showModalDialog("ClinicalRequestDecisionSelect.aspx?SelectMode=" + selectMode + "&RequestID=" + requestID + "&DecisionID=" + decisionID + "&rnd=" + new Date().valueOf()
		,window
		,"resizable:no;toolbar:no;dialogWidth:800px;dialogHeight:700px");
	return false;
}

function setClinicalReqDec(requestID, decisionID)
{
	SetElemValue('LetterContextRequestID', requestID);
	SetElemValue('LetterContextDecisionID', decisionID);
	//__doPostBack('butMerge', '');	// trigger butMerge Click event on the server
	__doPostBack('', '');
}


/*
Author: Rob Eberhardt, Slingshot Solutions - http://slingfive.com/
Description: fixes failings of modal/modeless dialogs
Fixes: form submission, link targets, cookies, window.opener, keyboard shortcuts, accelerator:true, 
	window.navigate(), window.location.assign(), window.location.reload(), window.location.replace()
Usage: simply call at/after window.onload fires, it automatically detects dialogs & fixes
Params: p_bEnableContextMenu as boolean (enables custom context menu to re-create IE context menu basics)
Not fixed:
	-dynamically setting document.title
	-"window.location = ..."
History:
	2004-09-30	changed form/link fix, uses dynamic BASE tag instead of element looping
	2004-03-10	1st public release

*/




function fixDialog(){
	// just for dialogs, else quit
	try{
		if(dialogArguments==undefined){return}
	}catch(e){return}
	
	// name window, so we can fix targeting
	if(window.name==''){window.name = "winDialog";}
		

	goToURL = function(p_strURL){
		var oLink = document.createElement("A");
		document.body.insertAdjacentElement('beforeEnd', oLink);
		with(oLink){
			href = p_strURL;
			target = window.name;
			click();
		}
	}

	// fix window.navigate()
	window.navigate = goToURL; 
	// fix window.location.assign()
	window.location.assign = goToURL; 
	// fix window.location.reload()
	window.location.reload = function(){window.navigate(window.location.href)}
	// fix window.location.replace() (SORTA!)
	window.location.replace = goToURL; 
			

	// if window object was passed to vArguments, hook up as window.opener
	// eg:  showModalDialog(sURL, window, sFeatures)
	var bWasPassedWindow = false;
	try{
		bWasPassedWindow = dialogArguments.location!=undefined;
	}catch(e){}


	if(bWasPassedWindow){
		// fix opener
		window.opener = dialogArguments;

		// fix cookies (make available in dialog) 	<--- seems to work fine without this too?
		document.cookie = dialogArguments.document.cookie;
	}



	// fix document stuff
	attachEvent("onload", function(){
	
		// fix form submissions and link openings
		// insert base tag with target (should be faster & work on dynamically created links)
		var oHead = document.getElementsByTagName("HEAD")[0];
		var oBase= document.createElement("BASE");
		oBase.target = window.name;
		oHead.insertAdjacentElement('AfterBegin', oBase);
		//alert(oHead.outerHTML);
		
	});


	// fix keyboard stuff
	document.attachEvent("onkeydown", function(){
//		alert(event.keyCode);
		switch(event.keyCode){
			case 27: {	// enable ESC to close dialog
				close();
				break;
			}

			//==== fix reload ====
			case 116: {	// f5 
				window.location.reload();
				break;
			}
			case 82: {	// ctl-R
				if(event.ctrlKey){
				window.location.reload();
				}
				break;
			}

			//==== fix keyboard navigation (does Not work, history object is always empty..) ====
			case 8: {	// backspace
				history.back();
				break;
			}
			case 37: {	// alt-left arrow
				if(event.altKey){history.back();}
				break;
			}
			case 39: {	// alt-right arrow
				if(event.altKey){history.forward();} 
				break;
			}
		}
	});

}


fixDialog();


