using System;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using NetsoftUSA.WebForms;
using ActiveAdvice.DataLayer;
using NetsoftUSA.InfragisticsWeb;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for Report.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ReportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MPatient")]
	public class FormSpecificReport : BasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		private string repName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReport;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected System.Web.UI.WebControls.DropDownList lstMIME;
		protected System.Web.UI.WebControls.Button btnExportPDF;
		private object[] param;
		private object[] param1;

		private void Page_Load(object sender, System.EventArgs e)
		{				
			if(!Page.IsPostBack)
			{
				this.RepName = (string)this.GetParam("ReportName");
				param = this.GetParam("FSReportParameters") as object[];
				this.CacheObject("ReportName",repName);
				this.CacheObject("FSReportParameters",param);
			}	
			else
			{
				this.RepName = (string)this.LoadObject("ReportName");
				param		 = this.LoadObject("FSReportParameters") as object[];
				param1		 = this.LoadObject("param1") as object[];
			}

				/*ReportDocument repDoc = new ReportDocument();					
				repDoc.Load(Server.MapPath("Reports\\"+this.RepFileName));
				ParameterFields paramFields = new ParameterFields ();
				SetLoginInfo(repDoc);
				AddParameter("PatientID",param[0],paramFields);
				switch(repName)
				{
					case "SINGLEEVENT":
						AddParameter("EventID",param[1],paramFields);
						break;
					case "COSTCOMPSINGLEPATIENTPROB":
						AddParameter("ProblemID",param[1],paramFields);
						break;
					case "CMSCOSTCOMP":
						AddParameter("CMSID",param[1],paramFields);
						break;
				}
				this.CacheObject("param1",param);
				rep.ParameterFieldInfo = paramFields;
				rep.ReportSource = repDoc;
				rep.DisplayGroupTree = false; // hide the group tree on the left
				rep.DataBind();*/
			// Put user code to initialize the page here


		}

		private void SetReportParameters()
		{
		}

//		public override void PopulateSubNavigation(WebListBar listbar)
//		{
//			base.PopulateSubNavigation (listbar);
//			
//		}


		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("@CANCEL@","Cancel",false,false);

		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BasePage.Redirect(this.BackPage);
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			try
			{
				if(!Page.IsPostBack)
				{
					this.RepName = (string)this.GetParam("ReportName");
					param = this.GetParam("FSReportParameters") as object[];
					param1 = null;
				}
				else
				{
					this.repName = this.LoadObject("ReportName") as string;
					param = this.LoadObject("FSReportParameters") as object[];
					param1 = this.LoadObject("param1") as object[];
				}
				this.CacheObject("ReportName",repName);
				this.CacheObject("FSReportParameters",param);
				ReportDocument repDoc = new ReportDocument();					
				repDoc.Load(Server.MapPath("Reports\\"+this.RepFileName));
				ParameterFields paramFields = new ParameterFields ();
				SetLoginInfo(repDoc);
				AddParameter("PatientID",param[0],paramFields);
				switch(repName)
				{
					case "SINGLEEVENT":
						AddParameter("EventID",param[1],paramFields);
						break;
					case "COSTCOMPSINGLEPATIENTPROB":
						AddParameter("ProblemID",param[1],paramFields);
						break;
					case "CMSCOSTCOMP":
						AddParameter("CMSID",param[1],paramFields);
						break;
				}
				this.CacheObject("param1",param);
				//rep.ParameterFieldInfo = paramFields;
				//rep.ReportSource = repDoc;
				//rep.DisplayGroupTree = false; // hide the group tree on the left
				//rep.DataBind();
			}
			catch(Exception ex)
			{
				this.RaisePageException(new Exception("Error running report!", ex));
			}
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnExportPDF.Click += new System.EventHandler(this.btnExportPDF_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		
		public string RepName
		{
			get { return repName; }
			set 
			{ 
				if(value!=null)
					repName = value;
			}
		}

	public string RepFileName
		{
			get
			{
				switch(repName)
				{
					case "SINGLEEVENT":
						return "SingleEvent.rpt";
					case "COSTCOMPSINGLEPATIENTPROB":
						return "SinglePatientProblemCostComp.rpt";
					case "CMSCOSTCOMP":
						return "CMSCostComparison.rpt";
					default:
						throw new ActiveAdviceException("Invalid report name");
				
				}
			}
		}
	
		private void SetLoginInfo(ReportDocument repDoc)
		{
			try
			{
				// set connection information for all tables
				foreach (CrystalDecisions.CrystalReports.Engine.Table table in repDoc.Database.Tables)
				{
					CrystalDecisions.Shared.TableLogOnInfo login = table.LogOnInfo;
					string servername ="";
					string dbname="";
					string uid="";
					string pwd="";
					NetsoftUSA.DataLayer.NSGlobal.GetConnectionAttributes(ref servername,
						ref dbname,
						ref uid,
						ref pwd);
					login.ConnectionInfo.ServerName=servername;
					login.ConnectionInfo.DatabaseName=dbname;
					login.ConnectionInfo.UserID = "aa_user";
					login.ConnectionInfo.Password = "aa_user";
					table.ApplyLogOnInfo(login);
					table.Location = dbname +".dbo." +table.Location.Substring(table.Location.LastIndexOf(".") + 1);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
	

		public static void Redirect(object[] param,string reportName)
		{
			BasePage.PushParam("FSReportParameters", param);
			BasePage.PushParam("ReportName",reportName);
			BasePage.Redirect("FormSpecificReport.aspx");
		}

		private void AddParameter(string paratmeterName,object paramValue,ParameterFields parameterFields)
		{
			ParameterField paramField = new ParameterField();
			ParameterDiscreteValue discreteVal = new ParameterDiscreteValue();
			paramField.ParameterFieldName = paratmeterName;
			discreteVal.Value = paramValue;
			paramField.CurrentValues.Add(discreteVal);
			parameterFields.Add(paramField);
		}

		private void SetReportParam(ReportDocument repDoc, string paramName,object paramValue)
		{	
			try
			{
				ParameterValues paramValues = repDoc.DataDefinition.ParameterFields[paramName].CurrentValues;
				paramValues.Clear();
				ParameterDiscreteValue paramDiscreteValue = new ParameterDiscreteValue ();
				paramDiscreteValue.Value = (paramValue == null ? "" : paramValue);
				paramValues.Add (paramDiscreteValue);
				repDoc.DataDefinition.ParameterFields[paramName].ApplyCurrentValues(paramValues);
			}
			catch
			{
				this.SetPageMessage("Could not set report parameter.  Ignoring.", EnumPageMessageType.Warning);
			}
		}


		public override void PopulateToolbarItems(WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@CANCEL@","Cancel",false);
		}



		private void ExportToPDF(string mimeType)
		{
			string expFile = Server.MapPath("Reports\\" + this.RepFileName);
			ReportDocument repDoc = new ReportDocument();
			repDoc.Load(expFile);

			SetLoginInfo(repDoc);
			param1 = this.LoadObject("param1") as object[];
			SetReportParam(repDoc,"PatientID",param1[0]);
			switch(repName)
			{
				case "SINGLEEVENT":
					SetReportParam(repDoc,"EventID",param1[1]);
					//AddParameter("EventID",param[1],paramFields);
					break;
				case "COSTCOMPSINGLEPATIENTPROB":
					SetReportParam(repDoc,"ProblemID",param1[1]);
					//AddParameter("ProblemID",param[1],paramFields);
					break;
				case "CMSCOSTCOMP":
					SetReportParam(repDoc,"CMSID",param1[1]);
					//AddParameter("CMSID",param[1],paramFields);
					break;
			}

			
			ExportFormatType expType = ExportFormatType.NoFormat;
			string           extension = null;
			string apptype = "";
			#region "Set MIME Type"
			switch( mimeType )
			{
				case "xls":
					expType		= ExportFormatType.Excel;
					extension	= "xls";
					apptype		= "application/vnd.ms-excel";
					break;
				case "word":
					expType		= ExportFormatType.WordForWindows;
					extension   = "doc";
					apptype		= "application/msword";
					break;
				default:
					expType		= ExportFormatType.PortableDocFormat;
					extension	= "pdf";
					apptype		= "application/pdf";
					break;		
			}
			#endregion 
			/*DiskFileDestinationOptions diskFileDestOpt = new DiskFileDestinationOptions();
			string outFile = "Login_" + ActiveAdvice.DataLayer.AASecurityHelper.GetUserId + "_report." + extension;
			diskFileDestOpt.DiskFileName = Server.MapPath("Reports\\" + outFile);
			ExportOptions expOptions = repDoc.ExportOptions;
			expOptions.DestinationOptions = diskFileDestOpt;
			expOptions.ExportDestinationType = ExportDestinationType.DiskFile;
			expOptions.ExportFormatType = expType;

			repDoc.Export();
			repDoc.Close();
		

			BasePage.Redirect("Reports\\" + outFile);*/
			MemoryStream oStream; // using System.IO

			oStream = (MemoryStream)
				repDoc.ExportToStream(
				expType);
			Response.Clear();
			Response.Buffer= true;
			Response.ContentType = apptype;
			Response.BinaryWrite(oStream.ToArray());
			Response.End();
		}

		private void btnExportPDF_Click(object sender, System.EventArgs e)
		{
			ExportToPDF(this.lstMIME.SelectedValue);
		}

		
	}
}
