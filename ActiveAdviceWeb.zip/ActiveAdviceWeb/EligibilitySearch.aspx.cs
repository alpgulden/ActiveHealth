using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using Infragistics.WebUI.UltraWebToolbar;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// This page is called when the user hits Eligibility button in the Intake form.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("EligibilitySearchResult,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MIntake")]
	[PageTitle("@ELIGIBILITYSEARCHTITLE@")]
	public class EligibilitySearch : BasePage
	{
		private EligibilitySearchResultCollection eligibilitySearchResults;
		private IntakeLog intakeLog;
		// FORK 1.0
		private bool linkToPatient;		// if true, link to the patient in context
		private Patient patient;		// link the selected coverage to this patient
		private int selectedEligIndex = -1;	// if there's more than 1 patients found, keep this and show found patients
		private PatientSearchResultCollection existingPatients;
		// END FORK 1.0

		// the intakeLog context
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchElig;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientFName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PatientFName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientFName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientLName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PatientLName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientLName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientSSN;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit PatientSSN;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientSSN;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPatSubsInfo;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientMemberID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientMemberID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PatientMemberID;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridExistingPatients;
		protected NetsoftUSA.WebForms.OBLabel GridTitle;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlExistingPatients;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientDOB;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit PatientDOB;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientDOB;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientGender;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PatientGender;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientGender;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSORGId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit SORGId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSORGID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtSorgPath;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForSORG;
		protected System.Web.UI.WebControls.Literal sorgPath;
		protected System.Web.UI.WebControls.Image butClear;
		protected TBarButton tbbCancel;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				eligibilitySearchResults = (EligibilitySearchResultCollection)this.LoadObject(typeof(EligibilitySearchResultCollection));  // load object from cache
				intakeLog = (IntakeLog)this.LoadObject(typeof(IntakeLog));  // load object from cache
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("EligibilitySearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			grid.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
			grid.RowBoundToDataObject +=new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(grid_RowBoundToDataObject);
			grid.ClickCellButton +=new ClickCellButtonEventHandler(grid_ClickCellButton);

			// FORK 1.0
			gridExistingPatients.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridExistingPatients_ColumnsBoundToDataClass);
			gridExistingPatients.ClickCellButton +=new ClickCellButtonEventHandler(gridExistingPatients_ClickCellButton);
			// END FORK 1.0
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSearchElig.Click += new System.EventHandler(this.butSearchElig_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			try
			{	// use any load method here
				// or pull from the parameter passed to this page via PushParam
				this.SetPageMessageFromParam();					// display the message sent by the calling page.

				// FORK 1.0
				patient = this.GetParam("Patient") as Patient;
				if (patient != null)
				{
					linkToPatient = true;
					// create a new intake log just for the use of this page.
					intakeLog = new IntakeLog(true);
					intakeLog.Patient = this.patient;
					//intakeLog.PullPatientInfo();
				}
				else
				{
					// END FORK 1.0
					intakeLog = this.GetParam("IntakeLog") as IntakeLog;
					// FORK 1.0
				}
					// END FORK 1.0

				if (intakeLog == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You can hit this page only in the context of an Intake");
				this.CacheObject(typeof(IntakeLog), intakeLog);		// cache the intake-log context so that we'll get it in the next post back

				// invoke the search using intake data
				// FORK 1.0
				this.IntakeLog = intakeLog;	
				if (!linkToPatient)
					result = SearchForEligibilitySearchResults(intakeLog);
				// END FORK 1.0
			
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patient.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(IntakeLog intakeLog)
		{
			BasePage.PushParam("IntakeLog", intakeLog);
			BasePage.Redirect("EligibilitySearch.aspx");
		}

		// FORK 1.0
		
		/// <summary>
		/// Create a new coverage from the selected eligibility
		/// and link it to the given patient.
		/// </summary>
		/// <param name="patient"></param>
		public static void RedirectForLinkToPatient(Patient patient)
		{
			BasePage.PushParam("Patient", patient);
			BasePage.Redirect("EligibilitySearch.aspx");
		}

		// END FORK 1.0

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
				if (this.intakeLog != null)
					toolbar.AddButton("@BACKTOINTAKE@", "Cancel");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			tbbCancel = toolbar.AddButton(PatientMessages.MessageIDs.CANCEL, "Cancel").Item;

			// FORK 1.0
			toolbar.AddButton("@ADDNEWPATIENT@", "AddNewPatient");
			// END FORK 1.0
		}

		// FORK 1.0
		public void SubscriberFormRedirectCurrentContext(string targetTab)
		{
			Patient patient = (Patient)this.LoadObject(typeof(Patient));
			PatientCoverage patCov = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));
			Subscriber subscriber = (Subscriber)this.LoadObject(typeof(Subscriber));
			BasePage.PushTargetTab(targetTab);
			SubscriberForm.Redirect(patient, patCov, subscriber);
		}
		// END FORK 1.0

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// FORK 1.0
			if (this.IsSelectingPatient)
			{
				CancelSelectPatient();
				return;
			}

			if (this.linkToPatient)
				PatientSummaryForm.Redirect(this.patient); //SubscriberFormRedirectCurrentContext("Coverage");
			// END FORK 1.0

			// in intake-log context.  Go back to intake page.
			IntakeForm.Redirect(intakeLog);
		}

		// FORK 1.0
		public void OnToolbarButtonClick_AddNewPatient(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SelectPatient(0);	// Create a new patient with the selected eligibility
		}
		// END FORK 1.0

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EligibilitySearchResultCollection EligibilitySearchResults
		{
			get { return eligibilitySearchResults; }
			set
			{
				eligibilitySearchResults = value;
				try
				{
					grid.UpdateFromCollection(eligibilitySearchResults);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(EligibilitySearchResultCollection), eligibilitySearchResults);  // cache object using the caching method declared on the page
			}
		}

		// FORK 1.0

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientSearchResultCollection ExistingPatients
		{
			get { return existingPatients; }
			set
			{
				existingPatients = value;
				try
				{
					gridExistingPatients.UpdateFromCollection(existingPatients);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject(typeof(PatientSearchResultCollection), existingPatients);  // cache object using the caching method declared on the page
			}
		}

		// END FORK 1.0

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool SearchForEligibilitySearchResults(IntakeLog intakeLog /* FORK 1.0 */)
		{
			bool result = true;
			EligibilitySearchResultCollection eligibilitySearchResults = new EligibilitySearchResultCollection();
			try
			{
				//if (!this.ReadControlsForSearcherObject()) // Use appropriate read controls method to read the searcher object from controls 
				//	return false;

				int maxRows = 100;
				eligibilitySearchResults.SearchEligibility(
					maxRows,
					intakeLog.ServiceDate,
					intakeLog.PatientMemberID,
					intakeLog.PatientSSN,
					intakeLog.PatientLName,
					intakeLog.PatientFName,
					// FORK 1.0
					intakeLog.PatientDOB,
					intakeLog.PatientGender,
					// END FORK 1.0
					intakeLog.SubscriberSSN,
					intakeLog.SubscriberLName,
					intakeLog.SubscriberFName,
					intakeLog.SORGId,
					intakeLog.PlanID);

				if (eligibilitySearchResults.Count >= maxRows)
					this.SetPageMessage("More than {0} records were found.  Refine your search criteria", EnumPageMessageType.Warning, maxRows);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//eligibilitySearchResults.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.EligibilitySearchResults = eligibilitySearchResults;
			return result;
		}

		private void grid_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			grid.AddColumnWithButtonLook("Detail", "@DETAIL@", 0);
			grid.AddButtonColumn("Select", "@SELECT@", 0);
		}

		// FORK 1.0

		public void SelectFromExistingPatients(int eligIndex)
		{
			this.selectedEligIndex = eligIndex;
			EligibilitySearchResult eligResult = this.eligibilitySearchResults[selectedEligIndex];
			ExistingPatients = eligResult.PatientEligibility.GetExistingPatientsInTheSystem();

			pnlExistingPatients.Visible = true;
			pnlSearch.Visible = false;
			pnlPatSubsInfo.Visible = false;
		}

		public void CancelSelectPatient()
		{
			pnlExistingPatients.Visible = false;
			pnlSearch.Visible = true;
			pnlPatSubsInfo.Visible = true;
		}

		public bool IsSelectingPatient
		{
			get { return this.pnlExistingPatients.Visible; }
		}

		// END FORK 1.0

		private void grid_ClickCellButton(object sender, CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			switch (e.Cell.Key)
			{
				case "Select":
				{
					try
					{
						EligibilitySearchResult eligResult = this.eligibilitySearchResults[index];
						if (!eligResult.IsValidCoverage)
						{
							throw new ActiveAdviceException(AAExceptionAction.None, "@COVERAGENOTVALID@");
						}
						// FORK 1.0

						if (this.linkToPatient && this.patient != null)	// selection must be linked to the patient in the context
						{
							// Has been called from subscriber form to create a new coverage for the given patient
							intakeLog.CreatePatSubsCovFromEligibility(eligResult, /* FORK 1.0 */ true);
							// Return to subscriber with the newly created patient coverage and subscriber
							this.CacheObject(typeof(IntakeLog), null);
							
							PushPageMessage("Subscriber and Coverage has been imported from eligibility but hasn't been saved yet.", EnumPageMessageType.Info);
							PushTargetTab("Coverage");
							SubscriberForm.Redirect(intakeLog.Patient, intakeLog.PatientCoverage, intakeLog.Subscriber);
							return;
						}

						// END FORK 1.0

						// FORK 1.0
						try
						{
							// END FORK 1.0
							intakeLog.CreatePatSubsCovFromEligibility(eligResult, /* FORK 1.0 */ true);
							// FORK 1.0
						}
						catch(System.Data.SqlClient.SqlException sqlEx)
						{
							// If there are more than 1 patients linked to the
							// selected eligibility, we need to display them to the user and let
							// him/her chose one.
							if (true) //sqlEx.Errors[0].Number == 16)
								SelectFromExistingPatients(index);
							else
								this.RaisePageException(sqlEx);
							return;
						}
						// END FORK 1.0

						// Check if PlanSORG.EligibilityAddAnyway is true,
						// If so, we save imported stuff right away..
						if (intakeLog.PatientCoverage != null && intakeLog.PatientCoverage.PlanSORG != null)
						{
							if (!intakeLog.PatientCoverage.PlanSORG.EligibilityAddAnyway)
							{
								// don't go to patient page, just save and reutrn;
								bool patientNew = intakeLog.Patient.IsNew;
								intakeLog.Subscriber.Save(intakeLog.Patient, intakeLog.PatientCoverage, patientNew);
								if (patientNew)
									PushPageMessage("New Patient, Subscriber and Coverage has been imported from eligibility and has been saved.", EnumPageMessageType.Info);
								else
									PushPageMessage("Subscriber and Coverage has been imported from eligibility and has been saved.", EnumPageMessageType.Info);
								IntakeForm.Redirect(intakeLog, true);
							}
						}

						if (intakeLog.Patient.IsNew)
							PushPageMessage("New Patient, Subscriber and Coverage has been imported from eligibility but hasn't been saved yet.", EnumPageMessageType.Info);
						else
							PushPageMessage("Using existing patient. Subscriber and Coverage has been imported from eligibility but hasn't been saved yet.", EnumPageMessageType.Info);
						//IntakeForm.Redirect(intakeLog, true);
						intakeLog.SaveWithPatient = false;		// this will cause the subscriber form to return to intake log without saving intakelog object.
						PatientForm.Redirect(intakeLog);
					}
					catch(Exception ex)
					{
						this.RaisePageException(ex);
					}
					break;
				}
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			// FORK 1. 0

			if (!this.IsSelectingPatient &&  this.intakeLog != null)
				this.SetPageToolbarItemText("Cancel", "@BACKTOINTAKE@");

			if (this.linkToPatient)
			{
				this.SetPageTabToolbarItemText("Cancel", "@BACKTOPATIENT@");
				this.SetPageToolbarItemText("Cancel", "@BACKTOPATIENT@");
			}

			this.SetPageToolbarItemVisible("AddNewPatient", this.IsSelectingPatient);

			sorgPath.Text = "<span id='sorgPath'>" + txtSorgPath.Text + "</span>";
			butClear.Attributes["OnClick"] = "setSORGID(null, '')";

			// END FORK 1.0
		}

		private void grid_RowBoundToDataObject(object sender, RowBindingEventArgs e)
		{
			UltraGridCell cell = e.row.Cells.FromKey("Detail");
			if (cell != null)
			{
				EligibilitySearchResult eligRes = e.data as EligibilitySearchResult;
				e.row.Cells.FromKey("Detail").Text = String.Format("<a href='#' onclick='return OpenEligibilityDetail({0});'>{1}</a>", eligRes.PatientEligibilityID, "Detail");
			}
		}

		// FORK 1.0

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public IntakeLog IntakeLog
		{
			get { return intakeLog; }
			set
			{
				intakeLog = value;
				try
				{
					this.RequiredValidationsEnabled = intakeLog.ValidateForSave();

					this.UpdateFromObject(pnlPatSubsInfo.Controls, intakeLog);
					txtSorgPath.Text = this.CreateOrgPathHTML(null, this.intakeLog.SORG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(IntakeLog), intakeLog);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public IntakeLog ReadControls()
		{
			try
			{
				IntakeLog intakeLog = (IntakeLog)this.intakeLog.Clone();	// never overwrite the passed intakeLog
				//customize this method for this specific page
				this.UpdateToObject(pnlPatSubsInfo.Controls, intakeLog, false);

				// other control-to-object methods if any
				if (!this.PageError)
					return intakeLog;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}

			return null;
		}

		private void butSearchElig_Click(object sender, System.EventArgs e)
		{
			IntakeLog intakeLog = this.ReadControls();
			if (intakeLog != null)
			{
				if (intakeLog.ServiceDate == DateTime.MinValue)
				{
					this.SetPageMessage("@SERVICEDATENOTGIVEN@", EnumPageMessageType.Error);
					return;
				}

				SearchForEligibilitySearchResults(intakeLog);
			}
		}

		protected override object SaveViewState()
		{
			this.ViewState["linkToPatient"] = this.linkToPatient;
			this.ViewState["selectedEligIndex"] = this.selectedEligIndex;

			return base.SaveViewState ();
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
			this.selectedEligIndex = (int)this.ViewState["selectedEligIndex"];
			this.linkToPatient = (bool)this.ViewState["linkToPatient"];
			if (this.linkToPatient)
				this.patient = (Patient)this.LoadObject(typeof(Patient));
		}

		private void gridExistingPatients_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			gridExistingPatients.AddButtonColumn("Select", "@SELECT@", 0);
		}

		private void gridExistingPatients_ClickCellButton(object sender, CellEventArgs e)
		{
			int patientID = gridExistingPatients.GetPKIntFromCellEvent(e);
			SelectPatient(patientID);
		}

		/// <summary>
		/// If patientID == 0, create a new one.
		/// </summary>
		/// <param name="patientID"></param>
		public void SelectPatient(int patientID)
		{
			if (patientID < 0)
				return;

			try
			{
				// force the patient to the selected one
				Patient patient = null;
				if (patientID != 0)
				{
					patient = new Patient();
					if (!patient.Load(patientID))
						throw new ActiveAdviceException("@CANTFINDRECORD@", "@PATIENT@");
				}
				intakeLog.Patient = patient;
				intakeLog.PullPatientInfo();

				// use the previously selected eligibility result.
				EligibilitySearchResult eligResult = this.eligibilitySearchResults[selectedEligIndex];

				// Now the selected eligibility result and selected patient is
				// ready on the intakeLog, go ahead and create the rest..
				intakeLog.CreatePatSubsCovFromEligibility(eligResult, false);

				// Check if PlanSORG.EligibilityAddAnyway is true,
				// If so, we save imported stuff right away..
				if (intakeLog.PatientCoverage != null && intakeLog.PatientCoverage.PlanSORG != null)
				{
					if (!intakeLog.PatientCoverage.PlanSORG.EligibilityAddAnyway)
					{
						// don't go to patient page, just save and reutrn;
						bool patientNew = intakeLog.Patient.IsNew;
						intakeLog.Subscriber.Save(intakeLog.Patient, intakeLog.PatientCoverage, patientNew);
						if (patientNew)
							PushPageMessage("New Patient, Subscriber and Coverage has been imported from eligibility and has been saved.", EnumPageMessageType.Info);
						else
							PushPageMessage("Subscriber and Coverage has been imported from eligibility and has been saved.", EnumPageMessageType.Info);
						IntakeForm.Redirect(intakeLog, true);
					}
				}

				if (intakeLog.Patient.IsNew)
					PushPageMessage("New Patient, Subscriber and Coverage has been imported from eligibility but hasn't been saved yet.", EnumPageMessageType.Info);
				else
					PushPageMessage("Using existing patient. Subscriber and Coverage has been imported from eligibility but hasn't been saved yet.", EnumPageMessageType.Info);
				//IntakeForm.Redirect(intakeLog, true);
				intakeLog.SaveWithPatient = false;		// this will cause the subscriber form to return to intake log without saving intakelog object.
				PatientForm.Redirect(intakeLog);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		// END FORK 1.0

	}
}
