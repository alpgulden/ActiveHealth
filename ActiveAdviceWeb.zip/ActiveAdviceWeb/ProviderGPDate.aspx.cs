using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for ContactForm.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ProviderMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("ProviderSpecialty,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class ProviderGPDate : BasePage
	{
		private GroupPracticeProviderLink gpLink;
		
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFocusDate;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnProceed;
		protected NetsoftUSA.InfragisticsWeb.WebCalendarDropDown WebCalendarDropDown1;
		protected System.Web.UI.HtmlControls.HtmlTable tblMain;
		protected NetsoftUSA.InfragisticsWeb.WebCombo BoardStatus;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBoardStatus;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnClose;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
				this.LoadData();
			else
				gpLink = (GroupPracticeProviderLink)this.LoadObject("providerNewGPLink");  // load object from cache

		}

		private void LoadData()
		{
			try
			{
				GroupPracticeLink = BasePage.PullParam("providerNewGPLink") as GroupPracticeProviderLink;
				if (GroupPracticeLink == null)
					Debug.Fail("Group Practice Provider Link was not supplied");					
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}

		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			this.DirtyCheckEnabled = false;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
		}

		private void btnProceed_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForGPLink())
			{
				// PostBack opener to process the SessionData
				BasePage.PushParam("providerNewGPLink",this.gpLink);
				Page.RegisterStartupScript("addGPLink","<script language=\"javascript\">window.opener.__doPostBack(\"\",\"\");window.close();</script>");
			}
		}

		private void btnClose_Click(object sender, System.EventArgs e)
		{
			BasePage.PushParam("providerNewGPLink", null);
			Page.RegisterStartupScript("closePage","<script language=\"javascript\">window.close();</script>");
		}




		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeProviderLink GroupPracticeLink
		{
			get { return gpLink; }
			set
			{
				gpLink = value;
				try
				{
					this.UpdateFromObject(this.tblMain.Controls, gpLink);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("providerNewGPLink", gpLink);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForGPLink()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblMain.Controls, gpLink);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}
	}
}
