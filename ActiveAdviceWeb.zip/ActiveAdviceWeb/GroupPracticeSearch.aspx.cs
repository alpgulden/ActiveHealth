using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Text;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.GroupPracticeMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("GroupPractice,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MProviderFacility")]
	[SelectedMenuItem("GroupPractices")]
	[PageTitle("@GROUPPRACTICESEARCHTITLE@")]
	public class GroupPracticeSearch : ProviderBasePage
	{
		private GroupPracticeLocation groupPracticeLocationSearch;
		private Location locationSearch;
		private GroupPracticeLocationService groupPracticeServiceTypeSearch;
		private GroupPracticeFocus groupPracticeFocusTypeSearch;
		private Address groupPracticeAddressSearch;
		private GroupPracticeCollection resultGroupPractices;
		private GroupPracticeLocationCollection resultGroupPracticeLocations;
		private NetworkPlanLink searchNetworkPlanLink;
		private GroupPracticeLocationNetworkLink searchgpNetworkLink;
		private GroupPractice groupPracticeSearch;

		private int startGroupPracticeId = 0;
		private string startName = "";
		
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProviderFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSearchName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearchName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResults;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNetworks;
		protected System.Web.UI.WebControls.RadioButton rdBtnName;
		protected System.Web.UI.WebControls.RadioButton rdBtnID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected System.Web.UI.WebControls.RadioButtonList rdSearchBy;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit County;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCounty;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit Zip;
		protected NetsoftUSA.WebForms.OBFieldLabel lbZip;
		protected NetsoftUSA.WebForms.OBComboBox State;
		protected NetsoftUSA.WebForms.OBFieldLabel lbState;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit City;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCity;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.WebForms.OBComboBox TypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTypeID;
		protected System.Web.UI.HtmlControls.HtmlTable tblName;
		protected System.Web.UI.HtmlControls.HtmlTable tblGroupPracticeType;
		protected System.Web.UI.HtmlControls.HtmlTable tblAddress;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit GroupPracticeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeID;
		protected System.Web.UI.HtmlControls.HtmlTable tblID1;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit LocationID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FederalTaxID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFederalTaxID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MedicareID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMedicareID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit UPIN;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUPIN;
		protected System.Web.UI.HtmlControls.HtmlTable tblID2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected System.Web.UI.HtmlControls.HtmlTable tblID3;
		protected NetsoftUSA.WebForms.OBComboBox GroupPracticeServiceTypeID;
		protected System.Web.UI.HtmlControls.HtmlTable tblServices;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GroupPracticeFocusTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeFocusTypeID;
		//protected System.Web.UI.HtmlControls.HtmlTable tblFocuses;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGroupPractices;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGroupPracticeLocations;
		protected NetsoftUSA.InfragisticsWeb.WebGrid GridNetworks;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected int currentMode = 0;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnGroupPracticeID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnGroupPracticeName;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnLocationID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnLocationDescription;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnTypeID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnTypeDescription;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkDescription; // 0 -> Normal Mode, 1 -> Pop-up mode
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnPhone; 
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatus;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatusDescriptionIn;
		
		private PatientCoverage patCov;
		protected NetsoftUSA.WebForms.OBLabel Oblabel12;
		protected System.Web.UI.WebControls.RadioButtonList lstNetworkSearch;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNetwokSearchID;
		protected NetsoftUSA.WebForms.OBComboBox NetwokSearchID;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkInfo;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatusDescriptionOut;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnFlag;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchNameNext;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnPrevious;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;

		// when in popup mode it will cause a postback on calling page when
		// locationitem is dblclicked.
		//To use a static Width across
		private   int  selectWidth = 75;

		private void Page_Load(object sender, System.EventArgs e)
		{

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				// translate manually added text's
				TranslateNames();
				this.LoadData();

			}
			else
			{
				groupPracticeSearch = (GroupPractice)this.LoadObject("objGroupPracticeSearch");  // load object from cache
				resultGroupPracticeLocations = (GroupPracticeLocationCollection)this.LoadObject("objResultGPLocations");  // load object from cache
				resultGroupPractices = (GroupPracticeCollection)this.LoadObject("objResultGPCollection");  // load object from cache
				groupPracticeAddressSearch = (Address)this.LoadObject("objSearchGPAddress");  // load object from cache
				//groupPracticeFocusTypeSearch = (GroupPracticeFocus)this.LoadObject("objSearchGPFocusType");  // load object from cache
				groupPracticeServiceTypeSearch = (GroupPracticeLocationService)this.LoadObject("objSearchGPServiceType");  // load object from cache
				locationSearch = (Location)this.LoadObject("objSearchGPLocationID");  // load object from cache
				groupPracticeLocationSearch = (GroupPracticeLocation)this.LoadObject("objSearchGPLoc");  // load object from cache
				searchNetworkPlanLink = (NetworkPlanLink)this.LoadObject(typeof(NetworkPlanLink),false);
				patCov = (PatientCoverage)this.LoadObject(typeof(PatientCoverage), false);  // load object from cache
				
				searchgpNetworkLink = (GroupPracticeLocationNetworkLink)this.LoadObject(typeof(GroupPracticeLocationNetworkLink));  // load object from cache
				//currentMode	= this.LoadObject("searchGPMode");
			}			

			if (this.HasCallbackFunction)
			{
				if (Request.QueryString["Flag"] == "1")
					hdnFlag.Value = "1";
				else
					hdnFlag.Value = "0";
			}

			CheckNetworkStatus();
		}

		private void LoadData()
		{

			// Will be sent to newsearch later on, to determine which properties should be
			// initialized.
			bool ignoreAddress = false;
			bool ignoreNetwork = false;
			bool ignorePlan	   = false;
			GroupPracticeSearcha				= new GroupPractice();
		
			//GroupPracticeFocusTypeSearch		= new GroupPracticeFocus();
			GroupPracticeServiceTypeSearch		= new GroupPracticeLocationService();
			GroupPracticeLocationSearch			= new GroupPracticeLocation();
			LocationSearch						= new Location();
			//SearchGPNetworkLink					= new GroupPracticeLocationNetworkLink(); 

			object	objCurrentMode				= this.GetParamOrGetFromCache("searchGPMode", "searchGPMode");
			if (objCurrentMode != null)
				currentMode = (int)objCurrentMode;
			this.CacheObject("searchGPMode",currentMode);
			this.pnlResults.Visible = false;
			this.SetSearchFormVisibility(0);	// Search By Name enabled by default
			//this.BlankForm = true;


			
			if (this.HasCallbackFunction)
			{
				this.ResultGroupPracticeLocations = null;
				patCov = this.GetParamOrGetFromCache("PatCov", typeof(PatientCoverage)) as PatientCoverage ;
				this.ClearProviderContext();
							
				if (patCov !=null)
				{
					Address addr					= new Address();
					addr.State						= patCov.Patient.Address.State;
					this.GroupPracticeAddressSearch	= addr;
					ignoreAddress					= true;

					// Network Info
					if (patCov.PlanID != 0)
					{
						string startDate;
						if (Request.QueryString["StartDate"] =="" || Request.QueryString["StartDate"] == null)
							startDate = Convert.ToString(DateTime.Now);
						else
							startDate = Request.QueryString["StartDate"];

						NetworkPlanLink networkPlanLink = new  NetworkPlanLink();
						GroupPracticeLocationNetworkLink gpNetLink = new GroupPracticeLocationNetworkLink ();
						gpNetLink.NetworkSearchID = patCov.GetPlanRelatedNetworkID();
						
						
						if (Request.QueryString["StartDate"] != null && Request.QueryString["StartDate"] != "")
							gpNetLink.EffectiveDate = networkPlanLink.StartDate = DateTime.Parse(startDate);						

						SearchGPNetworkLink = gpNetLink;					
							
						
						ignorePlan = true;														
						ignoreNetwork = true;						
						networkPlanLink.PlanId = patCov.PlanID;
						
						this.SearchNetworkPlanLink  = networkPlanLink;						
						this.lstNetworkSearch.SelectedIndex = 1;
					}
				}
			}
			
				NewSearch(ignoreAddress, ignoreNetwork, ignorePlan);
				//this.pnlResults.Visible = false;
				this.pnlNetworks.Visible = false;
			
		}
		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			Redirect("GroupPracticeSearch.aspx");
		}


		private void TranslateNames()
		{
			this.rdSearchBy.Items[0].Text = this.Language.TranslateSingle("NAME");
			this.rdSearchBy.Items[1].Text = this.Language.TranslateSingle("ID");
			this.lstNetworkSearch.Items[0].Text = this.Language.TranslateSingle("ALLNETWORKS");
			this.lstNetworkSearch.Items[1].Text = this.Language.TranslateSingle("SPECIFIEDNETWORK");

		}
		private void NewSearch()
		{
			this.NewGroupPracticeSearch();
			this.NewGroupPracticeAddressSearch();
			this.NewGroupPracticeServiceSearch();
			this.NewGroupPracticeLocationSearch();
			this.NewGroupPracticeNetworkSearch();
			this.SearchNetworkPlanLink = new NetworkPlanLink();
		}

		private void NewSearch(bool ignoreAddress, bool ignoreNetwork, bool ignorePlan)
		{
			this.NewGroupPracticeSearch();
			if (!ignoreAddress)
				this.NewGroupPracticeAddressSearch();
			this.NewGroupPracticeServiceSearch();
			this.NewGroupPracticeLocationSearch();
			if (!ignoreNetwork)
				this.NewGroupPracticeNetworkSearch();
			if (!ignorePlan)
				this.SearchNetworkPlanLink = new NetworkPlanLink();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			gridGroupPractices.PagingColumns = new string[] { "PKInt", "Name" };
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.rdSearchBy.SelectedIndexChanged += new System.EventHandler(this.rdSearchBy_SelectedIndexChanged);
			this.lstNetworkSearch.SelectedIndexChanged += new System.EventHandler(this.lstNetworkSearch_SelectedIndexChanged);
			this.btnSearchName.Click += new System.EventHandler(this.btnSearchName_Click);
			this.gridGroupPractices.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridGroupPractices_ClickCellButton);
			this.gridGroupPractices.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridGroupPractices_ColumnsBoundToDataClass);
			this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
			this.butSearchNameNext.Click += new System.EventHandler(this.butSearchNameNext_Click);
			this.gridGroupPracticeLocations.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridGroupPracticeLocations_ClickCellButton);
			this.gridGroupPracticeLocations.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.gridGroupPracticeLocations_RowBoundToDataObject);
			this.gridGroupPracticeLocations.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridGroupPracticeLocations_ColumnsBoundToDataClass);
			this.GridNetworks.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.GridNetworks_RowBoundToDataObject);
			this.GridNetworks.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.GridNetworks_ColumnsBoundToDataClass);
			this.DirtyCheckEnabled = false;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Display Specific Items based on Search
			
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
				toolbar.AddButton(OrgMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}
		}
		
        public override void PopulateTabItems(WebTab webTab)
		{
			base.PopulateTabItems (webTab);

			webTab.AddTab("@SEARCH@", "Search");
		}
		
		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewGroupPracticeNetworkSearch()
		{
			bool result = true;
			GroupPracticeLocationNetworkLink gpNetworkLink = new GroupPracticeLocationNetworkLink(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
					gpNetworkLink.New();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			this.SearchGPNetworkLink = gpNetworkLink;
			return result;
		}
					
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewSearch();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			GroupPracticeForm.Redirect(0);
		}
		
		private void SelectGroupPracticeLocation(int GroupPracticeLocationID)
		{
			if (GroupPracticeLocationID != -1)
			{
				GroupPracticeLocation groupPracticeLocation = new  GroupPracticeLocation();
				groupPracticeLocation.Load(GroupPracticeLocationID);
				
				GroupPracticeForm.Redirect(groupPracticeLocation.GroupPracticeID);
			}
		}
		private void btnSearchName_Click(object sender, System.EventArgs e)
		{
			this.gridGroupPractices.ClearValuesForPageStart();
			ReadForm(this.rdSearchBy.SelectedIndex);
		}

		private void rdSearchBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetSearchFormVisibility(rdSearchBy.SelectedIndex);
		}

		private void ReadForm(int searchBy)
		{
			if (searchBy == 1)
			{
				this.UpdateToObject(this.tblID1.Controls, this.groupPracticeSearch, false);
				this.UpdateToObject(this.tblID2.Controls, this.locationSearch, false);
				this.UpdateToObject(this.tblID3.Controls, this.groupPracticeLocationSearch, false);
			}

			else
			{
				// Read To Controls
				this.UpdateToObject(this.tblName.Controls, this.groupPracticeSearch, false); // basic info
				this.UpdateToObject(this.tblGroupPracticeType.Controls,this.groupPracticeSearch,false);
				this.UpdateToObject(this.tblAddress.Controls, this.groupPracticeAddressSearch, false);  // address info
				//this.UpdateToObject(this.tblFocuses.Controls, this.groupPracticeFocusTypeSearch, false);		// focuses
				this.UpdateToObject(this.tblServices.Controls, this.groupPracticeServiceTypeSearch, false);	// services
				this.UpdateToObject(this.tblNetworkInfo.Controls, this.searchgpNetworkLink, false); // network
				
			}
			//GroupPracticeLocationNetworkLink gpNetwork = new GroupPracticeLocationNetworkLink();
			this.GroupPracticeLocationSearch.GroupPracticeID = this.GroupPracticeSearcha.GroupPracticeID;
			this.GroupPracticeServiceTypeSearch.GroupPracticeLocationID = this.groupPracticeServiceTypeSearch.GroupPracticeLocationID = this.GroupPracticeLocationSearch.GroupPracticeLocationID;

			// clear Previous results
			this.gridGroupPractices.ClearRows();
			this.gridGroupPracticeLocations.ClearRows();
			
			if (this.HasCallbackFunction)  // -- In Pop-up mode.
			{
				if (lstNetworkSearch.SelectedValue == "0") // search all networks
				{
					searchgpNetworkLink = new GroupPracticeLocationNetworkLink();
					searchNetworkPlanLink = new NetworkPlanLink();
				}
				Search(this.groupPracticeSearch, this.groupPracticeAddressSearch,this.searchNetworkPlanLink, this.searchgpNetworkLink , this.groupPracticeServiceTypeSearch, this.groupPracticeLocationSearch, this.locationSearch);
			}
			else
			{
				if (lstNetworkSearch.SelectedValue == "0") // search all networks
					SearchGPNetworkLink = new GroupPracticeLocationNetworkLink ();
				// call search 
				Search(this.groupPracticeSearch, this.groupPracticeAddressSearch,this.SearchNetworkPlanLink, this.SearchGPNetworkLink , this.groupPracticeServiceTypeSearch, this.groupPracticeLocationSearch, this.locationSearch);
			}
			
		}

		private void Search(GroupPractice groupPractice, Address address, NetworkPlanLink netPlan, GroupPracticeLocationNetworkLink network, GroupPracticeLocationService service, GroupPracticeLocation gploc, Location loc)
		{
			GroupPracticeCollection gpCol = new GroupPracticeCollection();
			gpCol.SearchGroupPractices(startGroupPracticeId, startName, groupPractice, netPlan, network, service, gploc, loc, address);
			this.ResultGroupPractices = gpCol;
		}

		private void Search(GroupPractice groupPractice, Address address, GroupPracticeLocationNetworkLink network, GroupPracticeLocationService service, GroupPracticeLocation gploc, Location loc)
		{
			Search(groupPractice, address, new NetworkPlanLink(), network, service, gploc, loc);
		}
		
		private void lstNetworkSearch_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			CheckNetworkStatus();			
		}
		
		private void CheckNetworkStatus()
		{
			if (lstNetworkSearch.SelectedValue == "0") // search all networks
			{
				lbNetwokSearchID.Enabled = false;
				NetwokSearchID.Enabled = false;
			}
			else
			{
				lbNetwokSearchID.Enabled = true;
				NetwokSearchID.Enabled = true;
			}
			BindNetworkDropDown();

		}
		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewGroupPracticeAddressSearch()
		{
			bool result = true;
			Address groupPracticeAddressSearch = new Address(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				groupPracticeAddressSearch.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}	
			finally
			{
				// finalization code
			}
			this.GroupPracticeAddressSearch = groupPracticeAddressSearch;
			return result;
		}
		

		private void BindNetworkDropDown()
		{
			
			if (lstNetworkSearch.SelectedValue != "0" && this.patCov != null)
			{
				this.SearchGPNetworkLink.FilterPlanID = this.patCov.PlanID;				
				this.SearchGPNetworkLink.NetworkSearchID = 0;
			}
			if (!this.IsPostBack)
			{
				this.UpdateFromObject(this.tblNetworkInfo.Controls, searchgpNetworkLink);
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
//		public bool NewGroupPracticeFocusTypeSearch()
//		{
//			bool result = true;
//			GroupPracticeFocus searchGroupPracticeFocus = new GroupPracticeFocus(); // use a parameterized constructor which also initializes the data object
//			try
//			{	// or use an initialization method here
//				searchGroupPracticeFocus.New(/* parameters */);
//			}
//			catch(Exception ex)
//			{
//				this.RaisePageException(ex);	// notify the page about the error
//				result = false;
//			}
//			finally
//			{
//				// finalization code
//			}
//			this.GroupPracticeFocusTypeSearch = searchGroupPracticeFocus;
//			return result;
//		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewGroupPracticeServiceSearch()
		{
			bool result = true;
			GroupPracticeLocationService searchGroupPracticeService  = new GroupPracticeLocationService(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchGroupPracticeService.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.GroupPracticeServiceTypeSearch  = searchGroupPracticeService;
			return result;
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewGroupPracticeLocationSearch()
		{
			bool result = true;
			Location groupPracticeLocationSearch = new Location(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				groupPracticeLocationSearch.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.locationSearch = groupPracticeLocationSearch;
			return result;
		}

		private void SetSearchFormVisibility(int selectedIndex)
		{
			switch (selectedIndex)
			{
				default:
				case 0:
					tblID1.Visible = tblID2.Visible	= tblID3.Visible = false;
					tblAddress.Visible = tblGroupPracticeType.Visible = tblName.Visible = tblServices.Visible = true;
					//tblAddress.Visible = tblFocuses.Visible = tblGroupPracticeType.Visible = tblName.Visible = tblServices.Visible = true;
					this.tblNetworkInfo.Visible		= true;
					ClearSearchFields();
					break;
				case 1:
					ClearSearchFields();
					tblID1.Visible = tblID2.Visible	= tblID3.Visible = true;
					tblAddress.Visible = tblGroupPracticeType.Visible = tblName.Visible = tblServices.Visible = false;
					//tblAddress.Visible = tblFocuses.Visible = tblGroupPracticeType.Visible = tblName.Visible = tblServices.Visible = false;
					this.tblNetworkInfo.Visible		= false;
					break;
			}
		}

		private void ClearSearchFields()
		{
			NewSearch(false,true,true);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			if(!this.IsClientScriptBlockRegistered("formLoad"))
			{
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){}\n");
				s.Append("function getGridVals1(){}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
			}
		}

		private void BindGroupPracticeLocations(int groupPracticeID)
		{
			GroupPractice gp = new GroupPractice();
			gp.Load(groupPracticeID);
			
			GroupPracticeLocationCollection gpLocCol = new GroupPracticeLocationCollection();
			if (lstNetworkSearch.SelectedIndex == 1) // if selected Network
				gpLocCol.LoadLocationsWithFilter(this.SearchGPNetworkLink.NetworkID, groupPracticeID, this.GroupPracticeAddressSearch, this.SearchGPNetworkLink.FilterPlanID, this.SearchGPNetworkLink.EffectiveDate);
			else
				gpLocCol.LoadLocationsWithFilter(groupPracticeID,this.GroupPracticeAddressSearch);

			this.ResultGroupPracticeLocations = gpLocCol;
			/*
			FacilityLocationCollection facLocCol = new FacilityLocationCollection();
			if (lstNetworkSearch.SelectedIndex == 1) // if selected Network
				facLocCol.LoadLocationsWithFilter(this.SearchFacilityNetworkLink.NetworkID,providerID,this.searchFacilityAddress, this.SearchFacilityNetworkLink.FilterPlanID);
			else
				facLocCol.LoadLocationsWithFilter(providerID,this.searchFacilityAddress);
			this.LocationSearchResults = facLocCol;
			this.pnlResults2.Visible   = true;			 
			  
			  
			 */

		}
		
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public NetworkPlanLink SearchNetworkPlanLink
		{
			get { return searchNetworkPlanLink; }
			set
			{
				searchNetworkPlanLink = value;
				try
				{
					//this.UpdateFromObject(this.Controls, searchNetworkPlanLink);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(NetworkPlanLink), searchNetworkPlanLink);  // cache object using the caching method declared on the page
			}
		}

		private void gridGroupPractices_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			
			int index = -1;
			if (e.Cell != null)
				index	= (int)e.Cell.Row.DataKey;
			else if (e.Row != null)
				index	= (int)e.Row.DataKey;
			
			if (index != -1)
			{
				try
				{
					BindGroupPracticeLocations(int.Parse(this.ResultGroupPractices.GetAt(index).PKString));
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void gridGroupPracticeLocations_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			int index = -1;
			if (e.Cell != null)
				index = (int)e.Cell.Row.DataKey;
			else if (e.Row != null)
				index = (int)e.Row.DataKey;

			if (index != -1)
			{
				if (currentMode == 0)
				{
					GroupPracticeForm.Redirect(((GroupPracticeLocation)this.ResultGroupPracticeLocations.GetAt(index)).GroupPracticeID);
				}
				else if (currentMode == 1)
					PostBackOpener(index);
			}
			
		}
		
		private void GridNetworks_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction) // if in pop-up mode
			{
				this.GridNetworks.AddColumnWithButtonLook("Pick","@PICK@",0);
			}
		}
		
		private void GridNetworks_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			if (cell != null)
			{
				GroupPracticeLocationNetworkLink link = e.data as GroupPracticeLocationNetworkLink ;
				/*if (this.searchNetworkPlanLink.PlanId == 0)
				{
					
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
				}
				else*/
				e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");

			}			
		}
		
		private string GetPickAllScript(string linkCaption)
		{
			return "<a href='#' onclick=\"window.opener." + this.CallbackFunction + "(getGridVals());window.close();return false;\">" + Language.Translate(linkCaption) + "</a>";
		}

		private void PostBackOpener(int index)
		{
			GroupPracticeProviderLink gpLink = new GroupPracticeProviderLink();
			gpLink.New();
			gpLink.GroupPracticeLocationID	= ((GroupPracticeLocation)this.ResultGroupPracticeLocations.GetAt(index)).GroupPracticeLocationID;
			gpLink.GroupPracticeID			= ((GroupPracticeLocation)this.ResultGroupPracticeLocations.GetAt(index)).GroupPracticeID;
			BasePage.PushParam("providerNewGPLink", gpLink);					  
			Page.RegisterStartupScript("postBackOpener","<script language=\"javascript\">window.opener.__doPostBack(\"\",\"\");window.close();</script>");
		}

		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeLocationNetworkLink SearchGPNetworkLink
		{
			get { return searchgpNetworkLink ; }
			set
			{
				searchgpNetworkLink = value;
				try
				{
					BindNetworkDropDown();  // update controls for the given control collection
					
					//this.UpdateFromObject(this.tblID1.Controls, searchgpNetworkLink);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject("NetworkInfo", searchgpNetworkLink );  // cache object using the caching method declared on the page
				this.CacheObject(typeof(GroupPracticeLocationNetworkLink), searchgpNetworkLink ); 
			}
		}
		
		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearchGPNetworkLink()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblNetworkInfo.Controls, searchgpNetworkLink );	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPractice GroupPracticeSearcha
		{
			get { return groupPracticeSearch; }
			set
			{
				groupPracticeSearch = value;
				try
				{
					this.UpdateFromObject(this.tblName.Controls, groupPracticeSearch);  // update controls for the given control collection
					this.UpdateFromObject(this.tblID1.Controls, groupPracticeSearch);  // update controls for the given control collection
					this.UpdateFromObject(this.tblGroupPracticeType.Controls, groupPracticeSearch);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objGroupPracticeSearch", groupPracticeSearch);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForGroupPracticeSearch()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblName.Controls, groupPracticeSearch);	// controls-to-object
				this.UpdateToObject(this.tblID1.Controls, groupPracticeSearch);
				this.UpdateToObject(this.tblGroupPracticeType.Controls, groupPracticeSearch);
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewGroupPracticeSearch()
		{
			bool result = true;
			GroupPractice groupPracticeSearch = new GroupPractice(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				groupPracticeSearch.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.GroupPracticeSearcha = groupPracticeSearch;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeLocationCollection ResultGroupPracticeLocations
		{
			get { return resultGroupPracticeLocations; }
			set
			{
				resultGroupPracticeLocations = value;
				try
				{
					this.gridGroupPracticeLocations.UpdateFromCollection(resultGroupPracticeLocations);  // update given grid from the collection
					this.gridGroupPracticeLocations.Visible = true;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objResultGPLocations", resultGroupPracticeLocations);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForResultGroupPracticeLocations()
		{
			try
			{	//customize this method for this specific page
				//grid.UpdateToCollection(resultGroupPracticeLocations);	// grid-to-collection
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeCollection ResultGroupPractices
		{
			get { return resultGroupPractices; }
			set
			{
				resultGroupPractices = value;
				try
				{
					this.gridGroupPractices.KeepCollectionIndices = false;
					gridGroupPractices.UpdateFromCollection(resultGroupPractices);  // update given grid from the collection
					this.pnlResults.Visible = true;

					if (this.resultGroupPractices.Count > 0)
					{
						butSearchNameNext.Enabled = ResultGroupPractices.Count >= GroupPracticeCollection.MAXRECORDS;
						btnPrevious.Enabled = gridGroupPractices.HasAnyPreviousPages;

						this.gridGroupPractices.SelectedRowIndex = 0;
						this.BindGroupPracticeLocations(gridGroupPractices.SelectedRowPKInt);
					}
					

					

					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject("objResultGPCollection", resultGroupPractices);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForResultGroupPractices()
		{
			try
			{	//customize this method for this specific page
				//grid.UpdateToCollection(resultGroupPractices);	// grid-to-collection
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}





		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Address GroupPracticeAddressSearch
		{
			get { return groupPracticeAddressSearch; }
			set
			{
				groupPracticeAddressSearch = value;
				try
				{
					this.UpdateFromObject(this.tblAddress.Controls, groupPracticeAddressSearch);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objSearchGPAddress", groupPracticeAddressSearch);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForGroupPracticeAddressSearch()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblAddress.Controls, groupPracticeAddressSearch);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

//		/// <summary>
//		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
//		/// </summary>
//		public GroupPracticeFocus GroupPracticeFocusTypeSearch
//		{
//			get { return groupPracticeFocusTypeSearch; }
//			set
//			{
//				groupPracticeFocusTypeSearch = value;
//				try
//				{
//					//this.UpdateFromObject(this.tblFocuses.Controls, groupPracticeFocusTypeSearch);  // update controls for the given control collection
//					// other object-to-control methods if any
//				}
//				catch(Exception ex)
//				{
//					this.RaisePageException(ex);  // notify the page about the error
//				}
//				//this.CacheObject("objSearchGPFocusType", groupPracticeFocusTypeSearch);  // cache object using the caching method declared on the page
//			}
//		}

//		/// <summary>
//		/// Reads control values into the data object and validates them.  Returns false if there's any problem
//		/// </summary>
//		public bool ReadControlsForGroupPracticeFocusTypeSearch()
//		{
//			try
//			{	//customize this method for this specific page
//				//this.UpdateToObject(this.tblFocuses.Controls, groupPracticeFocusTypeSearch);	// controls-to-object
//				// other control-to-object methods if any
//				return this.IsValid;	// Return validation result
//			}
//			catch(Exception ex)
//			{
//				this.RaisePageException(ex);	// notify the page about the error
//				return false;
//			}
//		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeLocationService GroupPracticeServiceTypeSearch
		{
			get { return groupPracticeServiceTypeSearch; }
			set
			{
				groupPracticeServiceTypeSearch = value;
				try
				{
					this.UpdateFromObject(this.tblServices.Controls, groupPracticeServiceTypeSearch);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objSearchGPServiceType", groupPracticeServiceTypeSearch);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForGroupPracticeServiceTypeSearch()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblServices.Controls, groupPracticeServiceTypeSearch);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Location LocationSearch
		{
			get { return locationSearch; }
			set
			{
				locationSearch = value;
				try
				{
					this.UpdateFromObject(this.tblID2.Controls, locationSearch);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objSearchGPLocationID", locationSearch);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLocationSearch()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblID2.Controls, locationSearch);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeLocation GroupPracticeLocationSearch
		{
			get { return groupPracticeLocationSearch; }
			set
			{
				groupPracticeLocationSearch = value;
				try
				{
					this.UpdateFromObject(this.tblID3.Controls, groupPracticeLocationSearch);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objSearchGPLoc", groupPracticeLocationSearch);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForGroupPracticeLocationSearch()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblID3.Controls, groupPracticeLocationSearch);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}
	
		private void gridGroupPractices_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			this.gridGroupPractices.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;
			if (this.HasCallbackFunction) // if in pop-up mode
			{
				if (Request.QueryString["Flag"] != "1")
				this.gridGroupPractices.AddButtonColumn("Pick","@PICK@",1).Width=45;
			}
		}
		
		private void gridGroupPractices_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
//			int index = -1;
//			if (e.Cell != null)
//				index	= (int)e.Cell.Row.DataKey;
			
			if (e.Cell.Key == "Select") // pop-up mode
			{
				try
				{
					
					this.gridGroupPractices.SelectedRowIndex = e.Cell.Row.Index;
					//SelectProvider();
					
					BindGroupPracticeLocations((int)gridGroupPractices.SelectedRowPK [0]);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				
			}
			else if(e.Cell.Key == "Pick")
			{
				GroupPractice practice = new GroupPractice();
				
				object[] pk = this.gridGroupPractices.GetPKFromCellEvent(e);

				practice.Load((int)pk[0]);
				practice.LoadLocations(false);
				if((practice.Locations.Count != 0)&&(practice.Locations[0] !=null))
					practice.Locations[0].LoadNetworks(false);
				
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){\n");
				s.Append("window.opener.");
				s.Append(this.CallbackFunction);
				s.Append("(getGridVals1());\nwindow.close();\nreturn false;\n}\n");
				s.Append("\n function getGridVals1(){\n");
				s.Append("var o = new Object();\n");
				s.Append("o.GroupPracticeID = \"");
				s.Append(practice.GroupPracticeID.ToString());
				s.Append("\";\n o.GroupPracticeName =\"");
				s.Append(practice.Name);
				s.Append("\";\n o.Flag =\"0");
				
				if((practice.Locations.Count != 0)&&(practice.Locations[0] !=null))
				{
					string startDate;

					if (Request.QueryString["StartDate"]=="")
					{
						startDate = Convert.ToString(DateTime.Now);
					}
					else
						startDate = Request.QueryString["StartDate"];
				

					int status = 0;
					if(patCov !=null)
					{
						status  = (int)practice.Locations[0].GetStatusForGroupPracticeLocationNetworks(patCov.PlanID, Convert.ToDateTime(startDate),practice.Locations[0].LocationID);
						if (patCov.GetPlanRelatedNetworkID() == 0) // Patient Coverage has no networks.
							s.Append("\";\n o.PatCov = \"0");
						else 
							s.Append("\";\n o.PatCov = \"1");
					}
					else
					{
						status = 0;
						s.Append("\";\n o.PatCov = \"0");
					}
					s.Append("\";\n o.LocationID = \"");
					s.Append(practice.Locations[0].LocationID.ToString());
					s.Append("\";\n o.LocationDescription = \"");
					s.Append(practice.Locations[0].ServiceLocation);
					s.Append("\";\n o.PhoneNo	= \"");
					s.Append(practice.Locations[0].Phone);
					s.Append("\";\no.NetworkStatus	=  \"");
					s.Append(status.ToString());
					s.Append("\";\no.NetworkStatusDesc	=  \"");
					if(status == 1)
						s.Append("In");
					else if(status == 0)
						s.Append("Out");
					
				}
				else
				{
					
					s.Append("\";\n o.LocationDescription = \"");
				
					s.Append("\";\n o.PhoneNo	= \"");
					
					s.Append("\";\no.NetworkStatus	= \"");
					s.Append("\";\no.NetworkStatusDesc	=  \"");
				
				}
				
				
				if((practice.Locations.Count !=0) &&(practice.Locations[0] != null))
				{
					if((practice.Locations[0].Networks.Count !=0) && (practice.Locations[0].Networks[0] != null))
					{
						s.Append("\";\n o.NetworkID = \"");
						s.Append(practice.Locations[0].Networks[0].NetworkID.ToString());
						s.Append("\";\n o.NetworkDescription = \"");
						s.Append(practice.Locations[0].Networks[0].Description);
					
					}
					else
					{
						s.Append("\";\n o.NetworkID = \"");
						s.Append("\";\n o.NetworkDescription = \"");
					}
				}
				else
				{
					s.Append("\";\n o.NetworkID = \"");
					s.Append("\";\n o.NetworkDescription = \"");
				}
				s.Append("\";\n return o;}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
			}
//			else
//			{
//				if (e.Cell.Key == "SelectLocation")
//					SelectProviderLocation((int)gridProviderLocations.SelectedRowPK[0]);
//			}
		}
		
		private void gridGroupPracticeLocations_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			//int index = -1;
			//if (e.Cell != null)
			//	index	= (int)e.Cell.Row.DataKey;
			
			if (this.HasCallbackFunction) // pop-up mode
			{
				GroupPracticeLocation gploc = new GroupPracticeLocation();
				
				object[] pk = gridGroupPracticeLocations.GetPKFromCellEvent(e);

				gploc.Load((int)pk[0]);
				//providerloc.Load((int)gridProviderLocations.SelectedRowPK[0]);
				
				
				hdnLocationID.Value = gploc.LocationID.ToString();
				hdnLocationDescription.Value = gploc.ServiceLocation.ToString();
				
				GroupPractice gp= new GroupPractice();
				gp.Load (gploc.GroupPracticeID);
				hdnGroupPracticeID.Value = gploc.GroupPracticeID.ToString();
				hdnGroupPracticeName.Value = gp.Name;
				hdnPhone.Value = gploc.Phone;	
				string startDate;

				if (Request.QueryString["StartDate"]=="")
				{
					startDate = Convert.ToString(DateTime.Now);
				}
				else
					startDate = Request.QueryString["StartDate"];
				

				int status = 0;
				int patCovStatus = 0;
				if(patCov !=null)
				{
					status  = (int)gploc.GetStatusForGroupPracticeLocationNetworks(patCov.PlanID, Convert.ToDateTime(startDate),gploc.LocationID);
					patCovStatus  = patCov.GetPlanRelatedNetworkID();
				}
				else
				{
					status = 0;
				}
				hdnNetworkStatus.Value = status.ToString();
				
				
				if(e.Cell.Key == "SelectLocation")
					BindNetworkSpecialties((int)gridGroupPracticeLocations.SelectedRowPK[0]);
				else
				{
					//pick button is clicked
					gploc.LoadNetworks(false);
					StringBuilder s = new StringBuilder();
					s.Append("<SCRIPT>\n");
					s.Append("function formLoad(){\n");
					s.Append("window.opener.");
					s.Append(this.CallbackFunction);
					s.Append("(getGridVals1());\nwindow.close();\nreturn false;\n}\n");
					s.Append("\n function getGridVals1(){\n");
					s.Append("var o = new Object();\n");
					s.Append("o.GroupPracticeID = \"");
					s.Append(gp.GroupPracticeID.ToString());
					s.Append("\";\n o.PatCov = \"");
					s.Append(patCovStatus.ToString());
					s.Append("\";\n o.GroupPracticeName =\"");
					s.Append(gp.Name);
					//s.Append("\";\n o.Flag =\"0");
					s.Append("\";\n o.LocationID = \"");
					s.Append(gploc.LocationID.ToString());
					s.Append("\";\n o.LocationDescription = \"");
					s.Append(gploc.ServiceLocation);
					s.Append("\";\no.PhoneNo= \"");
					s.Append(gploc.Phone);
					s.Append("\";\no.NetworkStatus=\"");
					s.Append(status.ToString());
					s.Append("\";\no.NetworkStatusDesc=\"");
					if(status == 1)
						s.Append("In");
					else 
						s.Append("Out");
					if((gploc.Networks.Count !=0) && (gploc.Networks[0] != null))
					{
						s.Append("\";\n o.NetworkID = \"");
						s.Append(gploc.Networks[0].NetworkID.ToString());
						s.Append("\";\n o.NetworkDescription = \"");
						s.Append(gploc.Networks[0].Description);
				
					}
					else
					{
						s.Append("\";\n o.NetworkID  = \"");
						s.Append("\";\n o.NetworkDescription  = \" ");
						//s.Append("\";\n o.NetworkID = null;\n");
						//s.Append("o.NetworkDescription = \"");
					}
					s.Append("\";\n return o;}\n");
					s.Append("</SCRIPT>\n");
					this.RegisterClientScriptBlock("formLoad",  s.ToString());
					
				}
			}
			else 
			{
				if (e.Cell.Key == "Edit") //non pop-up mode
				{
					SelectGroupPracticeLocation((int)gridGroupPracticeLocations.SelectedRowPK[0]);
				}
			}
		}

		/// <summary>
		/// Bind the Network for only pop-up mode
		/// </summary>
		/// <param name="facilityLocationID"></param>

		private void BindNetworkSpecialties(int gpLocationID)
		{
			if (gpLocationID != -1)
				this.pnlNetworks.Visible = true;

			// Load FacilityLocatio / Facility
			GroupPracticeLocation  gpl = new GroupPracticeLocation();
			GroupPractice gp = new GroupPractice();
			gpl.Load(gpLocationID);
			gp.Load(gpl.GroupPracticeID);
			
			hdnGroupPracticeID.Value = gpl.GroupPracticeID.ToString();
			hdnGroupPracticeName.Value = gp.Name;
			hdnTypeID.Value = gp.TypeID.ToString();
			hdnTypeDescription.Value = gp.Type ;
			hdnLocationID.Value = gpl.LocationID.ToString();
			hdnLocationDescription.Value = gpl.ServiceLocation.ToString();
			
			// Load Networks/
			gpl.LoadNetworks(false);

			this.GridNetworks.UpdateFromCollection(gpl.Networks);
			if (GridNetworks.Rows.Count > 0)
				GridNetworks.SelectedRowIndex = 0;
		}		


		private void gridGroupPracticeLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction)
			{
				if (Request.QueryString["Flag"] == "1")
				{
					this.gridGroupPracticeLocations.AddColumnWithButtonLook("Pick", "@PICK@", 0).Width = 45;
					this.gridGroupPracticeLocations.ClickEventCommand = null;
				}
				else
				{
					this.gridGroupPracticeLocations.AddButtonColumn("SelectLocation", "@SELECT@", 0).Width = selectWidth;
					this.gridGroupPracticeLocations.ClickEventCommand = "SelectLocation";
					this.gridGroupPracticeLocations.AddButtonColumn("Pick", "@PICK@", 1).Width = 45;
				}
			}
			else
			{
				this.gridGroupPracticeLocations.AddButtonColumn("SelectLocation", "@SELECT@", 0).Width = selectWidth;
			}
		}

		private void gridGroupPracticeLocations_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			if (Request.QueryString["Flag"] =="1")
			{
				try
				{
					UltraGridCell cell = e.row.Cells.FromKey("Pick");
				
					GroupPractice gp = new GroupPractice();
					gp.Load(gridGroupPractices.SelectedRowPKInt);
						
					hdnGroupPracticeID.Value = gp.GroupPracticeID.ToString();
					hdnGroupPracticeName.Value = gp.Name;
					hdnTypeID.Value = gp.TypeID.ToString();
					hdnTypeDescription.Value = gp.Type;
			
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			

		}

		private void butSearchNameNext_Click(object sender, System.EventArgs e)
		{
			SearchNext(true);
			/*
			if (gridGroupPractices.Rows.Count > 0)
			{
				startGroupPracticeId = gridGroupPractices.GetPKIntFromRowIndex(gridGroupPractices.Rows.Count - 1); 
				startName = gridGroupPractices.Rows[gridGroupPractices.Rows.Count - 1].Cells.FromKey("Name").Text;
			}
			ReadForm(this.rdSearchBy.SelectedIndex);*/
		}

		private void btnPrevious_Click(object sender, System.EventArgs e)
		{
			SearchNext(false);
		}

		private bool SearchNext(bool nextPage)
		{
			bool result = true;
			try
			{
				
				object [] valuesForNextPageStart = gridGroupPractices.GetStartValuesForPrevOrNextPage(nextPage);
				if (valuesForNextPageStart == null)	// no more pages.
					return false;
				// use page start to load this set of records.
				startGroupPracticeId = (int)valuesForNextPageStart[0];
				startName   = (string)valuesForNextPageStart[1];
				
				ReadForm(this.rdSearchBy.SelectedIndex);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patients.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
				
			}
			return result;

		}


	}
}
