using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for InterventionTemplateForm.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]	
	[MainDataClass("InterventionTemplate,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("InterventionTemplates")]
	[BackPage(typeof(InterventionTemplateSearch))]
	public class InterventionTemplateForm : AssessmentMaintenanceBasePage
	{
		private LogicCollection selectedLogics;
		private Logic logic;
		private WebLinkCollection selectedWebLinks;
		private WebLinkCollection availableWebLinks;
		private InterventionTemplate interventionTemplate;


		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInterventionTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo InterventionTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInterventionTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPOCGoalTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo POCGoalTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPOCGoalTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPOCDeficitTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo POCDeficitTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPOCDeficitTypeID;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAvailableWebLinks;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSelectedWebLinks;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridAvailableWebLinks;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSelectedWebLinks;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLogic;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSelectedLogics;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSelectedLogics;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddLogic;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDeleteLogic;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		protected LogicSelect LogicSelect1;

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.wbtnAddLogic.Click += new System.EventHandler(this.wbtnAddLogic_Click);
			this.wbtnDeleteLogic.Click += new System.EventHandler(this.wbtnDeleteLogic_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			LogicSelect1.RebindControls(typeof(Logic), "LogicID","Description");

			if (!IsPostBack)
				InitialLoad();
			else
			{
				interventionTemplate = (InterventionTemplate)this.LoadObject(typeof(InterventionTemplate));  // load object from cache
				availableWebLinks = (WebLinkCollection)this.LoadObject(typeof(WebLinkCollection));  // load object from cache
				selectedWebLinks = (WebLinkCollection)this.LoadObject("SelectedWebLinks");  // load object from cache
				logic = (Logic)this.LoadObject(typeof(Logic));  // load object from cache
				selectedLogics = (LogicCollection)this.LoadObject("SelectedLogics");  // load object from cache
			}
		}
		
		private void InitialLoad()
		{
			LoadData(); // Loads InterventionTemplate object
			// Selected MUST be loaded before Availalbe
			LoadDataForSelectedWebLinks();
			LoadDataForAvailableWebLinks(); // Loads and presets Selectable based on SelectedWebLinks

			NewLogic();
			LoadDataForSelectedLogics();
		}

		
		#region Data Objects
		#region InterventionTemplate
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public InterventionTemplate InterventionTemplate
		{
			get { return interventionTemplate; }
			set
			{
				interventionTemplate = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, interventionTemplate);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(InterventionTemplate), interventionTemplate);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, interventionTemplate);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewData()
		{
			bool result = true;
			
			InterventionTemplate interventionTemplate = null; //new InterventionTemplate(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				interventionTemplate = new InterventionTemplate(true);
				
				// below lines are to clear cache and reset grid
				SelectedLogics = new LogicCollection();
				SelectedWebLinks = new WebLinkCollection();	
				LoadDataForAvailableWebLinks();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.InterventionTemplate = interventionTemplate;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			try
			{	// use any load method here
				// pull from the parameter passed to this page via PushParam
				interventionTemplate = GetParamOrGetFromCache("InterventionTemplate", typeof(InterventionTemplate)) as InterventionTemplate;
				if (interventionTemplate == null) 
					//interventionTemplate = new InterventionTemplate(true); // if not passed, create a new data object and init as new
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a Intervention Template");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//interventionTemplate.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.InterventionTemplate = interventionTemplate;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(InterventionTemplate interventionTemplate)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("InterventionTemplate", interventionTemplate);
			BasePage.Redirect("InterventionTemplateForm.aspx");
		}

		public static void Redirect(int interventionTemplateID)
		{
			InterventionTemplate interventionTemplate = new InterventionTemplate();
			if (!interventionTemplate.Load(interventionTemplateID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@INTERVENTIONTEMPLATE@");
			Redirect(interventionTemplateID);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				interventionTemplate.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region AvailableWebLinks
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public WebLinkCollection AvailableWebLinks
		{
			get { return availableWebLinks; }
			set
			{
				availableWebLinks = value;
				try
				{
					gridAvailableWebLinks.UpdateFromCollection(availableWebLinks);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(WebLinkCollection), availableWebLinks);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAvailableWebLinks()
		{
			try
			{	//customize this method for this specific page
				gridAvailableWebLinks.UpdateToCollection(availableWebLinks);	// grid-to-collection
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForAvailableWebLinks()
		{
			bool result = true;
			WebLinkCollection availableWebLinks = new WebLinkCollection();
			try
			{	// use any load method here
				availableWebLinks = WebLinkCollection.ActiveWebLinks; // Selectable Cached collection
				availableWebLinks.SetSelectedWebLinksFromCollection(this.SelectedWebLinks);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//availableWebLinks.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.AvailableWebLinks = availableWebLinks;
			return result;
		}
		#endregion

		#region SelectedWebLinks
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public WebLinkCollection SelectedWebLinks
		{
			get { return selectedWebLinks; }
			set
			{
				selectedWebLinks = value;
				try
				{
					gridSelectedWebLinks.UpdateFromCollection(selectedWebLinks);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("SelectedWebLinks", selectedWebLinks);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForSelectedWebLinks()
		{
			bool result = true;
			WebLinkCollection selectedWebLinks = new WebLinkCollection();
			try
			{	// use any load method here
				this.InterventionTemplate.LoadWebLinks(true);
				selectedWebLinks = this.InterventionTemplate.WebLinks;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//selectedWebLinks.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.SelectedWebLinks = selectedWebLinks;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForSelectedWebLinks()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForAvailableWebLinks())
					return false;
				InterventionTemplate.SaveWebLinks(this.availableWebLinks); 
				AvailableWebLinks = this.availableWebLinks;
				LoadDataForSelectedWebLinks();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region Logic
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Logic Logic
		{
			get { return logic; }
			set
			{
				logic = value;
				try
				{
					this.UpdateFromObject(this.pnlLogic.Controls, logic);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Logic), logic);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLogic()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlLogic.Controls, logic);	// controls-to-object
				if(logic.LogicID == 0)
				{
					this.SetPageMessage("Logic was not selected ", EnumPageMessageType.Error);
					return !this.IsValid;
				}
				else
					return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewLogic()
		{
			bool result = true;
			Logic logic = null; //new Logic(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				logic = new Logic(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Logic = logic;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForLogic()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForLogic())
					return false;
				SelectedLogics.IndexBy_LogicID.Rebuild();
				Logic existing = SelectedLogics.FindBy(this.logic.LogicID);
				if(existing != null) 
				{
					if (!existing.IsMarkedForDeletion)
						this.SetPageMessage("Specified Logic alredy exist", EnumPageMessageType.Error);
					else
						existing.IsMarkedForDeletion = false;
				}
				else
				{	// Adding Logic to Collection 
					//Logic toAdd = Logic.NewFromExisting(this.logic.LogicID);
					SelectedLogics.Add(Logic.NewFromExisting(this.logic.LogicID));
					SelectedLogics = SelectedLogics;			  
					NewLogic();
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region SelectedLogics
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LogicCollection SelectedLogics
		{
			get {return selectedLogics; }
			set
			{
				selectedLogics = value;
				try
				{
					gridSelectedLogics.UpdateFromCollection(selectedLogics);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("SelectedLogics", selectedLogics);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForSelectedLogics()
		{
			bool result = true;
			LogicCollection selectedLogics = new LogicCollection();
			try
			{	// use any load method here
				this.InterventionTemplate.LoadLogics();
				selectedLogics = this.InterventionTemplate.Logics;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//selectedLogics.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.SelectedLogics = selectedLogics;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForSelectedLogics()
		{
			try
			{	// data from controls to object
				InterventionTemplate.SaveLogics(this.SelectedLogics);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion
		#endregion

		#region UI Initialization and Events
		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}
		
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			this.wbtnDeleteLogic.Visible = this.gridSelectedLogics.Rows.Count > 0;
			this.wbtnDeleteLogic.OnClickScript = "if (confirm('Are you sure you want to delete this item?') != true) return false;";
			
			SetPageTabItemEnabled("Logic", !this.interventionTemplate.IsNew);
			SetPageTabItemEnabled("WebLinks", !this.interventionTemplate.IsNew);
		}


		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			if(!this.interventionTemplate.IsNew)
				pageSummary.RenderObjects(this.interventionTemplate);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Details":
					toolbar.AddButton(Messages.BaseMessages.MessageIDs.ADDNEWRECORD, "AddNewInterventionTemplate");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewInterventionTemplate(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewData();
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "Intervention Template "); 
			}
			if(this.InterventionTemplate.IsNew)
				return;
			
			if(SaveDataForSelectedWebLinks() && this.SelectedWebLinks.Count > 0) // do not change order, because SaveDataForSelectedWebLinks() controls SelectedWebLinks
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "WebLinks ");

			if(this.SelectedLogics.Count > 0 && SaveDataForSelectedLogics())
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "Logics ");
		}

		private void wbtnAddLogic_Click(object sender, System.EventArgs e)
		{
			SaveDataForLogic();
		}

		private void wbtnDeleteLogic_Click(object sender, System.EventArgs e)
		{
			if(gridSelectedLogics.SelectedRowIndex < 0)
				return;
			SelectedLogics[gridSelectedLogics.SelectedRowIndex].MarkDel();
			SelectedLogics = SelectedLogics;			  
			NewLogic();
		}		

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(interventionTemplate, selectedWebLinks, selectedLogics);
		}

		#endregion
	}
}
