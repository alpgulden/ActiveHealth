using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using Infragistics.WebUI.UltraWebToolbar;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// This page is called when the user hits Eligibility button in the Intake form.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	VS_PERMISSION
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ELIGIBILITY_SEARCH)]
	
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("EligibilitySearchResult,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MIntake")]
	[PageTitle("@ELIGIBILITYSEARCH@")]
	public class EligibilityMainSearch : BasePage
	{
		private EligibilitySearcher eligibilitySearcher;
		private EligibilityMainResultCollection eligibilityCol;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;		
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMedicaidId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MedicaidId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMedicaidId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMembershipId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MembershipId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMembershipId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberSSN;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit MemberSSN;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberSSN;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberGender;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MemberGender;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberGender;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNameSuffix;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit NameSuffix;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNameSuffix;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMiddleInitial;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRace;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Race;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRace;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMedicareId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MedicareId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMedicareId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateInsuranceID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateInsuranceID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternateInsuranceID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMemberInfo;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAddress;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFaxExtension;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FaxExtension;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFaxExtension;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFax;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fax;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFax;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldWorkPhoneExtension;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WorkPhoneExtension;
		protected NetsoftUSA.WebForms.OBFieldLabel lbWorkPhoneExtension;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldWorkPhoneNumber;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WorkPhoneNumber;
		protected NetsoftUSA.WebForms.OBFieldLabel lbWorkPhoneNumber;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHomePhoneNumber;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit HomePhoneNumber;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHomePhoneNumber;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberCountry;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberCountry;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberCountry;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberCounty;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberCounty;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberCounty;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberPostalCode;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberPostalCode;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberPostalCode;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberState;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberState;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberState;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberCity;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberCity;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberCity;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberAddress3;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberAddress3;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberAddress3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberAddress2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberAddress2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberAddress2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberAddress1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberAddress1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberAddress1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.WebForms.OBLabel Oblabel3;
		protected System.Web.UI.WebControls.RadioButtonList rdEligSearchType;
		protected NetsoftUSA.WebForms.OBLabel lblSortOrder;
		protected NetsoftUSA.WebForms.OBLabel lblSearchField;
		protected NetsoftUSA.WebForms.OBLabel Oblabel4;
		protected NetsoftUSA.WebForms.OBTextBox txtSearchFor;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSearchName;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSortField;
		protected NetsoftUSA.InfragisticsWeb.WebCombo SortField;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLastName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberDOB;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MemberDOB;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberDOB;
		protected NetsoftUSA.WebForms.OBFieldLabel lblMORGId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationId;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganizationSearch;
		protected System.Web.UI.WebControls.Label lblOrganizationName;
		protected System.Web.UI.WebControls.Image butClear;
		protected TBarButton tbbCancel;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				//eligibilityCol = (EligibilityMainResultCollection)this.LoadObject(typeof(EligibilityMainResultCollection));
				eligibilitySearcher = (EligibilitySearcher)this.LoadObject(typeof(EligibilitySearcher));
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("EligibilityMainSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			
			grid.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
			grid.ClickCellButton +=new ClickCellButtonEventHandler(grid_ClickCellButton);			
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.rdEligSearchType.SelectedIndexChanged += new System.EventHandler(this.rdEligSearchType_SelectedIndexChanged);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			try
			{
				FillRadioButton(this.rdEligSearchType);
				if (this.WasCancelled)
				{
					//this.rdEligSearchType.SelectedValue = (string)this.LoadObject("rdEligSearchType");
					//this.EligibilitySearcher= this.LoadObject(typeof(EligibilitySearcher)) as EligibilitySearcher;
					result = this.Search();
				}
				else
				{
					result = this.NewEligibilitySearcher();
					if (!result)
						return false;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patient.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			return result;
		}

		protected override object SaveViewState()
		{
			ViewState["rdEligSearchType"]=this.rdEligSearchType.SelectedIndex;
			return base.SaveViewState ();
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
			this.rdEligSearchType.SelectedIndex=(int)ViewState["rdEligSearchType"];
		}

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			//if (tab.Key == "Search")
			//{
			toolbar.AddButton("@NEWSEARCH@", "NewSearch");
			//}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			tbbCancel = toolbar.AddButton(PatientMessages.MessageIDs.CANCEL, "Cancel").Item;
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			Maintenance.Redirect();
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EligibilitySearcher EligibilitySearcher
		{
			get { return eligibilitySearcher; }
			set
			{
				eligibilitySearcher = value;
				try
				{
					this.UpdateFromObject(pnlSearch.Controls, eligibilitySearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(EligibilitySearcher), eligibilitySearcher);  // cache object using the caching method declared on the page
				//this.CacheObject("rdEligSearchType", this.rdEligSearchType.SelectedValue);
			}
		}		


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EligibilityMainResultCollection EligibilityCol
		{
			get { return eligibilityCol; }
			set
			{
				eligibilityCol = value;
				try
				{	
					grid.UpdateFromCollection(eligibilityCol);	
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject(typeof(EligibilityMainResultCollection), eligibilityCol);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlSearch.Controls, eligibilitySearcher);	// controls-to-object
				//eligibilitySearcher.PrimaryType = Convert.ToInt32(this.rdEligSearchType.SelectedValue);
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		public bool NewEligibilitySearcher()
		{
			bool result = true;
			EligibilitySearcher eligibilitySearcher= new EligibilitySearcher(); // use a parameterized constructor which also initializes the data object
			this.EligibilitySearcher = eligibilitySearcher;
			this.EligibilityCol = null;
			return result;
		}
		

		/*Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}*/

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewEligibilitySearcher();
		}
		

		private void grid_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			//grid.AddButtonColumn("Select", "@SELECT@");
			grid.AddButtonColumn("Edit", "@EDIT@", 0).Width = 50;
		}

		private void grid_ClickCellButton(object sender, CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			switch (e.Cell.Key)
			{
				case "Edit":
				{
					object[] pk = grid.GetPKFromCellEvent(e);
					try
					{
						EligibilityForm.Redirect((int)pk[0]);
					}
					catch(Exception ex)
					{
						this.RaisePageException(ex);
					}
					break;		
				}
			}
		}

		private void rdEligSearchType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if(this.rdEligSearchType.SelectedIndex==1)
			{
				this.LastName.Enabled=false;
				this.FirstName.Enabled=false;
				this.MemberDOB.Enabled=false;
				this.MemberGender.Enabled=false;
				this.lblSortOrder.Visible=false;
				this.lblSearchField.Visible=true;
				this.txtSearchFor.Visible=true;
			}
			else
			{
				this.LastName.Enabled=true;
				this.FirstName.Enabled=true;
				this.MemberDOB.Enabled=true;
				this.MemberGender.Enabled=true;
				this.txtSearchFor.Enabled=false;				
				this.lblSortOrder.Visible=false;
				this.lblSearchField.Visible=true;
			}
			this.EligibilityCol = null;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			if(this.rdEligSearchType.SelectedIndex<=0)
			{
				this.rdEligSearchType.Items[0].Selected = true;
				this.rdEligSearchType.SelectedIndex = 0;
				this.lblSortOrder.Visible=true;
				this.lblSearchField.Visible=false;				
				this.txtSearchFor.Visible=false;
			}
			else
			{
				this.lblSearchField.Visible=true;
				this.lblSortOrder.Visible=false;				
			}		
		}

		private void FillRadioButton(System.Web.UI.WebControls.RadioButtonList radio)
		{
			radio.Items.Clear();
			radio.Items.Add(new ListItem(this.Language.TranslateSingle("PARTIALMATCH"),"PARTIAL"));
			radio.Items.Add(new ListItem(this.Language.TranslateSingle("EXACTMATCH"),"EXACT"));
			radio.SelectedIndex = 0;
		}

		//		private void FillComboBox(NetsoftUSA.WebForms.OBComboBox combo)
		//		{
		//			combo.Items.Add(this.Language.TranslateSingle("MEMBERLASTNAME"));			
		//			combo.Items.Add(this.Language.TranslateSingle("MEMBERFISTNAME"));
		//			combo.Items.Add(this.Language.TranslateSingle("EFFECTIVEDATE"));
		//			combo.Items.Add(this.Language.TranslateSingle("TERMINATIONDATE"));
		//			combo.Items.Add(this.Language.TranslateSingle("MEMBERSSN"));
		//			combo.Items.Add(this.Language.TranslateSingle("SUBSCRIBERSSN"));
		//			combo.Items.Add(this.Language.TranslateSingle("MEMBERSHIPID"));
		//			combo.Items.Add(this.Language.TranslateSingle("ALTSUBSCRIBERID"));
		//			combo.Items.Add(this.Language.TranslateSingle("MEDICAREID"));
		//			combo.Items.Add(this.Language.TranslateSingle("MEDICIDID"));
		//		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		public bool Search()
		{
			bool result=true;
			EligibilityMainResultCollection eligibilityCol = new EligibilityMainResultCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				int maxRows = 200;
				if(this.rdEligSearchType.SelectedIndex==0)
					eligibilityCol.SearchFreeEligibilities(maxRows, eligibilitySearcher);
				else
					eligibilityCol.SearchExactEligibilities(maxRows, eligibilitySearcher, this.SortField.Value.ToString(), this.txtSearchFor.Text);
				if (eligibilityCol.Count >= 200)
					this.SetPageMessage("There may be more than {0} eligibilities.  Refine your search.", EnumPageMessageType.Info, maxRows);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//activities.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.EligibilityCol = eligibilityCol;
			return result;
		}
	}
}
