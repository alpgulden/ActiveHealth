using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PlanMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Plan,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("Search")]						//define the active menu item in side menu
	[SelectedMainMenuItem("MPlan")]						//defines active menu item in main navigation
	public class PlanSearch : PlanBasePage
	{
		private PlanSearcher planSearcher;
		private PlanCollection plans;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMasterOrg;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternatePlanId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternatePlanId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHEDISTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo HEDISTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHEDISTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PlanTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanTypeId;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected System.Web.UI.WebControls.CheckBox chkEffectiveOnly;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternatePlanId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PlanId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanId;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchNext;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchPrevious;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldName;

		private void Page_Load(object sender, System.EventArgs e)
		{
			//grid.Width=Unit.Percentage(100);
			//grid.Height=Unit.Percentage(100);
			//grid.DisplayLayout.FrameStyle.CustomRules = "table-layout:auto";

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.NewPlanSearcher();
			}
			else
			{
				//plans = (PlanCollection)this.LoadObject(typeof(PlanCollection));	// This would reload from cache
				planSearcher = (PlanSearcher)this.LoadObject("PlanSearcher");
			}
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject("PlanSearcher", null);
			base.NavigateAway (targetURL);
		}


		public static void Redirect()
		{
			Redirect("PlanSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			grid.PagingColumns = new string[] { "PKInt" };
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.grid.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.grid_DblClick);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.grid.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.grid_RowBoundToDataObject);
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grid_ColumnsBoundToDataClass);
			this.butSearchPrevious.Click += new System.EventHandler(this.butSearchPrevious_Click);
			this.butSearchNext.Click += new System.EventHandler(this.butSearchNext_Click);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = grid.GetPKFromCellEvent(e);

			if (e.Cell.Key == "Edit")
			{
				try
				{
					PlanForm.Redirect((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void grid_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = grid.GetPKFromClickEvent(e);
				if (pk != null)
					PlanForm.Redirect((int)pk[0]);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Display on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
				toolbar.AddButton(OrgMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}
		}


		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			//toolbar.AddButton("@CANCEL@", "Cancel");
			Infragistics.WebUI.UltraWebToolbar.TBarButton CancelButton = toolbar.AddButton("@CANCEL@", "Cancel").Item;
			if (this.IsPopup)
			{
				CancelButton.Text = this.BaseMessages.CLOSE;
				CancelButton.TargetURL = "javascript:window.close();";
			}
		}

		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.NewPlanSearcher();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PlanForm.Redirect(null);
		}

		public override void PopulateTabItems(WebTab webTab)
		{
			base.PopulateTabItems (webTab);

			webTab.AddTab("@SEARCH@", "Search");
			//webTab.AddTab("@MORG@", "Result");
		}

		public bool Search()
		{
			this.ScrollToControl(pnlResult);
			try
			{	// data from controls to object
				if (!this.ReadControlsForPlan())
					return false;
				PlanCollection plans = new PlanCollection();
				grid.PageStartStack = planSearcher.PageStartStack;
				grid.ClearValuesForPageStart();
				plans.SearchPlans(0, planSearcher);
				this.Plans = plans;
				//PageTab.SelectedTab = 1;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Call this method from anytime you want to search for the next set of plans
		/// </summary>
		public bool SearchNext(PagingDirection direction)
		{
			bool result = true;
			grid.PageStartStack = planSearcher.PageStartStack;

			
			try
			{
				//if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
				//	return false;

				PlanCollection plans = new PlanCollection();

				// Find the last patient that was displayed in the grid.
				object [] valuesForNextPageStart = grid.GetStartValuesForPrevOrNextPage(direction);
				if (valuesForNextPageStart == null)	// no more pages.
					return false;
				// use page start to load this set of records.
				plans.SearchPlans((int)valuesForNextPageStart[0], planSearcher);
				this.Plans = plans;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patients.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PlanCollection Plans
		{
			get { return plans; }
			set
			{
				plans = value;
				try
				{
					grid.KeepCollectionIndices = false;
					grid.UpdateFromCollection(plans);  // update given grid from the collection

					butSearchNext.Enabled = plans != null && plans.Count >= PlanCollection.MAXRECORDS;
					butSearchPrevious.Enabled = grid.HasAnyPreviousPages;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject(typeof(PlanCollection), plans);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PlanSearcher PlanSearcher
		{
			get { return planSearcher; }
			set
			{
				planSearcher = value;
				try
				{
					this.UpdateFromObject(this.pnlSearch.Controls, planSearcher);  // update controls for the given control collection
					if (planSearcher != null)
						chkEffectiveOnly.Checked = planSearcher.EffectiveOnly;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("PlanSearcher", planSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPlan()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSearch.Controls, planSearcher);	// controls-to-object
				if (planSearcher != null)
					planSearcher.EffectiveOnly = chkEffectiveOnly.Checked;
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPlanSearcher()
		{
			bool result = true;
			PlanSearcher plan = null;
			try
			{	// or use an initialization method here
				plan = new PlanSearcher(); // use a parameterized constructor which also initializes the data object
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PlanSearcher = plan;
			return result;
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();		
		}

		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{		
			if (this.HasCallbackFunction)                   // only if this is a popup
			{
				grid.AddColumnWithButtonLook("Detail", "@DETAIL@", 1);
				grid.AddColumnWithButtonLook("Pick", "@PICK@", 1); 
				grid.Columns.FromKey("Edit").Hidden=true;
			}
		}

		private void grid_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			if (!this.HasCallbackFunction) 
				return;

			Plan plan= e.data as Plan;
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			if (cell != null)
			{
				e.row.Cells.FromKey("Pick").Text = this.GetCallbackFunctionHyperLink("Pick", plan.PlanId, plan.Name);
			}

			cell = e.row.Cells.FromKey("Detail");
			if (cell != null)
				cell.Text = String.Format("<a href='#' onclick='return OpenPlan({0});'>{1}</a>", plan.PlanId, "Detail");
		}

		private void butSearchPrevious_Click(object sender, System.EventArgs e)
		{
			SearchNext(PagingDirection.PreviousPage);
		}

		private void butSearchNext_Click(object sender, System.EventArgs e)
		{
			SearchNext(PagingDirection.NextPage);
		}
	}
}
