using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics; 
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]

	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Logic,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(LogicSearch))]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("Logics")]
	[PageTitle("@LOGICSEARCHPAGETITLE@")]
	public class LogicSearch : AssessmentMaintenanceBasePage
	{
		private LogicCollection logics;
		private Logic logic;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpression;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Expression;
		protected NetsoftUSA.WebForms.OBFieldLabel lbExpression;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContentOwnerID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ContentOwnerID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContentOwnerID;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
				NewSearch();		// Use such a method for search pages
			else
			{
				// always load all server side objects from the cache
				logic = (Logic)this.LoadObject(typeof(Logic));  // load object from cache
				//logics = (LogicCollection)this.LoadObject(typeof(LogicCollection));  // load object from cache
			}

		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("LogicSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.grid.DblClick += new ClickEventHandler(grid_DblClick);
			this.grid.ClickCellButton += new ClickCellButtonEventHandler(grid_ClickCellButton);
			this.grid.ColumnsBoundToDataClass+=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
			this.grid.RowBoundToDataObject +=new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(grid_RowBoundToDataObject);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				toolbar.AddButton(AssessmentMessages.MessageIDs.NEWSEARCH, "NewSearch");
				toolbar.AddButton(AssessmentMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			if(this.HasCallbackFunction)
				toolbar.AddButton("@CLOSE@", "Cancel", false).Item.TargetURL = "javascript:window.close();";
			else
				toolbar.AddPreset(ToolbarButtons.Cancel);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Logic Logic
		{
			get { return logic; }
			set
			{
				logic = value;
				try
				{
					this.UpdateFromObject(pnlSearch.Controls, logic);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Logic), logic);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLogic()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlSearch.Controls, logic);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LogicCollection Logics
		{
			get { return logics; }
			set
			{
				logics = value;
				try
				{
					grid.UpdateFromCollection(logics);  // update given grid from the collection
					// other object-to-control methods if any
					if(logics.Count >= LogicCollection.MAXRECORDS)
						this.SetPageMessage("@BIGGERRESULTSET@", EnumPageMessageType.AddInfo, LogicCollection.MAXRECORDS, Messages.AssessmentMessages.MessageIDs.LOGICS);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject(typeof(LogicCollection), logics);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLogics()
		{
			try
			{	//customize this method for this specific page
				grid.UpdateToCollection(logics);	// grid-to-collection
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}





		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewSearch();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			Logic logic = new Logic(true);
			LogicForm.Redirect(logic);
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Edit")
			{
				object[] pk = grid.GetPKFromCellEvent(e);
				try
				{
					LogicForm.Redirect((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void grid_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = grid.GetPKFromClickEvent(e);
				if (pk != null)
					LogicForm.Redirect((int)pk[0]);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			LogicCollection logics = new LogicCollection();
			try
			{
				if (!this.ReadControlsForLogic()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
					logic.LogicTypeID = 2; // Presentation Logic
					/* exec usp_SearchLogics @description = NULL, @logicTypeID = 2, @contentOwnerID = NULL, @expression = NULL
					 * returns 67K records, MUST be limited
					 * */
					logics.SearchLogics(logic);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//logics.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Logics = logics;
			return result;
		}


		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearch()
		{
			bool result = true;
			Logic logic = new Logic(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				logic.SetMembersNull(true, true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Logic = logic;
			return result;
		}

		private void grid_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			if (this.HasCallbackFunction)
				grid.AddColumnWithButtonLook("Pick", "@PICK@", 0);
		}

		private void grid_RowBoundToDataObject(object sender, RowBindingEventArgs e)
		{
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			if (cell != null)
			{
				Logic logic = e.data as Logic;
				e.row.Cells.FromKey("Pick").Text = GetCallbackFunctionHyperLink("Pick", logic.LogicID, logic.Description);
			}
		}
	}
}
