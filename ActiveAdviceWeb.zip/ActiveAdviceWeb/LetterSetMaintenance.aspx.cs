using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterSetMaintenance.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.LETTER_SETUP)]
	
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterSet,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("LetterSet")]
	[PageTitle("@LETTERSETMAINTENANCE@")]
	public class LetterSetMaintenance : LetterMaintenanceBasePage
	{
		private LetterSet letterSet;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMatrixTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MatrixTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMatrixTypeID;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBTextBox Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		private LetterSetCollection letterSets;
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
//            this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
//			this.grid.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(grid_RowBoundToDataObject);
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.AutoScroll = true;
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				LoadData();
			else
			{
				letterSets = (LetterSetCollection)this.LoadObject("LetterSets");  // load object from cache
				letterSet = (LetterSet)this.LoadObject(typeof(LetterSet));  // load object from cache
			}
		}

		private void LoadData()
		{
			if(LoadDataForLetterSets())
			{
				if(this.letterSets.Count > 0)
				{
					this.LetterSet = this.letterSets[0];
					grid.SelectedRowIndex = 0;
				}
				else
					this.NewLetterSet();
			}
		}
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterSetCollection LetterSets
		{
			get { return letterSets; }
			set
			{
				letterSets = value;
				try
				{
					grid.UpdateFromCollection(letterSets);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("LetterSets", letterSets);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForLetterSets()
		{
			bool result = true;
			LetterSetCollection letterSets = new LetterSetCollection();
			try
			{	// use any load method here
				letterSets.LoadAllLetterSets();
				// or pull from the parameter passed to this page via PushParam
				// letterSets = this.GetParam("LetterSetCollection") as LetterSetCollection;
				// if (letterSets == null) letterSets = new LetterSetCollection(true); // if not passed, create a new data object and init as new
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterSets.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterSets = letterSets;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForLetterSets()
		{
			if(this.ReadControlsForLetterSet())
			{
				try
				{	// data from controls to object

					if(this.LetterSet.LetterSetID == 0)
					{	// New Letter Set - Adding
						LetterSets.Add(LetterSet);
						letterSets.Save(); // update or insert to db 
						grid.UpdateFromCollection(LetterSets);
						grid.SelectedRowIndex = grid.Rows.Count - 1;
					}
					else
					{	// Existing Letter Set - updating
						LetterSet.MarkDirty();
						letterSets.Save(); // update or insert to db 
						grid.UpdateFromCollection(LetterSets);
					}
					//NSGlobal.ClearCache(typeof(LetterSetCollection), false);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
					return false;
				}
			}
			return false;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterSet LetterSet
		{
			get { return letterSet; }
			set
			{
				letterSet = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, letterSet);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterSet), letterSet);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLetterSet()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, letterSet);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewLetterSet()
		{
			bool result = true;
			LetterSet letterSet = null; //new LetterSet(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				letterSet = new LetterSet(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.LetterSet = letterSet;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect()
		{
			BasePage.PushCurrentCallingPage();
			BasePage.Redirect("LetterSetMaintenance.aspx");
		}


		public override void OnSetDirty()
		{
			base.OnSetDirty();
			this.CheckForDirty(letterSet);
		}

		#region UI events and initialization
		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}

//		protected override void OnPreRender(EventArgs e)
//		{
//			base.OnPreRender(e); 
//		}

//		public override void RenderPageSummary(PageSummary pageSummary)
//		{
//			
//		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "LetterSet":
					toolbar.AddButton("@ADDNEW@", "AddNew");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.NewLetterSet();
			grid.SelectedRowIndex = -1;
			this.ScrollToControl(pnlDetails);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.SaveDataForLetterSets())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Letter Sets "); 
				grid.UpdateFromCollection(LetterSets);
			}
			this.ScrollToTop();
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			//int index = e.Cell.Row.Index;
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
			{
				//grid.SelectedRowIndex = index;
				//grid.SelectedRowIndex = e.Cell.Row.Index;
				LetterSet = LetterSets[index];
				this.ScrollToControl(pnlDetails);
			}
		}
		#endregion
	}
}
