using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.AUTO_ACTIVITIES_MAINT )]
	
	[MainLanguageClass("ActiveAdvice.Messages.ActivityMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("AutoActivityRule,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@AUTOACTIVITIES@")]
	public class AutoActivityForm : BasePage
	{
		private bool rEdit;
		private bool eEdit;
		private int rtID;
		private AutoActivityRule autoActivityRule;
		private AutoActivityRule autoActivityRuleCombo;
		private AutoActivityRuleCollection autoActivityRuleCol;
		private AutoActivityRuleException autoActivityRuleException;
		private AutoActivityRuleExceptionCollection autoActivityRuleExceptionCol;

     #region Control Definitions

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPlaceHolder2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAutoActivityException;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridActivityRule;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridActivityException;
		protected NetsoftUSA.InfragisticsWeb.WebButton butCloneRule;
		protected NetsoftUSA.InfragisticsWeb.WebButton butNewRule;
		protected NetsoftUSA.InfragisticsWeb.WebButton butActivityRuleValues;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddException;
		protected NetsoftUSA.InfragisticsWeb.WebButton butActivityExceptionValues;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAutoActivityRule;
		protected NetsoftUSA.WebForms.OBLabel Oblabel2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRuleTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRuleId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit RuleId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRuleId;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrimaryDiagEnd;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PrimaryDiagEnd;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimaryDiagEnd;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrimaryDiagStart;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PrimaryDiagStart;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimaryDiagStart;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrimaryDiagCodeType;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PrimaryDiagCodeType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimaryDiagCodeType;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrimaryProcEnd;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PrimaryProcEnd;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimaryProcEnd;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrimaryProcStart;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PrimaryProcStart;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimaryProcStart;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrimaryProcCodeType;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PrimaryProcCodeType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimaryProcCodeType;
		protected System.Web.UI.HtmlControls.HtmlTable tblSORGPlan;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldZipEnd;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ZipEnd;
		protected NetsoftUSA.WebForms.OBFieldLabel lbZipEnd;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldZipStart;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ZipStart;
		protected NetsoftUSA.WebForms.OBFieldLabel lbZipStart;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLastNameEnd;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastNameEnd;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastNameEnd;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLastNameStart;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastNameStart;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastNameStart;
		protected NetsoftUSA.WebForms.OBLabel Oblabel3;
		protected NetsoftUSA.WebForms.OBLabel Oblabel4;
		protected NetsoftUSA.WebForms.OBLabel Oblabel5;
		protected NetsoftUSA.WebForms.OBLabel Oblabel6;
		protected NetsoftUSA.InfragisticsWeb.WebCombo RuleTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanMgmtSvcTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PlanMgmtSvcTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanMgmtSvcTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCMSTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEventServiceCategoryId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EventServiceCategoryId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventServiceCategoryId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDecisionTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DecisionTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDecisionTypeId;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL7;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityNetworkStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityNetworkStatusId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFacilityNetworkStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityNetworkId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityNetworkId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFacilityNetworkId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityFedTaxId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FacilityFedTaxId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFacilityFedTaxId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProviderNetworkStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProviderNetworkStatusId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProviderNetworkStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProviderNetworkId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProviderNetworkId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProviderNetworkId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProviderFedTaxId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ProviderFedTaxId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProviderFedTaxId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferProviderNetworkStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ReferProviderNetworkStatusId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferProviderNetworkStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferProviderNetworkId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ReferProviderNetworkId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferProviderNetworkId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferProviderFedTaxId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ReferProviderFedTaxId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferProviderFedTaxId;
		protected NetsoftUSA.WebForms.OBLabel Oblabel8;
		protected NetsoftUSA.WebForms.OBLabel Oblabel9;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAutoActivityRuleForm;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAARuleMorgPlanFilter;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAARuleDiagProcFilter;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAARuleFacilityFilter;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAARuleProviderFilter;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAARuleReferrerFilter;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlRuleType;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL10;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL11;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL12;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL13;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL14;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL15;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL16;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL17;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExceptionId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ExceptionId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbExceptionId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator33;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit15;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel32;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator27;
		//protected NetsoftUSA.InfragisticsWeb.WebCombo PlanMgmtSvcTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel26;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator28;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ExpCMSTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel27;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpDecisionTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ExpDecisionTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel28;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ExpEventServiceCategoryId;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel30;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator32;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ExpActivityTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel31;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ExpPlanId;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel22;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator23;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ExpSORGId;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel23;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator24;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ExpORGId;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel24;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator25;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ExpMORGId;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel25;
		protected NetsoftUSA.WebForms.OBCheckBox GenerateActivity;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGenerateActivity;
		protected NetsoftUSA.WebForms.OBCheckBox OBCheckBox1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel17;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel18;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator19;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit10;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel19;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator20;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit11;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel20;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator21;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit12;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel21;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator22;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit13;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel33;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAAExceptionReferrerFilter;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAAExceptionProviderFilter;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAAExceptionFacilityFilter;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAAExceptionDiagProcFilter;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAAExceptionMorgPlanFilter;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAutoActivityExceptionForm;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator15;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ExpPrimaryDiagEnd;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel14;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator16;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ExpPrimaryDiagStart;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel15;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator17;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ExpPrimaryDiagCodeType;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel16;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator12;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ExpPrimaryProcEnd;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel11;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator13;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ExpPrimaryProcStart;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel12;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator14;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ExpPrimaryProcCodeType;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel13;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator9;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo5;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel8;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator10;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo6;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel9;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator11;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel10;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator3;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator4;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator5;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator6;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel5;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator7;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo4;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel6;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator8;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel7;
		protected NetsoftUSA.InfragisticsWeb.WebCombo cboRuleTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRuleTypeId;
		protected NetsoftUSA.WebForms.OBLabel lbRule;
		protected NetsoftUSA.WebForms.WindowOpener wo;
		protected NetsoftUSA.WebForms.WindowOpener Windowopener1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferralServiceCategoryId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ReferralServiceCategoryId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralServiceCategoryId;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpReferralServiceCategoryId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ExpReferralServiceCategoryId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator30;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator31;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStateId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Webnumericedit1;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganizationSearch;

		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationId;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganizationSearchExp;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit WebNumericEdit6;
		protected NetsoftUSA.WebForms.WindowOpener ExpPlanWindowOpener;
		protected System.Web.UI.WebControls.Label lblOrganizationName;
		protected System.Web.UI.WebControls.Label lblOrganizationName1;
		protected NetsoftUSA.WebForms.WindowOpener ExpDiagWindowOpener;
		protected NetsoftUSA.WebForms.WindowOpener ExpProcWindowOpener;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNoteTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo NoteTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNoteTypeId;
		protected System.Web.UI.WebControls.Image Image2;
		protected System.Web.UI.WebControls.Image Image3;
		protected System.Web.UI.WebControls.Image Image4;
		protected System.Web.UI.WebControls.Image Image5;
		protected System.Web.UI.WebControls.Image Image6;
		protected System.Web.UI.WebControls.Image Image7;
		protected System.Web.UI.WebControls.Label WebTextEdit14;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStateId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo StateId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator18;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo13;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBFieldLabel lblMORGId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtOrganizationPath;
		protected System.Web.UI.WebControls.Label Label1;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel34;
		protected System.Web.UI.HtmlControls.HtmlTableRow Sorgidrow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Planrow;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected PlanSelect PlanSelect;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSORGId;
		protected System.Web.UI.WebControls.Image butClearOrg;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PlanId;
		protected System.Web.UI.WebControls.Image butClear;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PlanName;
		protected System.Web.UI.WebControls.Label lblPlanOrgError;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpEventServiceCategoryId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpReferralServiceCategoryId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ExpPlanMgmtSvcTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpPlanMgmtSvcTypeId;
		protected NetsoftUSA.WebForms.OBLabel lblAAException;
		protected NetsoftUSA.WebForms.OBLabel lblPatients;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSORGIdExp;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationIdExp;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtOrganizationPathExp;
		protected System.Web.UI.WebControls.Label lblOrganizationNameExp;
		protected System.Web.UI.WebControls.Label lblPlanOrgErrorExp;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpLastNameStart;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ExpLastNameStart;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpLastNameStart;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpLastNameEnd;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ExpLastNameEnd;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpLastNameEnd;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpZipStart;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ExpZipStart;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpZipStart;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpZipEnd;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ExpZipEnd;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpZipEnd;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpStateId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ExpStateId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpStateId;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpPrimaryDiagCodeType;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpPrimaryDiagCodeType;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpPrimaryDiagStart;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpPrimaryDiagStart;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpPrimaryDiagEnd;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpPrimaryDiagEnd;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpPrimaryProcCodeType;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpPrimaryProcCodeType;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpPrimaryProcStart;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpPrimaryProcStart;
		protected NetsoftUSA.WebForms.OBFieldLabel lblExpPrimaryProcEnd;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExpPrimaryProcEnd;
		protected System.Web.UI.HtmlControls.HtmlTable Table10;
		protected System.Web.UI.HtmlControls.HtmlTable Table40;
		protected System.Web.UI.HtmlControls.HtmlTable Table41;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanIdExp;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PlanIdExp;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForPlanIDexception;
		protected System.Web.UI.WebControls.Image Image1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanIdExp;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PlanNameExp;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRuleType;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit RuleType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRuleType;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForPlanID;
#endregion
        
		private void Page_Load(object sender, System.EventArgs e)
		{
			//PlanSelect.RebindControls(typeof(AutoActivityRule), "PlanId" , "PlanName", this.OrganizationId);
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				rEdit=false;
				eEdit=false;
				rtID=0;
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
//				if (this.Cache["rEdit"]!=null)
//					rEdit = bool.Parse(this.Cache["rEdit"].ToString());
//				if (this.Cache["eEdit"]!=null)
//					eEdit = bool.Parse(this.Cache["eEdit"].ToString());
//				if (this.Cache["rtID"]!=null)
//					rtID = int.Parse(this.Cache["rtID"].ToString());
				autoActivityRule = (AutoActivityRule)this.LoadObject(typeof(AutoActivityRule));	// This would reload from cache
				autoActivityRuleCol = (AutoActivityRuleCollection)this.LoadObject(typeof(AutoActivityRuleCollection));	
				autoActivityRuleException = (AutoActivityRuleException)this.LoadObject(typeof(AutoActivityRuleException));	
				autoActivityRuleExceptionCol = (AutoActivityRuleExceptionCollection)this.LoadObject(typeof(AutoActivityRuleExceptionCollection));
			}
		}

		
		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			try
			{	// use any load method here
				autoActivityRuleCol				= this.GetParamOrGetFromCache("AutoActivityRuleCollection", typeof(AutoActivityRuleCollection)) as AutoActivityRuleCollection;
				autoActivityRuleExceptionCol	= this.GetParamOrGetFromCache("AutoActivityRuleExceptionCollection", typeof(AutoActivityRuleExceptionCollection)) as AutoActivityRuleExceptionCollection;

				if (autoActivityRuleCol==null)
				{
					autoActivityRuleCol = new AutoActivityRuleCollection();
					autoActivityRuleCol.LoadAllAutoActivityRules(-1);
					// this code will used if we want to load all exceptions on page load
//					autoActivityRuleExceptionCol =new AutoActivityRuleExceptionCollection();
//					autoActivityRuleExceptionCol.LoadAllAutoActivityRuleExceptions(-1);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//referral.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!			
			}
			this.AutoActivityRuleCol=autoActivityRuleCol;
//			this.AutoActivityRuleExceptionCol=autoActivityRuleExceptionCol;
//			this.REdit = rEdit;
//			this.EEdit = eEdit;
			return result;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			SetRULETYPEID();
			this.butAddException.Enabled=false;
			this.butCloneRule.Enabled=false;
			this.butActivityExceptionValues.Enabled=false;
			this.butActivityRuleValues.Enabled=false;
			SetPageToolbarItemVisible("Save", false);
			SetPageTabToolbarItemVisible("ViewAll",this.pnlAutoActivityRule.Visible);

			if(this.rtID>0)
				this.cboRuleTypeId.DataValue = this.rtID;

			if(autoActivityRuleCol!=null && autoActivityRuleCol.Count>0)
			{
				if(autoActivityRule!=null && this.gridActivityRule.SelectedRowIndex>=0)
				{
					//					this.gridActivityRule.SelectedRowIndex = 0;
					//					this.gridActivityRule.DisplayLayout.ActiveRow.Selected=true;					
					//					this.butAddException.Enabled=true;
					//				}
					//				else
					//				{					
					this.butAddException.Enabled=true;
					//ActiveRow.Selected commentout
					this.gridActivityRule.DisplayLayout.ActiveRow.Selected=true;
					//
					this.butCloneRule.Enabled=true;
					this.butActivityRuleValues.Enabled=true;
				}
				else
				{
					if(this.gridActivityRule.DisplayLayout.ActiveRow!=null)
						this.gridActivityRule.DisplayLayout.ActiveRow.Selected=false;
				}
			}

			if(autoActivityRuleExceptionCol!=null && autoActivityRuleExceptionCol.Count>0)
			{
				if(autoActivityRuleException!=null && this.gridActivityException.SelectedRowIndex>=0)
				{
					//ActiveRow.Selected commentout
					this.gridActivityException.DisplayLayout.ActiveRow.Selected=true;
					//
					this.butActivityExceptionValues.Enabled=true;
				}
				else
				{
					if(this.gridActivityException.DisplayLayout.ActiveRow!=null)
					//ActiveRow.Selected commentout
						this.gridActivityException.DisplayLayout.ActiveRow.Selected=false;
					//
				}
			}

			if((autoActivityRule!=null && autoActivityRule.IsNew) || rEdit || (autoActivityRuleException!=null && autoActivityRuleException.IsNew) || eEdit)
			{
				SetPageToolbarItemVisible("Save", true);
				SetPageToolbarItemVisible("Cancel", true);

//				// empty state combo.
//				if(autoActivityRule!=null && autoActivityRule.StateId==0)
//					this.StateId.Value="";
//				if(autoActivityRuleException!=null && autoActivityRuleException.StateId==0)
//					this.WebCombo13.Value="";

//				//set first item for state
//				if(this.StateId.SelectedIndex<0 && this.StateId.Rows.Count>0)
//				{					
//					this.StateId.Rows[0].Selected=true;
//					this.StateId.SelectedIndex=0;
//				}
//				if(this.WebCombo13.SelectedIndex<0 && this.WebCombo13.Rows.Count>0)
//				{					
//					this.WebCombo13.Rows[0].Selected=true;
//					this.WebCombo13.SelectedIndex=0;
//				}
				//set first item if not selected
				if(this.RuleTypeId.SelectedIndex<0 && this.RuleTypeId.Rows.Count>0)
				{					
					this.RuleTypeId.Rows[0].Selected=true;
					this.RuleTypeId.SelectedIndex=0;
				}

				// Hide fields by Category
				//if(autoActivityRule.RuleTypeId!=0)
				//{
					lbReferralServiceCategoryId.Visible = false;
					ReferralServiceCategoryId.Visible = false;
					lblExpReferralServiceCategoryId.Visible = false;
					ExpReferralServiceCategoryId.Visible=false;
					switch(autoActivityRule.GetRuleTypeCategory(autoActivityRule.RuleTypeId))
					{
						case "EVNT":
						{
							this.lbReferralServiceCategoryId.Visible = false;
							this.ReferralServiceCategoryId.Visible = false;
							this.lblExpReferralServiceCategoryId.Visible = false;
							this.ExpReferralServiceCategoryId.Visible = false;
							this.lbEventServiceCategoryId.Visible = true;
							this.OBFieldLabel30.Visible = true;
							this.EventServiceCategoryId.Visible = true;
							this.ExpEventServiceCategoryId.Visible = true;
							this.lbNoteTypeId.Visible = false;
							this.NoteTypeId.Visible = false;
							this.ActivityTypeId.Enabled=true;
							this.EventServiceCategoryId.Enabled=true;
							this.ExpEventServiceCategoryId.Enabled=true;
							this.DecisionTypeId.Enabled=true;
							this.CMSTypeId.Enabled=true;
							this.PlanMgmtSvcTypeId.Enabled=true;
							this.PrimaryDiagCodeType.Enabled=true;
							this.PrimaryDiagStart.Enabled=true;
							this.PrimaryDiagEnd.Enabled=true;
							this.PrimaryProcCodeType.Enabled=true;
							this.PrimaryProcStart.Enabled=true;
							this.PrimaryProcEnd.Enabled=true;
							this.FacilityFedTaxId.Enabled=true;
							this.FacilityNetworkId.Enabled=true;
							this.FacilityNetworkStatusId.Enabled=true;
							this.ProviderFedTaxId.Enabled=true;
							this.ProviderNetworkId.Enabled=true;
							this.ProviderNetworkStatusId.Enabled=true;
							this.ReferProviderFedTaxId.Enabled=true;
							this.ReferProviderNetworkId.Enabled=true;
							this.ReferProviderNetworkStatusId.Enabled=true;
							//this.WindowOpenerForOrganizationSearch.Visible=true;
							//this.butClear.Visible=true;
							//this.Windowopener2.Visible=true;
							//this.Image1.Visible=true;
							this.wo.Visible=true;
							this.Image2.Visible=true;
							this.Windowopener1.Visible=true;
							this.Image3.Visible=true;
							this.WindowOpenerForOrganizationSearchExp.Visible=true;
							//this.Image4.Visible=true;
							//this.ExpPlanWindowOpener.Visible=true;
							//this.Image5.Visible=true;
							this.ExpDiagWindowOpener.Visible=true;
							this.Image6.Visible=true;
							this.ExpProcWindowOpener.Visible=true;
							this.Image7.Visible=true;
							break;
						}
						case "REF":
						{
							this.lbEventServiceCategoryId.Visible = false;
							this.EventServiceCategoryId.Visible = false;
							this.OBFieldLabel30.Visible = false;
							this.ExpEventServiceCategoryId.Visible = false;
							this.lbReferralServiceCategoryId.Visible = true;
							this.ReferralServiceCategoryId.Visible = true;
							this.lblExpReferralServiceCategoryId.Visible = true;
							this.ExpReferralServiceCategoryId.Visible = true;
							this.lbNoteTypeId.Visible = false;
							this.NoteTypeId.Visible = false;
							this.ActivityTypeId.Enabled=true;
							this.ReferralServiceCategoryId.Enabled=true;
							this.ExpReferralServiceCategoryId.Enabled=true;
							this.DecisionTypeId.Enabled=true;
							this.CMSTypeId.Enabled=true;
							this.PlanMgmtSvcTypeId.Enabled=true;
							this.PrimaryDiagCodeType.Enabled=true;
							this.PrimaryDiagStart.Enabled=true;
							this.PrimaryDiagEnd.Enabled=true;
							this.PrimaryProcCodeType.Enabled=true;
							this.PrimaryProcStart.Enabled=true;
							this.PrimaryProcEnd.Enabled=true;
							this.FacilityFedTaxId.Enabled=true;
							this.FacilityNetworkId.Enabled=true;
							this.FacilityNetworkStatusId.Enabled=true;
							this.ProviderFedTaxId.Enabled=true;
							this.ProviderNetworkId.Enabled=true;
							this.ProviderNetworkStatusId.Enabled=true;
							this.ReferProviderFedTaxId.Enabled=true;
							this.ReferProviderNetworkId.Enabled=true;
							this.ReferProviderNetworkStatusId.Enabled=true;
							//this.WindowOpenerForOrganizationSearch.Visible=true;
							//this.butClear.Visible=true;
							//this.Windowopener2.Visible=true;
							//this.Image1.Visible=true;
							this.wo.Visible=true;
							this.Image2.Visible=true;
							this.Windowopener1.Visible=true;
							this.Image3.Visible=true;
							this.WindowOpenerForOrganizationSearchExp.Visible=true;
							//this.Image4.Visible=true;
							//this.ExpPlanWindowOpener.Visible=true;
							//this.Image5.Visible=true;
							this.ExpDiagWindowOpener.Visible=true;
							this.Image6.Visible=true;
							this.ExpPrimaryProcCodeType.Visible=true;
							this.Image7.Visible=true;
							break;
						}
						case "CMS":
						{
							this.lbReferralServiceCategoryId.Visible = false;
							this.ReferralServiceCategoryId.Visible = false;
							this.lblExpReferralServiceCategoryId.Visible = false;
							this.ExpReferralServiceCategoryId.Visible = false;
							this.lbNoteTypeId.Visible = false;
							this.NoteTypeId.Visible = false;
							this.ActivityTypeId.Enabled=true;
							this.EventServiceCategoryId.Enabled=true;
							this.ExpEventServiceCategoryId.Enabled=true;
							this.DecisionTypeId.Enabled=true;
							this.CMSTypeId.Enabled=true;
							this.PlanMgmtSvcTypeId.Enabled=true;
							this.PrimaryDiagCodeType.Enabled=true;
							this.PrimaryDiagStart.Enabled=true;
							this.PrimaryDiagEnd.Enabled=true;
							this.PrimaryProcCodeType.Enabled=true;
							this.PrimaryProcStart.Enabled=true;
							this.PrimaryProcEnd.Enabled=true;
							this.FacilityFedTaxId.Enabled=true;
							this.FacilityNetworkId.Enabled=true;
							this.FacilityNetworkStatusId.Enabled=true;
							this.ProviderFedTaxId.Enabled=true;
							this.ProviderNetworkId.Enabled=true;
							this.ProviderNetworkStatusId.Enabled=true;
							this.ReferProviderFedTaxId.Enabled=true;
							this.ReferProviderNetworkId.Enabled=true;
							this.ReferProviderNetworkStatusId.Enabled=true;
							//this.WindowOpenerForOrganizationSearch.Visible=true;
						    //this.butClear.Visible=true;
							//this.Windowopener2.Visible=true;
							//this.Image1.Visible=true;
							this.wo.Visible=true;
							this.Image2.Visible=true;
							this.Windowopener1.Visible=true;
							this.Image3.Visible=true;
							this.WindowOpenerForOrganizationSearchExp.Visible=true;
							//this.Image4.Visible=true;
							//this.ExpPlanWindowOpener.Visible=true;
							//this.Image5.Visible=true;
							this.ExpDiagWindowOpener.Visible=true;
							this.Image6.Visible=true;
							this.ExpProcWindowOpener.Visible=true;
							this.Image7.Visible=true;
							break;
						}
						case "ACT":
							break;
						case "NOTE":
							this.lbNoteTypeId.Visible = true;
							this.NoteTypeId.Visible = true;
							this.ActivityTypeId.Enabled=false;						
							this.EventServiceCategoryId.Enabled=false;
							this.OBFieldLabel30.Visible=false;
							this.ExpEventServiceCategoryId.Enabled=false;
							this.lbReferralServiceCategoryId.Visible = false;
							this.ReferralServiceCategoryId.Visible=false;
							this.lblExpReferralServiceCategoryId.Visible = false;
							this.ExpReferralServiceCategoryId.Visible=false;
							this.DecisionTypeId.Enabled=false;						
							this.CMSTypeId.Enabled=false;						
							this.PlanMgmtSvcTypeId.Enabled=false;						
							this.PrimaryDiagCodeType.Enabled=false;						
							this.PrimaryDiagStart.Enabled=false;
							this.PrimaryDiagEnd.Enabled=false;
							this.PrimaryProcCodeType.Enabled=false;
							this.PrimaryProcStart.Enabled=false;						
							this.PrimaryProcEnd.Enabled=false;						
							this.FacilityFedTaxId.Enabled=false;						
							this.FacilityNetworkId.Enabled=false;						
							this.FacilityNetworkStatusId.Enabled=false;						
							this.ProviderFedTaxId.Enabled=false;						
							this.ProviderNetworkId.Enabled=false;						
							this.ProviderNetworkStatusId.Enabled=false;						
							this.ReferProviderFedTaxId.Enabled=false;						
							this.ReferProviderNetworkId.Enabled=false;						
							this.ReferProviderNetworkStatusId.Enabled=false;
							//this.WindowOpenerForOrganizationSearch.Visible=false;
							//this.butClear.Visible=false;
							//this.Windowopener2.Visible=false;
							//this.Image1.Visible=false;
							this.wo.Visible=false;
							this.Image2.Visible=false;
							this.Windowopener1.Visible=false;
							this.Image3.Visible=false;
							this.WindowOpenerForOrganizationSearchExp.Visible=false;
							//this.Image4.Visible=false;
							//this.ExpPlanWindowOpener.Visible=false;
							//this.Image5.Visible=false;
							this.ExpDiagWindowOpener.Visible=false;
							this.Image6.Visible=false;
							this.ExpProcWindowOpener.Visible=false;
							this.Image7.Visible=false;					
							this.PrimaryDiagCodeType.Value="";
							this.PlanMgmtSvcTypeId.Value="";
							this.CMSTypeId.Value="";
							this.DecisionTypeId.Value="";
							this.ReferralServiceCategoryId.Value ="";
							this.ExpReferralServiceCategoryId.Value ="";
							this.EventServiceCategoryId.Value = "";
							this.ExpEventServiceCategoryId.Value = "";
							this.ActivityTypeId.Value = "";
							this.PrimaryDiagStart.Value="";
							this.PrimaryDiagEnd.Value="";
							this.PrimaryProcCodeType.Value="";
							this.PrimaryProcStart.Value="";
							this.PrimaryProcEnd.Value="";
							this.FacilityFedTaxId.Value="";
							this.FacilityNetworkId.Value="";
							this.FacilityNetworkStatusId.Value="";
							this.ProviderFedTaxId.Value="";
							this.ProviderNetworkId.Value="";
							this.ProviderNetworkStatusId.Value="";
							this.ReferProviderFedTaxId.Value="";
							this.ReferProviderNetworkId.Value="";
							this.ReferProviderNetworkStatusId.Value="";
							break;
						case "LTR":
							this.ActivityTypeId.Enabled=false;
							this.EventServiceCategoryId.Enabled=false;
							this.OBFieldLabel30.Visible=false;
							this.ExpEventServiceCategoryId.Enabled=false;
							this.lbReferralServiceCategoryId.Visible = false;
							this.ReferralServiceCategoryId.Visible=false;
							this.lblExpReferralServiceCategoryId.Visible = false;
							this.ExpReferralServiceCategoryId.Visible=false;
							this.DecisionTypeId.Enabled=false;
							this.CMSTypeId.Enabled=false;
							this.PlanMgmtSvcTypeId.Enabled=false;
							this.PrimaryDiagCodeType.Enabled=false;
							this.PrimaryDiagStart.Enabled=false;
							this.PrimaryDiagEnd.Enabled=false;
							this.PrimaryProcCodeType.Enabled=false;
							this.PrimaryProcStart.Enabled=false;
							this.PrimaryProcEnd.Enabled=false;
							this.FacilityFedTaxId.Enabled=false;
							this.FacilityNetworkId.Enabled=false;
							this.FacilityNetworkStatusId.Enabled=false;
							this.ProviderFedTaxId.Enabled=false;
							this.ProviderNetworkId.Enabled=false;
							this.ProviderNetworkStatusId.Enabled=false;
							this.ReferProviderFedTaxId.Enabled=false;
							this.ReferProviderNetworkId.Enabled=false;
							this.ReferProviderNetworkStatusId.Enabled=false;
							this.lbNoteTypeId.Visible = false;
							this.NoteTypeId.Visible = false;
							//this.WindowOpenerForOrganizationSearch.Visible=false;
							//this.butClear.Visible=false;
							//this.Windowopener2.Visible=false;
							//this.Image1.Visible=false;
							this.wo.Visible=false;
							this.Image2.Visible=false;
							this.Windowopener1.Visible=false;
							this.Image3.Visible=false;
							this.WindowOpenerForOrganizationSearchExp.Visible=false;
							//this.Image4.Visible=false;
							//this.ExpPlanWindowOpener.Visible=false;
							//this.Image5.Visible=false;
							this.ExpDiagWindowOpener.Visible=false;
							this.Image6.Visible=false;
							this.ExpProcWindowOpener.Visible=false;
							this.Image7.Visible=false;
							this.ActivityTypeId.Value = "";
							this.EventServiceCategoryId.Value = "";
							this.ExpEventServiceCategoryId.Value = "";
							this.ReferralServiceCategoryId.Value ="";
							this.ExpReferralServiceCategoryId.Value ="";
							this.DecisionTypeId.Value="";
							this.CMSTypeId.Value="";
							this.PrimaryDiagCodeType.Value="";
							this.PrimaryDiagStart.Value="";
							this.PrimaryDiagEnd.Value="";
							this.PrimaryProcCodeType.Value="";
							this.PrimaryProcStart.Value="";
							this.PrimaryProcEnd.Value="";
							this.FacilityFedTaxId.Value="";
							this.FacilityNetworkId.Value="";
							this.FacilityNetworkStatusId.Value="";
							this.ProviderFedTaxId.Value="";
							this.ProviderNetworkId.Value="";
							this.ProviderNetworkStatusId.Value="";
							this.ReferProviderFedTaxId.Value="";
							this.ReferProviderNetworkId.Value="";
							this.ReferProviderNetworkStatusId.Value="";
							break;
						default:
							this.lbReferralServiceCategoryId.Visible = false;
							this.ReferralServiceCategoryId.Visible = false;
							this.lblExpReferralServiceCategoryId.Visible = false;
							this.ExpReferralServiceCategoryId.Visible = false;
							this.lbEventServiceCategoryId.Visible = true;
							this.OBFieldLabel30.Visible = true;
							this.EventServiceCategoryId.Visible = true;
							this.ExpEventServiceCategoryId.Visible = true;
							this.lbNoteTypeId.Visible = false;
							this.NoteTypeId.Visible = false;
							this.ActivityTypeId.Enabled=true;
							this.EventServiceCategoryId.Enabled=true;
							this.ExpEventServiceCategoryId.Enabled=true;
							this.DecisionTypeId.Enabled=true;
							this.CMSTypeId.Enabled=true;
							this.PlanMgmtSvcTypeId.Enabled=true;
							this.PrimaryDiagCodeType.Enabled=true;
							this.PrimaryDiagStart.Enabled=true;
							this.PrimaryDiagEnd.Enabled=true;
							this.PrimaryProcCodeType.Enabled=true;
							this.PrimaryProcStart.Enabled=true;
							this.PrimaryProcEnd.Enabled=true;
							this.FacilityFedTaxId.Enabled=true;
							this.FacilityNetworkId.Enabled=true;
							this.FacilityNetworkStatusId.Enabled=true;
							this.ProviderFedTaxId.Enabled=true;
							this.ProviderNetworkId.Enabled=true;
							this.ProviderNetworkStatusId.Enabled=true;
							this.ReferProviderFedTaxId.Enabled=true;
							this.ReferProviderNetworkId.Enabled=true;
							this.ReferProviderNetworkStatusId.Enabled=true;
							//this.WindowOpenerForOrganizationSearch.Visible=true;
							//this.butClear.Visible=true;
							//this.Windowopener2.Visible=true;
							//this.Image1.Visible=true;
							this.wo.Visible=true;
							this.Image2.Visible=true;
							this.Windowopener1.Visible=true;
							this.Image3.Visible=true;
							this.WindowOpenerForOrganizationSearchExp.Visible=true;
							//this.Image4.Visible=true;
							//this.ExpPlanWindowOpener.Visible=true;
							//this.Image5.Visible=true;
							this.ExpDiagWindowOpener.Visible=true;
							this.Image6.Visible=true;
							this.ExpProcWindowOpener.Visible=true;
							this.Image7.Visible=true;
							break;
					//}
//					this.MORGId.Enabled=false;
//					this.ORGId.Enabled =false;
//					this.SORGId.Enabled =false;
//					this.PlanId.Enabled =false;
					this.PrimaryDiagCodeType.Enabled =false;
					this.PrimaryDiagStart.Enabled =false;
					this.PrimaryDiagEnd.Enabled =false;
					this.PrimaryProcCodeType.Enabled =false;
					this.PrimaryProcStart.Enabled =false;
					this.PrimaryProcEnd.Enabled =false;
					//this.ExpMORGId.Enabled =false;
					//this.ExpORGId.Enabled =false;
					//this.ExpSORGId.Enabled =false;
					//this.ExpPlanId.Enabled =false;
					this.ExpPrimaryDiagCodeType.Enabled =false;
					this.ExpPrimaryDiagStart.Enabled =false;
					this.ExpPrimaryDiagEnd.Enabled =false;
					this.ExpPrimaryProcCodeType.Enabled =false;
					this.ExpPrimaryProcStart.Enabled =false;
					this.ExpPrimaryProcEnd.Enabled =false;
				}
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("AutoActivityForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{   
			this.cboRuleTypeId.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.cboRuleTypeId_SelectedRowChanged);
			this.butNewRule.Click += new System.EventHandler(this.butNewRule_Click);
			this.butCloneRule.Click += new System.EventHandler(this.butCloneRule_Click);
			this.butActivityRuleValues.Click += new System.EventHandler(this.butActivityRuleValues_Click);
			this.gridActivityRule.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridActivityRule_ClickCellButton);
			this.gridActivityRule.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridActivityRule_ColumnsBoundToDataClass);
			this.butAddException.Click += new System.EventHandler(this.butAddException_Click);
			this.butActivityExceptionValues.Click += new System.EventHandler(this.butActivityExceptionValues_Click);
			this.gridActivityException.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridActivityException_ClickCellButton);
			this.gridActivityException.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridActivityException_ColumnsBoundToDataClass);
			this.RuleTypeId.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.RuleTypeId_SelectedRowChanged);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("@VIEWALL@", "ViewAll");
		}

		public void OnToolbarButtonClick_ViewAll(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			autoActivityRuleCol = new AutoActivityRuleCollection();
			autoActivityRuleCol.LoadAllAutoActivityRules(-1);
			this.rtID=0;
			this.AutoActivityRuleCol=autoActivityRuleCol;
			this.cboRuleTypeId.Value="";
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
	
			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@SAVERECORD@", "Save").Visible = false;
			toolbar.AddButton("@CANCEL@", "Cancel").Visible = false;
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			try
			{
				if(autoActivityRule.IsNew || rEdit || autoActivityRuleException.IsNew || eEdit)
				{
					if (SaveDataForAutoActivityRule())
					{
						this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@AUTOACTIVITY@");
					}
				}			
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);				
			}
//				if(autoActivityRule.IsNew || rEdit)
//				{
//					autoActivityRule.LoadAutoActivityInitializationValues(false);
//					if(autoActivityRule.AutoActivityInitializationValues.Count<=0)
//						ActivityValuesForm.Redirect(autoActivityRule,null);
//				}
//				if(autoActivityRuleException!=null && (autoActivityRuleException.IsNew || eEdit))
//				{
//					autoActivityRuleException.LoadAutoActivityInitializationValues(false);
//					if(autoActivityRuleException.AutoActivityInitializationValues.Count<=0)
//						ActivityValuesForm.Redirect(null,autoActivityRuleException);
//				}			
		}

		public void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.pnlRuleType.Visible = true; 
			this.pnlAutoActivityRule.Visible = true; 
			this.pnlAutoActivityException.Visible = true; 

			this.pnlAutoActivityRuleForm.Visible = false;
			this.pnlAARuleMorgPlanFilter.Visible = false;
			this.pnlAARuleDiagProcFilter.Visible = false;
			this.pnlAARuleFacilityFilter.Visible = false;
			this.pnlAARuleProviderFilter.Visible = false;
			this.pnlAARuleReferrerFilter.Visible = false;

			this.pnlAutoActivityExceptionForm.Visible = false;
			this.pnlAAExceptionMorgPlanFilter.Visible = false;
			this.pnlAAExceptionDiagProcFilter.Visible = false;
			this.pnlAAExceptionFacilityFilter.Visible = false;
			this.pnlAAExceptionProviderFilter.Visible = false;
			this.pnlAAExceptionReferrerFilter.Visible = false;
			rEdit=false;
			eEdit=false;
			autoActivityRule = null;
			autoActivityRuleException = null;			
		}

		private void gridActivityRule_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridActivityRule.AddButtonColumn("Edit","EDIT",0);
			gridActivityRule.AddButtonColumn("Select","SELECT",1);
		}

		private void gridActivityException_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridActivityException.AddButtonColumn("Edit","EDIT",0);
			gridActivityException.AddButtonColumn("Select","SELECT",1);
		}

		private void gridActivityRule_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			//string colName = grid.GetColumnKeyFromCellEvent(e);
			string colName = e.Cell.Key;
			if (colName == "Edit")
			{
				int pk =(int)(e.Cell.Row.DataKey);
				try
				{
					autoActivityRule = (AutoActivityRule)autoActivityRuleCol[pk];
					rEdit = true;
					this.AutoActivityRule = autoActivityRule;					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			if (colName == "Select")
			{	
				gridActivityRule.SelectedRowIndex = e.Cell.Row.Index;
				//ActiveRow.Selected commentout
				gridActivityRule.DisplayLayout.ActiveRow.Selected=true;
				//
				int pk =(int)(e.Cell.Row.DataKey);
				try
				{					
					autoActivityRule = (AutoActivityRule)autoActivityRuleCol[pk];
					rEdit = false;
					this.AutoActivityRule = autoActivityRule;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void gridActivityException_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			//string colName = grid.GetColumnKeyFromCellEvent(e);
			string colName = e.Cell.Key;
			if (colName == "Edit")
			{
				int pk =(int)(e.Cell.Row.DataKey);
				try
				{
					autoActivityRuleException = (AutoActivityRuleException)autoActivityRuleExceptionCol[pk];
					eEdit = true;
					this.AutoActivityRuleException = autoActivityRuleException;					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			if (colName == "Select")
			{	
				gridActivityException.SelectedRowIndex = e.Cell.Row.Index;
				//ActiveRow.Selected commentout
				gridActivityException.DisplayLayout.ActiveRow.Selected=true;
				//
				int pk =(int)(e.Cell.Row.DataKey);
				try
				{					
					autoActivityRuleException = (AutoActivityRuleException)autoActivityRuleExceptionCol[pk];
					eEdit = false;
					this.AutoActivityRuleException = autoActivityRuleException;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>	
		public AutoActivityRule AutoActivityRule
		{
			get { return autoActivityRule; }
			set
			{
				autoActivityRule = value;
				try
				{
					if(autoActivityRule==null || (!autoActivityRule.IsNew && !rEdit))
					{
						// show list
						AutoActivityRuleCollection autoActivityRuleCol = new AutoActivityRuleCollection();
						autoActivityRule.LoadAutoActivityRuleExceptions(true);
						autoActivityRuleExceptionCol = autoActivityRule.AutoActivityRuleExceptions;
						this.AutoActivityRuleExceptionCol = autoActivityRuleExceptionCol;

						this.pnlRuleType.Visible = true; 
						this.pnlAutoActivityRule.Visible = true; 
						this.pnlAutoActivityException.Visible = true; 

						this.pnlAutoActivityRuleForm.Visible = false;
						this.pnlAARuleMorgPlanFilter.Visible = false;
						this.pnlAARuleDiagProcFilter.Visible = false;
						this.pnlAARuleFacilityFilter.Visible = false;
						this.pnlAARuleProviderFilter.Visible = false;
						this.pnlAARuleReferrerFilter.Visible = false;

						this.pnlAutoActivityExceptionForm.Visible = false;
						this.pnlAAExceptionMorgPlanFilter.Visible = false;
						this.pnlAAExceptionDiagProcFilter.Visible = false;
						this.pnlAAExceptionFacilityFilter.Visible = false;
						this.pnlAAExceptionProviderFilter.Visible = false;
						this.pnlAAExceptionReferrerFilter.Visible = false;
					}
					else
					{
						// new or edit group
						this.UpdateFromObject(pnlAutoActivityRuleForm.Controls, autoActivityRule);  // update controls for the given control/collection
						this.UpdateFromObject(pnlAARuleMorgPlanFilter.Controls, autoActivityRule);  // update controls for the given control/collection
						this.UpdateFromObject(pnlAARuleDiagProcFilter.Controls, autoActivityRule);  // update controls for the given control/collection
						this.UpdateFromObject(pnlAARuleFacilityFilter.Controls, autoActivityRule);  // update controls for the given control/collection
						this.UpdateFromObject(pnlAARuleProviderFilter.Controls, autoActivityRule);  // update controls for the given control/collection
						this.UpdateFromObject(pnlAARuleReferrerFilter.Controls, autoActivityRule);  // update controls for the given control/collection

						this.pnlRuleType.Visible = false;
						this.pnlAutoActivityRule.Visible = false;
						this.pnlAutoActivityException.Visible = false;

						this.pnlAutoActivityRuleForm.Visible = true;
						this.pnlAARuleMorgPlanFilter.Visible = true;
						this.pnlAARuleDiagProcFilter.Visible = true;
						this.pnlAARuleFacilityFilter.Visible = true;
						this.pnlAARuleProviderFilter.Visible = true;
						this.pnlAARuleReferrerFilter.Visible = true; 

						this.pnlAutoActivityExceptionForm.Visible = false;
						this.pnlAAExceptionMorgPlanFilter.Visible = false;
						this.pnlAAExceptionDiagProcFilter.Visible = false;
						this.pnlAAExceptionFacilityFilter.Visible = false;
						this.pnlAAExceptionProviderFilter.Visible = false;
						this.pnlAAExceptionReferrerFilter.Visible = false;

					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AutoActivityRule), autoActivityRule);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AutoActivityRuleCollection AutoActivityRuleCol
		{
			get { return autoActivityRuleCol; }
			set
			{
				autoActivityRuleCol = value;
				try
				{
					if(this.rtID>0 && autoActivityRuleCol!=null)
						autoActivityRuleCol.LoadAutoActivityRulesByRuleTypeId(-1,(int)this.rtID);

					this.gridActivityRule.UpdateFromCollection(autoActivityRuleCol);
					this.UpdateFromObject(this.pnlAutoActivityRule.Controls,autoActivityRuleCol);	
					// this panel is using to fill combobox
					autoActivityRuleCombo = new AutoActivityRule(false);
					this.UpdateFromObject(this.pnlRuleType.Controls,autoActivityRuleCombo);

					this.pnlRuleType.Visible = true; 
					this.pnlAutoActivityRule.Visible = true; 
					this.pnlAutoActivityException.Visible = true; 

					this.pnlAutoActivityRuleForm.Visible = false;
					this.pnlAARuleMorgPlanFilter.Visible = false;
					this.pnlAARuleDiagProcFilter.Visible = false;
					this.pnlAARuleFacilityFilter.Visible = false;
					this.pnlAARuleProviderFilter.Visible = false;
					this.pnlAARuleReferrerFilter.Visible = false;

					this.pnlAutoActivityExceptionForm.Visible = false;
					this.pnlAAExceptionMorgPlanFilter.Visible = false;
					this.pnlAAExceptionDiagProcFilter.Visible = false;
					this.pnlAAExceptionFacilityFilter.Visible = false;
					this.pnlAAExceptionProviderFilter.Visible = false;
					this.pnlAAExceptionReferrerFilter.Visible = false;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AutoActivityRuleCollection), autoActivityRuleCol);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AutoActivityRuleException AutoActivityRuleException
		{
			get { return autoActivityRuleException; }
			set
			{
				autoActivityRuleException = value;
				try
				{
					if(autoActivityRuleException.RuleType==null)
					{
						AutoActivityRuleType existingRuleType=new AutoActivityRuleType();
						existingRuleType.Load(autoActivityRule.RuleTypeId);
						autoActivityRuleException.RuleType = existingRuleType.Description;
					}
					if(autoActivityRuleException==null || (!autoActivityRuleException.IsNew && !eEdit))
					{
						// show list
						autoActivityRuleExceptionCol = autoActivityRuleException.ParentAutoActivityRuleExceptionCollection;
						this.AutoActivityRuleExceptionCol= autoActivityRuleExceptionCol;

						this.pnlRuleType.Visible = true; 
						this.pnlAutoActivityRule.Visible = true; 
						this.pnlAutoActivityException.Visible = true; 

						this.pnlAutoActivityRuleForm.Visible = false;
						this.pnlAARuleMorgPlanFilter.Visible = false;
						this.pnlAARuleDiagProcFilter.Visible = false;
						this.pnlAARuleFacilityFilter.Visible = false;
						this.pnlAARuleProviderFilter.Visible = false;
						this.pnlAARuleReferrerFilter.Visible = false;

						this.pnlAutoActivityExceptionForm.Visible = false;
						this.pnlAAExceptionMorgPlanFilter.Visible = false;
						this.pnlAAExceptionDiagProcFilter.Visible = false;
						this.pnlAAExceptionFacilityFilter.Visible = false;
						this.pnlAAExceptionProviderFilter.Visible = false;
						this.pnlAAExceptionReferrerFilter.Visible = false;
					}
					else
					{
						// new or edit group
						this.UpdateFromObject(pnlAutoActivityExceptionForm.Controls, autoActivityRuleException);  // update controls for the given control/collection
						this.UpdateFromObject(pnlAAExceptionMorgPlanFilter.Controls, autoActivityRuleException);  // update controls for the given control/collection
						this.UpdateFromObject(pnlAAExceptionDiagProcFilter.Controls, autoActivityRuleException);  // update controls for the given control/collection
						this.UpdateFromObject(pnlAAExceptionFacilityFilter.Controls, autoActivityRuleException);  // update controls for the given control/collection
						this.UpdateFromObject(pnlAAExceptionProviderFilter.Controls, autoActivityRuleException);  // update controls for the given control/collection
						this.UpdateFromObject(pnlAAExceptionReferrerFilter.Controls, autoActivityRuleException);  // update controls for the given control/collection

						this.pnlRuleType.Visible = false;
						this.pnlAutoActivityRule.Visible = false;
						this.pnlAutoActivityException.Visible = false;

						this.pnlAutoActivityRuleForm.Visible = false;
						this.pnlAARuleMorgPlanFilter.Visible = false;
						this.pnlAARuleDiagProcFilter.Visible = false;
						this.pnlAARuleFacilityFilter.Visible = false;
						this.pnlAARuleProviderFilter.Visible = false;
						this.pnlAARuleReferrerFilter.Visible = false;

						this.pnlAutoActivityExceptionForm.Visible = true;
						this.pnlAAExceptionMorgPlanFilter.Visible = true;
						this.pnlAAExceptionDiagProcFilter.Visible = true;
						this.pnlAAExceptionFacilityFilter.Visible = true;
						this.pnlAAExceptionProviderFilter.Visible = true;
						this.pnlAAExceptionReferrerFilter.Visible = true;
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}				
				this.CacheObject(typeof(AutoActivityRuleException), autoActivityRuleException);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AutoActivityRuleExceptionCollection AutoActivityRuleExceptionCol
		{
			get { return autoActivityRuleExceptionCol; }
			set
			{
				autoActivityRuleExceptionCol = value;
				try
				{
//					if(autoActivityRuleExceptionCol!=null && autoActivityRuleExceptionCol.Count>=0)
//					{
//						autoActivityRuleException = autoActivityRuleExceptionCol[0];
//						this.CacheObject(typeof(AutoActivityRuleException), autoActivityRuleException);  // cache object using the caching method declared on the page
//					}
					this.gridActivityException.UpdateFromCollection(autoActivityRuleExceptionCol);
					this.UpdateFromObject(this.pnlAutoActivityException.Controls,autoActivityRuleExceptionCol);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}				
				this.CacheObject(typeof(AutoActivityRuleExceptionCollection), autoActivityRuleExceptionCol);  // cache object using the caching method declared on the page
			}
		}
	
		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAutoActivityRule()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlAutoActivityRuleForm.Controls, autoActivityRule);
				this.UpdateToObject(this.pnlAARuleMorgPlanFilter.Controls, autoActivityRule);
				this.UpdateToObject(this.pnlAARuleDiagProcFilter.Controls, autoActivityRule);
				this.UpdateToObject(this.pnlAARuleFacilityFilter.Controls, autoActivityRule);
				this.UpdateToObject(this.pnlAARuleProviderFilter.Controls, autoActivityRule);
				this.UpdateToObject(this.pnlAARuleReferrerFilter.Controls, autoActivityRule);
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAutoActivityRuleException()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlAutoActivityExceptionForm.Controls, autoActivityRuleException);
				this.UpdateToObject(this.pnlAAExceptionMorgPlanFilter.Controls, autoActivityRuleException);
				this.UpdateToObject(this.pnlAAExceptionDiagProcFilter.Controls, autoActivityRuleException);
				this.UpdateToObject(this.pnlAAExceptionFacilityFilter.Controls, autoActivityRuleException);
				this.UpdateToObject(this.pnlAAExceptionProviderFilter.Controls, autoActivityRuleException);
				this.UpdateToObject(this.pnlAAExceptionReferrerFilter.Controls, autoActivityRuleException);
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(AutoActivityRule autoActivityRule)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("AutoActivityRule", autoActivityRule);
			BasePage.Redirect("AutoActivityForm.aspx");
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForAutoActivityRule()
		{
			try
			{	// data from controls to object
				if(autoActivityRule.IsNew || rEdit)
				{
					if (!this.ReadControlsForAutoActivityRule())
						return false;
					autoActivityRule.Save(); // update or insert to db 
					rEdit = false;
				}
				if(autoActivityRuleException!=null && (autoActivityRuleException.IsNew || eEdit))
				{
					if (!this.ReadControlsForAutoActivityRuleException())
						return false;
					if(autoActivityRuleException.IsNew)
					{
						if(autoActivityRule.AutoActivityRuleExceptions==null)
							autoActivityRule.LoadAutoActivityRuleExceptions(true);
						autoActivityRule.AutoActivityRuleExceptions.AddRecord(autoActivityRuleException);
					}
					autoActivityRule.SaveAutoActivityRuleExceptions(); // update or insert to db 
					autoActivityRuleException = null;
					eEdit = false;	
				}
				this.AutoActivityRule = autoActivityRule;
				autoActivityRuleCol.LoadAllAutoActivityRules(-1);
				this.AutoActivityRuleCol = autoActivityRuleCol;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		protected override object SaveViewState()
		{
			ViewState["rEdit"]=this.rEdit;
			ViewState["eEdit"]=this.eEdit;
			ViewState["rtID"]=this.rtID;
			return base.SaveViewState ();
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
			this.rEdit=(bool)ViewState["rEdit"];
			this.eEdit=(bool)ViewState["eEdit"];
			this.rtID=(int)ViewState["rtID"];		
		}


		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForAutoActivityRuleException()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForAutoActivityRuleException())
					return false;
				AutoActivityRuleException.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		
		private void cboRuleTypeId_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{	
			if(this.cboRuleTypeId!=null && this.cboRuleTypeId.DataValue!=null && this.cboRuleTypeId.DataValue!="")
			{
				this.rtID=(int)this.cboRuleTypeId.DataValue;
			}
			else
			{
				this.rtID = 0;
			}			
			this.AutoActivityRuleCol = autoActivityRuleCol;
		}

//		private void RuleTypeId_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
//		{	
//			if(this.RuleTypeId!=null && this.RuleTypeId.DataValue!=null && this.RuleTypeId.DataValue!="")
//			{
//				switch(autoActivityRule.RuleTypeCategory)
//				{
//					case "EVNT":
//						this.category = 
//						breake;
//					case "REF":
//						breake;
//					case "CMS":
//						breake;
//					case "ACT":
//						breake;
//					case "NOTE":
//						breake;
//					case "LTR":
//						breake;
//				}
//				this.hiddenType=(int)this.RuleTypeId.DataValue;
//			}
//			else
//			{
//				this.RULETYPEID = 0;
//			}			
//			this.AutoActivityRuleCol = autoActivityRuleCol;
//		}		
//		
		public void SetRULETYPEID()		
		{
			if(this.rtID>0)
			{
				this.cboRuleTypeId.DataValue = this.rtID;
				//this.DAGroupID.DisplayValue = this.GroupIDDA;
			}
//			else
//			{
//				if(this.cboRuleTypeId.Rows.Count>0)
//				{					
//					this.cboRuleTypeId.Rows[0].Selected=true;
//					this.cboRuleTypeId.SelectedIndex=0;
//					this.RULETYPEID = 0;
//				}
//			}
		}

		private void butNewRule_Click(object sender, System.EventArgs e)
		{
			NewAutoActivityRule();
		}

		public bool NewAutoActivityRule()
		{
			bool result = true;
			try
			{	
				AutoActivityRule autoActivityRule = new AutoActivityRule(true); // use a parameterized constructor which also initializes the data object				
				rEdit = false;
				this.AutoActivityRule = autoActivityRule;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}			
			return result;
		}

		private void butAddException_Click(object sender, System.EventArgs e)
		{
			//// if exception is sperate page use
			//AutoActivityRuleException autoActivityRuleException = new autoActivityRuleException(true);			
			//AutoActivityExceptionForm.Redirect(autoActivityRuleException,false);
			//is not
			NewActivityRuleException();
		}

		public bool NewActivityRuleException()
		{
			bool result = true;
			try
			{	
				autoActivityRule = (AutoActivityRule)autoActivityRuleCol[this.gridActivityRule.SelectedRowIndex];
				this.AutoActivityRule = autoActivityRule;
				AutoActivityRuleException autoActivityRuleException = new AutoActivityRuleException(true); // use a parameterized constructor which also initializes the data object				
				eEdit = false;
				this.AutoActivityRuleException = autoActivityRuleException;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			return result;
		}

		private void butActivityRuleValues_Click(object sender, System.EventArgs e)
		{
			if(autoActivityRule!=null)
				ActivityValuesForm.Redirect(autoActivityRule,null);
		}

		private void butActivityExceptionValues_Click(object sender, System.EventArgs e)
		{
			if(autoActivityRuleException!=null)
				ActivityValuesForm.Redirect(null,autoActivityRuleException);
		}

		private void RuleTypeId_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			//this.Page_Load(sender,e);
		}


//		private void butCloneRule_Click(object sender, System.EventArgs e)
//		{
//			AutoActivityRule autoActivityRuleClone;
//			if(autoActivityRule!=null && !autoActivityRule.IsNew)
//			{
//				autoActivityRuleClone = (AutoActivityRule)autoActivityRule.Clone(true);
//				autoActivityRuleClone.Save();
//				autoActivityRuleCol.LoadAllAutoActivityRules(-1);
//				this.AutoActivityRuleCol = autoActivityRuleCol;
//			}
//		}

		private void butCloneRule_Click(object sender, System.EventArgs e)
		{

			if (autoActivityRule!=null && this.ReadControlsForAutoActivityRule())
			{
				try
				{
					AutoActivityRule sourceClass = new AutoActivityRule(false);
					sourceClass.Load(autoActivityRuleCol[gridActivityRule.SelectedRowIndex].RuleId);
					// creating clone object
					AutoActivityRule autoActivityRuleClone = sourceClass.CreateCopyOfRule();

					// save
					if(autoActivityRuleClone.IsNew)
					{
						autoActivityRuleClone.SaveClone();
						autoActivityRuleCol.LoadAllAutoActivityRules(-1);
						this.AutoActivityRuleCol = autoActivityRuleCol;
						this.SetPageMessage("@AUTOACTIVITYCLONEMSG@", EnumPageMessageType.Info, "@AUTOACTIVITY@");
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}
	}
}
