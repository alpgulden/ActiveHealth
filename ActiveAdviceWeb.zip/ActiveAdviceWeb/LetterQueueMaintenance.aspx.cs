using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Text;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterQueueMaintanence.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseLetterQueue,DataLayer")]	
	[PageTitle("@LETTERQUEUEPAGETITLE@")]
	public class LetterQueueMaintenance : PatientBasePage
	{
		private BaseLetterQueue baseLetterQueueSearcher;
		private BaseLetterQueueCollection letterQueues;
		private const string NOTSET = "";
		
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrganizationId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationId;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganization;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtOrganizationPath;
		protected System.Web.UI.WebControls.Label lblOrganizationPath;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSearch;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnReset;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridNonPrinted;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridPrinted;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridDraft;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDelete;
		protected System.Web.UI.WebControls.RadioButtonList rblDateFilter;
		protected PlanSelect PlanSelect1;
		protected Printer printerTo;

		private bool adminMode = false; //TRUE - if page accessed by administrator; FALSE - from user context, Patient object is set
		private Patient patient;
		private BaseForEventCMSReferral erc;

		object isEnvelope = null;
		object isDuplex = null;

		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnResetSelection;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtPatientName;
		protected System.Web.UI.WebControls.RadioButtonList rblQueueTypeFilter;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateFrom;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DateFrom;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDateFrom;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateTo;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DateTo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDateTo;
		protected NetsoftUSA.WebForms.OBLabel AssignedUser;

		protected TeamUserSelect TeamUserSelect1;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnReRunBatch;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnRunBatch;
		protected System.Web.UI.WebControls.Image butClearPatient;
		protected System.Web.UI.WebControls.Image butClearOrganization;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForPatient;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PatientID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatus;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBComboBox PrinterID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrinterID;
		protected NetsoftUSA.WebForms.OBLabel lblGridResultCount;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSendToPrintQueue;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnNonPrintedReport;

		private int totalLetterCount = 0; 
		
		public int TotalLetterCount
		{
			get { if (ViewState["totalLetterCount"] == null) ViewState["totalLetterCount"] = 0; return (int)ViewState["totalLetterCount"];}
			set { ViewState["totalLetterCount"] = value; }
		}
	
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.rblQueueTypeFilter.SelectedIndexChanged += new System.EventHandler(this.rblQueueTypeFilter_SelectedIndexChanged);
			this.wbtnDelete.Click += new System.EventHandler(this.wbtnDelete_Click);
			this.wbtnReset.Click += new System.EventHandler(this.wbtnReset_Click);
			
			this.wbtnSearch.Click += new System.EventHandler(this.wbtnSearch_Click);
			this.wbtnSendToPrintQueue.Click += new System.EventHandler(this.wbtnSendToPrintQueue_Click);
			this.wbtnRunBatch.Click += new System.EventHandler(this.wbtnRunBatch_Click);
			this.wbtnReRunBatch.Click += new EventHandler(wbtnReRunBatch_Click);

			this.gridDraft.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
			this.gridNonPrinted.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
			this.gridPrinted.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);

			this.gridDraft.ClickCellButton += new ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.gridNonPrinted.ClickCellButton += new ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.gridPrinted.ClickCellButton += new ClickCellButtonEventHandler(this.grid_ClickCellButton);

			this.gridDraft.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(grid_RowBoundToDataObject);
			this.gridNonPrinted.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(grid_RowBoundToDataObject);
			this.gridPrinted.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(grid_RowBoundToDataObject);

			this.ValidationsOnlyInSummary = true;

			// This has to be done before Page Load
			if (!this.IsPostBack)
				this.LoadDataForPatient();

			this.Load += new System.EventHandler(this.Page_Load);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.wbtnNonPrintedReport.Click += new System.EventHandler(this.wbtnNonPrintedReport_Click);
			this.AutoScroll = true;
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			//LetterGenerator letGen = new LetterGenerator();
			//letGen.ProcessQueue();

			this.TeamUserSelect1.RebindControls(typeof(BaseLetterQueue), "TeamID", "UserID");
			PlanSelect1.RebindControls(typeof(BaseLetterQueue), "PlanID", "PlanName");

			if (!this.IsPostBack)
			{
				BindQueueTypeFilterOptions();
				SetUIState(); 
				BindDateFilterOptions();
				NewBaseLetterQueueSearcher();
				NewLetterQueues();
				NewPrintTo();
			}
			else
			{
				adminMode = (bool)this.LoadObject("adminMode");  // load object from cache
				letterQueues = (BaseLetterQueueCollection)this.LoadObject(typeof(BaseLetterQueueCollection));  // load object from cache
				baseLetterQueueSearcher = (BaseLetterQueue)this.LoadObject("LetterQueueSearcher");  // load object from cache
				if(!adminMode)
				{
					patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
					erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache
				}
				
				isDuplex = this.LoadObject("IsDuplex");
				isEnvelope = this.LoadObject("IsEnvelope");

				// load the printer in memory
				printerTo = (Printer)this.LoadObject("PrinterTo");  // load object from cache
//				this.PrinterTo = printerTo;	
			}		

			if(isDuplex != null && ((bool)isDuplex))
			{
				this.SelectedSideMenuItem = "DuplexLetterQueue";
			}
			else if(isEnvelope != null && ((bool)isEnvelope))
			{
				this.SelectedSideMenuItem = "EnvelopeLetterQueue";
			}
			else
				this.SelectedSideMenuItem = "LetterQueue";

			if (adminMode)
				this.SelectedMainMenuItem = "MMaintenance";
			else
				this.SelectedMainMenuItem = "MPatient";


		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, BaseForEventCMSReferral erc)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("ERC", erc);
			BasePage.Redirect("LetterQueueMaintenance.aspx");
		}


		public static void Redirect(Patient patient, BaseForEventCMSReferral erc, object isDuplex, object isEnvelope)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("ERC", erc);
			BasePage.PushParam("IsDuplex", isDuplex);
			BasePage.PushParam("IsEnvelope", isEnvelope);
			BasePage.Redirect("LetterQueueMaintenance.aspx");
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			if (!adminMode)
				base.PopulateSubNavigation (listbar);
			else
			{
				LetterMaintenanceBasePage.PopulateSubNavigationItems(listbar);
			}
		}

		public void OnSubNavigationItemClick_LetterSet(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("LetterSetMaintenance.aspx");
		}


		public void OnSubNavigationItemClick_LetterMatrix(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("LetterMatrixSearch.aspx");
		}

		public void OnSubNavigationItemClick_LetterTemplate(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("LetterTemplateSearch.aspx");
		}

		public void OnSubNavigationItemClick_AssessmentLetterMaintenance(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("AssessmentLetterSearch.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect()
		{
			BasePage.PushCurrentCallingPage();
			BasePage.Redirect("LetterQueueMaintenance.aspx");
		}

		#region UI initialization and events
		private void SetUIState()
		{

		}


		protected override void OnPreRender(EventArgs e)
		{
			this.RenderClientFunctions(typeof(BaseLetterQueue), this.pnlSearch.Controls, this.BaseLetterQueueSearcher, "DateVerification");
			
			if (adminMode)
			{
				WindowOpenerForPatient.Enabled = true;	
				butClearPatient.Attributes["OnClick"] = "setPatientID('', '');";
			}
			else
			{
				WindowOpenerForPatient.Enabled = false;
				butClearPatient.Attributes["OnClick"] = "return false;";
			}

					
			// Display the send to Print Queue button only for Draft Queue
			this.wbtnSendToPrintQueue.Visible = this.SelectedQueueTypeFilter == LetterQueueType.Draft;
			// Disable it if there's no record in the grid
			this.wbtnSendToPrintQueue.Enabled = gridDraft.Rows.Count > 0;

			// Letter Generate Batch permission make sense only while in NotPrinted or Printed queue mode
			this.wbtnRunBatch.Visible =	((this.SelectedQueueTypeFilter == LetterQueueType.NotPrinted || this.SelectedQueueTypeFilter == LetterQueueType.Printed) && adminMode && AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_GENERATE_BATCH));
			// Disable if there's no record in the grid
			this.wbtnRunBatch.Enabled = gridNonPrinted.Rows.Count > 0 || gridPrinted.Rows.Count > 0;
 
			// Letter Generate Re-Batch permission make sense only while in Printed queue mode
			this.wbtnReRunBatch.Visible = (this.SelectedQueueTypeFilter == LetterQueueType.Printed && adminMode && AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_GENERATE_BATCH));
			// Do this on server side because we need to get the printerId as well
			//this.wbtnReRunBatch.OnClickScript = "javascript: return ReRunBatch();";

			// The Non-Printed Report must be visible only to admins
			this.wbtnNonPrintedReport.Visible = adminMode;

			// Generation and Print Date distinction exists only in Printed Queue
			this.rblDateFilter.Visible = this.SelectedQueueTypeFilter == LetterQueueType.Printed;
		
			// Delete option is available only for the draft and non-printed queues	
			this.wbtnDelete.Visible = (this.SelectedQueueTypeFilter == LetterQueueType.NotPrinted || this.SelectedQueueTypeFilter == LetterQueueType.Draft);
			this.wbtnDelete.Enabled = (wbtnSendToPrintQueue.Enabled || wbtnRunBatch.Enabled);

			lblGridResultCount.Visible = (gridNonPrinted.Rows.Count > 0 || gridPrinted.Rows.Count > 0);
			if (this.TotalLetterCount >= BaseLetterQueueCollection.MAXRECORDS)
				lblGridResultCount.Text = this.Language.Translate("@ITEMINQUEUEANDTOTAL@", BaseLetterQueueCollection.MAXRECORDS, this.TotalLetterCount);
			else
				lblGridResultCount.Text = this.Language.Translate("@ITEMINQUEUEANDTOTAL@",this.TotalLetterCount, this.TotalLetterCount);


			if (!this.IsClientScriptBlockRegistered("formLoad"))
			{
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
			}

			if (!AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_SETUP))
				this.gridDraft.EditButton = false;

			if (isDuplex != null && ((bool)isDuplex))
				this.PageTitle = "@DUPLEX@ " + this.PageTitle;
			else if (isEnvelope != null && ((bool)isEnvelope))
				this.PageTitle = "@ENVELOPE@ " + this.PageTitle;



			if(baseLetterQueueSearcher.OrganizationId > 0)
			{
				Organization o = new Organization();
				if (o.Load(baseLetterQueueSearcher.OrganizationId))
					this.lblOrganizationPath.Text = CreateOrgPathHTML(null, o);
			}
			else
				this.lblOrganizationPath.Text = "";

			if(!adminMode)
			{
				this.baseLetterQueueSearcher.PatientID = this.patient.PatientId;
				this.txtPatientName.Text = this.patient.Fmt_FullName;
				this.PatientID.Value 	 = this.patient.PatientId;
			}

			base.OnPreRender(e);
		}


		protected override void Render(HtmlTextWriter writer)
		{
			base.Render (writer);
		}


		private void BindQueueTypeFilterOptions()
		{
			rblQueueTypeFilter.Items.Clear();
			rblQueueTypeFilter.Items.Add(new ListItem("Not Printed", LetterQueueType.NotPrinted.ToString()));
			rblQueueTypeFilter.Items.Add(new ListItem("Printed", LetterQueueType.Printed.ToString()));
			if (isEnvelope == null || !((bool)isEnvelope))
				rblQueueTypeFilter.Items.Add(new ListItem("Drafts", LetterQueueType.Draft.ToString()));
			rblQueueTypeFilter.SelectedIndex = 0;
		}

		private LetterQueueType SelectedQueueTypeFilter
		{
			get { return (LetterQueueType)Enum.Parse(typeof(LetterQueueType), this.rblQueueTypeFilter.SelectedValue, true); }
		}

		private void BindDateFilterOptions()
		{
			rblDateFilter.Items.Clear();
			rblDateFilter.Items.Add(new ListItem("Generation Date", LetterPrintedQueueDateType.Generation.ToString()));
			rblDateFilter.Items.Add(new ListItem("Printed Date", LetterPrintedQueueDateType.Printed.ToString()));
			rblDateFilter.SelectedIndex = 0;
		}

		private LetterPrintedQueueDateType SelectedDateFilter
		{
			get { return (LetterPrintedQueueDateType)Enum.Parse(typeof(LetterPrintedQueueDateType), this.rblDateFilter.SelectedValue, true); }
		}

		
		private void rblQueueTypeFilter_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetUIState();
			NewBaseLetterQueueSearcher();
			NewLetterQueues();
		}

	
		private void wbtnSearch_Click(object sender, System.EventArgs e)
		{
			DoSearch();
		}

		private void DoSearch()
		{
			if(this.ReadControlsForBaseLetterQueueSearcher())
			{
				if(!LoadDataForLetterQueues()) // Loads from Search
					return;

				this.BaseLetterQueueSearcher = this.baseLetterQueueSearcher;
				this.LetterQueues = this.letterQueues;
			}
		}

		private void wbtnReset_Click(object sender, System.EventArgs e)
		{
			NewBaseLetterQueueSearcher();
			NewLetterQueues();
		}

		/// <summary>
		/// 1) Creates sorted collection of letters to be printed from selected letters
		/// 2) Saves collection into [LetterPrintedQueue] table with assigned BatchNumber & BatchRunDate
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void wbtnSendToPrintQueue_Click(object sender, System.EventArgs e)
		{
			if(!ReadControlsForLetterQueues())
				return;
			try
			{
				BaseLetterQueueCollection col = LetterQueueClassFactory.CreateLetterQueueCollectionFromCollection(SelectedQueueTypeFilter);

				// BDS - one line change
				// Printer printerTo = new Printer();
				// printerTo.New();
				//printerTo.PrinterID = this.

				col.CreateFromCollectionAndSave(this.letterQueues, true /* override */, true /* Print */, this.printerTo /* printer change */, true);

				this.letterQueues.Save();
				LetterQueues = this.letterQueues;
			}
			catch(Exception ex)
			{	this.RaisePageException(ex); }
		}

		private void wbtnDelete_Click(object sender, System.EventArgs e)
		{
			if (!ReadControlsForLetterQueues())
				return;

			if(this.letterQueues is LetterDraftQueueCollection)
			{
				(this.letterQueues as LetterDraftQueueCollection).DeleteSelectedAndSave();
				LetterQueues = this.letterQueues;
			}
			else if(this.letterQueues is LetterNonPrintedQueueCollection)
			{
				(this.letterQueues as LetterNonPrintedQueueCollection).DeleteSelectedAndSave();
				LetterQueues = this.letterQueues;
			}

		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			//toolbar.AddPreset(ToolbarButtons.Cancel);
		}
		
		#endregion

		#region BaseLetterQueueSearcher
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BaseLetterQueue BaseLetterQueueSearcher
		{
			get { return baseLetterQueueSearcher; }
			set
			{
				baseLetterQueueSearcher = value;
				try
				{
					this.UpdateFromObject(this.pnlSearch.Controls, baseLetterQueueSearcher);  // update controls for the given control collection
					// other object-to-control methods if any

				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("LetterQueueSearcher", baseLetterQueueSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForBaseLetterQueueSearcher()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSearch.Controls, baseLetterQueueSearcher);	// controls-to-object
				// other control-to-object methods if any
				if(baseLetterQueueSearcher is LetterPrintedQueue)
				{
					(baseLetterQueueSearcher as LetterPrintedQueue).DateTypeFilter = this.SelectedDateFilter;
				}
				Page.Validate();
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		public void NewBaseLetterQueueSearcher()
		{
			BaseLetterQueue letterQueue = null;
			try
			{
				letterQueue = LetterQueueClassFactory.CreateLetterQueue(SelectedQueueTypeFilter, false);
				this.lblOrganizationPath.Text = "All";
				this.txtPatientName.Text = "";

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
			this.BaseLetterQueueSearcher = letterQueue;
		}
		#endregion

		#region LetterQueues
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BaseLetterQueueCollection LetterQueues
		{
			get { return letterQueues; }
			set
			{
				letterQueues = value;
				try
				{
					switch (SelectedQueueTypeFilter)
					{
						case LetterQueueType.NotPrinted:
							gridNonPrinted.UpdateFromCollection(letterQueues);  // update given grid from the collection
							gridNonPrinted.Visible = true;
							gridPrinted.ClearRows();
							gridPrinted.Visible = false;
							gridDraft.ClearRows();
							gridDraft.Visible = false;
							break;
						case LetterQueueType.Printed:
							gridNonPrinted.ClearRows();
							gridNonPrinted.Visible = false;
							gridPrinted.UpdateFromCollection(letterQueues);  // update given grid from the collection
							gridPrinted.Visible = true;
							gridDraft.ClearRows();
							gridDraft.Visible = false;
							break;
						case LetterQueueType.Draft:
							gridNonPrinted.ClearRows();
							gridNonPrinted.Visible = false;
							gridPrinted.ClearRows();
							gridPrinted.Visible = false;
							gridDraft.UpdateFromCollection(letterQueues);  // update given grid from the collection
							gridDraft.Visible = true;
							break;
					}
	
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(BaseLetterQueueCollection), letterQueues);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLetterQueues()
		{
			try
			{
				this.ReadControlsForPrintTo();
				//customize this method for this specific page

				switch (SelectedQueueTypeFilter)
				{
					case LetterQueueType.NotPrinted:
						gridNonPrinted.UpdateToCollection(letterQueues);	// grid-to-collection
						break;
					case LetterQueueType.Printed:
						gridPrinted.UpdateToCollection(letterQueues);	// grid-to-collection
						break;
					case LetterQueueType.Draft:
						gridDraft.UpdateToCollection(letterQueues);	// grid-to-collection
						break;
				}

				Page.Validate();
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		public void NewLetterQueues()
		{
			BaseLetterQueueCollection letterQueues = null;
			try
			{
				letterQueues = LetterQueueClassFactory.CreateLetterQueueCollectionForSearch(SelectedQueueTypeFilter);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
			this.LetterQueues = letterQueues;
		}
		
		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForLetterQueues()
		{
			bool result = true;
			BaseLetterQueueCollection letterQueues = null;
			try
			{	// use any load method here
				letterQueues = LetterQueueClassFactory.CreateLetterQueueCollectionForSearch(SelectedQueueTypeFilter);

				// Fix: We don't want pre-selected checkboxes
				// if (this.adminMode)
				//	letterQueues.PreSelect = true;
				if (baseLetterQueueSearcher is LetterPrintedQueue)
					this.TotalLetterCount = ((LetterPrintedQueue)this.baseLetterQueueSearcher).GetLetterCount(isDuplex, isEnvelope);
				else if (baseLetterQueueSearcher is LetterNonPrintedQueue)
					this.TotalLetterCount  = ((LetterNonPrintedQueue)this.baseLetterQueueSearcher).GetLetterCount(isDuplex, isEnvelope);
				else if (baseLetterQueueSearcher is LetterDraftQueue)
					this.TotalLetterCount  = ((LetterDraftQueue)this.baseLetterQueueSearcher).GetLetterCount(isDuplex, isEnvelope);

				letterQueues.GetFromSearch(this.baseLetterQueueSearcher, isDuplex, isEnvelope);

//				if(letterQueues != null && letterQueues.Count >= BaseLetterQueueCollection.MAXRECORDS)
//					this.SetPageMessage("@BIGGERRESULTSET@", EnumPageMessageType.AddInfo, BaseLetterQueueCollection.MAXRECORDS, "@QUEUEITEM@");

				letterQueues.PreSelect = false;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterQueues.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterQueues = letterQueues;
			return result;
		}
		
		#endregion


		#region printer propety

		public Printer PrinterTo
		{
			get { return printerTo; }
			set
			{
				printerTo = value;
				try
				{
					this.UpdateFromObject(this.pnlGridHolder.Controls, printerTo);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}

				this.CacheObject("PrinterTo", printerTo);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPrintTo()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlGridHolder.Controls, printerTo);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
			this.CacheObject("PrinterTo", printerTo);
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPrintTo()
		{
			bool result = true;
			Printer printerTo = new Printer(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				printerTo.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PrinterTo = printerTo;
			return result;
		}
		#endregion

		#region Patient
		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForPatient()
		{
			bool result = true;
			Patient patient = null;
			BaseForEventCMSReferral erc = null;
			try
			{	// use any load method here
				patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				erc = GetParamOrGetFromCache("ERC", typeof(BaseForEventCMSReferral)) as BaseForEventCMSReferral;

				isEnvelope = GetParamOrGetFromCache("IsEnvelope", "IsEnvelope");
				isDuplex = GetParamOrGetFromCache("IsDuplex", "IsDuplex");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patient.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			
			this.patient = patient;
			this.erc = erc;

			// If there is no patient context this is admin mode
			adminMode = (patient == null);

			this.CacheObject(typeof(Patient), patient);  // cache object using the caching method declared on the page
			this.CacheObject(typeof(BaseForEventCMSReferral), erc);

			this.CacheObject("adminMode", adminMode);

			this.CacheObject("IsDuplex", isDuplex);
			this.CacheObject("IsEnvelope", isEnvelope);
			

			return result;
		}
		#endregion

		private void wbtnRunBatch_Click(object sender, System.EventArgs e)
		{
			this.ReadControlsForPrintTo();
			this.RegisterStartupScript("runbatch", "<SCRIPT>\nRunBatch();</SCRIPT>\n");
		}

		private void wbtnReRunBatch_Click(object sender, EventArgs e)
		{
			this.ReadControlsForPrintTo();
			this.RegisterStartupScript("rerunbatch", "<SCRIPT>\nReRunBatch();</SCRIPT>\n");
		}


		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			int index = 1;

			// Draft grid has the extra edit column
			if (((WebGrid)sender).ID == this.gridDraft.ID)
				index = 2;

			if (!((WebGrid)sender).Columns.Exists("Fax"))
				((WebGrid)sender).AddButtonColumn("Fax", "@FAX@", index);
			if (!((WebGrid)sender).Columns.Exists("Print"))
				((WebGrid)sender).AddButtonColumn("Print", "@PRINTLETTER@", index);
			if (!((WebGrid)sender).Columns.Exists("Preview"))
				((WebGrid)sender).AddColumnWithButtonLook("Preview", "@PREVIEWLETTER@", index);
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			this.ReadControlsForPrintTo();

			string colName = e.Cell.Key;

			int index = -1;
			
			index = ((WebGrid)sender).GetColIndexFromCellEvent(e);

			switch (colName)
			{
				case "Edit":
				{
					try
					{
						if(index < 0)
							return;
						// Redirect to Letter edit page
						LetterForm.Redirect(patient, erc, (LetterDraftQueue)this.letterQueues[index]);
					}
					catch(Exception ex)
					{
						this.RaisePageException(ex);
					}
					break;
				}
				case "Preview":

					break;

				case "Print":
				{
					try
					{
						// read printer seting
						this.ReadControlsForPrintTo();

						BaseLetterQueueCollection col = null;
						BaseLetterQueueCollection tmpCol = null;
							
						if (letterQueues is LetterPrintedQueueCollection)
						{
							((LetterPrintedQueue)this.letterQueues[index]).PrinterID = this.printerTo.PrinterID;
							((LetterPrintedQueue)this.letterQueues[index]).Status = LetterPrintedQueueStatus.Pending;
							((LetterPrintedQueue)this.letterQueues[index]).Delivery = true;
							((LetterPrintedQueue)this.letterQueues[index]).Save();

							LoadDataForLetterQueues();
						}
						else
						{
							if (letterQueues is LetterDraftQueueCollection)
							{
								// BDS - need more work here
								col = LetterQueueClassFactory.CreateLetterQueueCollectionFromCollection(LetterQueueType.Draft);	
								tmpCol = new LetterDraftQueueCollection();
							}
							else
							{
								col = LetterQueueClassFactory.CreateLetterQueueCollectionFromCollection(LetterQueueType.NotPrinted);	
								tmpCol = new LetterNonPrintedQueueCollection();
							}

							this.letterQueues[index].Selected = true;
							tmpCol.AddRecord(this.letterQueues[index]);

							col.CreateFromCollectionAndSave(tmpCol, true /* override */, true /* Print */, this.printerTo /* printer */, false);
							
							this.letterQueues.Save();
							
							DoSearch();
						}
					}
					catch(Exception ex)
					{	this.RaisePageException(ex); }

					break;
				}

				case "Fax":
				{
					try
					{
						WebGrid thisGrid = null;
						Debug.Assert(letterQueues != null);
						if (letterQueues is LetterDraftQueueCollection)
						{
							thisGrid = this.gridDraft;
						}
						else if (letterQueues is LetterNonPrintedQueueCollection)
						{
							thisGrid = this.gridNonPrinted;
						}
						else if (letterQueues is LetterPrintedQueueCollection)
						{
							thisGrid = this.gridPrinted;
						}
						Debug.Assert(thisGrid != null);

						if (index >= 0)
							FaxForm.Redirect(this.letterQueues[index]);
					}
					catch(Exception ex)
					{
						this.RaisePageException(ex);
					}
					break;
				}


			}
		}

		private void grid_RowBoundToDataObject(object sender, RowBindingEventArgs e)
		{
			BaseLetterQueue qItem = e.data as BaseLetterQueue;
			UltraGridCell cell = null;
			cell = e.row.Cells.FromKey("Preview");
			if (cell != null)
			{
				cell.Text = String.Format("<a href=\"#\" onclick=\"javascript:PreviewLetter({0},'{1}'); return false;\">{2}</a>", qItem.QueueID, this.rblQueueTypeFilter.SelectedValue, Language.Translate("@PREVIEWLETTER@"));
			}

// Requirements have changed
// Print button no longer prints locally it's supposed to send to print queue
//			if (this.SelectedQueueTypeFilter == LetterQueueType.Draft)
//			{
//				cell = e.row.Cells.FromKey("Print");
//				if (cell != null)
//				{
//					cell.Text = String.Format("<a href=\"#\" onclick=\"javascript:PrintLetter({0},'{1}'); return false;\">{2}</a>", qItem.QueueID, this.rblQueueTypeFilter.SelectedValue, Language.Translate("@PRINTLETTER@"));
//				}
//			}
		}

		private void wbtnNonPrintedReport_Click(object sender, System.EventArgs e)
		{
			this.CacheObject("ReportName", "RPTNONPRINTEDSUM");
			this.RegisterStartupScript("nonprintedreport",  "<script>ViewNonPrintedReport();\n</script>");
		}

	}
}
