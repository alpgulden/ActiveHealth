using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using Infragistics.WebUI.UltraWebToolbar;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Search patients
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("PatientSearcher,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Search")]
	public class PatientSearch : PatientBasePage
	{
		private BaseCollectionForEventCMSReferral ercCollection;
		private PatientSearchResultCollection patients;
		private PatientSearcher patientSearcher;
		private IntakeLog intakeLog;								// this is set when the patient search is opened from intake-log
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel GridTitle;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.WebForms.OBLabel SearchTitle;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLastName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PatientId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDateOfBirth;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DateOfBirth;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateOfBirth;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit SocialSecurityNumber;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSocialSecurityNumber;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSocialSecurityNumber;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PatientAlternateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAuthorizationID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit AuthorizationID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAuthorizationID;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchAuthorizationID;
		protected NetsoftUSA.WebForms.OBRadioButtonBox ercFilterOption;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAltAuthorizationID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AltAuthorizationID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAltAuthorizationID;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchAltAuthID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlERCs;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridERCs;
		protected System.Web.UI.HtmlControls.HtmlTable tblAuthorizationSearch;
		protected NetsoftUSA.WebForms.SimpleRecordNavigator navBottom;
		protected TBarButton tbbCancel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				//note: "asdMemberId" is used for Aetna Proof of Concept
				if( (Request.Params["asdMemberId"] != null) && (Request.Params["asdMemberId"].Length > 0) )
				{
					try
					{
						PatientSummaryForm.Redirect(Convert.ToInt32(Request.Params["asdMemberId"]));
					}
					catch(Exception ex)
					{
						this.RaisePageException(ex);
					}
				
				}
				else
				{
					BindERCFilterOptions();
					LoadData();
				}
			}
			else
			{
				// always load all server side objects from the cache
				patientSearcher = (PatientSearcher)this.LoadObject("PatientSearcher");  // load object from cache
				intakeLog = (IntakeLog)this.LoadObject(typeof(IntakeLog));
				// FORK 1.1.B
				if (patientSearcher != null)
					grid.PageStartStack = patientSearcher.PageStartStack;
				// END FORK 1.1.B
			}
		}

		private void BindERCFilterOptions()
		{
			ercFilterOption.Items.Clear();
			ercFilterOption.Items.Add(new ListItem(PatientMessages.EVENT, EnumERCType.Event.ToString()));
			ercFilterOption.Items.Add(new ListItem(PatientMessages.CMS, EnumERCType.CMS.ToString()));
			ercFilterOption.Items.Add(new ListItem(PatientMessages.REFERRAL, EnumERCType.Referral.ToString()));
			ercFilterOption.SelectedIndex = 0;
		}

		/// <summary>
		/// Called when the page is first loaded.
		/// </summary>
		/// <returns></returns>
		public bool LoadData()
		{
			bool result = true;
			try
			{
				// check if the patient search is called in the intake-log context.
				intakeLog = this.GetParam("IntakeLog") as IntakeLog;
				this.CacheObject(typeof(IntakeLog), intakeLog);		// cache the intake-log context so that we'll get it in the next post back
				if (intakeLog == null && this.WasCancelled)
				{
					this.PatientSearcher = (PatientSearcher)this.LoadObject("PatientSearcher");	// if not in intakelog context, load the previous patient searcher
				}
				
				if (this.patientSearcher != null)
				{
					result = this.SearchNext(PagingDirection.PreviousPage);
				}
				else
				{
					result = this.NewPatientSearch();
					if (!result)
						return false;
				}

				// automatically invoke search.
				if (intakeLog != null)
				{
					patientSearcher = new PatientSearcher(intakeLog);
					//this.patientSearcher.SocialSecurityNumber = intakeLog.PatientSSN;
					//this.patientSearcher.FirstName = intakeLog.PatientFName;
					//this.patientSearcher.LastName = intakeLog.PatientLName;
					this.PatientSearcher = patientSearcher;
					result = this.SearchForIntake();
					tblAuthorizationSearch.Visible = false;
				}
				else
				{
					//this.Patients = null;
					this.ERCCollection = null;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				result = false;
			}
			return result;
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("PatientSearch.aspx");
		}

		/// <summary>
		/// Redirect to search page in the intake-log context.
		/// </summary>
		public static void Redirect(IntakeLog intakeLog)
		{
			BasePage.PushParam("IntakeLog", intakeLog);
			BasePage.Redirect("PatientSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			this.navBottom.ClickNext += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(this.navBottom_ClickNext);
			this.navBottom.ClickPreviousPage += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(this.navBottom_ClickPreviousPage);
			this.navBottom.ClickPrevious += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(this.navBottom_ClickPrevious);
			this.navBottom.ClickFirst += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(this.navBottom_ClickFirst);
			this.navBottom.ClickNextPage += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(this.navBottom_ClickNextPage);
			this.navBottom.ClickLast += new NetsoftUSA.WebForms.SimpleRecordNavigator.SimpleRecordNavigatorEventHandler(this.navBottom_ClickLast);

			grid.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
			grid.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(grid_RowBoundToDataObject);
			grid.ClickCellButton +=new ClickCellButtonEventHandler(grid_ClickCellButton);
			grid.PagingColumns = new string[] { "PKInt", "LastName", "FirstName" };

			gridERCs.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridERCs_ColumnsBoundToDataClass);
			gridERCs.ClickCellButton +=new ClickCellButtonEventHandler(gridERCs_ClickCellButton);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.butSearchAuthorizationID.Click += new System.EventHandler(this.butSearchAuthorizationID_Click);
			this.butSearchAltAuthID.Click += new System.EventHandler(this.butSearchAltAuthID_Click);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.ViewStateOnServer = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				if (this.intakeLog != null)
					toolbar.AddButton("@BACKTOINTAKE@", "Cancel");
				toolbar.AddButton(PatientMessages.MessageIDs.NEWSEARCH, "NewSearch"); //.Item.TargetURL ="javascript:window.alert('hi')";
				//toolbar.AddButton(PatientMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}

			// Menu items to be displayed on all tabs
		}

		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewPatientSearch();
		}

//		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
//		{
//			base.RemovePatientContext();
//			if (this.intakeLog != null)
//			{
//				intakeLog.CreateNewPatientWithThisCoverage();
//				PatientForm.Redirect(intakeLog);
//			}
//			else
//				PatientForm.Redirect((Patient)null);
//		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			if (this.intakeLog == null)
				Search();
			else
				SearchForIntake();
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.intakeLog != null)
			{
				// in intake-log context.  Go back to intake page.
				IntakeForm.Redirect(intakeLog);
			}
			else
				base.OnToolbarButtonClick_Cancel(toolbar, button);
		}
		
		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			tbbCancel = toolbar.AddButton(PatientMessages.MessageIDs.CANCEL, "Cancel").Item;
			
			if (this.IsPopup)
			{
				tbbCancel.Text = this.BaseMessages.CLOSE;
				tbbCancel.TargetURL = "javascript:window.close();";
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientSearcher PatientSearcher
		{
			get { return patientSearcher; }
			set
			{
				patientSearcher = value;
				try
				{
					this.UpdateFromObject(pnlSearch.Controls, patientSearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("PatientSearcher", patientSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlSearch.Controls, patientSearcher, false);	// controls-to-object
				// other control-to-object methods if any
				return true;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPatientSearch()
		{
			bool result = true;
			PatientSearcher patientSearcher = new PatientSearcher(); // use a parameterized constructor which also initializes the data object
			this.PatientSearcher = patientSearcher;
			this.Patients = null;
			this.ERCCollection = null;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientSearchResultCollection Patients
		{
			get { return patients; }
			set
			{
				patients = value;
				ercCollection = null;
				try
				{
					SetVisiblePanel();

					grid.KeepCollectionIndices = false;  // update given grid from the collection
					grid.UpdateFromCollection(patients);  // update given grid from the collection

					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(PatientSearchResultCollection), patients);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			this.ScrollToControl(pnlResult);
			bool result = true;

			this.ERCCollection = null;
			PatientSearchResultCollection patients = new PatientSearchResultCollection();
			grid.PageStartStack = patientSearcher.PageStartStack;
			patientSearcher.PageRecordIDs = null;
			grid.ClearValuesForPageStart();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				patients.SearchPatients(0, "", "", patientSearcher);
				//this.SetPageMessage("There are more than PatientSearchResultCollection.MAXRECORDS"
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patients.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Patients = patients;
			grid.SelectedRowIndex = 0;
			
			return result;
		}

		/// <summary>
		/// Call this method from anytime you want to search for the next set of patients
		/// </summary>
		public bool SearchNext(PagingDirection direction)
		{
			bool result = true;
			grid.PageStartStack = patientSearcher.PageStartStack;

			PatientSearchResultCollection patients = new PatientSearchResultCollection();
			try
			{
				//if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
				//	return false;

				// Find the last patient that was displayed in the grid.
				object [] valuesForNextPageStart = grid.GetStartValuesForPrevOrNextPage(direction);
				if (valuesForNextPageStart == null)	// no more pages.
					return false;
				// use page start to load this set of records.
				if (intakeLog == null)
					patients.SearchPatients((int)valuesForNextPageStart[0], (string)valuesForNextPageStart[1], (string)valuesForNextPageStart[2], patientSearcher);
				else
					patients.SearchForPatientSubscriberInfo((int)valuesForNextPageStart[0], (string)valuesForNextPageStart[1], (string)valuesForNextPageStart[2], patientSearcher);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patients.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Patients = patients;
			if (direction == PagingDirection.NextPage)
				grid.SelectedRowIndex = 0;
			else
				grid.SelectedRowIndex = grid.Rows.Count - 1;
			
			return result;
		}

		public override void NavigateAway(string targetURL)
		{
			// Push the current start page before navigating away, so that we know where to start from when returned.
			if (patientSearcher != null)
			{
				grid.PageStartStack = patientSearcher.PageStartStack;
				grid.PushValuesForPageStart();	// push the page start values for this page.
			}
			base.NavigateAway (targetURL);
		}


		/// <summary>
		/// Search method for Intake.  Intake searches for the patient that
		/// has the given Patient and Subscriber Information.
		/// </summary>
		public bool SearchForIntake()
		{
			this.ScrollToControl(pnlResult);
			bool result = true;
			PatientSearchResultCollection patients = new PatientSearchResultCollection();

			grid.Columns.FromKey("IsValidCoverage").Hidden = false;

			grid.PageStartStack = patientSearcher.PageStartStack;
			patientSearcher.PageRecordIDs = null;
			grid.ClearValuesForPageStart();

			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;

				//patientSearcher.AlternatePatientID = intakeLog.PatientMemberID;
				//patients
				patientSearcher.SearchFieldsToIntakeSearchFields();
				patients.SearchForPatientSubscriberInfo(0, "", "", patientSearcher);
				//butSearchNext.Visible = false;
				//butSearchPrevious.Visible = false;

				//if (patients.Count >= PatientSearchResultCollection.MAXRECORDS)
				//{
					//this.SetPageMessage("The search returned more than {0} results. Please refine your search criteria.", EnumPageMessageType.Warning, PatientSearchResultCollection.MAXRECORDS);
				//}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patients.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Patients = patients;

			return result;
		}

		/*private void grid_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = grid.GetPKFromClickEvent(e);
				if (pk != null)
					PatientSummaryForm.Redirect((int)pk[0]);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}*/

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			//string colName = grid.GetColumnKeyFromCellEvent(e);
			string colName = e.Cell.Key;
			switch (colName)
			{
				/*case "Edit":
				{
					base.RemovePatientContext();
					object[] pk = grid.GetPKFromCellEvent(e);
					try
					{
						PatientForm.Redirect((int)pk[0]);
					}
					catch(Exception ex)
					{
						this.RaisePageException(ex);
					}
					break;
				}*/

				case "Edit":
				{
					base.RemovePatientContext();
					object[] pk = grid.GetPKFromCellEvent(e);
					try
					{
						//patientSearcher.PageRecordIDs = patients.GetPKs();
						PatientSummaryForm.Redirect((int)pk[0]);
					}
					catch(Exception ex)
					{
						this.RaisePageException(ex);
					}
					break;
				}

				case "SelectForIntakeLog":		// select for intake-log
				{
					int patientID = grid.GetPKIntFromCellEvent(e);
					if (patientID > 0)
					{
						intakeLog.PatientMemberID = e.Cell.Row.Cells.FromKey("PrimaryPatientAlternateID").Text;
						SelectPatientForIntakeLogAndReturn(patientID);
					}
					break;
				}
			}
		}

		/// <summary>
		/// This is called when the patient-search page is called in the Intake-log context
		/// and the user clicked 'Select' for a patient in the grid.
		/// </summary>
		/// <param name="patientID"></param>
		/// <returns></returns>
		public bool SelectPatientForIntakeLogAndReturn(int patientID)
		{
			try
			{
				// fill the intake log fields
				intakeLog.PatientId = patientID;
				intakeLog.PullPatientInfo();		// pull the patient info and populate the patient related fields.
				//intakeLog.PullFirstMatchingSubscriberInfo();		// find the first matching subscriber
				if (intakeLog.PatientCoverage == null)
				{
					// there was no patient coverage picked.
					// go to pick a valid coverage for the patient.
					CoverageSelectionContext covSelContext = new CoverageSelectionContext(intakeLog);
					EnumSelectValidCoverageResult result = this.SelectValidCoverage(covSelContext);
					switch (result)
					{
						case EnumSelectValidCoverageResult.NoCoverageFound:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.NoLogging, "@NOVALIDCOVERAGE@"));
							return false;
						case EnumSelectValidCoverageResult.CoverageValid:
						case EnumSelectValidCoverageResult.SingleCoverageAutoSelected:
						{
							// automatically selected a coverage
							IntakeForm.Redirect(covSelContext, true);
							return true;
						}
						case EnumSelectValidCoverageResult.UserMustSelectFromMultiple:
							return false;		// user was redirected to coverage selection page.
						default:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "Unknown selection result"));
							return false;
					}
				}
				// first coverage matching the search criteria was selected automatically.
				IntakeForm.Redirect(intakeLog, true);
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
		}

		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction)                   // only if this is a popup
				grid.AddColumn("Pick", "@PICK@", 0); 
			else if (this.intakeLog != null)				// only if in the intake-log context
			{
				//grid.AddColumnWithButtonLook("Detail", "@DETAIL@", 0);
				grid.AddButtonColumn("SelectForIntakeLog", "@SELECT@", 0);
				grid.DblClickEventCommand = "SelectForIntakeLog";
			}
			else
			{
				//grid.AddButtonColumn("Summary", "@SUMMARY@", 0);
				grid.AddEditButton("Edit", "@EDIT@", 0).Width = 60;
				grid.DblClickEventCommand = "Edit";
			}
		}

		private string GeneratePatientPickerData(PatientSearchResult pt)
		{
			System.Text.StringBuilder s = new System.Text.StringBuilder();
			/*s.Append("<SCRIPT>\n");
			s.Append("var o = new Object();\n");
			s.Append("o.SSN=\'" + pt.SocialSecurityNumber + @"\'\n;");
			s.Append("o.FullName=\'" + pt.Fmt_FullName + "\'\n;");
			s.Append("o.Gender=\'" + pt.Gender + "\'\n;");
			s.Append("o.DOB=\'" + pt.DateOfBirth + "\'\n;");
			s.Append("</SCRIPT>");*/
			return  s.ToString();
		}

		private void grid_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			PatientSearchResult pt = e.data as PatientSearchResult;
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			if (this.HasCallbackFunction && cell != null)
			{				
				cell.Text = this.GetCallbackFunctionHyperLink("Pick", pt.PatientId, pt.Fmt_FullName,pt.SocialSecurityNumber,pt.DateOfBirth.ToShortDateString(),pt.Gender);
				
			}

			cell = e.row.Cells.FromKey("SelectForIntakeLog");
			if (cell != null)
			{
				cell.Text = pt.PatientId.ToString();
			}

			/*cell = e.row.Cells.FromKey("Detail");
			if (cell != null)
			{
				PatientSearchResult patRes = e.data as PatientSearchResult;
				e.row.Cells.FromKey("Detail").Text = String.Format("<a href='#' onclick='return OpenPatientDetail({0});'>{1}</a>", patRes.PatientId, "Detail");
			}*/
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			//pageSummary.RenderObjects(this.intakeLog);			// display intake-log information when the patient-search is in called from intake form.
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			if (this.intakeLog != null)
				tbbCancel.Text = this.Language.Translate("@BACKTOINTAKE@");

			navBottom.Visible = grid.Rows.Count != 0;
			
			// FORK 1.1.B
			navBottom.NextPageButtonEnabled = navBottom.LastButtonEnabled = grid.Rows.Count >= PatientSearchResultCollection.MAXRECORDS; //  patients != null && patients.Count >= PatientSearchResultCollection.MAXRECORDS;
			// END FORK 1.1.B
			navBottom.FirstButtonEnabled = navBottom.PreviousPageButtonEnabled = grid.HasAnyPreviousPages;

			/*
			if (!navBottom.PreviousPageButtonEnabled)
				navBottom.FirstButtonScript = "if (FirstWebGridRow(grid)) return false;";
			else
				navBottom.FirstButtonScript = "";	// postback
				*/
		}

		public void SetVisiblePanel()
		{
			bool authorizationsSearched = ercCollection != null;
			pnlERCs.Visible = authorizationsSearched;
			pnlResult.Visible = !authorizationsSearched;
		}

		public void EditERC(int rowIndex)
		{
			if (rowIndex < 0)
				return;
			int ID = gridERCs.GetPKIntFromRowIndex(rowIndex);
			EnumERCType ercType = (EnumERCType)gridERCs.Rows[rowIndex].Cells.FromKey("ERCType").Value;
			EditERCAnyPatient(ercType, ID);
		}

		public void EditERCAnyPatient(EnumERCType ercType, int ID)
		{
			BaseForEventCMSReferral erc = ERCClassFactory.CreateERCAndLoad(ercType, null, ID);
			EditERC(erc);
		}

		public void EditERC(BaseForEventCMSReferral erc)
		{
			try
			{
				if (erc == null)
				{
					this.RaisePageException( new ActiveAdviceException("@CANTFINDRECORD@", ercFilterOption.SelectedItem.Text ) );
					return;
				}

				if (!CheckUserDxPxPermission(erc))
				{
					this.SetPageMessage("User has no Dx Or Px permission to view this {0}", EnumPageMessageType.Error, erc.ERCTypeDisplay);
					return;
				}

				//Patient patient = erc.ParentPatient;  // changed by Alp 03/01/2006 
				Patient patient = erc.ParentPatientWithDataFilter;

				if(patient==null)
				{
					this.SetPageMessage("@ACCESSDENIED@", EnumPageMessageType.Warning, erc.UserFriendlyDescription); 
					return;
				}
				PatientCoverage patientCoverage = null;
				Problem problem = null;

				// If not a new ERC, switch to the linked patientcoverage
				if (!erc.IsNew)
				{
					if (erc.PatientSubscriberLog == null)
					{
						this.SetPageMessage("The {0} has no patient subscriber log!", EnumPageMessageType.Warning, erc.UserFriendlyDescription); 
						return;
					}
					else
					{
						if (erc.PatientSubscriberLog.PatientCoverage != null)
							patientCoverage = erc.PatientSubscriberLog.PatientCoverage;
					}

					Problem primaryProblem = erc.GetPrimaryProblem();
					if (primaryProblem != null)
					{
						problem = primaryProblem;
					}
				
				}

				switch (erc.ERCType)
				{
					case EnumERCType.Event:
					{
						EventForm.Redirect(patient, patientCoverage, problem, (Event)erc);
						break;
					}
					case EnumERCType.CMS:
					{
						CaseManagementForm.Redirect(patient, patientCoverage, problem, (CMS)erc);
						break;
					}
					case EnumERCType.Referral:
					{
						ReferralForm.Redirect(patient, patientCoverage, problem, (Referral)erc);
						break;
					}
					default:
						this.SetPageMessage("Unknown ERC type", EnumPageMessageType.Error);
						break;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		/// <summary>
		/// Search just for authorization id.
		/// </summary>
		public bool SearchAuthorization()
		{
			bool result = true;
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;

				int authorizationID = this.patientSearcher.AuthorizationID;
				if (authorizationID == 0)
				{
					this.SetPageMessage("No Authorization ID specified", EnumPageMessageType.Warning);
					return false;
				}
				EnumERCType ercType = (EnumERCType)Enum.Parse(typeof(EnumERCType), this.ercFilterOption.SelectedValue);
				EditERCAnyPatient(ercType, authorizationID);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patients.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			return result;
		}

		/// <summary>
		/// Search just for alt-authorization id.
		/// </summary>
		public bool SearchAltAuthorization()
		{
			bool result = true;
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;

				this.Patients = null;

				string altAuthorizationID = this.patientSearcher.AltAuthorizationID;
				if (altAuthorizationID == null || altAuthorizationID == "")
				{
					this.SetPageMessage("No Alt-Authorization ID specified", EnumPageMessageType.Warning);
					return false;
				}

				EnumERCType ercType = (EnumERCType)Enum.Parse(typeof(EnumERCType), this.ercFilterOption.SelectedValue);
				BaseCollectionForEventCMSReferral ercCol = ERCClassFactory.CreateCollection(ercType);
				int count = ercCol.SearchByAltAuthorizationID(-1, altAuthorizationID);
				if (count <= 0)
				{
					this.SetPageMessage("@NOAUTHORIZATIONSFOUND@", EnumPageMessageType.Info);
				}
				else
				{
					// populate the grid.
					this.ERCCollection = ercCol;
				}

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patients.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			return result;
		}


		private void butSearchAuthorizationID_Click(object sender, System.EventArgs e)
		{
			SearchAuthorization();
		}

		private void butSearchAltAuthID_Click(object sender, System.EventArgs e)
		{
			SearchAltAuthorization();
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// Used when the ERCs are searched.
		/// </summary>
		public BaseCollectionForEventCMSReferral ERCCollection
		{
			get { return ercCollection; }
			set
			{
				ercCollection = value;
				patients = null;
				try
				{
					SetVisiblePanel();
					gridERCs.KeepCollectionIndices = false;  // update given grid from the collection
					gridERCs.UpdateFromCollection(ercCollection);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(BaseCollectionForEventCMSReferral), ercCollection);  // cache object using the caching method declared on the page
			}
		}

		private void gridERCs_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			gridERCs.AddButtonColumn("Edit", "@EDIT@", 0).Width = 70;
			gridERCs.SetColumnTranslate("ERCTypeDisplay", true);
		}

		private void gridERCs_ClickCellButton(object sender, CellEventArgs e)
		{
			// EditERC uses row indices not collection indices.
			// Since the ERC grid contains data from 3 different collections, we need to work on rowIndices.
			int rowIndex = e.Cell.Row.Index;
			if (rowIndex < 0)
				return;

			switch (e.Cell.Key)
			{
				case "Edit":
				{
					EditERC(rowIndex);
					break;
				}
			}
		}

		private void navBottom_ClickNextPage(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			SearchNext(PagingDirection.NextPage);			
		}

		private void navBottom_ClickPreviousPage(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			SearchNext(PagingDirection.PreviousPage);
		}

		private void navBottom_ClickFirst(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			Search();
		}

		private void navBottom_ClickNext(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			SearchNext(PagingDirection.NextPage);	// record prev/next handled in the client.
		}

		private void navBottom_ClickPrevious(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			SearchNext(PagingDirection.PreviousPage);	// record prev/next handled in the client.
		}

		private void navBottom_ClickLast(object sender, NetsoftUSA.WebForms.SimpleRecordNavigatorButtonEventArgs e)
		{
			SearchNext(PagingDirection.LastPage);	// record prev/next handled in the client.
		}
	}
}
