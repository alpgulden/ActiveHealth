using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Insurance Payors search page
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PlanMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("InsurancePayor,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("InsurancePayors")]						//define the active menu item in side menu
	[SelectedMainMenuItem("MPlan")]						//defines active menu item in main navigation
	public class InsurancePayorSearch : PlanBasePage
	{
		private InsurancePayor insurancePayor;
		private InsurancePayorCollection insurancePayors;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternatePayorId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternatePayorId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternatePayorId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlInsurancePayor;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				//this.LoadData();			// Use load data method for data entry forms
				this.NewSearch();		// Use such a method for search pages
			}
			else
			{
				// always load all server side objects from the cache
				//col = (MORGCollection)this.LoadObject(typeof(MORGCollection));	// This would reload from cache
				// searchers must cache and read from a different key than the class name
				//morgSearcher = (MORG)this.LoadObject("MORGSearcher");
				insurancePayor = (InsurancePayor)this.LoadObject("InsurancePayorSearcher");  // load object from cache
			}
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject("InsurancePayorSearcher", null);
			base.NavigateAway ();
		}


		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			Redirect("InsurancePayorSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			grid.ClickCellButton +=new ClickCellButtonEventHandler(grid_ClickCellButton);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.grid.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.grid_DblClick);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessage0s.MessageIDs.SEARCH, "Search");
				toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
				if (!this.IsPopup)
					toolbar.AddButton(OrgMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public InsurancePayorCollection InsurancePayors
		{
			get { return insurancePayors; }
			set
			{
				insurancePayors = value;
				try
				{
					grid.KeepCollectionIndices = false;  // update given grid from the collection
					grid.UpdateFromCollection(insurancePayors);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(InsurancePayorCollection), insurancePayors);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			InsurancePayorCollection insurancePayors = new InsurancePayorCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				insurancePayors.SearchInsurancePayors(-1, insurancePayor);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//insurancePayors.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.InsurancePayors = insurancePayors;
			return result;
		}

		// Handle menu items
		// Handler for 'Search' button
		//public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		//{
		//	this.Search();
		//}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.NewSearch();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			InsurancePayorForm.Redirect(null);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public InsurancePayor InsurancePayor
		{
			get { return insurancePayor; }
			set
			{
				insurancePayor = value;
				try
				{
					this.UpdateFromObject(pnlInsurancePayor.Controls, insurancePayor);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("InsurancePayorSearcher", insurancePayor);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlInsurancePayor.Controls, insurancePayor);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearch()
		{
			bool result = true;
			InsurancePayor insurancePayor = new InsurancePayor(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				//insurancePayor.New(/* parameters */);
				insurancePayor.SetMembersNull(true, true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.InsurancePayor = insurancePayor;
			return result;
		}

		private void grid_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = grid.GetPKFromClickEvent(e);
				if (pk != null)
					InsurancePayorForm.Redirect((int)pk[0]);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		private void grid_ClickCellButton(object sender, CellEventArgs e)
		{
			switch (e.Cell.Key)
			{
				case "Edit":
				{
					int payorId = grid.GetPKIntFromCellEvent(e);
					if (payorId < 0)
						return;
					InsurancePayorForm.Redirect(payorId);
					break;
				}
			}
		}
	}
}
