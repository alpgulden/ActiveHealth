using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Defines page modes that apply to note's text manipulations.
	/// Controls state(s) of text control(s).
	/// </summary>
	public enum EnumPageModes
	{
		Emtpy		= 0,
		ReadOnly	= 1,	// text cannot be changed.
		Create		= 2,	// creation of new note. Text manipulation is allowed.
		Edit		= 3,	// text cannot be changed. Other data can be modified.
		Append		= 4		// adding note (appending) to existing one. existing text - read only, new text - create.
	}
	
	/// <summary>
	/// Summary description for NoteForm.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.NOTES)]
	
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Note,DataLayer")]
	[MainDataProperty("Note")]
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Notes")]
	public class NoteForm : PatientBasePage
	{

		private EnumPageModes pageMode;
		private Note note;
		private Note noteTemplate;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProblemId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProblemId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProblemId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferralId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ReferralId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EventID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEventID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCMSId;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlContext;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNoteTerminationReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo NoteTerminationReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNoteTerminationReasonID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnTerminate;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnActivate;
		protected System.Web.UI.HtmlControls.HtmlTable tblTerminationReason;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlTextControlsHolder;

		protected TextControl txTextControlOld;
		protected TextControl txTextControlNew;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNoteTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo NoteTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAppend;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NoteID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNoteID;
		protected System.Web.UI.WebControls.TextBox TextASCII;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNoteTypeID;
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.wbtnTerminate.Click += new System.EventHandler(this.wbtnTerminate_Click);
			this.wbtnActivate.Click += new System.EventHandler(this.wbtnActivate_Click);
			this.wbtnAppend.Click += new System.EventHandler(this.wbtnAppend_Click);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			this.pageMode = (EnumPageModes)this.GetParamInt("PageMode", 0);
			
			// Put user code to initialize the page here
			if (!IsPostBack)
				LoadDataForNote();
			else
			{
				note = (Note)this.LoadObject(typeof(Note));  // load object from cache
				noteTemplate = (Note)this.LoadObject("NoteTemplate");  // load object from cache
			}

		}

		public EnumPageModes PageMode
		{
			get { return this.pageMode; }
			set 
			{ 
				this.pageMode = value;
				BasePage.PushParam("PageMode", this.pageMode);
			}
		}
		
		#region Note
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Note Note
		{
			get { return note; }
			set
			{
				note = value;
				try
				{
					this.UpdateFromObject(this.pnlContext.Controls, note);  // update controls for the given control collection
					this.UpdateFromObject(this.pnlDetails.Controls, note);  // update controls for the given control collection
					
					if(!note.NotePage.IsRTF)
						this.txTextControlOld.AppendPlainText(note.NotePage.NoteText, "Courier New", 10);
					else
						//if(note.NotePage.NoteText != null)
						this.txTextControlOld.Text = note.NotePage.NoteText;

					// added by Alp 09/29/05
					if(txTextControlOld.GetText(TxHelper.TextFormat.ANSIText).Length > 0)
						this.TextASCII.Text=this.txTextControlOld.GetText(TxHelper.TextFormat.ANSIText);

					if(this.pageMode==EnumPageModes.Create)
					{
						this.txTextControlNew.ClearContents();
						this.txTextControlOld.ClearContents();
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Note), note);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForNote()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlContext.Controls, note);	// controls-to-object
				this.UpdateToObject(this.pnlDetails.Controls, note);	// controls-to-object
			
				
				if(this.txTextControlNew.Visible && txTextControlNew.GetText(TxHelper.TextFormat.ANSIText).Length > 0)
				{
					// Check if we're in append mode. EnumPageModes.Append:
					if(this.pageMode == EnumPageModes.Append)
					{
						this.txTextControlOld.InsertNewLine();
						this.txTextControlOld.InsertNewLine();
						this.txTextControlOld.AppendPlainText(note.AppendedByAndSet(), "Courier New", 10);
					}
					this.txTextControlOld.AppendRTFFromTextControl(this.txTextControlNew, true);
				}
				
				note.NotePage.TextRTF = this.txTextControlOld.Text;
				note.MedicalNoteBrief = this.txTextControlOld.GetText(TxHelper.TextFormat.ANSIText);

				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewNote()
		{
			bool result = true;
			Note note = null;
			try
			{	// or use an initialization method here

				// create a new Note object from Template(Note Context) OR existing Note object
				if(this.noteTemplate == null)
					note = Note.CreateNoteFromNoteAndSet(this.note);
				else
					note = Note.CreateNoteFromNoteAndSet(this.noteTemplate);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			PageMode = EnumPageModes.Create;
			this.Note = note;			
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForNote()
		{
			bool result = true;
			Note note = null;
			try
			{	// use any load method here
				
				Note noteTemplate = (Note)this.LoadObject("NoteTemplate");
				if(noteTemplate == null)
					this.SetPageMessage("Note Context was not passed ", EnumPageMessageType.AddWarning);
				NoteTemplate = noteTemplate;

				note = GetParamOrGetFromCache("Note", typeof(Note)) as Note;
				if (note == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a Note");
				this.Note = note;
				PageMode = this.pageMode;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				
				result = false;
			}
			finally
			{
				//note.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Note note, EnumPageModes mode)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Note", note);
			BasePage.PushParam("PageMode", mode);
			BasePage.Redirect("NoteForm.aspx");

		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(int noteID, EnumPageModes mode)
		{
			Note note = new Note();
			if (!note.Load(noteID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@NOTE@");
			Redirect(note, mode);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForNote()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForNote())
					return false;
				// The selected coverage should be set in order for the auto-activity
				// to use for contexts other than event/problem.
				note.SelectedPatientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage), false);
				note.Save(); // update or insert to db 
				txTextControlOld.IsDirty = false;
				txTextControlNew.IsDirty = false;
				this.DumpAutoActivity(this.note, true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region NoteTemplate
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// Is used to keep Note context between Seach and Form pages.
		/// </summary>
		public Note NoteTemplate
		{
			get { return noteTemplate; }
			set
			{
				noteTemplate = value;
				this.CacheObject("NoteTemplate", noteTemplate);  // cache object using the caching method declared on the page
			}
		}
		#endregion

		#region UI Initialization and Events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			if(note == null)
				return;
			bool isActive = (this.note.TerminateTime > DateTime.MinValue ? false : true);
			this.wbtnActivate.Visible = !isActive;
			this.wbtnAppend.Visible = this.wbtnTerminate.Visible = this.tblTerminationReason.Visible = !note.IsNew && isActive;

			if(!isActive)
				PageMode = EnumPageModes.ReadOnly;
			SetUIState();
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty();
			this.IsDirty = note.IsDirty || txTextControlOld.IsDirty || txTextControlNew.IsDirty;
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.note.Patient/*, this.note*/);
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if(!note.NotePage.IsRTF)
				this.txTextControlOld.AppendPlainText(note.NotePage.NoteText, "Courier New", 10);
			if (SaveDataForNote())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Note ");
				PageMode = EnumPageModes.Edit;
			}
			Note = Note;
		}

		public new void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PageMode = EnumPageModes.ReadOnly;
			NoteSearch.Redirect(this.NoteTemplate);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Note":
					toolbar.AddButton(Messages.BaseMessages.MessageIDs.ADDNEWRECORD, "AddNewNote");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewNote(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewNote();
		}

		private void wbtnAppend_Click(object sender, System.EventArgs e)
		{
			PageMode = EnumPageModes.Append;
		}

		private void wbtnTerminate_Click(object sender, System.EventArgs e)
		{
			if(this.ReadControlsForNote())
			{
				if(this.note.NoteTerminationReasonID == 0)
				{
					this.SetPageMessage( this.Language.TranslateSingle("NOTETERMREQ"), EnumPageMessageType.AddError);
					return;
				}
				this.note.Terminate();
			}
			Note = this.note;
		}

		private void wbtnActivate_Click(object sender, System.EventArgs e)
		{
			Note.Activate();
			Note = Note;
		}

		private void SetUIState()
		{
			this.txTextControlOld.TextControlMode = TextControlModeEnum.SimpleEditor | TextControlModeEnum.PrintPreview;
			this.txTextControlNew.TextControlMode = TextControlModeEnum.SimpleEditor | TextControlModeEnum.ShowPrintLink;
			this.NoteTypeID.Enabled = false;
			this.TextASCII.Visible = false; // default state
			switch(this.pageMode)
			{
				case EnumPageModes.Create:
					this.txTextControlOld.Visible = false;
					this.txTextControlNew.Visible = true;
					this.txTextControlNew.TextControlMode |= TextControlModeEnum.ShowToolbar;
					this.NoteTypeID.Enabled = true;
					break;
				case EnumPageModes.Edit:
					this.txTextControlOld.Visible = true;
					this.txTextControlNew.Visible = false;
					break;
				case EnumPageModes.Append:
					this.txTextControlOld.Visible = false;  // page cannot support both controls at the same time - known issue
					if (this.Note != null && this.Note.NotePage != null & !this.Note.NotePage.IsRTF)
						this.txTextControlOld.ClearContents(); // added by Burag on Nov4, 2005 guideline note duplication.
					//Added by Alp 09/29/05
					this.TextASCII.Visible=true;

					this.txTextControlNew.Visible = true;
					this.txTextControlNew.TextControlMode |= TextControlModeEnum.ShowToolbar;
					this.txTextControlNew.ClearContents();
					break;
				case EnumPageModes.ReadOnly:
					this.txTextControlOld.Visible = true;
					this.txTextControlNew.Visible = false;
					break;
				case EnumPageModes.Emtpy:
				default:
					this.txTextControlOld.Visible = true;
					this.txTextControlNew.Visible = false;
					break;
			}
		}
		#endregion

	}
}
