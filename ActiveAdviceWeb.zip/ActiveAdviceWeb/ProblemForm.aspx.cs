using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// This pages is the edit and add page of a problem, which can be linked to a patient.
	/// If a new problem is being edited, an existing patient-subscriber-coverage must be passed to this page.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.PROBLEMS)]
	
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Problem,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(PatientSummaryForm))]
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[PageTitle("@PROBLEMPAGETITLE@")]
	public class ProblemForm : PatientBasePage
	{
		private Patient patient;							// patient
		private PatientCoverage patCov;		// selected patient-subscriber-coverage for the patient
		private Problem problem;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProblemDescription;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProblemDescriptionID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ProblemID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProblemID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel Contentpanel2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAssignedTeamID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit AssignedTeamID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAssignedTeamID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAssignedUserID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit AssignedUserID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAssignedUserID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProblemStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProblemStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProblemStatusID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusChangedDisplay;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit StatusChangedDisplay;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDxType;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit DxType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDxType;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDiagnosticCode;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit DiagnosticCode;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDiagnosticCode;
		protected NetsoftUSA.WebForms.WindowOpener wo;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected AdministrationControl AdministrationControl;
		protected TeamUserSelect TeamUserSelect1;

		private CoverageSelectionContext covSelContext;
		private IntakeLog intakeLog;				// this is set when the available coverage selection was called from intake log
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAdministration;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderGroupPractice;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProvider;
		protected UserDefined UserDefined1;
		protected ProviderSelect ProviderSelect;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected ProviderSelect ProviderGroupPracticeSelect;

		private void Page_Load(object sender, System.EventArgs e)
		{
			AdministrationControl.AdministrationForProblem = true;
			//this.DiagnosticSelect1.RebindControls(typeof(Problem));
			this.TeamUserSelect1.RebindControls(typeof(Problem), "AssignedTeamID", "AssignedUserID");
			this.UserDefined1.ReloadContext("Problem",problem,true);
			
			if(!UserDefined1.HasFields())
				this.PageTab.GetTab("UserDefined").Visible= false;
			// Provider select
			this.ProviderSelect.RebindControls(typeof(Problem), "@PROVIDER@", 
				ProviderSearcherType.Provider, null,
				"ProviderID", "ProviderLocationID", "ProviderSpecialtyID", "ProviderNetworkID", "ProviderNetworkStatus");

			// ProviderGroupPractice select
			this.ProviderGroupPracticeSelect.RebindControls(typeof(Problem), "@PROVIDERGROUPPRACTICE@", 
				ProviderSearcherType.GroupPractice, null,
				"ProviderGroupID", "ProviderGroupLocationID", "ProviderGroupTypeID", "ProviderGroupNetworkID", "ProviderGroupNetworkStatus");

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadDataForProblem();
			}
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient), false);  // load object from cache
				patCov = (PatientCoverage)this.LoadObject(typeof(PatientCoverage), false);
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				intakeLog = (IntakeLog)this.LoadObject(typeof(IntakeLog));
			}
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			this.SetPageToolbarItemEnabled("CostRpt",((this.problem != null) && (problem.ProblemID != 0) && (patient != null) && (patient.PatientId != 0)));
		}

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				toolbar.AddButton(OrgMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}
			else if (tab.Key == "Administration")
			{
				toolbar.AddButton(PatientMessages.MessageIDs.CHANGECOVERAGE, "ChangeCoverage", true, false);
			}

			// Menu items to be displayed on all tabs
			toolbar.AddButton("@COSTRPT@","CostRpt");
		}

		public void OnSubNavigationItemClick_Activities(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ActivitiesForm.Redirect(EnumActivityContext.Activity, EnumActivityAndNoteContext.Problem);
		}

		public new void OnSubNavigationItemClick_Notes(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			NoteSearch.Redirect(EnumActivityAndNoteContext.Problem);
		}

		public void OnToolbarButtonClick_ChangeCoverage(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// data from controls to object
			if (!this.ReadControlsForProblem())
				return;
			RedirectToSelectCoverage(this.patient, this.patCov, this.problem, null);			
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewProblem();
		}

		public void OnToolbarButtonClick_CostRpt(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BasePage.PushCallingPage(this);
			object[] val = new object[]{this.patient.PatientId,this.problem.ProblemID};
			FormSpecificReport.Redirect(val,"COSTCOMPSINGLEPATIENTPROB");
		}
		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForProblem())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@PROBLEM@");
				if (this.intakeLog != null)
				{
					// first set the new problem to the intake log context
					// then redirect depending on the intake log resolution.
					// usually, will redirect to event or referral pages.
					intakeLog.Problem = this.problem;
					this.IntakeRedirectByResolution(intakeLog);
				}
				else
					this.Problem = this.problem;	// refresh
			}
		}

		public new bool IntakeRedirectByResolution(IntakeLog intakeLog)
		{
			//if (this.intakeLog.AddProblemAndReturn)
			//{
			//	IntakeForm.Redirect(IntakeLog, true);
				//return true;
			//}
			//else
				return base.IntakeRedirectByResolution(intakeLog);
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.intakeLog != null)
			{
				// back to intake log with no selection
				IntakeForm.Redirect(intakeLog, true);
				return;
			}

			RedirectBack();
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Problem Problem
		{
			get { return problem; }
			set
			{
				problem = value;
				try
				{
					this.UpdateFromObject(pnlDetails1.Controls, problem);  // update controls for the given control collection
					this.UpdateFromObject(pnlDetails2.Controls, problem);  // update controls for the given control collection
					this.UpdateFromObject(pnlProvider.Controls, problem);
					this.UpdateFromObject(pnlProviderGroupPractice.Controls, problem);
					// other object-to-control methods if any

					// first cache then reload context
					this.CacheObject(typeof(Problem), problem);  // cache object using the caching method declared on the page
					AdministrationControl.ReloadContext();
					AdministrationControl.UpdateData(true);

					this.UserDefined1.ReloadContext("Problem",problem,false);
					

				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Problem), problem);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForProblem()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlDetails1.Controls, problem);	// controls-to-object
				this.UpdateToObject(pnlDetails2.Controls, problem);	// controls-to-object
				this.UpdateToObject(pnlProvider.Controls, problem);
				this.UpdateToObject(pnlProviderGroupPractice.Controls, problem);
				// other control-to-object methods if any
				UserDefined1.UserDefinedValue = problem.UserDefined;
				UserDefined1.ReadControls();
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewProblem()
		{
			bool result = true;
			Problem problem = new Problem(this.patient); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Problem = problem;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForProblem()
		{
			bool result = true;
			Problem problem = null;
			try
			{	
				// if a coverage selection context was passed, the user has selected a coverage and returned back to the problem page
				// to save the problem.
				// continue with saving.
				intakeLog = GetParam("IntakeLog") as IntakeLog;
				this.CacheObject(typeof(IntakeLog), intakeLog);

				covSelContext = this.GetParam("CoverageSelectionContext") as CoverageSelectionContext;

				if (intakeLog != null)
				{
					patient = intakeLog.Patient;
					patCov = intakeLog.PatientCoverage;
					problem = intakeLog.Problem;
					
					this.CacheObject(typeof(Patient), patient);
					this.CacheObject(typeof(PatientCoverage), patCov);

					patCov = intakeLog.PatientCoverage;
					if (problem == null)
						return NewProblem();
				}
				else
				{
					if (covSelContext != null)
					{
						// Back from Coverage Selection

						patient = covSelContext.Patient;
						problem = covSelContext.Problem;
						patCov = covSelContext.PatientCoverage;

						intakeLog = covSelContext.IntakeLog;

						this.CacheObject(typeof(Patient), patient);
						this.CacheObject(typeof(PatientCoverage), patCov);

						// Save the problem immediately if the user has selected picked a coverage for it.

						this.DumpCoverageSelectionContext(covSelContext);

						problem.ChangeCoverage(patCov);
					}
					else
					{
						patient = this.GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
						patCov = this.GetParamOrGetFromCache("PatCov", typeof(PatientCoverage)) as PatientCoverage;
						
						this.CacheObject(typeof(Patient), patient);
						this.CacheObject(typeof(PatientCoverage), patCov);

						problem = this.GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
						if (problem == null)
							return NewProblem();

						if (patient == null)
							patient = problem.Patient;
					}
				}

				this.CacheObject(typeof(Patient), patient);
				this.CacheObject(typeof(PatientCoverage), patCov);
				
				if ((patCov == null || patient == null) && problem.IsNew)
					throw new Exception("A problem can be created only in the context of a patient and a selected patient-coverage");

				if (patCov != null)		// if a patCov was specified, it must exist in db.
				{
					if (patCov.IsNew)	// The given patCov must not be new!
						throw new Exception("The given patient-coverage does not yet exist in the db");
				}

				// Back from Coverage Selection
				if (covSelContext != null && covSelContext.IsSaving)		// if back from coverage selection, save immediately
				{
					covSelContext.SaveProblem();
					this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@PROBLEM@");
					this.patient.PatientProblems = null;

					if (intakeLog != null)
					{
						// continue with next step.
						this.IntakeRedirectByResolution(intakeLog);
					}
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//problem.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Problem = problem;
			return result;
		}

		public static void Redirect(IntakeLog intakeLog)
		{
			//BasePage.PushCurrentCallingPage();
			BasePage.PushParam("IntakeLog", intakeLog);
			Redirect(intakeLog.Patient, intakeLog.PatientCoverage, intakeLog.Problem);
		}

		public static void Redirect(CoverageSelectionContext coverageSelectionContext)
		{
			//BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CoverageSelectionContext", coverageSelectionContext);
			BasePage.Redirect("ProblemForm.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.Redirect("ProblemForm.aspx");
		}

		public static void Redirect(Patient patient, PatientCoverage patCov,  int problemId)
			//public static void Redirect(Patient patient, int problemId)
		{
			Problem problem = new Problem();
			if (!problem.Load(patient, problemId))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@PROBLEM@");

			Redirect(patient, patCov, problem);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForProblem()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForProblem())
					return false;
				if (this.problem.IsNew)
				{
					// Select a valid coverage and save the problem
					// Creating a new problem in the context of the selected patient-subscriber-coverage
					covSelContext = new CoverageSelectionContext(true, this.patient, this.patCov, this.problem, null);
					covSelContext.IntakeLog = this.intakeLog;	// also pass the intake log context
					EnumSelectValidCoverageResult result = this.SelectValidCoverage(covSelContext);
					this.DumpCoverageSelectionContext(covSelContext);
					switch (result)
					{
						case EnumSelectValidCoverageResult.NoCoverageFound:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "@NOVALIDCOVERAGE@"));
							return false;
						case EnumSelectValidCoverageResult.CoverageValid:
						case EnumSelectValidCoverageResult.SingleCoverageAutoSelected:
						{
							// save the problem in the context of coverage selection
							covSelContext.SaveProblem();
							break;
						}
						case EnumSelectValidCoverageResult.UserMustSelectFromMultiple:
							return false;		// user was redirected to coverage selection page.
						default:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "Unknown selection result"));
							return false;
					}
					// Select a valid coverage and save the problem
				}
				else
				{
					// Updating an existing problem
					problem.Save();
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			this.patient.PatientProblems = null;
			return true;
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			if (this.problem.IsNew)
				pageSummary.RenderObjects(this.intakeLog, this.patient, this.patCov);
			else
				pageSummary.RenderObjects(this.intakeLog, this.patient);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();

			this.CheckForDirty(this.problem, this.problem.UserDefined);
		}

	}
}
