using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using Infragistics.WebUI.UltraWebNavigator;
using Infragistics.WebUI.UltraWebToolbar;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Plan Components page.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.PLAN)]
	
	[MainLanguageClass("ActiveAdvice.Messages.PlanMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Plan,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(PlanForm))]
	[SelectedMenuItem("Details")]						//define the active menu item in side menu
	[SelectedMainMenuItem("MPlan")]						//defines active menu item in main navigation
	public class PlanComponents : PlanBasePage
	{
		private Plan plan;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlComponents;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebTree tree;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
				//this.NewMORGSearch();		// Use such a method for search pages
			}
			else
			{
				// always load all server side objects from the cache
				plan = (Plan)this.LoadObject(typeof(Plan));	// This would reload from cache
				//col = (MORGCollection)this.LoadObject(typeof(MORGCollection));	// This would reload from cache
				// searchers must cache and read from a different key than the class name
				//morgSearcher = (MORG)this.LoadObject("MORGSearcher");
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			Redirect("PlanComponents.aspx");
		}

		private void tree_DemandLoad(object sender, Infragistics.WebUI.UltraWebNavigator.WebTreeNodeEventArgs e)
		{
			Debug.WriteLine("tree_DemandLoad " + e.Node.Text);
		}

		private void UltraWebTree1_NodeClicked(object sender, Infragistics.WebUI.UltraWebNavigator.WebTreeNodeEventArgs e)
		{
			if (!this.IsPopup)
				if (e.Node.Text == "Management Services")
					ManagementServicesForm.Redirect(plan.ManagementService);

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.tree.NodeClicked += new Infragistics.WebUI.UltraWebNavigator.NodeClickedEventHandler(this.tree_NodeClicked);
			this.tree.DemandLoad += new Infragistics.WebUI.UltraWebNavigator.DemandLoadEventHandler(this.tree_DemandLoad);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			TBarButton tbbCancel = toolbar.AddButton("@CANCEL@", "Cancel", false).Item;
			if (this.IsPopup)
			{
				tbbCancel.Text = this.BaseMessages.CLOSE;
				tbbCancel.TargetURL = "javascript:window.close()";
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			Plan plan = null;
			try
			{	// use any load method here

				string splanid = this.Request.QueryString["PlanID"];
				if (splanid != null)
				{
					plan = new Plan();
					if (!plan.Load(int.Parse(splanid)))
						throw new ActiveAdviceException("@CANTFINDRECORD@", "@PLAN@");
				}
				else
				{
					plan = plan = this.GetParamOrGetFromCache("Plan", typeof(Plan)) as Plan;
					if (plan == null)
					{
						SetPageMessage("You must come to this page from a plan's context", EnumPageMessageType.Error);
						return false;
					}
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//plan.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Plan = plan;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Plan plan)
		{
			BasePage.PushParam("Plan", plan);
			BasePage.Redirect("PlanComponents.aspx");

		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Plan Plan
		{
			get { return plan; }
			set
			{
				plan = value;
				try
				{
					//this.UpdateFromObject(this.Controls, plan);  // update controls for the given control collection
					tree.Nodes.Clear();
					tree.AutoPostBack = !this.IsPopup;
					Node nd = null;
					Node rootNode = null;
					string planDesc = String.Format("{0}", plan.Name);
					rootNode = tree.Nodes.Add( planDesc , "Plan");
					rootNode.Expanded = true;
					rootNode.ImageUrl = "pics/plan.gif";
					//rootNode.CssClass = "TreeNodeLink";
					//rootNode.HoverClass = "TreeNodeLink";

					nd = rootNode.Nodes.Add("Management Services", "ManagementServices");
					if (!this.IsPopup)
					{
						nd.TargetUrl = "ManagementServicesForm.aspx";
						//if(this.IsPopup)
						//	nd.TargetUrl += "?WindowMode=" + this.WindowMode.ToString();
						nd.CssClass = "TreeNodeLink";
						nd.HoverClass = "TreeNodeLink";
					}
					plan.ManagementService.LoadManagementServiceItems(false);	// ensure loaded
					tree.FillFromCollection(nd, plan.ManagementService.ManagementServiceItems, "ServiceTypeDescription", null, "ManagementServiceItemId");
					
					for (int i = 0; i < nd.Nodes.Count; i++)
					{
						if (plan.ManagementService.ManagementServiceItems[i].IsActiveNow)
							nd.Nodes[i].ImageUrl = "pics/dot.gif";
						else
						{
							nd.Nodes[i].ImageUrl = "pics/warningmark.gif";
							nd.Nodes[i].Hidden = true;
						}

					}
					//tree.FillNodeCssAttribs(nd, null, null, null "pics/dot.gif");

					
					nd = rootNode.Nodes.Add("Special Procedures", "SpecialProcedures");
					tree.AddDataObject(nd, plan.GetSpecialProcedure(), "Name", null, "SpecialProcedureId");
					tree.FillNodeCssAttribs(nd, "TreeNodeLink", "TreeNodeLink", "pics/dot.gif");

					nd = rootNode.Nodes.Add("Triggers", "Triggers");
					tree.AddDataObject(nd, plan.GetTriggerList(), "Name", null, "TriggerListId");
					tree.FillNodeCssAttribs(nd, "TreeNodeLink", "TreeNodeLink", "pics/dot.gif");

					nd = rootNode.Nodes.Add("Benefit Services", "BenefitServices");
					tree.AddDataObject(nd, plan.GetBenefitService(), "Name", null, "BenefitServiceId");
					tree.FillNodeCssAttribs(nd, "TreeNodeLink", "TreeNodeLink", "pics/dot.gif");

					nd = rootNode.Nodes.Add("Insurance Payor", "InsurancePayor");
					tree.AddDataObject(nd, plan.GetInsurancePayor(), "Name", null, "InsurancePayorId");
					tree.FillNodeCssAttribs(nd, "TreeNodeLink", "TreeNodeLink", "pics/dot.gif");

					nd = rootNode.Nodes.Add("Linked Networks", "LinkedNetworks");
					NetworkCollection networks = plan.GetLinkedNetworks();
					tree.FillFromCollection(nd, networks, "Name", null, "NetworkID");
					//tree.FillNodeCssAttribs(nd, "TreeNodeLink", "TreeNodeLink", "pics/dot.gif");

					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Plan), plan);  // cache object using the caching method declared on the page
			}
		}

		private void tree_NodeClicked(object sender, Infragistics.WebUI.UltraWebNavigator.WebTreeNodeEventArgs e)
		{
			if (e.Node.Parent == null)
				return;
			try
			{
				switch ((string)e.Node.Parent.Tag)
				{
					case "Plan":
						PlanForm.Redirect(this.plan);		// redirect to current plan						
						break;
					case "SpecialProcedures":
						// A special procedure item was clicked
						SpecialProceduresForm.Redirect(plan.SpecialProcedureId);
						break;
					case "Triggers":
						TriggerListForm.Redirect(plan.TriggerListId);
						break;
					case "BenefitServices":
						BenefitServicesForm.Redirect(plan.BenefitServiceId);
						break;
					case "InsurancePayor":
						InsurancePayorForm.Redirect(plan.InsurancePayorId);
						break;
				}
			}
			catch(Exception ex)
			{
				RaisePageException(ex);
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.plan);
		}

	}
}
