using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using Infragistics.WebUI.UltraWebToolbar;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Patient Details data entry page.
	/// </summary>
	/// 
	
	//Set Functional Access by roles asssigned to the user	VS_PERMISSION
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.PATIENT_INFORMATION)]

	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Patient,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Details")]
	//[MainDataProperty("Patient")]
	public class PatientForm : PatientBasePage
	{
		private PatientCOB patientCOB;
		private PatientFocusHistory focusToTerminate;
		private PatientFocusHistory focus;
		private Patient patient;
		private IntakeLog intakeLog;							// set whenever a patient is added from intake.
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLanguageID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNameSuffix;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit NameSuffix;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNameSuffix;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMiddleInitial;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMiddleInitial;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSocialSecurityNumber;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit SocialSecurityNumber;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSocialSecurityNumber;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLastName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGender;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Gender;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGender;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDateOfBirth;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DateOfBirth;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateOfBirth;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNamePrefixId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo NamePrefixId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNamePrefixId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLanguageID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo LanguageID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAddress;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBLabel RecordDescription;
		protected NetsoftUSA.WebForms.OBButton butCancelFocusTerminate;
		protected NetsoftUSA.WebForms.OBButton butTerminateFocus;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlTerminateFocus;
		protected NetsoftUSA.WebForms.OBButton butCancelFocus;
		protected NetsoftUSA.WebForms.OBButton butOKFocus;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEditFocus;
		protected NetsoftUSA.WebForms.OBButton butTerminate;
		protected NetsoftUSA.WebForms.OBButton butAddFocus;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridFocus;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridAvailFocusCodes;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFocuses;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientFocusID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PatientFocusID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientFocusID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFocusDescription;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatus;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Status;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatus;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOtherInsuranceType;
		protected NetsoftUSA.InfragisticsWeb.WebCombo OtherInsuranceType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOtherInsuranceType;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOtherInsuranceName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit OtherInsuranceName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOtherInsuranceName;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPatientCOBDetail;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPatientCOB;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridPatientCOB;
		protected NetsoftUSA.WebForms.OBButton butCancelPatientCOB;
		protected NetsoftUSA.WebForms.OBButton butSavePatientCOB;
		protected NetsoftUSA.WebForms.OBCheckBox IsPrimary;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIsPrimary;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FocusDescription;
		protected AddressControl AddressControl;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PatientId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientId;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected UserDefined UserDefined1;
		protected TeamUserSelect TeamUserSelect1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			this.TeamUserSelect1.RebindControls(typeof(Patient), "AssignedTeamId", "AssignedUserId");
			// Put user code to initialize the page here
			UserDefined1.ReloadContext("Patient",patient,true);
			if(!UserDefined1.HasFields())
				this.PageTab.GetTab("UserDefined").Visible= false;
			if (!this.IsPostBack)
			{
				this.LoadDataForPatient();
			}
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				intakeLog = (IntakeLog)this.LoadObject(typeof(IntakeLog));		// is available when this form is called from intake log.
				focus = (PatientFocusHistory)this.LoadObject(typeof(PatientFocusHistory));  // load object from cache
				focusToTerminate = (PatientFocusHistory)this.LoadObject(typeof(PatientFocusHistory));  // load object from cache
				patientCOB = (PatientCOB)this.LoadObject(typeof(PatientCOB));  // load object from cache
				if (patient != null)
				{
					this.AddressControl.Address = patient.Address;
				}
			}
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject(typeof(PatientFocusHistory), null);
			this.CacheObject(typeof(PatientCOB), null);
			base.NavigateAway (targetURL);
		}


		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("PatientForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			gridPatientCOB.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridPatientCOB_ColumnsBoundToDataClass);
			gridPatientCOB.ClickCellButton +=new ClickCellButtonEventHandler(gridPatientCOB_ClickCellButton);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butAddFocus.Click += new System.EventHandler(this.butAddFocus_Click);
			this.butTerminate.Click += new System.EventHandler(this.butTerminate_Click);
			this.butOKFocus.Click += new System.EventHandler(this.butOKFocus_Click);
			this.butCancelFocus.Click += new System.EventHandler(this.butCancelFocus_Click);
			this.butTerminateFocus.Click += new System.EventHandler(this.butTerminateFocus_Click);
			this.butCancelFocusTerminate.Click += new System.EventHandler(this.butCancelFocusTerminate_Click);
			this.butSavePatientCOB.Click += new System.EventHandler(this.butSavePatientCOB_Click);
			this.butCancelPatientCOB.Click += new System.EventHandler(this.butCancelPatientCOB_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			
			if (!this.IsPopup)
			{

				if (this.intakeLog != null && !EligibilityAddAnyway)
				{
					toolbar.AddButton("@BACKTOINTAKE@", "BackToIntake");
					return;
				}

				switch (tab.Key)
				{
					case "Details":
					
						//toolbar.AddButton("@ADDNEWRECORD@", "AddNew");
						break;
					case "Focus":
						toolbar.AddButton("@ADDNEWRECORD@", "AddNewFocus", true, false);
						break;
					case "PatientCOB":
						toolbar.AddButton("@ADDNEWRECORD@", "AddNewPatientCOB", true, false);
						break;
				}
			}
			// Menu items to be displayed on all tabs
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewPatient();
		}

		public void OnToolbarButtonClick_AddNewFocus(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewFocus();
		}

		public void OnToolbarButtonClick_AddNewPatientCOB(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewPatientCOB();
		}

		public void OnToolbarButtonClick_BackToIntake(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			IntakeForm.Redirect(this.intakeLog, true);
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			
			if (this.IsPopup)
			{
				TBarButton tbbCancel = toolbar.AddButton("@CLOSE@", "Close", false).Item;
				tbbCancel.TargetURL = "javascript:window.close()";
			}
			else
			{
				toolbar.AddButton(false, "@SAVERECORD@", "SaveWithCoverage", true, false);
				toolbar.AddButton(false, "@DEFINESUBSCRIBER@", "DefineSubscriber", true, false);
				toolbar.AddPreset(ToolbarButtons.SaveCancel);
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Patient Patient
		{
			get { return patient; }
			set
			{
				patient = value;
				try
				{
					this.UpdateFromObject(pnlDetails.Controls, patient);  // update controls for the given control collection
					this.UpdateFromObject(pnlAddress.Controls, patient.Address);  // update controls for the given control/collection

					patient.LoadPatientFocusHistory(false);
					this.PatientFocusHistory = patient.PatientFocusHistory;
					patient.LoadPatientCOBs(false);
					this.PatientCOBs = patient.PatientCOBs;
					UserDefined1.ReloadContext("Patient",patient,false);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Patient), patient);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPatient()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlDetails.Controls, patient);	// controls-to-object
				this.UpdateToObject(pnlAddress.Controls, patient.Address);  // controls-to-object
				// other control-to-object methods if any
				UserDefined1.UserDefinedValue = patient.UserDefined;
				UserDefined1.ReadControls();
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPatient()
		{
			bool result = true;
			Patient patient = new Patient(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				if (this.intakeLog != null)			// if from intake, use the pre-filled information
				{
					patient.SocialSecurityNumber = this.intakeLog.PatientSSN;
					patient.FirstName = this.intakeLog.PatientFName;
					patient.LastName = this.intakeLog.PatientLName;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Patient = patient;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForPatient()
		{
			bool result = true;
			Patient patient = null;
			try
			{	
				this.SetPageMessageFromParam();					// display the message sent by the calling page.
				// use any load method here
				// or pull from the parameter passed to this page via PushParam
				intakeLog = this.GetParam("IntakeLog") as IntakeLog;

				if (!this.IsPopup)
					this.CacheObject(typeof(IntakeLog), intakeLog);		// cache the intake-log context so that we'll get it in the next post back

				if (intakeLog != null)
				{
					patient = intakeLog.Patient;
					base.CacheEligibilityAddAnyway(intakeLog.PlanID, intakeLog.SORGId);
				}
				else
				{
					string spatientID = this.Request.QueryString["PatientID"];
					if (spatientID != null)
					{
						patient = new Patient();
						if (!patient.Load(int.Parse(spatientID)))
							throw new ActiveAdviceException("@CANTFINDRECORD@", "@PATIENT@");
					}
					else
						patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				}
				if (patient == null)
					return NewPatient();
			
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patient.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Patient = patient;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient)
		{
			//BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.Redirect("PatientForm.aspx");
		}

		public static void Redirect(int patientId)
		{
			Patient patient = new Patient();
			if (!patient.Load(patientId))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@PATIENT@");
			Redirect(patient);
		}

		/// <summary>
		/// Called when a patient is added from intake log
		/// </summary>
		public static void Redirect(IntakeLog intakeLog)
		{
			BasePage.PushParam("IntakeLog", intakeLog);
			BasePage.Redirect("PatientForm.aspx");
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPatient()
		{
			try
			{	// data from controls to object
				if(EligibilityAddAnyway)
					if (!this.ReadControlsForPatient())
						return false;
				
				// If came here from intake, and the patient exists but the coverage is new.
				if(this.IsNewPatientCoverageFromEligibilityData)
				{
					this.intakeLog.Patient = this.patient;
					this.intakeLog.Subscriber.Save(this.patient, this.intakeLog.PatientCoverage, true);
					PushPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Existing Patient and New Coverage");
					IntakeForm.Redirect(this.intakeLog);
					return true;
				}

				if (this.patient.IsNew)
				{
					if (!SaveWithOrWithoutCoverage())
						return false;
				}
				else
				{
					patient.Save(); // postponed until subscriber and the patient coverage is defined.  SubscriberForm will save the patient.
					// if came here from intake, redirect to what the user selected for resolution
					if (this.intakeLog != null)
					{
						this.intakeLog.RefreshPatientOnly(patient);
						if(!IntakeRedirectByResolution(intakeLog))
						{	
							// If nothing was selected for resolution redirect back to Intake
							IntakeForm.Redirect(this.intakeLog, true);
						}
					}
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}

			UpdatePKs();		// If this line is hit, the patient and child collections were saved in this page successfuly.
			return true;
		}

		public void UpdatePKs()
		{
			gridFocus.UpdatePKsFromCollection(patient.PatientFocusHistory);
			gridPatientCOB.UpdateFromCollection(patient.PatientCOBs);
		}

		/// <summary>
		/// When the patient is new and imported from Eligibility Data
		/// Both Patien and Coverage will be saved to db.
		/// 
		/// Otherwise (when patient created on the fly by user)
		/// user can't save directly to the db.
		/// Instead of Save button he/she can click on the DefineSubscriber button
		/// and this method redirects to SubscriberSearch to allow the user
		/// pick an existing subscriber or add a new one.
		/// Only after the subscriber and the coverage was entered,
		/// the patient is saved to the db.
		/// </summary>
		public bool SaveWithOrWithoutCoverage()
		{
			try
			{	
				if (!this.patient.IsNew)
					this.RaisePageException(
						new ActiveAdviceException( AAExceptionAction.None, "The patient must be new to call SaveWithOrWithoutCoverage from PatientForm"));

				this.intakeLog.Patient = this.patient;

				if(this.IsNewPatientFromEligibilityData)
				{
					this.intakeLog.Subscriber.Save(this.patient, this.intakeLog.PatientCoverage, this.patient.IsNew);
					PushPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "New Patient and New Coverage");
					IntakeForm.Redirect(this.intakeLog);
				}
				else
				{
					// if not from eligibility
					if (this.intakeLog.Subscriber == null)
						SubscriberSearch.Redirect(this.intakeLog);		// if no subscriber, pic a subscriber.
					else	// if there's subscriber use it
						SubscriberForm.Redirect(intakeLog);		// coverage for the existing subscriber
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/* Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMORGSearch();
		}
		*/

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.intakeLog != null)
			{
				IntakeForm.Redirect(intakeLog);
			}
			else
			{
				if (this.patient.IsNew)
					PatientSearch.Redirect();		// If the patient is new, don't redirect back to another patient context.
				else
					base.OnToolbarButtonClick_Cancel(toolbar, button);
			}
		}

		public void OnToolbarButtonClick_DefineSubscriber(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// called when the patient is new AND created by user.
			if (SaveDataForPatient())		// will automatically redirect to SubscriberSearch
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@PATIENT@");
			}
		}
		
		public void OnToolbarButtonClick_SaveWithCoverage(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// called when the patient is new AND imported from Eligibility data
			if (SaveDataForPatient())		
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@PATIENT@");
			}
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// called when the patient is NOT new
			if (SaveDataForPatient())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@PATIENT@");
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.intakeLog, this.patient);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientFocusHistoryCollection PatientFocusHistory
		{
			get { return patient.PatientFocusHistory; }
			set
			{
				try
				{
					// display all focus history
					gridFocus.UpdateFromCollection(patient.PatientFocusHistory);  // update given grid from the collection
					// display all available focuses
					gridAvailFocusCodes.KeepCollectionIndices = false;
					gridAvailFocusCodes.UpdateFromCollection(PatientFocusCollection.ActivePatientFocuses);
					
					this.Focus = null;	// go out of edit mode
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(PatientFocusHistoryCollection), patientFocusHistory);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientFocusHistory Focus
		{
			get { return focus; }
			set
			{
				focus = value;
				try
				{
					FocusToTerminate = null;
					pnlEditFocus.Visible = focus != null;
					this.UpdateFromObject(pnlEditFocus.Controls, focus);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PatientFocusHistory), focus);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForFocus()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlEditFocus.Controls, focus);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewFocus()
		{
			bool result = true;
			PatientFocusHistory focus = new PatientFocusHistory(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Focus = focus;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForFocus()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForFocus())
					return false;
				if (focus.ParentPatientFocusHistoryCollection == null)
					this.patient.PatientFocusHistory.Add(focus);
				// refresh focus history in the grid.
				this.PatientFocusHistory = patient.PatientFocusHistory;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void butOKFocus_Click(object sender, System.EventArgs e)
		{
			SaveDataForFocus();
		}

		private void butCancelFocus_Click(object sender, System.EventArgs e)
		{
			this.Focus = null;
		}

		/*private void gridAvailFocusCodes_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			object[] pk = gridAvailFocusCodes.GetPKFromClickEvent(e);
			if (pk == null)
				return;
			PatientFocusHistory focus = new PatientFocusHistory((int)pk[0]);
			this.Focus = focus;
		}*/

		private void butAddFocus_Click(object sender, System.EventArgs e)
		{
			if (gridAvailFocusCodes.SelectedRowIndex >= 0)
			{
				int focusCodeID = gridAvailFocusCodes.GetPKIntFromRowIndex(gridAvailFocusCodes.SelectedRowIndex);
				PatientFocusHistory focus = new PatientFocusHistory(focusCodeID);
				this.Focus = focus;
			}
			else
			{
				this.SetPageMessage("First select a focus code", EnumPageMessageType.Warning);
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientFocusHistory FocusToTerminate
		{
			get { return focusToTerminate; }
			set
			{
				focusToTerminate = value;
				try
				{
					pnlTerminateFocus.Visible = focusToTerminate != null;
					this.UpdateFromObject(pnlTerminateFocus.Controls, focusToTerminate);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PatientFocusHistory), focusToTerminate);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForFocusToTerminate()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlTerminateFocus.Controls, focusToTerminate);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForFocusToTerminate()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForFocusToTerminate())
					return false;

				this.PatientFocusHistory = patient.PatientFocusHistory;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void butCancelFocusTerminate_Click(object sender, System.EventArgs e)
		{
			this.FocusToTerminate = null;
		}

		/*private void gridFocus_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			int index = gridFocus.GetColIndexFromClickEvent(e);
			if (index < 0)
				return;
			PatientFocusHistory focus = patient.PatientFocusHistory[index];
			this.FocusToTerminate = focus;
		}*/

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientCOBCollection PatientCOBs
		{
			get { return patient.PatientCOBs; }
			set
			{
				try
				{
					gridPatientCOB.UpdateFromCollection(patient.PatientCOBs);  // update given grid from the collection

					this.PatientCOB = null;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(PatientCOBCollection), patientCOBs);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientCOB PatientCOB
		{
			get { return patientCOB; }
			set
			{
				patientCOB = value;
				try
				{
					pnlPatientCOBDetail.Visible = patientCOB != null;

					if (patientCOB != null)
					{
						this.UpdateFromObject(pnlPatientCOBDetail.Controls, patientCOB);  // update controls for the given control collection
					}
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PatientCOB), patientCOB);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPatientCOB()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlPatientCOBDetail.Controls, patientCOB);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPatientCOB()
		{
			bool result = true;
			PatientCOB patientCOB = new PatientCOB(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PatientCOB = patientCOB;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPatientCOB()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPatientCOB())
					return false;
				if (this.patientCOB.ParentPatientCOBCollection == null)
					patient.PatientCOBs.Add(this.patientCOB);

				this.PatientCOBs = this.PatientCOBs;		// refresh
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void butCancelPatientCOB_Click(object sender, System.EventArgs e)
		{
			this.PatientCOB = null;
		}

		private void butSavePatientCOB_Click(object sender, System.EventArgs e)
		{
			SaveDataForPatientCOB();
		}

		private void gridPatientCOB_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			// Add an edit button when the grid is populated
			if (!this.IsPopup)
				gridPatientCOB.AddButtonColumn("Edit", "@EDIT@", 0);
		}

		private void gridPatientCOB_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Edit")
			{
				// The Edit button was clicked, get the index and set it
				// to the current page data property which will automatically
				// set the UI context to edit mode.
				int index = gridPatientCOB.GetColIndexFromCellEvent(e);
				if (index < 0)
					return;

				this.PatientCOB = this.patient.PatientCOBs[index];
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			if (this.patient == null)
				return;

			bool IsNew = this.patient.IsNew;
			this.SetPageToolbarItemVisible("Save", IsNew ? false : EligibilityAddAnyway /* if editing check existing coverage */);
			this.SetPageToolbarItemVisible("SaveWithCoverage", IsNew && IsNewPatientFromEligibilityData/*called when the patient is new AND imported from Eligibility data*/);
			this.SetPageToolbarItemVisible("DefineSubscriber", IsNew && !IsNewPatientFromEligibilityData/*called when the patient is new AND created by user.*/);

			IsPrimary.Enabled = patientCOB != null && !patientCOB.IsNew;
			
			SetReadOnlyState();
		}

		private void butTerminate_Click(object sender, System.EventArgs e)
		{
			if (gridFocus.SelectedRowIndex >= 0)
			{
				int index = (int)gridFocus.GetColIndexFromRowIndex( gridFocus.SelectedRowIndex );
				PatientFocusHistory focus = this.PatientFocusHistory[index];
				this.FocusToTerminate = focus;
				Active.Checked = false;			// this will terminate when committed
			}
			else
			{
				this.SetPageMessage("First select a focus from the focus history", EnumPageMessageType.Warning);
			}
		}

		private void butTerminateFocus_Click(object sender, System.EventArgs e)
		{
			SaveDataForFocusToTerminate();	
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(this.patient, this.patient.Address, this.patient.UserDefined, this.patient.PatientFocusHistory, this.patient.PatientCOBs);
		}

		private void SetReadOnlyState()
		{
			if(!this.patient.IsNew)
				return;
			if(EligibilityAddAnyway)
				return;
			
			// Controls become Enabled = false ONLY when EligibilityAddAnyway IS false AND New Patient
			SetPropertyState(this.pnlDetails.Controls, ControlPropertyName.Enabled, false, false);
			SetPropertyState(this.pnlAddress.Controls, ControlPropertyName.Enabled, false, false);
			SetPropertyState(this.pnlUserDefined.Controls, ControlPropertyName.Enabled, false, true);
			SetPropertyState(this.pnlFocuses.Controls, ControlPropertyName.Enabled, false, true);
			SetPropertyState(this.pnlPatientCOB.Controls, ControlPropertyName.Enabled, false, true);
		}

		private bool IsNewPatientFromEligibilityData
		{
			get
			{
				return this.intakeLog != null && this.intakeLog.Patient.IsNew && 
					this.intakeLog.PatientCoverage != null && 
					this.intakeLog.PatientCoverage.PatientEligibilityID > 0;
			}
		}

		private bool IsNewPatientCoverageFromEligibilityData
		{
			get
			{
				return this.intakeLog != null && this.intakeLog.PatientCoverage != null && this.intakeLog.PatientCoverage.IsNew && 
					this.intakeLog.PatientCoverage.PatientEligibilityID > 0;
			}
		}

	}
}
