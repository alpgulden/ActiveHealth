using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{

	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Assessment,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[PageTitle("@ASSESSMENTSPAGETITLE@")]
	public class Assessments : PatientBasePage
	{
		private DiagnosticSelectCollection diagnosticSelects;
		private ProcedureSelectCollection procedureSelects;
				

		private Assessment assessment;
		private AssessmentCollection assessments;
		private AssessmentContext assessmentContext;
		private CMS cMS;
		private Problem problem;
		private PatientCoverage patientCoverage;
		private Patient patient;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDxPx;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDx;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnPx;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSelectedPXCodes;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSelectedDXCodes;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grid_ColumnsBoundToDataClass);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.wbtnDx.Click += new System.EventHandler(this.wbtnDx_Click);
			this.wbtnPx.Click += new System.EventHandler(this.wbtnPx_Click);
			this.ValidationsOnlyInSummary = true;
			this.ViewStateOnServer = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
				LoadData();
			else
			{
				cMS = (CMS)this.LoadObject(typeof(CMS));
				assessments = (AssessmentCollection)this.LoadObject(typeof(AssessmentCollection));  // load object from cache
				assessment = (Assessment)this.LoadObject(typeof(Assessment));  // load object from cache
				procedureSelects = (ProcedureSelectCollection)this.LoadObject("ProcedureSelects");  // load object from cache
				diagnosticSelects = (DiagnosticSelectCollection)this.LoadObject("DiagnosticSelects");  // load object from cache
			}

			assessmentContext = (AssessmentContext)this.LoadObject(typeof(AssessmentContext));
			if (assessmentContext != null) AssessmentView.Redirect(assessmentContext);

			problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
			patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
			patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache	
		}

		private void LoadData()
		{
			cMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;
			if (cMS == null)
			{
				this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a CMS"));
				return;
			}
			this.CacheObject(typeof(CMS), cMS);
			try
			{
				LoadDataForProcedureSelects();
				LoadDataForDiagnosticSelects();

				if(!LoadDataForAssessments())
					this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, "I was not able to Load Assessments for CMS with ID " + cMS.CMSID.ToString()));
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		
		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("Assessments.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(CMS cMS)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CMS", cMS);
			PushTargetTab("ASMT_Assessment");
			BasePage.Redirect("Assessments.aspx");
		}


		#region UI events and Initialization
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.cMS);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.SetERCTabVisibilities();
			SetPageTabItemActive(TargetTabKey);
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "ASMT_Assessment")
			{
				toolbar.AddButton("@STARTNEWASSESSMENT@", "AddNew");
			}
		}
		
		[System.Diagnostics.Conditional("DEBUG")]
		public void OnToolbarButtonClick_Test(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.Assessment = this.Assessments_[0];
			AssessmentContext assessmentContext = new AssessmentContext(this.cMS, this.Assessment);	
			AssessmentForm.Redirect(assessmentContext);
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// Try to create a new Assessment object
			if (!NewAssessment())
				return;
		
			try
			{
				// Delay this
				//AssessmentContext assessmentContext = new AssessmentContext(this.cMS, this.Assessment);	
				
				// This is a new assessment so it's not readonly
				//assessmentContext.IsReadOnly = false; 

				// Set the isnew to true so that assessment can be cancelled upon users request
				//assessmentContext.IsNew = true;
				
				// If somehow we're creating a new assessment and there's actually an assessment context 
				// (for another assessment) just remove that 
				this.CacheObject(typeof(AssessmentContext), null);
				this.CacheObject(typeof(Assessment), null);

				AssessmentForm.Redirect(this.cMS, assessment);
			}
			catch(Exception ex)
			{
				this.RaisePageException (new ActiveAdviceException(AAExceptionAction.DisableUI, ex.ToString()));
			}
			
		}

		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			grid.AddButtonColumn("Select", "Select", 0);			
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Select")
			{
				// Fix: Do not pass the assessment object on the CMS this creates problems
				Assessment assessment = Assessments_[index];
				// redirect to AssessmentsView.aspx
				AssessmentContext assessmentContext = new AssessmentContext(this.cMS, assessment.AssessmentGUID);	

				// Make sure the assessment is opened in readonly mode
				assessmentContext.IsReadOnly = true; 

				// Let's reset the context
				this.CacheObject(typeof(AssessmentContext), null);
				this.CacheObject(typeof(Assessment), null);

				AssessmentView.Redirect(assessmentContext);
			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
		}

		private void wbtnDx_Click(object sender, System.EventArgs e)
		{
			try
			{
				//ZippyCoderForm.Redirect(this.cMS, this.cMS.CreateDiagnosticSelectionCollection());
				ZippyCoderForm.Redirect(this.cMS, this.diagnosticSelects);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void wbtnPx_Click(object sender, System.EventArgs e)
		{
			try
			{
				//ZippyCoderForm.Redirect(this.cMS, this.cMS.CreateProcedureSelectionCollection());
				ZippyCoderForm.Redirect(this.cMS, this.procedureSelects);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}	
		}
		#endregion
		
		#region Data objects
		#region Assessments
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentCollection Assessments_
		{
			get { return assessments; }
			set
			{
				assessments = value;
				try
				{
					grid.UpdateFromCollection(assessments);  // update given grid from the collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AssessmentCollection), assessments);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		private bool LoadDataForAssessments()
		{
			bool result = true;
			AssessmentCollection assessments = null;
			try
			{	
				cMS.LoadAssessments(false);
				assessments = cMS.Assessments;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.Assessments_ = assessments;
			return result;
		}

//		/// <summary>
//		/// Call this method when you want to retrieve data from controls and save them to table.
//		/// </summary>
//		public bool SaveDataForAssessments()
//		{
//			try
//			{	// data from controls to object
//				cMS.Assessments = Assessments_;
//				cMS.SaveAssessments();
//			}
//			catch(Exception ex)
//			{
//				this.RaisePageException(ex);
//				return false;
//			}
//			return true;
//		}
		#endregion

		#region Assessment
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Assessment Assessment
		{
			get { return assessment; }
			set
			{
				assessment = value;
				this.CacheObject(typeof(Assessment), assessment);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAssessment()
		{
			bool result = true;
			Assessment assessment = null; //new Assessment(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				assessment = new Assessment(true);
				if (SystemControlValue.GetInstance.AssessmentContentOwnerID < 1)
				{
					this.RaisePageException (new ActiveAdviceException(AAExceptionAction.DisableUI, "SystemControlValue.GetInstance.AssessmentContentOwnerID is NOT set."));
					return false;
				}
				assessment.ContentOwnerID = SystemControlValue.GetInstance.AssessmentContentOwnerID;
				assessment.CMSID = this.cMS.CMSID;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.Assessment = assessment;
			return result;
		}
		#endregion

		#region ProcedureSelects
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ProcedureSelectCollection ProcedureSelects
		{
			get { return procedureSelects; }
			set
			{
				procedureSelects = value;
				try
				{
					this.gridSelectedPXCodes.UpdateFromCollection(procedureSelects);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("ProcedureSelects", procedureSelects);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForProcedureSelects()
		{
			bool result = true;
			ProcedureSelectCollection procedureSelects = new ProcedureSelectCollection();
			try
			{	// use any load method here
				this.cMS.LoadCMSDiagnosticProcedures(false);
				procedureSelects = this.cMS.CreateProcedureSelectionCollection();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//procedureSelects.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.ProcedureSelects = procedureSelects;
			return result;
		}
		#endregion

		#region DiagnosticSelects
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public DiagnosticSelectCollection DiagnosticSelects
		{
			get { return diagnosticSelects; }
			set
			{
				diagnosticSelects = value;
				try
				{
					this.gridSelectedDXCodes.UpdateFromCollection(diagnosticSelects);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("DiagnosticSelects", diagnosticSelects);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForDiagnosticSelects()
		{
			bool result = true;
			DiagnosticSelectCollection diagnosticSelects = new DiagnosticSelectCollection();
			try
			{	// use any load method here
				this.cMS.LoadCMSDiagnosticProcedures(false);
				diagnosticSelects = this.cMS.CreateDiagnosticSelectionCollection();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//diagnosticSelects.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.DiagnosticSelects = diagnosticSelects;
			return result;
		}
		#endregion
		#endregion

	}
}
