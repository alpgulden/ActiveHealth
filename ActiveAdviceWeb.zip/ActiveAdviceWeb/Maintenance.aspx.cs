using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	[MainLanguageClass("ActiveAdvice.Messages.BaseMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Assessment,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]

	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FILE_MAINTENANCE)]

	public class Maintenance : BasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder6;
		protected NetsoftUSA.WebForms.OBLabel selection;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReportMainteinance;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("Maintenance.aspx");
		}


		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			if (AASecurityHelper.IsAdminRole)
				listbar.AddItem("@SECURITY@", "Security");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.ASSESSMENTS_MAINT))
				listbar.AddItem("@ASSESSMENTS@", "Assessments");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_SETUP))
				listbar.AddItem("@LETTERS@", "Letters");

			listbar.AddItem("@FAXVIEWLOG@", "FaxLog");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.CMS_MAINT))
				listbar.AddItem("@CMS@", "CMS");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.CODE_TABLES))
				listbar.AddItem("@CODE@","Code");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.IMPORT_EXPORT_MAINT))
				listbar.AddItem("@INTERFACE@", "Interface");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.USER_DEFINED_MAINT))
				listbar.AddItem("@USERDEFINED@", "UserDefined");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.AUTO_ACTIVITIES_MAINT))
				listbar.AddItem("@AUTOACTIVITIES@", "AutoActivities");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.GUIDELINES_MAINT))
				listbar.AddItem("@GUIDELINES@","Guidelines");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.TEAMS_MAINT))
				listbar.AddItem("@TEAMS@","Teams");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.ENROLLMENTS_MAINT))
				listbar.AddItem("@ENROLLMENTS@","Enrollments");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.SYSTEM_SETTINGS))
				listbar.AddItem("@SYSVALUES@", "SystemValues");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.SYSTEM_SETTINGS))
				listbar.AddItem("@DUPLICATECASECHECKING@", "DuplicateCase");

			listbar.AddItem("@LICENSEE@", "Licensee");

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.ELIGIBILITY_SEARCH))
				listbar.AddItem("@ELIGIBILITYSEARCH@", "EligibilitySearch");
			
			//if (AASecurityHelper.HasFullAccessRole(AASecurityHelper. ))			
			listbar.AddItem("@MEMBERLIVESUTIL@", "MemberLivesUtil");

			// Adding MOVE E/R/C Link -- Burag C. 03/03/06			
			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.MOVEERC_MAINTENANCE))
				listbar.AddItem("@MOVEERC@","MoveERC");

		}

		public void OnSubNavigationItemClick_MoveERC(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ERCLinkMaintenance.Redirect(); // Redirect to ERCLinkMaintenance
		}

		public void OnSubNavigationItemClick_Interface(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ImportExportTasks.aspx");
		}

		public void OnSubNavigationItemClick_DuplicateCase(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("DuplicateCheckCriteriaForm.aspx");
		}

		public void OnSubNavigationItemClick_Security(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("SecurityGroupForm.aspx");
		}

		public void OnSubNavigationItemClick_Assessments(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("QuestionSearch.aspx");
		}

		public void OnSubNavigationItemClick_Letters(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			//Response.Redirect("LetterSetMaintenance.aspx");
			BasePage.Redirect("LetterMaintenance.aspx");
		}

		public void OnSubNavigationItemClick_FaxLog(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("FaxLogMaintenance.aspx");
		}

		public void OnSubNavigationItemClick_Code(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("CodeMaintenance.aspx");
		}

		public void OnSubNavigationItemClick_UserDefined(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("UserDefinedField.aspx");
		}

		public void OnSubNavigationItemClick_CMS(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("PackingListItemManagement.aspx");
		}

		public void OnSubNavigationItemClick_AutoActivities(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("AutoActivityForm.aspx");
		}

		public void OnSubNavigationItemClick_Guidelines(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("GuidelineCategoryProduct.aspx");
		}

		public void OnSubNavigationItemClick_Teams(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("TeamForm.aspx");
		}

		public void OnSubNavigationItemClick_Enrollments(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("EnrollmentsForm.aspx");
		}

		public void OnSubNavigationItemClick_SystemValues(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("SystemMaintanence.aspx");
		}

		public void OnSubNavigationItemClick_Licensee(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("LicenseeForm.aspx");
		}

		public void OnSubNavigationItemClick_EligibilitySearch(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("EligibilityMainSearch.aspx");
		}

		public void OnSubNavigationItemClick_MemberLivesUtil(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			MemberLivesUtilityForm.Redirect();
		}

		#region Web Form Designer generated code
								override protected void OnInit(EventArgs e)
								{
						//
						// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion




	}
}
