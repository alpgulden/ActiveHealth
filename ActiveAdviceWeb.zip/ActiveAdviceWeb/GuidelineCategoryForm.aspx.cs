using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.InfragisticsWeb;
using NetsoftUSA.WebForms;
using ActiveAdvice.DataLayer;
using NetsoftUSA.DataLayer;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for GuidelineCategoryForm.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.GUIDELINES)]
	
	[MainLanguageClass("ActiveAdvice.Messages.GuidelineMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("GuidelineCategory,DataLayer")]
	[BackPage(typeof(GuidelineCategoryProduct))]
	[PageTitle("@GUIDELINECATEGORYTITLE@")]
	public class GuidelineCategoryForm : BasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebTab UltraWebTab1;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCategory;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGuidelineSourceSetID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GuidelineSourceSetID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGuidelineSourceSetID;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected GuidelineCategory category;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
			{
				LoadData();
			}
			else
			{
				category = (GuidelineCategory) this.LoadObject(typeof(GuidelineCategory));
			}
		}

		private bool LoadData()
		{
								
			try
			{	// use any load method here
				category = this.GetParamOrGetFromCache("GuidelineCategory", typeof(GuidelineCategory)) as ActiveAdvice.DataLayer.GuidelineCategory;
				if (category == null)
				{
					return NewGuidelineCategory();
				}
				this.Category = category;		// When you set the object to the property, controls are automatically populated
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public bool NewGuidelineCategory()
		{
			try
			{
				GuidelineCategory prod = new GuidelineCategory(true);
				Category = prod;
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
		}

		public GuidelineCategory Category
		{
			get
			{
				return category;
			}
			set
			{
				this.category = value;
				try
				{
					this.UpdateFromObject(this.pnlCategory.Controls,category);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject(typeof(GuidelineCategory),category);
			}
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@SAVE@", "Save", true);
			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@GUIDELINECATEGORY@");
			}
		} 

		public bool SaveData()
		{
			bool result = true;
			try
			{
				if(this.ReadControls())
					category.Save();
				else
					return false;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				result = false;
			}
			return result;

		}

		public bool ReadControls()
		{
			try
			{
				this.UpdateToObject(this.pnlCategory.Controls,category);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
