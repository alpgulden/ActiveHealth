using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.BaseMessages,DataLayer")]		// Define the message class for this module
	//[MainDataClass("Question,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	//[SelectedMainMenuItem("")]					
	//[SelectedMenuItem("")]
	[PageTitle("@DATESELECT@")]
	public class DateSelectForm : BasePage
	{
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDateSelect;
		protected System.Web.UI.WebControls.Calendar Calendar1;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;

		private void Page_Load(object sender, System.EventArgs e)
		{
			this.WindowMode = WindowMode.ModalDialog;
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
			}
		}

		public bool LoadData()
		{
			DateTime date = DateTime.Today;
			string sdate = Request.QueryString["Date"];
			if (sdate != null && sdate != "")
				date = DateTime.Parse(sdate);

			Calendar1.SelectedDate = date;
			return true;
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Calendar1.DayRender += new System.Web.UI.WebControls.DayRenderEventHandler(this.Calendar_DayRender);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}

		private void Calendar_DayRender(object sender, System.Web.UI.WebControls.DayRenderEventArgs e)
		{
			string sdate = e.Day.Date == DateTime.MinValue ? (string)null : e.Day.Date.ToString();
			e.Cell.Text = String.Format( "<a href=# onclick=\"window.opener.{0}('{1}'); window.close();return false;\">{2}</a>", this.CallbackFunction, sdate, e.Day.DayNumberText);
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddButton("@OK@", "OK").Item.TargetURL = String.Format( "javascript:OnSelectDate(
			toolbar.AddButton("@CLOSE@", "Close").Item.TargetURL = "javascript:window.close();";
				
		}
		
	}
}
