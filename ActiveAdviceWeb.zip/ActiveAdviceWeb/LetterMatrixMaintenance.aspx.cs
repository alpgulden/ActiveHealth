using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterMatrixMaintenance.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.LETTER_SETUP)]
	
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterMatrix,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("LetterMatrix")]
	[PageTitle("@LETTERMATRIXPAGETITLE@")]
	public class LetterMatrixMaintenance : LetterMaintenanceBasePage
	{
		private LetterMatrix letterMatrix;
		private bool toReadSomeControls;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSessionIndicator;
		protected NetsoftUSA.InfragisticsWeb.WebCombo SessionIndicator;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSessionIndicator;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLetterSetID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo LetterSetID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLetterSetID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralUnitID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ReferralUnitID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferralUnitID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ReferralTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferralTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldClinicalReviewDecisionReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ClinicalReviewDecisionReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbClinicalReviewDecisionReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldClinicalReviewDecisionTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ClinicalReviewDecisionTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbClinicalReviewDecisionTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEventTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EventTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrganizationId;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganization;
		protected System.Web.UI.WebControls.Literal OrganizationPath;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtOrganizationPath;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMatrixTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MatrixTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMatrixTypeID;
		protected System.Web.UI.WebControls.Label lblOrganizationPath;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLetterTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo LetterTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLetterTypeI;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFacilityState;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityState;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityState;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLetterTypeID;
		protected NetsoftUSA.WebForms.OBTextBox Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEnrollmentID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EnrollmentID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEnrollmentID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected System.Web.UI.HtmlControls.HtmlTable tblOrganization;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected System.Web.UI.WebControls.Image butClear;
		protected PlanSelect PlanSelect1;
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.MatrixTypeID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.MatrixTypeID_SelectedRowChanged);
			
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{

			// Put user code to initialize the page here
			PlanSelect1.RebindControls(typeof(LetterMatrix), "PlanID", "PlanName");
			if (!IsPostBack)
				this.LoadData();
			else
			{
				letterMatrix = (LetterMatrix)this.LoadObject(typeof(LetterMatrix));  // load object from cache

				// If the organization has changed we need to reload the enrolments
				if (ReadControlsForOrganization())
				{
					this.UpdateFromObject(this.EnrollmentID, letterMatrix);
				}
			}
		}

		#region UI Initialization and Events
		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "LetterMatrix":
					toolbar.AddButton(Messages.BaseMessages.MessageIDs.ADDNEWRECORD, "AddNewLetterMatrix");
					break;
			}
		}
		
		public void OnToolbarButtonClick_AddNewLetterMatrix(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewData();
		}
		
		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "LetterMatrix "); 
		}

		private void MatrixTypeID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			this.toReadSomeControls = true;	// force reading of selected controls
		}

		/// <summary>
		/// Alters visible GUI controls depending on selected MatrixType
		/// </summary>
		private void SetUIState()
		{
			string code;
			if(this.MatrixTypeID.Value == null)
				code = "default";
			else
			{
				this.UpdateToObject(MatrixTypeID, letterMatrix);
				code = MatrixTypeCollection.ActiveMatrixTypes.Lookup_CodeByMatrixTypeID((int)this.MatrixTypeID.Value);
			}


			switch(code)
			{
				case "REFR":
					this.LetterTypeID.Visible = false; this.lbLetterTypeID.Visible = false; this.vldLetterTypeID.Visible = false;
					this.FacilityState.Visible = true; this.lbFacilityState.Visible = true; this.vldFacilityState.Visible = true;
					this.ReferralTypeID.Visible = true; this.lbReferralTypeID.Visible = true; this.vldReferralTypeID.Visible = true;
					this.ReferralUnitID.Visible = true; this.lbReferralUnitID.Visible = true; this.vldReferralUnitID.Visible = true;
					this.SessionIndicator.Visible = true; this.lbSessionIndicator.Visible = true; this.vldSessionIndicator.Visible = true;
					this.EventTypeID.Visible = false; this.lbEventTypeID.Visible = false; this.vldEventTypeID.Visible = false;
					this.ClinicalReviewDecisionReasonID.Visible = false; this.lbClinicalReviewDecisionReasonID.Visible = false; this.vldClinicalReviewDecisionReasonID.Visible = false;
					this.ClinicalReviewDecisionTypeID.Visible = false; this.lbClinicalReviewDecisionTypeID.Visible = false; this.vldClinicalReviewDecisionTypeID.Visible = false;

					break;
				case "E&CR":
					this.LetterTypeID.Visible = false; this.lbLetterTypeID.Visible = false; this.vldLetterTypeID.Visible = false;
					this.FacilityState.Visible = true; this.lbFacilityState.Visible = true; this.vldFacilityState.Visible = true;
					this.ReferralTypeID.Visible = false; this.lbReferralTypeID.Visible = false; this.vldReferralTypeID.Visible = false;
					this.ReferralUnitID.Visible = false; this.lbReferralUnitID.Visible = false; this.vldReferralUnitID.Visible = false;
					this.SessionIndicator.Visible = true; this.lbSessionIndicator.Visible = true; this.vldSessionIndicator.Visible = true;
					this.EventTypeID.Visible = true; this.lbEventTypeID.Visible = true; this.vldEventTypeID.Visible = true;
					this.ClinicalReviewDecisionReasonID.Visible = true; this.lbClinicalReviewDecisionReasonID.Visible = true; this.vldClinicalReviewDecisionReasonID.Visible = true;
					this.ClinicalReviewDecisionTypeID.Visible = true; this.lbClinicalReviewDecisionTypeID.Visible = true; this.vldClinicalReviewDecisionTypeID.Visible = true;
					break;
				default:
					this.LetterTypeID.Visible = true; this.lbLetterTypeID.Visible = true; this.vldLetterTypeID.Visible = true;
					this.FacilityState.Visible = false; this.lbFacilityState.Visible = false; this.vldFacilityState.Visible = false;
					this.ReferralTypeID.Visible = false; this.lbReferralTypeID.Visible = false; this.vldReferralTypeID.Visible = false;
					this.ReferralUnitID.Visible = false; this.lbReferralUnitID.Visible = false; this.vldReferralUnitID.Visible = false;
					this.SessionIndicator.Visible = false; this.lbSessionIndicator.Visible = false; this.vldSessionIndicator.Visible = false;
					this.EventTypeID.Visible = false; this.lbEventTypeID.Visible = false; this.vldEventTypeID.Visible = false;
					this.ClinicalReviewDecisionReasonID.Visible = false; this.lbClinicalReviewDecisionReasonID.Visible = false; this.vldClinicalReviewDecisionReasonID.Visible = false;
					this.ClinicalReviewDecisionTypeID.Visible = false; this.lbClinicalReviewDecisionTypeID.Visible = false; this.vldClinicalReviewDecisionTypeID.Visible = false;
					break;
			}
			presetCombos();
			SetOrganizationHTML();
		}

		/// <summary>
		/// Presets default selection for combos to "All" if matching int property = 0 (DBNULL)
		/// </summary>
		private void presetCombos()
		{
			if(this.EventTypeID.SelectedIndex < 1)
				this.EventTypeID.Value = 0;
			
			if(this.ClinicalReviewDecisionTypeID.SelectedIndex < 1)
				this.ClinicalReviewDecisionTypeID.Value = 0;
			
			if(this.ClinicalReviewDecisionReasonID.SelectedIndex < 1)
				this.ClinicalReviewDecisionReasonID.Value = 0;
			
			if(this.ReferralTypeID.SelectedIndex < 1)
				this.ReferralTypeID.Value = 0;
			
			if(this.ReferralUnitID.SelectedIndex < 1)
				this.ReferralUnitID.Value = 0;

			if(this.EnrollmentID.Rows.Count == 1)	// ONLY "All" is available
				this.EnrollmentID.Value = 0;

			
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty();
			this.CheckForDirty(letterMatrix);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			
			if(this.toReadSomeControls)
			{
				ReadSomeControls();
				LetterMatrix = this.letterMatrix;
				this.toReadSomeControls = false;
			}
			SetUIState();
		}

		private void SetOrganizationHTML()
		{
			if(letterMatrix.OrganizationId > 0)
			{
				Organization o = new Organization();
				if (o.Load(letterMatrix.OrganizationId))
					this.lblOrganizationPath.Text = CreateOrgPathHTML(null, o);
			}
			else
				this.lblOrganizationPath.Text = "All";
		}
		
		#endregion

		#region LetterMatrix
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterMatrix LetterMatrix
		{
			get { return letterMatrix; }
			set
			{
				letterMatrix = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, letterMatrix);
					// other object-to-control methods if any
					/*if(this.LetterSetID.Rows.Count == 0)
						this.SetPageMessage("No Letter Sets are associated with selected Matrix Type. Letter Matrix cannot be created.", 
							EnumPageMessageType.AddWarning);*/
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterMatrix), letterMatrix);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, letterMatrix);
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Reads control values From following fields:
		/// Matrix Type, Termination Date, Enrollment, Plan.
		/// Required when Matrix Type is changed.
		/// </summary>
		public bool ReadSomeControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.MatrixTypeID, letterMatrix);
				this.UpdateToObject(this.TerminationDate, letterMatrix);
				this.UpdateToObject(this.EnrollmentID, letterMatrix);

				WebNumericEdit control = this.PlanSelect1.FindControl("txbPlanId") as WebNumericEdit;
					letterMatrix.PlanID = control.ValueInt;
				// other control-to-object methods if any
				return true;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Read Organization ID ONLY if it was changed.
		/// </summary>
		/// <returns></returns>
		public bool ReadControlsForOrganization()
		{
			try
			{	//customize this method for this specific page
				if(letterMatrix.OrganizationId == this.OrganizationId.ValueInt)
					return false;
				this.UpdateToObject(tblOrganization.Controls, letterMatrix);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewData()
		{
			bool result = true;
			LetterMatrix letterMatrix = null; //new LetterMatrix(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				letterMatrix = new LetterMatrix(true);
				this.lblOrganizationPath.Text = "All";
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.LetterMatrix = letterMatrix;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			LetterMatrix letterMatrix = new LetterMatrix();
			try
			{	// use any load method here
				letterMatrix = GetParamOrGetFromCache("LetterMatrix", typeof(LetterMatrix)) as LetterMatrix;
				if (letterMatrix == null) 
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a LetterMatrix");			
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterMatrix.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterMatrix = letterMatrix;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(LetterMatrix letterMatrix)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("LetterMatrix", letterMatrix);
			BasePage.Redirect("LetterMatrixMaintenance.aspx");

		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				letterMatrix.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			finally
			{
			}
			return true;
		}
		#endregion

	}
}
