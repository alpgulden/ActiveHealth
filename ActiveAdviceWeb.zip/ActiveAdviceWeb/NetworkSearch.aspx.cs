using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.NetworkMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Network,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MProviderFacility")]
	[SelectedMenuItem("Networks")]
	[PageTitle("@NETWORKSEARCHTITLE@")]
	public class NetworkSearch : ProviderBasePage
	{
		private Address networkAddressSearch;
		private NetworkCollection resultNetworks;
		private Network searchNetworkInfo;
		private int startID = 0;
		private string startName = "";

		
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProviderFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResults;
		protected System.Web.UI.WebControls.RadioButton rdBtnName;
		protected System.Web.UI.WebControls.RadioButton rdBtnID;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSearchName;
		protected System.Web.UI.WebControls.RadioButtonList rdSearchBy;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearchName;
		protected NetsoftUSA.WebForms.OBComboBox TypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit Zip;
		protected NetsoftUSA.WebForms.OBFieldLabel lbZip;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit County;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCounty;
		protected NetsoftUSA.WebForms.OBComboBox State;
		protected NetsoftUSA.WebForms.OBFieldLabel lbState;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit City;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCity;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridNetworks;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkInfo;
		protected System.Web.UI.HtmlControls.HtmlTable tblID;
		protected System.Web.UI.HtmlControls.HtmlTable tblAddress;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NetworkID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lb;
		protected NetsoftUSA.WebForms.OBFieldLabel lblAlternateD;
		private   int  selectWidth = 65;
		protected NetsoftUSA.WebForms.OBFieldLabel lblNetworkID;
		protected NetsoftUSA.WebForms.OBFieldLabel lblAlternateID;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnPrevious;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnNext;	
		private PatientCoverage patCov;
		// when in popup mode it will cause a postback on calling page when
		// locationitem is dblclicked.
		private void Page_Load(object sender, System.EventArgs e)
		{

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				// translate manually added text's
				TranslateNames();
				this.LoadData();
			}
			else
			{
				searchNetworkInfo = (Network)this.LoadObject("objNetworkSearch");  // load object from cache
				resultNetworks = (NetworkCollection)this.LoadObject("objResultNetworks");  // load object from cache
				patCov = (PatientCoverage)this.LoadObject(typeof(PatientCoverage), false);  // load object from cache
				networkAddressSearch = (Address)this.LoadObject("objNetworkAddressSearch");  // load object from cache
			}			
		}

		private void LoadData()
		{
			if (this.HasCallbackFunction)
			{
				this.ClearProviderContext();
				patCov = this.GetParamOrGetFromCache("PatCov", typeof(PatientCoverage)) as PatientCoverage ;
			}

			if (this.HasCallbackFunction && Request.QueryString["Addr"] == "1")
			{
				this.ClearProviderContext();

				// Address Info
				if (Request.QueryString["State"] != null)
				{
					Address addr = new Address();
					addr.State = Request.QueryString["State"];
					this.SearchNetworkAddress = addr;
				}
				else
					this.SearchNetworkAddress = new Address();

				// Network Info
				if (patCov.PlanID != 0)
				{
					NetworkPlanLink networkPlanLink = new  NetworkPlanLink();
					this.SearchNetworkAddress = new Address();
					if (patCov.PlanID != 0)
						networkPlanLink.PlanId = patCov.PlanID;
					if (Request.QueryString["StartDate"] != null)
					{
						networkPlanLink.StartDate = DateTime.Parse(Request.QueryString["StartDate"].ToString());
					}
				}
				else
					this.SearchNetworkAddress = new Address ();
			}
			else
				NewSearch();
			//
			this.pnlResults.Visible = false;
			//this.pnlResults2.Visible = false;
			this.SetSearchFormVisibility(0);	// Search By Name enabled by default
			this.BlankForm = true;

			startID = 0;
			startName = "";
		}

		private void TranslateNames()
		{
			this.rdSearchBy.Items[0].Text = this.Language.TranslateSingle("NAME");
			this.rdSearchBy.Items[1].Text = this.Language.TranslateSingle("ID");
		}

		private void BindForm()
		{
			this.UpdateFromObject(this.tblNetworkInfo.Controls, this.searchNetworkInfo );
			this.UpdateFromObject(this.tblAddress.Controls, this.networkAddressSearch   );
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("NetworkSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.rdSearchBy.SelectedIndexChanged += new System.EventHandler(this.rdSearchBy_SelectedIndexChanged);
			this.btnSearchName.Click += new System.EventHandler(this.btnSearchName_Click);
			this.gridNetworks.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridNetworks_DblClick);
			this.gridNetworks.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridNetworks_ClickCellButton);
			this.gridNetworks.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.gridNetworks_RowBoundToDataObject);
			this.gridNetworks.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridNetworks_ColumnsBoundToDataClass);
			this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
			this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("@NEWSEARCH@", "NewSearch");
			toolbar.AddButton("@ADDNEWRECORD@", "AddNew");
		}
		
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewSearch ();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// add new 
			NetworkForm.Redirect(0);
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
		}

		private void btnSearchName_Click(object sender, System.EventArgs e)
		{
			this.gridNetworks.ClearValuesForPageStart();
			ReadForm(this.rdSearchBy.SelectedIndex);
		}

		private void rdSearchBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetSearchFormVisibility(rdSearchBy.SelectedIndex);

		}

		private void ReadForm(int searchBy)
		{
			if (searchBy == 1)
			{
				this.UpdateToObject(this.tblID.Controls, this.searchNetworkInfo, false);
			}
			else
			{
				// Read To Controls
				this.UpdateToObject(this.tblNetworkInfo.Controls, this.searchNetworkInfo, false); // basic info
				this.UpdateToObject(this.tblAddress.Controls, this.networkAddressSearch, false);  // address info
			}
			// call search 
			Search(this.searchNetworkInfo,this.networkAddressSearch);
			
		}

		private void Search(Network network,Address netAddress)
		{
			NetworkCollection netCol = new NetworkCollection();
			netCol.SearchNetworks(NetworkCollection.MAXRECORDS, startID, startName, network,netAddress);
			this.ResultNetworks = netCol;
		}
		
		private void NewSearch()
		{
			this.NewNetworkSearch();
			this.NewAddressSearch();
		}
		
		public bool NewNetworkSearch()
		{
			bool result = true;
			Network searchNetworkInfo = new Network(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchNetworkInfo.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.NetworkSearchObj = searchNetworkInfo;
			return result;
		}
		
		
		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAddressSearch()
		{
			bool result = true;
			Address searchNetworkAddress = new Address(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchNetworkAddress.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchNetworkAddress  = searchNetworkAddress;
			return result;
		}
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Address SearchNetworkAddress
		{
			get { return networkAddressSearch; }
			set
			{
				networkAddressSearch  = value;
				try
				{
					this.UpdateFromObject(this.tblAddress.Controls, networkAddressSearch);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objNetworkAddressSearch", networkAddressSearch);  // cache object using the caching method declared on the page
			}
		}

		private void SetSearchFormVisibility(int selectedIndex)
		{
			switch (selectedIndex)
			{
				default:
				case 0:
					tblID.Visible =  false;
					tblAddress.Visible = tblNetworkInfo.Visible = true;
					ClearSearchFields();
					break;
				case 1:
					ClearSearchFields();
					tblID.Visible =  true;
					tblAddress.Visible = tblNetworkInfo.Visible = false;
					break;
			}
		}

		private void ClearSearchFields()
		{
			NewSearch();
		}


		private void gridNetworks_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			int index = -1;
			if (e.Cell != null)
				index = (int)e.Cell.Row.DataKey;
			else if (e.Row != null)
				index = (int)e.Row.DataKey;

			if (index != -1)
			{
				//
			}
		}





		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Network NetworkSearchObj
		{
			get { return searchNetworkInfo; }
			set
			{
				searchNetworkInfo = value;
				try
				{
					this.UpdateFromObject(this.tblNetworkInfo.Controls, searchNetworkInfo);  // update controls for the given control collection
					this.UpdateFromObject(this.tblID.Controls, searchNetworkInfo);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objNetworkSearch", searchNetworkInfo);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForNetworkSearchObj()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblNetworkInfo.Controls, searchNetworkInfo);	// controls-to-object
				this.UpdateToObject(this.tblID.Controls, searchNetworkInfo);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public NetworkCollection ResultNetworks
		{
			get { return resultNetworks; }
			set
			{
				resultNetworks = value;
				try
				{
					this.gridNetworks.UpdateFromCollection(resultNetworks);  // update given grid from the collection

					if (this.resultNetworks.Count > 0)
					{
						btnNext.Enabled = resultNetworks.Count >= NetworkCollection.MAXRECORDS;
						btnPrevious.Enabled = gridNetworks.HasAnyPreviousPages;
					}
					this.pnlResults.Visible = true;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject("objResultNetworks", resultNetworks);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Address NetworkAddressSearch
		{
			get { return networkAddressSearch; }
			set
			{
				networkAddressSearch = value;
				try
				{
					this.UpdateFromObject(this.tblAddress.Controls, networkAddressSearch);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objNetworkAddressSearch", networkAddressSearch);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForNetworkAddressSearch()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblAddress.Controls, networkAddressSearch);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private void gridNetworks_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			if (cell != null)
			{
				Network net = e.data as Network;
				e.row.Cells.FromKey("Pick").Text = GetCallbackFunctionHyperLink("Pick", net.NetworkID, net.Name);

			}
		}
		
		private void SelectNetwork(int networkID)
		{
			if (networkID != -1)
			{
				try
				{
					/*Network network = new Network();
					network.Load(networkID);*/		// The Redirect already loads it! No need to load here..
					NetworkForm.Redirect(networkID);

//					.Value = facilityID.ToString();
//					hdnFacilityName.Value = fac.Name;
//					hdnTypeID.Value = fac.FacilityTypeID.ToString();
//					hdnTypeDescription.Value = fac.FacilityType;
					

//					BindFacilityLocations(facilityID);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}
	


		private void gridNetworks_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction)
				this.gridNetworks.AddColumnWithButtonLook("Pick","@PICK@",0).Width = selectWidth ;
			
		}

		private void gridNetworks_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Edit")
			{
				// update selected index
				this.gridNetworks.SelectedRowIndex = e.Cell.Row.Index;
				SelectNetwork((int)gridNetworks.SelectedRowPK [0]);
			}

		}

		private void btnNext_Click(object sender, System.EventArgs e)
		{
			SearchNext(true);
		}

		private void btnPrevious_Click(object sender, System.EventArgs e)
		{
			SearchNext(false);
		}

		private bool SearchNext(bool nextPage)
		{
			bool result = true;
			try
			{
				
				object [] valuesForNextPageStart = gridNetworks.GetStartValuesForPrevOrNextPage(nextPage);
				if (valuesForNextPageStart == null)	// no more pages.
					return false;
				// use page start to load this set of records.
				startID = (int)valuesForNextPageStart[0];
				startName   = (string)valuesForNextPageStart[1];
				ReadForm(this.rdSearchBy.SelectedIndex);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patients.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
				
			}
			return result;

		}

	}
}
