using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for ContactForm.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.CONTACTS)]
	
	[MainLanguageClass("ActiveAdvice.Messages.BaseMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Contact,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(ContactSearch))]
	[SelectedMenuItem("Search")]
	[PageTitle("@CONTACTSEARCHPAGETITLE@")]
	public class ContactSearch : ContactBasePage
	{
		private IContactOwner contactOwner;
		private Contact contactSearcher;
		private BaseData[] summaryObjects = null;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLastName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompany;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Company;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTitle;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Title;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		private ContactCollection contacts;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				contactOwner = GetParamOrGetFromCache("ContactOwner", typeof(IContactOwner) ) as IContactOwner;
				summaryObjects = GetParamOrGetFromCache("SummaryObjects", "SummaryObjects" ) as BaseData[];
				
				if (contactOwner == null)
					RaisePageException(new Exception("You must hit this page in the context of a Contact Owner"));

				this.CacheObject("IContactOwner", contactOwner); 
				this.CacheObject("SummaryObjects", summaryObjects);
				this.NewSearch();
			}
			else
			{
				contactOwner = (IContactOwner)this.LoadObject("IContactOwner", typeof(IContactOwner), false);
				summaryObjects = (BaseData[])this.LoadObject("SummaryObjects", typeof(BaseData[]) ,false);
				contactSearcher = (Contact)this.LoadObject("ContactSearcher");  // load object from cache
			}

		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(IContactOwner contactOwner)
		{
			BasePage.PushParam("ContactOwner", contactOwner);

			BasePage.Redirect("ContactSearch.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(IContactOwner contactOwner, BaseData[] summaryObjects)
		{
			BasePage.PushParam("ContactOwner", contactOwner);
			BasePage.PushParam("SummaryObjects", summaryObjects);

			BasePage.Redirect("ContactSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(grid_ClickCellButton);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.grid.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.grid_DblClick);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			if(this.IsPopup)
				return;

			// Menu items to be displayed on specific tabs
			if (tab.Key == "ContactSearchTab")
			{
				toolbar.AddButton(BaseMessages.MessageIDs.ADDNEWRECORD, "AddNew");
				//toolbar.AddButton(BaseMessages.MessageIDs.BACK, "Back");
			}

			// Menu items to be displayed on all tabs
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			ContactForm.Redirect(contactOwner, null);
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			GoBack();
		}

		private void grid_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = grid.GetPKFromClickEvent(e);
				if (pk != null)
					ContactForm.Redirect(contactOwner, (int)pk[0]);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ContactCollection Contacts
		{
			get { return contacts; }
			set
			{
				contacts = value;
				try
				{
					grid.KeepCollectionIndices = false;  // update given grid from the collection
					grid.UpdateFromCollection(contacts);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(BenefitServiceItemCollection), benefitServiceItems);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			ContactCollection contacts = new ContactCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				// do the search in the contact owners context
				contacts.SearchContacts(-1, contactSearcher, contactOwner);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//contacts.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Contacts = contacts;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Contact ContactSearcher
		{
			get { return contactSearcher; }
			set
			{
				contactSearcher = value;
				try
				{
					this.UpdateFromObject(pnlSearch.Controls, contactSearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("ContactSearcher", contactSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearch()
		{
			bool result = true;
			Contact contactSearcher = new Contact(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				contactSearcher.SetMembersNull(true, true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.ContactSearcher = contactSearcher;
			return result;
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlSearch.Controls, contactSearcher);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			if (summaryObjects != null)
				pageSummary.RenderObjects(summaryObjects);
			else
				pageSummary.RenderObjects((BaseData)this.contactOwner);
		}


		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			// Add an edit button when the grid is populated
			grid.AddButtonColumn("Edit", "@EDIT@", 0);
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Edit")
			{
				try
				{
					ContactForm.Redirect(contactOwner, grid.GetPKIntFromCellEvent(e));
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

	}
}
