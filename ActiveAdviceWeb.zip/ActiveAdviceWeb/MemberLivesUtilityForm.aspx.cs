using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.BaseMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("MemberLivesUtility,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("")]					
	[SelectedMenuItem("")]
	[PageTitle("@MEMBERLIVESUTILITY@")]
	public class MemberLivesUtilityForm : BasePage
	{
		private MemberLivesUtility memberLivesUtility;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUpdateFromElig;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlRollover;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldToDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ToDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbToDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFromDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FromDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFromDate;
		protected NetsoftUSA.InfragisticsWeb.WebButton butUpdateFromElig;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRolloverDstDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit RolloverDstDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRolloverDstDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRolloverSrcDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit RolloverSrcDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRolloverSrcDate;
		protected NetsoftUSA.InfragisticsWeb.WebButton butRollover;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				memberLivesUtility = (MemberLivesUtility)this.LoadRequiredObject(typeof(MemberLivesUtility));  // load object from cache
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("MemberLivesUtilityForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butUpdateFromElig.Click += new System.EventHandler(this.butUpdateFromElig_Click);
			this.butRollover.Click += new System.EventHandler(this.butRollover_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			/*
			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}
			*/

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			//toolbar.AddButton("@CANCEL@", "Cancel");
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MemberLivesUtility MemberLivesUtility
		{
			get { return memberLivesUtility; }
			set
			{
				memberLivesUtility = value;
				try
				{
					this.UpdateFromObject(pnlUpdateFromElig.Controls, memberLivesUtility);  // update controls for the given control collection
					this.UpdateFromObject(pnlRollover.Controls, memberLivesUtility);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(MemberLivesUtility), memberLivesUtility);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForUpdateFromElig()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlUpdateFromElig.Controls, memberLivesUtility);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForRollover()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlRollover.Controls, memberLivesUtility);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			MemberLivesUtility memberLivesUtility = null;
			try
			{	// use any load method here
				memberLivesUtility = new MemberLivesUtility();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//memberLivesUtility.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.MemberLivesUtility = memberLivesUtility;
			return result;
		}

		public void UpdateMemberLivesFromElig()
		{
			try
			{
				if (this.ReadControlsForUpdateFromElig())
				{
					if (memberLivesUtility.UpdateMemberLivesFromEligibility() > 0)
						this.SetPageMessage("@MLIVESUPDATEDFROMELIG@", EnumPageMessageType.Info);
					else
						this.SetPageMessage("@MLIVESUPDATENORECORDS@", EnumPageMessageType.Info);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
		}

		public void Rollover()
		{
			try
			{
				if (this.ReadControlsForRollover())
				{
					if (memberLivesUtility.RolloverMemberLives() > 0)
						this.SetPageMessage("@MLIVSROLLEDOVER@", EnumPageMessageType.Info);
					else
						this.SetPageMessage("@MLIVSROLLOVERNORECORDS@", EnumPageMessageType.Info);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
		}

		private void butUpdateFromElig_Click(object sender, System.EventArgs e)
		{
			UpdateMemberLivesFromElig();
		}

		private void butRollover_Click(object sender, System.EventArgs e)
		{
			Rollover();
		}

	}
}
