using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Questionnaire,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(QuestionnaireSearch))]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("QR")]
	[PageTitle("@QRSEARCHPAGETITLE@")]
	public class QuestionnaireSearch : AssessmentMaintenanceBasePage
	{
		private QuestionnaireCollection questionnaires;
		private Questionnaire questionnaire;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionnaireText;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit QuestionnaireText;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionnaireText;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActiveWithAll;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContentOwnerID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ContentOwnerID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContentOwnerID;
		protected Infragistics.WebUI.UltraWebListbar.UltraWebListbar WebListBar1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCMSTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionnaireTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo QuestionnaireTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionnaireTypeID;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.NewSearch();		// Use such a method for search pages
			}
			else
			{
				// always load all server side objects from the cache
				//questionnaires = (QuestionnaireCollection)this.LoadObject(typeof(QuestionnaireCollection));	// This would reload from cache
				// searchers must cache and read from a different key than the class name
				questionnaire = (Questionnaire)this.LoadObject("Questionnaire");
			}

		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("QuestionnaireSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.grid.DblClick += new ClickEventHandler(grid_DblClick);
			this.grid.ClickCellButton += new ClickCellButtonEventHandler(grid_ClickCellButton);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.grid.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.grid_RowBoundToDataObject);
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grid_ColumnsBoundToDataClass);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
				toolbar.AddButton(OrgMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			if(this.HasCallbackFunction)
				toolbar.AddButton("@CLOSE@", "Cancel", false).Item.TargetURL = "javascript:window.close();";
			else
				toolbar.AddPreset(ToolbarButtons.Cancel);
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewSearch();
		}

		// Handler for 'AddNew' button
		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			Questionnaire qr = new Questionnaire(true);
			QuestionnaireForm.Redirect(qr);
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public QuestionnaireCollection Questionnaires
		{
			get { return questionnaires; }
			set
			{
				questionnaires = value;
				try
				{
					grid.KeepCollectionIndices = false;  // update given grid from the collection
					if(this.HasCallbackFunction)
						grid.EditButton = false;
					grid.UpdateFromCollection(questionnaires);  // update given grid from the collection
					// other object-to-control methods if any
					if(questionnaires.Count >= QuestionnaireCollection.MAXRECORDS)
						this.SetPageMessage("@BIGGERRESULTSET@", EnumPageMessageType.AddInfo, QuestionnaireCollection.MAXRECORDS, Messages.AssessmentMessages.MessageIDs.QUESTIONNAIRES);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject(typeof(QuestionnaireCollection), questionnaires);  // cache object using the caching method declared on the page
			}
		}


		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Edit")
			{
				try
				{
					object[] pk = grid.GetPKFromCellEvent(e);
					if (pk != null)
						QuestionnaireForm.Redirect((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void grid_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = grid.GetPKFromClickEvent(e);
				if (pk != null)
					QuestionnaireForm.Redirect((int)pk[0]);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			QuestionnaireCollection questionnaires = new QuestionnaireCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				// do the search in the contact owners context
				questionnaires.SearchQuestionnaires(questionnaire);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//contacts.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Questionnaires = questionnaires;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Questionnaire Questionnaire
		{
			get { return questionnaire; }
			set
			{
				questionnaire = value;
				try
				{
					this.UpdateFromObject(pnlSearch.Controls, questionnaire);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("Questionnaire", questionnaire);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearch()
		{
			bool result = true;
			Questionnaire questionnaire = new Questionnaire(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				questionnaire.SetMembersNull(true, true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Questionnaire = questionnaire;
			return result;
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	
				this.UpdateToObject(pnlSearch.Controls, questionnaire);	// controls-to-object				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction)                   // only if this is a popup
				grid.AddColumn("Pick", "@PICK@", 0);
		}

		private void grid_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			if (!this.HasCallbackFunction) 
				return;
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			if (cell != null)
			{
				Questionnaire qr = e.data as Questionnaire;
				e.row.Cells.FromKey("Pick").Text = this.GetCallbackFunctionHyperLink("Pick", qr.QuestionnaireID, qr.Description);
			}
		}
	}
}
