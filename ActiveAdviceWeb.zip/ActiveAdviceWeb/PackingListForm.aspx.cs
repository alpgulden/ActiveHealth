using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for PackingListForm.
	/// </summary>
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.CLINICAL_MGMT_SERVICE),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.CARE_MANAGEMENT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.CMSMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("PackingListItem,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("Summary")]
	[SelectedMainMenuItem("MPatient")]
	[PageTitle("@CMSPAGETITLE@")]
	public class PackingListForm : PatientBasePage
	{
		private AssessmentContext assessmentContext;
		private PackingListItemSentCollection recentlyPrintedItems;
		private PackingListItemSentSelectionCollection packingListItemSentSelections;
		private DistinctDatePackingListItemSentCollection distinctDatePackingListItemSents;
		private CMS cMS;
		private Patient patient;
		private Problem problem;
		private bool finishedAddingPackingListItems = false; // flag that signals rendering of pop up page
		private string selectedAssmtGUID = null;	// tracks GUID of selected Assessment if any.
		private const int STATICCOLUMNS = 5;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnRePrint;
		protected NetsoftUSA.WebForms.OBComboBox PrintedDates;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gPcklst;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnPrintPackingList;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnRestore;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPackingList;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBComboBox Assessments;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		private PatientCoverage patientCoverage;
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.wbtnRestore.Click += new System.EventHandler(this.wbtnRestore_Click);
			this.wbtnPrintPackingList.Click += new System.EventHandler(this.wbtnPrintPackingList_Click);
			this.wbtnRePrint.Click += new System.EventHandler(this.wbtnRePrint_Click);
			this.Assessments.SelectedIndexChanged += new System.EventHandler(this.Assessments_SelectedIndexChanged);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				LoadData(null);
			else
			{
				cMS = (CMS)this.LoadObject(typeof(CMS));  // load object from cache
				distinctDatePackingListItemSents = (DistinctDatePackingListItemSentCollection)this.LoadObject(typeof(DistinctDatePackingListItemSentCollection));  // load object from cache
				packingListItemSentSelections = (PackingListItemSentSelectionCollection)this.LoadObject(typeof(PackingListItemSentSelectionCollection));  // load object from cache
				recentlyPrintedItems = (PackingListItemSentCollection)this.LoadObject("RecentlyPrintedItems");  // load object from cache
				assessmentContext = (AssessmentContext)this.LoadObject("AssessmentContext");  // load object from cache
			}
			patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
			problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
			patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
		}

		private void LoadData(string guid)
		{
			if(!IsPostBack && !LoadDataForCMS()) // CMS is loaded ONLY once.
				return;
			if(LoadDataForDistinctDatePackingListItemSents())
				LoadDataForPackingListItemSentSelections(guid);  // renders grid
			else
				ErrorForm.Redirect("LoadDataForDistinctDatePackingListItemSents() failed");
			RecentlyPrintedItems = new PackingListItemSentCollection();
		}

		#region CMS
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMS CMS
		{
			get { return cMS; }
			set
			{	
				try
				{
					this.cMS = value;
					this.CacheObject(typeof(CMS), value);  // cache object using the caching method declared on the page
					this.cMS.LoadAssessments(false);
					this.Assessments.FillComboFromCollection(this.cMS.Assessments, "AssessmentGUID", "DescriptionCombo");
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);	// notify the page about the error
				}
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForCMS()
		{
			bool result = true;
			CMS cMS = null;
			try
			{	// use any load method here
				// or pull from the parameter passed to this page via PushParam
				cMS = GetParam("CMS") as CMS;
				if (cMS == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a CMS");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//cMS.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CMS = cMS;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(CMS cMS)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CMS", cMS);
			BasePage.Redirect("PackingListForm.aspx");

		}
		#endregion

		#region DistinctDatePackingListItemSents
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// Generates columnt headers for dates items were send.
		/// </summary>
		public DistinctDatePackingListItemSentCollection DistinctDatePackingListItemSents
		{
			get { return this.distinctDatePackingListItemSents; }
			set
			{
				this.distinctDatePackingListItemSents = value;
				try
				{
					//Creating Columns for Distinct Dates
					for (int i = 0; i < this.distinctDatePackingListItemSents.Count; i++)
					{
						if(!IsPostBack)
						{
							AppendNewColumn(distinctDatePackingListItemSents[i]);
							this.distinctDatePackingListItemSents[i].ColumnIndex = gPcklst.Columns.Count - 1; // index of newly added column
						}
						else
							this.distinctDatePackingListItemSents[i].ColumnIndex = STATICCOLUMNS + i;
					}

					this.PrintedDates.FillComboFromCollection(value, "CreationTime", "DescriptionForCombo");
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(DistinctDatePackingListItemSentCollection), value);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForDistinctDatePackingListItemSents()
		{
			bool result = true;
			DistinctDatePackingListItemSentCollection distinctDatePackingListItemSents = null;
			try
			{	// use any load method here
				distinctDatePackingListItemSents = DataLayer.DistinctDatePackingListItemSentCollection.GetDistinctDatesByCMSId(this.cMS.CMSID);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//distinctDatePackingListItemSents.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.DistinctDatePackingListItemSents = distinctDatePackingListItemSents;
			return result;
		}
		#endregion

		#region PackingListItemSentSelections
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PackingListItemSentSelectionCollection PackingListItemSentSelections
		{
			get { return packingListItemSentSelections; }
			set
			{
				packingListItemSentSelections = value;
				try
				{
					if(packingListItemSentSelections.Count > 0)
					{
						this.gPcklst.ClearRows();
						int lastPLIiD = 0; // ID of last processed PLI from collection
						int rowIndex = gPcklst.Rows.Count; // tracks current row we're working on
						LogicEvaluator lEvaluator = new LogicEvaluator();

						bool createRow, preselectPLI = false;

						foreach(PackingListItemSentSelection pliss in packingListItemSentSelections)
						{
							if(pliss.PackingListItemId != lastPLIiD/*only differnt PLI creates new row*/)
							{
								/* Static columnts
								 * Cells[0] - checkbox
								 * Cells[1] - Description
								 * Cells[2] - PLI Id (not visible)
								 * Cells[3] - IsSelectedDefault, keeps original IsSelectd value (not visible)
								 * Cells[4] - Printable (not visible)
								 * */
								
								/* this.assessmentContext is set when user selects an assmnt from drop down
								 * it will cause execution of LoadDataForPackingListItemSentSelections(assmntGUID).
								 * Presence of PLI and its IsSelected state has to be evaluated based on LogicExpression and RangeExpression
								 * LogicExpression determines if PLI should be visible (row creation)
								 * RangeExpression determines if particular PLI should be checked or not.
								 * Use following rules:
								 * LogicExpression      RangeExpression
									true                  null             in list, pre-selected
									true                  true             in list, pre-selected
									true                  false            in list, not selected
									false                 X                not in list (don�t need to evaluate the RangeExpression, don't show PLI)
									null                  X                in list, selection based on IsSelected field
								 * */
								if(this.assessmentContext != null && pliss.LogicExpression != null)
								{
									lEvaluator.AssessmentContext = this.assessmentContext;

									createRow = lEvaluator.EvaluateExpression(pliss.LogicExpression);
									if(createRow)
									{
										if(pliss.RangeExpression == null)
											preselectPLI = true;
										else
											preselectPLI = lEvaluator.EvaluateExpression(pliss.RangeExpression);
									}
								}
								else
								{
									createRow = true;
									preselectPLI = pliss.IsSelected;
								}

								if(createRow)
									gPcklst.Rows.Add();
								else
									continue;

								rowIndex = gPcklst.Rows.Count - 1;
								gPcklst.Rows[rowIndex].Cells[0].Value = preselectPLI;

								if(!pliss.IsActive)
									gPcklst.Rows[rowIndex].Cells[0].AllowEditing = AllowEditing.No; // Inactive PLIs cannot be selected for printing
#if DEBUG
								gPcklst.Rows[rowIndex].Cells[1].Value = pliss.Description + " - " + pliss.PackingListItemId;
#else
								gPcklst.Rows[rowIndex].Cells[1].Value = pliss.Description;
#endif
								gPcklst.Rows[rowIndex].Cells[2].Value = pliss.PackingListItemId;
								gPcklst.Rows[rowIndex].Cells[3].Value = pliss.IsSelectedDefault;
								gPcklst.Rows[rowIndex].Cells[4].Value = pliss.Printable;
							} // end of new row creation

							DateTime searchByDate = 
								new DateTime(pliss.CreationTime.Year, pliss.CreationTime.Month, pliss.CreationTime.Day, pliss.CreationTime.Hour, pliss.CreationTime.Minute, 0, 0);
							DistinctDatePackingListItemSent ddPLIsent = distinctDatePackingListItemSents.FindBy(searchByDate);
							if(ddPLIsent != null)
								SetSentTextOnGridCell(rowIndex, ddPLIsent.ColumnIndex);
							else if(this.assessmentContext != null 
								&& this.recentlyPrintedItems != null && this.recentlyPrintedItems.Count > 0)
							{
								/* we need to maintain "Sent" state when PLIs were printed (reprinted), but not yet saved -> this.distinctDatePackingListItemSents
								 * and user has selected an Assessment.
								 * Parse date from Column.Header.Key and use it along with PLI ID to check
								 * if RecentlyPrintedItems contains PLI with matching ID and CreationTime.
								 * We need to walk on dynamicly added columns ONLY, which were not created
								 * as a result of evaluating PLIs that came from DB.
								 */
								
								System.Globalization.DateTimeFormatInfo dti	= new System.Globalization.DateTimeFormatInfo();
								dti.FullDateTimePattern = "dd/mm/yyyy HH:mm";
								
								//Total # of columns = STATICCOLUMNS + this.distinctDatePackingListItemSents.Count + RecentlyPrinted
								
								int colIndex = this.gPcklst.Columns.Count - (this.gPcklst.Columns.Count - this.distinctDatePackingListItemSents.Count - STATICCOLUMNS);
								for(int i = colIndex; i < this.gPcklst.Columns.Count; i++)
								{
									DateTime colKey = DateTime.Parse(this.gPcklst.Columns[i].Header.Key, dti);

									colIndex = this.recentlyPrintedItems.Exists(pliss.PackingListItemId, colKey);
									if(colIndex > -1)
										SetSentTextOnGridCell(rowIndex, i + colIndex);
								}
							}

							lastPLIiD = pliss.PackingListItemId;
						} // end of foreach
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PackingListItemSentSelectionCollection), packingListItemSentSelections);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForPackingListItemSentSelections(string assmtGUID)
		{
			bool result = true;
			PackingListItemSentSelectionCollection packingListItemSentSelections = null;
			try
			{	// use any load method here
				packingListItemSentSelections = PackingListItemSentSelectionCollection.GetPLISent(this.cMS.CMSID, assmtGUID);
				if(packingListItemSentSelections == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "PackingListItemSentSelections was not loaded correctly!!!");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//packingListItemSentSelections.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.PackingListItemSentSelections = packingListItemSentSelections;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// Reads all Active & Checked PLI and adds them to RecentlyPrintedItems Collection.
		///  
		/// </summary>
		public bool SaveDataForPackingListItemSentSelections()
		{
			try
			{	// data from controls to object 
				DateTime dt = DateTime.Now;
				PackingListItemSentCollection col = new PackingListItemSentCollection();
				int pliID;
				bool firstPrintedItem = true;
				for ( int row = 0; row < gPcklst.Rows.Count; row++)
				{
					pliID = (int)gPcklst.Rows[row].Cells[2].Value;
					bool isSelected = (bool)gPcklst.Rows[row].Cells[0].Value;
					bool isActive = PackingListItemCollection.AllPackingListItems.Lookup_ActiveByPackingListItemId(pliID);
					bool isPrintable = (bool)gPcklst.Rows[row].Cells[4].Value;
					if (isSelected && isActive && isPrintable)
					{						
						PackingListItemSent item = new PackingListItemSent(true, pliID, dt, this.cMS.CMSID, null);
						col.Add(item);

#if DEBUG
						this.SetPageMessage("Debug: PLI " + pliID.ToString(), EnumPageMessageType.AddInfo);
#endif
						if(firstPrintedItem)
						{
							// new column has to be added ONLY once
							AppendNewColumn(item);
							firstPrintedItem = false;
						}
						SetSentTextOnGridCell(row, gPcklst.Columns.Count - 1);
					}
				}
				if (col.Count > 0)
				{
					// refresh grid if items were printed
					finishedAddingPackingListItems = true;
					LoadDataForRecentlyPrintedItems(col); // appending to RecentlyPrintedItems
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region RecentlyPrintedItems
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PackingListItemSentCollection RecentlyPrintedItems
		{
			get { return recentlyPrintedItems; }
			set
			{
				recentlyPrintedItems = value;
				try
				{
					
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("RecentlyPrintedItems", recentlyPrintedItems);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForRecentlyPrintedItems(PackingListItemSentCollection col)
		{
			bool result = true;
			try
			{	// use any load method here

				this.recentlyPrintedItems.CopyElementsFrom(col, true, false);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//recentlyPrintedItems.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.RecentlyPrintedItems = this.recentlyPrintedItems;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForRecentlyPrintedItems()
		{
			try
			{	// data from controls to object
				this.recentlyPrintedItems.Save();
				this.recentlyPrintedItems = null;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			string guid = this.Assessments.SelectedIndex == 0 ? null : this.Assessments.SelectedValue;
			this.LoadData(guid);
			return true;
		}
		#endregion

		#region AssessmentContext
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentContext AssessmentContext
		{
			get { return assessmentContext; }
			set
			{
				assessmentContext = value;
				this.CacheObject("AssessmentContext", assessmentContext);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAssessmentContext(string assmtGUID)
		{
			bool result = true;
			AssessmentContext assessmentContext = null;
			try
			{	// or use an initialization method here
				assessmentContext = new AssessmentContext(this.cMS, assmtGUID);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.AssessmentContext = assessmentContext;
			return result;
		}
		#endregion

		#region UI Initialization and Events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			this.SetERCTabVisibilities();
			SetPageTabItemActive(TargetTabKey);

			if (cMS == null)
			{
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
				this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, "CMS was not created/set"));
				return;  // execution cannot continue with cMS == NULL
			}

			#region PackingListSummary.aspx
			WindowOpener wo = new WindowOpener();
			wo.ID = "PackingListSummary";
			wo.Resizable = true;
			wo.AddressBar = false;
			wo.CopyHistory = false;
			wo.LinksBar = false;
			wo.WindowWidth = 640;
			wo.WindowHeight = 350;
			wo.ScrollBars = true;

			wo.NavigateURL = "PackingListSummary.aspx";
			wo.registerClientScripts(this);
			
			if (finishedAddingPackingListItems)
			{
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){\n");
				s.Append(wo.getWindowOpenScript()+";}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
				finishedAddingPackingListItems = false;
			}
			else
			{	
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
			}
			#endregion			
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.cMS);
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public new void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.RedirectToCMS();
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if(this.SaveDataForRecentlyPrintedItems())
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, Messages.PatientMessages.MessageIDs.PACKINGLIST /*+ " " + Messages.PatientMessages.MessageIDs.ITEMS*/);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty();
			CheckForDirty(this.recentlyPrintedItems);
		}

		private void wbtnRestore_Click(object sender, System.EventArgs e)
		{
			RestoreDefaults();
		}

		private void RestoreDefaults()
		{
			try
			{
				for(int row = 0; row < this.gPcklst.Rows.Count; row++)
				{
					// Cells[0] - checkbox 
					// Cells[3] - IsSelectedDefault (not visible)
					this.gPcklst.Rows[row].Cells[0].Value =
						this.gPcklst.Rows[row].Cells[3].Value;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void wbtnPrintPackingList_Click(object sender, System.EventArgs e)
		{
			SaveDataForPackingListItemSentSelections();
		}

		private void wbtnRePrint_Click(object sender, System.EventArgs e)
		{
			try
			{
				//dd/mm/yyyy HH:mm
				System.Globalization.DateTimeFormatInfo dti	= new System.Globalization.DateTimeFormatInfo();
				dti.FullDateTimePattern = "dd/mm/yyyy HH:mm";
				if (this.PrintedDates.SelectedValue == "") // nothing selected, no past items to print
					return;

				DateTime dt = DateTime.Parse(this.PrintedDates.SelectedValue, dti);
				PackingListItemSentCollection col = this.packingListItemSentSelections.Reprint(dt, this.cMS.CMSID);

				if (col.Count > 0)
				{
					// refresh grid if items were printed
					finishedAddingPackingListItems = true;
					LoadDataForRecentlyPrintedItems(col); // appending to RecentlyPrintedItems
					AppendNewColumn();
					
					for(int row = 0; row < this.gPcklst.Rows.Count; row++)
					{
						int pLIId = (int)this.gPcklst.Rows[row].Cells[2].Value;
						if(col.Exists(pLIId))
							this.SetSentTextOnGridCell(row, this.gPcklst.Columns.Count - 1);
					}
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void Assessments_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.selectedAssmtGUID = this.Assessments.SelectedIndex == 0 ? null : this.Assessments.SelectedValue;
			if(this.selectedAssmtGUID != null)
				NewAssessmentContext(this.selectedAssmtGUID);
			
			LoadDataForPackingListItemSentSelections(this.selectedAssmtGUID);
		}

		#region Utility Methods
		private void SetSentTextOnGridCell(int row, int col)
		{
			gPcklst.Rows[row].Cells[col].Text = "Sent";
		}
		
		private void AppendNewColumn()
		{
			DateTime now = DateTime.Now;
			string key = now.ToShortDateString()+ " " + now.ToShortTimeString();
			string txt = now.ToShortDateString()+ "<br>" + now.ToShortTimeString();
			AppendNewColumn(key, txt);
		}
	
		private void AppendNewColumn(DistinctDatePackingListItemSent obj)
		{
			string key = obj.DescriptionForCombo;
			string txt = obj.DescriptionForGridHeader;
			AppendNewColumn(key, txt);
		}

		private void AppendNewColumn(string key, string txt)
		{
			gPcklst.AddColumn(key, txt, gPcklst.Columns.Count);
		}
		#endregion
		#endregion		
	}
}
