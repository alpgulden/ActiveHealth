using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Data.SqlTypes;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterSearch.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterTemplate,DataLayer")]
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[PageTitle("@LETTERFORMPAGETITLE@")]
	public class LetterForm : PatientBasePage
	{
		private LetterTemplate letterTemplate;
		private LetterNonPrintedQueue letterNonPrintedQueue;
		private LetterDraftQueue letterDraftQueue;
		private LetterCustomText letterCustomText;
		private Patient patient;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlTextControl;
		private BaseForEventCMSReferral erc;
		private ReferralDetail referralDetail;
		private DateTime startDate;
		private DateTime endDate;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected System.Web.UI.WebControls.TextBox LetterContextRequestID;
		protected System.Web.UI.WebControls.TextBox LetterContextDecisionID;
		protected System.Web.UI.WebControls.TextBox ReqDecSelectMode;

		protected bool justMerged = false;

		protected TextControl txTextControl;

		private void Page_Load(object sender, System.EventArgs e)
		{
			txTextControl.AfterLoadTextFunction = "OnLoadText";
			if (!IsPostBack)
				LoadData();
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache
				referralDetail = (ReferralDetail)this.LoadObject("ReferralDetail");
				letterCustomText = (LetterCustomText)this.LoadObject(typeof(LetterCustomText));  // load object from cache
				letterDraftQueue = (LetterDraftQueue)this.LoadObject(typeof(LetterDraftQueue));  // load object from cache
				letterNonPrintedQueue = (LetterNonPrintedQueue)this.LoadObject(typeof(LetterNonPrintedQueue));  // load object from cache
				letterTemplate = (LetterTemplate)this.LoadObject(typeof(LetterTemplate));  // load object from cache
				startDate = (DateTime)this.LoadObject("StartDate", typeof(DateTime));
				endDate = (DateTime)this.LoadObject("EndDate", typeof(DateTime));
			}


			if(letterDraftQueue != null || letterNonPrintedQueue != null)
			{
				this.SelectedSideMenuItem = "LetterQueue";
			}
			else
			{
				this.SelectedSideMenuItem = "CustomLetter";
			}
		}

		private void LoadData()
		{
			patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
			this.CacheObject(typeof(Patient), patient);

			erc = GetParam("ERC") as BaseForEventCMSReferral;
			this.CacheObject(typeof(BaseForEventCMSReferral), erc);

			referralDetail = GetParam("ReferralDetail") as ReferralDetail;
			this.CacheObject("ReferralDetail", referralDetail);

			letterDraftQueue = this.GetParam("LetterDraftQueue") as LetterDraftQueue;
			this.CacheObject(typeof(LetterDraftQueue), letterDraftQueue);

			if (patient == null && erc == null && letterDraftQueue == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page either in the context of a patient or with administrator rights");

			if (this.GetParam("StartDate") != null)
				startDate = (DateTime)this.GetParam("StartDate");
			else
				startDate = SqlDateTime.MinValue.Value;
			this.CacheObject("StartDate", startDate);
	
			if (this.GetParam("EndDate") != null)
				endDate = (DateTime)this.GetParam("EndDate");
			else
				endDate = SqlDateTime.MaxValue.Value;
			this.CacheObject("EndDate", endDate);


			letterTemplate = this.GetParam("LetterTemplate") as LetterTemplate;
            
			if (letterTemplate == null)
			{
				if (letterDraftQueue != null)
				{
					letterTemplate = new LetterTemplate(letterDraftQueue.LetterTemplateID, letterDraftQueue.Version);
					
					letterDraftQueue.LoadLetterCustomText(true);
					this.LetterCustomText = letterDraftQueue.LetterCustomText;
				}
			}
			else
			{
				NewLetterCustomText();
				letterCustomText.CustomText = letterTemplate.LetterTemplateBody.Body;
				this.LetterCustomText = letterCustomText;
			}

			this.CacheObject(typeof(LetterTemplate), letterTemplate);
			this.CacheObject(typeof(LetterCustomText), letterCustomText);

			if (letterTemplate.FormTypeID == LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_FormTypeIDByCode(LetterFormType.STANDARD)
				|| letterTemplate.FormTypeID == LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_FormTypeIDByCode(LetterFormType.ENVELOPE))
					txTextControl.TextControlMode = TextControlModeEnum.ReadOnly;
			else
					txTextControl.TextControlMode = TextControlModeEnum.Full;

			this.txTextControl.MatrixTypeID = letterTemplate.MatrixTypeID;
			this.txTextControl.FormTypeID = letterTemplate.FormTypeID;
			this.txTextControl.LoadMergeFieldTypes();

			//this.txTextControl.AutoPostBack = (letterTemplate.FormTypeID == LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_FormTypeIDByCode(LetterFormType.FORM));
			// Fix: This page is never used in maintenance mode, so always merge 
			this.txTextControl.AutoPostBack = true;
			
		}

		
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			// Fix: This page is never used in maintenance mode, so always merge 
			if (!justMerged /*&& letterTemplate.FormTypeID == LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_FormTypeIDByCode(LetterFormType.FORM)*/)
			{
				Merge();
			}

		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.erc);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("Back", "Cancel", false);
		}


		public new void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{	
			GoBack();			
		}

		private void GoBack()
		{
			switch(this.BackPage)
			{
				case "DGIForm.aspx":
					DGIForm.Redirect(this.erc as CMS);
					break;
				case "LetterQueueMaintenance.aspx":
					LetterQueueMaintenance.Redirect(patient, erc);
					break;
				default:
					LetterSearch.Redirect(patient, erc);
					break;
			}
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "CustomText":
					if (letterTemplate.FormTypeID == LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_FormTypeIDByCode(LetterFormType.FORM))
					{
						toolbar.AddButton("Save Draft", "SaveDraft", true, false);
						toolbar.AddButton("Load Text", "LoadText", false, true).Item.TargetURL = "javascript:mnu_menu_insert_file();";
					}
					toolbar.AddButton("Send to Print Queue", "SendToPrintQueue", true, false);
					toolbar.AddButton("Print", "SendToPrint", true, false).Item.TargetURL = "javascript:mnu_menu_file_print();";
					toolbar.AddButton("Fax", "SendToFax", true, false);
					toolbar.AddButton("Merge", "Merge", true, false);
					break;
			}
		}


		public override void PopulateSubNavigation(WebListBar listbar)
		{
			if (patient == null && erc == null) // Not in patient context
				LetterMaintenanceBasePage.PopulateSubNavigationItems(listbar);
			else
				base.PopulateSubNavigation (listbar);
				
		}


		public bool Merge()
		{

			if (!ReadControlsForLetterCustomText()) return false;


			MergeContext mergeContext = null;
			
			if (letterDraftQueue == null)
			{
				mergeContext = new MergeContext(letterTemplate.MatrixTypeID);

				// Set the context objects
				mergeContext.ERC = erc;
				mergeContext.Patient = patient;

				Event eventObj = erc as Event;
				Referral referral = erc as Referral;
				CMS cms = erc as CMS;
			
				if (patient != null)
					mergeContext.AddFilterValue(MergeFilter.PATIENTID, patient.PatientId);

				if (eventObj != null)
					mergeContext.AddFilterValue(MergeFilter.EVENTID, eventObj.EventID);
			
				if (erc.PrimaryProblemID != 0)
					mergeContext.AddFilterValue(MergeFilter.PROBLEMID, erc.PrimaryProblemID);

				mergeContext.AddFilterValue(MergeFilter.USERID, AASecurityHelper.GetUserId);
			
				if (referral != null)
					mergeContext.AddFilterValue(MergeFilter.REFERRALID, referral.ReferralID);

				if (referralDetail != null)
                    mergeContext.AddFilterValue(MergeFilter.REFERRALDETAILID, referralDetail.ReferralDetailID);

				if (cms != null)
					mergeContext.AddFilterValue(MergeFilter.CMSID, cms.CMSID);
			}
			else
			{
				mergeContext = new MergeContext(letterDraftQueue.MatrixTypeID);
				mergeContext.LetterQueue = letterDraftQueue;
				mergeContext.GetMergeFilterValuesFromQueue();
			}

			// Just use the selected request/decision ids.
			// First add filter values already set in the hidden texboxes

			int requestID = 0;
			int decisionID = 0;
			bool noRequestSelected = false;
			bool noDecisionSelected = false;

			if (this.LetterContextRequestID.Text != null && this.LetterContextRequestID.Text != "")
				requestID = int.Parse(this.LetterContextRequestID.Text);

			if (this.LetterContextDecisionID.Text != null && this.LetterContextDecisionID.Text != "")
				decisionID = int.Parse(this.LetterContextDecisionID.Text);	

			if (requestID == -1)
				noRequestSelected = true;
			else
			if (requestID != 0)
				mergeContext.AddFilterValue(MergeFilter.REQUESTID, requestID );

			if (decisionID == -1)
				noDecisionSelected = true;
			else
			if (decisionID != 0)
				mergeContext.AddFilterValue(MergeFilter.DECISIONID, decisionID );

			if (startDate != DateTime.MinValue)
				mergeContext.AddFilterValue(MergeFilter.STARTDATE, startDate);
			if (endDate != DateTime.MinValue)
				mergeContext.AddFilterValue(MergeFilter.ENDDATE, endDate);

			try
			{
				ReqDecSelectMode.Text = "";

				if (erc is Event)	// If we're generating letters for events, we detect if the letter refers to request and/or decision
				{
					// detect if the letter refers to clinical request/decision
					txTextControl.EnableSubstitution = false;
					
					txTextControl.DoMerge(mergeContext);

					bool hasClinicalRequests = ((Event)erc).HasClinicalRequests;

					if (txTextControl.UsesDecisionContext && (requestID == 0 || decisionID == 0) && hasClinicalRequests )
					{
						// the decision is referred, and request or decision is not already selected
						// ask decision id
						bool askDecision = true;
						
						// first check if only <CLINICAL_RATIONALE> is referring to decision context.
						// if so, we need to ask if there's at least one denied decision.

						if (txTextControl.OnlyClinicalRationaleReferred())
						{
							// only <CLINICAL_RATIONALE> is referred.  this means we need to ask for a decision only
							// if there's a decision with decision type = 'DENY'.
							if (!((Event)erc).HasEventDeniedDecisions())
							{
								// no denied decisions, hence no need to ask
								askDecision = false;
							}
						}

						if (askDecision)
						{
							if (!hasClinicalRequests)
								this.SetPageMessage("@NOCLINICALREQS@", EnumPageMessageType.AddInfo);
							else
							{
								ReqDecSelectMode.Text = "D";
								return false;
							}
						}
					}
					else if (txTextControl.UsesRequestContext && requestID == 0)
					{
						// request is referred, and request id is not already selected
						// ask request id
						if (!hasClinicalRequests)
							this.SetPageMessage("@NOCLINICALREQS@", EnumPageMessageType.AddInfo);
						else
						{
							ReqDecSelectMode.Text = "R";
							return false;
						}
					}

				}

				// do actual substitution of field values.
				txTextControl.EnableSubstitution = true;
				txTextControl.DoMerge(mergeContext);
				this.letterCustomText.CustomText = txTextControl.Text;
				this.LetterCustomText = letterCustomText;

				justMerged = true;
				return true;
			}
			catch (Exception ex)
			{
				//this.SetPageMessage("An error occured while merging...", EnumPageMessageType.Error); 
				this.RaisePageException(ex);
				return false;
			}
		}


		public void OnToolbarButtonClick_Merge(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			Merge();
		}

		public void OnToolbarButtonClick_SendToFax(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (!Merge()) return;

			FaxInfo faxInfo = new FaxInfo();

			// Fill in the fax detail from queue item
			if (letterDraftQueue != null)
			{
				faxInfo.FillFromReceiver(letterDraftQueue.ReceiverTypeID, letterDraftQueue.PatientID, letterDraftQueue.ReferralID, letterDraftQueue.EventID, letterDraftQueue.CMSID);
			}
			else // Or from context
			{
				if (patient != null && patient.Address != null)
				{
					faxInfo.ToFaxNo = patient.Address.FaxFull;
					faxInfo.ToFName = patient.FirstName;
					faxInfo.ToLName = patient.LastName;
				}
			}

			faxInfo.Attachment = this.LetterCustomText.CustomText;

			// Redirect to Fax Page
			FaxForm.Redirect(faxInfo);
		}

		public void OnToolbarButtonClick_SendToPrintQueue(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// create record in NON Printed queue

			if (!Merge()) return;
			 
			if (letterDraftQueue == null)
			{
				BaseLetterQueue blnpq = LetterQueueClassFactory.CreateLetterQueue(LetterQueueType.NotPrinted, true);
				blnpq.LetterTemplateID = letterTemplate.LetterTemplateID;
				blnpq.MatrixTypeID = letterTemplate.MatrixTypeID;
				blnpq.Version = letterTemplate.Version;
				blnpq.UserID = AASecurityHelper.GetUserId;
				blnpq.PatientID = this.patient.PatientId;
				blnpq.ReceiverTypeID = letterTemplate.ReceiverTypeID;
 
				int requestID = 0;
				int decisionID = 0;

				if (this.LetterContextRequestID.Text != null && this.LetterContextRequestID.Text != "")
					requestID = int.Parse(this.LetterContextRequestID.Text);

				if (this.LetterContextDecisionID.Text != null && this.LetterContextDecisionID.Text != "")
					decisionID = int.Parse(this.LetterContextDecisionID.Text);	

				blnpq.RequestID = requestID;
				blnpq.ClinicalReviewDecisionID = decisionID;

				Event eve = erc as Event;
				Referral refe = erc as Referral;
				CMS cms = erc as CMS;

				if (eve != null)
					blnpq.EventID = eve.EventID;
				else if (refe != null)
					blnpq.ReferralID = refe.ReferralID;
				else if (cms != null)
					blnpq.CMSID = cms.CMSID;

				if (referralDetail != null)
				blnpq.ReferralDetailID = referralDetail.ReferralDetailID;

				if (erc.PatientSubscriberLog != null)
				{
					blnpq.OrganizationId = erc.PatientSubscriberLog.SORGId;
					blnpq.PlanID = erc.PatientSubscriberLog.PlanId;
				}
				
				LetterNonPrintedQueue lnpq = blnpq as LetterNonPrintedQueue;

				lnpq.LoadLetterCustomText(true);
				lnpq.LetterCustomText.CustomText = letterCustomText.CustomText;
			
				lnpq.Save();
				this.txTextControl.IsDirty = false;

				this.SetPageMessage("Letter has been sent to print queue", EnumPageMessageType.Info); 
			}
			else
			{
				// We only have a method that deals with collections.
				// So just put the object in a collection and use that method

				LetterDraftQueueCollection draftCol = new LetterDraftQueueCollection();
				draftCol.Add(letterDraftQueue);

				// Workaround: This is temporary
				letterDraftQueue.Selected = true;
                
				// Fixed By V on 3/7/06
				// BaseLetterQueueCollection col = LetterQueueClassFactory.CreateLetterQueueCollectionFromCollection(LetterQueueType.NotPrinted);
				BaseLetterQueueCollection col = LetterQueueClassFactory.CreateLetterQueueCollection(LetterQueueType.NotPrinted);
			

				// BDS - use default for now
				Printer printerTo = new Printer();
				printerTo.New();
				col.CreateFromCollectionAndSave(draftCol, true /* override */, true /* print */, printerTo, false);

				letterDraftQueue.Save();

				// TODO: At some point we need display a confirmation message
				GoBack();
			}
			
		}

		public void OnToolbarButtonClick_SaveDraft(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (!Merge()) return;
			
			if (letterDraftQueue == null)
			{
				BaseLetterQueue bldq = LetterQueueClassFactory.CreateLetterQueue(LetterQueueType.Draft, true);
				bldq.LetterTemplateID = letterTemplate.LetterTemplateID;
				bldq.MatrixTypeID = letterTemplate.MatrixTypeID;
				bldq.Version = letterTemplate.Version;
				bldq.UserID = AASecurityHelper.GetUserId;
				bldq.PatientID = patient.PatientId;
				bldq.ReceiverTypeID = letterTemplate.ReceiverTypeID;


				int requestID = 0;
				int decisionID = 0;

				if (this.LetterContextRequestID.Text != null && this.LetterContextRequestID.Text != "" && this.LetterContextRequestID.Text != "-1")
					requestID = int.Parse(this.LetterContextRequestID.Text);

				if (this.LetterContextDecisionID.Text != null && this.LetterContextDecisionID.Text != "" && this.LetterContextDecisionID.Text != "-1")
					decisionID = int.Parse(this.LetterContextDecisionID.Text);	

				bldq.RequestID = requestID;
				bldq.ClinicalReviewDecisionID = decisionID;

				Event eve = erc as Event;
				Referral refe = erc as Referral;
				CMS cms = erc as CMS;

				if (eve != null)
					bldq.EventID = eve.EventID;
				else if (refe != null)
					bldq.ReferralID = refe.ReferralID;
				else if (cms != null)
					bldq.CMSID = cms.CMSID;

				if (referralDetail != null)
					bldq.ReferralDetailID = referralDetail.ReferralDetailID;

				if (erc.PatientSubscriberLog != null)
				{
					bldq.OrganizationId = erc.PatientSubscriberLog.SORGId;
					bldq.PlanID = erc.PatientSubscriberLog.PlanId;
				}

				LetterDraftQueue ldq = bldq as LetterDraftQueue;

				ldq.LoadLetterCustomText(true);
				ldq.LetterCustomText.CustomText = letterCustomText.CustomText;
				ldq.Save();
			}
			else
			{
				letterDraftQueue.LoadLetterCustomText(false);
				letterDraftQueue.LetterCustomText.CustomText = letterCustomText.CustomText;
				letterDraftQueue.Save();

				this.LetterDraftQueue = letterDraftQueue;
				this.LetterCustomText = letterDraftQueue.LetterCustomText;
			}
			
			this.txTextControl.IsDirty = false;
			this.SetPageMessage("Letter has been saved as draft", EnumPageMessageType.Info); 
		}

			
		
			#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.AutoScroll = true;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterCustomText LetterCustomText
		{
			get { return letterCustomText; }
			set
			{
				letterCustomText = value;
				try
				{
					txTextControl.Text = letterCustomText.CustomText;  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterCustomText), letterCustomText);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLetterCustomText()
		{
			try
			{	//customize this method for this specific page
				letterCustomText.CustomText = txTextControl.Text;	// controls-to-object
				letterCustomText.MarkDirty();
				// other control-to-object methods if any
				return true;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewLetterCustomText()
		{
			bool result = true;
			LetterCustomText letterCustomText = null; //new LetterCustomText(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				letterCustomText = new LetterCustomText(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.LetterCustomText = letterCustomText;
			return result;
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterDraftQueue LetterDraftQueue
		{
			get { return letterDraftQueue; }
			set
			{
				letterDraftQueue = value;
				try
				{
					//this.UpdateFromObject(this.Controls, letterDraftQueue);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterDraftQueue), letterDraftQueue);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterNonPrintedQueue LetterNonPrintedQueue
		{
			get { return letterNonPrintedQueue; }
			set
			{
				letterNonPrintedQueue = value;
				try
				{
					//this.UpdateFromObject(this.Controls, letterNonPrintedQueue);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterNonPrintedQueue), letterNonPrintedQueue);  // cache object using the caching method declared on the page
			}
		}



		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterTemplate LetterTemplate
		{
			get { return letterTemplate; }
			set
			{
				letterTemplate = value;
				try
				{
					//this.UpdateFromObject(this.Controls, letterTemplate);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(LetterTemplate), letterTemplate);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(LetterTemplate letterTemplate)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("LetterTemplate", letterTemplate);
			BasePage.Redirect("LetterForm.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, BaseForEventCMSReferral erc, LetterDraftQueue letterDraftQueue)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("ERC", erc);
			BasePage.PushParam("LetterDraftQueue", letterDraftQueue);
			BasePage.Redirect("LetterForm.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, BaseForEventCMSReferral erc, LetterTemplate letterTemplate, ReferralDetail referralDetail)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("ERC", erc);
			BasePage.PushParam("LetterTemplate", letterTemplate);
			BasePage.PushParam("ReferralDetail", referralDetail);
			BasePage.Redirect("LetterForm.aspx");
		}


		/// <summary>
		/// This redirect is used for the CMS reporting
		/// </summary>
		public static void Redirect(CMS cMS, DateTime startDate, DateTime endDate)
		{
			LetterTemplate letterTemplate = new LetterTemplate();

			bool found = false;
			if (cMS.Maternichek != null && SystemControlValue.GetInstance.MATReportLetterTemplateID > 0) // This is a Maternichek
			{
				letterTemplate.LoadLatestVersion(SystemControlValue.GetInstance.MATReportLetterTemplateID);
				found = true;
			}
			else if (SystemControlValue.GetInstance.CMReportLetterTemplateID > 0)
			{
				letterTemplate.LoadLatestVersion(SystemControlValue.GetInstance.CMReportLetterTemplateID);
				found = true;
			}
			
			if (!found) // No template is defined in system table for this type of CMS
			{
				//this.SetPageMessage("There is no letter template defined for this type of CMS", EnumPageMessageType.Error); 
				// TODO: Calling page must handle this
				return;
			}
			
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", cMS.Patient);
			BasePage.PushParam("ERC", cMS);
			BasePage.PushParam("StartDate", startDate);
			BasePage.PushParam("EndDate", endDate);
			BasePage.PushParam("LetterTemplate", letterTemplate);

			BasePage.Redirect("LetterForm.aspx");
		}


		
		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.IsDirty = letterCustomText.IsDirty || txTextControl.IsDirty;
		}

		private void butMerge_Click(object sender, System.EventArgs e)
		{
			Merge();
		}

	}
}
