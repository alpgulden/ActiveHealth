using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;
namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.DxPxMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("MomBabyCode,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu	
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@MOMBABYCODESEARCHTITLE@")]
	public class MomBabyCodeSearch : CodeBasePage
	{
		private MomBabyCodeCollection momBabyCodes;

		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;	
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder6;
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder7;
		protected NetsoftUSA.WebForms.WindowOpener wo;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCodes;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder1;
	
	
		


		private void Page_Load(object sender, System.EventArgs e)
		{			
			if (!this.IsPostBack)
			{							
				this.LoadData();			// Load data is the actual data loading method		
			}
			
	

		}



		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("Add New", "AddNew");
			
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// new Mom Baby Code
			MomBabyCodeForm.Redirect(-1);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
		}

		/// <summary>
		/// Redirect to current referral
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("MomBabyCodeSearch.aspx");
		}

		
		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;	
			// Initialize the grid with all available mom/baby codes.
			this.momBabyCodes = new MomBabyCodeCollection();
			this.momBabyCodes.Search(0,null);
			this.MomBabyCodes = this.momBabyCodes;

			return result;
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
 
		private void InitializeComponent()
		{   
			this.gridCodes.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridCodes_ClickCellButton);
			this.gridCodes.InitializeLayout += new Infragistics.WebUI.UltraWebGrid.InitializeLayoutEventHandler(this.WebGrid1_InitializeLayout);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}

		#endregion

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@CANCEL@", "Cancel").Visible  = false;
		}

		public void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BasePage.Redirect("CodeMaintenance.aspx");
		}

		private void WebGrid1_InitializeLayout(object sender, Infragistics.WebUI.UltraWebGrid.LayoutEventArgs e)
		{
		
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public MomBabyCodeCollection MomBabyCodes
		{
			get { return momBabyCodes; }
			set
			{
				momBabyCodes = value;
				try
				{
					//grid.KeepCollectionIndices = false;  // update given grid from the collection
					this.gridCodes.UpdateFromCollection(momBabyCodes);  // update given grid from the collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				
			}
		}


		private void gridCodes_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = this.gridCodes.GetPKFromCellEvent(e);
			if (e.Cell.Key == "Edit")
			{
				try
				{
					MomBabyCodeForm.Redirect((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

	


	}
}
