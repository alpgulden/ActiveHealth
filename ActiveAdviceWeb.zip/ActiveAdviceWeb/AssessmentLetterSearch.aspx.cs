using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for AssessmentLetterSearch.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.LETTER_SETUP)]

	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("AssessmentCategory,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("AssessmentLetterMaintenance")]
	[PageTitle("@ASMTCATEGORYSEARCHPAGETITLE@")]
	public class AssessmentLetterSearch : LetterMaintenanceBasePage
	{
		private AssessmentCategoryCollection assessmentCategories;
		private AssessmentCategory assessmentCategorySearcher;
		private AssessmentCategory assessmentCategory;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCMSTypeID_Seach;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSTypeID_Seach;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSTypeID_Seach;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActiveWithAllCategory;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCategorySearch;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCategories;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnShowCategoryDetailPanel;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCategoriesGridHolder;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.wbtnSearch.Click += new System.EventHandler(this.wbtnSearch_Click);
			this.wbtnShowCategoryDetailPanel.Click += new System.EventHandler(this.wbtnShowCategoryDetailPanel_Click);
			this.gridCategories.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridCategories_ClickCellButton);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
			{
				NewAssessmentCategorySearcher();
				NewAssessmentCategories();
			}
			else
			{
				assessmentCategorySearcher = (AssessmentCategory)this.LoadObject("AssessmentCategorySearcher");  // load object from cache
				assessmentCategories = (AssessmentCategoryCollection)this.LoadObject("AssessmentCategories");  // load object from cache
			}
		}

		#region AssessmentCategorySearcher
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentCategory AssessmentCategorySearcher
		{
			get { return assessmentCategorySearcher; }
			set
			{
				assessmentCategorySearcher = value;
				try
				{
					this.UpdateFromObject(this.pnlCategorySearch.Controls, assessmentCategorySearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("AssessmentCategorySearcher", assessmentCategorySearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAssessmentCategorySearcher()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlCategorySearch.Controls, assessmentCategorySearcher);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAssessmentCategorySearcher()
		{
			bool result = true;
			AssessmentCategory assessmentCategorySearcher = null; //new AssessmentCategory(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				assessmentCategorySearcher = new AssessmentCategory();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.AssessmentCategorySearcher = assessmentCategorySearcher;
			this.ActiveWithAllCategory.SelectedRow = this.ActiveWithAllCategory.Rows[0];
			return result;
		}
		#endregion

		#region AssessmentCategories
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentCategoryCollection AssessmentCategories
		{
			get { return assessmentCategories; }
			set
			{
				assessmentCategories = value;
				try
				{
					this.gridCategories.UpdateFromCollection(assessmentCategories);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("AssessmentCategories", assessmentCategories);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool SearchForAssessmentCategories()
		{
			bool result = true;
			AssessmentCategoryCollection assessmentCategories = new AssessmentCategoryCollection();
			try
			{
				if (!this.ReadControlsForAssessmentCategorySearcher()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				assessmentCategories = AssessmentCategoryCollection.GetFromSearch(this.assessmentCategorySearcher);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//assessmentCategories.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.AssessmentCategories = assessmentCategories;
			return result;
		}

		public bool NewAssessmentCategories()
		{
			bool result = true;
			AssessmentCategoryCollection assessmentCategories = null;
			try
			{
				assessmentCategories = new AssessmentCategoryCollection();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			this.AssessmentCategories = assessmentCategories;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForAssessmentCategories()
		{
			try
			{	// data from controls to object
				//				if (!this.ReadControlsForAssessmentCategories())
				//					return false;
				assessmentCategories.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region AssessmentCategory Object
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentCategory AssessmentCategory
		{
			get { return assessmentCategory; }
			set
			{
				assessmentCategory = value;
//				try
//				{
//					this.UpdateFromObject(this.pnlCategoryDetails.Controls, assessmentCategory);  // update controls for the given control collection
//					// other object-to-control methods if any
//				}
//				catch(Exception ex)
//				{
//					this.RaisePageException(ex);  // notify the page about the error
//				}
				this.CacheObject("AssessmentCategoryObject", assessmentCategory);  // cache object using the caching method declared on the page
			}
		}

//		/// <summary>
//		/// Reads control values into the data object and validates them.  Returns false if there's any problem
//		/// </summary>
//		public bool ReadControlsForAssessmentCategory()
//		{
//			try
//			{	//customize this method for this specific page
//				this.UpdateToObject(this.pnlCategoryDetails.Controls, assessmentCategory);	// controls-to-object
//				// other control-to-object methods if any
//				return this.IsValid;	// Return validation result
//			}
//			catch(Exception ex)
//			{
//				this.RaisePageException(ex);	// notify the page about the error
//				return false;
//			}
//		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAssessmentCategory()
		{
			bool result = true;
			AssessmentCategory assessmentCategory = null;
			try
			{	// or use an initialization method here
				assessmentCategory = new AssessmentCategory(true);
				assessmentCategory.Active = true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.AssessmentCategory = assessmentCategory;
			return result;
		}

//		/// <summary>
//		/// Call this method when you want to retrieve data from controls and save them to table.
//		/// </summary>
//		public bool SaveDataForAssessmentCategory()
//		{
//			try
//			{	// data from controls to object
//				if (!this.ReadControlsForAssessmentCategory())
//					return false;
//				this.AssessmentCategories.Add(this.assessmentCategory);
//			}
//			catch(Exception ex)
//			{
//				this.RaisePageException(ex);
//				return false;
//			}
//			return true;
//		}
		#endregion

		#region UI Initialization
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e); 
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}

		private void wbtnSearch_Click(object sender, System.EventArgs e)
		{
			SearchForAssessmentCategories();
		}

		private void wbtnShowCategoryDetailPanel_Click(object sender, System.EventArgs e)
		{
			NewAssessmentCategory();
			AssessmentLetterMaintenance.Redirect(AssessmentCategory);
		}

		private void gridCategories_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridCategories.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			AssessmentCategory = AssessmentCategories[index];
			if (e.Cell.Key == "Edit")
			{
				AssessmentLetterMaintenance.Redirect(AssessmentCategory);
			}
		}
		#endregion
	}
}
