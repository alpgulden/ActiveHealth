using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Outcome,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[PageTitle("@OUTCOMEPAGETITLE@")]
	public class OutcomesForm : PatientBasePage
	{
		private Outcome outcome;
		private OutcomeCollection outcomes;

		private Patient patient;
		private Problem problem;
		private PatientCoverage patientCoverage;
		private BaseForEventCMSReferral erc;			// any one of these:  Event, CMS, Referral

		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTabEvent;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTabRef;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTabCMS;

		protected NetsoftUSA.WebForms.OBButton butAddNewOutcome;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlOutcomes;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlOutcome;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldComment;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Comment;
		protected NetsoftUSA.WebForms.OBFieldLabel lbComment;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutcomeRiskID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo OutcomeRiskID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutcomeRiskID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldResultFrom;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ResultFrom;
		protected NetsoftUSA.WebForms.OBFieldLabel lbResultFrom;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutcomeDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit OutcomeDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutcomeDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutcomeCodeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo OutcomeCodeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutcomeCodeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutcomeReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo OutcomeReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutcomeReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSubindicator;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Subindicator;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSubindicator;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutcomeIndicatorID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo OutcomeIndicatorID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutcomeIndicatorID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldType;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Type;
		protected NetsoftUSA.WebForms.OBFieldLabel lbType;
		protected NetsoftUSA.WebForms.OBButton butCancelOutcome;
		protected NetsoftUSA.WebForms.OBButton butSaveOutcome;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridOutcomes;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSaveCancel;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected UserDefined UserDefined1;
		private void Page_Load(object sender, System.EventArgs e)
		{
			UserDefined1.ReloadContext("Outcome",outcome,true);
			if(!UserDefined1.HasFields())
				this.pnlUserDefined.Visible = false;
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache

				outcomes = erc.Outcomes;
				outcome = (Outcome)this.LoadObject(typeof(Outcome));  // load object from cache
			}
			
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject(typeof(Outcome), null);
			erc.Outcomes = null;
			base.NavigateAway (targetURL);
		}


		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			try
			{	
				// use any load method here
				// or pull from the parameter passed to this page via PushParam
				patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
				// get the passed patient subscriber coverage (link to patient)
				patientCoverage = GetParamOrGetFromCache("PatientCoverage", typeof(PatientCoverage)) as PatientCoverage;
				if (patientCoverage == null)	
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-subscriber-coverage");
				problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
				//if (problem == null)	
				//	throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
			finally
			{
				//eventObj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CacheObject(typeof(Patient), patient);
			this.CacheObject(typeof(PatientCoverage), patientCoverage);
			this.CacheObject(typeof(Problem), problem);
			this.CacheObject(typeof(BaseForEventCMSReferral), erc);
			return LoadDataForOutcomes();
			//return true;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitializeComponent();
			base.OnInit(e);

			gridOutcomes.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridOutcomes_ColumnsBoundToDataClass);
			gridOutcomes.ClickCellButton +=new ClickCellButtonEventHandler(gridOutcomes_ClickCellButton);
			this.butAddNewOutcome.Click += new System.EventHandler(this.butAddNewOutcome_Click);
			this.butSaveOutcome.Click += new System.EventHandler(this.butSaveOutcome_Click);
			this.butCancelOutcome.Click += new System.EventHandler(this.butCancelOutcome_Click);			

			this.Type.SelectedRowChanged +=new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(Type_SelectedRowChanged);
			this.OutcomeIndicatorID.SelectedRowChanged +=new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(OutcomeIndicatorID_SelectedRowChanged);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public OutcomeCollection Outcomes
		{
			get { return outcomes; }
			set
			{
				outcomes = value;
				try
				{
					gridOutcomes.UpdateFromCollection(outcomes);  // update given grid from the collection
					// other object-to-control methods if any
					Outcome = null;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(OutcomeCollection), outcomes);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForOutcomes()
		{
			bool result = true;
			OutcomeCollection outcomes = null;
			try
			{	// use any load method here
				erc.LoadOutcomes(false);
				outcomes = erc.Outcomes;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//outcomes.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Outcomes = outcomes;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, BaseForEventCMSReferral erc)
		{
			if (patient == null || patCov == null)
				throw new ActiveAdviceException("You can open outcomes only in the context of patient and coverage and event/referral/cms"); 

			BasePage.PushCurrentCallingPage();
			
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("ERC", erc);
			BasePage.Redirect("OutcomesForm.aspx");
		}


		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				erc.SaveOutcomes();

				this.gridOutcomes.UpdatePKsFromCollection(this.erc.Outcomes);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		#region Outcome
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Outcome Outcome
		{
			get { return outcome; }
			set
			{
				outcome = value;
				try
				{
					bool vis = (value != null);
					pnlOutcome.Visible = vis;
					if(UserDefined1.HasFields())
						pnlUserDefined.Visible = vis;
					pnlSaveCancel.Visible = vis;
					pnlOutcomes.Visible = !vis;

					this.UpdateFromObject(pnlOutcome.Controls, outcome);  // update controls for the given control collection
					UserDefined1.ReloadContext("Outcome",outcome,false);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Outcome), outcome);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForOutcome()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlOutcome.Controls, outcome);	// controls-to-object
				// other control-to-object methods if any
				UserDefined1.UserDefinedValue=outcome.UserDefined  ;
				UserDefined1.ReadControls();
				
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewOutcome()
		{
			bool result = true;
			Outcome outcome = new Outcome(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Outcome = outcome;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForOutcome()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForOutcome())
					return false;
				// we must do this to mark the parent as dirty
				if (this.outcome.ParentOutcomeCollection == null)
					this.outcomes.Add(this.outcome);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region UI Initialization and Events
		private void butAddNewOutcome_Click(object sender, System.EventArgs e)
		{
			NewOutcome();
		}

		private void butSaveOutcome_Click(object sender, System.EventArgs e)
		{
			if (SaveDataForOutcome())
				this.Outcomes = this.Outcomes;
		}

		private void butCancelOutcome_Click(object sender, System.EventArgs e)
		{
			this.Outcome = null;
		}

		private void gridOutcomes_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			gridOutcomes.AddButtonColumn("Edit", "@EDIT@", 0).Width = 70;
		}

		private void gridOutcomes_ClickCellButton(object sender, CellEventArgs e)
		{
			int index = gridOutcomes.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			switch (e.Cell.Key)
			{
				case "Edit":
				{
					this.Outcome = this.outcomes[index];
					break;
				}
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.erc);
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
			
			this.erc = this.GetParamOrGetFromCache("ERC", typeof(BaseForEventCMSReferral)) as BaseForEventCMSReferral;
			if (this.erc == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an event/referral/CMS");
			
			if(this.erc is Event)
			{
				this.PageTabRef.Visible = this.PageTabCMS.Visible = false;
				this.PageTabEvent.SelectedTabKey = "OUT_OutcomesEvent";
			}
			else if(this.erc is Referral)
			{
				this.PageTabEvent.Visible = this.PageTabCMS.Visible = false;
				this.PageTabRef.SelectedTabKey = "OUT_OutcomesRef";
			}
			else if(this.erc is CMS)
			{
				this.PageTabEvent.Visible = this.PageTabRef.Visible = false;
				this.PageTabCMS.SelectedTabKey = "OUT_OutcomesCMS";
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			SetERCTabVisibilities();
			this.SetPageToolbarItemEnabled("Save", !this.pnlSaveCancel.Visible);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();

			this.CheckForDirty(this.outcomes);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "OUT_OutcomesEvent" || tab.Key == "OUT_OutcomesRef" || tab.Key == "OUT_OutcomesCMS")
			{
				this.AddClinicalSummaryButton(toolbar);
			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public new void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if(this.erc is Event)
				this.RedirectToEvent();
			else if(this.erc is Referral)
				this.RedirectToReferrer();
			else if(this.erc is CMS)
				this.RedirectToCMS();
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@OUTCOMES@");
			}
		}

		private void Type_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			this.UpdateToObject(Type, outcome);
			outcome.OutcomeIndicatorID = 0;
			this.UpdateFromObject(OutcomeIndicatorID, this.outcome);
			outcome.Subindicator = 0;
			this.UpdateFromObject(Subindicator, this.outcome);
		}

		private void OutcomeIndicatorID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			this.UpdateToObject(OutcomeIndicatorID, this.outcome);
			outcome.Subindicator = 0;
			this.UpdateFromObject(Subindicator, this.outcome);
		}
		#endregion

	}
}
