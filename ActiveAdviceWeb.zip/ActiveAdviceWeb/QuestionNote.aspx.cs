using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]
	[MainDataClass("AssessmentQuestionNote,DataLayer")]
	[PageTitle("@QUESTIONNOTEPAGETITLE@")]
	public class QuestionNote : AssessmentBasePage
	{
		private Question question;
		private AssessmentQuestionNoteCollection assessmentQuestionNotes;
		private AssessmentQuestionNote assessmentQuestionNote;
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNotes;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridNotes;
		protected NetsoftUSA.WebForms.OBTextBox txtNote;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private enum PageModeEnum
		{
			SingleNote,
			NoteHistory
		}

		private PageModeEnum pageMode;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();
			}
			else
			{
				assessmentQuestionNote = (AssessmentQuestionNote)this.LoadObject("AssessmentQuestionNoteNP");  // load object from cache
				assessmentQuestionNotes = (AssessmentQuestionNoteCollection)this.LoadObject("AssessmentQuestionNoteCollectionNP");  // load object from cache
				question = (Question)this.LoadObject("QuestionNP");
				pageMode = (PageModeEnum)this.LoadObject(typeof(PageModeEnum));
			}

		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("QuestionNote.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.gridNotes.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridNotes_ColumnsBoundToDataClass);
			this.gridNotes.ClickCellButton += new ClickCellButtonEventHandler(gridNotes_ClickCellButton);
			this.gridNotes.SelectedRowIndexChanged += new EventHandler(gridNotes_SelectedRowIndexChanged);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			AssessmentQuestionNote assessmentQuestionNote = null;
			try
			{	
				if (this.Request["QID"] != null)
				{
					int questionID = int.Parse(this.Request["QID"].ToString());
					question = assessmentContext.Questions.FindBy(questionID);

					if (this.Request["M"] != null && this.Request["M"] == "H") // Note History
					{
						pageMode = PageModeEnum.NoteHistory;
						this.assessmentContext.QuestionNotes.FilterQuestionID = questionID;
						this.assessmentContext.QuestionNotes.FilterAssessmentGUID = this.assessmentContext.Assessment.AssessmentGUID;
					
						this.AssessmentQuestionNotes = this.assessmentContext.QuestionNotes;
					}
					else
					{
						pageMode = PageModeEnum.SingleNote;

						this.assessmentContext.QuestionNotes.IndexBy_AssessmentGUID_QuestionID.Rebuild();

						assessmentQuestionNote = this.assessmentContext.QuestionNotes.FindBy(this.assessmentContext.AssessmentGUID, questionID);
						if (assessmentQuestionNote == null)
							assessmentQuestionNote = new AssessmentQuestionNote(true);

						this.AssessmentQuestionNote = assessmentQuestionNote;
					}

//
//					this.assessmentContext.QuestionNotes.FilterQuestionID = -1;
//					this.assessmentContext.QuestionNotes.FilterAssessmentGUID = null;

				}

				this.CacheObject("QuestionNP", question);
				this.CacheObject(typeof(PageModeEnum), pageMode);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//obj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentQuestionNote AssessmentQuestionNote
		{
			get { return assessmentQuestionNote; }
			set
			{
				assessmentQuestionNote = value;
				try
				{
					this.UpdateFromObject(pnlNote.Controls, assessmentQuestionNote);  // update controls for the given control collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject("AssessmentQuestionNoteNP", assessmentQuestionNote);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentQuestionNoteCollection AssessmentQuestionNotes
		{
			get { return assessmentQuestionNotes; }
			set
			{
				assessmentQuestionNotes = value;
				try
				{
					gridNotes.UpdateFromCollection(assessmentQuestionNotes);  // update controls for the given control collection
					// other object-to-control methods if any

					if (pageMode == PageModeEnum.NoteHistory && gridNotes.Rows.Count > 0)
					{
						gridNotes.SelectedRowIndex = 0;
						AssessmentQuestionNote = assessmentQuestionNotes[gridNotes.SelectedColectionIndex];
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject("AssessmentQuestionNoteCollectionNP", assessmentQuestionNotes);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAssessmentQuestionNote()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlNote.Controls, assessmentQuestionNote);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}


		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForAssessmentQuestionNote()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForAssessmentQuestionNote())
					return false;
				if (assessmentQuestionNote.ParentAssessmentQuestionNoteCollection == null)
				{
					this.assessmentContext.QuestionNotes.AddRecord(assessmentQuestionNote);
					assessmentQuestionNote.AssessmentGUID = this.assessmentContext.AssessmentGUID;
					assessmentQuestionNote.QuestionID = question.QuestionID;
					assessmentQuestionNote.CMSID = this.assessmentContext.CMS.CMSID;
				}
				else
					assessmentQuestionNote.MarkDirty();

				this.AssessmentContext = assessmentContext;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void gridNotes_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridNotes.AddButtonColumn("Select", "@SELECT@", 0);
		}

		private void gridNotes_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridNotes.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			if (e.Cell.Key == "Select")
			{
				this.AssessmentQuestionNote = this.assessmentQuestionNotes[index];
			}
		}


		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(question);
		}

		private void gridNotes_SelectedRowIndexChanged(object sender, EventArgs e)
		{
			int index = gridNotes.SelectedRowIndex;
			if (index < 0)
				return;

			this.AssessmentQuestionNote = this.assessmentQuestionNotes[index];
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVE@", "Save");
			toolbar.AddButton("@CLOSE@", "Close");
		}


		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForAssessmentQuestionNote())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@NOTE@");
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.pnlNotes.Visible = (this.pageMode == PageModeEnum.NoteHistory);
			this.SetPageToolbarItemVisible("Save", (!assessmentContext.IsReadOnly && this.pageMode == PageModeEnum.SingleNote));
			this.txtNote.ReadOnly = (assessmentContext.IsReadOnly || this.pageMode == PageModeEnum.NoteHistory);

			if (assessmentContext.IsReadOnly)
				this.SetPageToolbarItemTargetURL("Close", "javascript:window.close();");
			else
				this.SetPageToolbarItemTargetURL("Close", "javascript:window.opener.__doPostBack('','');window.close();");
		}


	}
}
