using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using System.Text;
using System.Web.UI.HtmlControls;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using System.Collections;
using System.Diagnostics;
using System.Web.Caching;
using System.Collections.Specialized;
using System.Net;
using System.IO;



namespace ActiveAdvice.Web
{
	[Flags]
	public enum EnumActivityAndNoteContext
	{	
		// combinations
		Patient = fPatient,			// Use only patient context
		Problem = Patient + fProblem,	// Use patient, problem context
		ERC = Problem + fERC,		// Use patient, problem, and ERC context
		PRRequest = ERC + fPRRequest, // Use patient, problem, Event and PRRequest context
		PRReview = PRRequest + fPRReview,	// Use patient, problem, Event, PRRequest and PRReview context
		PRProviderDecision = PRReview + fPRProviderDecision, // Use patient, problem, Event, PRRequest, PRReview and PRProviderDecision context
		ReferralDetail = ERC + fReferralDetail,		// Use patient, problem, Referral and ReferralDetail context

		// individual flags
		fPatient = 1,			// Use only patient context
		fProblem = 2,			// Use patient, problem context
		fERC = 4,				// Use patient, problem, and ERC context
		fPRRequest = 8,	
		fPRReview = 16,	
		fPRProviderDecision = 32,
		fReferralDetail = 64	// Use patient, problem, Referral and ReferralDetail context
	}

	/// <summary>
	/// ActiveAdvice base page
	/// </summary>
	[Designer("Microsoft.VSDesigner.WebForms.WebFormDesigner,Microsoft.VSDesigner")]
	public class BasePage : NetsoftUSA.InfragisticsWeb.BasePage
	{
		public static bool EnableDebugButtons = false;		// Enables buttons like ClearCache

		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected WebToolbar PageToolbar;

		private TBarButton togglePrintButton;

		private NetsoftUSA.DataLayer.Language lang;

		private bool printablePage;				// whether this page should display print button or not.

		private string pageTitle;
		
		protected bool wasCancelled = false;		// True if this page was called after hitting a "Cancel" button.

		protected bool enableClientTimeout = true; // This controls the behavior of client timer
		protected bool enableAutoLogout = true; // This controls the action taken when the user closes the browser window

		// Custom implementation that collects un-translated messages and informs the user
		private Hashtable untranslatedMessageIDs = new Hashtable();

		public BasePage(): base()
		{

			//
			// TODO: Add constructor logic here
			//
			this.SourceClassNames = new string[] { "DataLayer.*" };
			//this.ViewStateOnServer = true;
		}

		public virtual void OnMainNavigationItemClick_MLicensee()  
		{ 
			LicenseeForm.Redirect(); 
		}

		protected override void CreateChildControls()
		{
			base.CreateChildControls ();
			this.ValidationsOnlyInSummary = true;
		}

		protected override void OnError(EventArgs e)
		{
			//base.OnError (e);
			// At this point we have information about the error
			// This fuction must be robust enough!  Don't cause any more exceptions.
			Exception ex = null;
			System.Reflection.TargetInvocationException tex = null;
			try
			{
				HttpContext ctx = HttpContext.Current;
				ex = ctx.Server.GetLastError();
				if (ex != null)
				{
					tex = ex as System.Reflection.TargetInvocationException;
					if (tex != null)
						ex = tex.InnerException;	// get the actual exception

					if (ex is System.Threading.ThreadAbortException)		// ignore the exception caused by Redirect!  This is used by ASP.NET's Redirect method as a way to abort the current execution.
						return;

					//this.RaisePageException(ex);
					this.CancelNavigateAway = true;
					ctx.Server.ClearError();
					ErrorForm.Redirect(ex);
				}
			}
			catch(System.Threading.ThreadAbortException)
			{
				throw;
			}
			catch
			{
				// ignore all local exceptions...
			}

			// Last chance to handle the exception.
			this.CancelNavigateAway = true;
			ErrorForm.Redirect(new ActiveAdviceException( "@APPLICATIONERROR@" ));
		}

		public override EnumPageType PageType
		{
			get
			{
				return base.PageType;
			}
			set
			{
				base.PageType = value;

				// aplication specific rule:  all data entry pages must also check for dirty
				this.DirtyCheckEnabled = this.IsDataEntryPage;
				this.RequiredValidationsEnabled = this.IsDataEntryPage;
			}
		}


		/// <summary>
		/// Easy access to translated base messages.
		/// </summary>
		public BaseMessages BaseMessages
		{
			get { return (BaseMessages)this.Language; }
		}

		/// <summary>
		/// If you set this property to true in design time,
		/// The page will handle all print preview and printing functionality.
		/// </summary>
		[DefaultValue(false)]
		public bool PrintablePage
		{
			get
			{
				return this.printablePage;
			}
			set
			{
				this.printablePage = value;
			}
		}

		[DefaultValue(true)]
		public bool EnableClientTimeout
		{
			get	{ return this.enableClientTimeout; }
			set	{ this.enableClientTimeout = value; }
		}

		[DefaultValue(true)]
		public bool EnableAutoLogout
		{
			get { return this.enableAutoLogout;}
			set	{ this.enableAutoLogout = value;}
		}

		protected override void OnLoad(EventArgs e)
		{
			
			this.wasCancelled = GetParamBool("WasCancelled", false);

			string callingPage = (string)GetParam("CallingPage");
			if (callingPage != null)
			{
				//this.PageReferrer = callingPage;		// cancel will go back to the given page
				this.BackPage = callingPage;
			}

			// Enable autoscroll on all pages
			this.AutoScroll = true;

			base.OnLoad (e);

			/*
			Response.Write(GC.GetTotalMemory(false));
			GC.Collect();
			Response.Write("<BR>" + GC.GetTotalMemory(false));
			*/
		}

		protected virtual void ArrangePageElements()
		{
			try
			{
				HtmlTable outerMostTable = ReflectionHelper.GetMemberValue(this, "OuterMostTable") as HtmlTable; 
				HtmlTable outerTable = ReflectionHelper.GetMemberValue(this, "OuterTable") as HtmlTable; 

				if (outerMostTable != null && outerTable != null)
				{

					// We need to hide some of the page elements if the page is in popup mode.
					// The implementation below is pretty ugly but it does the job.
					if (this.IsPopup)
					{
						try
						{
							outerMostTable.Rows[0].Visible = false;
							outerMostTable.Rows[1].Visible = false;

							//							foreach (HtmlTableRow tableRow in OuterTable.Rows)
							//							{
							//								tableRow.Cells[0].Visible = false;
							//							}

							//							Control control = null;
							//							for (int i = 0; i < OuterMostTable.Rows[2].Cells[0].Controls.Count; i++)
							//							{
							//								control = OuterMostTable.Rows[2].Cells[0].Controls[i];
							//								if (control != null && !(control is HtmlTable))
							//								{
							//									OuterMostTable.Rows[2].Cells[0].Controls[i].Visible = false;
							//								}
							//							}
					
						}
						catch
						{
							this.SetPageMessage("This page is running in popup mode but the system cannot hide unnecessary page elements properly. The most common reason is that the html code of this page has been modified.", EnumPageMessageType.Warning);
						}
					}

					try
					{
						Control parentControl = outerMostTable.Parent;
						Control childControl = null;
						for (int i = 0; i < parentControl.Controls.Count; i++)
						{
							childControl = parentControl.Controls[i];
							if (childControl != null && childControl is LiteralControl)
							{
								childControl.Visible = false;
							}
						}
					}
					catch
					{
						this.SetPageMessage("The system cannot hide unnecessary page elements properly. The most common reason is that the html code of this page has been modified.", EnumPageMessageType.Warning);
					}
				}
			}
			catch
			{
			}
		}


		protected override void OnPreRender(EventArgs e)
		{
			ArrangePageElements();
			base.OnPreRender (e);

			
			this.SetPageTabToolbarItemVisible("Print", this.PrintPreviewMode);
			this.SetPageToolbarItemVisible("Save", !this.PrintPreviewMode);
			this.SetPageToolbarItemVisible("Cancel", !this.PrintPreviewMode);

			if (togglePrintButton != null)
			{
				string s = this.PrintPreviewMode ? "@NORMALVIEW@" : "@PRINTPREVIEW@";
				togglePrintButton.Text = this.Language.Translate(s);
			}

			if (PageToolbar != null)
				PageToolbar.Visible = !this.PrintPreviewMode;

			if(enableClientTimeout && !this.IsPopup && !IsStartupScriptRegistered("setTimeout"))
			{
				RegisterStartupScript("setTimeout", AASecurityHelper.TimeoutJS);
			}

			// It's on by default so only render when it's off
			if(!IsStartupScriptRegistered("autoLogout"))
			{
				RegisterStartupScript("autoLogOut", "<script ='javascript'>Page_AutoLogout = " + (enableAutoLogout && !this.IsPopup).ToString().ToLower() + ";</script>");
			}
		}

		protected override void Render(HtmlTextWriter writer)
		{
			// Write the newly found un-translated messages into db and also display.
			WriteUntranslatedMessages(true);

			DebugDumpAnalysisWarnings(writer);

			base.Render (writer);
			

			// Write the possible last-second added newly found un-translated messages into db.
			//WriteUntranslatedMessages(false);

			DebugDumpPostRenderStatus(writer);
		}

		private void WriteUntranslatedMessages(bool beforeRender)
		{
			string messagesCreated = null;
			ArrayList toRemove = null;
			if (beforeRender)
				toRemove = new ArrayList();
			try
			{
				lock (this.untranslatedMessageIDs)
				{

					foreach (DictionaryEntry de in this.untranslatedMessageIDs)
					{
						string msgID = (string)de.Key;
						ActiveAdvice.Messages.Message msg = new ActiveAdvice.Messages.Message();
						string text = null;
					
						// if we can load it from db, and the text is not null, we just update the in-memory cached table
						bool existsInDB = msg.Load(msgID, this.Language.LangID);
						if (existsInDB)
							text = msg.Text;
						if (text != null)	// if already exists, update the in-memory table
						{
							try
							{
								this.Language.AddMessage(msgID, msg.Text);
								if (beforeRender)
									toRemove.Add(msgID);		// remove displayed msgIDs
							}
							catch
							{
								// ignore
							}
						}
						else
						{
							if (beforeRender)
								toRemove.Add(msgID);		// remove displayed msgIDs

							// the message was not found, either doesn't exist in db or the message is null
							// check if it really doesn't exist.
							if (!existsInDB)
							{
								msg.New(msgID, this.Language.LangID, null);
								msg.Save();

								if (messagesCreated != null)
									messagesCreated += ", ";
								messagesCreated += msgID;
								/*try
								{
									this.Language.AddMessage(msgID, null);
								}
								catch
								{
									// ignore
								}*/
							}
						}

					}
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}

			if (messagesCreated != null)
				this.SetPageMessage("The following messages have been created in the Message table: {0}.  You can put the texts for them.", EnumPageMessageType.AddWarning, messagesCreated);

			if (beforeRender)
			{
				lock (this.untranslatedMessageIDs)
				{
					// Remove all msgID's that were displayed to the user.
					foreach (string msgID in toRemove)
					{
						untranslatedMessageIDs.Remove(msgID);
					}
				}
			}
		}


		public override void RaisePageException(string source, Exception ex)
		{
			// if this is redirect exception don't wait until the basepage handles this
			System.Reflection.TargetInvocationException tex = ex as System.Reflection.TargetInvocationException;
			if (tex != null)
				ex = tex.InnerException;	// get the actual exception

			if (ex is System.Threading.ThreadAbortException)		// ignore the exception caused by Redirect!  This is used by ASP.NET's Redirect method as a way to abort the current execution.
				return;

			// Create a new pagesummary object to store the page context
			PageSummary pageSummary = new PageSummary();
			pageSummary.CurrentPage = this.Page as BasePage;

			// Get the page context from the method implemented on the page 
			this.RenderPageSummary(pageSummary);
            
			if (source == null) source = "";

			if (source != "")
				source += "\r\n";
			source += pageSummary.PlainTextContent;

			base.RaisePageException (source, ex);
		}


		/*protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			//untranslatedMessageIDs = (Hashtable)ViewState["UntranslatedMessageIDs"];
		}

		protected override object SaveViewState()
		{
			//ViewState["Untranslated/MessageIDs"] = untranslatedMessageIDs;
			return base.SaveViewState ();
			
		savedState = this.LoadObject(PageName + "_ViewState", ObjectCachingMethod.UseSession);
			this.CacheObject(PageName + "_ViewState", vs, ObjectCachingMethod.UseSession);
		}*/

		public virtual void OnToolbarButtonClick_TogglePrint(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.PrintPreviewMode = !this.PrintPreviewMode;
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems(toolbar, tab);
			
			if (this.printablePage)
			{
				if (togglePrintButton == null)
				{
					togglePrintButton =  toolbar.AddButton("@PRINTPREVIEW@", "TogglePrint").Item;
					toolbar.AddButton("@PRINT@", "Print").Item.TargetURL = "javascript:" + "window.print();";
				}
			}
			
		}

		public override void PopulateToolbarItems(WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
		}


		public override void PopulateTabItems(WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}
		
		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			if (AASecurityHelper.GetUserId != 0)
			{

				// Developer / Tester Mode buttons
				//#if DEBUG
				Infragistics.WebUI.UltraWebListbar.Group group = listbar.AddGroup("TestMode", "TestMode");
				if (ActiveAdvice.Web.BasePage.EnableDebugButtons)
					listbar.AddItem(group, "Clear Global Cache", "ClearCache");

				//#endif
			
				if (ActiveAdvice.Web.BasePage.EnableDebugButtons)
				{
					listbar.AddItem("@MESSAGEIDS@", "DisplayMessageIDs");
					listbar.AddItem("GC", "GC");
				}
			}
		}

		public override void SelectSideMenuItem(WebListBar listBar)
		{
			string selectedItem = null;
			if(this.SelectedSideMenuItem != null)
				selectedItem = this.SelectedSideMenuItem;
			else
				selectedItem = SelectedMenuItemAttribute.GetMenuItemFromType(this.GetType());

			Infragistics.WebUI.UltraWebListbar.Group group =listBar.Groups.FromKey("Default");
			if(group != null)
			{
				foreach (Infragistics.WebUI.UltraWebListbar.Item item in group.Items)
				{
					item.DefaultStyle.CssClass = "listbardefault";
				}

				if (selectedItem != null)
				{
					Infragistics.WebUI.UltraWebListbar.Item itm = group.Items.FromKey(selectedItem);
					if (itm != null)
						itm.DefaultStyle.CssClass = "listbarselected";
				}
			}
		}

		public override string SelectMainMenuItem()
		{
			if(this.SelectedMainMenuItem !=null)
				return this.SelectedMainMenuItem;
			else
			{
				string menuItem = SelectedMainMenuItemAttribute.GetMenuItemFromType(this.GetType());
				return menuItem;
			}
		}

		public string PageTitle
		{
			get 
			{
				if (this.pageTitle != null) 
					return this.pageTitle;
				else
					return PageTitleAttribute.GetPageTitleFromType(this.GetType()); 
			}
			set
			{
				this.pageTitle = value;
			}
		}

		public override void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (button.Key == "Cancel")
				PushCancelled();
			//	BasePage.PushParam("ReuseViewState", true);
			base.OnToolbarButtonClick (toolbar, button);
		}

		public override void OnSubNavigationItemClick(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			base.OnSubNavigationItemClick (listbar, item);

			switch (item.Key)
			{
				case "ClearCache":
					NSGlobal.ClearCache();

					// Don't clear any other context!  This is just to clear cached collections
					// and stuff like that, just to force them to be reloaded!
					// Only to use in a debugging environment.

					//AASecurityHelper.AAUser.InvalidateData();
					//RedirectBack();
					break;
				case "DisplayMessageIDs":
					NetsoftUSA.DataLayer.Language.TranslationEnabled = !NetsoftUSA.DataLayer.Language.TranslationEnabled;
					// Force the languages to be reloaded.
					this.ClearAllCachedLanguageClassInstances();					// This clears all the cached application message class instances.
					NetsoftUSA.DataLayer.Language.ClearGloballyCachedMessages();	// This clears all the globally cached language messages.
					break;
				case "GC":
					GC.Collect();
					break;
			}
		}

		public override void ApplyCss(WebTab webTab)
		{
			base.ApplyCss (webTab);

			//webTab.BackColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");

			foreach (Infragistics.WebUI.UltraWebTab.TabItem tabItem in webTab.Tabs)
			{
				Infragistics.WebUI.UltraWebTab.Tab tab = tabItem as Infragistics.WebUI.UltraWebTab.Tab;
				if (tab != null)
				{
					//tab.Style.BackColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
				}
			}

			webTab.BarHeight = 0;
			webTab.BorderStyle = BorderStyle.None;
			webTab.ThreeDEffect = false;
			webTab.SpaceOnRight = 0;
			webTab.SpaceOnLeft = 0;

			//webTab.DefaultTabStyle.Height = Unit.Pixel(22);

			webTab.CssClass = "tab";
			webTab.DefaultTabStyle.CssClass = "tabdefault";
			webTab.DefaultTabSeparatorStyle.CssClass = "DefaultTabSeperator";
			webTab.DisabledTabStyle.CssClass = "tabdisabled";
			webTab.HoverTabStyle.CssClass = "tabhover";
			webTab.SelectedTabStyle.CssClass = "tabselected";

			//webTab.DefaultTabStyle.CustomRules="background-color:#cccccc;border-right:white 3px solid;border-left:white 3px solid; border-bottom:#666666 1px solid";
			//webTab.SelectedTabStyle.CustomRules="background-color:#f9f9f9;border-right:white 3px solid;border-left:white 3px solid; border-bottom:0px;";
			//webTab.HoverTabStyle.CustomRules="background-color:#eeeeee;border-right:white 3px solid;border-left:white 3px solid; border-bottom:#666666 1px solid";
			//webTab.DisabledTabStyle.CustomRules="background-color:#f9f9f9;border-right:white 3px solid;border-left:white 3px solid; border-bottom:#666666 1px solid";

			webTab.RoundedImage.LeftSideWidth = 10;
			webTab.RoundedImage.RightSideWidth = 10;
			webTab.RoundedImage.DisabledImage= "./pics/tabdisabled.gif";
			webTab.RoundedImage.ShiftOfImages= 10;
			webTab.RoundedImage.SelectedImage= "./pics/tabselected.gif";
			webTab.RoundedImage.NormalImage= "./pics/tab.gif";
			webTab.RoundedImage.HoverImage= "./pics/tabhover.gif";
			webTab.RoundedImage.FillStyle= Infragistics.WebUI.UltraWebTab.RoundedImageStyle.None;
          
			webTab.DummyTargetUrl = "";
		}


		public override void ApplyCss(WebToolbar toolbar)
		{
			base.ApplyCss (toolbar);

			switch (toolbar.ToolbarType)
			{
				case ToolbarType.TabToolbar:
			
					toolbar.CssClass = "tabtoolbar";
					toolbar.DefaultStyle.CssClass = "tabtoolbarbuttondefault";
					toolbar.HoverStyle.CssClass = "tabtoolbarbuttonhover";
					toolbar.SelectedStyle.CssClass = "tabtoolbarbuttonselected";
								
					toolbar.Height = Unit.Pixel(10);
					toolbar.ItemSpacing = 0;
					toolbar.ItemWidthDefault = Unit.Pixel(50);

					TBSeparator ts = toolbar.Items.AddSeparator();
					ts.Key = "rightsepertor";
					ts.Width = Unit.Pixel(20); 
					ts.Image = "pics/pixel_trans.gif";
					break;

				case ToolbarType.PageToolbar:

					//Infragistics.WebUI.UltraWebToolbar.TBSeparator  separator = toolbar.Items.AddSeparator();
					//separator.Image = "pics/pixel_trans.gif";
					toolbar.CssClass = "pagetoolbar";
					toolbar.DefaultStyle.CssClass = "pagetoolbarbuttondefault";
					toolbar.HoverStyle.CssClass = "pagetoolbarbuttonhover";
					toolbar.SelectedStyle.CssClass = "pagetoolbarbuttonselected";
			
					//toolbar.Height = Unit.Pixel(46);
					toolbar.ItemSpacing = 2;	
					toolbar.ItemWidthDefault = Unit.Pixel(120);
					
					break;
			}
		}

		public override void ApplyCss(WebListBar listBar)
		{
			base.ApplyCss (listBar);
			listBar.DefaultItemSelectedStyle.CssClass = "listbardefault";
			listBar.DefaultItemStyle.CssClass = "listbarselected";
			listBar.DefaultItemHoverStyle.CssClass = "listbarhover";

			listBar.DefaultItemStyle.CustomRules = "float: left;";
			listBar.DefaultItemSelectedStyle.CustomRules = "float: left;";
			listBar.DefaultItemHoverStyle.CustomRules = "float: left;";

			listBar.DefaultItemStyle.BorderStyle = BorderStyle.None;
			listBar.DefaultItemSelectedStyle.BorderStyle = BorderStyle.None;
			listBar.DefaultItemHoverStyle.BorderStyle = BorderStyle.None;

		}

	
		public override NetsoftUSA.DataLayer.Language Language
		{
			get
			{
				if (lang == null)
				{
					string assemblyName = null, className = null;
					if (MainLanguageClassAttribute.GetMainLanguageClassFromType(this.GetType(), ref assemblyName, ref className))
					{
						Type t = Type.GetType(className + "," + assemblyName);
						string messagesKey = "Msgs-" + t.Name + "-EN";
						lang = NSGlobal.GetCachedObject(messagesKey) as NetsoftUSA.DataLayer.Language;
						if (lang == null)
						{
							lang = (NetsoftUSA.DataLayer.Language)Activator.CreateInstance(t, new object[] { "EN" });
							NSGlobal.CacheObject(messagesKey, lang);
						}

					}
					else	// no lang class for page
						lang = new NetsoftUSA.DataLayer.Language("EN");	// default language

					// IMPORTANT !! Creates a reference from Lang to UI, causing pages to be kept in memory.  This was the source
					// of memory leak issue in Release 11!
					//lang.MessageNotFoundEvent += new NetsoftUSA.DataLayer.Language.MessageNotFoundEventHandler(lang_MessageNotFoundEvent);

					if (lang.UntranslatedMessageIDs != null && lang.UntranslatedMessageIDs.Count > 0)
						this.untranslatedMessageIDs = lang.UntranslatedMessageIDs;
					else
						lang.UntranslatedMessageIDs = this.untranslatedMessageIDs;	// once set, this will collect all untranslated message ids.
				}
				
				return lang;
			}
		}

		/// <summary>
		/// Clears all the language classes from cache.  This forces them to be reloaded with
		/// the next attempt to access Language property.
		/// </summary>
		protected void ClearAllCachedLanguageClassInstances()
		{
			NSGlobal.ClearCache(typeof(NetsoftUSA.DataLayer.Language), true);
		}

		public virtual void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			RedirectBack();	// Redirect to the BackPage declared on the page class
		}

		/// <summary>
		/// This function is called whenever BasePage.Redirect is called.
		/// Override this in your module specific base page, to remove the current context.
		/// </summary>
		protected virtual void RemoveContext()
		{
		}

		public void RemovePatientContext()
		{
			this.CacheObject(typeof(Patient), null);
			this.CacheObject(typeof(PatientCoverage), null);
			this.CacheObject(typeof(Problem), null);
			this.CacheObject(typeof(BaseForEventCMSReferral), null);
			this.CacheObject(typeof(CMS), null);
			this.CacheObject(typeof(AssessmentContext), null);
			this.CacheObject("AssessmentContext", null);
			this.CacheObject("RecentlyPrintedItems", null);
			this.CacheObject("ActivityAndNoteContext", null);
			ClearEligibilityAddAnyway();
		}

		public virtual void RenderPageSummary(PageSummary pageSummary)
		{

		}

		public override void OnMainNavigationItemClick(string key)
		{
			this.ClearCache();
			base.OnMainNavigationItemClick (key);
		}


		public virtual void OnMainNavigationItemClick_MIntake()
		{
			IntakeForm.Redirect((IntakeLog)null, false);		// Redirect to intake page with a new intake.
		}

		public virtual void OnMainNavigationItemClick_MPlan()
		{
			PlanSearch.Redirect();
		}

		public virtual void OnMainNavigationItemClick_MLetters()
		{
			LetterSetMaintenance.Redirect();
		}

		public virtual void OnMainNavigationItemClick_MEligibility()
		{
			RemovePatientContext();
			EligibilityMainSearch.Redirect();
		}

		public virtual void OnMainNavigationItemClick_MMaintenance()
		{
			RemovePatientContext();
			Maintenance.Redirect();
		}

		public virtual void OnMainNavigationItemClick_MOrganizations()
		{	
			// 1 for Master Organizations
			OrganizationSearch.Redirect(1);
		}
		
		public virtual void OnMainNavigationItemClick_MPatient()
		{	
			RemovePatientContext();
			PatientSearch.Redirect();
		}	

		public virtual void OnMainNavigationItemClick_MActivities()
		{	
			this.RemoveContext();
			this.CacheObject(typeof(ActivitySearcher), null);
			RemovePatientContext();
			ActivitiesForm.RedirectWorklist();
		}	

		public virtual void OnMainNavigationItemClick_MProviderFacility()
		{
			NSGlobal.ClearCache(typeof(BaseDxPxCollection),true);
			NSGlobal.ClearCache(new string[] {"GuidelineMaintenance6","Guideline","Searcher","GuidelineForCode","GuidelinesForCode"});
			
			//NSGlobal.ClearCache("GuidelineMaintenance6");
			ProviderSearch.Redirect();
		}

		public virtual void OnMainNavigationItemClick_MGuidelines()
		{
			GuidelineForRef.Redirect();
		}
		public virtual void OnMainNavigationItemClick_MReports()
		{
			ReportMaintenance.Redirect();
		}
		public string CreateOrgPathHTML(string htmlTableID, ActiveAdvice.DataLayer.Organization org)
		{
			if (org == null)
				return null;

			StringBuilder sb = new StringBuilder();
			sb.Append("<table class=formpanelinside");
			if (htmlTableID == null)
				sb.Append(">");
			else
			{
				sb.Append(" ID=");
				sb.Append(htmlTableID);
				sb.Append(">");
			}

			ActiveAdvice.DataLayer.Organization[] orgs = org.GetParentOrganizations(true);

			for (int i = 0; i < orgs.Length; i++)
			{
				ActiveAdvice.DataLayer.Organization sorg = orgs[i];
				sb.Append("<tr>");
				sb.Append("<td class=SummaryFieldName>");
				sb.Append(sorg.OrganizationLevelDescription);
				sb.Append("</td>");
				sb.Append("<td class=SummaryFieldValue>");//<a href='#' onclick='");
				
				/*WindowOpener wo = new WindowOpener();
				wo.ID = "wo_Open" + sorg.OrganizationLevelCode;
				wo.NavigateURL = "OrganizationForm.aspx?WindowMode=NewWindow&OrganizationID=" + sorg.OrganizationID;
				wo.registerClientScripts(this);
				sb.Append(wo.getWindowOpenScript());
				sb.Append("'>");*/
				sb.Append(sorg.OrganizationID + "-" + sorg.Name);
				sb.Append("</td>");
				sb.Append("<td color=red>");
				if (sorg.IsTerminated)
					sb.Append( this.Language.Translate("(@TERMINATED@)") );
				sb.Append("</td>");
				sb.Append("</tr>");
			}
			sb.Append("</table>");
			return sb.ToString();
		}

		public void FillOrganizationPathInTable(ActiveAdvice.DataLayer.Organization org, Table tbl)
		{
			if (org == null)
				return;
			ActiveAdvice.DataLayer.Organization[] orgs = org.GetParentOrganizations(true);

			for (int i = 0; i < orgs.Length; i++)
			{
				Organization organization = orgs[i];
				WindowOpener wo = new WindowOpener();
				wo.ID = "wo_Open" + organization.OrganizationLevelCode;
				wo.NavigateURL = "OrganizationForm.aspx?WindowMode=NewWindow&OrganizationID=" + organization.OrganizationID;
				wo.registerClientScripts(this);

				FillNameValueInTable(organization.OrganizationLevelDescription,
					organization.OrganizationID + "-" + organization.Name, "javascript:" + wo.getWindowOpenScript(), tbl);
			}
		}

		/*
		 * wo = new WindowOpener();
					wo.ID = "CaseManagementHistory";
					wo.NavigateURL = "CaseManagementHistory.aspx";
					wo.registerClientScripts(this);
					WindowOpener woProblemLink = new WindowOpener();
					woProblemLink.ID = "ProblemLinkForm";
					woProblemLink.NavigateURL = "ProblemLinkForm.aspx";
					woProblemLink.registerClientScripts(this);
		 * */


		public void FillNameValueInTable(string label, string value, Table tbl)
		{
			FillNameValueInTable(label, value, null, tbl);
		}

		public void FillNameValueInTable(string label, string value, string url, Table tbl)
		{
			TableRow row = new TableRow();
			tbl.Rows.Add(row);
			TableCell cell = new TableCell();
			cell.CssClass = "SummaryFieldName";
			cell.Text = Language.Translate(label);
			row.Controls.Add(cell);
			cell = new TableCell();
			cell.CssClass = "SummaryFieldValue";
			if (url == null)
				cell.Text = Language.Translate(value);
			else
			{
				HyperLink hl = new HyperLink();
				hl.Text = Language.Translate(value);
				hl.NavigateUrl = url;
				cell.Controls.Add(hl);
			}
			row.Controls.Add(cell);
		}

		// FORK 1.0
		public void FillNameValueInTable(string label, string valueColumn1, string valueColumn2, string url, Table tbl)
		{
			TableRow row = new TableRow();
			tbl.Rows.Add(row);
			TableCell cell = new TableCell();
			cell.CssClass = "SummaryFieldName";
			cell.Text = Language.Translate(label);
			cell.Wrap = false;
			row.Controls.Add(cell);
			cell = new TableCell();
			cell.CssClass = "SummaryFieldValue";
			if (url == null)
			{
				cell.Text = Language.Translate(valueColumn1) 
					+ "&nbsp;&nbsp" +
					Language.Translate(valueColumn2);
			}
			else
			{
				HyperLink hl = new HyperLink();
				hl.Text = Language.Translate(valueColumn1);
				hl.NavigateUrl = url;
				Label lb = new Label();
				lb.Text = "&nbsp;&nbsp" + Language.Translate(valueColumn2);
				cell.Controls.Add(hl);
				cell.Controls.Add(lb);
			}
			row.Controls.Add(cell);
		}
		// END FORK 1.0

		public void FillFieldInTable(object obj, string property, Table tbl)
		{
			string label = FieldDescriptionAttribute.GetDescription(obj.GetType(), property, true);
			string value = ControlTypeAttribute.GetMemberValueAsString(obj, property);
			FillFieldInTable(label, value, tbl);
		}

		public void ClearProviderContext()
		{
			this.CacheObject("BasicInfo", null);
			this.CacheObject("AddressInfo", null);
			this.CacheObject("FocusInfo", null);
			this.CacheObject("ServiceInfo", null);
			this.CacheObject("LocationSearchResults", null);
		}

		/// <summary>
		/// IntakeForm, PatientForm and SubscriberForm pages use
		/// these functions to redirect after save.
		/// </summary>
		/// <param name="intakeLog"></param>
		/// <returns></returns>
		public bool IntakeCheckBeforeSaveAndRedirect(IntakeLog intakeLog)
		{
			/*switch (intakeLog.IntakeResolutionCode)
			{
				case IntakeResolution.ADDR:
				case IntakeResolution.ADDE:	// if event or referral is being added, problem must have been selected
				{
					if (intakeLog.Patient != null && !intakeLog.Patient.IsNew && intakeLog.Problem == null)
					{
						this.SetPageMessage("You must select a problem to add an event or referral", EnumPageMessageType.Error);
						return false;
					}
					break;
				}
					//case IntakeResolution.OTPS: // if go to patient summary selected, an existing patient must be alrea
			}*/
			return true;
		}

		/// <summary>
		/// IntakeForm, PatientForm and SubscriberForm pages use
		/// these functions to redirect after save.
		/// </summary>
		/// <param name="intakeLog"></param>
		/// <returns></returns>
		public bool IntakeRedirectByResolution(IntakeLog intakeLog)
		{
			if (intakeLog.Patient == null)
				return true;		// No patient, just stay in intake page.

			//PatientSummaryForm.Redirect(intakeLog.Patient); // Intake V10-8-23 mbk priority.doc requests that intake should only redirect to patient summary.

			//return true;

			
			if (intakeLog.IntakeResolutionAction == IntakeAction.ADDE ||
				intakeLog.IntakeResolutionAction == IntakeAction.ADDR)
			{
				// check if there's already a problem selected.
				// if not, create a new one.
				if (intakeLog.Problem == null)
				{
					ProblemForm.Redirect(intakeLog);
					return true;
				}
			}
			switch (intakeLog.IntakeResolutionAction)
			{
				case IntakeAction.ADDE:
				{
					Event evt = new Event(intakeLog.Patient, true);
					evt.StartDate = intakeLog.ServiceDate;
					evt.ServiceDate = intakeLog.ServiceDate;
					EventForm.Redirect(intakeLog.Patient, intakeLog.PatientCoverage, intakeLog.Problem, evt);
					break;
				}
				case IntakeAction.ADDR:
				{
					Referral referral = new Referral(true);
					referral.ReferralStartDate = intakeLog.ServiceDate;
					ReferralForm.Redirect(intakeLog.Patient, intakeLog.PatientCoverage, intakeLog.Problem, referral);
					break;
				}
				case IntakeAction.OTPS:
				{
					PatientSummaryForm.Redirect(intakeLog.Patient);
					break;
				}
				case IntakeAction.OTNA:
					return true;		// no action, just stay in intake.
				default:
					return false;		// unknown code.
			}
			return true;
			
		}

		/// <summary>
		/// Display DRG calculation log
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		//[System.Diagnostics.Conditional("DEBUG")]
		public void DumpDRGMessageLog(BaseForEventCMSReferral erc)
		{
			if (!CustomGrouper.DRGMessageLogDump)
				return;

			if (erc == null)
				return;
			if (erc.DRGMessageLog == null)
				return;

			this.SetPageMessage("DRG Calculation Log:", EnumPageMessageType.AddInfo);
			for (int i = 0; i < erc.DRGMessageLog.Count; i++)
			{
				this.SetPageMessage("   {0} - {1}", EnumPageMessageType.AddInfo, i, (string)erc.DRGMessageLog[i]);
			}
		}

		/// <summary>
		/// Display the coverage selection steps that were logged in the coverageSelectionContext object.
		/// This function is automatically discarded from release.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		//[System.Diagnostics.Conditional("DEBUG")]
		public void DumpCoverageSelectionContext(CoverageSelectionContext coverageSelectionContext)
		{
			if (!CoverageSelectionContext.CoverageLogDump)
				return;

			this.SetPageMessage(" Coverage selection steps performed:", EnumPageMessageType.AddInfo);
			for (int i = 0; i < coverageSelectionContext.MessageLog.Count; i++)
			{
				this.SetPageMessage("   {0} - {1}", EnumPageMessageType.AddInfo, i, (string)coverageSelectionContext.MessageLog[i]);
			}
		}

		/// <summary>
		/// Dumps both the autoactivity log and user notifications.
		/// </summary>
		/// <param name="autoActivityManager"></param>
		public void DumpAutoActivity(AutoActivityManager autoActivityManager)
		{
			DumpAutoActivityUserNotifications(autoActivityManager);	// discarded from release
			DumpAutoActivityLog(autoActivityManager);	// discarded from release
		}

		/// <summary>
		/// Dumps both the autoactivity log and user notifications
		/// and removes the autoactivity context if requested.
		/// </summary>
		/// <param name="data"></param>
		/// <param name="removeAutoActivityContext"></param>
		public void DumpAutoActivity(BaseData data, bool removeAutoActivityContext)
		{
			if (data == null)
				return;
			AutoActivityManager autoActivityManager = data.AutoActivityManager;
			if (autoActivityManager == null)
				return;
			DumpAutoActivityUserNotifications(autoActivityManager);	// discarded from release
			DumpAutoActivityLog(autoActivityManager);	// discarded from release
			if (removeAutoActivityContext)
				data.AutoActivityManager = null;
		}

		/// <summary>
		/// Dumps both the autoactivity log and user notifications
		/// and removes the autoactivity context if requested.
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="removeAutoActivityContext"></param>
		public void DumpAutoActivity(object obj, bool removeAutoActivityContext)
		{
			if (obj == null)
				return;
			AutoActivityManager autoActivityManager = ReflectionHelper.GetMemberValue(obj, "AutoActivityManager") as AutoActivityManager;
			if (autoActivityManager == null)
				return;
			DumpAutoActivityUserNotifications(autoActivityManager);	// discarded from release
			DumpAutoActivityLog(autoActivityManager);	// discarded from release
			if (removeAutoActivityContext)
				ReflectionHelper.SetMemberValue(obj, "AutoActivityManager", null);
		}

		/// <summary>
		/// Display the auto-activities created.
		/// This function is automatically discarded from release.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		//[System.Diagnostics.Conditional("DEBUG")]
		private void DumpAutoActivityLog(AutoActivityManager autoActivityManager)
		{
			if (!AutoActivityManager.AutoActivityLogDump)
				return;
			if (autoActivityManager == null)
				return;
			
			if (autoActivityManager.MessageLog.Count > 0)
			{
				this.SetPageMessage(" AutoActivities message log (to disable go to web.config and set AutoActivityLogDump to false)", EnumPageMessageType.AddInfo);
				for (int i = 0; i < autoActivityManager.MessageLog.Count; i++)
				{
					this.SetPageMessage("   {0} - {1}", EnumPageMessageType.AddInfo, i, (string)autoActivityManager.MessageLog[i]);
				}
			}

			// The autoactivity user notifications can't be disabled from viewing.
			// These are intended to be displayed to user whenever they exist.
			for (int i = 0; i < autoActivityManager.UserNotifications.Count; i++)
			{
				this.SetPageMessage((string)autoActivityManager.UserNotifications[i], EnumPageMessageType.AddInfo);
			}
		}

		/// <summary>
		/// Display the auto-activity user notification messages.
		/// This function displays messages even in the release mode.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		protected void DumpAutoActivityUserNotifications(AutoActivityManager autoActivityManager)
		{
			if (autoActivityManager == null)
				return;

			for (int i = 0; i < autoActivityManager.UserNotifications.Count; i++)
			{
				this.SetPageMessage((string)autoActivityManager.UserNotifications[i], EnumPageMessageType.AddInfo);
			}
		}

		/// <summary>
		/// Display the auto-activities created.
		/// This function is automatically discarded from release.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		//[System.Diagnostics.Conditional("DEBUG")]
		private void DumpAutoActivityLog(BaseData data, bool removeAutoActivityContext)
		{
			if (!AutoActivityManager.AutoActivityLogDump)
				return;
			if (data == null)
				return;
			AutoActivityManager autoActivityManager = data.AutoActivityManager;
			if (autoActivityManager == null)
				return;
			DumpAutoActivityLog(autoActivityManager);
			if (removeAutoActivityContext)
				data.AutoActivityManager = null;
		}

		/// <summary>
		/// Display the auto-activities created.
		/// This function is automatically discarded from release.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		//[System.Diagnostics.Conditional("DEBUG")]
		private void DumpAutoActivityLog(object obj, bool removeAutoActivityContext)
		{
			if (!AutoActivityManager.AutoActivityLogDump)
				return;
			if (obj == null)
				return;
			AutoActivityManager autoActivityManager = ReflectionHelper.GetMemberValue(obj, "AutoActivityManager") as AutoActivityManager;
			if (autoActivityManager == null)
				return;
			DumpAutoActivityLog(autoActivityManager);
			if (removeAutoActivityContext)
				ReflectionHelper.SetMemberValue(obj, "AutoActivityManager", null);
		}

		#region EligibilityAddAnyway
		/// <summary>
		/// Caches 'EligibilityAddAnyway' flag based on PlanID & SorgID
		/// Use EligibilityAddAnyway property to retrieve.
		/// </summary>
		/// <param name="planId"></param>
		/// <param name="sorgId"></param>
		/// <returns></returns>
		protected void CacheEligibilityAddAnyway(int planId, int sorgId)
		{
			if(planId < 1 && sorgId < 1)
				return;

			PlanSORG planSorg = new PlanSORG();				
			if(planSorg.LoadPlanSORGByIDs(sorgId, planId))
			{
				this.CacheObject("EligibilityAddAnyway", planSorg.EligibilityAddAnyway);
				this.CacheObject("CheckEligibility", planSorg.CheckEligibility);
			}
		}

		/// <summary>
		/// Gets value of [PlanSorg].ElibibilityAddAnyway from cache.
		/// When FALSE user cannot modify patient/eligibility information.
		/// Use base.EligibilityAddAnyway(intakeLog.PlanID, intakeLog.SORGId) to get value from DB. 
		/// </summary>
		protected bool EligibilityAddAnyway
		{
			get 
			{ 
				object result;
				result = this.LoadObject("EligibilityAddAnyway");
				if(result == null)
					return true; // default (normal) state for UI controls
				else
					return (bool)result;
			}
		}

		/// <summary>
		/// Gets value of [PlanSorg].CheckEligibility from cache.
		/// When FALSE user cannot modify patient/eligibility information.
		/// Use base.EligibilityAddAnyway(intakeLog.PlanID, intakeLog.SORGId) to get value from DB. 
		/// </summary>
		protected bool CheckEligibility
		{
			get 
			{ 
				object result;
				result = this.LoadObject("CheckEligibility");
				if(result == null)
					return true; // default (normal) state for UI controls
				else
					return (bool)result;
			}
		}

		protected void ClearEligibilityAddAnyway()
		{
			this.CacheObject("EligibilityAddAnyway", null);
			this.CacheObject("CheckEligibility", null);
		}
		#endregion


		public override void WriteFieldLabelExtraInfo(OBFieldLabel label, object sourceObject, string sourceMemberName, HtmlTextWriter writer)
		{
			base.WriteFieldLabelExtraInfo(label, sourceObject, sourceMemberName, writer);
	
			if (this.PageType == EnumPageType.DataEntryPage)
			{
				BaseData obj = sourceObject as BaseData;
				if (obj != null)
				{
					if (obj.PKFields != null && sourceMemberName != null && obj.PKFields.Length > 0 && sourceMemberName.ToUpper().Equals(obj.PKFields[0].ToUpper())) // could there be exceptions?
					{
						UserInfoControl ctrl = (UserInfoControl)this.LoadControl(@"~/UserControls/UserInfoControl.ascx");
						ctrl.BindObject(sourceObject);
						ctrl.RenderControl(writer);
					}
				}
			}
		}

		/*private void lang_MessageNotFoundEvent(object sender, NetsoftUSA.DataLayer.Language.LanguageEventArgs e)
		{
			untranslatedMessageIDs[e.MessageID] = e.MessageID;		// we make sure the message id is put only once.
		}*/

		/// <summary>
		/// 
		/// </summary>
		public Hashtable UntranslatedMessageIDs
		{
			get { return this.untranslatedMessageIDs; }
		}

		/// <summary>
		/// Returns object from collection represented by startRowIndex of passed grid
		/// If row is hidden as a result of filtering collection or Marking item for deletion, item from previous row will be returned.
		/// 
		/// </summary>
		/// <param name="grid"></param>
		/// <param name="col"></param>
		/// <param name="startRowIndex">Starting position in the grid. Usually 0 on initial load.</param>
		/// <param name="initNewObject">Determines if new object or null will be returned when there is nothing to return</param>
		/// <returns></returns>
		public BaseDataClass SetSelectedGridItem(WebGrid grid, BaseDataCollectionClass col, int startRowIndex, bool initNewObject)
		{
			if(startRowIndex < 0)
			{
				grid.SelectedRowIndex = -1;
				if(initNewObject)
					return col.NewRecord(true);
				else
					return null;
			}
			else if(startRowIndex == 0)
			{
				int colIndex = grid.GetColIndexFromNextVisibleRow(startRowIndex);
				if(colIndex == -1)
					return SetSelectedGridItem(grid, col, -1, initNewObject);
				else
				{
					grid.SelectedRowIndex = 0;
					return col.GetAt(colIndex);
				}
			}

			else if(grid.Rows.Count > startRowIndex && !grid.Rows[startRowIndex].Hidden)
			{
				grid.SelectedRowIndex = startRowIndex;
				return col.GetAt(grid.GetColIndexFromNextVisibleRow(startRowIndex));
			}
			else
				return SetSelectedGridItem(grid, col, --startRowIndex, initNewObject);
		}

		public void ClearCache()
		{
			for (int i = Session.Count - 1; i >= 0; i--)
			{
				string key = Session.Keys[i];
				object o = Session[i];
				if (key != "LoginName" && key != "__CurrentlyLoggedInUser__")
					if (o is NetsoftUSA.DataLayer.BaseDataClass || o is NetsoftUSA.DataLayer.BaseDataCollectionClass || o is AssessmentContext || o is Triplet)
						Session.Remove(key);
			}
		}

		/// <summary>
		/// True if this page was called after hitting a "Cancel" button.
		/// </summary>
		public bool WasCancelled
		{
			get { return this.wasCancelled; }
			set { this.wasCancelled = value; }
		}

		public void PushCancelled()
		{
			BasePage.PushParam("WasCancelled", true);
		}

	
		/// <summary>
		/// FORK 1.1 
		/// </summary>
		#region Async web request call to all active servers

		private delegate string AsyncDelegate(ref string strIPAddress, ref string codeKey);

		public void ClearOtherServersCache(string strCodeKey, bool bWithCurrent)
		{
			ArrayList al = CodeHelper.GetActiveServersIPAddress(bWithCurrent);

			
			foreach(string ipAddress in al)
			{						
				//validate IPAddress
				//...
				MakeAsyncCall(ipAddress,  strCodeKey);
			
			}//end foreach
		}

		private void MakeAsyncCall(string strIPAddress, string strCodeKey)
		{
			AsyncDelegate ad = new AsyncDelegate(SendWebRequest);

			IAsyncResult iar = ad.BeginInvoke(ref strIPAddress, ref strCodeKey,
				new AsyncCallback(EndSendWebRequest), ad);
		}

		private void EndSendWebRequest(IAsyncResult iar)
		{
			string result;
			string IPAddress = "";
			string strCode = "";

			try
			{
				AsyncDelegate ad = (AsyncDelegate)iar.AsyncState;

				result = ad.EndInvoke(ref IPAddress, ref strCode, iar);

				//Response should return CodeKey if success
				int iFind = result.IndexOf(strCode);
				if(iFind == 0)
				{
					//OK
					// test only
					//					CodeHelper.InsertCacheUpdateLog(DateTime.Now,
					//						IPAddress, strCode, "OK");
				}
				else
				{
					CodeHelper.WriteEventLog(result);
					CodeHelper.InsertCacheUpdateLog(DateTime.Now,
						IPAddress, strCode, result);
				}
			}
			catch(Exception ex)
			{
				string errMsg = String.Format("An error occurred while getting clear cache response from server {0}. Error Details: {1}",
					IPAddress , ex.Message);
				EventLog.WriteEntry("Application", errMsg, EventLogEntryType.Error);
			}
			
		}

		public HttpWebRequest CreateWebRequest(string uri, 
			NameValueCollection collHeader, string RequestMethod, bool NwCred)
		{
			HttpWebRequest webrequest = 
				(HttpWebRequest) WebRequest.Create(uri);
			webrequest.KeepAlive = false;
			webrequest.Method = RequestMethod;
 
			int iCount = collHeader.Count;
			string key;
			string keyvalue;
 
			for (int i=0; i < iCount; i++)
			{
				key = collHeader.Keys[i];
				keyvalue = collHeader[i];
				webrequest.Headers.Add(key, keyvalue);
			}
                  
			webrequest.ContentType = "application/x-www-form-urlencoded";
			//"text/html"; 
			//"application/x-www-form-urlencoded";
 
			//			if (ProxyServer.Length > 0)
			//			{
			//				webrequest.Proxy = new 
			//					WebProxy(ProxyServer,ProxyPort);
			//			}

			webrequest.AllowAutoRedirect = false;
 
			//			if (NwCred)
			//			{
			//				CredentialCache wrCache = 
			//					new CredentialCache();
			//				wrCache.Add(new Uri(uri),SECURITY_TYPE,
			//					new NetworkCredential(UserName,UserPwd));
			//				webrequest.Credentials = wrCache;
			//			}

			//Remove collection elements
			collHeader.Clear();
			return webrequest;
		}//End of secure CreateWebRequest
            

		/// <summary>
		/// send request for every active server
		/// returns true for success
		/// </summary>
		/// <param name="strIPAddress"></param>
		/// <param name="codeTable"></param>
		/// <returns></returns>
		public string SendWebRequest( ref string strIPAddress, ref string codeTable)
		{
			string err = "";
			string url = "";
			string strVirtualDirectory = "";
			HttpWebRequest webRequest= null;
			HttpWebResponse webResponse = null;

			try
			{
				strVirtualDirectory = this.Page.Server.MapPath(@"~");
				strVirtualDirectory = strVirtualDirectory.Substring(strVirtualDirectory.LastIndexOf(@"\")+1);			
							
				url = String.Format("http://{0}/{1}/{2}?{3}={4}", strIPAddress, strVirtualDirectory, CodeHelper.CALLING_PAGE, CodeHelper.KEY, codeTable);
			
				NameValueCollection collHeader = new NameValueCollection();
				webRequest = CreateWebRequest(url, collHeader, CodeHelper.METHOD, false);
				webResponse=(HttpWebResponse)webRequest.GetResponse();  
			}
			catch(Exception ex)
			{
				string temp = ex.Message;
				string temp2 = ex.ToString();
				err = String.Format("An error occurred while sending clear cache request {0}. Error Details: {1}",
					url, temp);				
				
				return err;
			}
			
			if(webResponse == null) 
			{				
				err = String.Format("An error occurred while sending clear cache request {0}. Error Details: {1}",
					url, " webResponse is null.");
				
				return err;
			}			

			int iStatusCode = (int)webResponse.StatusCode;

			if(iStatusCode != 200)
			{
				err = String.Format("An error occurred while sending clear cache request {0} : Status Code={1}.", url, iStatusCode.ToString());
												
				return err;
			}

			Encoding enc = Encoding.GetEncoding(1252);

			if(webResponse.ContentEncoding.Length > 0)
				enc = Encoding.GetEncoding(webResponse.ContentEncoding);

			StreamReader sr = new StreamReader(webResponse.GetResponseStream(), enc);
			string result = sr.ReadToEnd();

			//check if key sent back
			if(result.IndexOf(codeTable) != 0) 
			{
				err = String.Format("An error occurred while sending clear cache request {0}. Error Details: Response does not return key {1}", 
					url, codeTable);
				
				return err;
			}
			return result;

		}

		//test portion
		
		public void ClearOtherServersCacheTest(string strCodeKey, bool bWithCurrent)
		{
			ArrayList al = CodeHelper.GetActiveServersIPAddress(bWithCurrent);

			string temp = "";
			
			foreach(string ipAddress in al)
			{		
				temp += ipAddress + ", ";
				//validate IPAddress
				//...
				MakeAsyncCall(ipAddress ,  strCodeKey);
				//break;	//call just one with error
			
			}//end foreach

			//VS test only
			CodeHelper.InsertCacheUpdateLog(DateTime.Now, "Summary",  strCodeKey, temp);
		}



		#endregion Async call
		

	}

}
