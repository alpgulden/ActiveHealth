using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// All pages under provider should derive from this base class.
	/// </summary>
	[Designer("Microsoft.VSDesigner.WebForms.WebFormDesigner,Microsoft.VSDesigner")]
	[BackPage(typeof(ProviderSearch))]
	public class ProviderBasePage : BasePage
	{
		public ProviderBasePage() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private DataLayer.Provider Provider
		{
			get { return (Provider)this.LoadObject("providerObj"); }
		}

		private DataLayer.GroupPractice GroupPractice
		{
			get { return (GroupPractice)this.LoadObject("groupPracticeObj"); }
		}

		private DataLayer.Facility Facility
		{
			get { return (Facility)this.LoadObject("facilityObj"); }
		}
		
		private DataLayer.Network Network
		{
			get { return (Network)this.LoadObject("networkObj"); }
		}


		protected override void RemoveContext()
		{
			this.CacheObject(typeof(Provider), null);
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			Provider provider = this.Provider;
			if (!this.HasCallbackFunction)
			{
				listbar.AddItem("@PROVIDER@", "Providers");
				listbar.AddItem("@FACILITY@", "Facilities");
				listbar.AddItem("@GROUPPRACTICE@", "GroupPractices");
				listbar.AddItem("@NETWORKS@", "Networks");
				listbar.AddItem("@DETAILS@", "Details");
			}

		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);

			Provider provider = this.Provider;
			GroupPractice gp = this.GroupPractice;
			Facility facility = this.Facility;
			Network network = this.Network;
			 	
			this.SetPageSubMenuItemEnabled("Details", provider != null || gp != null || facility != null || network != null);
			
			//this.SetPageSubMenuItemEnabled("Details", gp != null);

		}

		public override void OnSubNavigationItemClick(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			if (item.Key != "Details")
				RemoveContext();

			base.OnSubNavigationItemClick (listbar, item);
		}

		public void OnSubNavigationItemClick_Providers(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ProviderSearch.aspx");
		}
		
		public void OnSubNavigationItemClick_Details(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			Provider provider = this.Provider;
			GroupPractice gp = this.GroupPractice;
			Facility facility = this.Facility;
			Network network = this.Network;

			if (provider !=null)
			{
				ProviderForm.Redirect(this.Provider);
			}
			else if (gp !=null)
			{
				GroupPracticeForm.Redirect(this.GroupPractice);
			}
			else if (facility !=null)
			{
				FacilityForm.Redirect(this.Facility);
			}
			else if (network !=null)
			{
				NetworkForm.Redirect(this.Network);
			}
		}

		public void OnSubNavigationItemClick_Facilities(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("FacilitySearch.aspx");
		}

		public void OnSubNavigationItemClick_GroupPractices(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("GroupPracticeSearch.aspx");
		}
		
		public void OnSubNavigationItemClick_Networks(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("NetworkSearch.aspx");
		}
	}
}
