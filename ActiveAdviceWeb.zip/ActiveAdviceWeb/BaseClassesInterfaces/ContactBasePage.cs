using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for ContactBasePage.
	/// </summary>
	[Designer("Microsoft.VSDesigner.WebForms.WebFormDesigner,Microsoft.VSDesigner")]
	[BackPage(typeof(ContactSearch))]
	public class ContactBasePage : BasePage
	{
		public ContactBasePage() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private Contact Contact
		{
			get { return (Contact)this.LoadObject(typeof(Contact), false); }
		}

		private DataLayer.Provider Provider
		{
			get { return (Provider)this.LoadObject("providerObj"); }
		}

		private DataLayer.GroupPractice GroupPractice
		{
			get { return (GroupPractice)this.LoadObject("groupPracticeObj"); }
		}
		private DataLayer.Facility Facility 
		{
			get { return (Facility)this.LoadObject("facilityObj"); }
		}

		private DataLayer.Patient Patient 
		{
			get { return (Patient)this.LoadObject("facilityObj"); }
		}

		private IContactOwner ContactOwner
		{
			get { return (IContactOwner)this.LoadObject("IContactOwner", typeof(IContactOwner), false); }
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			Contact contact = this.Contact;

			listbar.AddItem("@SEARCH@", "Search");
			listbar.AddItem("@DETAILS@", "Details").Visible = contact != null;

		}

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			toolbar.AddButton(BaseMessages.MessageIDs.BACK, "Back");
			// Menu items to be displayed on all tabs
		}

		public void OnSubNavigationItemClick_Search(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ContactSearch.aspx");
		}

		public void OnSubNavigationItemClick_Details(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			Contact contact = this.Contact;
			if (contact != null)
				ContactForm.Redirect(this.ContactOwner, this.Contact);
		}

		public void OnToolbarButtonClick_Back(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			GoBack();
		}

		public void GoBack()
		{
			IContactOwner contactOwner = this.ContactOwner;

			if (contactOwner is Organization)
			{
				OrganizationForm.Redirect(contactOwner as Organization);
			}
			else if (contactOwner is Plan)
			{
				PlanForm.Redirect(contactOwner as Plan);
			}
			else if (contactOwner is FacilityLocation)
			{// this has to be changed to FacilityLocationform once that page is created.
				FacilityLocationForm.Redirect(this.Facility);
				//this.SetPageMessage("Facility location redirect not implemented", EnumPageMessageType.Warning);
			}
			else if (contactOwner is ProviderLocation)
			{
				LocationForm.Redirect(this.Provider);
				//this.SetPageMessage("Provider location redirect not implemented", EnumPageMessageType.Warning);
			}
			else if (contactOwner is GroupPracticeLocation)
			{
				GroupPracticeLocationForm.Redirect(this.GroupPractice);
				//GroupPracticeForm.Redirect(contactOwner as GroupPractice);
				//this.SetPageMessage("Provider location redirect not implemented", EnumPageMessageType.Warning);
			}
			else if (contactOwner is Patient)
			{
				PatientForm.Redirect(contactOwner as Patient);
			}
			else if(contactOwner is Network)
			{
				NetworkForm.Redirect(contactOwner as Network);
			}
			else
			{	
				this.SetPageMessage("Unknown context to redirect to: " + contactOwner.GetType(), EnumPageMessageType.Warning);
			}
		}

		public void SetSelectedMainMenuItem()
		{
			IContactOwner contactOwner = this.ContactOwner;
			if (contactOwner is Organization)
			{
				SelectedMainMenuItem = "MOrganizations";
			}
			else if (contactOwner is Plan)
			{
				SelectedMainMenuItem = "MPlan";
			}
			else if (contactOwner is FacilityLocation)
			{
				SelectedMainMenuItem = "MProviderFacility";
			}
			else if (contactOwner is ProviderLocation)
			{
				
				SelectedMainMenuItem = "MProviderFacility";
			}
			else if (contactOwner is GroupPracticeLocation)
			{
				SelectedMainMenuItem = "MProviderFacility";
			}
			else if (contactOwner is Patient)
			{
				this.SelectedMainMenuItem = "MPatient";
			}
			else if (contactOwner is Network)
			{
				SelectedMainMenuItem = "MProviderFacility";
			}
		}
	}
}
