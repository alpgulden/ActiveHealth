using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;
using System.Collections.Specialized;
using System.Collections;
using System.Net;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// All pages under Plans should derive from this base class.
	/// </summary>
	[Designer("Microsoft.VSDesigner.WebForms.WebFormDesigner,Microsoft.VSDesigner")]
	public class CodeBasePage : BasePage
	{
		public CodeBasePage() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		
		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			listbar.AddItem("@ORGANIZATION@", "grpOrganization");
			listbar.AddItem("@PLAN@", "grpPlan");
			listbar.AddItem("@INTAKE@", "grpIntake");
			listbar.AddItem("@PATIENT@", "grpPatient");
			listbar.AddItem("@PROVIDER@", "grpProvider");
			listbar.AddItem("@SYSTEM@", "grpSystem");
			listbar.AddItem("@RDPARTY@", "grp3rdParty");
			listbar.AddItem("@ACTIVITIES@", "grpActivity");
			listbar.AddItem("@CLINICALREVIEW@", "grpClinicalReview");
			listbar.AddItem("@CLINICALMANAGEMENTSERVICE@", "grpClinicalMS");
			listbar.AddItem("@CAREMANAGEMENT@", "grpCareManagement");
			//listbar.AddItem("@DISEASEMANAGEMENT@", "grpDiseaseManagement");
			//listbar.AddItem("@MATERNICHECK@", "grpMaternicheck");
			listbar.AddItem("@MEDICATION@", "grpMedications");
			listbar.AddItem("@WORKERSCOMPENSATION@", "grpWorkersCompensation");
			listbar.AddItem("@CMSDMEQUIPMENT@", "grpCMSDMEquipment");
			listbar.AddItem("@ERCOUTCOME@", "grpERCOutcome");
			listbar.AddItem("@PHYSICIANREVIEW@", "grpPhysicianReview");
			listbar.AddItem("@PROBLEMEVENTREFERRAL@", "grpProblemER");
			listbar.AddItem("@LETTERS@", "grpLetters");
			listbar.AddItem("@REPORTCRITERIA@", "grpReportCriteria");
			listbar.AddItem("@ADDITIONALS@", "grpAdditional");		
			listbar.AddItem("@LANGUAGE@","language");
		}


		public void OnSubNavigationItemClick_grpOrganization(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("ORGANIZATION");
		}

		public void OnSubNavigationItemClick_grpPlan(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("PLAN");
		}

		public void OnSubNavigationItemClick_language(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeTypeFormForCodeWithNote.Redirect("Language",this.Language.TranslateSingle("LANGUAGE"));
		}

		public void OnSubNavigationItemClick_grpIntake(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("INTAKE");
		}

		public void OnSubNavigationItemClick_grpPatient(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("PATIENT");
		}

		public void OnSubNavigationItemClick_grpProvider(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("PROVIDER");
		}

		public void OnSubNavigationItemClick_grpSystem (WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("SYSTEM");
		}

		public void OnSubNavigationItemClick_grp3rdParty(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("RDPARTY");
		}

		public void OnSubNavigationItemClick_grpActivity(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("ACTIVITIES");
		}

		public void OnSubNavigationItemClick_grpClinicalReview(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("CLINICALREVIEW");
		}

		public void OnSubNavigationItemClick_grpClinicalMS(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("CLINICALMANAGEMENTSERVICE");
		}

		public void OnSubNavigationItemClick_grpCareManagement(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("CAREMANAGEMENT");
		}

//		public void OnSubNavigationItemClick_grpDiseaseManagement(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
//		{
//			CodeMaintenance.Redirect("DISEASEMANAGEMENT");
//		}

//		public void OnSubNavigationItemClick_grpMaternicheck(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
//		{
//			CodeMaintenance.Redirect("MATERNICHECK");
//		}

		public void OnSubNavigationItemClick_grpMedications(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("MEDICATION");
		}

		public void OnSubNavigationItemClick_grpWorkersCompensation(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("WORKERSCOMPENSATION");
		}

		public void OnSubNavigationItemClick_grpCMSDMEquipment(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("CMSDMEQUIPMENT");
		}

		public void OnSubNavigationItemClick_grpERCOutcome(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("ERCOUTCOME");
		}

		public void OnSubNavigationItemClick_grpPhysicianReview(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("PHYSICIANREVIEW");
		}

		public void OnSubNavigationItemClick_grpProblemER(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("PROBLEMEVENTREFERRAL");
		}

		public void OnSubNavigationItemClick_grpLetters(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("LETTERS");
		}

		public void OnSubNavigationItemClick_grpReportCriteria(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("REPORTCRITERIA");
		}

		public void OnSubNavigationItemClick_grpAdditional(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			CodeMaintenance.Redirect("ADDITIONALS");
		}
		
	}
}
