using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	public enum EnumSelectValidCoverageResult
	{
		NoCoverageFound = 0,
		CoverageValid = 1,					// the existing coverage is valid or a valid one was found in the log
		SingleCoverageAutoSelected = 2,
		UserMustSelectFromMultiple = 3
	}

	/// <summary>
	/// All pages under Plans should derive from this base class.
	/// </summary>
	[Designer("Microsoft.VSDesigner.WebForms.WebFormDesigner,Microsoft.VSDesigner")]
	[BackPage(typeof(PatientSearch))]
	[PageTitle("@PATIENTPAGETITLE@")]
	public class PatientBasePage : BasePage
	{
		protected bool letterContextRequestIDRequired;
		protected bool letterContextDecisionIDRequired;

		private ListbarButtonExtraProperties lbiDetails;

		protected bool DoNotCheckIsDirtWhenInPatientContext = false; 

		public PatientBasePage() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// The patient that's currently in the working context
		/// </summary>
		private Patient Patient
		{
			get { return (Patient)this.LoadObject(typeof(Patient), false); }
		}

		/// <summary>
		/// Easy access to translated patient messages.
		/// </summary>
		public PatientMessages PatientMessages
		{
			get { return (PatientMessages)this.Language; }
		}

		/// <summary>
		/// Selected coverage of the patient (selected in the summary page)
		/// </summary>
		private PatientCoverage PatientCoverage
		{
			get { return (PatientCoverage)this.LoadObject(typeof(PatientCoverage), false); }
		}

		/// <summary>
		/// Selected problem of the patient (selected in the summary page)
		/// </summary>
		private Problem Problem
		{
			get { return (Problem)this.LoadObject(typeof(Problem), false); }
		}

		/// <summary>
		/// Selected Event/Referral/CMS of the patient (selected in the summary page)
		/// </summary>
		private BaseForEventCMSReferral ERC
		{
			get { return (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral), false); }
		}


		private AssessmentContext AssessmentContext
		{
			get { return (AssessmentContext)this.LoadObject(typeof(AssessmentContext), false); }
		}


		/// <summary>
		/// Selected Event of the patient (selected in the summary page)
		/// </summary>
		private Event Event
		{
			get { return this.ERC as Event; }
		}

		/// <summary>
		/// Selected Referral of the patient (selected in the summary page)
		/// </summary>
		private Referral Referral
		{
			get { return this.ERC as Referral; }
		}

		/// <summary>
		/// Selected CMS of the patient (selected in the summary page)
		/// </summary>
		private CMS CMS
		{
			get { return this.ERC as CMS; }
		}

		protected override void RemoveContext()
		{
			RemovePatientContext();
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
		}

		/// <summary>
		/// We call this in the event shared sub-tab pages.
		/// </summary>
		public void AddClinicalSummaryButton(WebToolbar toolbar)
		{
			if (this.ERC is Event)
			{
				// Add summary button
				WindowOpener woSummary = new WindowOpener();
				
				woSummary.ID = "tbClinicalSummaryWindowOpener";
				woSummary.NavigateURL = "ClinicalReviewSummary.aspx?WindowMode=NewWindow";
				woSummary.registerClientScripts(this.Page);

				toolbar.AddButton("@SUMMARY@", "ClinicalSummary").Item.TargetURL = "javascript:" + woSummary.getWindowOpenScript();
			}
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);
			//Patient patient = this.Patient;

			listbar.AddItem("@SEARCH@", "Search", true);
			lbiDetails = listbar.AddItem("@DETAILS@", "Details", !this.DoNotCheckIsDirtWhenInPatientContext);		// will set dirty check flag
			listbar.AddItem("@SUMMARY@", "Summary", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem("@CONTACTS@", "Contacts", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem("@MEDICATIONS@", "Medications", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem("@ALLERGIES@", "Allergies", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem("@MEASUREMENTSMENUITEM@", "Measurements", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem("@ACTIVITIES@", "Activities", !this.DoNotCheckIsDirtWhenInPatientContext);	
			listbar.AddItem("@NOTES@", "Notes", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem("@IMAGES@", "Images", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem("@GUIDELINES@","Guidelines", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem(Messages.LetterMessages.MessageIDs.LETTERQUEUE, "LetterQueue", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem(Messages.LetterMessages.MessageIDs.LETTERDUPLEXQUEUE, "DuplexLetterQueue", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem(Messages.LetterMessages.MessageIDs.LETTERENVELOPEQUEUE, "EnvelopeLetterQueue", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem("@CUSTOMLETTER@", "CustomLetter", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem("@RETURNTO@" + " " + "@ERCTYPE@", "ReturnToERC", !this.DoNotCheckIsDirtWhenInPatientContext);
			listbar.AddItem("@RETURNTO@" + " " + Messages.AssessmentMessages.MessageIDs.ASSESSMENT, "ReturnToAss", !this.DoNotCheckIsDirtWhenInPatientContext);
		}

		protected override void OnPreRender(EventArgs e)
		{
			Patient patient = this.Patient;

			if (lbiDetails != null)
				lbiDetails.ChecksForIsDirty = patient != null && patient.IsNew;		// if the patient is newly entered, neither it nor the coverage records weren't saved yet.
			if (this.ERC is CMS)
				(this.ERC as CMS).DisplayDetailedInfo = false;  //All pages except CMS display different info in the summary

			base.OnPreRender (e);

			//bool notNewPatient = (patient != null && !patient.IsNew ? true : false);
			bool notNewPatient = (patient != null && !patient.IsNew);
			
			this.SetPageSubMenuItemEnabled("Contacts", notNewPatient && AASecurityHelper.HasFullAccessRole(AASecurityHelper.CONTACTS));

			this.SetPageSubMenuItemEnabled("Details", patient != null && AASecurityHelper.HasFullAccessRole(AASecurityHelper.PATIENT_INFORMATION));

			this.SetPageSubMenuItemEnabled("Summary", notNewPatient && AASecurityHelper.HasFullAccessRole(AASecurityHelper.PATIENT_SUMMARY));
			
			this.SetPageSubMenuItemVisible("Medications", notNewPatient && AASecurityHelper.HasFullAccessRole(AASecurityHelper.MEDICATIONS));

			this.SetPageSubMenuItemVisible("Allergies", notNewPatient && AASecurityHelper.HasFullAccessRole(AASecurityHelper.ALLERGIES));

			this.SetPageSubMenuItemVisible("Measurements", notNewPatient && AASecurityHelper.HasFullAccessRole(AASecurityHelper.MEASUREMENTS));

			this.SetPageSubMenuItemEnabled("Activities", notNewPatient && this.PatientCoverage != null && AASecurityHelper.HasFullAccessRole(AASecurityHelper.ACTIVITIES));

			if (!(this is LetterQueueMaintenance || this is LetterForm))
			{
				this.SetPageSubMenuItemVisible("LetterQueue", notNewPatient && AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_DRAFT_QUEUE));
				this.SetPageSubMenuItemVisible("DuplexLetterQueue", notNewPatient && AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_DRAFT_QUEUE));
				this.SetPageSubMenuItemVisible("EnvelopeLetterQueue", notNewPatient && AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_DRAFT_QUEUE));
			}
			else 
			{ 
				this.SetPageSubMenuItemVisible("LetterQueue", AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_DRAFT_QUEUE));
				this.SetPageSubMenuItemVisible("DuplexLetterQueue", AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_DRAFT_QUEUE));
				this.SetPageSubMenuItemVisible("EnvelopeLetterQueue", AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_DRAFT_QUEUE));
			}

			this.SetPageSubMenuItemVisible("Images", notNewPatient);

			this.SetPageSubMenuItemVisible("Notes", notNewPatient && AASecurityHelper.HasFullAccessRole(AASecurityHelper.NOTES));

			this.SetPageSubMenuItemEnabled("Guidelines", notNewPatient && AASecurityHelper.HasFullAccessRole(AASecurityHelper.GUIDELINES));

			this.SetPageSubMenuItemVisible("CustomLetter", notNewPatient && (this.ERC != null && !this.ERC.IsNew) && AASecurityHelper.HasFullAccessRole(AASecurityHelper.AD_HOC_LETTERS));

			this.SetPageSubMenuItemVisible("ReturnToERC", notNewPatient && this.ERC != null 
				&& AASecurityHelper.HasFullAccessRole(AASecurityHelper.ERCLINK));


		//		&& AASecurityHelper.HasFullAccessRole(AASecurityHelper.CARE_MANAGEMENT)
		//		&& AASecurityHelper.HasFullAccessRole(AASecurityHelper.REFERRALS)
		//		&& AASecurityHelper.HasFullAccessRole(AASecurityHelper.EVENTS));

			this.SetPageSubMenuItemVisible("ReturnToAss", AssmtVisibility);


			if (this.Patient != null)
			{
				string title = ""; 
				if (!this.Patient.IsNew)
					title = String.Format("{0} - {1}", this.Patient.Fmt_FullName, this.Patient.PatientId);
				else
					title = "@NEW@ @PATIENT@";
				if (this.PageTitle == null) 
					this.PageTitle = title; 
				else
					this.PageTitle = String.Format("{0} : {1}", title, this.PageTitle); 
			}
		}

		public override void OnSubNavigationItemClick(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			// A bad way to implement context-sensitivity.
			// Change this.
			if (
				item.Key != "ClearCache" && item.Key != "DisplayMessageIDs" && item.Key != "GC" && 
				item.Key != "Details" && item.Key != "Summary" && item.Key != "Contacts"
				&& item.Key != "Medications" && item.Key != "Allergies" && item.Key != "Activities"
				&& item.Key != "Measurements" && item.Key != "LetterQueue" && item.Key != "DuplexLetterQueue" && item.Key != "EnvelopeLetterQueue" && item.Key != "CustomLetter" 
				&& item.Key != "Images" && item.Key != "Guidelines" && item.Key != "Notes"
				&& item.Key != "ReturnToERC" && item.Key != "ReturnToAss")
				RemovePatientContext();

			base.OnSubNavigationItemClick (listbar, item);
		}

		public void OnSubNavigationItemClick_Search(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			PatientSearch.Redirect();
		}

		public void OnSubNavigationItemClick_Details(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			PatientForm.Redirect(this.Patient);
		}

		public void OnSubNavigationItemClick_Summary(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			PatientSummaryForm.Redirect(this.Patient);
		}

		public void OnSubNavigationItemClick_Contacts(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ContactSearch.Redirect(this.Patient);
		}

		public void OnSubNavigationItemClick_Medications(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			MedicationSummaryForm.Redirect(this.Patient);
		}

		public void OnSubNavigationItemClick_Allergies(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			AllergySummaryForm.Redirect(this.Patient);	
		}

		public void OnSubNavigationItemClick_Activities(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ActivitiesForm.Redirect(EnumActivityContext.Activity, EnumActivityAndNoteContext.Patient);
		}

		public void OnSubNavigationItemClick_Guidelines(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.PushCurrentCallingPage();
			GuidelineSelection.Redirect( this.Patient, this.ERC);
		}

		public void OnSubNavigationItemClick_Measurements(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			MeasurementSummaryForm.Redirect(this.Patient);
		}

		public void OnSubNavigationItemClick_LetterQueue(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			LetterQueueMaintenance.Redirect(this.Patient, this.ERC, false, false);
		}

		public void OnSubNavigationItemClick_DuplexLetterQueue(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			LetterQueueMaintenance.Redirect(this.Patient, this.ERC, true, false);
		}

		public void OnSubNavigationItemClick_EnvelopeLetterQueue(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			LetterQueueMaintenance.Redirect(this.Patient, this.ERC, false, true);
		}

		public void OnSubNavigationItemClick_CustomLetter(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			LetterSearch.Redirect(this.Patient, this.ERC);
		}

		public void OnSubNavigationItemClick_Images(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{		
			ImageSearch.Redirect(this.Patient,this.PatientCoverage , this.Problem, this.ERC, null,EnumActivityAndNoteContext.Patient);
		}

		public void OnSubNavigationItemClick_Notes(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			if(this.ERC != null)
				NoteSearch.Redirect(EnumActivityAndNoteContext.ERC);
			if(this.Problem != null)
				NoteSearch.Redirect(EnumActivityAndNoteContext.Problem);
			else
				NoteSearch.Redirect(EnumActivityAndNoteContext.Patient);
		}

		public void OnSubNavigationItemClick_ReturnToERC(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			if(this.ERC is Event)
				RedirectToEvent();
			else if(this.ERC is Referral)
				RedirectToReferrer();
			else if(this.ERC is CMS)
				RedirectToCMS();

		}

		public void OnSubNavigationItemClick_ReturnToAss(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			RedirectToAssessmentView();
		}


		/// <summary>
		/// 
		/// USE CASE ID: UC4.1
		/// TITLE: COVERAGE SELECTION LIST
		/// REQUIREMENT ID: 1.50.6
		/// 
		/// Select a valid coverage either automatically or let the
		/// use pic one if multiple coverages were found.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		public EnumSelectValidCoverageResult SelectValidCoverage(CoverageSelectionContext coverageSelectionContext)
		{
			coverageSelectionContext.AddToMessageLog("Attempting to select a valid coverage");
			
			// first check if the currently linked coverage is valid or not.
			// if an log entry with valid coverage is found, this will relink the ERC or Problem to it.
			if (coverageSelectionContext.PatientCoverage != null)
			{
				if (coverageSelectionContext.ValidateCoverage())
					return EnumSelectValidCoverageResult.CoverageValid;		// Coverage valid!

				// No valid coverage!
			}

			AvailableCoverageCollection availableCoverages = coverageSelectionContext.AvailableCoverages;

			if (availableCoverages.Count == 0)
			{
				/*
				* 5. If Number of Coverages = 0
				*    Unhandled
				*/
				coverageSelectionContext.AddToMessageLog("No valid or invalid coverages were found.");
				//throw new ActiveAdviceException(AAExceptionAction.DisableUI, "There's no available coverages!");
				return EnumSelectValidCoverageResult.NoCoverageFound;
			}
			
			int singleValidCoverageIndex = availableCoverages.GetIndexOfValidCoverageIfSingle();

			if (singleValidCoverageIndex >= 0)	// There is a single valid coverage.
			{
				/*
				* 
				* 5. If Number of Coverages = 1
				*	a.	If Coverage is from EligibilityPlan
				*	i.	Include subordinate use case UC3.5 �Create Patient Coverage�
				*	ii.	Select new PatientCoverage record
				*	b.	If Coverage is from PatientCoverage table
				*	i.	Select the existing PatientCoverage record
				*
				*/

				AvailableCoverage avaCov = availableCoverages[singleValidCoverageIndex];

				coverageSelectionContext.AddToMessageLog("A single valid coverage was found.");

				// Ensure the patient coverage whether from elibility or not.
				avaCov.EnsurePatientCoverageFromEligibility(coverageSelectionContext);
				this.CacheObject(typeof(PatientCoverage), avaCov.PatientCoverage);		// set automatically picked coverage to the context
				return EnumSelectValidCoverageResult.SingleCoverageAutoSelected;			// automatically created.
			}
			else // There are multiple coverages and no single valid coverage.
			{
				// Either no valid coverage or multiple valid coverages.
				if (singleValidCoverageIndex == -2)
				{
					// None of the found coverages was valid!
					coverageSelectionContext.AddToMessageLog("None of the {0} coverages found was valid.", availableCoverages.Count );
					return EnumSelectValidCoverageResult.NoCoverageFound;
				}

				/*
				* 
				* 4. If Number of coverages is > 1
				*	a.	System presents to User the Coverage List
				*	b.	User selects a coverage
				*	i.	If coverage is EligibilityPlan
				*	1.	Include subordinate use case UC3.5 �Create Patient Coverage�
				*	2.	Select the new PatientCoverage record
				*	ii.	If coverage is from PatientCoverage table
				*	1.	Select the existing PatientCoverage record
				*
				*/

				coverageSelectionContext.AddToMessageLog("Multiple coverages have been found.  Redirecting to SelectAvailableCoverage page.");
				coverageSelectionContext.AvailableCoverages = availableCoverages;	// use the available coverages returned
				SelectAvailableCoverage.Redirect(coverageSelectionContext);			// display a list of coverages.
				// the SelectAvailableCoverage page knows where to go back from the coverageSelectionContext.
				// The creation of it is delayed until user selects a coverage
				return EnumSelectValidCoverageResult.UserMustSelectFromMultiple;		// not automatically created
			}
		}

		/// <summary>
		/// When a new coverage is to be selected from Administration
		/// of Event/Referral/CMS, this method is called.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="patientCoverage"></param>
		/// <param name="problem"></param>
		/// <param name="erc"></param>
		public void RedirectToSelectCoverage(Patient patient, PatientCoverage patientCoverage, Problem problem, BaseForEventCMSReferral erc)
		{
			CoverageSelectionContext coverageSelectionContext = new CoverageSelectionContext(false, patient, patientCoverage, problem, erc);
			coverageSelectionContext.CoverageSelectionPrompt = "@SELECTANEWCOVERAGE@";
			SelectAvailableCoverage.Redirect(coverageSelectionContext);			// display a list of coverages.
		}

		/// <summary>
		/// Call this only from pages that are common to Event/Referral/CMS
		/// </summary>
		public void SetERCTabVisibilities()
		{
			BaseForEventCMSReferral erc = this.ERC;
			Event eve = erc as Event;
			Referral refe = erc as Referral;
			CMS cms = erc as CMS;

			bool isEvent = eve != null;
			bool isReferral = refe != null;
			bool isCMS = cms != null;

			// Event tabs
			this.SetPageTabItemVisible("EVE_Details", isEvent);
			this.SetPageTabItemVisible("EVE_Reviews", isEvent);
			this.SetPageTabItemVisible("EVE_PCPRefPr", isEvent);
			this.SetPageTabItemVisible("EVE_Administration", isEvent);
			this.SetPageTabItemVisible("EVE_UserDefined", isEvent);
			this.SetPageTabItemVisible("EVE_Mother", isEvent && eve.IsMom);
			this.SetPageTabItemVisible("EVE_Baby", isEvent && eve.IsBaby);

			// Referral tabs
			this.SetPageTabItemVisible("REF_Referral", isReferral);
			this.SetPageTabItemVisible("REF_Clinical", isReferral);
			this.SetPageTabItemVisible("REF_Reports", isReferral);
			this.SetPageTabItemVisible("REF_Administration", isReferral);
			this.SetPageTabItemVisible("REF_UserDefined", isReferral);
			this.SetPageTabItemVisible("REF_Appointments", isReferral);

			// CMS tabs
			this.SetPageTabItemVisible("CMS_General", isCMS);
			this.SetPageTabItemVisible("ASMT_Assessment", isCMS);
			this.SetPageTabItemVisible("POC_PlanOfCare", isCMS);
			this.SetPageTabItemVisible("CRS_CareResource", isCMS);
			this.SetPageTabItemVisible("CMS_Maternichek", isCMS && IsMaternichekVisible);
			this.SetPageTabItemVisible("PLI_PackingList", isCMS && !SystemControlValue.GetInstance.HidePackingListTab /*if true - hide tab*/);
			this.SetPageTabItemVisible("PRVD_Providers", isCMS && !SystemControlValue.GetInstance.HideProviderVendorTab /*if true - hide tab*/);
			this.SetPageTabItemVisible("PRVD_Vendors", isCMS && !SystemControlValue.GetInstance.HideProviderVendorTab /*if true - hide tab*/);
			this.SetPageTabItemVisible("CMS_Administration", isCMS);
			this.SetPageTabItemVisible("CMS_UserDefined", isCMS);

			// Tabs for common pages
			this.SetPageTabItemVisible("PHYREV_PhysicianReview", isEvent || isCMS); // Changed Per v1.1 
			this.SetPageTabItemVisible("CONSPR_ConsultingPr", isEvent);
			this.SetPageTabItemVisible("DXPX_DXPX", isEvent || isReferral);

		}

		#region Tab Redirect in current context utility functions

		public void RedirectToEvent()
		{
			EventForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.Event);
		}

		public void RedirectToPhysicianReview()
		{
			PhysicianReviewForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.ERC);
		}

		public void RedirectToConsultingPr()
		{
			EventConsultingProviderForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.Event);
		}

		public void RedirectToOutcomes()
		{
			OutcomesForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.ERC);
		}

		public void RedirectToDXPX()
		{
			DXPXForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.ERC);
		}
		
		public void RedirectToReferrer()
		{			
			ReferralForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.Referral);
		}

		public void RedirectToCMS()
		{
			CaseManagementForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.CMS, CaseManagementForm.Tabs.General);
		}

		public void RedirectToCMS(CaseManagementForm.Tabs tab)
		{
			CaseManagementForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.CMS, tab);
		}

		public void RedirectToAssessmentView()
		{
			AssessmentView.Redirect(AssessmentContext);
		}

		#endregion

		#region Tab Redirect handlers for common pages

		public void OnTabClick_PHYREV_PhysicianReview(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("PHYREV_PhysicianReview");
			RedirectToPhysicianReview();
		}

		public void OnTabClick_CONSPR_ConsultingPr(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("CONSPR_ConsultingPr");
			RedirectToConsultingPr();
		}

		public void OnTabClick_OUT_Outcomes(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			RedirectToOutcomes();
		}

		public void OnTabClick_DXPX_DXPX(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("DXPX_DXPX");
			RedirectToDXPX();
		}

		#endregion

		#region Tab Redirect handlers for Event page

		/*  This is a special tab that can't be redirect to.
		public void OnTabClick_EVE_Duplicates(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_Duplicates");
			RedirectToEvent();
		}
		*/

		public void OnTabClick_EVE_Details(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_Details");
			RedirectToEvent();
		}

		public void OnTabClick_EVE_Reviews(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_Reviews");
			RedirectToEvent();
		}

		public void OnTabClick_EVE_Administration(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_Administration");
			RedirectToEvent();
		}

		public void OnTabClick_EVE_UserDefined(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_UserDefined");
			RedirectToEvent();
		}

		public void OnTabClick_EVE_Mother(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_Mother");
			RedirectToEvent();
		}

		public void OnTabClick_EVE_Baby(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_Baby");
			RedirectToEvent();
		}

		public void OnTabClick_EVE_PCPRefPr(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_PCPRefPr");
			RedirectToEvent();
		}

		#endregion

		#region Tab Redirect handlers for Referral page

		public void OnTabClick_REF_Referral(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("REF_Referral");
			RedirectToReferrer();
		}

		public void OnTabClick_REF_Clinical(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("REF_Clinical");
			RedirectToReferrer();
		}
		public void OnTabClick_REF_Reports(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("REF_Reports");
			RedirectToReferrer();
		}
		public void OnTabClick_REF_Administration(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("REF_Administration");
			RedirectToReferrer();
		}

		public void OnTabClick_REF_UserDefined(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("REF_UserDefined");
			RedirectToReferrer();
		}

		#endregion

		#region Tab redirect handlers for CMS page
		public void OnTabClick_CMS_General(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			RedirectToCMS();
		}

		public virtual void OnTabClick_ASMT_Assessment(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("ASMT_Assessment");
			
			if(AssmtVisibility)
				RedirectToAssessmentView();
				//AssessmentView.Redirect(AssessmentContext);
			else
			{
				//NSGlobal.ClearCache("AssessmentContext");
				this.CacheObject(typeof(AssessmentContext), null);
				Assessments.Redirect(CMS);
			}
		}

		private bool AssmtVisibility
		{
			get
			{
				return AssessmentContext != null 
					&& this.CMS != null
					&& AssessmentContext.CMS.Patient.PatientId == this.CMS.Patient.PatientId 
					&& AssessmentContext.CMS.CMSID == this.CMS.CMSID;
			}
		}

		public void OnTabClick_POC_PlanOfCare(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			DGIForm.Redirect(CMS);
		}		

		public void OnTabClick_CRS_CareResource(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			bool isReloadCareResourceForm = false;
			this.CacheObject("isReloadCareResourceForm", isReloadCareResourceForm);
			PushTargetTab("CRS_CareResource");
			CareResourceForm.Redirect(this.CMS, this.PatientCoverage, this.Problem);
		}

		public void OnTabClick_CMS_Maternichek(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			RedirectToCMS(CaseManagementForm.Tabs.Maternichek);
		}

		public void OnTabClick_PLI_PackingList(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("PLI_PackingList");
			this.CacheObject("AssessmentContext", null);
			PackingListForm.Redirect(this.CMS);
		}

		public void OnTabClick_PRVD_Providers(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("PRVD_Providers");
			ProviderVendorForm.Redirect(CMS);
		}

		public void OnTabClick_PRVD_Vendors(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("PRVD_Vendors");
			ProviderVendorForm.Redirect(CMS);
		}

		public void OnTabClick_CMS_Administration(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			RedirectToCMS(CaseManagementForm.Tabs.Administration);
		}

		public void OnTabClick_CMS_UserDefined(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			RedirectToCMS(CaseManagementForm.Tabs.UserDefined);
		}
		#endregion

		
		#region Maternichek
		/// <summary>
		/// Determines visibility of Maternichek based on permissions, patient's gender, ERC type and type of CMS.
		/// </summary>
		/// <returns></returns>
		public bool IsMaternichekVisible
		{
			get
			{
				return IsMaternichekButtonVisible && this.ERC is CMS
					&& (this.ERC as CMS).CMSTypeID == Maternichek.CMSTypeCodeId;
			}
		}

		/// <summary>
		/// Determines visibility of Maternichek based on permissions and patient's gender.
		/// </summary>
		public bool IsMaternichekButtonVisible
		{
			get
			{
				if(Patient == null)
					return false;

				return AASecurityHelper.HasFullAccessRole(AASecurityHelper.MATERNICHEK)
					&& Patient.Gender == GenderCode.Female;
			}
		}
		#endregion

		public bool PerDayCoverageValidation(CoverageSelectionContext covSelContext, PatientCoverage patCov, Problem problem)
		{
			if (this.ERC == null)
				return false;

			// Validate coverage for an existing event.
			if (covSelContext == null) // && !eventObj.IsNew)
			{
				if (this.ERC.RequiresCoverageValidationForToday())
				{
					// if the event is open.
					// validate coverage once a day.
					// Select a valid coverage
					covSelContext = new CoverageSelectionContext(false, this.Patient, patCov, problem, this.ERC);
					covSelContext.CoverageSelectionPrompt = "@SELECTVALIDCOVERAGE@";
					EnumSelectValidCoverageResult aresult = this.SelectValidCoverage(covSelContext);
					switch (aresult)
					{
						case EnumSelectValidCoverageResult.NoCoverageFound:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "@NOVALIDCOVERAGE@"));
							return false;
						case EnumSelectValidCoverageResult.CoverageValid:
						case EnumSelectValidCoverageResult.SingleCoverageAutoSelected:
							break;
						case EnumSelectValidCoverageResult.UserMustSelectFromMultiple:
							return false;		// user was redirected to coverage selection page.
						default:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "Unknown selection result"));
							return false;
					}					
				}
			}
			return true;
		}

		public bool CheckUserDxPxPermission(BaseForEventCMSReferral erc)
		{
			try
			{
				return erc.CheckUserDxPxPermission();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);

			pageSummary.SummaryTitle = "@PATIENTINFORMATION@";
		}

		public bool LetterContextRequestIDRequired
		{
			get { return this.letterContextRequestIDRequired; }
			set { this.letterContextRequestIDRequired = value; }
		}

		public bool LetterContextDecisionIDRequired
		{
			get { return this.letterContextDecisionIDRequired; }
			set { this.letterContextDecisionIDRequired = value; }
		}
	}
}
