using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// All pages under Plans should derive from this base class.
	/// </summary>
	[Designer("Microsoft.VSDesigner.WebForms.WebFormDesigner,Microsoft.VSDesigner")]
	[BackPage(typeof(PlanSearch))]
	[SelectedMainMenuItem("MPlan")]	
	[PageTitle("@PLANPAGETITLE@")]
	public class PlanBasePage : BasePage
	{
		public PlanBasePage() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private Plan Plan
		{
			get { return (Plan)this.LoadObject(typeof(Plan), false); }
		}

		/// <summary>
		/// Easy access to translated plan messages.
		/// </summary>
		public PlanMessages PlanMessages
		{
			get { return (PlanMessages)this.Language; }
		}

		protected override void RemoveContext()
		{
			this.CacheObject(typeof(Plan), null);
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			Plan plan = this.Plan;

			listbar.AddItem("@SEARCH@", "Search");
			listbar.AddItem("@DETAILS@", "Details");
			//listbar.AddItem("@MANAGEMENTSVCS@", "ManagementServices").Enabled = plan != null && !plan.IsNew;
			if (!this.IsPopup)
			{
				//listbar.AddItem("@CONTACTS@", "Contacts"); // Issue 525
				listbar.AddItem("@SPECIALPROCEDURES@", "SpecialProcedures");
				listbar.AddItem("@TRIGGERLISTS@", "TriggerLists");
				listbar.AddItem("@BENEFITSERVICES@", "BenefitServices");
				listbar.AddItem("@INSURANCEPAYORS@", "InsurancePayors");
			}
			
			//listbar.AddItem("Summary", "MorgSummary");
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			Plan plan = this.Plan;

			this.SetPageSubMenuItemEnabled("Details", plan != null);
			//this.SetPageSubMenuItemEnabled("Contacts", plan != null && !plan.IsNew);
		}

		public override void OnSubNavigationItemClick(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			if (item.Key != "Details")
				RemoveContext();

			base.OnSubNavigationItemClick (listbar, item);
		}

		public void OnSubNavigationItemClick_Search(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			PlanSearch.Redirect();
		}

		public void OnSubNavigationItemClick_Details(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			PlanForm.Redirect(this.Plan);
		}

		/* Issue 525
		public void OnToolbarButtonClick_Contacts(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			ContactSearch.Redirect(this.Plan);
		}*/

		public void OnSubNavigationItemClick_ManagementServices(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			Plan plan = this.Plan;
			if (plan != null)
				ManagementServicesForm.Redirect(plan.ManagementService);
		}

		public void OnSubNavigationItemClick_SpecialProcedures(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			SpecialProceduresSearch.Redirect();
		}

		public void OnSubNavigationItemClick_BenefitServices(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BenefitServicesSearch.Redirect();
		}

		public void OnSubNavigationItemClick_InsurancePayors(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			InsurancePayorSearch.Redirect();
		}

		public void OnSubNavigationItemClick_TriggerLists(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			TriggerListsSearch.Redirect();
		}
		

	}
}
