using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;


namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for AssessmentBasePage.
	/// </summary>
	public class AssessmentBasePage : BasePage
	{
		protected AssessmentContext assessmentContext;
		protected Assessment assessment;
		protected CMS cMS;

		public AssessmentBasePage() : base()
		{
		}
		
		override protected void OnInit(EventArgs e)
		{
			base.OnInit(e);
			assessmentContext = GetParamOrGetFromCache("ASSESSMENTCONTEXT", typeof(AssessmentContext)) as AssessmentContext;

			if (assessmentContext == null)
				assessment = GetParamOrGetFromCache("ASSESSMENT", typeof(Assessment)) as Assessment;
			else
				assessment = assessmentContext.Assessment;

			cMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;

			this.AssessmentContext = assessmentContext;
			this.Assessment = assessment;
			this.CMS = cMS;
		}


		public AssessmentContext AssessmentContext
		{
			get { return assessmentContext; }
			set
			{
				assessmentContext = value;
				this.CacheObject(typeof(AssessmentContext), assessmentContext);	
			}
		}

		public Assessment Assessment
		{
			get { return assessment; }
			set
			{
				assessment = value;
				this.CacheObject(typeof(Assessment), assessment);	
			}
		}

		public CMS CMS
		{
			get { return cMS; }
			set
			{
				cMS = value;
				this.CacheObject(typeof(CMS), cMS);	
			}
		}

	}
}
