using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for CMSMaintenanceBasePage.
	/// </summary>
	public class CMSMaintenanceBasePage : BasePage
	{
		public CMSMaintenanceBasePage() : base()
		{
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			listbar.AddItem("@PACKINGLIST@", "PackingList");
			listbar.AddItem("@MEASUREMENTSMENUITEM@", "Measurements");
		}

		public void OnSubNavigationItemClick_PackingList(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("PackingListItemManagement.aspx");
		}

		public void OnSubNavigationItemClick_Measurements(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("MeasurementMaintenance.aspx");
		}
	}
}
