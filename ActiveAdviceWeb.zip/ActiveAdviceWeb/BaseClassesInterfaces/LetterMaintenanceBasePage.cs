using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterMaintenanceBasePage.
	/// </summary>
	public class LetterMaintenanceBasePage : BasePage
	{
		public LetterMaintenanceBasePage() : base()
		{
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			PopulateSubNavigationItems(listbar);
		}

		public static void PopulateSubNavigationItems(WebListBar listbar)
		{
			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_GENERATE_BATCH))
			{	
				listbar.AddItem(Messages.LetterMessages.MessageIDs.LETTERQUEUE, "LetterQueue");
				listbar.AddItem(Messages.LetterMessages.MessageIDs.LETTERDUPLEXQUEUE, "DuplexLetterQueue");
				listbar.AddItem(Messages.LetterMessages.MessageIDs.LETTERENVELOPEQUEUE, "EnvelopeLetterQueue");
			}		

			if (AASecurityHelper.HasFullAccessRole(AASecurityHelper.LETTER_SETUP))
			{					
				listbar.AddItem(Messages.LetterMessages.MessageIDs.LETTERMATRIX, "LetterMatrix");
				listbar.AddItem(Messages.LetterMessages.MessageIDs.LETTERTEMPLATE, "LetterTemplate");
				listbar.AddItem(Messages.LetterMessages.MessageIDs.ASMTLTRMAINT, "AssessmentLetterMaintenance");
				listbar.AddItem(Messages.LetterMessages.MessageIDs.INTROLTRS, "IntroLetter");
				listbar.AddItem(Messages.LetterMessages.MessageIDs.LETTERGRAPHICS, "LetterGraphics");
				listbar.AddItem(Messages.LetterMessages.MessageIDs.LETTERSET, "LetterSet");				
			}
		}

		public void OnSubNavigationItemClick_LetterSet(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("LetterSetMaintenance.aspx");
		}

		public void OnSubNavigationItemClick_LetterGraphics(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("LetterGraphicMaintenance.aspx");
		}

		public void OnSubNavigationItemClick_LetterQueue(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			// Fix: Only display letters that are not either duplex or envelope
			LetterQueueMaintenance.Redirect(null, null, false, false);
		}

		public void OnSubNavigationItemClick_DuplexLetterQueue(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			LetterQueueMaintenance.Redirect(null, null, true, false);
		}

		public void OnSubNavigationItemClick_EnvelopeLetterQueue(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			LetterQueueMaintenance.Redirect(null, null, false, true);
		}

		public void OnSubNavigationItemClick_LetterMatrix(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("LetterMatrixSearch.aspx");
		}

		public void OnSubNavigationItemClick_LetterTemplate(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("LetterTemplateSearch.aspx");
		}

		public void OnSubNavigationItemClick_AssessmentLetterMaintenance(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("AssessmentLetterSearch.aspx");
		}

		public void OnSubNavigationItemClick_IntroLetter(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("IntroLetterMaintenance.aspx");
		}
	}
}
