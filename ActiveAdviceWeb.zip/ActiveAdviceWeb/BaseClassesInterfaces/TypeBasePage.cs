using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// All pages under Plans should derive from this base class.
	/// </summary>
	[Designer("Microsoft.VSDesigner.WebForms.WebFormDesigner,Microsoft.VSDesigner")]
	public class TypeBasePage : BasePage
	{
		public TypeBasePage() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		
		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			listbar.AddItem("@NETWORKTYPES@", "NetworkTypes");
			listbar.AddItem("@GROUPPRACTICETYPES@", "GroupPracticeType");
			listbar.AddItem("@FACILITYTYPES@", "FacilityType");
			
		}

		public void OnSubNavigationItemClick_NetworkTypes(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			Response.Redirect("NetworkTypeForm.aspx");
		}

		public void OnSubNavigationItemClick_GroupPracticeType(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			Response.Redirect("GroupPracticeTypeForm.aspx");
		}

		public void OnSubNavigationItemClick_FacilityType(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			Response.Redirect("FacilityTypeForm.aspx");
		}
	}
}
