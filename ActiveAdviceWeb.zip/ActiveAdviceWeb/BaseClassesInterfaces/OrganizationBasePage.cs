using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// All pages under Plans should derive from this base class.
	/// </summary>
	[Designer("Microsoft.VSDesigner.WebForms.WebFormDesigner,Microsoft.VSDesigner")]
	[BackPage(typeof(OrganizationSearch))]
	[PageTitle("@ORGANIZATIONPAGETITLE@")]
	public class OrganizationBasePage : BasePage
	{
		public OrganizationBasePage() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private Organization Organization
		{
			get { return (Organization)this.LoadObject(typeof(Organization), false); }
		}

		/// <summary>
		/// Easy access to translated organization messages.
		/// </summary>
		public OrgMessages OrgMessages
		{
			get { return (OrgMessages)this.Language; }
		}

		protected override void RemoveContext()
		{
			this.CacheObject(typeof(Organization), null);
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			Organization organization = this.Organization;

			listbar.AddItem("@DETAILS@", "Details");

			for (int i = 0; i < OrganizationLevelCollection.OrganizationLevels.Count; i++)
			{
				OrganizationLevel level = OrganizationLevelCollection.OrganizationLevels[i];
				string searchChildOrgText = ((BasePage)Page).Language.Translate("@SEARCHCHILDORG@", level.CodePlural);
				listbar.AddItem(searchChildOrgText, "Search_" + level.OrganizationLevelID, true);
			}
			//listbar.AddItem("@MANAGEMENTSVCS@", "ManagementServices").Enabled = plan != null && !plan.IsNew;
			//listbar.AddItem("@SPECIALPROCEDURES@", "SpecialProcedures");
			//listbar.AddItem("@TRIGGERLISTS@", "TriggerLists");
			//listbar.AddItem("@BENEFITSERVICES@", "BenefitServices");
			//listbar.AddItem("@INSURANCEPAYORS@", "InsurancePayors");
			
			//listbar.AddItem("Summary", "MorgSummary");
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			Organization organization = this.Organization;

			this.SetPageSubMenuItemEnabled("Details", organization != null);
		}

		public override void OnSubNavigationItemClick(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			if (item.Key != "Details")
				RemoveContext();
			
			base.OnSubNavigationItemClick (listbar, item);

			if (item.Key.Length > 7)
			{
				if (item.Key.Substring(0, 7) == "Search_")
				{
					string slevel = item.Key.Substring(7);
					int level = Convert.ToInt32(slevel);
					OrganizationSearch.Redirect(level);
				}
			}
		}


		//public void OnSubNavigationItemClick_Search(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		//{
		//	OrganizationSearch.Redirect(null);
		//}

		public void OnSubNavigationItemClick_Details(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			OrganizationForm.Redirect(this.Organization);
		}

		//public void OnSubNavigationItemClick_ManagementServices(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		//{
		//	Organization organization = this.Organization;
		//	if (organization != null)
		//		ManagementServicesForm.Redirect(plan.ManagementService);
		//}

	}
}
