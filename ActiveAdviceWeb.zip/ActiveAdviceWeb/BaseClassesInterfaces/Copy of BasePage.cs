using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// ActiveAdvice base page
	/// </summary>
	[Designer("Microsoft.VSDesigner.WebForms.WebFormDesigner,Microsoft.VSDesigner")]
	[BackPage(typeof(PatientSearch))]
	public class NewBasePage : BasePage
	{

		private ListbarButtonExtraProperties lbiDetails;

		public NewBasePage() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// The patient that's currently in the working context
		/// </summary>
		private Patient Patient
		{
			get { return (Patient)this.LoadObject(typeof(Patient), false); }
		}

		/// <summary>
		/// Easy access to translated patient messages.
		/// </summary>
		public PatientMessages PatientMessages
		{
			get { return (PatientMessages)this.Language; }
		}

		/// <summary>
		/// Selected coverage of the patient (selected in the summary page)
		/// </summary>
		private PatientCoverage PatientCoverage
		{
			get { return (PatientCoverage)this.LoadObject(typeof(PatientCoverage), false); }
		}

		/// <summary>
		/// Selected problem of the patient (selected in the summary page)
		/// </summary>
		private Problem Problem
		{
			get { return (Problem)this.LoadObject(typeof(Problem), false); }
		}

		/// <summary>
		/// Selected Event/Referral/CMS of the patient (selected in the summary page)
		/// </summary>
		private BaseForEventCMSReferral ERC
		{
			get { return (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral), false); }
		}

		/// <summary>
		/// Selected Event of the patient (selected in the summary page)
		/// </summary>
		private Event Event
		{
			get { return this.ERC as Event; }
		}

		/// <summary>
		/// Selected Referral of the patient (selected in the summary page)
		/// </summary>
		private Referral Referral
		{
			get { return this.ERC as Referral; }
		}

		/// <summary>
		/// Selected CMS of the patient (selected in the summary page)
		/// </summary>
		private CMS CMS
		{
			get { return this.ERC as CMS; }
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);

			string callingPage = (string)GetParam("CallingPage");
			if (callingPage != null)
			{
				//this.PageReferrer = callingPage;		// cancel will go back to the given page
				this.BackPage = callingPage;
			}
		}

		protected override void RemoveContext()
		{
			this.CacheObject(typeof(Patient), null);
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			//Patient patient = this.Patient;

			listbar.AddItem("@SEARCH@", "Search");
			lbiDetails = listbar.AddItem("@DETAILS@", "Details");		// will set dirty check flag
			listbar.AddItem("@SUMMARY@", "Summary");
			listbar.AddItem("@MEDICATIONS@", "Medications");
			listbar.AddItem("@ALLERGIES@", "Allergies");
			listbar.AddItem("@MEASUREMENTS@", "Measurements");
			listbar.AddItem("@ACTIVITIES@", "Activities");
		}

		protected override void OnPreRender(EventArgs e)
		{
			Patient patient = this.Patient;

			if (lbiDetails != null)
				lbiDetails.ChecksForIsDirty = patient != null && patient.IsNew;		// if the patient is newly entered, neither it nor the coverage records weren't saved yet.

			base.OnPreRender (e);

			this.SetPageSubMenuItemEnabled("Details", patient != null);
			this.SetPageSubMenuItemEnabled("Summary", patient != null && !patient.IsNew);
			this.SetPageSubMenuItemVisible("Medications", patient != null && !patient.IsNew);
			this.SetPageSubMenuItemVisible("Allergies", patient != null && !patient.IsNew);
			this.SetPageSubMenuItemVisible("Measurements", patient != null && !patient.IsNew);
			this.SetPageSubMenuItemEnabled("Activities", patient != null && !patient.IsNew && this.PatientCoverage != null);
		}

		public override void OnSubNavigationItemClick(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			if (item.Key != "Details" && item.Key != "Summary" 
				&& item.Key != "Medications" && item.Key != "Allergies" && item.Key != "Activities"
				&& item.Key != "Measurements")
				RemoveContext();

			base.OnSubNavigationItemClick (listbar, item);
		}

		public void OnSubNavigationItemClick_Search(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			PatientSearch.Redirect();
		}

		public void OnSubNavigationItemClick_Details(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			PatientForm.Redirect(this.Patient);
		}

		public void OnSubNavigationItemClick_Summary(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			PatientSummaryForm.Redirect(this.Patient);
		}

		public void OnSubNavigationItemClick_Medications(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			MedicationSummaryForm.Redirect(this.Patient);
		}

		public void OnSubNavigationItemClick_Allergies(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			AllergySummaryForm.Redirect(this.Patient);	
		}

		public void OnSubNavigationItemClick_Activities(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ActivitiesForm.Redirect();
		}

		public void OnSubNavigationItemClick_Measurements(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			MeasurementSummaryForm.Redirect(this.Patient);
		}

		/// <summary>
		/// 
		/// USE CASE ID: UC4.1
		/// TITLE: COVERAGE SELECTION LIST
		/// REQUIREMENT ID: 1.50.6
		/// 
		/// Select a valid coverage either automatically or let the
		/// use pic one if multiple coverages were found.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		public EnumSelectValidCoverageResult SelectValidCoverage(CoverageSelectionContext coverageSelectionContext)
		{
			coverageSelectionContext.AddToMessageLog("Attempting to select a valid coverage");
			
			// first check if the currently linked coverage is valid or not.
			// if an log entry with valid coverage is found, this will relink the ERC or Problem to it.
			if (coverageSelectionContext.PatientCoverage != null)
			{
				if (coverageSelectionContext.ValidateCoverage())
					return EnumSelectValidCoverageResult.CoverageValid;		// Coverage valid!

				// No valid coverage!
			}

			AvailableCoverageCollection availableCoverages = coverageSelectionContext.AvailableCoverages;

			if (availableCoverages.Count == 0)
			{
				/*
				* 5. If Number of Coverages = 0
				*    Unhandled
				*/
				coverageSelectionContext.AddToMessageLog("No valid or invalid coverages were found.");
				//throw new ActiveAdviceException(AAExceptionAction.DisableUI, "There's no available coverages!");
				return EnumSelectValidCoverageResult.NoCoverageFound;
			}
			
			int singleValidCoverageIndex = availableCoverages.GetIndexOfValidCoverageIfSingle();

			if (singleValidCoverageIndex >= 0)	// There is a single valid coverage.
			{
				/*
				* 
				* 5. If Number of Coverages = 1
				*	a.	If Coverage is from EligibilityPlan
				*	i.	Include subordinate use case UC3.5 �Create Patient Coverage�
				*	ii.	Select new PatientCoverage record
				*	b.	If Coverage is from PatientCoverage table
				*	i.	Select the existing PatientCoverage record
				*
				*/

				AvailableCoverage avaCov = availableCoverages[singleValidCoverageIndex];

				coverageSelectionContext.AddToMessageLog("A single valid coverage was found.");

				// Ensure the patient coverage whether from elibility or not.
				avaCov.EnsurePatientCoverageFromEligibility(coverageSelectionContext);
				return EnumSelectValidCoverageResult.SingleCoverageAutoSelected;			// automatically created.
			}
			else // There are multiple coverages and no single valid coverage.
			{
				/*
				* 
				* 4. If Number of coverages is > 1
				*	a.	System presents to User the Coverage List
				*	b.	User selects a coverage
				*	i.	If coverage is EligibilityPlan
				*	1.	Include subordinate use case UC3.5 �Create Patient Coverage�
				*	2.	Select the new PatientCoverage record
				*	ii.	If coverage is from PatientCoverage table
				*	1.	Select the existing PatientCoverage record
				*
				*/

				coverageSelectionContext.AddToMessageLog("Multiple coverages have been found.  Redirecting to SelectAvailableCoverage page.");
				coverageSelectionContext.AvailableCoverages = availableCoverages;	// use the available coverages returned
				SelectAvailableCoverage.Redirect(coverageSelectionContext);			// display a list of coverages.
				// the SelectAvailableCoverage page knows where to go back from the coverageSelectionContext.
				// The creation of it is delayed until user selects a coverage
				return EnumSelectValidCoverageResult.UserMustSelectFromMultiple;		// not automatically created
			}
		}
		/// <summary>
		/// When a new coverage is to be selected from Administration
		/// of Event/Referral/CMS, this method is called.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="patientCoverage"></param>
		/// <param name="problem"></param>
		/// <param name="erc"></param>
		public void RedirectToSelectCoverage(Patient patient, PatientCoverage patientCoverage, Problem problem, BaseForEventCMSReferral erc)
		{
			CoverageSelectionContext coverageSelectionContext = new CoverageSelectionContext(false, patient, patientCoverage, problem, erc);
			coverageSelectionContext.CoverageSelectionPrompt = "@SELECTANEWCOVERAGE@";
			SelectAvailableCoverage.Redirect(coverageSelectionContext);			// display a list of coverages.
		}

		/// <summary>
		/// Display the coverage selection steps that were logged in the coverageSelectionContext object.
		/// This function is automatically discarded from release.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		[System.Diagnostics.Conditional("DEBUG")]
		public void DumpCoverageSelectionContext(CoverageSelectionContext coverageSelectionContext)
		{
			this.SetPageMessage(" Coverage selection steps performed:", EnumPageMessageType.AddInfo);
			for (int i = 0; i < coverageSelectionContext.MessageLog.Count; i++)
			{
				this.SetPageMessage("   {0} - {1}", EnumPageMessageType.AddInfo, i, (string)coverageSelectionContext.MessageLog[i]);
			}
		}

		/// <summary>
		/// Call this only from pages that are common to Event/Referral/CMS
		/// </summary>
		public void SetERCTabVisibilities()
		{
			BaseForEventCMSReferral erc = this.ERC;
			Event eve = erc as Event;
			Referral refe = erc as Referral;
			CMS cms = erc as CMS;

			bool isEvent = eve != null;
			bool isReferral = refe != null;
			bool isCMS = cms != null;

			// Event tabs
			this.SetPageTabItemVisible("EVE_Details", isEvent);
			this.SetPageTabItemVisible("EVE_Reviews", isEvent);
			this.SetPageTabItemVisible("EVE_PCPRefPr", isEvent);
			this.SetPageTabItemVisible("EVE_Administration", isEvent);
			this.SetPageTabItemVisible("EVE_UserDefined", isEvent);

			// Referral tabs
			this.SetPageTabItemVisible("REF_Referral", isReferral);
			this.SetPageTabItemVisible("REF_Clinical", isReferral);
			this.SetPageTabItemVisible("REF_Reports", isReferral);
			this.SetPageTabItemVisible("REF_Administration", isReferral);
			this.SetPageTabItemVisible("REF_UserDefined", isReferral);

			// Tabs for common pages
			this.SetPageTabItemVisible("PHYREV_PhysicianReview", isEvent);
			this.SetPageTabItemVisible("CONSPR_ConsultingPr", isEvent);
			this.SetPageTabItemVisible("OUT_Outcomes", isEvent || isReferral);
			this.SetPageTabItemVisible("DXPX_DXPX", isEvent || isReferral || isCMS);

		}
		
		#region Tab Redirect in current context utility functions

		public void RedirectToEvent()
		{
			EventForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.Event);
		}

		public void RedirectToPhysicianReview()
		{
			PhysicianReviewForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.ERC);
		}

		public void RedirectToConsultingPr()
		{
			EventConsultingProviderForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.Event);
		}

		public void RedirectToOutcomes()
		{
			OutcomesForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.ERC);
			throw new Exception("xxx");
		}

		public void RedirectToDXPX()
		{
			DXPXForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.ERC);
		}
		
		public void RedirectToReferrer()
		{			
			ReferralForm.Redirect(this.Patient, this.PatientCoverage, this.Problem, this.Referral);
		}

		#endregion

		#region Tab Redirect handlers for common pages


		public void OnTabClick_PHYREV_PhysicianReview(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("PHYREV_PhysicianReview");
			RedirectToPhysicianReview();
		}

		public void OnTabClick_CONSPR_ConsultingPr(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("CONSPR_ConsultingPr");
			RedirectToConsultingPr();
		}

		public void OnTabClick_OUT_Outcomes(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("OUT_Outcomes");
			RedirectToOutcomes();
		}

		public void OnTabClick_DXPX_DXPX(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("DXPX_DXPX");
			RedirectToDXPX();
		}

		#endregion

		/*
		public void OnTabClick_EVE_Details(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_Details");
			RedirectToEvent();
		}

		public void OnTabClick_EVE_Reviews(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_Reviews");
			RedirectToEvent();
		}

		public void OnTabClick_EVE_Administration(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_Administration");
			RedirectToEvent();
		}

		public void OnTabClick_EVE_PCPRefPr(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("EVE_PCPRefPr");
			RedirectToEvent();
		}

		public void OnTabClick_REF_Referral(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("REF_Referral");
			RedirectToReferrer();
		}

		public void OnTabClick_REF_Clinical(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("REF_Clinical");
			RedirectToReferrer();
		}
		public void OnTabClick_REF_Reports(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("REF_Reports");
			RedirectToReferrer();
		}
		public void OnTabClick_REF_Administration(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("REF_Administration");
			RedirectToReferrer();
		}

		public void OnTabClick_REF_UserDefined(WebTab tabControl, Infragistics.WebUI.UltraWebTab.Tab newTab, Infragistics.WebUI.UltraWebTab.Tab previousTab)
		{
			PushTargetTab("REF_UserDefined");
			RedirectToReferrer();
		}*/
	}
}
