using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for AssessmentMaintenanceBasePage.
	/// </summary>
	public class AssessmentMaintenanceBasePage : BasePage
	{
		public AssessmentMaintenanceBasePage() : base()
		{
		}


		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			listbar.AddItem("@QUESTIONS@", "Questions");
			listbar.AddItem("@PRESENTATIONGROUPS@", "PR");
			listbar.AddItem("@QUESTIONNAIRES@", "QR");
			listbar.AddItem("@QRORGANIZATIONS@", "QROrganizations");
			listbar.AddItem("@LOGICS@", "Logics");
			listbar.AddItem("@WEBLINKS@", "WebLinkSearch");
			listbar.AddItem("@INTERVTEMPLATES@", "InterventionTemplates");
			listbar.AddItem("@ICMQR@", "IcmQR");
			listbar.AddItem("@ICMPR@", "IcmPR");
		}

		public void OnSubNavigationItemClick_Questions(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("QuestionSearch.aspx");
		}

		public void OnSubNavigationItemClick_PR(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("PresentationGroupSearch.aspx");
		}

		public void OnSubNavigationItemClick_QR(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("QuestionnaireSearch.aspx");
		}

		public void OnSubNavigationItemClick_Logics(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("LogicSearch.aspx");
		}

		public void OnSubNavigationItemClick_QROrganizations(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("QuestionnaireOrganizations.aspx");
		}

		public void OnSubNavigationItemClick_WebLinkSearch(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("WebLinkSearch.aspx");
		}

		public void OnSubNavigationItemClick_InterventionTemplates(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("InterventionTemplateSearch.aspx");
		}

		public void OnSubNavigationItemClick_IcmQR(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ICMMaintenance.aspx");
		}

		public void OnSubNavigationItemClick_IcmPR(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ICMMaintenancePr.aspx");
		}
	}
}
