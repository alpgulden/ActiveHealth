using System;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using System.ComponentModel;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web.BaseClassesInterfaces
{
	/// <summary>
	/// Summary description for ImportExportBasePage.
	/// This page is inherited by all the Interface
	/// pages.
	/// </summary>
	public class ImportExportBasePage : BasePage
	{
		public ImportExportBasePage()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		protected bool ValidateArguments(TaskArguments ta, bool directories)
		{
			// Must have a label!
			if ( (ta.Label == null) || (ta.Label == "") )
				return false;
			// Must have a filename!
			if ( (ta.FileName == null) || (ta.FileName == "") )
				return false;

			// See if the file exists on the server...
			if (File.Exists(ta.FileName))
				return true;

			if (directories)
			{
				// See if this is a directory....
				DirectoryInfo di = new DirectoryInfo(ta.FileName);	

				if(di.Exists)
				{
					// Are there any files in this directory???
					FileInfo[] files = di.GetFiles();
					if (files.Length > 0)
						return true;
				}
			}

			if ( (ta.GetType() == typeof(CEExportArgs)       ) ||
				 (ta.GetType() == typeof(AuthorizationArgs)  ) ||
				 (ta.GetType() == typeof(MemberLogArgs)      ) ||
				 (ta.GetType() == typeof(MFLExportArguments) ) ||
				 (ta.GetType() == typeof(MemberFileListArgs) ) )
				return true;

			// We didn't find a file, nor a directory with at least one file
			this.SetPageMessage("@FILENOTFOUND@", EnumPageMessageType.AddError, ta.FileName);
			return false;
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);

			listbar.AddItem(true, "@TASKLIST@",      "TaskList",		false);
			listbar.AddItem(true, "@ELIGIBILITY@",   "Eligibility",		true);
			listbar.AddItem(true, "@SCORINGLOAD@",   "ScoringLoad",		true);
			listbar.AddItem(true, "@CEEXPORT@",      "CareEngine",		true);
			listbar.AddItem(true, "@AUTHORIZATION@", "Authorization",	true);
			listbar.AddItem(true, "@MEMBERLOG@",     "MemberLog",		true);
			listbar.AddItem(true, "@PROVIDER@",      "Provider",		true);
			listbar.AddItem(true, "@EDIRECEIVER@",   "EDIReceiver",     true);
			listbar.AddItem(true, "@EDIREQUESTER@",  "EDIRequester",    true);
			listbar.AddItem(true, "@MEMBERLISTFILE@", "MemberList",     true);
		}

		public void OnSubNavigationItemClick_TaskList(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ImportExportTasks.aspx");
		}
		public void OnSubNavigationItemClick_Provider(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ImportProvider.aspx");
		}
		public void OnSubNavigationItemClick_Eligibility(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ImportEligibility.aspx");
		}
		public void OnSubNavigationItemClick_ScoringLoad(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ImportScoringLoad.aspx");
		}
		public void OnSubNavigationItemClick_CareEngine(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ExportCareEngine.aspx");
		}
		public void OnSubNavigationItemClick_Authorization(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ExportAuthorization.aspx");
		}
		public void OnSubNavigationItemClick_MemberLog(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ExportMemberLog.aspx");
		}
		public void OnSubNavigationItemClick_EDIReceiver(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("EDIReceivers.aspx");
		}
		public void OnSubNavigationItemClick_EDIRequester(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("EDIRequesters.aspx");
		}
		public void OnSubNavigationItemClick_MemberList(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			BasePage.Redirect("ExportMemberFileList.aspx");
		}

		private int currentuser = 1; // for debugging userid = 1
		protected int CurrentUser
		{
			get { return currentuser; }
			set { currentuser = value; }
		}

	}
}
