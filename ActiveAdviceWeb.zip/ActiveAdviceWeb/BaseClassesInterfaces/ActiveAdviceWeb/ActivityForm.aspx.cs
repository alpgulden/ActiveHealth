using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// This page handles data entry for an Activity.  A patient and a selected coverage must be 
	/// passed to this page.  When a new activity is created, the plan of the pat-subs-coverage is used.
	/// 
	/// The Active Advice System utilizes Activities to allow users to schedule and assign tasks to users or teams. 
	/// Activities are used to track the status of work assignments and to record the time used to complete them. 
	/// The information captured by an activity can be used to provide billing information to clients.
	/// Activities organized in Work Lists are utilized by Users to structure their daily workflow. The Activity 
	/// provides a method of encapsulating a unit of work, and can be used to track the billable time expended on a task.
	/// Activities can be created manually by Users, automatically by the System in response to stimuli, or copied from 
	/// Interventions (see Plan of Care, section 1.26).
	/// Examples of how Activities are used within the Active Advice System
	/// 	�	Intake Staff assigning work to the Utilization Review (UR) Staff personnel
	/// 	�	UR staff personnel scheduling future tasks
	/// 	�	Case Management personnel copying an Intervention as a future task to follow up patient care
	/// Activities are used principally to track issues relating to a patient�s course of care. 
	/// An important attribute of an Activity is its Due Date. The Due Date can be used to schedule an Activity for 
	/// work at a future time; this feature is frequently used in the existing Active Advice system. 
	/// 
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Activity,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("Details")]						//define the active menu item in side menu
	[SelectedMainMenuItem("MPatient")]						//defines active menu item in main navigation
		public class ActivityForm : PatientBasePage
	{
		private Activity activity;
		private Patient patient;
		private PatientCoverage patientCoverage;
		private Problem problem;
		private BaseForEventCMSReferral erc;			// any one of these:  Event, CMS, Referral
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel RecordDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrimaryType;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PrimaryType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimaryType;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PlanId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PlanName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ActivityDescription;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DueDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityPriority;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityPriority;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityPriority;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCompletion;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityCompletionID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityCompletionID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityCompletionID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivitySubtypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivitySubtypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivitySubtypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompletionNote;
		protected NetsoftUSA.WebForms.OBValidator vldCompletionNote;
		protected NetsoftUSA.WebForms.OBTextBox CompletionNote;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityAmount;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityAmount;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ActivityAmount;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldManagementServiceRate;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ManagementServiceRate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbManagementServiceRate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTotalAmount;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit TotalAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTotalAmount;
		protected NetsoftUSA.WebForms.OBCheckBox IsBillable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIsBillable;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;

		protected TeamUserSelect TeamUserSelect1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ReferralID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferralID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProblemId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProblemId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProblemId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCMSID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEventID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EventID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldManagementServiceItemID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ManagementServiceItemID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbManagementServiceItemID;
		protected System.Web.UI.HtmlControls.HtmlTable tblMgmtSvc2;
		protected System.Web.UI.HtmlControls.HtmlTable tblMgmtSvc1;
		protected UserSelect UserSelect1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			this.TeamUserSelect1.RebindControls(typeof(Activity), "AssignedTeamID", "AssignedUserID");
			this.UserSelect1.RebindControls(typeof(Activity), "CompletedByUserID"); 

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadDataForActivity();			// Use load data method for data entry forms
			}
			else
			{
				activity = (Activity)this.LoadObject(typeof(Activity));  // load object from cache
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.PrimaryType.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.PrimaryType_SelectedRowChanged);
			this.ActivityCompletionID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.ActivityCompletionID_SelectedRowChanged);
			this.ManagementServiceItemID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.ManagementServiceItemID_SelectedRowChanged);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Details")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(PatientMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}

			// Menu items to be displayed on all tabs
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Activity Activity
		{
			get { return activity; }
			set
			{
				activity = value;
				try
				{
					this.UpdateFromObject(pnlDetails.Controls, activity);  // update controls for the given control collection
					this.UpdateFromObject(pnlCompletion.Controls, activity);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Activity), activity);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForActivity()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlDetails.Controls, activity);	// controls-to-object
				this.UpdateToObject(pnlCompletion.Controls, activity);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewActivity()
		{
			bool result = true;
			Activity activity = new Activity(this.patient, this.patientCoverage); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				if (problem != null)
				{
					activity.ProblemId = problem.ProblemID;
				}
				if (erc != null)
				{
					if (erc is Event)
						activity.EventID = erc.ID;
					else if (erc is CMS)
						activity.CMSID = erc.ID;
					else if (erc is Referral)					// i'm not sure of this
						activity.ReferralID = erc.ID;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Activity = activity;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForActivity()
		{
			bool result = true;
			Activity activity = null;
			try
			{	// use any load method here
				
				patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
				// get the passed patient subscriber coverage (link to patient)
				patientCoverage = GetParamOrGetFromCache("PatientCoverage", typeof(PatientCoverage)) as PatientCoverage;
				if (patientCoverage == null)	
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-coverage");

				problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
				erc = this.GetParamOrGetFromCache("ERC", typeof(BaseForEventCMSReferral)) as BaseForEventCMSReferral;

				// if event was not passed, create a new one
				activity = this.GetParamOrGetFromCache("Activity", typeof(Activity)) as Activity;
				if (activity == null)
					return NewActivity();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//activity.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			this.CacheObject(typeof(Patient), patient);
			this.CacheObject(typeof(PatientCoverage), patientCoverage);
			this.CacheObject(typeof(Problem), problem);
			this.CacheObject(typeof(BaseForEventCMSReferral), erc);

			this.Activity = activity;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, BaseForEventCMSReferral erc, Activity activity)
		{
			if (patient == null || patCov == null)
				throw new ActiveAdviceException("You can open an activity only when patient and coverage are selected"); 

			BasePage.PushCurrentCallingPage();

			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("ERC", erc);
			BasePage.PushParam("Activity", activity);
			BasePage.Redirect("ActivityForm.aspx");
		}

		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, BaseForEventCMSReferral erc, int activityID)
		{
			Activity activity = new Activity(patient, false);
			if (!activity.Load(activityID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@ACTIVITY@");
			Redirect(patient, patCov, problem, erc, activity);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForActivity()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForActivity())
					return false;
				activity.Save(this.patientCoverage); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveDataForActivity())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@ACTIVITY@");
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.erc);
		}

		private void PrimaryType_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			this.UpdateToObject(PrimaryType, this.activity);
			this.UpdateFromObject(ActivityTypeID, this.activity);
		}

		private void ActivityCompletionID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			string oldCompletionCode = this.activity.ActivityCompletionCode;
			this.UpdateToObject(ActivityCompletionID, this.activity);
			if (this.activity.ActivityCompletionCode == ActivityCompletion.COMPLETED)
			{
				if (oldCompletionCode != ActivityCompletion.COMPLETED)
				{
					this.activity.SetCompletingUser();
					this.UpdateFromObject(UserSelect1.Controls, this.activity);
				}
			}
			//this.UpdateFromObject(ActivityTypeID, this.activity);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			bool completed = (this.activity.ActivityCompletionCode == ActivityCompletion.COMPLETED);
			UserSelect1.Enabled = completed;
			ActivitySubtypeID.ReadOnly = !completed;
			CompletionDate.ReadOnly = !completed;
			CompletionNote.ReadOnly = !completed;

			this.RenderClientFunctions(pnlCompletion.Controls, this.activity, "OnCalculateCompletion");
		}

		private void ManagementServiceItemID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			// populate the management service item fields from the selected management service item
			this.UpdateToObject(this.tblMgmtSvc1.Controls, this.activity);
			this.UpdateToObject(this.tblMgmtSvc2.Controls, this.activity);
			this.activity.PullManagementServiceItemFields();
			this.UpdateFromObject(this.tblMgmtSvc1.Controls, this.activity);
			this.UpdateFromObject(this.tblMgmtSvc2.Controls, this.activity);
		}


	}
}
