using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for ContactForm.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.BaseMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Contact,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class ContactForm : ContactBasePage
	{
		private Contact contact;
		private IContactOwner contactOwner;
		private BaseData[] summaryObjects = null;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Title;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTitle;
		protected NetsoftUSA.InfragisticsWeb.WebCombo NamePrefixID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNamePrefixID;
		protected NetsoftUSA.WebForms.OBValidator vldLastName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ContactID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContactID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Company;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompany;
		protected NetsoftUSA.WebForms.OBValidator vldFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlContactInfo;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlRoles;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridRoles;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMiddleInitial;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDates;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAddress;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNameSuffix;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit NameSuffix;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNameSuffix;
		protected UserDefined UserDefined1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			UserDefined1.ReloadContext("Contact",contact,true);
			if (!this.IsPostBack)
				this.LoadData();			// Load data is the actual data loading method
			else
			{
				contact = (Contact)this.LoadObject(typeof(Contact));	// This would reload from cache
				contactOwner = (IContactOwner)this.LoadObject(typeof(IContactOwner), false);
				summaryObjects = (BaseData[])this.LoadObject("SummaryObjects", typeof(BaseData[]) ,false);
			}
			
		}

		public static void Redirect(IContactOwner contactOwner, Contact contact)
		{
			Redirect(contactOwner, contact, null);
		}

		public static void Redirect(IContactOwner contactOwner, Contact contact, BaseData[] summaryObjects)
		{
			BasePage.PushParam("CONTACTOWNER", contactOwner);
			BasePage.PushParam("CONTACT", contact);
			BasePage.PushParam("SUMMARYOBJECTS", contact);
			BasePage.Redirect("ContactForm.aspx");
		}

		public static void Redirect(IContactOwner contactOwner, int contactID)
		{
			Redirect(contactOwner, contactID, null);
		}

		public static void Redirect(IContactOwner contactOwner, int contactID, BaseData[] summaryObjects)
		{
			Contact contact = new Contact();
			if (!contact.Load(contactID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@CONTACT@");
			Redirect(contactOwner, contact, summaryObjects);
		}


		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			Contact contact = new Contact();
			try
			{	// use any load method here
				contact = this.GetParam("CONTACT") as Contact;
				if (contact == null)
				{
					contact = new Contact(true);
				}

				contactOwner = this.GetParam("CONTACTOWNER") as IContactOwner;
				summaryObjects = this.GetParam("SUMMARYOBJECTS") as BaseData[];
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//obj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Contact = contact;		// When you set the object to the property, controls are automatically populated
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				contact.Save(contactOwner); // update or insert to db
				contact.SaveContactRoles();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Contact Contact
		{
			get { return contact; }
			set
			{
				contact = value;
				try
				{
					
					// add all object-to-control population code here
					this.UpdateFromObject(pnlContactInfo.Controls, contact);  // update controls for the given control/collection
					this.UpdateFromObject(pnlNote.Controls, contact);  // update controls for the given control/collection
					this.UpdateFromObject(pnlAddress.Controls, contact.Address);  // update controls for the given control/collection
					this.UpdateFromObject(pnlDates.Controls, contact);

					contact.LoadContactRoles(false);

					RoleCollection roles = RoleCollection.GetRolesByContactOwnerTypeForSelection(contactOwner.ContactOwnerType);
					roles.SetSelectedRolesFromCollection(contact.ContactRoles);

					gridRoles.DisplayLayout.AllowUpdateDefault = Infragistics.WebUI.UltraWebGrid.AllowUpdate.Yes;
					gridRoles.UpdateFromCollection(roles);  // update given grid from the collection
					UserDefined1.ReloadContext("Contact",contact,false);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Contact), contact);  // cache object using the caching method declared on the page
				this.CacheObject(typeof(IContactOwner), contactOwner);  // cache object using the caching method declared on the page
				this.CacheObject("SummaryObjects", summaryObjects);
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	// add all control-to-object population code here
				this.UpdateToObject(pnlContactInfo.Controls, contact);  // controls-to-object
				this.UpdateToObject(pnlAddress.Controls, contact.Address);  // controls-to-object
				this.UpdateToObject(pnlNote.Controls, contact);
				this.UpdateToObject(pnlDates.Controls, contact);

				RoleCollection roles = RoleCollection.GetRolesByContactOwnerTypeForSelection(contactOwner.ContactOwnerType);
				roles.SetSelectedRolesFromCollection(contact.ContactRoles);
				gridRoles.UpdateToCollection(roles);
				contact.ContactRoles.SynchronizeRolesFromSelectableCollection(contact.ContactID, roles);
				UserDefined1.ReadControls();
				contact.UserDefined = UserDefined1.UserDefinedValue;
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "ContactTab")
			{
				toolbar.AddButton(BaseMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}

		}


		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}


		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
		}

		public override void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick (toolbar, button);
		}


		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.Contact = new Contact(true);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@CONTACT@");
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			if (summaryObjects != null)
				pageSummary.RenderObjects(summaryObjects);
			else
				pageSummary.RenderObjects((BaseData)contactOwner, this.Contact);
		}


	}
}
