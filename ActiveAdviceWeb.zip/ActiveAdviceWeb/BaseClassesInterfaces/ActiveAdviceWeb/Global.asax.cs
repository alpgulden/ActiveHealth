using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;
using NetsoftUSA.DataLayer;
using NetsoftUSA.Security;
using NetsoftUSA.WebForms;
using NetsoftUSA.InfragisticsWeb;

namespace ActiveAdviceWeb 
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public class Global : WebApplication
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		public Global()
		{
			InitializeComponent();
		}	
		

		protected override void EnsureConfiguration()
		{
			base.EnsureConfiguration ();
			NSGlobal.ConnectionString = WebApplication.ConnectionString;
			//OBValidator.ValidationErrorMarker = "<img src='pics/VldErr.gif'>";
			OBValidator.ValidationErrorMarker = "<span style=\"color:red;font-size:12pt;\">!</span>";
			WebGrid.EditButtonText = "Edit"; //<img src='pics/edit.gif'>";
			WebGrid.CssClassForSelectedRows = "GridSelectedRows";
			WebGrid.SelectedRowIconHTML = "<img src=pics/selectedRow.gif>";
			WebNumericEdit.CssClassForReadOnly = "readOnlyTextBox";
			WebTextEdit.CssClassForReadOnly = "readOnlyTextBox";
			OBCheckBox.BindTextsToDescriptions = true;

			OBTextBox.CssClassEditable = "textarea";

			PageMessage.CssClassErrorAll = "PageMessageError";
			PageMessage.CssClassInfoAll = "PageMessageInfo";
			PageMessage.CssClassWarningAll = "PageMessageWarning";

			OBButton.CssAll = "RegularButton";
		}



		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
		}
		#endregion
	}
}

