using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.GroupPracticeMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("GroupPracticeType,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class GroupPracticeTypeForm : CodeBasePage
	{
		private	  GroupPracticeType obj;
		private   GroupPracticeTypeCollection objCol;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEdit;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGrid;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGroupPracticeTypeDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit GroupPracticeTypeDescription;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeTypeDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGroupPracticeTypeCode;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit GroupPracticeTypeCode;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeTypeCode;
		protected NetsoftUSA.WebForms.OBValidator vldNote;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGroupPracticeTypes;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;



		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
				this.LoadData();			// Load data is the actual data loading method
			else
			{
				objCol = (GroupPracticeTypeCollection)this.LoadObject(typeof(GroupPracticeTypeCollection));
				obj    = (GroupPracticeType)this.LoadObject(typeof(GroupPracticeType));
			}
		}

		public static void Redirect(GroupPracticeType GroupPracticeType)
		{
			
			BasePage.PushParam("GroupPracticeType", GroupPracticeType);
			BasePage.Redirect("GroupPracticeType.aspx");
		}



		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			
			bool result					= true;
			LoadGrid();
			GroupPracticeType obj				= new GroupPracticeType();
			try
			{	// use any load method here
				this.obj = BasePage.PullParam("GroupPracticeType") as GroupPracticeType;
				if (obj == null)
				{
					obj = new GroupPracticeType();
					obj.New();
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			this.pnlEdit.Visible = false;
			return result;
		}


		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	
				if (!this.ReadControls())
					return false;
				obj.Save(); // update or insert to db
				ReLoadGrid();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public GroupPracticeTypeCollection GroupPracticeTypeCollection
		{
			get { return this.objCol; }
			set 
			{
				this.objCol = value;
				try
				{	
					this.gridGroupPracticeTypes.UpdateFromCollection(objCol);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject(typeof(GroupPracticeTypeCollection), objCol);
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeType GroupPracticeType
		{
			
			get { return obj; }
			set
			{
				obj = value;
				try
				{
					this.UpdateFromObject(this.pnlEdit.Controls, obj);  // update controls for the given control/collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(GroupPracticeType), obj);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	this.UpdateToObject(pnlEdit.Controls, this.obj);
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.gridGroupPracticeTypes.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridGroupPracticeTypes_DblClick);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void butClearSharedCache_Click(object sender, System.EventArgs e)
		{
			NSGlobal.ClearCache();
		}

		/*private void RenderSummary()
		{
			this.RenderSummaryForObjects(this.obj, this.obj2);
		}*/

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);

			
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@SAVERECORD@", "SaveType");
			toolbar.AddButton("@CANCEL@", "Cancel");
			

		}


		public override void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick (toolbar, button);
			//button.Key == "Save"
		}

		public void OnToolbarButtonClick_SaveType(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@GroupPracticeTYPE@");
				this.pnlEdit.Visible = false;
				this.pnlGrid.Visible = true;
			}
		}

		public void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.obj			 = new GroupPracticeType();
			this.pnlGrid.Visible = true;
			this.pnlEdit.Visible = false;
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("Add New", "AddNew");

		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.GroupPracticeType				= new GroupPracticeType();
			this.GroupPracticeType.New();
			this.pnlEdit.Visible				= true;
			this.pnlGrid.Visible				= false;

		}


		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
		}

		private void gridGroupPracticeTypes_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			if (e.Cell != null)
			{
				int index				= (int)e.Cell.Row.DataKey;
				this.GroupPracticeType		= this.objCol[index];
				this.pnlEdit.Visible	= true;
				this.pnlGrid.Visible    = false;
			}
			else if (e.Row != null)
			{
				int rowindex			= (int)e.Row.DataKey;
				this.GroupPracticeType		= this.objCol[rowindex];
				this.pnlEdit.Visible	= true;
				this.pnlGrid.Visible	= false;
			}
		}

		private void ReLoadGrid()
		{
			LoadGrid();
		}

		private void LoadGrid()
		{
			GroupPracticeTypeCollection grpCol = new GroupPracticeTypeCollection();
			grpCol.LoadAll();
			this.GroupPracticeTypeCollection   = grpCol;
		}

	}
}
