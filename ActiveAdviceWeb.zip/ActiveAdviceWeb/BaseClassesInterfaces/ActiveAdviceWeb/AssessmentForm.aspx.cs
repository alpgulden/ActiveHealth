using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{

	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Assessment,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class AssessmentForm : AssessmentBasePage
	{
		private Questionnaire questionnaire;  // filter object
		private AssessmentQuestionnaireOrderCollection assessmentQuestionnaireOrders;
		private QuestionnaireCollection availableQuestionnaires;
		private Assessment assessment;
		private CMS cMS;
		private ArrayList errorMessages;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFilter;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridAvailable;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSelected;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionnaireTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo QuestionnaireTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionnaireTypeID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridAvailable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridSelected;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

			
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.QuestionnaireTypeID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.QuestionnaireTypeID_SelectedRowChanged);

			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				LoadData();			// Use load data method for data entry forms
			}		
			else
			{
				cMS = (CMS)this.LoadObject(typeof(CMS));
				assessment = (Assessment)this.LoadObject(typeof(Assessment));  // load object from cache
				availableQuestionnaires = (QuestionnaireCollection)this.LoadObject(typeof(QuestionnaireCollection));  // load object from cache
				assessmentQuestionnaireOrders = (AssessmentQuestionnaireOrderCollection)this.LoadObject(typeof(AssessmentQuestionnaireOrderCollection));  // load object from cache
				questionnaire = (Questionnaire)this.LoadObject(typeof(Questionnaire));  // load object from cache
			}
		}


		public static void Redirect(AssessmentContext assessmentContext)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("AssessmentContext", assessmentContext);			
			BasePage.Redirect("AssessmentForm.aspx");
		}

		private void LoadData()
		{
			if (assessmentContext == null)
			{
				this.RaisePageException (new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an Assessment"));
				return;
			}
			
			this.cMS = assessmentContext.CMS;
			this.CacheObject(typeof(CMS), cMS);

			this.assessment = assessmentContext.Assessment;
			this.CacheObject(typeof(Assessment), assessment);

			NewQuestionnaire();
			LoadDataForAssessmentQuestionnaireOrders();  // Load Selected Questionnaires of this.Assessment
			LoadDataForAvailableQuestionnaires();		 // Load All available Questionnaires filtered by this.questionnaire
			if(AssessmentQuestionnaireOrders.Count == 0)
			{	// Preselect Questionnaires based on Dx/Px ONLY when page is loaded initially AND no questionnaires have been selected
				// Scenario for creation of a new Assessment.
				LoadDataForAssessmentQuestionnaireOrdersByDxPx();
				availableQuestionnaires.SetSelectedQuestionnairesFromCollection(AssessmentQuestionnaireOrders);
				this.AvailableQuestionnaires = availableQuestionnaires;
			}
		}

		#region UI Initialization and events
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			//if (tab.Key == "Questionaires")
			//{}
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save");
			toolbar.AddButton("@RETURNTOASSESSMENT@", "Return");

		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{			
			if (ReadControlsForAvailableQuestionnaires() & ReadControlsForAssessmentQuestionnaireOrders())
			{
				errorMessages = new ArrayList(); // used to pass possible errors from SynchronizeFromSelectableCollection back to page
				try
				{
					if (! assessmentQuestionnaireOrders.SynchronizeFromSelectableCollection(Assessment.AssessmentGUID, AvailableQuestionnaires, errorMessages, this.cMS))
					{	// display errors that occured during Synchronization
						foreach (Object obj in errorMessages)
						{
							this.SetPageMessage(obj.ToString(), EnumPageMessageType.AddWarning);
						}
						AvailableQuestionnaires = AvailableQuestionnaires; // restore Selected checkbox visual status
					}
				
					AssessmentQuestionnaireOrders.Save();
					this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Questionnaires "); 
					AssessmentQuestionnaireOrders = assessmentQuestionnaireOrders;
				}
				catch(Exception ex)
				{
					this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, ex.ToString()));
				}
			}
		}

		public void OnToolbarButtonClick_Return(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{	
			// redirect to AssessmentView.aspx
			AssessmentView.Redirect(this.cMS, this.assessment);
		}
		
		private void QuestionnaireTypeID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			LoadDataForAvailableQuestionnaires();
		}
		#endregion

		#region Data Objects
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Assessment Assessment
		{
			get { return assessment; }
			set
			{
				assessment = value;
				this.CacheObject(typeof(Assessment), assessment);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public QuestionnaireCollection AvailableQuestionnaires
		{
			get { return availableQuestionnaires; }
			set
			{
				availableQuestionnaires = value;
				try
				{
					gridAvailable.UpdateFromCollection(availableQuestionnaires);  // update given grid from the collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(QuestionnaireCollection), availableQuestionnaires);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAvailableQuestionnaires()
		{
			try
			{	//customize this method for this specific page
				gridAvailable.UpdateToCollection(availableQuestionnaires);	// grid-to-collection
				//return this.IsValid;	// Return validation result
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForAvailableQuestionnaires()
		{
			bool result = true;
			QuestionnaireCollection availableQuestionnaires = new QuestionnaireCollection();
			try
			{	// use any load method here
				ReadControlsForQuestionnaire(); // filter object which sets CMSType
				
				// ALWAYS present available questionnaires based on Organization links
				// IF No Questionnaries are available through Organization links show ALL questionnaires by given filter criteria

				// Creating new Questionnare Organization Searcher Object from CMS
				QuestionnaireOrganizationSearcher qos = new QuestionnaireOrganizationSearcher(this.cMS, Questionnaire.ContentOwnerID, Questionnaire.CMSTypeID, Questionnaire.QuestionnaireTypeID);
				availableQuestionnaires = QuestionnaireCollection.GetQuestionnairesByOrganization(qos);
				if(availableQuestionnaires.Count == 0) 
					availableQuestionnaires = QuestionnaireCollection.GetQuestionnairesForSelection(Questionnaire);
				availableQuestionnaires.SetSelectedQuestionnairesFromCollection(AssessmentQuestionnaireOrders);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.AvailableQuestionnaires = availableQuestionnaires;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentQuestionnaireOrderCollection AssessmentQuestionnaireOrders
		{
			get { return assessmentQuestionnaireOrders; }
			set
			{
				assessmentQuestionnaireOrders = value;
				try
				{
					this.gridSelected.UpdateFromCollection(assessmentQuestionnaireOrders);  // update given grid from the collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AssessmentQuestionnaireOrderCollection), assessmentQuestionnaireOrders);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForAssessmentQuestionnaireOrders()
		{
			bool result = true;
			AssessmentQuestionnaireOrderCollection assessmentQuestionnaireOrders = new AssessmentQuestionnaireOrderCollection();
			try
			{	
				assessmentQuestionnaireOrders.LoadAssessmentQuestionnaireOrders(assessment.AssessmentGUID);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.AssessmentQuestionnaireOrders = assessmentQuestionnaireOrders;
			return result;
		}

		/// <summary>
		/// Load AssessmentQuestionnaireOrders based on Dx/Px specified
		/// Works only on empty collection.
		/// Should be called ONLY on initial page load.
		/// </summary>
		private void LoadDataForAssessmentQuestionnaireOrdersByDxPx()
		{
			if (AssessmentQuestionnaireOrders.Count > 0)
				return;
			
			AssessmentQuestionnaireOrderCollection assessmentQuestionnaireOrders = new AssessmentQuestionnaireOrderCollection();
			try
			{
				assessmentQuestionnaireOrders.SelectByDxPx(this.cMS, AvailableQuestionnaires, Assessment.AssessmentGUID);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
			
			this.AssessmentQuestionnaireOrders = assessmentQuestionnaireOrders;
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAssessmentQuestionnaireOrders()
		{
			try
			{	//customize this method for this specific page
				gridSelected.UpdateToCollection(assessmentQuestionnaireOrders);
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Questionnaire Questionnaire
		{
			get { return questionnaire; }
			set
			{
				questionnaire = value;
				try
				{
					this.UpdateFromObject(this.pnlFilter.Controls, questionnaire);  // update controls for the given control collection
					if (!this.IsPostBack)
						this.QuestionnaireTypeID.SelectedRow = this.QuestionnaireTypeID.Rows[0];
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Questionnaire), questionnaire);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForQuestionnaire()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlFilter.Controls, questionnaire);	// controls-to-object
				if (questionnaire.QuestionnaireTypeID == -1) // -1 represents [ALL]
					questionnaire.QuestionnaireTypeID = 0;
				this.Questionnaire = questionnaire;
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewQuestionnaire()
		{
			bool result = true;
			Questionnaire questionnaire = null; //new Questionnaire(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				questionnaire = new Questionnaire();
				questionnaire.QuestionnaireTypeID = -1; //setting default.
				questionnaire.ContentOwnerID = Assessment.ContentOwnerID;
				questionnaire.ActiveWithAll = 1; // Always working with active Questionnaires
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.Questionnaire = questionnaire;
			return result;
		}
		#endregion
	}
}
