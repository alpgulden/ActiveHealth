using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.BaseCodeTypeMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseLookup,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class CodeTypeFormForLookup : CodeBasePage
	{
		private BaseLookup searchObj;
		private	  BaseLookup obj;
		private   BaseTypeCollection objCol;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGrid;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFocus;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlInfo;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEdit;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCodeTypes;
		protected NetsoftUSA.WebForms.OBValidator vldDescription;
		protected NetsoftUSA.WebForms.OBTextBox Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.WebForms.OBCheckBox OBCheckBox1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.WebForms.OBTextBox OBTextBox1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSearch;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNotepad;
		protected NetsoftUSA.WebForms.OBTextBox Notepad;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;



		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
				this.LoadData();			// Load data is the actual data loading method
			else
			{
				this.obj		= (BaseLookup)this.LoadObject("CodeTypeForLookup");
				this.objCol		= (BaseTypeCollection)this.LoadObject("CodeTypeForLookupCollection");			
				this.searchObj	= (BaseLookup)this.LoadObject("SearchObj");
			}
		}



		public static void Redirect(Type type)
		{
			if (typeof(PlanType) == type)
			{
				PlanTypeCollection planTypeCol = new PlanTypeCollection();
				BasePage.PushParam("Type", planTypeCol );
				BasePage.Redirect("CodeTypeFormForLookup.aspx");
			}
			/* -- REMOVED
			 * else if (typeof(PlanPayorType) == type)
			{
				PlanPayorTypeCollection planPayorCol = new PlanPayorTypeCollection();
				BasePage.PushParam("Type", planPayorCol);
				BasePage.Redirect("CodeTypeFormForLookup.aspx");
			}*/
			else if (typeof(PlanMaternichekIncentive) == type)
			{
				PlanMaternichekIncentiveCollection planIncentiveCol = new PlanMaternichekIncentiveCollection();
				BasePage.PushParam("Type", planIncentiveCol);
				BasePage.Redirect("CodeTypeFormForLookup.aspx");
			}
			else
			{
				Debug.Fail("Invalid FocusType");
			}
		}



		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			BaseTypeCollection  baseCodeCol	= BasePage.PullParam("Type") as BaseTypeCollection;
			if (baseCodeCol == null)
			{
				this.pnlGrid.Visible	= false;
				this.pnlInfo.Visible	= true;
				this.pnlSearch.Visible	= false;
				// disable buttons
				//((Button)this.PageToolbar.FindControl("AddNew")).Visible = false;
			}
			else
			{
				this.obj					= (BaseLookup)Activator.CreateInstance(baseCodeCol.ElementType);
				if (this.searchObj == null)
				{
					baseCodeCol.LoadAll();
					this.BaseTypeCollection = baseCodeCol;
					this.SearchObj			= new  BaseLookup();
				}

				this.pnlGrid.Visible		= true;
				this.pnlInfo.Visible		= false;
				this.pnlSearch.Visible		= true;
				// enable buttons
				//((Button)this.PageToolbar.FindControl("AddNew")).Visible = true;
				//((Button)this.
			}
			this.pnlEdit.Visible = false;
			return result;
		}


		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	
				// check if the record is read-only
				if (!this.BaseLookup.ReadOnly)
				{
					// data from controls to object
					if (!this.ReadControls())
						return false;
					this.obj.Save(); // update or insert to db
					this.searchObj = null;
					this.pnlSearch.Visible = true;
					// refresh grid.
					ReloadGrid();
					return true;
				}
				else
				{
					this.RaisePageException(new Exception("@READONLY@"));
					return false;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BaseLookup BaseLookup
		{
			get { return this.obj; }
			set 
			{
				this.obj = value;
				try
				{
					this.UpdateFromObject(pnlEdit.Controls, this.obj);
					this.pnlEdit.Visible = true;
					this.pnlGrid.Visible = false;
					this.pnlSearch.Visible = false;
					pnlEdit.Enabled  = (this.BaseLookup.ReadOnly) ? false : true;
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("CodeTypeForLookup", this.obj);
			}
		}

		public BaseTypeCollection BaseTypeCollection
		{
			get { return this.objCol; }
			set 
			{
				try
				{
					this.objCol				= value;
					objCol.ElementType      = value.ElementType;
					this.pnlGrid.Visible	= true;
					this.gridCodeTypes.UpdateFromCollection(this.objCol);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("CodeTypeForLookupCollection", this.objCol);
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	// add all control-to-object population code here
				this.UpdateToObject(pnlEdit.Controls, obj);  // controls-to-object
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.gridCodeTypes.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridCodeTypes_DblClick);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);

			
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@SAVERECORD@", "SaveType", true, false);
			toolbar.AddButton("@DELETE@", "DeleteType", false, false);
			toolbar.AddButton("@CANCEL@", "Cancel", false, true);
			

		}


		public override void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick (toolbar, button);
			//button.Key == "Save"
		}

		public void OnToolbarButtonClick_DeleteType(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			try
			{
				if (!this.BaseLookup.ReadOnly)
				{
					this.BaseLookup.Delete((int)this.BaseLookup.PK[0]);
					ReloadGrid();				
					this.pnlEdit.Visible = false;
					this.pnlGrid.Visible = true;
				}
				else
				{
					this.RaisePageException(new Exception("@READONLY@"));
					return;
				}

			}
			catch (SqlException ex)
			{
				this.RaisePageException(new Exception("This code is being referenced by other records and cannot be deleted. Please delete referenced records and try again"));								
			}			
		}

		public void OnToolbarButtonClick_SaveType(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@CODETYPE@");
				this.pnlEdit.Visible = false;
				this.pnlGrid.Visible = true;
			}
		}
//
//		public void  OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
//		{
//			CodeTypeFormForLookup.Redirect(this.obj.GetType());
//		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("Add New", "AddNew");
			toolbar.AddButton("@NEWSEARCH@", "NewSearch");
		}

		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BaseLookup baseLookup = (BaseLookup)Activator.CreateInstance(this.objCol.ElementType);
			baseLookup.New();
			this.BaseLookup     	= baseLookup;
			this.pnlEdit.Visible	= true;
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{

			BaseLookup baseFocus = (BaseLookup)Activator.CreateInstance(this.objCol.ElementType);
			baseFocus.New();
			this.BaseLookup		= baseFocus;
			this.pnlEdit.Visible	= true;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
		}

		protected void gridCodeTypes_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			if (e.Cell != null)
			{
				int index				= (int)e.Cell.Row.DataKey;
				this.BaseLookup 		= (BaseLookup)this.objCol.GetAt(index);
				this.pnlEdit.Visible	= true;
				this.pnlGrid.Visible    = false;
			}
			else if (e.Row != null)
			{
				int rowindex			= (int)e.Row.DataKey;
				this.BaseLookup		= (BaseLookup)this.objCol.GetAt(rowindex);
				this.pnlEdit.Visible	= true;
				this.pnlGrid.Visible	= false;
			}
		}

		private void ReloadGrid()
		{
			BaseTypeCollection.LoadAll();
			this.BaseTypeCollection = BaseTypeCollection;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BaseLookup SearchObj
		{
			get { return searchObj; }
			set
			{
				searchObj = value;
				try
				{
					this.UpdateFromObject(this.Controls, searchObj);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("SearchObj", searchObj);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearchObj()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.Controls, searchObj);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchObj()
		{
			bool result = true;
			BaseLookup searchObj = new BaseLookup(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchObj.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchObj = searchObj;
			return result;
		}

		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			BaseTypeCollection searchResults = (BaseTypeCollection)Activator.CreateInstance(this.objCol.GetType());
			this.UpdateToObject(this.pnlSearch.Controls, this.searchObj, false);
			searchResults.SearchCodeTypes(null, this.searchObj.Description, this.searchObj.Active);
			this.BaseTypeCollection = searchResults;
		}




	}
}
