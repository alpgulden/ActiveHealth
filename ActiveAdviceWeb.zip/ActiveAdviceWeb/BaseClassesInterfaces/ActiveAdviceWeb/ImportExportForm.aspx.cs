using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class ImportExportForm : BasePage
	{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlTasks;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridTasks;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMemberLog;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFileName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FileName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFileName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.WebControls.RadioButtonList rdOrganizationType;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridOrganization;
		protected NetsoftUSA.WebForms.OBLabel Oblabel12;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEligibility;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.WebForms.OBLabel Oblabel2;
		protected NetsoftUSA.WebForms.OBLabel Oblabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlScoringLoad;
		protected NetsoftUSA.WebForms.OBLabel Oblabel4;
		protected NetsoftUSA.WebForms.OBLabel Oblabel5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProvider;
		protected NetsoftUSA.WebForms.OBLabel Oblabel6;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAuthorization;
		protected NetsoftUSA.WebForms.OBLabel Oblabel7;
		protected System.Web.UI.WebControls.CheckBoxList chkTypes;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Webtextedit2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator2;
		protected System.Web.UI.WebControls.DropDownList ddlTypes;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator3;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator4;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit4;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridMorgList;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;


		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				ScheduleTaskCollection scheduleTasks = this.GetAllScheduleTasks();
				if (null != scheduleTasks)
					this.gridTasks.UpdateFromCollection(scheduleTasks);

				rdOrganizationType.Items.Add("MORG");
				rdOrganizationType.Items.Add("ORG");
				rdOrganizationType.Items.Add("SORG");

				rdOrganizationType.Items[0].Selected = true; // set MORG to selected

				OrganizationSummaryCollection organizationSummaryCol = this.RetrieveOrganization(1);

				gridOrganization.UpdateFromCollection(organizationSummaryCol);

				this.chkTypes.Items.Add("Events");
				this.chkTypes.Items.Add("Referrals");

				{
					ScheduleTypeCollection scheduleTypes		= new ScheduleTypeCollection();
					scheduleTypes.LoadScheduleTypeByActive(-1, true);
					ScheduleStatusCollection scheduleStatuses	= new ScheduleStatusCollection();
					scheduleStatuses.LoadScheduleStatusByActive(-1, true);
					this.ddlTypes.Items.Add(new ListItem("<ALL>", "0") );
					for (int i = 0; i < scheduleTypes.Count; i++)
					{
						ListItem itm = new ListItem(scheduleTypes[i].Description, scheduleTypes[i].ScheduleTypeID.ToString());
						this.ddlTypes.Items.Add(itm);
					}
				}
				SetPageToolbarItemVisible("Save", true);
				SetPageToolbarItemVisible("Cancel", true);			

				//this.LoadData();			// Use load data method for data entry forms
				//this.NewMORGSearch();		// Use such a method for search pages
			}
			else
			{
				// always load all server side objects from the cache
				//col = (MORGCollection)this.LoadObject(typeof(MORGCollection));	// This would reload from cache
				// searchers must cache and read from a different key than the class name
				//morgSearcher = (MORG)this.LoadObject("MORGSearcher");

				int i = rdOrganizationType.SelectedIndex;
				int level = 3;
				switch(rdOrganizationType.Items[i].Text)
				{
					case "MORG":
						level = 1; break;
					case "ORG":
						level = 2; break;
					default:
						break;
				}
				OrganizationSummaryCollection organizationSummaryCol = this.RetrieveOrganization(level);
				gridOrganization.UpdateFromCollection(organizationSummaryCol);

			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@SAVERECORD@", "Save").Visible = true;
			toolbar.AddButton("@CANCEL@", "Cancel").Visible   = true;
		}

		/// <summary>
		/// RetrieveOrganization()
		/// retrieves the list of all MORGs or ORGs or SORGs
		/// based on the input argument
		/// </summary>
		/// <param name="level">int, 1=MORG, 2=ORG, 3=SORG</param>
		/// <returns></returns>
		private OrganizationSummaryCollection RetrieveOrganization(int level)
		{
			OrganizationSummaryCollection organizationSummaryCol = new OrganizationSummaryCollection();
			if (organizationSummaryCol.GetOrganizationsByLevel(-1,level) > 0)
				return organizationSummaryCol;

			return null;
		}

		protected OrganizationSummaryCollection organizationSummaryCol = null;
		public OrganizationSummaryCollection OrgList
		{
			get { return organizationSummaryCol; }
			set
			{
				try
				{
					organizationSummaryCol = value;
					if(organizationSummaryCol == null)
						gridOrganization.UpdateFromCollection(null);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(OrganizationSummaryCollection), organizationSummaryCol);  // cache object using the caching method declared on the page
			}
		}
		
		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			HttpContext.Current.Response.Redirect("Redirect method must redirect to its own page.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
//		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
//		{
//			base.PopulateToolbarItems (toolbar);
//
//			//toolbar.AddPreset(ToolbarButtons.Cancel);
//			toolbar.AddButton("@CANCEL@", "Cancel");
//		}

		/* Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMORGSearch();
		}
		*/

		/// <summary>
		/// GetPendingScheduleTask()
		/// This method will return the first, pending schedule task
		/// from the schedule list.
		/// </summary>
		/// <returns>ScheduleTask, instance of a ScheduleTask that is pending</returns>
		protected ScheduleTaskCollection GetAllScheduleTasks()
		{
			try
			{
				ScheduleTaskCollection scheduleTasks	= new ScheduleTaskCollection();
				scheduleTasks.LoadScheduleTasks(-1);
				if (scheduleTasks.Count > 0)
					return scheduleTasks;
			}
			catch(Exception e)
			{
				string msg = e.Message;
			}

			return null;
		}	
	}// end of class
}// end of namespace
