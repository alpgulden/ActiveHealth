using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseDxPx,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class DXPXForm : PatientBasePage
	{
		private EventReferralDiagnoseCollection erds;
		private EventReferralProcedureCollection erps;

		private Patient patient;
		private Problem problem;
		private PatientCoverage patientCoverage;
		private BaseForEventCMSReferral erc;			// any one of these:  Event, CMS, Referral

		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnPx;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSelectedDXCodes;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSelectedPXCodes;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDx;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlZippyCoder;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache

				erds = erc.EventReferralDiagnoses;
				erps = erc.EventReferralProcedures;
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			try
			{	
				PageTab.SelectedTabKey = this.TargetTabKey;		// navigate to target tab.

				// use any load method here
				// or pull from the parameter passed to this page via PushParam
				patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
				// get the passed patient subscriber coverage (link to patient)
				patientCoverage = GetParamOrGetFromCache("PatientCoverage", typeof(PatientCoverage)) as PatientCoverage;
				if (patientCoverage == null)	
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-subscriber-coverage");
				problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
				//if (problem == null)	
				//	throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");					

				// if event was not passed, create a new one
				erc = this.GetParamOrGetFromCache("ERC", typeof(BaseForEventCMSReferral)) as BaseForEventCMSReferral;
				if (erc == null)
				{
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an event/referral/CMS");
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
			finally
			{
				//eventObj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CacheObject(typeof(Patient), patient);
			this.CacheObject(typeof(PatientCoverage), patientCoverage);
			this.CacheObject(typeof(Problem), problem);
			this.CacheObject(typeof(BaseForEventCMSReferral), erc);
			return LoadDataForDXPXs();
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, BaseForEventCMSReferral erc)
		{
			if (patient == null || patCov == null)
				throw new ActiveAdviceException("You can open Dx/Px only in the context of patient and coverage and event/referral/cms"); 

			BasePage.PushCurrentCallingPage();
			
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("ERC", erc);
			BasePage.Redirect("DXPXForm.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(BaseForEventCMSReferral erc)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("ERC", erc);
			BasePage.Redirect("DXPXForm.aspx");
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EventReferralDiagnoseCollection EventReferralDiagnoseCol
		{
			get { return erds; }
			set	
			{ 
				try
				{
					erds = value;
					gridSelectedDXCodes.UpdateFromCollection(erds);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
			}
		}
				
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EventReferralProcedureCollection EventReferralProcedureCol
		{
			get { return erps; }
			set	{ 
				try
				{
					erps = value;
					gridSelectedPXCodes.UpdateFromCollection(erps);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			this.wbtnPx.Click += new System.EventHandler(this.wbtnPx_Click);
			this.wbtnDx.Click += new System.EventHandler(this.wbtnDx_Click);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{			
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

//			// Menu items to be displayed on specific tabs
//			if (tab.Key == "DXPX_DXPX")
//			{
//				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
//				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
//			}
//
//			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			//toolbar.AddButton("@CANCEL@", "Cancel");
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForDXPXs()
		{
			bool result = true;
			try
			{	// use any load method here
				erc.LoadEventReferralDiagnoses(true);
				erds = erc.EventReferralDiagnoses;
				erc.LoadEventReferralProcedures(true);
				erps = erc.EventReferralProcedures;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//outcomes.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.EventReferralDiagnoseCol = erds;
			this.EventReferralProcedureCol = erps;
			return result;
		}

		private void wbtnDx_Click(object sender, System.EventArgs e)
		{
			try
			{
				ZippyCoderForm.Redirect(erc,erc.CreateDiagnosticSelectionCollection());
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void wbtnPx_Click(object sender, System.EventArgs e)
		{
			try
			{
				ZippyCoderForm.Redirect(erc,erc.CreateProcedureSelectionCollection());
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.SetERCTabVisibilities();
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.erc);
		}

	}
}
