using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.FacilityMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Facility,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class FacilitySearch : ProviderBasePage
	{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearchName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResults;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected System.Web.UI.WebControls.RadioButtonList rdSearchBy;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		[FieldValuesMember("ValuesOf_Name")]
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit GroupPracticeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCity;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit City;
		protected NetsoftUSA.WebForms.OBFieldLabel lbState;
		protected NetsoftUSA.WebForms.OBFieldLabel lbZip;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit Zip;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCounty;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit County;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GroupPracticeServiceTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GroupPracticeFocusTypeID;
		protected System.Web.UI.HtmlControls.HtmlTable tblName;
		protected System.Web.UI.HtmlControls.HtmlTable tblIDs;
		protected System.Web.UI.HtmlControls.HtmlTable tblIDs2;
		protected System.Web.UI.HtmlControls.HtmlTable tblGroupPracticeType;
		protected System.Web.UI.HtmlControls.HtmlTable tblID1;
		protected System.Web.UI.HtmlControls.HtmlTable tblID2;
		protected System.Web.UI.HtmlControls.HtmlTable tblID3;
		protected System.Web.UI.HtmlControls.HtmlTable tblAddress;
		//protected System.Web.UI.HtmlControls.HtmlTable tblDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFacilityID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit FacilityID;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacility;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit UPIN;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUPIN;
		protected NetsoftUSA.WebForms.OBLabel lbNetwork;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityNetworkTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityLocationNetworkID;
		
		protected NetsoftUSA.WebForms.OBLabel lbFacilityFocusID;
		protected NetsoftUSA.WebForms.OBValidator vldFacilityLocationServiceTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityLocationServiceTypeID;
		protected NetsoftUSA.WebForms.OBLabel lbFacilityLocationServiceTypeID;
		protected NetsoftUSA.WebForms.OBValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFacilityTypeID;
		protected NetsoftUSA.WebForms.OBValidator vldFacilityTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private NetworkPlanLink searchNetworkPlanLink;
		private FacilityLocationNetworkLink searchFacilityNetworkLink;
		private Location facilityLocationSearch;
		private FacilityLocationCollection locationSearchResults;
		private FacilityCollection facilitySearchResults;
		//private FAcLanguage searchLanguage;
		private FacilityLocationService searchFacilityLocationService;
		private FacilityFocus searchFacilityFocus; 
		private FacilityFocusCollection facilityFocusResults;
		private Facility searchFacilityInfo;
		private FacilityCollection searchFacilityResults;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkInfo;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacilityType;
		protected System.Web.UI.HtmlControls.HtmlTable tblFocus;
		protected System.Web.UI.HtmlControls.HtmlTable tblServices;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldState;
		protected NetsoftUSA.InfragisticsWeb.WebCombo State;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo NetworkSearchID;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSearchName;
		protected NetsoftUSA.InfragisticsWeb.WebGrid GridFacilities;	
		protected NetsoftUSA.InfragisticsWeb.WebGrid GridNetworks;
		private Address searchFacilityAddress;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResults2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNetworks;
		protected NetsoftUSA.InfragisticsWeb.WebGrid GridFacilityLocations;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
		protected System.Web.UI.WebControls.RadioButtonList lstNetworkSearch;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FederalTaxID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMedicareID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MedicareID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnFacilityID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnFacilityName;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnLocationID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnLocationDescription;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnTypeID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnTypeDescription;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkDescription;
		private   int  selectWidth = 65;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnPhone; 
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatus;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatusDescriptionIn;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatusDescriptionOut;
		protected NetsoftUSA.WebForms.OBLabel Oblabel12;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNetwokSearchID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo NetwokSearchID;
		protected NetsoftUSA.WebForms.OBValidator vldName;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnFlag;
		private PatientCoverage patCov;


		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				TranslateNames();				
				this.LoadData();			// Use load data method for data entry forms
				//this.NewMORGSearch();		// Use such a method for search pages
			}
			else
			{
				searchFacilityInfo = (Facility)this.LoadObject("BasicInfo");  // load object from cache
				searchFacilityAddress = (Address)this.LoadObject("AddressInfo");  // load object from cache
				searchFacilityFocus = (FacilityFocus)this.LoadObject("FocusInfo");  // load object from cache

				patCov = (PatientCoverage)this.LoadObject(typeof(PatientCoverage), false);  // load object from cache

				searchFacilityLocationService  = (FacilityLocationService)this.LoadObject("ServiceInfo");  // load object from cache
				facilitySearchResults = (FacilityCollection)this.LoadObject("FacilitySearchResults");  // load object from cache
				locationSearchResults = (FacilityLocationCollection)this.LoadObject("LocationSearchResults");  // load object from cache
				facilityLocationSearch = (Location)this.LoadObject("objFacilityLocationSearch");  // load object from cache
				searchFacilityNetworkLink = (FacilityLocationNetworkLink)this.LoadObject(typeof(FacilityLocationNetworkLink));  // load object from cache
				// always load all server side objects from the cache
				//col = (MORGCollection)this.LoadObject(typeof(MORGCollection));	// This would reload from cache
				// searchers must cache and read from a different key than the class name
				//morgSearcher = (MORG)this.LoadObject("MORGSearcher");
			}
			if (IsPostBack)
				searchNetworkPlanLink = (NetworkPlanLink)this.LoadObject(typeof(NetworkPlanLink));  // load object from cache
			
			if (this.HasCallbackFunction)
			{
				if (Request.QueryString["Flag"] == "1")
					hdnFlag.Value = "1";
				else
					hdnFlag.Value = "0";
			}

			CheckNetworkStatus();
		}
		
		private void TranslateNames()
		{
				this.rdSearchBy.Items[0].Text = this.Language.TranslateSingle("NAME");
			this.rdSearchBy.Items[1].Text = this.Language.TranslateSingle("ID");
			this.lstNetworkSearch.Items[0].Text = this.Language.TranslateSingle("ALLNETWORKS");
			this.lstNetworkSearch.Items[1].Text = this.Language.TranslateSingle("SPECIFIEDNETWORK");
		}

		private void BindForm()
		{
			//this.UpdateFromObject(this.pnlSearchName.Controls, this.searchProviderInfo);
			this.UpdateFromObject(this.tblName.Controls, this.searchFacilityInfo);
			//this.UpdateFromObject(this.tblFacility.Controls, this.);
			this.UpdateFromObject(this.tblAddress.Controls, this.searchFacilityAddress);

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.rdSearchBy.SelectedIndexChanged += new System.EventHandler(this.rdSearchBy_SelectedIndexChanged);
			this.lstNetworkSearch.SelectedIndexChanged += new System.EventHandler(this.lstNetworkSearch_SelectedIndexChanged);
			this.btnSearchName.Click += new System.EventHandler(this.btnSearchName_Click);
			this.GridFacilities.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.GridFacilities_ClickCellButton);
			this.GridFacilities.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.GridFacilities_ColumnsBoundToDataClass);
			this.GridFacilityLocations.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.GridFacilityLocations_ClickCellButton);
			this.GridFacilityLocations.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.GridFacilityLocations_RowBoundToDataObject);
			this.GridFacilityLocations.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.GridFacilityLocations_ColumnsBoundToDataClass);
			this.GridNetworks.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.GridNetworks_RowBoundToDataObject);
			this.GridNetworks.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.GridNetworks_ColumnsBoundToDataClass);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		

		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FacilityCollection FacilitySearchResults
		{
			get { return facilitySearchResults ; }
			set
			{
				facilitySearchResults = value;
				try
				{
					this.GridFacilities.KeepCollectionIndices = false;
					this.GridFacilities.UpdateFromCollection(facilitySearchResults);
					this.pnlResults.Visible				= true;			

					// If there are results then show the first result's Locations
					if (this.facilitySearchResults.Count > 0)
					{
						this.GridFacilities.SelectedRowIndex = 0;
						this.BindFacilityLocations((int)GridFacilities.SelectedRowPK[0]);
					}	
					else
					{
						pnlResults2.Visible =false;
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject("ProviderSearchResults", providerSearchResults);  // cache object using the caching method declared on the page
			}
		}
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Location FacilityLocationSearch
		{
			get { return facilityLocationSearch ; }
			set
			{
				facilityLocationSearch = value;
				try
				{
					this.UpdateFromObject(this.tblIDs2.Controls, facilityLocationSearch);  // update controls for the given control collection
				
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objFacilityLocationSearch", facilityLocationSearch);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForFacilityLocationSearch()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblIDs2.Controls, facilityLocationSearch);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}
			

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FacilityLocationCollection LocationSearchResults
		{
			get { return locationSearchResults; }
			set
			{
				locationSearchResults = value;
				try
				{
					this.GridFacilityLocations.KeepCollectionIndices = false;
					this.GridFacilityLocations.UpdateFromCollection(locationSearchResults);
					if (this.GridFacilityLocations.Rows.Count > 0)
						GridFacilityLocations.SelectedRowIndex = 0;
					
					GridFacilityLocations.Visible = true;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("LocationSearchResults", locationSearchResults);  // cache object using the caching method declared on the page
			}
		}



		private void BindFacilityLocations(int providerID)
		{
			FacilityLocationCollection facLocCol = new FacilityLocationCollection();
			facLocCol.LoadLocationsWithFilter(providerID,this.searchFacilityAddress);
			
			this.LocationSearchResults = facLocCol;
			this.pnlResults2.Visible   = true;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Address SearchFacilityAddress
		{
			get { return searchFacilityAddress; }
			set
			{
				searchFacilityAddress  = value;
				try
				{
					this.UpdateFromObject(this.tblAddress.Controls, searchFacilityAddress);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("AddressInfo", searchFacilityAddress);  // cache object using the caching method declared on the page
			}
		}
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Facility  SearchFacilityInfo
		{
			get { return searchFacilityInfo; }
			set
			{
				searchFacilityInfo = value;
				try
				{
					this.UpdateFromObject(this.tblName.Controls, searchFacilityInfo);  // update controls for the given control collection
					this.UpdateFromObject(this.tblFacilityType.Controls,searchFacilityInfo);
					this.UpdateFromObject(this.tblIDs.Controls, searchFacilityInfo);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("BasicInfo", searchFacilityInfo);  // cache object using the caching method declared on the page
			}
		}
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FacilityLocationNetworkLink SearchFacilityNetworkLink
		{
			get { return searchFacilityNetworkLink; }
			set
			{
				searchFacilityNetworkLink = value;
				try
				{
					this.UpdateFromObject(this.tblNetworkInfo.Controls, searchFacilityNetworkLink);  // update controls for the given control collection
					this.UpdateFromObject(this.tblIDs.Controls, searchFacilityInfo);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("NetworkInfo", searchFacilityNetworkLink);  // cache object using the caching method declared on the page
			}
		}
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FacilityLocationService SearchFacilityLocationServiceType
		{
			get { return searchFacilityLocationService; }
			set
			{
				searchFacilityLocationService = value;
				try
				{
					this.UpdateFromObject(this.tblServices.Controls, searchFacilityLocationService);  // update controls for the given control collection
					this.UpdateFromObject(this.tblIDs.Controls, searchFacilityInfo);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("ServiceInfo", searchFacilityLocationService);  // cache object using the caching method declared on the page
			}
		}
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FacilityFocus SearchFacilityFocus
		{
			get { return searchFacilityFocus; }
			set
			{
				searchFacilityFocus = value;
				try
				{
					this.UpdateFromObject(this.tblFocus.Controls, searchFacilityFocus);  // update controls for the given control collection
					this.UpdateFromObject(this.tblIDs.Controls, searchFacilityInfo);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("FocusInfo", searchFacilityFocus);  // cache object using the caching method declared on the page
			}
		}



		private void LoadData()
		{
			this.ClearProviderContext();
			if (this.HasCallbackFunction)
			{
				
				patCov = this.GetParamOrGetFromCache("PatCov", typeof(PatientCoverage)) as PatientCoverage ;
			}

			if (this.HasCallbackFunction && Request.QueryString["Addr"] == "1")
			{
				this.ClearProviderContext();

				// Address Info
				if (Request.QueryString["State"] != null)
				{
					Address addr = new Address();
					addr.State = Request.QueryString["State"];
					this.SearchFacilityAddress = addr;
				}
				else
					this.SearchFacilityAddress = new Address();

				// Network Info
				if (patCov.PlanID != 0)
				{
					NetworkPlanLink networkPlanLink = new  NetworkPlanLink();
					this.searchFacilityNetworkLink = new FacilityLocationNetworkLink();
					if (patCov.PlanID != 0)
						networkPlanLink.PlanId = patCov.PlanID;
					if (Request.QueryString["StartDate"] != null)
					{
						networkPlanLink.StartDate = DateTime.Parse(Request.QueryString["StartDate"].ToString());
						this.searchFacilityNetworkLink.EffectiveDate = networkPlanLink.StartDate;
					}
					this.SearchNetworkPlanLink = networkPlanLink;
						
					this.lstNetworkSearch.SelectedIndex = 1;
				}
				else
					this.searchFacilityNetworkLink = new FacilityLocationNetworkLink();
			}
			else
				NewSearch();
//
			this.pnlResults.Visible = false;
			this.pnlResults2.Visible = false;
			this.pnlNetworks.Visible = false;
			this.SetSearchFormVisibility(0);	// Search By Name enabled by default
			this.BlankForm = true;
		}
		// Tab toolbar

		private void NewSearch()
		{
			//this.NewSearchLanguage();
			this.NewSearchFacilityAddress();
			this.NewSearchFacilityInfo();
//			this.NewSearchProviderService();
//			this.NewSearchSpecialty();
			this.NewFacilityFocusSearch();
			this.NewFacilityLocationSearch();
			this.NewFacilityNetworkSearch();
			this.NewSearchFacilityLocationServiceType();

			this.SearchNetworkPlanLink = new NetworkPlanLink();
		}
		
		
	
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public NetworkPlanLink SearchNetworkPlanLink
		{
			get { return searchNetworkPlanLink; }
			set
			{
				searchNetworkPlanLink = value;
				try
				{
					//this.UpdateFromObject(this.Controls, searchNetworkPlanLink);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(NetworkPlanLink), searchNetworkPlanLink);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewFacilityLocationSearch()
		{
			bool result = true;
			Location facilityLocationSearch = new Location(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				facilityLocationSearch.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.FacilityLocationSearch = facilityLocationSearch;
			return result;
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchFacilityAddress()
		{
			bool result = true;
			Address searchFacilityAddress = new Address(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchFacilityAddress.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchFacilityAddress = searchFacilityAddress;
			return result;
		}
		
		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchFacilityLocationServiceType()
		{
			bool result = true;
			FacilityLocationService searchFacilityLocationServiceType = new FacilityLocationService(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchFacilityLocationServiceType.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchFacilityLocationServiceType = searchFacilityLocationServiceType;
			return result;
		}

		public bool NewSearchFacilityInfo()
		{
			bool result = true;
			Facility searchFacilityInfo = new Facility(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchFacilityInfo.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchFacilityInfo = searchFacilityInfo;
			return result;
		}
		
		public bool NewFacilityNetworkSearch()
		{
			bool result = true;
			FacilityLocationNetworkLink searchNetworkLinkInfo = new FacilityLocationNetworkLink(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchNetworkLinkInfo.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchFacilityNetworkLink = searchNetworkLinkInfo;
			return result;
		}
		
		public bool NewFacilityFocusSearch()
		{
			bool result = true;
			FacilityFocus searchFacilityFocus = new FacilityFocus(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchFacilityFocus.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchFacilityFocus = searchFacilityFocus;
			return result;
		}


		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("@NEWSEARCH@", "NewSearch");
			toolbar.AddButton("@ADDNEWRECORD@", "AddNew");
			//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
			//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");

			// Menu items to be displayed on all tabs
		}
		
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewSearch ();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{

			// add new 
			FacilityForm.Redirect(0);
		}
		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			Redirect("FacilitySearch.aspx");
		}

		private void grid_InitializeLayout(object sender, Infragistics.WebUI.UltraWebGrid.LayoutEventArgs e)
		{
		
		}

		private void FacilityFocusTypeID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
		
		}
		/// <summary>
		///	Sets the visibility status for all controls
		/// </summary>
		
		private void SetSearchFormVisibility(int selectedIndex)
		{
			switch (selectedIndex)
			{
				default:
				case 0:
					this.tblIDs.Visible				= this.tblIDs2.Visible			= false;
					this.tblName.Visible			= true;
					this.tblAddress.Visible			= true;
					tblFacilityType.Visible			= true;
					this.tblNetworkInfo.Visible		= true;
					this.tblServices.Visible		= true; 
					this.tblFocus.Visible			= true;
					//this.tblDate.Visible = true;
					
					break;
				case 1:
					this.tblIDs.Visible 			= this.tblIDs2.Visible  = true;
					this.tblAddress.Visible			= false;					
					this.tblName.Visible			= false;
					this.tblNetworkInfo.Visible		= false;
					this.tblServices.Visible		= false;
					this.tblFocus.Visible			= false;
					this.tblFacilityType.Visible	= false;
					//this.tblDate.Visible			= false;
					break;
			}
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			//toolbar.AddButton("@CANCEL@", "Cancel");
		}

		public NetsoftUSA.WebForms.OBLabel LbFacilityFocusID
		{
			get { return this.lbFacilityFocusID; }
			set { this.lbFacilityFocusID = value; }
		}

		public NetsoftUSA.InfragisticsWeb.WebCombo Prop_GroupPracticeServiceTypeID
		{
			get { return this.GroupPracticeServiceTypeID; }
			set { this.GroupPracticeServiceTypeID = value; }
		}

		public NetsoftUSA.InfragisticsWeb.WebTextEdit[] ValuesOf_Name
		{
			get
			{
				return new NetsoftUSA.InfragisticsWeb.WebTextEdit[] { }; // return possible field values
			}
			set
			{
				// you may remove the setter if not needed
			}
		}
		
		private void GridFacilities_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			this.GridFacilities.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;			
		}

		
		private void GridFacilities_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				// update selected index
				this.GridFacilities.SelectedRowIndex = e.Cell.Row.Index;
				SelectFacility((int)GridFacilities.SelectedRowPK[0]);
			}
		}

		private void GridFacilityLocations_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = GridFacilityLocations.GetPKFromCellEvent(e);

			if (this.HasCallbackFunction) // pop-up mode
			{
				FacilityLocation facloc = new FacilityLocation ();
				
				facloc.Load((int)pk[0]);
				//providerloc.Load((int)gridProviderLocations.SelectedRowPK[0]);
				
				
				hdnLocationID.Value = facloc.LocationID.ToString();
				hdnLocationDescription.Value = facloc.ServiceLocation.ToString();
				
				Facility fac= new Facility();
				fac.Load(facloc.FacilityID);
				hdnFacilityID.Value = facloc.FacilityID.ToString();
				hdnFacilityName.Value = fac.Name;
				hdnPhone.Value = facloc.Phone;	
				
				string startDate;

				if (Request.QueryString["StartDate"]=="")
				{
					startDate = Convert.ToString(DateTime.Now);
				}
				else
					startDate = Request.QueryString["StartDate"];
				

				int status = 0;
				if(patCov !=null)
				{
					status  = (int)facloc.GetStatusForFacilityLocationNetworks (patCov.PlanID, Convert.ToDateTime(startDate),facloc.LocationID);
				}
				else
				{
					status = 0;
				}
				hdnNetworkStatus.Value = status.ToString();


				BindNetworkSpecialties((int)pk[0]);
			}
			else
			{
				if (e.Cell.Key == "SelectLocation")
					SelectFacilityLocation((int)pk[0]); 
			}
		}
		
		private void GridFacilityLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction)
			{
				if (Request.QueryString["Flag"] == "1")
					this.GridFacilityLocations.AddColumnWithButtonLook("Pick", "@PICK@", 0).Width = 45;
				else
					this.GridFacilityLocations.AddButtonColumn("SelectLocation", "@SELECT@", 0).Width = selectWidth;
			}
			else
			{
				this.GridFacilityLocations.AddButtonColumn("SelectLocation", "@SELECT@", 0).Width = selectWidth;
			}
		}
		
		private void GridNetworks_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction) // if in pop-up mode
			{
				this.GridNetworks.AddColumnWithButtonLook("Pick","@PICK@",0);
			}
		}
		
		private void GridNetworks_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			if (cell != null)
			{
				FacilityLocationNetworkLink link = e.data as FacilityLocationNetworkLink ;
				if (this.searchNetworkPlanLink.PlanId == 0)
				{
					Infragistics.WebUI.UltraWebGrid.CellsCollection cells = this.GridFacilityLocations.DisplayLayout.ActiveRow.Cells;
					Infragistics.WebUI.UltraWebGrid.UltraGridCell activepCell = null;
					Infragistics.WebUI.UltraWebGrid.UltraGridCell activeplCell = null;

					for (int i = 0; i < cells.Count; i++)
					{
						if (cells[i].Key == "FacilityID")
							activepCell = cells[i];
						else if (cells[i].Key == "FacilityLocationID")
							activeplCell = cells[i];					
					}
					int facilityID = (int)activepCell.Value;
					int facilityLocID = (int)activeplCell.Value;
					Facility fac = new Facility();
					fac.Load(facilityID);
					FacilityLocation facilityloc = new FacilityLocation();
					facilityloc.Load(facilityLocID);

					//hdnNetworkID.Value = link.ProviderLocationNetworkID.ToString();
					//hdnNetworkDescription.Value = link.NetworkName.ToString();
 
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
					//e.row.Cells.FromKey("Pick").Text = GetCallbackFunctionHyperLink("Pick", facilityloc.FacilityID,fac.Name,facilityloc.LocationID,facilityloc.ServiceLocation,fac.FacilityTypeID,fac.FacilityType);
					//e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
				}
				else
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
			}			
		}


		private void GridFacilityLocations_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			if (Request.QueryString["Flag"] =="1")
			{
				try
				{
					UltraGridCell cell = e.row.Cells.FromKey("Pick");
				
					Facility gp = new Facility();
					gp.Load((int)GridFacilities.SelectedRowPK[0]);
						
					hdnFacilityID.Value = gp.FacilityID.ToString();
					hdnFacilityName.Value = gp.Name;
					hdnTypeID.Value = gp.TypeID.ToString();
					hdnTypeDescription.Value = gp.FacilityType;
			
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
//			//UltraGridCell cell = e.row.Cells.FromKey("Pick");
//			if ( cell != null)
//			{
//				if (this.searchNetworkPlanLink.PlanId == 0)
//				{
//					FacilityLocation facilityloc = e.data as FacilityLocation;
//					Facility fac = new Facility();
//					fac.Load(facilityloc.FacilityID);
//					
//					//hdnLocationID.Value = providerloc.ProviderLocationID.ToString();
//					//hdnLocationDescription.Value = providerloc.ServiceLocation.ToString();
//					
//					//e.row.Cells.FromKey("Pick").Text = GetCallbackFunctionHyperLink("Pick", facilityloc.FacilityID,fac.Name,facilityloc.LocationID,facilityloc.ServiceLocation,fac.FacilityTypeID,fac.FacilityType);
//				}
//				else
//					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
//			}
		}

		private string GetPickAllScript(string linkCaption)
		{
			return "<a href=\"#\" onclick='window.opener." + this.CallbackFunction + "(getGridVals());window.close();return false;'>" + Language.Translate(linkCaption) + "</a>";
		}

		/// <summary>
		/// Bind the Network for only pop-up mode
		/// </summary>
		/// <param name="facilityLocationID"></param>

		private void BindNetworkSpecialties(int facilityLocationID)
		{
			if (facilityLocationID != -1)
				this.pnlNetworks.Visible = true;

			// Load FacilityLocation / Facility
			FacilityLocation fl = new FacilityLocation();
			Facility f = new Facility();
			fl.Load(facilityLocationID);
			f.Load(fl.FacilityID);
			
			hdnFacilityID.Value = fl.FacilityID.ToString();
			hdnFacilityName.Value = f.Name;
			hdnTypeID.Value = f.FacilityTypeID.ToString();
			hdnTypeDescription.Value = f.FacilityType;
			hdnLocationID.Value = fl.LocationID.ToString() ;
			hdnLocationDescription.Value = fl.ServiceLocation.ToString();
			
			// Load Networks/
			fl.LoadNetworks(false);

			this.GridNetworks.UpdateFromCollection(fl.Networks);
			if (GridNetworks.Rows.Count > 0)
				GridNetworks.SelectedRowIndex = 0;
		}

		
		private void SelectFacilityLocation(int facilityLocationID)
		{
			if (facilityLocationID != -1)
			{
				FacilityLocation facLoc = new  FacilityLocation();
				facLoc.Load(facilityLocationID);
				FacilityForm.Redirect(facLoc.FacilityID);
			}
		}

		private void SelectFacility(int facilityID)
		{
			if (facilityID != -1)
			{
				try
				{
					Facility fac = new Facility();
					fac.Load(facilityID);


					hdnFacilityID.Value = facilityID.ToString();
					hdnFacilityName.Value = fac.Name;
					hdnTypeID.Value = fac.FacilityTypeID.ToString();
					hdnTypeDescription.Value = fac.FacilityType;
					

					BindFacilityLocations(facilityID);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void btnSearchName_Click(object sender, System.EventArgs e)
		{
			ReadForm(this.rdSearchBy.SelectedIndex);
		}

		private void rdSearchBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetSearchFormVisibility(rdSearchBy.SelectedIndex);

		}
		private void ReadForm(int searchBy)
		{
			try
			{
				if (searchBy == 1)
					this.UpdateToObject(this.tblIDs.Controls, this.searchFacilityInfo, false);
				else
				{
					// Read To Controls
					this.UpdateToObject(this.tblName.Controls, this.searchFacilityInfo, false); // basic info
					this.UpdateToObject(this.tblFacilityType.Controls, this.searchFacilityInfo, false);  // type info
					this.UpdateToObject(this.tblAddress.Controls, this.searchFacilityAddress, false);		// address
					this.UpdateToObject(this.tblServices.Controls,this.searchFacilityLocationService, false);	// services
					this.UpdateToObject(this.tblFocus.Controls, this.searchFacilityFocus, false);	// focus
					this.UpdateToObject(this.tblNetworkInfo.Controls,this.searchFacilityNetworkLink, false); // network
				}
				this.searchFacilityFocus.FacilityID = searchFacilityInfo.FacilityID;
				// if in pop-up mode send planID
				if (this.HasCallbackFunction)
					Search(this.searchFacilityInfo, this.searchFacilityAddress, this.SearchNetworkPlanLink , this.searchFacilityLocationService, this.searchFacilityFocus);
				else
				{
					if (lstNetworkSearch.SelectedValue == "0") // search all networks
						SearchFacilityNetworkLink = new FacilityLocationNetworkLink();
					Search(this.searchFacilityInfo, this.searchFacilityAddress, this.SearchFacilityNetworkLink , this.searchFacilityLocationService,this.searchFacilityFocus);
				}
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}
			
		}
		
		private void Search(Facility facility,Address address,FacilityLocationNetworkLink network,FacilityLocationService service, FacilityFocus focus)
		{
			try
			{
				FacilityCollection facilityCol	= new FacilityCollection();
				NetworkPlanLink netPlan		= new NetworkPlanLink();
				facilityCol.SearchFacilities (facility, network, netPlan ,focus, service,address  );
				this.FacilitySearchResults = facilityCol;
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}
		}


		private void Search(Facility facility,Address address, NetworkPlanLink netPlan, FacilityLocationService service, FacilityFocus focus)
		{
			try
			{
				FacilityCollection facilityCol	= new FacilityCollection();
				// empty network
				FacilityLocationNetworkLink network = new FacilityLocationNetworkLink();
				facilityCol.SearchFacilities(facility, network, netPlan , focus, service,address);
				this.FacilitySearchResults = facilityCol;
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		
		private void lstNetworkSearch_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			CheckNetworkStatus();			
		}
		
		private void CheckNetworkStatus()
		{
			if (lstNetworkSearch.SelectedValue == "0") // search all networks
			{
				lbNetwokSearchID.Enabled = false;
				NetwokSearchID.Enabled = false;
			}
			else
			{
				lbNetwokSearchID.Enabled = true;
				NetwokSearchID.Enabled = true;
			}

		}


		/* Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMORGSearch();
		}
		*/
	}
}
