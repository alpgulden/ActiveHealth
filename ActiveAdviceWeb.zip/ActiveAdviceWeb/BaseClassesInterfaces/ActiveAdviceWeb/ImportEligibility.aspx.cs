using System;
using System.IO;			// File.Exists()
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.BaseClassesInterfaces;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class ImportEligibilityForm : ImportExportBasePage
	{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFileName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FileName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFileName;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEligibility;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLabel;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Label;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLabel;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();
				TaskArguments ta = new TaskArguments();
				this.UpdateFromObject(pnlEligibility.Controls, ta, false);
			}
		}

		protected void LoadData()
		{
			// TODO: Load up data here
		}

		public void OnToolbarButtonClick_Update(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@ELIGIBILITY@");
			}
		}

		protected bool SaveData()
		{
			TaskArguments ta = new TaskArguments();
			this.UpdateToObject(pnlEligibility.Controls, ta, true);
			if (ValidateArguments(ta, false) ) // eligibility only supports filenames, not folders
			{
				// We can write this task out...
				ScheduleTask st						= new ScheduleTask();
				ScheduleTypeCollection types		= ScheduleTask.ActiveScheduleTypes;
				st.ScheduleTypeID					= types.IndexBy_Code.LookupIntMember("ScheduleTypeID", "ELIG");	// ELIGIBILITY
				ScheduleStatusCollection statuses	= ScheduleTask.ActiveScheduleStatuses;
				st.ScheduleStatusID					= statuses.IndexBy_Code.LookupIntMember("ScheduleStatusID", "PEND");	// PENDING

				st.Task				= ta.Task;	// create our "task" string
				st.Label			= ta.Label;	// label to attached to the scheduled item...
				st.CreatedBy		= this.CurrentUser;
				st.CreateTime		= DateTime.Now;
				st.ScheduledTime	= DateTime.Now;

				// Insert the record into the table...
				st.Insert();
				return true;
			}

			return false;
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			HttpContext.Current.Response.Redirect("Redirect method must redirect to its own page.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			ToolbarButtonExtraProperties tbep = toolbar.AddButton("@UPDATE@", "Update");
			tbep.ChecksForIsDirty = false;
		}

		/* Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMORGSearch();
		}
		*/
	}
}
