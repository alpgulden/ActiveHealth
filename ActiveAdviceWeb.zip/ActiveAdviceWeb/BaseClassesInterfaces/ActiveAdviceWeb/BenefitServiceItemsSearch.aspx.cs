using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PlanMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BenefitServiceItem,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(BenefitServicesForm))]
	[SelectedMenuItem("BenefitServices")]						//define the active menu item in side menu
	[SelectedMainMenuItem("MPlan")]						//defines active menu item in main navigation
	public class BenefitServiceItemsSearch : PlanBasePage
	{
		private BenefitServiceItem benefitServiceItem;
		private BenefitService benefitService;
		private BenefitServiceItemCollection benefitServiceItems;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBenefitServiceTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldBenefitServiceTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo BenefitServiceTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.benefitService = GetParamOrGetFromCache("BenefitService", typeof(BenefitService) ) as BenefitService;
				if (benefitService == null)
					RaisePageException(new Exception("You must hit this page in the context of a BenefitService"));
				this.NewSearch();
			}
			else
			{
				// always load all server side objects from the cache
				//col = (MORGCollection)this.LoadObject(typeof(MORGCollection));	// This would reload from cache
				// searchers must cache and read from a different key than the class name
				//morgSearcher = (MORG)this.LoadObject("MORGSearcher");
				benefitService = (BenefitService)this.LoadObject(typeof(BenefitService));
				benefitServiceItem = (BenefitServiceItem)this.LoadObject("BenefitServiceItem");  // load object from cache
			}

		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(BenefitService benefitService)
		{
			BasePage.PushParam("BenefitService", benefitService);

			BasePage.Redirect("BenefitServiceItemsSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			this.grid.ClickCellButton +=new ClickCellButtonEventHandler(grid_ClickCellButton);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.grid.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.grid_DblClick);
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.DirtyCheckEnabled = false;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				toolbar.AddButton(PlanMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}

			// Menu items to be displayed on all tabs
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BenefitServiceItemForm.Redirect(benefitService, null);
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BenefitServiceItemCollection BenefitServiceItems
		{
			get { return benefitServiceItems; }
			set
			{
				benefitServiceItems = value;
				try
				{
					grid.KeepCollectionIndices = false;  // update given grid from the collection
					grid.UpdateFromCollection(benefitServiceItems);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(BenefitServiceItemCollection), benefitServiceItems);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			BenefitServiceItemCollection benefitServiceItems = new BenefitServiceItemCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				// do the search in the parent BenefitService's context
				benefitServiceItem.BenefitServiceId = benefitService.BenefitServiceId;
				benefitServiceItems.SearchBenefitServiceItems(-1, benefitServiceItem);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//benefitServiceItems.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.BenefitServiceItems = benefitServiceItems;
			return result;
		}

		private void grid_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = grid.GetPKFromClickEvent(e);
				if (pk != null)
					BenefitServiceItemForm.Redirect(benefitService, (int)pk[0]);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BenefitServiceItem BenefitServiceItem
		{
			get { return benefitServiceItem; }
			set
			{
				benefitServiceItem = value;
				try
				{
					this.UpdateFromObject(pnlSearch.Controls, benefitServiceItem);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("BenefitServiceItem", benefitServiceItem);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearch()
		{
			bool result = true;
			BenefitServiceItem benefitServiceItem = new BenefitServiceItem(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				benefitServiceItem.SetMembersNull(true, true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.BenefitServiceItem = benefitServiceItem;
			return result;
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlSearch.Controls, benefitServiceItem);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.benefitService);
		}

		private void grid_ClickCellButton(object sender, CellEventArgs e)
		{
			switch (e.Cell.Key)
			{
				case "Edit":
				{
					int benefitServiceItemId = grid.GetPKIntFromCellEvent(e);
					if (benefitServiceItemId < 0)
						return;
					BenefitServiceItemForm.Redirect(this.benefitService, benefitServiceItemId);
					break;
				}
			}
		}
	}
}
