using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Insurance Payor page.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PlanMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("InsurancePayor,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(InsurancePayorSearch))]
	[SelectedMenuItem("InsurancePayors")]						//define the active menu item in side menu
	[SelectedMainMenuItem("MPlan")]						//defines active menu item in main navigation
	public class InsurancePayorForm : PlanBasePage
	{
		private InsurancePayor insurancePayor;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInsurancePayorId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit InsurancePayorId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInsurancePayorId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternatePayorId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternatePayorId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternatePayorId;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAddress;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected AddressControl AddressControl;
		protected UserDefined UserDefined1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			this.UserDefined1.ReloadContext("InsurancePayor",insurancePayor,true);
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				// always load all server side objects from the cache
				//col = (MORGCollection)this.LoadObject(typeof(MORGCollection));	// This would reload from cache
				// searchers must cache and read from a different key than the class name
				//morgSearcher = (MORG)this.LoadObject("MORGSearcher");
				insurancePayor = (InsurancePayor)this.LoadObject(typeof(InsurancePayor));  // load object from cache

				if (insurancePayor != null)
					this.AddressControl.Address = insurancePayor.Address;
			}
			
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		//public static void Redirect()
		//{
		//	HttpContext.Current.Response.Redirect("InsurancePayor.aspx");
		//}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Details")
			{
				toolbar.AddButton(PlanMessages.MessageIDs.ADDNEWRECORD, "AddNew");
				//toolbar.AddButton("@CLONE@", "Clone");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}

		// Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewData();
		}

		public void OnToolbarButtonClick_Clone(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.ReadControls())
			{
				this.InsurancePayor = insurancePayor.CreateCopyOfInsurancePayor();
			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			toolbar.AddButton("@SAVERECORD@", "Save");
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@INSURANCEPAYOR@");
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public InsurancePayor InsurancePayor
		{
			get { return insurancePayor; }
			set
			{
				insurancePayor = value;
				try
				{
					if (insurancePayor != null)
						this.AddressControl.Address = insurancePayor.Address;

					this.UpdateFromObject(pnlDetails.Controls, insurancePayor);  // update controls for the given control collection
					this.UpdateFromObject(pnlAddress.Controls, insurancePayor.Address);  // update controls for the given control collection
					this.UpdateFromObject(pnlNote.Controls, insurancePayor);  // update controls for the given control collection
					// other object-to-control methods if any
					UserDefined1.ReloadContext("InsurancePayor",insurancePayor,true);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(InsurancePayor), insurancePayor);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlDetails.Controls, insurancePayor);  // update controls for the given control collection
				this.UpdateToObject(pnlAddress.Controls, insurancePayor.Address);  // update controls for the given control collection
				this.UpdateToObject(pnlNote.Controls, insurancePayor);  // update controls for the given control collection
				// other control-to-object methods if any
				UserDefined1.ReadControls();
				insurancePayor.UserDefined = UserDefined1.UserDefinedValue;
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewData()
		{
			bool result = true;
			InsurancePayor insurancePayor = new InsurancePayor(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				//insurancePayor.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.InsurancePayor = insurancePayor;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			InsurancePayor insurancePayor = null; //new InsurancePayor();
			try
			{	// use any load method here
				//result = insurancePayor.Load();
				// or pull from the parameter passed to this page via PushParam
				insurancePayor = BasePage.PullParam("InsurancePayor") as InsurancePayor;
				if (insurancePayor == null)
					insurancePayor = new InsurancePayor(true); // if not passed, create a new data object and init as new
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//insurancePayor.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.InsurancePayor = insurancePayor;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(InsurancePayor insurancePayor)
		{
			BasePage.PushParam("InsurancePayor", insurancePayor);
			BasePage.Redirect("InsurancePayorForm.aspx");

		}

		public static void Redirect(int insurancePayorID)
		{
			InsurancePayor insPayor = new InsurancePayor();
			if (!insPayor.Load(insurancePayorID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@INSURANCEPAYOR@");
			Redirect(insPayor);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				insurancePayor.Save(); // update or insert to db 
				InsurancePayorCollection.ClearFromCache();
				this.InsurancePayor = this.insurancePayor;			// refresh the data on the page.
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.RenderClientFunctions(pnlDetails.Controls, this.insurancePayor, "OnCalcDetails");
			//this.SetPageTabToolbarItemEnabled("Clone", !this.insurancePayor.IsNew);
		}

		/* Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMORGSearch();
		}
		*/
	}
}
