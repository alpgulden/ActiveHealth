using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{

	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Assessment,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class Assessments : BasePage
	{
		private Assessment assessment;
		private AssessmentCollection assessments;
		private AssessmentContext assessmentContext;
		private CMS cMS;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDxPx;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDx;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnPx;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;		

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
				LoadData();
			else
			{
				cMS = (CMS)this.LoadObject(typeof(CMS));
				assessments = (AssessmentCollection)this.LoadObject(typeof(AssessmentCollection));  // load object from cache
				assessment = (Assessment)this.LoadObject(typeof(Assessment));  // load object from cache
			}

			assessmentContext = (AssessmentContext)this.LoadObject(typeof(AssessmentContext));
			if (assessmentContext != null) AssessmentView.Redirect(assessmentContext);
		}

		private void LoadData()
		{
			cMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;
			if (cMS == null)
			{
				this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a CMS"));
				return;
			}
			this.CacheObject(typeof(CMS), cMS);
 
			if(LoadDataForAssessments())
			{
				if(this.Assessments_.Count > 0)
				{
					grid.SelectedRowIndex = 0;
					Assessment = Assessments_[0];
				}
			}
			else
				this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, "I was not able to Load Assessments for CMS with ID " + cMS.CMSID.ToString()));
		}
		
		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			HttpContext.Current.Response.Redirect("AssessmentForm.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(CMS cMS)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CMS", cMS);			
			BasePage.Redirect("Assessments.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grid_ColumnsBoundToDataClass);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.wbtnDx.Click += new System.EventHandler(this.wbtnDx_Click);
			this.wbtnPx.Click += new System.EventHandler(this.wbtnPx_Click);
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		#region UI events and Initialization
		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Assessments")
			{
				toolbar.AddButton(BaseMessages.MessageIDs.ADD, "AddNew");
				#if DEBUG
				toolbar.AddButton("Test", "Test");
				#endif
			}
		}
		
		[System.Diagnostics.Conditional("DEBUG")]
		public void OnToolbarButtonClick_Test(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.Assessment = this.Assessments_[0];
			AssessmentContext assessmentContext = new AssessmentContext(this.cMS, this.Assessment);	
			AssessmentForm.Redirect(assessmentContext);
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewAssessment();
			// Save Assessment object first
			// redirect to AssessmentForm.aspx 
			
			try
			{
				this.Assessment.Save();
				Assessments_.Add(this.Assessment);

				AssessmentContext assessmentContext = new AssessmentContext(this.cMS, this.Assessment);	
				AssessmentForm.Redirect(assessmentContext);
			}
			catch(Exception ex)
			{
				this.RaisePageException (new ActiveAdviceException(AAExceptionAction.DisableUI, ex.ToString()));
			}
			
		}

		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			grid.AddButtonColumn("Select", "Select", 0);			
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = e.Cell.Row.Index;
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Select")
			{
				grid.SelectedRowIndex = index;
				Assessment = Assessments_[index];
				// redirect to AssessmentsView.aspx
				AssessmentContext assessmentContext = new AssessmentContext(this.cMS, Assessment);	
				AssessmentView.Redirect(assessmentContext);
			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		private void wbtnDx_Click(object sender, System.EventArgs e)
		{
			try
			{
				ZippyCoderForm.Redirect(this.cMS, this.cMS.CreateDiagnosticSelectionCollection());
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void wbtnPx_Click(object sender, System.EventArgs e)
		{
			try
			{
				ZippyCoderForm.Redirect(this.cMS, this.cMS.CreateProcedureSelectionCollection());
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}	
		}
		#endregion
		
		#region Data objects
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentCollection Assessments_
		{
			get { return assessments; }
			set
			{
				assessments = value;
				try
				{
					grid.UpdateFromCollection(assessments);  // update given grid from the collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AssessmentCollection), assessments);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		private bool LoadDataForAssessments()
		{
			bool result = true;
			AssessmentCollection assessments = new AssessmentCollection();
			try
			{	
				cMS.LoadAssessments(false);
				assessments = cMS.Assessments;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.Assessments_ = assessments;
			return result;
		}

//		/// <summary>
//		/// Call this method when you want to retrieve data from controls and save them to table.
//		/// </summary>
//		public bool SaveDataForAssessments()
//		{
//			try
//			{	// data from controls to object
//				cMS.Assessments = Assessments_;
//				cMS.SaveAssessments();
//			}
//			catch(Exception ex)
//			{
//				this.RaisePageException(ex);
//				return false;
//			}
//			return true;
//		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Assessment Assessment
		{
			get { return assessment; }
			set
			{
				assessment = value;
				this.CacheObject(typeof(Assessment), assessment);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewAssessment()
		{
			bool result = true;
			Assessment assessment = null; //new Assessment(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				assessment = new Assessment(true);
				if (SystemControlValue.GetInstance.AssessmentContentOwnerID < 1)
				{
					this.RaisePageException (new ActiveAdviceException(AAExceptionAction.DisableUI, "SystemControlValue.GetInstance.AssessmentContentOwnerID is NOT set."));
					return false;
				}
				assessment.ContentOwnerID = SystemControlValue.GetInstance.AssessmentContentOwnerID;
				assessment.CMSID = this.cMS.CMSID;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.Assessment = assessment;
			return result;
		}
		#endregion
	}
}
