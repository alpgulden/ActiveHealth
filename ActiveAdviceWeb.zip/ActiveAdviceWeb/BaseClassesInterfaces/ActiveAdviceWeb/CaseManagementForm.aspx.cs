using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.CMSMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("CMS,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class CaseManagementForm : BasePage
	{
		
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGeneral;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CaseOpenReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseOpenReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CaseStartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit CMSID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CaseClosedReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseClosedReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CaseContinuedReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseContinuedReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CaseSourceID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit AlternateCMSID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateCMSID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSRiskId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSRiskId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo StatusTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAcuityId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo AcuityId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIntensityId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo IntensityId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo StatusId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Prognosis;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrognosis;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlContactInformation;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCaseStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit1;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CaseEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCaseEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrognosis;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldClientReportContact;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhaseId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PhaseId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPhaseId;
		protected System.Web.UI.WebControls.Button butSave;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCaseOpenReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCaseContinuedReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbClientAuthorizationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ClientAuthorizationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbClientAuthorizerID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ClientAuthorizerID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlVerbalConsentPatients;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlVerbalConsentClients;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientAuthorizerID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PatientAuthorizerID; //temp object to verify if some controls were modified since they were loaded.

		private CMS cMS;
		private CMSStatusHistory nSH;
		private POCDeficit pOCDeficit;
		private POCGoal pOCGoal;
		private POCIntervention pOCIntervention;
		private ContentPlaceHolder cph;
		private Patient patient;
		private Problem problem;
		private PatientCoverage patientCoverage;
		private bool createMaternichek; 
		private WindowOpener wo;
		private bool finishedAddingPackingListItems;

		//protected TeamUserSelect TeamUserSelect;
		//protected ProviderSelect FacilitySelect;
		protected ProviderSelect ProviderSelect;

		 
		private	static Exception DeficitTypeDuplicateException = new Exception("Deficit of this type already exists!");
		private static Exception GoalTypeDuplicateException = new Exception("Goal of this type already exists!");
		private static Exception InterventionTypeDuplicateException = new Exception("Intervention of this type already exists!");


		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientAuthorizationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit PatientAuthorizationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbClientReportContact;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ClientReportContact;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPOCSummary;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridDeficits;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGoals;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridInterventions;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDeficit;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGoal;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlIntervention;
		
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEmpty;

		protected NetsoftUSA.InfragisticsWeb.WebValidator vldComment;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Comment;
		protected NetsoftUSA.WebForms.OBFieldLabel lbComment;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeficitStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DeficitStatusId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeficitTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DeficitTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitSourceId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeficitPriorityId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DeficitPriorityId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitPriorityId;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnShowDeficitPanel;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnShowInterventionPanel;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddDeficit;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeficitSourceId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DeficitSourceId;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCancelDeficit;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddNewDeficit;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnUpdateDeficitItem;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldComments;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Comments;
		protected NetsoftUSA.WebForms.OBFieldLabel lbComments;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGoalReasonId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GoalReasonId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGoalReasonId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProjectedCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ProjectedCompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProjectedCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGoalTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GoalTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGoalTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGoalOutcomeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GoalOutcomeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGoalOutcomeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActualCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ActualCompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActualCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGoalTermId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GoalTermId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGoalTermId;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCancelGoal;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnUpdateGoalItem;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddNewGoal;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddGoal;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInterventionStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo InterventionStatusID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInterventionStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DueDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivitySubTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivitySubTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivitySubTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInterventionTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo InterventionTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInterventionTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCancelIntervention;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnUpdateInterventionItem;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddNewIntervention;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddIntervention;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnShowGoalPanel;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlInterventionBilling;
		protected NetsoftUSA.WebForms.OBFieldLabel lbManagementServiceItemID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ManagementServiceItemID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldManagementServiceItemID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInterventionAmount;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit InterventionAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInterventionAmount;
		protected NetsoftUSA.WebForms.OBCheckBox IsBillable;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit BillableAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBillableAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBaseUOMID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit BaseAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBaseAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbConversionUnitOfMeasureID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fmt_BaseUOMID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fmt_ConversionUnitOfMeasureDescriptionByID;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCalculate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityPrimaryTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityPrimaryTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityPrimaryTypeID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMaternichek;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLMPdate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit LMPdate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLMPdate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEDCdate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EDCdate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEDCdate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstPrenatalVisit;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FirstPrenatalVisit;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstPrenatalVisit;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstPostpartumVisit;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FirstPostpartumVisit;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstPostpartumVisit;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGestationAge;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit GestationAge;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGestationAge;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeliveryDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DeliveryDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeliveryDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeliveryAge;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit DeliveryAge;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeliveryAge;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDaysOpen;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit DaysOpen;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDaysOpen;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnMaternichekUpdate;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridPackingList;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPackingList;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnRestore;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnPrintPackingList;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;		
		
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderSelect;		
		protected UserDefined UserDefined1;
		protected UserDefined UserDefined2;
		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForCMS()
		{
			bool result = true;
			try
			{	// use any load method here
				// or pull from the parameter passed to this page via PushParam
				patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a plan");
				this.CacheObject(typeof(Patient), patient);
				// get the passed patient subscriber coverage (link to patient)
				patientCoverage = GetParamOrGetFromCache("PatientCoverage", typeof(PatientCoverage)) as PatientCoverage;
				if (patientCoverage == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-subscriber-coverage");
				problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
				if (problem == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");					
				this.CacheObject(typeof(Problem), problem);
				
				cMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;
				createMaternichek = this.GetParamBool("CreateMaternichek", false);

				if (createMaternichek == true)
				{
					NewCMSMaternichek();
					cMS.CMSTypeID = Maternichek.CMSTypeCodeId;
				}
				else if (cMS == null) 
				{
					NewCMS(); // if not passed, create a new data object and init as new
					cMS.CMSTypeID = CMS.CMSTypeCodeId;
				}
				
				cMS.PrimaryProblemID = problem.ProblemID;
				//cMS.IsLinkedToProblem = false;
				cMS.Patient = patient;
				cMS.PatientId = patient.PatientId;
				cMS.Plan = patientCoverage.Plan;
				cMS.Plan.ManagementService.LoadManagementServiceItems(false);
								
				PopulatePackingItemsGrid();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}		

			this.CMS = cMS;
			return result;
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			//Provider select
			this.ProviderSelect.RebindControls(typeof(CMS), "@PROVIDER@", 
				ProviderSearcherType.Provider, null,
				"PrimaryProviderID", "PrimaryProviderLocationID", "PrimaryProviderSpecialtyID", "PrimaryProviderLocationNetworkID", "PrimaryProviderNetworkStatus", "CaseStartDate");
		
			
			UserDefined1.ReloadContext("CMS", cMS, true /*createcontrols*/); // short usage - always call
			UserDefined2.ReloadContext("Maternichek",null,true);
			if (!this.IsPostBack)
			{
				LoadDataForCMS();
			}
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				cMS = (CMS)this.LoadObject(typeof(CMS));	// This would reload from cache
				pOCDeficit = (POCDeficit)this.LoadObject(typeof(POCDeficit));  // load object from cache
				pOCGoal = (POCGoal)this.LoadObject(typeof(POCGoal));  // load object from cache
				pOCIntervention = (POCIntervention)this.LoadObject(typeof(POCIntervention));  // load object from cache
			}	
			
		}
		
		protected override void OnPreRender(EventArgs e)
		{
			if (cMS == null)
			{
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
				this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, "CMS was not created/set"));
				return;
			}
			
			base.OnPreRender (e);
			this.RenderClientFunctions(pnlGeneral.Controls, cMS, "onDateCheck");
			SetPageTabToolbarItemVisible("StatusHistory", !cMS.IsNew);
			//this.RenderClientFunctions(pnlIntervention, POCIntervention);
			this.SetPageTabToolbarItemVisible("Assessments", !cMS.IsNew);
			
		
			if (cMS.Maternichek != null)
			{
				SetPageTabItemVisible("Maternichek", true);
				pnlMaternichek.Visible = true;
			}
			else
			{
				SetPageTabItemVisible("Maternichek", false);
				pnlMaternichek.Visible = false;
			}
			
			
			wo = new WindowOpener();
			wo.ID = "PackingListSummary";
			wo.Resizable = true;
			wo.AddressBar = false;
			wo.CopyHistory = false;
			wo.LinksBar = false;
			wo.WindowWidth = 640;
			wo.WindowHeight = 350;
			wo.ScrollBars = true;

			wo.NavigateURL = "PackingListSummary.aspx";
			wo.registerClientScripts(this);
			
			if (finishedAddingPackingListItems)
			{
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){\n");
				s.Append(wo.getWindowOpenScript()+";}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
				finishedAddingPackingListItems = false;
			}
			else
			{	
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
			}
		}
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
				
			this.wbtnShowDeficitPanel.Click += new System.EventHandler(this.wbtnShowDeficitPanel_Click);
			this.gridDeficits.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridDeficits_ClickCellButton);
			this.gridDeficits.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridDeficits_ColumnsBoundToDataClass);
			this.wbtnShowGoalPanel.Click += new System.EventHandler(this.wbtnShowGoalPanel_Click);
			this.gridGoals.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridGoals_ClickCellButton);
			this.gridGoals.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridGoals_ColumnsBoundToDataClass);
			this.wbtnShowInterventionPanel.Click += new System.EventHandler(this.wbtnShowInterventionPanel_Click);
			this.gridInterventions.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridInterventions_ClickCellButton);
			this.wbtnAddDeficit.Click += new System.EventHandler(this.wbtnAddDeficit_Click);
			this.wbtnAddNewDeficit.Click += new System.EventHandler(this.wbtnAddNewDeficit_Click);
			this.wbtnUpdateDeficitItem.Click += new System.EventHandler(this.wbtnUpdateDeficitItem_Click);
			this.wbtnCancelDeficit.Click += new System.EventHandler(this.wbtnCancelDeficit_Click);
			this.wbtnAddGoal.Click += new System.EventHandler(this.wbtnAddGoal_Click);
			this.wbtnAddNewGoal.Click += new System.EventHandler(this.wbtnAddNewGoal_Click);
			this.wbtnUpdateGoalItem.Click += new System.EventHandler(this.wbtnUpdateGoalItem_Click);
			this.wbtnCancelGoal.Click += new System.EventHandler(this.wbtnCancelGoal_Click);
			this.InterventionStatusID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.InterventionStatusID_SelectedRowChanged);
			this.ActivityPrimaryTypeID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.ActivityPrimaryTypeID_SelectedRowChanged);
			this.wbtnAddIntervention.Click += new System.EventHandler(this.wbtnAddIntervention_Click);
			this.wbtnAddNewIntervention.Click += new System.EventHandler(this.wbtnAddNewIntervention_Click);
			this.wbtnUpdateInterventionItem.Click += new System.EventHandler(this.wbtnUpdateInterventionItem_Click);
			this.wbtnCancelIntervention.Click += new System.EventHandler(this.wbtnCancelIntervention_Click);
			this.ManagementServiceItemID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.ManagementServiceItemID_SelectedRowChanged);
			this.wbtnCalculate.Click += new System.EventHandler(this.wbtnCalculate_Click);
			this.wbtnPrintPackingList.Click += new System.EventHandler(this.wbtnPrintPackingList_Click);
			this.wbtnRestore.Click += new System.EventHandler(this.wbtnRestore_Click);
			this.wbtnMaternichekUpdate.Click += new System.EventHandler(wbtnMaternichekUpdate_Click);
			
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

			

			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.cMS, this.patientCoverage);
		}


		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			InitPOCParams();
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, cMS.CMSID.ToString()); //this.org.OrganizationLevelDescription);
			}
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			
			wo = new WindowOpener();
				wo.ID = "CaseManagementHistory";
				wo.NavigateURL = "CaseManagementHistory.aspx";
				wo.registerClientScripts(this);

			switch (tab.Key)
			{
				case "General":
					WindowOpener woProblemLink = new WindowOpener();
						woProblemLink.ID = "ProblemLinkForm";
						woProblemLink.NavigateURL = "ProblemLinkForm.aspx";
						woProblemLink.registerClientScripts(this);

					toolbar.AddButton("@LINKPROBLEM@", "LinkProblem").Item.TargetURL = "javascript:" + woProblemLink.getWindowOpenScript(); 
					toolbar.AddButton("@STATUSHISTORY@", "StatusHistory").Item.TargetURL = "javascript:" + wo.getWindowOpenScript();
					break;
				case "Assessment":
						toolbar.AddButton("@ASSESSMENTS@", "Assessments");
					break;
				case "PlanOfCare":
					//toolbar.AddButton("@ADDNEWRECORD@", "AddNewFocus");
					break;
				case "CareResource":
					toolbar.AddButton("@CARERESOURCE@", "CareResource");
					break;
				case "PackingList":
					break;
				case "ProvidersVendors":
					break;
				case "Outcomes":
					toolbar.AddButton("@OUTCOMES@","Outcomes");
					break;
				case "Administration":
					break;
			}
		}

//		public void OnToolbarButtonClick_StatusHistory(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
//		{
//		}

		public void OnToolbarButtonClick_CareResource(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// redirect to care resource page here.
		}

		public void OnToolbarButtonClick_Assessments(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// redirect to Assessments.aspx
			if (SaveData())
				Assessments.Redirect(CMS);
			else
				this.RaisePageException( new ActiveAdviceException(AAExceptionAction.DisableUI, "Can't redirect to Assessments.aspx because CMS was not saved"));
		}

		public void OnToolbarButtonClick_Outcomes(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// redirect to OutcomesForm.aspx.
			OutcomesForm.Redirect(this.patient, this.patientCoverage, this.problem, this.cMS);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMS CMS
		{
			get { return cMS; }
			set
			{
				cMS = value;
				try
				{
					this.UpdateFromObject(this.pnlGeneral.Controls, cMS);  // update controls for the given control collection
					this.UpdateFromObject(this.pnlDetails.Controls, cMS.LatestCMSStatusHistory);
					this.UpdateFromObject(this.pnlVerbalConsentPatients.Controls, cMS);
					this.UpdateFromObject(this.pnlVerbalConsentClients.Controls, cMS);
					
					this.UpdateFromObject(this.pnlProviderSelect.Controls, cMS);
					if (cMS.Maternichek != null)
						this.UpdateFromObject(this.pnlMaternichek.Controls, cMS.Maternichek);
					
					// Loading Deficits Collection
					cMS.LoadPOCDeficits(false);
					this.gridDeficits.UpdateFromCollection(cMS.POCDeficits);  // update given grid from the collection
					
					if(cMS.POCDeficits.Count > 0)
					{
						gridDeficits.SelectedRowIndex = 0;
						// Loading Goals Collection
						POCDeficit = cMS.POCDeficits[0];
						POCDeficit.LoadPOCGoals(false);
						this.gridGoals.UpdateFromCollection(POCDeficit.POCGoals);
						
						if(POCDeficit.POCGoals.Count > 0)
						{
							gridGoals.SelectedRowIndex = 0;
							if(POCDeficit.POCGoals.Count == 1)
								wbtnShowInterventionPanel.Visible = true;
							// Loading Interventions Collection
							POCGoal = POCDeficit.POCGoals[0];
							POCGoal.LoadPOCInterventions(false);
							this.gridInterventions.UpdateFromCollection(POCGoal.POCInterventions);
							if (POCGoal.POCInterventions.Count > 0)
							{
								gridInterventions.SelectedRowIndex = 0;
								POCIntervention = POCGoal.POCInterventions[0];
							}
						}
					}
					else
					{
						wbtnShowGoalPanel.Visible = false;
						wbtnShowInterventionPanel.Visible = false;
					}
					if(cMS.POCDeficits.Count == 1)
						wbtnShowGoalPanel.Visible = true;
					//PopulatePackingItemsGrid();
					cMS.LoadOutcomes(false);
					UserDefined1.ReloadContext("CMS",cMS,false);
					if(cMS.Maternichek != null)
						UserDefined2.ReloadContext("Maternicheck",cMS.Maternichek,false);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(CMS), cMS);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForCMS()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlGeneral.Controls, cMS);	// controls-to-object
				
				nSH = new CMSStatusHistory();
				nSH = (CMSStatusHistory) cMS.LatestCMSStatusHistory.Clone();
				
				//Saving controls state to a temp object to perform comparisson in order to determine if anything was changed from original object.
				this.UpdateToObject(this.pnlDetails.Controls, nSH); 
				
				this.UpdateToObject(this.pnlVerbalConsentPatients.Controls, cMS);
				this.UpdateToObject(this.pnlVerbalConsentClients.Controls, cMS);
				
				if (cMS.Maternichek != null)
				{
					this.UpdateToObject(this.pnlMaternichek.Controls, cMS.Maternichek);
					UserDefined2.ReadControls();
					cMS.Maternichek.UserDefined = UserDefined2.UserDefinedValue;
				}
				this.UpdateToObject(this.pnlProviderSelect.Controls, cMS);

				UserDefined1.ReadControls();
				cMS.UserDefined = UserDefined1.UserDefinedValue;
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewCMS()
		{
			bool result = true;
			//CMS cMS = new CMS(); // use a parameterized constructor which also initializes the data object
			CMS cMS = null;  
			try
			{	
				cMS = new CMS(true, patient);

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.CMS = cMS;
			//InitCMSMembers();
			return result;
		}

		public bool NewCMSMaternichek()
		{
			bool result = true;
			CMS cMS = null;
			try
			{
				cMS = new CMS(true, true, patient);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.CMS = cMS;
			return result;
		}
		
		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, bool createMaternichek)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("CreateMaternichek", createMaternichek);
			BasePage.Redirect("CaseManagementForm.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, CMS cMS)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("CMS", cMS);
			BasePage.Redirect("CaseManagementForm.aspx");

		}

		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, int cmsID)
		{
			CMS cmsObj = new CMS();
			if (!cmsObj.Load(cmsID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@CMS@");
			Redirect(patient, patCov, problem, cmsObj);
		}

		
		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			bool result = true;
			try
			{	// data from controls to object
				if (!this.ReadControlsForCMS())
					return false;
				 
				PrepareToSaveData();
				if(cMS.IsNew)
					cMS.Save(patientCoverage, problem); // update or insert to db
				else
					cMS.Save();
				this.CMS = cMS;
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return result;
		}

		private void PrepareToSaveData()
		{
			if(cMS.IsNew)
			{
				cMS.LatestCMSStatusHistory = nSH;
				cMS.LatestCMSStatusHistory.IsNew = true;
			}
			
			if(!cMS.IsNew)
			{
				// creating new CMSStatusHistory object ONLY if pnlDetails was modified
				if (!cMS.LatestCMSStatusHistory.EqualsMappedMembers(nSH, true, CMSStatusHistory.EXCLUDEDMEMBERS))
				{	// pnlDetails was changed -> insert new record into[CMSStatusHistory]
					nSH.IsNew = true;
					cMS.LatestCMSStatusHistory = nSH;
				}

			}

			//BR01.9.1.17	When the User updates the status of a CM case to a status other than OPEN, 
			//the System shall notify the User of any open deficits/goals/interventions associated with the case 
			//and provide means to change their status to CANCELLED.
			if(cMS.LatestCMSStatusHistory.StatusId != 
				SystemStatusCollection.ActiveSystemStatuses.Lookup_StatusIdByCode(SystemStatus.OPENCODE))
			{
				if(cMS.POCDeficits.Count > 0)
					this.SetPageMessage("This Case has Deficits associated with it.", EnumPageMessageType.Warning);
				
			}
		}

		private void InitPOCParams()
		{
			cph = this.PageTab.GetTab("PlanOfCare").ContentPane.FindControl("ContentPlaceHolder4DGI") as ContentPlaceHolder;
			
			pnlDeficit.Visible = false;
			pnlIntervention.Visible = false;
			pnlGoal.Visible = false;

			wbtnUpdateDeficitItem.Visible = false;
			wbtnUpdateGoalItem.Visible = false;
			wbtnUpdateInterventionItem.Visible = false;

			wbtnShowDeficitPanel.Visible = true;
			wbtnShowGoalPanel.Visible = false;
			wbtnShowInterventionPanel.Visible = false;
			
			pnlInterventionBilling.Visible = false;
			IsBillable.Enabled = false;
		}

		private void wbtnShowDeficitPanel_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			NewPOCDeficit();	
			pnlDeficit.Visible = true;
			cph.ControlToRender = "pnlDeficit";	
		}

		private void wbtnShowGoalPanel_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();	
			NewPOCGoal();
			pnlGoal.Visible = true;
			cph.ControlToRender = "pnlGoal";
		}

		private void wbtnShowInterventionPanel_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			NewPOCIntervention();
			pnlIntervention.Visible = true;
			cph.ControlToRender = "pnlIntervention";
		}

		private void wbtnAddDeficit_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForPOCDeficit())	
			{					
				cMS.POCDeficits.Add(POCDeficit); //Add to collection ONLY if Deficit of same type is not present
				
				gridDeficits.UpdateFromCollection(cMS.POCDeficits);		
				gridGoals.UpdateFromCollection(POCDeficit.POCGoals);
				NewPOCGoal();
				gridInterventions.UpdateFromCollection(POCGoal.POCInterventions);
				wbtnShowDeficitPanel.Visible = true;
				wbtnShowGoalPanel.Visible = true;
				pnlDeficit.Visible = false;
				//gridDeficits.Rows[cMS.POCDeficits.Count - 1].Activate();
				gridDeficits.SelectedRowIndex = cMS.POCDeficits.Count - 1;
			}
			else
			{
				this.InitPOCParams();
				pnlDeficit.Visible = true;
				cph.ControlToRender = "pnlDeficit";
				wbtnShowDeficitPanel.Visible = true;
			}
		}

		private void wbtnAddNewDeficit_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			if(ReadControlsForPOCDeficit())
			{
				cMS.POCDeficits.Add(POCDeficit); //Add to collection ONLY if Deficit of same type is not present
				this.gridDeficits.UpdateFromCollection(cMS.POCDeficits);
				this.gridGoals.UpdateFromCollection(POCDeficit.POCGoals);
				NewPOCGoal();
				this.gridInterventions.UpdateFromCollection(POCGoal.POCInterventions);
				wbtnShowGoalPanel.Visible = true;
				//gridDeficits.Rows[cMS.POCDeficits.Count - 1].Activate();
				gridDeficits.SelectedRowIndex = cMS.POCDeficits.Count - 1;
			}
			NewPOCDeficit();
			wbtnShowDeficitPanel.Visible = true;
			pnlDeficit.Visible = true;
			cph.ControlToRender = "pnlDeficit";
		}

		private void wbtnCancelDeficit_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			wbtnShowDeficitPanel.Visible = true;
		}

		

		private void gridDeficits_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = e.Cell.Row.Index;
			if (index < 0)
				return;	
			cMS.LoadPOCDeficits(false);
			if (e.Cell.Key == "Edit")
			{
				InitPOCParams();
				try
				{
					POCDeficit = cMS.POCDeficits[index];
					//e.Cell.Row.Activate();	
					gridDeficits.SelectedRowIndex = index;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				finally
				{
					pnlDeficit.Visible = true;
					wbtnUpdateDeficitItem.Visible = true;
					wbtnAddDeficit.Visible = false;
					wbtnAddNewDeficit.Visible = false;
					cph.ControlToRender = "pnlDeficit";
				}
			}
			if (e.Cell.Key == "Select")
			{
				InitPOCParams();
				try
				{
					POCDeficit = cMS.POCDeficits[index];
					//e.Cell.Row.Activate();			
					gridDeficits.SelectedRowIndex = index;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				finally
				{
					wbtnShowDeficitPanel.Visible = true;
					wbtnShowGoalPanel.Visible = true; // Make "Add Goal" availalbe
				}
			}
		}

		private void wbtnUpdateDeficitItem_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			if(ReadControlsForPOCDeficit())
			{
				POCDeficit.IsDirty = true;
				this.gridDeficits.UpdateFromCollection(cMS.POCDeficits); 
			}
			else
			{
				wbtnUpdateDeficitItem.Visible = true;
				pnlDeficit.Visible = true;
			}
			
			wbtnShowDeficitPanel.Visible = true;
			cph.ControlToRender = "pnlDeficit";
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public POCDeficit POCDeficit
		{
			get { return pOCDeficit; }
			set
			{
				pOCDeficit = value;
				try
				{
					this.UpdateFromObject(this.pnlDeficit.Controls, pOCDeficit);  // update controls for the given control collection
					// other object-to-control methods if any
					pOCDeficit.LoadPOCGoals(false);
					gridGoals.UpdateFromCollection(pOCDeficit.POCGoals);
					if (pOCDeficit.POCGoals.Count == 0)
					{
						NewPOCGoal();
					}
					else
					{
						//gridGoals.Rows[0].Activate();
						gridGoals.SelectedRowIndex = 0;
						POCGoal = pOCDeficit.POCGoals[0];
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(POCDeficit), pOCDeficit);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPOCDeficit()
		{
			try
			{	
				POCDeficit tmp = new POCDeficit();
				tmp = POCDeficit;
				this.UpdateToObject(this.pnlDeficit.Controls, pOCDeficit);	// controls-to--object
				if (CMS.POCDeficits.IsPOCDeficitTypeInCollection(POCDeficit, pOCDeficit.DeficitTypeID))
				{
					pOCDeficit = tmp;
					this.RaisePageException(DeficitTypeDuplicateException);
					return false;
				}
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPOCDeficit()
		{
			bool result = true;
			POCDeficit pOCDeficit = null; // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				pOCDeficit = new POCDeficit(true);
				pOCDeficit.ParentPOCDeficitCollection = CMS.POCDeficits;
				pOCDeficit.LoadPOCGoals(false);
				gridGoals.UpdateFromCollection(pOCDeficit.POCGoals);
				//NewPOCGoal();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.POCDeficit = pOCDeficit;
			NewPOCGoal();
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public POCGoal POCGoal
		{
			get { return pOCGoal; }
			set
			{
				pOCGoal = value;
				try
				{
					this.UpdateFromObject(this.pnlGoal.Controls, pOCGoal);  // update controls for the given control collection
					// other object-to-control methods if any
					pOCGoal.LoadPOCInterventions(false);
					gridInterventions.UpdateFromCollection(pOCGoal.POCInterventions);
					if(pOCGoal.POCInterventions.Count > 0)
						//gridInterventions.Rows[0].Activate();
						gridInterventions.SelectedRowIndex = 0;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(POCGoal), pOCGoal);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPOCGoal()
		{
			try
			{	
				POCGoal tmp = new POCGoal();
				tmp = POCGoal;
				this.UpdateToObject(this.pnlGoal.Controls, pOCGoal);	// controls-to-object
				if (POCDeficit.POCGoals.IsPOCGoalTypeInCollection(POCGoal, pOCGoal.GoalTypeId))
				{
					pOCGoal = tmp;
					this.RaisePageException(GoalTypeDuplicateException);
					return false;
				 }
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPOCGoal()
		{
			bool result = true;
			POCGoal pOCGoal = null; 
			try
			{	
				pOCGoal = new POCGoal(true);
				pOCGoal.ParentPOCGoalCollection = POCDeficit.POCGoals;
				pOCGoal.LoadPOCInterventions(false);
				gridInterventions.UpdateFromCollection(pOCGoal.POCInterventions);
				//NewPOCIntervention();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.POCGoal = pOCGoal;
			NewPOCIntervention();
			return result;
		}

		private void wbtnAddGoal_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForPOCGoal())
			{	
				POCDeficit.POCGoals.Add(this.POCGoal);
				POCDeficit.IsDirty = true;
				gridGoals.UpdateFromCollection(POCDeficit.POCGoals); 
				NewPOCIntervention();
				gridInterventions.UpdateFromCollection(POCGoal.POCInterventions);
				wbtnShowInterventionPanel.Visible = true;
				wbtnShowDeficitPanel.Visible = true;
				wbtnShowGoalPanel.Visible = true;
				pnlGoal.Visible = false;
				//gridGoals.Rows[gridGoals.Rows.Count - 1].Activate();
				gridGoals.SelectedRowIndex = gridGoals.Rows.Count - 1;
			}
			else
			{
				this.InitPOCParams();
				cph.ControlToRender = "pnlGoal";
				pnlGoal.Visible = true;
				wbtnShowInterventionPanel.Visible = false;
				wbtnShowDeficitPanel.Visible = true;
				wbtnShowGoalPanel.Visible = true;
			}
		}

		private void wbtnAddNewGoal_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			if(ReadControlsForPOCGoal())
			{
				POCDeficit.POCGoals.Add(this.POCGoal);
				POCDeficit.IsDirty = true;
				gridGoals.UpdateFromCollection(POCDeficit.POCGoals); 
				NewPOCIntervention();
				gridInterventions.UpdateFromCollection(POCGoal.POCInterventions);
				wbtnShowInterventionPanel.Visible = true;
				wbtnShowDeficitPanel.Visible = true;
				wbtnShowGoalPanel.Visible = true;
				//gridGoals.Rows[gridGoals.Rows.Count - 1].Activate();
				gridGoals.SelectedRowIndex = gridGoals.Rows.Count - 1;
			}
			NewPOCGoal();
			pnlGoal.Visible = true;
			cph.ControlToRender = "pnlGoal";					
		}

		private void wbtnUpdateGoalItem_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			if(ReadControlsForPOCGoal())
			{
				POCDeficit.IsDirty = true;  // parent object
				POCGoal.IsDirty = true;
				gridGoals.UpdateFromCollection(POCDeficit.POCGoals); 
			}
			else
			{
				wbtnUpdateGoalItem.Visible = true;
				pnlGoal.Visible = true;
				cph.ControlToRender = "pnlGoal";
			}
			wbtnShowDeficitPanel.Visible = true;
			wbtnShowGoalPanel.Visible = true;
		}

		private void wbtnCancelGoal_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			wbtnShowGoalPanel.Visible = true;
		}

		private void gridGoals_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{	
			int index = e.Cell.Row.Index;
			if (index < 0)
				return;
			POCDeficit.LoadPOCGoals(false);
			if (e.Cell.Key == "Edit")
			{
				InitPOCParams();
				try
				{
					POCGoal = POCDeficit.POCGoals[index];
					//e.Cell.Row.Activate();
					gridGoals.SelectedRowIndex = index;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				finally
				{
					pnlGoal.Visible = true;
					wbtnUpdateGoalItem.Visible = true;
					wbtnAddGoal.Visible = false;
					wbtnAddNewGoal.Visible = false;
					cph.ControlToRender = "pnlGoal";
				}
			}
			if (e.Cell.Key == "Select")
			{
				InitPOCParams();
				try
				{
					POCGoal = POCDeficit.POCGoals[index];
					//e.Cell.Row.Activate();
					gridGoals.SelectedRowIndex = index;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				finally
				{
					wbtnShowDeficitPanel.Visible = true;
					wbtnShowGoalPanel.Visible = true;
					wbtnShowInterventionPanel.Visible = true;
				}
			}
		}

		private void gridDeficits_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridDeficits.AddButtonColumn("Select", "Select", 1);			
		}

		private void gridGoals_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{	
			gridGoals.AddButtonColumn("Select", "Select", 1);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public POCIntervention POCIntervention
		{
			get { return pOCIntervention; }
			set
			{
				pOCIntervention = value;
				try
				{
					this.UpdateFromObject(this.pnlIntervention.Controls, pOCIntervention);  // update controls for the given control collection
					this.UpdateFromObject(this.pnlInterventionBilling.Controls, pOCIntervention);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(POCIntervention), pOCIntervention);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPOCIntervention()
		{
			try
			{	//customize this method for this specific page
				POCIntervention tmp = new POCIntervention();
				tmp = POCIntervention;
				this.UpdateToObject(this.pnlIntervention.Controls, pOCIntervention);	// controls-to-object
				this.UpdateToObject(this.pnlInterventionBilling.Controls, pOCIntervention);
				if(POCGoal.POCInterventions.IsPOCInterventionTypeInCollection(POCIntervention, pOCIntervention.InterventionTypeID))
				{
					pOCIntervention = tmp;
					this.RaisePageException(InterventionTypeDuplicateException);
					return false;
				}
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPOCIntervention()
		{
			bool result = true;
			POCIntervention pOCIntervention = null; 
			try
			{	
				pOCIntervention = new POCIntervention(true);
				pOCIntervention.ParentPOCInterventionCollection = POCGoal.POCInterventions;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.POCIntervention = pOCIntervention;
			return result;
		}

		

		private void gridInterventions_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = e.Cell.Row.Index;
			if (index < 0)
				return;
			if (e.Cell.Key == "Edit")
			{
				InitPOCParams();
				try
				{
					POCIntervention = POCGoal.POCInterventions[index];

					if (POCIntervention.Fmt_InterventionStatusID == POCIntervention.COMPLETE)
						pnlInterventionBilling.Visible = true;
					else
						pnlInterventionBilling.Visible = false;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				finally
				{
					pnlIntervention.Visible = true;
					wbtnUpdateInterventionItem.Visible = true;
					wbtnAddIntervention.Visible = false;
					wbtnAddNewIntervention.Visible = false;
					cph.ControlToRender = "pnlIntervention";
				}
			}
		}

		private void wbtnAddIntervention_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			if(ReadControlsForPOCIntervention())	
			{					
				POCGoal.POCInterventions.Add(POCIntervention); //Add to collection ONLY if Deficit of same type is not present
				POCDeficit.IsDirty = true;
				POCGoal.IsDirty = true;
				gridInterventions.UpdateFromCollection(POCGoal.POCInterventions); 
				wbtnShowInterventionPanel.Visible = true;
				pnlIntervention.Visible = false;
				//gridInterventions.Rows[gridInterventions.Rows.Count - 1].Activate();
				gridInterventions.SelectedRowIndex = gridInterventions.Rows.Count - 1;
			}
			wbtnShowDeficitPanel.Visible = true;
			wbtnShowGoalPanel.Visible = true;
			wbtnShowInterventionPanel.Visible = true;
			cph.ControlToRender = "pnlIntervention";
		}

		private void wbtnAddNewIntervention_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			//NewPOCIntervention();
			if(ReadControlsForPOCIntervention())
			{
				POCGoal.POCInterventions.Add(POCIntervention);
				POCDeficit.IsDirty = true;
				POCGoal.IsDirty = true;
				gridInterventions.UpdateFromCollection(POCGoal.POCInterventions);
				wbtnShowInterventionPanel.Visible = true;
				//gridInterventions.Rows[gridInterventions.Rows.Count - 1].Activate();
				gridInterventions.SelectedRowIndex = gridInterventions.Rows.Count - 1;
			}

			NewPOCIntervention();
			pnlIntervention.Visible = true;
			cph.ControlToRender = "pnlIntervention";
			wbtnShowDeficitPanel.Visible = true;
			wbtnShowGoalPanel.Visible = true;
			wbtnShowInterventionPanel.Visible = true;
		}

		private void wbtnUpdateInterventionItem_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			if(ReadControlsForPOCIntervention())
			{
				POCIntervention.IsDirty = true;
				POCDeficit.IsDirty = true;
				POCGoal.IsDirty = true;
				gridInterventions.UpdateFromCollection(POCGoal.POCInterventions);
				if (!POCIntervention.Calculate())
				{
					SetPageMessage("Intervention calculation failed!", NetsoftUSA.WebForms.EnumPageMessageType.Error);	
					UpdateBillableControls();
					this.pnlIntervention.Visible = true;
					pnlInterventionBilling.Visible = true;
				}
				wbtnShowDeficitPanel.Visible = true;
				wbtnShowGoalPanel.Visible = true;
				wbtnShowInterventionPanel.Visible = true;
				cph.ControlToRender = "pnlIntervention";
			}
			else
			{
				this.wbtnUpdateInterventionItem.Visible = true;
				cph.ControlToRender = "pnlIntervention";
			}
			
		}

		private void wbtnCancelIntervention_Click(object sender, System.EventArgs e)
		{
			InitPOCParams();
			wbtnShowInterventionPanel.Visible = true;
		}


		
		private void ActivityPrimaryTypeID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			InitPOCParams();
			if(ReadControlsForPOCIntervention())
			{
				POCIntervention.InterventionTypeID = 0;
				UpdateBillableControls();
				pnlIntervention.Visible = true;
				cph.ControlToRender = "pnlIntervention";
			}
		}

		private void InterventionStatusID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			InitPOCParams();
			if(ReadControlsForPOCIntervention())
			{
				UpdateBillableControls();
				pnlIntervention.Visible = true;
				wbtnUpdateInterventionItem.Visible = true;
				cph.ControlToRender = "pnlIntervention";
				
				// check for Completion Status.
				if(this.POCIntervention.Fmt_InterventionStatusID == POCIntervention.COMPLETE)
				{
					UpdateBillableControls();
					this.pnlInterventionBilling.Visible = true;
				}
				else
					this.pnlInterventionBilling.Visible = false;

			}
		}

		private void ManagementServiceItemID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			InitPOCParams();
			if(ReadControlsForPOCIntervention())
			{	
				// set ManagementServiceItem based on drop down selection
				
				POCIntervention.ManagementServiceItem =
					 POCIntervention.LookupOf_ManagementServiceItemID.FindBy(this.POCIntervention.ManagementServiceItemID);				  
				
				// set properties available from ManagementServiceItem
				UpdateBillableControls();
			}
			pnlInterventionBilling.Visible = true;
			pnlIntervention.Visible = true;
			wbtnUpdateInterventionItem.Visible = true;
			cph.ControlToRender = "pnlIntervention";
		}

		private void UpdateBillableControls()
		{
			InterventionTypeID.UpdateData(false);
			Fmt_BaseUOMID.UpdateData(false);
			Fmt_ConversionUnitOfMeasureDescriptionByID.UpdateData(false);
			IsBillable.UpdateData(false);
		}

		private void wbtnCalculate_Click(object sender, System.EventArgs e)
		{	
			InitPOCParams();
			if(ReadControlsForPOCIntervention())
			{		
				if (!POCIntervention.Calculate())
					SetPageMessage("Intervention calculation failed!", NetsoftUSA.WebForms.EnumPageMessageType.Error);	
				UpdateBillableControls();
			}
			pnlInterventionBilling.Visible = true;
			wbtnUpdateInterventionItem.Visible = true;
			wbtnUpdateInterventionItem.Visible = true;
			pnlIntervention.Visible = true;
			cph.ControlToRender = "pnlIntervention";
		}

		private void wbtnMaternichekUpdate_Click(object sender, System.EventArgs e)
		{
			ReadControlsForCMS();
			
			LMPdate.UpdateData(false);
			EDCdate.UpdateData(false);
			GestationAge.UpdateData(false);
			DeliveryAge.UpdateData(false);
			DaysOpen.UpdateData(false);
		}

		
		private void wbtnPrintPackingList_Click(object sender, System.EventArgs e)
		{
			//cMS.LoadPackingListItemsSent(false);
			DateTime dt = DateTime.Now;
			for ( int row = 0; row < gridPackingList.Rows.Count; row++)
			{
				if ((bool)gridPackingList.Rows[row].Cells[0].Value == true)
				{
					PackingListItemSent item = new PackingListItemSent(true);
					item.CMSId = this.cMS.CMSID;
					item.PackingListItemId = (int)gridPackingList.Rows[row].Cells[2].Value;
					item.CreationTime = dt;
					cMS.PackingListItemsSent.Add(item);
				}
			}
			if (cMS.PackingListItemsSent.Count > 0)
			{
				finishedAddingPackingListItems = true;
				PopulatePackingItemsGrid();
			}
		}

		private void PopulatePackingItemsGrid()
		{
			//1. Get Number of columns showing Sent history
			//2. Add needed coluns. Not to exceed predefined limit
			
			PackingListItemSentCollection distinctDates = new PackingListItemSentCollection();
			cMS.LoadPackingListItemsSent(false);
			distinctDates.GetAllDistinctDatesFromCollection(cMS.PackingListItemsSent);
			
			int limit;
			if (distinctDates.Count == 0)
				limit = 0;
			else if (distinctDates.Count > PackingListItemSent.COLUMNSLIMIT)
				limit = PackingListItemSent.COLUMNSLIMIT;
			else
				limit = distinctDates.Count;
			for (int i = 0; i < limit; i++)
			{
				string key = "Date" + i.ToString();
				string txt = distinctDates[i].CreationTime.ToShortDateString()+ "<br>" + distinctDates[i].CreationTime.ToShortTimeString();
				gridPackingList.AddColumn(key, txt, gridPackingList.Columns.Count);
			}
			
			PackingListItemCollection packingListItems = PackingListItemCollection.ActivePackingListItems;
			
			for ( int row = 0; row < packingListItems.Count; row++)
			{
				if (gridPackingList.Rows[row] == null)
				{
					gridPackingList.Rows.Add();	
					// Load Defaults in here.
					gridPackingList.Rows[row].Cells[0].Value = packingListItems[row].IsSelectedBeDefault(this.cMS); //returns Default behavior (checked or not checked) of Packing List Item
					gridPackingList.Rows[row].Cells[1].Value = packingListItems[row].Description;
					gridPackingList.Rows[row].Cells[2].Value = packingListItems[row].PackingListItemId;
				}
				if (cMS.PackingListItemsSent != null && cMS.PackingListItemsSent.Count > 0) // populating dates for sent items
				{
					for (int cell = 3; cell < gridPackingList.Columns.Count; cell++)
					{
						if (cMS.PackingListItemsSent.ContainsItemWithIdCreateTime(packingListItems[row].PackingListItemId, distinctDates[cell-3].CreationTime))
							gridPackingList.Rows[row].Cells[cell].Text = "Sent";
						else
							gridPackingList.Rows[row].Cells[cell].Text = " ";
					}
				}
			}// new grid row
		}

		private void wbtnRestore_Click(object sender, System.EventArgs e)
		{
			PackingListItemCollection packingListItems = PackingListItemCollection.ActivePackingListItems;
			for ( int row = 0; row < packingListItems.Count; row++)
			{
				gridPackingList.Rows[row].Cells[0].Value = packingListItems[row].IsSelectedBeDefault(this.cMS); //returns Default behavior (checked or not checked) of Packing List Item
			}
		}

		
 	}
}
