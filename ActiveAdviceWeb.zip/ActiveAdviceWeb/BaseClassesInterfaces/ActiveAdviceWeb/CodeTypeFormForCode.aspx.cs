using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.BaseCodeTypeMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseLookupWithCode,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class CodeTypeFormForCode : CodeBasePage
	{
		private BaseLookupWithCode searchObj;
		private	  BaseLookupWithCode obj;
		private   BaseTypeCollection objCol;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGrid;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridFocusTypes;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlInfo;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEdit;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCode;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Code;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCode;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCodeTypes;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBCheckBox OBCheckBox1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.WebForms.OBTextBox OBTextBox1;
		protected NetsoftUSA.WebForms.OBTextBox OBTextBox2;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;



		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
				this.LoadData();			// Load data is the actual data loading method
			else
			{
				this.obj    = (BaseLookupWithCode)this.LoadObject("Code");
				this.objCol = (BaseTypeCollection)this.LoadObject("CodeCollection");			
				this.searchObj = (BaseLookupWithCode)this.LoadObject("SearchObj");
			}
		}



		public static void Redirect(Type type)
		{
			if (typeof(InsuranceStatus) == type)
			{
				InsuranceStatusCollection insuranceCol = new InsuranceStatusCollection();
				BasePage.PushParam("Type", insuranceCol );
				BasePage.Redirect("CodeTypeFormForCode.aspx");
			}
			else if (typeof(InsuranceType) == type)
			{
				InsuranceTypeCollection insuranceTypeCol = new InsuranceTypeCollection();
				BasePage.PushParam("Type", insuranceTypeCol);
				BasePage.Redirect("CodeTypeFormForCode.aspx");
			}
			else if (typeof(BaseUnitOfMeasure) == type)
			{
				BaseUnitOfMeasureCollection unitOfMeasureCol = new BaseUnitOfMeasureCollection();
				BasePage.PushParam("Type", unitOfMeasureCol);
				BasePage.Redirect("CodeTypeFormForCode.aspx");
			}
			else if(typeof(BenefitServiceType) == type)
			{
				BenefitServiceTypeCollection benefitServiceTypeCol = new BenefitServiceTypeCollection();
				BasePage.PushParam("Type", benefitServiceTypeCol);
				BasePage.Redirect("CodeTypeFormForCode.aspx");
			}
			else if(typeof(CoveredType) == type)
			{
				CoveredTypeCollection coveredTypeCol = new CoveredTypeCollection();
				BasePage.PushParam("Type", coveredTypeCol);
				BasePage.Redirect("CodeTypeFormForCode.aspx");
			}
			else if(typeof(ManagementServicesRateType) == type)
			{
				ManagementServicesRateTypeCollection serviceRateCol = new ManagementServicesRateTypeCollection();
				BasePage.PushParam("Type", serviceRateCol);
				BasePage.Redirect("CodeTypeFormForCode.aspx");
			}
			else if(typeof(PlanHEDISType) == type)
			{
				PlanHEDISTypeCollection planHedisCol = new PlanHEDISTypeCollection();
				BasePage.PushParam("Type", planHedisCol);
				BasePage.Redirect("CodeTypeFormForCode.aspx");
			}
			else if(typeof(PlanNoteType) == type)
			{
				PlanNoteTypeCollection planNoteTypeCol = new PlanNoteTypeCollection();
				BasePage.PushParam("Type", planNoteTypeCol);
				BasePage.Redirect("CodeTypeFormForCode.aspx");
			}		
			else if(typeof(PlanUnitOfMeasure) == type)
			{
				PlanUnitOfMeasureCollection planUnitMeasureTypeCol = new PlanUnitOfMeasureCollection();
				BasePage.PushParam("Type", planUnitMeasureTypeCol);
				BasePage.Redirect("CodeTypeFormForCode.aspx");
			}			
			else if (typeof(ConversionUnitOfMeasure) == type)
			{
				ConversionUnitOfMeasureCollection planMeasureTypeCol = new ConversionUnitOfMeasureCollection();
				BasePage.PushParam("Type", planMeasureTypeCol);
				BasePage.Redirect("CodeTypeFormForCode.aspx");
			}
			else
			{
				Debug.Fail("Invalid Type");
			}
		}



		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			BaseTypeCollection  BaseLookupWithCodeCol	= BasePage.PullParam("Type") as BaseTypeCollection;
			if (BaseLookupWithCodeCol == null)
			{
				this.pnlGrid.Visible	= false;
				this.pnlInfo.Visible	= true;
				this.pnlSearch.Visible	= false;
				// disable buttons
				//((Button)this.PageToolbar.FindControl("AddNew")).Visible = false;
			}
			else
			{
				this.obj							= (BaseLookupWithCode)Activator.CreateInstance(BaseLookupWithCodeCol.ElementType);
				if (this.searchObj == null)
				{
					BaseLookupWithCodeCol.LoadAll();
					this.BaseTypeCollection = BaseLookupWithCodeCol;
					this.SearchObj			= new  BaseLookupWithCode();
				}
				
				
				this.pnlGrid.Visible	= true;
				this.pnlInfo.Visible	= false;
				this.pnlSearch.Visible	= true;
				// enable buttons
				//((Button)this.PageToolbar.FindControl("AddNew")).Visible = true;
				//((Button)this.
			}
			this.pnlEdit.Visible = false;
			return result;
		}


		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				this.obj.Save(); // update or insert to db
				this.searchObj = null;
				// refresh grid.
				ReloadGrid();
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BaseLookupWithCode BaseLookupWithCode
		{
			get { return this.obj; }
			set 
			{
				this.obj = value;
				try
				{
					this.UpdateFromObject(pnlEdit.Controls, this.obj);
					this.pnlEdit.Visible = true;
					this.pnlGrid.Visible = false;
					this.pnlSearch.Visible = false;
					
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("Code", this.obj);
			}
		}

		public BaseTypeCollection BaseTypeCollection
		{
			get { return this.objCol; }
			set 
			{
				try
				{
					this.objCol				= value;
					objCol.ElementType      = value.ElementType;
					this.pnlGrid.Visible	= true;
					this.pnlSearch.Visible  = true;
					this.gridCodeTypes.UpdateFromCollection(this.objCol);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("CodeCollection", this.objCol);
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	// add all control-to-object population code here
				this.UpdateToObject(pnlEdit.Controls, obj);  // controls-to-object
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.gridCodeTypes.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridCodeTypes_DblClick);
			this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);

			
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@SAVERECORD@", "SaveType");
			toolbar.AddButton("@CANCEL@", "Cancel");
			

		}


		public override void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick (toolbar, button);
			//button.Key == "Save"
		}

		public void OnToolbarButtonClick_SaveType(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@CODETYPE@");
				this.pnlEdit.Visible = false;
				this.pnlGrid.Visible = true;
			}
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			CodeTypeFormForCode.Redirect(this.objCol.ElementType);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("Add New", "AddNew");
			toolbar.AddButton("@NEWSEARCH@", "NewSearch");

		}

		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.SearchObj = new BaseLookupWithCode();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{

			BaseLookupWithCode BaseLookupWithCode		= (BaseLookupWithCode)Activator.CreateInstance(this.objCol.ElementType);
			BaseLookupWithCode.New();
			this.BaseLookupWithCode			= BaseLookupWithCode;
			this.pnlEdit.Visible	= true;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
		}

		protected void gridCodeTypes_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			if (e.Cell != null)
			{
				int index				= (int)e.Cell.Row.DataKey;
				this.BaseLookupWithCode 			= (BaseLookupWithCode)this.objCol.GetAt(index);
				this.pnlEdit.Visible	= true;
				this.pnlGrid.Visible    = false;
			}
			else if (e.Row != null)
			{
				int rowindex			= (int)e.Row.DataKey;
				this.BaseLookupWithCode			= (BaseLookupWithCode)this.objCol.GetAt(rowindex);
				this.pnlEdit.Visible	= true;
				this.pnlGrid.Visible	= false;
			}
		}


		private void ReloadGrid()
		{
			BaseTypeCollection.LoadAll();
			this.BaseTypeCollection = BaseTypeCollection;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BaseLookupWithCode SearchObj
		{
			get { return searchObj; }
			set
			{
				searchObj = value;
				try
				{
					this.UpdateFromObject(this.Controls, searchObj);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("SearchObj", searchObj);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSearchObj()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.Controls, searchObj);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchObj()
		{
			bool result = true;
			BaseLookupWithCode searchObj = new BaseLookupWithCode(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchObj.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchObj = searchObj;
			return result;
		}

		private void btnSearch_Click(object sender, System.EventArgs e)
		{
			BaseTypeCollection searchResults = (BaseTypeCollection)Activator.CreateInstance(this.objCol.GetType());
			this.UpdateToObject(this.pnlSearch.Controls, this.searchObj, false);
			searchResults.SearchCodeTypes(this.searchObj.Code, this.searchObj.Description, this.searchObj.Active);
			this.BaseTypeCollection = searchResults;		
		}



	}
}
