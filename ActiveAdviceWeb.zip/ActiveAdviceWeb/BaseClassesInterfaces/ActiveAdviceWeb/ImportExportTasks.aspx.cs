using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.BaseClassesInterfaces;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class ImportExportTasksForm : ImportExportBasePage
	{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlTasks;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridTasks;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldScheduleTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ScheduleTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbScheduleTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldScheduleStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ScheduleStatusID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbScheduleStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				ScheduleTaskCollection scheduleTasks = this.GetAllScheduleTasks();
				this.gridTasks.UpdateFromCollection(scheduleTasks);
				ScheduleTask task = new ScheduleTask();
				task.ScheduleTypeID = -1;
				task.ScheduleStatusID = -1;
				this.UpdateFromObject(this.pnlTasks.Controls, task);

			}
			else
			{
			}
		}

		// Page bottom toolbar
//		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
//		{
//			base.PopulateToolbarItems (toolbar);
//			ToolbarButtonExtraProperties tbep = toolbar.AddButton("@UPDATE@", "Update");
//			tbep.ChecksForIsDirty = false;
//		}

		public void OnToolbarButtonClick_Update(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			UpdateGridForSelection();
		}

		public void UpdateGridForSelection()
		{
			ScheduleTask task = new ScheduleTask();
			this.UpdateToObject(pnlTasks.Controls, task);
			int typeid = task.ScheduleTypeID;
			int statusid = task.ScheduleStatusID;
			ScheduleTask st = new ScheduleTask();

			ScheduleTaskCollection scheduleTasks = new ScheduleTaskCollection();
			if ( (typeid == -1) && (statusid == -1) )
			{
				scheduleTasks.LoadScheduleTasks(-1);
			}
			else if (statusid == -1)
			{
				scheduleTasks.LoadScheduleTasksByType(-1, task.ScheduleTypeID);
			}
			else if (typeid == -1)
				scheduleTasks.LoadScheduleTasksByStatus(-1, task.ScheduleStatusID);
			else
				scheduleTasks.LoadScheduleTasksByTypeANDStatus(-1, task.ScheduleTypeID, task.ScheduleStatusID);

			gridTasks.ClearRows();
			gridTasks.UpdateFromCollection(scheduleTasks);
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			HttpContext.Current.Response.Redirect("Redirect method must redirect to its own page.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ScheduleTypeID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.ScheduleTypeID_SelectedRowChanged);
			this.ScheduleStatusID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.ScheduleStatusID_SelectedRowChanged);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		/// <summary>
		/// GetAllScheduleTasks()
		/// This method will return the first, pending schedule task
		/// from the schedule list.
		/// </summary>
		/// <returns>ScheduleTask, instance of a ScheduleTask that is pending</returns>
		protected ScheduleTaskCollection GetAllScheduleTasks()
		{
			try
			{
				ScheduleTaskCollection scheduleTasks	= new ScheduleTaskCollection();
				scheduleTasks.LoadScheduleTasks(-1);
				if (scheduleTasks.Count > 0)
					return scheduleTasks;
			}
			catch(Exception e)
			{
				string msg = e.Message;
			}

			return null;
		}

		/// <summary>
		/// ScheduleTypeID_SelectedRowChanged
		/// User has changed the select drop-down, so update the
		/// view in the grid
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void ScheduleTypeID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			UpdateGridForSelection();
		}

		/// <summary>
		/// ScheduleStatusID_SelectedRowChanged
		/// User has changed the select drop-down, so update the
		/// view in the grid
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void ScheduleStatusID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			UpdateGridForSelection();
		}

	}// end of class
}// end of namespace
