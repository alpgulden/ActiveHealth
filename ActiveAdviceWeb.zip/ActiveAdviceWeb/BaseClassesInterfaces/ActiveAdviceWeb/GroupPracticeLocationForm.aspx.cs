using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using ActiveAdvice.Web.UserControls;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	/// 
	[BackPage(typeof(GroupPracticeForm))]
	[MainLanguageClass("ActiveAdvice.Messages.GroupPracticeMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseLocation,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class GroupPracticeLocationForm : ProviderBasePage
	{
		private GroupPracticeLocationNetworkLink selectedGroupPracticeNetwork;
		private GroupPracticeLocationService selectedGroupPracticeService;
		private GroupPracticeLocation baseLocation;
		private Facility facility;
		private GroupPractice groupPractice;
		private GroupPracticeLocationCollection  locationCollection;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResults;
		protected System.Web.UI.WebControls.RadioButton rdBtnName;
		protected System.Web.UI.WebControls.RadioButton rdBtnID;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridLocations;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLocationDetails;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEditServiceAddress;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected System.Web.UI.HtmlControls.HtmlTable tblServiceAddressNote;
		protected System.Web.UI.HtmlControls.HtmlTable tblAddressInfo; 
		protected NetsoftUSA.WebForms.OBTextBox LocationID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLocationID;
		protected System.Web.UI.HtmlControls.HtmlTable tblServiceAddressID;
		protected System.Web.UI.HtmlControls.HtmlTable tblServiceAddressID1;
		protected System.Web.UI.WebControls.ListBox ListBox1;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddService;
		protected NetsoftUSA.InfragisticsWeb.WebGrid WebGrid1;
		protected NetsoftUSA.InfragisticsWeb.WebButton WebButton1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridServices;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlServices;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNetworks;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNetwork;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridNetworks;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveServiceAddress;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelServiceAddrEdit;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel5;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel6;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit WebNumericEdit1;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WebMaskEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel7;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit WebNumericEdit2;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WebMaskEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel8;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel9;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WebMaskEdit3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel10;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel11;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit4;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel12;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit5;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel13;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEditMailingAddress;
		protected System.Web.UI.HtmlControls.HtmlTable tblMailingAddr1;
		protected System.Web.UI.HtmlControls.HtmlTable tblMailingAddr2;
		protected System.Web.UI.HtmlControls.HtmlTable tblMailingAddr3;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelMailingAddr;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveMailingAddr;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DeliveryMethodStr;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeliveryMethodStr;
		protected NetsoftUSA.InfragisticsWeb.WebButton WebButton2;
		protected System.Web.UI.HtmlControls.HtmlTable tblMailingAddr4;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit6;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit WebNumericEdit3;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WebMaskEdit4;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit WebNumericEdit4;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WebMaskEdit5;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel14;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit7;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel15;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WebMaskEdit6;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel16;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit8;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel17;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit9;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel18;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit10;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel19;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEditBillingAddress;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCanceSaveBillingAddr;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveBillingAddress;
		protected System.Web.UI.HtmlControls.HtmlTable tblBillingAddr1;
		protected System.Web.UI.HtmlControls.HtmlTable tblBillingAddr2;
		protected System.Web.UI.HtmlControls.HtmlTable tblBillingAddr3;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGroupPracticeNetworkHistory;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit AsOfDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddGroupPracticeNetworkDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveGroupPracticeNetworkHistoryDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelGroupPracticeNetworkHistoryDates;
		protected System.Web.UI.HtmlControls.HtmlTable tblGroupPracticeNetworkDates;
		private   int selectedNetworkLinkIndex = -1;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveNetwork;
		protected NetsoftUSA.InfragisticsWeb.WebGrid lstServices;
		private int			  selectedServiceIndex = -1;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkDates;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel20;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlServiceDates;
		protected System.Web.UI.HtmlControls.HtmlTable tblMain;
		protected System.Web.UI.HtmlControls.HtmlTable tblServiceEffectiveDate;
		protected System.Web.UI.HtmlControls.HtmlTable tblServiceTerminationDate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNetworkInfo;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForSORG;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNetworkID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtNetworkName;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnProceedNetwork;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelNetwork;
		protected NetsoftUSA.WebForms.OBFieldLabel lblNetworkEffDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit networkLinkEffDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lblNetworkTermDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit networkLinkTermDate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkEffDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnProceed;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelServiceAdd;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNetworkID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator3;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateID;
		protected NetsoftUSA.WebForms.OBTextBox AlternateID;
		private int	selectedServiceType  = -1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusChangedBy;
		protected NetsoftUSA.WebForms.OBTextBox StatusChangedBy;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusChangeDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StatusChangeDate;
		protected System.Web.UI.HtmlControls.HtmlTable tblAddressActiveInfo;
		protected System.Web.UI.HtmlControls.HtmlTable tblAddressActiveInfo1;
		
		protected AddressControl AddressControl;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NetworkID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLine1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Line1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLine1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLine2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Line2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCity;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit City;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCity;
		protected NetsoftUSA.WebForms.OBFieldLabel lbZip;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit Zip;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldZip;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCountry;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Country;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhoneNumber1;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit PhoneNumber1;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PhoneExt1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhoneNumber2;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit PhoneNumber2;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PhoneExt2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbState;
		protected NetsoftUSA.InfragisticsWeb.WebCombo State;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldState;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCounty;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit County;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveNetwork;
		protected System.Web.UI.HtmlControls.HtmlTable tblAddressInfo1;
		protected System.Web.UI.HtmlControls.HtmlTable tblAddressInfo2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected AddressControl AddressControl1;
		protected UserDefined UserDefined1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			AddressControl.RebindControls(typeof(ServiceAddress));
			UserDefined1.ReloadContext("GroupPracticeLocation",baseLocation,true);
			((LocationAddresses)this.FindControl("ctrlLocationAddresses")).ServiceAddressClick += new System.EventHandler(EditServiceAddress);
			((LocationAddresses)this.FindControl("ctrlLocationAddresses")).MailingAddressClick += new System.EventHandler(EditMailingAddress);
			((LocationAddresses)this.FindControl("ctrlLocationAddresses")).BillingAddressClick += new System.EventHandler(EditBillingAddress);
			
			
			
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();
			}
			else
			{
				groupPractice = (GroupPractice)this.LoadObject("locationType");  // load object from cache
				
				//groupPractice = (GroupPractice)this.LoadObject("groupPracticeObj");  // load object from cache
				locationCollection = (GroupPracticeLocationCollection)this.LoadObject("locationTypeCollection");  // load object from cache

				baseLocation = (GroupPracticeLocation)this.LoadObject("baseLocationObj");  // load object from cache
				
				selectedServiceIndex = (int)this.LoadObject("groupPracticeLocationServiceIndex");
				
				selectedNetworkLinkIndex = (int)this.LoadObject("groupPracticeNetworkLinkIndex");
				selectedServiceType		= (int)this.LoadObject("groupPracticeSelectedServiceType");
				selectedGroupPracticeService = (GroupPracticeLocationService)this.LoadObject("selectedGroupPracticeService");  // load object from cache
				selectedGroupPracticeNetwork = (GroupPracticeLocationNetworkLink)this.LoadObject("selectedGroupPracticeNetwork");  // load object from cache

				if (baseLocation != null)
					this.AddressControl.Address = baseLocation.Location.ServiceAddress ;
				
				if (selectedGroupPracticeNetwork==null)
				{
					if (gridNetworks.Rows.Count<=0)	
						this.gridGroupPracticeNetworkHistory.ClearRows();
				}
			}		
			
		}
		
		public int SelectedServiceType
		{
			get { return this.selectedServiceType; }
			set 
			{
				this.selectedServiceType = value;
				this.CacheObject("groupPracticeSelectedServiceType", this.selectedServiceType);
			}
		}

		public int SelectedNetworkLinkIndex
		{
			get { return this.selectedNetworkLinkIndex; }
			set 
			{
				this.selectedNetworkLinkIndex = value;
				this.CacheObject("groupPracticeNetworkLinkIndex", this.selectedNetworkLinkIndex);
				if (BaseLocation != null)
				{
					BaseLocation.LoadNetworks(false);
					GroupPracticeLocationNetworkLink provNetworkLink = BaseLocation.Networks[gridNetworks.SelectedColectionIndex];
					provNetworkLink.LoadEffectiveDatesHistory(true);
					
					//GroupPracticeLocationNetworkHistory currentDate = new GroupPracticeLocationNetworkHistory();
					//currentDate.New();
					//currentDate.AsOfDate					= provNetworkLink.AsOfDate;
					//currentDate.EffectiveDate				= provNetworkLink.EffectiveDate;
					//currentDate.TerminationDate				= provNetworkLink.TerminationDate;
					//currentDate.Active						= provNetworkLink.Active;
					//currentDate.GroupPracticeLocationNetworkID	= provNetworkLink.GroupPracticeLocationNetworkID;
					
					//provNetworkLink.EffectiveDatesHistory.InsertRecord(0,currentDate);
					
					this.gridGroupPracticeNetworkHistory.ClearRows();
					this.gridGroupPracticeNetworkHistory.UpdateFromCollection(provNetworkLink.EffectiveDatesHistory);
					this.tblNetworkDates.Disabled = false;
					
					DisableToolBarButtons();

				}
				
			}
		}

		private void DisableToolBarButtons()
		{
			this.SetPageToolbarItemVisible("Cancel", false);
			this.SetPageToolbarItemVisible("ServiceLocation", false);
		}


		private void AddNetworkLink()
		{
			if (this.SelectedGroupPracticeNetwork != null)
			{
				BaseLocation.Networks.Add(this.selectedGroupPracticeNetwork);
				this.gridNetworks.UpdateFromCollection(BaseLocation.Networks);
				if (gridNetworks.Rows.Count > 0)
					gridNetworks.SelectedRowIndex = 0;
				this.SelectedGroupPracticeNetwork = null;
				this.SelectedNetworkLinkIndex = 0;
			}
		}

		private void AddNewService()
		{
			
			if (this.SelectedGroupPracticeService != null)
			{
				BaseLocation.Services.Add(this.SelectedGroupPracticeService);
				this.SelectedGroupPracticeService = null;
				this.gridServices.UpdateFromCollection(BaseLocation.Services);
				BaseLocation.Services.Save();
				if (gridServices.Rows.Count > 0)
					gridServices.SelectedRowIndex = 0;
			}
		}

		private void TerminateService(int provServID)
		{
			
			if (provServID >= 0)
			{
				//this.gridServices.ClearRows();
				//BaseLocation.Services.FindBy(provServID).MarkDel();
				BaseLocation.SaveServices();
				this.gridServices.UpdateFromCollection(BaseLocation.Services);
				if (gridServices.Rows.Count > 0)
					gridServices.SelectedRowIndex  = 0;
			}

		}

		private void LoadData()
		{
			this.CacheObject("baseLocationObj", null);
			this.CacheObject("locationTypeCollection", null);

			SelectedNetworkLinkIndex = -1;
			
			SelectedServiceIndex = -1;

			SelectedServiceType = -1;

			this.pnlEditServiceAddress.Visible = false;
			this.pnlEditMailingAddress.Visible = false;
			this.pnlEditBillingAddress.Visible = false;
			this.pnlServiceDates.Visible	   = false;
			this.pnlLocationDetails.Visible = false;
			this.pnlNetworks.Visible = false;
			this.pnlServices.Visible = false;
			this.pnlNetworkInfo.Visible = false;

			this.SetPageTabToolbarItemVisible("CopyServiceBilling", false);
			this.SetPageTabToolbarItemVisible("CopyServiceMailing", false);
			this.SetPageTabToolbarItemVisible("AddNewLocation", true);
			tblNetworkDates.Disabled = true;
			DisableNetworkDates(false);

			object paramObj = this.GetParamOrGetFromCache("locationType", "locationType");
			Type objType =  paramObj.GetType();
			if (objType == typeof(GroupPractice))
				this.GroupPractice		= (GroupPractice)paramObj;
			else
				Debug.Fail("Unexcpected type");
		}

		public int SelectedServiceIndex
		{
			get { return this.selectedServiceIndex; } 
			set 
			{ 
				this.selectedServiceIndex = value;
				this.CacheObject("groupPracticeLocationServiceIndex",this.selectedServiceIndex);
				DisableToolBarButtons();
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.GroupPractice, this.BaseLocation);		
		}


		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.RenderClientFunctions(pnlServiceDates.Controls, BaseLocation, "OnCalcServiceDates");

			this.SetPageTabToolbarItemVisible("CopyServiceMailing", false);
			this.SetPageTabToolbarItemVisible("CopyServiceBilling", false);
			this.SetPageTabToolbarItemVisible("Contacts", false);
			this.SetPageTabToolbarItemVisible("AddNewLocation", false);

			if (!this.tblServiceEffectiveDate.Disabled)
				WebValidator3.Enabled = false;


			if (this.pnlEditMailingAddress.Visible && !this.pnlEditBillingAddress.Visible)
				this.SetPageTabToolbarItemVisible("CopyServiceMailing", true);
			if (this.pnlEditBillingAddress.Visible && !this.pnlEditMailingAddress.Visible)
				this.SetPageTabToolbarItemVisible("CopyServiceBilling", true);
			if (this.pnlLocationDetails.Visible || this.pnlResults.Visible)
				this.SetPageTabToolbarItemVisible("AddNewLocation", true);	
			if ((this.pnlLocationDetails.Visible && !this.pnlResults.Visible) || (this.pnlNetworks.Visible && this.pnlServices.Visible))
				this.SetPageTabToolbarItemVisible("Contacts", true );
			
			//btnAddNetwork.Visible = true;
			//			if (gridNetworks.Rows.Count <= 0)
			//				btnRemoveNetwork.Visible = false;
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			this.gridLocations.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridLocations_ClickCellButton);
			this.btnAddService.Click += new System.EventHandler(this.btnAddService_Click);
			this.gridServices.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridServices_DblClick);
			//this.gridServices.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridServices_ClickCellButton);
			this.gridNetworks.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridNetworks_DblClick);
			this.gridNetworks.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridNetworks_ClickCellButton);
			this.lstServices.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.lstServices_DblClick);
			
			this.gridLocations.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridLocations_DblClick);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{  
			this.gridLocations.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridLocations_ClickCellButton);
			this.gridLocations.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridLocations_ColumnsBoundToDataClass);
			this.btnSaveServiceAddress.Click += new System.EventHandler(this.btnSaveServiceAddress_Click);
			this.btnCancelServiceAddrEdit.Click += new System.EventHandler(this.btnCancelServiceAddrEdit_Click);
			this.lstServices.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.lstServices_ColumnsBoundToDataClass);
			this.btnAddService.Click += new System.EventHandler(this.btnAddService_Click);
			this.gridServices.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridServices_ColumnsBoundToDataClass);
			this.WebButton1.Click += new System.EventHandler(this.WebButton1_Click);
			this.gridNetworks.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridNetworks_ClickCellButton);
			this.gridNetworks.InitializeLayout += new Infragistics.WebUI.UltraWebGrid.InitializeLayoutEventHandler(this.gridNetworks_InitializeLayout);
			this.gridNetworks.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridNetworks_ColumnsBoundToDataClass);
			this.btnAddNetwork.Click += new System.EventHandler(this.btnAddNetwork_Click);
			this.btnSaveGroupPracticeNetworkHistoryDates.Click += new System.EventHandler(this.btnSaveGroupPracticeNetworkHistoryDates_Click);
			this.btnCancelGroupPracticeNetworkHistoryDates.Click += new System.EventHandler(this.btnCancelGroupPracticeNetworkHistoryDates_Click);
			this.btnAddGroupPracticeNetworkDates.Click += new System.EventHandler(this.btnAddGroupPracticeNetworkDates_Click);
			this.btnSaveMailingAddr.Click += new System.EventHandler(this.btnSaveMailingAddr_Click);
			this.btnCancelMailingAddr.Click += new System.EventHandler(this.btnCancelMailingAddr_Click);
			this.btnSaveBillingAddress.Click += new System.EventHandler(this.btnSaveBillingAddress_Click);
			this.btnCanceSaveBillingAddr.Click += new System.EventHandler(this.btnCanceSaveBillingAddr_Click);
			this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
			this.btnCancelServiceAdd.Click += new System.EventHandler(this.WebButton3_Click);
			this.btnProceedNetwork.Click += new System.EventHandler(this.btnProceedNetwork_Click);
			this.btnCancelNetwork.Click += new System.EventHandler(this.btnCancelNetwork_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			if (tab.Key == "Locations")
			{
				toolbar.AddButton("@CONTACTS@", "Contacts");
				toolbar.AddButton("@ADDLOCATION@", "AddNewLocation");				
				toolbar.AddButton("@COPYFROMSERVICE@", "CopyServiceMailing");
				toolbar.AddButton("@COPYFROMSERVICE@", "CopyServiceBilling");


			}
		}

		public void OnToolbarButtonClick_CopyServiceMailing(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.CopyAddressFromServiceToMailing();
		}

		public void OnToolbarButtonClick_Contacts(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			ContactSearch.Redirect(this.BaseLocation);
		}

		public void OnToolbarButtonClick_AddNewLocation(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			GroupPracticeLocation provLoc = new GroupPracticeLocation(true);
			//Location loc			= new Location();
			//Address serviceAddress = new ServiceAddress();
			//Address mailingAddress = new Address();
			//Address billingAddress = new Address();

			this.pnlEditBillingAddress.Visible		= true;
			this.pnlEditServiceAddress.Visible		= true;
			this.pnlEditMailingAddress.Visible      = true;
			//this.SetPageToolbarItemVisible("SaveLocation", true);
			this.pnlLocationDetails.Visible			= false;
			this.pnlResults.Visible					= false;
			this.pnlNetworks.Visible				= false;
			this.pnlServices.Visible				= false;	
			this.pnlLocationDetails.Visible			= false;

			// Service
			// ID Info
			//this.UpdateFromObject(this.tblServiceAddressID.Controls, loc);
			// ID Info
			this.UpdateFromObject(this.tblServiceAddressID.Controls, provLoc.Location );
			this.UpdateFromObject(this.tblServiceAddressID1.Controls, provLoc);
			this.UpdateFromObject(this.tblAddressActiveInfo1.Controls, provLoc.Location );	
	
			// Address Info
			this.UpdateFromObject(this.tblAddressInfo.Controls, provLoc.Location.ServiceAddress );
			//this.UpdateFromObject(tblAddressInfo serviceAddress);
			//this.UpdateFromObject(this.tblAddressInfo2.Controls, serviceAddress);

			//Note
			this.UpdateFromObject(this.tblServiceAddressNote.Controls, provLoc);

			//Status Info
			this.UpdateFromObject(this.tblAddressActiveInfo.Controls, provLoc.Location );
			this.UpdateFromObject(this.tblAddressActiveInfo1.Controls, provLoc.Location );

			
			
			this.UpdateFromObject(this.pnlEditBillingAddress.Controls, provLoc.Location.BillingAddress );
			this.UpdateFromObject(this.pnlEditMailingAddress.Controls, provLoc.Location.MailingAddress );

			LocationID.ReadOnly = true;
			LocationID.BackColor = System.Drawing.Color.Transparent;
			LocationID.BorderStyle = System.Web.UI.WebControls.BorderStyle.None;
			

			this.btnSaveBillingAddress.Visible		= false;
			this.btnCanceSaveBillingAddr.Visible	= false;
			this.btnCancelMailingAddr.Visible		= false;
			this.btnSaveMailingAddr.Visible			= false;
			this.btnSaveServiceAddress.Visible		= false;
			this.btnCancelServiceAddrEdit.Visible	= false;

			this.EnableToolBarItems();
		}

		public void OnToolbarButtonClick_CopyServiceBilling(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.CopyAddressFromServiceToBilling();
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@SAVE@","SaveLocation", true, false);
			toolbar.AddButton("@CANCEL@","Cancel",false, true);
			this.SetPageToolbarItemVisible("Cancel", false);
			this.SetPageToolbarItemVisible("SaveLocation", false);
			
		
		}


		public static void Redirect(GroupPractice GroupPractice)
		{
			BasePage.PushParam("groupPracticeObj",GroupPractice);
			BasePage.Redirect("GroupPracticeForm.aspx");
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(Type baseType, int entityID )
		{
			if (typeof(GroupPractice) == baseType)
			{
				GroupPractice gp = new GroupPractice();
				gp.GroupPracticeID	= entityID;
				GroupPracticeLocationForm.PushParam("locationType", gp);
				GroupPracticeLocationForm.Redirect("GroupPracticeLocationForm.aspx");
			}
		}
		private void EnableToolBarItems()
		{
			this.SetPageToolbarItemVisible("Cancel", true);
			this.SetPageToolbarItemVisible("SaveLocation", true);
		}

		public void OnToolbarButtonClick_SaveLocation(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{	
			try
			{

				//				Location loc = new Location();
				//				loc.New();
				GroupPracticeLocation provLoc = new GroupPracticeLocation(true);
			
			
				// ID Info
				this.UpdateToObject(this.tblServiceAddressID.Controls, provLoc.Location );
				this.UpdateToObject(this.tblServiceAddressID1.Controls, provLoc);
				this.UpdateToObject(this.tblAddressActiveInfo1.Controls, provLoc.Location );			
				
				// Address Info
				this.UpdateToObject(this.tblAddressInfo.Controls, provLoc.Location.ServiceAddress  );
				//this.UpdateToObject(this.tblAddressInfo1.Controls, serviceAddress);
				//this.UpdateToObject(this.tblAddressInfo2.Controls, serviceAddress);

				// Note
				this.UpdateToObject(this.tblServiceAddressNote.Controls, provLoc);

				// Status Info
				this.UpdateToObject(this.tblAddressActiveInfo.Controls, provLoc.Location );
				this.UpdateToObject(this.tblAddressActiveInfo1.Controls, provLoc.Location );


				this.UpdateToObject(this.pnlEditBillingAddress.Controls, provLoc.Location.BillingAddress );
				this.UpdateToObject(this.pnlEditMailingAddress.Controls, provLoc.Location.MailingAddress );

				
				provLoc.CreateTime			   = DateTime.Now;
				provLoc.CreatedBy			   = 1;
				provLoc.Location.CreateTime	   = DateTime.Now;
				provLoc.Location.CreatedBy     = 1;

				provLoc.GroupPracticeID		 = this.GroupPractice.GroupPracticeID;
			
				

				provLoc.Location.StatusChangedBy = 1;
				provLoc.ModifiedBy	             = 1;
				

				//this.BaseLocation.Location.ServiceAddressID = srvAddr.AddressID;
				//this.BaseLocation.Location.ServiceAddress.Save();
				provLoc.Save();
				
				this.BaseLocation = provLoc;

				groupPractice.Load(groupPractice.GroupPracticeID);
				groupPractice.LoadLocations(false);
				this.LocationCollection = groupPractice.Locations;	
				
				this.pnlEditBillingAddress.Visible	= false;
				this.pnlEditMailingAddress.Visible	= false;
				this.pnlEditServiceAddress.Visible	= false;
				this.pnlLocationDetails.Visible		= false;
				this.pnlServices.Visible			= false;
				this.pnlNetworks.Visible			= false;
				this.pnlResults.Visible				= true;
				
				//this.SetPageToolbarItemVisible("SaveLocation",false);
				
				
			}
			catch (Exception ex)
			{
				this.RaisePageException(new Exception("An error occurred while saving GroupPractice Location: " + ex.Message));
			}
			

		}
		
		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{		
			object cacheObj =  this.GetParamOrGetFromCache("locationTypeCollection", "locationTypeCollection");
			if (typeof(GroupPracticeLocationCollection) == cacheObj.GetType())
			{
				if (this.pnlEditBillingAddress.Visible && this.pnlEditMailingAddress.Visible && this.pnlEditServiceAddress.Visible)
				{
					this.ShowLocationDetails();
				}
				else
				{
					GroupPracticeForm.PushParam("groupPracticeObj",this.GroupPractice);	
					Response.Redirect("GroupPracticeForm.aspx");
				}
			}
			
			else
				Debug.Fail("Unexpected type.");
		}

	
	
		private void DisablePanels(bool addressSummary, bool networks, bool networkEffDates, bool services)
		{
			this.pnlLocationDetails.Visible = addressSummary;
			this.pnlNetworks.Visible		= networks;
			this.pnlServices.Visible		= services;
			this.tblNetworkDates.Visible    = networkEffDates;
		}
		

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeLocationCollection LocationCollection
		{
			get { return locationCollection; }
			set
			{
				locationCollection = value;
				try
				{
					this.gridLocations.UpdateFromCollection(locationCollection);
					if (gridLocations.Rows.Count > 0)
						gridLocations.SelectedRowIndex = 0;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("locationTypeCollection", locationCollection);  // cache object using the caching method declared on the page
			}
		}

		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPractice GroupPractice
		{
			get { return groupPractice; }
			set
			{
				groupPractice = value;
				try
				{
					groupPractice.Load(groupPractice.GroupPracticeID);
					groupPractice.LoadLocations(false);
					this.LocationCollection = groupPractice.Locations;	
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("locationType", groupPractice);  // cache object using the caching method declared on the page
				this.SetPageToolbarItemVisible("Cancel",true);
			}
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			listbar.AddItem("@DETAILS@", "Details");
			base.PopulateSubNavigation (listbar);
		}


		public void OnSubNavigationItemClick_Details(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			//BasePage.PushParam("groupPractice", this.GroupPractice);
			GroupPracticeForm.Redirect(this.GroupPractice.GroupPracticeID);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Facility Facility
		{
			get { return facility; }
			set
			{
				facility = value;
				try
				{
					facility.LoadLocations(false);
					//this.LocationCollection = facility.Locations;	
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("facilityObj", facility);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeLocation BaseLocation
		{
			get { return baseLocation; }
			set
			{
				baseLocation = value;

				try
				{
					this.UpdateFromObject(this.pnlLocationDetails.Controls, baseLocation);  // update controls for the given control collection
					LocationAddresses locAddr			= (LocationAddresses)this.pnlLocationDetails.FindControl("ctrlLocationAddresses");
					locAddr.Location					= this.baseLocation;			
					this.gridServices.ClearRows();
					BaseLocation.LoadNetworks(true);
					this.gridNetworks.UpdateFromCollection(BaseLocation.Networks);
					if (gridNetworks.Rows.Count > 0)
					{
						gridNetworks.SelectedRowIndex = 0;
						GroupPracticeLocationNetworkLink provNetworkLink = BaseLocation.Networks[gridNetworks.SelectedColectionIndex];
						provNetworkLink.LoadEffectiveDatesHistory(true);
						this.gridGroupPracticeNetworkHistory.UpdateFromCollection(provNetworkLink.EffectiveDatesHistory);
					}		

					this.tblNetworkDates.Disabled = false;
					//DisableNetworkDates(true);
					
					BaseLocation.LoadServices(true);
					this.gridServices.ClearRows();
					this.gridServices.UpdateFromCollection(BaseLocation.Services);		
					if (gridServices.Rows.Count > 0)
						gridServices.SelectedRowIndex = 0;
					ShowLocationDetails();	

					if (baseLocation != null)
						this.AddressControl.Address = baseLocation.Location.ServiceAddress ;
					UserDefined1.ReloadContext("GroupPracticeLocation",baseLocation,false);

					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("baseLocationObj", baseLocation);  // cache object using the caching method declared on the page
		
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForBaseLocation()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.Controls, baseLocation);	// controls-to-object
				// other control-to-object methods if any
				UserDefined1.ReadControls();
				baseLocation.UserDefined = UserDefined1.UserDefinedValue;
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		public void EditBillingAddress(object sender, EventArgs e)
		{
			this.UpdateFromObject(this.tblBillingAddr1.Controls, this.BaseLocation.Location.BillingAddress);
			this.UpdateFromObject(this.tblBillingAddr2.Controls, this.BaseLocation.Location.BillingAddress);
			this.UpdateFromObject(this.tblBillingAddr3.Controls, this.BaseLocation.Location.BillingAddress);

			this.pnlLocationDetails.Visible = false;
			this.pnlResults.Visible = false;
			this.pnlEditServiceAddress.Visible = false;
			this.pnlServices.Visible = false;
			this.pnlNetworks.Visible = false;
			this.pnlEditMailingAddress.Visible = false;
			this.pnlEditBillingAddress.Visible = true;
			
			this.SetPageTabToolbarItemVisible("CopyServiceMailing", false);
			this.SetPageTabToolbarItemVisible("AddNewLocation", false);
			this.SetPageTabToolbarItemVisible("CopyServiceBilling", true);

			this.btnSaveBillingAddress.Visible = true;
			this.btnCanceSaveBillingAddr.Visible = true;

			DisableToolBarButtons();
			
		}


		public void EditServiceAddress(object sender, EventArgs e)
		{
			// ID Info
			this.UpdateFromObject(this.tblServiceAddressID.Controls, this.BaseLocation.Location);
			this.UpdateFromObject(this.tblServiceAddressID1.Controls, (this.BaseLocation));
			this.UpdateFromObject(this.tblAddressActiveInfo1.Controls, this.BaseLocation.Location);			


			
			// Address Info
			this.UpdateFromObject(this.tblAddressInfo.Controls, this.BaseLocation.Location.ServiceAddress);
			//this.UpdateFromObject(this.tblAddressInfo1.Controls, this.BaseLocation.Location.ServiceAddress);
			//this.UpdateFromObject(this.tblAddressInfo2.Controls, this.BaseLocation.Location.ServiceAddress);

			// Note
			this.UpdateFromObject(this.tblServiceAddressNote.Controls, this.BaseLocation);

			// Status Info
			this.UpdateFromObject(this.tblAddressActiveInfo.Controls, this.BaseLocation.Location);
			this.UpdateFromObject(this.tblAddressActiveInfo1.Controls, this.BaseLocation.Location);

			this.pnlLocationDetails.Visible = false;
			this.pnlResults.Visible = false;
			this.pnlEditServiceAddress.Visible = true;
			this.pnlServices.Visible = false;
			this.pnlNetworks.Visible = false;
			this.pnlEditMailingAddress.Visible = false;
			this.pnlEditBillingAddress.Visible = false;
			
			this.btnSaveServiceAddress.Visible = true;
			this.btnCanceSaveBillingAddr.Visible = true;

			DisableToolBarButtons();



		}

		public void EditMailingAddress(object sender, EventArgs e)
		{
			this.UpdateFromObject(this.tblMailingAddr1.Controls, BaseLocation.Location.MailingAddress);
			this.UpdateFromObject(this.tblMailingAddr2.Controls, BaseLocation.Location.MailingAddress);
			this.UpdateFromObject(this.tblMailingAddr3.Controls, BaseLocation.Location.MailingAddress);
			this.UpdateFromObject(this.tblMailingAddr4.Controls, BaseLocation.Location.MailingAddress);


			this.pnlLocationDetails.Visible = false;
			this.pnlResults.Visible = false;
			this.pnlEditServiceAddress.Visible = false;
			this.pnlEditMailingAddress.Visible = true;
			this.pnlServices.Visible = false;
			this.pnlNetworks.Visible = false;
			this.pnlEditBillingAddress.Visible  = false;

			this.SetPageTabToolbarItemVisible("CopyServiceBilling", false);
			this.SetPageTabToolbarItemVisible("CopyServiceMailing", true);
			this.SetPageTabToolbarItemVisible("AddNewLocation", false);

			this.btnSaveMailingAddr.Visible = true;
			this.btnCancelMailingAddr.Visible = true;

			DisableToolBarButtons();

		}

		private void btnAddService_Click(object sender, System.EventArgs e)
		{
			
			if (lstServices.SelectedRowIndex >=0)
			{
				int groupPracticeServiceTypeID = -1;
				bool resume = true;
				GroupPracticeLocationService curService = null;
				
				
				groupPracticeServiceTypeID = (int)lstServices.SelectedRowPK[0];
			
				for (int i = 0; i < gridServices.Rows.Count; i++)
				{ 
					int index = gridServices.GetColIndexFromRowIndex(i);
					curService = BaseLocation.Services[index];
					if ((groupPracticeServiceTypeID == curService.GroupPracticeServiceTypeID) && (curService.TerminationDate == DateTime.MinValue))
					{
						resume = false;
						break;
					}
				}
				
				if (resume)
				{
					try
					{
						// get GroupPracticeServiceTypeID
						groupPracticeServiceTypeID = (int)lstServices.SelectedRowPK[0];
						GroupPracticeLocationService provService			= new GroupPracticeLocationService();
						provService.New();
						provService.GroupPracticeLocationID				= BaseLocation.GroupPracticeLocationID;
						provService.GroupPracticeServiceTypeID			= groupPracticeServiceTypeID;
						provService.CreatedBy						= 1; // Context.UserID
						provService.CreateTime						= DateTime.Now;
						this.SelectedGroupPracticeService = provService;
						
						this.DisablePanels(false, false, false, true);
						this.pnlServiceDates.Visible = true;
						this.tblServiceEffectiveDate.Visible = true;
						this.tblServiceEffectiveDate.Disabled = false; // dont remove
						SetItemEnabledServEffDates(true);
						
						this.tblServiceTerminationDate.Visible = false;

						this.UpdateFromObject(pnlServices.Controls, provService);
						
					}
					catch (Exception ex)
					{
						this.RaisePageException(ex);
					}
				}
				else
					this.SetPageMessage("Service already exists and is active.",NetsoftUSA.WebForms.EnumPageMessageType.Info);
			}
			else
				this.SetPageMessage("@SELECTSERVICE@",NetsoftUSA.WebForms.EnumPageMessageType.Warning);
			DisableToolBarButtons();
		}



		private void gridServices_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				this.SelectedServiceIndex = (int)gridServices.SelectedRowPK[0];
		
			}
		}

		

		private void WebButton1_Click(object sender, System.EventArgs e)
		{
			if (gridServices.SelectedRowIndex >= 0)
				InactivateSelectedIndex(gridServices.SelectedColectionIndex);
			else
				this.SetPageMessage("@SELECTPROVSERV@",NetsoftUSA.WebForms.EnumPageMessageType.Warning);
		}

		private void InactivateSelectedIndex(int groupPracticeServColIndex)
		{
			if (groupPracticeServColIndex >= 0)
			{
				GroupPracticeLocationService provService = null;
				provService = BaseLocation.Services[groupPracticeServColIndex];
				this.SelectedGroupPracticeService = provService;
				this.DisablePanels(false, false, false, true);			
				this.pnlServiceDates.Visible = true;
				this.tblServiceEffectiveDate.Disabled = true;
				SetItemEnabledServEffDates(false);
				this.tblServiceTerminationDate.Visible = true;
				WebDateTimeEdit2.Enabled = false;
			}

		}
	
		private void SetItemEnabledServEffDates(bool val)
		{
			this.WebDateTimeEdit2.Enabled = val;
			this.OBFieldLabel20.Enabled = val;
		}



		private void OpenSearchWindow(string target)
		{
			Page.RegisterStartupScript("openSearchWindow", "<script language=\"javascript\">window.open(\"" + target + "\",\"dateWindow\",\"width=800,height=800,scrollable=yes,resizable=yes\");</script>");
		}

		private void btnAddNetwork_Click(object sender, System.EventArgs e)
		{
			this.SelectedGroupPracticeNetwork = new GroupPracticeLocationNetworkLink();
			this.SelectedGroupPracticeNetwork.New();
			this.SelectedGroupPracticeNetwork.GroupPracticeLocationID = this.BaseLocation.GroupPracticeLocationID;
			this.SelectedGroupPracticeNetwork.CreatedBy  = 1;
			this.SelectedGroupPracticeNetwork.CreateTime = DateTime.Now.Date;
			this.UpdateFromObject(this.pnlNetworkInfo.Controls, this.selectedGroupPracticeNetwork);
			this.pnlNetworkInfo.Visible = true;
			this.DisablePanels(false, true, false, false);
			btnAddNetwork.Visible = false;
			btnAddGroupPracticeNetworkDates.Visible  = false ;
			//if (gridNetworks.Rows.Count <= 0)
			//	btnRemoveNetwork.Visible = false;
			DisableToolBarButtons();
		}
		private void StatusChangeDate_ValueChange(object sender, Infragistics.WebUI.WebDataInput.ValueChangeEventArgs e)
		{
			UpdateStatusInfo();
		}

		private void Active_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateStatusInfo();
		}

		private void UpdateStatusInfo()
		{
			if (this.BaseLocation != null && this.BaseLocation.Location != null)
			{
				Location loc = BaseLocation.Location;
				this.UpdateToObject(this.tblAddressActiveInfo.Controls, BaseLocation.Location);
				this.UpdateToObject(this.tblAddressActiveInfo1.Controls, BaseLocation.Location);
				// save
				this.BaseLocation.Location.Save();
			}
		}

		private void btnSaveServiceAddress_Click(object sender, System.EventArgs e)
		{
			try
			{
				// ID Info
				this.UpdateToObject(this.tblServiceAddressID.Controls, this.BaseLocation.Location);
				this.UpdateToObject(this.tblServiceAddressID1.Controls, this.BaseLocation);
				this.UpdateToObject(this.tblAddressActiveInfo1.Controls, this.BaseLocation.Location);			

				//ServiceAddress srvAddr = new ServiceAddress();
				//srvAddr.New();
				// Address Info
				this.UpdateToObject(this.tblAddressInfo.Controls, this.BaseLocation.Location.ServiceAddress);
				//this.UpdateToObject(this.tblAddressInfo1.Controls, this.BaseLocation.Location.ServiceAddress);
				//this.UpdateToObject(this.tblAddressInfo2.Controls, this.BaseLocation.Location.ServiceAddress);

				// Note
				this.UpdateToObject(this.tblServiceAddressNote.Controls, this.BaseLocation);

				// Status Info
				this.UpdateToObject(this.tblAddressActiveInfo.Controls, this.BaseLocation.Location);
				this.UpdateToObject(this.tblAddressActiveInfo1.Controls, this.BaseLocation.Location);

				//loc.MailingAddress = mailingAddress;
				//loc.BillingAddress = billingAddress;
				//this.BaseLocation.Location.ServiceAddressID = 
				this.BaseLocation.Location.StatusChangedBy	= 1;
				this.BaseLocation.ModifiedBy				= 1;
				//this.BaseLocation.Location.ServiceAddressID = srvAddr.AddressID;
				//this.BaseLocation.Location.ServiceAddress.Save();
				BaseLocation.Save();
				this.BaseLocation = this.baseLocation;
				ShowLocationDetails();
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void ShowLocationDetails()
		{
		
			

			
			this.pnlLocationDetails.Visible		= true;
			this.pnlResults.Visible				= false;
			this.pnlServices.Visible			= true;
			this.pnlNetworks.Visible			= true;
			this.pnlEditServiceAddress.Visible  = false;
			this.pnlEditMailingAddress.Visible  = false;
			this.pnlEditBillingAddress.Visible  = false;

			this.SetPageTabToolbarItemVisible("CopyServiceBilling", false);
			this.SetPageTabToolbarItemVisible("CopyServiceMailing", false);
			this.SetPageTabToolbarItemVisible("AddNewLocation", true);

			DisableToolBarButtons();

		}

		private void btnCancelServiceAddrEdit_Click(object sender, System.EventArgs e)
		{
			ShowLocationDetails();
		}

		private void btnCopyFromService_Click(object sender, System.EventArgs e)
		{
			CopyAddressFromServiceToMailing();
		}

		private void CopyAddressFromServiceToMailing()
		{
			object obj = this.BaseLocation.Location.ServiceAddress;
			this.UpdateFromObject(this.tblMailingAddr1.Controls, obj);
			this.UpdateFromObject(this.tblMailingAddr2.Controls, obj);
			this.UpdateFromObject(this.tblMailingAddr3.Controls, obj);


			this.SetPageTabToolbarItemVisible("CopyServiceBilling", false);
			this.SetPageTabToolbarItemVisible("CopyServiceMailing", true);
			this.SetPageTabToolbarItemVisible("AddNewLocation", false);
			DisableToolBarButtons();
		}

		private void btnSaveMailingAddr_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.UpdateToObject(this.tblMailingAddr1.Controls, this.BaseLocation.Location.MailingAddress);
				this.UpdateToObject(this.tblMailingAddr2.Controls, this.BaseLocation.Location.MailingAddress);
				this.UpdateToObject(this.tblMailingAddr3.Controls, this.BaseLocation.Location.MailingAddress);		

				this.BaseLocation.Location.StatusChangedBy	= 1;
				this.BaseLocation.ModifiedBy				= 1;
				//this.BaseLocation.Location.ServiceAddressID = srvAddr.AddressID;
				//this.BaseLocation.Location.ServiceAddress.Save();
				BaseLocation.Save();
				this.BaseLocation = this.baseLocation;
				ShowLocationDetails();
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void btnCancelMailingAddr_Click(object sender, System.EventArgs e)
		{
			ShowLocationDetails();
		}

		private void btnCanceSaveBillingAddr_Click(object sender, System.EventArgs e)
		{
			ShowLocationDetails();
		}

		private void btnCopyBillingFromService_Click(object sender, System.EventArgs e)
		{
			CopyAddressFromServiceToBilling();
		}

		private void CopyAddressFromServiceToBilling()
		{
			Address obj = this.BaseLocation.Location.ServiceAddress;
			this.UpdateFromObject(this.tblBillingAddr1.Controls, obj);
			this.UpdateFromObject(this.tblBillingAddr2.Controls, obj);
			this.UpdateFromObject(this.tblBillingAddr3.Controls, obj);

			this.SetPageTabToolbarItemVisible("CopyServiceBilling", true);
			this.SetPageTabToolbarItemVisible("CopyServiceMailing", false);
			this.SetPageTabToolbarItemVisible("AddNewLocation", false);

			DisableToolBarButtons();
		}


		private void btnSaveBillingAddress_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.UpdateToObject(this.tblBillingAddr1.Controls, this.BaseLocation.Location.BillingAddress);
				this.UpdateToObject(this.tblBillingAddr2.Controls, this.BaseLocation.Location.BillingAddress);
				this.UpdateToObject(this.tblBillingAddr3.Controls, this.BaseLocation.Location.BillingAddress);

				this.BaseLocation.Location.StatusChangedBy	= 1;
				this.BaseLocation.ModifiedBy				= 1;
				//this.BaseLocation.Location.ServiceAddressID = srvAddr.AddressID;
				//this.BaseLocation.Location.ServiceAddress.Save();
				BaseLocation.Save();
				this.BaseLocation = this.baseLocation;

				ShowLocationDetails();
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}

		}

		private void btnAddGroupPracticeNetworkDates_Click(object sender, System.EventArgs e)
		{
			if (this.SelectedNetworkLinkIndex >= 0)
			{
				GroupPracticeLocationNetworkHistory provNetworkHistory = new GroupPracticeLocationNetworkHistory();
				this.tblGroupPracticeNetworkDates.Disabled = false;
				DisableNetworkDates(true);
				this.UpdateFromObject(this.tblGroupPracticeNetworkDates.Controls, provNetworkHistory);
				this.AsOfDate.Value = DateTime.Now.Date;
			}
			else
				this.SetPageMessage("@SELECTPROVNETWORK@", NetsoftUSA.WebForms.EnumPageMessageType.Warning);
			DisableToolBarButtons();
		}

		private void btnCancelGroupPracticeNetworkHistoryDates_Click(object sender, System.EventArgs e)
		{
			GroupPracticeLocationNetworkHistory provNetworkHistory = new GroupPracticeLocationNetworkHistory();
			DisableNetworkDates(false);
			this.UpdateFromObject(this.tblGroupPracticeNetworkDates.Controls, provNetworkHistory);
			DisableToolBarButtons();
			
		}

		private void gridNetworks_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				this.SelectedNetworkLinkIndex = e.Cell.Row.Index;

				
			}
		}

		private void btnSaveGroupPracticeNetworkHistoryDates_Click(object sender, System.EventArgs e)
		{
			GroupPracticeLocationNetworkHistory provNetworkHistory = new GroupPracticeLocationNetworkHistory();
			this.UpdateToObject(this.tblGroupPracticeNetworkDates.Controls, provNetworkHistory);
			provNetworkHistory.AsOfDate = (DateTime)this.AsOfDate.Value;
			// check all dates for duplicates
			GroupPracticeLocationNetworkLink linkCheck = new GroupPracticeLocationNetworkLink();
			linkCheck.Load(this.SelectedNetworkLinkIndex);
			linkCheck.LoadEffectiveDatesHistory(false);
			
			bool resume = true;
			for (int i = 0 ; i < linkCheck.EffectiveDatesHistory.Count; i++)
			{
				if 	(((((GroupPracticeLocationNetworkHistory)BaseLocation.Networks.GetAt(i)).EffectiveDate == provNetworkHistory.EffectiveDate) && ((GroupPracticeLocationNetworkHistory)BaseLocation.Networks.GetAt(i)).EffectiveDate == provNetworkHistory.EffectiveDate))
				{
					resume = false;
					break;
				}
			}
			// check for current date too
			resume = (linkCheck.EffectiveDate == provNetworkHistory.EffectiveDate && linkCheck.TerminationDate == provNetworkHistory.TerminationDate) ? false : true;
			if (resume)
			{
				try
				{
					GroupPracticeLocationNetworkLink provCurrentLink = BaseLocation.Networks.GetAt(this.SelectedNetworkLinkIndex) as GroupPracticeLocationNetworkLink;
					// move current record to archive and mark it Inactive
					provCurrentLink.LoadEffectiveDatesHistory(false);
					GroupPracticeLocationNetworkHistory provCurrentDates = new GroupPracticeLocationNetworkHistory();
					//GroupPracticeLocationNetworkHistory provDate = new GroupPracticeLocationNetworkHistory();

					provCurrentDates.New();
					provCurrentDates.AsOfDate						= provNetworkHistory.AsOfDate;
					provCurrentDates.EffectiveDate					= provNetworkHistory.EffectiveDate;
					provCurrentDates.TerminationDate				= provNetworkHistory.TerminationDate;
					provCurrentDates.Active							= true;
					
					provCurrentLink.EffectiveDatesHistory.Add(provCurrentDates);
					
					//GroupPracticeLocationNetworkHistoryCollection coll = provCurrentLink.EffectiveDatesHistory;

					//provDate.New();
					//provDate.AsOfDate						= provNetworkHistory.AsOfDate;
					//provDate.EffectiveDate					= provNetworkHistory.EffectiveDate;
					//provDate.TerminationDate				= provNetworkHistory.TerminationDate;
					//provDate.Active							= true;
					
					//provCurrentLink.EffectiveDatesHistory.Add(provDate);

					// migrate new date info into Link
					//provCurrentLink.EffectiveDate					= provNetworkHistory.EffectiveDate;
					//provCurrentLink.TerminationDate					= provNetworkHistory.TerminationDate;
					//provCurrentLink.AsOfDate						= provNetworkHistory.AsOfDate;
					//provDate.Active = provCurrentDates.Active = provCurrentLink.Active = ((provCurrentLink.TerminationDate <= provCurrentLink.EffectiveDate) || (provCurrentLink.TerminationDate <= DateTime.Now.Date)) ? false : true;

					provNetworkHistory.Active = true;

					GroupPracticeLocationNetworkHistoryCollection provColHistoryCol = new GroupPracticeLocationNetworkHistoryCollection();
					provColHistoryCol.UpdateStatusForGroupPracticeLocationNetworkHistory(-1,provNetworkHistory,provCurrentLink.GroupPracticeLocationNetworkID);
					
					provCurrentDates.Save();

					//provCurrentLink.EffectiveDatesHistory.RemoveRecord(provDate);
	
					//this.gridGroupPracticeNetworkHistory.UpdateFromCollection(provCurrentLink.EffectiveDatesHistory);
					
					//this.SelectedNetworkLinkIndex = this.selectedNetworkLinkIndex;
					this.SelectedNetworkLinkIndex = 0;
					GroupPracticeLocationNetworkHistory blankHistory = new GroupPracticeLocationNetworkHistory();
					this.UpdateFromObject(this.tblGroupPracticeNetworkDates.Controls, blankHistory);
					DisableNetworkDates(false);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			else
				this.SetPageMessage("@DUPLICATEDATES@",NetsoftUSA.WebForms.EnumPageMessageType.Error);
		}

		private void DisableNetworkDates(bool val)
		{
			btnSaveGroupPracticeNetworkHistoryDates.Enabled = btnCancelGroupPracticeNetworkHistoryDates.Enabled = val;
			lbEffectiveDate.Enabled =  EffectiveDate.Enabled = lbTerminationDate.Enabled	= val;
			TerminationDate.Enabled = lbAsOfDate.Enabled	=  AsOfDate.Enabled	= val;
		}

		private void gridServices_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			if (e.Cell != null)
				this.SelectedServiceIndex = e.Cell.Row.Index;
			else if (e.Row != null)
				this.SelectedServiceIndex = e.Row.Index;
		}

		private void gridNetworks_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			if (e.Cell != null)
				this.SelectedNetworkLinkIndex = e.Cell.Row.Index;
			else if (e.Row != null)
				this.SelectedNetworkLinkIndex = e.Row.Index;
		}

		//	private void btnRemoveNetwork_Click(object sender, System.EventArgs e)
		//	{
		//			if (gridNetworks.SelectedRowIndex >= 0)
		//			{
		//				try
		//				{
		//					BaseLocation.Networks[gridNetworks.SelectedColectionIndex].MarkDel();
		//					this.gridNetworks.UpdateFromCollection(BaseLocation.Networks);
		//					if (gridNetworks.Rows.Count > 0)
		//						gridNetworks.SelectedRowIndex = 0;
		//				}
		//				catch (Exception ex)
		//				{
		//					this.RaisePageException(ex);
		//				}
		//			}
		//			else
		//				this.SetPageMessage("@SELECTNETWORK@", NetsoftUSA.WebForms.EnumPageMessageType.Warning);
		//	}

		private void gridLocations_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
				SelectLocation(gridLocations.SelectedColectionIndex);			
		}

		private void SelectLocation(int groupPracticeLocationIndex)
		{
			if (groupPracticeLocationIndex != -1)
			{
				try
				{
					this.BaseLocation = LocationCollection[groupPracticeLocationIndex];
					if (this.GroupPractice != null)
					{
						lstServices.UpdateFromCollection(GroupPracticeServiceTypeCollection.ActiveGroupPracticeServiceTypes);															
						if (lstServices.Rows.Count > 0)
							lstServices.SelectedRowIndex = 0;
						DisableToolBarButtons();
					}	
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}		
		}



		private void lstServices_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			this.SelectedServiceType = (int)lstServices.SelectedRowPK[0];
		}



		private void lstServices_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
				this.SelectedServiceType = (int)lstServices.SelectedRowPK[0];
		}

		private void btnProceed_Click(object sender, System.EventArgs e)
		{
				if (!this.tblServiceEffectiveDate.Disabled)
			{
				this.UpdateToObject(this.pnlServiceDates.Controls, this.SelectedGroupPracticeService, true);
				this.AddNewService();
			}
			else
			{

				BaseLocation.Services.IndexBy_GroupPracticeServiceID.Rebuild();
				GroupPracticeLocationService provServ = BaseLocation.Services.FindBy(SelectedGroupPracticeService.GroupPracticeServiceID);
				this.UpdateToObject(this.pnlServiceDates.Controls, provServ, true);
				
				this.TerminateService(provServ.GroupPracticeServiceID);
				this.SelectedGroupPracticeService = null;
				
			}
			
			this.pnlServiceDates.Visible = false;
			this.DisablePanels(true, true, true, true);
			
		}


		private void gridLocations_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			SelectLocation(gridLocations.SelectedColectionIndex);
		}

		private void btnProceedNetwork_Click(object sender, System.EventArgs e)
		{
			this.UpdateToObject(this.tblNetworkEffDates.Controls, this.selectedGroupPracticeNetwork);
			this.selectedGroupPracticeNetwork.NetworkID = (int)this.NetworkID.Value;
			
			
					
			this.selectedGroupPracticeNetwork.Save();
			this.AddNetworkLink();
			//AddCorrespondingHistory(this.selectedGroupPracticeNetwork);
			this.selectedGroupPracticeNetwork = BaseLocation.Networks[gridNetworks.Rows.Count-1];
			this.selectedGroupPracticeNetwork.LoadEffectiveDatesHistory(true);
					
			GroupPracticeLocationNetworkHistory currentDate = new GroupPracticeLocationNetworkHistory();
			currentDate.New();
			currentDate.AsOfDate					= this.selectedGroupPracticeNetwork.AsOfDate;
			currentDate.EffectiveDate				= this.selectedGroupPracticeNetwork.EffectiveDate;
			currentDate.TerminationDate				= this.selectedGroupPracticeNetwork.TerminationDate;
			currentDate.Active						= this.selectedGroupPracticeNetwork.Active;
			currentDate.GroupPracticeLocationNetworkID	= this.selectedGroupPracticeNetwork.GroupPracticeLocationNetworkID;
			// inserts a corresponding record in the history table				
			this.selectedGroupPracticeNetwork.EffectiveDatesHistory.InsertRecord(0,currentDate);
			this.selectedGroupPracticeNetwork.EffectiveDatesHistory.Save();
			
			this.gridGroupPracticeNetworkHistory.ClearRows();

			// displays the 1st Network's corresponding Network history in the History Grid whenever we add a providerlocation network info
			if (gridNetworks.Rows.Count > 0)
			{
				gridNetworks.SelectedRowIndex = 0;
				GroupPracticeLocationNetworkLink provNetworkLink = BaseLocation.Networks[gridNetworks.SelectedColectionIndex];
				provNetworkLink.LoadEffectiveDatesHistory(true);
				this.gridGroupPracticeNetworkHistory.UpdateFromCollection(provNetworkLink.EffectiveDatesHistory);
			}
			

			this.pnlNetworkInfo.Visible = false;
			this.DisablePanels(true, true, true, true);
			// To Make the Add Network button visible again 
			btnAddNetwork.Visible = true;
			btnAddGroupPracticeNetworkDates.Visible = true;	

		}

		private void btnCancelNetwork_Click(object sender, System.EventArgs e)
		{
			this.SelectedGroupPracticeNetwork = null;
			this.pnlNetworkInfo.Visible = false;
			this.DisablePanels(true, true, true, true);
		}

		private void gridNetworks_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			this.gridNetworks.AddButtonColumn("Select", "@SELECT@",0);
			//this.SelectedNetworkLinkIndex = 0;
		}

		private void WebButton3_Click(object sender, System.EventArgs e)
		{
			this.SelectedGroupPracticeService = null;
			this.DisablePanels(true, true, true, true);
			this.pnlServiceDates.Visible = false;
		}

		private void gridLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			this.gridLocations.AddButtonColumn("Select", "@SELECT@", 0).Width = 45;
		}

		private void gridServices_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			//this.gridServices.AddButtonColumn("Select", "@SELECT@", 0).Width = 60;
			
		}

		private void lstServices_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			//this.lstServices.AddButtonColumn("Select", "@SELECT@", 0);
		}

		private void PhoneNumber1_ValueChange(object sender, Infragistics.WebUI.WebDataInput.ValueChangeEventArgs e)
		{
		
		}

		private void gridNetworks_InitializeLayout(object sender, Infragistics.WebUI.UltraWebGrid.LayoutEventArgs e)
		{
		
		}







		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeLocationService SelectedGroupPracticeService
		{
			get { return selectedGroupPracticeService; }
			set
			{
				selectedGroupPracticeService = value;
				try
				{
					this.UpdateFromObject(this.pnlServiceDates.Controls, selectedGroupPracticeService);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedGroupPracticeService", selectedGroupPracticeService);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeLocationNetworkLink SelectedGroupPracticeNetwork
		{
			get { return selectedGroupPracticeNetwork; }
			set
			{
				selectedGroupPracticeNetwork = value;
				try
				{
					this.UpdateFromObject(this.pnlNetworkInfo.Controls, selectedGroupPracticeNetwork);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedGroupPracticeNetwork", selectedGroupPracticeNetwork);  // cache object using the caching method declared on the page
			}
		}
	}
}
