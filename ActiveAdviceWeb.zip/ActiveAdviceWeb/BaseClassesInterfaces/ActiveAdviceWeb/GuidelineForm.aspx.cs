using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;


namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for GuidelineForm.
	/// </summary>
	public class GuidelineForm : BasePage
	{
		protected Infragistics.WebUI.UltraWebTab.UltraWebTab UltraWebTab1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuideline;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGuidelineSourceSetID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GuidelineSourceSetID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGuidelineSourceSetID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldText;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Text;
		protected NetsoftUSA.WebForms.OBFieldLabel lbText;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGuidelineTip;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit GuidelineTip;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGuidelineTip;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCodes;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlIndicators;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddNew;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlIndicator;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGuidelineIndicatorTip;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit GuidelineIndicatorTip;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGuidelineIndicatorTip;
		protected NetsoftUSA.WebForms.OBCheckBox OBCheckBox1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldType2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Type2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbType2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldType1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Type1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbType1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSortSequence;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit SortSequence;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSortSequence;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDefaultNote;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit DefaultNote;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDefaultNote;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInstruction;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Instruction;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInstruction;
		protected NetsoftUSA.WebForms.OBCheckBox NoteRequired;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNoteRequired;
		protected NetsoftUSA.WebForms.OBCheckBox Selectable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSelectable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHierarchy;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Hierarchy;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHierarchy;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGuidelineID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit GuidelineID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGuidelineID;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid1;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnChangeDxCode;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnChangePxCode;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
