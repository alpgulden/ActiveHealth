using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.GroupPracticeMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("GroupPractice,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class GroupPracticeForm : ProviderBasePage
	{
		//private GroupPracticeGroupPracticeLinkCollection groupPracticeGroupPracticeLinks;
		//private GroupPracticeGroupPracticeLink selectedGroupPracticeGroupPractice;
		//private GroupPracticeSpecialty selectedGroupPracticeSpecialty;
		private GroupPracticeProviderLinkCollection groupPracticeProviderLinks;
		private GroupPracticeProviderLink selectedGroupPracticeProvider;
		private GroupPracticeFocus selectedGroupPracticeFocus;
		private GroupPractice groupPractice;
		private Location selectedLocation;
		private Address selectedGroupPracticeAddress;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlBasicInfo;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Gender;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGender;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Email;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEmail;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit Beeper;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBeeper;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSuffixId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PrefixId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrefixId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit GroupPracticeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		//protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLanguages;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		//protected NetsoftUSA.InfragisticsWeb.WebGrid lstLanguages;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnAddLanguage;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveLanguage;
		//protected NetsoftUSA.InfragisticsWeb.WebGrid gridGroupPracticeLanguages;
		//protected NetsoftUSA.InfragisticsWeb.WebGrid gridGroupPracticeFocuses;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveFocus;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnAddFocus;
		//protected NetsoftUSA.InfragisticsWeb.WebGrid lstFocuses;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		//protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGroupPracticeFocuses;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGPNote;
		protected NetsoftUSA.WebForms.OBLabel OBLabel11;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGroupPracticeSpecialties;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveSpecialty;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnAddSpecialty;
		protected System.Web.UI.WebControls.ListBox lstGroupPracticeSpecialties;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnSpecialtySetPrimary;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnSpecialtyChangeStatus;
		//protected NetsoftUSA.InfragisticsWeb.WebGrid gridGroupPracticeSpecialties;
		private   int selectedFocusIndex		= -1;
		//private   int selectedSpecialtyIndex	= -1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGroupPractices;
		protected NetsoftUSA.WebForms.OBLabel OBLabel12;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGroupPracticeGroupPractices;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGroupPracticeGPLocations;
		protected System.Web.UI.HtmlControls.HtmlTable tblGroupPracticeInfo1;
		protected System.Web.UI.HtmlControls.HtmlTable tblGroupPracticeInfo2;
		//private   int selectedLanguageIndex		= -1;
		private   int selectedProvIndex			= -1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Suffix;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DeliveryMethodStr;
		protected NetsoftUSA.WebForms.OBLabel OBLabel15;
		protected NetsoftUSA.InfragisticsWeb.WebGrid lstSpecialties;
		private   int selectedProvLocIndex		= -1;
		private   int selectedLangTypeIndex		= -1;
		private   int selectedFocusTypeIndex	= -1;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnClose;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnProceed;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFocusDate;
		protected System.Web.UI.HtmlControls.HtmlTable tblMain;
		protected System.Web.UI.HtmlControls.HtmlTable tblEffectiveDate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGPDates;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit AsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelGPDates;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GroupPracticeFocusTypeID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel16;
		protected NetsoftUSA.InfragisticsWeb.WebCombo BoardStatus;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBoardStatus;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		//protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSpecialtyStatus;
		protected System.Web.UI.HtmlControls.HtmlTable Table9;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelSpecialtyStatus;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnOKSpecialtyStatus;
		protected NetsoftUSA.WebForms.OBLabel OBLabel17;
		protected NetsoftUSA.WebForms.OBLabel lblGPLocs;
		protected NetsoftUSA.WebForms.OBLabel lblGPEffDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton WebButton1;
		protected NetsoftUSA.InfragisticsWeb.WebButton WebButton2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGroupPracticeDate;
		protected System.Web.UI.HtmlControls.HtmlTable Table11;
		protected NetsoftUSA.WebForms.OBLabel OBLabel13;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit groupPracticeID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel14;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForSORG;
		protected NetsoftUSA.WebForms.OBLabel OBLabel18;
		protected System.Web.UI.HtmlControls.HtmlTable tblGroupPracticeGP;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPLocations;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPEffectiveDates;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGroupPracticeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGroupPracticeLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGroupPracticeFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldBeeper;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEmail;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit BeeperExtension;
		protected NetsoftUSA.WebForms.OBCheckBox PhysicianReview;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhysicianReview;
		//protected System.Web.UI.HtmlControls.HtmlTable tblSpecialtyInfo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGender;
		protected System.Web.UI.HtmlControls.HtmlTable tblGroupPracticeAddress;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFax;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fax;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFax;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFaxNumber;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit FaxNumber;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFaxNumber;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffDate;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGroupPracticeInfo;
		//protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGPFocuses;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProviderFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnClose;
		protected NetsoftUSA.WebForms.OBCheckBox AddedOnFly;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAddedOnTheFly;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeliveryMethod;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeliveryMethodStr;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo TypeID;
		//protected NetsoftUSA.InfragisticsWeb.WebValidator vldFocusTypeID;
		//protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatusChangeTime;
		//protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StatusChangeTime;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusChangeTime;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusChangedBy;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit StatusChangedByStr;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		private   int selectWidth				= 65;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviderGroupPractices;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviderGPLocations;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProvider;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderDate;
		protected System.Web.UI.HtmlControls.HtmlTable tblProviderGP;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ProviderID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPacticeLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ProviderLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ProviderName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProviderID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProviderLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProviderLocationID;
		protected UserDefined UserDefined1;
		
		
		

		private void Page_Load(object sender, System.EventArgs e)
		{
			UserDefined1.ReloadContext("GroupPractice",groupPractice,true);
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
				lbAddedOnTheFly.Text ="";
				this.lbAddedOnTheFly.Text = this.Language.TranslateSingle("ADDEDONFLY");
			}
			else
			{
				groupPractice = (GroupPractice)this.LoadObject("groupPracticeObj");
				//selectedLanguageIndex = (int)this.LoadObject("GroupPracticeLanguageIndex");
				selectedFocusIndex	  = (int)this.LoadObject("GroupPracticeFocusIndex");
				//selectedSpecialtyIndex = (int)this.LoadObject("GroupPracticeSpecialtyIndex");
				selectedProvIndex			= (int)this.LoadObject("GroupPracticeGPIndex");
				selectedProvLocIndex		= (int)this.LoadObject("GroupPracticeGPLocIndex");
				//selectedLangTypeIndex   = (int)this.LoadObject("selectedLangTypeIndex");
				selectedFocusTypeIndex  = (int)this.LoadObject("selectedFocusTypeIndex");
				selectedGroupPracticeFocus = (GroupPracticeFocus)this.LoadObject("selectedFocus");  // load object from cache
				//selectedGroupPracticeSpecialty = (GroupPracticeSpecialty)this.LoadObject("selectedGroupPracticeSpecialty");  // load object from cach
				//selectedGroupPracticeAddress = (Address)this.LoadObject("GroupPracticeAddress");
				//selectedGroupPracticeGroupPractice = (GroupPracticeGroupPracticeLink)this.LoadObject("selectedGPGroupPracticeLink");  // load object from cache
				selectedLocation = (Location)this.LoadObject("locationObj");
				selectedGroupPracticeProvider = (GroupPracticeProviderLink)this.LoadObject("selectedGPProviderLink");  // load object from cache
			}
			//pnlGroupPracticeFocuses.Visible = false;
			//pnlFocusDate.Visible = false;
		

			if (IsPostBack)
				groupPracticeProviderLinks = (GroupPracticeProviderLinkCollection)this.LoadObject(typeof(GroupPracticeProviderLinkCollection));  // load object from cache
		}

		
		public int SelectedFocusTypeIndex
		{
			get { return this.selectedFocusTypeIndex; }
			set 
			{
				this.selectedFocusTypeIndex = value;
				this.CacheObject("selectedFocusTypeIndex", this.selectedFocusTypeIndex);
			}
		}
		public int SelectedLangTypeIndex
		{
			get { return this.selectedLangTypeIndex; }
			set 
			{
				this.selectedLangTypeIndex = value;
				this.CacheObject("selectedLangTypeIndex", this.selectedLangTypeIndex);
			}
		}
		public int SelectedProvIndex
		{
			get { return this.selectedProvIndex;}
			set 
			{ 
				this.selectedProvIndex = value;
				this.CacheObject("GroupPracticeGPIndex", selectedProvIndex);
				if (this.GroupPractice != null && this.selectedProvIndex >= 0)
				{

					// Clone Links From Actual Collection to Display Collection
					CopyGPLinksToDisplayCollection(selectedProvIndex);
					this.GroupPracticeProviderLinks  = this.GroupPracticeProviderLinks ;
					this.gridProviderGPLocations.ClearRows();
					this.gridProviderGPLocations.UpdateFromCollection (GroupPracticeProviderLinks );
				}
			}
		}
		
		private bool AddProviderLink()
		{
		
			bool resume = false;
			if (this.SelectedGroupPracticeProvider!= null)
			{
				if (this.SelectedGroupPracticeProvider.EffDate != DateTime.MinValue) // add 
				{
					resume = true;
					SelectedGroupPracticeProvider.CreatedBy  = 1; // Context.UserID
					SelectedGroupPracticeProvider.CreateTime = DateTime.Now;
					SelectedGroupPracticeProvider.GroupPracticeID = this.GroupPractice.GroupPracticeID;
					
					// check if ID already exists if it does then show a message to the user
					for (int i=0; i < GroupPractice.ProviderLinks.Count; i++)
					{
						if (SelectedGroupPracticeProvider.ProviderLocationID == GroupPractice.ProviderLinks[i].ProviderLocationID)
						{
							resume = false;
							break;
						}
					}
					if (resume)
					{
						this.GroupPractice.ProviderLinks.Add(SelectedGroupPracticeProvider);
						this.GroupPractice.ProviderLinks.Save();
						
						this.selectedGroupPracticeProvider.LoadEffectiveDateHistory(true);
					
						GroupPracticeProviderHistory currentDate = new GroupPracticeProviderHistory();
						currentDate.New();
						currentDate.AsOfDate					= DateTime.Now;
						currentDate.EffectiveDate				= this.selectedGroupPracticeProvider.EffDate;
						currentDate.TerminationDate				= this.selectedGroupPracticeProvider.TerminationDate;
						currentDate.Active						= this.selectedGroupPracticeProvider.Active ;
						currentDate.GroupPracticeProviderID		= this.selectedGroupPracticeProvider.GroupPracticeProviderID;
					
						this.selectedGroupPracticeProvider.EffectiveDateHistory.InsertRecord(0,currentDate);
						this.selectedGroupPracticeProvider.EffectiveDateHistory.Save();
			
						this.gridGPDates.ClearRows();
						this.gridGPDates.UpdateFromCollection(this.selectedGroupPracticeProvider.EffectiveDateHistory);
						this.gridProviderGPLocations.UpdateFromCollection (this.groupPractice.ProviderLinks);

						int oldIndex = this.selectedProvIndex ;
						//this.SelectedGPLocIndex = 0;
						//this.Provider = this.provider; // refresh all grids.
						this.SelectedProvIndex = oldIndex;
						
						bool addGp = true;
						for (int i=0; i < GroupPractice.Providers.Count; i++)
						{
							if (SelectedGroupPracticeProvider.ProviderID == GroupPractice.Providers[i].ProviderID )
								addGp = false;
							else
							{
								addGp = true;
								break;
							}
						}

						if (addGp) // add GP to current group practice col, wont be saved into DB
						{
							Provider gpNew = new Provider();
							gpNew.Load(SelectedGroupPracticeProvider.ProviderID);
							GroupPractice.Providers.Add(gpNew);
							this.gridProviderGroupPractices.UpdateFromCollection(GroupPractice.Providers);
						}

						this.CopyGPLinksToDisplayCollection(SelectedGroupPracticeProvider.ProviderID);
						this.SelectedGroupPracticeProvider = null;
						this.gridProviderGPLocations.UpdateFromCollection(this.GroupPractice.ProviderLinks);
					}
					else
						this.SetPageMessage("@PROVEXISTS@", NetsoftUSA.WebForms.EnumPageMessageType.Error);
				}
			}
			return resume;
		}
		public void OnToolbarButtonClick_AddProvider(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.SelectedGroupPracticeProvider = new GroupPracticeProviderLink();
			this.SelectedGroupPracticeProvider.New();

			//SetGroupPracticeGridsVisible(false); // disable the tabs
			this.pnlProviderDate.Visible = true;
			this.tblEffectiveDate.Visible = false;

		}

		private void CopyGPLinksToDisplayCollection(int gpID)
		{

			if (this.GroupPracticeProviderLinks != null)
				this.GroupPracticeProviderLinks.Clear();
					
			this.GroupPracticeProviderLinks = new GroupPracticeProviderLinkCollection();
			for (int i=0; i < GroupPractice.ProviderLinks.Count; i++)
			{
				if (!GroupPractice.ProviderLinks[i].IsMarkedForDeletion)
				{
					GroupPracticeProviderLinks.Add((GroupPracticeProviderLink)GroupPractice.ProviderLinks[i].Clone());
					GroupPracticeProviderLinks[i].IsNew = GroupPractice.ProviderLinks[i].IsNew;
					GroupPracticeProviderLinks[i].IsDirty = GroupPractice.ProviderLinks[i].IsDirty;
					//GroupPracticeProviderLinks[i].EffectiveDateHistory = Provider.GroupPracticeLinks[i].EffectiveDateHistory.Clone(false, true) ;
				}
			}
					
			for (int i = 0; i < GroupPracticeProviderLinks.Count; i++)
			{
				if (GroupPracticeProviderLinks[i].GroupPracticeID != gpID)
					GroupPracticeProviderLinks.RemoveAt(i);
			}

			
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeProviderLinkCollection GroupPracticeProviderLinks
		{
			get { return groupPracticeProviderLinks ; }
			set
			{
				groupPracticeProviderLinks  = value;
				try
				{
					this.gridProviderGPLocations.UpdateFromCollection(groupPracticeProviderLinks );  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(GroupPracticeProviderLinkCollection), groupPracticeProviderLinks);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(int GroupPracticeID)
		{
			GroupPractice GroupPractice = new GroupPractice();
			if (GroupPracticeID != 0)
				GroupPractice.Load(GroupPracticeID);
			else
				GroupPractice.New();
			BasePage.PushParam("groupPracticeObj",GroupPractice);
			BasePage.Redirect("GroupPracticeForm.aspx");
		}

		public static void Redirect(GroupPractice GroupPractice)
		{
			BasePage.PushParam("groupPracticeObj",GroupPractice);
			BasePage.Redirect("GroupPracticeForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			//this.btnAddFocus.Click += new System.EventHandler(this.btnAddFocus_Click);
			//this.btnRemoveFocus.Click += new System.EventHandler(this.btnRemoveFocus_Click);
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			this.WebButton1.Click += new System.EventHandler(this.WebButton1_Click);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.gridProviderGroupPractices.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridProviderGroupPractices_ClickCellButton_1);
			this.gridProviderGroupPractices.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridProviderGroupPractices_ColumnsBoundToDataClass);
			this.gridProviderGPLocations.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridProviderGPLocations_ClickCellButton_1);
			this.gridProviderGPLocations.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridProviderGPLocations_ColumnsBoundToDataClass);
			this.btnSaveGPDates.Click += new System.EventHandler(this.btnSaveGPDates_Click);
			this.btnCancelGPDates.Click += new System.EventHandler(this.btnCancelGPDates_Click);
			this.btnAddGPDates.Click += new System.EventHandler(this.btnAddGPDates_Click);
			this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
			this.WebButton2.Click += new System.EventHandler(this.WebButton2_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		
		public bool LoadData()
		{
			bool result = true;
			// get the parameter
			GroupPractice groupPractice = null;
			
			try
			{	// use any load method here
			groupPractice = this.GetParamOrGetFromCache("groupPracticeObj","groupPracticeObj") as GroupPractice ;
			//StatusChangedByStr.Value = "1";
			selectedLocation = this.GetParamOrGetFromCache("locationObj","locationObj") as Location ;

			SelectedFocusIndex				= -1;
			SelectedProvIndex				= -1;
			SelectedProvLocIndex				= -1;
			
			SelectedFocusTypeIndex			= -1;
			
			

			if (groupPractice == null)
			{
					return NewGroupPractice();
			}
			
			groupPractice.LoadProviderLinks(false);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//GP.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			groupPractice.Load(groupPractice.GroupPracticeID);
			

			if (groupPractice.GroupPracticeID == 0)
				groupPractice.New();
			//groupPractice.LoadFocuses(false);
		
			this.GroupPractice = groupPractice;
			return result;
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewGroupPractice()
		{
			bool result = true;
			GroupPractice gp = new GroupPractice(true); // use a parameterized constructor which also initializes the data object
			try
			{
				//gp.LoadFocuses(true);
				// or use an initialization method here
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.GroupPractice = gp;
			return result;
		}
		

		public Location SelectedLocation
		{
			get { return this.selectedLocation  ; }
			set 
			{ 
				this.selectedLocation = value;
				this.CacheObject("locationObj", selectedLocation);
			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@SAVE@", "Save",true, false);
			toolbar.AddButton("@CANCEL@", "Cancel", false, true);

		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if ( SaveData())			
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@GROUPPRACTICE@");
		}


		public int SelectedProvLocIndex
		{
			get { return this.selectedProvLocIndex;}
			set 
			{ 
				this.selectedProvLocIndex = value;
				this.CacheObject("GroupPracticeGPLocIndex", selectedProvLocIndex);

				
				// Load Date History
				if (GroupPractice != null && this.gridGroupPracticeGPLocations.SelectedRowIndex >= 0)
				{
					// Find Group Practice ID from GPLocIndex
					int gpID = 0;
					
					if (this.gridGroupPracticeGPLocations.SelectedRowIndex >= 0)
					{
						Infragistics.WebUI.UltraWebGrid.UltraGridCell mcell = null;
						for (int m = 0; m < this.gridGroupPracticeGPLocations.DisplayLayout.ActiveRow.Cells.Count; m++)
						{
							if (gridGroupPracticeGPLocations.DisplayLayout.ActiveRow.Cells[m].Key == "GroupPracticeID")
							{
								mcell = gridGroupPracticeGPLocations.DisplayLayout.ActiveRow.Cells[m];
								break;
							}
						}
						gpID = (int)mcell.Value;	
					}
					
					int gpLocID = (int)gridGroupPracticeGPLocations.SelectedRowPK[0];
					
				
				}
			}
		}

		public int SelectedFocusIndex
		{
			get { return this.selectedFocusIndex;}
			set 
			{ 
				this.selectedFocusIndex = value;
				this.CacheObject("GroupPracticeFocusIndex", selectedFocusIndex);
			}
		}
		
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.groupPractice);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPractice GroupPractice
		{
			get { return groupPractice; }
			set
			{
				groupPractice = value;
				try
				{
					this.pnlProviderDate.Visible  = false;
					this.tblGPDates.Visible = false;
					//GroupPractice.LoadLanguages();
					groupPractice.LoadLocations(true);
					groupPractice.LoadProviderLinks (false);
					this.UpdateFromObject(this.tblGroupPracticeInfo1.Controls, groupPractice );  // update controls for the given control collection
					this.UpdateFromObject(this.tblGroupPracticeInfo2.Controls, groupPractice );  // update controls for the given control collection
					//this.UpdateFromObject(this.tblGroupPracticeInfoTax.Controls, selectedLocation );
					// Bind Active GroupPractice Focuses
					//this.lstFocuses.UpdateFromCollection(GroupPracticeFocusTypeCollection.ActiveGroupPracticeFocusTypes);
					this.UpdateFromObject(this.pnlGPNote.Controls ,groupPractice );	
//					if (lstFocuses.Rows.Count > 0)
//						lstFocuses.SelectedRowIndex = 0;
					//this.gridGroupPracticeFocuses.UpdateFromCollection(GroupPractice.Focuses);
					//if (gridGroupPracticeFocuses.Rows.Count > 0)
						//gridGroupPracticeFocuses.SelectedRowIndex = 0;
			
					this.GroupPractice.LoadProviders();
					this.gridProviderGroupPractices.UpdateFromCollection(GroupPractice.Providers);
					if (this.gridProviderGroupPractices.Rows.Count > 0)
					{
						this.SelectedProvIndex  = 0;
						GroupPracticeProviderLink groupProviderNetworkLink = groupPractice.ProviderLinks[gridProviderGroupPractices.SelectedColectionIndex];
						groupProviderNetworkLink.LoadEffectiveDateHistory(true);
						this.gridGPDates.UpdateFromCollection(groupProviderNetworkLink.EffectiveDateHistory);
						this.gridProviderGPLocations.UpdateFromCollection (this.GroupPractice.ProviderLinks);
						this.gridProviderGroupPractices.SelectedRowIndex = 0;
					}


					this.pnlFocusDate.Visible = false;
					UserDefined1.ReloadContext("GroupPractice",groupPractice,false);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("groupPracticeObj", GroupPractice);  // cache object using the caching method declared on the page
			}
		}


		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			if (tab.Key == "GroupPractice")
			{
				toolbar.AddButton("@LOCATIONS@", "Locations");
				if (this.GroupPractice.GroupPracticeID == 0)
					this.SetPageTabToolbarItemEnabled("Locations", false);
			}
			else if (tab.Key == "Provider")
			{
				toolbar.AddButton("@ADDNEWRECORD@","AddProvider");
				//toolbar.AddButton("@DELETE@","DeleteGP");
				if (this.GroupPractice.GroupPracticeID == 0)
				{
					this.SetPageTabToolbarItemEnabled("AddProvider",false);
					//this.SetPageTabToolbarItemEnabled("DeleteGP",false);
					this.pnlProvider.Enabled = false;
				}
			}

		}
		
		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			GroupPracticeSearch.Redirect();
		}
			
		public void OnToolbarButtonClick_Locations(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			GroupPracticeLocationForm.PushCurrentCallingPage();
			GroupPracticeLocationForm.Redirect(typeof(GroupPractice),this.GroupPractice.GroupPracticeID);
		}


		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForGroupPractice()
		{
			try
			{	//customize this method for this specific page
				
				this.UpdateToObject(this.pnlGPNote.Controls, this.groupPractice  );
				this.UpdateToObject(this.tblGroupPracticeInfo1.Controls, this.groupPractice );	// controls-to-object
				this.UpdateToObject(this.tblGroupPracticeInfo2.Controls, this.groupPractice );	// controls-to-object
				//this.UpdateToObject(this.tblGroupPracticeInfoTax.Controls, selectedLocation );
				//this.UpdateToObject(this.tblGroupPracticeAddress.Controls,this.selectedGroupPracticeAddress);	// controls-to-object
				UserDefined1.ReadControls();
				groupPractice.UserDefined = UserDefined1.UserDefinedValue;	
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private bool SaveData()
		{
			if (this.ReadControlsForGroupPractice())
			{
				try
				{
					if (!this.GroupPractice.IsNew)
						this.GroupPractice.Locations[0].MarkDirty();
					//this.GroupPractice.StatusChangedBy = 1;
					
					this.GroupPractice.Save ();
					
					// Enable Locations Button
					this.SetPageTabToolbarItemEnabled("Locations", true);
					this.SetPageTabToolbarItemEnabled("AddProvider",true);
					this.pnlProvider.Enabled = true;
					this.GroupPractice = groupPractice;
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
					return false;
				}
				return true;
			}
			else
				return false;
				

		}
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeProviderLink SelectedGroupPracticeProvider
		{
			get { return selectedGroupPracticeProvider; }
			set
			{
				selectedGroupPracticeProvider = value;
				try
				{
					this.UpdateFromObject(this.pnlProviderDate.Controls, selectedGroupPracticeProvider);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedGPProviderLink", selectedGroupPracticeProvider);  // cache object using the caching method declared on the page
			}
		}
	
		private void btnAddFocus_Click(object sender, System.EventArgs e)
		{
			
//			if (lstFocuses.SelectedRowIndex >= 0)
//			{
//				bool			resume			= true;
//				GroupPracticeFocus	provFocCompare	= null;
//				int selectedTypeID = (int)lstFocuses.SelectedRowPK[0];	
//
//				if (selectedTypeID != 0)
//				{
//					if (GroupPractice.Focuses != null)
//					{
//						for (int i = 0; i < this.GroupPractice.Focuses.Count; i++)
//						{
//							provFocCompare		= GroupPractice.Focuses[i];
//							if (selectedTypeID == provFocCompare.GroupPracticeFocusTypeID && provFocCompare.TerminationDate == DateTime.MinValue)
//							{
//								resume = false;
//								break;
//							}
//						}
//					}
//					else
//						GroupPractice.Focuses = new GroupPracticeFocusCollection();
//
//					if (resume)
//					{
//						GroupPracticeFocus provFoc		= new GroupPracticeFocus();
//						provFoc.New();
//						provFoc.EffectiveDate		= DateTime.Today.Date;
//						provFoc.GroupPracticeFocusTypeID = selectedTypeID;
//						provFoc.GroupPracticeID			= this.GroupPractice.GroupPracticeID;
//						this.SelectedGroupPracticeFocus  = provFoc;
//						
//						// show the panel
//						SetFocusDatesVisible(true, false);
//						pnlFocusDate.Visible = true;
//					}
//				}
//			}
//			else
//				this.SetPageMessage("@SELECTFOCUS@", NetsoftUSA.WebForms.EnumPageMessageType.Warning);
	
		}
		
//		private void lstFocuses_ColumnsBoundToDataClass(object sender, System.EventArgs e)
//		{
//			lstFocuses.AddButtonColumn("Select", "@SELECT@",0).Width = selectWidth;
//		}

//		private void gridGroupPracticeFocuses_ColumnsBoundToDataClass(object sender, System.EventArgs e)
//		{
//			gridGroupPracticeFocuses.AddButtonColumn("Select", "@SELECT@",0).Width = selectWidth;
//		}
//		
		private void SetFocusDatesVisible(bool effAndFocus, bool termDate)
		{
			this.WebDateTimeEdit1.Enabled		= termDate;
			this.OBFieldLabel1.Enabled			= termDate;
			this.WebDateTimeEdit2.Enabled		= effAndFocus;
			this.OBLabel16.Enabled				= effAndFocus;
			this.OBFieldLabel2.Enabled			= effAndFocus;			
			this.GroupPracticeFocusTypeID.Enabled	= effAndFocus;
		}



//		private void btnRemoveFocus_Click(object sender, System.EventArgs e)
//		{
//			if (gridGroupPracticeFocuses.SelectedRowIndex >= 0)
//			{
//				InactivateSelectedIndex(gridGroupPracticeFocuses.SelectedColectionIndex);
//				
//				//this.SelectedGroupPracticeFocus = GroupPractice.Focuses[gridGroupPracticeFocuses.SelectedColectionIndex];
//				this.SetFocusDatesVisible(false, true);
//				this.pnlFocusDate.Visible = true;
//			}
//
//		}
		
//		private void InactivateSelectedIndex(int gpServColIndex)
//		{
//			if (gpServColIndex >= 0)
//			{
//				GroupPracticeFocus gpFocus = null;
//				gpFocus = GroupPractice.Focuses[gpServColIndex];
//				//RemoveFocus();
//				this.SelectedGroupPracticeFocus = gpFocus;
//			}
//		}
//		private void RemoveFocus()
//		{
//			if (this.SelectedGroupPracticeFocus != null)
//			{
//				GroupPractice.Focuses.Remove(this.SelectedGroupPracticeFocus);
//				this.SelectedGroupPracticeFocus = null;
//				this.gridGroupPracticeFocuses.UpdateFromCollection(GroupPractice.Focuses);
//				
//				if (gridGroupPracticeFocuses.Rows.Count > 0)
//					gridGroupPracticeFocuses.SelectedRowIndex = 0;
//			}
//		}

		
		


		/// <summary>
		///  Adds / Updates a focus based on effective dates.
		/// </summary>
//		private void AddFocus()
//		{
//			if (this.SelectedGroupPracticeFocus != null)
//			{
//				this.GroupPractice.Focuses.Add(this.SelectedGroupPracticeFocus);
//				//this.gridGroupPracticeFocuses.UpdateFromCollection(this.GroupPractice.Focuses);
//				this.SelectedGroupPracticeFocus = null;
//			}
//		}

//		private void TerminateFocus()
//		{
//			if (SelectedGroupPracticeFocus != null)
//			{
//				try
//				{
//
//					// find current focus in collection
//					for (int i=0; i < GroupPractice.Focuses.Count; i++)
//					{
//						if (GroupPractice.Focuses[i].GroupPracticeFocusID == SelectedGroupPracticeFocus.GroupPracticeFocusID)
//						{
//							GroupPracticeFocus currentFocus = GroupPractice.Focuses[i];
//							currentFocus.TerminationDate = this.SelectedGroupPracticeFocus.TerminationDate;
//							currentFocus.MarkDirty();
//							break;
//						}
//					}
//					
//					SelectedGroupPracticeFocus = null;
//				}
//				catch (Exception ex)
//				{
//					this.RaisePageException(ex);
//				}
//				finally
//				{
//					//this.gridGroupPracticeFocuses.UpdateFromCollection(this.GroupPractice.Focuses);
//				}
//			}
//		}

		

		
		private void gridGroupPracticeGPLocations_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				this.SelectedProvLocIndex = this.gridGroupPracticeGPLocations.GetColIndexFromCellEvent(e);
			}
		}


		private void LoadGPLocations(int groupPracticeID)
		{
			
		}

		private void gridGroupPracticeGroupPractices_InitializeLayout(object sender, Infragistics.WebUI.UltraWebGrid.LayoutEventArgs e)
		{
		
		}

		

		private void gridGroupPracticeGPLocations_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			this.SelectedProvLocIndex = gridGroupPracticeGPLocations.GetColIndexFromClickEvent(e);
		}

		

		/*

		private void lstLanguages_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell != null && e.Cell.Key == "Select")
			{
				this.SelectedLangTypeIndex = lstLanguages.GetColIndexFromCellEvent(e);
			}
		}

		private void lstFocuses_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell != null && e.Cell.Key == "Select")
			{
				this.SelectedFocusTypeIndex = lstFocuses.GetColIndexFromCellEvent(e);
				
			}
		}

		private void lstSpecialties_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell != null && e.Cell.Key == "Select")
			{
				SelectedSpecialtyIndex = lstSpecialties.GetColIndexFromCellEvent(e);
			}
		}
		*/
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public GroupPracticeFocus SelectedGroupPracticeFocus
		{
			get { return selectedGroupPracticeFocus; }
			set
			{
				selectedGroupPracticeFocus = value;
				try
				{
					this.UpdateFromObject(this.tblEffectiveDate.Controls , selectedGroupPracticeFocus);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedFocus", selectedGroupPracticeFocus);  // cache object using the caching method declared on the page
			}
		}
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Address SelectedGroupPracticeAddress
		{
			get { return selectedGroupPracticeAddress; }
			set
			{
				selectedGroupPracticeAddress = value;
				try
				{
					//this.UpdateFromObject(this.tblGroupPracticeAddress.Controls,selectedGroupPracticeAddress );  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("GroupPracticeAddress", selectedGroupPracticeAddress);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSelectedGroupPracticeFocus()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlFocusDate.Controls, selectedGroupPracticeFocus);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private void btnProceed_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.UpdateToObject(this.tblEffectiveDate.Controls, this.SelectedGroupPracticeFocus);
				this.SelectedGroupPracticeFocus.CreatedBy = 1;
				this.SelectedGroupPracticeFocus.CreateTime = DateTime.Now;
				//if (this.GroupPracticeFocusTypeID.Enabled)
				//	this.AddFocus();
				//else
				//	this.TerminateFocus();
					
				this.pnlFocusDate.Visible = false;
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}

		}

		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.SelectedGroupPracticeFocus = null;
			this.pnlFocusDate.Visible = false;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		

	
		private void SetGroupPracticeGridsVisible(bool visibility)
		{
			this.lblGPEffDates.Visible = this.gridGPDates.Visible = this.tblGPDates.Visible =  tblGPEffectiveDates.Visible =visibility;
			//this.lblGPLocs.Visible	= this.gridGroupPracticeGPLocations.Visible = tblGPLocations.Visible  = visibility;
		}

		
		private void gridGroupPracticeGroupPractices_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridGroupPracticeGroupPractices.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;
		}

		
//		private void lstFocuses_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
//		{
//			if (e.Cell.Key == "State")
//				lstFocuses.SelectedRowIndex = e.Cell.Row.Index;
//		}

		private void lstSpecialties_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
				lstSpecialties.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void gridGroupPracticeGroupPractices_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
				gridGroupPracticeGroupPractices.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void gridGroupPracticeGPLocations_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
				gridGroupPracticeGPLocations.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void gridGroupPracticeGPLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridGroupPracticeGPLocations.AddButtonColumn("Select","@SELECT@",0);
		}
		private void btnAddGPDates_Click(object sender, System.EventArgs e)
		{
			this.UpdateFromObject(this.tblGPDates.Controls, new GroupPracticeProviderHistory ());
			this.AsOfDate.Value = DateTime.Now;
			this.tblGPDates.Visible = true;
		}

		private void btnCancelGPDates_Click(object sender, System.EventArgs e)
		{
			this.UpdateFromObject(this.tblGPDates.Controls, new GroupPracticeProviderHistory());
			this.tblGPDates.Visible = false;			
		}
		
		
		private void DisableGPDates(bool val)
		{
			btnSaveGPDates.Enabled = btnCancelGPDates.Enabled = val;
			lbEffectiveDate.Enabled =  EffectiveDate.Enabled = lbTerminationDate.Enabled	= val;
			TerminationDate.Enabled = lbAsOfDate.Enabled	=  AsOfDate.Enabled	= val;
		}
		private void WebButton1_Click(object sender, System.EventArgs e)
		{
			this.SelectedGroupPracticeProvider = null;
			this.pnlProviderDate.Visible = false;
			SetGroupPracticeGridsVisible(true);
		}
		private void gridProviderGroupPractices_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				gridProviderGroupPractices.SelectedRowIndex = e.Cell.Row.Index;
				BindGroupPracticeLocations((int)gridProviderGroupPractices.SelectedRowPK [0]);
			}
		}
		private void BindGroupPracticeLocations(int providerID)
		{
			Provider prov = new Provider();
			prov.Load(providerID);
			this.gridProviderGPLocations.UpdateFromCollection (this.GroupPractice.ProviderLinks);
			//this.ResultGroupPracticeLocations = gp.Locations;
		}
		private void gridProviderGPLocations_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
				gridProviderGPLocations.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void gridProviderGPLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridProviderGPLocations.AddButtonColumn("Select","@SELECT@",0);
		}

		private void gridProviderGroupPractices_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridProviderGroupPractices.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;
		}

		private void WebButton2_Click(object sender, System.EventArgs e)
		{
			this.UpdateToObject(this.pnlProviderDate.Controls, this.SelectedGroupPracticeProvider);
			this.SelectedGroupPracticeProvider.ProviderID = (int)this.ProviderID.Value;
			this.SelectedGroupPracticeProvider.ProviderLocationID = (int)this.ProviderLocationID.Value;
			if (AddProviderLink())
			{
				this.pnlProviderDate.Visible = false;
				this.SetGroupPracticeGridsVisible (true);
			}
			
		}


		private void btnSaveGPDates_Click(object sender, System.EventArgs e)
		{
			GroupPracticeProviderHistory gpLink = new GroupPracticeProviderHistory();
			this.UpdateToObject(this.tblGPDates.Controls, gpLink);
			gpLink.AsOfDate = (DateTime)this.AsOfDate.Value;
			gpLink.Active	= true;

			
			// check all dates for duplicates
			GroupPracticeProviderLink linkCheck = new GroupPracticeProviderLink ();
			linkCheck.Load(this.SelectedProvIndex);
			linkCheck.LoadEffectiveDateHistory(false);
			
			bool resume = true;
			for (int i = 0 ; i < linkCheck.EffectiveDateHistory.Count; i++)
			{
				if 	(((((GroupPracticeProviderHistory)GroupPractice.ProviderLinks.GetAt(i)).EffectiveDate == gpLink.EffectiveDate) && ((GroupPracticeProviderHistory)GroupPractice.ProviderLinks.GetAt(i)).EffectiveDate == gpLink.EffectiveDate))
				{
					resume = false;
					break;
				}
			}
			// check for current date too
			resume = (linkCheck.EffDate == gpLink.EffectiveDate && linkCheck.TerminationDate == gpLink.TerminationDate) ? false : true;
			if (resume)
			{
				try
				{
					GroupPracticeProviderLink provCurrentLink = GroupPractice.ProviderLinks.GetAt(gridProviderGroupPractices.SelectedRowIndex ) as GroupPracticeProviderLink;
					// move current record to archive and mark it Inactive
					provCurrentLink.LoadEffectiveDateHistory(false);
					GroupPracticeProviderHistory provCurrentDates = new GroupPracticeProviderHistory();
					//ProviderLocationNetworkHistory provDate = new ProviderLocationNetworkHistory();

					provCurrentDates.New();
					provCurrentDates.AsOfDate						= gpLink.AsOfDate;
					provCurrentDates.EffectiveDate					= gpLink.EffectiveDate;
					provCurrentDates.TerminationDate				= gpLink.TerminationDate;
					provCurrentDates.Active							= true;
					
					provCurrentLink.EffectiveDateHistory.Add(provCurrentDates);
					
					gpLink.Active = true;
					provCurrentDates.GroupPracticeProviderID  = provCurrentLink.GroupPracticeProviderID;

					GroupPracticeProviderHistoryCollection provColHistoryCol = new GroupPracticeProviderHistoryCollection();
					provColHistoryCol.UpdateStatusForGroupPracticeProviderHistory(-1,gpLink,provCurrentLink.GroupPracticeProviderID);
		
					
					provCurrentDates.Save();
					this.SelectedProvIndex = 0;
					this.gridGPDates.UpdateFromCollection(provCurrentLink.EffectiveDateHistory);
					this.gridProviderGPLocations.UpdateFromCollection (this.GroupPractice.ProviderLinks);
					
					GroupPracticeProviderHistory blankHistory = new GroupPracticeProviderHistory();
					this.UpdateFromObject(this.tblGPEffectiveDates.Controls, blankHistory);
					DisableGPDates(false);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			else
				this.SetPageMessage("@DUPLICATEDATES@",NetsoftUSA.WebForms.EnumPageMessageType.Error);	
		}




	
	
	
	}
}
