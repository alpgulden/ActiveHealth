using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Assessment,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class AssessmentView : AssessmentBasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAssessment;
		protected AssessmentLayout ctrlAssessmentLayout;

		private Assessment assessment;
		private CMS cMS;
		private string assessmentGUID;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				LoadData();
			}

			ctrlAssessmentLayout.AssessmentContext = assessmentContext;		
		}

		private void LoadData()
		{
			try
			{	
#if DEBUG
				if (assessmentContext == null)
				{
					assessmentGUID = "099afe93b6bb42e29628e6a9c1d19f13"; //this.GetParam("AssessmentGUID") as string;
					cMS = new CMS(true);
					cMS.Load(10);
					assessmentContext = new AssessmentContext(cMS, assessmentGUID);		
				}
#endif					
				
				if (assessmentContext == null)
				{
					this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a CMS"));
					return;
				}

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
			finally
			{
				//obj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.AssessmentContext = assessmentContext;		// When you set the object to the property, controls are automatically populated
		}

			
		

		public AssessmentContext AssessmentContext
		{
			get { return assessmentContext; }
			set
			{
				assessmentContext = value;
				this.CacheObject(typeof(AssessmentContext), assessmentContext);	
			}
		}



		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "AssessmentView")
			{
				toolbar.AddButton("@PICKQUESTIONNAIRES@", "PickQuestionnaires");
			}
		}

		public void OnToolbarButtonClick_PickQuestionnaires(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			AssessmentForm.Redirect(assessmentContext);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@ASSESSMENT@");
			}
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.AssessmentContext = null;
			Assessments.Redirect(cMS);
		}


		private bool SaveData()
		{
			try
			{
				assessmentContext.Responses.Save();
				assessmentContext.ReloadResponses();
				return true;
			}
			catch
			{
				return false;
			}
		}


		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(CMS cMS, string assessmentGUID)
		{
			BasePage.PushParam("ASSESSMENTGUID", assessmentGUID);
			BasePage.PushParam("CMS", cMS);
			BasePage.Redirect("AssessmentView.aspx");
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(CMS cMS, Assessment assessment)
		{
			BasePage.PushParam("ASSESSMENT", assessment);
			BasePage.PushParam("CMS", cMS);
			BasePage.Redirect("AssessmentView.aspx");
		}


		public static void Redirect(AssessmentContext assessmentContext)
		{
			BasePage.PushParam("ASSESSMENTCONTEXT", assessmentContext);
			BasePage.Redirect("AssessmentView.aspx");
		}

        
		
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(assessmentContext.Assessment);
		}



		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


	}
}
