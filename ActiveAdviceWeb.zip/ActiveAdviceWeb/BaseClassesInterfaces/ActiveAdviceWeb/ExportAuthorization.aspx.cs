using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.BaseClassesInterfaces;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class ExportAuthorizationForm : ImportExportBasePage
	{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBCheckBox Events;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEvents;
		protected NetsoftUSA.WebForms.OBCheckBox Referrals;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferrals;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLabel;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOrgID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo OrgID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrgID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLabel;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Label;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAuthorization;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				AuthArgs = null; // clear cache
				this.UpdateFromObject(pnlAuthorization.Controls, AuthArgs);
			}
		}

		protected OrganizationSummaryCollection altmorgs;
		public OrganizationSummaryCollection AlternateMORGS
		{
			get
			{
				if (null == altmorgs)
				{
					// see if it's in the cache...
					altmorgs = (OrganizationSummaryCollection)LoadObject(typeof(OrganizationSummaryCollection), false);
				}

				return altmorgs;
			}
			set
			{
				altmorgs = value;
				CacheObject(typeof(OrganizationSummaryCollection), altmorgs);
			}
		}

		protected AuthorizationArgs a_args;
		public AuthorizationArgs AuthArgs
		{
			get
			{
				if (a_args == null)
					a_args = (AuthorizationArgs)LoadObject(typeof(AuthorizationArgs), true);
				return a_args;
			}

			set
			{
				a_args = value;
				CacheObject(typeof(AuthorizationArgs), a_args);
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			HttpContext.Current.Response.Redirect("Redirect method must redirect to its own page.aspx");
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
		}

		public void OnToolbarButtonClick_Update(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@AUTHORIZATION@");
			}
		}

		protected bool ReadControls()
		{
			bool valid = true;
			this.UpdateToObject(pnlAuthorization.Controls, AuthArgs);
			
			// Process all our special validations. keep track if there's a problem and
			// return "failed" status if even one is bad...
			if (!AuthArgs.Events && !AuthArgs.Referrals) // must choose at least one...
			{
				this.SetPageMessage("@AUTHREQUIREDEVENTREF@", EnumPageMessageType.AddError);
				valid = false;
			}

			return valid;
		}

		protected bool SaveData()
		{
			if (!ReadControls())
				return false;

			if (!this.IsValid)
				return false;

			// Time to write out our task. Authorizations don't have a filename
			// argument, then write to EVT.X12 & REF.X12 (and the error logs are defined too).
			try
			{
				ScheduleTask st = new ScheduleTask();
				// We can write this task out...
				ScheduleTypeCollection types		= ScheduleTask.ActiveScheduleTypes;
				st.ScheduleTypeID					= types.IndexBy_Code.LookupIntMember("ScheduleTypeID", "AUTH");	// Membership Log
				ScheduleStatusCollection statuses	= ScheduleTask.ActiveScheduleStatuses;
				st.ScheduleStatusID					= statuses.IndexBy_Code.LookupIntMember("ScheduleStatusID", "PEND");	// good to go once written

				st.Task				= AuthArgs.Task;	// create our "task" string
				st.Label			= AuthArgs.Label;	// label to attached to the scheduled item...
				st.CreatedBy		= this.CurrentUser;
				st.CreateTime		= DateTime.Now;
				st.ScheduledTime	= DateTime.Now;

				// Insert the record into the table...
				st.Insert();
			}
			catch(Exception stEx)
			{
				string msg = stEx.Message;
				throw(stEx);
			}

			return true;
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			ToolbarButtonExtraProperties tbep = toolbar.AddButton("@UPDATE@", "Update");
			tbep.ChecksForIsDirty = false;
		}

	}// end of class

	[TableMapping(null)]
	public class AuthorizationArgs : AuthorizationArguments
	{
		public AuthorizationArgs()
		{
		}

		[FieldDescription("@ALTMORGID@")]
		[FieldValuesMember("LookupOf_OrgID", "OrganizationID", "AlternateID")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int OrgID
		{
			get { return base.MORGID; }
			set { base.MORGID = value; }
		}

		/// <summary>
		/// LookupOf_OrgLevelID
		/// returns a collection of schedule types, the first record
		/// being "ALL".
		/// </summary>
		OrganizationSummaryCollection morgs = null;
		public OrganizationSummaryCollection LookupOf_OrgID
		{
			get
			{
				if (null == morgs) // not created yet...
				{
					morgs = new OrganizationSummaryCollection();
					morgs.GetOrganizationsByLevelAndFilter(-1, 1, "AND AlternateID is not null");
				}

				return morgs;
			}
		}// end of property

	}
}// end of namespace
