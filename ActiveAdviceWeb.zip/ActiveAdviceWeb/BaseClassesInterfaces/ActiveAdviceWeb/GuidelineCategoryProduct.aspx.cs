using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ActiveAdvice.DataLayer;
using NetsoftUSA.DataLayer;
using ActiveAdvice.Messages;
namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for GuidelineCategoryProduct.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.GuidelineMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Guideline,DataLayer")]
	public class GuidelineCategoryProduct:  BasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected Infragistics.WebUI.UltraWebTab.UltraWebTab UltraWebTab1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGuidelineSourceSetID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GuidelineSourceSetID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGuidelineSourceSetID;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCategory;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuideline;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProduct;
		protected System.Web.UI.WebControls.CheckBox chkGuideline;
		protected System.Web.UI.WebControls.CheckBox chkCategory;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddNew;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNew2;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNew1;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnLink;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator3;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProduct1;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNew3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator4;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo4;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid4;
		protected System.Web.UI.WebControls.CheckBox chkProduct;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNew4;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator5;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo5;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel5;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid5;
		protected System.Web.UI.WebControls.CheckBox chkProduct1;
		protected System.Web.UI.WebControls.CheckBox chkCategory1;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNew5;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnLink1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCategory1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuideline1;
		protected System.Web.UI.WebControls.CheckBox chkGuideline1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
	
	
		private GuidelineMaintenance guidelineMaintenance1;
		private GuidelineMaintenance guidelineMaintenance2;
		private GuidelineMaintenance guidelineMaintenance3;
		private GuidelineMaintenance guidelineMaintenance4;
		private GuidelineMaintenance guidelineMaintenance5;
		private GuidelineMaintenance guidelineMaintenance6;

		private GuidelineCollection guidelineCollectionGCP;
		private GuidelineCategoryCollection categoryCollectionGCP;
		private GuidelineProductCollection productCollectionGCP;
		private GuidelineCollection guidelineCollectionPCG;
		private GuidelineCategoryCollection categoryCollectionPCG;
		private GuidelineProductCollection productCollectionPCG;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
				LoadData();
		}

		private void LoadData()
		{
			NewGuidelineMaintenance1();
			NewGuidelineMaintenance2();
			NewGuidelineMaintenance3();
			NewGuidelineMaintenance4();
			NewGuidelineMaintenance5();
			NewGuidelineMaintenance6();
			GuidelineCollection guidelineCol = new GuidelineCollection();
			
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.GuidelineSourceSetID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.GuidelineSourceSetID_SelectedRowChanged);
			this.WebCombo1.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo1_SelectedRowChanged);
			this.chkGuideline.CheckedChanged += new System.EventHandler(this.chkGuideline_CheckedChanged);
			this.WebCombo2.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo2_SelectedRowChanged);
			this.chkGuideline1.CheckedChanged += new System.EventHandler(this.chkGuideline1_CheckedChanged);
			this.chkCategory.CheckedChanged += new System.EventHandler(this.chkCategory_CheckedChanged);
			this.WebCombo3.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo3_SelectedRowChanged);
			this.WebCombo4.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo4_SelectedRowChanged);
			this.chkProduct.CheckedChanged += new System.EventHandler(this.chkProduct_CheckedChanged);
			this.WebCombo5.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo5_SelectedRowChanged);
			this.chkProduct1.CheckedChanged += new System.EventHandler(this.chkProduct1_CheckedChanged);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void WebCombo2_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
		
		}

		private void GuidelineSourceSetID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
		
		}

		private void WebCombo1_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
		
		}

		private void WebCombo3_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
		
		}

		private void WebCombo4_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
		
		}

		private void WebCombo5_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
		
		}

		private void chkProduct1_CheckedChanged(object sender, System.EventArgs e)
		{
		
		}

		private void chkProduct_CheckedChanged(object sender, System.EventArgs e)
		{
		
		}

		private void chkCategory_CheckedChanged(object sender, System.EventArgs e)
		{
		
		}

		private void chkGuideline_CheckedChanged(object sender, System.EventArgs e)
		{
		
		}

		private void chkGuideline1_CheckedChanged(object sender, System.EventArgs e)
		{
		
		}

		public void NewGuidelineMaintenance1()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance1 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		public void NewGuidelineMaintenance2()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance2 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		public void NewGuidelineMaintenance3()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance3 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		public void NewGuidelineMaintenance4()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance4 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		public void NewGuidelineMaintenance5()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance5 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		public void NewGuidelineMaintenance6()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();
				this.GuidelineMaintenance6 = maintenance;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		
		public ActiveAdvice.DataLayer.GuidelineCollection GuidelineCollectionGCP
		{
			get { return this.guidelineCollectionGCP; }
			set { this.guidelineCollectionGCP = value; 
				try
				{
					this.grid.UpdateFromCollection(guidelineCollectionGCP);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineCategoryCollection CategoryCollectionGCP
		{
			get { return this.categoryCollectionGCP; }
			set { this.categoryCollectionGCP = value; 
				try
				{
					this.Webgrid1.UpdateFromCollection(categoryCollectionGCP);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineProductCollection ProductCollectionGCP
		{
			get { return this.productCollectionGCP; }
			set { this.productCollectionGCP = value;
				try
				{
					this.Webgrid2.UpdateFromCollection(productCollectionGCP);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineCollection GuidelineCollectionPCG
		{
			get { return this.guidelineCollectionPCG; }
			set { this.guidelineCollectionPCG = value;
				try
				{
					this.Webgrid5.UpdateFromCollection(guidelineCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineCategoryCollection CategoryCollectionPCG
		{
			get { return this.categoryCollectionPCG; }
			set { this.categoryCollectionPCG = value;
				try
				{
					this.Webgrid4.UpdateFromCollection(categoryCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineProductCollection ProductCollectionPCG
		{
			get { return this.productCollectionPCG; }
			set { this.productCollectionPCG = value; 
				try
				{
					this.Webgrid3.UpdateFromCollection(productCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}


		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance1
		{
			set 
			{
				this.guidelineMaintenance1 = value; 
				try
				{
					this.UpdateFromObject(this.pnlGuideline.Controls,guidelineMaintenance1);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance2
		{
			get { return this.guidelineMaintenance2; }
			set { this.guidelineMaintenance2 = value; 
				try
				{
					this.UpdateFromObject(this.pnlCategory.Controls,guidelineMaintenance2);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				}
		}

		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance3
		{
			get { return this.guidelineMaintenance3; }
			set { this.guidelineMaintenance3 = value;
				try
				{
					this.UpdateFromObject(this.pnlProduct.Controls,guidelineMaintenance3);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				}
		}

		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance4
		{
			get { return this.guidelineMaintenance4; }
			set { this.guidelineMaintenance4 = value;
				try
				{
					this.UpdateFromObject(this.pnlProduct1.Controls,guidelineMaintenance4);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				}
		}

		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance5
		{
			get { return this.guidelineMaintenance5; }
			set { this.guidelineMaintenance5 = value; 
				try
				{
					this.UpdateFromObject(this.pnlCategory1.Controls,guidelineMaintenance5);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance6
		{
			get { return this.guidelineMaintenance6; }
			set { this.guidelineMaintenance6 = value;
				try
				{
					this.UpdateFromObject(this.pnlGuideline1.Controls,guidelineMaintenance6);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

	}
}
