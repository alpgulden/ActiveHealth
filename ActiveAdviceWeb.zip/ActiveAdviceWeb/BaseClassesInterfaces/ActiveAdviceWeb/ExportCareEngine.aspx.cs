using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.BaseClassesInterfaces;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class ExportCareEngineForm : ImportExportBasePage
	{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCEExport;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMORGLevelID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MORGLevelID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldORGLevelID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ORGLevelID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSORGLevelID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo SORGLevelID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMORGLevelID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbORGLevelID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSORGLevelID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFileName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FileName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFileName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOrganizationID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrganizationID;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganizationSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLabel;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Label;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLabel;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtOrganizationPath;
		protected System.Web.UI.WebControls.Label lblOrganizationName;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
		}

		private void LoadData()
		{
			// Create our object that will be the sink for the controls
			targs = new CEExportArgs();
			this.CacheObject(typeof(CEExportArgs), targs);

			this.UpdateFromObject(pnlCEExport.Controls, targs);
			this.UpdateFromObject(pnlCEExport.Controls, (CEExportArguments)targs);
		}

		CEExportArgs targs = null;
		private bool ReadControls()
		{
			targs = (CEExportArgs)this.LoadObject(typeof(CEExportArgs), true);
			this.UpdateToObject(pnlCEExport.Controls, targs);
			this.UpdateToObject(pnlCEExport.Controls, (CEExportArguments)targs);
			return this.IsValid;
		}

		private bool SaveData()
		{
			if (!ReadControls() )
				return false;

			// okay we have ORGlist data, let's put it into the classes that'll be saved to the db
			// First create a schedule task and set it's status to 'INVL' (invalid) in the database
			// while we construct the list of morg/org/sorg
			ScheduleTask st = null;
			
			try
			{
				st = new ScheduleTask();
				if (ValidateArguments((TaskArguments)targs, false) ) // care engine only supports filenames, not folders
				{
					// We can write this task out...
					ScheduleTypeCollection types		= ScheduleTask.ActiveScheduleTypes;
					st.ScheduleTypeID					= types.IndexBy_Code.LookupIntMember("ScheduleTypeID", "CENG");	// Care Engine Export
					ScheduleStatusCollection statuses	= ScheduleTask.ActiveScheduleStatuses;
					st.ScheduleStatusID					= statuses.IndexBy_Code.LookupIntMember("ScheduleStatusID", "PEND"); // ready to rock & roll!!

					st.Task				= targs.Task;	// create our "task" string
					st.Label			= targs.Label;	// label to attached to the scheduled item...
					st.CreatedBy		= this.CurrentUser;
					st.CreateTime		= DateTime.Now;
					st.ScheduledTime	= DateTime.Now;

					// Insert the record into the table...
					st.Insert();
				}
			}
			catch(Exception stEx)
			{
				string msg = stEx.Message;
				throw(stEx);
			}

			return true;
		}

		public void OnToolbarButtonClick_Update(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@QUEUEEXPORT@", EnumPageMessageType.Info, targs.Label);
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			HttpContext.Current.Response.Redirect("Redirect method must redirect to its own page.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion



		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			ToolbarButtonExtraProperties tbep = toolbar.AddButton("@UPDATE@", "Update");
			tbep.ChecksForIsDirty = false;
		}

	}// end of class
}// end of namespace
