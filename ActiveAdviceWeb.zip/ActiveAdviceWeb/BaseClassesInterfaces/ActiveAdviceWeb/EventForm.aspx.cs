using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// The data entry page for a new or an existing Event of a patient's problem.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Event,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(PatientSummaryForm))]
	public class EventForm : PatientBasePage
	{
		private EventCollection possibleDuplicateEvents;
		private ClinicalReviewDecision clinicalReviewDecision;
		private ClinicalReviewRequest clinicalReviewRequest;
		private ClinicalReviewDecisionCollection clinicalReviewDecisions;
		private ClinicalReviewRequestCollection clinicalReviewRequests;
		private Patient patient;
		private Problem problem;
		private PatientCoverage patientCoverage;
		private Event eventObj;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit EventID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAltEventID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AltEventID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAltEventID;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusChangedDisplay;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit StatusChangedDisplay;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatusChangedDisplay;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLateCallIn;
		protected NetsoftUSA.WebForms.OBCheckBox LateCallIn;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNotifyDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit NotifyDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNotifyDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EventTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEventTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo StatusID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatusID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrimaryProblemID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEventSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EventSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEventSourceID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbResolution;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Resolution;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldResolution;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;

		protected TeamUserSelect TeamUserSelect1;
		protected ProviderSelect FacilitySelect;
		protected ProviderSelect ProviderSelect;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacility;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProvider;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderGroupPractice;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStartDateAP;
		protected NetsoftUSA.InfragisticsWeb.WebCombo StartDateAP;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEndDateAP;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EndDateAP;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrimaryProblemID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PrimaryProblemID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridClinicalRequests;
		protected NetsoftUSA.WebForms.OBButton butAddClinicalRequest;
		protected ProviderSelect ProviderGroupPracticeSelect;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlClinicalReview;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlConsultingPr;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel CONTENTPANEL1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldServiceDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ServiceDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbServiceDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPCPDetail;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPCPSelect;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPCPGroupSelect;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlRefProviderSelect;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlRefProviderGroupSelect;

		protected ClinicalReviewControl ClinicalReviewCtl;
		protected AdministrationControl AdministrationControl;

		protected ProviderSelect PCPSelect;
		protected ProviderSelect PCPGroupSelect;
		protected ProviderSelect RefProviderSelect;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDuplicates;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridDuplicates;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAdministration;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected ProviderSelect RefProviderGroupSelect;
		protected UserDefined UserDefined1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			this.TeamUserSelect1.RebindControls(typeof(Event), "AssignedTeamID", "AssignedUserID");
			UserDefined1.ReloadContext("Event",eventObj,true);
			// Facility select
			this.FacilitySelect.RebindControls(typeof(Event), "@FACILITY@", 
				ProviderSearcherType.Facility, null,
				"FacilityID", "FacilityLocationID", "FacilityTypeID", "FacilityNetworkID", "FacilityNetworkStatus");

			// Provider select
			this.ProviderSelect.RebindControls(typeof(Event), "@PROVIDER@", 
				ProviderSearcherType.Provider, null,
				"ProviderID", "ProviderLocationID", "ProviderSpecialtyID", "ProviderNetworkID", "ProviderNetworkStatus");

			// ProviderGroupPractice select
			this.ProviderGroupPracticeSelect.RebindControls(typeof(Event), "@PROVIDERGROUPPRACTICE@", 
				ProviderSearcherType.GroupPractice, null,
				"ProviderGroupID", "ProviderGroupLocationID", "ProviderGroupTypeID", "ProviderGroupNetworkID", "ProviderGroupNetworkStatus");
			
			// PCP/Ref Pr------

			// PCP select
			this.PCPSelect.RebindControls(typeof(Event), "@PCP@", 
				ProviderSearcherType.Provider, null,
				"PCPID", "PCPLocationID", "PCPSpecialtyID", "PCPNetworkID", "PCPNetworkStatus");

			// PCP Group select
			this.PCPGroupSelect.RebindControls(typeof(Event), "@PCPGROUP@", 
				ProviderSearcherType.GroupPractice, null,
				"PCPGroupID", "PCPGroupLocationID", "PCPGroupTypeID", "PCPGroupNetworkID", "PCPGroupNetworkStatus");

			// Ref Provider select
			this.RefProviderSelect.RebindControls(typeof(Event), "@REFPROVIDER@", 
				ProviderSearcherType.Provider, null,
				"RefProviderID", "RefProviderLocationID", "RefProviderSpecialtyID", "RefProviderNetworkID", "RefProviderNetworkStatus");

			// Ref Provider Group select
			this.RefProviderGroupSelect.RebindControls(typeof(Event), "@REFPROVIDERGROUP@", 
				ProviderSearcherType.GroupPractice, null,
				"RefProviderGroupID", "RefProviderGroupLocationID", "RefProviderGroupTypeID", "RefProviderGroupNetworkID", "RefProviderGroupNetworkStatus");

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				eventObj = (Event)this.LoadObject(typeof(Event));  // load object from cache
				clinicalReviewRequests = eventObj.ClinicalReviewRequests;
				clinicalReviewDecisions = (ClinicalReviewDecisionCollection)this.LoadObject(typeof(ClinicalReviewDecisionCollection));  // load object from cache
				clinicalReviewRequest = (ClinicalReviewRequest)this.LoadObject(typeof(ClinicalReviewRequest));  // load object from cache
				clinicalReviewDecision = (ClinicalReviewDecision)this.LoadObject(typeof(ClinicalReviewDecision));  // load object from cache
				possibleDuplicateEvents = (EventCollection)this.LoadObject("possibleDuplicateEvents");  // load object from cache
			}
		
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			//gridClinicalRequests.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridClinicalRequests_ColumnsBoundToDataClass);
			//gridClinicalRequests.ClickCellButton +=new ClickCellButtonEventHandler(gridClinicalRequests_ClickCellButton);

			//gridClinicalDecisions.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridClinicalDecisions_ColumnsBoundToDataClass);
			//gridClinicalDecisions.ClickCellButton += new ClickCellButtonEventHandler(gridClinicalDecisions_ClickCellButton);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "EVE_Details")
			{
				WindowOpener woProblemLink = new WindowOpener();
				woProblemLink.ID = "ProblemLinkForm";
				woProblemLink.NavigateURL = "ProblemLinkForm.aspx";
				woProblemLink.registerClientScripts(this);

				toolbar.AddButton("@LINKPROBLEM@", "LinkProblem").Item.TargetURL = "javascript:" + woProblemLink.getWindowOpenScript(); 
				
				toolbar.AddButton(PatientMessages.MessageIDs.ADDNEWRECORD, "AddNew");
				//toolbar.AddButton(PatientMessages.MessageIDs.PHYSICIANREVIEW, "PhysicianReview");
				//toolbar.AddButton(PatientMessages.MessageIDs.CONSULTINGPR, "ConsultingPr");
				//toolbar.AddButton(PatientMessages.MessageIDs.OUTCOMES, "Outcomes");
				//toolbar.AddButton(PatientMessages.MessageIDs.DIAGNOSES, "Diagnoses");
				//toolbar.AddButton(PatientMessages.MessageIDs.PROCEDURES, "Procedures");
			}
			else if (tab.Key == "EVE_Administration")
			{
				toolbar.AddButton(PatientMessages.MessageIDs.CHANGECOVERAGE, "EVE_ChangeCoverage", false, true);
			}

			// Menu items to be displayed on all tabs
		}

		public void OnToolbarButtonClick_ChangeCoverage(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// data from controls to object
			if (!this.ReadControls())
				return;
			RedirectToSelectCoverage(this.patient, this.patientCoverage, this.problem, this.eventObj);			
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewEvent();
		}

		/*public void OnToolbarButtonClick_PhysicianReview(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PhysicianReviewForm.Redirect(this.patient, this.patientCoverage, this.problem, this.eventObj);
		}*/

		/*
		public void OnToolbarButtonClick_ConsultingPr(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			EventConsultingProviderForm.Redirect(this.patient, this.patientCoverage, this.problem, this.eventObj);
		}*/

		/*public void OnToolbarButtonClick_Outcomes(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			OutcomesForm.Redirect(this.patient, this.patientCoverage, this.problem, this.eventObj);
		}*/

		/*public void OnToolbarButtonClick_Diagnoses(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			try
			{
				ZippyCoderForm.Redirect(this.eventObj, eventObj.CreateDiagnosticSelectionCollection());
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}*/

		/*public void OnToolbarButtonClick_Procedures(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			try
			{
				ZippyCoderForm.Redirect(this.eventObj, eventObj.CreateProcedureSelectionCollection());
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}*/

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@EVENT@");
			}
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.possibleDuplicateEvents == null)
				base.OnToolbarButtonClick_Cancel(toolbar, button);
			else
			{
				// duplicates display mode.  just go out of this mode.
				this.PossibleDuplicateEvents = null;
			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Event Event
		{
			get { return eventObj; }
			set
			{
				eventObj = value;
				try
				{
					this.UpdateFromObject(pnlDetails.Controls, eventObj);  // update controls for the given control collection
					this.UpdateFromObject(pnlFacility.Controls, eventObj);
					this.UpdateFromObject(pnlProvider.Controls, eventObj);
					this.UpdateFromObject(pnlProviderGroupPractice.Controls, eventObj);

					this.UpdateFromObject(pnlPCPSelect.Controls, eventObj);
					this.UpdateFromObject(pnlPCPGroupSelect.Controls, eventObj);
					this.UpdateFromObject(pnlRefProviderSelect.Controls, eventObj);
					this.UpdateFromObject(pnlRefProviderGroupSelect.Controls, eventObj);
					// other object-to-control methods if any
					this.UserDefined1.ReloadContext("Event",this.eventObj,false);
					// go out of duplicates mode.
					this.PossibleDuplicateEvents = null;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Event), eventObj);  // cache object using the caching method declared on the page
				this.CacheObject(typeof(BaseForEventCMSReferral), eventObj);  // cache object using the caching method declared on the page
				ClinicalReviewCtl.ReloadContext();		// must be called after caching the context
				ClinicalReviewCtl.LoadDataForClinicalReviewRequests();
				//AdministrationControl.ReloadContext();
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlDetails.Controls, eventObj);	// controls-to-object
				this.UpdateToObject(pnlFacility.Controls, eventObj);
				this.UpdateToObject(pnlProvider.Controls, eventObj);
				this.UpdateToObject(pnlProviderGroupPractice.Controls, eventObj);

				this.UpdateToObject(pnlPCPSelect.Controls, eventObj);
				this.UpdateToObject(pnlPCPGroupSelect.Controls, eventObj);
				this.UpdateToObject(pnlRefProviderSelect.Controls, eventObj);
				this.UpdateToObject(pnlRefProviderGroupSelect.Controls, eventObj);
				UserDefined1.UserDefinedValue = eventObj.UserDefined;
				UserDefined1.ReadControls();
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewEvent()
		{
			bool result = true;
			Event eventObj = new Event(this.patient, true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				if (problem != null)
					eventObj.PrimaryProblemID = problem.ProblemID;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Event = eventObj;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			Event eventObj = null;
			CoverageSelectionContext covSelContext = null;
			try
			{	
				PageTab.SelectedTabKey = this.TargetTabKey;		// navigate to target tab.

				// if a coverage selection context was passed, the user has selected a coverage and returned back to the problem page
				// to save the problem.
				// continue with saving.
				covSelContext = this.GetParam("CoverageSelectionContext") as CoverageSelectionContext;
				if (covSelContext != null)
				{
					#region Back from Coverage Selection

					// Back from Coverage Selection
					// Get all the context objects from the coverage selection context.
					patient = covSelContext.Patient;
					problem = covSelContext.Problem;
					patientCoverage = covSelContext.PatientCoverage;		// Newly selected coverage is here.
					eventObj = covSelContext.ERC as Event;
					if (eventObj == null)
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Returned from coverage selection with null Event!");
					
					this.CacheObject(typeof(Patient), patient);
					this.CacheObject(typeof(PatientCoverage), patientCoverage);
					this.CacheObject(typeof(Problem), problem);

					// dump the coverage selection steps performed.  will be disabled at deployment.
					this.DumpCoverageSelectionContext(covSelContext);

					if (covSelContext.IsSaving)
					{
						covSelContext.SaveERC();		// save in the coverage selection context.
						this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@EVENT@");
					}

					#endregion
				}
				else
				{
					patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
					if (patient == null)
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
					// get the passed patient subscriber coverage (link to patient)
					patientCoverage = GetParamOrGetFromCache("PatientCoverage", typeof(PatientCoverage)) as PatientCoverage;
					if (patientCoverage == null)	
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-subscriber-coverage");
					problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
					//if (problem == null)	
					//	throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");					

					// if event was not passed, create a new one
					this.CacheObject(typeof(Patient), patient);
					this.CacheObject(typeof(PatientCoverage), patientCoverage);
					this.CacheObject(typeof(Problem), problem);

					eventObj = this.GetParamOrGetFromCache("Event", typeof(Event)) as Event;
					if (eventObj == null)
					{
						if (problem == null)	
							throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");
						NewEvent();
						return PerDayCoverageValidation(covSelContext);
					}

				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//eventObj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			this.Event = eventObj;
			PerDayCoverageValidation(covSelContext);			

			return result;
		}

		#region Per-Day Coverage Validation

		public bool PerDayCoverageValidation(CoverageSelectionContext covSelContext)
		{
			if (this.eventObj == null)
				return false;

			// Validate coverage for an existing event.
			if (covSelContext == null) // && !eventObj.IsNew)
			{
				if (eventObj.RequiresCoverageValidationForToday())
				{
					// if the event is open.
					// validate coverage once a day.
					// Select a valid coverage
					covSelContext = new CoverageSelectionContext(false, this.patient, this.patientCoverage, this.problem, this.eventObj);
					covSelContext.CoverageSelectionPrompt = "@SELECTVALIDCOVERAGE@";
					EnumSelectValidCoverageResult aresult = this.SelectValidCoverage(covSelContext);
					switch (aresult)
					{
						case EnumSelectValidCoverageResult.NoCoverageFound:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "@NOVALIDCOVERAGE@"));
							return false;
						case EnumSelectValidCoverageResult.CoverageValid:
						case EnumSelectValidCoverageResult.SingleCoverageAutoSelected:
							break;
						case EnumSelectValidCoverageResult.UserMustSelectFromMultiple:
							return false;		// user was redirected to coverage selection page.
						default:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "Unknown selection result"));
							return false;
					}					
				}
			}
			return true;
		}

		#endregion

		#region Redirect with CoverageSelectionContext

		/// <summary>
		/// This is called when the user returns from Coverage Selection.
		/// The coverage selection context will contain the newly selected PatientCoverage.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		public static void Redirect(CoverageSelectionContext coverageSelectionContext)
		{
			// BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CoverageSelectionContext", coverageSelectionContext);
			BasePage.Redirect("EventForm.aspx");
		}

		#endregion

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, Event eventObj)
		{
			if (patient == null || patCov == null)
				throw new ActiveAdviceException("You can open an event only when patient and coverage are selected"); 

			//BasePage.PushCurrentCallingPage();
			
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("Event", eventObj);
			BasePage.Redirect("EventForm.aspx");
		}

		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, int eventID)
		{
			Event eventObj = new Event();
			if (!eventObj.Load(patient, eventID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@EVENT@");
			Redirect(patient, patCov, problem, eventObj);
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			//if (this.eventObj.IsNew)
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem);
			//else
			//	pageSummary.RenderObjects(this.patient);
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;

				if (possibleDuplicateEvents == null)		// check if the possible duplicates are already being presented to the user.
				{
					// if not, check duplicates and load possible duplicates and let the user decide
					if (eventObj.DuplicateExists())
					{
						LoadPossibleDuplicateEvents();
						return false;  // let the user decide
					}
				}

				if (this.eventObj.StartDateChanged)
				{
					#region Validate/Select Coverage before save

					// Select a valid coverage and save the event
					CoverageSelectionContext covSelContext = new CoverageSelectionContext(true, this.patient, this.patientCoverage, this.problem, this.eventObj);
					EnumSelectValidCoverageResult result = this.SelectValidCoverage(covSelContext);
					switch (result)
					{
						case EnumSelectValidCoverageResult.NoCoverageFound:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "@NOVALIDCOVERAGE@"));
							return false;
						case EnumSelectValidCoverageResult.CoverageValid:
						case EnumSelectValidCoverageResult.SingleCoverageAutoSelected:
						{
							// save the event in the context of coverage selection
							covSelContext.SaveERC();
							break;
						}
						case EnumSelectValidCoverageResult.UserMustSelectFromMultiple:
							return false;		// user was redirected to coverage selection page.
						default:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "Unknown selection result"));
							return false;
					}
					// End of Select a valid coverage and save the problem

					#endregion
				}
				else
				{
					// start date didn't change.  just save directly.
					if (this.eventObj.IsNew)
						this.eventObj.Save(this.patientCoverage, this.problem);
					else
						this.eventObj.Save();
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			this.PossibleDuplicateEvents = null;	// go out of the duplicates mode.
			return true;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EventCollection PossibleDuplicateEvents
		{
			get { return possibleDuplicateEvents; }
			set
			{
				possibleDuplicateEvents = value;
				try
				{
					gridDuplicates.UpdateFromCollection(possibleDuplicateEvents);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("possibleDuplicateEvents", possibleDuplicateEvents);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadPossibleDuplicateEvents()
		{
			bool result = true;
			EventCollection possibleDuplicateEvents = null;
			try
			{	// use any load method here
				possibleDuplicateEvents = eventObj.GetPossibleDuplicateEvents();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//possibleDuplicateEvents.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.PossibleDuplicateEvents = possibleDuplicateEvents;
			return result;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			bool duplicatesMode = this.possibleDuplicateEvents != null;
			bool isNew = eventObj.IsNew;

			this.SetPageTabItemVisible("EVE_Duplicates", duplicatesMode);
			this.SetPageTabItemVisible("EVE_Details", !duplicatesMode);
			this.SetPageTabItemVisible("EVE_Reviews", !duplicatesMode);
			this.SetPageTabItemVisible("EVE_PCPRefPr", !duplicatesMode);
			this.SetPageTabItemVisible("EVE_Administration", !duplicatesMode);
			this.SetPageTabItemVisible("EVE_UserDefined", !duplicatesMode);

			this.SetPageTabItemVisible("PHYREV_PhysicianReview", !duplicatesMode);
			this.SetPageTabItemVisible("CONSPR_ConsultingPr", !duplicatesMode);
			this.SetPageTabItemVisible("OUT_Outcomes", !duplicatesMode);
			this.SetPageTabItemVisible("DXPX_DXPX", !duplicatesMode);

			// Common tabs that are redirected are available only when the event is not new!
			this.SetPageTabItemEnabled("PHYREV_PhysicianReview", !isNew);
			this.SetPageTabItemEnabled("CONSPR_ConsultingPr", !isNew);
			this.SetPageTabItemEnabled("OUT_Outcomes", !isNew);
			this.SetPageTabItemEnabled("DXPX_DXPX", !isNew);

			// Tab toolbar buttons
			this.SetPageTabToolbarItemEnabled("LinkProblem", !isNew);

			if (duplicatesMode)
				this.SetPageMessage("@EVENTPOSSIBDUP@", EnumPageMessageType.Warning);
		}


		
	}
}
