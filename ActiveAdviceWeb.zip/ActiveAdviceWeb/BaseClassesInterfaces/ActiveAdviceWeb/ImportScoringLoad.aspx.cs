using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.BaseClassesInterfaces;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class ImportScoringLoad : ImportExportBasePage
	{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlScoringLoad;
		protected NetsoftUSA.WebForms.OBLabel OblblScoringLoad;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFileName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FileName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFileName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGenerateEnvelopes;
		protected NetsoftUSA.WebForms.OBCheckBox GenerateEnvelopes;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMORGID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MORGID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMORGID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldORGID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ORGID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbORGID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLabel;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Label;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLabel;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			HttpContext.Current.Response.Redirect("Redirect method must redirect to its own page.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.MORGID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.MORGID_SelectedRowChanged);
			this.ORGID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.ORGID_SelectedRowChanged);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			ToolbarButtonExtraProperties tbep = toolbar.AddButton("@SAVE@", "Update");
			tbep.ChecksForIsDirty = false;
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		protected void LoadData()
		{
			SLA = null; // clear the cache

			// Always start off with the MORG (level = 1).
			SLA.FileName	= null;
			this.UpdateFromObject(pnlScoringLoad.Controls, SLA);
			//this.UpdateFromObject(pnlScoringLoad.Controls, (ScoringLoadArguments)SLA);
		}

		protected bool SaveData()
		{
			this.UpdateToObject(pnlScoringLoad.Controls, SLA);
			this.UpdateToObject(pnlScoringLoad.Controls, (ScoringLoadArguments)SLA);

			if (!this.IsValid)
				return false;

			return true;
		}

		protected ScoringLoadArgs sla = null;
		protected ScoringLoadArgs SLA
		{
			get
			{
				if (null == sla)
				{
					sla = (ScoringLoadArgs)LoadObject(typeof(ScoringLoadArgs), true); // create if it doesn't exist
				}
				return sla;
			}
			set { CacheObject(typeof(ScoringLoadArgs), value); }
		}

		private void MORGID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			// See if the MORG we selected has an ICMID of 'ICM'
			int morgid = 0;
			try
			{
				morgid = Convert.ToInt32(MORGID.Value);
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				this.SetPageMessage("Error reading MORG value", EnumPageMessageType.Error);
				return;
			}
			if (null == SLA)
			{
				this.SetPageMessage("Error reading from cache", EnumPageMessageType.Error);
				return;
			}

			// Okay we recovered the arguments, get to the MORGS
			string ICMflag = null;
			foreach(OrganizationSummary os in SLA.MORGS)
			{
				if (os.OrganizationID == morgid) // find one we selected
				{
					ICMflag = os.ICMID;
					break;
				}
			}

			// ICMflag is either:
			//    null ........... do nothing
			//    "ICM" .......... enable some items
			//    "Anthem FP" ....
			//    "Anthem NA" ....
			EnableControls(ICMflag);
		}

		private void ORGID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			// See if the ORG we selected has an ICMID of 'ICM'
			int orgid = 0;
			try
			{
				orgid = Convert.ToInt32(ORGID.Value);
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				SetPageMessage("Error reading ORGID", EnumPageMessageType.Error);
				return;
			}

			if (null == SLA)
			{
				this.SetPageMessage("Error reading from cache", EnumPageMessageType.Error);
				return;
			}

			// Okay we recovered the arguments, get to the MORGS
			string ICMflag = null;
			foreach(OrganizationSummary os in SLA.ORGS)
			{
				if (os.OrganizationID == orgid) // find one we selected
				{
					ICMflag = os.ICMID;
					break;
				}
			}

			// ICMflag is either:
			//    null ........... do nothing
			//    "ICM" .......... enable some items
			//    "Anthem FP" ....
			//    "Anthem NA" ....
			EnableControls(ICMflag);
		}

		void EnableControls(string ICMflag)
		{
		}
	}// end of class

	[TableMapping(null)]
	public class ScoringLoadArgs : ScoringLoadArguments
	{
		int morgid = 0;
		[FieldValuesMember("LookupOf_MORGID", "OrganizationID", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0, IsRequired=true)]
		public int MORGID
		{
			get { return this.morgid; }
			set { this.morgid = value; }
		}

		int orgid = 0;
		[FieldValuesMember("LookupOf_ORGID", "OrganizationID", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0, IsRequired=true)]
		public int ORGID
		{
			get { return this.orgid; }
			set { this.orgid = value; }
		}

		public OrganizationSummaryCollection MORGS
		{
			get
			{ 
				if (null == morgs)
				{
					morgs = new OrganizationSummaryCollection();
					morgs.GetOrganizationsByLevelICMflag(-1, 1);
					OrganizationSummary os = new OrganizationSummary();
					os.OrganizationID = 0; os.Selected = false; os.Name = "ALL";
					morgs.InsertRecord(0, os);
				}
				return morgs;
			}
		}

		public OrganizationSummaryCollection ORGS
		{
			get
			{
				if (null == orgs)
				{
					orgs = new OrganizationSummaryCollection();
					orgs.GetOrganizationsByLevelICMflag(-1, 2);
					OrganizationSummary os = new OrganizationSummary();
					os.OrganizationID = 0; os.Selected = false; os.Name = "ALL";
					orgs.InsertRecord(0, os);
				}
				return orgs;
			}
		}

		/// <summary>
		/// LookupOf_OrgLevelID
		/// returns a collection of schedule types, the first record
		/// being "ALL".
		/// </summary>
		OrganizationSummaryCollection morgs = null;
		public OrganizationSummaryCollection LookupOf_MORGID
		{
			get	{ return MORGS; }
		}

		OrganizationSummaryCollection orgs = null;
		public OrganizationSummaryCollection LookupOf_ORGID
		{
			get	{ return ORGS; }
		}

	}// end of class


}// end of namespace
