using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;


namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for CaseManagementHistory.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.CMSMessages,DataLayer")]
	[MainDataClass("ActiveAdvice.DataLayer.CMS,DataLayer")]
	public class CaseManagementHistory : BasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlHistory;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private CMSStatusHistoryCollection cMSStatusHistories;
		private CMS parentCMS;

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModelessDialog;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				LoadDataForCMSStatusHistories();
			}
			else
			{
				cMSStatusHistories = (CMSStatusHistoryCollection)this.LoadObject(typeof(CMSStatusHistoryCollection));  // load object from cache
			}	
		}
		
		
		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}
	

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@CLOSE@", "Close", true).Item.TargetURL = "javascript:window.close()";
		}

		public void OnToolbarButtonClick_Close(WebToolbar PageToolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BasePage.PushParam("CMS", cMSStatusHistories.ParentCMS);
			BasePage.Redirect("CaseManagementForm.aspx");
		}
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMSStatusHistoryCollection CMSStatusHistories
		{
			get { return cMSStatusHistories; }
			set
			{
				cMSStatusHistories = value;
				try
				{
					grid.UpdateFromCollection(cMSStatusHistories);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(CMSStatusHistoryCollection), cMSStatusHistories);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForCMSStatusHistories()
		{
			bool result = true;
			CMSStatusHistoryCollection cMSStatusHistories = new CMSStatusHistoryCollection();
			try
			{	// use any load method here
				// or pull from the parameter passed to this page via PushParam
				parentCMS  = (CMS)this.LoadObject("CMS");
				if (parentCMS != null)
				{
					parentCMS.LoadCMSStatusHistories(true);
					cMSStatusHistories = parentCMS.CMSStatusHistories;
				}
				else 
					throw new ActiveAdviceException("CMS Object is required to show its history!");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				cMSStatusHistories.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CMSStatusHistories = cMSStatusHistories;
			return result;
		}
	}
}
