using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using Infragistics.WebUI.UltraWebToolbar;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// The Intake Log module is the typical initial entry point for Patient information into the ActiveAdvice system. 
	/// All incoming calls or requests are handled by the Intake staff and are entered into the Intake Log. 
	/// Every entry into the Intake log must have a resolution, a resolution being an Event, Note or Activity.
	/// </summary>
	/// 

	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.INTAKE)]

	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("FaxForm,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	//[BackPage(typeof(FaxInfoSearch))]
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@FAXLOGTITLE@")]
	public class FaxForm : BasePage
	{
		private FaxInfo faxInfo;
		
		private BaseLetterQueue queue;

		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbToFName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbToFaxNo;
		protected NetsoftUSA.WebForms.OBFieldLabel lbToLName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbToCompany;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldToFName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldToLName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldToFaxNo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldToCompany;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDisclaimer;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnFromInfo;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDisclaimer;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit textFromCompany;
		protected NetsoftUSA.WebForms.OBFieldLabel obSubjet;
		protected NetsoftUSA.WebForms.OBFieldLabel ObFromCompany;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit textSubject;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFromComapny;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSubject;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit textToFName;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit textToFaxNo;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit textToCompany;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit textToLName;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.WebForms.OBTextBox textDisclaimer;
		protected System.Web.UI.WebControls.Label Label1;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel Oblabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLetter;
		protected NetsoftUSA.WebForms.OBLabel OblabelPreview;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlToInfo;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				this.LoadDataOnPostback();			// Use load data method for data entry forms
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@FAXSEND@", "Send", true, false);
			toolbar.AddButton("@CANCEL@", "Cancel", false, true);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FaxInfo FaxInfoField
		{
			get { return faxInfo; }
			set
			{
				faxInfo = value;
				try
				{
					this.RequiredValidationsEnabled = faxInfo.ValidateForSend();

					this.UpdateFromObject(pnlToInfo.Controls, faxInfo);
					this.UpdateFromObject(pnFromInfo.Controls, faxInfo);
					this.UpdateFromObject(pnlDisclaimer.Controls, faxInfo);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(FaxInfo), faxInfo);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlToInfo.Controls, faxInfo, false);
				this.UpdateToObject(pnFromInfo.Controls, faxInfo, false);
				this.UpdateToObject(pnlDisclaimer.Controls, faxInfo, false);

				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
		}

		
		/// <summary>
		///
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			FaxInfo faxInfo = null;
			try
			{	
				queue = this.GetParamOrGetFromCache("BaseQueueForFax", typeof(BaseLetterQueue)) as BaseLetterQueue;
				faxInfo = this.GetParamOrGetFromCache("FaxInfo", typeof(FaxInfo)) as FaxInfo;
				if (queue == null && (faxInfo!=null && faxInfo.Attachment == null))
					throw (new ApplicationException("There is nothing to fax!."));

				// if queue
				if (faxInfo == null)
				{
					faxInfo = new FaxInfo();
					if (queue != null)
					{
						faxInfo.FillFromReceiver(queue.ReceiverTypeID, queue.PatientID, queue.ReferralID, queue.EventID, queue.CMSID);
					}
				}

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
			}
			this.FaxInfoField = faxInfo;
			BasePage.PushParam("BaseQueueForFax", this.queue);
			return result;
		}

		/// <summary>
		///
		/// </summary>
		public bool LoadDataOnPostback()
		{
			bool result = true;
			try
			{	
				//this.faxInfo = new FaxInfo();
				// still from cache - ow attachment info is lost
				faxInfo = this.GetParamOrGetFromCache("FaxInfo", typeof(FaxInfo)) as FaxInfo;
				queue = this.GetParamOrGetFromCache("BaseQueueForFax", typeof(BaseLetterQueue)) as BaseLetterQueue;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
			}
			return result;
		}
		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(FaxInfo faxInfo)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("FaxInfo", faxInfo);
			BasePage.Redirect("FaxForm.aspx");
		}

		public static void Redirect(BaseLetterQueue queue)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("BaseQueueForFax", queue);
			BasePage.Redirect("FaxForm.aspx");
		}
		
		public static void Redirect()
		{
			BasePage.PushCurrentCallingPage();
			BasePage.Redirect("FaxForm.aspx");
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			//this.SetPageToolbarItemEnabled("Send", FaxInfo.ValidateForSend());
			this.SetPageToolbarItemEnabled("Send", true);

			// finally add client script
			if (this.queue != null)
				this.ImageButton1.Attributes["onclick"] = MapPreviewClientScript();
			else
				this.ImageButton1.Visible = false;
		}

		/*
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
		}
		*/

		public void OnToolbarButtonClick_Send(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (!this.ReadControls())
				return;

			bool success = false;

			try 
			{
				if (this.queue != null)
				{
					if (BaseFaxQueue.SendQueueItemToFax(this.queue.QueueID, this.faxInfo, AASecurityHelper.UserName))
					{
						this.SetPageMessage("@FAXSENTMSG@", EnumPageMessageType.Info, "@FAXINFO@");
						this.IsDirty = false;
						success = true;
					}
				}
				else if (faxInfo.Attachment != null)
				{
					if (BaseFaxQueue.SendDirectFax(this.faxInfo, AASecurityHelper.UserName))
					{
						this.SetPageMessage("@FAXSENTMSG@", EnumPageMessageType.Info, "@FAXINFO@");
						this.IsDirty = false;
						success = true;
					}
				}
			}
			catch(Exception ex)
			{
			}
			finally
			{
				if (!success)
				{
					this.SetPageMessage("@FAXFAILEDMSG@", EnumPageMessageType.Error, "@FAXINFO@");
					this.IsDirty = true;
				}		
			}
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// need to clean out cache
			this.CacheObject(typeof(FaxInfo), null);  // cache object using the caching method declared on the page

			GoBack();			
		}

		private void GoBack()
		{
			switch(this.BackPage)
			{
				case "LetterForm.aspx":
					BasePage.Redirect("LetterForm.aspx");
					break;
				case "LetterQueueMaintenance.aspx":
					BasePage.Redirect("LetterQueueMaintenance.aspx");
					break;
			}
		}


		public override void OnSetDirty()
		{
			base.OnSetDirty ();
		}
	
	
		private static string targeturlPreview = "FaxPreView.aspx?Mode=OBJECT";
		private int popupWidth = 770;
		private int popupHeight = 520;
		private string MapPreviewClientScript()
		{
//			string fullURL = String.Format("{0}&PARAM1={1}",  targeturlPreview, this.queue.QueueID);
//			string parameters   = String.Format("'width={0},height={1},resizable=0,titlebar=1,toolbar=0,scrollbars=0,status=0'", popupWidth,popupHeight);
//			string previewURL =  "JScript:window.open('" 
//				+ fullURL
//				+ "', 'PREVIEW',"
//				+ parameters
//				+" ); return false;";
//			return previewURL;

			if (this.queue == null) return "";

			string previewURL =  String.Format("javascript:PreviewLetter({0},'{1}'); return false;", 
					this.queue.QueueID, this.queue.LQType.ToString());

			return previewURL;
		}

	}
}
