using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.InfragisticsWeb;


namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for ReportParameter.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ReportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MReports")]
	[PageTitle("@REPORTPARAMETERSTITLE@")]
	public class ReportParameter : BasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTillDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TillDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTillDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFromDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FromDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFromDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutliners;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutliners;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Outliners;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNewBornDischaredWithMother;
		protected NetsoftUSA.WebForms.OBCheckBox NewBornDischaredWithMother;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCodeTable;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CodeTable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCodeTable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSubtotalBy;
		protected NetsoftUSA.InfragisticsWeb.WebCombo SubtotalBy;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSubtotalBy;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStateName;
		protected NetsoftUSA.InfragisticsWeb.WebCombo StateName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStateName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCmsTypeName;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CmsTypeName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCmsTypeName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlParameters;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForSORG;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanId;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected TeamUserSelect TeamUserSelect1;
		private string reportName;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMajorGroup;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSubGroup;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSubSubGroup;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSortBy;
		protected NetsoftUSA.WebForms.OBFieldLabel lbShowDetails;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReadmitDays;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMajorGroup;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MajorGroup;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSubGroup;
		protected NetsoftUSA.InfragisticsWeb.WebCombo SubGroup;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSubSubGroup;
		protected NetsoftUSA.InfragisticsWeb.WebCombo SubSubGroup;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSortBy;
		protected NetsoftUSA.InfragisticsWeb.WebCombo SortBy;
		protected NetsoftUSA.WebForms.OBCheckBox ShowDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReadmitDays;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ReadmitDays;
		private ReportParameters reportParameters;

		//for hiding the controls based on report for better layout the table
		// and rows are made server controls
		protected System.Web.UI.HtmlControls.HtmlTable Table1;
		protected System.Web.UI.HtmlControls.HtmlTableRow Sorgidrow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Planrow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Teamuserrow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Enddaterow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Fromdaterow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Statenamerow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Cmstyperow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Outliersrow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Newborndischargedwithmotherrow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Codetablerow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Subtotalbyrow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Majorgrouprow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Subgrouprow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Subsubgrouprow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Sortbyrow;
		protected System.Web.UI.HtmlControls.HtmlTableRow Showdetailsrow;
		//protected System.Web.UI.WebControls.Label lblOrganizationName;
		protected System.Web.UI.HtmlControls.HtmlTable Table2;
		protected System.Web.UI.HtmlControls.HtmlTable Table4;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMORGId;
		protected NetsoftUSA.WebForms.OBFieldLabel lblMORGId;
		protected System.Web.UI.HtmlControls.HtmlTableRow Readmitdaysrow;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtOrganizationPath;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganizationSearch;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationId;
		protected System.Web.UI.WebControls.Label lblOrganizationName;
		protected NetsoftUSA.WebForms.OBLabel lblReportName;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Dates;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDates;
		protected System.Web.UI.HtmlControls.HtmlTableRow IntDatesRow;		
		protected PlanSelect PlanSelect;

	
		private void Page_Load(object sender, System.EventArgs e)
		{		
			 // Put user code to initialize the page here
			this.TeamUserSelect1.RebindControls(typeof(ReportParameters), "TeamID", "UserID");
			if(!Page.IsPostBack)
				LoadData();
			else
			{
				reportParameters = this.LoadObject(typeof(ReportParameters)) as ReportParameters;
				//this.UpdateFromObject(this.Sorgidrow.Controls, reportParameters);
				reportName = this.LoadObject("ReportName") as string;
				
			}
			this.PlanSelect.RebindControls(typeof(ReportParameters), "PlanID", "PlanName", this.OrganizationId);
			// set report header 
			lblReportName.Text = "Select Parameters for ";
			if (reportName == Language.TranslateSingle("BYTEAMMORGORGSORGUSER") || reportName == Language.TranslateSingle("BYUSERFACMORGORGSORG"))
				lblReportName.Text += Language.TranslateSingle("DAILYWORKLIST") + " " + reportName;
			else if (reportName == Language.TranslateSingle("SUMMARYBYMORGORGSORG") ||
				reportName == Language.TranslateSingle("SUMMARYBYUSERFACMORGORGSORG") ||
				reportName == Language.TranslateSingle("SUMMARYBYFACMORGORGSORG"))
				lblReportName.Text += Language.TranslateSingle("PATIENTCENSUSSUMMARY") + " " + reportName;
			else if (reportName == Language.TranslateSingle("COSTCOMPSUMMARY") ||
				reportName == Language.TranslateSingle("COSTCOMPDETAILS") || 
				reportName == Language.TranslateSingle("SUMMARYOFINPATINETOUTPATIENTSAVINGS"))
				lblReportName.Text += Language.TranslateSingle("SAVINGS") + " " + reportName;
			else if (reportName == Language.TranslateSingle("FACILITYNETWORKANALYSIS") || 
				reportName == Language.TranslateSingle("PROVIDERNETWORKANALYSIS"))
				lblReportName.Text += Language.TranslateSingle("NETWORKANALYSIS") + " " + reportName;
			else if (reportName == Language.TranslateSingle("OPENCMLOGBYUSER") || reportName == Language.TranslateSingle("OPENCMLOGBYORGLEVELS") ||
				reportName == Language.TranslateSingle("NEWCMLOGBYORGLEVELS") || reportName == Language.TranslateSingle("NEWCMLOGBYUSER") ||
				reportName == Language.TranslateSingle("CLOSEDCMLOGBYORGLEVELS") || reportName == Language.TranslateSingle("CLOSEDCMLOGBYUSER"))
				lblReportName.Text += Language.TranslateSingle("CAREMANAGEMENT") + " " + reportName;
			else if (reportName == Language.TranslateSingle("RPTACTPATIENTSUBSC") || reportName == Language.TranslateSingle("RPTCLOSEDCMSEVENT") ||
				reportName == Language.TranslateSingle("RPTCLOSEDEVENT") || reportName == Language.TranslateSingle("RPTCLOSEDIPEVENT") ||
				reportName == Language.TranslateSingle("RPTOPENEVENT") || reportName == Language.TranslateSingle("RPTREFERRALS"))

				lblReportName.Text += Language.TranslateSingle("GENERALEDIT") + " " + reportName;
			else
				lblReportName.Text += reportName;
		}

//		protected override void OnPreRender(EventArgs e)
//		{
//			base.OnPreRender(e);
//			if(this.SORGId.ValueInt==0)
//			{
//				this.PlanId.Enabled=false;
//				this.WindowOpenerForPlanID.Enabled=false;
//			}
//
//		}
		
		public void LoadData()
		{
			reportName = this.GetParamOrGetFromCache("ReportName",System.Type.GetType("System.String")) as string;
			NewReportParameters();
			HideControls(reportName);
			this.CacheObject("ReportName",reportName);
		}

		public ReportParameters ReportParameters
		{
			get
			{
				return this.reportParameters;
			}
			set
			{
				this.reportParameters = value;
				try
				{
					this.UpdateFromObject(this.pnlParameters.Controls,reportParameters);
					this.CacheObject(typeof(ReportParameters),reportParameters);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public void NewReportParameters()
		{
			ReportParameters param = new ReportParameters();
			param.FromDate = System.DateTime.Today;
			param.EndDate = System.DateTime.Today;
			this.ReportParameters = param;
		}

		public void HideControls(string repName)
		{

			Sorgidrow.Visible = false;
			Planrow.Visible = false;
			Teamuserrow.Visible = false;
			Enddaterow.Visible = false;
			Fromdaterow.Visible = false;
			Statenamerow.Visible = false;
			Cmstyperow.Visible = false;
			Outliersrow.Visible = false;
			Newborndischargedwithmotherrow.Visible = false;
			Codetablerow.Visible = false;
			Subtotalbyrow.Visible = false;
			Majorgrouprow.Visible = false;
			Subgrouprow.Visible = false;
			Subsubgrouprow.Visible = false;
			IntDatesRow.Visible = false;
			Sortbyrow.Visible = false;
			Showdetailsrow.Visible = false;
			Readmitdaysrow.Visible = false;
			try
			{
				#region "Show/Hide Report Specific Criteria"
				if(repName==Language.TranslateSingle("BYTEAMMORGORGSORGUSER"))
				{
					Sorgidrow.Visible = Teamuserrow.Visible = Enddaterow.Visible = true;
				}
				else if(repName == Language.TranslateSingle("BYUSERFACMORGORGSORG"))
				{
					Sorgidrow.Visible = Teamuserrow.Visible = Enddaterow.Visible =  true;
				}
				else if(repName==Language.TranslateSingle("SUMMARYBYMORGORGSORG"))
				{
					Sorgidrow.Visible = true;
				}
			
				else if(repName==Language.TranslateSingle("SUMMARYBYUSERFACMORGORGSORG"))
				{
					Sorgidrow.Visible =  true;
				}
				else if(repName==Language.TranslateSingle("SUMMARYBYFACMORGORGSORG"))
				{
					Sorgidrow.Visible = true;
				}
				else if(repName==	Language.TranslateSingle("OPENEVENTSPAGEBREAKAFTERSORG"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = true;
				}
			
				else if(repName==	Language.TranslateSingle("OPENEVENTSPAGEBRAFTEREVENT"))
				{
					Sorgidrow.Visible =  Enddaterow.Visible = Fromdaterow.Visible = true;
				}
				else if(repName==	Language.TranslateSingle("CLOSEDEVENTSPAGEBRAFTERSORG"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = true;
				}
				else if(repName == Language.TranslateSingle("CLOSEDEVENTSPAGEBRAFTEREVENT"))
				{
					Sorgidrow.Visible = Fromdaterow.Visible = Enddaterow.Visible = true;
				}
				else if(repName==	Language.TranslateSingle("UTILWITHNOAGGBYSUBGRP"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = Planrow.Visible= Outliersrow.Visible = true;
					Newborndischargedwithmotherrow.Visible = true;
				
					this.Outliners.SelectedIndex = 1; // Set Exclude as default.
					ReportCriteria criteriaPopulate = new ReportCriteria();
				
					Majorgrouprow.Visible = true;
					// Change Major Group Contents.
					MajorGroup.FillComboFromArray(criteriaPopulate.GetMajorGroupItems("UTILWITHNOAGGBYSUBGRP"));
				
				
					Subgrouprow.Visible = true;
					// Change SubGroup Contents.
					SubGroup.FillComboFromArray(criteriaPopulate.GetSubItems("UTILWITHNOAGGBYSUBGRP"));

					Subtotalbyrow.Visible = true;
					// Change SubTotal Contents.
					SubtotalBy.FillComboFromArray(criteriaPopulate.GetSubtotalItems("UTILWITHNOAGGBYSUBGRP"));

				}
				else if(repName==	Language.TranslateSingle("ACTUTILWITHNOAGGBYSUBGRP"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = Planrow.Visible= Outliersrow.Visible = true;
					Newborndischargedwithmotherrow.Visible = true;

					ReportCriteria populateCriteria = new ReportCriteria();

					Majorgrouprow.Visible = true;
					MajorGroup.FillComboFromArray(populateCriteria.GetMajorGroupItems("ACTUTILWITHNOAGGBYSUBGRP"));

					Subgrouprow.Visible = true;
					SubGroup.FillComboFromArray(populateCriteria.GetSubItems("ACTUTILWITHNOAGGBYSUBGRP"));


					Subtotalbyrow.Visible = true;
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("ACTUTILWITHNOAGGBYSUBGRP"));
				}
				else if(repName==	Language.TranslateSingle("IPAUTHORIZATIONSBYSTATE"))
				{
					Enddaterow.Visible = Fromdaterow.Visible = 	Statenamerow.Visible = true;
					ReportCriteria populateCriteria = new ReportCriteria();

					Subtotalbyrow.Visible = true;
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("IPAUTHORIZATIONSBYSTATE"));

				}
				else if(repName==	Language.TranslateSingle("OUTPATIENTUTILWITHNOAGGBYSUBGRP"))
				{
					Sorgidrow.Visible = Fromdaterow.Visible = Enddaterow.Visible = 	Planrow.Visible= true;
					ReportCriteria populateCriteria = new ReportCriteria();
				    
					Majorgrouprow.Visible = true;
					MajorGroup.FillComboFromArray(populateCriteria.GetMajorGroupItems("OUTPATIENTUTILWITHNOAGGBYSUBGRP"));
			
					Subtotalbyrow.Visible = true;
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("OUTPATIENTUTILWITHNOAGGBYSUBGRP"));
				
					Subgrouprow.Visible = true;		
					SubGroup.FillComboFromArray(populateCriteria.GetSubItems("OUTPATIENTUTILWITHNOAGGBYSUBGRP"));
					// select 
					SubGroup.SelectedIndex = 0;
					SubGroup.ReadOnly = !(SubGroup.Editable = false);

				}
				else if(repName==	Language.TranslateSingle("COSTCOMPSUMMARY"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = 	Planrow.Visible= true;
					ReportCriteria populateCriteria = new ReportCriteria();

					Subtotalbyrow.Visible = true;
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("COSTCOMPSUMMARY"));

				
				}
				else if(repName==	Language.TranslateSingle("COSTCOMPDETAILS"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = Planrow.Visible= true;
					ReportCriteria populateCriteria = new ReportCriteria();
				
					Subtotalbyrow.Visible = true;
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("COSTCOMPDETAILS"));
				
				}
				else if(repName==	Language.TranslateSingle("SUMMARYOFINPATINETOUTPATIENTSAVINGS"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = 	Planrow.Visible= true;
					Outliersrow.Visible = true;
					Newborndischargedwithmotherrow.Visible = true;

					// Populate Report Criteria 
					ReportCriteria populateCriteria = new ReportCriteria();
				
					Subtotalbyrow.Visible = true;
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("SUMMARYOFINPATINETOUTPATIENTSAVINGS"));

				
				}
				else if(repName==	Language.TranslateSingle("REFERRALSUMMARYWITHNOAGGRBYSUBGRP"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = 	Planrow.Visible= true;
					ReportCriteria populateCriteria = new ReportCriteria();
					Majorgrouprow.Visible = true;
					MajorGroup.FillComboFromArray(populateCriteria.GetMajorGroupItems("REFERRALSUMMARYWITHNOAGGRBYSUBGRP"));

					Subgrouprow.Visible = true;	
					SubGroup.FillComboFromArray(populateCriteria.GetSubItems("REFERRALSUMMARYWITHNOAGGRBYSUBGRP"));

					Subtotalbyrow.Visible = true;
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("REFERRALSUMMARYWITHNOAGGRBYSUBGRP"));


				}
				else if(repName==	Language.TranslateSingle("FACILITYNETWORKANALYSIS"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = Outliersrow.Visible = true;
					Newborndischargedwithmotherrow.Visible = true;
				}
				else if(repName==	Language.TranslateSingle("PROVIDERNETWORKANALYSIS"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = Outliersrow.Visible = true;
					Newborndischargedwithmotherrow.Visible = true;
				}
				else if(repName==	Language.TranslateSingle("SUMMARYOFCLOSEDCASES"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = true;
				
					Planrow.Visible= true;
					ReportCriteria populateCriteria = new ReportCriteria();
					Subtotalbyrow.Visible = true;
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("SUMMARYOFCLOSEDCASES"));

				}
				else if((repName==	Language.TranslateSingle("OPENCMLOGBYUSER")) ||
					(repName == Language.TranslateSingle("NEWCMLOGBYUSER")))
				{
					Teamuserrow.Visible = Cmstyperow.Visible = true;
				}
				else if (repName == Language.TranslateSingle("CLOSEDCMLOGBYUSER"))
				{
					Teamuserrow.Visible = Cmstyperow.Visible = true;
					Fromdaterow.Visible = Enddaterow.Visible = true;
				}
				else if((repName==	Language.TranslateSingle("OPENCMLOGBYORGLEVELS")) ||
					(repName ==	Language.TranslateSingle("NEWCMLOGBYORGLEVELS")) ||
					(repName ==	Language.TranslateSingle("CLOSEDCMLOGBYORGLEVELS")))
				{
					Teamuserrow.Visible = Cmstyperow.Visible = Sorgidrow.Visible = true;
					// Date range visible only for NEW / CLOSED CMS
					Enddaterow.Visible = Fromdaterow.Visible = !(repName==	Language.TranslateSingle("OPENCMLOGBYORGLEVELS"));
				}			
				else if((repName==	Language.TranslateSingle("OPENMATERNICHEKLOGBYUSER")) ||
					(repName == Language.TranslateSingle("NEWMATERNICHEKLOGBYUSER")) || 
					(repName == Language.TranslateSingle("CLOSEDMATERNICHEKLOGBYUSER")))
				{
					Teamuserrow.Visible = true;
					Fromdaterow.Visible = Enddaterow.Visible = !(repName == Language.TranslateSingle("OPENMATERNICHEKLOGBYUSER"));
				}
				else if ((repName == Language.TranslateSingle("OPENMATERNICHEKLOGBYORGLEVELS")) ||
					(repName == Language.TranslateSingle("NEWMATERNICHEKLOGBYORGLEVELS")) ||
					(repName == Language.TranslateSingle("CLOSEDMATERNICHEKLOGBYORGLEVELS")))

				{
					Sorgidrow.Visible = true;
					Fromdaterow.Visible = Enddaterow.Visible = !(repName == Language.TranslateSingle("OPENMATERNICHEKLOGBYORGLEVELS"));
			
				}

				else if(repName==	Language.TranslateSingle("MATERNICHEKRISKTYPESTATISTICS"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = true;	
				}
				else if(repName==	Language.TranslateSingle("POTENTIALLARGECASES"))
				{
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = true;
				}
				else if(repName==	Language.TranslateSingle("MULTIPLEADMISSIONREPORT"))
				{
					IntDatesRow.Visible = true;
					Sorgidrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = 	Planrow.Visible = true;
					//Readmitdaysrow.Visible = true;
					Planrow.Visible= true;
					ReportCriteria populateCriteria = new ReportCriteria();

					Majorgrouprow.Visible = true;
					MajorGroup.FillComboFromArray(populateCriteria.GetMajorGroupItems("MULTIPLEADMISSIONREPORT"));

					Subgrouprow.Visible = true;	
					SubGroup.FillComboFromArray(populateCriteria.GetSubItems("MULTIPLEADMISSIONREPORT"));

					Subtotalbyrow.Visible = true;
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("MULTIPLEADMISSIONREPORT"));
				
				}

				else if(repName==	Language.TranslateSingle("ACTIVITYEDIT"))
				{
					Sorgidrow.Visible = Teamuserrow.Visible = Planrow.Visible= true;
					ReportCriteria populateCriteria = new ReportCriteria();
					Sortbyrow.Visible =true;
					SortBy.FillComboFromArray(populateCriteria.GetSortByItems("ACTIVITYEDIT"));
					Subtotalbyrow.Visible = true;
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("ACTIVITYEDIT"));
				}
				else if(repName==	Language.TranslateSingle("INVOICEOFBILLABLEACTIVITY"))
				{
					Sorgidrow.Visible = true;
					Enddaterow.Visible = true;
					Fromdaterow.Visible = true;
				
				}
				else if(repName==	Language.TranslateSingle("CODETABLEREPORT"))
				{
					Codetablerow.Visible = true;
					CodeTableListCollection codeTables = new CodeTableListCollection();
					codeTables.LoadAll();
					this.CodeTable.FillComboFromCollection(codeTables,"CodeTableName","CodeTableName");
				}
				else if(repName==	Language.TranslateSingle("INTAKELOGWITHNOAGG"))
				{
					Showdetailsrow.Visible = Sorgidrow.Visible = Planrow.Visible = Enddaterow.Visible = Fromdaterow.Visible = true;
					
					ReportCriteria populateCriteria = new ReportCriteria();
					Subtotalbyrow.Visible = true;
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("INTAKELOGWITHNOAGG"));
					Majorgrouprow.Visible = true;
					MajorGroup.FillComboFromArray(populateCriteria.GetMajorGroupItems("INTAKELOGWITHNOAGG"));
					Subgrouprow.Visible = true;
					SubGroup.FillComboFromArray(populateCriteria.GetSubItems("INTAKELOGWITHNOAGG"));
					Subsubgrouprow.Visible = true;
					SubSubGroup.FillComboFromArray(populateCriteria.GetSubItems("INTAKELOGWITHNOAGG"));
				}
				else if(repName==	Language.TranslateSingle("EVENTSTATISTICS"))
				{
					Sorgidrow.Visible = Planrow.Visible=  Enddaterow.Visible = Fromdaterow.Visible = true;
					ReportCriteria populateCriteria = new ReportCriteria();

					Subtotalbyrow.Visible = true;			
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubtotalItems("EVENTSTATISTICS"));
					Majorgrouprow.Visible = true;
					MajorGroup.FillComboFromArray(populateCriteria.GetMajorGroupItems("EVENTSTATISTICS"));
					Subgrouprow.Visible = true;
					SubGroup.FillComboFromArray(populateCriteria.GetSubItems("EVENTSTATISTICS"));
				}
				else if (repName == Language.TranslateSingle("RPTREFERRALS"))
				{
					ReportCriteria populateCriteria = new ReportCriteria();
					Sorgidrow.Visible = Planrow.Visible = this.Teamuserrow.Visible = Fromdaterow.Visible = Enddaterow.Visible = true;
					Sortbyrow.Visible = Subtotalbyrow.Visible = true;
					SortBy.FillComboFromArray(populateCriteria.GetSortByItems("RPTREFERRALS"));
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubItems("RPTREFERRALS"));
				}
				else if (repName == Language.TranslateSingle("RPTOPENEVENT"))
				{
					ReportCriteria populateCriteria = new ReportCriteria();
					Sorgidrow.Visible = Planrow.Visible = this.Teamuserrow.Visible = Fromdaterow.Visible = Enddaterow.Visible = true;
					Sortbyrow.Visible = Subtotalbyrow.Visible = true;
					SortBy.FillComboFromArray(populateCriteria.GetSortByItems("RPTOPENEVENT"));
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubItems("RPTOPENEVENT"));
				}
				else if (repName == Language.TranslateSingle("RPTCLOSEDIPEVENT")) 
				{
					ReportCriteria populateCriteria = new ReportCriteria();
					Sorgidrow.Visible = Planrow.Visible = this.Teamuserrow.Visible = Fromdaterow.Visible = Enddaterow.Visible = true;
					Sortbyrow.Visible = Subtotalbyrow.Visible = true;
					SortBy.FillComboFromArray(populateCriteria.GetSortByItems("RPTCLOSEDIPEVENT"));
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubItems("RPTCLOSEDIPEVENT"));
				}
				else if (repName == Language.TranslateSingle("RPTCLOSEDEVENT"))
				{
					ReportCriteria populateCriteria = new ReportCriteria();
					Sorgidrow.Visible = Planrow.Visible = this.Teamuserrow.Visible = Fromdaterow.Visible = Enddaterow.Visible = true;
					Sortbyrow.Visible = Subtotalbyrow.Visible = true;
					SortBy.FillComboFromArray(populateCriteria.GetSortByItems("RPTCLOSEDEVENT"));
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubItems("RPTCLOSEDEVENT"));
				}
				else if (repName == Language.TranslateSingle("RPTCLOSEDCMSEVENT"))
				{
					ReportCriteria populateCriteria = new ReportCriteria();
					Sorgidrow.Visible = Planrow.Visible = this.Teamuserrow.Visible = Fromdaterow.Visible = Enddaterow.Visible = true;
					Sortbyrow.Visible = Subtotalbyrow.Visible = true;
					SortBy.FillComboFromArray(populateCriteria.GetSortByItems("RPTCLOSEDCMSEVENT"));
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubItems("RPTCLOSEDCMSEVENT"));
				}
				else if (repName == Language.TranslateSingle("RPTACTPATIENTSUBSC"))
				{
					ReportCriteria populateCriteria = new ReportCriteria();
					Sorgidrow.Visible = Planrow.Visible = this.Teamuserrow.Visible = Fromdaterow.Visible = Enddaterow.Visible = true;
					Sortbyrow.Visible = Subtotalbyrow.Visible = true;
					SortBy.FillComboFromArray(populateCriteria.GetSortByItems("RPTACTPATIENTSUBSC"));
					SubtotalBy.FillComboFromArray(populateCriteria.GetSubItems("RPTACTPATIENTSUBSC"));
				}
				else
					throw new ActiveAdviceException("Invalid report name","redirect");
				#endregion
			}
			catch (ActiveAdviceException ex)
			{
				BasePage.Redirect("ReportMaintenance.aspx");
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@REPORT@","Report",true,false);
			toolbar.AddButton("@CANCEL@","Cancel",false,false);
		}

		public static new void Redirect(string repName)
		{
			BasePage.PushParam("ReportName",repName);
			BasePage.Redirect("ReportParameter.aspx");
		}

		public void OnToolbarButtonClick_Report(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if(this.ReadControls())
				Report.Redirect(reportParameters,reportName);
		}

		public bool ReadControls()
		{
			try
			{
				//Check Major and Sub Group Conditions
				if (this.Majorgrouprow.Visible && this.Subgrouprow.Visible) // both visible select one
				{
					if (Subsubgrouprow.Visible) // if sub-sub visible
					{
						if (MajorGroup.SelectedIndex == -1 && SubGroup.SelectedIndex == -1 && (SubSubGroup.SelectedIndex == -1 || SubSubGroup.DisplayValue == null))
							throw new ActiveAdviceException("@SELECTMAJORORSUBSUB@");
					}
					if (MajorGroup.SelectedIndex == -1 && SubGroup.SelectedIndex == -1 && !Subsubgrouprow.Visible)
						throw new ActiveAdviceException("@SELECTMAJORORSUB@");
					else if (MajorGroup.DisplayValue == SubGroup.DisplayValue && MajorGroup.DisplayValue != null && MajorGroup.DisplayValue != "")/*  && !Subsubgrouprow.Visible)*/
						throw new ActiveAdviceException("@SAMEMAJORSUB@");
				}
				// Check if Major and SubGroup are the same
				/*if (this.MajorGroup.DisplayValue == this.SubGroup.DisplayValue && this.MajorGroup.DisplayValue != null)
					throw new ActiveAdviceException("@SAMEMAJORSUN*/
				// Check if Sub and SubSub group are the same
				if ((this.Subgrouprow.Visible && this.Subsubgrouprow.Visible) && 
					(this.SubGroup.DisplayValue == this.SubSubGroup.DisplayValue && (SubGroup.DisplayValue != null && SubGroup.DisplayValue != "")))
					throw new ActiveAdviceException("@SAMESUBSUBSUB@");			
				// Check if Major and SubSub group are the same
				if ((this.Majorgrouprow.Visible && this.Subsubgrouprow.Visible) &&
					(this.MajorGroup.DisplayValue == this.SubSubGroup.DisplayValue && (MajorGroup.DisplayValue != null && MajorGroup.DisplayValue != "")))
					throw new ActiveAdviceException("@SAMEMAJORSUBSUB@");


				
				this.UpdateToObject(this.pnlParameters.Controls,this.reportParameters);
				reportParameters.SorgID = reportParameters.OrgID = reportParameters.MorgID;
				if(this.lbFromDate.Visible)
					reportParameters.DateType =1;
				return this.IsValid;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void PlanName_ValueChange(object sender, Infragistics.WebUI.WebDataInput.ValueChangeEventArgs e)
		{
		
		}
	}
}
