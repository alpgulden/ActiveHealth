using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.BaseClassesInterfaces;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.IMPORT_EXPORT_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("Provider")]
	public class ImportProviderForm : ImportExportBasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProvider;
		protected NetsoftUSA.WebForms.OBLabel OblblProvider;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFileName;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Webtextedit1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator1;
		protected NetsoftUSA.WebForms.OBFieldLabel lblLabel;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Label;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLabel;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected CommonDialog CommDlg;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				TaskArguments ta = new TaskArguments();
				this.UpdateFromObject(pnlProvider.Controls, ta, false);
			}
			else
			{
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("ImportProviderForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}


		public void OnToolbarButtonClick_Update(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@PROVIDER@");
			}
		}

		protected bool SaveData()
		{
			TaskArguments ta = new TaskArguments();
			this.UpdateToObject(pnlProvider.Controls, ta, true);
			ta.FileName = CommDlg.FileName;
			if (ValidateArguments(ta, true) ) // test if "filename" is really a folder name
			{
				// We can write this task out...
				ScheduleTask st		= new ScheduleTask();
				ScheduleTypeCollection types = ScheduleTask.ActiveScheduleTypes;
				st.ScheduleTypeID	= types.IndexBy_Code.LookupIntMember("ScheduleTypeID", "PROV");	// ELIGIBILITY
				ScheduleStatusCollection statuses = ScheduleTask.ActiveScheduleStatuses;
				st.ScheduleStatusID = statuses.IndexBy_Code.LookupIntMember("ScheduleStatusID", "PEND");	// PENDING

				st.Task				= ta.Task;	// create our "task" string
				st.Label			= ta.Label;	// label to attached to the scheduled item...
				st.CreatedBy		= this.CurrentUser;
				st.CreateTime		= DateTime.Now;
				st.ScheduledTime	= DateTime.Now;

				// Insert the record into the table...
				st.Insert();
				return true;
			}

			return false;
		}
		
		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			ToolbarButtonExtraProperties tbep = toolbar.AddButton("@SAVE@", "Update");
			tbep.ChecksForIsDirty = false;
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		/* Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMORGSearch();
		}
		*/
	}
}
