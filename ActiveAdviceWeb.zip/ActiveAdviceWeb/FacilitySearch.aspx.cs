using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Text;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.FacilityMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Facility,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MProviderFacility")]
	[SelectedMenuItem("Facilities")]
	[PageTitle("@FACILITYSEARCHTITLE@")]
	public class FacilitySearch : ProviderBasePage
	{
		private int startFacilityId = 0;
		private string startName = "";

		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearchName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResults;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected System.Web.UI.WebControls.RadioButtonList rdSearchBy;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit GroupPracticeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCity;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit City;
		protected NetsoftUSA.WebForms.OBFieldLabel lbState;
		protected NetsoftUSA.WebForms.OBFieldLabel lbZip;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit Zip;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCounty;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit County;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GroupPracticeServiceTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GroupPracticeFocusTypeID;
		protected System.Web.UI.HtmlControls.HtmlTable tblName;
		protected System.Web.UI.HtmlControls.HtmlTable tblIDs;
		protected System.Web.UI.HtmlControls.HtmlTable tblIDs2;
		protected System.Web.UI.HtmlControls.HtmlTable tblGroupPracticeType;
		protected System.Web.UI.HtmlControls.HtmlTable tblID1;
		protected System.Web.UI.HtmlControls.HtmlTable tblID2;
		protected System.Web.UI.HtmlControls.HtmlTable tblID3;
		protected System.Web.UI.HtmlControls.HtmlTable tblAddress;
		//protected System.Web.UI.HtmlControls.HtmlTable tblDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFacilityID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit FacilityID;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacility;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit UPIN;
		protected NetsoftUSA.WebForms.OBFieldLabel lbUPIN;
		protected NetsoftUSA.WebForms.OBLabel lbNetwork;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityNetworkTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityLocationNetworkID;
		
		protected NetsoftUSA.WebForms.OBLabel lbFacilityFocusID;
		protected NetsoftUSA.WebForms.OBValidator vldFacilityLocationServiceTypeID;
		protected NetsoftUSA.WebForms.OBComboBox FacilityLocationServiceTypeID;
		protected NetsoftUSA.WebForms.OBLabel lbFacilityLocationServiceTypeID;
		//protected NetsoftUSA.WebForms.OBValidator vldEffectiveDate;
		//protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		//protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFacilityTypeID;
		protected NetsoftUSA.WebForms.OBValidator vldFacilityTypeID;
		protected NetsoftUSA.WebForms.OBComboBox FacilityTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private NetworkPlanLink searchNetworkPlanLink;
		private FacilityLocationNetworkLink searchFacilityNetworkLink;
		private Location facilityLocationSearch;
		private FacilityLocationCollection locationSearchResults;
		private FacilityCollection facilitySearchResults;
		//private FAcLanguage searchLanguage;
		private FacilityLocationService searchFacilityLocationService;
		private FacilityFocus searchFacilityFocus; 
		private FacilityFocusCollection facilityFocusResults;
		private Facility searchFacilityInfo;
		private FacilityCollection searchFacilityResults;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkInfo;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacilityType;
		protected System.Web.UI.HtmlControls.HtmlTable tblFocus;
		protected System.Web.UI.HtmlControls.HtmlTable tblServices;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldState;
		protected NetsoftUSA.WebForms.OBComboBox State;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityFocusTypeID;
		protected NetsoftUSA.WebForms.OBComboBox FacilityFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo NetworkSearchID;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSearchName;
		protected NetsoftUSA.InfragisticsWeb.WebGrid GridFacilities;	
		protected NetsoftUSA.InfragisticsWeb.WebGrid GridNetworks;
		private Address searchFacilityAddress;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResults2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNetworks;
		protected NetsoftUSA.InfragisticsWeb.WebGrid GridFacilityLocations;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
		protected System.Web.UI.WebControls.RadioButtonList lstNetworkSearch;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FederalTaxID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMedicareID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MedicareID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnFacilityID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnFacilityName;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnLocationID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnLocationDescription;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnTypeID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnTypeDescription;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkDescription;
		private   int  selectWidth = 65;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnPhone; 
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatus;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatusDescriptionIn;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNetworkStatusDescriptionOut;
		protected NetsoftUSA.WebForms.OBLabel Oblabel12;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNetwokSearchID;
		protected NetsoftUSA.WebForms.OBComboBox NetwokSearchID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnFlag;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchNameNext;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnPrevious;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		private PatientCoverage patCov;

		// The page start stack is implemented diferently from patient/subsriber search pages.
		// We keep the pageSartStack in the session directly and set it to the grid each time
		// the page is created.
		private ArrayList pageStartStack;	// page start stack for this page

		public ArrayList PageStartStack
		{
			get
			{
				if (pageStartStack == null)
				{
					string key = "FacilitySearchPageStartStack";
					pageStartStack = (ArrayList)this.LoadObject(key);
					if (pageStartStack == null)
					{
						pageStartStack = new ArrayList();
						this.CacheObject(key, pageStartStack);
					}
				}
				return pageStartStack;
			}
		}

		public override void NavigateAway(string targetURL)
		{
			// Push the current start page before navigating away, so that we know where to start from when returned.
			GridFacilities.PushValuesForPageStart();	// push the page start values for this page.
			
			// since there's no single search object, we save these into the session directly.
			this.CacheObject("rdSearchBy", rdSearchBy.SelectedValue);
			this.CacheObject("lstNetworkSearch", lstNetworkSearch.SelectedValue);
			base.NavigateAway ();
		}

		public void LoadSearcherFromCache()
		{
			searchFacilityInfo = (Facility)this.LoadObject("BasicInfo");  // load object from cache
			searchFacilityAddress = (Address)this.LoadObject("AddressInfo");  // load object from cache
			searchFacilityFocus = (FacilityFocus)this.LoadObject("FocusInfo");  // load object from cache
			patCov = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
			searchFacilityLocationService  = (FacilityLocationService)this.LoadObject("ServiceInfo");  // load object from cache
			facilitySearchResults     = (FacilityCollection)this.LoadObject("FacilitySearchResults");  // load object from cache
			locationSearchResults     = (FacilityLocationCollection)this.LoadObject("LocationSearchResults");  // load object from cache
			facilityLocationSearch    = (Location)this.LoadObject("objFacilityLocationSearch");  // load object from cache
			searchFacilityNetworkLink = (FacilityLocationNetworkLink)this.LoadObject("NetworkInfo");  // load object from cache
			searchNetworkPlanLink     = (NetworkPlanLink)this.LoadObject(typeof(NetworkPlanLink));  // load object from cache
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			GridFacilities.PageStartStack = this.PageStartStack;	// Let the new instance know about the common page start stack instance

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				TranslateNames();				
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				LoadSearcherFromCache();
			}
			
			if (this.HasCallbackFunction)
			{
				if (Request.QueryString["Flag"] == "1")
					hdnFlag.Value = "1";
				else
					hdnFlag.Value = "0";
			}

			CheckNetworkStatus();
		}
		
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			if(!this.IsClientScriptBlockRegistered("formLoad"))
			{
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){}\n");
				s.Append("function getGridVals1(){}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
			}
		}

		private void TranslateNames()
		{
			this.rdSearchBy.Items[0].Text = this.Language.TranslateSingle("NAME");
			this.rdSearchBy.Items[1].Text = this.Language.TranslateSingle("ID");
			this.lstNetworkSearch.Items[0].Text = this.Language.TranslateSingle("ALLNETWORKS");
			this.lstNetworkSearch.Items[1].Text = this.Language.TranslateSingle("SPECIFIEDNETWORK");
		}

		private void BindForm()
		{
			//this.UpdateFromObject(this.pnlSearchName.Controls, this.searchProviderInfo);
			this.UpdateFromObject(this.tblName.Controls, this.searchFacilityInfo);
			//this.UpdateFromObject(this.tblFacility.Controls, this.);
			this.UpdateFromObject(this.tblAddress.Controls, this.searchFacilityAddress);

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			GridFacilities.PagingColumns = new string[] { "PKInt", "Name" };
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.rdSearchBy.SelectedIndexChanged += new System.EventHandler(this.rdSearchBy_SelectedIndexChanged);
			this.lstNetworkSearch.SelectedIndexChanged += new System.EventHandler(this.lstNetworkSearch_SelectedIndexChanged);
			this.btnSearchName.Click += new System.EventHandler(this.btnSearchName_Click);
			this.GridFacilities.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.GridFacilities_ClickCellButton);
			this.GridFacilities.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.GridFacilities_ColumnsBoundToDataClass);
			this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
			this.butSearchNameNext.Click += new System.EventHandler(this.butSearchNameNext_Click);
			this.GridFacilityLocations.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.GridFacilityLocations_ClickCellButton);
			this.GridFacilityLocations.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.GridFacilityLocations_RowBoundToDataObject);
			this.GridFacilityLocations.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.GridFacilityLocations_ColumnsBoundToDataClass);
			this.GridNetworks.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.GridNetworks_RowBoundToDataObject);
			this.GridNetworks.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.GridNetworks_ColumnsBoundToDataClass);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		

		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FacilityCollection FacilitySearchResults
		{
			get { return facilitySearchResults ; }
			set
			{
				facilitySearchResults = value;
				try
				{
					this.GridFacilities.KeepCollectionIndices = false;
					this.GridFacilities.UpdateFromCollection(facilitySearchResults);
					this.pnlResults.Visible				= true;			

					// If there are results then show the first result's Locations
					if (this.facilitySearchResults.Count > 0)
					{
						butSearchNameNext.Enabled = facilitySearchResults.Count >= FacilityCollection.MAXRECORDS;
						btnPrevious.Enabled = GridFacilities.HasAnyPreviousPages;

						this.GridFacilities.SelectedRowIndex = 0;
						this.BindFacilityLocations((int)GridFacilities.SelectedRowPK[0]);
					}	
					else
					{
						pnlResults2.Visible =false;
					}

					butSearchNameNext.Enabled = facilitySearchResults.Count >= FacilityCollection.MAXRECORDS;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject("ProviderSearchResults", providerSearchResults);  // cache object using the caching method declared on the page
			}
		}
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Location FacilityLocationSearch
		{
			get { return facilityLocationSearch ; }
			set
			{
				facilityLocationSearch = value;
				try
				{
					this.UpdateFromObject(this.tblIDs2.Controls, facilityLocationSearch);  // update controls for the given control collection
				
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("objFacilityLocationSearch", facilityLocationSearch);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForFacilityLocationSearch()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.tblIDs2.Controls, facilityLocationSearch);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}
			

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FacilityLocationCollection LocationSearchResults
		{
			get { return locationSearchResults; }
			set
			{
				locationSearchResults = value;
				try
				{
					this.GridFacilityLocations.KeepCollectionIndices = false;
					this.GridFacilityLocations.UpdateFromCollection(locationSearchResults);
					if (this.GridFacilityLocations.Rows.Count > 0)
						GridFacilityLocations.SelectedRowIndex = 0;
					
					GridFacilityLocations.Visible = true;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("LocationSearchResults", locationSearchResults);  // cache object using the caching method declared on the page
			}
		}



		private void BindFacilityLocations(int facilityID)
		{
			#region Obsolete
			/*
			 * Replaced by GetFacilityLocationsWithNetworkFilter(bool filterByNetwork, int facilityID) call.
			 * 
			 * FacilityLocationCollection facLocCol = new FacilityLocationCollection();
			if (lstNetworkSearch.SelectedIndex == 1) // if selected Network
				facLocCol.LoadLocationsWithFilter(this.SearchFacilityNetworkLink.NetworkID,providerID,this.searchFacilityAddress, this.SearchFacilityNetworkLink.FilterPlanID,  this.SearchFacilityNetworkLink.EffectiveDate);
			else
				facLocCol.LoadLocationsWithFilter(providerID,this.searchFacilityAddress);
				
			*/
			#endregion

			this.LocationSearchResults = this.GetFacilityLocationsWithNetworkFilter(lstNetworkSearch.SelectedIndex == 1, facilityID);//facLocCol;
			this.pnlResults2.Visible   = true;
		}

		/// <summary>
		///  Returns FacilityLocationCollection filtered by network information supplied on the page.
		/// </summary>
		/// <param name="filterByNetwork">indicates whether to filter by network information or not</param>
		/// <param name="facilityID">Facility for which locations will be filtered.</param>
		/// <returns></returns>
		private FacilityLocationCollection GetFacilityLocationsWithNetworkFilter(bool filterByNetwork, int facilityID)
		{
			FacilityLocationCollection facLocCol = new FacilityLocationCollection();
			if (filterByNetwork)
				facLocCol.LoadLocationsWithFilter(this.SearchFacilityNetworkLink.NetworkID,facilityID,this.searchFacilityAddress, this.SearchFacilityNetworkLink.FilterPlanID,  this.SearchFacilityNetworkLink.EffectiveDate);
			else
				facLocCol.LoadLocationsWithFilter(facilityID,this.searchFacilityAddress);
			return facLocCol;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Address SearchFacilityAddress
		{
			get { return searchFacilityAddress; }
			set
			{
				searchFacilityAddress  = value;
				try
				{
					this.UpdateFromObject(this.tblAddress.Controls, searchFacilityAddress);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("AddressInfo", searchFacilityAddress);  // cache object using the caching method declared on the page
			}
		}
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Facility  SearchFacilityInfo
		{
			get { return searchFacilityInfo; }
			set
			{
				searchFacilityInfo = value;
				try
				{
					this.UpdateFromObject(this.tblName.Controls, searchFacilityInfo);  // update controls for the given control collection
					this.UpdateFromObject(this.tblFacilityType.Controls,searchFacilityInfo);
					this.UpdateFromObject(this.tblIDs.Controls, searchFacilityInfo);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("BasicInfo", searchFacilityInfo);  // cache object using the caching method declared on the page
			}
		}

		private void BindNetworkDropDown()
		{
			
			if (lstNetworkSearch.SelectedValue != "0" && this.patCov != null)
			{
				this.searchFacilityNetworkLink.FilterPlanID = this.patCov.PlanID;
				this.searchFacilityNetworkLink.NetwokSearchID = 0;
			}
			if (!this.IsPostBack)
			{
				this.UpdateFromObject(this.tblNetworkInfo.Controls, searchFacilityNetworkLink);
			}
		}
	
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FacilityLocationNetworkLink SearchFacilityNetworkLink
		{
			get { return searchFacilityNetworkLink; }
			set
			{
				searchFacilityNetworkLink = value;
				try
				{
					BindNetworkDropDown();// update controls for the given control collection
					this.UpdateFromObject(this.tblIDs.Controls, searchFacilityInfo);  // update controls for the given control collection
					// other object-to-control methods if any

					
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("NetworkInfo", searchFacilityNetworkLink);  // cache object using the caching method declared on the page
			}
		}
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FacilityLocationService SearchFacilityLocationServiceType
		{
			get { return searchFacilityLocationService; }
			set
			{
				searchFacilityLocationService = value;
				try
				{
					this.UpdateFromObject(this.tblServices.Controls, searchFacilityLocationService);  // update controls for the given control collection
					this.UpdateFromObject(this.tblIDs.Controls, searchFacilityInfo);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("ServiceInfo", searchFacilityLocationService);  // cache object using the caching method declared on the page
			}
		}
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FacilityFocus SearchFacilityFocus
		{
			get { return searchFacilityFocus; }
			set
			{
				searchFacilityFocus = value;
				try
				{
					this.UpdateFromObject(this.tblFocus.Controls, searchFacilityFocus);  // update controls for the given control collection
					this.UpdateFromObject(this.tblIDs.Controls, searchFacilityInfo);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("FocusInfo", searchFacilityFocus);  // cache object using the caching method declared on the page
			}
		}



		private void LoadData()
		{
			bool ignoreAddress = false;
			bool ignoreNetwork = false;
			
			this.pnlResults.Visible = false;
			this.pnlResults2.Visible = false;
			this.pnlNetworks.Visible = false;

			if (this.WasCancelled)		// If cancelled, re-use the existing context
				this.LoadSearcherFromCache();
			else
				this.ClearProviderContext();

			if (this.HasCallbackFunction )
			{
				patCov = this.GetParamOrGetFromCache("PatCov", typeof(PatientCoverage)) as PatientCoverage ;
				// Address Info -- Now using Address from paitent coverage Obsoloete !!!

					
				// Patient Coverage Info
				if (patCov != null) // For searches within pages w/ no Patient context
				{
					// -- Get the address of current patient and set search state to it.
					Address addr = new Address();
					addr.State = patCov.Patient.Address.State;
					this.SearchFacilityAddress = addr;
					ignoreAddress = true;
					// --- End of address ---
					

					// Network Info
					if (patCov.PlanID != 0)
					{
						NetworkPlanLink networkPlanLink = new  NetworkPlanLink();
						FacilityLocationNetworkLink facNetLink = new FacilityLocationNetworkLink();
						
						this.searchFacilityNetworkLink = facNetLink;															
						if (patCov.PlanID != 0)
							networkPlanLink.PlanId = patCov.PlanID;
						
						if (Request.QueryString["StartDate"] != null && Request.QueryString["StartDate"] != "")
						{
							networkPlanLink.StartDate						= DateTime.Parse(Request.QueryString["StartDate"].ToString());
							this.searchFacilityNetworkLink.EffectiveDate	= networkPlanLink.StartDate;
						}
						facNetLink.NetwokSearchID			= patCov.GetPlanRelatedNetworkID();
						
						this.lstNetworkSearch.SelectedIndex = (facNetLink.NetwokSearchID == 0) ? 0 : 1;
						if (facNetLink.NetwokSearchID == 0)
							ignoreNetwork = true;
						if (lstNetworkSearch.SelectedIndex == 1)
							ignoreNetwork = true;

						this.SearchFacilityNetworkLink		= this.searchFacilityNetworkLink;					
						this.SearchNetworkPlanLink			= networkPlanLink;
						
					}
				}	
			}
			
		/*	if (this.WasCancelled)		// If cancelled, re-use the existing context
			{
				// refresh
				this.SearchFacilityAddress = this.SearchFacilityAddress;
				this.SearchFacilityInfo = this.SearchFacilityInfo;
				this.SearchFacilityFocus = this.SearchFacilityFocus;
				this.FacilityLocationSearch = this.FacilityLocationSearch;
				this.SearchFacilityNetworkLink = this.SearchFacilityNetworkLink;
				this.SearchFacilityLocationServiceType = this.SearchFacilityLocationServiceType;
				this.SearchNetworkPlanLink = this.SearchNetworkPlanLink;

				rdSearchBy.SelectedValue = (string)this.LoadObject("rdSearchBy");
				lstNetworkSearch.SelectedValue = (string)this.LoadObject("lstNetworkSearch");
				this.SearchNext(false);		// go to previous page (the current page before navigation)
			}
			else
			{*/
				NewSearch(ignoreAddress, ignoreNetwork);
				this.SetSearchFormVisibility(0);	// Search By Name enabled by default
			//}
		}
		// Tab toolbar

		private void NewSearch()
		{
			//this.NewSearchLanguage();
			this.NewSearchFacilityAddress();
			this.NewSearchFacilityInfo();
//			this.NewSearchProviderService();
//			this.NewSearchSpecialty();
			this.NewFacilityFocusSearch();
			this.NewFacilityLocationSearch();
			this.NewFacilityNetworkSearch();
			this.NewSearchFacilityLocationServiceType();

			this.SearchNetworkPlanLink = new NetworkPlanLink();
		}

		private void NewSearch(bool ignoreAddress, bool ignoreNetwork)
		{
			this.NewFacilityFocusSearch();
			this.NewFacilityLocationSearch();
			this.NewSearchFacilityInfo();
			this.NewSearchFacilityLocationServiceType();
			if (!ignoreNetwork)
				this.NewFacilityNetworkSearch();
			if (!ignoreAddress)
				this.NewSearchFacilityAddress();
		}
		
		
	
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public NetworkPlanLink SearchNetworkPlanLink
		{
			get { return searchNetworkPlanLink; }
			set
			{
				searchNetworkPlanLink = value;
				try
				{
					//this.UpdateFromObject(this.Controls, searchNetworkPlanLink);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(NetworkPlanLink), searchNetworkPlanLink);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewFacilityLocationSearch()
		{
			bool result = true;
			Location facilityLocationSearch = new Location(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				facilityLocationSearch.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.FacilityLocationSearch = facilityLocationSearch;
			return result;
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchFacilityAddress()
		{
			bool result = true;
			Address searchFacilityAddress = new Address(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchFacilityAddress.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchFacilityAddress = searchFacilityAddress;
			return result;
		}
		
		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearchFacilityLocationServiceType()
		{
			bool result = true;
			FacilityLocationService searchFacilityLocationServiceType = new FacilityLocationService(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchFacilityLocationServiceType.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchFacilityLocationServiceType = searchFacilityLocationServiceType;
			return result;
		}

		public bool NewSearchFacilityInfo()
		{
			bool result = true;
			Facility searchFacilityInfo = new Facility(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchFacilityInfo.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchFacilityInfo = searchFacilityInfo;
			return result;
		}
		
		public bool NewFacilityNetworkSearch()
		{
			bool result = true;
			FacilityLocationNetworkLink searchNetworkLinkInfo = new FacilityLocationNetworkLink(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchNetworkLinkInfo.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchFacilityNetworkLink = searchNetworkLinkInfo;
			return result;
		}
		
		public bool NewFacilityFocusSearch()
		{
			bool result = true;
			FacilityFocus searchFacilityFocus = new FacilityFocus(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				searchFacilityFocus.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.SearchFacilityFocus = searchFacilityFocus;
			return result;
		}


		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("@NEWSEARCH@", "NewSearch");
			toolbar.AddButton("@ADDNEWRECORD@", "AddNew");
			
		}
		
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewSearch ();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{

			// add new 
			FacilityForm.Redirect(0);
		}
		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			Redirect("FacilitySearch.aspx");
		}

		private void grid_InitializeLayout(object sender, Infragistics.WebUI.UltraWebGrid.LayoutEventArgs e)
		{
		
		}

		private void FacilityFocusTypeID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
		
		}
		/// <summary>
		///	Sets the visibility status for all controls
		/// </summary>
		
		private void SetSearchFormVisibility(int selectedIndex)
		{
			switch (selectedIndex)
			{
				default:
				case 0:
					this.tblIDs.Visible				= this.tblIDs2.Visible			= false;
					this.tblName.Visible			= true;
					this.tblAddress.Visible			= true;
					tblFacilityType.Visible			= true;
					this.tblNetworkInfo.Visible		= true;
					this.tblServices.Visible		= true; 
					this.tblFocus.Visible			= true;
					//this.tblDate.Visible = true;
					ClearSearchFields();
					break;
				case 1:
					ClearSearchFields();
					this.tblIDs.Visible 			= this.tblIDs2.Visible  = true;
					this.tblAddress.Visible			= false;					
					this.tblName.Visible			= false;
					this.tblNetworkInfo.Visible		= false;
					this.tblServices.Visible		= false;
					this.tblFocus.Visible			= false;
					this.tblFacilityType.Visible	= false;
					//this.tblDate.Visible			= false;
					break;
			}
		}

		private void ClearSearchFields()
		{
			NewSearch(true,true);
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			//toolbar.AddButton("@CANCEL@", "Cancel");
		}

		public NetsoftUSA.WebForms.OBLabel LbFacilityFocusID
		{
			get { return this.lbFacilityFocusID; }
			set { this.lbFacilityFocusID = value; }
		}

		public NetsoftUSA.InfragisticsWeb.WebCombo Prop_GroupPracticeServiceTypeID
		{
			get { return this.GroupPracticeServiceTypeID; }
			set { this.GroupPracticeServiceTypeID = value; }
		}

		private void GridFacilities_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			this.GridFacilities.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;			
			if (this.HasCallbackFunction) // if in pop-up mode
			{
				if (Request.QueryString["Flag"] != "1")
					GridFacilities.AddButtonColumn("Pick","@PICK@",1).Width=45;
			}
		}

		
		private void GridFacilities_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				// update selected index
				this.GridFacilities.SelectedRowIndex = e.Cell.Row.Index;
				SelectFacility((int)GridFacilities.SelectedRowPK[0]);
			}
			else if(e.Cell.Key == "Pick")
			{
				Facility facility = new Facility();
				FacilityLocation facLoc = null;
				object[] pk = this.GridFacilities.GetPKFromCellEvent(e);

				facility.Load((int)pk[0]);
				facility.LoadLocations(false);
				if((facility.Locations.Count != 0)&&(facility.Locations[0] !=null))
					facility.Locations[0].LoadNetworks(false);
				
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				s.Append("function formLoad(){\n");
				s.Append("window.opener.");
				s.Append(this.CallbackFunction);
				s.Append("(getGridVals1());\nwindow.close();\nreturn false;\n}\n");
				s.Append("\n function getGridVals1(){\n");
				s.Append("var o = new Object();\n");
				s.Append("o.FacilityID = \"");
				s.Append(facility.FacilityID.ToString());
				s.Append("\";\n o.FacilityName =\"");
				s.Append(facility.Name);


				hdnTypeID.Value = facility.FacilityTypeID.ToString();
					s.Append("\";\n o.TypeID = \"");
					s.Append(facility.FacilityTypeID.ToString());
				hdnTypeDescription.Value = facility.FacilityType;
					s.Append("\";\n o.TypeDescription = \"");
					s.Append(facility.FacilityType);

				s.Append("\";\n o.Flag =\"0");
				

				if((facility.Locations.Count != 0)&&(facility.Locations[0] !=null))
				{
					string startDate;

					if (Request.QueryString["StartDate"]=="")
					{
						startDate = Convert.ToString(DateTime.Now);
					}
					else
						startDate = Request.QueryString["StartDate"];
				

					int status = 0;


					if (this.GridFacilityLocations.SelectedRowIndex > 0)
					{
						facLoc = new FacilityLocation();
						facLoc.Load(this.GridFacilityLocations.SelectedRowPKInt);
						if (facility.FacilityID != facLoc.FacilityID)
							facLoc = facility.Locations[0];
					}
					else // If no location is selected, or location is for wrong facility, load facility locations that match given criteria, then select the first one
					{
						FacilityLocationCollection facLocCol = this.GetFacilityLocationsWithNetworkFilter(this.lstNetworkSearch.SelectedIndex == 1, facility.FacilityID);
						if (facLocCol != null && facLocCol.Count > 0)
							facLoc = facLocCol[0];
						else
							facLoc = facility.Locations[0];
					}

					if(patCov !=null)
					{		
						
						status  = (int)facLoc.GetStatusForFacilityLocationNetworks (patCov.PlanID, Convert.ToDateTime(startDate),facLoc.LocationID);
						if (patCov.GetPlanRelatedNetworkID() == 0) // Patient Coverage has no networks.
							s.Append("\";\n o.PatCov = \"0");
						else 
							s.Append("\";\n o.PatCov = \"1");
					}
					else
					{
						// -- Patient Coverage is null so automatic no networks.
						s.Append("\";\n o.PatCov = \"0");
						status = 0;
					}
					s.Append("\";\n o.LocationID = \"");
					s.Append(facLoc.LocationID.ToString());
					s.Append("\";\n o.LocationDescription = \"");					
					s.Append(facLoc.ServiceLocation);
					s.Append("\";\n o.PhoneNo	= \"");
					s.Append(facLoc.Phone);
					s.Append("\";\no.NetworkStatus	=  \"");
					s.Append(status.ToString());
					
					s.Append("\";\no.NetworkStatusDesc	=  \"");
					if(status == 1)
						s.Append("In");
					else if(status == 0)
						s.Append("Out");
					s.Append("\";\n o.ResourceContactName	=  \"");					
					s.Append(Contact.GetLatestContactNameByFacilityLocationId(facLoc.FacilityLocationID));

					if (facLoc.Networks == null)
						facLoc.LoadNetworks(false);

					if((facLoc.Networks.Count !=0) && (facLoc.Networks[0] != null))
					{
						s.Append("\";\n o.NetworkID = \"");
						s.Append(facLoc.Networks[0].NetworkID.ToString());
						s.Append("\";\n o.NetworkDescription = \"");

						s.Append(facLoc.Networks[0].Description);
					
					}
					else
					{
						s.Append("\";\n o.NetworkID = \"");
						s.Append("\";\n o.NetworkDescription = \"");
					}
					
				}
				else
				{
					
					s.Append("\";\n o.LocationDescription = \"");
				
					s.Append("\";\n o.PhoneNo	= \"");
					
					s.Append("\";\no.NetworkStatus	= \"");
					s.Append("\";\no.NetworkStatusDesc	=  \"");
					s.Append("\";\no.ResourceContactName	=  \"");
					s.Append("\";\n o.NetworkID = \"");
					s.Append("\";\n o.NetworkDescription = \"");
				}
				
				
				s.Append("\";\n return o;}\n");
				s.Append("</SCRIPT>\n");
				this.RegisterClientScriptBlock("formLoad",  s.ToString());
			}
		}

		private void GridFacilityLocations_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = GridFacilityLocations.GetPKFromCellEvent(e);

			if (this.HasCallbackFunction) // pop-up mode
			{
				FacilityLocation facloc = new FacilityLocation ();
				
				facloc.Load((int)pk[0]);
				//providerloc.Load((int)gridProviderLocations.SelectedRowPK[0]);
				facloc.LoadNetworks(false);
				
				hdnLocationID.Value = facloc.LocationID.ToString();
				hdnLocationDescription.Value = facloc.ServiceLocation.ToString();
				
				Facility fac= new Facility();
				fac.Load(facloc.FacilityID);
				hdnFacilityID.Value = facloc.FacilityID.ToString();
				hdnFacilityName.Value = fac.Name;
				hdnPhone.Value = facloc.Phone;	
				
				string startDate;

				if (Request.QueryString["StartDate"]=="")
				{
					startDate = Convert.ToString(DateTime.Now);
				}
				else
					startDate = Request.QueryString["StartDate"];
				

				int status = 0;
				int patCovStatus = 0;
				if(patCov !=null)
				{
					status  = (int)facloc.GetStatusForFacilityLocationNetworks (patCov.PlanID, Convert.ToDateTime(startDate),facloc.LocationID);
					patCovStatus = patCov.GetPlanRelatedNetworkID(); //Does  Patient Coverage have networks?
				}
				else
				{					
					status = 0;
				}
				hdnNetworkStatus.Value = status.ToString();

				if(e.Cell.Key == "SelectLocation")
					BindNetworkSpecialties((int)pk[0]);
				else
				{
					facloc.LoadNetworks(false);
				
					StringBuilder s = new StringBuilder();
					s.Append("<SCRIPT>\n");
					s.Append("function formLoad(){\n");
					s.Append("window.opener.");
					s.Append(this.CallbackFunction);
					s.Append("(getGridVals1());\nwindow.close();\nreturn false;\n}\n");
					s.Append("\n function getGridVals1(){\n");
					s.Append("var o = new Object();\n");
					s.Append("o.FacilityID = \"");
					s.Append(fac.FacilityID.ToString());
					s.Append("\";\n o.PatCov = \"");
					s.Append(patCovStatus.ToString());
					s.Append("\";\n o.FacilityName =\"");
					s.Append(fac.Name);

					s.Append("\";\n o.TypeID = \"");
					s.Append(fac.FacilityTypeID.ToString());
				
					s.Append("\";\n o.TypeDescription = \"");
					s.Append(fac.FacilityType);

					s.Append("\";\n o.Flag =\"0");
					s.Append("\";\n o.LocationID = \"");
					s.Append(facloc.LocationID.ToString());
					s.Append("\";\n o.LocationDescription = \"");
					s.Append(facloc.ServiceLocation);
					s.Append("\";\n o.PhoneNo	= \"");
					s.Append(facloc.Phone);
					s.Append("\";\no.NetworkStatus	=  \"");
					s.Append(status.ToString());	
					s.Append("\";\no.NetworkStatusDesc	=  \"");
					if(status == 1)
						s.Append("In");
					else if(status == 0)
						s.Append("Out");
					if((facloc.Networks.Count !=0) && (facloc.Networks[0] != null))
					{
						s.Append("\";\n o.NetworkID = \"");
						s.Append(facloc.Networks[0].NetworkID.ToString());
						s.Append("\";\n o.NetworkDescription = \"");
						s.Append(facloc.Networks[0].Description);
				
					}
					else
					{
						s.Append("\";\n o.NetworkID = \"");
						s.Append("\";\n o.NetworkDescription = \"");
					}
					s.Append("\";\n return o;}\n");
					s.Append("</SCRIPT>\n");
					this.RegisterClientScriptBlock("formLoad",  s.ToString());
				}
			}
			else
			{
				if (e.Cell.Key == "Edit")
					SelectFacilityLocation((int)pk[0]); 
			}
		}
		
		private void GridFacilityLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction)
			{
				if (Request.QueryString["Flag"] == "1")
				{
					this.GridFacilityLocations.AddColumnWithButtonLook("Pick", "@PICK@", 0).Width = 45;
					this.GridFacilityLocations.ClickEventCommand = null;
				}
				else
				{
					this.GridFacilityLocations.AddButtonColumn("SelectLocation", "@SELECT@", 0).Width = selectWidth;
					this.GridFacilityLocations.ClickEventCommand = "SelectLocation";
					this.GridFacilityLocations.AddButtonColumn("Pick", "@PICK@", 1).Width = 45;
				}
			}
			else
			{
				this.GridFacilityLocations.AddButtonColumn("SelectLocation", "@SELECT@", 0).Width = selectWidth;
			}
		}
		
		private void GridNetworks_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (this.HasCallbackFunction) // if in pop-up mode
			{
				this.GridNetworks.AddColumnWithButtonLook("Pick","@PICK@",0);
			}
		}
		
		private void GridNetworks_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			if (cell != null)
			{
				FacilityLocationNetworkLink link = e.data as FacilityLocationNetworkLink ;
				if (this.searchNetworkPlanLink.PlanId == 0)
				{
					Infragistics.WebUI.UltraWebGrid.CellsCollection cells = this.GridFacilityLocations.DisplayLayout.ActiveRow.Cells;
					Infragistics.WebUI.UltraWebGrid.UltraGridCell activepCell = null;
					Infragistics.WebUI.UltraWebGrid.UltraGridCell activeplCell = null;

					for (int i = 0; i < cells.Count; i++)
					{
						if (cells[i].Key == "FacilityID")
							activepCell = cells[i];
						else if (cells[i].Key == "FacilityLocationID")
							activeplCell = cells[i];					
					}
					int facilityID = (int)activepCell.Value;
					int facilityLocID = (int)activeplCell.Value;
					Facility fac = new Facility();
					fac.Load(facilityID);
					FacilityLocation facilityloc = new FacilityLocation();
					facilityloc.Load(facilityLocID);

					//hdnNetworkID.Value = link.ProviderLocationNetworkID.ToString();
					//hdnNetworkDescription.Value = link.NetworkName.ToString();
 
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
					//e.row.Cells.FromKey("Pick").Text = GetCallbackFunctionHyperLink("Pick", facilityloc.FacilityID,fac.Name,facilityloc.LocationID,facilityloc.ServiceLocation,fac.FacilityTypeID,fac.FacilityType);
					//e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
				}
				else
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
			}			
		}


		private void GridFacilityLocations_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			if (Request.QueryString["Flag"] =="1")
			{
				try
				{
					UltraGridCell cell = e.row.Cells.FromKey("Pick");
				
					Facility gp = new Facility();
					gp.Load((int)GridFacilities.SelectedRowPK[0]);
						
					hdnFacilityID.Value = gp.FacilityID.ToString();
					hdnFacilityName.Value = gp.Name;
					hdnTypeID.Value = gp.TypeID.ToString();
					hdnTypeDescription.Value = gp.FacilityType;
			
					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
//			//UltraGridCell cell = e.row.Cells.FromKey("Pick");
//			if ( cell != null)
//			{
//				if (this.searchNetworkPlanLink.PlanId == 0)
//				{
//					FacilityLocation facilityloc = e.data as FacilityLocation;
//					Facility fac = new Facility();
//					fac.Load(facilityloc.FacilityID);
//					
//					//hdnLocationID.Value = providerloc.ProviderLocationID.ToString();
//					//hdnLocationDescription.Value = providerloc.ServiceLocation.ToString();
//					
//					//e.row.Cells.FromKey("Pick").Text = GetCallbackFunctionHyperLink("Pick", facilityloc.FacilityID,fac.Name,facilityloc.LocationID,facilityloc.ServiceLocation,fac.FacilityTypeID,fac.FacilityType);
//				}
//				else
//					e.row.Cells.FromKey("Pick").Text = GetPickAllScript("Pick");
//			}
		}

		private string GetPickAllScript(string linkCaption)
		{
			return "<a href='#' onclick=\"window.opener." + this.CallbackFunction + "(getGridVals());window.close();return false;\">" + Language.Translate(linkCaption) + "</a>";
		}

		/// <summary>
		/// Bind the Network for only pop-up mode
		/// </summary>
		/// <param name="facilityLocationID"></param>

		private void BindNetworkSpecialties(int facilityLocationID)
		{
			if (facilityLocationID != -1)
				this.pnlNetworks.Visible = true;

			// Load FacilityLocation / Facility
			FacilityLocation fl = new FacilityLocation();
			Facility f = new Facility();
			fl.Load(facilityLocationID);
			f.Load(fl.FacilityID);
			
			hdnFacilityID.Value = fl.FacilityID.ToString();
			hdnFacilityName.Value = f.Name;
			hdnTypeID.Value = f.FacilityTypeID.ToString();
			hdnTypeDescription.Value = f.FacilityType;
			hdnLocationID.Value = fl.LocationID.ToString() ;
			hdnLocationDescription.Value = fl.ServiceLocation.ToString();
			
			// Load Networks/
			fl.LoadNetworks(false);

			this.GridNetworks.UpdateFromCollection(fl.Networks);
			if (GridNetworks.Rows.Count > 0)
				GridNetworks.SelectedRowIndex = 0;
		}

		
		private void SelectFacilityLocation(int facilityLocationID)
		{
			if (facilityLocationID != -1)
			{
				FacilityLocation facLoc = new  FacilityLocation();
				facLoc.Load(facilityLocationID);
				FacilityForm.Redirect(facLoc.FacilityID);
			}
		}

		private void SelectFacility(int facilityID)
		{
			if (facilityID != -1)
			{
				try
				{
					Facility fac = new Facility();
					fac.Load(facilityID);


					hdnFacilityID.Value = facilityID.ToString();
					hdnFacilityName.Value = fac.Name;
					hdnTypeID.Value = fac.FacilityTypeID.ToString();
					hdnTypeDescription.Value = fac.FacilityType;
					

					BindFacilityLocations(facilityID);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void btnSearchName_Click(object sender, System.EventArgs e)
		{
			GridFacilities.ClearValuesForPageStart();
			ReadForm(this.rdSearchBy.SelectedIndex);
		}

		private void rdSearchBy_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			SetSearchFormVisibility(rdSearchBy.SelectedIndex);

		}
		private void ReadForm(int searchBy)
		{
			try
			{
				if (searchBy == 1)
				{
					this.UpdateToObject(this.tblIDs.Controls, this.searchFacilityInfo, false);
					this.ReadControlsForFacilityLocationSearch(); // get the federal tax id
				}
				else
				{
					// Read To Controls
					this.UpdateToObject(this.tblName.Controls, this.searchFacilityInfo, false); // basic info
					this.UpdateToObject(this.tblFacilityType.Controls, this.searchFacilityInfo, false);  // type info
					this.UpdateToObject(this.tblAddress.Controls, this.searchFacilityAddress, false);		// address
					this.UpdateToObject(this.tblServices.Controls,this.searchFacilityLocationService, false);	// services
					this.UpdateToObject(this.tblFocus.Controls, this.searchFacilityFocus, false);	// focus
					this.UpdateToObject(this.tblNetworkInfo.Controls,this.searchFacilityNetworkLink, false); // network
				}
				this.searchFacilityFocus.FacilityID = searchFacilityInfo.FacilityID;
				//if (this.SearchFacilityNetworkLink != null)
				//	this.SearchFacilityNetworkLink.FacilityLocationNetworkID = this.SearchFacilityNetworkLink.NetwokSearchID;
				// if in pop-up mode send planID
				if (this.HasCallbackFunction)
				{
					if (lstNetworkSearch.SelectedValue == "0")
					{
						this.searchNetworkPlanLink     = new NetworkPlanLink();
						this.searchFacilityNetworkLink = new FacilityLocationNetworkLink();
					}
					
					Search(this.searchFacilityInfo, this.searchFacilityAddress, this.SearchNetworkPlanLink, SearchFacilityNetworkLink, this.searchFacilityLocationService, this.searchFacilityFocus, this.facilityLocationSearch.FederalTaxID);
				}
				else
				{
					if (lstNetworkSearch.SelectedValue == "0") // search all networks
						SearchFacilityNetworkLink = new FacilityLocationNetworkLink();

					Search(this.searchFacilityInfo, this.searchFacilityAddress, this.SearchFacilityNetworkLink, this.searchFacilityLocationService,this.searchFacilityFocus, this.facilityLocationSearch.FederalTaxID);
				}
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}
			
		}

		private void Search(Facility facility,Address address,FacilityLocationNetworkLink network,FacilityLocationService service, FacilityFocus focus, string federaltaxid)
		{
			
			Search(facility, address, new NetworkPlanLink(), network, service, focus, federaltaxid);
			
		}


		private void Search(Facility facility,Address address, NetworkPlanLink netPlan, FacilityLocationService service, FacilityFocus focus, string federaltaxid)
		{
			Search(facility,address, netPlan, new FacilityLocationNetworkLink(),service,focus, federaltaxid);
			
		}

		private void Search(Facility facility, Address address, NetworkPlanLink netPlan, FacilityLocationNetworkLink facNetLink, FacilityLocationService service, FacilityFocus focus, string federaltaxid)
		{
			try
			{
				FacilityCollection facilityCol	= new FacilityCollection();
				facilityCol.SearchFacilities(startFacilityId, startName, facility, facNetLink, netPlan , focus, service,address, federaltaxid);
				this.FacilitySearchResults = facilityCol;
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		
		private void lstNetworkSearch_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			CheckNetworkStatus();			
		}
		
		private void CheckNetworkStatus()
		{
			if (lstNetworkSearch.SelectedValue == "0") // search all networks
			{
				lbNetwokSearchID.Enabled = false;
				NetwokSearchID.Enabled = false;
			}
			else
			{
				lbNetwokSearchID.Enabled = true;
				NetwokSearchID.Enabled = true;
			}
			BindNetworkDropDown();

		}

		private void butSearchNameNext_Click(object sender, System.EventArgs e)
		{
			SearchNext(true);
			/*if (GridFacilities.Rows.Count > 0)
			{
				startFacilityId = GridFacilities.GetPKIntFromRowIndex(GridFacilities.Rows.Count - 1); 
				startName = GridFacilities.Rows[GridFacilities.Rows.Count - 1].Cells.FromKey("Name").Text;
			}
			ReadForm(this.rdSearchBy.SelectedIndex);*/
		}

		private void btnPrevious_Click(object sender, System.EventArgs e)
		{
			SearchNext(false);
		}

		private bool SearchNext(bool nextPage)
		{
			bool result = true;
			if (nextPage)
				this.GridFacilities.PushValuesForPageStart();	// push the page start values for this page.
			try
			{
				
				object [] valuesForNextPageStart = GridFacilities.GetStartValuesForPrevOrNextPage(nextPage);
				if (valuesForNextPageStart == null)	// no more pages.
					return false;
				// use page start to load this set of records.
				startFacilityId = (int)valuesForNextPageStart[0];
				startName   = (string)valuesForNextPageStart[1];
				
				ReadForm(this.rdSearchBy.SelectedIndex);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patients.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
				
			}
			return result;

		}

	}
}
