using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using System.Diagnostics;
using System.Data.SqlTypes;
using Tx4oleLib;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterSearch.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseFaxQueue,DataLayer")]
	//public class FaxLogViewForm : BasePage
	public class FaxLogViewForm : Page
	{
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label LabelQueueID;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;


		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
			{
				if (this.Request.QueryString["Mode"] != "") 
					mode = this.Request.QueryString["Mode"];

				logName = this.Request.QueryString["PARAM1"];

				if (mode == "VIEWLOG")
				{
					this.LabelQueueID.Text = logName;
					this.Label1.Text =  "Log File:";
				}
				else
					return;

				LoadData();
			}
			else
			{
			}
		}

		private string queueID = "";
		private string mode = "VIEWLOG";
		private string logName = "";

		private static string faxDirName = ConfigHelper.GetConfigValue("FaxDirName");

		private void LoadData()
		{
			if (mode == "VIEWLOG")
			{
				StreamReader sr = new StreamReader(new FileStream(faxDirName + "\\" + logName,  FileMode.Open));
				string s = sr.ReadToEnd();
				this.TextBox1.Text = s;
				sr.Close();
			}
			/*
			else if (mode == "PREVIEW")
			{
				char[] token1 = {'.'};
				string[] s1 = logName.Split(token1);
				if (s1.Length < 2) return;

				strRFTFile = faxCoverDirName + s1[0] + ".rtf";

				TXLicenseManagerClass txLicenceManager = null;
				Tx4oleLib.TXTextControlClass tx = null;
				try
				{
					txLicenceManager = new TXLicenseManagerClass();
					tx = new TXTextControlClass();
					tx.EnableAutomationServer();
				
					long lRet = tx.Load(strRFTFile,0,5, false);
					tx.Save(strTempTXT,0,1,false);
					StreamReader sr = new StreamReader(new FileStream(strTempTXT,  FileMode.Open));
					string s = sr.ReadToEnd();
					this.TextBox1.Text = s;
					sr.Close();
					File.Delete(strTempTXT);
					
					this.TextBox1.Text = s;
				}
				catch(Exception ex)
				{
					this.TextBox1.Text = "";
					//this.RaisePageException(ex);  // notify the page about the error
				}
				finally
				{

					if (txLicenceManager != null)
					{
						Marshal.ReleaseComObject(txLicenceManager);
					}
					if (tx != null)
					{
						Marshal.ReleaseComObject(tx);
					}
				}
			}
			*/
		}

		
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

		}


		
			#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			//this.AutoScroll = true;
			//this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

	}
}
