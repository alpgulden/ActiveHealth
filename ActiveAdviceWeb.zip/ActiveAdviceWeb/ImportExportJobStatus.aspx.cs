using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.BaseClassesInterfaces;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	public class ImportExportJobStatus : BasePage // ImportExportBasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldJobID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit JobID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbJobID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLabel;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Label;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLabel;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCreatedBy;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit CreatedBy;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCreatedBy;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCreateTime;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CreateTime;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCreateTime;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStartTime;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartTime;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartTime;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEndTime;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndTime;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndTime;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlJobStatus;
		protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder ContentPlaceHolder1;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTotalRecordsProcessed;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit TotalRecordsProcessed;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTotalRecordsProcessed;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTotalErrorRecords;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit TotalErrorRecords;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTotalErrorRecords;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;

		private void Page_Load(object sender, System.EventArgs e)
		{
			this.pnlJobStatus.Visible	= false;
			this.PageTab.Visible		= false;
			return;
		}


		protected ScheduleTask st = null;
		protected ScheduleTask scheduleTask
		{
			get
			{
				if (null == st)
				{
					try
					{
						st = new ScheduleTask();
						int jobid = Convert.ToInt32(Request.QueryString["JobID"]);
						st.Load(jobid);
					}
					catch(Exception ex)
					{
						string msg = ex.Message;
						st = null;
					}
				}
				return st;
			}
		}
		protected ScheduleTaskStatus sts = null;
		protected ScheduleTaskStatus scheduleTaskStatus
		{
			get
			{
				if ( (null == sts) && (scheduleTask != null) )
				{
					ScheduleTaskStatusCollection stsc = new ScheduleTaskStatusCollection();
					stsc.LoadAllScheduleTaskStatusesByJobID(-1, scheduleTask.JobID);
					int i = stsc.Count - 1;
					if (stsc.Count > 0)
						sts = (ScheduleTaskStatus)stsc.GetAt(i);
				}
				return sts;
			}
		}

		protected ScheduleTypeCollection stc = null;
		protected ScheduleTypeCollection scheduleTypeCollection
		{
			get
			{
				if (null == stc)
				{
					stc = (ScheduleTypeCollection)this.LoadObject(typeof(ScheduleTypeCollection), false);
					if (null == stc) // not in the cache
					{
						stc = new ScheduleTypeCollection();
						stc.LoadScheduleTypeByActive(-1, true);
						CacheObject(typeof(ScheduleTypeCollection), stc);
					}
				}
				return stc;
			}
		}
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			// For rendering we want to make some "type" specific decisions, i.e. different data display for "Eligibility"
			// versus "Scoring Load"
			if ((scheduleTypeCollection != null) && (scheduleTaskStatus != null) )
			{
				ScheduleType type = scheduleTypeCollection.FindBy(scheduleTask.ScheduleTypeID);
				scheduleTaskStatus.scheduleType	= (type == null ? null : type.Code);

			}
			if (scheduleTask != null)
			{
				Uri url = Request.Url;
				scheduleTask.URLformat = "<a href=\"http://" + url.Host + Request.ApplicationPath + "/Logs/{0}\">{1} [{2} bytes]</a>";
			}
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(scheduleTask, scheduleTaskStatus);
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("ImportExportJobStatus.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@CLOSE@", "Close", true).Item.TargetURL = "javascript:window.close()";
		}


	}
}
