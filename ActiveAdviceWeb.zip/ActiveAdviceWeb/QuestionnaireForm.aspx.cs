using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Questionnaire,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
    [BackPage(typeof(QuestionnaireSearch))]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("QR")]
	[PageTitle("@QRPAGETITLE@")]
	public class QuestionnaireForm : AssessmentMaintenanceBasePage
	{
		private QuestionnaireLetterMatrixCollection questionnaireLetterMatrixes;
		private QuestionnaireTrigger questionnaireTrigger;
		private Questionnaire questionnaire;
		private QuestionnairePresentationGroupCollection questionnairePresentationGroups;
		private PresentationGroupCollection presentationGroupPicker;
		private QuestionnaireTriggerCollection questionnaireTriggers;

		private LetterMatrixCollection letterMatrixes;
		private LetterMatrix letterMatrixSearcher;
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetail;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCMSTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionnaireTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo QuestionnaireTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionnaireTypeID;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridPresentationGroupPicker;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridPresentationGroups;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPresentationGroupPicker;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPresentationGroups;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSaveSelections;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelSelections;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContentOwnerID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ContentOwnerID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContentOwnerID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionnaireID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit QuestionnaireID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionnaireID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlTrigger;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCodeType;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CodeType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCodeType;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDiagOrProc;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DiagOrProc;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDiagOrProc;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionnaireTriggerID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit QuestionnaireTriggerID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionnaireTriggerID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCodeEnd;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CodeEnd;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCodeEnd;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCodeStart;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CodeStart;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCodeStart;
		protected NetsoftUSA.WebForms.OBCheckBox OBCheckBox1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlTriggers;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelTrigger;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveTrigger;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridTriggers;
		protected NetsoftUSA.WebForms.WindowOpener wo;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDeleteTrigger;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSortOrder;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit SortOrder;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSortOrder;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActiveWithAll;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridLetterMatrixes;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSelectedLetterMatrixes;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSelectedLetterMatrixes;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnUpdateSelection;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMatrixTypeID;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLetterMatrixesGridHolder;
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitializeComponent();
			this.butSaveSelections.Click += new System.EventHandler(this.butSaveSelections_Click);
			this.btnCancelSelections.Click += new System.EventHandler(this.btnCancelSelections_Click);
			this.btnSaveTrigger.Click += new System.EventHandler(this.btnSaveTrigger_Click);
			this.btnCancelTrigger.Click += new System.EventHandler(this.btnCancelTrigger_Click);
			this.gridTriggers.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridTriggers_ClickCellButton);
			this.btnCancelTrigger.Click += new System.EventHandler(this.btnCancelTrigger_Click);
			this.wbtnDeleteTrigger.Click += new System.EventHandler(this.wbtnDeleteTrigger_Click);
			this.wbtnSearch.Click += new System.EventHandler(this.wbtnSearch_Click);
			this.wbtnUpdateSelection.Click += new System.EventHandler(this.wbtnUpdateSelection_Click);
			this.gridSelectedLetterMatrixes.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridSelectedLetterMatrixes_ClickCellButton);
			this.gridSelectedLetterMatrixes.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridSelectedLetterMatrixes_ColumnsBoundToDataClass);
			
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				LoadData();			// Load data is the actual data loading method
				NewLetterMatrixSearcher();
				if(this.questionnaire != null)
					this.LoadDataForQuestionnaireLetterMatrixes();
			}
			else
			{
				questionnaire = (Questionnaire)this.LoadObject(typeof(Questionnaire));	// This would reload from cache
				questionnairePresentationGroups = (QuestionnairePresentationGroupCollection)this.LoadObject(typeof(QuestionnairePresentationGroupCollection));
				questionnaireTriggers = (QuestionnaireTriggerCollection)this.LoadObject(typeof(QuestionnaireTriggerCollection));
				questionnaireTrigger = (QuestionnaireTrigger)this.LoadObject(typeof(QuestionnaireTrigger));
				presentationGroupPicker = (PresentationGroupCollection)this.LoadObject(typeof(PresentationGroupCollection));

				letterMatrixSearcher = (LetterMatrix)this.LoadObject("LetterMatrixSearcher");  // load object from cache
				letterMatrixes = (LetterMatrixCollection)this.LoadObject("LetterMatrixCollectionForQuestionnaire");  // load object from cache
				questionnaireLetterMatrixes = (QuestionnaireLetterMatrixCollection)this.LoadObject("QuestionnaireLetterMatrixes");  // load object from cache
			}
		}

		#region Questionnaire
		public static void Redirect(Questionnaire questionnaire)
		{
			BasePage.PushParam("Questionnaire", questionnaire);
			BasePage.Redirect("QuestionnaireForm.aspx");
		}

		public static void Redirect(int questionnaireID)
		{
			Questionnaire questionnaire = new Questionnaire();
			if (!questionnaire.Load(questionnaireID))
				throw new ActiveAdviceException("Can't find Questionnaire");
			BasePage.PushParam("Questionnaire", questionnaire);
			BasePage.Redirect("QuestionnaireForm.aspx");
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			Questionnaire questionnaire = null;
			try
			{	// use any load method here
				string questionnaireId = this.Request.QueryString["QuestionnaireID"];
				if (questionnaireId != null)
				{
					Questionnaire qr = new Questionnaire();
					if (!qr.Load(int.Parse(questionnaireId)))
						throw new ActiveAdviceException("@CANTFINDRECORD@", "@QUESTIONNAIRE@");
					questionnaire = qr;
				}
				else
				{	
					// no query string
					questionnaire = GetParamOrGetFromCache("Questionnaire", typeof(Questionnaire)) as Questionnaire;
					if (questionnaire == null)	// if not specified create a new one
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a Questionnaire");
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//questionnaire.SqlData.CloseConnection();	// if the questionnaireect is cached and read method is executed, we need this connection closed!
			}
			this.Questionnaire = questionnaire;		// When you set the questionnaireect to the property, controls are automatically populated
			this.QuestionnaireTrigger = null;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to questionnaireect
				if (!this.ReadControls())
					return false;
				if (!this.ReadControlsForPresentationGroups())
					return false;
				questionnaire.Save(); // update or insert to db 

				QuestionnairePresentationGroups = this.questionnaire.PresentationGroups;				
				QuestionnaireTriggers = this.questionnaire.Triggers;
				QuestionnaireLetterMatrixes = this.questionnaire.QuestionnaireLetterMatrixs;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Gets/Sets the data questionnaireect for the page.  When set, it also caches the questionnaireect and updates the controls
		/// </summary>
		public Questionnaire Questionnaire
		{
			get { return questionnaire; }
			set
			{
				questionnaire = value;
				try
				{
					// add all questionnaireect-to-control population code here
					this.UpdateFromObject(pnlDetail.Controls, questionnaire);  // update controls for the given control/collection

					questionnaire.LoadPresentationGroups(false);
					this.QuestionnairePresentationGroups = questionnaire.PresentationGroups;

					questionnaire.LoadTriggers(false);
					this.QuestionnaireTriggers = questionnaire.Triggers;
                    
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Questionnaire), questionnaire);  // cache questionnaireect using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data questionnaireect and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	// add all control-to-questionnaireect population code here
				this.UpdateToObject(pnlDetail.Controls, questionnaire);  // controls-to-questionnaireect

				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}

		}
		#endregion


		public QuestionnairePresentationGroupCollection QuestionnairePresentationGroups
		{
			get { return questionnairePresentationGroups; }
			set
			{
				questionnairePresentationGroups = value;
				try
				{
					pnlPresentationGroups.Visible = questionnairePresentationGroups != null;

					if (questionnairePresentationGroups != null)
					{
						// Load the selected Presentation Groups
						gridPresentationGroups.UpdateFromCollection(questionnairePresentationGroups);
						this.PresentationGroupPicker = null; // Cannot be in pick mode
					}
				
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(QuestionnairePresentationGroupCollection), questionnairePresentationGroups);  // cache questionnaireect using the caching method declared on the page
			}
		}


		public PresentationGroupCollection PresentationGroupPicker
		{
			get { return presentationGroupPicker; }
			set
			{
				presentationGroupPicker = value;
				try
				{
					pnlPresentationGroupPicker.Visible = presentationGroupPicker != null;

					if (presentationGroupPicker != null)
					{
						// Load the whole Presentation Groups list
						gridPresentationGroupPicker.DisplayLayout.AllowUpdateDefault = Infragistics.WebUI.UltraWebGrid.AllowUpdate.Yes;
						gridPresentationGroupPicker.UpdateFromCollection(presentationGroupPicker);  // update given grid from the collection
					}
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(PresentationGroupCollection), presentationGroupPicker);  // cache questionnaireect using the caching method declared on the page
			}
		}

		#region QuestionnaireTriggers
		public QuestionnaireTriggerCollection QuestionnaireTriggers
		{
			get { return questionnaireTriggers; }
			set
			{
				questionnaireTriggers = value;
				try
				{
					pnlTriggers.Visible = questionnaireTriggers != null;

					if (questionnaireTriggers != null)
					{
						// Load the selected Presentation Groups
						gridTriggers.UpdateFromCollection(questionnaireTriggers);
					}
				
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(QuestionnaireTriggerCollection), questionnaireTriggers);  // cache questionnaireect using the caching method declared on the page
			}
		}
		#endregion

		#region QuestionnaireTrigger
		public QuestionnaireTrigger QuestionnaireTrigger
		{
			get { return questionnaireTrigger; }
			set
			{
				questionnaireTrigger = value;
				try
				{
					pnlTrigger.Visible = questionnaireTrigger != null;

					if (questionnaireTrigger != null)
					{
						this.UpdateFromObject(pnlTrigger.Controls, questionnaireTrigger);
					}
				
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(QuestionnaireTrigger), questionnaireTrigger);  // cache questionnaireect using the caching method declared on the page
			}
		}
		#endregion


		public bool ReadControlsForPicker()
		{
			try
			{	
				// Read the selected values 
				PresentationGroupCollection presentationGroups = PresentationGroupCollection.GetPresentationGroupsByContentOwnerForSelection(questionnaire.ContentOwnerID);
				presentationGroups.SetSelectedPresentationGroupsFromCollection(questionnaire.PresentationGroups);
				gridPresentationGroupPicker.UpdateToCollection(presentationGroups);
				questionnaire.PresentationGroups.SynchronizePresentationGroupsFromSelectableCollection(questionnaire.QuestionnaireID, presentationGroups);

				this.QuestionnairePresentationGroups = questionnaire.PresentationGroups;

				// other control-to-object methods if any
				return true;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		public bool ReadControlsForTrigger()
		{
			try
			{	
				// Read the sort order values
				this.UpdateToObject(pnlTrigger.Controls, questionnaireTrigger);

				// other control-to-object methods if any
				return true;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		public bool ReadControlsForPresentationGroups()
		{
			try
			{	
				// Read the sort order values
				gridPresentationGroups.UpdateToCollection(questionnaire.PresentationGroups);				

				this.QuestionnairePresentationGroups = questionnaire.PresentationGroups;

				// other control-to-object methods if any
				return true;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		#region LetterMatrixSearcher
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterMatrix LetterMatrixSearcher
		{
			get { return letterMatrixSearcher; }
			set
			{
				letterMatrixSearcher = value;
				try
				{
					this.UpdateFromObject(this.pnlSearch.Controls, letterMatrixSearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("LetterMatrixSearcher", letterMatrixSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLetterMatrixSearcher()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSearch.Controls, letterMatrixSearcher);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewLetterMatrixSearcher()
		{
			bool result = true;
			LetterMatrix letterMatrixSearcher = null; //new LetterMatrix(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				letterMatrixSearcher = new LetterMatrix();
				
				// lookup [matrixtype].matrixtypeid by CMSTypeID -- Issue 411
				letterMatrixSearcher.MatrixTypeID = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCMSTypeID(Questionnaire.CMSTypeID);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.LetterMatrixSearcher = letterMatrixSearcher;
			this.ActiveWithAll.SelectedRow = this.ActiveWithAll.Rows[0];
			return result;
		}
		#endregion

		#region LetterMatrixes
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterMatrixCollection LetterMatrixes
		{
			get { return letterMatrixes; }
			set
			{
				letterMatrixes = value;
				try
				{
					this.gridLetterMatrixes.UpdateFromCollection(letterMatrixes);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject("LetterMatrixCollectionForQuestionnaire", letterMatrixes);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForLetterMatrixes()
		{
			try
			{	//customize this method for this specific page
				this.gridLetterMatrixes.UpdateToCollection(letterMatrixes);	// grid-to-collection
				// other control-to-object methods if any
				//return this.IsValid;	// Return validation result
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool SearchLetterMatrixes()
		{
			bool result = true;
			LetterMatrixCollection letterMatrixes = new LetterMatrixCollection();
			try
			{
				if (!this.ReadControlsForLetterMatrixSearcher()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				
				letterMatrixes = LetterMatrixCollection.GetFromSearch(this.letterMatrixSearcher);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterMatrixes.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			letterMatrixes.SetSelectedFromCollection(this.questionnaireLetterMatrixes);
			this.LetterMatrixes = letterMatrixes;
			return result;
		}
		#endregion

		#region QuestionnaireLetterMatrixes
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public QuestionnaireLetterMatrixCollection QuestionnaireLetterMatrixes
		{
			get { return questionnaireLetterMatrixes; }
			set
			{
				questionnaireLetterMatrixes = value;
				try
				{
					this.gridSelectedLetterMatrixes.UpdateFromCollection(questionnaireLetterMatrixes);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("QuestionnaireLetterMatrixes", questionnaireLetterMatrixes);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForQuestionnaireLetterMatrixes()
		{
			bool result = true;
			QuestionnaireLetterMatrixCollection questionnaireLetterMatrixes = new QuestionnaireLetterMatrixCollection();
			try
			{	// use any load method here
				Questionnaire.LoadQuestionnaireLetterMatrixs(false);
				questionnaireLetterMatrixes = Questionnaire.QuestionnaireLetterMatrixs;		
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//questionnaireLetterMatrixes.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.QuestionnaireLetterMatrixes = questionnaireLetterMatrixes;
			return result;
		}
		#endregion

		#region UI Initialization and Events
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			if(this.IsPopup)
				toolbar.AddButton("@CLOSE@", "Cancel", false).Item.TargetURL = "javascript:window.close();";
			else
				toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}


		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@QUESTIONNAIRE@");
			}
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			if(this.IsPopup)
				return;

			switch (tab.Key)
			{
				case "Details":
					toolbar.AddButton("@ADDNEWRECORD@", "AddNew");
					break;
				case "PresentationGroups":
					toolbar.AddButton("@ADDREMOVEPR@", "AddRemovePR", false, false);
					break;
				case "Triggers":
					//toolbar.AddButton("@ADDNEWICMTRIGGER@", "AddNewICMTrigger", false, false);
					toolbar.AddButton("@ADDNEWRECORD@", "AddNewTrigger", false, false);
					break;
			}
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.Questionnaire = new Questionnaire(true);
		}

		public void OnToolbarButtonClick_AddNewTrigger(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.QuestionnaireTrigger = new QuestionnaireTrigger(true);
		}

//		public void OnToolbarButtonClick_AddNewICMTrigger(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
//		{
//			ICMForm.Redirect(this.questionnaire);
//		}

		public void OnToolbarButtonClick_AddRemovePR(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// First read and store the presentationgroups because once we switch to picker mode we'll lose those values
			if (!ReadControlsForPresentationGroups())
				return;

			PresentationGroupCollection presentationGroups = PresentationGroupCollection.GetPresentationGroupsByContentOwnerForSelection(questionnaire.ContentOwnerID);
			if (questionnairePresentationGroups != null)
				presentationGroups.SetSelectedPresentationGroupsFromCollection(questionnairePresentationGroups);

			this.QuestionnairePresentationGroups = null;
			this.PresentationGroupPicker = presentationGroups;
		}

		private void gridTriggers_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if(this.IsPopup)
				return;

			if (e.Cell.Key == "Edit")
			{
				try
				{
					int index = gridTriggers.GetColIndexFromCellEvent(e);
					if (index < 0)
						return;
					this.QuestionnaireTrigger = questionnaireTriggers[index];
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void gridTriggers_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				this.QuestionnaireTrigger = questionnaireTriggers[gridTriggers.GetColIndexFromClickEvent(e)];
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.questionnaire);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			bool isNotNew = questionnaire != null && !questionnaire.IsNew;
			this.SetPageTabItemEnabled("PresentationGroups", isNotNew);
			this.SetPageTabItemEnabled("Triggers", isNotNew);
			this.SetPageTabItemEnabled("LetterMatrixes", isNotNew);

			this.wbtnDeleteTrigger.Visible = !(QuestionnaireTrigger == null || QuestionnaireTrigger.CodeType == null);

			this.wbtnDeleteTrigger.OnClickScript = "if (confirm('Are you sure you want to delete this item?') != true) return false;";
			this.SetPageToolbarItemEnabled("Save", !(pnlTrigger.Visible || pnlPresentationGroupPicker.Visible));
			//this.SetPageToolbarItemEnabled("Save", !pnlPresentationGroupPicker.Visible);

			this.RenderClientFunctions(this.pnlTrigger.Controls, this.questionnaireTrigger, "OnCalcTrigger");
			this.pnlSearch.Visible = this.pnlLetterMatrixesGridHolder.Visible = !this.IsPopup;
		}

		public bool SaveSelections()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPicker())
					return false;
				this.QuestionnairePresentationGroups = questionnaire.PresentationGroups;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public bool SaveSortOrders()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPresentationGroups())
					return false;
				this.QuestionnairePresentationGroups = questionnaire.PresentationGroups;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public bool SaveTrigger()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForTrigger())
					return false;
				if (questionnaireTrigger.IsNew)
				{
					questionnaireTrigger.QuestionnaireID = questionnaire.QuestionnaireID;
					questionnaireTrigger.ContentOwnerID = questionnaire.ContentOwnerID;
					questionnaire.Triggers.AddRecord(questionnaireTrigger);
				}
				this.QuestionnaireTrigger = null;
				this.QuestionnaireTriggers = questionnaire.Triggers;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}



		private void butSaveSelections_Click(object sender, System.EventArgs e)
		{
			SaveSelections();
		}

		private void btnCancelSelections_Click(object sender, System.EventArgs e)
		{
			this.PresentationGroupPicker = null;
			this.QuestionnairePresentationGroups = questionnaire.PresentationGroups;
		}

		private void btnSort_Click(object sender, System.EventArgs e)
		{
			SaveSortOrders();
		}

		private void btnSaveTrigger_Click(object sender, System.EventArgs e)
		{
			SaveTrigger();
		}

		private void btnCancelTrigger_Click(object sender, System.EventArgs e)
		{
			this.QuestionnaireTrigger = null;
		}

		private void wbtnDeleteTrigger_Click(object sender, System.EventArgs e)
		{
			this.QuestionnaireTrigger.MarkDel();
			SaveTrigger();
		}

		private void wbtnUpdateSelection_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForLetterMatrixes())
			{
				this.QuestionnaireLetterMatrixes.SynchronizeFromCollection(this.letterMatrixes, this.questionnaire);
				this.questionnaire.QuestionnaireLetterMatrixs = QuestionnaireLetterMatrixes;
				QuestionnaireLetterMatrixes = QuestionnaireLetterMatrixes;
			}
		}

		private void gridSelectedLetterMatrixes_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if(!this.IsPopup)
				gridSelectedLetterMatrixes.AddButtonColumn("Remove", "Remove", 0);
		}

		private void gridSelectedLetterMatrixes_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridSelectedLetterMatrixes.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;	
			if (e.Cell.Key == "Remove")
			{
				QuestionnaireLetterMatrixes[index].MarkDel();
				if(letterMatrixes != null)
				{
					letterMatrixes.SetSelectedFromCollection(this.questionnaireLetterMatrixes);
					LetterMatrixes = letterMatrixes;
				}
				QuestionnaireLetterMatrixes = QuestionnaireLetterMatrixes;
			}
		}

		private void wbtnSearch_Click(object sender, System.EventArgs e)
		{
			SearchLetterMatrixes();
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(questionnaire, questionnairePresentationGroups, questionnaireTriggers, letterMatrixes);
		}

		#endregion
	}
}
