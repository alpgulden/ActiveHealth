using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ActiveAdvice.DataLayer;
using NetsoftUSA.DataLayer;
using ActiveAdvice.Messages;
using NetsoftUSA.WebForms;
using NetsoftUSA.InfragisticsWeb;
using System.Text;

using System.Security.Permissions;

namespace ActiveAdvice.Web
{



	/// <summary>
	/// Summary description for GuidelineCategoryProduct.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.GUIDELINES)]
	
	[MainLanguageClass("ActiveAdvice.Messages.GuidelineMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Guideline,DataLayer")]
	[SelectedMainMenuItem("MPatient")]			
	[SelectedMenuItem("Guidelines")]
	[PageTitle("@GUIDELINESELECTIONTITLE@")]
	public class GuidelineSelection:  PatientBasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProduct1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid4;
		protected System.Web.UI.WebControls.CheckBox chkProduct;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo5;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel5;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuideline1;
	
		
		private GuidelineMaintenance guidelineMaintenance6;

		private GuidelineCollection guidelineCollectionPCG;
		private GuidelineCategoryCollection categoryCollectionPCG;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTip;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuidelineTip;
		private GuidelineProductCollection productCollectionPCG;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator5;
		protected NetsoftUSA.InfragisticsWeb.WebGrid Webgrid1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReference;
		private Guideline guideline;
		private Patient patient;
		
		protected System.Web.UI.WebControls.DataGrid Datagrid1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSelection;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCodeDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CodeDescription;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCodeDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCodeValue;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CodeValue;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCodeValue;
		protected NetsoftUSA.WebForms.OBRadioButtonBox CodeType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCodeType;
		protected NetsoftUSA.WebForms.OBRadioButtonBox DiagOrProc;
		protected NetsoftUSA.WebForms.OBFieldLabel DxOrPx;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearcher;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGuidelines;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCodes;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuidelineCodes;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGuidelineTip1;
		

		private DxPxSearcher searcher;
		private BaseDxPxCollection diagProcs;
		private GuidelineCollection guidelinesForCode;
		private Guideline guidelineForCode;
		private BaseForEventCMSReferral erc;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		private Problem problem;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected System.Web.UI.WebControls.CheckBox chkProduct1;
		protected System.Web.UI.WebControls.CheckBox chkCategory1;
		private Note note;
		protected DataSet dsSelection;
		protected NetsoftUSA.WebForms.OBTextBox Tip;
		protected NetsoftUSA.WebForms.OBTextBox OBTextBox1;
		protected ArrayList dates;

        private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
				LoadData();
			else
			{
				guidelineMaintenance6	= this.LoadObject("GuidelineMaintenance6") as GuidelineMaintenance;
				
				searcher				= (DxPxSearcher)this.LoadObject("Searcher");  // load object from cache
				diagProcs				= (BaseDxPxCollection)this.LoadObject(typeof(BaseDxPxCollection));  // load object from cache
				guidelineForCode		= this.LoadObject("GuidelineForCode") as Guideline;
				patient					= (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				erc						= (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache
				problem					= (Problem) this.LoadObject(typeof(Problem));
				this.note				= this.LoadObject("note") as Note;
				guideline				= this.LoadObject("Guideline") as Guideline;
				
			}
		
			dates		= null;
			dsSelection = null;
		}



		private void LoadData()
		{						
			patient = GetParam("Patient") as Patient;
			if(patient == null)
			{
				this.SetPageMessage("Page must be opened in Patient context",NetsoftUSA.WebForms.EnumPageMessageType.Error);
			}
		
			GuidelineProductCollection productCol1 = new GuidelineProductCollection();
			productCol1.LoadAllGuidelineProducts(-1);
			ProductCollectionPCG = productCol1;

			GuidelineCategoryCollection categoryCol1 = new GuidelineCategoryCollection();
			categoryCol1.LoadAllGuidelineCategories(-1);
			CategoryCollectionPCG = categoryCol1;

			GuidelineCollection guidelineCol1 = new GuidelineCollection();
			guidelineCol1.LoadAllGuidelines(-1);
			

			NotePage notepage = new NotePage();
		
			guideline = new Guideline();
			
			// get the passed patient subscriber coverage (link to patient)
			erc = GetParam("ERC") as BaseForEventCMSReferral;
			if(erc != null)
			{
				this.DiagProcs = CreateSelectedCodes();
				if(this.diagProcs.Count > 0)
				{
					this.PageTab.SelectedTabKey = "Codes";
				}
			}

			GuidelineCollectionPCG = guidelineCol1;
			/*if (guidelineCol1.Count > 0)
				Guideline = guidelineCol1[0];
			else
				Guideline = new Guideline(true);*/

			
			problem = (Problem)this.LoadObject(typeof(Problem));
			NewSearcher("D");

			NewGuidelineMaintenance6();
			
			}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.chkProduct.CheckedChanged += new System.EventHandler(this.chkProduct_CheckedChanged);
			this.Webgrid3.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.Webgrid3_ClickCellButton);
			this.Webgrid3.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.Webgrid3_ColumnsBoundToDataClass);
			this.Webgrid4.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.Webgrid4_ClickCellButton);
			this.Webgrid4.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.Webgrid4_ColumnsBoundToDataClass);
			this.WebCombo5.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.WebCombo5_SelectedRowChanged);
			this.chkProduct1.CheckedChanged += new System.EventHandler(this.chkProduct1_CheckedChanged);
			this.chkCategory1.CheckedChanged += new System.EventHandler(this.chkCategory1_CheckedChanged);
			this.Webgrid5.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.Webgrid5_ClickCellButton);
			this.Webgrid5.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.Webgrid5_ColumnsBoundToDataClass);
			this.Datagrid1.ItemCreated += new System.Web.UI.WebControls.DataGridItemEventHandler(this.Datagrid1_ItemCreated);
			this.Datagrid1.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.Datagrid1_ItemDataBound);
			this.DiagOrProc.SelectedIndexChanged += new System.EventHandler(this.DiagOrProc_SelectedIndexChanged);
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.gridCodes.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridCodes_ClickCellButton);
			this.gridCodes.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridCodes_ColumnsBoundToDataClass);
			this.gridGuidelines.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridGuidelines_ClickCellButton);
			this.gridGuidelines.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridGuidelines_ColumnsBoundToDataClass);
			this.ValidationsOnlyInSummary = true;
			this.ViewStateOnServer = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		

		
		private void UpdateCategoryCollectionPCG()
		{
			GuidelineCategoryCollection col = new GuidelineCategoryCollection();
			try
			{
			
				if(this.chkProduct.Checked)
				{
					int productID=this.Webgrid3.SelectedRowPKInt;
					if(productID == 0)
					{
						this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
						return;
					}
					else
					{
						col.LoadActiveGuidelineCategoriesForProduct(-1,productID,true);
					}
				}
				else
				{
					col.LoadActiveGuidelineCategories(-1,true);
				}
			
				this.CategoryCollectionPCG= col;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
			
		}
	

	
		private void WebCombo5_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			UpdateGuidelineCollectionPCG();
		}
		private void UpdateGuidelineCollectionPCG()
		{
			// Names of grids and combos and their def
			// Product -> WebGrid3
			// Category -> WebGrid4
			// Guideline -> WebGrid5
			// Codes     -> grid

			GuidelineCollection col = new GuidelineCollection();
			try
			{
				this.UpdateToObject(this.pnlGuideline1.Controls,guidelineMaintenance6);
				if(guidelineMaintenance6.GuidelineSourceSetID != 0)
				{
					// Try updating category and product grids.
					// Update Categories filtered by Selected SourceSet
					GuidelineCategoryCollection guidelineCats = new GuidelineCategoryCollection();
					guidelineCats.LoadGuidelineCategoriesForSS(-1, guidelineMaintenance6.GuidelineSourceSetID);
					this.Webgrid4.UpdateFromCollection(guidelineCats);
					// Update Products filtered by Selected SourceSet
					GuidelineProductCollection guidelineProds = new GuidelineProductCollection();
					guidelineProds.LoadGuidelineProductsForSourceSet(-1, guidelineMaintenance6.GuidelineSourceSetID);
					this.Webgrid3.UpdateFromCollection(guidelineProds);

					if(this.chkProduct1.Checked && this.chkCategory1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadActiveGuidelinesForProductCategorySS(-1,guidelineMaintenance6.GuidelineSourceSetID,productID,categoryID,true);
						}
					}
					else if(this.chkProduct1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadActiveGuidelinesForProductSourceSet(-1,productID,guidelineMaintenance6.GuidelineSourceSetID,true);
					}
					else if(this.chkCategory1.Checked)
					{
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadActiveGuidelinesForCategorySourceSet(-1,categoryID,guidelineMaintenance6.GuidelineSourceSetID,true);
					}
					else
					{
						col.LoadActiveGuidelinesForSS(-1,true,guidelineMaintenance6.GuidelineSourceSetID);
					}
				}
				else
				{
					if(this.chkProduct1.Checked && this.chkCategory1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
						{
							col.LoadActiveGuidelinesForProductCategory(-1,productID,categoryID,true);
						}
					}
					else if(this.chkProduct1.Checked)
					{
						int productID=this.Webgrid3.SelectedRowPKInt;
						if(productID == 0)
						{
							this.SetPageMessage("@SELECTPRODUCT@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadActiveGuidelinesForProduct(-1,productID,true);
					}
					else if(this.chkCategory1.Checked)
					{
						int categoryID = this.Webgrid4.SelectedRowPKInt;
						if(categoryID == 0)
						{
							this.SetPageMessage("@SELECTCATEGORY@",EnumPageMessageType.Error);
							return;
						}
						else
							col.LoadActiveGuidelinesForCategory(-1,categoryID,true);
					}
					else
					{
						col.LoadActiveGuidelines(-1,true);
					}
				}
				this.GuidelineCollectionPCG= col;
				if (this.GuidelineCollectionPCG != null && this.GuidelineCollectionPCG.Count >= 1)
					this.Guideline = this.GuidelineCollectionPCG[0];
				else
					this.Guideline = null;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
			
		}

		private void chkProduct1_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateGuidelineCollectionPCG();
		}

		private void chkProduct_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateCategoryCollectionPCG();
		}

		

		private void chkCategory1_CheckedChanged(object sender, System.EventArgs e)
		{
			UpdateGuidelineCollectionPCG();
		}

	
		public void NewGuidelineMaintenance6()
		{
			try
			{
				GuidelineMaintenance maintenance = new GuidelineMaintenance();			
				maintenance.GuidelineSourceSetID = SystemControlValue.GetInstance.GuidelineSourceSetID;
				this.GuidelineMaintenance6 = maintenance;
				UpdateGuidelineCollectionPCG();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		

		public ActiveAdvice.DataLayer.GuidelineCollection GuidelineCollectionPCG
		{
			get { return this.guidelineCollectionPCG; }
			set { this.guidelineCollectionPCG = value;
				try
				{
					this.Webgrid5.UpdateFromCollection(guidelineCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineCategoryCollection CategoryCollectionPCG
		{
			get { return this.categoryCollectionPCG; }
			set { this.categoryCollectionPCG = value;
				try
				{
					this.Webgrid4.UpdateFromCollection(categoryCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.GuidelineProductCollection ProductCollectionPCG
		{
			get { return this.productCollectionPCG; }
			set { this.productCollectionPCG = value; 
				try
				{
					this.Webgrid3.UpdateFromCollection(productCollectionPCG);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}



		public ActiveAdvice.DataLayer.GuidelineMaintenance GuidelineMaintenance6
		{
			get { return this.guidelineMaintenance6; }
			set { this.guidelineMaintenance6 = value;
				try
				{
					this.UpdateFromObject(this.pnlGuideline1.Controls,guidelineMaintenance6);
					this.CacheObject("GuidelineMaintenance6",guidelineMaintenance6);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public Guideline Guideline
		{
			get
			{
				return this.guideline;
			}
			set
			{
				try
				{
					guideline = value;
					if (guideline != null)
					{
						this.dates = null; // invalidate previous selection dates.
						this.dsSelection = null;
						guideline.LoadGuidelineTips(false);
						guideline.LoadGuidelineCodes(false);
						guideline.LoadGuidelineIndicatorsActiveOnly(false);
						guideline.LoadGuidelineIndicators(false);
						this.UpdateFromObject(this.pnlGuidelineTip.Controls,guideline.GuidelineTips[0]);
						grid.UpdateFromCollection(guideline.GuidelineCodes);
						this.Webgrid1.UpdateFromCollection(guideline.GuidelineIndicators);
						this.UpdateFromCollection(Datagrid1,guideline.GuidelineIndicators,true,"GuidelineIndicatorID");
					}
					else
					{
						this.UpdateFromObject(this.pnlGuidelineTip.Controls, new GuidelineTip());
						grid.UpdateFromCollection(new GuidelineCodeCollection());
						this.Webgrid1.UpdateFromCollection(new GuidelineIndicatorCollection());
						this.CacheObject("savedNow", null);
					}
					
					this.CacheObject("Guideline",guideline);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}

			}
		}


		public static void Redirect(Patient patient,BaseForEventCMSReferral erc)
		{
			BasePage.PushParam("Patient",patient);
			BasePage.PushParam("ERC", erc);
			BasePage.Redirect("GuidelineSelection.aspx");
		}

		private void Webgrid5_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if(e.Cell.Key == "Select")
			{
				object[] pk= Webgrid5.SelectedRowPK;
				int guidelineID = (int) pk[0];
				Guideline guideline = new Guideline();
				guideline.Load(guidelineID);
				this.Guideline = guideline;		
			}
		}

		private void Webgrid5_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			Webgrid5.AddButtonColumn("Select","@SELECT@",0);
		}

		private void gridCodes_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if(e.Cell.Key == "Select")
			{
				int index = gridCodes.GetColIndexFromCellEvent(e);
				GuidelineCollection col = new GuidelineCollection();
				col.LoadActiveGuidelinesForCode(-1,diagProcs[index].CodeType,this.diagProcs[index].CodeValue,diagProcs[index].DxOrPx,true);
				this.GuidelinesForCode = col;
			}
		}

		private void gridCodes_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridCodes.AddButtonColumn("Select","@SELECT@",0);
		}

		private void gridGuidelines_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridGuidelines.AddButtonColumn("Select","@SELECT@",0);
		}

		private void gridGuidelines_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if(e.Cell.Key == "Select")
			{
				object[] pk= gridGuidelines.SelectedRowPK;
				int guidelineID = (int) pk[0];
				Guideline guideline = new Guideline();
				guideline.Load(guidelineID);
				this.GuidelineForCode	= guideline;
				this.Guideline			= guideline; // SCR1517
		
			}
		}


		private void Datagrid1_ItemCreated(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{

//			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
//			{
//				CheckBox check = new CheckBox();
//				check = e.Item.FindControl("chkSelect") as CheckBox;
//				System.Web.UI.HtmlControls.HtmlInputHidden hiddenfield = new HtmlInputHidden();
//				hiddenfield = e.Item.FindControl("HiddenNote") as HtmlInputHidden;
//				if(check != null && hiddenfield != null)
//				{
//					check.CheckedChanged +=new EventHandler(check_CheckedChanged);
//					
//				}
//			}
		}

		/// <summary>
		///  Fills previous guideline selection related data.
		/// </summary>
		private void GetSelectionData(int patientID, int guidelineID, int eventID, int referralID, int cmsID, int problemID)
		{
			string storedProcName = null;
			if (dates == null )
			{
				ArrayList dateList = new ArrayList();
				storedProcName = "usp_GetGuidelineSelectionDates";
				this.guideline.SqlData.SPExecReadArrayList(storedProcName,-1,dateList,new string[] {"CreateTime"}  , new object[] { patientID, guidelineID, SQLDataDirect.MakeDBValue(eventID,0) , SQLDataDirect.MakeDBValue(referralID,0), SQLDataDirect.MakeDBValue(cmsID,0), SQLDataDirect.MakeDBValue(problemID,0) });				
				this.dates = dateList;
			}
			if (dsSelection == null)
			{
				storedProcName = "usp_GetGuidelineSelections";
				this.dsSelection = this.guideline.SqlData.SPExecDataSet(storedProcName, new object[] { patientID, guidelineID, SQLDataDirect.MakeDBValue(eventID,0),SQLDataDirect.MakeDBValue(referralID,0), SQLDataDirect.MakeDBValue(cmsID,0),SQLDataDirect.MakeDBValue(problemID,0) });			
			}
		}
		
		private void Datagrid1_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			
			
			int	guidelineID					= 0; 
			int	patientID					= 0; 
			int	currentGuidelineIndicatorID = 0;

			try
			{
				guidelineID = this.Guideline.GuidelineID;
				patientID	= this.patient.PatientId;
			}
			catch
			{
				guidelineID = 0;
				patientID = 0;
			}
			
			// Get event/cms/referral/problem IDs
			int  eventID		= 0;
			int  cmsID			= 0;
			int  referralID		= 0;
			int  problemID		= 0;

			try
			{
				if (erc is CMS)
					cmsID = ((CMS)erc).CMSID;
				if (erc is Event)
					eventID = ((Event)erc).EventID;
				if (erc is Referral)
					referralID = ((Referral)erc).ReferralID;
				problemID = this.erc.PrimaryProblemID;
			}
			catch 
			{
				
			}
			GetSelectionData(patientID, guidelineID, eventID, referralID, cmsID, problemID);

			if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				ImageButton img = new ImageButton();
				img=e.Item.FindControl("imgNote") as ImageButton;

				if(img != null)
				{
					
					GuidelineIndicator indicator = new GuidelineIndicator();
					indicator = e.Item.DataItem as GuidelineIndicator;
					System.Web.UI.HtmlControls.HtmlInputCheckBox check = new System.Web.UI.HtmlControls.HtmlInputCheckBox();
					check = e.Item.FindControl("chkSelect") as System.Web.UI.HtmlControls.HtmlInputCheckBox;
					if(!indicator.Selectable)
					{
						img.Visible = false;
						check.Visible = false;
					}
					else
					{
						System.Web.UI.HtmlControls.HtmlInputHidden hiddenfield = new HtmlInputHidden();
						hiddenfield = e.Item.FindControl("HiddenNote") as HtmlInputHidden;
						if(check != null && hiddenfield != null)
							img.Attributes.Add("OnClick","OpenNoteWindow(\'"+check.ClientID+"\',\'"+hiddenfield.ClientID+"\');return false;");
						if(indicator != null)
						{
							if(indicator.NoteRequired == true)
							{
								if(check != null)
								{
							
									check.Disabled =true;
									img.ImageUrl = "pics/impt_16.gif";
								}
							}
						}
					}
					// Move Data into a DataView for filtering in memory.
					DataView dv = null;
					
					currentGuidelineIndicatorID	 = 0; // GuidelineIndicatorID of the current row.
				
					try
					{
						// get the ID. If there's an error throw exception.
						dv = new DataView(dsSelection.Tables[0]);
						currentGuidelineIndicatorID = (e.Item.Cells[4] == null) ? 0 : int.Parse(e.Item.Cells[4].Text);
					}
					catch
					{
						guidelineID = 0;
					}

						// Iterate through each Date Entry for this row. Look for matches if found mark as selected.
					for (int j=0; j < this.dates.Count; j++)
					{
						if (guidelineID == 0)
							break;
						DateTime DateCriteria = (DateTime)dates[j];
						// Compare both date and guidelineIndicatorID
						string filter = String.Format("(CreateTime = '#{0:G}#') AND (GuidelineIndicatorID = {1})" , DateCriteria, currentGuidelineIndicatorID); 
						dv.RowFilter = filter;
						string cellText = "        ";
						if (dv.Count > 0)
							cellText = @"<img src='pics\successmark.gif' alt='Created By: " + dv[0]["Name"] +"'>"; // Update cell content with a check image.
							
						TableCell newCell = new TableCell();
						newCell.Text      = cellText;
						newCell.Font.Size = 10;
						newCell.Font.Name = "Arial";
						e.Item.Cells.Add(newCell);

						// Reset RowFilter.
						dv.RowFilter = "";					
					}
					
				}

				System.Web.UI.WebControls.Image imgTip = e.Item.FindControl("imgTip") as System.Web.UI.WebControls.Image;
				GuidelineIndicator guidelineInd		   = null;
				if (imgTip != null)
				{
				
					guidelineInd = (GuidelineIndicator)e.Item.DataItem;
					guidelineInd.LoadGuidelineIndicatorTips(true);
					imgTip.Visible = false;
					if (guidelineInd.GuidelineIndicatorTips != null && guidelineInd.GuidelineIndicatorTips.Count > 0)
					{
						GuidelineIndicatorTip guidelineTip = guidelineInd.GuidelineIndicatorTips.GetGuidelineIndicatorTip(currentGuidelineIndicatorID);
						if (guidelineTip != null)
						{
							imgTip.ImageUrl = "pics/infomark.gif";
							imgTip.Attributes.Add("OnClick","OpenGuidelineTip(\'"+ guidelineTip.GuidelineIndicatorTipID.ToString() +"\');return false;");
							imgTip.Visible = true;
						}
					}					
				}
			}	
		
			// IF header then add info.
			if (e.Item.ItemType == ListItemType.Header && guidelineID != 0)
			{
				//this.guideline.SqlData.SPExecReadArrayList(storedProcName,-1,dates,new string[] {"CreateTime"}  , new object[] { patientID, guidelineID,SQLDataDirect.MakeDBValue(eventID,0), SQLDataDirect.MakeDBValue(referralID, 0), SQLDataDirect.MakeDBValue(cmsID,0), SQLDataDirect.MakeDBValue(problemID,0) });
				for (int i=0; i < this.dates.Count; i++)
				{
					TableCell cell = new TableCell();
					cell.Font.Name = "Arial";
					cell.Font.Size = 10;
					cell.Width	   = 60;
					cell.Text = dates[i].ToString();
					e.Item.Cells.Add(cell);		
				}

		
			}
			
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@SAVE@","Save");
			toolbar.AddButton("@CANCEL@","Cancel");
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			if(tab.Key == "Selection")
				toolbar.AddButton("@MEDICALNOTE@","MedicalNote").Visible = false;
			toolbar.AddButton("@BACK@","Back");
		}

		/// <summary>
		///	  Populates the given grid with previous selections.
		/// </summary>
		/// <param name="patientID">PatientID</param>
		/// <param name="guidelineID">GuidelineID</param>
		/// <param name="grid">Grid to be modified.</param>
		private void MarkPreviousSelections(int patientID, int guidelineID, ref DataGrid grid )
		{
		
			if (guidelineID == 0 || patientID == 0 || this.erc == null)
				return ;

			// Get event/cms/referral/problem IDs
			int  eventID		= 0;
			int  cmsID			= 0;
			int  referralID		= 0;
			int  problemID		= 0;
					
			if (erc is CMS)
				cmsID = ((CMS)erc).CMSID;
			if (erc is Event)
				eventID = ((Event)erc).EventID;
			if (erc is Referral)
				referralID = ((Referral)erc).ReferralID;
			problemID = this.erc.PrimaryProblemID;

			// Execute stored proc to get the selections.
			string		storedProcName = "usp_GetGuidelineSelections";
			DataSet ds = this.guideline.SqlData.SPExecDataSet(storedProcName, new object[] { patientID, guidelineID, SQLDataDirect.MakeDBValue(eventID,0),SQLDataDirect.MakeDBValue(referralID,0), SQLDataDirect.MakeDBValue(cmsID,0),SQLDataDirect.MakeDBValue(problemID,0) });			
			ArrayList dates = new ArrayList();
			this.guideline.SqlData.SPExecReadArrayList(storedProcName,-1,dates,new string[] {"CreateTime"}  , new object[] { patientID, guidelineID, SQLDataDirect.MakeDBValue(eventID,0) , SQLDataDirect.MakeDBValue(referralID,0), SQLDataDirect.MakeDBValue(cmsID,0), SQLDataDirect.MakeDBValue(problemID,0) });
			
			// If there are currently displayed columns we need to refresh on next postback as well. 
			// cache the string to ensure refresh on next postback.
			/*if (dates.Count > 0)
					this.CacheObject("savedNow","Saved Now");*/


			// Move Data into a DataView for filtering in memory.
			DataView dv = new DataView(ds.Tables[0]);
			int			currentGuidelineIndicatorID = 0; // GuidelineIndicatorID of the current row.
			for (int i=0; i < grid.Items.Count; i++) // For each row see if an item exists in dv if yes mark that cell as selected.
			{
				DataGridItem currentItem = grid.Items[i];
				if (currentItem == null) // if null exit loop.
					break;
				try
				{
					// get the ID. If there's an error throw exception.
					currentGuidelineIndicatorID = (grid.Columns[4] == null) ? 0 : int.Parse(currentItem.Cells[4].Text);
				}
				catch
				{
					throw new ActiveAdviceException(AAExceptionAction.None,"@GUIDELINESELERROR");
				}

				// Iterate through each Date Entry for this row. Look for matches if found mark as selected.
				for (int j=5; j < grid.Columns.Count; j++)
				{
					if (dates == null || dates.Count == 0 || (j-5) < 0 || currentItem.Cells.Count < j)
						return;

					
					
					if (j == currentItem.Cells.Count)
					{
						TableCell cell = new TableCell();
						cell.EnableViewState = true;
						currentItem.Cells.Add(cell);
					}
					// Get The Date from the header.
					DateTime DateCriteria = (DateTime)dates[j-5];
					// Compare both date and guidelineIndicatorID
					string filter = String.Format("(CreateTime = '#{0:G}#') AND (GuidelineIndicatorID = {1})" , DateCriteria, currentGuidelineIndicatorID); 

					dv.RowFilter = filter;
					string cellText = "        ";
					if (dv.Count > 0)
						cellText = @"<img src='pics\successmark.gif' alt='Created By: " + dv[0]["Name"] +"'>"; // Update cell content with a check image.


						currentItem.Cells[j].Text = cellText;
					// Reset RowFilter.
					dv.RowFilter = "";					
				}
			}
		}

		/// <summary>
		///  This method adds appropriate number of previous selection column headers
		///  with their test.
		/// </summary>
		/// <param name="patientID">PatientID</param>
		/// <param name="guidelineID">GuidelineID</param>
		/// <param name="grid">Grid to which columns will be added.</param>
		private void SetSelectionColumns(int patientID, int guidelineID, ref DataGrid grid)
		{
			if (guidelineID == 0 || patientID == 0 || this.erc == null)
				return;
			string		storedProcName	= "usp_GetGuidelineSelectionDates";
			ArrayList   dates			= new ArrayList();
			int  eventID				= 0;
			int  cmsID					= 0;
			int  referralID				= 0;
			int  problemID				= 0;

			
			
			if (erc is CMS)
				cmsID = ((CMS)erc).CMSID;
			if (erc is Event)
				eventID = ((Event)erc).EventID;
			if (erc is Referral)
				referralID = ((Referral)erc).ReferralID;
			problemID = this.erc.PrimaryProblemID;

			this.guideline.SqlData.SPExecReadArrayList(storedProcName,-1,dates,new string[] {"CreateTime"}  , new object[] { patientID, guidelineID,SQLDataDirect.MakeDBValue(eventID,0), SQLDataDirect.MakeDBValue(referralID, 0), SQLDataDirect.MakeDBValue(cmsID,0), SQLDataDirect.MakeDBValue(problemID,0) });
			for (int i=0; i < dates.Count; i++)
			{
				
				TemplateColumn  column		= new  TemplateColumn();
				column.ItemTemplate			= new DataGridTemplate(ListItemType.Header, " ");
				column.ItemStyle.Font.Size	= FontUnit.Small;
				column.HeaderStyle.Width	= Unit.Pixel(60);
				column.ItemStyle.Width		= Unit.Pixel(60);
				column.HeaderTemplate		= new DataGridTemplate(ListItemType.Header, dates[i].ToString());
				column.Visible				= true;
				
				grid.Columns.Add(column);
					
			}

			// If there are currently displayed columns we need to refresh on next postback as well. 
			// cache the string to ensure refresh on next postback.
			if (dates.Count > 0)
				this.CacheObject("savedNow","Saved Now");
			
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// Medical Note Creation.
			try
			{
				string str = GenerateMedicalNoteText();
				Note note = new Note(this.patient,true);
				if(problem != null)
					note.ProblemId = this.problem.ProblemID;
				if(this.erc != null)
				{
					switch (erc.ERCType)
					{
						case EnumERCType.Event:
							note.EventID = erc.ID;
							break;
						case EnumERCType.CMS:
							note.CMSId = erc.ID;
							break;
						case EnumERCType.Referral:
							note.ReferralId = erc.ID;
							break;
					}
				}
		
				
				NoteType noteType		= new NoteType();
				noteType				= NoteTypeCollection.ActiveNoteTypes.FindBy("GUID");
				note.NoteTypeID			= noteType.NoteTypeID;
				note.NotePage.TextASCII = str;
				note.MedicalNoteBrief	= str;
				note.SelectedPatientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage), false);
				note.Save();
				
				CacheObject("note",note);
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@MEDICALNOTE@");
				this.SetPageTabToolbarItemVisible("MedicalNote", true);
				this.UpdateFromCollection(this.Datagrid1, this.guideline.GuidelineIndicators, true, "GuidelineIndicatorID");
				
				

			

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		public void OnToolbarButtonClick_Back(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.RedirectBack();
		}

		

		public void OnToolbarButtonClick_MedicalNote(WebToolbar toolbar,Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			
			CacheObject("NoteTemplate",LoadObject("note") as Note);
			NoteForm.PushCallingPage(this);
			NoteForm.Redirect(LoadObject("note") as Note, EnumPageModes.Append);
			
			#region "medical code creation moved to Save button "
//			try
//			{
//				string str = GenerateMedicalNoteText();
//				Note note = new Note(this.patient,true);
//				if(problem != null)
//					note.ProblemId = this.problem.ProblemID;
//				if(this.erc != null)
//				{
//					switch (erc.ERCType)
//					{
//						case EnumERCType.Event:
//							note.EventID = erc.ID;
//							break;
//						case EnumERCType.CMS:
//							note.CMSId = erc.ID;
//							break;
//						case EnumERCType.Referral:
//							note.ReferralId = erc.ID;
//							break;
//					}
//				}
//		
//			
//				NoteType noteType = new NoteType();
//				noteType = NoteTypeCollection.ActiveNoteTypes.FindBy("GUID");
//				note.NoteTypeID = noteType.NoteTypeID;
//				note.NotePage.TextASCII = str;
//				note.Save();
//				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@MEDICALNOTE@");
//			}
//			catch(Exception ex)
//			{
//				this.RaisePageException(ex);
//			}
			#endregion
		}
		private string GenerateMedicalNoteText()
		{
			GuidelineSelectionCollection guidelineSelCol = new GuidelineSelectionCollection();
			try
			{
				StringBuilder sb = new StringBuilder();
				sb.Append(this.Guideline.Text + "\n\n");
				foreach(DataGridItem item in this.Datagrid1.Items)
				{
					System.Web.UI.HtmlControls.HtmlInputCheckBox check=item.FindControl("chkSelect") as System.Web.UI.HtmlControls.HtmlInputCheckBox;
					HtmlInputHidden hiddenfield = item.FindControl("HiddenNote") as HtmlInputHidden;
					NetsoftUSA.WebForms.OBLabel label = item.FindControl("DisplayText") as OBLabel;
					ActiveAdvice.DataLayer.GuidelineSelection guidelineSel = null;

					if(check != null && hiddenfield != null && label != null)
					{
						if(check.Visible)
						{
							if(check.Checked)
							{
								guidelineSel = new ActiveAdvice.DataLayer.GuidelineSelection();
								guidelineSel.New();
								switch (this.erc.ERCType)
								{
									case EnumERCType.CMS:
										guidelineSel.CMSID = ((CMS)erc).CMSID;
										break;
									case EnumERCType.Event:
										guidelineSel.EventID = ((Event)erc).EventID;
										break;
									case EnumERCType.Referral:
										guidelineSel.ReferralID = ((Referral)erc).ReferralID;
										break;
								}
								guidelineSel.ProblemID = erc.PrimaryProblemID;
								guidelineSel.GuidelineIndicatorID = int.Parse(item.Cells[4].Text);
								guidelineSel.PatientID = this.patient.PatientId;
								guidelineSelCol.Add(guidelineSel);
					
								sb.Append(label.Text);
								sb.Append("\n");
								sb.Append(hiddenfield.Value);
								sb.Append("\n\n");
							}
						}
					}
				}
				try
				{
					if (guidelineSelCol.Count > 0)
						guidelineSelCol.Save();
				}
				catch 
				{
					throw new ActiveAdviceException(AAExceptionAction.None, "An error occurred while saving selections");
				}
				sb.Replace("&nbsp;"," ");
				return sb.ToString();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return "";
			}
		}

		public DxPxSearcher Searcher
		{
			get { return searcher; }
			set
			{
				searcher = value;
				try
				{
					this.UpdateFromObject(pnlSearcher.Controls, searcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("Searcher", searcher);  // cache object using the caching method declared on the page
			}
		}

		public bool ReadControlsForSearcher()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlSearcher.Controls, searcher);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// </summary>
		public bool Search()
		{
			bool result = true;
			BaseDxPxCollection diagProcs = null;
			try
			{

				if (!this.ReadControlsForSearcher()) // Use appropriate read controls method to read the searcher object from controls 
					return false;

				if (this.searcher.CodeType == null)
				{
					this.SetPageMessage("@FIRSTSELECTCODETYPE@", EnumPageMessageType.Warning);
					return false;
				}

				diagProcs = DxPxCodeClassFactory.CreateDxPxCollection(searcher.CodeType);
				//				diagProcs.Patient = this.patient;
				
				diagProcs.Search(this.searcher.CodeValue, this.searcher.DxOrPx, this.searcher.CodeDescription, true, this.GuidelineMaintenance6.GuidelineSourceSetID);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
			}
			this.DiagProcs = diagProcs;
			return result;
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewSearcher(string dxOrPx)
		{
			bool result = true;
			DxPxSearcher searcher = new DxPxSearcher(dxOrPx); // use a parameterized constructor which also initializes the data object
			searcher.CodeType = "ICD9";
			try
			{	// or use an initialization method here
			
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Searcher = searcher;
			return result;
		}

		private void DiagOrProc_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.NewSearcher(this.DiagOrProc.SelectedValue);
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		public BaseDxPxCollection DiagProcs
		{
			get { return diagProcs; }
			set
			{
				diagProcs = value;
				try
				{
					gridCodes.KeepCollectionIndices = false;  // update given grid from the collection
					gridCodes.UpdateFromCollection(diagProcs);  // update given grid from the collection
					// other object-to-control methods if any
					
					if(diagProcs!= null && diagProcs.Count >0)
					{
						GuidelineCollection col = new GuidelineCollection();
						col.LoadActiveGuidelinesForCode(-1,diagProcs[0].CodeType,diagProcs[0].CodeValue,diagProcs[0].DxOrPx,true);
						this.GuidelinesForCode = col;
					}
					else
						this.GuidelinesForCode = new GuidelineCollection();
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(BaseDxPxCollection), diagProcs);  // cache object using the caching method declared on the page
			}
		}

		public ActiveAdvice.DataLayer.GuidelineCollection GuidelinesForCode
		{
			get { return this.guidelinesForCode; }
			set 
			{
				this.guidelinesForCode = value;
				try
				{
					this.gridGuidelines.UpdateFromCollection(guidelinesForCode);
					if(guidelinesForCode != null && guidelinesForCode.Count >0)
					{
						this.GuidelineForCode	= guidelinesForCode[0];
						this.Guideline			= guidelinesForCode[0];
					}
					else
					{
						if (Webgrid5.Rows.Count > 0 && Webgrid5.SelectedRowPKInt != 0)
						{
							Guideline gl = new Guideline();
							gl.Load(Webgrid5.SelectedRowPKInt);
							this.Guideline = gl;
						}
					}
					
					
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("GuidelinesForCode",guidelinesForCode);
			}
		}

		public ActiveAdvice.DataLayer.Guideline GuidelineForCode
		{
			get { return this.guidelineForCode; }
			set 
			{
				this.guidelineForCode = value;
				try
				{
					guidelineForCode.LoadGuidelineIndicatorsActiveOnly(false);
					guidelineForCode.LoadGuidelineTips(false);
					this.UpdateFromObject(this.pnlGuidelineTip1.Controls,guidelineForCode.GuidelineTips[0]);
					this.Webgrid1.UpdateFromCollection(guidelineForCode.GuidelineIndicators);
					this.UpdateFromCollection(Datagrid1,guidelineForCode.GuidelineIndicators,true,"GuidelineIndicatorID");
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("GuidelineForCode",guidelineForCode);
			}
		}

		public static void Redirect()
		{
			Redirect("GuidelineSelection.aspx");
		}

		public BaseDxPxCollection CreateSelectedCodes()
		{
			BaseDxPxCollection col = new BaseDxPxCollection();
			if(erc != null)
			{
				DxPxSelectCollection col1 =erc.CreateDiagnosticSelectionCollection();
				foreach(DxPxSelect dxpxSel in col1)
				{
					GuidelineCollection col3 = new GuidelineCollection();
					col3.LoadAllGuidelinesForCode(-1,dxpxSel.CodeType,dxpxSel.CodeValue,dxpxSel.CodeDxOrPx);
					if(col3.Count >0)
						col.Add(dxpxSel.GetDxPxCode());
				}
				DxPxSelectCollection col2 = erc.CreateProcedureSelectionCollection();
				foreach(DxPxSelect dxpxSel in col2)
				{
					GuidelineCollection col3 = new GuidelineCollection();
					col3.LoadAllGuidelinesForCode(-1,dxpxSel.CodeType,dxpxSel.CodeValue,dxpxSel.CodeDxOrPx);
					if(col3.Count >0)
						col.Add(dxpxSel.GetDxPxCode());
				}	
				
			}
			col.ElementInstance = new ICD9Code(true);
			return col;
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.erc);
		}

		private void Webgrid3_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if(e.Cell.Key == "Select")
			{
				if(this.chkProduct.Checked)
					UpdateCategoryCollectionPCG();
				if(this.chkProduct1.Checked)
					UpdateGuidelineCollectionPCG();
			}
		}

		private void Webgrid3_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			Webgrid3.AddButtonColumn("Select","@SELECT@");
		}

		private void Webgrid4_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			Webgrid4.AddButtonColumn("Select","@SELECT@");
		}

		private void Webgrid4_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if(e.Cell.Key == "Select")
			{
				if(this.chkCategory1.Checked)
					UpdateGuidelineCollectionPCG();
			}
		}
		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			if (this.guideline != null)
				this.CheckForDirty(this.guideline.GuidelineIndicators);
		}

	}

	public class DataGridTemplate : ITemplate
	{
		ListItemType templateType;
		string columnName;
   
		public DataGridTemplate(ListItemType type, string colname)
		{
			templateType = type;
			columnName = colname;
		}

		public void InstantiateIn(System.Web.UI.Control container)
		{
			Literal lc = new Literal();
			switch(templateType)
			{
				case ListItemType.Header:
					lc.Text = "<font face=\'arial\' size=\'2\'>" + columnName + "</font>" ;
					container.Controls.Add(lc);
					break;
				case ListItemType.Item:
					lc.Text = "Item " + columnName;
					container.Controls.Add(lc);
					break;
				case ListItemType.EditItem:
					TextBox tb = new TextBox();
					tb.Text = "";
					container.Controls.Add(tb);
					break;
				case ListItemType.Footer:
					lc.Text = "<I>" + columnName + "</I>";
					container.Controls.Add(lc);
					break;
			}
		}
	}

}
