using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.INTAKE )]

	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("IntakeLog,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MIntake")]
	[PageTitle("@INTAKELOGPAGETITLE@")]
	public class IntakeLogSearch : BasePage
	{
		private IntakeLogSearcher intakeLogSearcher;
		private IntakeLogCollection intakeLogs;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCallerOrganization;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CallerOrganization;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCallerOrganization;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientFName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PatientFName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientFName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCallerFName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CallerFName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCallerFName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFromDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FromDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFromDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientLName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PatientLName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientLName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCallerLName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CallerLName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCallerLName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldToDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ToDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbToDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPatientSSN;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit PatientSSN;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientSSN;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCreationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CreationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCreationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldIntakeCallReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo IntakeCallReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIntakeCallReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldIntakeResolutionID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo IntakeResolutionID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIntakeResolutionID;
		protected System.Web.UI.WebControls.Literal sorgPath;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSORGID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtSorgPath;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForSORG;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit SORGId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSORGId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PlanName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanID;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForPlanID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PlanID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanID;
		protected System.Web.UI.WebControls.Image butClearSORGId;
		protected System.Web.UI.WebControls.Image butClearPlanID;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();
			}
			else
			{
				intakeLogSearcher = (IntakeLogSearcher)this.LoadObject("IntakeLogSearcher");  // load object from cache
			}
		}

		/// <summary>
		/// Called when the page is first loaded.
		/// </summary>
		/// <returns></returns>
		public bool LoadData()
		{
			bool result = true;
			try
			{
				// check if the patient search is called in the intake-log context.
				if (this.WasCancelled)
				{
					this.IntakeLogSearcher = (IntakeLogSearcher)this.LoadObject("IntakeLogSearcher", typeof(IntakeLogSearcher), true);	// if not in intakelog context, load the previous patient searcher
					result = this.SearchForIntakeLogs();
				}
				else
				{
					result = this.NewIntakeLogSearcher();
					if (!result)
						return false;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				result = false;
			}
			return result;
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("IntakeLogSearch.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			grid.ClickCellButton +=new ClickCellButtonEventHandler(grid_ClickCellButton);
			grid.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				toolbar.AddButton(PatientMessages.MessageIDs.NEWINTAKE, "NewIntake");
				toolbar.AddButton(PatientMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public IntakeLogCollection IntakeLogs
		{
			get { return intakeLogs; }
			set
			{
				intakeLogs = value;
				try
				{
					grid.KeepCollectionIndices = false;  // update given grid from the collection
					grid.UpdateFromCollection(intakeLogs);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(IntakeLogCollection), intakeLogs);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool SearchForIntakeLogs()
		{
			bool result = true;
			IntakeLogCollection intakeLogs = new IntakeLogCollection();
			try
			{
				if (!this.ReadControlsForIntakeLogSearcher()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				intakeLogs.Search(intakeLogSearcher);
				if (intakeLogs.Count >= IntakeLogCollection.MAXRECORDS)
					this.SetPageMessage("There are more then {0} records returned.  Please refine your search.", EnumPageMessageType.Warning, IntakeLogCollection.MAXRECORDS);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//intakeLogs.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.IntakeLogs = intakeLogs;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public IntakeLogSearcher IntakeLogSearcher
		{
			get { return intakeLogSearcher; }
			set
			{
				intakeLogSearcher = value;
				try
				{
					this.UpdateFromObject(pnlSearch.Controls, intakeLogSearcher);  // update controls for the given control collection

					if (this.intakeLogSearcher != null)
					{
						txtSorgPath.Text = this.CreateOrgPathHTML(null, this.intakeLogSearcher.SORG);
					}
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("IntakeLogSearcher", intakeLogSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForIntakeLogSearcher()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlSearch.Controls, intakeLogSearcher, false);	// controls-to-object
				// other control-to-object methods if any
				return true;
				//return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewIntakeLogSearcher()
		{
			bool result = true;
			IntakeLogSearcher intakeLogSearcher = null; //new IntakeLogSearcher(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				intakeLogSearcher = new IntakeLogSearcher();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.IntakeLogSearcher = intakeLogSearcher;
			this.IntakeLogs = null;
			return result;
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			this.SearchForIntakeLogs();
		}

		/* Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}*/

		public void OnToolbarButtonClick_NewIntake(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			IntakeForm.Redirect((IntakeLog)null, false);
		}

		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewIntakeLogSearcher();
		}

		private void grid_ClickCellButton(object sender, CellEventArgs e)
		{
			switch (e.Cell.Key)
			{
				case "Edit":
				{
					int id = grid.GetPKIntFromCellEvent(e);
					IntakeForm.Redirect(id, false);
					break;
				}
				case "Display":
				{
					int id = grid.GetPKIntFromCellEvent(e);
					IntakeForm.RedirectForDisplay(id, false);
					break;
				}
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			sorgPath.Text = "<span id='sorgPath'>" + txtSorgPath.Text + "</span>";
			this.butClearSORGId.Attributes["OnClick"] = "setSORGID(null, '')";
			this.butClearPlanID.Attributes["OnClick"] = "setPlanID(null, null)";
		}

		private void grid_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			grid.AddButtonColumn("Edit", "@EDIT@", 0).Width = 60;
			grid.AddButtonColumn("Display", "@DISPLAY@", 0).Width = 60;
		}
	}
}
