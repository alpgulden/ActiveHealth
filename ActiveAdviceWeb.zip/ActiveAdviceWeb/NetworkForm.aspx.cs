using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.NetworkMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Network,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(NetworkSearch))]
	[SelectedMainMenuItem("MProviderFacility")]
	[SelectedMenuItem("Networks")]
	[PageTitle("@NETWORKFORMTITLE@")]
	public class NetworkForm : ProviderBasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlBasicInfo;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusChangedByID;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DateActive;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateActive;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Gender;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGender;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit Beeper;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBeeper;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSuffixId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PrefixId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrefixId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBLabel NOblabel7;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridPlanDates;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridPlan;
	
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridNetworkFocuses;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveFocus;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddFocus;
		protected NetsoftUSA.InfragisticsWeb.WebGrid lstFocuses;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNetworkFocuses;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGPNote;
		protected NetsoftUSA.WebForms.OBLabel OBLabel11;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNetworkSpecialties;
		protected System.Web.UI.WebControls.ListBox lstNetworkSpecialties;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
	
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNetworks;
		protected NetsoftUSA.WebForms.OBLabel OBLabel12;
		
		
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkInfo1;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkInfo2;
		
		
		
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Suffix;
		protected NetsoftUSA.WebForms.OBLabel OBLabel15;
		
	
		
		
		protected NetsoftUSA.InfragisticsWeb.WebButton btnProceed;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFocusDate;
		protected System.Web.UI.HtmlControls.HtmlTable tblMain;
		protected System.Web.UI.HtmlControls.HtmlTable tblEffectiveDate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit AsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelGPDates;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebCombo NetworkFocusTypeID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel16;
		protected NetsoftUSA.InfragisticsWeb.WebCombo BoardStatus;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBoardStatus;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		
		protected System.Web.UI.HtmlControls.HtmlTable Table9;
		protected NetsoftUSA.WebForms.OBLabel OBLabel17;
		protected NetsoftUSA.WebForms.OBLabel lblGPLocs;
		protected NetsoftUSA.WebForms.OBLabel lblGPEffDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton WebButton1;
		protected NetsoftUSA.InfragisticsWeb.WebButton WebButton2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNetworkDate;
		protected System.Web.UI.HtmlControls.HtmlTable Table11;
		protected NetsoftUSA.WebForms.OBLabel OBLabel13;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit networkID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel14;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit NetworkName;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForSORG;
		protected NetsoftUSA.WebForms.OBLabel OBLabel18;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NetworkLocationID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNetworkLocationID;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkGP;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPLocations;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPEffectiveDates;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffDate;
	
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNetworkLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNetworkFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldBeeper;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit BeeperExtension;
		protected NetsoftUSA.WebForms.OBCheckBox PhysicianReview;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhysicianReview;
	
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGender;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkAddress;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFax;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fax;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFax;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNetworkInfo;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGPFocuses;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProviderFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnClose;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		private   int selectWidth				= 65;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNetworkID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NetworkID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNetworkID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.InfragisticsWeb.WebCombo TypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator3;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Email;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEmail;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldWebURL;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebURL;
		protected NetsoftUSA.WebForms.OBFieldLabel lbWebURL;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator4;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected System.Web.UI.HtmlControls.HtmlTable tblAddressInfo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator5;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacilityInfo;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridFacilityFocuses;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacilityFocuses;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityFocusTypeID;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacilityInfo1;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacilityInfo2;
		protected UserDefined UserDefined1;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel3;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator6;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel4;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit4;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator7;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProvider;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ProviderID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProviderID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProviderLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ProviderLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProviderLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ProviderName;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderDate;
		protected System.Web.UI.HtmlControls.HtmlTable tblProviderGP;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviderNetworkLocations;
		protected NetsoftUSA.WebForms.OBLabel GPOBLabel12;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGPNetworkLocations;
		protected NetsoftUSA.WebForms.OBLabel lblNetGPEffDates;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel6;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit5;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator8;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel7;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit6;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator9;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel8;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit7;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveNetGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelNetGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddNetGPDates;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGroupPractices;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPProviderGP;
		protected System.Web.UI.HtmlControls.HtmlTable Table2;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetworkGPEffectiveDates;
		protected NetsoftUSA.WebForms.OBLabel Oblabel4;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit GroupPracticeID;
		protected NetsoftUSA.WebForms.WindowOpener Windowopener1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGroupPracticeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGroupPracticeLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit GroupPracticeLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGroupPracticeLocationID;
		protected NetsoftUSA.WebForms.OBLabel Oblabel5;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit GroupPracticeName;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel9;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit8;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator10;
		protected NetsoftUSA.InfragisticsWeb.WebButton GPWebButton2;
		protected NetsoftUSA.InfragisticsWeb.WebButton GPWebButton1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGroupPracticeDate;
		protected System.Web.UI.HtmlControls.HtmlTable Table7;
		protected NetsoftUSA.WebForms.OBLabel NetOblabel2;
		protected System.Web.UI.HtmlControls.HtmlTable tblNetGPDates;
		protected NetsoftUSA.WebForms.OBLabel OBLabel12FAC;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridFacility;
		protected NetsoftUSA.WebForms.OBLabel lblFacLocs;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridFacilityLocations;
		protected NetsoftUSA.WebForms.OBLabel lblFacEffDates;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridFacDates;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel10;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit9;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator11;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel11;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit10;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel12;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit11;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveFacDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelFacDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddFacDates;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacility;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPlan;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPlanDate;
		protected NetsoftUSA.WebForms.OBLabel FacOblabel2;
		protected NetsoftUSA.WebForms.OBLabel Oblabel2;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit FacilityID;
		protected NetsoftUSA.WebForms.WindowOpener Windowopener2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFacilityLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit FacilityLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityLocationID;
		protected NetsoftUSA.WebForms.OBLabel Oblabel6;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FacilityName;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel13;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit12;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator13;
		protected NetsoftUSA.InfragisticsWeb.WebButton FacWebButton2;
		protected NetsoftUSA.InfragisticsWeb.WebButton FacWebButton1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacilityDate;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacility;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacilityLoc;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacEffectiveDates;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacDates;
		protected System.Web.UI.HtmlControls.HtmlTable Table3;
		protected NetsoftUSA.WebForms.OBLabel lblPLanEffDates;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel14;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit13;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator12;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel15;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit14;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator14;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel16;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit15;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSavePlanDates;
		protected NetsoftUSA.WebForms.OBLabel PlanOblabel2;
		protected NetsoftUSA.WebForms.OBLabel Oblabel7;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PlanID;
		protected NetsoftUSA.WebForms.WindowOpener Windowopener3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanID;
		protected NetsoftUSA.WebForms.OBLabel Oblabel10;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PlanDescription;
		protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel17;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit Webdatetimeedit16;
		protected NetsoftUSA.InfragisticsWeb.WebValidator Webvalidator15;
		protected NetsoftUSA.InfragisticsWeb.WebButton PlanWebButton2;
		protected NetsoftUSA.InfragisticsWeb.WebButton PlanWebButton1;
		protected System.Web.UI.HtmlControls.HtmlTable Table10;
		protected System.Web.UI.HtmlControls.HtmlTable tblPlanEffectiveDates;
		protected System.Web.UI.HtmlControls.HtmlTable tblPlanDates;
		protected System.Web.UI.HtmlControls.HtmlTable PlanTable3;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProvider;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProviderDates;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGP;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGPDates;
		protected AddressControl AddressControl;

		private ProviderLocationNetworkSummaryCollection provLocNetworkCol;
		private FacilityLocationNetworkSummaryCollection facilityLocNetworkCol;
		private GroupPracticeLocationNetworkSummaryCollection groupPracticeLocNetworkCol;
	
		private ProviderLocationNetworkLink selectedNetworkProviderLocLink;
		
		private GroupPracticeLocationNetworkLink selectedNetworkGroupPracticeLocLink;
		
		private FacilityLocationNetworkLink selectedNetworkFacilityLocLink;
		
		private ProviderLocationNetworkHistoryCollection provLocDates;

		private FacilityLocationNetworkHistoryCollection facilityLocDates;

		private GroupPracticeLocationNetworkHistoryCollection gpLocDates;

		private NetworkPlanHistoryCollection planDates;

		private NetworkPlanLink selectedNetworkPlan;

		private Network network;
			
		private Address selectedNetworkAddress;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelPlanDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddPlanDates;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator16;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPreferenceLevel;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PreferenceLevel;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPreferenceLevel;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNote;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel18;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnNextProvider;
		protected System.Web.UI.HtmlControls.HtmlAnchor linkURL;
		private NetworkFocus selectedNetworkFocus;

		// used for paging
		private int startID = 0;
		private string startFirstName = "";
		private string startLastName = "";
		protected NetsoftUSA.InfragisticsWeb.WebButton btnNextFacility;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnGroupPracticeNext;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		private string startName = "";

		
		
		#region network
		private void Page_Load(object sender, System.EventArgs e)
		{
			UserDefined1.ReloadContext("Network",network,true);
			if(!UserDefined1.HasFields())
				this.PageTab.GetTab("UserDefined").Visible = false;
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
				}
			else
			{
				network = (Network)this.LoadObject("networkObj");
			
				selectedNetworkFocus = (NetworkFocus)this.LoadObject("selectedFocus");  // load object from cache

				selectedNetworkProviderLocLink = (ProviderLocationNetworkLink)this.LoadObject("selectedNetworkProviderLink");  // load object from cache

				selectedNetworkGroupPracticeLocLink = (GroupPracticeLocationNetworkLink)this.LoadObject("selectedNetworkGroupPracticeLocLink");  // load object from cache

				selectedNetworkFacilityLocLink = (FacilityLocationNetworkLink)this.LoadObject("selectedNetworkFacility");  // load object from cache

				selectedNetworkPlan = (NetworkPlanLink)this.LoadObject("selectedNetworkPlan");  // load object from cache

				if (network != null)
					this.AddressControl.Address = network.Address ;
			}
		
		}


		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(int NetworkID)
		{
			Network Network = new Network();
			if (NetworkID != 0)
				Network.Load(NetworkID);
			else
				Network.New();
			BasePage.PushParam("networkObj",Network);
			BasePage.Redirect("NetworkForm.aspx");
		}

		public static void Redirect(Network Network)
		{
			BasePage.PushParam("networkObj",Network);
			BasePage.Redirect("NetworkForm.aspx");
		}


		public bool LoadData()
		{
			bool result = true;
			// get the parameter
			Network network = null;
			
			try
			{	// use any load method here
				network = this.GetParamOrGetFromCache("networkObj","networkObj") as Network ;
				//StatusChangedByStr.Value = "1";
				//selectedLocation = this.GetParamOrGetFromCache("locationObj","locationObj") as Location ;
		
				if (network == null)
				{
					return NewNetwork();
				}

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//GP.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			network.Load(network.NetworkID);
			

			if (network.NetworkID == 0)
				network.New();
			network.LoadFocuses(false);
		
			this.Network = network;
			return result;
		}


		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewNetwork()
		{
			bool result = true;
			Network net = new Network(true); // use a parameterized constructor which also initializes the data object
			try
			{
				net.LoadFocuses(true);
				// or use an initialization method here
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Network = net;
			return result;
		}
		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@SAVE@", "Save",true, false);
			toolbar.AddButton("@CANCEL@", "Cancel", false, true);
			
		}
		
		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if ( SaveData())			
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@NETWORK@");
		}
		
//		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
//		{
//			NetworkSearch.Redirect();
//		}
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.network);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			
			this.RenderClientFunctions(pnlFocusDate.Controls, SelectedNetworkFocus, "OnFocusDateValidation");
			
		
			
			this.RenderClientFunctions(tblNetworkInfo2.Controls, network, "OnNetworkDateValidation");

			this.RenderClientFunctions(tblGPDates.Controls, new ProviderLocationNetworkHistory(), "OnProvNetworkDateValidation");

			this.RenderClientFunctions(tblNetGPDates.Controls, new  GroupPracticeLocationNetworkHistory(), "OnGPNetworkDateValidation");

			this.RenderClientFunctions(tblFacDates.Controls, new FacilityLocationNetworkHistory(), "OnFacNetworkDateValidation");

			this.RenderClientFunctions(this.tblPlanDates.Controls,new NetworkPlanHistory(),"OnPlanNetworkDateVaildation");

		}
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Network Network
		{
			get { return network; }
			set
			{
				network = value;
				try
				{
					this.pnlProviderDate.Visible = false;
					this.tblGPDates.Visible = false;
					//Network.LoadLanguages();
					this.pnlGroupPracticeDate.Visible = false;
					this.tblNetGPDates.Visible = false;
					//network.LoadLocations(true);
					
					this.pnlFacilityDate.Visible = false;
					this.tblFacDates.Visible = false;
					this.tblPlanDates.Visible =false;
					this.pnlPlanDate.Visible = false;

					this.UpdateFromObject(this.tblNetworkInfo1.Controls, network );  // update controls for the given control collection
					this.UpdateFromObject(this.tblNetworkInfo2.Controls, network );  // update controls for the given control collection
					
					this.UpdateFromObject(this.tblAddressInfo.Controls, network.Address );
					// Bind Active Network Focuses

					this.lstFocuses.UpdateFromCollection(NetworkFocusTypeCollection.ActiveNetworkFocusTypes);
					this.UpdateFromObject(this.pnlGPNote.Controls,network );
					
					if (lstFocuses.Rows.Count > 0)
						lstFocuses.SelectedRowIndex = 0;
					
					this.gridNetworkFocuses.UpdateFromCollection(Network.Focuses);
					this.network.LoadProviderNetworkLinks(false);
					this.network.LoadProviders(ProviderLocationNetworkLinkCollection.MAXRECORDS, startID, startFirstName, startLastName);

					this.network.LoadGroupPracticeNetworkLinks(false);
					this.network.LoadGroupPractices(GroupPracticeLocationNetworkLinkCollection.MAXRECORDS, startID, startName);
					
					this.network.LoadFacilityNetworkLinks(false);
					this.network.LoadFacilities(FacilityLocationNetworkLinkCollection.MAXRECORDS, startID, startName);

					this.gridProvider.UpdateFromCollection(Network.Providers);
					btnNextProvider.Enabled = Network.Providers.Count >= ProviderLocationNetworkLinkCollection.MAXRECORDS;
				

					this.gridGP.UpdateFromCollection(Network.GroupPractices);
					btnGroupPracticeNext.Enabled = Network.GroupPractices.Count >= GroupPracticeLocationNetworkLinkCollection.MAXRECORDS;

					this.gridFacility.UpdateFromCollection(Network.Facilities);
					btnNextFacility.Enabled = Network.Facilities.Count >= FacilityLocationNetworkLinkCollection.MAXRECORDS;


					if (this.gridProvider.Rows.Count > 0)
					{
						UpdateProviderRelatedInfo();
					}
					else
						this.btnAddGPDates.Enabled = false;

					if (this.gridGP.Rows.Count > 0)
					{
						UpdateGroupPracticeRelatedInfo();
					}
					else
						this.btnAddNetGPDates.Enabled = false;
				
					if (this.gridFacility.Rows.Count > 0)
					{
						UpdateFacilityRelatedInfo();
					}
					else
						this.btnAddFacDates.Enabled= false;

					if (gridNetworkFocuses.Rows.Count > 0)
						gridNetworkFocuses.SelectedRowIndex = 0;
			

					this.pnlFocusDate.Visible = false;

					network.LoadPlanNetworkLinks(false);
					NetworkPlanSummaryCollection networkPlanSummaryCol = new NetworkPlanSummaryCollection();
					networkPlanSummaryCol.LoadPlanNetworkSummary(-1,this.network.NetworkID);

					this.gridPlan.UpdateFromCollection(networkPlanSummaryCol);
					if(gridPlan.Rows.Count > 0)
					{
						gridPlan.SelectedRowIndex = 0;
						int networkPlanID = (int) gridPlan.SelectedRowPK[0];

						NetworkPlanLink planLink = new NetworkPlanLink();
						planLink.Load(networkPlanID);
						planLink.LoadEffectiveDatesHistory(false);
						this.gridPlanDates.UpdateFromCollection(planLink.EffectiveDatesHistory);
					}
					else
						this.btnAddPlanDates.Enabled = false;
					UserDefined1.ReloadContext("Network",network,false);
					SetButtonsEnabled();
					
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("networkObj", Network);  // cache object using the caching method declared on the page
			}
		}

		private void UpdateGroupPracticeRelatedInfo()
		{
			this.gridGP.SelectedRowIndex = 0;
			int gpID = (int) gridGP.SelectedRowPK[0];
			GroupPracticeLocationNetworkSummaryCollection col = new GroupPracticeLocationNetworkSummaryCollection();
			col.LoadGroupPracticeLocationNetworkSummary(-1,gpID,this.network.NetworkID);
			this.GPLocNetworkCol = col;

			this.gridGPNetworkLocations.SelectedRowIndex = 0;
			int gpLocNetworkID = (int)gridGPNetworkLocations.SelectedRowPK[0];
			GroupPracticeLocationNetworkLink provNetworkLink = new GroupPracticeLocationNetworkLink();
			provNetworkLink.Load(gpLocNetworkID);
			provNetworkLink.LoadEffectiveDatesHistory(true);
			this.GpLocDates = provNetworkLink.EffectiveDatesHistory;
		}
		private void UpdateProviderRelatedInfo()
		{
			this.gridProvider.SelectedRowIndex = 0;
			int provID = (int)gridProvider.SelectedRowPK[0];
			ProviderLocationNetworkSummaryCollection col = new ProviderLocationNetworkSummaryCollection();
			col.LoadProviderLocationNetworkSummary(-1,provID,this.network.NetworkID);
					 
			this.ProvLocNetworkCol = col;
						
			this.gridProviderNetworkLocations.SelectedRowIndex = 0;
			int provLocNetworkLinkID = (int)this.gridProviderNetworkLocations.SelectedRowPK[0];
			ProviderLocationNetworkLink provNetworkLink = new ProviderLocationNetworkLink();
			provNetworkLink.Load(provLocNetworkLinkID);				
			provNetworkLink.LoadEffectiveDatesHistory(true);
					
			this.ProvLocDates = provNetworkLink.EffectiveDatesHistory;
			//gridProviderDates.UpdateFromCollection(this.ProvLocNetworkCol);
		}


		private void SetButtonsEnabled()
		{
			this.btnRemoveFocus.Enabled = (this.gridNetworkFocuses.Rows.Count > 0);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			if (tab.Key == "Network")
			{
				//toolbar.AddButton("@LOCATIONS@", "Locations");
				//if (this.Network.NetworkID == 0)
				//	this.SetPageTabToolbarItemEnabled("Locations", false);
				toolbar.AddButton("@CONTACTS@", "Contacts");
			}
			else if (tab.Key == "Provider")
			{
				toolbar.AddButton("@ADDNEWRECORD@","AddProvider");
				//toolbar.AddButton("@DELETE@","DeleteGP");
				if (this.Network.NetworkID == 0)
				{
					this.SetPageTabToolbarItemEnabled("AddProvider",false);
					//this.SetPageTabToolbarItemEnabled("DeleteGP",false);
					this.pnlProvider.Enabled = false;
				}
			}
			else if (tab.Key == "GroupPractice")
			{
				toolbar.AddButton("@ADDNEWRECORD@","AddGP");
				//toolbar.AddButton("@DELETE@","DeleteGP");
				if (this.Network.NetworkID == 0)
				{
					this.SetPageTabToolbarItemEnabled("AddGP",false);
					//this.SetPageTabToolbarItemEnabled("DeleteGP",false);
					this.pnlGroupPractices.Enabled = false;
				}
			}
			else if (tab.Key == "Facility")
			{
				toolbar.AddButton("@ADDNEWRECORD@","AddFACILITY");
				//toolbar.AddButton("@DELETE@","DeleteGP");
				if (this.Network.NetworkID == 0)
				{
					this.SetPageTabToolbarItemEnabled("AddFACILITY",false);
					//this.SetPageTabToolbarItemEnabled("DeleteGP",false);
					this.pnlFacility.Enabled = false;
				}
			}
			else if (tab.Key == "Plan")
			{
				toolbar.AddButton("@ADDNEWRECORD@","AddPlan");
				//toolbar.AddButton("@DELETE@","DeleteGP");
				if (this.Network.NetworkID == 0)
				{
					this.SetPageTabToolbarItemEnabled("AddPlan",false);
					//this.SetPageTabToolbarItemEnabled("DeleteGP",false);
					this.pnlPlan.Enabled = false;
				}
			}
		}

			
		
		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForNetwork()
		{
			try
			{	//customize this method for this specific page
				
				this.UpdateToObject(this.pnlGPNote.Controls, this.network);
				this.UpdateToObject(this.tblNetworkInfo1.Controls, this.network );	// controls-to-object
				this.UpdateToObject(this.tblNetworkInfo2.Controls, this.network );	// controls-to-object
				//this.UpdateToObject(this.tblNetworkInfoTax.Controls, selectedLocation );
				this.UpdateToObject(this.tblAddressInfo.Controls, this.network.Address );
				UserDefined1.UserDefinedValue=network.UserDefined;
				UserDefined1.ReadControls();
				
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private bool SaveData()
		{
			if (this.ReadControlsForNetwork())
			{
				try
				{
					//if (!this.Network.IsNew)
					//this.Network.Locations[0].MarkDirty();
					//this.Network.StatusChangedBy = 1;
					
					this.Network.Save ();
					
					// Enable Provider , Group Practices , Facility and plan button 
					this.SetPageTabToolbarItemEnabled("AddProvider",true);
					this.pnlProvider.Enabled = true;
					
					this.SetPageTabToolbarItemEnabled("AddGP",true);
					this.pnlGroupPractices.Enabled = true;
					
					this.SetPageTabToolbarItemEnabled("AddFACILITY",true);
					this.pnlFacility.Enabled = true;

					this.SetPageTabToolbarItemEnabled("AddPlan",true);
					this.pnlPlan.Enabled = true;

					this.Network = network;
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
					return false;
				}
				return true;
			}
			else
				return false;
				

		}
		public Address SelectedNetworkAddress
		{
			get { return selectedNetworkAddress; }
			set
			{
				selectedNetworkAddress = value;
				try
				{
					//this.UpdateFromObject(this.tblNetworkAddress.Controls,selectedNetworkAddress );  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("NetworkAddress", selectedNetworkAddress);  // cache object using the caching method declared on the page
			}
		}


		#endregion
		
		
		#region focus
		private void btnAddFocus_Click(object sender, System.EventArgs e)
		{
			
			if (lstFocuses.SelectedRowIndex >= 0)
			{
				bool			resume			= true;
				NetworkFocus	provFocCompare	= null;
				int selectedTypeID = (int)lstFocuses.SelectedRowPK[0];	

				if (selectedTypeID != 0)
				{
					if (Network.Focuses != null)
					{
						for (int i = 0; i < this.Network.Focuses.Count; i++)
						{
							provFocCompare		= Network.Focuses[i];
							if (selectedTypeID == provFocCompare.NetworkFocusTypeID && provFocCompare.TerminationDate == DateTime.MinValue)
							{
								resume = false;
								break;
							}
						}
					}
					else
						Network.Focuses = new NetworkFocusCollection();

					if (resume)
					{
						NetworkFocus provFoc		= new NetworkFocus();
						provFoc.New();
						provFoc.EffectiveDate		= DateTime.Today.Date;
						provFoc.NetworkFocusTypeID = selectedTypeID;
						provFoc.NetworkID			= this.Network.NetworkID;
						this.SelectedNetworkFocus  = provFoc;
						
						// show the panel
						SetFocusDatesVisible(true, false);
						pnlFocusDate.Visible = true;
					}
				}
			}
			else
				this.SetPageMessage("@SELECTFOCUS@", NetsoftUSA.WebForms.EnumPageMessageType.Warning);
	
		}
		

		private void SetFocusDatesVisible(bool effAndFocus, bool termDate)
		{
			this.TerminationDate.Enabled		= termDate;
			this.OBFieldLabel1.Enabled			= termDate;
			this.EffectiveDate.Enabled			= effAndFocus;
			this.OBLabel16.Enabled				= effAndFocus;
			this.OBFieldLabel2.Enabled			= effAndFocus;			
			this.NetworkFocusTypeID.Enabled	= effAndFocus;
		}


		
		private void btnRemoveFocus_Click(object sender, System.EventArgs e)
		{
			if (gridNetworkFocuses.SelectedRowIndex >= 0)
			{
				this.SelectedNetworkFocus = Network.Focuses[gridNetworkFocuses.SelectedColectionIndex];
				this.SetFocusDatesVisible(false, true);
				this.pnlFocusDate.Visible = true;
			}

		}
		
		private void RemoveFocus()
		{
			if (this.SelectedNetworkFocus != null)
			{
				//Network.Focuses.Remove(this.SelectedNetworkFocus);
				this.SelectedNetworkFocus = null;

				//this.gridNetworkFocuses.UpdateFromCollection(Network.Focuses);
				
				if (gridNetworkFocuses.Rows.Count > 0)
					gridNetworkFocuses.SelectedRowIndex = 0;
				SetButtonsEnabled();
			}
		}

		
		


		/// <summary>
		///  Adds / Updates a focus based on effective dates.
		/// </summary>
		private void AddFocus()
		{
			if (this.SelectedNetworkFocus != null)
			{
				this.Network.Focuses.Add(this.SelectedNetworkFocus);	
				this.gridNetworkFocuses.UpdateFromCollection(this.Network.Focuses);
				this.SelectedNetworkFocus = null;
				SetButtonsEnabled();
			}
		}

		private void TerminateFocus()
		{
			if (SelectedNetworkFocus != null)
			{
				try
				{

					NetworkFocus currentFocus = Network.Focuses[gridNetworkFocuses.GetColIndexFromRowIndex(gridNetworkFocuses.SelectedRowIndex)];
					currentFocus.TerminationDate = this.SelectedNetworkFocus.TerminationDate;
					SelectedNetworkFocus = null;
					this.gridNetworkFocuses.UpdateFromCollection(Network.Focuses);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				finally
				{
					this.gridNetworkFocuses.UpdateFromCollection(this.Network.Focuses);
					SetButtonsEnabled();
				}
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public NetworkFocus SelectedNetworkFocus
		{
			get { return selectedNetworkFocus; }
			set
			{
				selectedNetworkFocus = value;
				try
				{
					this.UpdateFromObject(this.tblEffectiveDate.Controls , selectedNetworkFocus);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedFocus", selectedNetworkFocus);  // cache object using the caching method declared on the page
			}
		}

		public bool ReadControlsForSelectedNetworkFocus()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlFocusDate.Controls, selectedNetworkFocus);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private void btnProceed_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.UpdateToObject(this.tblEffectiveDate.Controls, this.SelectedNetworkFocus);
				
				this.SelectedNetworkFocus.CreateTime = DateTime.Now;

				if (this.NetworkFocusTypeID.Enabled)
					this.AddFocus();
				else
					this.TerminateFocus();
				
				
				this.pnlFocusDate.Visible = false;
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}

		}

		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.SelectedNetworkFocus = null;
			this.pnlFocusDate.Visible = false;
		}

		private void lstFocuses_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "State")
				lstFocuses.SelectedRowIndex = e.Cell.Row.Index;
		}

	
		
		#endregion

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			this.btnAddFocus.Click += new System.EventHandler(this.btnAddFocus_Click);
			this.btnRemoveFocus.Click += new System.EventHandler(this.btnRemoveFocus_Click);
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.lstFocuses.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.lstFocuses_ClickCellButton);
			this.btnRemoveFocus.Click += new System.EventHandler(this.btnRemoveFocus_Click);
			this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
			this.gridProvider.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridProvider_ClickCellButton_1);
			this.gridProvider.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridProvider_ColumnsBoundToDataClass);
			this.btnNextProvider.Click += new System.EventHandler(this.btnNextProvider_Click);
			this.gridProviderNetworkLocations.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridProviderNetworkLocations_ClickCellButton_1);
			this.gridProviderNetworkLocations.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridProviderNetworkLocations_ColumnsBoundToDataClass);
			this.btnSaveGPDates.Click += new System.EventHandler(this.btnSaveGPDates_Click);
			this.btnCancelGPDates.Click += new System.EventHandler(this.btnCancelGPDates_Click);
			this.btnAddGPDates.Click += new System.EventHandler(this.btnAddGPDates_Click);
			this.gridGP.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridGP_ClickCellButton_1);
			this.gridGP.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridGP_ColumnsBoundToDataClass);
			this.btnGroupPracticeNext.Click += new System.EventHandler(this.btnGroupPracticeNext_Click);
			this.gridGPNetworkLocations.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridGPNetworkLocations_ClickCellButton_1);
			this.gridGPNetworkLocations.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridGPNetworkLocations_ColumnsBoundToDataClass);
			this.btnSaveNetGPDates.Click += new System.EventHandler(this.btnSaveNetGPDates_Click);
			this.btnCancelNetGPDates.Click += new System.EventHandler(this.btnCancelNetGPDates_Click);
			this.btnAddNetGPDates.Click += new System.EventHandler(this.btnAddNetGPDates_Click);
			this.gridFacility.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridFacility_ClickCellButton_1);
			this.gridFacility.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridFacility_ColumnsBoundToDataClass);
			this.btnNextFacility.Click += new System.EventHandler(this.btnNextFacility_Click);
			this.gridFacilityLocations.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridFacilityLocations_ClickCellButton_1);
			this.gridFacilityLocations.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridFacilityLocations_ColumnsBoundToDataClass);
			this.btnSaveFacDates.Click += new System.EventHandler(this.btnSaveFacDates_Click);
			this.btnCancelFacDates.Click += new System.EventHandler(this.btnCancelFacDates_Click);
			this.btnAddFacDates.Click += new System.EventHandler(this.btnAddFacDates_Click);
			this.gridPlan.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridPlan_ClickCellButton);
			this.gridPlan.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridPlan_ColumnsBoundToDataClass);
			this.btnSavePlanDates.Click += new System.EventHandler(this.btnSavePlanDates_Click);
			this.btnCancelPlanDates.Click += new System.EventHandler(this.btnCancelPlanDates_Click);
			this.btnAddPlanDates.Click += new System.EventHandler(this.btnAddPlanDates_Click);
			this.GPWebButton2.Click += new System.EventHandler(this.GPWebButton2_Click);
			this.GPWebButton1.Click += new System.EventHandler(this.GPWebButton1_Click);
			this.WebButton2.Click += new System.EventHandler(this.WebButton2_Click);
			this.WebButton1.Click += new System.EventHandler(this.WebButton1_Click);
			this.FacWebButton2.Click += new System.EventHandler(this.FacWebButton2_Click);
			this.FacWebButton1.Click += new System.EventHandler(this.FacWebButton1_Click);
			this.PlanWebButton2.Click += new System.EventHandler(this.PlanWebButton2_Click);
			this.PlanWebButton1.Click += new System.EventHandler(this.PlanWebButton1_Click);
			this.ValidationsOnlyInSummary = true;
			this.ViewStateOnServer = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private bool AddProviderLink()
		{
		
			bool resume = false;
			if (this.selectedNetworkProviderLocLink != null)
			{
				if (this.selectedNetworkProviderLocLink.EffectiveDate != DateTime.MinValue) // add 
				{
					resume = true;
					selectedNetworkProviderLocLink.CreatedBy  = 1; // Context.UserID
					selectedNetworkProviderLocLink.CreateTime = DateTime.Now;
					selectedNetworkProviderLocLink.NetworkID = this.Network.NetworkID;
					
					// check if ID already exists if it does then show a message to the user
					for (int i=0; i < Network.ProviderNetworkLinks.Count; i++)
					{
						if (SelectedNetworkProviderLocLink.ProviderLocationID == Network.ProviderNetworkLinks[i].ProviderLocationID)
						{
							resume = false;
							break;
						}
					}
					if (resume)
					{
						try
						{
							this.Network.ProviderNetworkLinks.Add(SelectedNetworkProviderLocLink);
							this.Network.ProviderNetworkLinks.Save();
							this.SelectedNetworkProviderLocLink.LoadEffectiveDatesHistory(true); 

							ProviderLocationNetworkHistory currentDate = new ProviderLocationNetworkHistory();
							currentDate.New();
							currentDate.AsOfDate					= DateTime.Now;
							currentDate.EffectiveDate				= this.SelectedNetworkProviderLocLink.EffectiveDate;
							currentDate.TerminationDate				= this.SelectedNetworkProviderLocLink.TerminationDate;
							currentDate.Active						= this.SelectedNetworkProviderLocLink.Active ;
							currentDate.ProviderLocationNetworkID 	= this.SelectedNetworkProviderLocLink.ProviderLocationNetworkID ;
					
							this.SelectedNetworkProviderLocLink.EffectiveDatesHistory.InsertRecord(0,currentDate);
							this.SelectedNetworkProviderLocLink.EffectiveDatesHistory.Save();
			
							// update the grids
							this.network.LoadProviders(ProviderLocationNetworkLinkCollection.MAXRECORDS, startID, startFirstName, startLastName);
							this.gridProvider.UpdateFromCollection(Network.Providers);
							btnNextProvider.Enabled = Network.Providers.Count >= ProviderLocationNetworkLinkCollection.MAXRECORDS;
							
	
							if (this.gridProvider.Rows.Count > 0)
							{
								this.gridProvider.SelectedRowIndex = 0;
								int provID = (int)gridProvider.SelectedRowPK[0];
								ProviderLocationNetworkSummaryCollection col = new ProviderLocationNetworkSummaryCollection();
								col.LoadProviderLocationNetworkSummary(-1,provID,this.network.NetworkID);
					 
								this.ProvLocNetworkCol = col;
						
								this.gridProviderNetworkLocations.SelectedRowIndex = 0;
								int provLocNetworkLinkID = (int)this.gridProviderNetworkLocations.SelectedRowPK[0];
								ProviderLocationNetworkLink provNetworkLink = new ProviderLocationNetworkLink();
								provNetworkLink.Load(provLocNetworkLinkID);				
								provNetworkLink.LoadEffectiveDatesHistory(true);
					
								this.ProvLocDates = provNetworkLink.EffectiveDatesHistory;
								this.btnAddGPDates.Enabled = true;
							}

							this.SelectedNetworkProviderLocLink = null;
							this.pnlProviderDate.Visible = false;
						}
						catch(Exception ex)
						{
							this.RaisePageException(ex);
						}
					}
					else
						this.SetPageMessage("@PROVEXISTS@", NetsoftUSA.WebForms.EnumPageMessageType.Error);
				}
			}
			return resume;
		}

		private bool AddFacilityLink()
		{
			bool resume = false;
			if (this.SelectedNetworkFacilityLocLink != null)
			{
				if (this.SelectedNetworkFacilityLocLink.EffectiveDate != DateTime.MinValue) // add 
				{
					resume = true;
					//SelectedNetworkFacilityLocLink.CreatedBy  = 1; // Context.UserID
					//SelectedNetworkFacilityLocLink.CreateTime = DateTime.Now;
					SelectedNetworkFacilityLocLink.NetworkID = this.Network.NetworkID;
					
					// check if ID already exists if it does then show a message to the user
					for (int i=0; i < Network.FacilityNetworkLinks.Count; i++)
					{
						if (SelectedNetworkFacilityLocLink.FacilityLocationID == Network.FacilityNetworkLinks[i].FacilityLocationID)
						{
							resume = false;
							break;
						}
					}
					if (resume)
					{
						this.Network.FacilityNetworkLinks.Add(SelectedNetworkFacilityLocLink);
						this.Network.FacilityNetworkLinks.Save();
						this.SelectedNetworkFacilityLocLink.LoadEffectiveDatesHistory(true); 

						FacilityLocationNetworkHistory currentDate = new FacilityLocationNetworkHistory();
						currentDate.New();
						currentDate.AsOfDate					= DateTime.Now;
						currentDate.EffectiveDate				= this.SelectedNetworkFacilityLocLink.EffectiveDate;
						currentDate.TerminationDate				= this.SelectedNetworkFacilityLocLink.TerminationDate;
						currentDate.Active						= this.SelectedNetworkFacilityLocLink.Active ;
						currentDate.FacilityLocationNetworkID 	= this.SelectedNetworkFacilityLocLink.FacilityLocationNetworkID ;
					
						this.SelectedNetworkFacilityLocLink.EffectiveDatesHistory.InsertRecord(0,currentDate);
						this.SelectedNetworkFacilityLocLink.EffectiveDatesHistory.Save();
						this.network.LoadFacilities(FacilityLocationNetworkLinkCollection.MAXRECORDS, startID, startName);
						this.gridFacility.UpdateFromCollection(Network.Facilities);
						if (this.gridFacility.Rows.Count > 0)
						{
							this.gridFacility.SelectedRowIndex = 0;
							int facilityID = (int) gridFacility.SelectedRowPK[0];
							FacilityLocationNetworkSummaryCollection col = new FacilityLocationNetworkSummaryCollection();
							col.LoadFacilityLocationNetworkSummary(-1,facilityID,this.network.NetworkID);
							this.FacLocNetworkCol= col;
						 
							this.gridFacilityLocations.SelectedRowIndex = 0;
							int facilityLocNetworkID = (int) gridFacilityLocations.SelectedRowPK[0];
							FacilityLocationNetworkLink facNetworkLink =  new FacilityLocationNetworkLink();
							facNetworkLink.Load(facilityLocNetworkID);
							facNetworkLink.LoadEffectiveDatesHistory(true);
							this.FacilityLocDates = facNetworkLink.EffectiveDatesHistory;
							this.btnAddFacDates.Enabled = true;
						}
						this.SelectedNetworkFacilityLocLink = null;
						this.pnlFacilityDate.Visible = false;
					}
					else
						this.SetPageMessage("@FACEXISTS@", NetsoftUSA.WebForms.EnumPageMessageType.Error);
				}
			}
			return resume;
		}

		private bool AddGroupPracticeLink()
		{
		
			bool resume = false;
			if (this.SelectedNetworkGroupPracticeLocLink != null)
			{
				if (this.SelectedNetworkGroupPracticeLocLink.EffectiveDate != DateTime.MinValue) // add 
				{
					resume = true;
					SelectedNetworkGroupPracticeLocLink.CreatedBy  = 1; // Context.UserID
					SelectedNetworkGroupPracticeLocLink.CreateTime = DateTime.Now;
					SelectedNetworkGroupPracticeLocLink.NetworkID = this.Network.NetworkID;
					
					// check if ID already exists if it does then show a message to the user
					for (int i=0; i < Network.GroupPracticeNetworkLinks.Count; i++)
					{
						if (SelectedNetworkGroupPracticeLocLink.GroupPracticeLocationID == Network.GroupPracticeNetworkLinks[i].GroupPracticeLocationID)
						{
							resume = false;
							break;
						}
					}
					if (resume)
					{
						this.Network.GroupPracticeNetworkLinks.Add(SelectedNetworkGroupPracticeLocLink);
						this.Network.GroupPracticeNetworkLinks.Save();
						this.SelectedNetworkGroupPracticeLocLink.LoadEffectiveDatesHistory(true); 

						GroupPracticeLocationNetworkHistory currentDate = new GroupPracticeLocationNetworkHistory();
						currentDate.New();
						currentDate.AsOfDate					= DateTime.Now;
						currentDate.EffectiveDate				= this.SelectedNetworkGroupPracticeLocLink.EffectiveDate;
						currentDate.TerminationDate				= this.SelectedNetworkGroupPracticeLocLink.TerminationDate;
						currentDate.Active						= this.SelectedNetworkGroupPracticeLocLink.Active ;
						currentDate.GroupPracticeLocationNetworkID 	= this.SelectedNetworkGroupPracticeLocLink.GroupPracticeLocationNetworkID ;
					
						this.SelectedNetworkGroupPracticeLocLink.EffectiveDatesHistory.InsertRecord(0,currentDate);
						this.SelectedNetworkGroupPracticeLocLink.EffectiveDatesHistory.Save();
						this.network.LoadGroupPractices(GroupPracticeLocationNetworkLinkCollection.MAXRECORDS, startID, startName);
					
						this.gridGP.UpdateFromCollection(Network.GroupPractices);
						if (this.gridGP.Rows.Count > 0)
						{
							this.gridGP.SelectedRowIndex = 0;
							int gpID = (int) gridGP.SelectedRowPK[0];
							GroupPracticeLocationNetworkSummaryCollection col = new GroupPracticeLocationNetworkSummaryCollection();
							col.LoadGroupPracticeLocationNetworkSummary(-1,gpID,this.network.NetworkID);
							this.GPLocNetworkCol = col;

							this.gridGPNetworkLocations.SelectedRowIndex = 0;
							int gpLocNetworkID = (int)gridGPNetworkLocations.SelectedRowPK[0];
							GroupPracticeLocationNetworkLink provNetworkLink = new GroupPracticeLocationNetworkLink();
							provNetworkLink.Load(gpLocNetworkID);
							provNetworkLink.LoadEffectiveDatesHistory(true);
							this.GpLocDates = provNetworkLink.EffectiveDatesHistory;
							this.btnAddNetGPDates.Enabled = true;
						}
						this.SelectedNetworkGroupPracticeLocLink = null;
						this.pnlGroupPracticeDate.Visible = false;
					}
					else
						this.SetPageMessage("@GPEXISTS@", NetsoftUSA.WebForms.EnumPageMessageType.Error);
				}
			}
			return resume;
		}
		public void OnToolbarButtonClick_AddProvider(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.SelectedNetworkProviderLocLink = new ProviderLocationNetworkLink();
			this.SelectedNetworkProviderLocLink.New();

			//SetGroupPracticeGridsVisible(false); // disable the tabs
			this.pnlProviderDate.Visible = true;
			
		}
		public void OnToolbarButtonClick_AddGP(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.SelectedNetworkGroupPracticeLocLink = new GroupPracticeLocationNetworkLink();
			this.SelectedNetworkGroupPracticeLocLink.New();

			//SetGroupPracticeGridsVisible(false); // disable the tabs
			this.pnlGroupPracticeDate.Visible = true;
		
		}
		
		public void OnToolbarButtonClick_AddFACILITY(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.SelectedNetworkFacilityLocLink = new FacilityLocationNetworkLink();
			this.SelectedNetworkFacilityLocLink.New();

			//SetGroupPracticeGridsVisible(false); // disable the tabs
			this.pnlFacilityDate.Visible = true;
			
		}

		public void OnToolbarButtonClick_AddPlan(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.SelectedNetworkPlan = new NetworkPlanLink();
			this.SelectedNetworkPlan.New();

			this.pnlPlanDate.Visible = true;
		}

		public void OnToolbarButtonClick_Contacts(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			ContactSearch.Redirect(this.network);
		}

			
		private void gridProviderNetworkLocations_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				object[] pk= gridProviderNetworkLocations.GetPKFromCellEvent(e);
				ProviderLocationNetworkLink provNetworkLink = new ProviderLocationNetworkLink();
				provNetworkLink.Load((int)pk[0]);				
				provNetworkLink.LoadEffectiveDatesHistory(true);
					
				this.ProvLocDates = provNetworkLink.EffectiveDatesHistory;
					
			}
		}

		private void gridGPNetworkLocations_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				object[] pk = gridGPNetworkLocations.GetPKFromCellEvent(e);
				GroupPracticeLocationNetworkLink provNetworkLink = new GroupPracticeLocationNetworkLink();
				provNetworkLink.Load((int)pk[0]);
				provNetworkLink.LoadEffectiveDatesHistory(true);
				this.GpLocDates = provNetworkLink.EffectiveDatesHistory;
			}
		}
		
		private void gridFacilityLocations_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				object[] pk = gridFacilityLocations.GetPKFromCellEvent(e);
				FacilityLocationNetworkLink facNetworkLink =  new FacilityLocationNetworkLink();
				facNetworkLink.Load((int)pk[0]);
				facNetworkLink.LoadEffectiveDatesHistory(true);
				this.FacilityLocDates = facNetworkLink.EffectiveDatesHistory;
			}
		}

		
	

				
		private void FacWebButton1_Click(object sender, System.EventArgs e)
		{
			this.SelectedNetworkFacilityLocLink  = null;
			this.pnlFacilityDate.Visible = false;
		}

		private void FacWebButton2_Click(object sender, System.EventArgs e)
		{
			this.UpdateToObject(this.pnlFacilityDate.Controls, this.SelectedNetworkFacilityLocLink);
			this.SelectedNetworkFacilityLocLink.FacilityLocationID = (int)this.FacilityLocationID.Value;

			if (AddFacilityLink())
			{
				this.pnlFacilityDate.Visible = false;
			}
			
		}

		private void WebButton1_Click(object sender, System.EventArgs e)
		{
			this.selectedNetworkProviderLocLink = null;
			this.pnlProviderDate.Visible = false;
		
		}

		private void WebButton2_Click(object sender, System.EventArgs e)
		{
			this.UpdateToObject(this.pnlProviderDate.Controls, selectedNetworkProviderLocLink);
			this.selectedNetworkProviderLocLink.ProviderLocationID = (int)this.ProviderLocationID.Value;

			if (AddProviderLink())
			{
				this.pnlProviderDate.Visible = false;
			}
			
		}
		private void GPWebButton1_Click(object sender, System.EventArgs e)
		{
			this.SelectedNetworkGroupPracticeLocLink = null;
			this.pnlGroupPracticeDate.Visible = false;
			
		}

		private void GPWebButton2_Click(object sender, System.EventArgs e)
		{
			this.UpdateToObject(this.pnlGroupPracticeDate.Controls, this.SelectedNetworkGroupPracticeLocLink);
			this.SelectedNetworkGroupPracticeLocLink.GroupPracticeLocationID = (int)this.GroupPracticeLocationID.Value;

			if (AddGroupPracticeLink())
			{
				this.pnlGroupPracticeDate.Visible = false;
			}
			
		}
		private void gridProvider_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridProvider.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;
		}
		private void gridProvider_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				object[] pk =  gridProvider.GetPKFromCellEvent(e);
				ProviderLocationNetworkSummaryCollection col = new ProviderLocationNetworkSummaryCollection();
				col.LoadProviderLocationNetworkSummary(-1,(int)pk[0],this.network.NetworkID);
					 
				this.ProvLocNetworkCol = col;
						
				this.gridProviderNetworkLocations.SelectedRowIndex = 0;
				int provLocNetworkLinkID = (int)this.gridProviderNetworkLocations.SelectedRowPK[0];
				ProviderLocationNetworkLink provNetworkLink = new ProviderLocationNetworkLink();
				provNetworkLink.Load(provLocNetworkLinkID);				
				provNetworkLink.LoadEffectiveDatesHistory(true);
					
				this.ProvLocDates = provNetworkLink.EffectiveDatesHistory;
			}
		}
		private void gridGP_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridGP.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;
		}

		private void gridFacility_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridFacility.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;
		}

		private void gridGP_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				object[] pk = gridGP.GetPKFromCellEvent(e);
				GroupPracticeLocationNetworkSummaryCollection col = new GroupPracticeLocationNetworkSummaryCollection();
				col.LoadGroupPracticeLocationNetworkSummary(-1,(int)pk[0],this.network.NetworkID);
				this.GPLocNetworkCol = col;

				this.gridGPNetworkLocations.SelectedRowIndex = 0;
				int gpLocNetworkID = (int)gridGPNetworkLocations.SelectedRowPK[0];
				GroupPracticeLocationNetworkLink provNetworkLink = new GroupPracticeLocationNetworkLink();
				provNetworkLink.Load(gpLocNetworkID);
				provNetworkLink.LoadEffectiveDatesHistory(true);
				this.GpLocDates = provNetworkLink.EffectiveDatesHistory;
			}
		}
		private void gridFacility_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				object[] pk= gridFacility.GetPKFromCellEvent(e);
				FacilityLocationNetworkSummaryCollection col = new FacilityLocationNetworkSummaryCollection();
				col.LoadFacilityLocationNetworkSummary(-1,(int)pk[0],this.network.NetworkID);
				this.FacLocNetworkCol= col;
						 
				this.gridFacilityLocations.SelectedRowIndex = 0;
				int facilityLocNetworkID = (int) gridFacilityLocations.SelectedRowPK[0];
				FacilityLocationNetworkLink facNetworkLink =  new FacilityLocationNetworkLink();
				facNetworkLink.Load(facilityLocNetworkID);
				facNetworkLink.LoadEffectiveDatesHistory(true);
				this.FacilityLocDates = facNetworkLink.EffectiveDatesHistory;
			}
		}

		private void btnSaveGPDates_Click(object sender, System.EventArgs e)
		{
			ProviderLocationNetworkHistory provLink = new ProviderLocationNetworkHistory();
			
			this.UpdateToObject(this.tblGPDates.Controls, provLink);
			provLink.AsOfDate = (DateTime)this.AsOfDate.Value;
			provLink.Active	= true;

			
			// check all dates for duplicates
			ProviderLocationNetworkLink linkCheck = new ProviderLocationNetworkLink();
			object[] pk = this.gridProviderNetworkLocations.SelectedRowPK;
			if((pk[0] != null) &&((int)pk[0] != 0))
			{
				linkCheck.Load((int)pk[0]);
				linkCheck.LoadEffectiveDatesHistory(false);
			
				bool resume = true;
//				for (int i = 0 ; i < linkCheck.EffectiveDatesHistory.Count; i++)
//				{
//					if 	(((((ProviderLocationNetworkLink)Network.ProviderNetworkLinks.GetAt(i)).EffectiveDate == provLink.EffectiveDate) && ((ProviderLocationNetworkLink)Network.ProviderNetworkLinks.GetAt(i)).EffectiveDate == provLink.EffectiveDate))
//					{
//						resume = false;
//						break;
//					}
//				}
				// check for current date too
				resume = (linkCheck.EffectiveDate == provLink.EffectiveDate && linkCheck.TerminationDate == provLink.TerminationDate) ? false : true;
				if (resume)
				{
					try
					{
							// move current record to archive and mark it Inactive
						ProviderLocationNetworkHistory provCurrentDates = new ProviderLocationNetworkHistory();
						//ProviderLocationNetworkHistory provDate = new ProviderLocationNetworkHistory();

						provCurrentDates.New();
						provCurrentDates.AsOfDate						= provLink.AsOfDate;
						provCurrentDates.EffectiveDate					= provLink.EffectiveDate;
						provCurrentDates.TerminationDate				= provLink.TerminationDate;
						provCurrentDates.Active							= true;
					
						linkCheck.EffectiveDatesHistory.Add(provCurrentDates);
					
						provLink.Active = true;
						provCurrentDates.ProviderLocationNetworkID = linkCheck.ProviderLocationNetworkID ;

						ProviderLocationNetworkHistoryCollection provColHistoryCol = new ProviderLocationNetworkHistoryCollection();
						provColHistoryCol.UpdateStatusForProviderLocationNetworkHistory(-1,provLink,linkCheck.ProviderLocationNetworkID);
		
					
						provCurrentDates.Save();
						//					this.SelectedProvIndex = 0;
						this.gridProviderDates.UpdateFromCollection(linkCheck.EffectiveDatesHistory );
						//this.gridProviderNetworkLocations.UpdateFromCollection (this.Network.ProviderNetworkLinks);
					
						ProviderLocationNetworkHistory blankHistory = new ProviderLocationNetworkHistory();
						this.UpdateFromObject(this.tblGPEffectiveDates.Controls, blankHistory);
						DisableGPDates(false);
					}
					catch (Exception ex)
					{
						this.RaisePageException(ex);
					}
				}
				else
					this.SetPageMessage("@DUPLICATEDATES@",NetsoftUSA.WebForms.EnumPageMessageType.Error);	
			}
			else
				this.SetPageMessage("@SELECTPROVLOC@",NetsoftUSA.WebForms.EnumPageMessageType.Error);	
		}
		private void btnSaveFacDates_Click(object sender, System.EventArgs e)
		{
			FacilityLocationNetworkHistory provLink = new FacilityLocationNetworkHistory();
			
			this.UpdateToObject(this.tblFacDates.Controls, provLink);
			provLink.AsOfDate = (DateTime)this.Webdatetimeedit11.Value ;
			provLink.Active	= true;

			
			// check all dates for duplicates
			FacilityLocationNetworkLink linkCheck = new FacilityLocationNetworkLink ();
			object[] pk = this.gridFacilityLocations.SelectedRowPK;
			if((pk[0] != null) &&((int)pk[0] != 0))
			{
				linkCheck.Load((int)pk[0]);
				linkCheck.LoadEffectiveDatesHistory(false);
			
				bool resume = true;
//				for (int i = 0 ; i < linkCheck.EffectiveDatesHistory.Count; i++)
//				{
//					if 	(((((FacilityLocationNetworkLink)Network.FacilityNetworkLinks.GetAt(i)).EffectiveDate == provLink.EffectiveDate) && ((FacilityLocationNetworkLink)Network.FacilityNetworkLinks.GetAt(i)).EffectiveDate == provLink.EffectiveDate))
//					{
//						resume = false;
//						break;
//					}
//				}
				// check for current date too
				resume = (linkCheck.EffectiveDate == provLink.EffectiveDate && linkCheck.TerminationDate == provLink.TerminationDate) ? false : true;
				if (resume)
				{
					try
					{
					
						FacilityLocationNetworkHistory provCurrentDates = new FacilityLocationNetworkHistory();
						//ProviderLocationNetworkHistory provDate = new ProviderLocationNetworkHistory();

						provCurrentDates.New();
						provCurrentDates.AsOfDate						= provLink.AsOfDate;
						provCurrentDates.EffectiveDate					= provLink.EffectiveDate;
						provCurrentDates.TerminationDate				= provLink.TerminationDate;
						provCurrentDates.Active							= true;
					
						linkCheck.EffectiveDatesHistory.Add(provCurrentDates);
					
						provLink.Active = true;
						provCurrentDates.FacilityLocationNetworkID = linkCheck.FacilityLocationNetworkID ;

						FacilityLocationNetworkHistoryCollection provColHistoryCol = new FacilityLocationNetworkHistoryCollection();
						provColHistoryCol.UpdateStatusForFacilityLocationNetworkHistory (-1,provLink,linkCheck.FacilityLocationNetworkID);
		
					
						provCurrentDates.Save();
						//					this.SelectedFacIndex = 0;
						this.gridFacDates.UpdateFromCollection(linkCheck.EffectiveDatesHistory );
//						this.gridFacilityLocations.UpdateFromCollection (this.Network.FacilityNetworkLinks);
					
						FacilityLocationNetworkHistory blankHistory = new FacilityLocationNetworkHistory();
						this.UpdateFromObject(this.tblFacEffectiveDates.Controls, blankHistory);
						DisableFacDates(false);
					}
					catch (Exception ex)
					{
						this.RaisePageException(ex);
					}
				}
				else
					this.SetPageMessage("@DUPLICATEDATES@",NetsoftUSA.WebForms.EnumPageMessageType.Error);	
			}
			else
					this.SetPageMessage("@SELECTFACILITY@",NetsoftUSA.WebForms.EnumPageMessageType.Error);	
		}

		private void btnSaveNetGPDates_Click(object sender, System.EventArgs e)
		{
			GroupPracticeLocationNetworkHistory provLink = new GroupPracticeLocationNetworkHistory();
			
			this.UpdateToObject(this.tblNetGPDates.Controls, provLink);
			provLink.AsOfDate = (DateTime)this.Webdatetimeedit7.Value  ;
			provLink.Active	= true;

			
			// check all dates for duplicates
			GroupPracticeLocationNetworkLink linkCheck = new GroupPracticeLocationNetworkLink ();
			object[] pk = this.gridGPNetworkLocations.SelectedRowPK;
			if(pk[0] != null && (int)pk[0] != 0)
			{
				linkCheck.Load((int)pk[0]);
				linkCheck.LoadEffectiveDatesHistory(false);
			
				bool resume = true;
//				for (int i = 0 ; i < linkCheck.EffectiveDatesHistory.Count; i++)
//				{
//					if 	(((((GroupPracticeLocationNetworkLink)Network.GroupPracticeNetworkLinks.GetAt(i)).EffectiveDate == provLink.EffectiveDate) && ((GroupPracticeLocationNetworkLink)Network.GroupPracticeNetworkLinks.GetAt(i)).EffectiveDate == provLink.EffectiveDate))
//					{
//						resume = false;
//						break;
//					}
//				}
				// check for current date too
				resume = (linkCheck.EffectiveDate == provLink.EffectiveDate && linkCheck.TerminationDate == provLink.TerminationDate) ? false : true;
				if (resume)
				{
					try
					{
						GroupPracticeLocationNetworkHistory provCurrentDates = new GroupPracticeLocationNetworkHistory();
						//ProviderLocationNetworkHistory provDate = new ProviderLocationNetworkHistory();

						provCurrentDates.New();
						provCurrentDates.AsOfDate						= provLink.AsOfDate;
						provCurrentDates.EffectiveDate					= provLink.EffectiveDate;
						provCurrentDates.TerminationDate				= provLink.TerminationDate;
						provCurrentDates.Active							= true;
					
						linkCheck.EffectiveDatesHistory.Add(provCurrentDates);
					
						provLink.Active = true;
						provCurrentDates.GroupPracticeLocationNetworkID = linkCheck.GroupPracticeLocationNetworkID ;

						GroupPracticeLocationNetworkHistoryCollection provColHistoryCol = new GroupPracticeLocationNetworkHistoryCollection();
						provColHistoryCol.UpdateStatusForGroupPracticeLocationNetworkHistory(-1,provLink,linkCheck.GroupPracticeLocationNetworkID);
		
					
						provCurrentDates.Save();
						//					this.SelectedGPIndex = 0;
						this.gridGPDates.UpdateFromCollection(linkCheck.EffectiveDatesHistory );
//						this.gridGPNetworkLocations.UpdateFromCollection (this.Network.GroupPracticeNetworkLinks);
					
						GroupPracticeLocationNetworkHistory blankHistory = new GroupPracticeLocationNetworkHistory();
						this.UpdateFromObject(this.tblNetworkGPEffectiveDates.Controls, blankHistory);
						DisableNetGPDates(false);
					}
					catch (Exception ex)
					{
						this.RaisePageException(ex);
					}
				}
				else
					this.SetPageMessage("@DUPLICATEDATES@",NetsoftUSA.WebForms.EnumPageMessageType.Error);	
			}
			else
					this.SetPageMessage("@SELECTGROUPPRACTICE@",NetsoftUSA.WebForms.EnumPageMessageType.Error);	
		}

		private void DisableGPDates(bool val)
		{
			btnSaveGPDates.Enabled = btnCancelGPDates.Enabled = val;
			Obfieldlabel3.Enabled =  Webdatetimeedit3.Enabled = Obfieldlabel4.Enabled	= val;
			Webdatetimeedit4.Enabled = lbAsOfDate.Enabled	=  AsOfDate.Enabled	= val;
		}

	
		private void gridProviderNetworkLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridProviderNetworkLocations.AddButtonColumn("Select","@SELECT@",0);
		}

	
		private void btnAddGPDates_Click(object sender, System.EventArgs e)
		{
			this.UpdateFromObject(this.tblGPDates.Controls, new ProviderLocationNetworkHistory ());
			this.AsOfDate.Value = DateTime.Now;
			this.tblGPDates.Visible = true;
			DisableGPDates(true);
		}

		private void btnCancelGPDates_Click(object sender, System.EventArgs e)
		{
			this.UpdateFromObject(this.tblGPDates.Controls, new ProviderLocationNetworkHistory());
			this.tblGPDates.Visible = false;			
		}
		// group Practice events
		private void DisableNetGPDates(bool val)
		{
			btnSaveNetGPDates.Enabled = btnCancelNetGPDates.Enabled = val;
			Obfieldlabel6.Enabled =  Webdatetimeedit5.Enabled = Obfieldlabel7.Enabled	= val;
			Webdatetimeedit6.Enabled = Obfieldlabel8.Enabled	=  Webdatetimeedit7.Enabled	= val;
		}

		
		private void gridGPNetworkLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridGPNetworkLocations.AddButtonColumn("Select","@SELECT@",0);
		}
		private void btnAddNetGPDates_Click(object sender, System.EventArgs e)
		{
			this.UpdateFromObject(this.tblNetGPDates.Controls, new GroupPracticeLocationNetworkHistory ());
			this.Webdatetimeedit7.Value = DateTime.Now;
			this.tblNetGPDates.Visible = true;
			DisableNetGPDates(true);
		}

		private void btnCancelNetGPDates_Click(object sender, System.EventArgs e)
		{
			this.UpdateFromObject(this.tblNetGPDates.Controls, new GroupPracticeLocationNetworkHistory ());
			this.tblNetGPDates.Visible = false;
		}
		// facility Events

		private void DisableFacDates(bool val)
		{
			btnSaveFacDates.Enabled = btnCancelFacDates.Enabled = val;
			Obfieldlabel10.Enabled =  Webdatetimeedit9.Enabled = Obfieldlabel11.Enabled	= val;
			Webdatetimeedit10.Enabled = Obfieldlabel12.Enabled	=  Webdatetimeedit11.Enabled	= val;
		}

		private void gridFacilityLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridFacilityLocations.AddButtonColumn("Select","@SELECT@",0);
		}
		private void btnAddFacDates_Click(object sender, System.EventArgs e)
		{
			this.UpdateFromObject(this.tblFacDates.Controls, new FacilityLocationNetworkHistory ());
			this.Webdatetimeedit11.Value = DateTime.Now;
			this.tblFacDates.Visible = true;
			DisableFacDates(true);
		}

		private void btnCancelFacDates_Click(object sender, System.EventArgs e)
		{
			this.UpdateFromObject(this.tblFacDates.Controls, new FacilityLocationNetworkHistory ());
			this.tblFacDates.Visible = false;
		}
		
	
		public ProviderLocationNetworkSummaryCollection ProvLocNetworkCol
		{
			get
			{
				return this.provLocNetworkCol;
			}
			set
			{
				try
				{
					this.provLocNetworkCol = value;
					this.gridProviderNetworkLocations.UpdateFromCollection(provLocNetworkCol);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}			
			}
		}

		public FacilityLocationNetworkSummaryCollection FacLocNetworkCol
		{
			get
			{
				return this.facilityLocNetworkCol;
			}
			set
			{
				try
				{
					this.facilityLocNetworkCol = value;
					this.gridFacilityLocations.UpdateFromCollection(facilityLocNetworkCol);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public GroupPracticeLocationNetworkSummaryCollection GPLocNetworkCol
		{
			get
			{
				return this.groupPracticeLocNetworkCol;
			}
			set
			{
				this.groupPracticeLocNetworkCol = value;
				this.gridGPNetworkLocations.UpdateFromCollection(groupPracticeLocNetworkCol);
			}
		}
	
		public ActiveAdvice.DataLayer.ProviderLocationNetworkHistoryCollection ProvLocDates
		{
			get { return this.provLocDates; }
			set 
			{
				try
				{
					this.provLocDates = value;
					this.gridProviderDates.UpdateFromCollection(provLocDates);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public ActiveAdvice.DataLayer.FacilityLocationNetworkHistoryCollection FacilityLocDates
		{
			get { return this.facilityLocDates; }
			set 
			{ 
				try
				{
					this.facilityLocDates = value; 
					this.gridFacDates.UpdateFromCollection(facilityLocDates);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}				
		}

		public ActiveAdvice.DataLayer.GroupPracticeLocationNetworkHistoryCollection GpLocDates
		{
			get { return this.gpLocDates; }
			set 
			{
				try
				{
					this.gpLocDates = value; 
					this.gridGPDates.UpdateFromCollection(gpLocDates);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		
		}

		public FacilityLocationNetworkLink SelectedNetworkFacilityLocLink
		{
			get { return selectedNetworkFacilityLocLink ; }
			set
			{
				selectedNetworkFacilityLocLink = value;
				try
				{
					this.UpdateFromObject(this.pnlFacilityDate.Controls, selectedNetworkFacilityLocLink);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedNetworkFacility", selectedNetworkFacilityLocLink);  // cache object using the caching method declared on the page
			}
		}
	
		public ProviderLocationNetworkLink SelectedNetworkProviderLocLink
		{
			get { return selectedNetworkProviderLocLink; }
			set
			{
				selectedNetworkProviderLocLink = value;
				try
				{
					this.UpdateFromObject(this.pnlProviderDate.Controls, selectedNetworkProviderLocLink);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedNetworkProviderLink", selectedNetworkProviderLocLink);  // cache object using the caching method declared on the page
			}
		}


		public GroupPracticeLocationNetworkLink SelectedNetworkGroupPracticeLocLink
		{
			get { return selectedNetworkGroupPracticeLocLink ; }
			set
			{
				selectedNetworkGroupPracticeLocLink = value;
				try
				{
					this.UpdateFromObject(this.pnlGroupPracticeDate.Controls, selectedNetworkGroupPracticeLocLink);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedNetworkGroupPracticeLocLink", selectedNetworkGroupPracticeLocLink);  // cache object using the caching method declared on the page
			}
		}
		
		
		#region plan
		private void btnCancelPlanDates_Click(object sender, System.EventArgs e)
		{
			this.UpdateFromObject(this.tblPlanDates.Controls, new NetworkPlanHistory ());
			this.tblPlanDates.Visible = false;
		}

		private void PlanWebButton2_Click(object sender, System.EventArgs e)
		{
			this.UpdateToObject(this.pnlPlanDate.Controls,selectedNetworkPlan);
			this.selectedNetworkPlan.PlanId = (int)this.PlanID.Value;

			if (this.AddPlanLink())
			{
				this.pnlPlanDate.Visible = false;
			}
		}

		private void PlanWebButton1_Click(object sender, System.EventArgs e)
		{
			//click cancel button
			this.SelectedNetworkPlan = null;
			this.pnlPlanDate.Visible = false;
		}

		private void btnSavePlanDates_Click(object sender, System.EventArgs e)
		{
		
			NetworkPlanHistory planLink = new NetworkPlanHistory();
			
			this.UpdateToObject(tblPlanDates.Controls, planLink);	//, false
			planLink.AsOfDate = (DateTime)this.Webdatetimeedit15.Value ;
			planLink.Active	= true;

			
			// check all dates for duplicates
			NetworkPlanLink linkCheck = new NetworkPlanLink ();
			object[] pk = this.gridPlan.SelectedRowPK;
			if((pk[0] != null) &&((int)pk[0] != 0))
			{
				linkCheck.Load((int)pk[0]);
				linkCheck.LoadEffectiveDatesHistory(false);
			
				bool resume = true;
//				for (int i = 0 ; i < linkCheck.EffectiveDatesHistory.Count; i++)
//				{
//					if 	(((((NetworkPlanLink)Network.PlanNetworkLinks.GetAt(i)).EndDate == planLink.EndDate) && ((NetworkPlanLink)Network.PlanNetworkLinks.GetAt(i)).StartDate == planLink.StartDate))
//					{
//						resume = false;
//						break;
//					}
//				}
				// check for current date too
				resume = (linkCheck.StartDate == planLink.StartDate && linkCheck.EndDate == planLink.EndDate) ? false : true;
				if (resume)
				{
					try
					{
					
						NetworkPlanHistory planCurrentDates = new NetworkPlanHistory();
						//ProviderLocationNetworkHistory provDate = new ProviderLocationNetworkHistory();

						planCurrentDates.New();
						planCurrentDates.AsOfDate						= planLink.AsOfDate;
						planCurrentDates.StartDate				= planLink.StartDate;
						planCurrentDates.EndDate				= planLink.EndDate;
						planCurrentDates.Active							= true;
					
						linkCheck.EffectiveDatesHistory.Add(planCurrentDates);
					
						planLink.Active = true;
						planCurrentDates.NetworkPlanID = linkCheck.NetworkPlanID;

						NetworkPlanHistoryCollection planHistoryCol = new NetworkPlanHistoryCollection();
						planHistoryCol.UpdateStatusForPlanNetworkHistory (-1,planCurrentDates,linkCheck.NetworkPlanID);
		
					
						planCurrentDates.Save();
						//					this.SelectedFacIndex = 0;
						this.gridPlanDates.UpdateFromCollection(linkCheck.EffectiveDatesHistory );
						//						this.gridFacilityLocations.UpdateFromCollection (this.Network.FacilityNetworkLinks);
					
						NetworkPlanHistory blankHistory = new NetworkPlanHistory();
						this.UpdateFromObject(this.tblPlanEffectiveDates.Controls, blankHistory);
						DisablePlanDates(false);
					}
					catch (Exception ex)
					{
						this.RaisePageException(ex);
					}
				}
				else
					this.SetPageMessage("@DUPLICATEDATES@",NetsoftUSA.WebForms.EnumPageMessageType.Error);	
			}
			else
				this.SetPageMessage("@SELECTPLAN@",NetsoftUSA.WebForms.EnumPageMessageType.Error);
		}

		private void gridPlan_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridPlan.AddButtonColumn("Select","@SELECT@",0);
		}

		private void gridPlan_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			try
			{
				if (e.Cell.Key == "Select")
				{
					object[] pk = gridPlan.GetPKFromCellEvent(e);
					NetworkPlanLink planLink = new NetworkPlanLink();
					planLink.Load((int)pk[0]);
					planLink.LoadEffectiveDatesHistory(false);
					this.gridPlanDates.UpdateFromCollection(planLink.EffectiveDatesHistory);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

	

				
		public NetworkPlanLink SelectedNetworkPlan
		{
			get { return selectedNetworkPlan ; }
			set
			{
				selectedNetworkPlan = value;
				try
				{
					this.UpdateFromObject(this.pnlPlanDate.Controls , selectedNetworkPlan);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedNetworkPlan", selectedNetworkPlan);  // cache object using the caching method declared on the page
			}
		}

		public ActiveAdvice.DataLayer.NetworkPlanHistoryCollection PlanDates
		{
			get
			{
				return planDates;
			}
			set
			{
				planDates = value;
				this.gridPlanDates.UpdateFromCollection(planDates);
			}
		}

		private bool AddPlanLink()
		{
			bool resume = false;
			if (this.SelectedNetworkPlan != null)
			{
				if (this.SelectedNetworkPlan.StartDate!= DateTime.MinValue) // add 
				{
					resume = true;										
					SelectedNetworkPlan.NetworkID = this.Network.NetworkID;
					
					// check if ID already exists if it does then show a message to the user
					for (int i=0; i < Network.PlanNetworkLinks.Count; i++)
					{
						if (SelectedNetworkPlan.PlanId == Network.PlanNetworkLinks[i].PlanId)
						{
							resume = false;
							break;
						}
					}
					if (resume)
					{
						this.Network.PlanNetworkLinks.Add(SelectedNetworkPlan);
						this.Network.PlanNetworkLinks.Save();
						this.SelectedNetworkPlan.LoadEffectiveDatesHistory(true); 

						NetworkPlanHistory currentDate = new NetworkPlanHistory();
						currentDate.New();
						currentDate.AsOfDate					= DateTime.Now;
						currentDate.StartDate				= this.SelectedNetworkPlan.StartDate;
						currentDate.EndDate				= this.SelectedNetworkPlan.EndDate;
						currentDate.Active						= this.SelectedNetworkPlan.Active ;
						currentDate.NetworkPlanID 	= this.SelectedNetworkPlan.NetworkPlanID;
					
						this.SelectedNetworkPlan.EffectiveDatesHistory.InsertRecord(0,currentDate);
						this.SelectedNetworkPlan.EffectiveDatesHistory.Save();
						network.LoadPlanNetworkLinks(false);
						NetworkPlanSummaryCollection networkPlanSummaryCol = new NetworkPlanSummaryCollection();
						networkPlanSummaryCol.LoadPlanNetworkSummary(-1,this.network.NetworkID);

						this.gridPlan.UpdateFromCollection(networkPlanSummaryCol);
						if(gridPlan.Rows.Count > 0)
						{
							gridPlan.SelectedRowIndex = 0;
							int networkPlanID = (int) gridPlan.SelectedRowPK[0];

							NetworkPlanLink planLink = new NetworkPlanLink();
							planLink.Load(networkPlanID);
							planLink.LoadEffectiveDatesHistory(false);
							this.gridPlanDates.UpdateFromCollection(planLink.EffectiveDatesHistory);
							this.btnAddPlanDates.Enabled = true;
						}
						this.SelectedNetworkPlan = null;
						this.pnlPlanDate.Visible = false;
					}
					else
						this.SetPageMessage("@PLANEXISTS@", NetsoftUSA.WebForms.EnumPageMessageType.Error);
				}
			}
			return resume;
		}

		private void btnAddPlanDates_Click(object sender, System.EventArgs e)
		{
			
			this.UpdateFromObject(this.tblPlanDates.Controls, new NetworkPlanHistory ());
			this.Webdatetimeedit15.Value = DateTime.Now;
			this.tblPlanDates.Visible = true;
			DisablePlanDates(true);
		}

		private void DisablePlanDates(bool val)
		{
			btnSavePlanDates.Enabled = btnCancelPlanDates.Enabled = val;
			Obfieldlabel14.Enabled =  Webdatetimeedit13.Enabled = Obfieldlabel5.Enabled	= val;
			Webdatetimeedit14.Enabled = Obfieldlabel16.Enabled	=  Webdatetimeedit15.Enabled	= val;
		}

		#endregion

		private void btnNextProvider_Click(object sender, System.EventArgs e)
		{
			if (gridProvider.Rows.Count > 0)
			{
				startID			= gridProvider.GetPKIntFromRowIndex(gridProvider.Rows.Count - 1); 
				int providerID = gridProvider.GetColIndexFromRowIndex(gridProvider.Rows.Count - 1);
				if (this.network.Providers[providerID]	!= null )
				{
					startFirstName = this.network.Providers[providerID].FirstName;
					startLastName  = this.network.Providers[providerID].LastName;
				}
				this.network.LoadProviders(ProviderLocationNetworkLinkCollection.MAXRECORDS, startID, startFirstName, startLastName);
				this.gridProvider.UpdateFromCollection(this.network.Providers);
				btnNextProvider.Enabled = Network.Providers.Count >= ProviderLocationNetworkLinkCollection.MAXRECORDS;
				if (gridProvider.Rows.Count > 0)
					UpdateProviderRelatedInfo();
			}
		}

		private void btnNextFacility_Click(object sender, System.EventArgs e)
		{
			if (gridFacility.Rows.Count > 0)
			{
				startID = gridFacility.GetPKIntFromRowIndex(gridFacility.Rows.Count - 1);
				int facID = gridFacility.GetColIndexFromRowIndex(gridFacility.Rows.Count - 1);
				if (this.network.Facilities[facID] != null)
				{
					startName = this.network.Facilities[facID].Name;
				}
				this.network.LoadFacilities(FacilityLocationNetworkLinkCollection.MAXRECORDS, startID, startName);
				this.gridFacility.UpdateFromCollection(this.network.Facilities);
				btnNextFacility.Enabled = Network.Facilities.Count >= FacilityLocationNetworkLinkCollection.MAXRECORDS;
				if (gridFacility.Rows.Count > 0 )
					UpdateFacilityRelatedInfo();
			}
		}

		void UpdateFacilityRelatedInfo()
		{
			this.gridFacility.SelectedRowIndex = 0;
			int facilityID = (int) gridFacility.SelectedRowPK[0];
			FacilityLocationNetworkSummaryCollection col = new FacilityLocationNetworkSummaryCollection();
			col.LoadFacilityLocationNetworkSummary(-1,facilityID,this.network.NetworkID);
			this.FacLocNetworkCol= col;
						 
			this.gridFacilityLocations.SelectedRowIndex = 0;
			int facilityLocNetworkID = (int) gridFacilityLocations.SelectedRowPK[0];
			FacilityLocationNetworkLink facNetworkLink =  new FacilityLocationNetworkLink();
			facNetworkLink.Load(facilityLocNetworkID);
			facNetworkLink.LoadEffectiveDatesHistory(true);
			this.FacilityLocDates = facNetworkLink.EffectiveDatesHistory;
		}

		private void btnGroupPracticeNext_Click(object sender, System.EventArgs e)
		{
			if (gridGP.Rows.Count > 0)
			{
				startID = gridGP.GetPKIntFromRowIndex(gridGP.Rows.Count - 1);
				int gpID = gridGP.GetColIndexFromRowIndex(gridGP.Rows.Count - 1);
				if (this.network.GroupPractices[gpID] != null)
				{
					startName = this.network.GroupPractices[gpID].Name;
				}
				this.network.LoadGroupPractices(GroupPracticeLocationNetworkLinkCollection.MAXRECORDS, startID, startName);
				this.gridGP.UpdateFromCollection(this.network.GroupPractices);
				if (this.gridGP.Rows.Count > 0)
					UpdateGroupPracticeRelatedInfo();
			}
		}


	
	
	}
}
