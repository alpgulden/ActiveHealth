using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;
using NetsoftUSA.DataLayer;
using NetsoftUSA.Security;
using NetsoftUSA.WebForms;
using NetsoftUSA.InfragisticsWeb;
using System.Security.Principal;
using System.Web.Security;
using System.Web.Caching;
using ActiveAdvice.DataLayer;
using System.Diagnostics;

namespace ActiveAdvice.Web 
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public class Global : WebApplication
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		public Global()
		{
			InitializeComponent();
		}	
		

		protected override void EnsureConfiguration()
		{
			bool configurationInMemory = ConfigurationInMemory;
			if (!configurationInMemory)
				NSGlobal.WriteToEventLog("Loading configuration..", EventLogEntryType.Information);
			base.EnsureConfiguration ();
			if (!configurationInMemory)
			{
				GrouperHIPAA.dllPath = Server.MapPath(@"bin\hcfa_020.dll");
				// Event logging parameters
				NSGlobal.ApplicationName = ConfigHelper.GetConfigValue("ApplicationName");
				NSGlobal.EventLogName = ConfigHelper.GetConfigValue("EventLogName");
				NSGlobal.EventLogMachine = ConfigHelper.GetConfigValue("EventLogMachine");

				// AutoActivity evaluation/generation parameters.
				AutoActivityManager.AutoActivityEvaluateEnabled = ConfigHelper.GetConfigValueBool("AutoActivityEvaluateEnabled", true);
				AutoActivityManager.AutoActivityGenerateEnabled = ConfigHelper.GetConfigValueBool("AutoActivityGenerateEnabled", true);
				AutoActivityManager.AutoActivityLogDump = ConfigHelper.GetConfigValueBool("AutoActivityLogDump", false);
				CoverageSelectionContext.CoverageLogDump = ConfigHelper.GetConfigValueBool("CoverageLogDump", false);
				CustomGrouper.DRGMessageLogDump = ConfigHelper.GetConfigValueBool("DRGMessageLogDump", false);
				ActiveAdvice.Web.BasePage.EnableDebugButtons = ConfigHelper.GetConfigValueBool("EnableDebugButtons", false);	// Enables buttons like ClearCache
				BasePage.DebugDump = ConfigHelper.GetConfigValueBool("DebugDump", false);						// Dump debug statistics
				NetsoftUSA.WebForms.BasePage.CacheCollectionWarningLimit = ConfigHelper.GetConfigValueInt("CacheCollectionWarningLimit", 100);		// If a collection being cached is larger than this limit, display a warning message
				NetsoftUSA.WebForms.BasePage.ChildCollectionWarningLimit = ConfigHelper.GetConfigValueInt("ChildCollectionWarningLimit", 50);		// If a child collection of a cached data class is larger than this limit, display a warning message
				
				OBComboBox.OBComboWarningRowLimit = ConfigHelper.GetConfigValueInt("OBComboWarningRowLimit", 200);		// If the number of rows is more than this limit, a warning is displayed when DebugDump = true
				WebCombo.WebComboWarningRowLimit = ConfigHelper.GetConfigValueInt("WebComboWarningRowLimit", 100);		// If the number of rows is more than this limit, a warning is displayed when DebugDump = true
				WebGrid.WebGridWarningRowLimit = ConfigHelper.GetConfigValueInt("WebGridWarningRowLimit", 200);			// If the number of rows is more than this limit, a warning is displayed when DebugDump = true

				NetsoftUSA.WebForms.BasePage.MemoryWarningDelta = ConfigHelper.GetConfigValueInt("MemoryWarningDelta", 1000);						// If a page increased the used mermory in the given amount (in KB), display a warning message

				NSGlobal.ConnectionString = WebApplication.ConnectionString;
				//NSGlobal.ConnectionString = "data source=NS1DEV005;initial catalog=ActiveAdviceAHMData;uid=AA_user;pwd=AA_user;packet size=4096;pooling=true;max pool size=500;connection lifetime=5;Persist Security Info=True";
				//OBValidator.ValidationErrorMarker = "<img src='pics/VldErr.gif'>";
				OBValidator.ValidationErrorMarker = "<span style=\"color:red;font-size:12pt;\">!</span>";
				WebGrid.EditButtonText = "Edit"; //<img src='pics/edit.gif'>";
				WebGrid.CssClassForSelectedRows = "GridSelectedRows";

				WebGrid.CssClassForFrame = "GridFrame";
				WebGrid.CssClassForRow = "GridRow";
				WebGrid.CssClassForRowAlternate = "GridRowAlternate";
				WebGrid.CssClassForEditCell = "GridEditCell";
				WebGrid.CssClassForHeader = "GridHeader";
				WebGrid.CssClassForSelectedHeader = "GridSelectedHeader";

				WebGrid.SelectedRowIconHTML = "<img src=pics/selectedRow.gif>";
				WebNumericEdit.CssClassForReadOnly = "readOnlyTextBox";
				WebTextEdit.CssClassForReadOnly = "readOnlyTextBox";
				WebMaskEdit.CssClassForReadOnly = "readOnlyTextBox";
				OBTextBox.CssClassForReadOnly = "readOnlyTextBox";
				WebCombo.CssClassForReadOnly = "readOnlyTextBox";
				WebCurrencyEdit.CssClassForReadOnly = "readOnlyTextBox";
				WebDateTimeEdit.CssClassForReadOnly = "readOnlyTextBox";
				OBCheckBox.BindTextsToDescriptions = true;

				OBTextBox.CssClassEditable = "textarea";
				OBFieldLabel.CssClassGlobal = "fieldlabel";
				OBLabel.CssClassGlobal = "OBLabel";

				PageMessage.CssClassErrorAll = "PageMessageError";
				PageMessage.CssClassInfoAll = "PageMessageInfo";
				PageMessage.CssClassWarningAll = "PageMessageWarning";

				WebToolbar.CssClassForPageToolbarButtonDisabled = "pagetoolbarbuttondisabled";
				WebToolbar.CssClassForTabToolbarButtonDisabled = "tabtoolbarbuttondefault";	// will disable

				OBButton.CssAll = "RegularButton";

				AASecurityHelper.defaultRedirectUrl = "PatientSearch.aspx";

				//ValidationExpression.USSSN = @"(\d{9})";

				WebGrid.DataCutOffLength = 500; // This is in pixels
				WebGrid.NoRecordsToDisplayMessage = "<table style=\"color:red;font-size:12pt;\" cellSpacing=0 cellPadding=0 border=0><tr height=20><td></td></tr><tr><td>No records to display.</td></tr><tr height=20><td></td></tr></table>";

				ContentPanel.GlobalCSSClass = "cpanel";
			}
			
		}

		private void Global_AcquireRequestState(object sender, System.EventArgs e)
		{
			// Check validity of session if the user is already authenticated.
			if (Context.Session != null)
			{
				string cookieName = FormsAuthentication.FormsCookieName;
				HttpCookie authCookie = Context.Request.Cookies[cookieName];
				if(authCookie != null)
				{								
					// User is authenticated, there must be a valid session
					if (Context.Session["SessionValid"] == null)
					{
						Context.Session["SessionValid"] = true;	// make session valid from this point on

		 				BasePage basePage = Context.Handler as BasePage;
						if (basePage != null)
							basePage.CancelNavigateAway = true;
						ErrorForm.Redirect("@SESSIONNOTVALID@", "@SESSIONNOTVALIDLONG@");
						//LogOut.Redirect("@SESSIONNOTVALID@");
					}
				}
			} 
		}

		public override void Application_Start(Object sender, EventArgs e)
		{
			base.Application_Start(sender,e);
			NSGlobal.WriteToEventLog("ActiveAdvice application starting", EventLogEntryType.Information);
			CodeHelper.ActivateServer(true);
		}

		public override void Application_End(Object sender, EventArgs e)
		{
			NSGlobal.WriteToEventLog("ActiveAdvice application shutting down", EventLogEntryType.Information);
			CodeHelper.ActivateServer(false);
		}

		public override void Application_AuthenticateRequest(Object sender, EventArgs e)
		{
			//TODO Retrieve session timeout information from system settings table and use for cache expiration
			// Extract the forms authentication cookie
			
			string cookieName = FormsAuthentication.FormsCookieName;
			HttpCookie authCookie = Context.Request.Cookies[cookieName];
			if(null == authCookie)
			{								
				// User is not authenticated or auth cookie is expired.
				return;
			}

			//Authentication cookie is found now we need to decrypt it.
			FormsAuthenticationTicket authTicket = null;
			try
			{
				authTicket = FormsAuthentication.Decrypt(authCookie.Value);
			}
			catch (Exception ex)
			{
				//TODO handle the exception
				// Log exception details 
				return;
			}


			if (null == authTicket)
			{
				// Cookie failed to decrypt.
				return;
			}

			//Create a form identity from the authentication ticket.
			FormsIdentity ID = new FormsIdentity(authTicket);

			// Check to see whether the Principal was cached. 
			string CachedPrincipalKey = ActiveAdvice.DataLayer.AASecurityHelper.CACHED_PRINCIPAL +  ID.Name;

			//if ticket is expired we may take UserId, drop cached principal with old roles
			if(authTicket.Expired)
			{
				HttpContext.Current.Cache.Remove(CachedPrincipalKey);
				FormsAuthentication.SignOut();
				//Response.Redirect("Logout.aspx");
				return ;
			}
			
			if (HttpContext.Current.Cache[CachedPrincipalKey] == null)
			{
				//Create the principal. Getroles method retrieves the roles for this user identity
				//PrincipalEx principal = new PrincipalEx(ID,  WebAccount.GetRoles(CurrentUserIdentity.Name));
				int iUserId = System.Int32.Parse(ID.Name);		//storing UserId in principal, not Login Name
				
				string[] roles = ActiveAdvice.DataLayer.AASecurityHelper.GetRoles(iUserId);
				GenericPrincipal principal = new GenericPrincipal(ID, roles );
				// Insert principal to cache
				HttpContext.Current.Cache.Insert(
					CachedPrincipalKey,
					principal, 
					null,
					DateTime.MaxValue, 
					new TimeSpan(0,ActiveAdvice.DataLayer.AASecurityHelper.CachedPrincipalTimeOut,0), //Cache must expire when the session times out
					CacheItemPriority.Normal, 
					null);
				HttpContext.Current.User = principal; 
			}
			else
			{
				GenericPrincipal principal = (GenericPrincipal) Context.Cache.Get(CachedPrincipalKey);
				HttpContext.Current.User = principal;
			}
			return; 
			
		}

		public override void Session_Start(object sender, EventArgs e)
		{
			base.Session_Start (sender, e);
			NSGlobal.WriteToEventLog(String.Format( "Session started for UID={0}", AASecurityHelper.GetUserId), EventLogEntryType.Information);
		}

		public override void Session_End(object sender, EventArgs e)
		{
			base.Session_End (sender, e);
			NSGlobal.WriteToEventLog(String.Format( "Session ended for UID={0}", AASecurityHelper.GetUserId), EventLogEntryType.Information);
		}


		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			// 
			// Global
			// 
			this.AcquireRequestState += new System.EventHandler(this.Global_AcquireRequestState);

		}
		#endregion

	}
}

