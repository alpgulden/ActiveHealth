using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for ProblemLinkForm.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.PROBLEMS)]
	
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Outcome,DataLayer")]
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[PageTitle("@PROBLEMLINKPAGETITLE@")]
	public class ProblemLinkForm : BasePage
	{
		
		private ProblemCollection patientProblems;
		private Patient patient;
		private BaseForEventCMSReferral erc; // any one of these:  Event, CMS, Referral

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGrid;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSetPrimary;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;			
		

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
//			this.rblSelection.SelectedIndexChanged += new System.EventHandler(this.rblSelection_SelectedIndexChanged);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
			this.wbtnSetPrimary.Click += new System.EventHandler(this.wbtnSetPrimary_Clicked);

			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModelessDialog;

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				LoadData();
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache
				patientProblems = (ProblemCollection)this.LoadObject(typeof(ProblemCollection));  // load object from cache
			}
		}

		public void LoadData()
		{
			try
			{	
				patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
				
				erc = this.GetParamOrGetFromCache("ERC", typeof(BaseForEventCMSReferral)) as BaseForEventCMSReferral;
				if (erc == null)
				{
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an event/referral/CMS");
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
			
			this.CacheObject(typeof(Patient), patient);
			this.CacheObject(typeof(BaseForEventCMSReferral), erc);
			this.LoadDataForPatientProblems();
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ProblemCollection PatientProblems
		{
			get { return patientProblems; }
			set
			{
				patientProblems = value;
				try
				{
					grid.UpdateFromCollection(patientProblems);  // update given grid from the collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(ProblemCollection), patientProblems);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForPatientProblems()
		{
			bool result = true;
			ProblemCollection problems = new ProblemCollection();
			try
			{	// use any load method here
				problems = patient.GetLinkedProblems();  //all problems for current patient
				
				erc.LoadERCProblemLinks(false); 
				erc.ERCProblemLinks.DetermineLinkedProblems(problems); //sets if problem is linked with Event/Referral/CMS
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.PatientProblems = problems;
			return result;
		}	


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@CLOSE@", "Close", false).Item.TargetURL = "javascript:window.close();";
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Problems Linked ");
			}
		}

		private bool SaveData()
		{
			bool result = true;
			try
			{
				grid.UpdateToCollection(this.patientProblems);
				erc.LoadERCProblemLinks(false); 
				
				erc.ERCProblemLinks.SynchronizeFromProblems(this.patientProblems);
				erc.SaveERCProblemLinks();
			}
			catch(Exception ex)
			{
				result = false;
				this.RaisePageException(ex);
			}
			return result;
		}

		private void wbtnSetPrimary_Clicked(object sender, System.EventArgs e)
		{
			if (grid.SelectedRowIndex < 0 )
				return;
			
			erc.ERCProblemLinks.SetPrimaryProblem(patientProblems[grid.SelectedRowIndex]);
			erc.ERCProblemLinks.DetermineLinkedProblems(this.patientProblems);
			PatientProblems = this.patientProblems;
		}
	}
}
