using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.BaseCodeTypeMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseLookup,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@CODEBRAKET@")]
	public class CodeTypeFormForCodeBraket : CodeBasePage
	{
		private	BaseLookup obj1,obj2;
		private	BaseCodeBracket obj;
		private BaseTypeCollection objCol1,objCol2;
		private BaseTypeCollection objCol;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFocus;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCodeTypes;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEdit;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNotepad;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCode;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Code;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCode;
		protected NetsoftUSA.WebForms.OBValidator vldNotepad;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.WebForms.OBCheckBox obChkSearchActive;
		protected NetsoftUSA.WebForms.OBTextBox obTxtSearchDescription;
		protected NetsoftUSA.WebForms.OBTextBox obTxtSearchCode;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSearch;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.WebForms.OBTextBox NoteGeneric;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCodeTypes1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCodeTypes2;
		protected NetsoftUSA.WebForms.OBLabel lblCodeType1;
		protected NetsoftUSA.WebForms.OBLabel lblCodeType2;
		protected NetsoftUSA.InfragisticsWeb.WebButton butLink;
		protected NetsoftUSA.WebForms.OBLabel lblLink;
		protected NetsoftUSA.InfragisticsWeb.WebButton butRemove;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
				this.LoadData();			// Load data is the actual data loading method
			else
			{				
				//this.obj = (BaseCodeBracket)this.LoadObject("BaseCodeBracket");
				this.objCol = (BaseTypeCollection)this.LoadObject("CodeTypeFormForCodeBraket");
				this.objCol1= (BaseTypeCollection)this.LoadObject("CodeType1Collection");
				this.objCol2= (BaseTypeCollection)this.LoadObject("CodeType2Collection");
			}
		}


		public static void Redirect(Type type,string title,string codeType1Title,string codeType2Title)
		{
			if (typeof(ActivityTypeSubType) == type)   //// Organization
			{				
				ActivityTypeSubTypeCollection col = new ActivityTypeSubTypeCollection();
				ActivityTypeCollection codeType1 = new ActivityTypeCollection();
				ActivitySubTypeCollection codeType2 = new ActivitySubTypeCollection();
				BasePage.PushParam("CodeType1Title", codeType1Title);
				BasePage.PushParam("CodeType2Title", codeType2Title);
				BasePage.PushParam("CodeTitle", title);
				BasePage.PushParam("Type", col );
				BasePage.PushParam("CodeType1", codeType1 );
				BasePage.PushParam("CodeType2", codeType2 );
				BasePage.Redirect("CodeTypeFormForCodeBraket.aspx");
			}
			if (typeof(OutcomeIndicatorSubIndicator) == type)   //// Organization
			{				
				OutcomeIndicatorSubIndicatorCollection col = new OutcomeIndicatorSubIndicatorCollection();
				OutcomeIndicatorCollection codeType1 = new OutcomeIndicatorCollection();
				OutcomeSubIndicatorCollection codeType2 = new OutcomeSubIndicatorCollection();
				BasePage.PushParam("CodeType1Title", codeType1Title);
				BasePage.PushParam("CodeType2Title", codeType2Title);
				BasePage.PushParam("CodeTitle", title);
				BasePage.PushParam("Type", col );
				BasePage.PushParam("CodeType1", codeType1 );
				BasePage.PushParam("CodeType2", codeType2 );
				BasePage.Redirect("CodeTypeFormForCodeBraket.aspx");
			}
			else
			{
				Debug.Fail("Invalid Type");
			}
		}


		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			string title = this.GetParamString("CodeTitle");
			this.lblLink.Text = title;
			this.lblCodeType1.Text = this.GetParamString("CodeType1Title");
			this.lblCodeType2.Text = this.GetParamString("CodeType2Title");			
			BaseTypeCollection  baseFocusCol	= (BaseTypeCollection)this.GetParam("Type");
			BaseTypeCollection  baseCodeTypeCol1	= (BaseTypeCollection)this.GetParam("CodeType1");
			BaseTypeCollection  baseCodeTypeCol2	= (BaseTypeCollection)this.GetParam("CodeType2");			

			if (baseFocusCol != null)
			{
				this.obj	= (BaseCodeBracket)Activator.CreateInstance(baseFocusCol.ElementType);
			}
			if (baseCodeTypeCol1 != null)
			{
				baseCodeTypeCol1.LoadAll();
				this.BaseCodeTypeCol1 = baseCodeTypeCol1;
			}			

			if(this.gridCodeTypes1.SelectedRowIndex==0)
			{
				obj1	= (BaseLookup)objCol1.GetAt(this.gridCodeTypes1.SelectedRowIndex);
				obj1.LoadBracketCodeTableChilderen(true);
				objCol	= (BaseTypeCollection)obj1.BracketCodeTableChilderen;
				this.BaseTypeCollection = objCol;
			}

			if (baseCodeTypeCol2 != null)
			{
				baseCodeTypeCol2.LoadAll();
				this.BaseCodeTypeCol2 = baseCodeTypeCol2;				
			}

			//select sidemenuitem
			this.SelectedSideMenuItem = this.LoadObject("SelectedSideMenuItem") as string;

//	No need to fill activitytypesubtype grid
//			if (baseFocusCol != null)
//			{
//				baseFocusCol.LoadAllActivityTypeSubType();
//				this.BaseDataCollectionClass = baseFocusCol;
//			}
			return result;
		}


		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{
				obj1 = (BaseLookup)objCol1.GetAt(this.gridCodeTypes1.SelectedRowIndex);
				if(obj1!=null)
				{
					this.obj1.SaveBracketCodeTableChilderen();

					#region Clear CodeTable Cache
					// clear cache 
					string strType = this.BaseTypeCollection.GetType().Name;
					//clear cache for the current server
					NSGlobal.ClearCacheByType(strType);

					//clear cache for other servers 
					// calling WebRequest for every server but current and passing collection type
					// ...
					ClearOtherServersCache(strType, false);
					#endregion Clear CodeTable Cache

					return true;
				}
				else
					return false;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}			
		}

		public BaseCodeBracket BaseCodeBracket
		{
			get { return obj;  }
			set { obj = value; }
		}

		public BaseTypeCollection BaseTypeCollection
		{
			get { return this.objCol; }
			set 
			{
				try
				{
					this.objCol				= value;
					objCol.ElementType      = value.ElementType;

					this.gridCodeTypes.ClearRows();
					this.objCol.DisplayOnlyActive=false;
					this.gridCodeTypes.UpdateFromCollection(this.objCol);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("CodeTypeFormForCodeBraket", this.objCol);
			}
		}

		public BaseLookup BaseLookup1
		{
			get { return obj1;  }
			set { obj1 = value; }
		}

		public BaseTypeCollection BaseCodeTypeCol1
		{
			get { return this.objCol1; }
			set 
			{
				try
				{
					this.objCol1			= value;
					objCol1.ElementType      = value.ElementType;
					this.gridCodeTypes1.Visible	= true;
					this.gridCodeTypes1.ClearRows();
					this.objCol1.DisplayOnlyActive=false;
					this.gridCodeTypes1.UpdateFromCollection(this.objCol1);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("CodeType1Collection", this.objCol1);
			}
		}

		
		public BaseLookup BaseLookup2
		{
			get { return this.obj2;  }
			set { this.obj2 = value; }
		}

		public BaseTypeCollection BaseCodeTypeCol2
		{
			get { return this.objCol2; }
			set 
			{
				try
				{
					this.objCol2			= value;
					objCol2.ElementType     = value.ElementType;
					this.gridCodeTypes2.Visible	= true;
					this.gridCodeTypes2.ClearRows();
					this.objCol2.DisplayOnlyActive=false;
					if(objCol!=null)
						this.objCol2.SynchronizeCollection(objCol);
					this.gridCodeTypes2.UpdateFromCollection(this.objCol2);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("CodeType2Collection", this.objCol2);
			}
		}

		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.gridCodeTypes1.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridCodeTypes1_ClickCellButton);
			this.gridCodeTypes1.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridCodeTypes1_ColumnsBoundToDataClass);
			this.gridCodeTypes2.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridCodeTypes2_ClickCellButton);
			this.gridCodeTypes2.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridCodeTypes2_ColumnsBoundToDataClass);
			this.butLink.Click += new System.EventHandler(this.butLink_Click);
			this.butRemove.Click += new System.EventHandler(this.butRemove_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@SAVERECORD@", "SaveType",true, false);
			toolbar.AddButton("@CANCEL@", "Cancel", false, true);
		}


		public override void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick (toolbar, button);
			//button.Key == "Save"
		}

		public void OnToolbarButtonClick_SaveType(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{			
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@CODETYPE@");
			}
		}

		private void gridCodeTypes1_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridCodeTypes1.AddButtonColumn("Select","SELECT",0);
		}

		private void gridCodeTypes1_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			string colName = e.Cell.Key;
			if (colName == "Select")
			{	
				gridCodeTypes1.SelectedRowIndex = e.Cell.Row.Index;
				//gridCodeTypes1.DisplayLayout.ActiveRow.Selected=true;
				int pk =(int)(e.Cell.Row.DataKey);
				try
				{			
					obj1	= (BaseLookup)objCol1.GetAt(pk);
					this.BaseLookup1 = obj1;
					obj1.LoadBracketCodeTableChilderen(true);
					objCol	= (BaseTypeCollection)obj1.BracketCodeTableChilderen;
					this.BaseTypeCollection = objCol;
					this.BaseCodeTypeCol2 = objCol2;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void gridCodeTypes2_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridCodeTypes2.AddButtonColumn("Select","SELECT",0);
		}

		private void gridCodeTypes2_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			string colName = e.Cell.Key;
			if (colName == "Select")
			{	
				gridCodeTypes2.SelectedRowIndex = e.Cell.Row.Index;
				//gridCodeTypes2.DisplayLayout.ActiveRow.Selected=true;
				int pk =(int)(e.Cell.Row.DataKey);
				try
				{			
					obj2	= (BaseLookup)objCol2.GetAt(pk);
					this.BaseLookup2 = obj2;
//					obj2.LoadBracketCodeTableChilderen(true);
//					objCol	= (BaseTypeCollection)obj2.BracketCodeTableChilderen;
//					this.BaseTypeCollection = objCol;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{			
			CodeMaintenance.Redirect(this.GetParamString("CodeTitle"));
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			if(objCol!=null && objCol.Count>0 && this.gridCodeTypes.SelectedRowIndex>=0)
				this.butRemove.Visible=true;
		}

		private void butLink_Click(object sender, System.EventArgs e)
		{
			if(this.gridCodeTypes1.SelectedRowIndex<0)
				this.SetPageMessage("@LINKEDMSG@", EnumPageMessageType.Error);
			else
				this.obj1 = (BaseLookup)objCol1.GetAt(this.gridCodeTypes1.SelectedRowIndex);
				
			if(this.gridCodeTypes1.SelectedRowIndex<0)
				this.SetPageMessage("@LINKEDMSG@", EnumPageMessageType.Error);
			else
				this.obj2 = (BaseLookup)objCol2.GetAt(this.gridCodeTypes2.SelectedRowIndex);				
			
			if(objCol!=null && objCol.Count>=0)
			{
				// 	if the link collection is not empty //  sync and add new record if needed.	
				if(!objCol.FindBaseCodeType(obj1.ID,obj2.ID))
				{					
					this.obj	= (BaseCodeBracket)Activator.CreateInstance(this.objCol.ElementType);
					obj.CodeTypeID = obj1.ID;
					obj.LinkedCodeTypeID = obj2.ID;
					obj.IsNew = true;
					objCol.AddRecord(obj);
					this.BaseTypeCollection = objCol;
					this.SetPageMessage("@LINKEDSUCCESS@", EnumPageMessageType.Info);
				}
				else
					this.SetPageMessage("@LINKEDFAIL@", EnumPageMessageType.Info);
				this.BaseCodeTypeCol2 = objCol2;
			}	
			else
				this.SetPageMessage("@BRACKETCLASSMSG@", EnumPageMessageType.Error);
		}

		private void butRemove_Click(object sender, System.EventArgs e)
		{
			try
			{
				if(objCol!=null)
				{
					if(this.gridCodeTypes.SelectedRowIndex>=0)
					{
						if(objCol.GetType().Name == "ActivityTypeSubTypeCollection")
							((ActivityTypeSubTypeCollection)objCol).MyMarkDel((ActivityTypeSubType)objCol.GetAt(this.gridCodeTypes.SelectedRowIndex));
						else if(objCol.GetType().Name == "OutcomeIndicatorSubIndicatorCollection")
							((OutcomeIndicatorSubIndicatorCollection)objCol).MyMarkDel((OutcomeIndicatorSubIndicator)objCol.GetAt(this.gridCodeTypes.SelectedRowIndex));
						this.BaseTypeCollection = objCol;
						this.BaseCodeTypeCol2 = objCol2;
					}
					else
						this.SetPageMessage("@REMOVEMSG@", EnumPageMessageType.Error);
				}
				else
					this.SetPageMessage("@BRACKETCLASSMSG@", EnumPageMessageType.Error);

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}		
		}

		protected override object SaveViewState()
		{
			ViewState["SelectedSideMenuItem"] = this.SelectedSideMenuItem;
			return base.SaveViewState ();
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
			this.SelectedSideMenuItem = (string)ViewState["SelectedSideMenuItem"];
		}
	}
}
