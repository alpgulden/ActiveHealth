using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.BaseClassesInterfaces;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.IMPORT_EXPORT_MAINT)]

	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("ScoringLoad")]
	public class ImportScoringLoad : ImportExportBasePage
	{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlScoringLoad;
		protected NetsoftUSA.WebForms.OBLabel OblblScoringLoad;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFileName;		
		protected CommonDialog CommDlg;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMORGID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MORGID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMORGID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldORGID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ORGID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbORGID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLabel;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Label;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLabel;
		protected System.Web.UI.WebControls.RadioButton GenerateEnvelopesOnly;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGenerateEnvelopesOnly;
		protected System.Web.UI.WebControls.RadioButton GenerateEnvelopes;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGenerateEnvelopes;
		protected System.Web.UI.WebControls.RadioButton ScoringLoadOnly;
		protected NetsoftUSA.WebForms.OBFieldLabel lbScoringLoadOnly;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("ImportScoringLoad.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.MORGID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.MORGID_SelectedRowChanged);
			this.ORGID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.ORGID_SelectedRowChanged);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			ToolbarButtonExtraProperties tbep = toolbar.AddButton("@SAVE@", "Update");
			tbep.ChecksForIsDirty = false;
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		private void BindScoringLoadChoices()
		{
			if (SLA.ScoringLoadOnly)
				ScoringLoadOnly.Checked = SLA.ScoringLoadOnly;
			else if (SLA.GenerateEnvelopesOnly) // envelopes only
				GenerateEnvelopesOnly.Checked = SLA.GenerateEnvelopesOnly;
			else
				GenerateEnvelopes.Checked = SLA.GenerateEnvelopesOnly = true;
		}

		protected void LoadData()
		{
			SLA = null; // clear the cache
			this.BindScoringLoadChoices();

			// Always start off with the MORG (level = 1).
			SLA.FileName	= null;
			this.UpdateFromObject(pnlScoringLoad.Controls, SLA);
			this.UpdateFromObject(pnlScoringLoad.Controls, (ScoringLoadArguments)SLA); // radio buttons
			this.UpdateFromObject(pnlScoringLoad.Controls, (TaskArguments)SLA); // filename
		}

		/// <summary>
		/// ValidateArguments()
		/// Perform page-specific argument validation.
		/// </summary>
		/// <param name="ta"></param>
		/// <param name="directories"></param>
		/// <returns></returns>
		protected bool ValidateArguments(TaskArguments ta, bool directories)
		{
			if (!base.ValidateArguments(ta, directories) )
				return false;

			// Okay we passed the initial test, now see if the 
			// ORG (if specified) belongs to the MORG
			if ( (SLA.ORGID == -1) || (SLA.MORGID == -1) ) // "all" ORGs
				return true;

			// Okay we have specified an ORG and MORG, make sure they are related
			OrganizationSummary org = this.SLA.ORGS.FindBy(SLA.ORGID);
			if (null == org)
				return false; // special message to indicate couldn't find the ORG ???

			// Okay we have the Organization, check it's parent id
			if (org.ParentOrganizationID != SLA.MORGID)
			{
				this.SetPageMessage("@ORGMORGMISMATCH@", EnumPageMessageType.AddError, ta.FileName);
				return false;
			}
			return true;
		}

		protected bool SaveData()
		{
			this.UpdateToObject(pnlScoringLoad.Controls, SLA); // our MORG/ORG info
			this.UpdateToObject(pnlScoringLoad.Controls, (ScoringLoadArguments)SLA); // get employerletterid & others
			this.UpdateToObject(pnlScoringLoad.Controls, (TaskArguments)SLA);	// filename
			SLA.FileName	= CommDlg.FileName;
			
			// One must be checked, we defaulted to 'Generate Envelopes & Scoring load'
			if (ScoringLoadOnly.Checked)
				SLA.ScoringLoadOnly			= true;
			else if (GenerateEnvelopesOnly.Checked)
				SLA.GenerateEnvelopesOnly	= true;
			else
				SLA.GenerateEnvelopes		= true;

			if (ValidateArguments((TaskArguments)SLA, false))
			{
				// We can write this task out...
				ScheduleTask st		= new ScheduleTask();
				ScheduleTypeCollection types = ScheduleTask.ActiveScheduleTypes;
				st.ScheduleTypeID	= types.IndexBy_Code.LookupIntMember("ScheduleTypeID", "ICM");	// Scoring Load
				ScheduleStatusCollection statuses = ScheduleTask.ActiveScheduleStatuses;
				st.ScheduleStatusID = statuses.IndexBy_Code.LookupIntMember("ScheduleStatusID", "PEND");	// PENDING

				st.Task				= SLA.Task;		// create our "task" string
				st.Label			= SLA.Label;	// label to attached to the scheduled item...
				st.CreatedBy		= this.CurrentUser;
				st.CreateTime		= DateTime.Now;
				st.ScheduledTime	= DateTime.Now;

				// Insert the record into the table...
				st.Insert();

				UnloadCachedObjects(); // don't need this stuff any more
				return true;
			}
			return false;
		}

		/// <summary>
		/// UnloadCachedObjects()
		/// This method will remove from the cache any objects we don't 
		/// need.
		/// </summary>
		private void UnloadCachedObjects()
		{
			this.SLA = null;
		}

		public void OnToolbarButtonClick_Update(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@SCORINGLOAD@");
			}
		}

		protected ScoringLoadArgs sla = null;
		protected ScoringLoadArgs SLA
		{
			get
			{
				if (null == sla)
				{
					sla = (ScoringLoadArgs)LoadObject(typeof(ScoringLoadArgs), true); // create if it doesn't exist
				}
				return sla;
			}
			set { CacheObject(typeof(ScoringLoadArgs), value); }
		}

		private void MORGID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			// See if the MORG we selected has an ICMID of 'ICM'
			int morgid = 0;
			try
			{
				morgid = Convert.ToInt32(MORGID.Value);
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				this.SetPageMessage("Error reading MORG value", EnumPageMessageType.Error);
				return;
			}
			if (null == SLA)
			{
				this.SetPageMessage("Error reading from cache", EnumPageMessageType.Error);
				return;
			}

			// Okay we recovered the arguments, get to the MORGS
			string ICMflag = null;
			foreach(OrganizationSummary os in SLA.MORGS)
			{
				if (os.OrganizationID == morgid) // find one we selected
				{
					ICMflag = os.ICMID;
					break;
				}
			}

			// ICMflag is either:
			//    null ........... do nothing
			//    "ICM" .......... enable some items
			//    "Anthem FP" ....
			//    "Anthem NA" ....
			EnableControls(ICMflag);
		}

		private void ORGID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			// See if the ORG we selected has an ICMID of 'ICM'
			int orgid = 0;
			try
			{
				orgid = Convert.ToInt32(ORGID.Value);
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				SetPageMessage("Error reading ORGID", EnumPageMessageType.Error);
				return;
			}

			if (null == SLA)
			{
				this.SetPageMessage("Error reading from cache", EnumPageMessageType.Error);
				return;
			}

			// Okay we recovered the arguments, get to the MORGS
			string ICMflag = null;
			foreach(OrganizationSummary os in SLA.ORGS)
			{
				if (os.OrganizationID == orgid) // find one we selected
				{
					ICMflag = os.ICMID;
					break;
				}
			}

			// ICMflag is either:
			//    null ........... do nothing
			//    "ICM" .......... enable some items
			//    "Anthem FP" ....
			//    "Anthem NA" ....
			EnableControls(ICMflag);
		}

		void EnableControls(string ICMflag)
		{
			GenerateEnvelopes.Enabled	= true;
			lbGenerateEnvelopes.Enabled	= true;
		}

	}// end of class

	[TableMapping(null)]
	public class ScoringLoadArgs : ScoringLoadArguments
	{
		int morgid = 0;
		[FieldValuesMember("LookupOf_MORGID", "OrganizationID", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int MORGID
		{
			get { return this.morgid; }
			set
			{ 
				this.morgid = value;
				this.morg = (morgid == -1 ? "0" : this.morgid.ToString());
			}
		}

		int orgid = 0;
		[FieldValuesMember("LookupOf_ORGID", "OrganizationID", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int ORGID
		{
			get { return this.orgid; }
			set
			{ 
				this.orgid = value;
				this.org	= (orgid == -1 ? "0" : orgid.ToString());
			}
		}

		public OrganizationSummaryCollection MORGS
		{
			get
			{ 
				if (null == morgs)
				{
					morgs = new OrganizationSummaryCollection();
					morgs.GetOrganizationsByLevelICMflag(-1, 1);
					OrganizationSummary os = new OrganizationSummary();
					os.OrganizationID = -1; os.Selected = true; os.Name = "ALL";
					morgs.InsertRecord(0, os);
				}
				return morgs;
			}
		}

		public OrganizationSummaryCollection ORGS
		{
			get
			{
				if (null == orgs)
				{
					orgs = new OrganizationSummaryCollection();
					orgs.GetOrganizationsByLevelICMflag(-1, 2);
					OrganizationSummary os = new OrganizationSummary();
					os.OrganizationID = -1; os.Selected = true; os.Name = "ALL";
					orgs.InsertRecord(0, os);
				}
				return orgs;
			}
		}

		/// <summary>
		/// LookupOf_OrgLevelID
		/// returns a collection of schedule types, the first record
		/// being "ALL".
		/// </summary>
		OrganizationSummaryCollection morgs = null;
		public OrganizationSummaryCollection LookupOf_MORGID
		{
			get	{ return MORGS; }
		}

		OrganizationSummaryCollection orgs = null;
		public OrganizationSummaryCollection LookupOf_ORGID
		{
			get	{ return ORGS; }
		}

	}// end of class


}// end of namespace
