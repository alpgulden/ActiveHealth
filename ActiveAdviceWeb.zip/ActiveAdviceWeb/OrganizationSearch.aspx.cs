using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Search organizations
	/// </summary>

	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ORGANIZATIONS )]

	[MainLanguageClass("ActiveAdvice.Messages.OrgMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Organization,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MOrganizations")]
	public class OrganizationSearch : OrganizationBasePage
	{
		private int level = 0;		// if level is specified, search will be free but not for a specific parent
		private int pickLevel = 0;		// what level of organization is allowed to pick
		private Organization parentOrganization;		// the parent org whose chil orgs are being managed
		private Organization organizationSearcher;
		private OrgSynonym synonymSearcher;
		private OrganizationCollection col;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMasterOrg;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Type;
		protected NetsoftUSA.WebForms.OBFieldLabel lbType;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.WebForms.OBLabel GridTitle;
		protected System.Web.UI.HtmlControls.HtmlTable tblSynonym;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Synonym;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSynonym;
		protected System.Web.UI.HtmlControls.HtmlTable tblSearch;
		protected NetsoftUSA.WebForms.OBLabel SearchTitle;
		protected System.Web.UI.WebControls.CheckBox chkEffectiveOnly;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;

		private int planID = 0;			// search sub-organizations linked to this plan only

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				LoadData();				
			}
			else
			{
				col = (OrganizationCollection)this.LoadObject(typeof(OrganizationCollection), true);	// This would reload from cache
				organizationSearcher = (Organization)this.LoadObject("OrganizationSearcher");
				synonymSearcher = (OrgSynonym)this.LoadObject("SynonymSearcher");
				parentOrganization = (Organization)this.LoadObject("ParentOrganization");
			}
			this.SelectedSideMenuItem = "Search_"+ level.ToString();
		}

		/// <summary>
		/// Organization level currently being managed
		/// </summary>
		public int OrganizationLevelManaged
		{
			get 
			{ 
				if (level > 0)
					return level;
				// if there's no parent, top level is being managed
				if (this.parentOrganization == null)
					return 1;
				else	// if there's a parent, parent level + 1 is being managed
					return this.parentOrganization.OrganizationLevelID + 1;
			}
		}

		public static void Redirect(Organization parentOrganization)
		{
			Redirect(parentOrganization, false);
		}

		public static void Redirect(Organization parentOrganization, bool autoSearch)
		{
			BasePage.PushParam("ParentOrganization", parentOrganization);
			BasePage.PushParam("AutoSearch", autoSearch);
			Redirect("OrganizationSearch.aspx");
		}

		public static void Redirect(int level)
		{
			BasePage.PushParam("Level", level);
			Redirect("OrganizationSearch.aspx");
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			OrganizationCollection col = new OrganizationCollection();
			try
			{	// use any load method here

				// if a level was passed, search in that level freely.  no parentid will be used.
				// a level may be passed from the query string or as a session parameter
				int passedLevel = 0;
				if (this.Request.QueryString["PlanID"] != null)
					planID = Convert.ToInt32(this.Request.QueryString["PlanID"]);
				if (this.Request.QueryString["Level"] != null)
					passedLevel = Convert.ToInt32(this.Request.QueryString["Level"]);
				else if (this.HasParam("Level"))
					passedLevel = this.GetParamInt("Level", 1);
				if (passedLevel == -1)
					passedLevel = OrganizationLevel.MaxLevel;

				if (this.Request.QueryString["PickLevel"] != null)
				{
					this.pickLevel = Convert.ToInt32(this.Request.QueryString["PickLevel"]);
					if (pickLevel == -1)
						pickLevel = OrganizationLevel.MaxLevel;
					if (pickLevel == -2)		// any level
						pickLevel = -2;
				}

				if (passedLevel > 0)
				{
					this.level = passedLevel;		// search all in given level.
					this.parentOrganization = null;	// remove parent org context.
				}
				else
				{
					// search for the given parent
					parentOrganization = GetParamOrGetFromCache("ParentOrganization", "ParentOrganization") as Organization;
					/*if (parentOrganization != null)
					{
						this.level = parentOrganization.OrganizationLevelID;
					}*/
				}
				bool autoSearch = this.GetParamBool("AutoSearch", false);
				this.CacheObject("ParentOrganization", parentOrganization);
				//	if (parentOrganization.IsSubOrganization)
				//		this.RaisePageException(new Exception("A sub-organiz

				result = this.NewOrganizationSearch();
				if (!result)
					return false;

				if (this.WasCancelled)
				{
					Organization org = (Organization)this.LoadObject("OrganizationSearcher_" + this.OrganizationLevelManaged.ToString() );
					if (org != null)
					{
						org.CopyMappedMembersTo(this.organizationSearcher, false, false, false);
						this.OrganizationSearcher = this.organizationSearcher;	// refresh
						autoSearch = true;
					}
				}

				if (planID != 0)
				{
					LoadOrganizationsOfPlan();
				}
				else
				{
					if (autoSearch)
						SearchOrganizations();
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//obj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			//this.MORGs = col;		// When you set the object to the property, controls are automatically populated
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public OrganizationCollection Organizations
		{
			get { return col; }
			set
			{
				col = value;
				try
				{
					// add all object-to-control population code here
					grid.KeepCollectionIndices = false;
					grid.UpdateFromCollection(col);
					if(col.Count >= OrganizationCollection.MAXRECORDS)
						this.SetPageMessage("@BIGGERRESULTSET@", EnumPageMessageType.AddInfo, OrganizationCollection.MAXRECORDS, Messages.OrgMessages.MessageIDs.ORGANIZATIONS);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject(typeof(MORGCollection), col);  // cache object using the caching method declared on the page
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.grid.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.grid_DblClick);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.grid.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.grid_RowBoundToDataObject);
			this.grid.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grid_ColumnsBoundToDataClass);
			this.grid.PageIndexChanged += new Infragistics.WebUI.UltraWebGrid.PageIndexChangedEventHandler(this.grid_PageIndexChanged);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void grid_RowBoundToDataObject(object sender, NetsoftUSA.InfragisticsWeb.RowBindingEventArgs e)
		{
			UltraGridCell cell = e.row.Cells.FromKey("Pick");
			if (cell != null)
			{
				Organization sorg = e.data as Organization;
				string sorgPathHTML = CreateOrgPathHTML(null, sorg);
				string orgIDs = sorg.OrganizationFullPath;

				object planID = null;
				string planName = null;
				// if there's a single plan of linked to the organization, return it in the parameters
				if (this.planID != 0)
				{
					planID = this.planID;
				}
				else
				{
					// no specific planID was given in the query string, just use the plan if there's one.
					sorg.LoadPlanSORGs(false);
					if (sorg.PlanSORGs.Count == 1)
					{
						PlanSORG planSORG = sorg.PlanSORGs[0];
						planID = planSORG.PlanId;
						planName = planSORG.PlanName;
					}
				}
				e.row.Cells.FromKey("Pick").Text = GetCallbackFunctionHyperLink("Pick", sorg.OrganizationID, sorgPathHTML, sorg.Name, orgIDs, planID, planName);
			}
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = grid.GetPKFromCellEvent(e);
			if (e.Cell.Key == "Edit")
			{
				try
				{
					OrganizationForm.Redirect((int)pk[0]);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
			else if (e.Cell.Key == "Children")
			{
				Organization org = new Organization();
				if (org.Load((int)pk[0]))
					OrganizationSearch.Redirect(org, true);
			}
		}

		private void grid_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			if (!this.organizationSearcher.IsSubOrganization)
			{
				grid.AddButtonColumn("Children", this.organizationSearcher.OrganizationSubLevelCodePlural);
			}
			//else
			if (this.HasCallbackFunction)
			{
				if (pickLevel != 0)
				{
					// this is a suborganization
					if (pickLevel == -2 || pickLevel == this.organizationSearcher.OrganizationLevelID)	// any level
						grid.AddColumnWithButtonLook("Pick", "@PICK@", 0);
				}
			}
			else
			{
				grid.AddButtonColumn("Edit", "@EDIT@", 0).Width = 60;
			}
		}

		private void grid_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = grid.GetPKFromClickEvent(e);
				if (pk != null)
					OrganizationForm.Redirect((int)pk[0]);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Display on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
				if (!this.IsPopup)
					toolbar.AddButton(OrgMessages.MessageIDs.ADDNEWRECORD, "AddNew");
			}
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			if (this.parentOrganization != null)
			{
				toolbar.AddButton("Back to " + this.parentOrganization.OrganizationLevelCodePlural, "BackToParents");
				toolbar.AddButton("Back to " + this.parentOrganization.OrganizationLevelCode, "BackToParent");
			}
			else
			{
				Infragistics.WebUI.UltraWebToolbar.TBarButton CancelButton = toolbar.AddButton("@CANCEL@", "Cancel").Item;
				if (this.IsPopup)
				{
					CancelButton.Text = this.BaseMessages.CLOSE;
					CancelButton.TargetURL = "javascript:window.close();";
				}
			}
		}

		public void OnToolbarButtonClick_BackToParent(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PushCancelled();
			OrganizationForm.Redirect(this.parentOrganization);		// continue editing parent
		}

		public void OnToolbarButtonClick_BackToParents(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PushCancelled();
			OrganizationSearch.Redirect(this.parentOrganization.ParentOrganization, true);		// continue editing parent
		}

		public new void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			//if (this.parentOrganization == null || this.parentOrganization.IsMasterOrganization)
			//	base.OnToolbarButtonClick_Cancel(toolbar, button);
			//else
			if (this.parentOrganization == null || this.parentOrganization.IsMasterOrganization)
				OrganizationSearch.Redirect(null);
			else
				OrganizationForm.Redirect(this.parentOrganization);		// continue editing parent
		}

		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewOrganizationSearch();
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// An organization can be created only under a parent!
			OrganizationForm.RedirectNew(this.parentOrganization);
		}

		public override void OnSubNavigationItemClick(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			if (item.Key.Length > 7)
			{
				if (item.Key.Substring(0, 7) == "Search_")
				{
					string slevel = item.Key.Substring(7);
					int level = Convert.ToInt32(slevel);
					if (this.pickLevel != 0)
					{
						OrganizationSearch.Redirect("OrganizationSearch.aspx?Level=" + level + "&PickLevel=" + this.pickLevel + "&CallBackFunction=" + this.CallbackFunction);
						return;
					}
				}
			}
			
			base.OnSubNavigationItemClick (listbar, item);
		}

		public override void PopulateTabItems(WebTab webTab)
		{
			base.PopulateTabItems (webTab);

			webTab.AddTab("@SEARCH@", "Search");
			//webTab.AddTab("@MORG@", "Result");
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Organization OrganizationSearcher
		{
			get { return organizationSearcher; }
			set
			{
				organizationSearcher = value;
				try
				{
					this.UpdateFromObject(tblSearch.Controls, organizationSearcher);  // update controls for the given control collection
					GridTitle.SourceObject = this.organizationSearcher;
					GridTitle.UpdateData(false);
					SearchTitle.SourceObject = organizationSearcher;
					SearchTitle.UpdateData(false);
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("OrganizationSearcher", organizationSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public OrgSynonym SynonymSearcher
		{
			get { return synonymSearcher; }
			set
			{
				synonymSearcher = value;
				try
				{
					this.UpdateFromObject(tblSynonym.Controls, synonymSearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("SynonymSearcher", synonymSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForOrganizationSearch()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(tblSearch.Controls, organizationSearcher);	// controls-to-object
				this.UpdateToObject(tblSynonym.Controls, synonymSearcher);
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewOrganizationSearch()
		{
			bool result = true;
			Organization organizationSearcher = null;

			if (level > 0)
				organizationSearcher = Organization.CreateSearcherForLevel(level);
			else
				organizationSearcher = Organization.CreateSearcherForParent(this.parentOrganization);
			OrgSynonym synonymSearcher = new OrgSynonym(true);
			try
			{	// or use an initialization method here
				//organizationSearcher.NewSearcher();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.OrganizationSearcher = organizationSearcher;
			this.SynonymSearcher = synonymSearcher;
			//PageTab.SelectedTab = 0;
			return result;
		}

		public bool SearchOrganizations()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForOrganizationSearch())
					return false;
				this.col = new OrganizationCollection();

				this.CacheObject("OrganizationSearcher_" + this.OrganizationLevelManaged.ToString(), organizationSearcher);  // cache object using the caching method declared on the page
				this.col.SearchOrganizationsBySynonym(-1, organizationSearcher, 0, synonymSearcher.Name, false, chkEffectiveOnly.Checked, level);
				this.Organizations = this.col;
				//PageTab.SelectedTab = 1;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public bool LoadOrganizationsOfPlan()
		{
			try
			{	// data from controls to object
				//if (!this.ReadControlsForOrganizationSearch())
				//	return false;
				this.col = new OrganizationCollection();

				this.CacheObject("OrganizationSearcher_" + this.OrganizationLevelManaged.ToString(), organizationSearcher);  // cache object using the caching method declared on the page
				this.col.LoadOrganizationsOfPlan(planID);
				this.Organizations = this.col;
				//PageTab.SelectedTab = 1;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/*public bool SearchBySynonym()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForOrganizationSearch())
					return false;
				this.col.LoadBySynonym(synonymSearcher.Name, false);
				this.Organizations = this.col;
				//PageTab.SelectedTab = 1;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}*/

		private void grid_PageIndexChanged(object sender, Infragistics.WebUI.UltraWebGrid.PageEventArgs e)
		{
			//grid.UpdateFromCollection(e.NewPageIndex, this.col);
			//e.NewPageIndex;
			//grid.DisplayLayout.Pager.CurrentPageIndex = e.NewPageIndex;
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			SearchOrganizations();
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.parentOrganization);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			Synonym.Visible = this.organizationSearcher.IsSubOrganization;
			lbSynonym.Visible = Synonym.Visible;
		}

		protected override object SaveViewState()
		{
			ViewState["Level"] = this.level;
			ViewState["PickLevel"] = this.pickLevel;
			return base.SaveViewState ();
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			this.level = (int)ViewState["Level"];
			this.pickLevel = (int)ViewState["PickLevel"];
		}


	}
}
