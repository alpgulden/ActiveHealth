using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>

	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.REFERRALS)]

	[MainLanguageClass("ActiveAdvice.Messages.ReferralMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Referral,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[BackPage(typeof(PatientSummaryForm))]
	[PageTitle("@REFERRAL@")]
public class ReferralForm : PatientBasePage
{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
	private Referral referral;
	private ReferralCollection referralCol;
	private ReferralCollection possibleDuplicateReferrals;
	private ReferralDetail referralDetail;
	private ReferralAppointment referralAppointment;
	private ReferralReportEntry referralReportEntry;
	private bool newRD=false;
	private bool loadRD=false;
	private bool childRD=false;   // set when a child of referral detail needed to be save.
	private Patient patient;
	private Problem problem;
	private PatientCoverage patientCoverage;
	private WindowOpener woProblemLink;
	private WindowOpener wo;
	protected ProviderSelect ProviderSelect;
	protected ProviderSelect RefProviderSelect;
	protected ProviderSelect RefToSelect;

	protected NetsoftUSA.InfragisticsWeb.WebValidator vldCreateTime;
	protected NetsoftUSA.WebForms.OBFieldLabel lbCompany;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit Company;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferralTypeId;
	protected NetsoftUSA.WebForms.OBLabel OBLabel8;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlClinical;
	protected NetsoftUSA.WebForms.OBTextBox OBTextBox1;
	protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel6;
	protected NetsoftUSA.WebForms.OBFieldLabel lbDecisionReasonID;
	protected NetsoftUSA.WebForms.OBTextBox Reason;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReason;
	protected NetsoftUSA.WebForms.OBFieldLabel lbValidStartDate;
	protected NetsoftUSA.WebForms.OBFieldLabel lbValidEndDate;
	protected NetsoftUSA.WebForms.OBFieldLabel lbAuthorizationDecisionID;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralDetailDate;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferralUrgencyID;	
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferralAuthorizationDecisionID;
	protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ValidStartDate;
		protected NetsoftUSA.WebForms.OBComboBox ReferralUrgencyID;
		protected NetsoftUSA.WebForms.OBComboBox ReferralAuthorizationDecisionID;
	protected NetsoftUSA.WebForms.OBFieldLabel Obfieldlabel2;
	protected NetsoftUSA.WebForms.OBTextBox UnitQuantity;
		protected NetsoftUSA.WebForms.OBComboBox UnitTypeID;
	protected NetsoftUSA.WebForms.OBLabel OBLabel6;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlClinicalView;
	protected NetsoftUSA.InfragisticsWeb.WebGrid gridReferralAppointments;
	protected NetsoftUSA.InfragisticsWeb.WebGrid gridReferralDetail;
	protected NetsoftUSA.InfragisticsWeb.WebGrid gridDuplicates;
	protected NetsoftUSA.InfragisticsWeb.WebGrid gridReferral;
	protected NetsoftUSA.WebForms.OBLabel Oblabel2;
	protected NetsoftUSA.WebForms.OBLabel Oblabel3;
	protected NetsoftUSA.InfragisticsWeb.WebGrid gridReferralReportEntry;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReports;
	protected NetsoftUSA.InfragisticsWeb.WebCombo Webcombo1;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAppointments;
	protected NetsoftUSA.WebForms.OBLabel lbRecordDescription;
	protected NetsoftUSA.WebForms.OBFieldLabel lbUnitQuantity;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDuplicates;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReferralView;
	protected NetsoftUSA.WebForms.OBLabel Oblabel8;
	protected NetsoftUSA.WebForms.OBTextBox ReferralDetailReferralID;
	protected NetsoftUSA.InfragisticsWeb.WebValidator valReferralDetailDate;
	protected NetsoftUSA.InfragisticsWeb.WebValidator valUnitQuantity;
	protected NetsoftUSA.InfragisticsWeb.WebValidator valUnitTypeID;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferralID2;
	protected NetsoftUSA.InfragisticsWeb.WebButton butSaveAppointment;
	protected NetsoftUSA.InfragisticsWeb.WebButton butDeleteAppointment;
	protected NetsoftUSA.InfragisticsWeb.WebButton butDeleteReports;
	protected NetsoftUSA.WebForms.OBFieldLabel lbAppointmentDate;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferralDetailDate;
	protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ReferralDetailDate;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit lbempty;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit ReferredToPCPPager;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferredToPCPPager;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit ReferredToPCPFax;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferredToPCPFax;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit ReferredToPCPPhone;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferredToPCPPhone;
	protected NetsoftUSA.WebForms.OBLabel Oblabel7;
	protected NetsoftUSA.WebForms.OBLabel Oblabel1;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferralDescription;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit ReferralDescription;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralTypeID;
		protected NetsoftUSA.WebForms.OBComboBox ReferralTypeID;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferralTypeID;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReferral;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPCP;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReferredFrom;
	protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
	protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
	protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PCPNetworkID;
	protected NetsoftUSA.WebForms.OBFieldLabel lbPCPNetworkID;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit PCPFullLocation;
	protected NetsoftUSA.WebForms.OBFieldLabel lbPCPFullLocation;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit PCPFullName;
	protected NetsoftUSA.WebForms.OBFieldLabel lbPCPFullName;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit PCPPager;
	protected NetsoftUSA.WebForms.OBFieldLabel lbPCPPager;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit PCPFax;
	protected NetsoftUSA.WebForms.OBFieldLabel lbPCPFax;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit PCPPhone;
	protected NetsoftUSA.WebForms.OBFieldLabel lbPCPPhone;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldValidEndDate;
	protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ValidEndDate;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldAppointmentDate;
	protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit AppointmentDate;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferralStatusID;
		protected NetsoftUSA.WebForms.OBComboBox ReferralStatusID;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralStatusID;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralAuthorizationDecisionID;
	protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder6;
	protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder1;
	protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder8;
	protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder9;
	protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder7;
	protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder3;
	protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder2;
	protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder4;
	protected NetsoftUSA.InfragisticsWeb.ContentPlaceHolder Contentplaceholder5;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferredToProviderNetworkID;
	protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ReferredToProviderNetworkID;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferredToProviderNetworkID;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferredToPCPFullLocation;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit ReferredToPCPFullLocation;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferredToPCPFullLocation;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferredToPCPFullName;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit ReferredToPCPFullName;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferredToPCPFullName;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferralScheduledByID;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralScheduledByID;
		protected NetsoftUSA.WebForms.OBComboBox ReferralScheduledByID;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReferredTo;
	protected NetsoftUSA.WebForms.OBLabel Oblabel12;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAdministration;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlProviderSelect;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralStartDate;
	protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ReferralStartDate;
	protected NetsoftUSA.WebForms.OBFieldLabel lbReferralStartDate;
	protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateReferralID;
	protected AdministrationControl AdministrationControl;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAppointmentForm;
	protected NetsoftUSA.InfragisticsWeb.WebButton butNewAppointment;
	protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAddOther;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldProviderLocationID;
	protected NetsoftUSA.WebForms.OBFieldLabel lbProviderLocationID;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit ReportEntryName;
	protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
	protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ProviderLocationID;
	protected NetsoftUSA.InfragisticsWeb.WebButton butAddOther;
	protected NetsoftUSA.InfragisticsWeb.WebButton butCancelOther;
	protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForSORG;
	protected System.Web.UI.HtmlControls.HtmlTable tblAppointmentForm;
		
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldDecisionReasonID;
		protected NetsoftUSA.WebForms.OBComboBox DecisionReasonID;
	protected NetsoftUSA.WebForms.OBRadioButtonBox ReferredToOption;
	protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternateReferralID;
	protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateReferralID;
	protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CreateTime;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ReferralID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferralID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.InfragisticsWeb.WebButton butGenerateLetter;
	protected UserDefined UserDefined1;	
    int vSessionIndicator;

private void Page_Load(object sender, System.EventArgs e)
{
	//Provider select	
	this.ProviderSelect.RebindControls(typeof(Referral), "@PCP@", 
		ProviderSearcherType.Provider, null,
		"PCPID", "PCPLocationID", "PCPSpecialtyID", "PCPNetworkID", "PCPNetworkStatus","ReferralStartDate");
	UserDefined1.ReloadContext("Referral",referral,true);
	if(!UserDefined1.HasFields())
		this.PageTab.GetTab("REF_UserDefined").Visible= false;
	// Ref Provider select
	this.RefProviderSelect.RebindControls(typeof(Referral), "@REFERREDFROM@", 
		ProviderSearcherType.Provider, null,
		"ReferredFromProviderID", "ReferredFromLocationID", "ReferredFromSpecialtyID", "ReferredFromNetworkID", "ReferredFromNetworkStatus","ReferralStartDate");

//	// RefTo select
//	int selection;
//	if(referral!=null && referral.ReferredToType>0)
//		selection = this.ReferredToOption.SelectedIndex=referral.ReferredToType-1;
//	if(this.ReferredToOption.SelectedItem==null)
//		selection =1;
//	else
//		selection = int.Parse(this.ReferredToOption.SelectedItem.Value);
//	
//	CallPCPFaciltyGP(selection);
	
	this.tblAppointmentForm.Visible=false;
	this.butNewAppointment.Visible=true;
	this.butGenerateLetter.Visible=true;
	if (!this.IsPostBack)
	{
		newRD				= false;
		loadRD				= false;
		childRD				= false;
//		this.NewRD	= false;
//		this.LoadRD= false;
//		this.ChildRD= false;
		BindReferredToOption();
		if(this.UnitQuantity.Text == "0")
			this.UnitQuantity.Text ="";
		this.LoadData();			// Load data is the actual data loading method		
	}
	else
	{
		patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
		problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
		patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
		referral = (Referral)this.LoadObject(typeof(Referral));	// This would reload from cache
		referralCol = (ReferralCollection)this.LoadObject(typeof(ReferralCollection));	// This would reload from cache
		referralDetail = (ReferralDetail)this.LoadObject(typeof(ReferralDetail));
		referralAppointment = (ReferralAppointment)this.LoadObject(typeof(ReferralAppointment));
		referralReportEntry = (ReferralReportEntry)this.LoadObject(typeof(ReferralReportEntry));

		possibleDuplicateReferrals = (ReferralCollection)this.LoadObject("possibleDuplicateReferrals");  // load object from cache

//		if (referralDetail != null)
//		{
//			referralDetail.LoadReferralAppointments(false);
//			if(referralDetail.ReferralAppointments!=null && referralDetail.ReferralAppointments.Count>0)
//			{
//				referralAppointment=(ReferralAppointment)referralDetail.ReferralAppointments[0];
//				this.ReferralAppointment = referralAppointment;
//			}
//			referralDetail.LoadReferralReportEntries(false);
//			if(referralDetail.ReferralReportEntries!=null && referralDetail.ReferralReportEntries.Count>0)
//			{
//				referralReportEntry=(ReferralReportEntry)referralDetail.ReferralReportEntries[0];
//				this.ReferralReportEntry = referralReportEntry;
//			}
//		}

		//if (this.Cache["newRD"]!=null)
			//newRD = bool.Parse(this.Cache["newRD"].ToString());		
		//if (this.Cache["loadRD"]!=null)
			//loadRD = bool.Parse(this.Cache["loadRD"].ToString());
		//if (this.Cache["childRD"]!=null)
			//childRD = bool.Parse(this.Cache["childRD"].ToString());

		// RefTo select
		int selection;
		selection = int.Parse(this.ReferredToOption.SelectedItem.Value);

//		if(referral!=null && referral.ReferredToType>0)
//			selection = referral.ReferredToType;
//		else
//			selection = int.Parse(this.ReferredToOption.SelectedItem.Value);

		RebindPCPFaciltyGP(selection);


//		if(this.ReferredToOption.SelectedItem==null)
//			selection =1;
//		else
//			selection = int.Parse(this.ReferredToOption.SelectedItem.Value);
//		if(referral!=null && referral.ReferredToType>0)
//		{
//			if(selection != referral.ReferredToType)
//			{
//				this.ReferredToOption.SelectedIndex=referral.ReferredToType-1;
//				selection = referral.ReferredToType;
//			}
//		}


	}

}


	public override void OnSubNavigationItemClick(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
	{
		if (item.Key == "CustomLetter")
		{
			if((this.newRD || this.loadRD) && referralDetail != null && !referralDetail.IsNew)
			{
				LetterSearch.Redirect(this.patient, this.referral, referralDetail);	
			}
		}
		
		base.OnSubNavigationItemClick (listbar, item);
	}

	protected override void OnPreRender(EventArgs e)
	{		
		base.OnPreRender (e);
		if (referral == null)
		{
			/*StringBuilder s = new StringBuilder();
			s.Append("<SCRIPT>\n");
			s.Append("function formLoad(){}\n");
			s.Append("</SCRIPT>\n");
			this.RegisterClientScriptBlock("formLoad",  s.ToString());
			this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, "Referral was not created/set"));
			return;*/
		}		
		if(referralDetail!=null && !referralDetail.IsNew)
		{
			if(referral.ReferralDetails.Count>0)
			{
				//appointments
				//SetPageTabToolbarItemEnabled("AddNewAppointment", true);
				butSaveAppointment.Enabled=true;				
				if(referralAppointment!=null)
				{
					butDeleteAppointment.Enabled=false;
					// This part can be done by makinf referralAppointment null for new appointments.
					if(referralDetail.ReferralAppointments!=null)
					{
						foreach(object tmp in referralDetail.ReferralAppointments)
						{
							if(tmp.Equals((object)referralAppointment))
								butDeleteAppointment.Enabled=true;
						}
					}
				}
				// reports
				SetPageTabToolbarItemEnabled("AddPCP", referral.PCPID!=0);
				SetPageTabToolbarItemEnabled("AddReferrer", referral.ReferredFromProviderID!=0);
				SetPageTabToolbarItemEnabled("AddOther", true);
				if(referralReportEntry!=null)
				{
					butDeleteReports.Enabled=false;
					// This part can be done by makinf referralAppointment null for new appointments.
					if(referralDetail.ReferralReportEntries!=null)
					{
						foreach(object tmp in referralDetail.ReferralReportEntries)
						{						
							if(tmp.Equals((object)referralReportEntry))
								butDeleteReports.Enabled=true;
							if(referral.ReferredFromLocationID !=0)
							{
								if((int)referral.ReferredFromLocationID==(int)((ReferralReportEntry)tmp).ProviderLocationID)
									SetPageTabToolbarItemEnabled("AddReferrer", false);
							}
							if(referral.PCPLocationID !=0)
							{
								if((int)referral.PCPLocationID ==(int)((ReferralReportEntry)tmp).ProviderLocationID)
									SetPageTabToolbarItemEnabled("AddPCP", false);
							}
						}
					}
				}
			}
		}
		else
		{
			//SetPageTabToolbarItemEnabled("AddNewAppointment", false);
			SetPageTabToolbarItemEnabled("AddPCP", false);
			SetPageTabToolbarItemEnabled("AddReferrer", false);
			SetPageTabToolbarItemEnabled("AddOther", false);
			butSaveAppointment.Enabled=false;
			butDeleteAppointment.Enabled=false;
			butDeleteReports.Enabled=false;
		}
		// client side function generator
		this.RenderClientFunctions(pnlClinical.Controls, this.referralDetail, "OnCalcClinical");
		this.RenderClientFunctions(pnlAppointments.Controls, this.referralAppointment, "OnCalcAppoinment");
		// added 04/10/2005 //*
		SetPageTabItemEnabled("DXPX_DXPX",!(referral!=null && referral.IsNew));
		SetPageTabItemEnabled("OUT_Outcomes",!(referral!=null && referral.IsNew));
		SetPageTabItemEnabled("REF_Reports",!(referral!=null && referral.IsNew));
		if(referral!=null && referral.IsNew)
		{
			lbReferralID2.Visible=false;
			ReferralDetailReferralID.Visible=false;
			SetPageTabToolbarItemVisible("LinkProblem",false);
			SetPageTabToolbarItemVisible("AddNewReferral",false);
		}

		if(referralDetail!=null && referralDetail.IsNew)
		{
			SetPageTabToolbarItemVisible("AddNewClinical",false);
			SetPageTabToolbarItemVisible("ViewAll",false);			
		}
		else
		{
			//ActiveRow.Selected commentout
			if(referral.ReferralDetails!=null && referral.ReferralDetails.Count>0)
			{
				for(int i=0;i<=referral.ReferralDetails.Count;i++)
			{
					if(referral.ReferralDetails[i].IsPKEqual(referralDetail)) 			
					{
						gridReferralDetail.SelectedRowIndex = i;						
						gridReferralDetail.DisplayLayout.ActiveRow.Selected=true;
						break;
					}
				}
			}
		}
		//


//		if(referralDetail.ReferralAppointments!=null && referralDetail.ReferralAppointments.Count>0)
//		{
//			if(this.gridReferralAppointments.SelectedRowIndex>0)
//				gridReferralAppointments.DisplayLayout.ActiveRow.Selected=true;
//			else if(this.gridReferralAppointments.SelectedRowIndex==0)
//			{
//				gridReferralAppointments.DisplayLayout.ActiveRow.Selected=true;
//				referralAppointment = referralDetail.ReferralAppointments[0];
//			}
//		}
//		if(referralDetail.ReferralReportEntries!=null && referralDetail.ReferralReportEntries.Count>0)
//		{
//			if(this.gridReferralReportEntry.SelectedRowIndex>0)
//				gridReferralReportEntry.DisplayLayout.ActiveRow.Selected=true;
//			else if(this.gridReferralReportEntry.SelectedRowIndex==0)
//			{
//				gridReferralReportEntry.DisplayLayout.ActiveRow.Selected=true;
//				referralReportEntry = referralDetail.ReferralReportEntries[0];
//			}
//		}

		this.CreateTime.ClientVisible = false;


		bool duplicatesMode = this.possibleDuplicateReferrals != null;
		this.SetPageTabItemVisible("REF_Duplicates", duplicatesMode);
		this.SetPageTabItemVisible("REF_Referral", !duplicatesMode);
		this.SetPageTabItemVisible("REF_Clinical", !duplicatesMode);
		this.SetPageTabItemVisible("REF_Reports", !duplicatesMode);
		this.SetPageTabItemVisible("REF_Administration", !duplicatesMode);
		this.SetPageTabItemVisible("REF_UserDefined", !duplicatesMode);

		this.SetPageTabItemVisible("OUT_Outcomes", !duplicatesMode);
		this.SetPageTabItemVisible("DXPX_DXPX", !duplicatesMode);

		if (duplicatesMode)
			if (!this.PageError)
				this.SetPageMessage("@REFERRALPOSSIBDUP@", EnumPageMessageType.Warning);

		
	}

	private void BindReferredToOption()
	{
		ReferToType referToType = new ReferToType();

		ReferredToOption.Items.Clear();
		if(referToType.LoadReferToTypeByCode("PROV"))
			ReferredToOption.Items.Add(new ListItem("Provider",referToType.ReferToTypeID.ToString()));
		if(referToType.LoadReferToTypeByCode("FAC"))
			ReferredToOption.Items.Add(new ListItem("Facilities",referToType.ReferToTypeID.ToString()));
		if(referToType.LoadReferToTypeByCode("GRP"))
			ReferredToOption.Items.Add(new ListItem("GroupPractice",referToType.ReferToTypeID.ToString()));
		ReferredToOption.SelectedIndex = 0;
	}

	/// <summary>
	/// Redirect to current referral
	/// </summary>
	public static void Redirect()
	{
		BasePage.Redirect("ReferralForm.aspx");
	}

	public static void Redirect(Referral referral)
	{
		BasePage.PushParam("Referral", referral);
		BasePage.Redirect("ReferralForm.aspx");
	}

	public static void Redirect(int referralID)
	{
		Referral referral = new Referral();
		if (!referral.Load(referralID))
			throw new ActiveAdviceException("@CANTFINDRECORD@", "@REFERRAL@");
		Redirect(referral);
	}

	/// <summary>
	/// Passes the given object to the redirected page.
	/// </summary>
	public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, Referral referral)
	{
		if (patient == null || patCov == null)
			throw new ActiveAdviceException("You can open an referral only when patient and coverage are selected"); 

		//BasePage.PushCurrentCallingPage();
		BasePage.PushParam("Patient", patient);
		BasePage.PushParam("PatientCoverage", patCov);
		BasePage.PushParam("Problem", problem);
		BasePage.PushParam("Referral", referral);
		BasePage.Redirect("ReferralForm.aspx");	
	}

	public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, int referralID)
	{
		Referral obj = new Referral(true);
		if (!obj.Load(referralID))
			throw new ActiveAdviceException("@CANTFINDRECORD@", "@REFERRAL@");
		Redirect(patient, patCov, problem, obj);
	}

	public static void Redirect(CoverageSelectionContext coverageSelectionContext)
	{
		// BasePage.PushCurrentCallingPage();
		BasePage.PushParam("CoverageSelectionContext", coverageSelectionContext);
		BasePage.Redirect("ReferralForm.aspx");
	}


	/// <summary>
	/// Call this method from Page_Load or anytime you want to load data
	/// </summary>
	public bool LoadData()
	{
		bool result = true;
		int selection;
		bool toSetProperty = true;
		Referral referral = null;
		CoverageSelectionContext covSelContext = null;
		try
		{	
			PageTab.SelectedTabKey = this.TargetTabKey;		// navigate to target tab.

			// if a coverage selection context was passed, the user has selected a coverage and returned back to the problem page
			// to save the problem.
			// continue with saving.
			covSelContext = this.GetParam("CoverageSelectionContext") as CoverageSelectionContext;
			if (covSelContext != null)
			{
				
				#region Back from Coverage Selection

				try
				{
					// Back from Coverage Selection
					// Get all the context objects from the coverage selection context.
					patient = covSelContext.Patient;
					problem = covSelContext.Problem;
					patientCoverage = covSelContext.PatientCoverage;		// Newly selected coverage is here.
					referral = covSelContext.ERC as Referral;
					referralDetail = (ReferralDetail)this.LoadObject(typeof(ReferralDetail));
					if (referral == null)
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Returned from coverage selection with null Referral!");
					
					this.CacheObject(typeof(Patient), patient);
					this.CacheObject(typeof(PatientCoverage), patientCoverage);
					this.CacheObject(typeof(Problem), problem);

					// dump the coverage selection steps performed.  will be disabled at deployment.
					this.DumpCoverageSelectionContext(covSelContext);

					referral.ChangeCoverage(patientCoverage);

					if (covSelContext.IsSaving)
					{
						covSelContext.SaveERC();		// save in the coverage selection context.
						
						// need to save referralDetail and generate letter depends on status
						if(referralDetail!=null)
						{
							if (referralDetail.ParentReferralDetailCollection == null)
							{
								referral.ReferralDetails.AddRecord(referralDetail);
								//this.ReferralDetail = referralDetail;
							}
							referralDetail.ReferralID = referral.ReferralID;
							referralDetail.ParentReferralDetailCollection = referral.ReferralDetails;
							referralDetail.PatientSubscriberLogID = referral.PatientSubscriberLogID;
							referralDetail.PlanSORGLogID = referral.PlanSORGLogID;
							referralDetail.Save();

							// RefTo select	
							if(this.ReferredToOption.SelectedItem==null)
								selection =1;
							else
								selection = int.Parse(this.ReferredToOption.SelectedItem.Value);
							if(referral!=null && referral.ReferredToType>0)
							{
								if(selection != referral.ReferredToType)
								{
									this.ReferredToOption.SelectedIndex=referral.ReferredToType-1;
									selection = referral.ReferredToType;
								}
							}

							RebindPCPFaciltyGP(selection);	

							this.Referral = referral;  // cashe referral and referralDetail
							toSetProperty = false;
							// is referraldetail first record?
							if(referral.ReferralDetails.Count>0 && referral.ReferralDetails[0].IsPKEqual(referralDetail)) 
								vSessionIndicator=1;    
							else
								vSessionIndicator=2;
							SystemStatus systemStatus = new SystemStatus();
							if(referralDetail.StatusCode == SystemStatus.CLOSED)
							{
								try
								{
									LetterGenerator letterGenerator = new LetterGenerator();
									if(letterGenerator.GenerateReferralLetters(patient, referral, referralDetail, vSessionIndicator))
										this.SetPageMessage("Referral letters have been generated successfully.", EnumPageMessageType.Info);
									else
										this.SetPageMessage("There are no referral letters to be generated.", EnumPageMessageType.Info);

								}
								catch(Exception ex)
								{
									this.RaisePageException(new Exception("An error occured while generating letters.", ex));
								}
							}
						}
						this.DumpAutoActivity(referral, true);
						this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@REFERRAL@");						
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(new Exception("An error occured while coverage selection", ex));
				}

				#endregion
			}
			else
			{
				// code added by Alp to link referral with problem
				patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a plan");
				this.CacheObject(typeof(Patient), patient);
				// get the passed patient subscriber coverage (link to patient)
				patientCoverage = GetParamOrGetFromCache("PatientCoverage", typeof(PatientCoverage)) as PatientCoverage;
				if (patientCoverage == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-subscriber-coverage");
				this.CacheObject(typeof(PatientCoverage), patientCoverage);
				problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
				if (problem == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");					
				this.CacheObject(typeof(Problem), problem);
			
				// use any load method here
				referral = this.GetParamOrGetFromCache("Referral", typeof(Referral)) as Referral;
				if (referral == null)
				{
					referral = new Referral(true);
				}
				else
				{
					referral.LoadReferralDetails(false);
					if(referral.ReferralDetails!=null && referral.ReferralDetails.Count>0)
					{
						referralDetail=(ReferralDetail)referral.ReferralDetails[0];
						this.ReferralDetail = referralDetail;
					}
				}

				referral.PrimaryProblemID = problem.ProblemID;
				//referral.IsLinkedToProblem = false;
				referral.ParentPatient = patient;
				referral.PatientId = patient.PatientId;
				referral.Plan = patientCoverage.Plan;
				referral.Plan.ManagementService.LoadManagementServiceItems(false);

				//this.UpdateFromObject(pnlReferredTo.Controls, referral);

				// RefTo select				
//				if(this.ReferredToOption.SelectedItem==null)
//					selection =1;
//				else
//					selection = int.Parse(this.ReferredToOption.SelectedItem.Value);
//				if(referral!=null && referral.ReferredToType>0)
//				{
//					if(selection != referral.ReferredToType)
//					{
//						this.ReferredToOption.SelectedIndex=referral.ReferredToType-1;
//						selection = referral.ReferredToType;
//					}
//				}
//
//				RebindPCPFaciltyGP(selection);

				this.CacheObject(typeof(Referral), referral);
				this.CacheObject(typeof(BaseForEventCMSReferral), referral);
				PerDayCoverageValidation(covSelContext, this.patientCoverage, this.problem);
			}

			this.patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage)); // reload since might be changed by PerDayCoverageValidation
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			result = false;
		}
		finally
		{
			//referral.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
		}

		if(toSetProperty)  // not getin if comes from coverage.
		{
			// RefTo select	
			if(this.ReferredToOption.SelectedItem==null)
				selection =1;
			else
				selection = int.Parse(this.ReferredToOption.SelectedItem.Value);
			if(referral!=null && referral.ReferredToType>0)
			{
				if(selection != referral.ReferredToType)
				{
					this.ReferredToOption.SelectedIndex=referral.ReferredToType-1;
					selection = referral.ReferredToType;
				}
			}

			RebindPCPFaciltyGP(selection);		
			this.Referral = referral;		// When you set the object to the property, controls are automatically populated
		}
		
		return result;
	}

	
	/// <summary>
	/// Call this method when you want to retrieve data from controls and save them to table.
	/// </summary>
	public bool SaveData()
	{
		try
		{	// data from controls to object
			if (!this.ReadControls())
				return false;			

			if (possibleDuplicateReferrals == null)		// check if the possible duplicates are already being presented to the user.
			{
				// if not, check duplicates and load possible duplicates and let the user decide
				if (referral.DuplicateCheck())
				{
					LoadPossibleDuplicateReferrals();
					return false;  // let the user decide
				}
			}

			if (this.PossibleDuplicateReferrals != null)
				this.PossibleDuplicateReferrals = null;	// go out of the duplicates mode.

			if (this.referral.IsNew || this.referral.StartDateChanged)
			{
				#region Validate/Select Coverage before save

				try
				{
					// Select a valid coverage and save the referral
					CoverageSelectionContext covSelContext = new CoverageSelectionContext(true, this.patient, this.patientCoverage, this.problem, this.referral);
					EnumSelectValidCoverageResult result = this.SelectValidCoverage(covSelContext);
					this.DumpCoverageSelectionContext(covSelContext);
					switch (result)
					{
						case EnumSelectValidCoverageResult.NoCoverageFound:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "@NOVALIDCOVERAGE@"));
							return false;
						case EnumSelectValidCoverageResult.CoverageValid:
						case EnumSelectValidCoverageResult.SingleCoverageAutoSelected:
						{
							// save the referral in the context of coverage selection
							covSelContext.SaveERC();
							this.DumpAutoActivity(this.referral, true);
							break;
						}
						case EnumSelectValidCoverageResult.UserMustSelectFromMultiple:
							return false;		// user was redirected to coverage selection page.
						default:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "Unknown selection result"));
							return false;
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(new Exception("An error occured while coverage selection", ex));
				}
				// End of Select a valid coverage and save the problem

				#endregion
			}
			else
				referral.Save();

			if(referralDetail!=null && (newRD || loadRD || childRD))
			{
				if(referral.ReferralDetails.Count>0 && referral.ReferralDetails[0].IsPKEqual(referralDetail)) 
					vSessionIndicator=1;
				else
					vSessionIndicator=2;
				if (referralDetail.ParentReferralDetailCollection == null)
				{
					referral.ReferralDetails.AddRecord(referralDetail);
					//this.ReferralDetail = referralDetail;
				}
				referralDetail.ReferralID = referral.ReferralID;
				referralDetail.ParentReferralDetailCollection = referral.ReferralDetails;
				referralDetail.PatientSubscriberLogID = referral.PatientSubscriberLogID;
				referralDetail.PlanSORGLogID = referral.PlanSORGLogID;
				referralDetail.Save();
				SystemStatus systemStatus = new SystemStatus();				
				if(referralDetail.StatusCode == SystemStatus.CLOSED)
				{
					try
					{
						LetterGenerator letterGenerator = new LetterGenerator();
						if(letterGenerator.GenerateReferralLetters(patient, referral, referralDetail, vSessionIndicator))
							this.SetPageMessage("Referral letters have been generated successfully.", EnumPageMessageType.Info);
						else
							this.SetPageMessage("There are no referral letters to be generated.", EnumPageMessageType.Info);

					}
					catch(Exception ex)
					{
						this.RaisePageException(new Exception("An error occured while generating letters.", ex));
					}
				}

				referralDetail.SaveReferralAppointments();
				SecurityGroupCollection.ClearAllSecurityGroupsFromCache();
				referralDetail.SaveReferralReportEntries();
				newRD=false;
				this.loadRD=false;
				this.childRD=false;
				this.ReferralDetail = referralDetail;		
			}
//				referral.SaveReferralDetails();		// save all the referral details if referral is already created.
//			}
			
			this.DumpAutoActivity(this.referral, true);
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);
			return false;
		}
		return true;
	}

	protected override object SaveViewState()
	{
		ViewState["newRD"]=this.newRD;
		ViewState["loadRD"]=this.loadRD;
		ViewState["childRD"]=this.childRD;
		return base.SaveViewState ();
	}

	protected override void LoadViewState(object savedState)
	{
		base.LoadViewState (savedState);
		this.newRD=(bool)ViewState["newRD"];
		this.loadRD=(bool)ViewState["loadRD"];
		this.childRD=(bool)ViewState["childRD"];		
	}

	/// <summary>
	/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
	/// </summary>
	public Referral Referral
	{
		get { return referral; }
		set
		{
		referral = value;
			try
			{
				if(referral!=null)
				{
					// add all object-to-control population code here
					//referral.FillProviderInfo();
					this.UpdateFromObject(pnlReferral.Controls, referral);  // update controls for the given control/collection
					this.UpdateFromObject(pnlPCP.Controls, referral);  // update controls for the given control/collection
					this.UpdateFromObject(pnlReferredFrom.Controls, referral);  // update controls for the given control/collection
					this.UpdateFromObject(pnlReferredTo.Controls, referral);  // update controls for the given control/collection

					// referral detail
					referral.LoadReferralDetails(false);
					if(referral.ReferralDetails.Count>0)
					{
						// referral detail grid
						gridReferralDetail.UpdateFromCollection(referral.ReferralDetails);
						referralDetail = referral.ReferralDetails[0];
						this.ReferralDetail = referralDetail; 
						this.UpdateFromObject(pnlClinicalView.Controls);
						this.pnlClinical.Visible = false;
						this.pnlClinicalView.Visible = true;
						this.pnlAppointments.Visible = true;
					}
					else
						NewReferralDetail();	
				}
				else // if referral is null do nothing
				{ 
					this.pnlReferral.Visible = false;
					this.pnlPCP.Visible = false;
					this.pnlReferredFrom.Visible = false;
					this.pnlReferredTo.Visible = false;
					this.pnlClinical.Visible = false;
					this.pnlClinicalView.Visible = false;
					this.pnlAppointments.Visible = false;
					this.pnlReferral.Visible = false;
				}			

				// first cache then reload context
				this.CacheObject(typeof(Referral), referral);  // cache object using the caching method declared on the page
				this.CacheObject(typeof(BaseForEventCMSReferral), referral);  // cache object using the caching method declared on the page

				AdministrationControl.ReloadContext();
				AdministrationControl.UpdateData(true);

				UserDefined1.ReloadContext("Referral",referral,false);

				// go out of duplicates mode.
				this.PossibleDuplicateReferrals = null;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);  // notify the page about the error
			}
			
		}
	}

	/// <summary>
	/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
	/// </summary>
	public ReferralCollection ReferralCollection
	{
		get { return referralCol; }
		set
		{
			referralCol = value;
			try
			{
				// add all object-to-control population code here
				//referral.FillProviderInfo();
				this.UpdateFromObject(pnlReferralView.Controls, referralCol);  // update controls for the given control/collection

				// referral detail
				//referralCol.LoadAllReferrals(-1);
				ReferralCollection = null;
				if(referralCol.Count>0)
				{
					// referral detail grid
					gridReferral.UpdateFromCollection(referralCol);
					this.UpdateFromObject(pnlReferralView.Controls);
					this.pnlReferral.Visible = false;
					this.pnlPCP.Visible = false;
					this.pnlReferredFrom.Visible = false;
					this.pnlReferredTo.Visible = false;
					this.pnlReferralView.Visible = true;
				}
				else
				{
					this.UpdateFromObject(pnlReferral.Controls, new Referral());
					this.UpdateFromObject(pnlPCP.Controls, new Referral());
					this.UpdateFromObject(pnlReferredFrom.Controls, new Referral());
					this.UpdateFromObject(pnlReferredTo.Controls, new Referral());
					this.pnlReferral.Visible = true;
					this.pnlPCP.Visible = true;
					this.pnlReferredFrom.Visible = true;
					this.pnlReferredTo.Visible = true;
					this.pnlReferralView.Visible = false;
				}				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);  // notify the page about the error
			}
			this.CacheObject(typeof(Referral), referral);  // cache object using the caching method declared on the page
		}
	}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ReferralCollection PossibleDuplicateReferrals
		{
			get { return possibleDuplicateReferrals; }
			set
			{
				if (possibleDuplicateReferrals != null && value == null)	// switching back to normal
					this.PageTab.SelectedTabKey = "REF_Referral";
				possibleDuplicateReferrals = value;
				try
				{
					gridDuplicates.UpdateFromCollection(possibleDuplicateReferrals);  // update given grid from the collection
					// other object-to-control methods if any
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("possibleDuplicateReferrals", possibleDuplicateReferrals);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadPossibleDuplicateReferrals()
		{
			bool result = true;
			ReferralCollection possibleDuplicateReferrals = null;
			try
			{	// use any load method here
				possibleDuplicateReferrals = referral.GetPossibleDuplicateReferrals();
				if (possibleDuplicateReferrals == null || possibleDuplicateReferrals.Count == 0)
					this.SetPageMessage("No duplicate referral found", EnumPageMessageType.Info);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//possibleDuplicateEvents.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.PossibleDuplicateReferrals = possibleDuplicateReferrals;
			return result;
		}
		
	/// <summary>
	/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
	/// </summary>
	public ReferralDetail ReferralDetail
	{
		get { return referralDetail; }
		set
		{
			referralDetail = value;
			try
			{
//				this.pnlClinical.Visible = this.referralDetail != null;
//				this.pnlClinicalView.Visible = this.referralDetail == null;
//				this.UpdateFromObject(pnlClinical.Controls, referralDetail);  // update controls for the given control collection

				if(referral!=null)
				{
					if(!referral.IsNew)
					{
						referral.LoadReferralDetails(false);
						if(referral.ReferralDetails.Count>0)
						{
							if(this.newRD || this.loadRD)
							{
								this.UpdateFromObject(pnlClinical.Controls, referralDetail);
								if(this.UnitQuantity.Text == "0")
									this.UnitQuantity.Text ="";
								this.pnlClinical.Visible = true;
								this.pnlClinicalView.Visible = false;
								this.pnlAppointments.Visible = false;
							}
							else
							{
								this.gridReferralDetail.UpdateFromCollection(referral.ReferralDetails);
								this.UpdateFromObject(pnlClinicalView.Controls, referralDetail);						
								this.pnlClinical.Visible = false;
								this.pnlClinicalView.Visible = true;
								this.pnlAppointments.Visible = true;
								this.butNewAppointment.Enabled=true;
								this.butGenerateLetter.Enabled=true;
							}
							referralDetail.LoadReferralAppointments(false);
							if(referralDetail.ReferralAppointments.Count>=0)
							{
								gridReferralAppointments.UpdateFromCollection(referralDetail.ReferralAppointments);
								this.UpdateFromObject(pnlAppointments.Controls,referralAppointment);								
							}
							else
							{
								NewReferralAppointment();
							}
							referralDetail.LoadReferralReportEntries(false);
							if(referralDetail.ReferralReportEntries.Count>=0)
							{
								gridReferralReportEntry.UpdateFromCollection(referralDetail.ReferralReportEntries);
								this.UpdateFromObject(pnlReports.Controls,referralReportEntry);
							}
							else
							{
								NewReferrerObject();								
							}

						}
					}
					else  // this case works when referral is new.
					{						
						gridReferralAppointments.UpdateFromCollection(referralDetail.ReferralAppointments);
						this.UpdateFromObject(pnlClinical.Controls, referralDetail);
						NewReferralAppointment();
						gridReferralReportEntry.UpdateFromCollection(referralDetail.ReferralReportEntries);
						this.UpdateFromObject(pnlAppointments.Controls, referralAppointment);
						NewReferrerObject();
						this.UpdateFromObject(pnlReports.Controls, referralReportEntry);
						if(this.UnitQuantity.Text == "0")
							this.UnitQuantity.Text ="";
						//this.UpdateFromObject(pnlAppointments.Controls, new ReferralAppointment());
					}
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);  // notify the page about the error
			}
			this.CacheObject(typeof(ReferralDetail), referralDetail);  // cache object using the caching method declared on the page
		}
	}

//	public bool NewRD
//	{
//		get{return newRD;}
//		set{
//			newRD = value;
//			this.Cache["newRD"]=newRD;
//		   }
//	}
//
//	public bool LoadRD
//	{
//		get{return loadRD;}
//		set{
//			loadRD = value;
//			this.Cache["loadRD"]=loadRD;
//		   }
//	}
//
//	public bool ChildRD
//	{
//		get{return childRD;}
//		set
//		{
//			childRD = value;
//			this.Cache["childRD"]=childRD;
//		}
//	}

	public ReferralAppointment ReferralAppointment
	{
		get { return referralAppointment; }
		set
		{
			referralAppointment = value;
			try
			{
				this.UpdateFromObject(pnlAppointments.Controls, referralAppointment);  // update controls for the given control collection				
//				SetPageTabToolbarItemEnabled("AddNewAppointment", true);
				// other object-to-control methods if any
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);  // notify the page about the error
			}
			this.CacheObject(typeof(ReferralAppointment), referralAppointment);  // cache object using the caching method declared on the page
		}

//		{
//			referralAppointment = value;
//			try
//			{
//				if(referralDetail!=null && !referralDetail.IsNew)
//				{
//					referralDetail.LoadReferralAppointments(false);
//					if(referralDetail.ReferralAppointments.Count>0)
//						gridReferralAppointments.UpdateFromCollection(referralDetail.ReferralAppointments);
////					if(newRA)
////					{
////						ReferralAppointment newAppointment = new ReferralAppointment(true);
////						this.UpdateFromObject(pnlAppointments.Controls,newAppointment);
////					}
////					else
////					{
//						this.UpdateFromObject(pnlAppointments.Controls,referralAppointment);
////					}
//					// update controls for the given control/collection
//				}
//			}
//			catch(Exception ex)
//			{
//				this.RaisePageException(ex);  // notify the page about the error
//			}
//			this.CacheObject(typeof(ReferralAppointment), referralAppointment);  // cache object using the caching method declared on the page
//		}
	}


	public ReferralReportEntry ReferralReportEntry
	{
		get { return referralReportEntry; }
		set
		{
			referralReportEntry = value;
			try
			{
				this.UpdateFromObject(pnlReports.Controls, referralReportEntry);  // update controls for the given control collection
				// other object-to-control methods if any
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);  // notify the page about the error
			}
			this.CacheObject(typeof(ReferralReportEntry), referralReportEntry);  // cache object using the caching method declared on the page
		}
	}

	/// <summary>
	/// Reads control values into the data object and validates them.  Returns false if there's any problem
	/// </summary>
	public bool ReadControlsForReferralDetail()
	{
		try
		{	//customize this method for this specific page
			this.UpdateToObject(pnlClinical.Controls, referralDetail);	// controls-to-object
			// other control-to-object methods if any
			return this.IsValid;	// Return validation result
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			return false;
		}
	}

	public bool ReadControlsForReferralAppointment()
	{
		try
		{	//customize this method for this specific page
			this.UpdateToObject(pnlAppointments.Controls, referralAppointment);	// controls-to-object
			// other control-to-object methods if any
			return this.IsValid;	// Return validation result
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			return false;
		}
	}

	/// <summary>
	/// Reads control values into the data object and validates them.  Returns false if there's any problem
	/// </summary>
	public bool ReadControls()
	{
		try
		{	// add all control-to-object population code here
			this.UpdateToObject(pnlReferral.Controls, referral);  // controls-to-object
			if(referral!=null)
				referral.ReferredToType=int.Parse(this.ReferredToOption.SelectedItem.Value);
			this.UpdateToObject(pnlPCP.Controls, referral);  // controls-to-object
			this.UpdateToObject(pnlReferredFrom.Controls, referral);  // controls-to-object
			
			
			this.UpdateToObject(pnlReferredTo.Controls, referral);  // controls-to-object
			this.UpdateToObject(this.pnlPCP.Controls, referral);
			if(referral.ReferralDetails!= null && (this.newRD || this.loadRD))
				this.UpdateToObject(pnlClinical.Controls, referralDetail);  // controls-to-object		

			AdministrationControl.ReloadContext();
			AdministrationControl.UpdateData(true);

			UserDefined1.UserDefinedValue = referral.UserDefined;
			UserDefined1.ReadControls();			
			return this.IsValid;	// Return validation result
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			return false;
		}
	}

#region Web Form Designer generated code
override protected void OnInit(EventArgs e)
{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
		InitializeComponent();
		base.OnInit(e);		
}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
 
	private void InitializeComponent()
	{   
		this.ReferredToOption.SelectedIndexChanged += new System.EventHandler(this.ReferredToOption_SelectedIndexChanged);
		this.butGenerateLetter.Click += new System.EventHandler(this.butGenerateLetter_Click);
		this.gridReferralDetail.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridReferralDetail_ClickCellButton);
		this.gridReferralDetail.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridReferralDetail_ColumnsBoundToDataClass);
		this.butNewAppointment.Click += new System.EventHandler(this.butNewAppointment_Click);
		this.gridReferralAppointments.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridReferralAppointments_ClickCellButton);
		this.gridReferralAppointments.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridReferralAppointments_ColumnsBoundToDataClass);
		this.butSaveAppointment.Click += new System.EventHandler(this.butSaveAppointment_Click);
		this.butDeleteAppointment.Click += new System.EventHandler(this.butDeleteAppointment_Click);
		this.butAddOther.Click += new System.EventHandler(this.butAddOther_Click);
		this.butCancelOther.Click += new System.EventHandler(this.butCancelOther_Click);
		this.gridReferralReportEntry.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridReferralReportEntry_ClickCellButton);
		this.gridReferralReportEntry.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridReferralReportEntry_ColumnsBoundToDataClass);
		this.butDeleteReports.Click += new System.EventHandler(this.butDeleteReports_Click);
		this.ValidationsOnlyInSummary = true;
		this.Load += new System.EventHandler(this.Page_Load);

	}

public override void RenderPageSummary(PageSummary pageSummary)
{
	base.RenderPageSummary (pageSummary);
	pageSummary.RenderObjects(this.referral,this.patient, this.patientCoverage, this.problem);
}

private void gridReferralDetail_Click(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
{	
	int referralIndex =  gridReferralDetail.GetColIndexFromClickEvent(e);
	if (referralIndex < 0)
		return;
	this.Referral=referral;
	this.ReferralDetail = referral.ReferralDetails[referralIndex];
}

private void gridReferralAppointments_ClickCellButton(object sender, CellEventArgs e)
{	
	//string colName = grid.GetColumnKeyFromCellEvent(e);
	string colName = e.Cell.Key;
	if (colName == "Edit")
	{
		int referralAppointmentIndex =(int)(e.Cell.Row.DataKey);		
		if (referralAppointmentIndex < 0)
			return;
		this.ReferralDetail=referralDetail;
		this.ReferralAppointment = referralDetail.ReferralAppointments[referralAppointmentIndex];
		this.tblAppointmentForm.Visible=true;		
		// set grid invisible
	}
					//	int referralAppointmentIndex =  gridReferralAppointments.GetColIndexFromClickEvent(e);
					//	if (referralAppointmentIndex < 0)
					//		return;
					//	this.ReferralDetail=referralDetail;
					//	this.ReferralAppointment = referralDetail.ReferralAppointments[referralAppointmentIndex];
}

private void gridReferralReportEntry_ClickCellButton(object sender, CellEventArgs e)
{
//	gridReferralReportEntry.SelectedRowIndex = e.Cell.Row.Index;
//	gridReferralReportEntry.DisplayLayout.ActiveRow.Selected=true;
	int referralReportEntryIndex =(int)(e.Cell.Row.DataKey);
	string colName = e.Cell.Key;
	if (colName == "Select")
	{
			if (referralReportEntryIndex < 0)
				return;
			this.ReferralDetail=referralDetail;
			this.ReferralReportEntry = referralDetail.ReferralReportEntries[referralReportEntryIndex];	
	}
}

private void gridReferralDetail_ColumnsBoundToDataClass(object sender, System.EventArgs e)
{	
	gridReferralDetail.AddButtonColumn("Edit", "@EDIT@",0);	
	gridReferralDetail.AddButtonColumn("Select","@SELECT@",0);
}

private void gridReferralDetail_SelectedRowIndexChanged(object sender, EventArgs e)
{
	try
	{	
//		referralDetail = referral.ReferralDetails[this.gridReferralDetail.SelectedRowIndex];
//		this.ReferralDetail=referralDetail;
		BindReferralDetailAppoinments(referralDetail);
		this.butNewAppointment.Enabled=true;
		this.butGenerateLetter.Enabled=true;
	}
	catch(Exception ex)
	{
		this.RaisePageException(ex);
	}
}

private void gridReferralReportEntry_SelectedRowIndexChanged(object sender, EventArgs e)
{
	try
	{	
//		if (this.gridReferralReportEntry.SelectedRowIndex < 0)
//			return;
//		this.ReferralDetail=referralDetail;
		this.ReferralReportEntry = referralDetail.ReferralReportEntries[this.gridReferralReportEntry.SelectedRowIndex];
	}
	catch(Exception ex)
	{
		this.RaisePageException(ex);
	}
}

private void gridReferralReportEntry_ColumnsBoundToDataClass(object sender, System.EventArgs e)
{
	gridReferralReportEntry.AddButtonColumn("Select","@SELECT@",0);
}

private void gridReferralAppointments_ColumnsBoundToDataClass(object sender, System.EventArgs e)
{
	gridReferralAppointments.AddButtonColumn("Edit","@EDIT@",0);
}

private void gridReferralDetail_ClickCellButton(object sender, CellEventArgs e)
{
	//string colName = grid.GetColumnKeyFromCellEvent(e);
//	gridReferralDetail.SelectedRowIndex = e.Cell.Row.Index;
//	gridReferralDetail.DisplayLayout.ActiveRow.Selected=true;
	int referralIndex =(int)(e.Cell.Row.DataKey);
	string colName = e.Cell.Key;
	if (colName == "Edit")
	{
		if (referralIndex < 0)
			return;
		this.loadRD=true;
		ReferralDetail = referral.ReferralDetails[referralIndex];
		// set grid invisible
	}
	if (colName == "Select")
	{	
		try
		{	
			referralDetail = referral.ReferralDetails[referralIndex];
			this.ReferralDetail=referralDetail;
			BindReferralDetailAppoinments(referralDetail);
			this.butNewAppointment.Enabled=true;
			this.butGenerateLetter.Enabled=true;
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);
		}
	}
}

public void BindReferralDetailAppoinments(ReferralDetail referralDetail)
{	
	try
	{
		referralDetail.LoadReferralAppointments(false);
		if(referralDetail.ReferralAppointments.Count>0)
		{
			gridReferralAppointments.UpdateFromCollection(referralDetail.ReferralAppointments);
			this.UpdateFromObject(pnlAppointments.Controls,referralAppointment);
		}
		else
		{
			gridReferralAppointments.UpdateFromCollection(referralDetail.ReferralAppointments);				
			NewReferralAppointment();
		}
		referralDetail.LoadReferralReportEntries(false);
		if(referralDetail.ReferralReportEntries.Count>0)
		{
			gridReferralReportEntry.UpdateFromCollection(referralDetail.ReferralReportEntries);
			this.UpdateFromObject(pnlReports.Controls,referralReportEntry);
		}
		else
		{
			gridReferralReportEntry.UpdateFromCollection(referralDetail.ReferralReportEntries);
			NewReferralAppointment();
		}
		this.ReferralDetail=referralDetail;
		// not complete.
		// set grid visible.
	}
	catch(Exception ex)
	{
		this.RaisePageException(ex);
	}
}

//private void gridReferralDetail_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
//{
//	int referralIndex =  gridReferralDetail.GetColIndexFromClickEvent(e);
//	if (referralIndex < 0)
//		return;
//	this.LoadRD=true;
//	ReferralDetail = referral.ReferralDetails[referralIndex];
//}

//private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
//{
//	if (e.Cell.Key == ReferralMessages.MessageIDs.APPOINTMENTSTAB)
//	{
//		try
//		{				
//			int pk =(int)(e.Cell.Row.DataKey);
//			ReferralDetail referralDetail = new ReferralDetail(false);
//			referralDetail = referral.ReferralDetails[pk];
//			referralDetail.LoadReferralAppointments(false);
//			if(referralDetail.ReferralAppointments.Count>0)
//			{
//				gridReferralAppointments.UpdateFromCollection(referralDetail.ReferralAppointments);
//				this.UpdateFromObject(pnlAppointments.Controls,referralAppointment);
//			}
//			else
//			{
//				gridReferralAppointments.UpdateFromCollection(referralDetail.ReferralAppointments);				
//				NewReferralAppointment();
//			}
//			referralDetail.LoadReferralReportEntries(false);
//			if(referralDetail.ReferralReportEntries.Count>0)
//			{
//				gridReferralReportEntry.UpdateFromCollection(referralDetail.ReferralReportEntries);
//				this.UpdateFromObject(pnlReports.Controls,referralReportEntry);
//			}
//			else
//			{
//				gridReferralReportEntry.UpdateFromCollection(referralDetail.ReferralReportEntries);
//				NewReferralAppointment();
//			}
//			this.ReferralDetail=referralDetail;
//			/// not complete.
//			SetPageTabItemActive("1_Appointments");
//		}
//		catch(Exception ex)
//		{
//			this.RaisePageException(ex);
//		}
//	}
//}


#endregion

	public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
	{
		base.PopulateToolbarItems (toolbar, tab);
//
//		wo = new WindowOpener();
//		wo.ID = "ProviderSearch";
//		wo.NavigateURL = "ProviderSearch.aspx?Flag=1&amp;CallbackFunction=setGPID";
//		wo.registerClientScripts(this);
//		wo.ToolBar=false;
//		wo.MenuBar=false;
//		wo.LinksBar=false;
//		wo.CopyHistory=false;
//		wo.AddressBar=false;
//		wo.StatusBar=true;
//		wo.WindowWidth=Unit.Pixel(500);
        
		switch (tab.Key)
		{
			case "REF_Referral":
				WindowOpener woProblemLink = new WindowOpener();
				woProblemLink.ID = "ProblemLinkForm";
				woProblemLink.NavigateURL = "ProblemLinkForm.aspx";
				woProblemLink.registerClientScripts(this);

				toolbar.AddButton("@LINKPROBLEM@", "LinkProblem").Item.TargetURL = "javascript:" + woProblemLink.getWindowOpenScript(); 
				toolbar.AddButton("@ADDNEWRECORD@", "AddNewReferral").Visible=false;
				toolbar.AddButton("@VIEWREFERRALS@", "ViewReferrals").Visible = false;
				break;
			case "REF_Clinical":
				toolbar.AddButton("@ADDNEWCLINICAL@", "AddNewClinical");
				toolbar.AddButton("@VIEWALL@", "ViewAll");
				break;
//			case "REF_Appointments":
//				toolbar.AddButton("@ADDNEWRECORD@", "AddNewAppointment").Enabled = false;
//				break;
			case "REF_Reports":
				toolbar.AddButton("@ADDPCP@", "AddPCP").Enabled = false;
				toolbar.AddButton("@ADDREFERRER@", "AddReferrer").Enabled = false;
				toolbar.AddButton("@ADDOTHER@", "AddOther").Enabled = false;
				//toolbar.AddButton("@ADDOTHER@", "AddOther").Item.TargetURL = "javascript:" + wo.getWindowOpenScript(); 
				break;
			case "REF_Administration":
				toolbar.AddButton(PatientMessages.MessageIDs.CHANGECOVERAGE, "EVE_ChangeCoverage", true, true);
				break;
		}
	}

	public void OnToolbarButtonClick_ViewAll(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
	{
		int i=0;
		this.newRD=false;
		this.loadRD=false;
		this.childRD=false;
		this.Referral = referral;
		for(i=0;i<=referral.ReferralDetails.Count;i++)
		{
			if(referral.ReferralDetails[i].IsPKEqual(referralDetail)) 			
			{
				this.ReferralDetail=referral.ReferralDetails[i];
				gridReferralDetail.SelectedRowIndex = i;
				//ActiveRow.Selected commentout
				gridReferralDetail.DisplayLayout.ActiveRow.Selected=true;
				//
				break;
			}
		}
	}

	public void OnToolbarButtonClick_AddNewReferral(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
	{
		NewReferral();
	}
	public void OnToolbarButtonClick_ViewReferrals(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
	{
		ViewReferrals();
	}
	
	public void OnToolbarButtonClick_AddNewClinical(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
	{
		NewReferralDetail();
	}

//	public void OnToolbarButtonClick_AddNewAppointment(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
//	{
//		NewReferralAppointment();
//	}

	public void OnToolbarButtonClick_AddPCP(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
	{
		NewPCP();
	}

	public void OnToolbarButtonClick_AddReferrer(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
	{
		NewReferrer();
	}

	public void OnToolbarButtonClick_AddOther(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
	{
		VisibleOtherPanel();
	}

	public void OnToolbarButtonClick_EVE_ChangeCoverage(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
	{
		// data from controls to object
		if (!this.ReadControls())
			return;
		RedirectToSelectCoverage(this.patient, this.patientCoverage, this.problem, this.referral);			
	}

	public bool NewReferral()
	{
		bool result = true;
		try
		{	
			Referral referral = new Referral(true); // use a parameterized constructor which also initializes the data object
			ReferralDetail referralDetail = new ReferralDetail(true);
			ReferralAppointment referralAppointment = new ReferralAppointment(true);
			ReferralReportEntry referralReportEntry = new ReferralReportEntry(true);
			this.Referral = referral;			
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			result = false;
		}
		finally
		{
			// finalization code
		}
		return result;
	}

	public void VisibleOtherPanel()
	{
		this.pnlAddOther.Visible= true;
	}

	public bool NewOthers()
	{
		bool result = true;
		try
		{	
			ReferralRole role= new ReferralRole();
			referralReportEntry = new ReferralReportEntry(true);
			if(role.LoadReferralRoleByCode("OTHR"))
				referralReportEntry.ReferralRoleID = role.ReferralRoleID;
			referralReportEntry.ReportEntryName = this.ReportEntryName.Value.ToString();
			referralReportEntry.ProviderLocationID= (int)this.ProviderLocationID.Value;
			referralReportEntry.ReferralDetailID = referralDetail.ReferralDetailID;
			if((int)this.ProviderLocationID.Value==0)
			{
				this.SetPageMessage("@REFERRERERROR@", EnumPageMessageType.Error);
				return false;
			}
			if(referralDetail.ReferralReportEntries==null)
				referralDetail.LoadReferralReportEntries(false);
			if (referralReportEntry.ParentReferralReportEntryCollection== null)
				referralDetail.ReferralReportEntries.AddRecord(referralReportEntry);
			gridReferralReportEntry.UpdateFromCollection(referralDetail.ReferralReportEntries);	
            this.childRD = true;
			this.pnlAddOther.Visible= false;
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			result = false;
		}
		finally
		{
			// finalization code
		}		
		return result;
	}


	public bool ViewReferrals()
	{
		bool result = true;
		try{
			ReferralCollection referralCol = new ReferralCollection();
			//referralCol.LoadAllReferrals(-1);				// You must load the referrals for the current patient only
			if(referralCol!=null)
			{
				// referral detail grid
				gridReferral.UpdateFromCollection(referralCol);
				this.UpdateFromObject(pnlReferralView.Controls);
				this.pnlReferralView.Visible = true;
				this.pnlReferral.Visible	 = false;
				this.pnlPCP.Visible	 = false;
				this.pnlReferredFrom.Visible	 = false;
				this.pnlReferredTo.Visible	 = false;
			}
			this.UpdateFromObject(pnlReferralView.Controls, referralCol);
			this.ReferralCollection= referralCol;
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			result = false;
		}
		finally
		{
			// finalization code
		}		
		return result;
	}

		public void GenerateLetter()
		{			
			if(ReferralDetail!=null)
			{
				try
				{
					if(referral.ReferralDetails.Count>0 && referral.ReferralDetails[0].IsPKEqual(referralDetail)) 
						vSessionIndicator=1;
					else
						vSessionIndicator=2;

					LetterGenerator letterGenerator = new LetterGenerator();
					if (letterGenerator.GenerateReferralLetters(patient, referral, referralDetail, vSessionIndicator))
						this.SetPageMessage("Referral letters have been generated successfully.", EnumPageMessageType.Info);
					else
						this.SetPageMessage("There are no referral letters to be generated.", EnumPageMessageType.Info);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

	public bool NewReferralDetail()
	{
		bool result = true;
		try
		{	
			ReferralDetail referralDetail = new ReferralDetail(true); // use a parameterized constructor which also initializes the data object
			this.pnlAppointments.Visible = false;
			this.pnlClinicalView.Visible = false;
			this.pnlClinical.Visible	 = true;
			this.newRD = true;
			this.ReferralDetail = referralDetail;
			this.UnitQuantity.Text = "";
			
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			result = false;
		}
		finally
		{
			// finalization code
		}		
		return result;
	}

	public bool NewReferralAppointment()
	{
		bool result = true;
		try{
			ReferralAppointment referralAppointment = new ReferralAppointment(true); // use a parameterized constructor which also initializes the data object
			this.ReferralAppointment = referralAppointment;			
		}	
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			result = false;
		}
		finally
		{
			// finalization code
		}		
		return result;
	}

	public bool NewPCP()
	{

		bool result = true;
		try
		{	
			ReferralRole role= new ReferralRole();
			referralReportEntry = new ReferralReportEntry(true);
			referral.FillProviderInfo();
			if(role.LoadReferralRoleByCode("PCP"))
				referralReportEntry.ReferralRoleID = role.ReferralRoleID;
			referralReportEntry.ReportEntryName = referral.PCPFullName.ToString();
			referralReportEntry.ProviderLocationID= referral.PCPLocationID;
			referralReportEntry.ReferralDetailID = referralDetail.ReferralDetailID;
			if(referralDetail.ReferralReportEntries==null)
				referralDetail.LoadReferralReportEntries(false);
			if (referralReportEntry.ParentReferralReportEntryCollection== null)
				referralDetail.ReferralReportEntries.AddRecord(referralReportEntry);
			gridReferralReportEntry.UpdateFromCollection(referralDetail.ReferralReportEntries);	
			this.childRD=true;
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			result = false;
		}
		finally
		{
			// finalization code
		}		
		return result;
	}


	public bool NewReferrer()
	{
		bool result = true;
		try
		{	
			ReferralRole role= new ReferralRole();			
			referralReportEntry = new ReferralReportEntry(true);
			referral.FillProviderInfo();
			if(role.LoadReferralRoleByCode("REFR"))
				referralReportEntry.ReferralRoleID = role.ReferralRoleID;
			referralReportEntry.ReportEntryName = referral.ReferredFromPCPFullName.ToString();
			referralReportEntry.ReferralDetailID = referralDetail.ReferralDetailID;
			referralReportEntry.ProviderLocationID= referral.ReferredFromLocationID;
			if(referralDetail.ReferralReportEntries==null)
				referralDetail.LoadReferralReportEntries(false);
			if (referralReportEntry.ParentReferralReportEntryCollection== null)
				referralDetail.ReferralReportEntries.AddRecord(referralReportEntry);
			gridReferralReportEntry.UpdateFromCollection(referralDetail.ReferralReportEntries);		
			this.childRD=true;
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			result = false;
		}
		finally
		{
			// finalization code
		}		
		return result;
	}

	public bool NewReferrerObject()
	{
		bool result = true;
		try
		{	
			ReferralReportEntry referralReportEntry = new ReferralReportEntry(true); 
			this.ReferralReportEntry = referralReportEntry;
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);	// notify the page about the error
			result = false;
		}
		finally
		{
			// finalization code
		}		
		return result;
	}

		// Page bottom toolbar
	public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
	{
		base.PopulateToolbarItems (toolbar);

		//toolbar.AddPreset(ToolbarButtons.SaveCancel);
		toolbar.AddButton("@SAVERECORD@", "Save","Referral",true);
		toolbar.AddButton("@CANCEL@", "Cancel",false);
	}

	public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
	{
		if (SaveData())
		{
			this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "@REFERRAL@");
		}
	}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.possibleDuplicateReferrals == null)
				base.OnToolbarButtonClick_Cancel(toolbar, button);
			else
			{
				// duplicates display mode.  just go out of this mode.
				this.PossibleDuplicateReferrals = null;
			}
		}

//	public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
//	{
//		this.NewRD=false;
//		this.LoadRD=false;
//		this.ChildRD=false;
//		this.Referral = referral;
//		if(referral.ReferralDetails.Count>0)
//			this.ReferralDetail = referral.ReferralDetails[referral.ReferralDetails.Count-1];
//	}

	/// <summary>
	/// Call this method when you want to retrieve data from controls and save them to table.
	/// </summary>
	private void butSaveAppointment_Click(object sender, System.EventArgs e)
	{
		SaveDataForSaveAppointment();
	}

	public bool SaveDataForSaveAppointment()
	{
		try
		{	// data from controls to object
			if (!this.ReadControlsForReferralAppointment())
				return false;
			if(referralAppointment!=null)
			{
				foreach(object tmp in referralDetail.ReferralAppointments)
				{
					if(tmp.Equals((object)referralAppointment))
					{
						referralDetail.ReferralAppointments.RemoveRecord(referralAppointment);
						break;
					}
				}
			}
			referralDetail.ReferralAppointments.AddRecord(referralAppointment);
			gridReferralAppointments.UpdateFromCollection(referralDetail.ReferralAppointments);
			this.childRD=true;
			NewReferralAppointment();
			return true;		// kept in child collection
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);
			return false;
		}
	}

	private void butDeleteAppointment_Click(object sender, System.EventArgs e)
	{
		DeleteDataForAppointment();
	}

	public bool DeleteDataForAppointment()
	{
		try
		{	// data from controls to object
//			if (!this.ReadControlsForReferralAppointment())
//				return false;
//			//referralAppointment.ParentReferralAppointmentCollection == null;
//			referralDetail.LoadReferralAppointments(true);
//			referralAppointment.Load((int)gridReferralAppointments.SelectedRowPK[0]);
//			referralAppointment.MarkDel();
//			//ReferralAppointmentCollection.ClearAllReferralAppointmentsFromCache();
//			referralDetail.LoadReferralAppointments(true);
//			gridReferralAppointments.UpdateFromCollection(referralDetail.ReferralAppointments);
//			NewReferralAppointment();
//			return true;		// kept in child collection
			if(referralAppointment!=null)
			{
				foreach(object tmp in referralDetail.ReferralAppointments)
				{
					if(tmp.Equals((object)referralAppointment))
					{
						referralDetail.ReferralAppointments.RemoveRecord(referralAppointment);
						break;
					}
				}
			}
			gridReferralAppointments.UpdateFromCollection(referralDetail.ReferralAppointments);
			this.childRD=true;
			NewReferralAppointment();
			return true;		// kept in child collection
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);
			return false;
		}		
	}

	private void butDeleteReports_Click(object sender, System.EventArgs e)
	{
		DeleteDataForReports();
	}

	public bool DeleteDataForReports()
	{
		try
		{	// data from controls to object
			if (referralReportEntry.ParentReferralReportEntryCollection!= null)
				referralDetail.ReferralReportEntries.RemoveRecord(referralReportEntry);
			gridReferralReportEntry.UpdateFromCollection(referralDetail.ReferralReportEntries);
			referralReportEntry = null;
			this.childRD=true;
			return true;		// kept in child collection
		}
		catch(Exception ex)
		{
			this.RaisePageException(ex);
			return false;
		}		
	}

	private void butNewAppointment_Click(object sender, System.EventArgs e)
	{		
		this.tblAppointmentForm.Visible=true;
		this.butNewAppointment.Visible=false;
		NewReferralAppointment();
	}

	private void butAddOther_Click(object sender, System.EventArgs e)
	{
		NewOthers();
	}

	private void butCancelOther_Click(object sender, System.EventArgs e)
	{
		this.ProviderLocationID.Value = "";
		this.ReportEntryName.Value = "";
		this.pnlAddOther.Visible = false;
	}

	public void OnSubNavigationItemClick_Activities(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
	{
		ActivitiesForm.Redirect(EnumActivityContext.Activity, EnumActivityAndNoteContext.ERC);
	}

	public void OnSubNavigationItemClick_Images(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
	{
		ImageSearch.Redirect(this.patient, this.patientCoverage, this.problem, this.referral, null);
	}

	public new void OnSubNavigationItemClick_Notes(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
	{
		NoteSearch.Redirect(EnumActivityAndNoteContext.ERC);
	}

	private void ReferredToOption_SelectedIndexChanged(object sender, System.EventArgs e)
	{
		int selection;
		selection = int.Parse(this.ReferredToOption.SelectedItem.Value);
		//if(referral!=null && referral.ReferredToType>0)
		//{
		//	if(selection != referral.ReferredToType)
		//	{
				referral.ReferredToID = 0;
				referral.ReferredToLocationID = 0;
				referral.ReferredToSpecialtyID=0;
				referral.ReferredToSpecialtyID=0;
				referral.ReferredToNetworkID =0;
				referral.ReferredToNetworkStatus=0;
				this.UpdateFromObject(pnlReferredTo.Controls, referral);
		//	}
		//}
		//else
		//{
		//	if(referral.IsNew)
		//	{
		//		referral.ReferredToID = 0;
		//		referral.ReferredToLocationID = 0;
		//		referral.ReferredToSpecialtyID=0;
		//		referral.ReferredToSpecialtyID=0;
		//		referral.ReferredToNetworkID =0;
		//		referral.ReferredToNetworkStatus=0;
		//		this.UpdateFromObject(pnlReferredTo.Controls, referral);
		//	}
		//}
		RebindPCPFaciltyGP(selection);
	}

	public bool RebindPCPFaciltyGP(int selection)
	{
		try
		{
			switch(selection)
			{
				case (int)EnumReferredToOption.Provider:
				{
					this.RefToSelect.RebindControls(typeof(Referral), "@PROVIDER@", 
						ProviderSearcherType.Provider, null,
						"ReferredToID", "ReferredToLocationID", "ReferredToSpecialtyID", "ReferredToNetworkID", "ReferredToNetworkStatus","ReferralStartDate");
					break;
				}
				case (int)EnumReferredToOption.Facilities:
				{
					this.RefToSelect.RebindControls(typeof(Referral), "@FACILITY@", 
						ProviderSearcherType.Facility, null,
						"ReferredToID", "ReferredToLocationID", "ReferredToSpecialtyID", "ReferredToNetworkID", "ReferredToNetworkStatus","ReferralStartDate");
					break;
				}
				case (int)EnumReferredToOption.GroupPractice:
				{
					this.RefToSelect.RebindControls(typeof(Referral), "@PROVIDERGROUPPRACTICE@", 
						ProviderSearcherType.GroupPractice, null,
						"ReferredToID", "ReferredToLocationID", "ReferredToSpecialtyID", "ReferredToNetworkID", "ReferredToNetworkStatus","ReferralStartDate");
					break;
				}
			}
			return true;
		}
		catch(Exception ex)
		{
			return false;
		}
	}

	private void butGenerateLetter_Click(object sender, System.EventArgs e)
	{
		GenerateLetter();	
	}
}
}