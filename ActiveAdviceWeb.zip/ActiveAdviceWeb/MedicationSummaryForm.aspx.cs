using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for MedicationSummaryForm.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.MEDICATIONS)]
	
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]	
	[MainDataClass("PatientMedication,DataLayer")]	
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Medications")]
	[PageTitle("@MEDICATIONPAGETITLE@")]
	public class MedicationSummaryForm : PatientBasePage
	{
		private Patient patient;
		private PatientMedicationCollection patientMedications;
		private PatientMedication patientMedication;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMedications;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridMedications;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMedicationDetails;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMedicationGeneral;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBrandName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit BrandName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGenericName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit GenericName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEtcName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit EtcName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNDC;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit NDC;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo StatusID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatusID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo StatusReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatusReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMedicationTerminationReasonId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MedicationTerminationReasonId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMedicationTerminationReasonId;
		protected System.Web.UI.HtmlControls.HtmlTable Table6;
		protected System.Web.UI.HtmlControls.HtmlTable GeneralNamingTable1;
		protected System.Web.UI.HtmlControls.HtmlTable GeneralNamingTable2;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForMedicationId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MedicationID;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMedicationFFRM;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MedicationFFRM;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMedicationFFRM;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDosage;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Dosage;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDosage;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDosageUnits;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit DosageUnits;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDosageUnits;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFrequency;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Frequency;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFrequency;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFrequencyUnits;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit FrequencyUnits;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFrequencyUnits;
		protected NetsoftUSA.WebForms.OBFieldLabel lbComments;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txbComments;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldComments;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected System.Web.UI.HtmlControls.HtmlTable table16;
		
	
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.gridMedications.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridMedications_ClickCellButton);
			this.StatusID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.StatusID_SelectedRowChanged);

			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.PrintablePage = true;
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				LoadData();
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));
				patientMedication = (PatientMedication)this.LoadObject(typeof(PatientMedication));  // load object from cache
				patientMedications = (PatientMedicationCollection)this.LoadObject(typeof(PatientMedicationCollection));  // load object from cache
			}
		}

		private void LoadData()
		{
			try
			{
				patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
				this.CacheObject(typeof(Patient), patient);
				if(LoadPatientMedications())
					PatientMedication = SetSelectedGridItem(this.gridMedications, this.patientMedications, 0, true) as PatientMedication;
				else
					this.SetPageMessage("@LOADERR@", EnumPageMessageType.AddError, Messages.PatientMessages.MessageIDs.MEDICATIONS);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		#region PatientMedication
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientMedication PatientMedication
		{
			get { return patientMedication; }
			set
			{
				patientMedication = value;
				try
				{
					SetMedicineFreeEntry(/*controls UI state*/);

					this.UpdateFromObject(this.pnlMedicationDetails.Controls, patientMedication);  // update controls for the given control collection					
					if(!PatientMedication.EnableICMMedications /*forces user to pick*/)
						this.UpdateFromObject(this.pnlMedicationGeneral.Controls, patientMedication);  // update controls for the given control collection
					
					SetReasonVisibility(patientMedication.BR1283B);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PatientMedication), patientMedication);  // cache object using the caching method declared on the page
			}
		}

		private void SetReasonVisibility(bool state)
		{
			this.lbStatusReasonID.Visible = this.StatusReasonID.Visible = this.vldStatusReasonID.Visible = state;
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				// NO need to Update From pnlMedicationGeneral since only MedicationID is needed
				this.UpdateToObject(this.pnlMedicationDetails.Controls, patientMedication);	// controls-to-object

				if(this.patientMedication.IsNew)
					this.patientMedication.Medication = null; // refreshes object
				
				// other control-to-object methods if any
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPatientMedication()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				patientMedication.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			finally
			{
				SetMedicineFreeEntry(); // update UI state
			}
			return true;
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPatientMedication()
		{
			bool result = true;
			PatientMedication patientMedication = null;
			try
			{	// or use an initialization method here
				patientMedication = new PatientMedication(true); // use a parameterized constructor which also initializes the data object
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.PatientMedication = patientMedication;
			return result;
		}

		public static void Redirect(Patient patient)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.Redirect("MedicationSummaryForm.aspx");
		}
		#endregion

		#region PatientMedications
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientMedicationCollection PatientMedications
		{
			get { return patientMedications; }
			set
			{
				patientMedications = value;
				try
				{
					gridMedications.UpdateFromCollection(patientMedications);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(PatientMedicationCollection), patientMedications);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool LoadPatientMedications()
		{
			bool result = true;
			PatientMedicationCollection patientMedications = new PatientMedicationCollection();
			try
			{
				this.patient.LoadPatientMedications(false);
				patientMedications = this.patient.PatientMedications;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.PatientMedications = patientMedications;
			return result;
		}
		#endregion

		#region UI Initialization and Events
		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}
		
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			//AddNewMedication control should not be visible in PrintPreviewMode
			this.SetPageTabToolbarItemVisible("AddNewMedication", !this.PrintPreviewMode);
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Medications":
					toolbar.AddButton("@ADDMEDICATION@", "AddNewMedication");
					break;
			}
		}

		private void gridMedications_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = gridMedications.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
			{
				PatientMedication = PatientMedications[index];
			}
		}
		
		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveMedications())
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Medication "); 
		}

		public void OnToolbarButtonClick_AddNewMedication(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewPatientMedication();
			gridMedications.SelectedRowIndex = -1;
		}

		private bool SaveMedications()
		{
			bool result, wasNew;

			wasNew = PatientMedication.IsNew;
			PatientMedication.PatientID = patient.PatientId;
			
			result = SaveDataForPatientMedication(); // attempt to Save to DB. Business rulles will be evaluated here.
			if(wasNew && result)
			{
				PatientMedications.Add(PatientMedication);
				PatientMedications = PatientMedications;
				gridMedications.SelectedRowIndex = gridMedications.Rows.Count - 1;	
			}
			else if(!wasNew && result && this.patientMedication.Active)
				// updating grid to reflect changes made to the PatientMedication
				gridMedications.UpdateRowFromObject(gridMedications.GetRowIndexFromPK(this.patientMedication.PK), this.patientMedication);
			else 
			{
				/*remove item from grid - because it was deactived - updating PatientMedication*/
				PatientMedications = PatientMedications;
				PatientMedication = SetSelectedGridItem(this.gridMedications, this.patientMedications, this.gridMedications.Rows.Count - 1, true) as PatientMedication;
			}
			
			return result;
		}
		
		private void SetMedicineFreeEntry()
		{
			bool state = PatientMedication.EnableICMMedications;
			/* FALSE - forces user to pick a medication
			 * TRUE  - FFRM medication entry
			 * */
			
			this.GeneralNamingTable1.Visible = !state;
			this.GeneralNamingTable2.Visible = !state;
			this.lbMedicationFFRM.Visible = state;
			this.MedicationFFRM.Visible = state;
			this.vldMedicationFFRM.Visible = state;
			this.WindowOpenerForMedicationId.Visible = !state;
		}

		private void StatusID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			this.patientMedication.MedicationID = (int)this.MedicationID.Value;
			
			ReadControls();

			PatientMedication = this.patientMedication;
		}
		#endregion
	}
}
