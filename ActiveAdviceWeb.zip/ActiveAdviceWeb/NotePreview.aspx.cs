using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Data.SqlTypes;


namespace ActiveAdvice.Web
{
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Note,DataLayer")]
	[PageTitle("@NOTEPREVIEWPAGETITLE@")]
	public class NotePreview : BasePage
	{
		private NoteCollection notesToBePrinted;
		protected TextControl txTextControl;

		private void Page_Load(object sender, System.EventArgs e)
		{
			notesToBePrinted = (NoteCollection)this.LoadObject(typeof(NoteCollection));  // load object from cache
			txTextControl.TextControlMode = TextControlModeEnum.SimpleEditor | TextControlModeEnum.PrintPreview;

			ConcatenateNotes();

			this.RegisterStartupScript("autoPrint", "<script language=javascript>setTimeout('mnu_menu_file_print()', 3000);</script>");
		}

		
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
		}

		public void ConcatenateNotes()
		{
			try
			{
				if (notesToBePrinted == null || notesToBePrinted.RealCount == 0) return;
				
				this.txTextControl.ClearContents();

				// We need notes in reverse chronological order

				NoteComparer noteComparer = new NoteComparer();
				SortedList sortedNotes = new SortedList(noteComparer);

				foreach (Note note in notesToBePrinted)
					sortedNotes.Add(note, note);

				for (int index = 0; index < sortedNotes.Count; index++)
				{
					Note note = (Note)sortedNotes.GetByIndex(index);
					DateTime dateX = (note.ModifyTime == DateTime.MinValue) ? note.CreateTime : note.ModifyTime;
					string userName = (note.ModifiedBy == 0) ? note.CreatedByString : note.ModifiedByString;
	
					this.txTextControl.AppendPlainText(dateX.ToString("G") + " " + userName, "Times New Roman", 12);
					this.txTextControl.InsertNewLine();

					if (note.NotePage.IsRTF)
						this.txTextControl.AppendRTF(note.NotePage.NoteText);
					else
						//this.txTextControl.AppendPlainText(note.NotePage.NoteText);
						this.txTextControl.AppendPlainText(note.NotePage.NoteText, "Courier New", 10);

					this.txTextControl.InsertNewLine();					
				}
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}
		}




		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.Load += new System.EventHandler(this.Page_Load);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.AutoScroll = true;
			this.ValidationsOnlyInSummary = true;
			this.WindowMode = NetsoftUSA.WebForms.WindowMode.ModalDialog;
		}
		#endregion

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("This page is designed to be run as a popUp");
		}

	}


	public class NoteComparer : IComparer 
	{
		public NoteComparer() : base() { }

		int IComparer.Compare(object x, object y) 
		{
			Note noteX = (Note) x;
			Note noteY = (Note) y;

			if (noteX == null && noteY == null) 
				return 0;
			else if (noteX == null && noteY != null) 
				return 1;
			else if (noteX != null && noteY == null) 
				return -1;
			else
			{
				DateTime dateX = (noteX.ModifyTime == DateTime.MinValue) ? noteX.CreateTime : noteX.ModifyTime;
				DateTime dateY = (noteY.ModifyTime == DateTime.MinValue) ? noteY.CreateTime : noteY.ModifyTime;
				return dateY.CompareTo(dateX);
			}
		}
	}

}


