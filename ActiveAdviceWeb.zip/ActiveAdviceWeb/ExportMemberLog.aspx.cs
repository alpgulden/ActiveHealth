using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.BaseClassesInterfaces;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.IMPORT_EXPORT_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.ImportExportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("MemberLog")]
	public class ExportMemberLogForm : ImportExportBasePage
	{
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFileName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FileName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFileName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOrgLevelID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo OrgLevelID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrgLevelID;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridOrgs;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMemberLog;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLabel;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Label;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLabel;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
				this.LoadData();			// Use load data method for data entry forms
		}

		protected void LoadData()
		{
			// First empty our caches
			MORGS = null;
			ORGS  = null;
			SORGS = null;

			// Always start off with the MORG (level = 1).
			MemberLogArgs mla = new MemberLogArgs();
			mla.OrgLevelID	= 1; // default to MORGs
			mla.FileName	= null;
			this.UpdateFromObject(pnlMemberLog.Controls, mla);
			this.UpdateFromObject(pnlMemberLog.Controls, (MembershipLogArguments)mla);
			this.UpdateFromObject(pnlMemberLog.Controls, (TaskArguments)mla);
			gridOrgs.UpdateFromCollection(MORGS);
			CacheObject(typeof(MemberLogArgs), mla);
		}


		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("ExportMemberLogForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.OrgLevelID.SelectedRowChanged += new Infragistics.WebUI.WebCombo.SelectedRowChangedEventHandler(this.OrgLevelID_SelectedRowChanged);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
		}

		protected void UpdateOrgGrid()
		{
			if (!orglevelchanged)
				return;

			MemberLogArgs mla = (MemberLogArgs)LoadObject(typeof(MemberLogArgs), true);

			// save the state we are returning with...
			switch(mla.OrgLevelID)
			{
				default:
				case 1:
					gridOrgs.UpdateToCollection(MORGS);
					break;
				case 2:
					gridOrgs.UpdateToCollection(ORGS);
					break;
				case 3:
					gridOrgs.UpdateToCollection(SORGS);
					break;
			}

			// Get the page state into our local object
			this.UpdateToObject(pnlMemberLog.Controls, mla);
			this.UpdateToObject(pnlMemberLog.Controls, (MembershipLogArguments)mla);
			this.UpdateToObject(pnlMemberLog.Controls, (TaskArguments)mla);

			// Determine what to fill organization grid with based on
			// user's selection...
			switch(mla.OrgLevelID)
			{
				default:
				case 1:
					gridOrgs.UpdateFromCollection(MORGS);
					break;
				case 2:
					gridOrgs.UpdateFromCollection(ORGS);
					break;
				case 3:
					gridOrgs.UpdateFromCollection(SORGS);
					break;
			}

			CacheObject(typeof(MemberLogArgs), mla);
		}

		OrganizationSummaryCollection morgs = null;
		public OrganizationSummaryCollection MORGS
		{
			get
			{
				if (null == morgs)
				{
					morgs = (OrganizationSummaryCollection)this.LoadObject("MORGS");
					if (null == morgs)
					{
						morgs = new OrganizationSummaryCollection();
						morgs.GetValidOrganizationsByLevel(-1, 1, DateTime.Now);
//						morgs.GetOrganizationsByLevel(-1, 1);
						this.CacheObject("MORGS", morgs); // cache to the session
					}
				}

				return morgs;
			}
			set
			{
				morgs = value;
				this.CacheObject("MORGS", morgs);
			}
		}

		OrganizationSummaryCollection orgs = null;
		public OrganizationSummaryCollection ORGS
		{
			get
			{
				if (null == orgs)
				{
					orgs = (OrganizationSummaryCollection)this.LoadObject("ORGS");
					if (null == orgs)
					{
						orgs = new OrganizationSummaryCollection();
						orgs.GetValidOrganizationsByLevel(-1, 2, DateTime.Now);
//						orgs.GetOrganizationsByLevel(-1, 2);
						this.CacheObject("ORGS", orgs); // cache to the session
					}
				}

				return orgs;
			}
			set
			{
				orgs = value;
				this.CacheObject("ORGS", orgs);
			}
		}

		OrganizationSummaryCollection sorgs = null;
		public OrganizationSummaryCollection SORGS
		{
			get
			{
				if (null == sorgs)
				{
					sorgs = (OrganizationSummaryCollection)this.LoadObject("SORGS");
					if (null == sorgs)
					{
						sorgs = new OrganizationSummaryCollection();
						sorgs.GetValidOrganizationsByLevel(-1, 3, DateTime.Now);
//						sorgs.GetOrganizationsByLevel(-1, 3);
						this.CacheObject("SORGS", sorgs); // cache to the session
					}
				}

				return sorgs;
			}
			set
			{
				sorgs = value;
				this.CacheObject("SORGS", sorgs);
			}
		}

		/// <summary>
		/// SaveData()
		/// Write the information collected from the User to the database.
		/// From here the "Service" will pickup the task and perform the
		/// requested operation.
		/// </summary>
		/// <returns></returns>
		protected bool SaveData()
		{
			MemberLogArgs mla = null;
			try
			{
				mla = new MemberLogArgs();
				this.UpdateToObject(pnlMemberLog.Controls, mla);
				this.UpdateToObject(pnlMemberLog.Controls, (MembershipLogArguments)mla);
				this.UpdateToObject(pnlMemberLog.Controls, (TaskArguments)mla);

				// Make sure we have our required data...
				if (!this.IsValid)
					return false;

				CacheObject(typeof(MemberLogArgs), mla);
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				throw ex;
			}

			try
			{
				switch(mla.OrgLevelID)
				{
					case 1:
					default:
						gridOrgs.UpdateToCollection(MORGS);
						break;
					case 2:
						gridOrgs.UpdateToCollection(ORGS);
						break;
					case 3:
						gridOrgs.UpdateToCollection(SORGS);
						break;
				}
			}
			catch(Exception exUpdate)
			{
				string msg = exUpdate.Message;
				throw exUpdate;
			}

			// okay we have ORGlist data, let's put it into the classes that'll be saved to the db
			// First create a schedule task and set it's status to 'INVL' (invalid) in the database
			// while we construct the list of morg/org/sorg
			ScheduleTask st = null;
			
			try
			{
				st = new ScheduleTask();
				if (ValidateArguments((TaskArguments)mla, false) ) // eligibility only supports filenames, not folders
				{
					// We can write this task out...
					ScheduleTypeCollection types		= ScheduleTask.ActiveScheduleTypes;
					st.ScheduleTypeID					= types.IndexBy_Code.LookupIntMember("ScheduleTypeID", "MLOG");	// Membership Log
					ScheduleStatusCollection statuses	= ScheduleTask.ActiveScheduleStatuses;
					st.ScheduleStatusID					= statuses.IndexBy_Code.LookupIntMember("ScheduleStatusID", "INVL");	// Invalid - updating data

					st.Task				= mla.Task;	// create our "task" string
					st.Label			= mla.Label;	// label to attached to the scheduled item...
					st.CreatedBy		= this.CurrentUser;
					st.CreateTime		= DateTime.Now;
					st.ScheduledTime	= DateTime.Now;

					// Insert the record into the table...
					st.Insert();
				}
			}
			catch(Exception stEx)
			{
				string msg = stEx.Message;
				throw(stEx);
			}

			// Take all the selected MORG/ORG/SORGs and put them into 
			// the dataclass so they can be written to the database.
			InterfaceORGListCollection iolc = new InterfaceORGListCollection();
			foreach(OrganizationSummary os in MORGS)
			{
				if (os.Selected)
				{
					InterfaceORGList iol = new InterfaceORGList(true); // init object
					iol.OrganizationLevelID = os.OrganizationLevelID;
					iol.OrganizationID		= os.OrganizationID;
					iol.JobID				= st.JobID;
					iolc.Add(iol);
				}
			}
			foreach(OrganizationSummary os in ORGS)
			{
				if (os.Selected)
				{
					InterfaceORGList iol = new InterfaceORGList(true); // init object
					iol.OrganizationLevelID = os.OrganizationLevelID;
					iol.OrganizationID		= os.OrganizationID;
					iol.JobID				= st.JobID;
					iolc.Add(iol);
				}
			}
			foreach(OrganizationSummary os in SORGS)
			{
				if (os.Selected)
				{
					InterfaceORGList iol	= new InterfaceORGList(true); // init object
					iol.OrganizationLevelID = os.OrganizationLevelID;
					iol.OrganizationID		= os.OrganizationID;
					iol.JobID				= st.JobID;
					iolc.Add(iol);
				}
			}

			try
			{
				// Okay, let's write out our ORG list
				iolc.Save();

				// Okay the OrgList has been written, so we can update our status to "Pending"
				ScheduleStatusCollection schedstatus	= ScheduleTask.ActiveScheduleStatuses;
				st.ScheduleStatusID						= schedstatus.IndexBy_Code.LookupIntMember("ScheduleStatusID", "PEND");	// Invalid - updating data
				st.Update();
			}
			catch(Exception e)
			{
				string msg = e.Message;
				throw e;
			}
			return true;
		}// end of method

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				MemberLogArgs mla = (MemberLogArgs)LoadObject(typeof(MemberLogArgs), false);
				this.SetPageMessage("@QUEUEEXPORT@", EnumPageMessageType.Info, mla.Label);
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			UpdateOrgGrid();
		}

		bool orglevelchanged = false;
		private void OrgLevelID_SelectedRowChanged(object sender, Infragistics.WebUI.WebCombo.SelectedRowChangedEventArgs e)
		{
			orglevelchanged = true;
			this.ValidationsEnabled = false; // turn off validators, just updating the grid
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@UPDATE@", "Save");
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

	}// end of class

	[TableMapping(null)]
	public class MemberLogArgs : MembershipLogArguments
	{
		int orglevelid;
		[FieldValuesMember("LookupOf_OrgLevelID", "OrgLevelID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int OrgLevelID
		{
			get { return this.orglevelid; }
			set { this.orglevelid = value; }
		}

		/// <summary>
		/// LookupOf_OrgLevelID
		/// returns a collection of schedule types, the first record
		/// being "ALL".
		/// </summary>
		public OrgNameCollection LookupOf_OrgLevelID
		{
			get
			{
				OrgNameCollection onc = new OrgNameCollection();
				OrgName on = new OrgName(1, "MORG");
				onc.InsertRecord(0, on);
				on = new OrgName(2, "ORG");
				onc.InsertRecord(1, on);
				on = new OrgName(3, "SORG");
				onc.InsertRecord(2, on);
				return onc;
			}
		}

	}// end of class

}// end of namespace
