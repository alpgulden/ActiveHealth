ALTER VIEW Report_MoveERCActivities
AS
	/*******EVENT********/
	SELECT DISTINCT EventP.ActivityID, EventP.ActivityType, EventP.ActPrimaryType, EventP.OriginalPatientID, EventP.NewPatientID, EventP.ModifiedDate as MoveDate, EventP.ActivityDescription, PC.PlanId as NewPlan--,  MST.ManagementServiceTypeId as NewMgtServiceType--Activity New Patient Info: that were moved but the new patient doesn't have the MST that the old patient has 
	FROM		(SELECT A.ActivityAmount, MEL.NewPatientID, A.ActivityID, AT.Description as ActivityType, APT.Description as ActPrimaryType, A.ActivityDescription, MEL.OriginalPatientID, MEL.ModifiedDate --New PatientID details that event / activities are moved to and Moved Activity data
				FROM	MoveEventReferralLog MEL INNER JOIN
				Event E ON MEL.EventReferralID = E.EventID INNER JOIN
				Activity A ON E.EventId = A.EventID LEFT JOIN 
				ActivityType AT ON A.ActivityTypeId = AT.ActivityTypeID LEFT JOIN
				ActivityPrimaryType APT ON AT.ActivityPrimaryTypeId = APT.ActivityPrimaryTypeId 		
				where MEL.ER = 'E' and A.ActivityAmount = '0.00') EventP INNER JOIN 
			PatientCoverage PC ON EventP.NewPatientID = PC.PatientID INNER JOIN 
			[Plan] P ON PC.PlanId = P.PlanId INNER JOIN 
			ManagementService MS ON MS.ManagementServiceid = P.ManagementServiceID INNER JOIN 
			ManagementServiceItem MSI ON MS.ManagementServiceID = MSI.ManagementServiceId INNER JOIN 
			ManagementServiceType MST ON MSI.ManagementServiceTypeId = MST.ManagementServiceTypeId --To retrieve mgtservicetypes for the new patient's plans 
	WHERE MST.ManagementServiceTypeId NOT IN
				
				/**Selecting Original Patient's ManagementServiceType's**/
				(SELECT MST.ManagementServiceTypeId--, EventP.OriginalPatientID, PC.PlanId, PC.PatientID, PC.PlanID, PC.IsPrimary
				FROM	(SELECT  MEL.OriginalPatientID--,MEL.EventReferralID,a.activityid --PatientIDs that has event / activities moved 
						FROM	MoveEventReferralLog MEL INNER JOIN
						Event E ON MEL.EventReferralID = E.EventID INNER JOIN
						Activity A ON E.EventId = A.EventID
						where MEL.ER = 'E')		EventP INNER JOIN 
					PatientCoverage PC ON EventP.OriginalPatientID = PC.PatientID INNER JOIN 
					[Plan] P ON PC.PlanId = P.PlanId INNER JOIN --To retrieve the plans for the originalpatient
					ManagementService MS ON MS.ManagementServiceid = P.ManagementServiceID INNER JOIN 
					ManagementServiceItem MSI ON MS.ManagementServiceID = MSI.ManagementServiceId INNER JOIN 
					ManagementServiceType MST ON MSI.ManagementServiceTypeId = MST.ManagementServiceTypeId --To retrieve mgtservicetypes for the original patient 
				GROUP BY EventP.OriginalPatientID, PC.PlanId,  MST.ManagementServiceTypeId)


UNION 
	/******CMS******/
	SELECT DISTINCT CMSP.ActivityID, CMSP.ActivityType, CMSP.ActPrimaryType, CMSP.OriginalPatientID, CMSP.NewPatientID, CMSP.ModifiedDate as MoveDate, CMSP.ActivityDescription,  PC.PlanId as NewPlan --Activity New Patient Info: that were moved but the new patient doesn't have the MST that the old patient has 
	FROM		(SELECT A.ActivityAmount, MEL.NewPatientID, A.ActivityID, AT.Description as ActivityType, APT.Description as ActPrimaryType, A.ActivityDescription, MEL.OriginalPatientID, MEL.ModifiedDate --New PatientIDs that CMS / activities are moved to and Moved Activity Data
				FROM	MoveEventReferralLog MEL INNER JOIN
				CMS C ON MEL.EventReferralID = C.CMSID INNER JOIN
				Activity A ON C.CMSID = A.CMSID LEFT JOIN 
				ActivityType AT ON A.ActivityTypeId = AT.ActivityTypeID LEFT JOIN
				ActivityPrimaryType APT ON AT.ActivityPrimaryTypeId = APT.ActivityPrimaryTypeId 		
				where MEL.ER = 'C' and A.ActivityAmount = '0.00') CMSP INNER JOIN 
			PatientCoverage PC ON CMSP.NewPatientID = PC.PatientID INNER JOIN 
			[Plan] P ON PC.PlanId = P.PlanId INNER JOIN 
			ManagementService MS ON MS.ManagementServiceid = P.ManagementServiceID INNER JOIN 
			ManagementServiceItem MSI ON MS.ManagementServiceID = MSI.ManagementServiceId INNER JOIN 
			ManagementServiceType MST ON MSI.ManagementServiceTypeId = MST.ManagementServiceTypeId --To retrieve mgtservicetypes for the new patient's plans 
	WHERE MST.ManagementServiceTypeId NOT IN
				
				/**Selecting Original Patient's ManagementServiceTypes**/
				(SELECT MST.ManagementServiceTypeId
				 FROM	(SELECT MEL.OriginalPatientID 
						FROM	MoveEventReferralLog MEL INNER JOIN
						CMS C ON MEL.EventReferralID = C.CMSID INNER JOIN
						Activity A ON C.CMSID = A.CMSID LEFT JOIN 
						ActivityType AT ON A.ActivityTypeId = AT.ActivityTypeID LEFT JOIN
						ActivityPrimaryType APT ON AT.ActivityPrimaryTypeId = APT.ActivityPrimaryTypeId 		
						where MEL.ER = 'C')		CMSP INNER JOIN 
					PatientCoverage PC ON CMSP.OriginalPatientID = PC.PatientID INNER JOIN 
					[Plan] P ON PC.PlanId = P.PlanId INNER JOIN --To retrieve the plans for the originalpatient
					ManagementService MS ON MS.ManagementServiceid = P.ManagementServiceID INNER JOIN 
					ManagementServiceItem MSI ON MS.ManagementServiceID = MSI.ManagementServiceId INNER JOIN 
					ManagementServiceType MST ON MSI.ManagementServiceTypeId = MST.ManagementServiceTypeId --To retrieve mgtservicetypes for the original patient 
				GROUP BY CMSP.OriginalPatientID, PC.PlanId,  MST.ManagementServiceTypeId)
UNION
	/**********REFERRAL*******/
	SELECT DISTINCT ReferralP.ActivityID, ReferralP.ActivityType, ReferralP.ActPrimaryType, ReferralP.OriginalPatientID, ReferralP.NewPatientID, ReferralP.ModifiedDate as MoveDate, ReferralP.ActivityDescription, PC.PlanId as NewPlan--,  MST.ManagementServiceTypeId as NewMgtServiceType--Activity New Patient Info: that were moved but the new patient doesn't have the MST that the old patient has 
	FROM		(SELECT A.ActivityAmount, MEL.NewPatientID, A.ActivityID, AT.Description as ActivityType, APT.Description as ActPrimaryType, A.ActivityDescription, MEL.OriginalPatientID, MEL.ModifiedDate --New PatientIDs that event / activities are moved to and Moved Activity Details
				FROM	MoveEventReferralLog MEL INNER JOIN
				Referral R ON MEL.EventReferralID = R.ReferralID INNER JOIN
				Activity A ON R.Referralid = A.ReferralID LEFT JOIN 
				ActivityType AT ON A.ActivityTypeId = AT.ActivityTypeID LEFT JOIN
				ActivityPrimaryType APT ON AT.ActivityPrimaryTypeId = APT.ActivityPrimaryTypeId 		
				where MEL.ER = 'R' and A.ActivityAmount = '0.00') ReferralP INNER JOIN 
			PatientCoverage PC ON ReferralP.NewPatientID = PC.PatientID INNER JOIN 
			[Plan] P ON PC.PlanId = P.PlanId INNER JOIN 
			ManagementService MS ON MS.ManagementServiceid = P.ManagementServiceID INNER JOIN 
			ManagementServiceItem MSI ON MS.ManagementServiceID = MSI.ManagementServiceId INNER JOIN 
			ManagementServiceType MST ON MSI.ManagementServiceTypeId = MST.ManagementServiceTypeId --To retrieve mgtservicetypes for the new patient's plans 
	WHERE MST.ManagementServiceTypeId NOT IN
				
				/**Selecting Original Patient's ManagementServiceTypes**/
				(SELECT MST.ManagementServiceTypeId
				 FROM	(SELECT MEL.OriginalPatientID --New PatientIDs that referral / activities are moved to and Moved Activity data
						FROM	MoveEventReferralLog MEL INNER JOIN
						Referral R ON MEL.EventReferralID = R.ReferralID INNER JOIN
						Activity A ON R.Referralid = A.ReferralID LEFT JOIN 
						ActivityType AT ON A.ActivityTypeId = AT.ActivityTypeID LEFT JOIN
						ActivityPrimaryType APT ON AT.ActivityPrimaryTypeId = APT.ActivityPrimaryTypeId 		
						where MEL.ER = 'R')		ReferralP INNER JOIN 
					PatientCoverage PC ON ReferralP.OriginalPatientID = PC.PatientID INNER JOIN 
					[Plan] P ON PC.PlanId = P.PlanId INNER JOIN --To retrieve the plans for the originalpatient
					ManagementService MS ON MS.ManagementServiceid = P.ManagementServiceID INNER JOIN 
					ManagementServiceItem MSI ON MS.ManagementServiceID = MSI.ManagementServiceId INNER JOIN 
					ManagementServiceType MST ON MSI.ManagementServiceTypeId = MST.ManagementServiceTypeId --To retrieve mgtservicetypes for the original patient 
				GROUP BY ReferralP.OriginalPatientID, PC.PlanId,  MST.ManagementServiceTypeId)