SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_IPUtilization]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_IPUtilization]
GO

CREATE         VIEW dbo.Report_IPUtilization
AS
--LEGACY VIEW HCC_RPT_150_V 
SELECT 
'E' RecType,
1 SessionID,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
VPSL.MorgID,
VPSL.MorgName,

pla.PlanID,
ISNULL(pla.[Name],'zNo Plan') as PlanName,
e.EventID,
pat.PatientID,
ISNULL(drgsc.[Description],'zNo Service Class') as ServiceClass,
e.ProviderID,
ISNULL(p.LastName,'zNo Attending Provider')+' '+ISNULL(p.FirstName, '')+' '+ISNULL(p.MiddleInitial,'') as ProviderName,
e.PCPID,
ISNULL(pcp.LastName,'zNo PCP')+' '+ISNULL(pcp.FirstName, '')+' '+ISNULL(pcp.MiddleInitial,'') as PCPName,
e.FacilityID,
ISNULL(f.[Name],'zNo Facility') as FacilityName,
et.[Description] as EventType,
drg.DRGserviceclass,
ISNULL(e.DRGCode,'zNo DRG') as DRGCode, 
ISNULL(drg.DRGTitle, 'zNo DRG') as DRGTitle, 
drg.DRGweight,
e.EndDate as SelectDate,
e.StartDate as EventStartDate,
e.EndDate as EventEndDate,
DATEDIFF(day,e.StartDate,e.EndDate) as EventDays,
dbo.GetLOS(e.StartDate,isnull(e.EndDate,GetDate())) as EventLOS,
e.LOS_50,
e.LOS_95,
ISNULL(pla.LengthOfStayTrigger, 10 ) as LOSTrigger,
pla.OutlierTrigger,
ISNULL( 
(CASE
WHEN pla.OutlierTrigger = '10' THEN e.LOS_10
WHEN pla.OutlierTrigger = '25' THEN e.LOS_25
WHEN pla.OutlierTrigger = '50' THEN e.LOS_50
WHEN pla.OutlierTrigger = '75' THEN e.LOS_75
WHEN pla.OutlierTrigger = '90' THEN e.LOS_90
WHEN pla.OutlierTrigger = '95' THEN e.LOS_95
WHEN pla.OutlierTrigger = '99' THEN e.LOS_99
ELSE null END), isnull(pla.LengthOfStayTrigger,10)) as OutlierLOS,
et.HEDISRptType,
ss.Code as Status,

sorgml.SorgLives,
orgml.OrgLives,
morgml.MorgLives,
planml.PlanLives,
0 TotalLives, -- not used in the report


DATEDIFF(month,vpsl.PatientDOB, e.EndDate) / 12 as PatientAge,
ISNULL(pat.Gender,'zNo Gender') + ' :' + 
			CASE
			WHEN vpsl.PatientDOB is null THEN 'No Age' 
			ELSE dbo.GetAgeRange(e.EndDate,vpsl.PatientDOB) 
			END as AgeRangeGender,

VPSL.PatientDOB,
pat.Gender,

e.DischSameMom,
dbo.GetIsOutlier
(dbo.GetLOS(e.StartDate,isnull(e.EndDate,GetDate())),
isnull(pla.LengthOfStayTrigger,10),
isnull(
(CASE
WHEN pla.OutlierTrigger = '10' THEN e.LOS_10
WHEN pla.OutlierTrigger = '25' THEN e.LOS_25
WHEN pla.OutlierTrigger = '50' THEN e.LOS_50
WHEN pla.OutlierTrigger = '75' THEN e.LOS_75
WHEN pla.OutlierTrigger = '90' THEN e.LOS_90
WHEN pla.OutlierTrigger = '95' THEN e.LOS_95
WHEN pla.OutlierTrigger = '99' THEN e.LOS_99
ELSE null END), isnull(pla.LengthOfStayTrigger,10))) as IsOutlier



FROM Event e
INNER JOIN SystemStatus ss ON e.StatusID = ss.StatusID and ss.CodeStatus = 'CLOS'
LEFT JOIN EventType et ON e.EventTypeID = et.EventTypeID and et.HEDISRptType='IP'
LEFT JOIN  dbo.Report_PatientSubscriberLog VPSL ON e.PatientSubscriberLogId = VPSL.PatientSubscriberLogId

LEFT JOIN (SELECT SorgID, SUM(TotalMembers) AS SorgLives FROM MemberLives GROUP BY SorgID) sorgml ON vpsl.SorgID = sorgml.SorgID
LEFT JOIN (SELECT OrgID, SUM(TotalMembers) AS OrgLives FROM MemberLives GROUP BY OrgID) orgml ON vpsl.OrgID = orgml.OrgID
LEFT JOIN (SELECT MorgID, SUM(TotalMembers) AS MorgLives FROM MemberLives GROUP BY MorgID) morgml ON vpsl.MorgID = morgml.MorgID
LEFT JOIN (SELECT PlanID, SUM(TotalMembers) AS PlanLives FROM MemberLives GROUP BY PlanID) planml ON vpsl.PlanID = planml.PlanID


LEFT JOIN PlanSorgLog psl ON e.PlanSorgLogID = psl.PlanSorgLogID 
LEFT JOIN [Plan] pla ON psl.PlanID = pla.PlanID
LEFT JOIN DRGCode drg ON e.DRGCode = drg.DRGCode AND e.DRGVersion = drg.DRGVersion AND e.DRGType = drg.DRGType
LEFT JOIN DRGServiceClass drgsc ON drg.DRGserviceclass = drgsc.Code

LEFT JOIN Provider p ON e.ProviderID = p.ProviderID
LEFT JOIN Location loc ON e.ProviderLocationID = loc.LocationID
LEFT JOIN Address padr ON loc.ServiceAddressID = padr.AddressID

LEFT JOIN Provider pcp ON e.ProviderID = pcp.ProviderID
LEFT JOIN Location ploc ON e.PCPLocationID = ploc.LocationID
LEFT JOIN Address pcpadr ON ploc.ServiceAddressID = pcpadr.AddressID

LEFT JOIN Facility f ON e.FacilityID = f.FacilityID 
LEFT JOIN Location l ON e.FacilityLocationID = l.LocationID
LEFT JOIN Address fadr ON l.ServiceAddressID = fadr.AddressID

LEFT JOIN EventReferralDiagnose erd ON e.EventID = erd.EventID and erd.[Sequence]= 10
LEFT JOIN EventReferralProcedure erp ON E.EventID =erp.EventID and erp.[Sequence] = 10 

LEFT JOIN Problem pr ON E.PrimaryProblemID = pr.ProblemID
LEFT JOIN Patient pat ON e.PatientID = pat.PatientID
LEFT JOIN Address patadr ON pat.AddressID = patadr.AddressID



/*
HCC_RPT_150_V
INPATIENT UTILIZATION
SELECT
 'E' REC_TYPE,
 k.SESSION_ID,
 e.MORG_ID, 
 e.MORG_NAME,
 f.ORG_ID,  
 f.ORG_NAME,
 g.SORG_ID,  
 g.SORG_NAME,
 h.PLAN_ID,  
 decode(h.PLAN_NAME,null,'zNo Plan',' '||h.PLAN_NAME) PLAN_NAME,
 a.EVENT_ID,
 s.PATIENT_ID, 
 decode(j.CODE_DESC,null,'zNo Service Class',' '||j.CODE_DESC)  SERVICE_CLASS,
 a.HEALTH_CENTER_ID, 
 decode(l.CODE_DESC,null,'zNo Health Center',' '||l.CODE_DESC) HEALTH_CENTER,
 a.PROVIDER_ID, 
 decode(m.LNAME,null,'zNo Attending Provider',' '||m.LNAME||decode(m.FNAME,null,'',', '||m.FNAME)||' ('||a.PROVIDER_ID||')') PROV_NAME,
 a.PCP_ID, 
 decode(n.LNAME,null,'zNo PCP',' '||n.LNAME||decode(n.FNAME,null,'',', '||n.FNAME)||' ('||a.PCP_ID||')') PCP_NAME,
 a.FACILITY_ID, 
 decode(o.NAME,null,'zNo Facility',' '||o.NAME||' ('||a.FACILITY_ID||')') FAC_NAME,
 c.CODE_DESC  EVENT_TYPE,
 i.DRG_SERVICE_CLASS,
 decode(a.DRG_CODE,null,'zNo DRG',' '||a.DRG_CODE||': '||i.DRG_TITLE) DRG_CODE,
 decode(a.DRG_CODE,null,'zNo DRG',' '||a.DRG_CODE||': '||i.DRG_TITLE) DRG_TITLE,
 i.DRG_WEIGHT, 
 a.EVENT_END_DATE SELECT_DATE, 
 a.EVENT_START_DATE, a.EVENT_END_DATE,
 a.EVENT_END_DATE-a.EVENT_START_DATE EVENT_DAYS, 
 COMPUTE_LOS(a.EVENT_START_DATE,a.EVENT_END_DATE) EVENT_LOS,
 a.LOS_50, 
 a.LOS_95, 
 nvl(h.LOS_TRIGGER,10) LOS_TRIGGER,
 h.OUTLIER_TRIGGER,
 nvl(decode(h.OUTLIER_TRIGGER,10,a.los_10,25,a.los_25,50,a.los_50,
        75,a.los_75,90,a.los_90,95,a.los_95,99,a.los_99,null),
        nvl(h.LOS_TRIGGER,10)) OUTLIER_LOS,
 c.HEDIS_RPT_TYPE, 
 b.CODE_STATUS,
 p.DX_TYPE,
 decode(p.DX_CODE,null,'zNo Diagnosis',' '||p.DX_CODE||': '||rtrim(rpad
	(DX_PX_DESCRIPTION(p.DX_TYPE,'D',p.DX_CODE),60))||' ('||p.DX_TYPE||')') DX_CODE,
 decode(p.DX_CODE,null,'',p.DX_CODE||': '||rtrim(rpad
        (DX_PX_DESCRIPTION(p.DX_TYPE,'D',p.DX_CODE),60))||' ('||p.DX_TYPE||')') DX_TITLE,
 decode(q.LINKED_PX_TYPE,'ICD9',q.LINKED_PX_TYPE,q.PX_TYPE) PX_TYPE,
 decode(q.LINKED_PX_TYPE,null,'zNo Procedure','ICD9',' '||q.LINKED_PX_CODE||': '
	||rtrim(rpad(DX_PX_DESCRIPTION(q.LINKED_PX_TYPE,'P',q.LINKED_PX_CODE),60))
        ||' ('||q.LINKED_PX_TYPE||')',
 	' '||PX_CODE||': '||rtrim(rpad(
        DX_PX_DESCRIPTION(q.PX_TYPE,'P',q.PX_CODE),60))||' ('||q.PX_TYPE||')') PX_CODE,
 decode(PX_CODE,null,'',PX_CODE||': '||
	rtrim(rpad(DX_PX_DESCRIPTION(
        decode(q.LINKED_PX_TYPE,'ICD9',q.LINKED_PX_TYPE,q.PX_TYPE),'P',
        decode(q.LINKED_PX_TYPE,'ICD9',q.LINKED_PX_CODE,q.PX_CODE)),60))||
	' ('||q.PX_TYPE||')') PX_TITLE,
 k.MORG_LIVES, 
 k.ORG_LIVES, 
 k.SORG_LIVES, 
 k.PLAN_LIVES, 
 k.TOTAL_LIVES,
 upper(s.PT_SEX) PT_SEX,

 TRUNC(MONTHS_BETWEEN(a.EVENT_END_DATE,s.PT_DOB)/12) PT_AGE,
 decode(upper(s.PT_SEX),null,'z',decode(s.PT_DOB,null,'z',' '))
 ||rtrim(rpad(nvl(upper(s.PT_SEX),'No Gender')||': '||
 decode(s.PT_DOB,null,'No Age',
 rpt_150_agerange(a.EVENT_END_DATE,s.PT_DOB)),20)) age_range,
 nvl(a.DISCH_SAME_MOM,'N') DISCH_SAME_MOM,
 rtrim(rpad(RPT_150_IS_OUTLIER(
	COMPUTE_LOS(a.EVENT_START_DATE,a.EVENT_END_DATE),
 	nvl(h.LOS_TRIGGER,10),nvl(decode(h.OUTLIER_TRIGGER,10,a.los_10,25,a.los_25,50,a.los_50,
        75,a.los_75,90,a.los_90,95,a.los_95,99,a.los_99,null),
	nvl(h.LOS_TRIGGER,10))),1)) IS_OUTLIER
FROM
HCC_PPER_EVENT a,
HCC_SYST_STATUS b,
HCC_PPER_EVENT_TYPE c,
HCC_PLAN_SORG_PLAN_LOG d,
HCC_ORGN_MORG e,
HCC_ORGN_ORG f,
HCC_ORGN_SORG g,
HCC_PLAN_PLAN h,
HCC_SYST_DRG_CODE i,
HCC_SYST_SERVICE_CLASS j,
HCC_SYST_MEMB_LIVES_SUMM k,
HCC_PPER_HEALTH_CENTER l,
HCC_PRFA_PROVIDER m,
HCC_PRFA_PROVIDER n,
HCC_PRFA_FACILITY o,
HCC_PPER_EVENT_REF_DIAGNOSES p,
HCC_PPER_EVENT_REF_PROCEDURES q,
HCC_PPER_PROBLEM r,
HCC_PPER_PATIENT s
WHERE
a.EVENT_STATUS=b.CODE_ID
and b.CODE_STATUS='CLOS'
and a.EVENT_TYPE=c.CODE_ID
and c.HEDIS_RPT_TYPE='IP'
and a.PLAN_SORG_LOG_ID=d.SORG_PLAN_LOG_ID
and d.BRK_MORG_ID=e.MORG_ID
and d.BRK_MORG_ID=f.MORG_ID
and d.BRK_ORG_ID=f.ORG_ID
and d.BRK_MORG_ID=g.MORG_ID
and d.BRK_ORG_ID=g.ORG_ID
and d.BRK_SORG_ID=g.SORG_ID
and d.PLAN_ID=h.PLAN_ID
and a.DRG_CODE=i.DRG_CODE(+)
and a.DRG_TYPE=i.DRG_TYPE(+)
and a.DRG_VERSION=i.DRG_VERSION(+)
and i.DRG_SERVICE_CLASS=j.CODE_ID(+)
and a.HEALTH_CENTER_ID=l.CODE_ID(+)
and a.PROVIDER_ID=m.PROVIDER_ID(+)
and a.PCP_ID=n.PROVIDER_ID(+)
and a.FACILITY_ID=o.FACILITY_ID(+)
and d.BRK_MORG_ID=k.MORG_ID
and d.BRK_ORG_ID=k.ORG_ID
and d.BRK_SORG_ID=k.SORG_ID
and d.PLAN_ID=decode(k.PLAN_ID,0,d.PLAN_ID,k.PLAN_ID)
and (a.EVENT_ID=p.EVENT_REFERRAL_ID(+)
and p.EVENT_REFERRAL_TYPE(+)='E'
and p.SEQUENCE_ID(+)=1)
and (a.EVENT_ID=q.EVENT_REFERRAL_ID(+)
and q.EVENT_REFERRAL_TYPE(+)='E'
and q.SEQUENCE_ID(+)=1)
and a.PRIMARY_PROBLEM_ID=r.PROBLEM_ID
and r.PATIENT_ID=s.PATIENT_ID
union all
select
 'N',
 SESSION_ID, b.MORG_ID, b.MORG_NAME,
 aa.ORG_ID,  c.ORG_NAME,
 aa.SORG_ID,  d.SORG_NAME,
 aa.PLAN_ID, decode(e.PLAN_NAME,null,'zNo Plan',' '||e.PLAN_NAME) PLAN_NAME,
 0,0, 'zNo Service Class'  SERVICE_CLASS, '', 'zNo Health Center' HEALTH_CENTER,
 0, 'zNo Attending Provider' PROV_NAME,
 0, 'zNo PCP' PCP_NAME, 0, 'zNo Facility' FAC_NAME, ''  EVENT_TYPE,
 '',
  'zNo DRG', 'zNo DRG',
  0, SELECT_DATE, SELECT_DATE, SELECT_DATE,
 0 EVENT_DAYS, 0 EVENT_LOS,
 0, 0, 0,0,
 0 OUTLIER_LOS,
 '', '',
 '', 'zNo Diagnosis','',
 '','zNo Procedure','',
 MORG_LIVES, ORG_LIVES, SORG_LIVES, PLAN_LIVES,TOTAL_LIVES,
 '',0,'zNo Gender/Age Range','',''
 from
 HCC_SYST_MEMB_LIVES_SUMM aa,
 HCC_ORGN_MORG b,
 HCC_ORGN_ORG c,
 HCC_ORGN_SORG d,
 HCC_PLAN_PLAN e
 where
 aa.MORG_ID=b.MORG_ID(+)
 and aa.MORG_ID=c.MORG_ID(+)
 and aa.ORG_ID=c.ORG_ID(+)
 and aa.MORG_ID=d.MORG_ID(+)
 and aa.ORG_ID=d.ORG_ID(+)
 and aa.SORG_ID=d.SORG_ID(+)
 and aa.PLAN_ID=e.PLAN_ID(+)
 and not exists (SELECT a.event_id
	FROM
	HCC_PPER_EVENT a,
	HCC_SYST_STATUS b,
	HCC_PPER_EVENT_TYPE c,
	HCC_PLAN_SORG_PLAN_LOG d,
	HCC_ORGN_MORG e,
	HCC_ORGN_ORG f,
	HCC_ORGN_SORG g,
	HCC_PLAN_PLAN h,
	HCC_SYST_DRG_CODE i,
	HCC_SYST_SERVICE_CLASS j,
	HCC_SYST_MEMB_LIVES_SUMM k,
	HCC_PPER_HEALTH_CENTER l,
	HCC_PRFA_PROVIDER m,
	HCC_PRFA_PROVIDER n,
	HCC_PRFA_FACILITY o
	WHERE
	k.session_id=aa.session_id
	and k.morg_id=aa.morg_id
	and k.org_id=aa.org_id
	and k.sorg_id=aa.sorg_id
	and k.plan_id=aa.plan_id
	and a.event_end_date between aa.SELECT_DATE and aa.END_DATE
	and a.EVENT_STATUS=b.CODE_ID
	and b.CODE_STATUS='CLOS'
	and a.EVENT_TYPE=c.CODE_ID
	and c.HEDIS_RPT_TYPE='IP'
	and a.PLAN_SORG_LOG_ID=d.SORG_PLAN_LOG_ID
	and d.BRK_MORG_ID=e.MORG_ID
	and d.BRK_MORG_ID=f.MORG_ID
	and d.BRK_ORG_ID=f.ORG_ID
	and d.BRK_MORG_ID=g.MORG_ID
	and d.BRK_ORG_ID=g.ORG_ID
	and d.BRK_SORG_ID=g.SORG_ID
	and d.PLAN_ID=h.PLAN_ID
	and a.DRG_CODE=i.DRG_CODE(+)
	and a.DRG_TYPE=i.DRG_TYPE(+)
	and a.DRG_VERSION=i.DRG_VERSION(+)
	and i.DRG_SERVICE_CLASS=j.CODE_ID(+)
	and a.HEALTH_CENTER_ID=l.CODE_ID(+)
	and a.PROVIDER_ID=m.PROVIDER_ID(+)
	and a.PCP_ID=n.PROVIDER_ID(+)
	and a.FACILITY_ID=o.FACILITY_ID(+)
	and d.BRK_MORG_ID=k.MORG_ID
	and d.BRK_ORG_ID=k.ORG_ID
	and d.BRK_SORG_ID=k.SORG_ID
  and d.PLAN_ID=decode(k.PLAN_ID,0,d.PLAN_ID,k.PLAN_ID))
*/
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

