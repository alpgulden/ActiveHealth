SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GeneralEditEvent]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_GeneralEditEvent]
GO








CREATE        VIEW dbo.Report_GeneralEditEvent 
AS
SELECT 'E' RecType,
pat.PatientID,
pat.DateOfBirth as PatientDOB,
VPSL.PatientFullName,
--'Open Event with End Date' Message,
'Type: '+ ISNULL(et.Description, '<none>') OD1,
'Start Date: ' + ISNULL (CAST (e.StartDate as varchar),'<none>') OD2,
'End Date: ' + ISNULL(CAST (e.EndDate as varchar), '<none>') OD3,
'Status: ' + ISNULL(ss.Description, '<none>') OD4,
'Source: ' + ISNULL(es.Description, '<none>') OD5,
'Resolution: ' + ISNULL(er.Description,'<none>') OD6,
--' ' OD7,
--' ' OD8,
'      ' NextActivity,
e.EventID,
et.[Description] as EventType,
0 SubscriberID,
0 ActivityID,
0 PhysReviewID,
0 ReferralID,
e.CMSID,
u.LoginName as AssignedUser, 
e.ModifyTime  as SelectDate,
--101 ErrorNumber,
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
psl.SORGTerminationDate,
pl.PlanID,
pl.[Name] as PlanName,
e.EndDate as EvenEndDate,
ss.CodeStatus as StatusCode,
e.ProviderID,
e.PatientID as EventPatientID,
e.FacilityID,
e.DRGCode,
e.Resolution as EventResolution,
e.EventTypeID,
e.EventSourceID,
et.HedisRptType,
e.StartDate as EventStartDate,
e.LOS_10,
VCRRD.ReqUOFM,
VCRRD.ReqAmount,
VCRRD.ReqUnitCost,
VCRRD.DecUnitCost,
VCRRD.DecisionType,
VCRRD.DecisionTypeCode,
VCRRD.DecAmount,
VCRRD.DecUOFM,
e2.EventID as e2EventID,
e.EventID as e1EventID,
e2.StartDate as e2StartDate,
e.StartDate as e1StartDate


FROM Event e
INNER JOIN SystemStatus ss ON e.StatusID = ss.StatusID 
LEFT JOIN Problem pr ON e.PrimaryProblemID = pr.ProblemID
LEFT JOIN Patient pat ON e.PatientId = pat.PatientId
LEFT JOIN Event e2 ON e2.PatientID = pat.PatientID
INNER JOIN EventSource es ON e.EventSourceID = es.EventSourceID
INNER JOIN EventResolution er ON e.Resolution = er.EventResolutionID
INNER JOIN EventType et ON e.EventTypeID = et.EventTypeID
LEFT JOIN PlanSorgLog psl ON e.PlanSorgLogID = psl.PlanSorgLogID
LEFT JOIN [Plan] pl ON psl.PlanID = pl.PlanID
LEFT JOIN AAUser u ON e.AssignedUserID = u.UserID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON e.PatientSubscriberLogID = VPSL.PatientSubscriberLogID
LEFT JOIN Report_CRRequestandDecision  VCRRD ON E.EventID = VCRRD.CRRequestDecisionEventID









GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

