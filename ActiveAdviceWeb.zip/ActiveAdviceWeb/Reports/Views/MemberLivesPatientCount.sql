SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[MemberLivesPatientCount]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[MemberLivesPatientCount]
GO

CREATE VIEW dbo.MemberLivesPatientCount
AS
SELECT MLI.morgid, MLI.orgid, MLI.sorgid, MLI.SorgLives, MLI.OrgLives, MLI.MorgLives/*, MorgCount.MorgPatientCount, OrgCount.orgPatientCount, SorgCount.SorgPatientCount*/ FROM Report_MemberLivesInfo MLI
LEFT JOIN (SELECT MorgF.MorgID, SUM(MorgF.MorgPatientCount) AS MorgPatientCount FROM (SELECT DISTINCT MorgID, MorgPatientCount FROM Report_MemberLivesInfo) MorgF GROUP BY MorgF.MorgID) MorgCount ON MLI.MorgID = MorgCount.MorgID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

