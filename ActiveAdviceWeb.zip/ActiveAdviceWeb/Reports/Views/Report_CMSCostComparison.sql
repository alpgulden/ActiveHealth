SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_CMSCostComparison]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_CMSCostComparison]
GO

CREATE          VIEW dbo.Report_CMSCostComparison
AS

SELECT  
'D' as SubRecType, --Decisions
ISNULL(E.EndDate,E.ModifyTime) as SelectDate,  
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
P.PlanID,
P.[Name] as PlanName,
VPSL.PatientLastName,
VPSL.PatientFirstName,
VPSL.PatientFullName,
VPSL.PatientId,
VPSL.PatientGender,
VPSL.PatientDOB,
VPSL.PatientAlternateId,
E.EventID,
E.PrimaryProblemID,
E.StartDate as EventStartDate,
E.EndDate as EventEndDate,
SS.Code as EventStatus,
ET.[Description] as EventType,
ProblemDescription = 
CASE 
WHEN pr.ProblemDescription IS NULL THEN pd.[Description] 
ELSE pr.ProblemDescription 
END,
VCRD.ClinicalReviewRequestID,
VCRD.ReqAmount as RevReqAmount,
VCRD.ReqFrequencyAmount,
VCRD.ReqDurationAmount,
CAST(VCRD.ReqUnitCost AS int) as ReqUnitCost,
VCRD.ReqUOFM,
VCRD.ReqDescription,
VCRD.ReqFrequencyUofM,
VCRD.ReqDurationUofM,
VCRD.ClinicalReviewDecisionID,
VCRD.DecAmount,
ISNULL(CAST(VCRD.DecUnitCost AS int),-99) AS DecUnitCost,
VCRD.DecDiscount,
VCRD.DecisionStartDate,
VCRD.DecisionEndDate,
VCRD.DecFrequencyAmount,
VCRD.DecDurationAmount,
VCRD.DecisionActualAmount,
VCRD.DecisionActualEndDate,
VCRD.DecComment,
VCRD.DecisionReason,
VCRD.DecDescription,
VCRD.DecUOFM,
VCRD.DecisionType,
VCRD.DecFrequencyUofM,
VCRD.DecDurationUofM,
0 AS ActEventID,
'' as ServiceTypeDescription,
0 as ActivityID,
0 as ActivityAmount,
'' as BaseUofM,
'' as ConversionUofM,
0 as BaseAmount,
0 as ManagementServiceRate,
0 as BaseConvMult,
0 as BaseConvDiv,
'' as IsBillable,
0 as ExtendedAmount,
e.CMSID

FROM Event e 
LEFT JOIN Problem pr ON e.PrimaryProblemID = pr.ProblemID 
LEFT JOIN ProblemDescription PD ON PR.ProblemDescriptionID = PD.CodeID
LEFT JOIN dbo.Report_CRRequestandDecision VCRD ON E.EventId = VCRD.CRRequestDecisionEventID
LEFT JOIN EventType ET ON E.EventTypeID = ET.EventTypeID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON E.PatientSubscriberLogID = VPSL.PatientSubscriberLogID
LEFT JOIN PlanSorgLog PSL ON e.PlanSorgLogId = PSL.PlanSorgLogID
LEFT JOIN [Plan] P ON PSL.PlanID = P.PlanID
INNER JOIN SystemStatus SS ON E.StatusID = SS.StatusID and SS.CodeStatus IN ('OPEN','CLOS')
WHERE VCRD.ReqUnitCost>0

UNION ALL

SELECT  
'A' as SubRecType, --Activities
a.CompletionDate as SelectDate,
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
p.PlanId,
p.[Name] as PlanName,
VPSL.PatientLastName,
VPSL.PatientFirstName,
VPSL.PatientFullName,
VPSL.PatientId,
VPSL.PatientGender,
VPSL.PatientDOB,
VPSL.PatientAlternateId,
0 as EventID,
0 PrimaryProblemID,
NULL as EventStartDate,
NULL as EventEndDate,
'' AS EventStatus,
'' AS EventType,
ProblemDescription = 
CASE 
WHEN pr.ProblemDescription IS NULL THEN pd.[Description] 
ELSE pr.ProblemDescription 
END,
0 as ClinicalReviewRequestID,
0 AS ReqAmount,
0 AS ReqFrequencyAmount,
0 AS ReqDurationAmount,
0 AS ReqUnitCost,
'' AS ReqUOFM,
'' AS ReqDescription,
'' AS ReqFrequencyUofM,
'' AS ReqDurationUofM,
0 as ClinicalReviewDecisionID,
0 AS DecAmount ,
0 AS DecUnitCost,
0 AS DecDiscount,
NULL AS DecisionStartDate,
NULL AS DecisionEndDate,
0 AS DecFrequencyAmount,
0 AS DecDurationAmount,
0 AS DecisionActualAmount,
NULL AS DecisionActualEndDate,
'' AS DecComment,
'' AS DecisionReason,
'' AS DecDescription,
'' AS DecUOFM,
'' AS DecisionType,
'' AS DecFrequencyUofM,
'' AS DecDurationUofM,
a.EventID as ActEventID,
mst.[Description] as ServiceTypeDescription,
a.ActivityID,
a.ActivityAmount,
bum.Code as BaseUofM,
cum.Code as ConversionUofM,
a.BaseAmount,
a.ManagementServiceRate,
a.BaseConvMult,
a.BaseConvDiv,
a.IsBillable,
a.ExtendedAmount,
cms.CMSID

FROM Activity a
LEFT JOIN CMS ON cms.CMSID = a.CMSID
LEFT JOIN Problem pr ON a.ProblemID = pr.ProblemID
LEFT JOIN ProblemDescription PD ON PR.ProblemDescriptionID = PD.CodeID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON pr.PatientSubscriberLogID = VPSL.PatientSubscriberLogId
LEFT JOIN ManagementServiceType mst ON a.ManagementServiceTypeId = mst.ManagementServiceTypeId
LEFT JOIN BaseUnitofMeasure bum ON a.BaseUOMId = bum.BaseUnitOfMeasureId 
LEFT JOIN ConversionUnitofMeasure cum ON a.ConversionUOMId = cum.ConversionUnitOfMeasureId
LEFT JOIN [Plan] P ON a.PlanID = P.PlanID
WHERE a.ManagementServiceRate>0 AND
a.ActivityAmount>0 AND
a.ExtendedAmount>0 AND 
a.IsBillable=1




/*
HCC_RPT_137_V
CMS Cost Comparison

SELECT
'D' as SUB_REC_TYPE, -- decisions
--a.EVENT_END_DATE SELECT_DATE,
decode(a.EVENT_END_DATE,null,a.MOD_DATE,a.EVENT_END_DATE) SELECT_DATE,
c.MORG_ID,
c.MORG_NAME,
g.ORG_ID,
g.ORG_NAME,
f.SORG_ID,
f.SORG_NAME,
u.PLAN_ID,
u.PLAN_NAME,
e.PT_LNAME,
e.PT_FNAME,
e.PATIENT_ID,
e.PT_SSN,
e.PT_SEX,
e.PT_DOB,
a.EVENT_ID,
a.PRIMARY_PROBLEM_ID,
to_CHAR(a.EVENT_START_DATE,'mm/dd/yyyy') AS EVENT_START_DATE,
to_CHAR(a.EVENT_END_DATE,'mm/dd/yyyy') AS EVENT_END_DATE,
A.EVENT_STATUS,
h.CODE_DESC AS EVENTTYPE,
d.PROB_DESC,
i.REV_REQUEST_ID,
i.AMOUNT AS REVREQAMOUNT,
i.FREQUENCY_AMOUNT AS REQFREQAMT,
i.DURATION_AMOUNT AS REQDURAMT,
i.UNIT_COST AS REQUNITCOST,
j.CODE_DESC AS REQUOFM,
k.CODE_DESC AS REQDESC,
l.CODE_DESC AS REQFREQUOFM,
m.CODE_DESC AS REQDURUOFM,
n.REV_DECISION_ID,
n.AMOUNT AS DESCAMOUNT,
nvl(N.UNIT_COST,-99) AS DECUNITCOST,
n.DISCOUNT,
to_CHAR(n.START_DATE,'mm/dd/yyyy') AS DESCSTARTDATE,
to_CHAR(n.END_DATE,'mm/dd/yyyy') AS DESCENDDATE,
n.FREQUENCY_AMOUNT,
n.DURATION_AMOUNT,
n.ACTUAL_AMOUNT,
to_CHAR(n.ACTUAL_END_DATE,'mm/dd/yyyy') AS ACTUAL_END_DATE,
n.DECISION_COMMENT,
o.CODE_DESC AS DESCREASON,
q.CODE_DESC AS DECDESC,
r.CODE_DESC AS DECUOFM,
S.CODE_DESC AS DECTYPE,
l.CODE_DESC AS DESCFREQUOFM,
m.CODE_DESC AS DESCDURUOFM,
0 AS ACTEVENTID,
'' as SERVICETYPE,
0 as ACTIVITY_AMT,
'' as BASE_UOFM,
'' as CONV_UOFM,
0 as BASE_AMT,
0 as MGT_SVC_RATE,
0 as BASE_CONV_MULT,
0 as BASE_CONV_DIV,
'' as BILLABLE,
0 as EXTENDED_AMT,
a.CMS_ID
FROM
HCC_PPER_PROBLEM d,
HCC_PPER_EVENT a,
HCC_CLINIC_REV_REQUEST  i,
HCC_CLINIC_REV_DECISION  n,
HCC_PPER_PAT_SUB_LOG b,
HCC_PPER_PATIENT  e,
HCC_PPER_EVENT_TYPE  h,
HCC_ORGN_MORG  c,
HCC_ORGN_SORG  f ,
HCC_ORGN_ORG  g ,
HCC_CLINIC_REV_DESCRIPTION r,
HCC_CLINIC_REV_UNITS  j,
HCC_CLINIC_REV_DESCRIPTION k,
HCC_CLINIC_REV_FREQ_UNITS  l,
HCC_CLINIC_REV_DURATION_UNITS  m,
HCC_CLINIC_REV_DECISION_REASON o,
HCC_CLINIC_REV_DECISION_TYPE  q,
HCC_CLINIC_REV_UNITS S,
HCC_PLAN_SORG_PLAN_LOG t,
HCC_PLAN_PLAN u,
HCC_SYST_STATUS z
WHERE
A.SUB_PAT_LOG_ID = b.PAT_SUB_LOG_ID AND
b.SUB_MORG_ID = c.MORG_ID  AND
b.SUB_MORG_ID = g.MORG_ID  AND
b.SUB_ORG_ID = g.ORG_ID  AND
b.SUB_SORG_ID = f.SORG_ID  AND
b.SUB_ORG_ID = f.ORG_ID  AND
b.SUB_MORG_ID = f.MORG_ID  AND
i.REV_REQUEST_ID = n.REV_REQUEST_ID AND
a.PRIMARY_PROBLEM_ID = d.PROBLEM_ID  AND
a.PATIENT_ID = e.PATIENT_ID AND
a.EVENT_ID = i.EVENT_ID AND
a.EVENT_TYPE = h.CODE_ID(+)  AND
i.UOFM = j.CODE_ID(+)  AND
i.DESCRIPTION = k.CODE_ID(+)  AND
i.FREQUENCY_UOFM = l.CODE_ID(+)  AND
i.DURATION_UOFM = m.CODE_ID(+)  AND
n.REASON = o.CODE_ID(+)  AND
n.DECISION_TYPE = q.CODE_ID(+)  AND
N.DESCRIPTION = r.CODE_ID(+) AND
N.UOFM = S.CODE_ID(+)
and a.PLAN_SORG_LOG_ID=t.SORG_PLAN_LOG_ID(+)
and t.PLAN_ID=u.PLAN_ID(+)
and i.UNIT_COST>0
and a.EVENT_STATUS = z.CODE_ID
and z.CODE_STATUS in ('OPEN','CLOS')
UNION ALL
SELECT distinct + ordered 
'A' as SUB_REC_TYPE,  --activities
p1.COMP_DATE SELECT_DATE,
c1.MORG_ID,
c1.MORG_NAME,
g1.ORG_ID,
g1.ORG_NAME,
f1.SORG_ID,
f1.SORG_NAME,
v1.PLAN_ID,
v1.PLAN_NAME,
e1.PT_LNAME,
e1.PT_FNAME,
e1.PATIENT_ID,
e1.PT_SSN,
e1.PT_SEX,
e1.PT_DOB,
999999 as EVENT_ID,
d1.PROBLEM_ID AS PRIMARY_PROBLEM_ID,
NULL AS EVENT_START_DATE,
NULL AS EVENT_END_DATE,
'' AS EVENT_STATUS,
'' AS EVENTTYPE,
d1.PROB_DESC,
0 as REV_REQUEST_ID,
0 AS REVREQAMOUNT,
0 AS REQFREQAMT,
0 AS REQDURAMT,
0 AS REQUNITCOST,
'' AS REQUOFM,
'' AS REQDESC,
'' AS REQFREQUOFM,
'' AS REQDURUOFM,
0 as REV_DECISION_ID,
0 AS DESCAMOUNT,
0 AS DECUNITCOST,
0 AS DISCOUNT,
NULL AS DESCSTARTDATE,
NULL AS DESCENDDATE,
0 AS FREQUENCY_AMOUNT,
0 AS DURATION_AMOUNT,
0 AS ACTUAL_AMOUNT,
NULL AS ACTUAL_END_DATE,
'' AS DECISION_COMMENT,
'' AS DESCREASON,
'' AS DECDESC,
'' AS DECUOFM,
'' AS DECTYPE,
'' AS DESCFREQUOFM,
'' AS DESCDURUOFM,
p1.EVENT_ID AS ACTEVENTID,
T1.CODE_DESC AS SERVICETYPE,
p1.ACTIVITY_AMT,
p1.BASE_UOFM,
p1.CONV_UOFM,
p1.BASE_AMT,
p1.MGT_SVC_RATE,
p1.BASE_CONV_MULT,
p1.BASE_CONV_DIV,
p1.BILLABLE,
p1.EXTENDED_AMT,
a.CMS_ID
FROM
HCC_PPER_CMS_SUMMARY a,
HCC_PPER_PROBLEM d1,
HCC_ORGN_MORG  c1,
HCC_ORGN_SORG  f1 ,
HCC_ORGN_ORG  g1 ,
HCC_ACTV_ACTIVITY p1,
HCC_PPER_PAT_SUB_LOG b1,
HCC_PPER_PATIENT  e1,
HCC_PLAN_MGT_SVC_TYPE T1,
HCC_PLAN_SORG_PLAN_LOG u1,
HCC_PLAN_PLAN v1
WHERE
a.CMS_ID = p1.CMS_ID AND
d1.PROBLEM_ID = p1.PROBLEM_ID AND
d1.PATIENT_ID = e1.PATIENT_ID AND
e1.PATIENT_ID = p1.PATIENT_ID AND
d1.SUB_PAT_LOG_ID = b1.PAT_SUB_LOG_ID AND
b1.SUB_MORG_ID = c1.MORG_ID (+) AND
b1.SUB_MORG_ID = g1.MORG_ID (+) AND
b1.SUB_ORG_ID = g1.ORG_ID (+) AND
b1.SUB_SORG_ID = f1.SORG_ID (+) AND
b1.SUB_ORG_ID = f1.ORG_ID (+) AND
b1.SUB_MORG_ID = f1.MORG_ID (+) AND
P1.MGT_SVC_TYPE = T1.CODE_ID(+)
and p1.MGT_SVC_RATE>0
and p1.ACTIVITY_AMT>0
and p1.EXTENDED_AMT>0
and p1.BILLABLE='Y'
and d1.PLAN_SORG_LOG_ID=u1.SORG_PLAN_LOG_ID(+)
and u1.PLAN_ID=v1.PLAN_ID
*/
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

