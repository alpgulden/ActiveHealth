SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_ClosedMaternichek]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_ClosedMaternichek]
GO

CREATE                 VIEW dbo.Report_ClosedMaternichek
AS
SELECT DISTINCT
--View # used in the current app: HCC_RPT_152_V

cms.CMSID,
cms.CreateTime as SelectDate,
cms.CaseEndDate as CMSEndDate,
cms.CaseStartDate as CMSStartDate,
cms.AssignedUser,
cms.AssignedTeam,
cms.ProblemID,
cms.ProblemDescription,
cms.Source,
cms.Acuity,
cms.Intensity,
cms.Phase,
cms.Category,
ss.Code AS CMSStatus,
cms.CMSTypeCode,
cms.RiskFactor,
cms.Risk,
rpsl.SorgID,
rpsl.SorgName,
rpsl.OrgID,
rpsl.OrgName,
rpsl.MorgID,
rpsl.MorgName,
p.PlanId, p.[Name] as PlanName,
RPSL.PatientFullName as PatientName,  
rpsl.PatientDOB, 
rpsl.PatientId, 
rpsl.PatientSSN,
rpsl.SubscriberSSN,
rpsl.PatientAlternateId, 
RPSL.SubscriberFullName as SubscriberName,
cms.DetailType as Type,
m.EDCdate 

FROM Report_CMS AS cms
INNER JOIN SystemStatus ss ON cms.StatusID = ss.StatusID 
LEFT JOIN Report_PatientSubscriberLog rpsl ON cms. PatientSubscriberLogID = rpsl.PatientSubscriberLogId
LEFT JOIN [Plan] p ON rpsl.PlanId = p.PlanID
LEFT JOIN Maternichek m ON cms.CMSID = m.CMSID
WHERE ss.CodeStatus = 'OPEN'
and (cms.CMSTypeCode ='MC'
OR (cms.CMSTypeCode = 'CM'
AND cms.CreateTime >= '01/01/03'
AND cms.CaseType = 'MATE'))
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

