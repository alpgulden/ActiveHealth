SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GeneralEdit]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_GeneralEdit]
GO







CREATE       VIEW dbo.Report_GeneralEdit
AS

--E1---

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open Event with no future Activities ' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
100 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode = 'OPEN' AND 
NOT EXISTS (SELECT a.ActivityID
		FROM Activity a 
		INNER JOIN ActivityCompletion ac ON a.ActivityCompletionID = ac.ActivityCompletionID AND ac.CodeStatus = 'OPEN'
		INNER JOIN Patient p ON a.PatientID = p.PatientID)
AND EXISTS (SELECT  OpenEventNoFutureActivities 
	    FROM dbo.SystemReportDefaults
	    WHERE OpenEventNoFutureActivities = 1)
		

UNION ALL

--E2---

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open Event with End Date ' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
101 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE EvenEndDate IS NOT NULL AND StatusCode = 'OPEN'
AND EXISTS (SELECT  OpenEventWithEndDate
	    FROM dbo.SystemReportDefaults
	    WHERE OpenEventWithEndDate = 1)
UNION ALL

--E3--


SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
Message = 
	CASE
	WHEN CMSID IS NULL THEN 'Closed Event with no Provider' 
	ELSE  'Closed CMS Event with no Provider'
	END, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
101 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND ProviderID IS NULL
AND EXISTS (SELECT  CMS_EventsWithNoProvider
	    FROM dbo.SystemReportDefaults
	    WHERE CMS_EventsWithNoProvider = 1)
UNION ALL

--E5--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
Message = 
	CASE 
	WHEN CMSID IS NULL THEN 'Closed Event with no facility'
	ELSE 'Closed CMS Event with no facility'
	END, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
101 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND FacilityID IS NULL
AND EXISTS (SELECT CMS_EventsWithNoFacilities 
	    FROM dbo.SystemReportDefaults
	    WHERE CMS_EventsWithNoFacilities = 1)
UNION ALL

--E7--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with no End Date' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
106 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND EvenEndDate IS NULL
AND EXISTS (SELECT  ClosedEventNoEndDate
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventNoEndDate = 1)


UNION ALL

--E8--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with no Diagnosis' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
107 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND NOT EXISTS (SELECT erd.EventDiagnosisID
		FROM EventReferralDiagnose erd 
		WHERE erd.EventID = EventID)
AND EXISTS (SELECT ClosedEventsWithNoDx 
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventsWithNoDx = 1)

UNION ALL

--E9--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event with no DRG' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
108 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND DRGCode IS NULL AND HedisRptType = 'IP'
AND EXISTS (SELECT  ClosedIPEventsNoDRG
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventsNoDRG = 1)

UNION ALL

--E10--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event where DRG is 468, 469 or 470' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'DRG Code: ' + CAST(DRGCode as varchar) as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
109 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND DRGCode in (468,469,470) AND HedisRptType = 'IP'
AND EXISTS (SELECT  ClosedIPEventsDRG468_469_470
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventsDRG468_469_470 = 1)

UNION ALL

--E11--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event and DX/PX without an associated LOS Message' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'DRG Code: ' + CAST(DRGCode as varchar) as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
110 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND HedisRptType = 'IP' AND LOS_10 IS NULL 
AND EXISTS (SELECT  ClosedIPEventsNoLOS
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventsNoLOS = 1)

UNION ALL

--E12--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with no Resolution' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
111 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND EventResolution IS NULL
AND EXISTS (SELECT  ClosedEventsNoResolution
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventsNoResolution = 1)
UNION ALL

--E13--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with no Type' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
112 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND EventTypeID IS NULL
AND EXISTS (SELECT  ClosedEventNoType
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventNoType = 1)

UNION ALL

--E14--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with no Source' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
113 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND EventSourceID IS NULL
AND EXISTS (SELECT  ClosedEventsNoSource
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventsNoSource = 1)

UNION ALL

--E15--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event with Start Date = End Date' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
114 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND HedisRptType = 'IP' 
AND EventStartDate = EvenEndDate
AND EXISTS (SELECT  ClosedIPEventStartEqualsEnd
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventStartEqualsEnd = 1)

UNION ALL

--E16--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event with no Review' as Message , 
OD1,
OD2,
OD3,OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
115 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND HedisRptType = 'IP' 
AND NOT EXISTS (SELECT crr.ClinicalReviewRequestID
		FROM ClinicalReviewRequest crr
		WHERE EventID = crr.EventID)
AND EXISTS (SELECT  ClosedIPEventsNoReview
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventsNoReview = 1)
UNION ALL

--E17--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with Review Request but no Review Decision' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'Request Amount: '+ CAST(ReqAmount as varchar) as OD7, 
'Request UOfM: '+ ReqUOFM  as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
116 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode = 'CLOS'  
AND NOT EXISTS (SELECT crd.ClinicalReviewDecisionID
		FROM ClinicalReviewDecision crd 
		INNER JOIN ClinicalReviewRequest crr ON crd.ClinicalReviewRequestID = crr.ClinicalReviewRequestID) 
AND EXISTS (SELECT  ClosedEventWithReviewReqNoRevDec
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventWithReviewReqNoRevDec = 1)

UNION ALL

--E18--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event with Actual LOS greater than Approved + Denied LOS' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'Actual LOS: '+ CAST(dbo.GetLOS(EventStartDate,ISNULL(EvenEndDate,GetDate())) as varchar) as OD7, 
'Approved+Denied LOS: '+ CAST (dbo.GetDecDaysGeneralEditReport(EventID) as varchar) as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
117 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND HedisRptType = 'IP' AND
dbo.GetLOS(EventStartDate,ISNULL(EvenEndDate,GetDate())) > 
dbo.GetDecDaysGeneralEditReport (EventID)
AND EXISTS (SELECT  ClosedIPEventActualLOStoobig
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventActualLOStoobig = 1)

UNION ALL

--E19--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with Requested Amount less than Approved + Denied Amount' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
118 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
-- !!!!!!!!AND ADD CHECK AMOUNT FUNCTIONS, CREATE FIRST
AND EXISTS (SELECT  ClosedEventRequestedAmounttoobig
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventRequestedAmounttoobig = 1)
UNION ALL

--E20--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with no Start Date' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
119 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND EventStartDate IS NULL
AND EXISTS (SELECT  EventNoStartDate
	    FROM dbo.SystemReportDefaults
	    WHERE EventNoStartDate = 1)

UNION ALL

--E21--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with Start Date on or after Sub Organization"s Termination Date' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'Sorg Name: ' +SorgName as OD7,
'Sorg Term Date: ' + CAST(SORGTerminationDate as varchar) as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
120 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND EventStartDate >= SORGTerminationDate
AND EXISTS (SELECT  EventStartDateAfterSORGTermDate
	    FROM dbo.SystemReportDefaults
	    WHERE  EventStartDateAfterSORGTermDate = 1)

UNION ALL

--E22--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Multiple Events for Patient with the same Start Date' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
121 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName


FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND EventID<>e2EventID 
AND e1StartDate = e2StartDate
AND EXISTS (SELECT  DuplicateStartDateEvents
	    FROM dbo.SystemReportDefaults
	    WHERE  DuplicateStartDateEvents = 1)

UNION ALL

--E23--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with Review Request Amount = 0' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
122 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') AND ReqAmount = 0
AND EXISTS (SELECT  EventRequestedAmount0
	    FROM dbo.SystemReportDefaults
	    WHERE  EventRequestedAmount0 = 1)

UNION ALL

--E24--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Event Start date before Patient DOB' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
123 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND EventStartDate < PatientDOB
AND EXISTS (SELECT  EventStartDateBeforePatientDOB
	    FROM dbo.SystemReportDefaults
	    WHERE EventStartDateBeforePatientDOB  = 1)

UNION ALL

--E25--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with blank Review Request Unit Cost and non blank Review Decision Unit Cost' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
124 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND ReqUnitCost IS NULL 
AND ISNULL(DecUnitCost,0) > 0
AND EXISTS (SELECT  EventBlankReviewRequestUnitCost
	    FROM dbo.SystemReportDefaults
	    WHERE  EventBlankReviewRequestUnitCost = 1)
UNION ALL

--E26--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with Review Decision of "Deny" or "Refer to Physician Reviewer"' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'Decision Type: '+ DecisionType  as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
125 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND DecisionTypeCode in ('DENY','RFPR')


UNION ALL

--E27--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with Review Decision Amount = 0 or blank' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
126 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND ISNULL(DecAmount,0) = 0
AND EXISTS (SELECT  EventReviewDecisionAmount0
	    FROM dbo.SystemReportDefaults
	    WHERE  EventReviewDecisionAmount0 = 1)

UNION ALL

--REFERRALS---
--R1--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Referral with no Referred To Information' as Message,
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
OD7,
OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysicianReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
201 as ErrorNumber,
MorgID,
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditReferral
WHERE StatusCode in ('OPEN','CLOS') AND 
ISNULL(ReferredToID,0) = 0
AND EXISTS (SELECT  ReferralWithNoReferTo
	    FROM dbo.SystemReportDefaults
	    WHERE  ReferralWithNoReferTo = 1)

UNION ALL

--R2--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Referral with no PCP Information' as Message,
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
OD7,
OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysicianReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
202 as ErrorNumber,
MorgID,
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditReferral
WHERE StatusCode in ('OPEN','CLOS') AND 
ISNULL(PCPID,0) = 0
AND EXISTS (SELECT ReferralWithNoPCP 
	    FROM dbo.SystemReportDefaults
	    WHERE  ReferralWithNoPCP = 1)
UNION ALL

--R3--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Referral with no Referred From Information' as Message,
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
OD7,
OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysicianReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
203 as ErrorNumber,
MorgID,
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditReferral
WHERE StatusCode in ('OPEN','CLOS') AND 
ISNULL(ReferredFromProviderID,0) = 0
AND EXISTS (SELECT ReferralWithNoReferredFromInfo 
	    FROM dbo.SystemReportDefaults
	    WHERE  ReferralWithNoReferredFromInfo = 1)
UNION ALL

--R4--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Referral with no Number of Units' as Message,
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
OD7,
OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysicianReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
204 as ErrorNumber,
MorgID,
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditReferral
WHERE StatusCode in ('OPEN','CLOS') AND 
ISNULL(UnitQuantity,0) = 0 AND 
UnitUnlimited = 0
AND EXISTS (SELECT  ReferralsWithNoNumberofUnits
	    FROM dbo.SystemReportDefaults
	    WHERE  ReferralsWithNoNumberofUnits = 1)
UNION ALL

--P1

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Physician Review with No Decision' as Message,
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
OD7,
OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysicianReviewID,
ReferralID,
CMSID,
AssignedToUser,
SelectDate,
160 ErrorNumber,
MorgID,
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditPhysRequest
WHERE EventStatus in ('OPEN','CLOS') AND PhysicianReviewStatus = 'CLOS'
AND ClinicalReviewDecisionID IS NULL
AND EXISTS (SELECT  ClosedPhysicianReviewNoDecision
	    FROM dbo.SystemReportDefaults
	    WHERE  ClosedPhysicianReviewNoDecision = 1)
/*
UNION ALL

--P2--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Physician Review with Minutes Spent=0 or Blank' as Message,
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
OD7,
OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysicianReviewID,
ReferralID,
CMSID,
AssignedToUser,
SelectDate,
160 ErrorNumber,
MorgID,
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditPhysRequest
WHERE EventStatus in ('OPEN','CLOS') AND PhysicianReviewStatus = 'CLOS'
AND ClinicalReviewDecisionID IS NULL

*/





GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

