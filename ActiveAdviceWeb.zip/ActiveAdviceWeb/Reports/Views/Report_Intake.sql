SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_Intake]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_Intake]
GO

CREATE            VIEW dbo.Report_Intake
AS
SELECT 
il.IntakeLogID,
il.CreateTime as SelectDate,
il.ServiceDate,
ISNULL((ISNULL(il.CallerLName,'')+' '+ISNULL(il.CallerFName,'')),'No Caller Name') as CallerName,
ISNULL(ict.[Description],'No Caller Type') as CallerType,
ISNULL(ics.[Description],'No Caller Source') as CallerSource,
ISNULL(icr.[Description],'No Caller Reason') as CallerReason, il.PatientId, il.PatientMemberID,
ISNULL((ISNULL(il.PatientLName,'')+' '+ISNULL(il.PatientFName,'')+' '+ISNULL(il.PatientMI,'')),'No Patient Name') as PatientName,
il.SubscriberId,
ISNULL((ISNULL(il.SubscriberLname,'')+' '+ISNULL(SubscriberFName,'')+' '+ISNULL(SubscriberMI,'')),'No  Subscriber Name') as SubscriberName,
sorg.OrganizationID as SorgID,
ISNULL(sorg.[Name],'No Sub Organization') as SorgName,
org.OrganizationID as OrgID,
ISNULL(org.[Name],'No Organization') as OrgName,
morg.OrganizationID as MorgID,
ISNULL(morg.[Name],'No Master Organization') as MorgName,
p.PlanId, 
ISNULL(p.[Name],'No Plan') as PlanName,
ir.[Description] as Resolution,
u.[Name] as UserName,
u.LoginName as UserID,
il.CreateTime,
il.PatientDOB,
il.PatientGender


FROM IntakeLog il 
LEFT JOIN IntakeCallType ict ON il.IntakeCallTypeID = ict.IntakeCallTypeID
LEFT JOIN IntakeCallSource ics ON il.IntakeCallSourceID = ics.IntakeCallSourceID
LEFT JOIN IntakeCallReason icr ON il.IntakeCallReasonID = icr.IntakeCallReasonID
LEFT JOIN Organization sorg ON il.SORGID = sorg.OrganizationID
LEFT JOIN Organization org ON sorg.ParentOrganizationID = org.OrganizationID
LEFT JOIN Organization morg ON org.ParentOrganizationID = morg.OrganizationID
LEFT JOIN [Plan] p ON il.PlanID = p.PlanID
LEFT JOIN IntakeResolution ir ON il.IntakeResolutionID = ir.IntakeResolutionID
LEFT JOIN AAUser u ON il.CreatedBy = u.UserId


/*
HCC_RPT_169_V

select
  a.INTAKE_ID,
  a.CREATE_DATE SELECT_DATE,
  a.SERVICE_DATE,
  decode(a.CALLER_LNAME||a.CALLER_FNAME,null,'zNo Caller Name',' '||a.CALLER_LNAME||decode(a.CALLER_FNAME,null,'',decode(a.CALLER_LNAME,null,'',', ')||a.CALLER_FNAME)) CALLER_NAME,
  decode(c.CODE_DESC,null,'zNo Caller Type',' '||c.CODE_DESC) CALLER_TYPE,
  decode(d.CODE_DESC,null,'zNo Caller Source',' '||d.CODE_DESC) CALLER_SOURCE,
  decode(e.CODE_DESC,null,'zNo Caller Reason',' '||e.CODE_DESC) CALLER_REASON,
  a.PT_SSN,
  a.PT_ID,
  a.PT_MEMBER_ID,
  decode(a.PT_LNAME||a.PT_FNAME,null,'zNo Patient Name',' '||a.PT_LNAME||decode(a.PT_FNAME,null,'',decode(a.PT_LNAME,null,'',', ')||a.PT_FNAME||' '||a.PT_MI)) PT_NAME,
  SUB_SSN,
  SUB_ID,
  a.SUB_LNAME||decode(a.SUB_FNAME,null,'',decode(a.SUB_LNAME,null,'',', ')||a.SUB_FNAME||' '||a.SUB_MI) SUB_NAME,
  f.MORG_ID,
  decode(f.MORG_NAME,null,'zNo Master Organization',' '||f.MORG_NAME) MORG_NAME,
  g.ORG_ID,
  decode(g.ORG_NAME,null,'zNo Organization',' '||g.ORG_NAME) ORG_NAME,
  h.SORG_ID,
  decode(h.SORG_NAME,null,'zNo Sub Organization',' '||h.SORG_NAME) SORG_NAME,
  i.PLAN_ID,
  decode(i.PLAN_NAME,null,'zNo Plan',' '||i.PLAN_NAME) PLAN_NAME,
  j.CODE_DESC RESOLUTION,
  a.CREATE_ID USER_ID,
  k.CODE_DESC USER_NAME,
  a.CREATE_DATE,
  a.PT_DOB,
  a.PT_SEX
from
  HCC_PPER_INTAKE_LOG a,
  HCC_PPER_INTAKE_CALL_TYPE c,
  HCC_PPER_INTAKE_CALL_SOURCE d,
  HCC_PPER_INTAKE_CALL_REASON e,
  HCC_ORGN_MORG f,
  HCC_ORGN_ORG g,
  HCC_ORGN_SORG h,
  HCC_PLAN_PLAN i,
  HCC_PPER_INTAKE_RESOLUTION j,
  HCC_SYST_USER k
where
  a.CALLER_TYPE=c.CODE_ID(+)
  and a.CALLER_SOURCE=d.CODE_ID(+)
  and a.CALLER_REASON=e.CODE_ID(+)
  and a.MORG_ID=f.MORG_ID(+)
  and a.MORG_ID=g.MORG_ID(+)
  and a.ORG_ID=g.ORG_ID(+)
  and a.MORG_ID=h.MORG_ID(+)
  and a.ORG_ID=h.ORG_ID(+)
  and a.SORG_ID=h.SORG_ID(+)
  and a.PLAN_ID=i.PLAN_ID(+)
  and a.RESOLUTION=j.CODE_ID(+)
  and a.CREATE_ID=k.CODE_ID(+)
*/
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

