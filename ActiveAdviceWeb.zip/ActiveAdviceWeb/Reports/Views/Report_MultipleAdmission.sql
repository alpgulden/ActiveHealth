SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_MultipleAdmission]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_MultipleAdmission]
GO

CREATE        VIEW dbo.Report_MultipleAdmission
AS

--HCC_RPT_171_V - MULTIPLE ADMISSION REPORT
SELECT 
E.StartDate AS SelectDate,
VPSL.PatientId,
VPSL.PatientAlternateId,
VPSL.PatientFullName,
VPSL.PatientDOB,
VPSL.PatientSSN,
VPSL.SubscriberSSN,
VPSL.PatientGender,
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
r.RelationshipName as SubscriberPatientRelation,
VPSL.SubscriberFullName,
E.EventID,
E.PrimaryProblemID,
PrimaryProblemDescription = 
CASE 
WHEN pr.ProblemDescription IS NULL THEN pd.[Description] 
ELSE pr.ProblemDescription 
END,
et.[Description] as EventType,
ss.Code as EventStatus,
er.[Description] as EventResolution,
E.StartDate as EventStartDate,
sdap.Code as EventStartDateAP,
E.EndDate as EventEndDate,
edap.Code as EventEndDateAP,
e.[Description] as EventDescription,
e.LOS_50,
e.LOS_95,
erd1.DiagnosisCode AS PrimaryDiagnosisCode,
erd1.DiagnosisType AS PrimaryDiagnosisType,
rtrim(left(dbo.GetDxPxDescription(erd1.DiagnosisType,'D',erd1.DiagnosisCode),60)) as PrimaryDiagnosisDescription,
erd2.DiagnosisCode AS SecondaryDiagnosisCode,
erd2.DiagnosisType AS SecondaryDiagnosisType,
rtrim(left(dbo.GetDxPxDescription(erd2.DiagnosisType,'D',erd2.DiagnosisCode),60)) as SecondaryDiagnosisDescription,
erp.ProcedureCode,
erp.ProcedureType,
erp.LinkedPxType,
erp.LinkedPxCode,
rtrim(left(dbo.GetDxPxDescription(erp.ProcedureType,'P',erp.ProcedureCode),60)) as ProcedureDescription,
erp.ScheduledDate as PxDate,
dbo.GetEventReqDays(e.EventID) as RequestedTotal,
dbo.GetEventDecDays(e.EventID) as ApprovedTotal,
f.FacilityID,
f.[Name] as FacilityName,
fadr.State as FacilityState,
fadr.City as FacilityCity,
FacilityPhone = 
CASE 
WHEN fadr.PhoneNumber1 IS NULL THEN ' '
ELSE fadr.PhoneNumber1+'ext. '+isnull(fadr.PhoneExt1,'') 
END,
facl.FederalTaxID as FacilityTaxID,
isnull(prov.FirstName,'')+' '+isnull(prov.LastName,'') as ProviderName,
l.FederalTaxID AS ProviderTaxID,
padr.State as ProviderState,
padr.City as ProviderCity,
prov.ProviderID,
ProviderPhone = 
CASE
WHEN padr.PhoneNumber1 IS NULL THEN ' ' 
ELSE padr.PhoneNumber1+'ext. '+isnull(padr.PhoneExt1,'')
END,
pl.PlanID,
pl.[Name] as PlanName,
et.HedisRptType

FROM Event e 
LEFT JOIN Patient p ON e.PatientID = p.PatientID
LEFT JOIN DateActualProjected edap ON e.EndDateAP = edap.DateActualProjectedID
LEFT JOIN DateActualProjected sdap ON e.StartDateAP = sdap.DateActualProjectedID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON E.PatientSubscriberLogId = VPSL.PatientSubscriberLogId
LEFT JOIN Relationship r ON VPSL.PatientSubscriberRelationshipID = r.RelationshipID
LEFT JOIN Problem pr ON E.PrimaryProblemID = pr.ProblemID
LEFT JOIN ProblemDescription pd ON pr.ProblemDescriptionID = pd.CodeID
INNER JOIN EventType et ON e.EventTypeID = ET.EventTypeID and et.HedisRPTType = 'IP'
INNER JOIN SystemStatus SS ON E.StatusID = SS.StatusID AND ss.CodeStatus in ('CLOS','OPEN')
LEFT JOIN EventResolution ER ON e.Resolution = ER.EventResolutionID 

LEFT JOIN EventReferralDiagnose erd1 ON e.EventID = erd1.EventID and erd1.[Sequence]='10'
LEFT JOIN EventReferralDiagnose erd2 ON e.EventID = erd2.EventID and erd2.[Sequence] = '20'
LEFT JOIN EventReferralProcedure erp ON E.EventID =erp.EventID and erp.[Sequence] = '10'

LEFT JOIN Facility f ON E.FacilityID = f.FacilityID
LEFT JOIN Location facl ON E.FacilityLocationID = facl.LocationID
LEFT JOIN Address fadr ON facl.ServiceAddressID = fadr.AddressID

LEFT JOIN Provider prov ON E.ProviderID = prov.ProviderID
LEFT JOIN Location l ON E.ProviderLocationID = l.LocationID
LEFT JOIN Address padr ON l.ServiceAddressID = padr.AddressID

LEFT JOIN PlanSorgLog PSL ON E.PlanSorgLogID = PSL.PlanSorgLogID
LEFT JOIN [Plan] pl ON psl.PlanId = pl.PlanId


/*
HCC_RPT_171_V
MULTIPLE ADMISSION REPORT

select
  tab.SESSION_ID,
  R2.EVENT_START_DATE SELECT_DATE,
  a.PATIENT_ID,
  a.ALT_PT_ID,
  a.PT_LNAME||decode(a.PT_FNAME,null,'',', '||a.PT_FNAME||' '||a.PT_MI) PT_NAME,

  a.PT_SSN,
  a.PT_DOB,
  a.PT_SEX,
  b.BRK_SUB_PT_RELATION,
  b.SUB_LNAME||decode(b.SUB_FNAME,null,'',', '||b.SUB_FNAME||' '||b.SUB_MI) SUB_NAME,
  b.SUB_SSN SUB_SSN,
  R2.EVENT_ID EVENT_ID,
  R2.PRIMARY_PROBLEM_ID PRIMARY_PROBLEM_ID,
  c.PROB_DESC PRIMARY_PROBLEM_DESC,
  d.CODE_DESC R2_EVENT_TYPE_DESC,
  e.CODE_DESC EVENT_STATUS,
  f.CODE_DESC EVENT_RESOLUTION,
  R2.EVENT_START_DATE EVENT_START_DATE,
  R2.START_DATE_ACT_PROJ START_DATE_ACT_PROJ,
  R2.EVENT_END_DATE EVENT_END_DATE,
  R2.END_DATE_ACT_PROJ END_DATE_ACT_PROJ,
  R2.EVENT_DESC EVENT_DESCRIPTION,
  R2.LOS_50 LOS_50,
  R2.LOS_95 LOS_95,
  g.DX_TYPE PRIMARY_DIAG_TYPE,
  g.DX_CODE PRIMARY_DIAG_CODE,
  rtrim(rpad(DX_PX_DESCRIPTION(g.DX_TYPE,'D',g.DX_CODE),60)) PRIMARY_DIAG_DESC,
  gg.DX_TYPE SECONDARY_DIAG_TYPE,
  gg.DX_CODE SECONDARY_DIAG_CODE,
  rtrim(rpad(DX_PX_DESCRIPTION(gg.DX_TYPE,'D',gg.DX_CODE),60)) SECONDARY_DIAG_DESC,
  h.PX_TYPE PROCEDURE_CODE,
  h.PX_CODE PROCEDURE_TYPE,
  decode(to_char(h.SCHEDULED_DATE,'MM/DD/YYYY'),'12/30/1899',NULL,to_char(h.SCHEDULED_DATE,'MM/DD/YYYY')) PX_DATE,
  h.LINKED_PX_TYPE LINKED_PROCEDURE_TYPE,
  h.LINKED_PX_CODE LINKED_PROCEDURE_CODE,
  rtrim(rpad(DX_PX_DESCRIPTION(h.PX_TYPE,'P',h.PX_CODE),60)) PROCEDURE_DESC,
  event_req_days(R2.EVENT_ID) REQUESTED_TOTAL,
  event_dec_days(R2.EVENT_ID) APPROVED_TOTAL,
  i.FACILITY_ID FAC_ID,
  i.NAME R2_FAC_NAME,
  j.SERVICE_STATE FAC_STATE,
  j.SERVICE_PHONE FAC_PHONE,
  i.FED_TAX_ID FAC_TAX_ID,
  k.PROVIDER_ID PROVIDER_ID,
  k.LNAME||decode(k.LNAME,NULL,'',', '||k.FNAME) R2_PROV_NAME,
  k.FED_TAX_ID PROV_TAX_ID,
  l.SERVICE_STATE PROV_STATE,
  l.SERVICE_PHONE PROV_PHONE,
  cc.MORG_ID MORG_ID,cc.MORG_NAME MORG_NAME,
  dd.ORG_ID ORG_ID,dd.ORG_NAME ORG_NAME,
  ee.SORG_ID SORG_ID,ee.SORG_NAME SORG_NAME,
  ff.PLAN_ID PLAN_ID,ff.PLAN_NAME PLAN_NAME
from
  HCC_PPER_EVENT R2,
  hcc_rpt_171_events tab,
  HCC_PPER_PATIENT a,
  HCC_PPER_PAT_SUB_LOG b,
  HCC_PPER_PROBLEM c,
  HCC_PPER_EVENT_TYPE d,
  HCC_SYST_STATUS e,
  HCC_PPER_EVENT_RESOLUTION f,
  HCC_PPER_EVENT_REF_DIAGNOSES g,
  HCC_PPER_EVENT_REF_DIAGNOSES gg,
  HCC_PPER_EVENT_REF_PROCEDURES h,
  HCC_PRFA_FACILITY i,
  HCC_PRFA_FAC_LOCATION j,
  HCC_PRFA_PROVIDER k,
  HCC_PRFA_PROV_LOCATION l,
  HCC_PLAN_SORG_PLAN_LOG bb,
  HCC_ORGN_MORG cc,
  HCC_ORGN_ORG dd,
  HCC_ORGN_SORG ee,
  HCC_PLAN_PLAN ff
where
  R2.EVENT_ID=tab.EVENT_ID
  and R2.PATIENT_ID=a.PATIENT_ID(+)
  and R2.SUB_PAT_LOG_ID=b.PAT_SUB_LOG_ID(+)
  and R2.PRIMARY_PROBLEM_ID=c.PROBLEM_ID
  and R2.EVENT_TYPE=d.CODE_ID(+)
  and R2.EVENT_STATUS=e.CODE_ID(+)
  and e.CODE_STATUS in ('OPEN','CLOS')
  and R2.EVENT_RESOLUTION=f.CODE_ID(+)
  and (R2.EVENT_ID=g.EVENT_REFERRAL_ID(+)
       and g.EVENT_REFERRAL_TYPE(+)='E'
       and g.SEQUENCE_ID(+)=1)
  and (R2.EVENT_ID=gg.EVENT_REFERRAL_ID(+)
       and gg.EVENT_REFERRAL_TYPE(+)='E'
       and gg.SEQUENCE_ID(+)=2)
  and (R2.EVENT_ID=h.EVENT_REFERRAL_ID(+)
       and h.EVENT_REFERRAL_TYPE(+)='E'
       and h.SEQUENCE_ID(+)=1)
  and R2.FACILITY_ID=i.FACILITY_ID(+)
  and R2.FAC_LOC_ID=j.LOCATION_ID(+)
  and R2.PROVIDER_ID=k.PROVIDER_ID(+)
  and R2.PROV_LOCATION_ID=l.LOCATION_ID(+)
  and R2.PLAN_SORG_LOG_ID=bb.SORG_PLAN_LOG_ID(+)
  and bb.BRK_MORG_ID=cc.MORG_ID(+)
  and bb.BRK_MORG_ID=dd.MORG_ID(+)
  and bb.BRK_ORG_ID=dd.ORG_ID(+)
  and bb.BRK_MORG_ID=ee.MORG_ID(+)
  and bb.BRK_ORG_ID=ee.ORG_ID(+)
  and bb.BRK_SORG_ID=ee.SORG_ID(+)
  and bb.PLAN_ID=ff.PLAN_ID(+)
*/
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

