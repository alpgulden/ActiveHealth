SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GeneralEditPhysRequest]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_GeneralEditPhysRequest]
GO


CREATE  VIEW dbo.Report_GeneralEditPhysRequest
AS
SELECT 
pr.ClinicalReviewDecisionID,
ess.Code as EventStatus,
prss.Code as PhysicianReviewStatus,
'R' RecType,
pat.PatientID,
VPSL.PatientFullName,
-- Message,
'Review Start Date: '+ CAST (pr.StartDate as varchar) as OD1,
' ' OD2,
' ' OD3,
' ' OD4,
' ' OD5,
' ' OD6,
' ' OD7,
' ' OD8,
' ' NextActivity,
pr.EventID,
' ' EventType,
0 SubscriberID,
0 ActivityID,
pr.PhysicianReviewID,
0 ReferralID,
0 CMSID,
u.LoginName as AssignedToUser,
pr.ModifyTime as SelectDate,
--ErrorNumber,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
VPSL.MorgID,
VPSL.MorgName,
pl.PlanID,
pl.[Name] as PlanName

FROM PhysicianReview pr 
LEFT JOIN Patient pat ON pr.PatientID = pat.PatientID
LEFT JOIN AAUser u ON pr.ModifiedBy = u.UserID
INNER JOIN SystemStatus prss ON pr.StatusID = prss.StatusID
LEFT JOIN Event e ON pr.EventID = e.EventID
INNER JOIN SystemStatus ess ON e.StatusID = ess.StatusID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON e.PatientSubscriberLogID = VPSL.PatientSubscriberLogID
LEFT JOIN [Plan] pl ON VPSL.PlanID = pl.PlanID
WHERE VPSL.PatientSubscriberLogID in (Select Max(VPSL2.PatientSubscriberLogID)
      	FROM dbo.Report_PatientSubscriberLog VPSL2
	INNER JOIN Patient p2 ON VPSL2.PatientId = p2.PatientID)
	



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

