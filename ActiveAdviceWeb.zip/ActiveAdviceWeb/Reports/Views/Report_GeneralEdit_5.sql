SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GeneralEdit_5]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_GeneralEdit_5]
GO



CREATE   VIEW dbo.Report_GeneralEdit_5
AS



--REFERRALS---
--R1--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Referral with no Referred To Information' as Message,
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
OD7,
OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysicianReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
201 as ErrorNumber,
MorgID,
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditReferral
WHERE StatusCode in ('OPEN','CLOS') AND 
ISNULL(ReferredToID,0) = 0
AND EXISTS (SELECT  ReferralWithNoReferTo
	    FROM dbo.SystemReportDefaults
	    WHERE  ReferralWithNoReferTo = 1)

UNION ALL

--R2--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Referral with no PCP Information' as Message,
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
OD7,
OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysicianReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
202 as ErrorNumber,
MorgID,
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditReferral
WHERE StatusCode in ('OPEN','CLOS') AND 
ISNULL(PCPID,0) = 0
AND EXISTS (SELECT ReferralWithNoPCP 
	    FROM dbo.SystemReportDefaults
	    WHERE  ReferralWithNoPCP = 1)
UNION ALL

--R3--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Referral with no Referred From Information' as Message,
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
OD7,
OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysicianReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
203 as ErrorNumber,
MorgID,
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditReferral
WHERE StatusCode in ('OPEN','CLOS') AND 
ISNULL(ReferredFromProviderID,0) = 0
AND EXISTS (SELECT ReferralWithNoReferredFromInfo 
	    FROM dbo.SystemReportDefaults
	    WHERE  ReferralWithNoReferredFromInfo = 1)
UNION ALL

--R4--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Referral with no Number of Units' as Message,
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
OD7,
OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysicianReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
204 as ErrorNumber,
MorgID,
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditReferral
WHERE StatusCode in ('OPEN','CLOS') AND 
ISNULL(UnitQuantity,0) = 0 AND 
UnitUnlimited = 0
AND EXISTS (SELECT  ReferralsWithNoNumberofUnits
	    FROM dbo.SystemReportDefaults
	    WHERE  ReferralsWithNoNumberofUnits = 1)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

