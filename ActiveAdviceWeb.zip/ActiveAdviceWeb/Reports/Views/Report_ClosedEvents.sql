
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
ALTER      VIEW dbo.Report_ClosedEvents
AS
SELECT DISTINCT
--Corresponding view in the current app: HCC_RPT_140_V & HCC_RPT_141_V

Sub_Rec_Type = 
	CASE
	WHEN erp.ProcedureCode iS NULL THEN ' '
	ELSE 'P'
	END,
e.EventID,
ISNULL(e.ModifyTime, e.CreateTime) as EventSelectDate,  
e.StartDate as EventStartDate,
sdap.Code as StartDateActualProjected,
e.EndDate as EventEndDate,
edap.Code as EndDateActualProjected,
e.CreateTime as EventCreateDate,
ss.Code as EventStatus, 
e.LateCallIn as EventLateCallin,
et.[Description] as EventType,
es.[Description] as EventSource,
er.[Description] as EventResolution,
ProblemDescription = 
CASE 
WHEN pr.ProblemDescription IS NULL THEN pd.[Description] 
ELSE pr.ProblemDescription 
END,
VPSL.PatientId,
VPSL.PatientAlternateId,
VPSL.PatientFullName as PatientName,
VPSL.PatientDOB,
VPSL.PatientSSN,
VPSL.SubscriberSSN,
VPSL.PatientGender,
VPSL.SubscriberId,
VPSL.SubscriberFullName AS SubscriberName,
r.RelationshipName as SubscriberPatientRelation,
VPSL.SorgID,
VPSL.SorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.MorgID,
VPSL.MorgName,
VPSL.SorgTermDate,
prov.ProviderID,
isnull(prov.FirstName,'')+' '+isnull(prov.LastName,'') as ProviderName,
padr.State as ProviderState,
ProviderPhone = 
CASE
WHEN padr.PhoneNumber1 IS NULL THEN ' ' 
ELSE padr.PhoneNumber1
END,
l.FederalTaxID AS ProviderTaxID,
pcp.ProviderID as PCPID,
isnull(pcp.FirstName,'')+' '+isnull(pcp.LastName,'') as PCPName,
pcpadr.State as PCPState,
PCPPhone = 
CASE 
WHEN pcpadr.PhoneNumber1 IS NULL THEN ' ' 
ELSE pcpadr.PhoneNumber1
END, 
ploc.FederalTaxID as PCPTaxID,
f.FacilityID,
f.[Name] as FacilityName,
fadr.State as FacilityState,
FacilityPhone = 
CASE 
WHEN fadr.PhoneNumber1 IS NULL THEN ' '
ELSE fadr.PhoneNumber1 
END,
facl.FederalTaxID as FacilityTaxID,
erd1.DiagnosisCode AS DiagnosisCode1,
erd1.DiagnosisType AS DiagnosisType1,
rtrim(left(dbo.GetDxPxDescription(erd1.DiagnosisType,'D',erd1.DiagnosisCode),60)) as Dx1ShortTitle,
erd2.DiagnosisCode AS DiagnosisCode2,
erd2.DiagnosisType AS DiagnosisType2,
rtrim(left(dbo.GetDxPxDescription(erd2.DiagnosisType,'D',erd2.DiagnosisCode),60)) as Dx2ShortTitle,
--
erp.Sequence AS ProcedureSequence,
erp.ProcedureCode,
erp.ProcedureType,
erp.ScheduledDate AS ProcedureDate,
erp.LinkedPxType,
erp.LinkedPxCode,
rtrim(left(dbo.GetDxPxDescription(erp.ProcedureType,'P',erp.ProcedureCode),60)) as PxShortTitle,
NULL as ClinicalReviewRequestID,
NULL as ReqAmount,
' ' as ReqUOFM,
' ' as ReqFrequencyAmount,
' ' as ReqFrequencyUofM,
' ' as ReqDurationAmount,
' ' as ReqDurationUofM,
' ' as ReqDescription,
' ' as ClinicalReviewDecisionID,
' ' as DecAmount,
' ' as DecUOFM,
' ' as DecFrequencyAmount,
' ' as DecFrequencyUofM,
' ' as DecDurationAmount,
' ' as DecDurationUofM,
' ' as DecDescription,
' ' as DecisionType,
' ' as DecisionReason,
' ' as DecisionActualAmount,
NULL as DecisionActualEndDate,
NULL as DecisionStartDate,
NULL as DecisionEndDate

FROM Event AS e
INNER JOIN SystemStatus ss ON e.StatusID = ss.StatusID and ss.CodeStatus = 'CLOS'
LEFT JOIN DateActualProjected sdap ON e.StartDateAP = sdap.DateActualProjectedID
LEFT JOIN DateActualProjected edap ON e.EndDateAP = edap.DateActualProjectedID
LEFT JOIN EventType et ON e.EventTypeID = et.EventTypeID
LEFT JOIN EventSource es ON e.EventSourceID = es.EventSourceID
LEFT JOIN EventResolution er ON e.Resolution = er.EventResolutionID
LEFT JOIN Problem pr ON E.PrimaryProblemID = pr.ProblemID
LEFT JOIN ProblemDescription pd ON pr.ProblemDescriptionID = pd.CodeID
LEFT JOIN ProblemEvent pe ON pr.ProblemID = pe.ProblemID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON E.PatientSubscriberLogID = VPSL.PatientSubscriberLogID
LEFT JOIN Relationship r ON VPSL.PatientSubscriberRelationshipID = r.RelationshipID

LEFT JOIN Provider prov ON E.ProviderID = prov.ProviderID
LEFT JOIN Location l ON E.ProviderLocationID = l.LocationID

LEFT JOIN Address padr ON l.ServiceAddressID = padr.AddressID
LEFT JOIN Provider pcp ON E.PCPID = pcp.ProviderID 
LEFT JOIN Location ploc ON  E.PCPLocationID = ploc.LocationID
LEFT JOIN Address pcpadr ON ploc.ServiceAddressID = pcpadr.AddressID
LEFT JOIN Facility f ON E.FacilityID = f.FacilityID
LEFT JOIN Location facl ON E.FacilityLocationID = facl.LocationID
LEFT JOIN Address fadr ON facl.ServiceAddressID = fadr.AddressID

LEFT JOIN EventReferralDiagnose erd1 ON e.EventID = erd1.EventID and erd1.[Sequence] = 10
LEFT JOIN EventReferralDiagnose erd2 ON e.EventID = erd2.EventID and erd2.[Sequence] = 20
LEFT JOIN EventReferralProcedure erp ON E.EventID =erp.EventID and erp.[Sequence] IN (10,20) 
LEFT JOIN Report_CRRequestandDecision  crrd ON E.EventID =crrd.CRRequestDecisionEventID
WHERE  (erp.ProcedureCode IS NOT NULL OR
(crrd.ClinicalReviewDecisionID is null AND 
erp.ProcedureCode is null))

UNION ALL
 
SELECT DISTINCT
'R' as Sub_Rec_Type,
e.EventID,
ISNULL(e.ModifyTime, e.CreateTime) as EventSelectDate, 
e.StartDate as EventStartDate,
sdap.Code as StartDateActualProjected,
e.EndDate as EventEndDate,
edap.Code as EndDateActualProjected,
e.CreateTime as EventCreateDate,
ss.Code as EventStatus, 
e.LateCallIn as EventLateCallin,
et.[Description] as EventType,
es.[Description] as EventSource,
er.[Description] as EventResolution,
ProblemDescription = 
CASE 
WHEN pr.ProblemDescription IS NULL THEN pd.[Description] 
ELSE pr.ProblemDescription 
END,
VPSL.PatientId,
VPSL.PatientAlternateId,
VPSL.PatientFullName as PatientName,
VPSL.PatientDOB,
VPSL.PatientSSN,
VPSL.SubscriberSSN,
VPSL.PatientGender,
VPSL.SubscriberId,
VPSL.SubscriberFullName AS SubscriberName,
r.RelationshipName as SubscriberPatientRelation,
VPSL.SorgID,
VPSL.SorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.MorgID,
VPSL.MorgName,
VPSL.SorgTermDate,
prov.ProviderID,
isnull(prov.FirstName,'')+' '+isnull(prov.LastName,'') as ProviderName,
padr.State as ProviderState,
ProviderPhone = 
CASE
WHEN padr.PhoneNumber1 IS NULL THEN ' ' 
ELSE padr.PhoneNumber1
END,
l.FederalTaxID AS ProviderTaxID,
pcp.ProviderID as PCPID,
isnull(pcp.FirstName,'')+' '+isnull(pcp.LastName,'') as PCPName,
pcpadr.State as PCPState,
PCPPhone = 
CASE 
WHEN pcpadr.PhoneNumber1 IS NULL THEN ' ' 
ELSE pcpadr.PhoneNumber1
END, 
ploc.FederalTaxID as PCPTaxID,
f.FacilityID,
f.[Name] as FacilityName,
fadr.State as FacilityState,
FacilityPhone = 
CASE 
WHEN fadr.PhoneNumber1 IS NULL THEN ' '
ELSE fadr.PhoneNumber1 
END,
facl.FederalTaxID as FacilityTaxID,
erd1.DiagnosisCode AS DiagnosisCode1,
erd1.DiagnosisType AS DiagnosisType1,
rtrim(left(dbo.GetDxPxDescription(erd1.DiagnosisType,'D',erd1.DiagnosisCode),60)) as Dx1ShortTitle,
erd2.DiagnosisCode AS DiagnosisCode2,
erd2.DiagnosisType AS DiagnosisType2,
rtrim(left(dbo.GetDxPxDescription(erd2.DiagnosisType,'D',erd2.DiagnosisCode),60)) as Dx2ShortTitle,
--
' ' AS ProcedureSequence,
' ' as ProcedureCode,
' ' as ProcedureType,
NULL AS ProcedureDate,
' ' as LinkedPxType,
' ' as LinkedPxCode,
' ' as PxShortTitle,
--
crrd.ClinicalReviewRequestID,
crrd.ReqAmount,
crrd.ReqUOFM,
crrd.ReqFrequencyAmount,
crrd.ReqFrequencyUofM,
crrd.ReqDurationAmount,
crrd.ReqDurationUofM,
crrd.ReqDescription,
crrd.ClinicalReviewDecisionID,
crrd.DecAmount,
crrd.DecUOFM,
crrd.DecFrequencyAmount,
crrd.DecFrequencyUofM,
crrd.DecDurationAmount,
crrd.DecDurationUofM,
crrd.DecDescription,
crrd.DecisionType,
crrd.DecisionReason,
crrd.DecisionActualAmount,
crrd.DecisionActualEndDate,
crrd.DecisionStartDate,
crrd.DecisionEndDate

FROM Event AS e
INNER JOIN SystemStatus ss ON e.StatusID = ss.StatusID and ss.CodeStatus = 'CLOS'
LEFT JOIN DateActualProjected sdap ON e.StartDateAP = sdap.DateActualProjectedID
LEFT JOIN DateActualProjected edap ON e.EndDateAP = edap.DateActualProjectedID
LEFT JOIN EventType et ON e.EventTypeID = et.EventTypeID
LEFT JOIN EventSource es ON e.EventSourceID = es.EventSourceID
LEFT JOIN EventResolution er ON e.Resolution = er.EventResolutionID
LEFT JOIN Problem pr ON E.PrimaryProblemID = pr.ProblemID
LEFT JOIN ProblemDescription pd ON pr.ProblemDescriptionID = pd.CodeID
LEFT JOIN ProblemEvent pe ON pr.ProblemID = pe.ProblemID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON E.PatientSubscriberLogID = VPSL.PatientSubscriberLogID
LEFT JOIN Relationship r ON VPSL.PatientSubscriberRelationshipID = r.RelationshipID

LEFT JOIN Provider prov ON E.ProviderID = prov.ProviderID
LEFT JOIN Location l ON E.ProviderLocationID = l.LocationID
LEFT JOIN Address padr ON l.ServiceAddressID = padr.AddressID
LEFT JOIN Provider pcp ON E.PCPID = pcp.ProviderID 
LEFT JOIN Location ploc ON  E.PCPLocationID = ploc.LocationID
LEFT JOIN Address pcpadr ON ploc.ServiceAddressID = pcpadr.AddressID
LEFT JOIN Facility f ON E.FacilityID = f.FacilityID
LEFT JOIN Location facl ON E.FacilityLocationID = facl.LocationID
LEFT JOIN Address fadr ON facl.ServiceAddressID = fadr.AddressID

LEFT JOIN EventReferralDiagnose erd1 ON e.EventID = erd1.EventID and erd1.[Sequence] = 10
LEFT JOIN EventReferralDiagnose erd2 ON e.EventID = erd2.EventID and erd2.[Sequence] = 20
LEFT JOIN EventReferralProcedure erp ON E.EventID =erp.EventID and erp.[Sequence] IN (10,20)
LEFT JOIN Report_CRRequestandDecision  crrd ON E.EventID =crrd.CRRequestDecisionEventID
WHERE (crrd.ClinicalReviewDecisionID IS NOT NULL)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO