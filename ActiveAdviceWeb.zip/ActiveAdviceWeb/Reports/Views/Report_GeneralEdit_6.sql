SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GeneralEdit_6]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_GeneralEdit_6]
GO

CREATE      VIEW dbo.Report_GeneralEdit_6
AS


--Patient

SELECT DISTINCT
'P' as RecType,
p1.PatientID,
ISNULL(p1.LastName,'')+' , '+ISNULL(p1.FirstName,'')+' '+ISNULL(p1.MiddleInitial,'') as PatientFullName,   
'Multiple Patients with same SSN' Message,
' ' OD1,
'Date of Birth: '+ CAST(p1.DateOfBirth as varchar) as OD2,
' ' OD3,
' ' OD4,
' ' OD5,
' ' OD6,
' ' OD7,
' ' OD8,
' ' NextActivity,
0 EventID,
' ' EventType,
0 SubscriberID,
0 ActivityID,
0 PhysicianReviewID,
0 ReferralID,
0 CMSID,
u.LoginName as AssignedUser,
p1.ModifyTime as SelectDate,
305 as ErrorNumber,
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
VPSL.PlanID,
' ' PlanName

FROM Patient p1
INNER JOIN Patient p2 ON p1.SocialSecurityNumber = p2.SocialSecurityNumber AND p1.patientid<p2.patientid
LEFT JOIN AAUser u ON p1.ModifiedBy = u.UserID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON p1.PatientID = VPSL.PatientID 
WHERE VPSL.PatientSubscriberLogId IN (SELECT MAX(VPSL2.PatientSubscriberLogId)
					FROM dbo.Report_PatientSubscriberLog VPSL2
					GROUP BY PatientID)
AND EXISTS (SELECT  MultiplePatientsSameSSN 
	    FROM dbo.SystemReportDefaults
	    WHERE MultiplePatientsSameSSN = 1)

UNION ALL

--Subscriber 

SELECT DISTINCT
'S' as RecType,
0 as PatientID,
'See Associated Data' as PatientFullName,   
'Multiple Subscribers with same SSN' Message,
'Subscriber ID: '+ CAST(S1.SubscriberID as varchar) as OD1,
'Subscriber Name: '+ ISNULL(S1.LastName,'')+' , '+ISNULL(S1.FirstName,'')+' '+ISNULL(S1.MiddleInitial,'') as OD2,   
' ' OD3,
'Date of Birth: '+ CAST(S1.DateOfBirth as varchar) as OD4,
' ' OD5,
' ' OD6,
' ' OD7,
' ' OD8,
' ' NextActivity,
0 EventID,
' ' EventType,
S1.SubscriberID,
0 ActivityID,
0 PhysicianReviewID,
0 ReferralID,
0 CMSID,
u.LoginName as AssignedUser,
s1.ModifyTime as SelectDate,
307 as ErrorNumber,
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
VPSL.PlanID,
' ' PlanName

FROM Subscriber S1
INNER JOIN Subscriber S2 ON s1.SocialSecurityNumber = s2.SocialSecurityNumber AND s1.Subscriberid<s2.Subscriberid
LEFT JOIN AAUser u ON S1.ModifiedBy = u.UserID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON S1.SubscriberID = VPSL.SubscriberID 
WHERE VPSL.PatientSubscriberLogId IN (SELECT MAX(VPSL2.PatientSubscriberLogId)
					FROM dbo.Report_PatientSubscriberLog VPSL2
					GROUP BY SubscriberID)
AND EXISTS (SELECT  MultipleSubscribersSameSSN 
	    FROM dbo.SystemReportDefaults
	    WHERE MultipleSubscribersSameSSN = 1)

UNION ALL

--Activity 

SELECT DISTINCT
'A' as RecType,
p.patientid as PatientID,
VPSL.PatientFullName,   
'Activity with no Problem, CMS, Event or Referral ID' Message,
'Type: '+ act.[Description] as OD1,
'Due Date: '+ CAST(a.DueDate as varchar) as OD2,   
'Completion Code: '+act.Code as OD3,
' ' OD4,
' ' OD5,
' ' OD6,
' ' OD7,
' ' OD8,
' ' NextActivity,
0 EventID,
' ' EventType,
0 SubscriberID,
a.ActivityID,
0 PhysicianReviewID,
0 ReferralID,
0 CMSID,
u.LoginName as AssignedUser,
a.ModifyTime as SelectDate,
150 as ErrorNumber,
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
VPSL.PlanID,
pl.[Name] as PlanName

FROM Activity a 
INNER JOIN Patient p ON a.PatientId = p.PatientId
INNER JOIN ActivityType act ON a.ActivityTypeID = act.ActivityTypeID
LEFT JOIN ActivityCompletion ac ON a.ActivityCompletionID = ac.ActivityCompletionID and ac.CodeStatus = 'OPEN'
LEFT JOIN AAUser u ON a.ModifiedBy = u.UserID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON P.PatientID = VPSL.PatientID
LEFT JOIN [Plan] pl ON a.PlanID = pl.PlanID
WHERE a.ProblemId IS NULL AND 
a.CMSID IS NULL AND
a.EventID IS NULL AND
a.ReferralID IS NULL AND
VPSL.PatientSubscriberLogId in (Select max(VPSL2.PatientSubscriberLogId)
					FROM dbo.Report_PatientSubscriberLog VPSL2
					WHERE A.PatientID = VPSL2.PatientID
					AND VPSL2.SubscriberCoverageIsPrimary = 1)
AND EXISTS (SELECT ActivitiesWithNoPCER
	    FROM dbo.SystemReportDefaults
	    WHERE ActivitiesWithNoPCER = 1)
UNION ALL

--Physician Review
--P1
SELECT DISTINCT
'R' as RecType,
pat.patientid as PatientID,
VPSL.PatientFullName,   
'Closed Physician Review with No Decision' Message,
'Review Start Date : '+ CAST(prev.StartDate as varchar) as OD1,
'' OD2,   
' ' OD3,
' ' OD4,
' ' OD5,
' ' OD6,
' ' OD7,
' ' OD8,
' ' NextActivity,
prev.EventID,
' ' EventType,
0 SubscriberID,
0 ActivityID,
prev.PhysicianReviewID,
0 ReferralID,
0 CMSID,
u.LoginName as AssignedUser,
prev.ModifyTime as SelectDate,
160 as ErrorNumber,
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
VPSL.PlanID,
' ' PlanName

FROM PhysicianRequest preq
LEFT JOIN PhysicianReview prev ON preq.PhysicianReviewID = prev.PhysicianReviewID
LEFT JOIN Patient pat ON prev.PatientID = pat.PatientID
INNER JOIN SystemStatus ss ON prev.StatusID = ss.StatusID and ss.CodeStatus = 'CLOS'
LEFT JOIN Event e ON prev.EventID = e.EventID
INNER JOIN SystemStatus ess ON e.StatusID = ess.StatusID AND ess.CodeStatus in ('OPEN','CLOS')
LEFT JOIN AAUser u ON prev.ModifiedBy = u.UserID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON e.PatientSubscriberLogID = VPSL.PatientSubscriberLogID
WHERE prev.PhysicianReviewDecisionID IS NULL
AND EXISTS (SELECT ClosedPhysicianReviewNoDecision
	    FROM dbo.SystemReportDefaults
	    WHERE  ClosedPhysicianReviewNoDecision= 1)

UNION ALL

--P2
SELECT DISTINCT
'R' as RecType,
pat.patientid as PatientID,
VPSL.PatientFullName,   
'Closed Physician Review with Minutes Spent 0 or Blank' Message,
'Review Start Date : '+ CAST(prev.StartDate as varchar) as OD1,
'' OD2,   
' ' OD3,
' ' OD4,
' ' OD5,
' ' OD6,
' ' OD7,
' ' OD8,
' ' NextActivity,
prev.EventID,
' ' EventType,
0 SubscriberID,
0 ActivityID,
prev.PhysicianReviewID,
0 ReferralID,
0 CMSID,
u.LoginName as AssignedUser,
prev.ModifyTime as SelectDate,
161 as ErrorNumber,
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
VPSL.PlanID,
' ' PlanName

FROM PhysicianRequest preq
LEFT JOIN PhysicianReview prev ON preq.PhysicianReviewID = prev.PhysicianReviewID
LEFT JOIN Patient pat ON prev.PatientID = pat.PatientID
INNER JOIN SystemStatus ss ON prev.StatusID = ss.StatusID and ss.CodeStatus = 'CLOS'
LEFT JOIN Event e ON prev.EventID = e.EventID
INNER JOIN SystemStatus ess ON e.StatusID = ess.StatusID AND ess.CodeStatus in ('OPEN','CLOS')
LEFT JOIN AAUser u ON prev.ModifiedBy = u.UserID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON e.PatientSubscriberLogID = VPSL.PatientSubscriberLogID
LEFT JOIN PhysicianDecision pdec ON preq.PhysicianRequestID = pdec.PhysicianRequestID AND pdec.MinutesSpent IS NULL OR pdec.MinutesSpent = '0' 
WHERE EXISTS (SELECT ClosedPhysRevMinutes0
	    FROM dbo.SystemReportDefaults
	    WHERE  ClosedPhysRevMinutes0 = 1)


UNION ALL

--P3
SELECT DISTINCT
'R' as RecType,
pat.patientid as PatientID,
VPSL.PatientFullName,   
'Open or Closed Physician Review with No Reason' Message,
'Review Start Date : '+ CAST(prev.StartDate as varchar) as OD1,
'' OD2,   
' ' OD3,
' ' OD4,
' ' OD5,
' ' OD6,
' ' OD7,
' ' OD8,
' ' NextActivity,
prev.EventID,
' ' EventType,
0 SubscriberID,
0 ActivityID,
prev.PhysicianReviewID,
0 ReferralID,
0 CMSID,
u.LoginName as AssignedUser,
prev.ModifyTime as SelectDate,
161 as ErrorNumber,
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
VPSL.PlanID,
' ' PlanName

FROM PhysicianRequest preq
LEFT JOIN PhysicianReview prev ON preq.PhysicianReviewID = prev.PhysicianReviewID
LEFT JOIN Patient pat ON prev.PatientID = pat.PatientID
INNER JOIN SystemStatus ss ON prev.StatusID = ss.StatusID and ss.CodeStatus in ('CLOS','OPEN')
LEFT JOIN Event e ON prev.EventID = e.EventID
INNER JOIN SystemStatus ess ON e.StatusID = ess.StatusID AND ess.CodeStatus in ('OPEN','CLOS')
LEFT JOIN AAUser u ON prev.ModifiedBy = u.UserID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON e.PatientSubscriberLogID = VPSL.PatientSubscriberLogID
LEFT JOIN PhysicianDecision pdec ON preq.PhysicianRequestID = pdec.PhysicianRequestID 
WHERE prev.PhysicianReviewRequestReasonID IS NULL
AND EXISTS (SELECT PhysicianReviewWithNoReason
	    FROM dbo.SystemReportDefaults
	    WHERE  PhysicianReviewWithNoReason = 1)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

