SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_ActivityEdit]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_ActivityEdit]
GO

CREATE      VIEW dbo.Report_ActivityEdit
AS
SELECT 'A' Rec_Type,
p.PatientID,
VPSL.PatientFullName, 
'Activity late by ' + CAST(DATEDIFF(day, A.DueDate, getdate())as varchar) + ' days or more' as Message,
'Assigned to User: ' + ISNULL(u.LoginName, '<none>') as OD1,
'Type: ' + ISNULL(act.[Description],'<none>') as OD2,
'Due Date: '+ 	ISNULL(CAST (a.DueDate as varchar),'<none>') as OD3,
--dbo.GetNextActivity (p.PatientID) NextActivity, -- i'm skipping this field, NOT USED IN THE REPORT 
u2.LoginName as AssignedUser, 
a.ModifyTime as SelectDate, 
151 ErrorNumber,
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
pl.PlanID,
pl.[Name] as PlanName

FROM Activity a 
INNER JOIN Patient p ON a.PatientId = p.PatientId
INNER JOIN ActivityType act ON a.ActivityTypeID = act.ActivityTypeID
LEFT JOIN ActivityCompletion ac ON a.ActivityCompletionID = ac.ActivityCompletionID and ac.CodeStatus = 'OPEN'
LEFT JOIN AAUser u ON a.AssignedUserID = u.UserID
LEFT JOIN AAUser u2 ON a.ModifiedBy = u2.UserID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON P.PatientID = VPSL.PatientID
LEFT JOIN [Plan] pl ON a.PlanID = pl.PlanID
WHERE DATEDIFF(day, A.DueDate, getdate()) < 365 AND DATEDIFF(day, A.DueDate, getdate()) >= 1 AND
	VPSL.PatientSubscriberLogId in (Select max(VPSL2.PatientSubscriberLogId)
					FROM dbo.Report_PatientSubscriberLog VPSL2
					WHERE A.PatientID = VPSL2.PatientID
					AND VPSL2.SubscriberCoverageIsPrimary = 1)


UNION ALL

SELECT  'A' Rec_Type,
p.PatientID,
VPSL.PatientFullName, 
'Activity late by > 1 year ' as Message,
'Assigned to User: ' + ISNULL(u.LoginName, '<none>') as OD1,
'Type: ' + ISNULL(act.[Description],'<none>') as OD2,
'Due Date: '+ 	ISNULL(CAST (a.DueDate as varchar),'<none>') as OD3,
--dbo.GetNextActivity (p.PatientID) NextActivity, -- i'm skipping this field, NOT USED IN THE REPORT 
u2.LoginName as AssignedUser, 
a.ModifyTime as SelectDate, 
152 ErrorNumber,
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
pl.PlanID,
pl.[Name] as PlanName

FROM Activity a 
INNER JOIN Patient p ON a.PatientId = p.PatientId
INNER JOIN ActivityType act ON a.ActivityTypeID = act.ActivityTypeID
LEFT JOIN ActivityCompletion ac ON a.ActivityCompletionID = ac.ActivityCompletionID and ac.CodeStatus = 'OPEN'
LEFT JOIN AAUser u ON a.AssignedUserID = u.UserID
LEFT JOIN AAUser u2 ON a.ModifiedBy = u2.UserID
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON P.PatientID = VPSL.PatientID
LEFT JOIN [Plan] pl ON a.PlanID = pl.PlanID
WHERE DATEDIFF(day, A.DueDate, getdate()) >= 365 AND
	VPSL.PatientSubscriberLogId in (Select max(VPSL.PatientSubscriberLogId)
					FROM dbo.Report_PatientSubscriberLog VPSL
					WHERE A.PatientID = VPSL.PatientID
					AND VPSL.SubscriberCoverageIsPrimary = 1)




/*
HCC_RPT_160_V
ACTIVITY EDIT REPORT


select
  'A' REC_TYPE,b.PATIENT_ID PATIENT_ID,b.PT_LNAME||decode(b.PT_FNAME,null,'',', '||b.PT_FNAME) PATIENT_NAME,
  'Activity late by '|| Activityedit_days() ||' days or more' Message,
  'Assigned To User: '||nvl(a.ASSIGNEDTO_USER,'<none>') OD1,
  'Type: '||nvl(nvl(d.CODE_DESC,a.ACTIVITY_TYPE),'<none>') OD2,
  'Due Date: '||nvl(to_char(a.DUE_DATE,'mm/dd/yyyy'),'<none>') OD3,
  '' OD4,'' OD5,'' OD6,'' OD7,'' OD8,
  HCC_RPT_159_NEXT_ACTIVITY(b.PATIENT_ID) NEXT_ACTIVITY,
  0 EVENT_ID,'' EVENT_TYPE,0 SUBSCRIBER_ID,0 ACTIVITY_ID,0 PHYS_REVIEW_ID,0 REFERRAL_ID,0 CMS_ID,
  a.MOD_ID ASSIGNEDTO_USER,a.MOD_DATE SELECT_DATE,151 ERROR_NUMBER,k.morg_id,k.morg_name,
  l.org_id,l.org_name,m.sorg_id,m.sorg_name,q.plan_id,q.plan_name
from
  HCC_ACTV_ACTIVITY a,
  HCC_PPER_PATIENT b,
  HCC_ACTV_COMPLETION_CODE c,
  HCC_ACTV_ACTIVITY_TYPE d,
  hcc_pper_pat_sub_brk j,
  hcc_orgn_morg k,
  hcc_orgn_org l,
  hcc_orgn_sorg m,
  hcc_plan_plan q,
  hcc_pper_pat_sub_log r
where
  a.PATIENT_ID=b.PATIENT_ID
  and a.COMPLETION_CODE=c.CODE_ID
  and c.CODE_STATUS='OPEN'
  and trunc(sysdate-a.DUE_DATE) >= Activityedit_days() and trunc(sysdate-a.DUE_DATE) < 365
  and a.ACTIVITY_TYPE=d.CODE_ID(+)
  and a.patient_id = j.patient_id
  and k.morg_id = l.morg_id
  and l.org_id = m.org_id
  and (k.morg_id = j.morg_id
  and l.org_id =j.org_id
  and j.sorg_id = m.sorg_id)
  and r.pt_patient_id = a.patient_id
  and r.brk_morg_id = j.morg_id
  and r.brk_org_id = j.org_id
  and r.brk_sorg_id = j.sorg_id
  and r.pat_sub_log_id in(select max(w.pat_sub_log_id)
  							from hcc_pper_pat_sub_log w,
  								 hcc_pper_pat_sub_brk x
  							where w.pt_patient_id = a.patient_id
  								and	w.pt_primary_sub_id = b.primary_sub_id --mj
  								and x.sub_id = b.primary_sub_id --mj
  								and x.patient_id = a.patient_id
  								and w.brk_morg_id = x.morg_id
  								and w.brk_org_id = x.org_id
  								and w.brk_sorg_id = x.sorg_id)
  and r.sub_medical_planid = q.plan_id
union all
select
  'A' REC_TYPE,b.PATIENT_ID,b.PT_LNAME||decode(b.PT_FNAME,null,'',', '||b.PT_FNAME),
  'Activity late by > 1 year' Message,
  'Assigned To User: '||nvl(a.ASSIGNEDTO_USER,'<none>') OD1,
  'Type: '||nvl(d.CODE_DESC,'<none>') OD2,
  'Due Date: '||nvl(to_char(a.DUE_DATE,'mm/dd/yyyy'),'<none>') OD3,
  '' OD4,'' OD5,'' OD6,'' OD7,'' OD8,
  HCC_RPT_159_NEXT_ACTIVITY(b.PATIENT_ID) NEXT_ACTIVITY,
  0,'',0,0,0,0,0,
  a.MOD_ID,a.MOD_DATE,152,k.morg_id,k.morg_name,
  l.org_id,l.org_name,m.sorg_id,m.sorg_name,q.plan_id,q.plan_name
from
  HCC_ACTV_ACTIVITY a,
  HCC_PPER_PATIENT b,
  HCC_ACTV_COMPLETION_CODE c,
  HCC_ACTV_ACTIVITY_TYPE d,
  hcc_pper_pat_sub_brk j,
  hcc_orgn_morg k,
  hcc_orgn_org l,
  hcc_orgn_sorg m,
  hcc_plan_plan q,
  hcc_pper_pat_sub_log r
where
  a.PATIENT_ID=b.PATIENT_ID
  and a.COMPLETION_CODE=c.CODE_ID
  and c.CODE_STATUS='OPEN'
  and trunc(sysdate-a.DUE_DATE) >= 365
  and a.ACTIVITY_TYPE=d.CODE_ID(+)
  and a.patient_id = j.patient_id
  and k.morg_id = l.morg_id
  and l.org_id = m.org_id
  and (k.morg_id = j.morg_id
  and l.org_id =j.org_id
  and j.sorg_id = m.sorg_id)
  and r.pt_patient_id = a.patient_id
  and r.brk_morg_id = j.morg_id
  and r.brk_org_id = j.org_id
  and r.brk_sorg_id = j.sorg_id
  and r.pat_sub_log_id in(select max(w.pat_sub_log_id)
  							from hcc_pper_pat_sub_log w,
  								 hcc_pper_pat_sub_brk x
  							where w.pt_patient_id = a.patient_id
  								and	w.pt_primary_sub_id = b.primary_sub_id --mj
  								and x.sub_id = b.primary_sub_id --mj
  								and x.patient_id = a.patient_id
  								and w.brk_morg_id = x.morg_id
  								and w.brk_org_id = x.org_id
  								and w.brk_sorg_id = x.sorg_id)
  and r.sub_medical_planid = q.plan_id
*/
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

