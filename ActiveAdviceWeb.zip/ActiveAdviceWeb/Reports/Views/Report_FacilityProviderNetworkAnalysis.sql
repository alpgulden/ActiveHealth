SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_FacilityProviderNetworkAnalysis]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_FacilityProviderNetworkAnalysis]
GO













CREATE           VIEW dbo.Report_FacilityProviderNetworkAnalysis
AS 

SELECT 
e.EventID,
vpsl.PatientId,
vpsl.PatientFullName,
e.EndDate as SelectDate,
e.StartDate as EventStartDate,
e.EndDate as EventEndDate,
DATEPART(dw, e.StartDate) as AdmitDay, 
	WeekendAdmit =
		CASE 
		WHEN DATEPART(dw, e.StartDate)='1' THEN 'Y'
		WHEN DATEPART(dw, e.StartDate)='6' THEN 'Y'
		WHEN DATEPART(dw, e.StartDate)='7' THEN 'Y'
		ELSE 'N'
		END,
et.HEDISRptType,
	EventServiceType =
		CASE
		WHEN et.HEDISRptType = 'IP' THEN 'IP'
		ELSE 'OP'
		END,

e.EventTypeID,
et.[Description] as EventTypeDescription,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
VPSL.MorgID,
VPSL.MorgName,
pla.PlanId,
pla.[Name] as PlanName,
f.FacilityID,
ISNULL(f.[Name],'No Facility') as FacilityName,
--fl.FacilityLocationID,
ISNULL(adr.State,'Not Specified') as FacilityServiceState,
e.FacilityNetworkStatus, 
FacilityNetworkStatusDescription =
		CASE 
		WHEN e.FacilityNetworkStatus = '1' THEN 'In Network'
		WHEN e.FacilityNetworkStatus = '0' THEN 'Out of Network'
		ELSE 'Network Not Applicable'
		END,

e.FacilityNetworkID,
isnull(facn.[Name],'Network Not Specified') as FacilityNetworkName,
e.ProviderID,
ISNULL(p.LastName,'')+' '+ISNULL(p.FirstName,'')+' '+ISNULL(p.MiddleInitial,'') as ProviderName,
e.ProviderLocationID,
ISNULL(padr.State,'Not Specified') as ProviderServiceState,
e.ProviderSpecialtyID,
e.ProviderNetworkStatus, 
ProviderNetworkStatusDescription =
		CASE 
		WHEN e.ProviderNetworkStatus = '1' THEN 'In Network'
		WHEN e.ProviderNetworkStatus = '0' THEN 'Out of Network'
		ELSE 'Network Not Applicable'
		END,
e.ProviderNetworkID, 
ISNULL(provn.[Name],'Network Not Specified') as ProviderNetworkName,
dbo.GetLOS(e.StartDate,isnull(e.EndDate,GetDate())) as EventLOS,
--
dbo.GetIsOutlier
(dbo.GetLOS(e.StartDate,isnull(e.EndDate,GetDate())),
isnull(pla.LengthOfStayTrigger,10),
isnull(
(CASE
WHEN pla.OutlierTrigger = '10' THEN e.LOS_10
WHEN pla.OutlierTrigger = '25' THEN e.LOS_25
WHEN pla.OutlierTrigger = '50' THEN e.LOS_50
WHEN pla.OutlierTrigger = '75' THEN e.LOS_75
WHEN pla.OutlierTrigger = '90' THEN e.LOS_90
WHEN pla.OutlierTrigger = '95' THEN e.LOS_95
WHEN pla.OutlierTrigger = '99' THEN e.LOS_99
ELSE null END), isnull(pla.LengthOfStayTrigger,10))) as IsOutlier,
--
e.DischSameMom, 
e.DrgCode as EventDRG,
drg.DRGweight

FROM Event e
INNER JOIN SystemStatus ss ON e.StatusID = ss.StatusID AND ss.CodeStatus = 'CLOS'
LEFT JOIN EventType et ON e.EventTypeID = et.EventTypeID
LEFT JOIN  dbo.Report_PatientSubscriberLog VPSL ON e.PatientSubscriberLogId = VPSL.PatientSubscriberLogId --I ADDED THIS INSTEAD OF THE ABOVE
LEFT JOIN PlanSorgLog psl ON e.PlanSorgLogID = psl.PlanSorgLogID 
LEFT JOIN [Plan] pla ON psl.PlanID = pla.PlanID

LEFT JOIN Facility f ON e.FacilityID = f.FacilityID 
LEFT JOIN Location l ON e.FacilityLocationID = l.LocationID
LEFT JOIN Address adr ON l.ServiceAddressID = adr.AddressID

LEFT JOIN DRGCode drg ON e.DRGCode = drg.DRGCode AND e.DRGVersion = drg.DRGVersion
LEFT JOIN Network facn ON e.FacilityNetworkID = facn. NetworkID 
LEFT JOIN Patient pat ON e.PatientID = pat.PatientID

LEFT JOIN Provider p ON e.ProviderID = p.ProviderID
LEFT JOIN Location loc ON e.ProviderLocationID = loc.LocationID
LEFT JOIN Address padr ON loc.ServiceAddressID = padr.AddressID

LEFT JOIN Network provn ON e.ProviderNetworkID = provn.NetworkID
WHERE  et.HEDISRptType IN ('IP','AMSX','ER','OBSR','OPVS')
AND e.FacilityID<>0 AND e.FacilityNetworkID<>0 AND e.FacilityLocationID<>0
AND e.FacilityNetworkStatus is not null
AND adr.State is not null



/*
HCC_RPT_164_V

SELECT
 a.EVENT_ID,
 a.PATIENT_ID,
 o.PT_LNAME||decode(o.PT_FNAME,null,'',', '||o.PT_FNAME||' '||o.PT_MI) PATIENT_NAME,
 a.EVENT_END_DATE SELECT_DATE,
 a.EVENT_START_DATE,
 a.EVENT_END_DATE,
 to_char(a.EVENT_START_DATE,'Day') ADMIT_DAY,
 decode(to_char(a.EVENT_START_DATE,'D'),'1','Y','6','Y','7','Y','N') WEEKEND_ADMIT,
 c.HEDIS_RPT_TYPE,
 decode(c.HEDIS_RPT_TYPE,'IP','IP','OP') EVENT_SERVICE_TYPE, -- If IP then IP else OP
 nvl(a.DISCH_SAME_MOM,'N') DISCH_SAME_MOM,
 a.EVENT_TYPE,p.CODE_DESC EVENT_TYPE_DESC,
 e.MORG_ID,e.MORG_NAME,
 f.ORG_ID,f.ORG_NAME,
 g.SORG_ID,g.SORG_NAME,
 h.PLAN_ID,h.PLAN_NAME,
 k.FACILITY_ID,nvl(k.NAME,'No Facility') FACILITY_NAME,
 l.LOCATION_ID FAC_LOCATION_ID,
 nvl(l.SERVICE_STATE,'No State') FAC_SERVICE_STATE,
 a.FAC_NETWORK_STATUS,
 decode(a.FAC_NETWORK_STATUS,'Y','In Network','N','Out of Network','Network Not Applicable') FAC_NETWORK_STATUS_DESC,
 a.FAC_NETWORK_ID,
 nvl(n.NAME,decode(nvl(a.FAC_NETWORK_STATUS,'X'),'X','Network Not Required',decode(sign(a.FAC_NETWORK_ID),-1,'Network Not Specified','Network Not Specified'))) FAC_NETWORK_NAME,
 a.PROVIDER_ID,
 decode(nvl(a.PROVIDER_ID,0),0,'No Provider',q.LNAME||decode(q.FNAME,null,'',', '||q.FNAME)) PROVIDER_NAME,
 a.PROV_LOCATION_ID,
 nvl(r.SERVICE_STATE,'No State') PROV_SERVICE_STATE,
 a.PROV_SPECIALTY,nvl(s.CODE_DESC,'No Specialty') PROV_SPECIALTY_DESC,
 a.PROV_NETWORK_STATUS,
 decode(a.PROV_NETWORK_STATUS,'Y','In Network','N','Out of Network','Network Not Applicable') PROV_NETWORK_STATUS_DESC,
 a.PROV_NETWORK_ID,
 nvl(t.NAME,decode(nvl(a.PROV_NETWORK_STATUS,'X'),'X','Network Not Required',decode(sign(a.PROV_NETWORK_ID),-1,'Network Not Specified','Network Not Specified'))) PROV_NETWORK_NAME,
 COMPUTE_LOS(a.EVENT_START_DATE,a.EVENT_END_DATE) EVENT_LOS,
 rtrim(rpad(RPT_150_IS_OUTLIER(COMPUTE_LOS(a.EVENT_START_DATE,a.EVENT_END_DATE),nvl(h.LOS_TRIGGER,10),nvl(decode(h.OUTLIER_TRIGGER,10,a.los_10,25,a.los_25,50,a.los_50,
        75,a.los_75,90,a.los_90,95,a.los_95,99,a.los_99,null),nvl(h.LOS_TRIGGER,10))),1)) IS_OUTLIER,
 a.DRG_CODE EVENT_DRG,
 m.DRG_WEIGHT
FROM
HCC_PPER_EVENT a,
HCC_SYST_STATUS b,
HCC_PPER_EVENT_TYPE c,
HCC_PLAN_SORG_PLAN_LOG d,
HCC_ORGN_MORG e,
HCC_ORGN_ORG f,
HCC_ORGN_SORG g,
HCC_PLAN_PLAN h,
HCC_PRFA_FACILITY k,
HCC_PRFA_FAC_LOCATION l,
HCC_SYST_DRG_CODE m,
HCC_PRFA_NETWORK n,
HCC_PPER_PATIENT o,
HCC_PPER_EVENT_TYPE p,
HCC_PRFA_PROVIDER q,
HCC_PRFA_PROV_LOCATION r,
HCC_PRFA_PROV_SPECIALTY s,
HCC_PRFA_NETWORK t,
HCC_PRFA_FAC_NETWORK_BRK fac,
HCC_PRFA_PROV_NETWORK_BRK prov
WHERE
a.EVENT_STATUS=b.CODE_ID
and b.CODE_STATUS='CLOS'
and a.EVENT_TYPE=c.CODE_ID
and c.HEDIS_RPT_TYPE in ('IP','AMSX','ER','OBSR','OPVS')
and a.PLAN_SORG_LOG_ID=d.SORG_PLAN_LOG_ID
and d.BRK_MORG_ID=e.MORG_ID
and d.BRK_MORG_ID=f.MORG_ID
and d.BRK_ORG_ID=f.ORG_ID
and d.BRK_MORG_ID=g.MORG_ID
and d.BRK_ORG_ID=g.ORG_ID
and d.BRK_SORG_ID=g.SORG_ID
and d.PLAN_ID=h.PLAN_ID
and a.FACILITY_ID=k.FACILITY_ID(+)
and a.FAC_LOC_ID=l.LOCATION_ID(+)
and nvl(a.FACILITY_ID,0)<>0
and nvl(a.FAC_NETWORK_ID,0)<>0
and nvl(a.FAC_LOC_ID,0)<>0
and a.FAC_NETWORK_STATUS is not null
and l.SERVICE_STATE is not null
and a.DRG_CODE=m.DRG_CODE(+)
and a.DRG_VERSION = m.DRG_VERSION(+)
and a.FAC_NETWORK_ID=fac.FAC_NETWORK_ID(+)
	and fac.NETWORK_ID = n.NETWORK_ID(+)
and a.PATIENT_ID=o.PATIENT_ID(+)
and a.EVENT_TYPE=p.CODE_ID(+)
and a.PROVIDER_ID=q.PROVIDER_ID(+)
and a.PROV_LOCATION_ID=r.LOCATION_ID(+)
and a.PROV_SPECIALTY=s.CODE_ID(+)
and a.PROV_NETWORK_ID=prov.PROV_NETWORK_ID(+)
	and prov.NETWORK_ID = t.NETWORK_ID(+)
*/
















GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

