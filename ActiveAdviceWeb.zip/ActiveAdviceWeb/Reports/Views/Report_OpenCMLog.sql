SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_OpenCmLog]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_OpenCmLog]
GO

CREATE              VIEW dbo.Report_OpenCMLog
AS
SELECT DISTINCT
--View # used in the current app: HCC_RPT_185_V
cms.CMSID,
cms.CreateTime as SelectDate,
cms.CaseEndDate as CMSEndDate,
cms.CaseStartDate as CMSStartDate,
cms.AssignedUser,
cms.AssignedTeam,
cms.ProblemID,
cms.ProblemDescription,
cms.Source,
cms.Acuity,
cms.Intensity,
cms.Phase,
cms.Category,
ss.Code AS CMSStatus,
cms.CMSTypeCode,
cms.RiskFactor,
rpsl.SorgID,
rpsl.SorgName,
rpsl.OrgID,
rpsl.OrgName,
rpsl.MorgID,
rpsl.MorgName,
p.PlanId, p.[Name] as PlanName,
RPSL.PatientFullName as PatientName,  
rpsl.PatientSSN,
rpsl.SubscriberSSN,
rpsl.PatientDOB, 
rpsl.PatientId, 
rpsl.PatientAlternateId, 
RPSL.SubscriberFullName as SubscriberName,
cms.DetailType as Type,
m.EDCdate 

FROM Report_CMS AS cms
INNER JOIN SystemStatus ss ON cms.StatusID = ss.StatusID and ss.CodeStatus = 'OPEN' 
LEFT JOIN Report_PatientSubscriberLog rpsl ON cms. PatientSubscriberLogID = rpsl.PatientSubscriberLogId
LEFT JOIN [Plan] p ON rpsl.PlanId = p.PlanID
LEFT JOIN Maternichek m ON cms.CMSID = m.CMSID
WHERE cms.CMSTypeCode = 'CM'
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

