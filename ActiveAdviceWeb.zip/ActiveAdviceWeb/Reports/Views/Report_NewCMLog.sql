SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_NewCMLog]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_NewCMLog]
GO

CREATE           VIEW dbo.Report_NewCMLog 
AS
SELECT 
/*
HCC_RPT_184_V 
*/

cms.CMSID,
cms.CreateTime as SelectDate,
cms.CaseEndDate as CMSEndDate,
cms.CaseStartDate as CMSStartDate,
cms.AssignedUser,
cms.AssignedTeam,
cms.ProblemID,
cms.ProblemDescription,
cms.Source,
cms.Acuity,
cms.Intensity,
cms.Phase,
cms.Category,
ss.Code AS CMSStatus,
cms.CMSTypeCode,
cms.RiskFactor,
rpsl.SorgID,
rpsl.SorgName,
rpsl.OrgID,
rpsl.OrgName,
rpsl.MorgID,
rpsl.MorgName,
p.PlanId, p.[Name] as PlanName,
rpsl.PatientLastName+' '+ rpsl.PatientMiddleInitial+' '+rpsl.PatientFirstName as PatientName,  
rpsl.PatientDOB, 
rpsl.PatientId,
rpsl.PatientSSN,
rpsl.SubscriberSSN, 
rpsl.PatientAlternateId, 
rpsl.SubscriberLastName+' '+rpsl.SubscriberFirstName as SubscriberName,
cms.DetailType as Type,
m.EDCdate 

FROM Report_CMS AS cms
LEFT JOIN SystemStatus ss ON cms.StatusID = ss.StatusID
LEFT JOIN Report_PatientSubscriberLog rpsl ON cms. PatientSubscriberLogID = rpsl.PatientSubscriberLogId
LEFT JOIN [Plan] p ON rpsl.PlanId = p.PlanID
LEFT JOIN Maternichek m ON cms.CMSID = m.CMSID
WHERE ss.CodeStatus in ('OPEN','CLOS') AND cms.CMSTypeCode = 'CM' 


/*
HCC_RPT_184_V
SELECT  DISTINCT
	  	C.CMS_ID,
	  	SS.CODE_STATUS CMS_STATUS,
	  	C.CMS_TYPE,
  	  	C.CREATE_DATE SELECT_DATE,
	  	NVL(C.ASSIGNEDTO_TEAM, 'No Team Specified'),
		NVL(C.ASSIGNEDTO_USER, 'No User Specified'),
	  	M.MORG_ID, M.MORG_NAME,
	  	O.ORG_ID, O.ORG_NAME,
	  	S.SORG_ID, S.SORG_NAME,
		PP.PLAN_ID, PP.PLAN_NAME,
	  	P.PT_LNAME||DECODE(P.PT_FNAME,'',NULL,', '||P.PT_FNAME) PT_NAME,
	  	P.PT_DOB,
	  	P.PT_SSN,
	  	Q.SUB_SSN,
	  	P.PATIENT_ID,
	  	P.ALT_PT_ID,
  		H.PROBLEM_ID,
  		H.PROB_DESC,
 	 	C.CMS_START_DATE,
  		C.CMS_TERM_DATE END_DATE,
  	   	J.CODE_DESC SOURCE,
  	   	D.TYPE_ID CM_TYPE,
  		K.CODE_DESC TYPE,
  		CC.CODE_DESC CATEGORY,
   		A.CODE_DESC ACUITY,
  		N.CODE_DESC INTENSITY,
   		CP.CODE_DESC PHASE,
  		DECODE(MC.EDC_DATE, NULL, C.EDC_DATE, MC.EDC_DATE) EDC_DATE,
  		DECODE(MC.RISK_ID, NULL, D.RISK_ID, MC.RISK_ID) RISKFACTOR
FROM 	HCC_PPER_CMS_SUMMARY C,
 	 	HCC_SYST_STATUS SS,
	  	HCC_PLAN_SORG_PLAN_LOG L,
	  	HCC_ORGN_MORG M,
 	 	HCC_ORGN_ORG O,
 	 	HCC_ORGN_SORG S,
		HCC_PLAN_PLAN PP,
 	 	HCC_PPER_PATIENT P,
 	 	HCC_PPER_PROBLEM H,
 	 	HCC_CMGT_DETAIL D,
	  	HCC_CMS_SOURCE J,
 	 	HCC_CMS_DETAIL_TYPE K,
 	 	HCC_CMS_CATG CC,
 	 	HCC_CMS_ACUITY A,
	  	HCC_CMS_INTENSITY N,
 	 	HCC_CMS_PHASE CP,
 	 	HCC_MCHK_DETAIL MC,
  		HCC_PPER_SUBSCRIBER Q
WHERE   C.CMS_STATUS = SS.CODE_ID
		AND SS.CODE_STATUS IN ('OPEN','CLOS')
	  	AND C.CMS_TYPE = 'CM'
		AND C.PLAN_SORG_LOG_ID = L.SORG_PLAN_LOG_ID
	  	AND L.BRK_MORG_ID = M.MORG_ID
	  	AND L.BRK_SORG_ID = S.SORG_ID
	  	AND L.BRK_ORG_ID = O.ORG_ID
		AND L.PLAN_ID = PP.PLAN_ID
	  	AND C.PATIENT_ID = P.PATIENT_ID
	  	AND C.PRIMARY_PROBLEM_ID = H.PROBLEM_ID(+)
	  	AND C.CMS_ID = D.CMS_ID(+)
	  	AND D.SOURCE_ID = J.CODE_ID(+)
  		AND D.TYPE_ID = K.CODE_ID(+)
	  	AND D.CATG_ID = CC.CODE_ID(+)
	  	AND D.ACUTITY_ID = A.CODE_ID(+)
	  	AND D.INTENSITY_ID = N.CODE_ID(+)
	  	AND D.PHASE_ID = CP.CODE_ID(+)
	  	AND C.CMS_ID = MC.CMS_ID(+)
	  	AND P.PRIMARY_SUB_ID = Q.SUB_ID
*/
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

