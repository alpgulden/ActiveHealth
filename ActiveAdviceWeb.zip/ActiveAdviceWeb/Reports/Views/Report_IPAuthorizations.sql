SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_IPAuthorizations]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_IPAuthorizations]
GO








CREATE        VIEW dbo.Report_IPAuthorizations
AS
SELECT 
e.EventID, 
e.EndDate as SelectDate,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
VPSL.MorgID,
VPSL.MorgName,
VPSL.PatientId,
VPSL.PatientFullName,
pl.PlanID,pl.[Name] as PlanName,
f.FacilityID,
f.[Name]as FacilityName, 
loc.LocationID,
st.Code ServiceStateCode,
ISNULL(st.[Description],'zNo State')as ServiceStateDescription,
rtrim(dbo.GetAuthDecision(e.EventID)) AS AuthDecision

FROM Event e
INNER JOIN SystemStatus ss ON e.StatusID = ss.StatusID AND ss.CodeStatus = 'CLOS'
LEFT JOIN EventType et ON e.EventTypeID = et.EventTypeID AND et.HEDISRptType='IP'
LEFT JOIN PlanSorgLog psl ON e.PlanSorgLogID = psl.PlanSorgLogID
LEFT JOIN [Plan] pl ON psl.PlanID = pl.PlanID
LEFT JOIN Report_PatientSubscriberLog VPSL ON e.PatientSubscriberLogID = VPSL.PatientSubscriberLogID
LEFT JOIN Problem pr ON e.PrimaryProblemID =pr.ProblemID
LEFT JOIN Facility f ON e.FacilityID = f.FacilityID
LEFT JOIN Location loc ON e.FacilityLocationID = loc.LocationID
LEFT JOIN Address adr ON loc.ServiceAddressID = adr.AddressID
LEFT JOIN State st ON adr.State = st.code
INNER JOIN ClinicalReviewRequest crr ON e.EVentID = crr.EventID
INNER JOIN ClinicalReviewDecision crd ON crr.ClinicalReviewRequestID = crd.ClinicalReviewRequestID
INNER JOIN ClinicalReviewDecisionType crdt ON crd.ClinicalReviewDecisionTypeID = crdt.ClinicalReviewDecisionTypeID
INNER JOIN ClinicalReviewDecisionTypeCode crdtc ON crdt.ClinicalReviewDecisionTypeCodeID = crdtc.ClinicalReviewDecisionTypeCodeID 
WHERE e.FacilityID is not null
AND crdtc.Code in ('APPR','DENY')



/*
HCC_RPT_162_V

SELECT
 a.EVENT_ID,
 a.EVENT_END_DATE SELECT_DATE,
 e.MORG_ID,e.MORG_NAME,
 f.ORG_ID,f.ORG_NAME,
 g.SORG_ID,g.SORG_NAME,
 h.PLAN_ID,h.PLAN_NAME,
 j.PATIENT_ID,
 j.PT_LNAME||decode(j.PT_FNAME,null,'',', '||j.PT_FNAME||' '||j.PT_MI) PATIENT_NAME,
 k.FACILITY_ID,k.NAME FACILITY_NAME,
 l.LOCATION_ID,m.CODE_ID SERVICE_STATE,decode(m.CODE_DESC,null,'zNo State',' '||m.CODE_DESC) SERVICE_STATE_DESC, 
 rtrim(rpad(hcc_rpt_162_auth_decision(a.EVENT_ID),10)) AUTH_DECISION
FROM
HCC_PPER_EVENT a,
HCC_SYST_STATUS b,
HCC_PPER_EVENT_TYPE c,
HCC_PLAN_SORG_PLAN_LOG d,
HCC_ORGN_MORG e,
HCC_ORGN_ORG f,
HCC_ORGN_SORG g,
HCC_PLAN_PLAN h,
HCC_PPER_PROBLEM i,
HCC_PPER_PATIENT j,
HCC_PRFA_FACILITY k,
HCC_PRFA_FAC_LOCATION l,
HCC_SYST_STATE m
WHERE
a.EVENT_STATUS=b.CODE_ID
and b.CODE_STATUS='CLOS'
and a.EVENT_TYPE=c.CODE_ID
and c.HEDIS_RPT_TYPE='IP'
and a.PLAN_SORG_LOG_ID=d.SORG_PLAN_LOG_ID
and d.BRK_MORG_ID=e.MORG_ID
and d.BRK_MORG_ID=f.MORG_ID
and d.BRK_ORG_ID=f.ORG_ID
and d.BRK_MORG_ID=g.MORG_ID
and d.BRK_ORG_ID=g.ORG_ID
and d.BRK_SORG_ID=g .SORG_ID
and d.PLAN_ID=h.PLAN_ID
and a.PRIMARY_PROBLEM_ID=i.PROBLEM_ID
and i.PATIENT_ID=j.PATIENT_ID
and a.FACILITY_ID=k.FACILITY_ID(+)
and a.FAC_LOC_ID=l.LOCATION_ID(+)
and nvl(a.FACILITY_ID,0)<>0   
and l.SERVICE_STATE=m.CODE_ID(+) 
and exists (select aa.EVENT_ID 
            from
              HCC_CLINIC_REV_REQUEST aa,
              HCC_CLINIC_REV_DECISION bb,
              HCC_CLINIC_REV_DECISION_TYPE cc
            where
              aa.EVENT_ID=a.EVENT_ID
              and aa.REV_REQUEST_ID=bb.REV_REQUEST_ID              and bb.DECISION_TYPE=cc.CODE_ID
              and cc.DECISION_CODE in ('APPR','DENY'))
*/









GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

