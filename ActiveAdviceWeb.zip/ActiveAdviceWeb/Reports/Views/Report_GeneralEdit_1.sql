SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GeneralEdit_1]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_GeneralEdit_1]
GO








CREATE        VIEW dbo.Report_GeneralEdit_1
AS

--E1---

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open Event with no future Activities ' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
100 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode = 'OPEN' AND 
NOT EXISTS (SELECT a.ActivityID
		FROM Activity a 
		INNER JOIN ActivityCompletion ac ON a.ActivityCompletionID = ac.ActivityCompletionID AND ac.CodeStatus = 'OPEN'
		INNER JOIN Patient p ON a.PatientID = p.PatientID)
AND EXISTS (SELECT  OpenEventNoFutureActivities 
	    FROM dbo.SystemReportDefaults
	    WHERE OpenEventNoFutureActivities = 1)
		

UNION ALL

--E2---

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open Event with End Date ' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
101 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE EvenEndDate IS NOT NULL AND StatusCode = 'OPEN'
AND EXISTS (SELECT  OpenEventWithEndDate
	    FROM dbo.SystemReportDefaults
	    WHERE OpenEventWithEndDate = 1)

UNION ALL

--E20--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with no Start Date' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
119 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND EventStartDate IS NULL
AND EXISTS (SELECT  EventNoStartDate
	    FROM dbo.SystemReportDefaults
	    WHERE EventNoStartDate = 1)

UNION ALL

--E21--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with Start Date on or after Sub Organization"s Termination Date' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'Sorg Name: ' +SorgName as OD7,
'Sorg Term Date: ' + CAST(SORGTerminationDate as varchar) as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
120 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND EventStartDate >= SORGTerminationDate
AND EXISTS (SELECT  EventStartDateAfterSORGTermDate
	    FROM dbo.SystemReportDefaults
	    WHERE  EventStartDateAfterSORGTermDate = 1)


UNION ALL

--E25--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with blank Review Request Unit Cost and non blank Review Decision Unit Cost' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
124 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND ReqUnitCost IS NULL 
AND ISNULL(DecUnitCost,0) > 0
AND EXISTS (SELECT  EventBlankReviewRequestUnitCost
	    FROM dbo.SystemReportDefaults
	    WHERE  EventBlankReviewRequestUnitCost = 1)
UNION ALL

--E26--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with Review Decision of "Deny" or "Refer to Physician Reviewer"' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'Decision Type: '+ DecisionType  as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
125 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND DecisionTypeCode in ('DENY','RFPR')







GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

