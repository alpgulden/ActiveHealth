SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GeneralEdit_2]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_GeneralEdit_2]
GO


CREATE  VIEW dbo.Report_GeneralEdit_2
AS

--E7--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with no End Date' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
106 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND EvenEndDate IS NULL
AND EXISTS (SELECT  ClosedEventNoEndDate
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventNoEndDate = 1)
UNION ALL

--E8--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with no Diagnosis' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
107 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND NOT EXISTS (SELECT erd.EventDiagnosisID
		FROM EventReferralDiagnose erd 
		WHERE erd.EventID = EventID)
AND EXISTS (SELECT ClosedEventsWithNoDx 
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventsWithNoDx = 1)


UNION ALL

--E12--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with no Resolution' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
111 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND EventResolution IS NULL
AND EXISTS (SELECT  ClosedEventsNoResolution
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventsNoResolution = 1)
UNION ALL

--E13--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with no Type' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
112 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND EventTypeID IS NULL
AND EXISTS (SELECT  ClosedEventNoType
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventNoType = 1)

UNION ALL

--E14--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with no Source' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
113 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND EventSourceID IS NULL
AND EXISTS (SELECT  ClosedEventsNoSource
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventsNoSource = 1)

UNION ALL

--E17--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with Review Request but no Review Decision' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'Request Amount: '+ CAST(ReqAmount as varchar) as OD7, 
'Request UOfM: '+ ReqUOFM  as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
116 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode = 'CLOS'  
AND NOT EXISTS (SELECT crd.ClinicalReviewDecisionID
		FROM ClinicalReviewDecision crd 
		INNER JOIN ClinicalReviewRequest crr ON crd.ClinicalReviewRequestID = crr.ClinicalReviewRequestID) 
AND EXISTS (SELECT  ClosedEventWithReviewReqNoRevDec
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedEventWithReviewReqNoRevDec = 1)

UNION ALL

--E19--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed Event with Requested Amount less than Approved + Denied Amount' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
118 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

