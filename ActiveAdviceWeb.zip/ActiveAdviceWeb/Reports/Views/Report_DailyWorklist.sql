SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_DailyWorklist]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_DailyWorklist]
GO

CREATE            VIEW dbo.Report_DailyWorklist
AS 
SELECT 
--Respective report in the current app. uses the view: HCC_RPT_101_V

a.PatientId, 
a.EventID, 
a.ReferralID, 
rd.ReferralDetailID,
a.PhysicianReviewID, 
a.ActivityID, 
act.[Description] as ActivityTypeDescription, 
a.ActivityDescription, 
a.DueDate as SelectDate,
ac.[Description] as CompletionCodeDescription, 
t.Code as AssignedTeam,
u.[LoginName] as AssignedUser,
e.[Description] as EventDescription,
et.[Description] as EventTypeDescription,
ss.Code as EventStatus,
e.StartDate as EventStartDate, 
e.EndDate as EventEndDate,
e.FacilityID,
e.AdmittingDiagnosisType,
e.AdmittingDiagnosisCode,
a.ProblemId,
e.ProviderID,
e.PlanSorgLogID,
ISNULL(vpsl.PatientFullName,'No Patient Name') as PatientName,
prob.ProblemDescription,
prob.DxType as ProblemDiagnoses,
vpsl.SorgID,
vpsl.SorgName,
vpsl.MorgID,
vpsl.MorgName,
vpsl.OrgID,
vpsl.OrgName,
vpsl.PatientSSN,
vpsl.SubscriberSSN,
isnull(pr.FirstName,'')+' '+isnull(pr.LastName,'') as ProviderName, 
ProviderPhone = 
CASE
WHEN pradr.PhoneNumber1 IS NULL THEN ' '
ELSE pradr.PhoneNumber1+'ext. '+isnull(pradr.PhoneExt1,'')
END,
fac.[Name]as FacilityName,
FacilityPhone = 
CASE 
WHEN facadr.PhoneNumber1 IS NULL THEN ' ' 
ELSE facadr.PhoneNumber1+'ext. '+isnull(facadr.PhoneExt1,'')
END,
isnull(refprov.LastName,'')+' '+isnull(refprov.FirstName,'')+' '+isnull(refprov.MiddleInitial,'') as ReferringProviderName,
ReferringProviderPhone = 
CASE 
WHEN refadr.PhoneNumber1 IS NULL THEN ' '
ELSE refadr.PhoneNumber1+'ext. '+isnull(refadr.PhoneExt1,'')
END,
RefToName = 
	CASE 
	WHEN r.ReferredToType = 1 THEN reftop.LastName +', ' +reftop.FirstName
	WHEN r.ReferredToType = 2 THEN reftof.Name
	WHEN r.ReferredToType = 3 THEN reftogp.Name
	ELSE 'zNo Referred To Entity'
	END,
' ' as RefToPhone, 
erd1.DiagnosisCode AS DiagnosisCode1,
erd1.DiagnosisType AS DiagnosisType1,
erd2.DiagnosisCode AS DiagnosisCode2,
erd2.DiagnosisType AS DiagnosisType2,
rtrim(left(dbo.GetDxPxDescription(erd1.DiagnosisType,'D',erd1.DiagnosisCode),60)) as Dx1ShortTitle,
rtrim(left(dbo.GetDxPxDescription(erd2.DiagnosisType,'D',erd2.DiagnosisCode),60)) as Dx2ShortTitle,
rt.[Description] as ReferralType,
rd.ValidStartDate as ReferralStartDate,
rd.ValidEndDate as ReferralEndDate,
rut.[Description] as ReferralUnit

FROM Activity a
INNER JOIN ActivityCompletion ac ON a.ActivityCompletionID = ac.ActivityCompletionID and ac.CodeStatus='OPEN'
LEFT JOIN ActivityType act ON a.ActivityTypeID = act.ActivityTypeID
LEFT JOIN AAUser u ON a.AssignedUserID = u.UserID
LEFT JOIN Team t ON a.AssignedTeamID = t.TeamID 
LEFT JOIN Event e ON a.EventID = e.EventID
LEFT JOIN EventType et ON e.EventTypeID = et.EventTypeID
LEFT JOIN SystemStatus ss ON e.StatusID = ss.StatusID --For Event Status
--For Facility Name & Phone Number
LEFT JOIN Facility fac ON e.FacilityID = fac.FacilityID
LEFT JOIN FacilityLocation fc ON e.FacilityLocationID = fc.FacilityLocationID
LEFT JOIN Location facloc ON fc.LocationID = facloc.LocationID
LEFT JOIN Address facadr ON facloc.ServiceAddressID = facadr.AddressID
--For Provider Name & Phone Number 
LEFT JOIN Provider pr ON e.ProviderID = pr.ProviderID
LEFT JOIN ProviderLocation pl ON e.ProviderLocationID = pl.ProviderLocationID
LEFT JOIN Location prloc ON pl.LocationID = prloc.LocationID
LEFT JOIN Address pradr ON prloc.ServiceAddressID = pradr.AddressID
--For ReferringProvider Name & Phone Number 
LEFT JOIN Referral ref ON a.ReferralID = ref.ReferralID 
LEFT JOIN ProviderLocation refpl ON ref.ReferredFromLocationID = refpl.ProviderLocationID
LEFT JOIN Provider refprov ON refpl.ProviderID = refprov.ProviderID
LEFT JOIN Location refloc ON refpl.LocationID = refloc.LocationID
LEFT JOIN Address refadr ON refloc.ServiceAddressID = refadr.AddressID
--REfTO
LEFT JOIN Referral r ON a.ReferralID = r.ReferralID
LEFT JOIN Provider reftop ON r.ReferredToID = reftop.ProviderID 
LEFT JOIN Facility reftof ON r.ReferredToID = reftof.FacilityID 
LEFT JOIN GroupPractice reftogp ON r.ReferredtoID = reftogp.GroupPracticeID 
LEFT JOIN ReferToType reftot ON r.ReferredToType = reftot.ReferToTypeID
LEFT JOIN Specialty reftos ON r.ReferredToSpecialtyID = reftos. SpecialtyID

LEFT JOIN dbo.Report_PatientSubscriberLog vpsl ON a.PatientSubscriberLogID = vpsl.PatientSubscriberLogID 
LEFT JOIN Problem prob ON a.ProblemID = prob.ProblemID
LEFT JOIN EventReferralDiagnose erd1 ON a.EventID = erd1.EventID and erd1.[Sequence]='10'
LEFT JOIN EventReferralDiagnose erd2 ON a.EventID = erd2.EventID and erd2.[Sequence] = '20'
LEFT JOIN ReferralType rt ON ref.ReferralTypeID = rt.ReferralTypeID
LEFT JOIN ReferralDetail rd ON ref.ReferralID = rd.ReferralID
LEFT JOIN ReferralUnitType rut ON rd.UnitTypeID = rut.ReferralUnitTypeID 
/*
WHERE  rd.ReferralDetailID in (Select min(rd.ReferralDetailID)
FROM ReferralDetail rd
GROUP BY ReferralID) 

AND a.ActivityID in (Select min(a2.ActivityID)
FROM Activity a2
INNER JOIN ActivityCompletion ac2 ON a2.ActivityCompletionID = ac2.ActivityCompletionID 
WHERE a2.ReferralId = a.ReferralID AND ac2.CodeStatus='OPEN')
*/
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

