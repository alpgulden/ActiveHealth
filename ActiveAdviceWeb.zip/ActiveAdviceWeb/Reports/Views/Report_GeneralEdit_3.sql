SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GeneralEdit_3]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_GeneralEdit_3]
GO


CREATE  VIEW dbo.Report_GeneralEdit_3
AS



--E9--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event with no DRG' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
108 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND DRGCode IS NULL AND HedisRptType = 'IP'
AND EXISTS (SELECT  ClosedIPEventsNoDRG
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventsNoDRG = 1)

UNION ALL

--E10--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event where DRG is 468, 469 or 470' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'DRG Code: ' + CAST(DRGCode as varchar) as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
109 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND DRGCode in (468,469,470) AND HedisRptType = 'IP'
AND EXISTS (SELECT  ClosedIPEventsDRG468_469_470
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventsDRG468_469_470 = 1)

UNION ALL

--E11--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event and DX/PX without an associated LOS Message' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'DRG Code: ' + CAST(DRGCode as varchar) as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
110 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND HedisRptType = 'IP' AND LOS_10 IS NULL 
AND EXISTS (SELECT  ClosedIPEventsNoLOS
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventsNoLOS = 1)


UNION ALL
--E15--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event with Start Date = End Date' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
114 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND HedisRptType = 'IP' 
AND EventStartDate = EvenEndDate
AND EXISTS (SELECT  ClosedIPEventStartEqualsEnd
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventStartEqualsEnd = 1)

UNION ALL

--E16--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event with no Review' as Message , 
OD1,
OD2,
OD3,OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
115 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND HedisRptType = 'IP' 
AND NOT EXISTS (SELECT crr.ClinicalReviewRequestID
		FROM ClinicalReviewRequest crr
		WHERE EventID = crr.EventID)
AND EXISTS (SELECT  ClosedIPEventsNoReview
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventsNoReview = 1)

UNION ALL

--E18--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Closed IP Event with Actual LOS greater than Approved + Denied LOS' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'Actual LOS: '+ CAST(dbo.GetLOS(EventStartDate,ISNULL(EvenEndDate,GetDate())) as varchar) as OD7, 
'Approved+Denied LOS: '+ CAST (dbo.GetDecDaysGeneralEditReport(EventID) as varchar) as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
117 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND HedisRptType = 'IP' AND
dbo.GetLOS(EventStartDate,ISNULL(EvenEndDate,GetDate())) > 
dbo.GetDecDaysGeneralEditReport (EventID)
AND EXISTS (SELECT  ClosedIPEventActualLOStoobig
	    FROM dbo.SystemReportDefaults
	    WHERE ClosedIPEventActualLOStoobig = 1)





GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

