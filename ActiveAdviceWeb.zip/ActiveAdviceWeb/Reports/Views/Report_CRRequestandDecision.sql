ALTER              VIEW dbo.Report_CRRequestandDecision
AS
SELECT 
crr.EventID as CRRequestDecisionEventID,
crr.ClinicalReviewRequestID,
crr.ReqAmount,
reqcru.[Description] as ReqUOFM,
reqru.Code as ReqReportUnit,
crr.FreqAmount as ReqFrequencyAmount,
reqcrfu.[Description] as ReqFrequencyUofM,
crr.DurAmount as ReqDurationAmount,
crr.UnitCost as ReqUnitCost,
reqcrdu.[Description] as ReqDurationUofM,
reqcrdesc.[Description] as ReqDescription,
crd.ClinicalReviewDecisionID,
crd.DecAmount,
deccru.[Description] as DecUOFM,
decru.Code as DecReportUnit,
crd.FreqAmount as DecFrequencyAmount,
deccrfu.[Description] as DecFrequencyUofM,
crd.DurationAmount as DecDurationAmount,
deccrdu.[Description] as DecDurationUofM,
deccrdesc.[Description] as DecDescription,
crdt.[Description] as DecisionType,
crdt.[Code] as DecisionTypeCode,
crdr.[Description] as DecisionReason,
crd.ActualAmount as DecisionActualAmount,
crd.ActualEndDate as DecisionActualEndDate,
crd.StartDate as DecisionStartDate,
crd.EndDate as DecisionEndDate,
crd.UnitCost as DecUnitCost,
crd.Comment as DecComment,
crd.PercentUnitDisc as DecDiscount

FROM  ClinicalReviewRequest crr
LEFT JOIN ClinicalReviewUnit reqcru ON crr.ReqUOMID = reqcru.ClinicalReviewUnitID
LEFT JOIN ReportUnit reqru ON reqcru.ReportUnitID = reqru.CodeID
LEFT JOIN ClinicalReviewFreqUnit reqcrfu ON crr.FreqUOMID = reqcrfu.ClinicalReviewFreqUnitID
LEFT JOIN ClinicalReviewDurUnit reqcrdu ON crr.DurUOMID = reqcrdu.ClinicalReviewDurUnitID
LEFT JOIN ClinicalReviewDescription reqcrdesc ON crr.ClinicalReviewDescriptionID = reqcrdesc.ClinicalReviewDescriptionID 
LEFT JOIN ClinicalReviewDecision crd  ON crr.ClinicalReviewRequestID = crd.ClinicalReviewRequestID
LEFT JOIN ClinicalReviewUnit deccru ON crd.DecUOMID = deccru.ClinicalReviewUnitID
LEFT JOIN ReportUnit decru ON deccru.ReportUnitID = decru.CodeID
LEFT JOIN ClinicalReviewFreqUnit deccrfu ON crd.FreqUOMID = deccrfu.ClinicalReviewFreqUnitID
LEFT JOIN ClinicalReviewDurUnit deccrdu ON crd.DurationUOMID = deccrdu.ClinicalReviewDurUnitID
LEFT JOIN ClinicalReviewDescription deccrdesc ON crd.ClinicalReviewDescriptionID =deccrdesc.ClinicalReviewDescriptionID 
LEFT JOIN ClinicalReviewDecisionType crdt ON crd.ClinicalReviewDecisionTypeID = crdt.ClinicalReviewDecisionTypeID 
LEFT JOIN ClinicalReviewDecisionTypeCode crdtc ON crdt.ClinicalReviewDecisionTypeCodeID = crdtc.ClinicalReviewDecisionTypeCodeID  
LEFT JOIN ClinicalReviewDecisionReason crdr ON crd.ClinicalReviewDecisionReasonID = crdr.ClinicalReviewDecisionReasonID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

