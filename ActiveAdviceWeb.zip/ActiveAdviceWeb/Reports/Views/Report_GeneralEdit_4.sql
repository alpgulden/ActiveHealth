SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GeneralEdit_4]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_GeneralEdit_4]
GO



CREATE   VIEW dbo.Report_GeneralEdit_4
AS



--E3--


SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
Message = 
	CASE
	WHEN CMSID IS NULL THEN 'Closed Event with no Provider' 
	ELSE  'Closed CMS Event with no Provider'
	END, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
101 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND ProviderID IS NULL
AND EXISTS (SELECT  CMS_EventsWithNoProvider
	    FROM dbo.SystemReportDefaults
	    WHERE CMS_EventsWithNoProvider = 1)
UNION ALL

--E5--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
Message = 
	CASE 
	WHEN CMSID IS NULL THEN 'Closed Event with no facility'
	ELSE 'Closed CMS Event with no facility'
	END, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7, 
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
101 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode ='CLOS' AND FacilityID IS NULL
AND EXISTS (SELECT CMS_EventsWithNoFacilities 
	    FROM dbo.SystemReportDefaults
	    WHERE CMS_EventsWithNoFacilities = 1)
/*
UNION ALL
--E22--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Multiple Events for Patient with the same Start Date' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
121 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName


FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND EventID<>e2EventID 
AND e1StartDate = e2StartDate
*/

UNION ALL

--E23--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with Review Request Amount = 0' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
122 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') AND ReqAmount = 0
AND EXISTS (SELECT  EventRequestedAmount0
	    FROM dbo.SystemReportDefaults
	    WHERE  EventRequestedAmount0 = 1)

UNION ALL

--E24--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Event Start date before Patient DOB' as Message , 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
123 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND EventStartDate < PatientDOB
AND EXISTS (SELECT  EventStartDateBeforePatientDOB
	    FROM dbo.SystemReportDefaults
	    WHERE EventStartDateBeforePatientDOB  = 1)



UNION ALL

--E27--

SELECT DISTINCT
RecType,
PatientID,
PatientFullName,
'Open or Closed Event with Review Decision Amount = 0 or blank' as Message, 
OD1,
OD2,
OD3,
OD4,
OD5,
OD6,
'' as OD7,
'' as OD8,
NextActivity,
EventID,
EventType,
SubscriberID,
ActivityID,
PhysReviewID,
ReferralID,
CMSID,
AssignedUser,
SelectDate,
126 as ErrorNumber,
MorgID, 
MorgName,
OrgID,
OrgName,
SorgID,
SorgName,
PlanID,
PlanName

FROM dbo.Report_GeneralEditEvent
WHERE StatusCode in ('CLOS','OPEN') 
AND ISNULL(DecAmount,0) = 0
AND EXISTS (SELECT  EventReviewDecisionAmount0
	    FROM dbo.SystemReportDefaults
	    WHERE  EventReviewDecisionAmount0 = 1)




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

