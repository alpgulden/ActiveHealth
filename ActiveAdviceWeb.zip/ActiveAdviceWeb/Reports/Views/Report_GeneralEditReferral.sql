SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_GeneralEditReferral]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_GeneralEditReferral]
GO




CREATE    VIEW dbo.Report_GeneralEditReferral
AS
SELECT  
'F' RecType,
pat.PatientID,
VPSL.PatientFullName,
--' ' Message 
'Type: ' + rt.[Description] as OD1,
'Start Date: '+ CAST(rd.ReferralDetailDate as varchar) as OD2,
'Status: ' +ss.[Description] as OD3,
'' OD4,
'' OD5,
'' OD6,
'' OD7,
'' OD8,
'' NextActivity,
0 EventID,
'' EventType,
0 SubscriberID,
0 ActivityID,
0 PhysicianReviewID,
r.ReferralID,
0 CMSID,
u.LoginName as AssignedUser, 
r.ModifyTime as SelectDate,
--201 Error Number
VPSL.MorgID,
VPSL.MorgName,
VPSL.OrgID,
VPSL.OrgName,
VPSL.SorgID,
VPSL.SorgName,
pl.PlanID,
pl.[Name] as PlanName,
r.ReferredToID,
ss.CodeStatus as StatusCode,
r.PCPID,
r.ReferredFromProviderID,
rd.UnitQuantity,
rd.UnitUnlimited

FROM Referral r
LEFT JOIN Problem pr ON r.PrimaryProblemID = pr.ProblemID
LEFT JOIN Patient pat ON r.PatientID = pat.PatientID
LEFT JOIN ReferralDetail rd ON r.ReferralID = rd.ReferralID
LEFT JOIN AAUser u ON r.AssignedToUser = u.UserID
INNER JOIN ReferralType rt ON r.ReferralTypeID = rt.ReferralTypeID
INNER JOIN SystemStatus ss ON rd.ReferralStatusID = ss.StatusID
LEFT JOIN PlanSorgLog psl ON r.PlanSorgLogID = psl.PlanSorgLogID
LEFT JOIN [Plan] pl ON psl.PlanId = pl.PlanId
LEFT JOIN dbo.Report_PatientSubscriberLog VPSL ON r.PatientSubscriberLogID = VPSL.PatientSubscriberLogID
WHERE rd.ReferralDetailID in (Select min(rd2.ReferralDetailID)
FROM ReferralDetail rd2
GROUP BY rd2.ReferralID)







GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

