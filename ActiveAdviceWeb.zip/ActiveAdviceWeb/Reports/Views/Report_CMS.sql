SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_CMS]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_CMS]
GO

CREATE               VIEW dbo.Report_CMS
AS
SELECT C.CMSID, 
C.AlternateCMSID, 
C.PrimaryProblemID, 
C.CaseStartDate, 
C.CaseEndDate,  
C.CaseSourceID, 
C.CaseOpenReasonID, 
C.CaseContinuedReasonID, 
C.CaseClosedReasonID,
C.CaseType,
C.PatientAuthorizerID, 
C.PatientAuthorizationDate, 
C.ClientAuthorizerID, 
C.ClientAuthorizationDate, 
C.CreatedBy, 
C.CreateTime, 
C.ModifyTime, 
C.ModifiedBy, 
C.PrimaryProviderSpecialtyID, 
C.PrimaryProviderLocationID, 
C.PrimaryProviderLocationNetworkID, 
C.PrimaryProviderNetworkStatus, 
C.PrimaryProviderLocationContactID, 
C.PrimaryFacilityTypeID, 
C.PrimaryFacilityLocationID, 
C.PrimaryFacilityLocationNetworkID, 
C.PrimaryFacilityNetworkStatus, 
C.PrimaryFacilityLocationContactID, 
--C.ProviderInNetwork, 
--C.FacilityInNetwork, 
C.PrimaryProviderID, 
C.PrimaryFacilityID, 
--C.ProviderOutNetwork, 
--C.FacilityOutNetwork, 
C.ClientReportContact, 
C.PatientSubscriberLogID, 
C.PlanSorgLogID, 
C.UserDefinedID, 
C.PatientId,
CA.Code AS AcuityCode,
CA.[Description] AS Acuity,
CI.Code AS IntensityCode,
CI.[Description] AS  Intensity,
CP.Code AS PhaseCode,
CP.[Description] AS  Phase,
CS.[Description] AS Source,
P.ProblemID,
ProblemDescription = 
CASE 
WHEN p.ProblemDescription IS NULL THEN pd.[Description] 
ELSE p.ProblemDescription 
END,
CR.Code AS RiskCode,
CR.[Description] AS  Risk,
CR.CMSRiskID as RiskFactor,
CG.Code as CategoryCode,
CG.[Description] as Category,
CT.Code as CMSTypeCode,
CT.[Description] as CMSType,
ISNULL(u.LoginName,'No User Specified') as AssignedUser,
T.Code AS TeamCode,
ISNULL(t.[Description], 'No Team Specified') as AssignedTeam,
CST.Code AS DetailTypeCode,
/*CT.[Description] as DetailType,--CMSType table*/
CST.[Description] as DetailType, --CMSStatusTypeTable
CSH.StatusID

FROM CMS C
LEFT JOIN dbo.CMSStatusHistory CSH ON CSH.CMSID=C.CMSID
LEFT JOIN dbo.CMSAcuity CA ON CSH.AcuityId = CA.AcuityId
LEFT JOIN dbo.CMSIntensity CI ON CSH.IntensityId = CI.IntensityId
LEFT JOIN dbo.CMSPhase CP ON CSH.PhaseId = CP.PhaseID
LEFT JOIN dbo.CMSCategory CG ON CSH.CMSCategoryID = CG.CMSCategoryID
LEFT JOIN dbo.CMSType CT ON C.CMSTypeId = CT.CMSTypeID
LEFT JOIN dbo.Problem P ON C.PrimaryProblemID = P.ProblemID
LEFT JOIN dbo.ProblemDescription PD ON P.ProblemDescriptionID=PD.CodeID
LEFT JOIN CaseSource cs ON c.CaseSourceID = cs.CaseSourceID
LEFT JOIN dbo.CMSRisk CR ON CSH.CMSRiskID= CR.CMSRiskId
LEFT JOIN dbo.CMSStatusType CST ON CSH.StatusTypeId = CST.StatusTypeId -- Refers CMS DetailType in the current app.
LEFT JOIN AAUser U ON csh.AssignedUserID = u.UserID
LEFT JOIN Team T ON csh.AssignedTeamID = TeamID
LEFT JOIN CaseSource CSO ON C.CaseSourceID = CSO.CaseSourceID
WHERE csh.cmsstatusid in (Select  max(csh.cmsstatusID)
FROM cmsstatushistory csh
GROUP BY cmsid)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

