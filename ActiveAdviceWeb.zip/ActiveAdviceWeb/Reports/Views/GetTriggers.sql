SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

ALTER    FUNCTION dbo.GetTriggers (
		@EventID int, 
		@startdate datetime, 
		@enddate datetime)
RETURNS VARCHAR(50)
AS
BEGIN
--RPT_134_SELECT VIEW - POTENTIAL LARGE CASES REPORT
DECLARE @return varchar(50)


declare @cmtrigger int
SET @cmtrigger = 0
SELECT 	@cmtrigger = EventID
FROM 	dbo.EventReferralDiagnose
WHERE 	EVENTID = @eventid 
	AND EVENTID is not null
	AND CMTRIGGER = '1'

SELECT 	@CMTrigger = EventID
FROM 	dbo.EventReferralProcedure 
WHERE 	EVENTID = @eventid 
	AND EventID is not null
	AND CMTrigger = '1'

DECLARE @LOSTrigger INT
SET 	@LOSTrigger = 0
SELECT 	@LOSTrigger = E.EventID
FROM 	Event E,
	EVENTTYPE ET,
	PLANSORGLOG L,
	[PLAN] P
WHERE 	ET.HedisRPTType='IP' AND
	E.EventTypeID = ET.EventTypeID AND
	E.PlanSorgLogID = L.PlanSorgLogID AND
	L.PlanID = P.PlanID AND
	E.EventID = @eventid AND
	((dbo.GetLOS(@StartDate,@EndDate) >= p.LengthOfStayTrigger)
	OR (dbo.GetEventReqDays(e.EventID) >= p.LengthOfStayTrigger))


DECLARE @OutlierTrigger INT
SET @OutlierTrigger = 0 
SELECT 	@OutlierTrigger = E.EVENTID
FROM 	EVENT E
INNER JOIN EventType ET ON e.EventTypeID = ET.EventTypeID AND HedisRPTType='IP'
INNER JOIN PlanSorgLog psl ON e.PlanSorgLogID = psl.PlanSorgLogID
INNER JOIN [Plan] P ON psl.PlanID = p.PlanID

WHERE ((dbo.GetLOS(@StartDate,@EndDate) > 
(SELECT LOSTR = CASE  P.OutlierTrigger
	WHEN '10' THEN e.LOS_10
	WHEN '25' THEN e.LOS_25
	WHEN '50' THEN e.LOS_50
	WHEN '75' THEN e.LOS_75
	WHEN '90' THEN e.LOS_90
	WHEN '95' THEN e.LOS_95
	WHEN '99' THEN e.LOS_99
	END
FROM [PLAN] P
INNER JOIN PLANSORGLOG ON P.PLANID=PLANSORGLOG.PLANID
INNER JOIN EVENT  E ON E.PLANSORGLOGID = PLANSORGLOG.PLANSORGLOGID
WHERE E.EVENTID=@eventid))
OR
(dbo.GetEventReqDays(e.EventID) > 
(SELECT LOSTR = CASE  P.OutlierTrigger
	WHEN '10' THEN e.LOS_10
	WHEN '25' THEN e.LOS_25
	WHEN '50' THEN e.LOS_50
	WHEN '75' THEN e.LOS_75
	WHEN '90' THEN e.LOS_90
	WHEN '95' THEN e.LOS_95
	WHEN '99' THEN e.LOS_99
	END
FROM [PLAN] P
INNER JOIN PLANSORGLOG ON P.PLANID=PLANSORGLOG.PLANID
INNER JOIN EVENT  E ON E.PLANSORGLOGID = PLANSORGLOG.PLANSORGLOGID
WHERE E.EVENTID=@eventid)))
AND
p.OutlierTrigger IS NOT NULL
AND 
(SELECT LOSTR = CASE  P.OutlierTrigger
	WHEN '10' THEN e.LOS_10
	WHEN '25' THEN e.LOS_25
	WHEN '50' THEN e.LOS_50
	WHEN '75' THEN e.LOS_75
	WHEN '90' THEN e.LOS_90
	WHEN '95' THEN e.LOS_95
	WHEN '99' THEN e.LOS_99
	END
FROM [PLAN] P
INNER JOIN PLANSORGLOG ON P.PLANID=PLANSORGLOG.PLANID
INNER JOIN EVENT  E ON E.PLANSORGLOGID = PLANSORGLOG.PLANSORGLOGID
WHERE E.EVENTID=@EVENTID) IS NOT NULL
AND e.EventID = @eventid


IF @CMTrigger > 0 AND @LOSTrigger > 0 AND @OutlierTrigger > 0
SET @Return = 'CM Flag, LOS, Outlier'
ELSE 
IF @CMTrigger  > 0 AND @LOSTrigger > 0 AND @OutlierTrigger = 0
SET @Return = 'CM Flag, LOS'
ELSE
IF @CMTrigger = 0 AND @LOSTrigger > 0 AND @OutlierTrigger > 0
SET @Return = 'LOS, Outlier'
ELSE
IF @CMTrigger = 0 AND @LOSTrigger = 0 AND @OutlierTrigger > 0
SET @Return = 'Outlier'
ELSE
IF @CMTrigger = 0 AND @LOSTrigger > 0 AND @OutlierTrigger = 0
SET @Return = 'LOS'
ELSE
IF @CMTrigger > 0 AND @LOSTrigger = 0 AND @OutlierTrigger = 0
SET @Return = 'CM Flag'
ELSE
IF @CMTrigger > 0 AND @LOSTrigger = 0 AND @OutlierTrigger > 0
SET @Return = 'CM Flag,  Outlier'
ELSE
IF @Return IS NULL
SET @Return ='NONE'

RETURN @Return

END








GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

