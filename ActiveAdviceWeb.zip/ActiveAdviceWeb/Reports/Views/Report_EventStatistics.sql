SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_EventStatistics]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_EventStatistics]
GO

CREATE         VIEW dbo.Report_EventStatistics
AS
SELECT


--CORRESPONDING OLD VIEW: HCC_RPT_153_V

e.EventID, 
e.PatientID, 
et.Code as EventTypeCode,
e.EndDate as EventEndDate,
ISNULL(et.[Description],'zNo Event Type') as EventTypeDescription,
ISNULL(et.HEDISRptType,'zNo Category') as HedisReportType, -- Event Category
	HedisReportDescription = 
	CASE 
	WHEN et.HEDISRptType = 'IP' THEN 'Inpatient'
	WHEN et.HEDISRptType = 'AMSX' THEN 'Ambulatory Surgery'
	WHEN et.HEDISRptType = 'OBSR' THEN 'Observation'
	WHEN et.HEDISRptType = 'OPVS' THEN 'Outpatient Visit'	
	WHEN et.HEDISRptType = 'ER' THEN 'Emergency Room'
	WHEN et.HEDISRptType = 'NA' THEN 'Not Applicable'
	ELSE ISNULL(et.HEDISRptType,'zNo Category')
	END,
psl.SorgID,
psl.SorgName,
psl.OrgID,
psl.OrgName,
psl.MorgID,
psl.MorgName,
p.PlanId, 
p.[Name] as PlanName

FROM Event e
INNER JOIN SystemStatus ss ON e.StatusID = ss.StatusID and ss.CodeStatus='CLOS'
LEFT JOIN EventType et ON e.EventTypeID = et.EventTypeID
LEFT JOIN dbo.Report_PatientSubscriberLog psl ON e.PatientSubscriberLogId = psl.PatientSubscriberLogId
LEFT JOIN [Plan] p ON psl.PlanId = p.PlanID

