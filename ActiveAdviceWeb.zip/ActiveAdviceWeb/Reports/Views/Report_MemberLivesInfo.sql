SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Report_MemberLivesInfo]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[Report_MemberLivesInfo]
GO

CREATE VIEW dbo.Report_MemberLivesInfo
AS
--This view calculates the Morg,Org,SorgLives info from MemberLives table and 
--It is used in 
--1. View MemberLivesPatientCount, 
--2. Hence View: Report_ReferralSummary 
SELECT vpsl.morgid, vpsl.orgid, vpsl.sorgid, sorgml.SorgLives, orgml.OrgLives, morgml.MorgLives, MORGCount.MorgPatientCount, ORGCount.orgPatientCount, SORGCount.SorgPatientCount
FROM dbo.Report_PatientSubscriberLog vpsl
LEFT JOIN (SELECT SorgID, SUM(TotalMembers) AS SorgLives FROM MemberLives GROUP BY SorgID) sorgml ON vpsl.SorgID = sorgml.SorgID
LEFT JOIN (SELECT OrgID, SUM(TotalMembers) AS OrgLives FROM MemberLives GROUP BY OrgID) orgml ON vpsl.OrgID = orgml.OrgID
LEFT JOIN (SELECT MorgID, SUM(TotalMembers) AS MorgLives FROM MemberLives GROUP BY MorgID) morgml ON vpsl.MorgID = morgml.MorgID
LEFT JOIN (SELECT PlanID, SUM(TotalMembers) AS PlanLives FROM MemberLives GROUP BY PlanID) planml ON vpsl.PlanID = planml.PlanID

LEFT JOIN (SELECT MorgID, COUNT(DISTINCT PatientID) AS MorgPatientCount FROM Report_ReferralSummaryClone GROUP BY MorgID) MORGCount ON vpsl.MorgID = MORGCount.MorgID
LEFT JOIN (SELECT orgID, COUNT(DISTINCT PatientID) AS orgPatientCount FROM Report_ReferralSummaryClone GROUP BY orgID) ORGCount ON vpsl.orgID = ORGCount.OrgID
LEFT JOIN (SELECT SorgID, COUNT(DISTINCT PatientID) AS SorgPatientCount FROM Report_ReferralSummaryClone GROUP BY sorgID) sORGCount ON vpsl.SorgID = SORGCount.SorgID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

