using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ActiveAdvice.Web;
using NetsoftUSA.WebForms;
using ActiveAdvice.DataLayer;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for MedicalNote.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.GuidelineMessages,DataLayer")]		// Define the message class for this module
	public class MedicalNote : BasePage
	{
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnCheckboxID;
		protected System.Web.UI.HtmlControls.HtmlInputHidden hdnNoteID;
		protected System.Web.UI.HtmlControls.HtmlTextArea txtNote;
		protected NetsoftUSA.WebForms.OBButton butSaveListItem;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBButton butCancelListItem;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
		this.hdnCheckboxID.Value =	Request.QueryString["CheckBox"];	// Put user code to initialize the page here
		this.hdnNoteID.Value = Request.QueryString["NoteID"];
			this.txtNote.Value = Request.QueryString["Note"];
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
