using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ActivityMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("AutoActivityInitializationValue,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@AUTOACTIVITYVALUES@")]
	public class ActivityValuesForm : BasePage
	{
		private AutoActivityRule autoActivityRule;
		private AutoActivityRuleException autoActivityRuleException;
		private AutoActivityInitializationValue autoActivityInitializationValue;
		private AutoActivityInitializationValueCollection autoActivityInitializationValueCol;

		protected TeamUserSelect TeamUserSelect1;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridAutoActivityValues;
		protected NetsoftUSA.WebForms.OBLabel lbRule;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAutoActivityValues;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAutoActivityValuesForm;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAAValuesUserTeam;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDateSource;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DateSource;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateSource;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDateOffset;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit DateOffset;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateOffset;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPriorityID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PriorityID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPriorityID;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCompletionID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CompletionID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompletionID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBLabel lbl1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAssignedUserType;
		protected NetsoftUSA.InfragisticsWeb.WebCombo AssignedUserType;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAssignedUserType;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDueTime;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DueTime;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;

		private void Page_Load(object sender, System.EventArgs e)
		{
			//TeamUser select
			this.TeamUserSelect1.RebindControls(typeof(AutoActivityInitializationValue), "AssignedTeamID", "AssignedUserID");

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				autoActivityRule = (AutoActivityRule)this.LoadObject(typeof(AutoActivityRule));	// This would reload from cache
				autoActivityRuleException = (AutoActivityRuleException)this.LoadObject(typeof(AutoActivityRuleException));	
				autoActivityInitializationValue = (AutoActivityInitializationValue)this.LoadObject(typeof(AutoActivityInitializationValue));
				autoActivityInitializationValueCol = (AutoActivityInitializationValueCollection)this.LoadObject(typeof(AutoActivityInitializationValueCollection));

			}

		}

		
		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			try
			{	// use any load method here
				autoActivityRule = this.GetParamOrGetFromCache("AutoActivityRule",typeof(AutoActivityRule)) as AutoActivityRule;
				autoActivityRuleException = this.GetParamOrGetFromCache("AutoActivityRuleException",typeof(AutoActivityRuleException)) as AutoActivityRuleException;	
				autoActivityInitializationValue = this.GetParamOrGetFromCache("AutoActivityInitializationValue",typeof(AutoActivityInitializationValue)) as AutoActivityInitializationValue;

				if(autoActivityRule==null && autoActivityRuleException==null)
				{
					this.SetPageMessage("@LINKERRORMSG@", EnumPageMessageType.Info);
					result = false;
				}
				if (autoActivityInitializationValueCol==null)
				{
					autoActivityInitializationValueCol = new AutoActivityInitializationValueCollection();
					if(autoActivityRule!=null)
						autoActivityInitializationValueCol.LoadAllActivityValuesByRuleId(-1,autoActivityRule.RuleId);
					if(autoActivityRuleException!=null)
						autoActivityInitializationValueCol.LoadAllActivityValuesByExceptId(-1,autoActivityRuleException.ExceptionId);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//referral.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!			
			}
			this.AutoActivityInitializationValueCol=autoActivityInitializationValueCol;
			return result;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
			SetPageToolbarItemVisible("Save", false);
			if(autoActivityInitializationValue!=null)
			{
				SetPageToolbarItemVisible("Save", true);				
			}
		}

		public static void Redirect()
		{
			BasePage.Redirect("ActivityValuesForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{   
			this.gridAutoActivityValues.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridAutoActivityValues_ClickCellButton);
			this.gridAutoActivityValues.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridAutoActivityValues_ColumnsBoundToDataClass);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			if(autoActivityRuleException==null)
				pageSummary.RenderObjects(this.autoActivityRule);
			else
				pageSummary.RenderObjects(this.autoActivityRuleException.ParentAutoActivityRuleExceptionCollection.ParentAutoActivityRule,this.autoActivityRuleException);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			switch (tab.Key)
			{
				case "ActivityValues":
					toolbar.AddButton("@ADDNEWRECORD@", "AddActivityValue");
					break;
			}
		}
		
		public void OnToolbarButtonClick_AddActivityValue(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewActivityValue();
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
	
			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@SAVERECORD@", "Save").Visible = false;
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@AUTOACTIVITYVALUE@");
			}
		}

		public void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if(autoActivityInitializationValue==null)
				AutoActivityForm.Redirect(autoActivityRule);
			else
			{
				autoActivityInitializationValue = null;
				this.AutoActivityInitializationValue = autoActivityInitializationValue;
			}
		}

		private void gridAutoActivityValues_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridAutoActivityValues.AddButtonColumn("Edit","EDIT",0);
		}

		private void gridAutoActivityValues_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			//string colName = grid.GetColumnKeyFromCellEvent(e);
			string colName = e.Cell.Key;
			if (colName == "Edit")
			{
				int pk =(int)(e.Cell.Row.DataKey);
				try
				{
					autoActivityInitializationValue = (AutoActivityInitializationValue)autoActivityInitializationValueCol[pk];
					this.AutoActivityInitializationValue = autoActivityInitializationValue;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>	
		public AutoActivityInitializationValue AutoActivityInitializationValue
		{
			get { return autoActivityInitializationValue; }
			set
			{
				autoActivityInitializationValue = value;
				try
				{
					if(autoActivityInitializationValue==null)
					{
						// show list
						AutoActivityInitializationValueCollection autoActivityInitializationValueCol = new AutoActivityInitializationValueCollection();						
						autoActivityInitializationValueCol = new AutoActivityInitializationValueCollection();
						if(autoActivityRule!=null)
							autoActivityInitializationValueCol.LoadAllActivityValuesByRuleId(-1,autoActivityRule.RuleId);
						if(autoActivityRuleException!=null)
							autoActivityInitializationValueCol.LoadAllActivityValuesByExceptId(-1,autoActivityRuleException.ExceptionId);
						
						this.AutoActivityInitializationValueCol = autoActivityInitializationValueCol;
					}
					else
					{
						// new or edit group
						this.UpdateFromObject(pnlAutoActivityValuesForm.Controls, autoActivityInitializationValue);  // update controls for the given control/collection
						this.UpdateFromObject(pnlAAValuesUserTeam.Controls, autoActivityInitializationValue);  // update controls for the given control/collection

						this.pnlAutoActivityValues.Visible = false; 
						this.pnlAutoActivityValuesForm.Visible = true;
						this.pnlAAValuesUserTeam.Visible = true;
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AutoActivityInitializationValue), autoActivityInitializationValue);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AutoActivityInitializationValueCollection AutoActivityInitializationValueCol
		{
			get { return autoActivityInitializationValueCol; }
			set
			{
				autoActivityInitializationValueCol = value;
				try
				{
					this.gridAutoActivityValues.UpdateFromCollection(autoActivityInitializationValueCol);
					this.UpdateFromObject(this.pnlAutoActivityValues.Controls,autoActivityInitializationValueCol);	
					// this panel is using to fill combobox

					this.pnlAutoActivityValues.Visible = true; 
					this.pnlAutoActivityValuesForm.Visible = false;
					this.pnlAAValuesUserTeam.Visible = false;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AutoActivityInitializationValueCollection), autoActivityInitializationValueCol);  // cache object using the caching method declared on the page
				this.CacheObject(typeof(AutoActivityRule), autoActivityRule);  // cache object using the caching method declared on the page
				this.CacheObject(typeof(AutoActivityRuleException), autoActivityRuleException);  // cache object using the caching method declared on the page
			}
		}


		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlAutoActivityValuesForm.Controls, autoActivityInitializationValue);
				this.UpdateToObject(this.pnlAAValuesUserTeam.Controls, autoActivityInitializationValue);
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(AutoActivityRule autoActivityRule,AutoActivityRuleException autoActivityRuleException)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("AutoActivityRule", autoActivityRule);			
			BasePage.PushParam("AutoActivityRuleException", autoActivityRuleException);
			BasePage.Redirect("ActivityValuesForm.aspx");		
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				if(autoActivityRule!=null)
				{
					if(autoActivityInitializationValue.IsNew)
					{
						if(autoActivityRule.AutoActivityInitializationValues==null)							
							autoActivityRule.LoadAutoActivityInitializationValues(false);
						autoActivityRule.AutoActivityInitializationValues.AddRecord(autoActivityInitializationValue);
					}

					autoActivityInitializationValue.Save();
				}

				if(autoActivityRuleException!=null)
				{
					if(autoActivityInitializationValue.IsNew)
					{
						if(autoActivityRuleException.AutoActivityInitializationValues==null)
							autoActivityRuleException.LoadAutoActivityInitializationValues(false);
						autoActivityRuleException.AutoActivityInitializationValues.AddRecord(autoActivityInitializationValue);
					}
				}

				autoActivityInitializationValue.Save(); // only need to save the one that has changed

				autoActivityInitializationValue = null;
				this.AutoActivityInitializationValue = autoActivityInitializationValue;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}		

		public bool NewActivityValue()
		{
			bool result = true;
			try
			{	
				AutoActivityInitializationValue autoActivityInitializationValue = new AutoActivityInitializationValue(true); // use a parameterized constructor which also initializes the data object				
				this.AutoActivityInitializationValue = autoActivityInitializationValue;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}			
			return result;
		}
	}
}
