using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using System.Diagnostics;
using System.Data.SqlTypes;
using Tx4oleLib;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterSearch.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseFaxQueue,DataLayer")]
	public class FaxPreviewForm : Page
	{
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label LabelQueueID;
		protected System.Web.UI.WebControls.TextBox __TEXTFAXARGS;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;


		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!IsPostBack)
			{
				if (this.Request.QueryString["Mode"] == ""
					|| this.Request.QueryString["PARAM1"] == "")
					return;

				string strArgs = "FaxPreview2.aspx?" + "MODE=" 
											+ this.Request.QueryString["Mode"]
										+ "&PARAM1="
										+ this.Request.QueryString["PARAM1"];

				this.LabelQueueID.Text = this.Request.QueryString["PARAM1"];
				this.Label1.Text = "Letter:";
				this.__TEXTFAXARGS.Text  = strArgs;
			}
		}

		private string mode = "VIEWLOG";
		private string param1 = "";

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


	}
}
