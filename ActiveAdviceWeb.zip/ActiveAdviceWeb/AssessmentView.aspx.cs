using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Text;


namespace ActiveAdvice.Web
{
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Assessment,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[PageTitle("@ASMTVIEWPAGETITLE@")]
	public class AssessmentView : PatientBasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAssessment;
		protected AssessmentLayout AL;
		protected AssessmentContext assessmentContext;

		protected Title Title1;

		private CMS cMS;
		private string assessmentGUID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAssessmentDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAssessmentDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit AssessmentDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAssessmentDate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveDetails;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelDetails;
		private bool saveRequested = false;
		private bool printRequested = false;
		private bool printWResponsesRequested = false;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDummySave;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnDummySaveAndPrintLetters;
		private bool letterGenerationRequested = false;

		public AssessmentContext AssessmentContext
		{
			get { return assessmentContext; }
			set
			{
				assessmentContext = value;
				this.CacheObject(typeof(AssessmentContext), assessmentContext);	
			}
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				LoadData();
			}
			else
			{
				cMS = (CMS)this.LoadObject(typeof(CMS));
				assessmentContext = (AssessmentContext)this.LoadObject(typeof(AssessmentContext));
				this.AssessmentContext = assessmentContext;
			}
			
			// For some reason we came here with no questionnaires
			if(assessmentContext.QuestionnaireOrders.Count == 0)
			{
				// Let's redirect to the questionnaire pick page
				AssessmentForm.Redirect(assessmentContext);
			}

			AL.AssessmentContext = assessmentContext;
			this.pnlAssessmentDetails.Visible = false;

			EnsureChildControls();
		}

		private void LoadData()
		{
			try
			{
				cMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;
				if (cMS == null)
				{
					this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a CMS"));
					return;
				}
				this.CacheObject(typeof(CMS), cMS);

				assessmentContext = GetParamOrGetFromCache("ASSESSMENTCONTEXT", typeof(AssessmentContext)) as AssessmentContext;
				//this.AssessmentContext = assessmentContext;

				if (assessmentContext == null)
				{
					this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a CMS"));
					return;
				}
				
				// Scroll to where we left off
				this.ScrollToPosition(this.assessmentContext.HPos, this.assessmentContext.VPos);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
			finally
			{
				//obj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.AssessmentContext = assessmentContext;		// When you set the object to the property, controls are automatically populated
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			// Set this so that the sub menu click won't trigger is dirt check.
			this.DoNotCheckIsDirtWhenInPatientContext = true;
			base.PopulateSubNavigation (listbar);
		}


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			if (tab.Key == "ASMT_Assessment")
			{
				toolbar.AddButton("@PICKQUESTIONNAIRES@", "PickQuestionnaires", true, false);
				toolbar.AddButton("@PRINTLETTERS@", "PrintLetters", true, false);
				toolbar.AddButton("@PRINTASSESSMENT@", "PrintAssessment", true, false);
				toolbar.AddButton("@PRINTASSESSMENTWRESPONSES@", "PrintAssessmentWResponses", true, false);
				toolbar.AddButton("@CHANGEASSESSMENTDATE@", "ChangeDate", true, false);
			}
		}

		public void OnToolbarButtonClick_PickQuestionnaires(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// cache the assessmentcontext
			this.AssessmentContext = assessmentContext;

			AssessmentForm.Redirect(assessmentContext);
		}

		public void OnToolbarButtonClick_PrintLetters(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				letterGenerationRequested = true;
			}
		}

		private void PrintLetters()
		{
			LetterGenerator letterGenerator = new LetterGenerator();
			
			try
			{
				if (letterGenerator.GenerateAssessmentLetters(this.assessmentContext))
					this.SetPageMessage("Assessment letters have been generated successfully.", EnumPageMessageType.AddInfo);
				else
					this.SetPageMessage("There are no assessment letters to be generated.", EnumPageMessageType.AddInfo);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		public void OnToolbarButtonClick_PrintAssessment(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				printRequested = true;
			}
		}

		public void OnToolbarButtonClick_PrintAssessmentWResponses(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				printWResponsesRequested = true;
			}
		}


		private void PrintAssessment()
		{
			if (printRequested)
				this.CacheObject("ReportName", "RPTASSESSMENTPRINT");
			else
				this.CacheObject("ReportName", "RPTASSESSMENTRESPONSEPRINT");
		
			ReportParameters reportParameters = new ReportParameters();
			reportParameters.AssessmentGUID = assessmentContext.AssessmentGUID;
			this.CacheObject(typeof(ReportParameters), reportParameters);

			this.RegisterOnLoadScript("assessmentreport",  "PrintAssessment();\n");
		}


		public void OnToolbarButtonClick_ChangeDate(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.pnlAssessmentDetails.Visible = true;
			this.UpdateFromObject(this.pnlAssessmentDetails.Controls, assessmentContext.Assessment);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// NOTE: We're not using this method anymore
			// To be able to print the letter generation prompt we use a dummy button
				
			SaveEvent();
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			CMS cMS = this.assessmentContext.CMS;

			if (this.assessmentContext.IsNew)
				this.assessmentContext.Cancel();
			
			this.AssessmentContext = null;
			this.CacheObject(typeof(Assessment), null);
			Assessments.Redirect(cMS);
		}

		public void OnToolbarButtonClick_BackToCMS(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// cache the assessmentcontext
			this.AssessmentContext = assessmentContext;

			CaseManagementForm.Redirect(this.assessmentContext.CMS);
		}

		private bool SaveData()
		{
			try
			{
				assessmentContext.Assessment.MarkDirty();
				assessmentContext.Assessment.Save();

				assessmentContext.Responses.UpdatePatientLevelOfDiseases();
				assessmentContext.Responses.UpdatePatientRisks();

				assessmentContext.Responses = null;
				
				assessmentContext.QuestionNotes.Save();
				assessmentContext.CMS.SavePOCDeficits();
				assessmentContext.CMS.LoadPOCDeficits(true);

				assessmentContext.QuestionNotes = null;

				assessmentContext.CMS.Patient.SavePatientMedications();
				assessmentContext.CMS.Patient.SavePatientMeasurements();
				assessmentContext.CMS.Patient.SavePatientAllergies();

				assessmentContext.CMS.Patient.LoadPatientMedications(true);
				assessmentContext.CMS.Patient.LoadPatientMeasurements(true);
				assessmentContext.CMS.Patient.LoadPatientAllergies(true);

				if (assessmentContext.MaterniChekCreated)
				{
					assessmentContext.CMS.Maternichek.Save();
					assessmentContext.MaterniChekCreated = false;
				}

				// This has already been saved in UpdatePatientRisks
				assessmentContext.CMS.LoadCMSStatusHistories(true);
				
				// Reload assessment collection
				assessmentContext.CMS.LoadAssessments(true);

				if (assessmentContext.IsNew)
				{
					assessmentContext.Assessment.UpdateScoringLoadQuestionnaires();
				}

				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@ASSESSMENT@");

				saveRequested = true;
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				saveRequested = false;
				return false;
			}
			finally
			{
				assessmentContext.IsNew = false;
				this.AssessmentContext = assessmentContext;
			}
		}





		public static void Redirect(AssessmentContext assessmentContext)
		{
			BasePage.PushParam("ASSESSMENTCONTEXT", assessmentContext);
			PushTargetTab("ASMT_Assessment");
			BasePage.Redirect("AssessmentView.aspx");
		}

        
		
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(assessmentContext.CMS, assessmentContext.CMS.Patient, assessmentContext.Assessment);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			if (saveRequested)
			{
				try
				{
					if (SaveData())
					{
						if (letterGenerationRequested)
						{
							PrintLetters();
						}
						else if (printRequested || printWResponsesRequested)
						{	
							PrintAssessment();
						}
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}

			this.SetERCTabVisibilities();
			SetPageTabItemActive(TargetTabKey);

			if (assessmentContext.IsNew)
				this.SetPageToolbarItemText("Cancel", "@CANCEL@");
			else
				this.SetPageToolbarItemText("Cancel", "@CLOSE@");

			this.SetPageToolbarItemVisible("Save", !assessmentContext.IsReadOnly);
			this.SetPageToolbarItemTargetURL("Save", "javascript:AskForLetterGenAndSave();");

			this.SetPageTabToolbarItemEnabled("PickQuestionnaires", !assessmentContext.IsReadOnly);
			this.SetPageTabToolbarItemEnabled("ChangeDate", !assessmentContext.IsReadOnly);


			this.RegisterClientScriptBlock("AskForLetterGenAndSave", @"
			<script language=""javascript"">
			function AskForLetterGenAndSave()
			{
				ret = confirm(""Would you like to generate letters (if any) after the saving the assessment?"");
				if (ret)
					GetElem('" + this.wbtnDummySaveAndPrintLetters.ClientID + @"').click();
				else
					GetElem('" + this.wbtnDummySave.ClientID + @"').click();
			}
			</script>
			");


			this.assessmentContext.VPos = this.VPos;
			this.assessmentContext.HPos = this.HPos;
			this.AssessmentContext = assessmentContext;
		}

		protected override void Render(HtmlTextWriter writer)
		{
			base.Render (writer);
		}



		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(assessmentContext.Responses, assessmentContext.QuestionNotes, assessmentContext.Assessment, assessmentContext.ITemplates);
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.Title1.PageValidationSummary.Visible = true;
			this.Title1.PageValidationSummary.HeaderText = "Please correct following errors:";
			this.Title1.PageValidationSummary.ShowSummary = false;
			this.Title1.PageValidationSummary.DisplayMode = ValidationSummaryDisplayMode.BulletList;
			this.Title1.PageValidationSummary.ShowMessageBox = true;
			this.DirtyCheckEnabledForTabChange = false;
			this.wbtnDummySave.Click += new System.EventHandler(this.wbtnDummySave_Click);
			this.btnSaveDetails.Click += new System.EventHandler(this.btnSaveDetails_Click);
			this.btnCancelDetails.Click += new System.EventHandler(this.btnCancelDetails_Click);
			this.wbtnDummySaveAndPrintLetters.Click += new System.EventHandler(this.wbtnDummySaveAndPrintLetters_Click);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.AutoScroll = true;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnSaveDetails_Click(object sender, System.EventArgs e)
		{
			this.UpdateToObject(this.pnlAssessmentDetails.Controls, assessmentContext.Assessment);
			this.AssessmentContext = assessmentContext; 
			this.pnlAssessmentDetails.Visible = false;
		}

		private void btnCancelDetails_Click(object sender, System.EventArgs e)
		{
			this.pnlAssessmentDetails.Visible = false;
		}

		private void wbtnDummySave_Click(object sender, System.EventArgs e)
		{
			SaveEvent();
		}

		private void wbtnDummySaveAndPrintLetters_Click(object sender, System.EventArgs e)
		{
			this.letterGenerationRequested = true;
			SaveEvent();
		}

		private void SaveEvent()
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@ASSESSMENT@ ");
			}

			// saveRequested = true;
			//this.ScrollToTop();
		}

			
	}
}
