
// This file contains java script used by the DropDownCalendar.aspx form.
//
// flag to avoid multiple listeners to same mouse-down event
var globalListenerWasCreated = false;
// optional references to drop-down calendars
// Notes: in case of single global calendar it can be replaced by a simple object instead of array
//  or it can be not used at all: igcal_getCalendarById("SharedCalendar") will return calendar object dynamically.
var dropDownCalendars = new Array();
// it is called when drop-down calendar is initialized
// Note: that name should match with the ClientSideEvents.InitializeCalendar property
//  which is set in aspx for WebCalendar
function initCalendarEvent(oCalendar)
{
	// ensure absolute position
	// Note: it can be skipped if style in aspx has that
	oCalendar.element.style.position = "absolute";
	// assume that calendar on start is visible
	// create boolean member variable, which simplifies visibility test
	oCalendar.isDisplayed = true;
	// optional global cash of calendar-reference
	// Note: igcal_getCalendarById("SharedCalendar") or something like that
	//  can be used instead of dropDownCalendars[0]
	dropDownCalendars[dropDownCalendars.length] = oCalendar;
	oCalendar.setSelectedDate(oCalendar.oEdit.getDate());
	// hide drop-down calendar
	//showDropDown(oCalendar, null, false);
}
// it is called by date click events of WebCalendar
// Note: that name should match with the ClientSideEvents.DateClicked property
//  which is set in aspx for WebCalendar
function calendarDateClickedEvent(oCalendar, oDate, oEvent)
{
	
	// update editor with latest date and hide calendar
	showDropDown(oCalendar, oDate, false, true);
	
	var oCoverFrame = document.getElementById("cover_calendar");
	if (oCoverFrame != null)
		oCoverFrame.style.display = "none";
}
// it is called by custom-button click event of WebDateTimeEdit
// Note: that name should match with the ClientSideEvents.CustomButtonPress property
//  which is set in aspx for WebDateTimeEdit
function openDropDownEvent(oEdit, text, oEvent)
{
	// open drop-down calendar
	openDropDown(oEdit, dropDownCalendars[0]);
	// Note: if dropDownCalendars is not used, then following commented line
	//  can be used instead of line above
	//openDropDown(oEdit, igcal_getCalendarById("SharedCalendar"));
}
// it is called by spin and focus events of WebDateTimeEdit
// Note: that name should match with the ClientSideEvents.KeyDown/Spin/Focus/etc. properties
//  which are set in aspx for WebDateTimeEdit
function closeDropDownEvent(oEdit, text, oEvent)
{
	
	// hide calendar
	showDropDown(oEdit.oCalendar, null, false);
	var oCoverFrame = document.getElementById("cover_calendar");
	oCoverFrame.style.display = "none";
}
// open calendar and attach it to WebDateTimeEdit
// oEdit - reference to the owner of calendar (WebDateTimeEdit)
// oCalendar - the WebCalendar which should be dropped and attached to oEdit
function openDropDown(oEdit, oCalendar)
{
	if(oCalendar == null) return;
	// add listener to mouse click events for page
	if(!globalListenerWasCreated)
		ig_csom.addEventListener(window.document, "mousedown", globalMouseDown, false);
	
	globalListenerWasCreated = true;
	// set reference of calendar to editor:
	// create member variable, which points to drop-down calendar
	oEdit.oCalendar = oCalendar;
	// if it belongs to another oEdit, then close oCalendar
	if(oCalendar.oEdit != oEdit)
	{
		showDropDown(oCalendar, null, false);
		// set reference in oCalendar to this oEdit
		// create member variable, which points to the owner oEdit
		oCalendar.oEdit = oEdit;
	}
	// show calendar with date from editor
	// if calendar is already opened, then hide calendar (last param)
	
	showDropDown(oCalendar, oEdit.getDate(), true, true, true);
}
// synchronize dates in DateEdit and calendar, and show/close calendar
function showDropDown(oCalendar, date, show, update, toggle)
{
	if(oCalendar == null) return;
	if(toggle == true && oCalendar.isDisplayed == true)
		show = update = false;
	// update editor with latest date
	if(update == true)
	{
		if(oCalendar.isDisplayed)
		{			
			oCalendar.oEdit.setDate(date);
			ValidatorValidateIndividual(oCalendar.oEdit.ID);
			SetDirty(oCalendar.oEdit.ID);
		}	
		else
		{
			if (oCalendar.oEdit.getDate() == null)
				oCalendar.setSelectedDate(new Date());
			else			
				oCalendar.setSelectedDate(oCalendar.oEdit.getDate());
		}
	}
	// check current state of calendar
	if(oCalendar.isDisplayed == show)
		return;
	// show/hide calendar
	oCalendar.element.style.display = show ? "block" : "none";
	oCalendar.element.style.visibility = show ? "visible" : "hidden";
	var oCoverFrame = document.getElementById("cover_calendar");
	oCoverFrame.style.display = show ? "inline" : "none";
	oCalendar.isDisplayed = show;
	if(show)
		positionCalendar(oCalendar);
}
// set position of calendar below DateEdit
function positionCalendar(oCalendar)
{
	var elem = oCalendar.oEdit.Element;
	// left and top position of calendar
	var x = 0, y = elem.offsetHeight;
	if(y == null) y = 0;
	// width and height of super parent (document)
	var w = 0, h = 0;
	while(elem != null)
	{
		if(elem.offsetLeft != null) x += elem.offsetLeft;
		if(elem.offsetTop != null) y += elem.offsetTop;
		h = elem.offsetHeight;
		w = elem.offsetWidth;
		elem = elem.offsetParent;
	}
	// check if calendar fits below editor
	// if not, then move it above editor
	elem = oCalendar.element;
	//if(y + elem.offsetHeight > h)
	if(y > h + oCalendar.oEdit.Element.offsetHeight + window.document.body.scrollTop - y)
		y -= (elem.offsetHeight + oCalendar.oEdit.Element.offsetHeight);
	// check if calendar fits on the right from editor
	// if not, then move it to the left
	// 20 - extra shift for possible vertical scrollbar in browser
	//if(x + elem.offsetWidth + 20 > w)
	//	x = w - elem.offsetWidth - 20;
	if(x + elem.offsetWidth + 20 > w + window.document.body.scrollLeft)
		x = w - elem.offsetWidth - 20 + window.document.body.scrollLeft;
	oCalendar.element.style.left = x + "px";
	oCalendar.element.style.top = y + "px";
	// -- Get Iframe.
	oCoverFrame = document.getElementById("cover_calendar");

	// -- Set Right and Top corners of iframe.
	oCoverFrame.style.top    = oCalendar.element.style.top;
	oCoverFrame.style.display = "inline";
	oCoverFrame.style.zIndex  = 100;
	oCalendar.element.style.zIndex = oCoverFrame.style.zIndex + 1;
	oCoverFrame.style.left   = oCalendar.element.style.left;
}
// process mouse click events for page: close drop-down
function globalMouseDown(evt)
{
	// reference to visible dropped-down calendar
	var oCalendar = null;
	// Note: 2 commented lines below can be used instead of a loop,
	//  if dropDownCalendars is not used and a single global calendar with id "SharedCalendar" is used
	//oCalendar = igcal_getCalendarById("SharedCalendar");
	//if(oCalendar != null && !oCalendar.isDisplayed) oCalendar = null;
	var i = dropDownCalendars.length;
	for(var i = 0; i < dropDownCalendars.length; i++) if(dropDownCalendars[i].isDisplayed)
	{
		oCalendar = dropDownCalendars[i];
		break;
	}
	// check if opened calendar was found
	if(oCalendar == null)
		return;
	// find source element
	if(evt == null) evt = window.event;
	if(evt != null)
	{
		var elem = evt.srcElement;
		if(elem == null) if((elem = evt.target) == null) o = this;
		while(elem != null)
		{
			// ignore events that belong to calendar
			if(elem == oCalendar.element) return;
			elem = elem.offsetParent;
		}
	}
	// close calendar
	showDropDown(oCalendar, null, false, false);
	
}



/////////////////////////////////////////////////
/// Validation, Grouping and IsDirty related stuff
/////////////////////////////////////////////////

function ig_UpdateDisplay(id, controlType){

var BackColor, BorderColor, ForeColor;

var isValid = true;
var tooltip = "";
var dontTouch = true; // if there is no validator attached to the control don't try to change it's appearance
					  // because it's unnecessary and also the page might be in viewonly mode	

if (typeof(Page_Validators) != "undefined")
{
	for (i = 0; i < Page_Validators.length; i++) {
		if (Page_Validators[i].enabled != false && Page_Validators[i].controltovalidate == id)
		{
			dontTouch = false;
			if (Page_Validators[i].isvalid != "undefined" && !Page_Validators[i].isvalid) 
			{
				isValid = false;
				tooltip += Page_Validators[i].errormessage;
			}
		}
	}
}

if (dontTouch) return true;

if (isValid)
{
BackColor = "white";
BorderColor = "#7F9DB9";
ForeColor = "black";
}
else
{
BackColor = "red";
BorderColor = "red";
ForeColor = "black";
}


switch(controlType)
{
    case "WebCombo":
        var oControl = igcmbo_getComboById(id); 
    break;
    case "WebTextEdit":
    case "WebNumericEdit":
    case "WebMaskEdit":
    case "WebDateTimeEdit":
    case "WebCurrencyEdit":
        var oControl = igedit_getById(id); 
    break;
    case "WebCalendar":
        var oControl = igcal_getCalendarById(id); 
    break;
    case "WebDateChooser":
        var oControl = igdrp_getComboById(id); 
    case "OBTextBox":
		var oControl = GetElem(id);
	// FORK 1.1	
	case "OBComboBox":
		var oControl = GetElem(id + '_Border');
	break;
	default:
		//var oControl = GetElem(id);
		// We don't know what to do with this control
		// Return false so that the regular error message display takes place
		return false;
    break;
}
try
{
	if (oControl)
	{
		if (oControl.Element)
		{
			oControl.Element.style.borderWidth = "1px";
			oControl.Element.style.borderColor = BorderColor;
			oControl.Element.style.color = ForeColor;
			oControl.Element.title = tooltip;
		}
		else
		{
			if (controlType == "OBComboBox" && isValid)
			{
				oControl.style.borderStyle = "none";
			}
			else
			{	
				oControl.style.borderWidth = "1px";
				//oControl.style.borderTopStyle = "solid";
				oControl.style.borderColor = BorderColor;
				oControl.style.padding = "0px";
				oControl.style.color = ForeColor;
				oControl.title = tooltip;
			}
		}
	}
}
catch(oException)
{
}

return true;

}


function WebCombo_AfterSelectChange(webComboId)
{
	SetDirty(webComboId);
}

function WebCombo_EditKeyUp(id, newValue, keyCode) 
{
	SetDirty(id);
}

function WebCombo_UpdatePostField(value)
{
	//if (value != ValidatorGetComboValue(this))
		ValidatorValidateIndividual(this.ClientUniqueId); 
	
	this.oldupdatePostField(value);
}

function WebCombo_InitializeCombo(id)
{
	// We need to intercept the updatepostfield call to be able to validate the control
	// We do this by creating a new function pointer on the object
	var oWebCombo1 = igcmbo_getComboById(id);
	oWebCombo1.oldupdatePostField = oWebCombo1.updatePostField;
	oWebCombo1.updatePostField = WebCombo_UpdatePostField;
	oWebCombo1.FreeTextAllowed = false;
	oWebCombo1.Element.style.borderColor = "#7F9DB9";
	
	return oWebCombo1;
}

function WebCombo_InitializeEditableCombo(id)
{
	var oWebCombo1 = WebCombo_InitializeCombo(id);
	oWebCombo1.FreeTextAllowed = true;
}

function WebDateTimeEdit_ValueChange(oEdit, oldValue, oEvent) 
{
	ValidatorValidateIndividual(oEdit.ID);
	SetDirty(oEdit.ID);
}

function WebCurrencyEdit_ValueChange(oEdit, oldValue, oEvent) 
{
	ValidatorValidateIndividual(oEdit.ID);
	SetDirty(oEdit.ID);
}

function WebMaskEdit_ValueChange(oEdit, oldValue, oEvent) 
{
	ValidatorValidateIndividual(oEdit.ID);
	SetDirty(oEdit.ID);
}

function WebNumericEdit_ValueChange(oEdit, oldValue, oEvent) 
{
	ValidatorValidateIndividual(oEdit.ID);
	SetDirty(oEdit.ID);
}

function WebTextEdit_ValueChange(oEdit, oldValue, oEvent) 
{
	ValidatorValidateIndividual(oEdit.ID);
	SetDirty(oEdit.ID);
}



function WebDateTimeEdit_TextChanged(oEdit, newText, oEvent) 
{
	SetDirty(oEdit.ID);
}

function WebCurrencyEdit_TextChanged(oEdit, newText, oEvent) 
{
	SetDirty(oEdit.ID);
}

function WebMaskEdit_TextChanged(oEdit, newText, oEvent)
{
	SetDirty(oEdit.ID);
}

function WebNumericEdit_TextChanged(oEdit, newText, oEvent) 
{
	SetDirty(oEdit.ID);
}

function WebTextEdit_TextChanged(oEdit, newText, oEvent) 
{
	SetDirty(oEdit.ID);
}

function WebGrid_AfterCellUpdate(gridName, cellId)
{
	SetDirty(gridName);
}

function WebGrid_InitializeLayout(gridName)
{
	var row = igtbl_getActiveRow(gridName);
	if (row)
	{
		igtbl_clearSelectionAll(gridName);
		igtbl_selectRow(gridName, row.Id, true, false);
	}
}

function WebCalendar_ValueChanged(oCalendar, oDate, oEvent)
{
/*
	if (oCalendar.oEdit && (( "" + oCalendar.getSelectedDate()) != ("" + oCalendar.oEdit.getDate())))
	{
		ValidatorValidateIndividual(oCalendar.oEdit.ID);
		SetDirty(oCalendar.oEdit.ID);
	}
*/	
}

function WebCalendar_ValueChanging(oCalendar, oDate, oEvent)
{
/*
alert(oDate);
alert(oCalendar.oEdit.getDate());
	if (oCalendar.oEdit && (( "" + oDate) != ("" + oCalendar.oEdit.getDate())))
	{
		SetDirty(oCalendar.oEdit.ID);
	}
*/	
}




function WebListBar_BeforeItemSelected(oListbar, oItem, oEvent)
{
   if (Page_Controls[oItem.Key][ControlChecksForDirtyIndex] && !DisplayIsDirtyWarning())
   {
  	  oEvent.cancel = true;
	  oEvent.cancelPostBack = true;
      return;
   }
   Page_IsSubmitted = true;
}

function WebTab_BeforeSelectedTabChange(oWebTab, oTab, oEvent)
{
	var currentKey = oWebTab.getSelectedTab().Key;
	var newKey = oTab.Key;

	var currentTabGroup = ""; 
	var newTabGroup = "";
	
	// Let's see if the groups support Tab Grouping
	if (currentKey.indexOf("_") > 0) currentTabGroup = currentKey.substring(0, currentKey.indexOf("_"));
	if (newKey.indexOf("_") > 0) newTabGroup = newKey.substring(0, newKey.indexOf("_"));
		
	// If we're switching between groups that means we need postback
	if (currentTabGroup != newTabGroup)
	{
		// But before we need to check for validation
		Page_GroupToValidate = "default";	
		if (typeof(Page_ClientValidate) == 'function' && !Page_ClientValidate())  
		{
			oEvent.cancel = true;
			oEvent.cancelPostBack = true;
			return;
		}
		
		// And we need to check for isdirty as well
		if (Page_CheckDirtyForTabChange == true && !DisplayIsDirtyWarning())
		{
  			oEvent.cancel = true;
			oEvent.cancelPostBack = true;
			return;
		}   
		
		// This will trigger a post back to the server	
		oEvent.needPostBack = true;
	}

}


function Toolbar_Click(oToolbar, oButton, oEvent)
{
   if (Page_Controls[oButton.Key][ControlCausesValidationIndex])
   {
		Page_GroupToValidate = Page_Controls[oButton.Key][ControlGroupIndex];
	
		if (typeof(Page_ClientValidate) == 'function' && !Page_ClientValidate())  
		{
			oEvent.cancel = true;
			oEvent.cancelPostBack = true;
			return;
		}
   }
   
   	if (typeof(Page_Toolbar_Click) == 'function')
	{
		if (Page_Toolbar_Click(oToolbar, oButton, oEvent) == false)
			return;
	}
   
   if (Page_Controls[oButton.Key][ControlChecksForDirtyIndex] && !DisplayIsDirtyWarning())
   {
  	  oEvent.cancel = true;
	  oEvent.cancelPostBack = true;
      return;
   }   
   
   Page_IsSubmitted = true;
}


function OBButton_OnClick(buttonID)
{
   Page_GroupToValidate = Page_Controls[buttonID][ControlGroupIndex];

   if (Page_Controls[buttonID][ControlChecksForDirtyIndex] && !DisplayIsDirtyWarning())
   {
      return false;
   }
   else
   {
//	  Page_CheckDirty = false;
	  Page_IsSubmitted = true;
	  return true;	  
   }
   
/*   
   if (Page_Controls[oButton.Key][ControlCausesValidationIndex])
   {
		Page_GroupToValidate = Page_Controls[oButton.Key][ControlGroupIndex];
	
		if (typeof(Page_ClientValidate) == 'function' && !Page_ClientValidate())  
		{
			oEvent.cancel = true;
			oEvent.cancelPostBack = true;
		}
   }
*/  
}


function OBTextBox_OnChange(textboxID)
{
	SetDirty(textboxID);
}

function OBRadioButton_OnClick(radioButtonID)
{
	SetDirty(radioButtonID);
}

function OBCheckBox_OnClick(checkboxID)
{
	SetDirty(checkboxID);
	
	// Call individual checkbox onlick events
	eval('if (typeof(' + checkboxID + '_OnClick) == \'function\') ' + checkboxID + '_OnClick();');
}



/////////////////////////////////////////////////
/// End of Validation, Grouping and IsDirty related stuff
/////////////////////////////////////////////////
	
function FindGridCell(gridID, editID) 
{
	var grid = igtbl_getGridById(gridID);
	window.alert(grid);
	var findValue = GetElem(editID).value;
	window.alert(findValue);
	var re = new RegExp("^" + findValue, "gi");
	
	igtbl_clearSelectionAll(grid.Id)
	var oCell = grid.find(re);
	if(oCell != null) 
	{
		var row = oCell.Row.ParentRow;
		while(row != null) 
		{
			row.setExpanded(true);
			row = row.ParentRow;
		}
		oCell.setSelected(true);
	}
}		



function WebListBar_HeaderClick(oListbar, oGroup, oEvent)
{
	if (oGroup.Key == "Default")
	{
		oEvent.cancel = true;
	}
}


function WebListBar_HeaderDoubleClick(oListbar, oGroup, oEvent)
{
	if (oGroup.Key == "Default")
	{
		oEvent.cancel = true;
	}
}


function WebListBar_InitializeListbar(oListbar, oEvent)
{
	for (i = 0; i < oListbar.groupCount; i++)
	{
		oListbar.Groups[i].setExpanded(oListbar.Groups[i].selected && (oListbar.Groups[i].itemCount > 0));
	}
}




function ResetFind(strFindButton, strFind, strFindNext) 
{
	btnFind = GetElem(strFindButton);
    btnFind.value = strFind;
}

function FindValue(strGrid, btnFind, strTextBox, strFind, strFindNext) {
    var eVal = GetElem(strTextBox);
    findValue = eVal.value;
    var re;
    
    if (IsNumeric(findValue))
		re = new RegExp("\\b" + findValue + "\\b", "gi");
    else
		re = new RegExp(findValue, "gi");
    // Determine if this is an initial find or a find next.
    if(btnFind.value == strFind) 
    { 
        igtbl_clearSelectionAll(igtbl_getGridById(strGrid).Id)
        var oCell = igtbl_getGridById(strGrid).find(re);
        if(oCell != null) {
    	    btnFind.value = strFindNext;
        	var row = oCell.Row.ParentRow;
        	while(row != null) {
    		    row.setExpanded(true);
        		row = row.ParentRow;
        	}
    	//oCell.setSelected(true);
    	oCell.Row.setSelected(true);
    	oCell.Row.scrollToView();
        }
    }
    else { // Otherwise it's a Find Next operation
        var oCell = igtbl_getGridById(strGrid).findNext();
        if(oCell == null) {
    	    btnFind.value = strFind;
        }
        else {
    	    var row = oCell.Row.ParentRow;
        	while(row != null) {
        		row.setExpanded(true);
    	    	row = row.ParentRow;
    	    }
    	//oCell.setSelected(true);
    	oCell.Row.setSelected(true);
    	oCell.Row.scrollToView();
        }
    }
}

function IsNumeric(sText)
{
   var ValidChars = "0123456789.";
   var IsNumber=true;
   var Char;

 
   for (i = 0; i < sText.length && IsNumber == true; i++) 
      { 
      Char = sText.charAt(i); 
      if (ValidChars.indexOf(Char) == -1) 
         {
         IsNumber = false;
         }
      }
   return IsNumber;
   
}


function NextWebGridRow(grid)
{
	var row = igtbl_getActiveRow(grid.id); //grid.getActiveRow();
	
	if (row != null)
	{
		row = row.getNextRow();
		if (row != null)
		{
			row.activate();
			row.setSelected();// = true;
			return true;
		}
	}
	
	//button.click();
	return false;
}

function PreviousWebGridRow(grid)
{
	var row = igtbl_getActiveRow(grid.id);  // grid.getActiveRow();
	if (row != null)
	{
		row = row.getPrevRow();
		if (row != null)
		{
			row.activate();
			row.setSelected();
			return true;
		}
	}
	
	return false;
}

function FirstWebGridRow(grid)
{
	grid = igtbl_getGridById(grid.id);
	//var row = igtbl_getActiveRow(grid.id);  // grid.getActiveRow();
	if (grid != null)
	{
		row = grid.getFirstRow();
		if (row != null)
		{
			row.activate();
			row.setSelected();
			return true;
		}
	}
	
	return false;
}
