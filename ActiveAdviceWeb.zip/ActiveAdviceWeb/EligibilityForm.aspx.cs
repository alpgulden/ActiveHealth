using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using Infragistics.WebUI.UltraWebToolbar;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// This page is called when the user hits Eligibility button in the Intake form.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	VS_PERMISSION
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ELIGIBILITY_SEARCH)]
	
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Eligibility,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@ELIGIBILITYSEARCHFORM@")]
	public class EligibilityForm : BasePage
	{
		private Eligibility eligibility;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;		
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMemberInfo;
		protected NetsoftUSA.WebForms.OBLabel Oblabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAddress;
		protected NetsoftUSA.WebForms.OBLabel Oblabel3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFaxExtension;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FaxExtension;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFaxExtension;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFax;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldWorkPhoneExtension;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WorkPhoneExtension;
		protected NetsoftUSA.WebForms.OBFieldLabel lbWorkPhoneExtension;
		protected NetsoftUSA.WebForms.OBFieldLabel lbWorkPhoneNumber;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHomePhoneNumber;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEmail;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberCountry;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberCountry;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberCountry;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberCounty;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberCounty;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberCounty;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberPostalCode;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberState;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberCity;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberCity;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberCity;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberAddress3;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberAddress3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberAddress2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberAddress2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberAddress1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MemberAddress1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberAddress1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEligibilityId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit EligibilityId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEligibilityId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternateInsuranceID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateInsuranceID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateInsuranceID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMedicaidId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MedicaidId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMedicaidId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMedicareId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MedicareId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMedicareId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMembershipId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MembershipId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMembershipId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberSSN;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberDOB;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MemberDOB;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberDOB;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMemberGender;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNameSuffix;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit NameSuffix;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNameSuffix;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMiddleInitial;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMiddleInitial;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLastName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberGender;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MemberGender;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberSSN;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit MemberSSN;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberState;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MemberState;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMemberPostalCode;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit MemberPostalCode;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEmail;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Email;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHomePhoneNumber;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit HomePhoneNumber;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldWorkPhoneNumber;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WorkPhoneNumber;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFax;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit Fax;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSubscriber;
		protected NetsoftUSA.WebForms.OBLabel Oblabel2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHomePhoneExtension;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit HomePhoneExtension;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHomePhoneExtension;
		protected NetsoftUSA.WebForms.OBLabel Oblabel4;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSORGID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit SORGID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSORGID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldORGID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ORGID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbORGID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMORGID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MORGID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMORGID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit AsOfDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAsOfDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlOrganization;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator3;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WebMaskEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator4;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator5;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WebMaskEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel5;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator6;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel6;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator7;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WebMaskEdit3;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel7;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator8;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit4;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel8;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator9;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WebMaskEdit4;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel9;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator10;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel10;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator11;
		protected NetsoftUSA.InfragisticsWeb.WebCombo WebCombo1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel11;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator12;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit5;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel12;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator13;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit6;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel13;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator14;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit7;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel14;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternateSubscriberID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateSubscriberID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateSubscriberID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEligibilityTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EligibilityTerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEligibilityTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMORGName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MORGName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSORGName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit SORGName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldORGName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ORGName;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MemberEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPlan;
		protected NetsoftUSA.WebForms.OBLabel Oblabel5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPCP;
		protected NetsoftUSA.WebForms.OBLabel Oblabel6;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridEligibilityPlan;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridEligibilityPCP;
		protected TBarButton tbbCancel;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{				
				eligibility = (Eligibility)this.LoadObject(typeof(Eligibility));  // load object from cache				
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("EligibilityForm.aspx");
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(Eligibility eligibility)
		{
			BasePage.PushParam("Eligibility",eligibility);
			BasePage.Redirect("EligibilityForm.aspx");
		}

		public static void Redirect(int eligibilityId)
		{
			Eligibility eligibility = new Eligibility ();
			if (!eligibility.Load(eligibilityId))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@ELIGIBILITY@");
			Redirect(eligibility);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			//			grid.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_ColumnsBoundToDataClass);
			//			grid.ClickCellButton +=new ClickCellButtonEventHandler(grid_ClickCellButton);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			try
			{
				string seligibilityID = this.Request.QueryString["EligibilityID"];
				if (seligibilityID != null)
				{
					eligibility = new Eligibility();
					if (!eligibility.Load(int.Parse(seligibilityID)))
						throw new ActiveAdviceException("@CANTFINDRECORD@", "@ELIGIBILITY@");
				}
				else
				{
					eligibility	= this.GetParamOrGetFromCache("Eligibility", typeof(Eligibility)) as Eligibility;
					if (eligibility==null)
					{
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You can hit this page only in the context of an Eligibility.");
					}
				}

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patient.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Eligibility = eligibility;
			return result;
		}

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			//if (tab.Key == "Search")
			//{
			toolbar.AddButton("@NEWSEARCH@", "NewSearch");
			//}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			tbbCancel = toolbar.AddButton(PatientMessages.MessageIDs.CANCEL, "Cancel").Item;
			if (this.IsPopup)
			{
				tbbCancel.Text = this.BaseMessages.CLOSE;
				tbbCancel.TargetURL = "javascript:window.close()";
			}
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			EligibilityMainSearch.Redirect();
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Eligibility Eligibility
		{

			get { return eligibility; }
			set
			{	
				eligibility = value;
				try
				{						
					if(eligibility==null)
					{
					}
					else
					{
						// new or edit group
						this.UpdateFromObject(this.pnlMemberInfo.Controls, eligibility);
						this.UpdateFromObject(this.pnlAddress.Controls, eligibility); 
						Eligibility subs = new Eligibility();						
						if(subs.LoadEligibilityByAlternateIdAndSorgandMembershipId(eligibility.AlternateSubscriberID,eligibility.SORGID,eligibility.MembershipId))
							this.UpdateFromObject(this.pnlSubscriber.Controls, subs); 
						this.UpdateFromObject(this.pnlOrganization.Controls, eligibility);
						eligibility.LoadEligibilityPlans(true);
						if(eligibility.EligibilityPlans!=null)
						{
							this.UpdateFromObject(this.pnlPlan.Controls, eligibility.EligibilityPlans);
							this.gridEligibilityPlan.UpdateFromCollection(eligibility.EligibilityPlans);
						}
						eligibility.LoadEligibilityPCPs(true);
						if(eligibility.EligibilityPCPs!=null)
						{
							this.UpdateFromObject(this.pnlPCP.Controls, eligibility.EligibilityPCPs);
							this.gridEligibilityPCP.UpdateFromCollection(eligibility.EligibilityPCPs);
						}
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Eligibility), eligibility);  
			}
		}	

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			EligibilityMainSearch.Redirect();
		}
		

		//		private void grid_ColumnsBoundToDataClass(object sender, EventArgs e)
		//		{
		//			//grid.AddButtonColumn("Select", "@SELECT@");
		//			grid.AddButtonColumn("Edit", "@EDIT@", 0).Width = 50;
		//		}
		//
		//		private void grid_ClickCellButton(object sender, CellEventArgs e)
		//		{
		//			int index = grid.GetColIndexFromCellEvent(e);
		//			switch (e.Cell.Key)
		//			{
		//				case "Edit":
		//				{
		//					try
		//					{
		//						Eligibility eligibility = this.eligibilityCol[index];
		//						this.Eligibility=eligibility;
		//					}
		//					catch(Exception ex)
		//					{
		//						this.RaisePageException(ex);
		//					}
		//					break;
		//				}
		//			}
		//		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			SetPropertyState(this.pnlMemberInfo.Controls, ControlPropertyName.Enabled, false, false);
			SetPropertyState(this.pnlAddress.Controls, ControlPropertyName.Enabled, false, false);
			SetPropertyState(this.pnlSubscriber.Controls, ControlPropertyName.Enabled, false, false);
			SetPropertyState(this.pnlOrganization.Controls, ControlPropertyName.Enabled, false, false);
			SetPropertyState(this.pnlPlan.Controls, ControlPropertyName.Enabled, false, false);
			SetPropertyState(this.pnlPCP.Controls, ControlPropertyName.Enabled, false, false);
		}
	}
}
