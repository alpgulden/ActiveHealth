using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// This is the general application error page.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.BaseMessages,DataLayer")]		// Define the message class for this module
	//[MainDataClass("Question,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("")]					
	[SelectedMenuItem("")]
	[BackPage(typeof(PatientSearch))]
	[PageTitle("@APPLICATIONERRORTITLE@")]		// don't put a dummy @MESSAGEID@ in the template, the message may get created in the message table.
	public class ErrorForm : BasePage
	{
		protected Exception ex;				// the error message and exception information.

		protected new System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlError;
		protected NetsoftUSA.WebForms.OBLabel lbErrorDesc;
		protected NetsoftUSA.WebForms.OBLabel lbErrorLongDesc;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public void LoadData()
		{
			ex = this.GetParam("Exception") as Exception;	// Let's be graceful, we're in the Error page after all..
			if (ex == null)
			{
				HttpContext ctx = HttpContext.Current;
				ex = ctx.Server.GetLastError();
				if (ex != null)
				{
					System.Reflection.TargetInvocationException tex = ex as System.Reflection.TargetInvocationException;
					if (tex != null)
						ex = tex.InnerException;	// get the actual exception					
				}

				if (ex == null)
					ex = new ActiveAdviceException("@APPLICATIONERROR@");

			}
			else if(ex is System.Security.SecurityException)
					ex = new ActiveAdviceException("@ACCESSDENIED@", ex);
			
			DisplayException();
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("ErrorForm.aspx");
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(Exception ex)
		{
			BasePage.PushParam("Exception", ex);
			Redirect();
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(string errorMessage)
		{
			Redirect( new ActiveAdviceException(errorMessage) );
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(string errorMessage, string longMessage)
		{
			ActiveAdviceException aex = new ActiveAdviceException(errorMessage);
			aex.LongMessage = longMessage;
			Redirect( aex );
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(string errorMessage, string longMessage, params object[] messageParameters)
		{
			Redirect( new ActiveAdviceException(errorMessage, longMessage, messageParameters) );
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(string errorMessage, System.Exception innerException, params object[] messageParameters)
		{
			Redirect( new ActiveAdviceException(errorMessage, innerException, messageParameters) );
		}

		public void DisplayException()
		{
			this.RaisePageException(ex);
		}

		public override void SetPageMessage(string msg, EnumPageMessageType messageType)
		{
			// Capture the page message behavior to display message on the form
			if (messageType == EnumPageMessageType.Error || messageType == EnumPageMessageType.Warning || messageType == EnumPageMessageType.Info)
			{
				this.lbErrorDesc.TextToTranslate = msg;
				this.lbErrorLongDesc.TextToTranslate = "";
			}
		}

		public override void SetPageLongMessage(string msg)
		{
			// Capture the page message behavior to display message on the form
			if (msg != this.lbErrorDesc.TextToTranslate)
				this.lbErrorLongDesc.TextToTranslate = msg;
			/*else
			{
				this.lbErrorLongDesc.TextToTranslate = "";
				this..Text = "";
			}*/
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Error")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			//toolbar.AddButton("@OK@", "Cancel");

			Infragistics.WebUI.UltraWebToolbar.TBarButton tbbCancel = toolbar.AddButton("@OK@", "Cancel", false, !this.IsPopup).Item;
			if (this.IsPopup)
				tbbCancel.TargetURL = "javascript:window.close()";
		}

		protected override void OnError(EventArgs e)
		{
			base.OnError (e);	//VS
			// Just ignore, we're in Error Page after all.
		}

	}
}
