using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.BaseCodeTypeMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("BaseLookupWithSubCodeTwoSTR,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@CODETABLES@")]
	public class CodeTypeFormForTwoStrLoopUp : CodeBasePage
	{
		private	BaseLookupWithSubCodeTwoSTR searchObj;
		private	BaseLookupWithSubCodeTwoSTR obj;
		private	BaseTypeCollection objCol;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGrid;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFocus;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCodeTypes;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlInfo;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEdit;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;

		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNotepad;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCode;
		protected NetsoftUSA.WebForms.OBTextBox Code;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCode;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.WebForms.OBCheckBox obChkSearchActive;
		protected NetsoftUSA.WebForms.OBTextBox obTxtSearchDescription;
		protected NetsoftUSA.WebForms.OBTextBox obTxtSearchCode;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSearch;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActivityPrimaryTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActivityPrimaryTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSubCode;
		protected NetsoftUSA.WebForms.OBFieldLabel lbExtSubCode;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSubCodeStr;
		protected NetsoftUSA.InfragisticsWeb.WebCombo SubCodeStr;
		protected NetsoftUSA.InfragisticsWeb.WebCombo SubCodeExtStr;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSubCodeExtStr;
		protected NetsoftUSA.WebForms.OBTextBox NoteGeneric;
		protected NetsoftUSA.WebForms.OBValidator vldNoteGeneric;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
				this.LoadData();			// Load data is the actual data loading method
			else
			{
				this.obj    = (BaseLookupWithSubCodeTwoSTR)this.LoadObject("CodeTypeFormForTwoStrLoopUp");
				this.objCol = (BaseTypeCollection)this.LoadObject("CodeTypeFormForTwoStrLoopUpCollection");
				this.searchObj = (BaseLookupWithSubCodeTwoSTR)this.LoadObject("SearchObj");
			}

		}

		
		public static void Redirect(Type type, string title)
		{
			if (typeof(EventType) == type)
			{				
				EventTypeCollection col = new EventTypeCollection();
				BasePage.PushParam("CodeTitle",title);
				BasePage.PushParam("Type", col );				
				BasePage.Redirect("CodeTypeFormForTwoStrLoopUp.aspx");
			}
// FORK1.1
			else if (typeof(PhysicianReviewRequestDetailType) == type)
			{				
				PhysicianReviewRequestDetailTypeCollection col = new PhysicianReviewRequestDetailTypeCollection();
				BasePage.PushParam("CodeTitle",title);
				BasePage.PushParam("Type", col );				
				BasePage.Redirect("CodeTypeFormForTwoStrLoopUp.aspx");
			}

			else
			{
				Debug.Fail("Invalid Type");
			}
		}



		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			string title = this.GetParamString("CodeTitle");
			OBLabel5.Text = title;
			OBLabel1.Text = title;
			BaseTypeCollection  baseFocusCol	= (BaseTypeCollection)this.GetParam("Type");
			if (baseFocusCol == null)
			{
				this.pnlGrid.Visible	= false;
				this.pnlInfo.Visible	= true;
				this.pnlSearch.Visible	= false;
				// disable buttons
				//((Button)this.PageToolbar.FindControl("AddNew")).Visible = false;
			}
			else
			{
				this.obj	= (BaseLookupWithSubCodeTwoSTR)Activator.CreateInstance(baseFocusCol.ElementType);
				
				if (this.searchObj == null)
				{
					baseFocusCol.LoadAll();
					this.BaseTypeCollection = baseFocusCol;
					this.SearchObj			= this.obj;
				}
				this.pnlGrid.Visible	= true;
				this.pnlInfo.Visible	= false;
				this.pnlSearch.Visible	= false;
				// enable buttons
				//((Button)this.PageToolbar.FindControl("AddNew")).Visible = true;
				//((Button)this.
			}
			this.pnlEdit.Visible = false;
			this.SelectedSideMenuItem = this.LoadObject("SelectedSideMenuItem") as string;

			return result;
		}


		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{
				// if the type is not marked as read-only
				if (!this.BaseLookupWithSubCodeTwoSTR.ReadOnly)
				{
//					// data from controls to object
					if (!this.ReadControls())
						return false;
//					if(obj.Code==null || obj.Code=="")
//					{
//						this.SetPageMessage("@CODEERR@", EnumPageMessageType.Error);
//						return false;
//					}
//					if(obj.Description==null || obj.Description=="")
//					{
//						this.SetPageMessage("@DESCRIPTIONERR@", EnumPageMessageType.Error);
//						return false;
//					}
//					if(obj.SubCodeStr==null || obj.SubCodeStr=="")
//					{
//						this.SetPageMessage("@SUBCODEERR@", EnumPageMessageType.Error);
//						return false;
//					}
//					if(obj.SubCodeExtStr==null || obj.SubCodeExtStr=="")
//					{
//						this.SetPageMessage("@SUBCODEERR@", EnumPageMessageType.Error);
//						return false;
//					}
					this.obj.Save(); // update or insert to db
					this.searchObj = null;

					#region Clear CodeTable Cache
					// clear cache for BaseTypeCollection
					string strType = this.BaseTypeCollection.GetType().Name;
					//clear cache for the current server
					NSGlobal.ClearCacheByType(strType);

					//clear cache for other servers 
					// calling WebRequest for every server but current and passing collection type
					// ...
					ClearOtherServersCache(strType, false);
					#endregion Clear CodeTable Cache

					// refresh grid.
					ReloadGrid();
					return true;
				}
				else
				{
					this.SetPageMessage("@READONLY@",NetsoftUSA.WebForms.EnumPageMessageType.Warning);
					return false;
				}		
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BaseLookupWithSubCodeTwoSTR BaseLookupWithSubCodeTwoSTR
		{
			get { return this.obj; }
			set 
			{
				this.obj = value;
				try
				{											
					this.lbCode.SourceMemberName = "Code";
					lbCode.SourceClassName = this.obj.GetType().AssemblyQualifiedName;
					this.Code.SourceMemberName = "Code";
					Code.SourceClassName = this.obj.GetType().AssemblyQualifiedName;
					this.vldCode.SourceMemberName = "Code";
					vldCode.SourceClassName = this.obj.GetType().AssemblyQualifiedName;

					this.lbDescription.SourceMemberName = "Description";
					lbDescription.SourceClassName = this.obj.GetType().AssemblyQualifiedName;
					this.Description.SourceMemberName = "Description";
					Description.SourceClassName = this.obj.GetType().AssemblyQualifiedName;
					this.vldDescription.SourceMemberName = "Description";
					vldDescription.SourceClassName = this.obj.GetType().AssemblyQualifiedName;

					lbSubCode.SourceMemberName = "SubCodeStr";
					lbSubCode.SourceClassName = this.obj.GetType().AssemblyQualifiedName;
					SubCodeStr.SourceMemberName = "SubCodeStr";
					SubCodeStr.SourceClassName = this.obj.GetType().AssemblyQualifiedName;
					vldSubCodeStr.SourceMemberName = "SubCodeStr";
					vldSubCodeStr.SourceClassName = this.obj.GetType().AssemblyQualifiedName;

					lbExtSubCode.SourceMemberName = "SubCodeExtStr";
					lbExtSubCode.SourceClassName = this.obj.GetType().AssemblyQualifiedName;
					SubCodeExtStr.SourceMemberName = "SubCodeExtStr";
					SubCodeExtStr.SourceClassName = this.obj.GetType().AssemblyQualifiedName;
					vldSubCodeExtStr.SourceMemberName = "SubCodeExtStr";
					vldSubCodeExtStr.SourceClassName = this.obj.GetType().AssemblyQualifiedName;

					this.UpdateFromObject(pnlEdit.Controls, this.obj);	
					this.pnlEdit.Visible	= true;
					this.pnlGrid.Visible	= false;
					this.pnlSearch.Visible	= false;
					pnlEdit.Enabled  = (this.BaseLookupWithSubCodeTwoSTR.ReadOnly) ? false : true;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("CodeTypeFormForTwoStrLoopUp", this.obj);
			}
		}

		public BaseTypeCollection BaseTypeCollection
		{
			get { return this.objCol; }
			set 
			{
				try
				{
					this.objCol				= value;
					objCol.ElementType      = value.ElementType;
					this.pnlGrid.Visible	= true;
					this.pnlSearch.Visible	= false;
					this.gridCodeTypes.ClearRows();
					this.objCol.DisplayOnlyActive=false;
					this.gridCodeTypes.UpdateFromCollection(this.objCol);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject("CodeTypeFormForTwoStrLoopUpCollection", this.objCol);
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	// add all control-to-object population code here
				this.UpdateToObject(pnlEdit.Controls, obj);  // controls-to-object
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.gridCodeTypes.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridCodeTypes_ClickCellButton);
			this.gridCodeTypes.RowBoundToDataObject += new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(this.gridCodeTypes_RowBoundToDataObject);
			this.gridCodeTypes.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridCodeTypes_ColumnsBoundToDataClass);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);

			
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@SAVERECORD@", "SaveType",true, false);
			toolbar.AddButton("@DELETE@","DeleteType",false, false).Visible=false;
			toolbar.AddButton("@CANCEL@", "Cancel", false, true);
		}


		public override void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick (toolbar, button);
			//button.Key == "Save"
		}

		public void OnToolbarButtonClick_SaveType(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@CODETYPE@");
				this.pnlEdit.Visible = false;
				this.pnlGrid.Visible = true;
			}
		}
		public void OnToolbarButtonClick_DeleteType(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			
			try
			{
				if (!this.BaseLookupWithSubCodeTwoSTR.ReadOnly)
				{
					this.BaseLookupWithSubCodeTwoSTR.Delete((int)this.BaseLookupWithSubCodeTwoSTR.PK[0]);
					ReloadGrid();				
					this.pnlEdit.Visible = false;
					this.pnlGrid.Visible = true;
				}
				else
				{
					this.SetPageMessage("@READONLY@",NetsoftUSA.WebForms.EnumPageMessageType.Warning);
				}
			}
			catch(SqlException e)
			{ 
				if(e.Number==547)
					this.SetPageMessage("@DELETEDEPENDENCYMSGCODE@", EnumPageMessageType.Error, "@CODE@");
				else
					this.RaisePageException(e);
			}
			catch(Exception ex)
			{ 
				this.RaisePageException(ex);
			}

//			catch (SqlException ex)
//			{
//				throw;
//				//this.RaisePageException(new Exception("This code is being referenced by other records and cannot be deleted. Please delete referenced records and try again"));								
//			}
		}
		

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if(this.gridCodeTypes.Visible)
				CodeMaintenance.Redirect(this.GetParamString("CodeTitle"));
			CodeTypeFormForTwoStrLoopUp.Redirect(this.objCol.ElementType,OBLabel5.Text);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			toolbar.AddButton("Add New", "AddNew").Visible = !(this.obj==null);
			//toolbar.AddButton("@NEWSEARCH@","NewSearch");

		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{

			BaseLookupWithSubCodeTwoSTR BaseLookupWithSubCodeTwoSTR = (BaseLookupWithSubCodeTwoSTR)Activator.CreateInstance(this.objCol.ElementType);
			BaseLookupWithSubCodeTwoSTR.New();
			this.BaseLookupWithSubCodeTwoSTR	= BaseLookupWithSubCodeTwoSTR;
			this.pnlEdit.Visible	= true;
		}

//		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
//		{
//			this.SearchObj = new BaseLookupWithSubCodeTwoSTR();
//		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			SetPageToolbarItemVisible("DeleteType",(this.pnlEdit.Visible && !obj.IsNew) || !this.BaseLookupWithSubCodeTwoSTR.ReadOnly);
			SetPageToolbarItemVisible("SaveType",this.pnlEdit.Visible || !this.BaseLookupWithSubCodeTwoSTR.ReadOnly);
		}

//		protected void gridCodeTypes_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
//		{
//			if (e.Cell != null)
//			{
//				int index				= (int)e.Cell.Row.DataKey;
//				this.BaseLookupWithSubCodeTwoSTR	= (BaseLookupWithSubCodeTwoSTR)this.objCol.GetAt(index);
//				this.pnlEdit.Visible	= true;
//				this.pnlGrid.Visible    = false;
//			}
//			else if (e.Row != null)
//			{
//				int rowindex			= (int)e.Row.DataKey;
//				this.BaseLookupWithSubCodeTwoSTR	= (BaseLookupWithSubCodeTwoSTR)this.objCol.GetAt(rowindex);
//				this.pnlEdit.Visible	= true;
//				this.pnlGrid.Visible	= false;
//			}
//		}


		private void gridCodeTypes_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridCodeTypes.AddButtonColumn("EDIT","EDIT",0);
		}

		private void gridCodeTypes_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell != null)
			{
				int index					= (int)e.Cell.Row.DataKey;
				this.BaseLookupWithSubCodeTwoSTR	= (BaseLookupWithSubCodeTwoSTR)this.objCol.GetAt(index);
				this.pnlEdit.Visible		= true;
				this.pnlGrid.Visible		= false;
			}
			else if (e.Cell.Row != null)
			{
				int rowindex			= (int)e.Cell.Row.DataKey;
				this.BaseLookupWithSubCodeTwoSTR= (BaseLookupWithSubCodeTwoSTR)this.objCol.GetAt(rowindex);
				this.pnlEdit.Visible	= true;
				this.pnlGrid.Visible	= false;
			}
		}

		private void gridCodeTypes_RowBoundToDataObject(object sender, RowBindingEventArgs e)
		{
			BaseLookupWithSubCodeTwoSTR lineitem = e.data as BaseLookupWithSubCodeTwoSTR;
			if (lineitem.ReadOnly)
				e.row.Style.CssClass = "GridIncompleteCode";
		}

		private void ReloadGrid()
		{
			BaseTypeCollection.Clear();
			BaseTypeCollection.LoadAll();
			this.BaseTypeCollection = BaseTypeCollection;
		}

//		private void btnSearch_Click(object sender, System.EventArgs e)
//		{
//			BaseTypeCollection searchResults = (BaseTypeCollection)Activator.CreateInstance(this.objCol.GetType());
//			//this.UpdateToObject(this.pnlSearch.Controls, this.searchObj, false);
//			//searchResults.SearchCodeTypes(this.searchObj.Code, this.searchObj.Description, this.searchObj.Active);
//			//this.BaseTypeCollection = searchResults;
//		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BaseLookupWithSubCodeTwoSTR SearchObj
		{
			get { return searchObj; }
			set
			{
				searchObj = value;
				try
				{
					this.UpdateFromObject(this.Controls, searchObj);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("SearchObj", searchObj);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
//		public bool ReadControlsForSearchObj()
//		{
//			try
//			{	//customize this method for this specific page
//				//this.UpdateToObject(this.Controls, searchObj);	// controls-to-object
//				// other control-to-object methods if any
//				return this.IsValid;	// Return validation result
//			}
//			catch(Exception ex)
//			{
//				this.RaisePageException(ex);	// notify the page about the error
//				return false;
//			}
//		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
//		public bool NewSearchObj()
//		{
//			bool result = true;
//			BaseLookupWithSubCodeTwoSTR searchObj = this.obj; // use a parameterized constructor which also initializes the data object
//			try
//			{	// or use an initialization method here
//				searchObj.New(/* parameters */);
//			}
//			catch(Exception ex)
//			{
//				this.RaisePageException(ex);	// notify the page about the error
//				result = false;
//			}
//			finally
//			{
//				// finalization code
//			}
//			this.SearchObj = searchObj;
//			return result;
//		}
		protected override object SaveViewState()
		{
			ViewState["SelectedSideMenuItem"] = this.SelectedSideMenuItem;
			return base.SaveViewState ();
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
			this.SelectedSideMenuItem = (string)ViewState["SelectedSideMenuItem"];
		}
	}
}
