using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for LetterTemplateSearch.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.LETTER_SETUP)]
	
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("LetterTemplate,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("LetterTemplate")]
	[PageTitle("@LETTERTEMPLATESEARCHPAGETITLE@")]
	public class LetterTemplateSearch : LetterMaintenanceBasePage
	{
		private LetterTemplateCollection letterTemplates;
		private LetterTemplate letterTemplateSearcher;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSearch;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActiveWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnSearch;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMatrixTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MatrixTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMatrixTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLetterTemplateID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit LetterTemplateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLetterTemplateID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			
			this.wbtnSearch.Click += new System.EventHandler(this.wbtnSearch_Click);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);

			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				NewData();
			else
			{
				letterTemplateSearcher = (LetterTemplate)this.LoadObject("LetterTemplate");  // load object from cache
				//letterTemplates = (LetterTemplateCollection)this.LoadObject(typeof(LetterTemplateCollection));  // load object from cache
			}
		}

		#region LetterTemplateSearcher
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterTemplate LetterTemplateSearcher
		{
			get { return letterTemplateSearcher; }
			set
			{
				letterTemplateSearcher = value;
				try
				{
					this.UpdateFromObject(this.pnlSearch.Controls, letterTemplateSearcher);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("LetterTemplate", letterTemplateSearcher);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlSearch.Controls, letterTemplateSearcher);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewData()
		{
			bool result = true;
			LetterTemplate letterTemplateSearcher = null; //new LetterTemplate(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				letterTemplateSearcher = new LetterTemplate();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.LetterTemplateSearcher = letterTemplateSearcher;
			this.ActiveWithAll.SelectedRow = this.ActiveWithAll.Rows[0];
			return result;
		}
		#endregion

		#region LetterTemplates
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public LetterTemplateCollection LetterTemplates
		{
			get { return letterTemplates; }
			set
			{
				letterTemplates = value;
				try
				{
					grid.UpdateFromCollection(letterTemplates);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				//this.CacheObject(typeof(LetterTemplateCollection), letterTemplates);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			LetterTemplateCollection letterTemplates = new LetterTemplateCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				letterTemplates = LetterTemplateCollection.GetFromSearch(this.letterTemplateSearcher);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//letterTemplates.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.LetterTemplates = letterTemplates;
			return result;
		}
		#endregion

		#region UI Initialization and Events
		private void wbtnSearch_Click(object sender, System.EventArgs e)
		{
			Search();	
			if(this.LetterTemplates.Count > 0 )
				grid.SelectedRowIndex = 0;
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
			{
				object[] pk = grid.GetPKFromCellEvent(e);
				LetterTemplateMaintenance.Redirect((int)pk[0]);
			}
			
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Search":
					toolbar.AddButton(Messages.BaseMessages.MessageIDs.ADDNEWRECORD, "AddNewLetterTemplate");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewLetterTemplate(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			LetterTemplate lt = new LetterTemplate(true);
			LetterTemplateMaintenance.Redirect(lt);
		}
		#endregion
		
	}
}
