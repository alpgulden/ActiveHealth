using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{

	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Assessment,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("MPatient")]
	[PageTitle("@ASMTQRPICKERPAGETITLE@")]
	public class AssessmentForm : AssessmentBasePage
	{
		private Questionnaire questionnaire;  // filter object
		private AssessmentQuestionnaireOrderCollection assessmentQuestionnaireOrders;
		private QuestionnaireCollection availableQuestionnaires;
		private ArrayList errorMessages;

		private bool displayRowCountMessage = false;

		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridAvailable;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridSelected;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridAvailable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridSelected;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBButton wbtnAddChecked;
		protected NetsoftUSA.WebForms.OBButton wbtnDeleteSelectedQRs;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionnaireID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit QuestionnaireID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionnaireID;
		protected NetsoftUSA.WebForms.OBButton wbtnSearch;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFilter;
		protected NetsoftUSA.InfragisticsWeb.WebCombo QuestionnaireTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionnaireTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionnaireTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchNext;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchPrevious;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;

			
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
			InitializeComponent();
			gridAvailable.PagingColumns = new string[] { "PKInt", "SortOrder" };
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.wbtnSearch.Click += new System.EventHandler(this.wbtnSearch_Click);
			this.butSearchPrevious.Click += new System.EventHandler(this.butSearchPrevious_Click);
			this.butSearchNext.Click += new System.EventHandler(this.butSearchNext_Click);
			this.wbtnAddChecked.Click += new System.EventHandler(this.wbtnAddChecked_Click);
			this.wbtnDeleteSelectedQRs.Click += new System.EventHandler(this.wbtnDeleteSelectedQRs_Click);
			this.AutoScroll = true;
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				LoadData();			// Use load data method for data entry forms
			}		
			else
			{
				availableQuestionnaires = (QuestionnaireCollection)this.LoadObject(typeof(QuestionnaireCollection));  // load object from cache
				assessmentQuestionnaireOrders = (AssessmentQuestionnaireOrderCollection)this.LoadObject(typeof(AssessmentQuestionnaireOrderCollection));  // load object from cache
				questionnaire = (Questionnaire)this.LoadObject(typeof(Questionnaire));  // load object from cache
			}


			//this.gridSelected.DisplayLayout.CellClickActionDefault = CellClickAction.Edit;
		}


		public static void Redirect(AssessmentContext assessmentContext)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("ASSESSMENTCONTEXT", assessmentContext);			
			BasePage.Redirect("AssessmentForm.aspx");
		}

		public static void Redirect(CMS cMS, Assessment assessment)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CMS", cMS);			
			BasePage.PushParam("ASSESSMENT", assessment);			
			BasePage.Redirect("AssessmentForm.aspx");
		}

		private void LoadData()
		{
			if (assessment == null)
			{
				this.RaisePageException (new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an Assessment"));
				return;
			}
			
			assessment.LoadAssessmentQuestionnaireOrders(false);
			this.AssessmentQuestionnaireOrders = assessment.AssessmentQuestionnaireOrders;
			
			NewQuestionnaire();  // filter object
			LoadDataForAvailableQuestionnaires();		 // Load All available Questionnaires filtered by this.questionnaire
			if(assessment.IsNew)
			{	// Preselect Questionnaires based on Dx/Px ONLY when page is loaded initially AND no questionnaires have been selected
				// Scenario for creation of a new Assessment.
				LoadDataForAssessmentQuestionnaireOrdersByDxPxAndScoringLoad();
				//availableQuestionnaires.SetSelectedQuestionnairesFromCollection(AssessmentQuestionnaireOrders);
			}
			this.AvailableQuestionnaires = availableQuestionnaires;
		}

		#region UI Initialization and events
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(cMS, cMS.Patient, assessment);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@CANCEL@", "Cancel");
			toolbar.AddButton("@RETURNTOASSESSMENT@", "Return", true, false);
		}

		public void AddQuestionnaires()
		{
			if (ReadControlsForAvailableQuestionnaires() & ReadControlsForAssessmentQuestionnaireOrders())
			{
				errorMessages = new ArrayList(); // used to pass possible errors from SynchronizeFromSelectableCollection back to page
				try
				{
					if (! assessmentQuestionnaireOrders.SynchronizeFromSelectableCollection(AvailableQuestionnaires, errorMessages, cMS))
					{	// display errors that occured during Synchronization
						foreach (Object obj in errorMessages)
						{
							this.SetPageMessage(obj.ToString(), EnumPageMessageType.AddWarning);
						}
					}
				
					assessmentQuestionnaireOrders.SortBy_SortOrder(true, true);
					assessment.AssessmentQuestionnaireOrders = assessmentQuestionnaireOrders;
					AssessmentQuestionnaireOrders = assessment.AssessmentQuestionnaireOrders;
					
					AvailableQuestionnaires = availableQuestionnaires; // restore Selected checkbox visual status

					this.AssessmentContext = assessmentContext;
					this.Assessment = assessment;
				}
				catch(Exception ex)
				{
					this.RaisePageException(new ActiveAdviceException(AAExceptionAction.DisableUI, ex.ToString()));
				}
			}
		}

		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{			
			if (assessmentContext == null)
			{
				this.Assessment = null;
				Assessments.Redirect(cMS);
			}
			else
			{
				if (this.assessmentContext.IsNew)
				{
					this.assessmentContext.Cancel();
					this.AssessmentContext = null;
					this.Assessment = null;
					Assessments.Redirect(cMS);
				}
				else
				{
					this.assessmentContext.Cancel();
					AssessmentView.Redirect(this.assessmentContext);
				}
			}
		}

		public void OnToolbarButtonClick_Return(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{	
			AddQuestionnaires();
			
			if (assessmentQuestionnaireOrders.RealCount == 0)
			{
				this.SetPageMessage("Please select at least one questionnaire before continuing", EnumPageMessageType.AddWarning); 
				return; 
			}

			// If this is a new assessment create the context
			if (this.assessment.IsNew)
			{
				this.assessment.Save();
				cMS.Assessments.Add(this.assessment);

				AssessmentContext assessmentContext = new AssessmentContext(this.cMS, this.assessment);	
				
				// This is a new assessment so it's not readonly
				assessmentContext.IsReadOnly = false; 

				// Set the isnew to true so that assessment can be cancelled upon users request
				assessmentContext.IsNew = true;

				// Refresh the presentation group question order stuff
				assessment.RefreshPresentationGroupQuestionOrdersFromDB();
				AssessmentQuestionnaireOrders = assessment.AssessmentQuestionnaireOrders;

				this.AssessmentContext = assessmentContext;
			}
			else
			{
				this.assessment.Save();
				// Refresh the presentation group question order stuff
				assessment.RefreshPresentationGroupQuestionOrdersFromDB();
				AssessmentQuestionnaireOrders = assessment.AssessmentQuestionnaireOrders;

				// Reload context
				this.assessmentContext.Questions = null;
				this.assessmentContext.ITemplates = null;
				this.assessmentContext.LogicEvaluator = null;
				this.assessmentContext.QuestionNotes = null;

                this.AssessmentContext = assessmentContext;
			}

			// redirect to AssessmentView.aspx
			AssessmentView.Redirect(this.assessmentContext);
		}
		
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			
			if (this.assessmentContext == null)
			{
				this.SetPageToolbarItemText("Return", "@STARTASSESSMENT@");
				this.SetPageToolbarItemText("Cancel", "@BACKTOEXISTINGASSESSMENTS@");
			}
			else
			{
				this.SetPageToolbarItemText("Return", "@CONTINUEASSESSMENT@");
				this.SetPageToolbarItemVisible("Cancel", false);
			}
		}




		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(assessmentQuestionnaireOrders);
		}

		private void wbtnDeleteSelectedQRs_Click(object sender, System.EventArgs e)
		{
			ReadControlsForAssessmentQuestionnaireOrders();

			int i = this.gridSelected.SelectedColectionIndex;
			if(i < 0) 
				return;

			AssessmentQuestionnaireOrder aQO = this.assessmentQuestionnaireOrders[i];

			if (aQO.IsNew)
				this.assessmentQuestionnaireOrders.Remove(aQO);
			else
			{
				try
				{
					this.ScrollToControl(this.pnlGridSelected);
					aQO.Delete();
					this.assessmentQuestionnaireOrders.Remove(aQO);
				}
				catch(Exception ex)
				{
					this.SetPageMessage("Questionnaire '" + aQO.Description + "' (ID: " + aQO.QuestionnaireID + ") cannot be removed.", EnumPageMessageType.AddWarning);
					this.ScrollToTop();
				}
			}
			AssessmentQuestionnaireOrders = assessmentQuestionnaireOrders;
			
			//availableQuestionnaires.SetSelectedQuestionnairesFromCollection(assessmentQuestionnaireOrders);
			//AvailableQuestionnaires = AvailableQuestionnaires;
		}
		#endregion

		#region Data Objects
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public QuestionnaireCollection AvailableQuestionnaires
		{
			get { return availableQuestionnaires; }
			set
			{
				availableQuestionnaires = value;
				try
				{
					gridAvailable.KeepCollectionIndices = false;  // update given grid from the collection
					gridAvailable.UpdateFromCollection(availableQuestionnaires);  // update given grid from the collection
					
//					if(availableQuestionnaires != null && availableQuestionnaires.Count >= QuestionnaireCollection.MAXRECORDS)
//						this.SetPageMessage("@BIGGERRESULTSET@", EnumPageMessageType.AddInfo, QuestionnaireCollection.MAXRECORDS, "@QUESTIONNAIRES@");

					butSearchNext.Enabled = availableQuestionnaires != null && availableQuestionnaires.Count >= QuestionnaireCollection.MAXRECORDS;
					butSearchPrevious.Enabled = gridAvailable.HasAnyPreviousPages;

				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(QuestionnaireCollection), availableQuestionnaires);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAvailableQuestionnaires()
		{
			try
			{	//customize this method for this specific page
				gridAvailable.UpdateToCollection(availableQuestionnaires);	// grid-to-collection
				//return this.IsValid;	// Return validation result
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForAvailableQuestionnaires()
		{
			bool result = true;
			QuestionnaireCollection availableQuestionnaires = new QuestionnaireCollection();
			gridAvailable.PageStartStack = questionnaire.PageStartStack;
			gridAvailable.ClearValuesForPageStart();

			try
			{	// use any load method here
				ReadControlsForQuestionnaire(); // filter object which sets CMSType
				
				// ALWAYS present available questionnaires based on Organization links
				// IF No Questionnaries are available through Organization links show ALL questionnaires by given filter criteria

				// Creating new Questionnare Organization Searcher Object from CMS
				//QuestionnaireOrganizationSearcher qos = new QuestionnaireOrganizationSearcher(cMS, Questionnaire.ContentOwnerID, Questionnaire.QuestionnaireTypeID, Questionnaire.QuestionnaireID, Questionnaire.Description);
				//availableQuestionnaires = QuestionnaireCollection.GetUsableQuestionnairesByOrganization(qos);
				//if(assessment.IsNew)
				availableQuestionnaires = QuestionnaireCollection.GetUsableQuestionnairesForSelectionInOrder(0, 0, this.questionnaire, cMS.CMSID);
				
				// no need to select anymore
				// availableQuestionnaires.SetSelectedQuestionnairesFromCollection(AssessmentQuestionnaireOrders);
			}
			catch(Exception ex)
			{ 
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			// We're intentionally not using public property
			this.availableQuestionnaires = availableQuestionnaires;
			return result;
		}


		/// <summary>
		/// Call this method from anytime you want to search for the next set of questionnaires
		/// </summary>
		public bool SearchNext(PagingDirection direction)
		{
			bool result = true;
			gridAvailable.PageStartStack = questionnaire.PageStartStack;

			QuestionnaireCollection questionnaires = new QuestionnaireCollection();
			try
			{
				//if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
				//	return false;

				// Find the last questionnaire that was displayed in the grid.
				object [] valuesForNextPageStart = gridAvailable.GetStartValuesForPrevOrNextPage(direction);
				if (valuesForNextPageStart == null)	// no more pages.
					return false;
				// use page start to load this set of records.
				questionnaires = QuestionnaireCollection.GetUsableQuestionnairesForSelectionInOrder((int)valuesForNextPageStart[0], (int)valuesForNextPageStart[1], this.questionnaire, cMS.CMSID);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patients.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.AvailableQuestionnaires = questionnaires;
			
			return result;
		}


		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public AssessmentQuestionnaireOrderCollection AssessmentQuestionnaireOrders
		{
			get { return assessmentQuestionnaireOrders; }
			set
			{
				assessmentQuestionnaireOrders = value;
				try
				{
					this.gridSelected.UpdateFromCollection(assessmentQuestionnaireOrders);  // update given grid from the collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(AssessmentQuestionnaireOrderCollection), assessmentQuestionnaireOrders);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Load AssessmentQuestionnaireOrders based on Dx/Px specified and Scoring Load
		/// Works only on empty collection.
		/// Should be called ONLY on initial page load.
		/// </summary>
		private void LoadDataForAssessmentQuestionnaireOrdersByDxPxAndScoringLoad()
		{
			if (AssessmentQuestionnaireOrders.Count > 0)
				return;
			try
			{
				// Load the questionnaire orders triggered by Scoring Load and CMS DxPx
				this.assessmentQuestionnaireOrders.LoadQuestionnaireOrdersTriggeredForDxPxAndScoringLoad(assessment.ContentOwnerID, cMS);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
			}
			
			this.AssessmentQuestionnaireOrders = this.assessmentQuestionnaireOrders;
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForAssessmentQuestionnaireOrders()
		{
			try
			{	//customize this method for this specific page
				gridSelected.UpdateToCollection(assessmentQuestionnaireOrders);
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Questionnaire Questionnaire
		{
			get { return questionnaire; }
			set
			{
				questionnaire = value;
				try
				{
					this.UpdateFromObject(this.pnlFilter.Controls, questionnaire);  // update controls for the given control collection

					if (questionnaire.QuestionnaireTypeID == 0)
						this.QuestionnaireTypeID.SelectedRow = this.QuestionnaireTypeID.Rows[0];
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Questionnaire), questionnaire);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForQuestionnaire()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlFilter.Controls, questionnaire);	// controls-to-object
				this.Questionnaire = questionnaire;
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewQuestionnaire()
		{
			bool result = true;
			Questionnaire questionnaire = null; //new Questionnaire(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				questionnaire = new Questionnaire();
				questionnaire.PrototypeInstance = true; // Set this so that we'll get the All option
				questionnaire.QuestionnaireTypeID = 0; //setting default - All.
				questionnaire.ContentOwnerID = assessment.ContentOwnerID;
				questionnaire.ActiveWithAll = 1;		// Always working with active Questionnaires
				questionnaire.CMSTypeID = cMS.CMSTypeID;		// Always working with CMSType of given CMS
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.Questionnaire = questionnaire;
			return result;
		}
		#endregion

		private void wbtnAddChecked_Click(object sender, System.EventArgs e)
		{
			ReadControlsForAssessmentQuestionnaireOrders();
			AddQuestionnaires();
			this.ScrollToControl(this.pnlGridSelected);
		}

		private void wbtnSearch_Click(object sender, System.EventArgs e)
		{
			displayRowCountMessage = true;
			LoadDataForAvailableQuestionnaires();
			this.AvailableQuestionnaires = availableQuestionnaires;
			this.ScrollToControl(this.pnlGridAvailable);
		}

		private void butSearchPrevious_Click(object sender, System.EventArgs e)
		{
			ReadControlsForAssessmentQuestionnaireOrders();
			AddQuestionnaires();
			SearchNext(PagingDirection.PreviousPage);
		}

		private void butSearchNext_Click(object sender, System.EventArgs e)
		{
			ReadControlsForAssessmentQuestionnaireOrders();
			AddQuestionnaires();
			SearchNext(PagingDirection.NextPage);
		}

//		private void gridAvailable_DblClick(object sender, ClickEventArgs e)
//		{
//			int index = gridAvailable.GetColIndexFromClickEvent(e);
//			if (index >= 0)
//			{
//				((SelectableQuestionnaire)availableQuestionnaires[index]).Selected = true;
//
//				// Call the general method
//				AddQuestionnaires();
//			}
//		}
//
//		private void gridSelected_DblClick(object sender, ClickEventArgs e)
//		{
//			int i = this.gridSelected.GetColIndexFromClickEvent(e);
//			if(i < 0) 
//				return;
//			this.assessmentQuestionnaireOrders[i].MarkDel();
//			AssessmentQuestionnaireOrders = assessmentQuestionnaireOrders;
//		}
	}
}
