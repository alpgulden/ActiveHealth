using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;


namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("ImageBase,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Images")]
	[PageTitle("@IMAGES@")]
	public class ImageSearch : PatientBasePage
	{
		private ImageBase imageBase;
		private ImageBaseCollection imageBaseCol;
		private ImageLink imageLink;
		private ImageLinkCollection imageLinkCol;
		private ImageLinkCollection imageLinkColByImageId;

		private EnumActivityAndNoteContext context;
		private Patient patient;
		private Problem problem;
		private PatientCoverage patientCoverage;
		private BaseForEventCMSReferral erc;			// any one of these:  Event, CMS, Referral
		private PRRequest prr;
		private int filterImages;
		private string ImagePath;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL2;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBLabel lbRule;
		protected NetsoftUSA.WebForms.OBRadioButtonBox imgFilterOption;
		protected NetsoftUSA.WebForms.OBRadioButtonBox recFilterOption;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridImages;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlImages;
		protected NetsoftUSA.WebForms.OBLabel OBLABEL1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlImageEntry;
		protected NetsoftUSA.WebForms.OBLabel Oblabel2;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridImageLink;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlImageLink;
		protected System.Web.UI.HtmlControls.HtmlInputFile imgUpload;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ImageFileName;
		protected NetsoftUSA.InfragisticsWeb.WebButton butUpload;
		protected System.Web.UI.WebControls.Image ImgDisplay;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here			
			
			// get the image folder from system value control table
			
			ImagePath = SystemControlValue.GetInstance.ImageLibraryPath;
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				context = (EnumActivityAndNoteContext)this.LoadObject("EnumActivityAndNoteContext");
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache				
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				erc = (BaseForEventCMSReferral)this.LoadObject(typeof(BaseForEventCMSReferral));  // load object from cache
				prr = (PRRequest)this.LoadObject(typeof(PRRequest));  // load object from cache
//				if (this.Cache["filterImages"]!=null)
//					filterImages = int.Parse(this.Cache["filterImages"].ToString());

				imageBase = (ImageBase)this.LoadObject(typeof(ImageBase));
//				imageBaseCol = (ImageBaseCollection)this.LoadObject(typeof(ImageBaseCollection));
				imageLinkCol = (ImageLinkCollection)this.LoadObject(typeof(ImageLinkCollection));
				
//				LoadFilterImages();

			}
		}

		protected override object SaveViewState()
		{
			ViewState["filterImages"]=this.filterImages;
			return base.SaveViewState ();
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
			this.filterImages=(int)ViewState["filterImages"];
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			try
			{					
				object objContext = GetParamOrGetFromCache("EnumActivityAndNoteContext", "context");
				context = (EnumActivityAndNoteContext)Convert.ToInt32(objContext);
				patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
				// get the passed patient subscriber coverage (link to patient)
				patientCoverage = GetParamOrGetFromCache("PatientCoverage", typeof(PatientCoverage)) as PatientCoverage;
				if (patientCoverage == null)	
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-subscriber-coverage");
				problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
				erc = this.GetParamOrGetFromCache("ERC", typeof(BaseForEventCMSReferral)) as BaseForEventCMSReferral;
				prr = this.GetParamOrGetFromCache("PRR", typeof(PRRequest)) as PRRequest;
				if (patient == null && erc == null && prr == null)
				{
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an event/referral/CMS or Physician Review");
				}
				BindIMGFilterOptions();
				BindRECFilterForProblem();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//referral.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!			
			}
			this.CacheObject("EnumActivityAndNoteContext", context);
			this.CacheObject(typeof(Patient), patient);
			this.CacheObject(typeof(PatientCoverage), patientCoverage);
			this.CacheObject(typeof(Problem), problem);
			this.CacheObject(typeof(BaseForEventCMSReferral), erc);
			this.CacheObject(typeof(PRRequest), prr);
			LoadDataForImages();
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForImages()
		{
			bool result = true;
			// use any load method here
//			imageBase = this.GetParamOrGetFromCache("ImageBase",typeof(ImageBase)) as ImageBase;
//			imageLink = this.GetParamOrGetFromCache("ImageLink",typeof(ImageLink)) as ImageLink;

			ImageLinkCollection imageLinkCol = null;
			try
			{	// use any load method here
				if(prr == null && erc==null)
				{
					patient.LoadImages(false);
					imageLinkCol = patient.Images;
				}
				else
				{
					if(prr != null)
					{
						prr.LoadImages(false);
						imageLinkCol = prr.Images;
					}
					else
					{
						erc.LoadImages(false);
						imageLinkCol = erc.Images;
					}
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//outcomes.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.ImageLinkCol=imageLinkCol;
			return result;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
//
//			if(imageBase!=null && imageBase.IsNew)
//			{
//				SetPageToolbarItemVisible("Save", true);
//				SetPageToolbarItemVisible("Cancel", true);
//			}

			SetPageToolbarItemVisible("Save", !gridImages.Visible);

			SetPageTabToolbarItemVisible("AddImage", context != EnumActivityAndNoteContext.Patient);
			
			int pk =gridImages.SelectedRowIndex;
			if(ImageLinkCol!=null && pk>=0)
			{				
				SetPageTabToolbarItemVisible("Activate", !this.pnlImageEntry.Visible && !ImageLinkCol[pk].Active);
				SetPageTabToolbarItemVisible("Terminate",!this.pnlImageEntry.Visible && ImageLinkCol[pk].Active);			
				SetPageTabToolbarItemVisible("Link", context!=EnumActivityAndNoteContext.Patient);
				SetPageToolbarItemVisible("Save", true);
			}
			//showImage();
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("ImageSearch.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, BaseForEventCMSReferral erc, PRRequest prr)
		{
			if (patient == null && erc==null && prr == null)
				throw new ActiveAdviceException("You can open images only in the context of patient and event/referral/cms or PhysicianReview"); 

			BasePage.PushCurrentCallingPage();
			
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("ERC", erc);
			BasePage.PushParam("PRR", prr);
			//NSGlobal.ClearCache();
			BasePage.Redirect("ImageSearch.aspx");
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, BaseForEventCMSReferral erc, PRRequest prr, EnumActivityAndNoteContext context)
		{
			if (patient == null && erc==null && prr == null)
				throw new ActiveAdviceException("You can open images only in the context of patient and event/referral/cms or PhysicianReview"); 

			BasePage.PushCurrentCallingPage();
			
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("ERC", erc);
			BasePage.PushParam("PRR", prr);
			BasePage.PushParam("EnumActivityAndNoteContext", context);
			//NSGlobal.ClearCache();
			BasePage.Redirect("ImageSearch.aspx");
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{   
			this.imgFilterOption.SelectedIndexChanged += new System.EventHandler(this.imgFilterOption_SelectedIndexChanged);
			this.recFilterOption.SelectedIndexChanged += new System.EventHandler(this.recFilterOption_SelectedIndexChanged);
			this.gridImages.SelectedRowIndexChanged += new System.EventHandler(this.gridImages_SelectedRow);
			this.gridImages.Click += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.gridImages_Click);
			this.butUpload.Click += new System.EventHandler(this.butUpload_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		//update this code to get patient summary
//		public override void RenderPageSummary(PageSummary pageSummary)
//		{
//			base.RenderPageSummary (pageSummary);
//			if(autoActivityRuleException==null)
//				pageSummary.RenderObjects(this.autoActivityRule);
//			else
//				pageSummary.RenderObjects(this.autoActivityRuleException.ParentAutoActivityRuleExceptionCollection.ParentAutoActivityRule,this.autoActivityRuleException);
//		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.erc);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			switch (tab.Key)
			{
				case "Images":
					toolbar.AddButton("@ADDNEWRECORD@", "AddImage");
					toolbar.AddButton("@PRINT@", "Print");
					toolbar.AddButton("@ACTIVATEIMG@", "Activate").Visible=false;
					toolbar.AddButton("@TERMINATEIMG@", "Terminate").Visible=false;
					toolbar.AddButton("@LINKOBJ@", "Link").Visible=false;
				//	toolbar.AddButton("@DISPLAY@", "Display").Item.TargetURL = "javascript:" + wo.getWindowOpenScript();
					break;
			}
		}
		
		public void OnToolbarButtonClick_AddImage(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewImage();
		}

		public void OnToolbarButtonClick_OpenFolder(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			//OpenFolder();
		}
				
		public void OnToolbarButtonClick_Activate(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			ActivateImage();
		}

		public void OnToolbarButtonClick_Terminate(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			TeminateImage();
		}
		
		public void OnToolbarButtonClick_Link(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			LinkImage();
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
	
			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddButton("@SAVERECORD@", "Save").Visible = false;
			toolbar.AddButton("@CANCEL@", "Cancel").Visible = false;;
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@IMAGE@");
			}
		}
//
//		public void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
//		{
////			if(autoActivityInitializationValue==null)
////				AutoActivityForm.Redirect(autoActivityRule);
////			else
////			{
////				autoActivityInitializationValue = null;
////				this.AutoActivityInitializationValue = autoActivityInitializationValue;
////			}
//
//			this.imgFilterOption.Visible=true;
//			this.recFilterOption.Visible=true;
//			this.gridImages.Visible = true;
//			this.ImgDisplay.Visible=false;
//			this.pnlImageEntry.Visible = false; 
//			this.pnlImageLink.Visible=false;
//
//			if(imageBase!=null && imageBase.IsDirty)
//			{
//				if(File.Exists(ImagePath + this.ImageFileName.Value))
//					File.Delete(ImagePath + this.ImageFileName.Value);
//			}
//
//			imageBase = null;
//			imageLink = null;
//		}

//		private void gridImages_ColumnsBoundToDataClass(object sender, System.EventArgs e)
//		{
//			gridImages.AddButtonColumn("EDIT","EDIT",0);
//		}

//		private void gridImages_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
//		{
//			//string colName = grid.GetColumnKeyFromCellEvent(e);
//			string colName = e.Cell.Key;
//			if (colName == "EDIT")
//			{
//				int pk =(int)(e.Cell.Row.DataKey);
//				try
//				{
//					imageBase = (ImageBase)(imageLinkCol.ParentImageBase);
//					this.ImageBase = imageBase;
//				}
//				catch(Exception ex)
//				{
//					this.RaisePageException(ex);
//				}
//			}
//		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>	
		public ImageBase ImageBase
		{
			get { return imageBase; }
			set
			{
				imageBase = value;
				try
				{
					if(imageBase!=null)
					{
//						// show list
//						ImageBaseCollection imageBaseCol = new ImageBaseCollection();						
//						imageBaseCol.LoadAllImages(-1);						
//						this.ImageBaseCol = imageBaseCol;
//					}
//					else
//					{
						// new or edit group
						this.UpdateFromObject(pnlImageEntry.Controls, imageBase);  // update controls for the given control/collection
						
						if(imageBase.IsNew)
						{
							this.gridImages.Visible = false;
							this.imgFilterOption.Visible=false;
							this.recFilterOption.Visible=false;
							this.imgUpload.Visible=true;
							this.butUpload.Visible=true;
							this.Description.Enabled=true;
							this.Note.Enabled=true;
						}
						else
						{
							this.imgUpload.Visible=false;
							this.butUpload.Visible=false;
							this.Description.Enabled=false;
							this.Note.Enabled=false;
						}
						if(this.ImageFileName!=null)
							this.ImgDisplay.Visible=false;
						else
							this.ImgDisplay.Visible=true;
						this.pnlImageEntry.Visible = true;
						this.pnlImageLink.Visible=false;
						showImage();
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(ImageBase), imageBase);  // cache object using the caching method declared on the page
			}
		}

//		/// <summary>
//		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
//		/// </summary>
//		public ImageBaseCollection ImageBaseCol
//		{
//			get { return imageBaseCol; }
//			set
//			{
//				imageBaseCol = value;
//				try
//				{
//					this.gridImages.UpdateFromCollection(imageBaseCol);
//					this.UpdateFromObject(this.pnlImages.Controls,imageBaseCol);	
//					// this panel is using to fill combobox
//
//					this.pnlImages.Visible = true;
//					this.pnlImageEntry.Visible = false;
//				}
//				catch(Exception ex)
//				{
//					this.RaisePageException(ex);  // notify the page about the error
//				}
//				this.CacheObject(typeof(ImageBaseCollection), imageBaseCol);  // cache object using the caching method declared on the page
//			}
//		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ImageLinkCollection ImageLinkCol
		{
			get { return imageLinkCol; }
			set
			{
				imageLinkCol = value;
				try
				{
					this.gridImages.UpdateFromCollection(imageLinkCol);
					this.UpdateFromObject(this.pnlImages.Controls,imageLinkCol);	
					// this panel is using to fill combobox

					this.imgFilterOption.Visible=true;
					this.recFilterOption.Visible=true;
					this.gridImages.Visible = true;
					this.ImgDisplay.Visible=false;
					this.pnlImageEntry.Visible = false;
					this.pnlImageLink.Visible=false;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(ImageLinkCollection), imageLinkCol);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ImageLinkCollection ImageLinkColByImageId
		{
			get { return imageLinkColByImageId; }
			set
			{
				imageLinkColByImageId = value;
				try
				{
					this.gridImageLink.UpdateFromCollection(imageLinkColByImageId);
					this.UpdateFromObject(this.pnlImageLink.Controls,imageLinkColByImageId);	
					this.imgFilterOption.Visible=true;
					this.recFilterOption.Visible=true;
					this.gridImages.Visible = true;
					this.ImgDisplay.Visible=false;
					this.pnlImageEntry.Visible = false;
					this.pnlImageLink.Visible=true;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlImageEntry.Controls, imageBase);
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

//		/// <summary>
//		/// Passes the given object to the redirected page.
//		/// </summary>
//		public static void Redirect(AutoActivityRule autoActivityRule,AutoActivityRuleException autoActivityRuleException)
//		{
//			BasePage.PushCurrentCallingPage();
//			BasePage.PushParam("AutoActivityRule", autoActivityRule);			
//			BasePage.PushParam("AutoActivityRuleException", autoActivityRuleException);
//			BasePage.Redirect("ActivityValuesForm.aspx");		
//		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				if(imageBase!=null && imageBase.IsNew)
				{
					imageBase.Save();

					// update image name for new images
					string temp,newtemp="";
					if(imageBase.ImageFileName!=null)
					{
						temp = imageBase.ImageFileName;
						if(temp.IndexOf(Session.SessionID)>=0)
							newtemp = temp.Replace(Session.SessionID,imageBase.ImageBaseID.ToString());
						imageBase.ImageFileName = newtemp;

						// rename file
						if(File.Exists(ImagePath + temp) && newtemp!="")
							File.Move(ImagePath + temp,ImagePath + newtemp);
					
						//imageBase.RecoverRecordState();
						imageBase.Save();
					}
					SaveNewImageLink();
				}
				else
					SaveImageLink();
				imageBase = null;
				this.ImageBase = imageBase;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			//NSGlobal.ClearCache();
			return true;
		}

		public bool SaveImageLink()
		{
			try{
				if(context==EnumActivityAndNoteContext.Patient)
					patient.SaveImages();
				else
				{
					if(prr != null)
						prr.SaveImages();
					else
						erc.SaveImages();
				}
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public bool SaveNewImageLink()
		{
			try
			{
				ImageLink imageLink = new ImageLink(true,imageBase.ImageBaseID,patient.PatientId);
				imageLink.Active = true;
				imageLinkCol.AddRecord(imageLink);
				if(prr != null)
					prr.SaveImages();
				else
					erc.SaveImages();
				this.ImageLinkCol = imageLinkCol;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}


		public bool NewImage()
		{
			bool result = true;
			try
			{	
				ImageBase imageBase = new ImageBase(true); // use a parameterized constructor which also initializes the data object				
				this.ImageBase= imageBase;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}			
			return result;
		}


		private void gridImages_SelectedRow(object sender,EventArgs e)
		{	
			try
			{
				imageBase = GetSelectedImage();
				if(imageBase!=null)
					this.ImageBase = imageBase;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		public ImageBase GetSelectedImage()
		{
			try
			{
				int ImageBaseID = 0;
				if(imageLinkCol!=null && imageLinkCol.Count>0)
					ImageBaseID = (int)gridImages.SelectedRowPK[0];
				ImageBase img = new ImageBase();
				if (img.Load(ImageBaseID))
					return img;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}

			return null;
		}
        
		private void gridImages_Click(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{	
			int pk =gridImages.GetColIndexFromClickEvent(e);
			try
			{
				imageBase = (ImageBase)(imageLinkCol[pk].ParentImageBase);
				this.ImageBase = imageBase;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void imgFilterOption_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			LoadFilterImages();
		}

		private void recFilterOption_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			LoadFilterRecords();
		}


		private void BindIMGFilterOptions()
		{
			imgFilterOption.Items.Clear();
			if(patient != null)
			{
				imgFilterOption.Items.Add(new ListItem(PatientMessages.PATIENT, "@PATIENT@"));
				imgFilterOption.SelectedIndex = 0;
			}
			if(prr != null)
			{
				imgFilterOption.Items.Add(new ListItem("@PHYSICIANREVIEWREQUEST@", "PRR"));
				imgFilterOption.SelectedIndex = 1;
			}
			if(erc != null && context!=EnumActivityAndNoteContext.Patient)
			{
				if(erc.ERCType==EnumERCType.Event)
					imgFilterOption.Items.Add(new ListItem(PatientMessages.EVENT, EnumERCType.Event.ToString()));				
				if(erc.ERCType==EnumERCType.CMS)
					imgFilterOption.Items.Add(new ListItem(PatientMessages.CMS, EnumERCType.CMS.ToString()));
				if(erc.ERCType==EnumERCType.Referral)
					imgFilterOption.Items.Add(new ListItem(PatientMessages.REFERRAL, EnumERCType.Referral.ToString()));
				imgFilterOption.SelectedIndex = 1;		
			}			
		}

		private void BindRECFilterForProblem()
		{
			recFilterOption.Items.Clear();
			recFilterOption.Items.Add(new ListItem(PatientMessages.ACTIVE, "@ACTIVE@"));
			recFilterOption.Items.Add(new ListItem(PatientMessages.ALL, "@ALL@"));
			recFilterOption.SelectedIndex = 0;
		}

		public bool ActivateImage()
		{
			bool result = true;
			ImageLink imgLink;
			try
			{	
				if(ImageLinkCol!=null && gridImages.SelectedRowIndex>=0)
				{
					int pk =gridImages.SelectedRowIndex;
//					imgLink = (ImageLink)ImageLinkCol[pk];
					ImageLinkCol[pk].Active = true;
//					imgLink.Active = true;
//					imgLink.Save();
					ImageLinkCol[pk].MarkDirty();
					//ImageLinkCol[pk].Save();
					this.SetPageMessage("@IMAGEACTIVATE@", EnumPageMessageType.Info, "@IMAGE@");
					this.ImageLinkCol = imageLinkCol;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}			
			return result;
		}

		public bool TeminateImage()
		{
			bool result = true;
			try
			{	
				if(ImageLinkCol!=null && gridImages.SelectedRowIndex>=0)
				{
					int pk =gridImages.SelectedRowIndex;
					ImageLinkCol[pk].Active = false;
					ImageLinkCol[pk].MarkDirty();
					//ImageLinkCol[pk].Save();
					this.SetPageMessage("@IMAGETERMINATE@", EnumPageMessageType.Info, "@IMAGE@");
					this.ImageLinkCol=ImageLinkCol;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}			
			return result;
		}

		public bool LoadFilterImages()
		{
			bool result = true;
			try
			{					
				string selected = this.imgFilterOption.SelectedValue;

				switch(selected)
				{
					case "@PATIENT@":
						filterImages = patient.PatientId;						
						//imageLinkCol = patient.Images;
						if(this.recFilterOption.SelectedValue == "@ACTIVE@")
							imageLinkCol.LoadActiveImageLinksByPatientId(-1,filterImages);
						else
							imageLinkCol.LoadImageLinksByPatientId(-1,filterImages);
						break;
					case "Event":
						filterImages=erc.ID;
						//imageLinkCol = erc.Images;
						if(this.recFilterOption.SelectedValue == "@ACTIVE@")
							imageLinkCol.LoadActiveImageLinksByEventId(-1,patient.PatientId,filterImages);
						else
							imageLinkCol.LoadImageLinksByEventId(-1,patient.PatientId,filterImages);
						break;
					case "Referral":
						filterImages = erc.ID;
						//imageLinkCol = erc.Images;
						if(this.recFilterOption.SelectedValue == "@ACTIVE@")
							imageLinkCol.LoadActiveImageLinksByReferralId(-1,patient.PatientId,filterImages);
						else
							imageLinkCol.LoadImageLinksByReferralId(-1,patient.PatientId,filterImages);
						break;
					case "CMS":
						filterImages=erc.ID;
						//imageLinkCol = erc.Images;
						imageLinkCol.LoadActiveImageLinksByCMSId(-1,patient.PatientId,filterImages);
						break;
					case "@PRR@":
						filterImages = prr.PRRequestID;
						//imageLinkCol = pr.Images;
						if(this.recFilterOption.SelectedValue=="@ACTIVE@")
							imageLinkCol.LoadActiveImageLinksByPRRId(-1,patient.PatientId,filterImages);
						else
							imageLinkCol.LoadImageLinksByPRRId(-1,patient.PatientId,filterImages);
						break;
				}				
				this.ImageLinkCol= imageLinkCol;
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}			
			return result;
		}	

		public bool LoadFilterRecords()
		{
			bool result = true;
			string selected;
			try
			{					
				selected = this.recFilterOption.SelectedValue;

				if(selected=="@ACTIVE@")
				{
					selected = this.imgFilterOption.SelectedValue;
					switch(selected)
					{
						case "@PATIENT@":
							filterImages = patient.PatientId;						
							//imageLinkCol = patient.Images;
							imageLinkCol.LoadActiveImageLinksByPatientId(-1,filterImages);
							break;
						case "Event":
							filterImages = erc.ID;
							//imageLinkCol = erc.Images;
							imageLinkCol.LoadActiveImageLinksByEventId(-1,patient.PatientId,filterImages);
							break;
						case "Referral":
							filterImages = erc.ID;
							//imageLinkCol = erc.Images;
							imageLinkCol.LoadActiveImageLinksByReferralId(-1,patient.PatientId,filterImages);
							break;
						case "CMS":
							filterImages = erc.ID;
							//imageLinkCol = erc.Images;
							imageLinkCol.LoadActiveImageLinksByCMSId(-1,patient.PatientId,filterImages);
							break;
						case "@PRR@":
							filterImages = prr.PRRequestID;
							//imageLinkCol = pr.Images;
							imageLinkCol.LoadActiveImageLinksByPRRId(-1,patient.PatientId,filterImages);
							break;
					}
				}
				else
				{
					selected = this.imgFilterOption.SelectedValue;
					switch(selected)
					{
						case "@PATIENT@":
							filterImages = patient.PatientId;						
							//imageLinkCol = patient.Images;
							imageLinkCol.LoadImageLinksByPatientId(-1,filterImages);
							break;
						case "Event":
							filterImages = erc.ID;
							//imageLinkCol = erc.Images;
							imageLinkCol.LoadImageLinksByEventId(-1,patient.PatientId,filterImages);
							break;
						case "Referral":
							filterImages = erc.ID;
							//imageLinkCol = erc.Images;
							imageLinkCol.LoadImageLinksByReferralId(-1,patient.PatientId,filterImages);
							break;
						case "CMS":
							filterImages = erc.ID;
							//imageLinkCol = erc.Images;
							imageLinkCol.LoadImageLinksByCMSId(-1,patient.PatientId,filterImages);
							break;
						case "@PRR@":
							filterImages = prr.PRRequestID;
							//imageLinkCol = pr.Images;
							imageLinkCol.LoadImageLinksByPRRId(-1,patient.PatientId,filterImages);
							break;
					}
				}
				this.ImageLinkCol= imageLinkCol;				
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}			
			return result;
		}

		public bool LinkImage()
		{
			bool result = true;
			ImageLink tempLink = new ImageLink(false);			
			imageLinkColByImageId = new ImageLinkCollection();			
			try
			{	
				if(ImageLinkCol != null && gridImages.SelectedRowIndex >= 0)
				{
					int pk = gridImages.SelectedRowIndex;
					tempLink = (ImageLink)ImageLinkCol[pk];
					imageLinkColByImageId.LoadImageLinksByImageId(-1,ImageLinkCol[pk].ImageBaseID, ImageLinkCol[pk].PatientID);
					if(prr != null)
					{
						if(imageLinkColByImageId.FindBy(tempLink.ImageBaseID, prr.PRRequestID,4) == null)
						{
							tempLink.PRRequestID = prr.PRRequestID;
							tempLink.IsNew=true;
							imageLinkColByImageId.AddRecord(tempLink);
						}
					}
					else if(erc != null && context != EnumActivityAndNoteContext.Patient)
					{
						if(erc.ERCType == EnumERCType.Event)
						{
							if(imageLinkColByImageId.FindBy(tempLink.ImageBaseID,erc.ID,2) == null)
							{
								tempLink.EventID = erc.ID;
								tempLink.IsNew = true;
								imageLinkColByImageId.AddRecord(tempLink);
							}								
						}
						if(erc.ERCType == EnumERCType.CMS)
						{
							if(imageLinkColByImageId.FindBy(tempLink.ImageBaseID,erc.ID,3) == null)
							{
								tempLink.CMSID = erc.ID;
								tempLink.IsNew = true;
								imageLinkColByImageId.AddRecord(tempLink);
							}								
						}
						if(erc.ERCType == EnumERCType.Referral)
						{
							if(imageLinkColByImageId.FindBy(tempLink.ImageBaseID,erc.ID,4) == null)
							{
								tempLink.ReferralID = erc.ID;
								tempLink.IsNew = true;
								imageLinkColByImageId.AddRecord(tempLink);
							}
						}					
						this.ImageLinkColByImageId = imageLinkColByImageId;
						this.SetPageMessage("@LINKIMG@",EnumPageMessageType.Info, "@IMAGE@");
						tempLink=null;
					}
					else 
						result=false;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}			
			return result;
		}

		private bool processFile()
		{	
			bool result = true;
			int intThumbWidth =  85;
			int intThumbHeight = 135;
			string ext;
			string fileName;
			if (imgUpload.PostedFile != null)
			{				
				if (imgUpload.PostedFile.ContentLength == 0)
				{
					this.SetPageMessage("@NOFILEMSG@",EnumPageMessageType.Error);
					result= false;
				}
				
				// rename the file with SessionID
				HttpPostedFile imageFile = imgUpload.PostedFile;
				byte[] myData = new Byte[imgUpload.PostedFile.ContentLength];
				imageFile.InputStream.Read(myData,0,imgUpload.PostedFile.ContentLength);
				// Save the stream to disk
				//Session.SessionID + 
				//System.IO.FileStream newFile = new System.IO.FileStream(Server.MapPath("../ProductImages/" + System.IO.Path.GetFileNameWithoutExtension(imgUpload.PostedFile.FileName) + System.IO.Path.GetExtension(imgUpload.PostedFile.FileName)), System.IO.FileMode.Create);

				// Check extention if need.//
				ext = System.IO.Path.GetExtension(imgUpload.PostedFile.FileName);
				if(ext.Equals(".JPG") || ext.Equals(".jpg") || ext.Equals(".JEPG") || ext.Equals(".jepg") || ext.Equals(".TIF") || ext.Equals(".tif") || ext.Equals(".TIFF") || ext.Equals(".tiff") || ext.Equals(".GIF") || ext.Equals(".gif") || ext.Equals(".BMP") || ext.Equals(".bmp"))
				{				//string imagename=System.IO.Path.GetFileNameWithoutExtension(imgUpload.PostedFile.FileName);
					if(imageBase.IsNew)
						fileName=Session.SessionID.ToString();
					else
					{
						fileName=imageBase.ImageBaseID.ToString();
					}
					System.IO.FileStream newFile = new System.IO.FileStream(ImagePath + fileName + ext, System.IO.FileMode.Create);
					newFile.Write(myData,0, myData.Length);
					newFile.Close();
					this.ImageFileName.Value = fileName + ext;
				}
				else
				{
					this.SetPageMessage("@NOIMGFILEMSG@",EnumPageMessageType.Error);
					result= false;
				}
			}
			else
			{
				this.SetPageMessage("@NOFILEMSG@",EnumPageMessageType.Error);
				result= false;
			}
			return result;
		}

		private void showImage()
		{
			if(this.ImageFileName.Value != "")
			{
				this.ImgDisplay.ImageUrl = "file://" + ImagePath + this.ImageFileName.Value;
				this.ImgDisplay.Visible=true;
			}
		}

		private void butUpload_Click(object sender, System.EventArgs e)
		{
			try
			{
				processFile();
				showImage();
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}		
		}
	}
}

