using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using ActiveAdvice.Web.UserControls;

namespace ActiveAdvice.Web
{
	public class ERCMoveData
	{
		public int OldProblem;
		public int NewProblem;
		public int OldCMSEventReferral;
		public EnumERCType ErcType;
		public int NewCMSEventReferral;
	}

	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Question,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("")]					
	[SelectedMenuItem("@MAINTENANCE@")]
	[PageTitle("@MOVEERC@")]		// don't put a dummy @MESSAGEID@ in the template, the message may get created in the message table.
	public class ERCLinkMaintenance : BasePage
	{
		private CoverageSelectionContext coverageSelection;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel1;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnLoadPatient1Problems;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnLoadPatient2Problems;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected PatientSelect PatientSelect1;
		protected PatientSelect PatientSelect2;
		protected Patient		patient1;
		protected Patient		patient2;		
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProblems;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCMSEvents;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridProblems2;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridCMSEvents2;
		protected System.Web.UI.HtmlControls.HtmlTableCell tdpatient1;
		protected System.Web.UI.HtmlControls.HtmlTableCell tdpatient2;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnDontAdjustDate;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAdjustDates;
		protected System.Web.UI.HtmlControls.HtmlTable tblMain;
		protected System.Web.UI.HtmlControls.HtmlTable tblEffectiveDate;
		protected NetsoftUSA.WebForms.OBLabel lblAdjustDates;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAdjustDates;				
		protected NetsoftUSA.InfragisticsWeb.WebButton btnMoveERC;
		protected bool adjustServiceDate;
		protected ERCMoveData ercMoveData;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				LoadData();
			}
			else
			{
				this.patient1 = this.LoadObject("moveERCPatient1") as Patient;
				this.patient2 = this.LoadObject("moveERCPatient2") as Patient;
				coverageSelection = (CoverageSelectionContext)this.LoadObject("ERCCoverage");  // load object from cache
				object adjServ = this.LoadObject("AdjustServiceDate");				
				this.adjustServiceDate =  (adjServ == null) ? false : bool.Parse(adjServ.ToString());
				ercMoveData = this.LoadObject("ERCMoveData") as ERCMoveData;
				
			}							
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect()
		{
			BasePage.PushParam("ERCMoveData",null);
			BasePage.Redirect("ERCLinkMaintenance.aspx");
		}

		
		public static void Redirect(ERCMoveData ercMoveData)
		{
			BasePage.PushParam("ERCMoveData",ercMoveData);
			BasePage.Redirect("ERCLinkMaintenance.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			this.PatientSelect1.BindingEnabled = true;
			this.PatientSelect2.BindingEnabled = true;
			this.PatientSelect1.FieldsEnabled = false;
			this.PatientSelect2.FieldsEnabled = false;
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnLoadPatient1Problems.Click += new System.EventHandler(this.btnLoadPatient1Problems_Click);
			this.btnLoadPatient2Problems.Click += new System.EventHandler(this.btnLoadPatient2Problems_Click);
			this.gridProblems.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridProblems_ClickCellButton);
			this.gridProblems.SelectedRowIndexChanged += new System.EventHandler(this.gridProblems_SelectedRowIndexChanged);
			this.gridProblems.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridProblems_ColumnsBoundToDataClass);
			this.gridProblems2.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.gridProblems2_ClickCellButton);
			this.gridProblems2.SelectedRowIndexChanged += new System.EventHandler(this.gridProblems2_SelectedRowIndexChanged);
			this.gridProblems2.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.gridProblems2_ColumnsBoundToDataClass);
			this.gridCMSEvents.SelectedRowIndexChanged += new System.EventHandler(this.gridCMSEvents_SelectedRowIndexChanged);
			this.btnMoveERC.Click += new System.EventHandler(this.btnMoveERC_Click);
			this.gridCMSEvents2.SelectedRowIndexChanged += new System.EventHandler(this.gridCMSEvents2_SelectedRowIndexChanged);
			this.btnAdjustDates.Click += new System.EventHandler(this.btnAdjustDates_Click);
			this.btnDontAdjustDate.Click += new System.EventHandler(this.btnDontAdjustDate_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void LoadData()
		{

			// Load coverage object from session.
			coverageSelection = this.LoadObject(typeof(CoverageSelectionContext),false) as CoverageSelectionContext;
			ercMoveData = this.LoadObject("ERCMoveData") as ERCMoveData;
			// If the coverage object/ ERC Data is NULL we're not coming back from SelectCoverage page. So re-set all fields.
			if (coverageSelection == null || this.ercMoveData == null)
			{
				this.coverageSelection = new CoverageSelectionContext(new IntakeLog(true));				
				this.btnMoveERC.Enabled = false;
				this.Patient1 = new Patient();
				this.Patient2 = new Patient();
				this.AdjustServiceDate = false;				
			}
			else // Otherwise load from session.
			{
				this.Patient1 = this.LoadObject("moveERCPatient1") as Patient;
				this.Patient2 = this.LoadObject("moveERCPatient2") as Patient;
				this.CoverageSelection = coverageSelection;
				this.btnMoveERC.Enabled = true;								
				SetSelectedERCData(ercMoveData);
				/*object adjServ = this.LoadObject("AdjustServiceDate");
				this.AdjustServiceDate = (adjServ == null) ? false : bool.Parse(adjServ.ToString());*/

				// Check dates and display date screen if dates are out of sync.
				VerifyDatesAndMove(ercMoveData);
			}
						
		}
		protected bool AdjustServiceDate
		{
			get { return this.adjustServiceDate; }
			set 
			{
				this.adjustServiceDate = value; 
				this.CacheObject("AdjustServiceDate",this.adjustServiceDate);
			}
		}

		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);			
		}

		private void gridCMSEvents2_SelectedRowIndexChanged(object sender, System.EventArgs e)
		{
			this.SetMoveEnabled();			
		}

		private void AdjustEventCoverageDates(bool adjust)
		{
			if (adjust) // Check whether the user wanted to adjust the dates or not.
			{
				// -- Adjust the date.				
				if (this.ercMoveData == null)
					return; // can't go forward without ercData.

				// Need to do the following in a transaction
				// so if anything goes wrong we don't end up with modified
				// date
				
				try
				{
					// Create ERC.					
					BaseForEventCMSReferral erc = ERCClassFactory.CreateERCAndLoad(ercMoveData.ErcType, this.patient1, ercMoveData.OldCMSEventReferral);
					this.coverageSelection.PatientCoverage.LatestCoverageData.EffectiveDate = erc.ERCStartDate;										
					// Adjust Coverage Effective Date
					this.coverageSelection.PatientCoverage.SqlData.BeginOuterTransaction();
					this.coverageSelection.PatientCoverage.LatestCoverageData.SqlData.Transaction = this.coverageSelection.PatientCoverage.SqlData.Transaction;
					this.coverageSelection.PatientCoverage.LatestCoverageData.Save(true);

					if (MovePatientERC(this.coverageSelection.PatientCoverage)) // Move Patient Data.
						this.coverageSelection.PatientCoverage.SqlData.CommitOuterTransaction();
					else
						this.coverageSelection.PatientCoverage.SqlData.RollbackOuterTransaction();


					// Update patient info on screen.
					this.Patient1 = patient1;
					this.Patient2 = patient2;					
					

				}
				catch (Exception ex)
				{
					this.SetPageMessage(ex.ToString(),EnumPageMessageType.Error);
				}
			}
			btnMoveERC.Enabled = true; // Move is enabled again.			
			this.pnlAdjustDates.Visible = false; // Close panel.
		}

		private void btnDontAdjustDate_Click(object sender, System.EventArgs e)
		{
			AdjustEventCoverageDates(false);
		}

		private void btnAdjustDates_Click(object sender, System.EventArgs e)
		{
			AdjustEventCoverageDates(true);
		}

		private void btnSelectCoverage_Click(object sender, System.EventArgs e)
		{
			// Check if items are selected. If not show message.

		}

		private void StartCoverageSelection()
		{
			if (gridProblems.SelectedRowIndex < 0 || gridCMSEvents.SelectedRowIndex < 0 || gridProblems2.SelectedRowIndex < 0)
			{
				this.SetPageMessage("@ERCPickEvent",EnumPageMessageType.Info);
				return;
			}
			BaseForEventCMSReferral erc = (BaseForEventCMSReferral)LoadPatientEvents(this.patient1, this.patient1.PatientProblems[this.gridProblems.SelectedColectionIndex].Problem, true).GetAt(this.gridCMSEvents.SelectedColectionIndex);
			
			// Items are selected. Create CoverageSelectionContext.			
			this.coverageSelection = new CoverageSelectionContext(false,this.patient2,null,this.Patient1.PatientProblems[this.gridProblems.SelectedColectionIndex].Problem, erc);
			
			
			// Set a new ercData, that will be passed to SelectAvailableCoverage.
			ERCMoveData ercData = new ERCMoveData();
			ercData.NewCMSEventReferral = this.gridCMSEvents2.SelectedRowPKInt;			
			ercData.NewProblem			= this.gridProblems2.SelectedRowPKInt;
			ercData.OldCMSEventReferral	= this.gridCMSEvents.SelectedRowPKInt;
			ercData.OldProblem			= this.gridProblems.SelectedRowPKInt;
			
			ercData.ErcType				= erc.ERCType;//GetERCType(this.patient1, this.patient1.PatientProblems[this.gridProblems.SelectedColectionIndex].Problem, this.gridCMSEvents.SelectedColectionIndex);


			this.CacheObject("ERCMoveData",ercData);
			SelectAvailableCoverage.Redirect(this.coverageSelection);
		}

		private void VerifyDatesAndMove(ERCMoveData ercData)
		{
			// Get the current coverage. If null return.
			if (this.coverageSelection == null || this.coverageSelection.PatientCoverage == null || this.coverageSelection.PatientCoverage.LatestCoverageData == null)
				return;
			
			if (this.Patient1 == null)
				return;
			
			// Not a vaild problem!
			if ((this.gridProblems.SelectedColectionIndex == -1 || this.gridProblems.SelectedColectionIndex >= this.Patient1.PatientProblems.Count))			
				return;
			
			ERCContainerCollection col = LoadPatientEvents(this.patient1, this.patient1.PatientProblems[this.gridProblems.SelectedColectionIndex].Problem, true);
			if (((TimeSpan)(((BaseForEventCMSReferral)col.GetAt(this.gridCMSEvents.SelectedColectionIndex)).ERCStartDate.Subtract(this.coverageSelection.PatientCoverage.LatestCoverageData.EffectiveDate))).Days >= 0)
			{
				BaseData bd = new ERCLinkMove();
				bd.SqlData.BeginOuterTransaction();
				if (MovePatientERC(bd)) // Dates are OK, go ahead and move patient ERC.
					bd.SqlData.CommitOuterTransaction();
				else
					bd.SqlData.RollbackOuterTransaction();
			
				this.Patient1 = patient1;
				this.Patient2 = patient2;
			}
			else
			{   // Dates are out of sync. Check if ElibilityAddAnyway is enabled.
				// if it is, show the panel to adjust dates. 
				if (this.coverageSelection.PatientCoverage.PlanSORG.EligibilityAddAnyway)
				{					
					this.CacheObject("ERCMoveData",ercData);
					this.pnlAdjustDates.Visible = true;
				}
				else
				{
					// If not show a message and disable move.
					this.SetPageMessage("@COVERAGENOTVALIDFORERC@",EnumPageMessageType.Warning);
					this.btnMoveERC.Enabled = false;
				}
			}
		}

		private bool MovePatientERC(BaseData tranInitiator)
		{		
			bool result = true;
			Problem patient1Problem = Patient1.PatientProblems[this.gridProblems.SelectedColectionIndex].GetProblem(); // Get patient problem.			
			
			#region AutoGenerated Event Check
			// First Check if the Event is AutoGenerated.
			EnumERCType type = GetERCType(this.Patient1,patient1Problem,this.gridCMSEvents.SelectedColectionIndex );
			if (type == EnumERCType.Event) // Working on an event.
			{				
				Event evt = new Event();				
				evt.Load(this.Patient1, this.gridCMSEvents.SelectedRowPKInt);
				if (evt.CMSAutoGenerated) // Auto Generated by a CMS Show exception, cannot move by itself.
				{
					this.SetPageMessage("@ERCMOVEAUTOEVENT@",EnumPageMessageType.Warning);					
					return false;
				}
			}
			#endregion
			
			string message;		// Message that will be returned from the stored proc.
							
			try
			{

				// Move patient Data.
				ERCLinkMove ercmove = new ERCLinkMove();
				ercmove.MoveERC(tranInitiator, this.PatientSelect2.PatientID,  this.Patient2.PatientProblems[this.gridProblems2.SelectedColectionIndex].ProblemId, this.PatientSelect1.PatientID, this.Patient1.PatientProblems[gridProblems.SelectedColectionIndex].ProblemId,this.gridCMSEvents.SelectedRowPKInt,GetERCType(this.Patient1,patient1Problem,this.gridCMSEvents.SelectedColectionIndex ), this.coverageSelection.PatientCoverage.SubscriberID, this.coverageSelection.Problem.PlanSORGLogID,AASecurityHelper.AAUser.UserId, out message);

				
				#region Set Page Message
				// Translate message here ("@MESSAGE@" -> "Message"..)
				string []prm = message.Split(','); // Split message returned by commas
				if (prm.Length > 0)
				{
					result = (prm[0].IndexOf("ERROR") >= 0) ? false : true;
					

					object [] vals = new object[prm.Length - 1];
					for (int i=1; i <= vals.Length; i++)
					{
						// Replace E, R, C with Event/Referral/CMS
						if (prm[i].ToString() == "E")
							prm[i] = Language.TranslateSingle("EVENT");
						else if (prm[i].ToString() == "R")
							prm[i] = Language.TranslateSingle("REFERRAL");
						else if (prm[i].ToString() == "C")
							prm[i] = Language.TranslateSingle("CMS");

						vals[i-1] = prm[i];
					}
					// Show message on page.
					this.SetPageMessage(this.Language.Translate(prm[0], vals), EnumPageMessageType.Info);					
				}		
				#endregion
			}
			catch (Exception ex)
			{				
				this.RaisePageException(ex);				
			}			
				return result;
			
			
	

		}


		private void btnMoveERC_Click(object sender, System.EventArgs e)
		{			
			if (this.Patient1 == null || this.Patient2 == null)
				return;

			StartCoverageSelection(); // First Redirect the user to the page for coverage Selection

			
		}

		private void gridCMSEvents_SelectedRowIndexChanged(object sender, System.EventArgs e)
		{
			 // Update button enabled property based on availability of selection.
			this.SetMoveEnabled();			
		}

		private void gridProblems2_SelectedRowIndexChanged(object sender, System.EventArgs e)
		{
			Problem problem = new Problem();
			problem.Load(this.Patient2,gridProblems2.SelectedRowPKInt);
			this.LoadPatientERC(this.Patient2,gridCMSEvents2,problem);	
			SetMoveEnabled();
			
		}

		private void SetMoveEnabled()
		{
			this.btnMoveERC.Enabled = (this.gridCMSEvents.SelectedRowIndex >= 0 && this.gridProblems2.SelectedRowIndex >= 0);
		}

		private static EnumERCType GetERCType(Patient patient, Problem problem, int index)
		{
			if (index < 0 || patient == null || problem == null)
				return EnumERCType.Undefined;
			ERCContainerCollection ercs = LoadPatientEvents(patient, problem, true);
			return ((BaseForEventCMSReferral)ercs.GetAt(index)).ERCType;
			
			
		}

		private void gridProblems2_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			switch (e.Cell.Key)
			{
				case "Select":
				default:
					Problem problem = new Problem();
					problem.Load(this.Patient2,gridProblems2.GetPKIntFromCellEvent(e));
					this.LoadPatientERC(this.Patient2,gridCMSEvents2,problem);
					break;
			}
		}

		private void gridProblems2_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridProblems2.AddButtonColumn("Select", "@SELECT@", 0).Width = 60;
		}

		private void btnLoadPatient2Problems_Click(object sender, System.EventArgs e)
		{
			int patientID = this.PatientSelect2.PatientID;
			if (patientID == 0)
			{
				this.SetPageMessage("@INVALIDPATIENTID@",EnumPageMessageType.Warning);
				return;
			}

			// Load Patient
			Patient patient = new Patient();
			patient.Load(patientID);
			
			
			this.Patient2 = patient;			
		}

		private void gridProblems_SelectedRowIndexChanged(object sender, System.EventArgs e)
		{
			Problem problem = new Problem();
			problem.Load(this.Patient1,gridProblems.SelectedRowPKInt);
			this.LoadPatientERC(this.Patient1,gridCMSEvents,problem);
		}

		private void SetSelectedERCData(ERCMoveData data)
		{
			if (data == null)
				return;
			// Set the OLD problem.
			if (this.gridProblems.Rows.Count > 0)			
				this.gridProblems.SelectedRowPKInt = data.OldProblem;
			// Set the NEW problem.
			if (this.gridProblems2.Rows.Count > 0)
				this.gridProblems2.SelectedRowPKInt = data.NewProblem;
			// Set the OLD cms.
			if (this.gridCMSEvents.Rows.Count > 0)
				this.gridCMSEvents.SelectedRowPKInt = data.OldCMSEventReferral;
			// Set the NEW cms.
			if (this.gridCMSEvents2.Rows.Count > 0)
				this.gridCMSEvents2.SelectedRowPKInt = data.NewCMSEventReferral;							
	}

		private void gridProblems_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			switch (e.Cell.Key)
			{
				case "Select":
				default:
					Problem problem = new Problem();
					problem.Load(this.Patient1,gridProblems.GetPKIntFromCellEvent(e));
					this.LoadPatientERC(this.Patient1,gridCMSEvents,problem);
					break;
			}
		}

		private void gridProblems_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridProblems.AddButtonColumn("Select", "@SELECT@", 0).Width = 60;
		}

		
		private void btnLoadPatient1Problems_Click(object sender, System.EventArgs e)
		{
			int patientID = this.PatientSelect1.PatientID;
			if (patientID == 0)
			{
				this.SetPageMessage("@INVALIDPATIENTID@",EnumPageMessageType.Warning);
				return;
			}
			// Load Patient
			Patient patient = new Patient();
			patient.Load(patientID);						
			this.Patient1 = patient;		
		}

		/// <summary>
		/// Load problems associated with the current patient
		/// </summary>
		public bool LoadPatientProblems(Patient patient,WebGrid problemGrid, WebGrid cmsEventGrid )
		{
			bool result = true;
			ProblemCollection problems = null; 
			try
			{	// use any load method here
				// or pull from the parameter passed to this page via PushParam
				if (patient == null)
					return false;
				patient.LoadPatientProblems(true);
				problems = patient.GetLinkedProblems();
				
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patient.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			// fill the problems collection and keep the PKs..
			problemGrid.KeepCollectionIndices = false;
			problemGrid.UpdateFromCollection(problems);

			if (problems.Count > 0)
			{
				this.LoadPatientERC(patient,cmsEventGrid,problems[0]);
				problemGrid.SelectedRowIndex = 0;
			}
			//this.SelectedProblemIndex = 0;			// unnecessary..  UpdateFromCollection already does it.
			return result;
		}

		private void SetLinkCheckboxUpdatable(WebGrid grid)
		{			
			grid.Columns.FromKey("IsLinkedToProblem").AllowUpdate =  AllowUpdate.No;
		}

		private static ERCContainerCollection LoadPatientEvents(Patient patient, Problem problem, bool linkedOnly)
		{	// We need to Load all types of collections then append them.		
			BaseCollectionForEventCMSReferral ercs = null;
			ERCContainerCollection allERC = new ERCContainerCollection();
			allERC.FilterLinkedOnly = linkedOnly;

			// Determine the linked events for the selected problem
			ercs = patient.GetLinkedERCs(EnumERCType.Event);			
			if (problem != null)
				ercs.DetermineElementsLinkedToProblem(problem);
			ercs.FilterLinkedOnly = linkedOnly;			
			allERC.AppendToCollection(ercs);

			// load referrals
			ercs = patient.GetLinkedERCs(EnumERCType.Referral);			
			if (problem != null)
				ercs.DetermineElementsLinkedToProblem(problem);
			ercs.FilterLinkedOnly = linkedOnly;
			allERC.AppendToCollection(ercs);			
			
			// load CMSs
			ercs = patient.GetLinkedERCs(EnumERCType.CMS);			
			if (problem != null)
				ercs.DetermineElementsLinkedToProblem(problem);
			ercs.FilterLinkedOnly = linkedOnly;			
			allERC.AppendToCollection(ercs);

			// now update from union of all ERC collections
			allERC.SortByStartDate(false, false);	// sort by ID in descending order
			if (problem != null)
					problem.UnloadParts(false);
			return allERC;

		}

		public bool LoadPatientERC(Patient patient, WebGrid grid, Problem problem)
		{
			if (patient == null || problem == null || grid == null)
				return false;
			bool result = true;
			BaseCollectionForEventCMSReferral ercs = null; 
			EnumERCType ercFilter = EnumERCType.All;
			try
			{	
				if (ercFilter == EnumERCType.All)
				{										
					SetLinkCheckboxUpdatable(grid);					
					grid.KeepCollectionIndices = false;				
					grid.UpdateFromCollection(LoadPatientEvents(patient,problem, true));		// append			
					return true;
				}

				ercs = patient.GetLinkedERCs(ercFilter);
				// Determine the linked events for the selected problem
				if (problem != null)
					ercs.DetermineElementsLinkedToProblem(problem);
				ercs.FilterLinkedOnly = true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//patient.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}

			// fill the problems collection and keep the PKs..
			grid.KeepCollectionIndices = false;
			SetLinkCheckboxUpdatable(grid);
			grid.UpdateFromCollection(ercs);

			// get rid of unnecessary child collections of problem
			if (problem != null)
				problem.UnloadParts(false);
			return result;
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.Cancel);
			toolbar.AddButton("@CANCEL@", "Cancel");
		}

		public ActiveAdvice.DataLayer.Patient Patient2
		{
			get { return this.patient2; }
			set 
			{ 
				this.patient2 = value;				
				this.CacheObject("moveERCPatient2",this.patient2);				
				this.LoadPatientProblems(patient2,this.gridProblems2,this.gridCMSEvents2);			
				this.UpdateFromObject(this.tdpatient2.Controls,patient2);
				PatientSelect2.UpdateGender();
			}
		}

		public ActiveAdvice.DataLayer.Patient Patient1
		{
			get { return this.patient1; }
			set { 

				this.patient1 = value;				
				this.LoadPatientProblems(patient1, this.gridProblems, this.gridCMSEvents);
				this.UpdateFromObject(this.tdpatient1.Controls,patient1);
				PatientSelect1.UpdateGender();
				this.CacheObject("moveERCPatient1",this.patient1);
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CoverageSelectionContext CoverageSelection
		{
			get { return coverageSelection; }
			set
			{
				coverageSelection = value;
				/*try
				{					
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}*/
				this.CacheObject("ERCCoverage", coverageSelection);  // cache object using the caching method declared on the page
			}
		}

		

	}
}
