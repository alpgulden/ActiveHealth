using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using ActiveAdvice.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.DataLayer;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for GuidelineSourceset.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.GUIDELINES),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.GUIDELINES_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.GuidelineMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("GuidelineSourceSet,DataLayer")]
	[BackPage(typeof(GuidelineCategoryProduct))]
	[SelectedMainMenuItem("MMaintenance")]
	[PageTitle("@GUIDELINESOURCESETTITLE@")]
	public class GuidelineSourceset :BasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebTab UltraWebTab1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSourcesets;
		protected NetsoftUSA.InfragisticsWeb.WebButton butAddNew;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.WebForms.OBCheckBox ReadOnly;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReadOnly;
		protected NetsoftUSA.WebForms.OBButton butSave;
		protected NetsoftUSA.WebForms.OBButton butCancel;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSourceset;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		private ActiveAdvice.DataLayer.GuidelineSourceSetCollection guidelineSourceSets;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCode;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCode;
		protected NetsoftUSA.WebForms.OBTextBox Code;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProductLabel;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProductLabel;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ProductLabel;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNote;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCategoryLabel;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCategoryLabel;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit CategoryLabel;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbExportDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldExportDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ExportDate;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		private ActiveAdvice.DataLayer.GuidelineSourceSet guidelineSourceSet;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
			{
				LoadData();
				pnlSourceset.Visible = false;
			}
			else
			{
				this.guidelineSourceSet = (GuidelineSourceSet)this.LoadObject(typeof(GuidelineSourceSet));
				this.guidelineSourceSets = (GuidelineSourceSetCollection)this.LoadObject(typeof(GuidelineSourceSetCollection));
			}
		}

		public bool LoadData()
		{
			try
			{
				NewGuidelineSourceSets();
				NewGuidelineSourceSet();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public bool NewGuidelineSourceSet()
		{
			bool result = true;
			try
			{
				GuidelineSourceSet guidelineSourceSet= new GuidelineSourceSet(true);
				guidelineSourceSet.Active = true;
				this.GuidelineSourceSet = guidelineSourceSet; 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return result;
		}

		public bool NewGuidelineSourceSets()
		{
			bool result = true;
			try
			{
				GuidelineSourceSetCollection col =	 new GuidelineSourceSetCollection();
				col.LoadAllGuidelineSourceSets(-1);
				this.GuidelineSourceSets = col;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return result;
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.grid.DblClick += new Infragistics.WebUI.UltraWebGrid.ClickEventHandler(this.grid_DblClick);
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.butAddNew.Click += new System.EventHandler(this.butAddNew_Click);
			this.butSave.Click += new System.EventHandler(this.butSave_Click);
			this.butCancel.Click += new System.EventHandler(this.butCancel_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void butAddNew_Click(object sender, System.EventArgs e)
		{
			this.pnlSourceset.Visible = true;
			NewGuidelineSourceSet();
		}

		private void butSave_Click(object sender, System.EventArgs e)
		{
			if(SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@GUIDELINESOURCESET@");
				this.pnlSourceset.Visible = false;
			}
		}

		private void butCancel_Click(object sender, System.EventArgs e)
		{
			this.pnlSourceset.Visible  = false;
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddButton("@CANCEL@","Cancel");
		}


		public bool SaveData()
		{
			if(!ReadControls())
				return false;
			try
			{
				this.guidelineSourceSet.Save();
				GuidelineSourceSetCollection.ClearFromCache();
				NewGuidelineSourceSets();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public bool ReadControls()
		{
			try
			{
				this.UpdateToObject(pnlSourceset.Controls,this.guidelineSourceSet);
				return  this.IsValid;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
		}
		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			object[] pk = grid.GetPKFromCellEvent(e);
			if (e.Cell.Key == "Edit")
			{
				try
				{
					GuidelineSourceSet sourceSet = new GuidelineSourceSet();
					if(!sourceSet.Load((int)pk[0]))
						throw new ActiveAdviceException("@CANTFINDRECORD@", "@GUIDELINESOURCESET@");
					this.GuidelineSourceSet = sourceSet;
					this.pnlSourceset.Visible = true;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void grid_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			try
			{
				object[] pk = grid.GetPKFromClickEvent(e);
				if (pk != null)
				{
					GuidelineSourceSet sourceSet = new GuidelineSourceSet();
					sourceSet.Load((int)pk[0]);
					this.GuidelineSourceSet = sourceSet;
					this.pnlSourceset.Visible = true;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		public ActiveAdvice.DataLayer.GuidelineSourceSet GuidelineSourceSet
		{
			get { return this.guidelineSourceSet; }
			set
			{
				this.guidelineSourceSet = value; 
				try
				{
					this.UpdateFromObject(pnlSourceset.Controls,guidelineSourceSet);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject(typeof(GuidelineSourceSet),guidelineSourceSet);
			}
		}

		public ActiveAdvice.DataLayer.GuidelineSourceSetCollection GuidelineSourceSets
		{
			get { return this.guidelineSourceSets; }
			set 
			{
				this.guidelineSourceSets = value; 
				try
				{
					grid.UpdateFromCollection(guidelineSourceSets);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
				this.CacheObject(typeof(GuidelineSourceSetCollection),guidelineSourceSets);
			}
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			this.CheckForDirty(this.guidelineSourceSet,this.guidelineSourceSets);
		}

	}
}
