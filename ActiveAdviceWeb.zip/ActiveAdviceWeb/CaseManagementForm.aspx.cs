using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.CLINICAL_MGMT_SERVICE),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.CARE_MANAGEMENT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.CMSMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("CMS,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("Summary")]
	[SelectedMainMenuItem("MPatient")]
	[MainDataProperty("CMS")]
	[PageTitle("@CMSPAGETITLE@")]
	public class CaseManagementForm : PatientBasePage
	{
		public enum Tabs
		{
			General,
			Maternichek,
			Administration,
			UserDefined
		}

		private CMS cMS;
		private CMSStatusHistory nSH;
		private Patient patient;
		private Problem problem;
		private PatientCoverage patientCoverage;
		private bool createMaternichek; 
		private WindowOpener wo;
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGeneral;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseEndDate;
		protected NetsoftUSA.WebForms.OBComboBox CaseOpenReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseOpenReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CaseStartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit CMSID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSID;
		protected NetsoftUSA.WebForms.OBComboBox CaseClosedReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseClosedReasonID;
		protected NetsoftUSA.WebForms.OBComboBox CaseContinuedReasonID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseContinuedReasonID;
		protected NetsoftUSA.WebForms.OBComboBox CaseSourceID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCaseSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateCMSID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateCMSID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSRiskId;
		protected NetsoftUSA.WebForms.OBComboBox CMSRiskId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusTypeId;
		protected NetsoftUSA.WebForms.OBComboBox StatusTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAcuityId;
		protected NetsoftUSA.WebForms.OBComboBox AcuityId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbIntensityId;
		protected NetsoftUSA.WebForms.OBComboBox IntensityId;
		protected NetsoftUSA.WebForms.OBComboBox StatusId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Prognosis;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrognosis;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCaseStartDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WebDateTimeEdit1;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CaseEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCaseEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPrognosis;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldClientReportContact;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhaseId;
		protected NetsoftUSA.WebForms.OBComboBox PhaseId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPhaseId;
		protected System.Web.UI.WebControls.Button butSave;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCaseOpenReasonID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCaseContinuedReasonID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlVerbalConsentPatients;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlVerbalConsentClients;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientAuthorizerID;
		protected NetsoftUSA.WebForms.OBComboBox PatientAuthorizerID; //temp object to verify if some controls were modified since they were loaded.
		protected NetsoftUSA.WebForms.OBFieldLabel lbPatientAuthorizationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit PatientAuthorizationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbClientReportContact;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit ClientReportContact;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlEmpty;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMaternichek;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLMPdate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit LMPdate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLMPdate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEDCdate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EDCdate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEDCdate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstPrenatalVisit;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FirstPrenatalVisit;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstPrenatalVisit;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstPostpartumVisit;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FirstPostpartumVisit;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstPostpartumVisit;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeliveryDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DeliveryDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeliveryDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeliveryAge;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit DeliveryAge;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnMaternichekUpdate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserControlsHolder;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternateCMSID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCaseSourceID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCaseClosedReasonID;
		protected NetsoftUSA.WebForms.OBLabel AssignedUser;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAdministration;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGestationAgeDisplay;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit GestationAgeDisplay;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlContactInfo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOtherContactExt;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OtherContactExt;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit OtherContactPhone;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOtherContactPhone;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldWorkContactExt;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit WorkContactExt;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit WorkContactPhone;
		protected NetsoftUSA.WebForms.OBFieldLabel lbWorkContactPhone;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit HomeContactPhone;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHomeContactPhone;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOtherContactTime;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit OtherContactTime;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOtherContactTime;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldWorkContactTime;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit WorkContactTime;
		protected NetsoftUSA.WebForms.OBFieldLabel lbWorkContactTime;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHomeContactTime;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit HomeContactTime;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHomeContactTime;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMaternichekComplicationID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo MaternichekComplicationID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternichekComplicationID;
		protected TeamUserSelect Slct;
		protected ProviderSelect PSel;
		protected ProviderSelect FSel;
		protected UserDefined Ud2;
		protected UserDefined Ud1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldStatusTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbClientAuthorizationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ClientAuthorizationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbClientAuthorizerID;
		protected NetsoftUSA.WebForms.OBComboBox ClientAuthorizerID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected AdministrationControl Admn;

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			InitializeComponent();
				
			this.wbtnMaternichekUpdate.Click += new System.EventHandler(wbtnMaternichekUpdate_Click);
			
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Facility select
			this.FSel.RebindControls(typeof(CMS), "@FACILITY@", 
				ProviderSearcherType.Facility, null,
				"PrimaryFacilityID", "PrimaryFacilityLocationID", "PrimaryFacilityTypeID", "PrimaryFacilityLocationNetworkID", "PrimaryFacilityNetworkStatus", "CaseStartDate", true);

			//Provider select
			
			this.PSel.RebindControls(typeof(CMS), "@PROVIDER@", 
				ProviderSearcherType.Provider, null,
				"PrimaryProviderID", "PrimaryProviderLocationID", "PrimaryProviderSpecialtyID", "PrimaryProviderLocationNetworkID", "PrimaryProviderNetworkStatus", "CaseStartDate", true);
		
			//TeamUser select
			this.Slct.RebindControls(typeof(CMSStatusHistory), "AssignedTeamId", "AssignedUserId");
			
			Ud1.ReloadContext("CMS", null, true /*createcontrols*/); // short usage - always call
			this.PageTab.GetTab("CMS_UserDefined").Visible = Ud1.HasFields();
			Ud2.ReloadContext("Maternichek",null,true);
			
			if (!this.IsPostBack)
				LoadDataForCMS();
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				cMS = (CMS)this.LoadObject(typeof(CMS));	// This would reload from cache
			}	
		}

		#region CMS
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMS CMS
		{
			get { return cMS; }
			set
			{
				cMS = value;
				try
				{
					#region Issue 989 (00427)
					if(SystemControlValue.GetInstance.IsCMTypeRequired)
					{
						this.vldStatusTypeId.ValidatorBehavior = EnumValidatorBehavior.ForceRequired;
						this.lbStatusTypeId.ForceRequiredMark = EnumForceRequiredMark.Required;
					}
					else
					{
						this.vldStatusTypeId.ValidatorBehavior = EnumValidatorBehavior.ForceNotRequired;
						this.lbStatusTypeId.ForceRequiredMark = EnumForceRequiredMark.NotRequired;
					}
					#endregion

					this.UpdateFromObject(this.pnlGeneral.Controls, cMS);  // update controls for the given control collection
					this.UpdateFromObject(this.pnlDetails.Controls, cMS.LatestCMSStatusHistory);
					this.UpdateFromObject(this.pnlVerbalConsentPatients.Controls, cMS);
					this.UpdateFromObject(this.pnlVerbalConsentClients.Controls, cMS);
					this.UpdateFromObject(this.pnlUserControlsHolder.Controls, cMS);
					this.UpdateFromObject(this.pnlContactInfo.Controls, cMS);

					this.CacheObject(typeof(CMS), cMS);  // cache object using the caching method declared on the page
					this.CacheObject(typeof(BaseForEventCMSReferral), cMS as BaseForEventCMSReferral);

					Admn.ReloadContext();
					Admn.UpdateData(true);

					Ud1.ReloadContext("CMS",cMS,false);
					if(IsMaternichekVisible)
					{
						UpdateMaternichek();
						Ud2.ReloadContext("Maternicheck",cMS.Maternichek,false);
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
			}
		}

		private void UpdateMaternichek()
		{
			if (cMS.Maternichek != null)
			{
				this.UpdateFromObject(this.pnlMaternichek.Controls, cMS.Maternichek);
				this.DeliveryAge.Text = this.Language.Translate(cMS.Maternichek.DeliveryAge);
				this.GestationAgeDisplay.Text = this.Language.Translate(cMS.Maternichek.GestationAgeDisplay);
			}
			//PushTargetTab("CMS_Maternichek");
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForCMS()
		{
			bool result = true;
			bool toSetProperty = true;
			CMS cMS = null;
			CoverageSelectionContext covSelContext = null;
			try
			{	
				PageTab.SelectedTabKey = this.TargetTabKey;		// navigate to target tab.

				// if a coverage selection context was passed, the user has selected a coverage and returned back to the problem page
				// to save the problem.
				// continue with saving.
				covSelContext = this.GetParam("CoverageSelectionContext") as CoverageSelectionContext;
				if (covSelContext != null)
				{
					#region Back from Coverage Selection

					// Back from Coverage Selection
					// Get all the context objects from the coverage selection context.
					patient = covSelContext.Patient;
					problem = covSelContext.Problem;
					patientCoverage = covSelContext.PatientCoverage;		// Newly selected coverage is here.
					cMS = covSelContext.ERC as CMS;
					if (cMS == null)
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Returned from coverage selection with null CMS!");
					
					this.CacheObject(typeof(Patient), patient);
					this.CacheObject(typeof(PatientCoverage), patientCoverage);
					this.CacheObject(typeof(Problem), problem);

					// dump the coverage selection steps performed.  will be disabled at deployment.
					this.DumpCoverageSelectionContext(covSelContext);
					cMS.ChangeCoverage(patientCoverage);
					
					if (covSelContext.IsSaving)
					{
						covSelContext.SaveERC();		// save in the coverage selection context.
						this.DumpAutoActivity(cMS, true);
						this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "CMS ");
					}
					#endregion
				}
				else
				{
					// or pull from the parameter passed to this page via PushParam
					patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
					if (patient == null)
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
					this.CacheObject(typeof(Patient), patient);
					// get the passed patient subscriber coverage (link to patient)
					patientCoverage = GetParamOrGetFromCache("PatientCoverage", typeof(PatientCoverage)) as PatientCoverage;
					if (patientCoverage == null)	// if not specified create a new one
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-subscriber-coverage");
					this.CacheObject(typeof(PatientCoverage), patientCoverage);
					problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
					if (problem == null)	// if not specified create a new one
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");					
					this.CacheObject(typeof(Problem), problem);
				
					cMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;
					createMaternichek = this.GetParamBool("CreateMaternichek", false);

					if (createMaternichek == true && IsMaternichekButtonVisible/*checks permissions and gender*/)
					{
						NewCMSMaternichek();
						cMS = this.cMS;
						toSetProperty = false; // this.CMS was already set inside NewCMSMaternichek()
					}
					else if (cMS == null) 
					{
						NewCMS(); // if not passed, create a new data object and init as new
						cMS = this.cMS;
						toSetProperty = false; // this.CMS was already set inside NewCMS()
					}

					this.CacheObject(typeof(CMS), cMS);
					this.CacheObject(typeof(BaseForEventCMSReferral), cMS);
					PerDayCoverageValidation(covSelContext, this.patientCoverage, this.problem);
				} // end else of if(covSelContext != null)
				
				this.patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage)); // reload since might be changed by PerDayCoverageValidation

				cMS.PrimaryProblemID = problem.ProblemID;
				cMS.ParentPatient = patient;
				cMS.PatientId = patient.PatientId;
				cMS.Plan = patientCoverage.Plan;
				cMS.Plan.ManagementService.LoadManagementServiceItems(false);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}		

			if(toSetProperty)
				this.CMS = cMS;
			return result;
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForCMS()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlGeneral.Controls, cMS);	// controls-to-object
				
				nSH = new CMSStatusHistory();
				//Saving controls state to a temp object to perform comparisson in order to determine if anything was changed from original object.
				this.UpdateToObject(this.pnlDetails.Controls, nSH); 
				
				this.UpdateToObject(this.pnlVerbalConsentPatients.Controls, cMS);
				this.UpdateToObject(this.pnlVerbalConsentClients.Controls, cMS);
				this.UpdateToObject(this.pnlContactInfo.Controls, cMS);
				
				if (IsMaternichekVisible)
				{
					this.UpdateToObject(this.pnlMaternichek.Controls, cMS.Maternichek);
					Ud2.UserDefinedValue=cMS.Maternichek.UserDefined;
					Ud2.ReadControls();
					
				}
				this.UpdateToObject(this.pnlUserControlsHolder.Controls, cMS);

				Admn.ReloadContext();
				Admn.UpdateData(true);

				Ud1.UserDefinedValue=cMS.UserDefined;
				Ud1.ReadControls();
				
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewCMS()
		{
			bool result = true;
			CMS cMS = null;  
			try
			{	
				cMS = new CMS(true, patient);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.CMS = cMS;
			return result;
		}

		public bool NewCMSMaternichek()
		{
			bool result = true;
			CMS cMS = null;
			try
			{
				cMS = new CMS(true, true, patient);		// creates a CMS object with new Maternichek object inside
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			this.CMS = cMS;
			return result;
		}
		
		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(CMS cMS)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CMS", cMS);
			PushTargetTab("CMS_General");
			BasePage.Redirect("CaseManagementForm.aspx");
		}
		
		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, bool createMaternichek)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatientCoverage", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("CreateMaternichek", createMaternichek);
			PushTargetTab("CMS_General");
			BasePage.Redirect("CaseManagementForm.aspx");
		}

		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, int cmsID)
		{
			CMS cmsObj = new CMS();
			if (!cmsObj.Load(cmsID))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@CMS@");
			Redirect(patient, patCov, problem, cmsObj);
		}		

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, CMS cMS)
		{
			Redirect(patient, patCov, problem, cMS, CaseManagementForm.Tabs.General);
		}

		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, CMS cMS, CaseManagementForm.Tabs tab)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatientCoverage", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("CMS", cMS);
			switch(tab)
			{
				case CaseManagementForm.Tabs.UserDefined:
					PushTargetTab("CMS_UserDefined");
					break;
				case CaseManagementForm.Tabs.Administration:
					PushTargetTab("CMS_Administration");
					break;
				case CaseManagementForm.Tabs.Maternichek:
					PushTargetTab("CMS_Maternichek");
					break;
				case CaseManagementForm.Tabs.General:
				default:
					PushTargetTab("CMS_General");
					break;
			}
				
			BasePage.Redirect("CaseManagementForm.aspx");
		}

		#region Redirect with CoverageSelectionContext

		/// <summary>
		/// This is called when the user returns from Coverage Selection.
		/// The coverage selection context will contain the newly selected PatientCoverage.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		public static void Redirect(CoverageSelectionContext coverageSelectionContext)
		{
			// BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CoverageSelectionContext", coverageSelectionContext);
			PushTargetTab("CMS_General");
			BasePage.Redirect("CaseManagementForm.aspx");
		}

		#endregion

		
		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForCMS())
					return false;
				 
				PrepareToSaveData();
				if(cMS.IsNew || cMS.StartDateChanged)
				{
					#region Validate/Select Coverage before save

					// Select a valid coverage and save the event
					CoverageSelectionContext covSelContext = new CoverageSelectionContext(true, this.patient, this.patientCoverage, this.problem, this.cMS);
					EnumSelectValidCoverageResult result = this.SelectValidCoverage(covSelContext);
					switch (result)
					{
						case EnumSelectValidCoverageResult.NoCoverageFound:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "@NOVALIDCOVERAGE@"));
							return false;
						case EnumSelectValidCoverageResult.CoverageValid:
						case EnumSelectValidCoverageResult.SingleCoverageAutoSelected:
						{
							// save the event in the context of coverage selection
							covSelContext.SaveERC();
							this.DumpAutoActivity(this.cMS, true);
							break;
						}
						case EnumSelectValidCoverageResult.UserMustSelectFromMultiple:
							return false;		// user was redirected to coverage selection page.
						default:
							this.RaisePageException(new ActiveAdviceException(AAExceptionAction.None, "Unknown selection result"));
							return false;
					}
					// End of Select a valid coverage and save the problem

					#endregion
				}
				else
					cMS.Save();
				this.CMS = cMS;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void PrepareToSaveData()
		{
			if(cMS.IsNew)
			{
				cMS.LatestCMSStatusHistory = nSH;
				cMS.LatestCMSStatusHistory.IsNew = true;
			}
			
			if(!cMS.IsNew)
			{
				// creating new CMSStatusHistory object ONLY if pnlDetails was modified
				if (!cMS.LatestCMSStatusHistory.EqualsMappedMembers(nSH, true, CMSStatusHistory.EXCLUDEDMEMBERS))
				{	// pnlDetails was changed -> insert new record into[CMSStatusHistory]
					nSH.IsNew = true;
					cMS.LatestCMSStatusHistory = nSH;
				}
			}

			//BR01.9.1.17	When the User updates the status of a CM case to a status other than OPEN, 
			//the System shall notify the User of any open deficits/goals/interventions associated with the case 
			//and provide means to change their status to CANCELLED.
			if(cMS.LatestCMSStatusHistory.StatusId != 
				SystemStatusCollection.ActiveSystemStatuses.Lookup_StatusIdByCode(SystemStatus.OPEN))
			{
				cMS.LoadPOCDeficits(false);
				if(cMS.POCDeficits.Count > 0)
					this.SetPageMessage("This Case has Deficits associated with it.", EnumPageMessageType.AddWarning);
			}
		}

		private new bool IsMaternichekVisible
		{
			get {return base.IsMaternichekVisible && !this.cMS.IsNew && cMS.Maternichek != null; }
					 
		}
		#endregion

		#region UI Initialization and Events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			if (cMS == null)
				return;  // execution cannot continue with cMS == NULL
			
			this.SetERCTabVisibilities();

			cMS.DisplayDetailedInfo = true; // Controls info being displayed as Summary
			this.RenderClientFunctions(pnlGeneral.Controls, cMS, "onDateCheck");

			if(IsMaternichekVisible)
			{
				pnlMaternichek.Visible = true;
				RenderClientFunctions(pnlMaternichek.Controls, cMS.Maternichek, "onDeliveryDateCheck");
				this.OBLabel3.Visible = this.Ud2.Visible = Ud2.HasFields();
			}

			bool isNew = this.cMS.IsNew;
			
			SetPageTabToolbarItemVisible("StatusHistory", !isNew);
			SetPageTabToolbarItemVisible("LinkProblem", !isNew);

			SetPageTabItemEnabled("ASMT_Assessment", !isNew);
			SetPageTabItemEnabled("POC_PlanOfCare", !isNew);
			SetPageTabItemEnabled("PLI_PackingList", !isNew);
			SetPageTabItemEnabled("CRS_CareResource", !isNew);
			SetPageTabItemEnabled("OUT_Outcomes", !isNew);
			SetPageTabItemEnabled("PHYREV_PhysicianReview", !isNew);
			SetPageTabItemEnabled("CMS_Maternichek", IsMaternichekVisible);
			SetPageTabItemEnabled("PRVD_Providers", !isNew);
			SetPageTabItemEnabled("PRVD_Vendors", !isNew);
			SetPageTabItemEnabled("CMS_Administration", !isNew);
			SetPageTabItemEnabled("CMS_UserDefined", !isNew);
			
			this.SetPageToolbarItemEnabled("CostRpt",(!isNew && this.patient!=null && this.patient.PatientId != 0));
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			
			switch (tab.Key)
			{
				case "CMS_General":
					wo = new WindowOpener();
					wo.ID = "CaseManagementHistory";
					wo.NavigateURL = "CaseManagementHistory.aspx";
					wo.registerClientScripts(this);
					WindowOpener woProblemLink = new WindowOpener();
					woProblemLink.ID = "ProblemLinkForm";
					woProblemLink.NavigateURL = "ProblemLinkForm.aspx";
					woProblemLink.registerClientScripts(this);

					toolbar.AddButton("@LINKPROBLEM@", "LinkProblem").Item.TargetURL = "javascript:" + woProblemLink.getWindowOpenScript(); 
					toolbar.AddButton("@STATUSHISTORY@", "StatusHistory").Item.TargetURL = "javascript:" + wo.getWindowOpenScript();
					break;
				case "CMS_Administration":
					toolbar.AddButton(Messages.PatientMessages.MessageIDs.CHANGECOVERAGE, "CMS_ChangeCoverage", false, true);
					break;
			}
			toolbar.AddButton("@COSTRPT@","CostRpt");
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.cMS);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty();
			CheckForDirty(this.cMS/*, this.cMS.PackingListItemsSent*/);
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}

		public void OnToolbarButtonClick_CMS_ChangeCoverage(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// data from controls to object
			if (!ReadControlsForCMS())
				return;
			RedirectToSelectCoverage(this.patient, this.patientCoverage, this.problem, this.cMS);			
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "CMS ");
			}
		}

		public void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PatientSummaryForm.Redirect(this.patient);
		}

		public void OnToolbarButtonClick_CostRpt(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			BasePage.PushCallingPage(this); // push current page as calling page so we can navigate back to it.
			object[] val = new object[]{this.patient.PatientId,this.CMS.CMSID};
			FormSpecificReport.Redirect(val,"CMSCOSTCOMP");
		}

		private void wbtnMaternichekUpdate_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForCMS())
				UpdateMaternichek();
		}

		public new void OnSubNavigationItemClick_Images(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			// make sure active event is selected.
			ImageSearch.Redirect(this.patient, this.patientCoverage, this.problem, this.cMS, null);
		}

		public new void OnSubNavigationItemClick_Notes(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			NoteSearch.Redirect(EnumActivityAndNoteContext.ERC);
		}

		public new void OnSubNavigationItemClick_Activities(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ActivitiesForm.Redirect(EnumActivityContext.Activity, EnumActivityAndNoteContext.ERC);
		}
		#endregion
		
 	}
}
