using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for IntroLetterMaintenance.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.LETTER_SETUP)]
	
	[MainLanguageClass("ActiveAdvice.Messages.LetterMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("IntroLetterParam,DataLayer")]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("IntroLetter")]
	public class IntroLetterMaintenance : LetterMaintenanceBasePage
	{
		private IntroLetterParam introLetterParam;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnGenerateLetters;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldScoringLoadDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ScoringLoadDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbScoringLoadDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOrgID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrgID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOrgID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMorgID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MorgID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMorgID;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganizationSearch;
		protected System.Web.UI.WebControls.Label lblMorgName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtMorgPath;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForMorgSearch;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrgSearch;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtOrgPath;
		protected System.Web.UI.WebControls.Label lblOrgName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldIntroletterNumber;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit IntroletterNumber;
		protected System.Web.UI.WebControls.RadioButtonList rblIntroLetterNumber;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.rblIntroLetterNumber.SelectedIndexChanged += new System.EventHandler(this.rblIntroLetterNumber_SelectedIndexChanged);
			this.wbtnGenerateLetters.Click += new System.EventHandler(this.wbtnGenerateLetters_Click);
			InitializeComponent();
			BindIntroLetterNumberOptions();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				NewIntroLetterParam();
			else
				introLetterParam = (IntroLetterParam)this.LoadObject("IntroLetterParam");  // load object from cache
		}

		#region Data Object
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public IntroLetterParam IntroLetterParam
		{
			get { return introLetterParam; }
			set
			{
				introLetterParam = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, introLetterParam);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("IntroLetterParam", introLetterParam);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForIntroLetterParam()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, introLetterParam);	// controls-to-object
				// other control-to-object methods if any
				introLetterParam.IntroletterNumber = SelectedLetterNumber;
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewIntroLetterParam()
		{
			bool result = true;
			IntroLetterParam introLetterParam = null;
			try
			{	// or use an initialization method here
				introLetterParam = new IntroLetterParam();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.IntroLetterParam = introLetterParam;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool GenerateLetters()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForIntroLetterParam())
					return false; 
				introLetterParam.IntroLetterGeneration();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion

		#region UI Initialization and Events
		private void wbtnGenerateLetters_Click(object sender, System.EventArgs e)
		{
			if (GenerateLetters())
				this.SetPageMessage("Intro Letter generation has been successfully completed.", EnumPageMessageType.Info); 
		}
		
		private void BindIntroLetterNumberOptions()
		{
			this.rblIntroLetterNumber.Items.Add(new ListItem(this.Language.TranslateSingle("INTROLTR1"), IntroLetterNumber.IntroLetter1.ToString()));
			this.rblIntroLetterNumber.Items.Add(new ListItem(this.Language.TranslateSingle("INTROLTR2"), IntroLetterNumber.IntroLetter2.ToString()));
			this.rblIntroLetterNumber.Items.Add(new ListItem(this.Language.TranslateSingle("INTROLTR3"), IntroLetterNumber.IntroLetter3.ToString()));
			this.rblIntroLetterNumber.Items.Add(new ListItem(this.Language.TranslateSingle("INTROLTRS"), IntroLetterNumber.CCLetter.ToString()));
			this.rblIntroLetterNumber.SelectedIndex = 0;
		}

		private void rblIntroLetterNumber_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.ScoringLoadDate.Enabled = SelectedLetterNumber == IntroLetterNumber.IntroLetter1;
		}

		private IntroLetterNumber SelectedLetterNumber
		{
			get { return (IntroLetterNumber)Enum.Parse(typeof(IntroLetterNumber), this.rblIntroLetterNumber.SelectedValue, true); }
		}
		
		#endregion
	}
}
