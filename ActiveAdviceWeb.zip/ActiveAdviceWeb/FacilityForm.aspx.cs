using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using Infragistics.WebUI.UltraWebToolbar;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.FacilityMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Facility,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MProviderFacility")]
	[SelectedMenuItem("Details")]
	[PageTitle("@FACILITYFORMTITLE@")]
	public class FacilityForm : ProviderBasePage
	{
		//private FacilityFacilityLinkCollection facilityFacilityLinks;
		//private FacilityFacilityLink selectedFacilityFacility;
		//private FacilitySpecialty selectedFacilitySpecialty;
		private FacilityFocus selectedFacilityFocus;
		private Facility facility;
		private Location selectedLocation;
		private Address selectedFacilityAddress;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlBasicInfo;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStatusChangedByID;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DateActive;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDateActive;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.WebCombo Gender;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGender;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Email;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEmail;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit Beeper;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBeeper;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSuffixId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo PrefixId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPrefixId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit MiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMiddleInitial;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFirstName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLastName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternateID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit FacilityID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFacilityID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		//protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLanguages;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		//protected NetsoftUSA.InfragisticsWeb.WebGrid lstLanguages;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnAddLanguage;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveLanguage;
		//protected NetsoftUSA.InfragisticsWeb.WebGrid gridFacilityLanguages;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridFacilityFocuses;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveFocus;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddFocus;
		protected NetsoftUSA.InfragisticsWeb.WebGrid lstFocuses;
		protected NetsoftUSA.WebForms.OBLabel OBLabel9;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacilityFocuses;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGPNote;
		protected NetsoftUSA.WebForms.OBLabel OBLabel11;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacilitySpecialties;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnRemoveSpecialty;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnAddSpecialty;
		protected System.Web.UI.WebControls.ListBox lstFacilitySpecialties;
		protected NetsoftUSA.WebForms.OBLabel OBLabel10;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnSpecialtySetPrimary;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnSpecialtyChangeStatus;
		//protected NetsoftUSA.InfragisticsWeb.WebGrid gridFacilitySpecialties;
		private   int selectedFocusIndex		= -1;
		//private   int selectedSpecialtyIndex	= -1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacilitys;
		protected NetsoftUSA.WebForms.OBLabel OBLabel12;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridFacilityFacilitys;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridFacilityGPLocations;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacilityInfo1;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacilityInfo2;
		//private   int selectedLanguageIndex		= -1;
		private   int selectedGPIndex			= -1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Suffix;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DeliveryMethodStr;
		protected NetsoftUSA.WebForms.OBLabel OBLabel15;
		protected NetsoftUSA.InfragisticsWeb.WebGrid lstSpecialties;
		private   int selectedGPLocIndex		= -1;
		private   int selectedLangTypeIndex		= -1;
		private   int selectedFocusTypeIndex	= -1;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnClose;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnProceed;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFocusDate;
		protected System.Web.UI.HtmlControls.HtmlTable tblMain;
		protected System.Web.UI.HtmlControls.HtmlTable tblEffectiveDate;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit AsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnAddGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnSaveGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelGPDates;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPDates;
		protected NetsoftUSA.InfragisticsWeb.WebCombo FacilityFocusTypeID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel16;
		protected NetsoftUSA.InfragisticsWeb.WebCombo BoardStatus;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBoardStatus;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EndDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEndDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit StartDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbStartDate;
		//protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSpecialtyStatus;
		protected System.Web.UI.HtmlControls.HtmlTable Table9;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelSpecialtyStatus;
		//protected NetsoftUSA.InfragisticsWeb.WebButton btnOKSpecialtyStatus;
		protected NetsoftUSA.WebForms.OBLabel OBLabel17;
		protected NetsoftUSA.WebForms.OBLabel lblGPLocs;
		protected NetsoftUSA.WebForms.OBLabel lblGPEffDates;
		protected NetsoftUSA.InfragisticsWeb.WebButton WebButton1;
		protected NetsoftUSA.InfragisticsWeb.WebButton WebButton2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacilityDate;
		protected System.Web.UI.HtmlControls.HtmlTable Table11;
		protected NetsoftUSA.WebForms.OBLabel OBLabel13;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit facilityID;
		protected NetsoftUSA.WebForms.OBLabel OBLabel14;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FacilityName;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForSORG;
		protected NetsoftUSA.WebForms.OBLabel OBLabel18;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit FacilityLocationID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFacilityLocationID;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacilityGP;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPLocations;
		protected System.Web.UI.HtmlControls.HtmlTable tblGPEffectiveDates;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternateID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit FirstName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit LastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLastName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAsOfDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityLocationID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFacilityFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFirstName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldBeeper;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit BeeperExtension;
		protected NetsoftUSA.WebForms.OBCheckBox PhysicianReview;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPhysicianReview;
		//protected System.Web.UI.HtmlControls.HtmlTable tblSpecialtyInfo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGender;
		protected System.Web.UI.HtmlControls.HtmlTable tblFacilityAddress;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFax;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fax;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFax;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFaxNumber;
		protected NetsoftUSA.InfragisticsWeb.WebMaskEdit FaxNumber;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFaxNumber;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffDate;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldName;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFacilityInfo;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGPFocuses;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ProviderFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnClose;
		protected NetsoftUSA.WebForms.OBCheckBox AddedOnFly;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel4;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAddedOnTheFly;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeliveryMethod;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeliveryMethodStr;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo TypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFocusTypeID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		private   int selectWidth				= 65;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.WebForms.OBValidator vldEmail;
		protected UserDefined UserDefined1;

		private void Page_Load(object sender, System.EventArgs e)
		{
			UserDefined1.ReloadContext("Facility",facility,true);
			if(!UserDefined1.HasFields())
				this.PageTab.GetTab("UserDefined").Visible = false;
			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
				lbAddedOnTheFly.Text ="";
				this.lbAddedOnTheFly.Text = this.Language.TranslateSingle("ADDEDONFLY");
			}
			else
			{
				facility = (Facility)this.LoadObject("facilityObj");
				try
				{
					//selectedLanguageIndex = (int)this.LoadObject("FacilityLanguageIndex");
					selectedFocusIndex	  = (int)this.LoadObject("FacilityFocusIndex");
					//selectedSpecialtyIndex = (int)this.LoadObject("FacilitySpecialtyIndex");
					//selectedGPIndex			= (int)this.LoadObject("FacilityGPIndex");
					selectedGPLocIndex		= (int)this.LoadObject("FacilityGPLocIndex");
					//selectedLangTypeIndex   = (int)this.LoadObject("selectedLangTypeIndex");
					selectedFocusTypeIndex  = (int)this.LoadObject("selectedFocusTypeIndex");
					selectedFacilityFocus = (FacilityFocus)this.LoadObject("selectedFocus");  // load object from cache
					//selectedFacilitySpecialty = (FacilitySpecialty)this.LoadObject("selectedFacilitySpecialty");  // load object from cach
					//selectedFacilityAddress = (Address)this.LoadObject("FacilityAddress");
					//selectedFacilityFacility = (FacilityFacilityLink)this.LoadObject("selectedGPFacilityLink");  // load object from cache
					selectedLocation = (Location)this.LoadObject("locationObj");
				}
				catch(Exception ex)
				{
					/*
					 * Some of the above lines are throwing
					 * with Object Reference not set excpetion.
					 * I guess there are cases when they're not being cached. 
					 * For instance just load page in popup mode and click 'locations' link.
					 * Since I don't know anything about business logic and didn't have time to investigate
					 * I placed above code into try - catch block so users can still use this page
					 * */
					//string str = ex.ToString();
					//this.RaisePageException(ex);	// notify the page about the error
				}
			}
			//pnlFacilityFocuses.Visible = false;
			//pnlFocusDate.Visible = false;
			
			UserDefined1.ReloadContext("Facility",facility,false);
		}

		
		public int SelectedFocusTypeIndex
		{
			get { return this.selectedFocusTypeIndex; }
			set 
			{
				this.selectedFocusTypeIndex = value;
				this.CacheObject("selectedFocusTypeIndex", this.selectedFocusTypeIndex);
			}
		}
		public int SelectedLangTypeIndex
		{
			get { return this.selectedLangTypeIndex; }
			set 
			{
				this.selectedLangTypeIndex = value;
				this.CacheObject("selectedLangTypeIndex", this.selectedLangTypeIndex);
			}
		}

		/// <summary>
		/// A helper static function to redirect to this page
		/// </summary>
		public static void Redirect(int FacilityID)
		{
			Facility Facility = new Facility();
			if (FacilityID != 0)
				Facility.Load(FacilityID);
			else
				Facility.New();
			BasePage.PushParam("facilityObj",Facility);
			BasePage.Redirect("FacilityForm.aspx");
		}

		public static void Redirect(Facility Facility)
		{
			BasePage.PushParam("facilityObj",Facility);
			BasePage.Redirect("FacilityForm.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			//this.btnAddFocus.Click += new System.EventHandler(this.btnAddFocus_Click);
			this.btnRemoveFocus.Click += new System.EventHandler(this.btnRemoveFocus_Click);
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnAddFocus.Click += new System.EventHandler(this.btnAddFocus_Click);
			this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		public override void OnSetDirty()
		{
			if(Facility == null)
				return;
			CheckForDirty(this.Facility, this.Facility.Focuses, this.Facility.Locations);
		}

		
		public bool LoadData()
		{
			bool result = true;
			// get the parameter
			Facility facility = new Facility();
			string sFacilityID = Request.QueryString["FacilityID"];
			if (sFacilityID != null) // If QueryString has FacilityID
			{
				try
				{
					if(sFacilityID == "" || sFacilityID == "0")
						throw new ActiveAdviceException("@ISNOTSET@","@FACILITY@");
					if (!facility.Load(int.Parse(sFacilityID)))
						throw new ActiveAdviceException("@CANTFINDRECORD@","@FACILITY@");
					this.Facility = facility;
					return true;
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
					return false;
				}
			}
			else // If QueryString Doesn't Contain FacilityID
			{
				try
				{	
					facility = this.GetParamOrGetFromCache("facilityObj","facilityObj") as Facility ;
					selectedLocation = this.GetParamOrGetFromCache("locationObj","locationObj") as Location ;
					// Set Selected Indeces = -1;
					SelectedFocusIndex	= SelectedGPLocIndex  = SelectedFocusTypeIndex			= -1;
					if (facility == null)
						return NewFacility();
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);	// notify the page about the error
					result = false;
				}
				facility.Load(facility.FacilityID);
				if (facility.FacilityID == 0)
					facility.New();
				facility.LoadFocuses(false);
				this.Facility = facility;
				return result;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewFacility()
		{
			bool result = true;
			Facility gp = new Facility(true); // use a parameterized constructor which also initializes the data object
			try
			{
				gp.LoadFocuses(true);
				// or use an initialization method here
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Facility = gp;
			return result;
		}
		

		public Location SelectedLocation
		{
			get { return this.selectedLocation  ; }
			set 
			{ 
				this.selectedLocation = value;
				this.CacheObject("locationObj", selectedLocation);
			}
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			if (!this.IsPopup)
				toolbar.AddButton("@SAVE@", "Save",true, false);
			TBarButton tbbCancel = toolbar.AddButton("@CANCEL@", "Cancel", false, !this.IsPopup).Item;
			if (this.IsPopup)
				tbbCancel.TargetURL = "javascript:window.close()";
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			bool wasNew = Facility.IsNew;
			bool saveDataResult = SaveData();
			if ( wasNew && saveDataResult)			
				this.SetPageMessage("@PROVIDERSAVEDMSG@", EnumPageMessageType.Info, "@FACILITY@","@LOCATIONLOWER@");
			else if (saveDataResult)
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@FACILITY@");
		}
		
		public override void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			FacilitySearch.Redirect();
		}

		public int SelectedGPLocIndex
		{
			get { return this.selectedGPLocIndex;}
			set 
			{ 
				this.selectedGPLocIndex = value;
				this.CacheObject("FacilityGPLocIndex", selectedGPLocIndex);

				
				// Load Date History
				if (Facility != null && this.gridFacilityGPLocations.SelectedRowIndex >= 0)
				{
					// Find Group Practice ID from GPLocIndex
					int gpID = 0;
					
					if (this.gridFacilityGPLocations.SelectedRowIndex >= 0)
					{
						Infragistics.WebUI.UltraWebGrid.UltraGridCell mcell = null;
						for (int m = 0; m < this.gridFacilityGPLocations.DisplayLayout.ActiveRow.Cells.Count; m++)
						{
							if (gridFacilityGPLocations.DisplayLayout.ActiveRow.Cells[m].Key == "FacilityID")
							{
								mcell = gridFacilityGPLocations.DisplayLayout.ActiveRow.Cells[m];
								break;
							}
						}
						gpID = (int)mcell.Value;	
					}
					
					int gpLocID = (int)gridFacilityGPLocations.SelectedRowPK[0];
					
				
				}
			}
		}

		public int SelectedFocusIndex
		{
			get { return this.selectedFocusIndex;}
			set 
			{ 
				this.selectedFocusIndex = value;
				this.CacheObject("FacilityFocusIndex", selectedFocusIndex);
			}
		}
		
		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			if(this.facility == null)
				return;
			pageSummary.RenderObjects(this.facility);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.RenderClientFunctions(pnlFocusDate.Controls, SelectedFacilityFocus , "OnDateValidation");
		}
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Facility Facility
		{
			get { return facility; }
			set
			{
				facility = value;
				try
				{
					//this.pnlFacilityDate.Visible = false;
					//this.tblGPDates.Visible = false;
					//Facility.LoadLanguages();
					facility.LoadLocations(true);
					
					this.UpdateFromObject(this.tblFacilityInfo1.Controls, facility );  // update controls for the given control collection
					this.UpdateFromObject(this.tblFacilityInfo2.Controls, facility );  // update controls for the given control collection
					//this.UpdateFromObject(this.tblFacilityInfoTax.Controls, selectedLocation );
					// Bind Active Facility Focuses
					this.lstFocuses.UpdateFromCollection(FacilityFocusTypeCollection.ActiveFacilityFocusTypes);
					this.UpdateFromObject(this.pnlGPNote.Controls ,facility );	
					if (lstFocuses.Rows.Count > 0)
						lstFocuses.SelectedRowIndex = 0;
					this.gridFacilityFocuses.UpdateFromCollection(Facility.Focuses);
					if (gridFacilityFocuses.Rows.Count > 0)
						gridFacilityFocuses.SelectedRowIndex = 0;
			
					this.pnlFocusDate.Visible = false;

					UserDefined1.ReloadContext("Facility",facility,false);
					
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("facilityObj", Facility);  // cache object using the caching method declared on the page
			}
		}


		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);
			if(Facility == null)
				return;
			if (tab.Key == "Facility")
			{
				toolbar.AddButton("@LOCATIONS@", "Locations");
				if (this.Facility.FacilityID == 0)
					this.SetPageTabToolbarItemEnabled("Locations", false);
			}
		}

			
		public void OnToolbarButtonClick_Locations(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			FacilityLocationForm.PushCurrentCallingPage();
			FacilityLocationForm.Redirect(typeof(Facility),this.Facility.FacilityID);
		}


		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForFacility()
		{
			try
			{	//customize this method for this specific page
				
				this.UpdateToObject(this.pnlGPNote.Controls, this.facility  );
				this.UpdateToObject(this.tblFacilityInfo1.Controls, this.facility );	// controls-to-object
				this.UpdateToObject(this.tblFacilityInfo2.Controls, this.facility );	// controls-to-object
				//this.UpdateToObject(this.tblFacilityInfoTax.Controls, selectedLocation );
				//this.UpdateToObject(this.tblFacilityAddress.Controls,this.selectedFacilityAddress);	// controls-to-object
				UserDefined1.UserDefinedValue =	facility.UserDefined;
				UserDefined1.ReadControls();
			
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private bool SaveData()
		{
			if (this.ReadControlsForFacility())
			{
				try
				{
					if (!this.Facility.IsNew)
						this.Facility.Locations[0].MarkDirty();
					//this.Facility.StatusChangedBy = 1;
					
					this.Facility.Save ();
					
					// Enable Locations Button
					this.SetPageTabToolbarItemEnabled("Locations", true);
					this.Facility = facility;
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
					return false;
				}
				return true;
			}
			else
				return false;
				

		}

	
		private void btnAddFocus_Click(object sender, System.EventArgs e)
		{
			
			if (lstFocuses.SelectedRowIndex >= 0)
			{
				bool			resume			= true;
				FacilityFocus	provFocCompare	= null;
				int selectedTypeID = (int)lstFocuses.SelectedRowPK[0];	

				if (selectedTypeID != 0)
				{
					if (Facility.Focuses != null)
					{
						for (int i = 0; i < this.Facility.Focuses.Count; i++)
						{
							provFocCompare		= Facility.Focuses[i];
							if (selectedTypeID == provFocCompare.FacilityFocusTypeID && provFocCompare.TerminationDate == DateTime.MinValue)
							{
								resume = false;
								break;
							}
						}
					}
					else
						Facility.Focuses = new FacilityFocusCollection();

					if (resume)
					{
						FacilityFocus provFoc		= new FacilityFocus();
						provFoc.New();
						provFoc.EffectiveDate		= DateTime.Today.Date;
						provFoc.FacilityFocusTypeID = selectedTypeID;
						provFoc.FacilityID			= this.Facility.FacilityID;
						this.SelectedFacilityFocus  = provFoc;
						
						// show the panel
						SetFocusDatesVisible(true, false);
						pnlFocusDate.Visible = true;
					}
				}
			}
			else
				this.SetPageMessage("@SELECTFOCUS@", NetsoftUSA.WebForms.EnumPageMessageType.Warning);
	
		}
		
		

		
		
		private void SetFocusDatesVisible(bool effAndFocus, bool termDate)
		{
			this.TerminationDate.Enabled		= termDate;
			this.OBFieldLabel1.Enabled			= termDate;
			this.EffectiveDate.Enabled			= effAndFocus;
			this.OBLabel16.Enabled				= effAndFocus;
			this.OBFieldLabel2.Enabled			= effAndFocus;			
			this.FacilityFocusTypeID.Enabled	= effAndFocus;
		}


		
		private void btnRemoveFocus_Click(object sender, System.EventArgs e)
		{
			if (gridFacilityFocuses.SelectedRowIndex >= 0)
			{
				this.SelectedFacilityFocus = Facility.Focuses[gridFacilityFocuses.SelectedColectionIndex];
				this.SetFocusDatesVisible(false, true);
				this.pnlFocusDate.Visible = true;
			}

		}
		
		private void RemoveFocus()
		{
			if (this.SelectedFacilityFocus != null)
			{
				//Facility.Focuses.Remove(this.SelectedFacilityFocus);
				this.SelectedFacilityFocus = null;
				//this.gridFacilityFocuses.UpdateFromCollection(Facility.Focuses);
				
				if (gridFacilityFocuses.Rows.Count > 0)
					gridFacilityFocuses.SelectedRowIndex = 0;
			}
		}

		/// <summary>
		///  Adds / Updates a focus based on effective dates.
		/// </summary>
		private void AddFocus()
		{
			if (this.SelectedFacilityFocus != null)
			{
				this.Facility.Focuses.Add(this.SelectedFacilityFocus);	
				this.gridFacilityFocuses.UpdateFromCollection(this.Facility.Focuses);
				this.SelectedFacilityFocus = null;
			}
		}

		private void TerminateFocus()
		{
			if (SelectedFacilityFocus != null)
			{
				try
				{

					// find current focus in collection
					for (int i=0; i < Facility.Focuses.Count; i++)
					{
						if (Facility.Focuses[i].FacilityFocusID == SelectedFacilityFocus.FacilityFocusID)
						{
							FacilityFocus currentFocus = Facility.Focuses[i];
							currentFocus.TerminationDate = this.SelectedFacilityFocus.TerminationDate;
							//currentFocus.MarkDirty();
							//Facility.Focuses.Remove(currentFocus);
							break;
						}
					}
					SelectedFacilityFocus = null;
					this.gridFacilityFocuses.UpdateFromCollection(Facility.Focuses);
				}
				catch (Exception ex)
				{
					this.RaisePageException(ex);
				}
				finally
				{
					this.gridFacilityFocuses.UpdateFromCollection(this.Facility.Focuses);
				}
			}
		}

		private void gridFacilityGPLocations_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
			{
				this.SelectedGPLocIndex = this.gridFacilityGPLocations.GetColIndexFromCellEvent(e);
			}
		}


		private void LoadGPLocations(int facilityID)
		{
			
		}

		private void gridFacilityFacilitys_InitializeLayout(object sender, Infragistics.WebUI.UltraWebGrid.LayoutEventArgs e)
		{
		
		}

		
		private void gridFacilityGPLocations_DblClick(object sender, Infragistics.WebUI.UltraWebGrid.ClickEventArgs e)
		{
			this.SelectedGPLocIndex = gridFacilityGPLocations.GetColIndexFromClickEvent(e);
		}

		

		/*

		private void lstLanguages_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell != null && e.Cell.Key == "Select")
			{
				this.SelectedLangTypeIndex = lstLanguages.GetColIndexFromCellEvent(e);
			}
		}

		private void lstFocuses_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell != null && e.Cell.Key == "Select")
			{
				this.SelectedFocusTypeIndex = lstFocuses.GetColIndexFromCellEvent(e);
				
			}
		}

		private void lstSpecialties_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell != null && e.Cell.Key == "Select")
			{
				SelectedSpecialtyIndex = lstSpecialties.GetColIndexFromCellEvent(e);
			}
		}
		*/
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public FacilityFocus SelectedFacilityFocus
		{
			get { return selectedFacilityFocus; }
			set
			{
				selectedFacilityFocus = value;
				try
				{
					this.UpdateFromObject(this.tblEffectiveDate.Controls , selectedFacilityFocus);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("selectedFocus", selectedFacilityFocus);  // cache object using the caching method declared on the page
			}
		}
		
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Address SelectedFacilityAddress
		{
			get { return selectedFacilityAddress; }
			set
			{
				selectedFacilityAddress = value;
				try
				{
					//this.UpdateFromObject(this.tblFacilityAddress.Controls,selectedFacilityAddress );  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("FacilityAddress", selectedFacilityAddress);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForSelectedFacilityFocus()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlFocusDate.Controls, selectedFacilityFocus);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		private void btnProceed_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.UpdateToObject(this.tblEffectiveDate.Controls, this.SelectedFacilityFocus);
				this.SelectedFacilityFocus.CreatedBy = 1;
				this.SelectedFacilityFocus.CreateTime = DateTime.Now;

				if (this.FacilityFocusTypeID.Enabled)
					this.AddFocus();
				else
					this.TerminateFocus();
				
				
				this.pnlFocusDate.Visible = false;
			}
			catch (Exception ex)
			{
				this.RaisePageException(ex);
			}

		}

		private void btnClose_Click(object sender, System.EventArgs e)
		{
			this.SelectedFacilityFocus = null;
			this.pnlFocusDate.Visible = false;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		

	
		private void SetFacilityGridsVisible(bool visibility)
		{
			this.lblGPEffDates.Visible = this.gridGPDates.Visible = this.tblGPDates.Visible =  tblGPEffectiveDates.Visible =visibility;
			//this.lblGPLocs.Visible	= this.gridFacilityGPLocations.Visible = tblGPLocations.Visible  = visibility;
		}

		
		private void gridFacilityFacilitys_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridFacilityFacilitys.AddButtonColumn("Select", "@SELECT@", 0).Width = selectWidth;
		}

		
		private void lstFocuses_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "State")
				lstFocuses.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void lstSpecialties_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
				lstSpecialties.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void gridFacilityFacilitys_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
				gridFacilityFacilitys.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void gridFacilityGPLocations_ClickCellButton_1(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Select")
				gridFacilityGPLocations.SelectedRowIndex = e.Cell.Row.Index;
		}

		private void gridFacilityGPLocations_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			gridFacilityGPLocations.AddButtonColumn("Select","@SELECT@",0);
		}

	}
}
