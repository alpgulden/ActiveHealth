using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("ActivityTotalFilter,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("Activities")]						//define the active menu item in side menu
	[PageTitle("@ACTIVITYSUMMARY@")]
	public class ActivitySummary : BasePage
	{
		private ActivityTotalCollection activityTotals;
		private ActivityTotalFilter activityTotalFilter;
		private ActivitySearcher activitySearcher;
		private Patient patient;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.WebForms.OBLabel GridTitle;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlResult;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFilter;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldToCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ToCompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbToCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFromCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FromCompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFromCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldToDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ToDueDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbToDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldFromDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit FromDueDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbFromDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearch;
		protected NetsoftUSA.WebForms.OBRadioButtonBox SubTotalBy;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSubTotalBy;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;


		private void Page_Load(object sender, System.EventArgs e)
		{
			// Always get the activity searcher context.  Gives worlist/activit mode etc.
			activitySearcher = (ActivitySearcher)this.LoadObject(typeof(ActivitySearcher));  // load object from cache
			patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				activityTotalFilter = (ActivityTotalFilter)this.LoadObject("ActivityTotalFilter");  // load object from cache
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();

			SubTotalBy.SelectedIndexChanged +=new EventHandler(SubTotalBy_SelectedIndexChanged);   // Resets radiobutton value after postback.
			grid.BeforeColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(grid_BeforeColumnsBoundToDataClass);
			grid.RowBoundToDataObject +=new NetsoftUSA.InfragisticsWeb.WebGrid.RowBoundToDataObjectHandler(grid_RowBoundToDataObject);

			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
			this.DirtyCheckEnabled = false;
			this.PageType = NetsoftUSA.WebForms.EnumPageType.SearchPage;
			this.RequiredValidationsEnabled = false;
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "Search")
			{
				//toolbar.AddButton(OrgMessages.MessageIDs.SEARCH, "Search");
				//toolbar.AddButton(OrgMessages.MessageIDs.NEWSEARCH, "NewSearch");
			}

			// Menu items to be displayed on all tabs
		}


		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@CLOSE@", "Close", false).Item.TargetURL = "javascript:window.close()";
		}

		/* Handle menu items
		// Handler for 'Search' button
		public void OnToolbarButtonClick_Search(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			SearchMORG();
		}

		// Handler for 'NewSearch' button
		public void OnToolbarButtonClick_NewSearch(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewMORGSearch();
		}
		*/

		private void grid_BeforeColumnsBoundToDataClass(object sender, EventArgs e)
		{
			grid.Columns.Clear();
			grid.AddColumn("ManagementServiceTypeID", "@MANAGEMENTSERVICETYPEID@", true);
			grid.AddColumn("Description", "Description", false);		// Populated for each row
			grid.AddColumn("Amount", "@AMOUNT@", true);
			grid.AddColumn("BaseUOMID", "@BASEUOMID@", true);
			grid.AddColumn("Cost", "@COST@", true);
			grid.AddColumn("IsBillableStr", "@ISBILLABLE@", true);
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			try
			{	// use any load method here

				result = NewFilter();
				if (result)
					result = Search();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//activityTotalFilter.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ActivityTotalFilter ActivityTotalFilter
		{
			get { return activityTotalFilter; }
			set
			{
				activityTotalFilter = value;
				try
				{
					this.UpdateFromObject(pnlFilter.Controls, activityTotalFilter);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("ActivityTotalFilter", activityTotalFilter);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlFilter.Controls, activityTotalFilter);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewFilter()
		{
			bool result = true;
			ActivityTotalFilter activityTotalFilter = null; //new ActivityTotalFilter(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				activityTotalFilter = new ActivityTotalFilter();

				if (activitySearcher.Context == EnumActivityContext.WorkList)
				{
					activityTotalFilter.AssignedUserID = activitySearcher.AssignedUserID;
					activityTotalFilter.AssignedTeamID = activitySearcher.AssignedTeamID;
				}
				else
				{
					activityTotalFilter.PatientID = activitySearcher.PatientId;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.ActivityTotalFilter = activityTotalFilter;
			return result;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public ActivityTotalCollection ActivityTotals
		{
			get { return activityTotals; }
			set
			{
				activityTotals = value;
				try
				{
					grid.KeepCollectionIndices = false;  // update given grid from the collection
					grid.KeepPKs = false;  // update given grid from the collection
					grid.UpdateFromCollection(activityTotals);  // update given grid from the collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(ActivityTotalCollection), activityTotals);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool Search()
		{
			bool result = true;
			ActivityTotalCollection activityTotals = new ActivityTotalCollection();
			try
			{
				if (!this.ReadControls()) // Use appropriate read controls method to read the searcher object from controls 
					return false;
				activityTotals.CalculateActivityTotals(activityTotalFilter);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//activityTotals.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.ActivityTotals = activityTotals;
			return result;
		}

		private void grid_RowBoundToDataObject(object sender, RowBindingEventArgs e)
		{
			ActivityTotal total = (ActivityTotal)e.data;
			if (total.ManagementServiceTypeID == 0)
			{
				// Grand total
				e.row.Cells.FromKey("Description").Value = Language.Translate("@GRANDTOTAL@");
				e.row.Cells.FromKey("ManagementServiceTypeID").Value = null;
				e.row.Cells.FromKey("BaseUOMID").Text = null;
				e.row.Cells.FromKey("IsBillableStr").Text = null;				
				e.row.Style.CssClass = "GridGrandTotal";
			}
			else if (total.BaseUOMID == 0)
			{
				// Total of all BaseUOMIDs by Management Service Type.
				e.row.Cells.FromKey("Description").Text = Language.Translate("@SUBTOTALBYFMT@", total.ManagementServiceTypeDesc);
				e.row.Cells.FromKey("BaseUOMID").Text = null;
				e.row.Cells.FromKey("IsBillableStr").Text = null;

				e.row.Hidden = !(activityTotalFilter.SubTotalBy == ActivityTotalFilter.SUBTOTALBYALL || activityTotalFilter.SubTotalBy == ActivityTotalFilter.SUBTOTALBYSVCTYPE);
				

				e.row.Style.CssClass = "GridSubTotal";
			}
			else if (total.IsBillable == -1)
			{
				// Total of all IsBillables by BaseUOMID
				e.row.Cells.FromKey("Description").Text = Language.Translate("@SUBTOTALBYFMT@", total.BaseUOMDesc);
				e.row.Cells.FromKey("IsBillableStr").Text = null;

				e.row.Hidden = !(activityTotalFilter.SubTotalBy == ActivityTotalFilter.SUBTOTALBYALL || activityTotalFilter.SubTotalBy == ActivityTotalFilter.SUBTOTALBYUOM);

				e.row.Style.CssClass = "GridSubTotal";
			}
			else
			{
				// Total for a specific group
				e.row.Cells.FromKey("Description").Text = Language.Translate("@TOTAL@");
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			if (this.activitySearcher.Context == EnumActivityContext.WorkList)
				this.PageTitle = Language.Translate("@ACTIVITIESOF@", activityTotalFilter.AssignedTeamAndUserDisplay);
			else
				this.PageTitle = Language.Translate("@ACTIVITIESOFPATIENT@", patient.Fmt_FullName);

			base.OnPreRender (e);
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			Search();
		}

		private void SubTotalBy_SelectedIndexChanged(object sender, EventArgs e)
		{
			Search();
		}
	}
}
