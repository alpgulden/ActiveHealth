using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for DGIForm.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.CMSMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("CMS,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("Summary")]
	[SelectedMainMenuItem("MPatient")]
	[PageTitle("@DGIPAGETITLE@")]
	public class DGIForm : PatientBasePage
	{
		#region Declarations
		private CMS cMS;
		private POCDeficit pOCDeficit;
		private POCGoal pOCGoal;
		private POCIntervention pOCIntervention;
		private Patient patient;
		private PatientCoverage patientCoverage;
		private Problem problem;
		protected TeamUserSelect TUSel;

		private WindowOpener wo;
		private BasePOC deficitsFilter;
		private BasePOC goalsFilter;
		private BasePOC interventionsFilter;

		// stores previous visibility state controls
		private bool wbtnAddInterventionOldState, wbtnUpdateInterventionItemOldState/*, pnlInterventionBillingOldState*/; 
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnShowGoalPanel;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnShowDeficitPanel; // state of this is never changed - no need for viewstate
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCalculate;  // state of this is never changed - no need for viewstate
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit BillableAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBillableAmount;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fmt_BaseUOMID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBaseUOMID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit BaseAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBaseAmount;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Fmt_ConversionUnitOfMeasureDescriptionByID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbConversionUnitOfMeasureID;
		protected NetsoftUSA.WebForms.OBCheckBox IsBillable;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInterventionAmount;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit InterventionAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInterventionAmount;
		protected NetsoftUSA.WebForms.OBFieldLabel lbManagementServiceItemID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlInterventionBilling;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCancelIntervention;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnUpdateInterventionItem;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddIntervention;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivitySubTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInterventionTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActivityPrimaryTypeID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit WebTextEdit1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit CompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDueDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit DueDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDueDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlIntervention;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCancelGoal;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnUpdateGoalItem;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddNewGoal;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddGoal;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGoalOutcomeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGoalOutcomeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldActualCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ActualCompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActualCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGoalTermId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGoalTermId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldComments;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Comments;
		protected NetsoftUSA.WebForms.OBFieldLabel lbComments;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGoalReasonId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGoalReasonId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldProjectedCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ProjectedCompletionDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbProjectedCompletionDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldGoalTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbGoalTypeId;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGoal;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCancelDeficit;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnUpdateDeficitItem;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddNewDeficit;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddDeficit;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitSourceId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeficitPriorityId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitPriorityId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldComment;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Comment;
		protected NetsoftUSA.WebForms.OBFieldLabel lbComment;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeficitStatusId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitStatusId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDeficitTypeID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitTypeID;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDeficit;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit DeficitSourceDisplayOnly;
		protected NetsoftUSA.WebForms.OBLabel AssignedUser;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPOCSummary;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnCreateActivity;
		protected NetsoftUSA.WebForms.OBFieldLabel lbICompletionID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDeficitsOpenWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnFilterDeficits; // state of this is never changed - no need for viewstate
		protected NetsoftUSA.WebForms.OBFieldLabel lbGoalsOpenWithAll;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnFilterGoals; // state of this is never changed - no need for viewstate
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnFilterInterventions; // state of this is never changed - no need for viewstate
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlReport;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReportDateTo;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ReportDateTo;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReportDateTo;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReportDateFrom;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ReportDateFrom;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReportDateFrom;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnRunReport;  // state of this is never changed - no need for viewstate
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlInterventionsGridHolder;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGoalsGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnWebLinks;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnShowInterventionPanel;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnShowAllInterventions;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnGoToActivity;
		protected NetsoftUSA.WebForms.OBComboBox ActivityPrimaryTypeID;
		protected NetsoftUSA.WebForms.OBValidator vldInterventionTypeID;
		protected NetsoftUSA.WebForms.OBComboBox ActivitySubTypeID;
		protected NetsoftUSA.WebForms.OBComboBox DeficitsOpenWithAll;
		protected NetsoftUSA.WebForms.OBComboBox GoalsOpenWithAll;
		protected NetsoftUSA.WebForms.OBComboBox InterventionsOpenWithAll;
		protected NetsoftUSA.WebForms.OBComboBox DeficitStatusId;
		protected NetsoftUSA.WebForms.OBComboBox DeficitPriorityId;
		protected NetsoftUSA.WebForms.OBComboBox GoalTermId;
		protected NetsoftUSA.WebForms.OBComboBox GoalReasonId;
		protected NetsoftUSA.WebForms.OBComboBox GoalOutcomeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo DT;
		protected NetsoftUSA.InfragisticsWeb.WebCombo GT;
		protected NetsoftUSA.WebForms.OBComboBox IT;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grD;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grG;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grI;
		protected NetsoftUSA.WebForms.OBComboBox CompletionID;
		protected NetsoftUSA.WebForms.OBComboBox ManagementServiceItemID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInterventionsOpenWithAll;
		#endregion
		
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.wbtnShowDeficitPanel.Click += new System.EventHandler(this.wbtnShowDeficitPanel_Click);
			this.grD.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grD_ClickCellButton);
			this.grD.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grD_ColumnsBoundToDataClass);
			this.wbtnShowGoalPanel.Click += new System.EventHandler(this.wbtnShowGoalPanel_Click);
			this.grG.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grG_ClickCellButton);
			this.grG.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grG_ColumnsBoundToDataClass);
			this.grI.ColumnsBoundToDataClass += new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(this.grI_ColumnsBoundToDataClass);
			this.wbtnShowInterventionPanel.Click += new System.EventHandler(this.wbtnShowInterventionPanel_Click);
			this.grI.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grI_ClickCellButton);
			this.wbtnAddDeficit.Click += new System.EventHandler(this.wbtnAddDeficit_Click);
			this.wbtnUpdateDeficitItem.Click += new System.EventHandler(this.wbtnUpdateDeficitItem_Click);
			this.wbtnCancelDeficit.Click += new System.EventHandler(this.wbtnCancelDeficit_Click);
			this.wbtnAddGoal.Click += new System.EventHandler(this.wbtnAddGoal_Click);
			this.wbtnUpdateGoalItem.Click += new System.EventHandler(this.wbtnUpdateGoalItem_Click);
			this.wbtnCancelGoal.Click += new System.EventHandler(this.wbtnCancelGoal_Click);
			this.wbtnShowAllInterventions.Click += new System.EventHandler(this.wbtnShowAllInterventions_Click);
			this.ActivityPrimaryTypeID.SelectedIndexChanged += new EventHandler(this.ActivityPrimaryTypeID_SelectedRowChanged);
			this.IT.SelectedIndexChanged += new EventHandler(this.IT_SelectedRowChanged);
			this.wbtnGoToActivity.Click += new System.EventHandler(this.wbtnGoToActivity_Click);
			this.wbtnAddIntervention.Click += new System.EventHandler(this.wbtnAddIntervention_Click);
			this.wbtnUpdateInterventionItem.Click += new System.EventHandler(this.wbtnUpdateInterventionItem_Click);
			this.wbtnCancelIntervention.Click += new System.EventHandler(this.wbtnCancelIntervention_Click);
			this.wbtnCalculate.Click += new System.EventHandler(this.wbtnCalculate_Click);
			this.wbtnCreateActivity.Click += new System.EventHandler(this.wbtnCreateActivity_Click);
			this.wbtnGoToActivity.Click += new System.EventHandler(this.wbtnGoToActivity_Click);
			this.wbtnFilterDeficits.Click += new System.EventHandler(this.wbtnFilterDeficits_Click);
			this.wbtnFilterGoals.Click += new System.EventHandler(this.wbtnFilterGoals_Click);
			this.wbtnFilterInterventions.Click += new System.EventHandler(this.wbtnFilterInterventions_Click);
			this.wbtnRunReport.Click += new System.EventHandler(this.wbtnRunReport_Click);
			this.CompletionID.SelectedIndexChanged += new System.EventHandler(this.CompletionID_SelectedIndexChanged);
			this.ManagementServiceItemID.SelectedIndexChanged += new System.EventHandler(this.ManagementServiceItemID_SelectedIndexChanged);

			InitializeComponent();

			wo = new WindowOpener();
			wo.ID = "WebLinksWindow";
			wo.NavigateURL = "WebLinks.aspx";
			wo.registerClientScripts(this);

			this.wbtnWebLinks.OnClickScript = "javascript:" + wo.getWindowOpenScript() + "; return false;";

			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			InitPOCParams(); // set UI state
			
			//TeamUser select
			this.TUSel.RebindControls(typeof(POCIntervention), "AssignedTeamID", "AssignedUserID");

			if (!IsPostBack)
			{
				LoadData();
			}
			else
			{
				cMS = (CMS)this.LoadObject(typeof(CMS));	// This would reload from cache
				pOCDeficit = (POCDeficit)this.LoadObject(typeof(POCDeficit));  // load object from cache
				pOCGoal = (POCGoal)this.LoadObject(typeof(POCGoal));  // load object from cache
				pOCIntervention = (POCIntervention)this.LoadObject(typeof(POCIntervention));  // load object from cache

				deficitsFilter = (BasePOC)this.LoadObject("deficitsFilter");  // load object from cache
				goalsFilter = (BasePOC)this.LoadObject("GoalsFilter");  // load object from cache
				interventionsFilter = (BasePOC)this.LoadObject("InterventionsFilter");  // load object from cache
			}
			problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
			patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
			patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
		}

		private void LoadData()
		{
			NewFilters();

			if(InterventionParam != null)
			{
				// set DGI tree from passed POCIntevention
				LoadDataForIntervention(InterventionParam);
			}
			else
			{	// Load by given CMS	
				LoadDataForCMS();
				if(this.CMS != null)
					LoadDataForDGI();
			}
		}

		private void NewFilters()
		{
			NewDeficitsFilter();
			NewGoalsFilter();
			NewInterventionsFilter();
		}

		#region Data Objects
		#region CMS
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public CMS CMS
		{
			get { return cMS; }
			set
			{
				cMS = value;
				try
				{
					this.UpdateFromObject(this.pnlReport.Controls, cMS);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(CMS), cMS);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForCMS()
		{
			bool result = true;
			CMS cMS = null;
			try
			{	// use any load method here
				cMS = GetParamOrGetFromCache("CMS", typeof(CMS)) as CMS;
				if (cMS == null)	// if not specified create a new one
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a CMS");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//cMS.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CMS = cMS;
			return result;
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForCMS()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlReport.Controls, cMS);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}		

		private void LoadDataForDGI()
		{
			LoadDataForDGI(0);
		}

		/// <summary>
		/// Loads DGI data and sets required Defict
		/// </summary>
		/// <param name="deficitId">ID of Deficit to be selected</param>
		private void LoadDataForDGI(int deficitId)
		{
			try
			{
				cMS.LoadPOCDeficits(false);
				this.cMS.POCDeficits.OpenWithAll = this.deficitsFilter.OpenWithAll;
				grD.UpdateFromCollection(cMS.POCDeficits);
				
				if(deficitId > 0)
				{
					POCDeficit = cMS.POCDeficits.FindBy(deficitId);
					grD.SelectedRowPK = new object[]{deficitId};
					return;
				}
				if(this.grD.Rows.Count > 0)
				{
					//	LOAD Child collection ONLY for the first item that satisfies filer
					//	grid ALWAYS shows ONLY filtered items from collection
					//	If no such items found keep child grids empty
					POCDeficit = cMS.POCDeficits[this.grD.GetColIndexFromRowIndex(0)];
					grD.SelectedRowIndex = 0;
				}
				else
				{
					POCDeficit = null;
					grD.ClearRows();
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(CMS cMS)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("CMS", cMS);
			PushTargetTab("POC_PlanOfCare");
			BasePage.Redirect("DGIForm.aspx");

		}
		#endregion

		#region POCDeficit
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public POCDeficit POCDeficit
		{
			get { return pOCDeficit; }
			set
			{
				pOCDeficit = value;
				bool clearGoals = false;
				try
				{
					if(value == null)
						clearGoals = true;
					else
					{
						this.UpdateFromObject(this.pnlDeficit.Controls, pOCDeficit);  // update controls for the given control collection
						// other object-to-control methods if any					
						pOCDeficit.LoadPOCGoals(false);
						POCDeficit.POCGoals.OpenWithAll = this.goalsFilter.OpenWithAll;
						grG.UpdateFromCollection(POCDeficit.POCGoals);
						
						if(InterventionParam != null)
						{
							// If POCIntervention was passed use it to select proper Goal
							POCGoal = POCDeficit.POCGoals.FindBy(InterventionParam.GoalID);
							grG.SelectedRowPK = new object[]{InterventionParam.GoalID};
						}
						else if(this.grG.Rows.Count > 0)
						{
							//	LOAD Child collection ONLY for the first item that satisfies filer
							//	grid ALWAYS shows ONLY filtered items from collection
							//	If no such items found keep child grids empty
							POCGoal = POCDeficit.POCGoals[this.grG.GetColIndexFromRowIndex(0)];
							grG.SelectedRowIndex = 0;
						}
						else
							clearGoals = true;
					}
					if(clearGoals)
					{
						POCGoal = null;
						grG.ClearRows();
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				
				this.CacheObject(typeof(POCDeficit), pOCDeficit);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPOCDeficit()
		{
			try
			{	
				POCDeficit tmp = new POCDeficit();
				tmp = POCDeficit;
				this.UpdateToObject(this.pnlDeficit.Controls, pOCDeficit);	// controls-to--object
				if (CMS.POCDeficits.IsPOCDeficitTypeInCollection(POCDeficit, pOCDeficit.DeficitTypeID))
				{
					pOCDeficit = tmp;
					this.SetPageMessage(Messages.CMSMessages.MessageIDs.POCDEFICITDUPLICATE, EnumPageMessageType.Error);
					return false;
				}
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPOCDeficit()
		{
			bool result = true;
			POCDeficit pOCDeficit = null; // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				pOCDeficit = new POCDeficit(true, false);
				pOCDeficit.ParentPOCDeficitCollection = CMS.POCDeficits;
				// Fix: Don't need this here anynore, implemented in constructor
				//pOCDeficit.Fmt_DeficitStatusId = POCDeficitStatus.OPEN;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			POCDeficit = pOCDeficit;
			return result;
		}
		#endregion
		
		#region POCGoal
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public POCGoal POCGoal
		{
			get { return pOCGoal; }
			set
			{
				pOCGoal = value;
				bool clearInterventions = false;
				try
				{
					if(value == null)
						clearInterventions = true;
					else
					{
						this.UpdateFromObject(this.pnlGoal.Controls, pOCGoal);  // update controls for the given control collection
						// other object-to-control methods if any
						pOCGoal.LoadPOCInterventions(false);
						POCGoal.POCInterventions.OpenWithAll = this.interventionsFilter.OpenWithAll;
						POCGoal.POCInterventions.FilterObject = null; // simple filtering
						grI.UpdateFromCollection(pOCGoal.POCInterventions);
						if(InterventionParam != null)
						{
							// If POCIntervention was passed use it to select proper row.
							SetPOCIntervention(InterventionParam, true, true);
						}
						else if(grI.Rows.Count > 0)
						{
							//	LOAD Child collection ONLY for the first item that satisfies filer
							//	grid ALWAYS shows ONLY filtered items from collection
							//	If no such items found keep child grids empty
							SetPOCIntervention(POCGoal.POCInterventions[this.grI.GetColIndexFromRowIndex(0)]
								, true, false);
						}
						else
							clearInterventions = true;
					}
					if(clearInterventions)
					{
						POCIntervention = null;
						grI.ClearRows();
					}
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				
				this.CacheObject(typeof(POCGoal), pOCGoal);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPOCGoal()
		{
			try
			{	
				POCGoal tmp = new POCGoal();
				tmp = POCGoal;
				this.UpdateToObject(this.pnlGoal.Controls, pOCGoal);	// controls-to-object
				if (POCDeficit.POCGoals.IsPOCGoalTypeInCollection(POCGoal, pOCGoal.GoalTypeId))
				{
					pOCGoal = tmp;
					this.SetPageMessage(Messages.CMSMessages.MessageIDs.POCGOALDUPLICATE, EnumPageMessageType.Error);
					return false;
				}
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPOCGoal()
		{
			bool result = true;
			POCGoal pOCGoal = null; 
			try
			{	
				pOCGoal = new POCGoal(true);
				pOCGoal.GoalTermId = POCGoalTermCollection.ActivePOCGoalTerms.Lookup_GoalTermIdByCode(POCGoalTerm.GOALTERMSHORT);
				pOCGoal.Fmt_GoalOutcomeId = POCGoalOutcome.OPEN;
				pOCGoal.ParentPOCGoalCollection = POCDeficit.POCGoals;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			POCGoal = pOCGoal;
			return result;
		}
		#endregion
		
		#region POCIntervention
		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(POCIntervention intrv)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("POCIntervention", intrv);
			PushTargetTab("POC_PlanOfCare");
			BasePage.Redirect("DGIForm.aspx");
		}

		public static void Redirect(int interventionId)
		{
			POCIntervention intrv = new POCIntervention(false);
			if(!intrv.Load(interventionId))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@INTERVENTION@");
			Redirect(intrv);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public POCIntervention POCIntervention
		{
			get { return pOCIntervention; }
			set
			{
				pOCIntervention = value;
				if(value != null)
				{
					try
					{
						#region  Issue 1140
						bool completed = pOCIntervention.IsInterventionCompleted;
						CompletionDateVisibility = SubtypeVisibility = completed;
						if(completed && pOCIntervention.CompletionDate == DateTime.MinValue)
								pOCIntervention.CompletionDate = DateTime.Now;
						#endregion

						this.UpdateFromObject(this.pnlIntervention.Controls, pOCIntervention);  // update controls for the given control collection
						if(completed)
							this.UpdateFromObject(this.pnlInterventionBilling.Controls, pOCIntervention);
					}
					catch(Exception ex)
					{
						this.RaisePageException(ex);  // notify the page about the error
					}
				}
				this.CacheObject(typeof(POCIntervention), pOCIntervention);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPOCIntervention()
		{
			try
			{	//customize this method for this specific page
				POCIntervention tmp = new POCIntervention();
				tmp = POCIntervention;
				this.UpdateToObject(this.pnlIntervention.Controls, pOCIntervention);	// controls-to-object
				this.UpdateToObject(this.pnlInterventionBilling.Controls, pOCIntervention);
				if(POCGoal.POCInterventions.IsPOCInterventionTypeInCollection(POCIntervention, pOCIntervention.InterventionTypeID, POCGoal.GoalId))
				{
					pOCIntervention = tmp;
					this.SetPageMessage(Messages.CMSMessages.MessageIDs.POCINTERVENTIONDUPLICATE, EnumPageMessageType.Error);
					return false;
				}
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPOCIntervention()
		{
			bool result = true;
			POCIntervention pOCIntervention = null; 
			try
			{	
				pOCIntervention = new POCIntervention(true);
				pOCIntervention.ParentPOCInterventionCollection = POCGoal.POCInterventions;
				pOCIntervention.DueDate = DateTime.Now;
				pOCIntervention.Fmt_CompletionID = ActivityCompletion.FUTU;		// per Issue 1140
				pOCIntervention.ActivityPrimaryTypeID = 
					ActivityPrimaryTypeCollection.ActiveActivityPrimaryTypes.Lookup_ActivityPrimaryTypeIDByCode(ActivityPrimaryType.INTERVENTION);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			POCIntervention = pOCIntervention;
			return result;
		}

		private void LoadDataForIntervention(POCIntervention intv)
		{	
			if(intv.ParentPOCInterventionCollection != null)
				this.CMS = intv.ParentPOCInterventionCollection.ParentCMS;
			else
				this.CMS = CMS.GetCMSByPOCInterventionId(intv.POCInterventionID);
			// Load grids from given Intervention. Properly Set selected Deficit, Goal and Intervention.
			LoadDataForDGI(intv.DeficitId /*will set given Deficit as selected*/);			
		}

		private POCIntervention InterventionParam
		{
			get 
			{
				return GetParam("POCIntervention") as POCIntervention; 
			}
		}
		#endregion	

		#region Filters
		#region DeficitsFilter
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BasePOC DeficitsFilter
		{
			get { return deficitsFilter; }
			set
			{
				deficitsFilter = value;
				try
				{
					this.UpdateFromObject(this.DeficitsOpenWithAll, deficitsFilter);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("deficitsFilter", deficitsFilter);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForDeficitsFilter()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.DeficitsOpenWithAll, deficitsFilter);	// controls-to-object
				// other control-to-object methods if any
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewDeficitsFilter()
		{
			bool result = true;
			BasePOC deficitsFilter = null; //new BasePOC(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				deficitsFilter = new BasePOC();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.DeficitsFilter = deficitsFilter;
			return result;
		}
		#endregion

		#region GoalsFilter
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BasePOC GoalsFilter
		{
			get { return goalsFilter; }
			set
			{
				goalsFilter = value;
				try
				{
					this.UpdateFromObject(this.GoalsOpenWithAll, goalsFilter);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("GoalsFilter", goalsFilter);  // cache object using the caching method declared on the page
			}
		}
		

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForGoalsFilter()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.GoalsOpenWithAll, goalsFilter);	// controls-to-object
				// other control-to-object methods if any
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewGoalsFilter()
		{
			bool result = true;
			BasePOC goalsFilter = null;
			try
			{	// or use an initialization method here
				goalsFilter = new BasePOC();
				goalsFilter.OpenWithAll = -1;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.GoalsFilter = goalsFilter;
			return result;
		}
		#endregion

		#region InterventionsFilter
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public BasePOC InterventionsFilter
		{
			get { return interventionsFilter; }
			set
			{
				interventionsFilter = value;
				try
				{
					this.UpdateFromObject(this.InterventionsOpenWithAll, interventionsFilter);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject("InterventionsFilter", interventionsFilter);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForInterventionsFilter()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.InterventionsOpenWithAll, interventionsFilter);	// controls-to-object
				// other control-to-object methods if any
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewInterventionsFilter()
		{
			bool result = true;
			BasePOC interventionsFilter = null; //new BasePOC(); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				interventionsFilter = new BasePOC();
				interventionsFilter.OpenWithAll = -1;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.InterventionsFilter = interventionsFilter;
			return result;
		}
		#endregion
		#endregion
		#endregion

		#region UI Initialization and Events
		#region Initialization
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.SetERCTabVisibilities();
			SetPageTabItemActive(TargetTabKey);

			this.wbtnWebLinks.Visible = (this.pOCIntervention == null ? false : true);

			// main ADD buttons - enable main panels
			this.pnlReport.Visible = this.wbtnShowGoalPanel.Visible = this.grD.Rows.Count > 0;
			this.wbtnShowInterventionPanel.Visible = this.grG.Rows.Count > 0;
			bool saveButtonEnabled;
			if(!this.pnlDeficit.Visible && !this.pnlGoal.Visible && !this.pnlIntervention.Visible && !this.pnlInterventionBilling.Visible)
				saveButtonEnabled = true;
			else
				saveButtonEnabled = false;
			this.SetPageToolbarItemEnabled("Save", saveButtonEnabled);
			this.RenderClientFunctions(this.pnlReport.Controls, this.cMS, "ReportDatesValidation");
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.cMS);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);
			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		public new void OnToolbarButtonClick_Cancel(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.RedirectToCMS();
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			try
			{
				this.CMS.SavePOCDeficits();
				LoadDataForDGI();  // refresh grids with PKs
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, Messages.CMSMessages.MessageIDs.PLANOFCARE); 
			}
			catch(Exception ex)
			{
				RaisePageException(ex);
			}
		}

		private void InitPOCParams()
		{
			// buttons availalble at main panels
			this.wbtnAddDeficit.Visible = false;
			this.wbtnUpdateDeficitItem.Visible = false;

			this.wbtnAddGoal.Visible = false;
			this.wbtnUpdateGoalItem.Visible = false;

			wbtnAddInterventionOldState = this.wbtnAddIntervention.Visible;
			this.wbtnAddIntervention.Visible = false;
			wbtnUpdateInterventionItemOldState = this.wbtnUpdateInterventionItem.Visible;
			this.wbtnUpdateInterventionItem.Visible = false;
			
			// main panels
			this.pnlDeficit.Visible = false;
			this.pnlGoal.Visible = false;
			this.pnlIntervention.Visible = false;
			this.pnlInterventionBilling.Visible = false;
			IsBillable.Enabled = false;
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			CheckForDirty(this.cMS, this.cMS.POCDeficits);
		}

		#endregion
		
		#region Main buttons
		private void wbtnShowDeficitPanel_Click(object sender, System.EventArgs e)
		{
			NewPOCDeficit();	
			this.pnlDeficit.Visible = true;
			this.wbtnAddDeficit.Visible = true;
			ScrollToControl(this.pnlDeficit);
		}

		private void wbtnShowGoalPanel_Click(object sender, System.EventArgs e)
		{
			NewPOCGoal();
			this.pnlGoal.Visible = true;
			this.wbtnAddGoal.Visible = true;
			ScrollToControl(this.pnlGoal);
		}

		private void wbtnShowInterventionPanel_Click(object sender, System.EventArgs e)
		{
			NewPOCIntervention();
			this.pnlIntervention.Visible = true;
			this.wbtnAddIntervention.Visible = true;
			this.wbtnCreateActivity.Visible = false;
			ScrollToControl(this.pnlIntervention);
		}

		private void wbtnRunReport_Click(object sender, System.EventArgs e)
		{
			if(!this.ReadControlsForCMS())
				return;
				//if(this.cMS.ReportDateFrom <= this.cMS.ReportDateTo)
			LetterForm.Redirect(this.cMS, this.cMS.ReportDateFrom, this.cMS.ReportDateTo);
			this.SetPageMessage("@POCREPORTTEMPLATENOTDEFINED@", EnumPageMessageType.AddError); 
		} 
		#endregion

		#region Grids
		private void grD_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{
			grD.AddButtonColumn("Select", "Select", 1);			
		}

		private void grG_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{	
			grG.AddButtonColumn("Select", "Select", 1);
		}

		private void grI_ColumnsBoundToDataClass(object sender, System.EventArgs e)
		{	
			grI.AddButtonColumn("Select", "Select", 1);
		}

		private void grD_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grD.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;	
			try
			{
				POCDeficit = cMS.POCDeficits[index];
				grD.SelectedRowIndex = index;

				if (e.Cell.Key == "Edit")
				{
					pnlDeficit.Visible = true;
					wbtnUpdateDeficitItem.Visible = true;
					ScrollToControl(this.pnlDeficit);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void grG_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{	
			int index = grG.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			try
			{
				POCGoal = POCDeficit.POCGoals[index];
				grG.SelectedRowIndex = index;

				if (e.Cell.Key == "Edit")
				{
					pnlGoal.Visible = true;
					wbtnUpdateGoalItem.Visible = true;
					ScrollToControl(this.pnlGoal);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}

		private void grI_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grI.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			this.grI.SelectedRowIndex = index;
			if (e.Cell.Key == "Edit")
				SetPOCIntervention(POCGoal.POCInterventions[index], false, true);
		}

		private void SetPOCIntervention(POCIntervention intv, bool setSelectedRow, bool processRelatedPanels)
		{
			try
			{
				POCIntervention = intv;
				if(setSelectedRow)
					grI.SelectedRowPK = this.pOCIntervention.PK;

				if(processRelatedPanels)
				{
					if (POCIntervention.Fmt_CompletionID == ActivityCompletion.COMP)
						pnlInterventionBilling.Visible = true;

					KeepInterventionUIState();
					wbtnUpdateInterventionItem.Visible = true;
					ScrollToControl(this.pnlIntervention);
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
			}
		}
		#endregion

		#region Deficit Events
		private void wbtnCancelDeficit_Click(object sender, System.EventArgs e)
		{
			this.pnlDeficit.Visible = false;
		}

		private void wbtnAddDeficit_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForPOCDeficit())	
			{					
				cMS.POCDeficits.Add(pOCDeficit); //Add to collection ONLY if Deficit of same type is not present
				grD.UpdateFromCollection(cMS.POCDeficits);
				grD.SelectedRowIndex = cMS.POCDeficits.Count - 1;
				POCDeficit = pOCDeficit;	
			}
		}

		private void wbtnUpdateDeficitItem_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForPOCDeficit())
			{
				grD.UpdateRowFromObject(grD.GetRowIndexFromPK(this.pOCDeficit.PK), this.pOCDeficit);
				POCDeficit.IsDirty = true;
				POCDeficit = pOCDeficit;
				pnlDeficit.Visible = false;
			}
		}
		#endregion

		#region Goal Events
		private void wbtnCancelGoal_Click(object sender, System.EventArgs e)
		{
			this.pnlGoal.Visible = false;
		}
		
		private void wbtnAddGoal_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForPOCGoal())
			{	
				POCDeficit.POCGoals.Add(pOCGoal);
				grG.UpdateFromCollection(POCDeficit.POCGoals); 
				grG.SelectedRowIndex = grG.Rows.Count - 1;
				POCDeficit.IsDirty = true;
				POCGoal = pOCGoal;
			}
		}

		private void wbtnUpdateGoalItem_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForPOCGoal())
			{
				POCDeficit.IsDirty = true;
				POCGoal.IsDirty = true;
				grG.UpdateRowFromObject(grG.GetRowIndexFromPK(this.pOCGoal.PK), this.pOCGoal);
				this.pnlGoal.Visible = false;
				/* UR01.26.17	
				   When all Goals for a Deficit are resolved (status = complete) 
				   the application must display a message asking if the Deficit should be complete.  
				   If yes, the application must change the Deficit to complete
				*/
				if(POCDeficit.POCGoals.AreAllGoalsResolved())
				{
					this.SetPageMessage(POCDeficit.GOALSRESOVLED, EnumPageMessageType.AddInfo);

					pnlDeficit.Visible = true;
					wbtnUpdateDeficitItem.Visible = true;
					POCDeficit = POCDeficit;
				}
				else
					POCGoal = pOCGoal;
			}
		}
		#endregion

		#region Intervention Events
		private void wbtnCancelIntervention_Click(object sender, System.EventArgs e)
		{
			pnlInterventionBilling.Visible = pnlIntervention.Visible = false;
		}

		private void wbtnAddIntervention_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForPOCIntervention())	
			{					
				UpdateBillableControls();
				POCGoal.POCInterventions.Add(POCIntervention); //Add to collection ONLY if Deficit of same type is not present
				grI.UpdateFromCollection(POCGoal.POCInterventions); 
				grI.SelectedRowIndex = grI.Rows.Count - 1;
				POCIntervention = POCIntervention;
				POCDeficit.IsDirty = true;
				POCGoal.IsDirty = true;
			}
		}

		private void wbtnUpdateInterventionItem_Click(object sender, System.EventArgs e)
		{
			bool keepInterventionUIState = true;
			if(ReadControlsForPOCIntervention())
			{
				POCDeficit.IsDirty = true;
				POCGoal.IsDirty = true;
				POCIntervention.IsDirty = true;
				UpdateBillableControls();
				POCIntervention.Calculate();
				
				grI.UpdateRowFromObject(grI.GetRowIndexFromPK(this.pOCIntervention.PK), this.pOCIntervention);
				pnlIntervention.Visible = false;
				pnlInterventionBilling.Visible = false;
				keepInterventionUIState = false;
				//pOCIntervention.UpdateAndSaveActivity();  // keep Activity in sync. Need to rethink this, because of possible unsyncronized states of both structures.
				/* UR01.26.16	
				 * When all Interventions for a Goal are resolved (status = complete) 
				 * the application must display a message asking if the Goal�s Outcome should be complete.  
				 * If yes, the application must change the Goal�s Outcome to complete
				*/
				if(POCGoal.POCInterventions.AreAllInterventionsResolved())
				{
					this.SetPageMessage(POCGoal.INTERVENTIONSRESOVLED, EnumPageMessageType.AddInfo);

					/*pnlIntervention.Visible = false;
					pnlInterventionBilling.Visible = false;
					keepInterventionUIState = false;*/
					pnlGoal.Visible = true;
					wbtnUpdateGoalItem.Visible = true;
					ScrollToControl(this.pnlGoal);
					POCGoal = POCGoal;
					
				}
				else
					POCIntervention = POCIntervention;
			}
			if(keepInterventionUIState)
				KeepInterventionUIState();
		}	

		private void ActivityPrimaryTypeID_SelectedRowChanged(object sender, System.EventArgs e)
		{
			this.UpdateToObject(ActivityPrimaryTypeID, this.pOCIntervention);

			this.pOCIntervention.InterventionTypeID = 0;
				this.UpdateFromObject(this.IT, this.pOCIntervention);
			this.pOCIntervention.ActivitySubTypeID = 0;
				this.UpdateFromObject(this.ActivitySubTypeID, this.pOCIntervention);
			KeepInterventionUIState();
		}

		private void IT_SelectedRowChanged(object sender, System.EventArgs e)
		{
			this.UpdateToObject(IT, this.pOCIntervention);

			this.pOCIntervention.ActivitySubTypeID = 0;
				this.UpdateFromObject(ActivitySubTypeID, this.pOCIntervention);
			int i = this.pOCIntervention.ActivityPrimaryTypeID;
			this.pOCIntervention.SyncronizePrimaryTypeByInterventionType();
				this.UpdateFromObject(ActivityPrimaryTypeID, this.pOCIntervention);
			if(i != this.pOCIntervention.ActivityPrimaryTypeID /*ActivityPrimaryTypeID has been changed*/)
				this.UpdateFromObject(this.IT, this.pOCIntervention /*Filter down drop down selection*/);
			KeepInterventionUIState();
		}

		private void CompletionID_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if(ReadControlsForPOCIntervention())
			{
				POCIntervention = POCIntervention;
				UpdateBillableControls();
			}
			KeepInterventionUIState();
		}

		private void ManagementServiceItemID_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if(ReadControlsForPOCIntervention())
			{	
				// set ManagementServiceItem based on drop down selection
				POCIntervention.ManagementServiceItem =
					POCIntervention.LookupOf_ManagementServiceItemID.FindBy(this.POCIntervention.ManagementServiceItemID);				  
				
				UpdateBillableControls();
			}
			KeepInterventionUIState();
		}

		private void wbtnCalculate_Click(object sender, System.EventArgs e)
		{	
			if(ReadControlsForPOCIntervention())
			{		
				if (!POCIntervention.Calculate())
					SetPageMessage("Intervention calculation failed!", NetsoftUSA.WebForms.EnumPageMessageType.Error);	
				UpdateBillableControls();
			}
			KeepInterventionUIState();
		}

		private void KeepInterventionUIState()
		{
			pnlIntervention.Visible = true;
			CompletionDateVisibility = SubtypeVisibility = pnlInterventionBilling.Visible = this.POCIntervention.IsInterventionCompleted;
			wbtnAddIntervention.Visible = wbtnAddInterventionOldState;
			wbtnUpdateInterventionItem.Visible = wbtnUpdateInterventionItemOldState;
			this.wbtnCreateActivity.Visible = !this.POCIntervention.IsNew && this.POCIntervention.ActivityID == 0;
			this.wbtnGoToActivity.Visible = this.POCIntervention.ActivityID > 0;
			ScrollToControl(this.pnlIntervention);
		}

		private bool SubtypeVisibility
		{
			set {this.lbActivitySubTypeID.Visible = this.ActivitySubTypeID.Visible = value; }
		}

		private bool CompletionDateVisibility
		{
			set {this.lbCompletionDate.Visible = this.CompletionDate.Visible = this.vldCompletionDate.Visible
				 = value;}
		}

		private void UpdateBillableControls()
		{
			IT.UpdateData(false);
			Fmt_BaseUOMID.UpdateData(false);
			Fmt_ConversionUnitOfMeasureDescriptionByID.UpdateData(false);
			IsBillable.UpdateData(false);
		}

		private void wbtnGoToActivity_Click(object sender, System.EventArgs e)
		{
			EnumActivityAndNoteContext ctx = EnumActivityAndNoteContext.ERC;
			this.CacheObject("ActivityAndNoteContext", ctx);
			ActivityForm.Redirect(this.patient, this.POCIntervention.ActivityID);
		}

		private void wbtnCreateActivity_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForPOCIntervention())
			{
				try
				{
					if (this.POCIntervention.Activity == null)
					{
						this.POCIntervention.CreateActivityAndSave(this.patient, this.patientCoverage, this.cMS);
						this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, Messages.PatientMessages.MessageIDs.ACTIVITY);
						POCDeficit.IsDirty = true;
						POCGoal.IsDirty = true;
						POCIntervention.IsDirty = true;
					}
					KeepInterventionUIState();
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		private void wbtnShowAllInterventions_Click(object sender, System.EventArgs e)
		{
			PlanOfCareSearch.Redirect(CMS);
		}
		#endregion

		#region Filter events
		private void wbtnFilterDeficits_Click(object sender, System.EventArgs e)
		{
			if(this.ReadControlsForDeficitsFilter())
				LoadDataForDGI();
		}

		private void wbtnFilterGoals_Click(object sender, System.EventArgs e)
		{
			if(this.ReadControlsForGoalsFilter() && POCDeficit != null)
				POCDeficit = POCDeficit;	
		}

		private void wbtnFilterInterventions_Click(object sender, System.EventArgs e)
		{
			if(this.ReadControlsForInterventionsFilter() && POCGoal != null)
				POCGoal = POCGoal;
		}
		#endregion

		#endregion
	}
}
