using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ASSESSMENTS_MAINT)]
	
	[MainLanguageClass("ActiveAdvice.Messages.AssessmentMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("PresentationGroup,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(PresentationGroupSearch))]
	[SelectedMainMenuItem("MMaintenance")]
	[SelectedMenuItem("PR")]
	public class PresentationGroupForm : AssessmentMaintenanceBasePage
	{
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetail;
		protected NetsoftUSA.WebForms.OBFieldLabel lblDescription;
		protected NetsoftUSA.WebForms.OBTextBox QuestionText;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPresentationGroupID;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PresentationGroupID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPresentationGroupID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContentOwnerID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo ContentOwnerID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContentOwnerID;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlContent;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridQuestionPicker;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSaveSelections;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnCancelSelections;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlQuestionPicker;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridQuestions;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlQuestions;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPresentationGroupPicker;

		private PresentationGroup presentationGroup;
		private PresentationGroupQuestionCollection presentationGroupQuestions;
		private QuestionCollection questionPicker;		


		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!this.IsPostBack)
				this.LoadData();			// Load data is the actual data loading method
			else
			{
				presentationGroup = (PresentationGroup)this.LoadObject(typeof(PresentationGroup));	// This would reload from cache
				presentationGroupQuestions = (PresentationGroupQuestionCollection)this.LoadObject(typeof(PresentationGroupQuestionCollection));
				questionPicker = (QuestionCollection)this.LoadObject(typeof(QuestionCollection));
			}
		}

		public static void Redirect(PresentationGroup presentationGroup)
		{
			BasePage.PushParam("PresentationGroup", presentationGroup);
			BasePage.Redirect("PresentationGroupForm.aspx");
		}

		public static void Redirect(int presentationGroupID)
		{
			PresentationGroup presentationGroup = new PresentationGroup();
			if (!presentationGroup.Load(presentationGroupID))
				throw new ActiveAdviceException("Can't find PresentationGroup");
			BasePage.PushParam("PresentationGroup", presentationGroup);
			BasePage.Redirect("PresentationGroupForm.aspx");
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			PresentationGroup presentationGroup = null;
			try
			{	// use any load method here
				presentationGroup = this.GetParam("PresentationGroup") as PresentationGroup;
				if (presentationGroup == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a Presentation Group");
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//presentationGroup.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.PresentationGroup = presentationGroup;		// When you set the object to the property, controls are automatically populated
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				if (!this.ReadControlsForQuestions())
					return false;
				presentationGroup.Save(); // update or insert to db 
				presentationGroupQuestions.Save();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PresentationGroup PresentationGroup
		{
			get { return presentationGroup; }
			set
			{
				presentationGroup = value;
				try
				{
					// add all object-to-control population code here
					this.UpdateFromObject(pnlDetail.Controls, presentationGroup);  // update controls for the given control/collection
					this.UpdateFromObject(pnlContent.Controls, presentationGroup); 

					presentationGroup.LoadPresentationGroupQuestions(false);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PresentationGroup), presentationGroup);  // cache object using the caching method declared on the page
				this.PresentationGroupQuestions = presentationGroup.Questions;
			}
		}

		public PresentationGroupQuestionCollection PresentationGroupQuestions
		{
			get { return presentationGroupQuestions; }
			set
			{
				presentationGroupQuestions = value;
				try
				{
					pnlQuestions.Visible = presentationGroupQuestions != null;

					if (presentationGroupQuestions != null)
					{
						// Load the selected Presentation Groups
						gridQuestions.UpdateFromCollection(presentationGroupQuestions);
						this.QuestionPicker = null; // Cannot be in pick mode
					}
				
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(PresentationGroupQuestionCollection), presentationGroupQuestions);  // cache questionnaireect using the caching method declared on the page
			}
		}


		public QuestionCollection QuestionPicker
		{
			get { return questionPicker; }
			set
			{
				questionPicker = value;
				try
				{
					pnlQuestionPicker.Visible = questionPicker != null;

					if (questionPicker != null)
					{
						// Load the whole Presentation Groups list
						/* commented to fix Issue 418
						gridQuestionPicker.DisplayLayout.AllowUpdateDefault = Infragistics.WebUI.UltraWebGrid.AllowUpdate.Yes;*/
						gridQuestionPicker.UpdateFromCollection(questionPicker);  // update given grid from the collection
					}
					
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(QuestionCollection), questionPicker);  // cache questionnaireect using the caching method declared on the page
			}
		}

		public bool ReadControlsForPicker()
		{
			try
			{	
				// Read the selected values 
				QuestionCollection questions = QuestionCollection.GetQuestionsByContentOwnerForSelection(presentationGroup.ContentOwnerID);
				questions.SetSelectedQuestionsFromCollection(presentationGroup.Questions);
				gridQuestionPicker.UpdateToCollection(questions);
				presentationGroup.Questions.SynchronizeQuestionsFromSelectableCollection(presentationGroup.PresentationGroupID, questions);

				this.PresentationGroupQuestions = presentationGroup.Questions;

				// other control-to-object methods if any
				return true;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}


		public bool ReadControlsForQuestions()
		{
			try
			{	
				// Read the sort order values
				gridQuestions.UpdateToCollection(presentationGroup.Questions);

				this.PresentationGroupQuestions = presentationGroup.Questions;

				// other control-to-object methods if any
				return true;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	// add all control-to-object population code here
				this.UpdateToObject(pnlDetail.Controls, presentationGroup);  // controls-to-object
				this.UpdateToObject(pnlContent.Controls, presentationGroup);

				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			this.gridQuestions.PagingColumns = new string[] { "PKInt" };
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSaveSelections.Click += new System.EventHandler(this.butSaveSelections_Click);
			this.btnCancelSelections.Click += new System.EventHandler(this.btnCancelSelections_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			//toolbar.AddPreset(ToolbarButtons.SaveCancel);
			toolbar.AddPreset(ToolbarButtons.Save);
			toolbar.AddButton("@CANCEL@", "Cancel", false, true);
		}


		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@PRESENTATIONGROUP@");
			}
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Details":
					toolbar.AddButton("@ADDNEWRECORD@", "AddNew");
					break;
				case "Notes":
					break;
				case "Questions":
					toolbar.AddButton("@ADDREMOVEQUESTION@", "AddRemoveQuestion");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.PresentationGroup = new PresentationGroup(true);
		}

		public void OnToolbarButtonClick_AddRemoveQuestion(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			// First read and store the questions because once we switch to picker mode we'll lose those values
			if (!ReadControlsForQuestions())
				return;

			QuestionCollection questions = QuestionCollection.GetQuestionsByContentOwnerForSelection(presentationGroup.ContentOwnerID);
			if (presentationGroupQuestions != null)
				questions.SetSelectedQuestionsFromCollection(presentationGroupQuestions);

			this.PresentationGroupQuestions = null;
			this.QuestionPicker = questions;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			this.SetPageTabToolbarItemEnabled("AddRemoveQuestion", !presentationGroup.IsNew);
			this.SetPageToolbarItemEnabled("Save", !pnlQuestionPicker.Visible);
		}


		public bool SaveSelections()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPicker())
					return false;
				this.PresentationGroupQuestions = presentationGroup.Questions;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		public bool SaveSortOrders()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForQuestions())
					return false;
				presentationGroup.Questions.SortBySortOrder(true);
				this.PresentationGroupQuestions = presentationGroup.Questions;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}


		public void OnToolbarButtonClick_Answers(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			
		}

		private void butSaveSelections_Click(object sender, System.EventArgs e)
		{
			SaveSelections();
		}

		private void btnCancelSelections_Click(object sender, System.EventArgs e)
		{
			this.QuestionPicker = null;
			this.PresentationGroupQuestions = presentationGroup.Questions;
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(presentationGroup);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			CheckForDirty(this.presentationGroup.Questions);
		}
	}
}
