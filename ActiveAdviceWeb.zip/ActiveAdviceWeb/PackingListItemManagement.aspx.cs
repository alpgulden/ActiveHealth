using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web 
{
	/// <summary>
	/// Summary description for PackingListItemManagement.
	/// </summary>
	/// 
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.CMS_MAINT)]

	[MainLanguageClass("ActiveAdvice.Messages.CMSMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("PackingListItem,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MMaintenance")]						//defines active menu item in main navigation
	[SelectedMenuItem("PackingList")]
	public class PackingListItemManagement : CMSMaintenanceBasePage
	{
		private PackingListItemTriggerCollection packingListItemTriggers;
		private PackingListItemTrigger packingListItemTrigger;
		private PackingListItem packingListItem;
		private PackingListItemCollection packingListItems;
		
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridContainer;
		protected NetsoftUSA.WebForms.OBCheckBox Active;
		protected NetsoftUSA.WebForms.OBFieldLabel lbActive;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnUpdate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCMSTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddItem;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlLinking;
		protected NetsoftUSA.WebForms.OBFieldLabel lbSORGId;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForOrganizationSearch;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanId;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PlanId;
		protected NetsoftUSA.WebForms.WindowOpener WindowOpenerForPlanID;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit PlanName;
		protected System.Web.UI.HtmlControls.HtmlTable tblSORGPlan;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected System.Web.UI.WebControls.Label lblOrganizationName;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OrganizationId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit txtOrganizationPath;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnShowDefaults;
		protected NetsoftUSA.InfragisticsWeb.WebButton wbtnAddTriggers;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEnrollmentId;
		protected NetsoftUSA.InfragisticsWeb.WebCombo EnrollmentId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEnrollmentId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Webtextedit1;
		protected System.Web.UI.HtmlControls.HtmlTable Table8;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldQuestionnaireID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo QuestionnaireID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbQuestionnaireID;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected PlanSelect PlanSelect1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldCMSTypeIDPLITrigger;
		protected NetsoftUSA.InfragisticsWeb.WebCombo CMSTypeIDPLITrigger;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMSTypeIDPLITrigger;
		protected LogicSelect LogicSelect1;
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.wbtnUpdate.Click += new System.EventHandler(this.wbtnUpdate_Click);
			this.wbtnAddItem.Click += new System.EventHandler(this.wbtnAddItem_Click);
			this.wbtnShowDefaults.Click += new System.EventHandler(this.wbtnShowDefaults_Click);
			this.wbtnAddTriggers.Click += new System.EventHandler(this.wbtnAddTriggers_Click);
			this.wbtnShowDefaults.Click += new System.EventHandler(this.wbtnShowDefaults_Click);

			InitializeComponent();
			
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			PlanSelect1.RebindControls(typeof(PackingListItemTrigger), "PlanId", "PlanName");
			LogicSelect1.RebindControls(typeof(PackingListItemTrigger), "LogicId", "LogicDescription");

			if (!IsPostBack)
				LoadData();
			else
			{
				packingListItems = (PackingListItemCollection)this.LoadObject(typeof(PackingListItemCollection));  // load object from cache
				packingListItem = (PackingListItem)this.LoadObject(typeof(PackingListItem));  // load object from cache
				packingListItemTrigger = (PackingListItemTrigger)this.LoadObject(typeof(PackingListItemTrigger));  // load object from cache
				packingListItemTriggers = (PackingListItemTriggerCollection)this.LoadObject(typeof(PackingListItemTriggerCollection));  // load object from cache
			}			
		}

		#region Data Objects
		#region PackingListItems
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PackingListItemCollection PackingListItems
		{
			get { return packingListItems; }
			set
			{
				packingListItems = value;
				try
				{
					grid.DisplayLayout.AllowUpdateDefault = Infragistics.WebUI.UltraWebGrid.AllowUpdate.Yes;
					grid.UpdateFromCollection(packingListItems);  // update given grid from the collection

					PackingListItem item = this.SetSelectedGridItem(grid, packingListItems, 0, false) as PackingListItem;
					if(item == null)
						NewPackingListItem();
					else
						PackingListItem = item;
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(PackingListItemCollection), packingListItems);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				grid.UpdateToCollection(this.PackingListItems);
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			PackingListItemCollection packingListItems = new PackingListItemCollection();
			try
			{	// use any load method here
				packingListItems = PackingListItemCollection.AllPackingListItems;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//packingListItems.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.PackingListItems = packingListItems;
			NewPackingListItemTrigger();
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				packingListItems.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion
		
		#region PackingListItem
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PackingListItem PackingListItem
		{
			get { return packingListItem; }
			set
			{
				packingListItem = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, packingListItem);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PackingListItem), packingListItem);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPackingListItem()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, packingListItem);	// controls-to-object
				// other control-to-object methods if any
				return true;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPackingListItem()
		{
			bool result = true;
			packingListItem = null; // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				packingListItem = new PackingListItem(true);

			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PackingListItem = packingListItem;
			wbtnUpdate.Visible = false;
			wbtnAddItem.Visible = true;
			ScrollToControl(this.pnlDetails);
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPackingListItem()
		{
			try
			{	// data from controls to object
				if (ReadControlsForPackingListItem())
				{
					PackingListItems.Add(PackingListItem);
					grid.UpdateFromCollection(PackingListItems);
					grid.SelectedRowIndex = PackingListItems.Count - 1;
					wbtnUpdate.Visible = true;
					wbtnAddItem.Visible = false;
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}	
		#endregion

		#region PackingListItemTrigger
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PackingListItemTrigger PackingListItemTrigger
		{
			get { return packingListItemTrigger; }
			set
			{
				packingListItemTrigger = value;
				try
				{
					this.UpdateFromObject(this.pnlLinking.Controls, packingListItemTrigger);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PackingListItemTrigger), packingListItemTrigger);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPackingListItemTrigger()
		{
			//int oldOrganizationId = packingListItemTrigger.OrganizationId;
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlLinking.Controls, packingListItemTrigger);	// controls-to-object
				// other control-to-object methods if any
				this.lblOrganizationName.Text = packingListItemTrigger.OrganizationPath;
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPackingListItemTrigger()
		{
			bool result = true;
			PackingListItemTrigger packingListItemTrigger = null;
			try
			{	// or use an initialization method here
				packingListItemTrigger = new PackingListItemTrigger(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			PackingListItemTrigger = packingListItemTrigger;
			this.lblOrganizationName.Text = null;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPackingListItemTrigger()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPackingListItemTrigger())
					return false;
				packingListItemTrigger.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion
		
		#region PackingListItemTriggers
		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PackingListItemTriggerCollection PackingListItemTriggers
		{
			get { return packingListItemTriggers; }
			set
			{
				packingListItemTriggers = value;
				this.CacheObject(typeof(PackingListItemTriggerCollection), packingListItemTriggers);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPackingListItemTriggers()
		{
			bool result = true;
			PackingListItemTriggerCollection packingListItemTriggers = null;
			try
			{	// or use an initialization method here
				packingListItemTriggers = new PackingListItemTriggerCollection(); 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PackingListItemTriggers = packingListItemTriggers;
			return result;
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForPackingListItemTriggers()
		{
			bool result = true;
			NewPackingListItemTriggers();
			try
			{	// use any load method here
				packingListItemTriggers.GetAllPackingListItemTriggers(-1);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//packingListItemTriggers.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.PackingListItemTriggers = packingListItemTriggers;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPackingListItemTriggers()
		{
			try
			{	// data from controls to object
				packingListItemTriggers.Save(); // update or insert to db 
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}
		#endregion
		#endregion

		#region UI Initialization and Events
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			if(this.packingListItem.CMSTypeId == 0)
				this.CMSTypeId.SelectedRow = this.CMSTypeId.Rows[0];
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			switch(tab.Key)
			{
				case "Template" :
					toolbar.AddButton("@ADDNEW@", "newItem", true);
					toolbar.AddButton("@RESETUSERBUTTON@", "Reset", true);
					break;
			}
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Packing List Item(s)"); 
				NSGlobal.ClearCache("AllPackingListItems");
				NSGlobal.ClearCache("ActivePackingListItems");
				grid.UpdateFromCollection(PackingListItems);
			}
		}

		public void OnToolbarButtonClick_newItem(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewPackingListItem();
		}

		public void OnToolbarButtonClick_Reset(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewPackingListItemTrigger();
			RestoreDefaults(true);
		}

		private void wbtnShowDefaults_Click(object sender, System.EventArgs e)
		{
			if(ReadControlsForPackingListItemTrigger())
				RestoreDefaults(false);	
		}

		private void RestoreDefaults(bool reset)
		{
			if(reset)
				PackingListItems.ResetAttachedByTriggerSignature();
			else
				PackingListItems.ResetAttachedByTriggerSignature(packingListItemTrigger);
			grid.UpdateFromCollection(this.PackingListItems);
		}

		private void wbtnAddTriggers_Click(object sender, System.EventArgs e)
		{
			// read Trigger
			// read grid
			// for each Attached == true PLItem and not existing trigger create a trigger. If trigger exists do nothing.
			// for each Attached == false PLItem remove a trigger
			// within context of PLItem each trigger is identified by Organization/PLAN
			ReadControlsForPackingListItemTrigger();
			ReadControls();
			
			LoadDataForPackingListItemTriggers(); // to optimize: don't add new triggers to ALL triggers, just create new collection and save it. Remove trigger by PK if found.
			DateTime dt = DateTime.Now;
			bool triggerSet = IsTriggerSet();
			foreach (PackingListItem item in this.PackingListItems)
			{
				if (item.Attached == true && triggerSet)
				{
					if (!item.TriggerExists(this.packingListItemTrigger))
					{
						PackingListItemTrigger tr = new PackingListItemTrigger(true);
						tr.CopyMembersFrom(this.packingListItemTrigger, true, true, false);
						tr.PackingListItemId = item.PackingListItemId;
						tr.CreationTime = dt;
						PackingListItemTriggers.Add(tr);		
					}
				}
				if (item.Attached == false)
				{
					// remove Trigger for item in context of Organization/PLAN
					if (item.TriggerExists(this.packingListItemTrigger))
					{
						PackingListItemTrigger tr = PackingListItemTriggers.FindBy(packingListItemTrigger.PackingListItemTriggerId);
						tr.MarkDel();
					}
				}
			}// end of all Packing List Items
			if (SaveDataForPackingListItemTriggers())
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.AddInfo, "Triggers "); 
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;	
			
			if (e.Cell.Key == "Edit")
			{
				PackingListItem = PackingListItems[index];
				ScrollToControl(this.pnlDetails);
			}
		}

		private void wbtnUpdate_Click(object sender, System.EventArgs e)
		{
			if (ReadControlsForPackingListItem())
				grid.UpdateFromCollection(PackingListItems);
		}	

		private void wbtnAddItem_Click(object sender, System.EventArgs e)
		{
			SaveDataForPackingListItem();
		}

		private void SetPlanControlsVisibility(bool visible)
		{
			this.lbPlanId.Visible = visible;
			this.PlanId.Visible = visible;
			this.WindowOpenerForPlanID.Visible = visible;
			this.PlanName.Visible = visible;
			this.PackingListItemTrigger.PlanId = (visible == false ? 0 : this.PackingListItemTrigger.PlanId);
		}

		private bool IsTriggerSet()
		{
			return PackingListItemTrigger.LogicId > 0 || PackingListItemTrigger.PlanId > 0
				|| PackingListItemTrigger.OrganizationId > 0 || PackingListItemTrigger.EnrollmentId > 0
				|| PackingListItemTrigger.QuestionnaireID > 0 || PackingListItemTrigger.CMSTypeID > 0;
		}
		#endregion
		
	}	
}
