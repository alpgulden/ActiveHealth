using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms.
	/// You can copy and paste this form and follow the remarks to specialize it.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.ReportMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("DataClass,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMainMenuItem("MReports")]
	[PageTitle("@REPORTSTITLE@")]

	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.REPORTS)]

	public class ReportMaintenance : BasePage
	{
		protected NetsoftUSA.WebForms.OBLabel selection;
		protected NetsoftUSA.WebForms.OBLabel selectionheader;
		protected System.Web.UI.WebControls.Repeater AltMenuList;		
		protected System.Web.UI.WebControls.LinkButton menulink;

		private string menuheader;
	
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			menuheader = this.GetParamOrGetFromCache("menuheader", typeof(string)) as string;
			if(menuheader!=null) 
			{
				this.selection.Visible=false;
				this.selectionheader.Visible=true;
				selectionheader.TextToTranslate = "@" + menuheader + "@";
				GenerateAltMenu(menuheader);
			}
			else
			{
				this.selection.Visible=true;
				this.selectionheader.Visible=false;
			}
		}

		public new static void Redirect(string type)
		{
			BasePage.PushParam("menuheader",type);
			BasePage.Redirect("ReportMaintenance.aspx");
		}

		public static void Redirect()
		{
			BasePage.Redirect("ReportMaintenance.aspx");
		}

		private void GenerateAltMenu(string menuheader)
		{
			ArrayList menuitems= new ArrayList();

			switch(menuheader)
			{
				case "SAVEDREPORTS":
					break;
				case("PRODUCTIONOPERATION"):
					menuitems.Add(Language.TranslateSingle("DAILYWORKLIST"));
					menuitems.Add(Language.TranslateSingle("PATIENTCENSUSSUMMARY"));
					menuitems.Add(Language.TranslateSingle("OPENEVENTSPAGEBREAKAFTERSORG"));
					menuitems.Add(Language.TranslateSingle("OPENEVENTSPAGEBRAFTEREVENT"));
					menuitems.Add(Language.TranslateSingle("CLOSEDEVENTSPAGEBRAFTERSORG"));
					menuitems.Add(Language.TranslateSingle("CLOSEDEVENTSPAGEBRAFTEREVENT"));
					break;
				case "DAILYWORKLIST":
					menuitems.Add(Language.TranslateSingle("BYTEAMMORGORGSORGUSER"));
					menuitems.Add(Language.TranslateSingle("BYUSERFACMORGORGSORG"));
					break;
				case "PATIENTCENSUSSUMMARY":
					menuitems.Add(Language.TranslateSingle("SUMMARYBYMORGORGSORG"));
					menuitems.Add(Language.TranslateSingle("SUMMARYBYUSERFACMORGORGSORG"));
					menuitems.Add(Language.TranslateSingle("SUMMARYBYFACMORGORGSORG"));
					break;
				case "UTILIZATIONSTATISTICS":
					menuitems.Add(Language.TranslateSingle("INPATIENT"));
					menuitems.Add(Language.TranslateSingle("OUTPATIENT"));
					menuitems.Add(Language.TranslateSingle("SAVINGS"));
					menuitems.Add(Language.TranslateSingle("REFERRALSTATISTICS"));
					menuitems.Add(Language.TranslateSingle("NETWORKANALYSIS"));
					menuitems.Add(Language.TranslateSingle("SUMMARYOFCLOSEDCASES"));
					break;
				case("INPATIENT"):
					menuitems.Add(Language.TranslateSingle("UTILWITHNOAGGBYSUBGRP"));
					menuitems.Add(Language.TranslateSingle("ACTUTILWITHNOAGGBYSUBGRP"));
					menuitems.Add(Language.TranslateSingle("IPAUTHORIZATIONSBYSTATE"));
					break;
				case("OUTPATIENT"):
					menuitems.Add(Language.TranslateSingle("OUTPATIENTUTILWITHNOAGGBYSUBGRP"));
					break;
				case("SAVINGS"):
					menuitems.Add(Language.TranslateSingle("COSTCOMPSUMMARY"));
					menuitems.Add(Language.TranslateSingle("COSTCOMPDETAILS"));
					menuitems.Add(Language.TranslateSingle("SUMMARYOFINPATINETOUTPATIENTSAVINGS"));
					break;
				case("REFERRALSTATISTICS"):
					menuitems.Add(Language.TranslateSingle("REFERRALSUMMARYWITHNOAGGRBYSUBGRP"));
					break;
				case "NETWORKANALYSIS":
					menuitems.Add(Language.TranslateSingle("FACILITYNETWORKANALYSIS"));
					menuitems.Add(Language.TranslateSingle("PROVIDERNETWORKANALYSIS"));
					break;
				case "CLINICALMANAGEMENTSERVICE":
					menuitems.Add(Language.TranslateSingle("CAREMANAGEMENT"));
					menuitems.Add(Language.TranslateSingle("MATERNICHEK"));
					menuitems.Add(Language.TranslateSingle("POTENTIALLARGECASES"));
					menuitems.Add(Language.TranslateSingle("MULTIPLEADMISSIONREPORT"));
					break;
				
				case "CAREMANAGEMENT":
					menuitems.Add(Language.TranslateSingle("OPENCMLOGBYUSER"));
					menuitems.Add(Language.TranslateSingle("OPENCMLOGBYORGLEVELS"));
					menuitems.Add(Language.TranslateSingle("NEWCMLOGBYORGLEVELS"));
					menuitems.Add(Language.TranslateSingle("NEWCMLOGBYUSER"));
					menuitems.Add(Language.TranslateSingle("CLOSEDCMLOGBYORGLEVELS"));
					menuitems.Add(Language.TranslateSingle("CLOSEDCMLOGBYUSER"));
					break;
				case "MATERNICHEK":
					menuitems.Add(Language.TranslateSingle("OPENMATERNICHEKLOGBYUSER"));
					menuitems.Add(Language.TranslateSingle("OPENMATERNICHEKLOGBYORGLEVELS"));
					menuitems.Add(Language.TranslateSingle("NEWMATERNICHEKLOGBYUSER"));
					menuitems.Add(Language.TranslateSingle("NEWMATERNICHEKLOGBYORGLEVELS"));
					menuitems.Add(Language.TranslateSingle("CLOSEDMATERNICHEKLOGBYUSER"));
					menuitems.Add(Language.TranslateSingle("CLOSEDMATERNICHEKLOGBYORGLEVELS"));
					menuitems.Add(Language.TranslateSingle("MATERNICHEKRISKTYPESTATISTICS"));
					break;
				case "MANAGEMENT":
					menuitems.Add(Language.TranslateSingle("GENERALEDIT"));
					menuitems.Add(Language.TranslateSingle("ACTIVITYEDIT"));
					menuitems.Add(Language.TranslateSingle("INVOICEOFBILLABLEACTIVITY"));
					menuitems.Add(Language.TranslateSingle("CODETABLEREPORT"));
					menuitems.Add(Language.TranslateSingle("INTAKELOGWITHNOAGG"));
					menuitems.Add(Language.TranslateSingle("EVENTSTATISTICS"));
					break;
				case "GENERALEDIT":
					menuitems.Add(Language.TranslateSingle("RPTACTPATIENTSUBSC"));
					menuitems.Add(Language.TranslateSingle("RPTCLOSEDCMSEVENT"));
					menuitems.Add(Language.TranslateSingle("RPTCLOSEDEVENT"));
					menuitems.Add(Language.TranslateSingle("RPTCLOSEDIPEVENT"));
					menuitems.Add(Language.TranslateSingle("RPTOPENEVENT"));
					menuitems.Add(Language.TranslateSingle("RPTREFERRALS"));
					break;
		
				default:
					throw new ActiveAdviceException("Unknown Header");
					
			}			
 
			AltMenuList.DataSource = menuitems;
			AltMenuList.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{   
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		protected void AltMenuList_ItemDataBound(Object Sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem) 
			{  			
				LinkButton a = (LinkButton)e.Item.FindControl("menulink");
				a.Text = e.Item.DataItem.ToString();
			}
		}

		protected void menulink_click(object sender, System.EventArgs e)
		{
			LinkButton a = (LinkButton) sender;
			if(a.Text == Language.TranslateSingle("GENERALEDIT"))
			{
				ReportMaintenance.Redirect("GENERALEDIT");
			}
			else if(a.Text == Language.TranslateSingle("DAILYWORKLIST"))
			{
				ReportMaintenance.Redirect("DAILYWORKLIST");
			}
			else if(a.Text == Language.TranslateSingle("PATIENTCENSUSSUMMARY"))
			{
				ReportMaintenance.Redirect("PATIENTCENSUSSUMMARY");
			}
			else if(a.Text == Language.TranslateSingle("INPATIENT"))
			{
				ReportMaintenance.Redirect("INPATIENT");
			}
			else if(a.Text == Language.TranslateSingle("OUTPATIENT"))
			{
				ReportMaintenance.Redirect("OUTPATIENT");
			}
			else if(a.Text == Language.TranslateSingle("SAVINGS"))
			{
				ReportMaintenance.Redirect("SAVINGS");
			}
			else if(a.Text == Language.TranslateSingle("REFERRALSTATISTICS"))
			{
				ReportMaintenance.Redirect("REFERRALSTATISTICS");
			}
			else if(a.Text == Language.TranslateSingle("NETWORKANALYSIS"))
			{
				ReportMaintenance.Redirect("NETWORKANALYSIS");
			}
			else if(a.Text == Language.TranslateSingle("CAREMANAGEMENT"))
			{
				ReportMaintenance.Redirect("CAREMANAGEMENT");
			}
			else if(a.Text == Language.TranslateSingle("MATERNICHEK"))
			{
				ReportMaintenance.Redirect("MATERNICHEK");
			}
			else
				ReportParameter.Redirect(a.Text);
		}

		public override void PopulateSubNavigation(WebListBar listbar)
		{
			base.PopulateSubNavigation (listbar);
			listbar.AddItem("@SAVEDREPORTS@","SavedReports");
			listbar.AddItem("@PRODUCTIONOPERATION@","Production");
			listbar.AddItem("@UTILIZATIONSTATISTICS@","UtilizationStatistics");
			listbar.AddItem("@CLINICALMANAGEMENTSERVICE@","ClinicalManagementServices");
			listbar.AddItem("@MANAGEMENT@","Management");
			
		}

		public void OnSubNavigationItemClick_Production(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ReportMaintenance.Redirect("PRODUCTIONOPERATION");
		}
		
		public void OnSubNavigationItemClick_Management(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ReportMaintenance.Redirect("MANAGEMENT");
		}
		public void OnSubNavigationItemClick_UtilizationStatistics(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ReportMaintenance.Redirect("UTILIZATIONSTATISTICS");
		}
		public void OnSubNavigationItemClick_ClinicalManagementServices(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ReportMaintenance.Redirect("CLINICALMANAGEMENTSERVICE");
		}
		public void OnSubNavigationItemClick_SavedReports(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			ReportMaintenance.Redirect("SAVEDREPORTS");
		}
	}
}
