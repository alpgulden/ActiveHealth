using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebToolbar;
using ActiveAdvice.DataLayer;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Use this page as a sample for other forms
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.PLAN)]
	
	[MainLanguageClass("ActiveAdvice.Messages.PlanMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("Plan,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[SelectedMenuItem("Details")]						//define the active menu item in side menu
	[SelectedMainMenuItem("MPlan")]						//defines active menu item in main navigation
	[PageTitle("@PLANPAGETITLE@")]
	public class PlanForm : PlanBasePage
	{
		private PlanNote planNote;
		private Plan plan;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel ContentPanel3;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected System.Web.UI.WebControls.Button butClearSharedCache;
		protected NetsoftUSA.InfragisticsWeb.WebValidator OBValidator1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator OBValidator2;
		protected System.Web.UI.WebControls.Button butNewFocus;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlAddress;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit EffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldName;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Name;
		protected NetsoftUSA.WebForms.OBFieldLabel lbName;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit TerminationDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTerminationDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldContractEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ContractEffectiveDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbContractEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanTypeId;
		protected NetsoftUSA.WebForms.OBComboBox PlanTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAlternatePlanId;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AlternatePlanId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAlternatePlanId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldInsurancePayorId;
		protected NetsoftUSA.WebForms.OBComboBox InsurancePayorId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbInsurancePayorId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbBenefitServiceId;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel1;
		protected NetsoftUSA.WebForms.OBFieldLabel lbTriggerListId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHEDISTypeId;
		protected NetsoftUSA.WebForms.OBComboBox HEDISTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHEDISTypeId;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlSpecs;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlTriggers;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReferralGoodFor;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit ReferralGoodFor;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReferralGoodFor;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldLengthOfStayTrigger;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit LengthOfStayTrigger;
		protected NetsoftUSA.WebForms.OBFieldLabel lbLengthOfStayTrigger;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReview;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit Review;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReview;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldOutlierTrigger;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit OutlierTrigger;
		protected NetsoftUSA.WebForms.OBFieldLabel lbOutlierTrigger;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlFlags;
		protected NetsoftUSA.WebForms.OBCheckBox EAPreferral;
		protected NetsoftUSA.WebForms.OBFieldLabel lbEAPreferral;
		protected NetsoftUSA.WebForms.OBCheckBox URWhenMedicareIsPrimary;
		protected NetsoftUSA.WebForms.OBFieldLabel lbURWhenMedicareIsPrimary;
		protected NetsoftUSA.WebForms.OBCheckBox URWhenOtherInsIsPrimary;
		protected NetsoftUSA.WebForms.OBFieldLabel lbURWhenOtherInsIsPrimary;
		protected NetsoftUSA.WebForms.OBCheckBox CMWhenMedicareIsPrimary;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMWhenMedicareIsPrimary;
		protected NetsoftUSA.WebForms.OBCheckBox CMWhenOtherInsIsPrimary;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCMWhenOtherInsIsPrimary;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldTriggerListId;
		protected NetsoftUSA.WebForms.OBComboBox TriggerListId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldSpecialProcedureId;
		protected NetsoftUSA.WebForms.OBComboBox SpecialProcedureId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldBenefitServiceId;
		protected NetsoftUSA.WebForms.OBComboBox BenefitServiceId;
		protected NetsoftUSA.WebForms.OBLabel OBLabel5;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDenial;
		protected NetsoftUSA.WebForms.OBCheckBox CallBeforeDeny;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCallBeforeDeny;
		protected NetsoftUSA.WebForms.OBCheckBox NormalDeny;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNormalDeny;
		protected NetsoftUSA.WebForms.OBCheckBox CallForLatePreCert;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCallForLatePreCert;
		protected NetsoftUSA.WebForms.OBCheckBox CallBeforeLetter;
		protected NetsoftUSA.WebForms.OBFieldLabel lbCallBeforeLetter;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanDenyNote;
		protected NetsoftUSA.WebForms.OBTextBox PlanDenyNote;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNotificationServicesRequiredUOM;
		protected NetsoftUSA.WebForms.OBComboBox NotificationServicesRequiredUOM;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldNotificationServicesRequired;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit NotificationServicesRequired;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNotificationServicesRequired;
		protected NetsoftUSA.WebForms.OBTextBox Penalty;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPenalty;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MaternicheckBeginDate;
		protected NetsoftUSA.WebForms.OBTextBox OBTextBox1;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNotes;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlNoteDetail;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridNotes;
		protected NetsoftUSA.WebForms.OBValidator vldNote;
		protected NetsoftUSA.WebForms.OBTextBox Note;
		protected NetsoftUSA.WebForms.OBFieldLabel lbNote;
		protected NetsoftUSA.WebForms.OBFieldLabel lbDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Description;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSaveNote;
		protected NetsoftUSA.InfragisticsWeb.WebButton butCancelNote;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPlanNoteTypeId;
		protected NetsoftUSA.WebForms.OBComboBox PlanNoteTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanNoteTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator1;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel3;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit DescriptionSearch;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternicheckBeginDate;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldPayorHEDISTypeId;
		protected NetsoftUSA.WebForms.OBComboBox PayorHEDISTypeId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPayorHEDISTypeId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator WebValidator2;
		protected NetsoftUSA.WebForms.OBFieldLabel OBFieldLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlCert;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected NetsoftUSA.WebForms.OBLabel OBLabel4;
		protected NetsoftUSA.WebForms.OBLabel OBLabel6;
		protected NetsoftUSA.WebForms.OBLabel OBLabel8;
		protected NetsoftUSA.WebForms.OBLabel OBLabel7;
		protected System.Web.UI.WebControls.Button butSave;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMaternichekBeginDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternichekRegistrationWeeks;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit MaternichekRegistrationWeeks;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMaternichekRegistrationWeeks;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternichekIncentiveId;
		protected NetsoftUSA.WebForms.OBComboBox MaternichekIncentiveId;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldMaternichekIncentiveId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternichekNote;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlMaterniChek;
		protected NetsoftUSA.WebForms.OBFieldLabel lbMaternichekBeginDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit MaternichekBeginDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit NoteEffectiveDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit NoteTerminateDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected AddressControl AddressControl;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.WebButton butSearchNote;
		protected NetsoftUSA.InfragisticsWeb.WebNumericEdit PlanId;
		protected NetsoftUSA.WebForms.OBFieldLabel lbPlanId;
		protected UserDefined UserDefined1;

		

		private void Page_Load(object sender, System.EventArgs e)
		{
			UserDefined1.ReloadContext("Plan", plan, true /*createcontrols*/); // short usage - always call
			if(!UserDefined1.HasFields())
				this.PageTab.GetTab("UserDefined").Visible = false;
			// Put user code to initialize the page here
			if (!this.IsPostBack)
				this.LoadData();			// Load data is the actual data loading method
			else
			{
				plan = (Plan)this.LoadObject(typeof(Plan));	// This would reload from cache
				planNote = (PlanNote)this.LoadObject(typeof(PlanNote));

				if (plan != null)
					this.AddressControl.Address = plan.Address;
			}
		}

		public override void NavigateAway(string targetURL)
		{
			this.CacheObject(typeof(PlanNote), null);
			base.NavigateAway (targetURL);
		}


		/// <summary>
		/// Redirect to current plan
		/// </summary>
		public static void Redirect()
		{
			BasePage.Redirect("PlanForm.aspx");
		}

		public static void Redirect(Plan plan)
		{
			BasePage.PushParam("Plan", plan);
			BasePage.Redirect("PlanForm.aspx");
		}

		public static void Redirect(int planId)
		{
			Plan plan = new Plan();
			if (!plan.Load(planId))
				throw new ActiveAdviceException("@CANTFINDRECORD@", "@PLAN@");
			Redirect(plan);
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			bool result = true;
			Plan plan = null;
			try
			{	// use any load method here

				string splanid = this.Request.QueryString["PlanID"];
				if (splanid != null)
				{
					plan = new Plan();
					if (!plan.Load(int.Parse(splanid)))
						throw new ActiveAdviceException("@CANTFINDRECORD@", "@PLAN@");
				}
				else
				{
					plan = this.GetParamOrGetFromCache("Plan", typeof(Plan)) as Plan;
					if (plan == null)
					{
						return NewPlan();
					}
				}
				//result = plan.Load(4);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//plan.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.Plan = plan;		// When you set the object to the property, controls are automatically populated
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				if (!this.ReadControls())
					return false;
				plan.Save(); // update or insert to db
				plan.SavePlanNotes();	// save all the plans out of transaction

				gridNotes.UpdatePKsFromCollection(plan.PlanNotes);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public Plan Plan
		{
			get { return plan; }
			set
			{
				plan = value;
				try
				{
					if (plan != null)
						this.AddressControl.Address = plan.Address;
					// add all object-to-control population code here
					this.UpdateFromObject(pnlDetails.Controls, plan);  // update controls for the given control/collection
					this.UpdateFromObject(pnlAddress.Controls, plan.Address);  // update controls for the given control/collection
					this.UpdateFromObject(pnlSpecs.Controls, plan);
					this.UpdateFromObject(pnlTriggers.Controls, plan);
					this.UpdateFromObject(pnlFlags.Controls, plan);
					this.UpdateFromObject(pnlDenial.Controls, plan);
					this.UpdateFromObject(pnlCert.Controls, plan);
					this.UpdateFromObject(pnlMaterniChek.Controls, plan);

					// plan notes
					plan.LoadPlanNotes(false);
					gridNotes.UpdateFromCollection(plan.PlanNotes);
					PlanNote = null;
					this.UpdateFromObject(pnlNotes.Controls, new PlanNote());
					UserDefined1.ReloadContext("Plan", plan, false /*createcontrols*/); // short usage - always call

				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(Plan), plan);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	// add all control-to-object population code here
				this.UpdateToObject(pnlDetails.Controls, plan);  // controls-to-object
				this.UpdateToObject(pnlAddress.Controls, plan.Address);  // update controls for the given control/collection
				this.UpdateToObject(pnlSpecs.Controls, plan);
				this.UpdateToObject(pnlTriggers.Controls, plan);
				this.UpdateToObject(pnlFlags.Controls, plan);
				this.UpdateToObject(pnlDenial.Controls, plan);
				this.UpdateToObject(pnlCert.Controls, plan);
				this.UpdateToObject(pnlMaterniChek.Controls, plan);
				UserDefined1.UserDefinedValue = plan.UserDefined;
				UserDefined1.ReadControls();
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
			gridNotes.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridNotes_ColumnsBoundToDataClass);
			gridNotes.ClickCellButton +=new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(gridNotes_ClickCellButton);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butSaveNote.Click += new System.EventHandler(this.butSaveNote_Click);
			this.butCancelNote.Click += new System.EventHandler(this.butCancelNote_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void butClearSharedCache_Click(object sender, System.EventArgs e)
		{
			NSGlobal.ClearCache();
		}

		private void butSearch_Click(object sender, System.EventArgs e)
		{
			PlanSearch.Redirect();
		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);

			//webTab.AddTab("@DETAILS@", "Details"); //, "MorgDetail");
			//webTab.AddTab("@SPECIFICATION@", "Specification");
			//webTab.AddTab("@PLANDENY@/@MATERNICHECK@", "PlanDeny"); //, "MorgDetail");
			//webTab.AddTab("@NOTES@", "Notes"); //, "MorgDetail");
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			if (!this.IsPopup)
				toolbar.AddButton("@SAVERECORD@", "Save");

			TBarButton tbbCancel = toolbar.AddButton("@CANCEL@", "Cancel", false).Item;
			if (this.IsPopup)
			{
				tbbCancel.Text = this.BaseMessages.CLOSE;
				tbbCancel.TargetURL = "javascript:window.close()";
			}
		}


		public override void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			base.OnToolbarButtonClick (toolbar, button);

			//button.Key == "Save"
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@PLAN@");
			}
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			if(tab.Key == "Details")
				toolbar.AddButton("@COMPONENTS@", "Components"); // created even for popup

			if (this.IsPopup)
				return;

			switch (tab.Key)
			{
				case "Details":
					toolbar.AddButton("@CONTACTS@", "Contacts");
					toolbar.AddButton("@ADDNEWRECORD@", "AddNew");
					toolbar.AddButton("@CLONE@", "Clone");
					//toolbar.AddButton("@COMPONENTS@", "Components");
					//toolbar.AddButton("View", "View");
					break;
				case "Specification":
					//toolbar.AddButton("@COPYCHILDORG@", "CopyAsChildOrg");
					break;
				case "PlanDeny":
					//toolbar.AddButton("@COPYCHILDORG@", "CopyAsChildOrg");
					break;
				case "Notes":
					//toolbar.AddButton("@COPYCHILDORG@", "CopyAsChildOrg");
					toolbar.AddButton(Messages.PlanMessages.MessageIDs.ADD, "AddNewNote", "Notes", false, false);
					break;
			}
		}

		public void OnToolbarButtonClick_Contacts(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			ContactSearch.Redirect(this.plan);
		}

		public void OnToolbarButtonClick_View(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			this.ViewOnlyMode = !this.ViewOnlyMode;
		}

		public void OnToolbarButtonClick_AddNew(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewPlan();
		}

		public void OnToolbarButtonClick_Clone(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (this.ReadControls())
			{
				try
				{
					this.Plan = plan.CreateCopyOfPlan();
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		public void OnToolbarButtonClick_Components(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			PlanComponents.Redirect(plan);
		}

		public void OnToolbarButtonClick_AddNewNote(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewPlanNote();
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			butSearchNote.Attributes["OnClick"] = String.Format( "FindGridCell('{0}', '{1}'); return false;", gridNotes.ID, DescriptionSearch.ID );
			this.RenderClientFunctions(pnlDetails.Controls, plan, "OnCalcDetails");
			this.RenderClientFunctions(pnlNoteDetail.Controls, planNote, "OnCalcPlanNote");

			this.SetPageTabToolbarItemEnabled("Components", !plan.IsNew);
			this.SetPageTabToolbarItemEnabled("Clone", !plan.IsNew);
			this.SetPageTabToolbarItemEnabled("Contacts", !plan.IsNew);

			butSaveNote.Visible = !this.IsPopup;

			//this.PageSubMenuVisible = !this.IsPopup;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PlanNote PlanNote
		{
			get { return planNote; }
			set
			{
				planNote = value;
				try
				{
					this.pnlNoteDetail.Visible = this.planNote != null;
					this.pnlNotes.Visible = this.planNote == null;
					this.UpdateFromObject(pnlNoteDetail.Controls, planNote);  // update controls for the given control collection
					// other object-to-control methods if any
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PlanNote), planNote);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForPlanNote()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlNoteDetail.Controls, planNote);	// controls-to-object
				// other control-to-object methods if any
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPlan()
		{
			bool result = true;
			Plan plan = new Plan(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.Plan = plan;
			return result;
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewPlanNote()
		{
			bool result = true;
			PlanNote planNote = new PlanNote(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
				//planNote.New(/* parameters */);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.PlanNote = planNote;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForPlanNote()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForPlanNote())
					return false;
				if (planNote.ParentPlanNoteCollection == null)
					plan.PlanNotes.Add(planNote);
				PlanNote = null;
				gridNotes.UpdateFromCollection(plan.PlanNotes);
				return true;		// kept in child collection
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
		}

		private void butSaveNote_Click(object sender, System.EventArgs e)
		{
			SaveDataForPlanNote();
		}

		private void butCancelNote_Click(object sender, System.EventArgs e)
		{
			PlanNote = null;
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.plan);
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();
			
			if(!this.IsPopup)
				this.CheckForDirty(this.plan, this.plan.Address, this.plan.UserDefined, this.plan.PlanNotes);
		}

		private void gridNotes_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			gridNotes.AddButtonColumn("Edit", "@DESCRIPTION@", 0);// this.IsPopup ? "@VIEW@" : "@EDIT@", 0);
		}

		private void gridNotes_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			if (e.Cell.Key == "Edit")
			{
				int planIndex = gridNotes.GetColIndexFromCellEvent(e);
				if (planIndex < 0)
					return;
				PlanNote = plan.PlanNotes[planIndex];
			}
		}

	}
}
