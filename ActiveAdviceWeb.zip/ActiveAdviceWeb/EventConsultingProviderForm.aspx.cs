using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// This page manages the consulting providers for an event.
	/// </summary>
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]		// Define the message class for this module
	[MainDataClass("EventConsultingProvider,DataLayer")]					// Define the main data class for this page, so that you can directly open it from the page context menu
	[BackPage(typeof(EventForm))]
	[SelectedMainMenuItem("MPatient")]
	[SelectedMenuItem("Summary")]
	[PageTitle("@EVENTPAGETITLE@")]
	public class EventConsultingProviderForm : PatientBasePage
	{
		private EventConsultingProvider eventConsultingProvider;
		private EventConsultingProviderCollection eventConsultingProviders;

		private Patient patient;
		private Problem problem;
		private PatientCoverage patientCoverage;
		private Event eventObj;
		// Use Add Page Property addin menu to create a property and 
		// relevant access methods for a specific type of data class.
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.WebForms.OBLabel OBLabel2;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlConsultingProviders;
		protected NetsoftUSA.InfragisticsWeb.WebGrid gridConsultingProviders;
		protected NetsoftUSA.WebForms.OBButton butAddNewConsultingPr;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlConsultingProvider;
		protected NetsoftUSA.WebForms.OBLabel OBLabel1;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldRoleID;
		protected NetsoftUSA.InfragisticsWeb.WebCombo RoleID;
		protected NetsoftUSA.WebForms.OBFieldLabel lbRoleID;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldServiceDate;
		protected NetsoftUSA.InfragisticsWeb.WebDateTimeEdit ServiceDate;
		protected NetsoftUSA.WebForms.OBFieldLabel lbServiceDate;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlPCPSelect;
		protected NetsoftUSA.WebForms.OBButton butSaveConsultingProvider;
		protected NetsoftUSA.WebForms.OBButton butCancelConsultingProvider;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlUserDefined;
		protected UserDefined UserDefined1;
		protected NetsoftUSA.WebForms.OBLabel OBLabel3;
		protected System.Web.UI.HtmlControls.HtmlTable OuterMostTable;
		protected System.Web.UI.HtmlControls.HtmlTable OuterTable;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlButton;
		protected ProviderSelect PCPSelect;

		private void Page_Load(object sender, System.EventArgs e)
		{
			UserDefined1.ReloadContext("EventConsultingProvider",eventConsultingProvider,true);
			if(!UserDefined1.HasFields())
				this.pnlUserDefined.Visible = false;
			// Provider select
			this.PCPSelect.RebindControls(typeof(EventConsultingProvider), "@PCP@",
				ProviderSearcherType.Provider, null,
				"ProviderID", "ProviderLocationID", "ProviderSpecialtyID", "ProviderLocationNetworkID", "ProviderNetworkStatusID", "ServiceDate");

			// Put user code to initialize the page here
			if (!this.IsPostBack)
			{
				this.LoadData();			// Use load data method for data entry forms
			}
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));  // load object from cache
				problem = (Problem)this.LoadObject(typeof(Problem));  // load object from cache
				patientCoverage = (PatientCoverage)this.LoadObject(typeof(PatientCoverage));  // load object from cache
				eventObj = (Event)this.LoadObject(typeof(Event));  // load object from cache

				eventConsultingProviders = eventObj.EventConsultingProviders;
				eventConsultingProvider = (EventConsultingProvider)this.LoadObject(typeof(EventConsultingProvider));  // load object from cache
			}
			
			
		}

		public override void NavigateAway(string targetURL)
		{
			eventObj.EventConsultingProviders = null;
			this.CacheObject(typeof(EventConsultingProvider), null);
			base.NavigateAway ();
		}


		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadData()
		{
			try
			{	
				PageTab.SelectedTabKey = this.TargetTabKey;		// navigate to target tab.

				// use any load method here
				// or pull from the parameter passed to this page via PushParam
				patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
				if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
				// get the passed patient subscriber coverage (link to patient)
				patientCoverage = GetParamOrGetFromCache("PatientCoverage", typeof(PatientCoverage)) as PatientCoverage;
				if (patientCoverage == null)	
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected patient-subscriber-coverage");
				problem = GetParamOrGetFromCache("Problem", typeof(Problem)) as Problem;
				//if (problem == null)	
				//	throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a selected problem");					

				// if event was not passed, create a new one
				eventObj = this.GetParamOrGetFromCache("Event", typeof(Event)) as Event;
				if (eventObj == null)
				{
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of an event");
				}
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
			finally
			{
				//eventObj.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.CacheObject(typeof(Patient), patient);
			this.CacheObject(typeof(PatientCoverage), patientCoverage);
			this.CacheObject(typeof(Problem), problem);
			this.CacheObject(typeof(Event), eventObj);
			return LoadDataForEventConsultingProviders();
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient, PatientCoverage patCov, Problem problem, Event eventObj)
		{
			if (patient == null || patCov == null)
				throw new ActiveAdviceException("You can open outcomes only in the context of patient and coverage and event/referral/cms"); 

			BasePage.PushCurrentCallingPage();
			
			BasePage.PushParam("Patient", patient);
			BasePage.PushParam("PatCov", patCov);
			BasePage.PushParam("Problem", problem);
			BasePage.PushParam("Event", eventObj);
			BasePage.Redirect(typeof(EventConsultingProviderForm));
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient, this.patientCoverage, this.problem, this.eventObj);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);

			gridConsultingProviders.ColumnsBoundToDataClass +=new NetsoftUSA.InfragisticsWeb.WebGrid.ColumnsBoundToDataClassHandler(gridConsultingProviders_ColumnsBoundToDataClass);
			gridConsultingProviders.ClickCellButton +=new ClickCellButtonEventHandler(gridConsultingProviders_ClickCellButton);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.butAddNewConsultingPr.Click += new System.EventHandler(this.butAddNewConsultingPr_Click);
			this.butSaveConsultingProvider.Click += new System.EventHandler(this.butSaveConsultingProvider_Click);
			this.butCancelConsultingProvider.Click += new System.EventHandler(this.butCancelConsultingProvider_Click);
			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		// Tab toolbar
		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			// Menu items to be displayed on specific tabs
			if (tab.Key == "CONSPR_ConsultingPr")
			{
				this.AddClinicalSummaryButton(toolbar);
			}

			// Menu items to be displayed on all tabs
		}

		// Page bottom toolbar
		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddPreset(ToolbarButtons.SaveCancel);
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EventConsultingProviderCollection EventConsultingProviders
		{
			get { return eventConsultingProviders; }
			set
			{
				eventConsultingProviders = value;
				try
				{
					gridConsultingProviders.UpdateFromCollection(eventConsultingProviders);  // update given grid from the collection
					// other object-to-control methods if any
					EventConsultingProvider = null;
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				// this.CacheObject(typeof(EventConsultingProviderCollection), eventConsultingProviders);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from Page_Load or anytime you want to load data
		/// </summary>
		public bool LoadDataForEventConsultingProviders()
		{
			bool result = true;
			EventConsultingProviderCollection eventConsultingProviders = null;
			try
			{	// use any load method here
				eventObj.LoadEventConsultingProviders(false);
				eventConsultingProviders = eventObj.EventConsultingProviders;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				//eventConsultingProviders.SqlData.CloseConnection();	// if the object is cached and read method is executed, we need this connection closed!
			}
			this.EventConsultingProviders = eventConsultingProviders;
			return result;
		}

		private void butAddNewConsultingPr_Click(object sender, System.EventArgs e)
		{
			NewEventConsultingProvider();
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public EventConsultingProvider EventConsultingProvider
		{
			get { return eventConsultingProvider; }
			set
			{
				eventConsultingProvider = value;
				try
				{
					bool vis = (value != null);
					pnlConsultingProvider.Visible = vis;
					pnlPCPSelect.Visible = vis;
					//if(UserDefined1.HasFields())
					//	pnlUserDefined.Visible = vis;
					pnlConsultingProviders.Visible = !vis;
					pnlButton.Visible = vis;
					//butSaveConsultingProvider.Visible = vis;
					//butCancelConsultingProvider.Visible = vis;

					this.UpdateFromObject(pnlPCPSelect.Controls, eventConsultingProvider);  // update controls for the given control collection
					this.UpdateFromObject(pnlConsultingProvider.Controls, eventConsultingProvider);  // update controls for the given control collection
					// other object-to-control methods if any
					UserDefined1.ReloadContext("EventConsultingProvider",eventConsultingProvider,false);
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(EventConsultingProvider), eventConsultingProvider);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControlsForEventConsultingProvider()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(pnlPCPSelect.Controls, eventConsultingProvider);	// controls-to-object
				this.UpdateToObject(pnlConsultingProvider.Controls, eventConsultingProvider);	// controls-to-object
				// other control-to-object methods if any

				UserDefined1.UserDefinedValue = eventConsultingProvider.UserDefined;
				UserDefined1.ReadControls();
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewEventConsultingProvider()
		{
			bool result = true;
			EventConsultingProvider eventConsultingProvider = new EventConsultingProvider(true); // use a parameterized constructor which also initializes the data object
			try
			{	// or use an initialization method here
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			finally
			{
				// finalization code
			}
			this.EventConsultingProvider = eventConsultingProvider;
			return result;
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveDataForEventConsultingProvider()
		{
			try
			{	// data from controls to object
				if (!this.ReadControlsForEventConsultingProvider())
					return false;
				if (this.eventConsultingProvider.ParentEventConsultingProviderCollection == null)
					this.eventConsultingProviders.Add(eventConsultingProvider);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void butCancelConsultingProvider_Click(object sender, System.EventArgs e)
		{
			this.EventConsultingProvider = null;
		}

		private void butSaveConsultingProvider_Click(object sender, System.EventArgs e)
		{
			if (SaveDataForEventConsultingProvider())
				this.EventConsultingProviders = this.EventConsultingProviders;
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SaveData())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "@CONSULTINGPROVIDERS@");
			}
		}

		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SaveData()
		{
			try
			{	// data from controls to object
				eventObj.SaveEventConsultingProviders();
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);
				return false;
			}
			return true;
		}

		private void gridConsultingProviders_ColumnsBoundToDataClass(object sender, EventArgs e)
		{
			gridConsultingProviders.AddButtonColumn("Edit", "@EDIT@", 0).Width = 70;
		}

		private void gridConsultingProviders_ClickCellButton(object sender, CellEventArgs e)
		{
			int index = gridConsultingProviders.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;

			switch (e.Cell.Key)
			{
				case "Edit":
				{
					this.EventConsultingProvider = this.eventConsultingProviders[index];
					break;
				}
			}
		}

		public override void OnSetDirty()
		{
			base.OnSetDirty ();

			this.CheckForDirty(this.eventConsultingProviders);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			SetERCTabVisibilities();
		}


	}
}
