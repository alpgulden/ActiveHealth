using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using NetsoftUSA.Security;
using NetsoftUSA.InfragisticsWeb;
using ActiveAdvice.DataLayer;
using ActiveAdvice.Messages;
using Infragistics.WebUI.UltraWebGrid;
using System.Diagnostics;
using System.Security.Permissions;

namespace ActiveAdvice.Web
{
	/// <summary>
	/// Summary description for AllergiesSummaryForm.
	/// </summary>
	
	//Set Functional Access by roles asssigned to the user	
	[PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ADMIN),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.FULL),
	PrincipalPermission(SecurityAction.Demand,Role=AASecurityHelper.ALLERGIES)]
	
	[MainLanguageClass("ActiveAdvice.Messages.PatientMessages,DataLayer")]	
	[MainDataClass("PatientAllergy,DataLayer")]	
	[SelectedMainMenuItem("MPatient")]	
	[SelectedMenuItem("Allergies")]
	[PageTitle("@ALLERGYPAGETITLE@")]
	public class AllergySummaryForm : PatientBasePage
	{
		private PatientAllergy patientAllergy;
		private PatientAllergyCollection patientAllergies;
		protected NetsoftUSA.InfragisticsWeb.WebTab PageTab;
		protected NetsoftUSA.InfragisticsWeb.WebToolbar PageToolbar;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlGridHolder;
		protected NetsoftUSA.InfragisticsWeb.WebGrid grid;
		protected NetsoftUSA.InfragisticsWeb.ContentPanel pnlDetails;
		protected NetsoftUSA.WebForms.OBFieldLabel lbAllergyDescription;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit AllergyDescription;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldAllergyDescription;
		protected NetsoftUSA.WebForms.OBFieldLabel lbReaction;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit Reaction;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldReaction;
		protected NetsoftUSA.WebForms.OBFieldLabel lbHowLong;
		protected NetsoftUSA.InfragisticsWeb.WebTextEdit HowLong;
		protected NetsoftUSA.InfragisticsWeb.WebValidator vldHowLong;
		protected NetsoftUSA.InfragisticsWeb.WebButton btnDelete;
		private Patient patient;
		
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			this.grid.ClickCellButton += new Infragistics.WebUI.UltraWebGrid.ClickCellButtonEventHandler(this.grid_ClickCellButton);
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);

			this.ValidationsOnlyInSummary = true;
			this.Load += new System.EventHandler(this.Page_Load);
			
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.PrintablePage = true;
			this.ValidationsOnlyInSummary = true;

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
				LoadData();
			else
			{
				patient = (Patient)this.LoadObject(typeof(Patient));
				patientAllergies = (PatientAllergyCollection)this.LoadObject(typeof(PatientAllergyCollection));  // load object from cache
				patientAllergy = (PatientAllergy)this.LoadObject(typeof(PatientAllergy));  // load object from cache
			}
		}

		public void LoadData()
		{
			patient = GetParamOrGetFromCache("Patient", typeof(Patient)) as Patient;
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must hit this page in the context of a patient");
			this.CacheObject(typeof(Patient), patient);
			if (LoadPatientAllergies())
			{
				if(PatientAllergies.Count > 0)
				{
					PatientAllergy = PatientAllergies[0];
					grid.SelectedRowIndex = 0;
				}
				else
					NewData();
			}
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientAllergyCollection PatientAllergies
		{
			get { return patientAllergies; }
			set
			{
				patientAllergies = value;
				try
				{
					grid.UpdateFromCollection(patientAllergies);  // update given grid from the collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				// active the caching if the object is not too big and you need this object in the next post-back
				this.CacheObject(typeof(PatientAllergyCollection), patientAllergies);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Call this method from anytime you want to load the collection with search results
		/// </summary>
		public bool LoadPatientAllergies()
		{
			bool result = true;
			PatientAllergyCollection patientAllergies = new PatientAllergyCollection();
			try
			{
				this.patient.LoadPatientAllergies(false);
				patientAllergies = this.patient.PatientAllergies;
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			
			this.PatientAllergies = patientAllergies;
			return result;
		}
		
		/// <summary>
		/// Call this method when you want to retrieve data from controls and save them to table.
		/// </summary>
		public bool SavePatientAllergies()
		{
			if (ReadControls())
			{
				if (PatientAllergy.IsNew)
				{	// New Allergy - Adding
					PatientAllergy.PatientId = patient.PatientId; 
					PatientAllergies.Add(PatientAllergy);
					PatientAllergy = PatientAllergy;
					grid.UpdateFromCollection(PatientAllergies);
					grid.SelectedRowIndex = grid.Rows.Count - 1;
				}
				else
				{	//Existing Allergy - Updating
					PatientAllergy.MarkDirty();
					PatientAllergy = PatientAllergy;
					grid.UpdateFromCollection(this.PatientAllergies);
				}
				
				try
				{	// data from controls to object
					patientAllergies.Save(); // update or insert to db 
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
					return false;
				}
				return true;
			}
			return false;
		}

		/// <summary>
		/// Gets/Sets the data object for the page.  When set, it also caches the object and updates the controls
		/// </summary>
		public PatientAllergy PatientAllergy
		{
			get { return patientAllergy; }
			set
			{
				patientAllergy = value;
				try
				{
					this.UpdateFromObject(this.pnlDetails.Controls, patientAllergy);  // update controls for the given control collection
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);  // notify the page about the error
				}
				this.CacheObject(typeof(PatientAllergy), patientAllergy);  // cache object using the caching method declared on the page
			}
		}

		/// <summary>
		/// Reads control values into the data object and validates them.  Returns false if there's any problem
		/// </summary>
		public bool ReadControls()
		{
			try
			{	//customize this method for this specific page
				this.UpdateToObject(this.pnlDetails.Controls, patientAllergy);	// controls-to-object
				return this.IsValid;	// Return validation result
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				return false;
			}
		}

		/// <summary>
		/// Call this method whenever you need to create a new data object and also populate the controls for it
		/// </summary>
		public bool NewData()
		{
			bool result = true;
			PatientAllergy patientAllergy = null;
			try
			{	// or use an initialization method here
				patientAllergy = new PatientAllergy(true);
			}
			catch(Exception ex)
			{
				this.RaisePageException(ex);	// notify the page about the error
				result = false;
			}
			this.pnlDetails.Visible = true;
			this.PatientAllergy = patientAllergy;
			return result;
		}

		/// <summary>
		/// Passes the given object to the redirected page.
		/// </summary>
		public static void Redirect(Patient patient)
		{
			BasePage.PushCurrentCallingPage();
			BasePage.PushParam("Patient", patient);
			BasePage.Redirect("AllergySummaryForm.aspx");

		}

		public override void PopulateTabItems(NetsoftUSA.InfragisticsWeb.WebTab webTab)
		{
			base.PopulateTabItems (webTab);
		}

		public override void PopulateToolbarItems(NetsoftUSA.InfragisticsWeb.WebToolbar toolbar)
		{
			base.PopulateToolbarItems (toolbar);

			toolbar.AddButton("@SAVERECORD@", "Save", true);
			toolbar.AddButton("@CANCEL@", "Cancel", false);
		}
		
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e); 
			
			//AddNewAllergy control should not be visible in PrintPreviewMode
			this.SetPageTabToolbarItemVisible("AddNewAllergy", !this.PrintPreviewMode);
			this.btnDelete.Visible = this.grid.Rows.Count > 0 && !this.patientAllergy.IsNew && !this.PrintPreviewMode;
			this.btnDelete.OnClickScript = "if (confirm('Are you sure you want to delete this item?') != true) return false;";
		}

		public override void RenderPageSummary(PageSummary pageSummary)
		{
			base.RenderPageSummary (pageSummary);
			pageSummary.RenderObjects(this.patient);
		}

		public override void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			base.PopulateToolbarItems (toolbar, tab);

			switch (tab.Key)
			{
				case "Allergies":
					toolbar.AddButton("@ADDALLERGY@", "AddNewAllergy");
					break;
			}
		}

		public void OnToolbarButtonClick_AddNewAllergy(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			NewData();
			grid.SelectedRowIndex = -1;
		}

		private void grid_ClickCellButton(object sender, Infragistics.WebUI.UltraWebGrid.CellEventArgs e)
		{
			int index = grid.GetColIndexFromCellEvent(e);
			if (index < 0)
				return;
			
			if (e.Cell.Key == "Edit")
			{
				this.pnlDetails.Visible = true;
				PatientAllergy = PatientAllergies[index];
			}
		}

		public void OnToolbarButtonClick_Save(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			if (SavePatientAllergies())
			{
				this.SetPageMessage("@SAVEDMSG@", EnumPageMessageType.Info, "Allergies "); 
				grid.UpdateFromCollection(PatientAllergies);
			}
		}

		private void btnDelete_Click(object sender, System.EventArgs e)
		{
			PatientAllergy.MarkDel();
			grid.UpdateFromCollection(PatientAllergies);
			grid.SelectedRowIndex = -1;
			this.pnlDetails.Visible = false;
		}
	}
}
