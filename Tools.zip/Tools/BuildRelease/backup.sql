use master
go
BACKUP DATABASE ActiveAdviceDev TO DISK = 'RELEASEBAK'

