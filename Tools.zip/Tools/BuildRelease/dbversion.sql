--
-- Update the database version information
--
update SystemControlValues set Databaseversion = 'RELEASENAME', DatabaseversionDate = getdate()
go
