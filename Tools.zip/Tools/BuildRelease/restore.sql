--
-- Restore database
--
if exists(select * from master.dbo.sysdatabases where name = 'RELEASENAME')
    drop database RELEASENAME
go

RESTORE DATABASE RELEASENAME
   FROM DISK = 'RELEASEFILE'
   WITH MOVE 'ActiveAdvice_Data' TO 'd:\MSSQL\data\RELEASENAME_Data.MDF',
        MOVE 'ActiveAdvice_Log'  TO 'd:\MSSQL\data\RELEASENAME_Log.MDF'

go

-- Okay now use this database. We need to
-- remove the 'aa_user' in the db and 
-- grant access to the 'AA_user' 

use RELEASENAME
go
exec sp_revokedbaccess 'aa_user'
go
exec sp_grantdbaccess 'AA_user'
go
