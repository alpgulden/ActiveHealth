using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EDIControl]
	/// </summary>
	[SPLoad("usp_LoadEDIControl")]
	[SPInsert("usp_InsertEDIControl")]
	[SPUpdate("usp_UpdateEDIControl")]
	[SPAutoGen("usp_SelectAllEDIControlByActive","SelectAllByGivenArgs.sptpl","active")]
	[TableMapping("EDIControl","eDIControlID")]
	public class EDIControl : BaseDataClass
	{
		[NonSerialized]
		private EDIControlCollection parentEDIControlCollection;
		[ColumnMapping("EDIControlID",(int)0)]
		private int eDIControlID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("LogPath")]
		private string logPath;
		[ColumnMapping("UMOIdentification")]
		private string uMOIdentification;
		[ColumnMapping("UMOIdentificationQualifierID",StereoType=DataStereoType.FK)]
		private int uMOIdentificationQualifierID;
		[ColumnMapping("UMO_Code")]
		private string umoCode;
		[ColumnMapping("UMO_Name")]
		private string umoName;
		[ColumnMapping("ContactName")]
		private string contactName;
		[ColumnMapping("UMOContactNumberQualifier1ID",StereoType=DataStereoType.FK)]
		private int uMOContactNumberQualifier1ID;
		[ColumnMapping("ContactPhone_1")]
		private string contactphone1;
		[ColumnMapping("UMOContactNumberQualifier2ID",StereoType=DataStereoType.FK)]
		private int uMOContactNumberQualifier2ID;
		[ColumnMapping("ContactPhone_2")]
		private string contactphone2;
		[ColumnMapping("UMOContactNumberQualifier3ID",StereoType=DataStereoType.FK)]
		private int uMOContactNumberQualifier3ID;
		[ColumnMapping("ContactPhone_3")]
		private string contactphone3;
	
		public EDIControl()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EDIControlID
		{
			get { return this.eDIControlID; }
			set { this.eDIControlID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=200)]
		public string LogPath
		{
			get { return this.logPath; }
			set { this.logPath = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=15)]
		public string UMOIdentification
		{
			get { return this.uMOIdentification; }
			set { this.uMOIdentification = value; }
		}

//		[FieldDescription("type of identifier in UMOIdentification")]
		[FieldValuesMember("LookupOf_UMOIdentificationQualifierID", "UMOIdentificationQualifierID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0, IsRequired=true)]
		public int UMOIdentificationQualifierID
		{
			get { return this.uMOIdentificationQualifierID; }
			set { this.uMOIdentificationQualifierID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=80)]
		public string UmoCode
		{
			get { return this.umoCode; }
			set { this.umoCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string UmoName
		{
			get { return this.umoName; }
			set { this.umoName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string ContactName
		{
			get { return this.contactName; }
			set { this.contactName = value; }
		}

//		[FieldDescription("type of contact # (ie. phone, fax or email)")]
		[FieldValuesMember("LookupOf_UMOContactNumberQualifierID", "UMOContactNumberQualifierID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int UMOContactNumberQualifier1ID
		{
			get { return this.uMOContactNumberQualifier1ID; }
			set { this.uMOContactNumberQualifier1ID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Contactphone1
		{
			get { return this.contactphone1; }
			set { this.contactphone1 = value; }
		}

//		[FieldDescription("type of contact # (i.e.phone, fax, email,e tc.)")]
		[FieldValuesMember("LookupOf_UMOContactNumberQualifierID", "UMOContactNumberQualifierID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int UMOContactNumberQualifier2ID
		{
			get { return this.uMOContactNumberQualifier2ID; }
			set { this.uMOContactNumberQualifier2ID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Contactphone2
		{
			get { return this.contactphone2; }
			set { this.contactphone2 = value; }
		}

//		[FieldDescription("type of contact # (i.e. phone, fax, email, etc)")]
		[FieldValuesMember("LookupOf_UMOContactNumberQualifierID", "UMOContactNumberQualifierID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int UMOContactNumberQualifier3ID
		{
			get { return this.uMOContactNumberQualifier3ID; }
			set { this.uMOContactNumberQualifier3ID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Contactphone3
		{
			get { return this.contactphone3; }
			set { this.contactphone3 = value; }
		}

//		[FieldDescription("=1, then we can use this value, it's valid")]
		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		protected UMOContactNumberQualifierCollection umocnqc = null;
		public UMOContactNumberQualifierCollection LookupOf_UMOContactNumberQualifierID
		{
			get
			{
				if (null == umocnqc)
				{
					umocnqc = new UMOContactNumberQualifierCollection();
					umocnqc.SelectAllUMOContactNumberQualifiersByActive(-1, true);
				}
				return umocnqc;
			}
		}

		/// <summary>
		/// Parent EDIControlCollection that contains this element
		/// </summary>
		public EDIControlCollection ParentEDIControlCollection
		{
			get
			{
				return this.parentEDIControlCollection;
			}
			set
			{
				this.parentEDIControlCollection = value; // parent is set when added to a collection
			}
		}

		public UMOIdentificationQualifierCollection LookupOf_UMOIdentificationQualifierID
		{
			get 
			{
				UMOIdentificationQualifierCollection umoc = new UMOIdentificationQualifierCollection();
				umoc.SelectAllUMOIdentificationQualifiersByActive(-1, true);
				return umoc;
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool SelectAllEDIControlByActive(bool active)
		{
			return SqlData.SPExecReadObj("usp_SelectAllEDIControlByActive", this, false, new object[] { active });
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eDIControlID)
		{
			return base.Load(eDIControlID);
		}
	}

	/// <summary>
	/// Strongly typed collection of EDIControl objects
	/// </summary>
	[ElementType(typeof(EDIControl))]
	public class EDIControlCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_EDIControlID;
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SelectAllEDIControlByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllEDIControlByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Hashtable based index on eDIControlID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_EDIControlID
		{
			get
			{
				if (this.indexBy_EDIControlID == null)
					this.indexBy_EDIControlID = new CollectionIndexer(this, new string[] { "eDIControlID" }, true);
				return this.indexBy_EDIControlID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on eDIControlID fields returns the object.  Uses the IndexBy_EDIControlID indexer.
		/// </summary>
		public EDIControl FindBy(int eDIControlID)
		{
			return (EDIControl)this.IndexBy_EDIControlID.GetObject(eDIControlID);
		}
	}
}
