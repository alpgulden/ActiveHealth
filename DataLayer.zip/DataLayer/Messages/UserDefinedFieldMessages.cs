using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Summary description for UserDefinedFieldMessages.
	/// </summary>
	public class UserDefinedFieldMessages: BaseMessages
	{
		
		private static UserDefinedFieldMessages messageIDs;

		public UserDefinedFieldMessages(): base()
		{
				
		}

		public UserDefinedFieldMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public static UserDefinedFieldMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)  
					messageIDs = new UserDefinedFieldMessages();
				return messageIDs;
			}
		}

		
		public string SELECTENTITY;
		public string USERDEFINEDFIELD;
		public string USERDEFINEDFIELDS;
		public string LABEL;
		public string USERDEFINEDFIELDNUMBER;
		public string REQUIRED;
		public string PRESENTATIONTYPE;
		public string USERDEFINEDENTITYID;
		public string USERDEFINEDLISTID;
		public string MASKEDEDITVALUE;
		public string USERDEFINEDENTITYNAME;
		public string ADDUSERDEFINEDFIELD;
		public string FIELDNUMBEROUTOFRANGE;
		public string FIELDNUMBERDUPLICATED;
		public string ADDLISTITEM;
		public string SAVELISTITEM;
		public string EDITLIST;
		public string LISTNAME;
		public string VALUE;
		public string DELETELISTITEM;
		public string USERDEFINEDFIELDFORMTITLE;
		public string USERDEFINEDLISTTITLE;
	}
}
