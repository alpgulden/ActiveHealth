using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	public class SecurityMessages : BaseMessages
	{	
		private static SecurityMessages messageIDs;

		public SecurityMessages() : base()
		{
		}

		public new static SecurityMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new SecurityMessages();
				return messageIDs;
			}
		}

		public SecurityMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string GROUP;
		public string GROUPS;
		public string GROUPSMENU;
		public string NEWGROUP;
		public string USER;
		public string USERID;
		public string LOGINNAME;
		public string LOCATION;
		public string USERSMENU;
		public string NEWUSER;
		public string PHONE;
		public string EXTENTION;
		public string STATUS;
		public string FAILEDLOGINS;
		public string MEMBERS;
		public string FUNCTIONALACCESS;
		public string DATAACCESS;
		public string ADDGROUP;
		public string ADDUSER;
		public string SELECT;
		public string GROUPNAME;
		public string RESETUSER;
		public string RESETUSERHEADER;
		public string RESETUSERBUTTON;
		public string NEWPASSWORD;
		public string OLDPASSWORD;
		public string FUCTIONALACCESS;
		public string BUILDINROLES;
		public string DATALEVEL;
		public string CODETYPE;
		public string CODETO;
		public string CODEFROM;
		public string GROUPID;
		public string PREVIEW;
		public string NOTEQUAL;
		public string DELETEUSER;
		public string DELETEGROUP;
		public string FILTERBY;
		public string FILTEREDBY;
		public string MEMBERSUSER;
		public string MEMBERSGROUP;
		public string AVAILABLEUSERS;
		public string AVAILABLEGROUPS;
		public string CLEARFILTER;
		public string ALL;
		public string INACTIVEUSERMSG;
		public string INACTIVATE;
		public string FALEVELNAME;
		public string FULLACCESS;
		public string READONLYCOL;
		public string ASSIGNED;
		public string PX;
		public string DX;
		public string LOGINREGEXERROR;
		public string GROUPREGEXERROR;
		public string ORGNAME;
		public string DELETEDEPENDENCYMSG;
		public string ACTIVEUSERMSG;
		public string ACTIVATE;
		public string SAVEUSERDEPENDENCYMSG;
		public string SAVEGROUPDEPENDENCYMSG;
		public string SECURITYFAFORM;
		public string SECURITYUSER;
		public string SECURITYGROUP;
		public string SECURITYDAFORM;		
	}
}
