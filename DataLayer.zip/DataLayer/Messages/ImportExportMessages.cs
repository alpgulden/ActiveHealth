using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	public class ImportExportMessages : BaseMessages
	{	
		private static ImportExportMessages messageIDs;

		public ImportExportMessages() : base()
		{
		}

		public new static ImportExportMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new ImportExportMessages();
				return messageIDs;
			}
		}

		public ImportExportMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string ELIGIBILITY;
		public string SCORINGLOAD;
		//public string PROVIDER;		// in base class
		public string MEMBERLOG;
		public string TASKLIST;
		public string AUTHORIZATION;
		public string JOBID;
		public string SCHEDULETYPE;
		public string SCHEDULESTATUS;
		public string LABEL;
		public string FILENAME;
		public string STARTDATE;
		public string UPDATE;
		public string CEEXPORT;
		public string ASSIGNED;
		public string ORGNAME;
		public string SCHEDULETYPEID;
		public string SCHEDULESTATUSID;
		public string FILENOTFOUND;
		public string REFERRALS;
		public string ENDDATE;
		public string EVENTS;
		public string GENERATEENVELOPES;
		public string QUEUEIMPORT;
		public string QUEUEEXPORT;
		public string AUTHREQUIREDEVENTREF;
		public string ALTMORGID;
		public string MORGID;
		public string ORGID;
		public string SAVE;
		public string MORGLEVELID;
		public string SORGLEVELID;
		public string ORGLEVELID;
		public string ORGANIZATIONID;

		// UMO (EDI) messages
		public string UMONAME;
		public string UMOIDENTIFICATIONQUALIFIERID;
        public string UMOIDENTIFICATION;
		public string UMOCODE;
		public string LOGPATH;
		public string CONTACTPHONE1;
		public string CONTACTPHONE2;
		public string CONTACTPHONE3;
		public string UMOCONTACTNUMBERQUALIFIER1ID;
		public string UMOCONTACTNUMBERQUALIFIER2ID;
		public string UMOCONTACTNUMBERQUALIFIER3ID;
		public string CONTACTNAME;
		public string EDIREQUESTER;
		public string EDIRECEIVER;
		public string EDICONTROLID;
		public string REQUESTERNAME;
		public string MAPROVIDERID;
		public string OUTBOXPATH;
		public string CONTACTTYPE1ID;
		public string CONTACTTYPE2ID;
		public string CONTACTTYPE3ID;
		public string IDQUALIFIERID;
		public string IDCODE;
		public string EDIREQUESTORDETAILID;

		public string GENERATEEMPLOYEELETTER;
		public string EMPLOYERLETTERID;
		public string ELAPSEDTIME;
		public string TOTALRECORDS;
		public string TOTALERRORS;
		public string NUMBERNEWPATIENTS;
		public string NUMBERNEWPROBLEMS;
		public string NUMBERNEWCMS;
		public string ERRORLOGFILENAME;
	}
}
