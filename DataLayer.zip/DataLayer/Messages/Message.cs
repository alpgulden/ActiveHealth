using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Message].
	/// When the Language.Transate cannot translate a message, we use this class to put
	/// the new message into db.
	/// </summary>
	[SPInsert("usp_InsertMessage")]
	[SPLoad("usp_LoadMessage")]
	[TableMapping("Message","msgID,langID",true)]
	public class Message : BaseDataClass
	{
		[ColumnMapping("MsgID")]
		private string msgID;
		[ColumnMapping("LangID")]
		private string langID;
		[ColumnMapping("Text")]
		private string text;
	
		public Message()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Message(string msgID, string text)
		{
			this.NewRecord();
			this.msgID = msgID;
			this.text = text;
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=40)]
		public string MsgID
		{
			get { return this.msgID; }
			set { this.msgID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=2)]
		public string LangID
		{
			get { return this.langID; }
			set { this.langID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=250)]
		public string Text
		{
			get { return this.text; }
			set { this.text = value; }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.langID = "EN";
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(string msgID, string langID)
		{
			return base.Load(msgID,langID);
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(string msgID)
		{
			return Load(msgID, "EN");
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New(string msgID, string text)
		{
			this.NewRecord(); // initialize record state
			this.msgID = msgID;
			this.text = text;
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New(string msgID, string langID, string text)
		{
			this.NewRecord(); // initialize record state
			this.msgID = msgID;
			this.langID = langID;
			this.text = text;
		}
	}
}
