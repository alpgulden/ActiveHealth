using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	public class DuplicateCheckCriteriaMessages : BaseMessages
	{	
		private static DuplicateCheckCriteriaMessages messageIDs;

		public DuplicateCheckCriteriaMessages() : base()
		{
		}

		public new static DuplicateCheckCriteriaMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new DuplicateCheckCriteriaMessages();
				return messageIDs;
			}
		}

		public DuplicateCheckCriteriaMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string DUPLICATECHECK;
		public string EXACTMATCH;
		public string DAYS;
		public string REFPROVIDER;
		public string SERVICETYPE;
		public string TREATINGPROVFACGRP;
		public string SERVICESTARTDATE;
		public string ORPLUSMINUS;
		public string REFERRINGPROVIDER;
		public string TREATINGPROVFACGROUP;
		public string SETTINGS;
	
		
	}
}
