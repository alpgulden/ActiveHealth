using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	[LanguageTable("Message", "MsgID", "LangID", "Text")]
	public class ProviderMessages : BaseMessages
	{

		public ProviderMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string STREETADDR;
		public string STREETADDR1;
		public string STREETADDR2;
		public string ADDEDONFLY;
		public string ALTERNATEID;
		public string BEEPER;
		public string DATEACTIVE;
		public string EXTENSION;
		public string FEDTAXID;
		public string GENDER;
		public string FOCUS;
		public string MEDICAREID;
		public string PHONE;
		public string PHYSICIANREVIEW;
		public string PREFIX;
		public string PROVIDERID;
		public string SUFFIX;
		public string UPIN;
		public string ZIP;
		public string SPECIALTYSTATUSID;
		public string SPECIALTYID;
		public string ISPRIMARY;
		public string LANGUAGE;
		public string SPECIALTY;
		public string FOCUSTYPE;
		public string FEDERALTAXID;
		public string SEARCHBY;
		public string NULL;
		public string LOCATIONID;
		public string LOCATIONS;
		public string PROVIDERINFO;
		public string NOTAVAILABLE;
		public string SELECT;
		public string SAVE;
		public string SETASPRIMARY;
		public string CHANGESTATUS;
		public string INACTIVATE;
		public string BOARDSTATUS;
		public string ENDDATE;
		public string STARTDATE;
		public string NETWORKS;
		public string STATUSCHANGEDBY;
		public string STATUSCHANGEDATE;
		public string COPYFROMSERVICE;
		public string DATECREATED;
		public string NETWORKADDRESS;
		public string NETWORKID;
		public string NETWORKNAME;
		public string NETWORKTYPE;
		public string ASOFDATE;
		public string SELECTPROVNETWORK;
		public string DUPLICATEDATES;
		public string ADDLOCATION;
		public string SELECTPROVSERV;
		public string SELECTSERVICE;
		public string SELECTNETWORK;
		public string PHYISICIANREVIEW;
		public string GROUPPRACTICEDATES;
		public string GROUPPRACTICEADDRESS;
		public string GROUPPRACTICEALTERNATEID;
		public string GROUPPRACTICEID;
		public string GROUPPRACTICELOCATIONID;
		public string GROUPPRACTICELOCATIONS;
		public string REFERENCED;
		public string SELECTGROUPPRACTICE;
		public string PROVIDERTPE;
		public string PROVIDERS;
		public string FOCUSTITLE;
		public string MemberMatchRegex;
		public string SPECIALTYTITLE;
		public string ADDEDBY;
		public string SERVICETITLE;
		public string NETWORKTITLE;
		public string ADDNEWRECORD;
		public string CONTACTS;
		public string GROUPPRACTICETITLE;
		public string GROUPPRACTICENAME;
		public string GPEXISTS;
		public string ALLNETWORKS;
		public string SPECIFIEDNETWORK;
		public string FAXNUMBER;
		public string IN;
		public string OUT;
		public string NEXT;
		public string PREVIOUS;
		public string LINE1;
		public string CANTFINDRECORD;
		public string PROVIDERFORMTITLE;
		public string PROVIDERSEATCHTITLE;
		public string PROVIDERLOCATIONFORMTITLE;
		public string PROVIDERSAVEDMSG;
		public string LOCATION;
		public string LOCATIONLOWER;
		public string BOARDCERTIFICATION;
		
	}
}
