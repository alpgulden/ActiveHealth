using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Summary description for LetterMessages.
	/// </summary>
	[LanguageTable("Message", "MsgID", "LangID", "Text")]
	public class LetterMessages : PatientMessages
	{
		private static LetterMessages messageIDs;
		
		public LetterMessages() : base()
		{
		}

		public LetterMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public static LetterMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new LetterMessages();
				return messageIDs;
			}
		}

		public string EVENTTYPEID;
		public string LETTERSET;
		public string LETTERTYPEID;
		public string MATRIXTYPE;
		public string REFERRALTYPEID;
		public string REFERRALUNITID;
		public string REVIEWDECISIONREASONID;
		public string REVIEWDECISIONTYPEID;
		public string ORGANIZATION;
		public string SESSIONINDICATOR;
		public string STATEFACILITY;
		public string ENROLLMENT;
		public string LETTERQUEUE;
		public string LETTERMATRIX;
		public string LETTERMATRIXEXCEPTION;
		public string SELECT;
		public string LETTERTEMPLATE;
		public string DUPLEXPRINT;
		public string FORMTYPEID;
		public string LETTERBODY;
		public string LETTERNAME;
		public string RECEIVERTYPEID;
		public string VERSION;
		public string ERRLETTERDATE;
		public string INTROLETTERNUMBER;
		public string ICMENVELOPE;
		public string ASSIGNEDTEAMANDUSER;
		public string ENDDATE;
		public string STARTDATE;
		public string BATCHNUMBER;
		public string PRINTDRAFT;
		public string RESETUSERBUTTON;
		public string SENDTOQUEUE;
		public string PRINTER;
		public string STATUS;
		public string USER;
		public string RERUNBATCH;
		public string ADDCATEGORY;
		public string CMSTYPE;
		public string HEADERTEXT;
		public string UPDATEITEM;
		public string ASMTLTRMAINT;
		public string LOGIC;
		public string POSITION;
		public string ADDPARAGRAPH;
		public string FILTERBY;
		public string CATEGORIES;
		public string CATEGORY;
		public string PARAGRAPH;
		public string PARAGRAPHS;
		public string LETTERSETMAINTENANCE;
		public string LETTERSETID;
		public string MATRIXTYPEID;
		public string ADDLETTERSET;
		public string CANNOTCHANGEMATRIXTYPEMFL;
		public string CANNOTCHANGEMATRIXTYPECOMP;
		public string CANNOTCHANGEFORMTYPECOMP;
		public string CANNOTCHANGEFORMTYPEMFL;
		public string MODIFIEDBY;
		public string ADDNEW;
		public string LETTERDUPLEXQUEUE;
		public string LETTERENVELOPEQUEUE;
		public string GENERATELETTERS;
		public string MORGID;
		public string ORGID;
		public string SCORINGLOADDATE;
		public string INTROLTR1;
		public string INTROLTR2;
		public string INTROLTR3;
		public string INTROLTRS;
		public string LETTERGRAPHICS;
		public string LETTERGRAPHIC;
		public string FILELOCATION;
		public string GRAPHICID;
		public string ASSESSMENTPARAGRAPHBRIEF;
		public string ASSESSMENTCATEGORY;
		public string ASSESSMENTPARAGRAPH;
		public string DUPLICATELETTERTEMPLATE;

		// fax related
		public string REFRESH;			//Refresh
		public string FAXVIEWLOG;		// "View Log"
		public string FAXPREVIEW;		// "Preview"
		public string FAXLOGTITLE;	// "SEND FAX"
		public string FAXSEND;			// "Send Fax"
		public string FAXINFO;			// "Fax Info"
		public string FAXSENTMSG;	// "Fax Successfully Sent To Server"
		public string FAXFAILEDMSG;	// "Fax Attempt Failed"
		public string FAXLETTERCONTENT; // "Letter Content"
		public string FAXDELIVERTOINFO;	// "Deliver To:"
		public string FAXFROMINFO;		// "From:"
		public string FAXDISCLAIMER;		// "Disclaimer"

	}
}
