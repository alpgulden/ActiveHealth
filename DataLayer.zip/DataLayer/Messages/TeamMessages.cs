using System;

	namespace ActiveAdvice.Messages
	{
		/// <summary>
		/// Language class that contains app specific messages
		/// </summary>
		public class TeamMessages : BaseMessages
		{	
			private static TeamMessages messageIDs;

			public TeamMessages() : base()
			{
			}

			public new static TeamMessages MessageIDs
			{
				get
				{
					if (messageIDs == null)
						messageIDs = new TeamMessages();
					return messageIDs;
				}
			}

			public TeamMessages(string langID): base(langID)
			{
				LoadFromTable();
			}

			public string TEAM;
			public string TEAMS;
			public string TEAMUSER;
			public string TEAMMEMBERS;
			public string NEWTEAM;
			public string USER;
			public string USERS;
			public string CODEID;
			public string CODEDESCRIPTION;
			public string INACTIVECODEQ;
			public string INACTIVECODE;
			public string MEMBERS;
			public string ADDTEAM;
			public string MEMBERSUSER;
			public string AVAILABLEUSERS;
			public string ALL;
			public string INACTIVEUSERMSG;
			public string INACTIVETEAMMSG;
			public string ASSIGNED;
			public string LINKUSER;
			public string LINKUSERS;
			public string LINKUSERTOTEAM;
			public string MEMBERWARNING;
			public string ADDTEAMMEBERS;
			public string TEAMMEMBER;
			public string VALIDATIONERROR;
			public string USERSELECTIONERROR;
			public string SELECTBY;
			public string SELECT;
			public string TEAMSELECTION;
			public string CLEARADMIT;
			public string INACTIVATE;
			public string ACTIVATE;
			public string LOGINNAME;
			public string USERID;
		}
	}
