using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	public class PlanMessages : BaseMessages
	{
		private static PlanMessages messageIDs;

		public PlanMessages(): base()
		{
			
		}

		public PlanMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public static PlanMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new PlanMessages();
				return messageIDs;
			}
		}

		public string PLAN;
		public string SPECIFICATION;
		public string MATERNICHECK;
		public string PLANDENY;
		public string PLANS;
		public string DENIAL;
		public string PRECERT;
		public string ALTERNATEID;
		public string TYPE;
		public string SEARCHTERM;
		public string HEDISTYPEID;
		public string BENEFITSERVICEID;
		public string INSURANCEPAYORID;
		public string OUTLIERTRIGGER;
		public string PAYORTYPEID;
		public string REFERRALGOODFOR;
		public string REVIEW;
		public string TRIGGERLISTID;
		public string URWHENMEDICAREISPRIMARY;
		public string URWHENOTHERINSISPRIMARY;
		public string EAPREFERRAL;
		public string CALLBEFORELETTER;
		public string CALLFORLATEPRECERT;
		public string BEGIN;
		public string BEGINDATE;
		public string PENALTY;
		public string NOTIFICATIONSVCSREQUIRED;
		public string REGISTRATION;
		public string WEEKS;
		public string CMWHENMEDICAREISPRIMARY;
		public string CMWHENOTHERINSISPRIMARY;
		public string CALLBEFOREDENY;
		public string NORMALDENY;
		public string LENGTHOFSTAYTRIGGER;
		public string NOTETYPE;
		public string CONTRACTEFFDATE;
		public string MANAGEMENTSVCS;
		public string MANAGEMENTSVCITEMS;
		public string MANAGEMENTSVCRATETYPE;
		public string MANAGEMENTSVCTYPE;
		public string BILLABLE;
		public string INSURERS;
		public string RETIREES;
		public string SPOUSES;
		public string MULTIPLIER;
		public string DIVIDER;
		public string CONVERSION;
		public string SPECIALPROCEDURES;
		public string LISTID;
		public string DIAGORPROC;
		public string SPECIALPROCEDUREITEMS;
		public string CODETYPE;
		public string CODEEND;
		public string CODESTART;
		public string SPECIALPROCEDUREITEM;
		public string PLANCOMPONENTS;
		public string COMPONENTS;
		public string ZIPPYCODER;
		public string SPECIALPROCEDURE;
		public string BENEFITSERVICE;
		public string BENEFITSERVICES;
		public string BENEFITSERVICEITEMS;
		public string BENEFITSERVICETYPEID;
		public string INNETDETAILS;
		public string OUTNETDETAILS;
		public string BENEFITSERVICEITEM;
		public string DAYSANNUAL;
		public string DAYSLIFE;
		public string DOLLARSANNUAL;
		public string EXCLUDED;
		public string OUTOFPOCKETINDIVIDUAL;
		public string PERCENT;
		public string COPAY;
		public string COVERED;
		public string DEDUCTIBLEFAMILY;
		public string DEDUCTIBLEINDIVIDUAL;
		public string DOLLARSLIFE;
		public string NETWORKID;
		public string OUTOFPOCKETFAMILY;
		public string VISITANNUAL;
		public string VISITSANNUAL;
		public string VISITSLIFE;
		public string INSURACNEPAYORS;
		public string INSURANCEPAYOR;
		public string INSURANCEPAYORS;
		public string TRIGGERLISTS;
		public string TRIGGERITEM;
		public string TRIGGERITEMS;
		public string TRIGGERLIST;
		public string SPECIALPROCEDUREID;
		public string MANAGEMENTSERVICEID;
		public string CAREMANAGEMENT;
		public string DISEASEMANAGEMENT;
		public string REVIEWPERCENT;
		public string PRECERTPENALTY;
		public string ITEMS;
		public string SPECIFICATIONS;
		public string REGISTRATIONWEEKS;
		public string NOTEDETAIL;
		public string NOTEDETAILS;
		public string NOTETITLE;
		public string SPECIFICATIONTITLE;
		public string DENIALTITLE;
		public string MATERNICHEKTITLE;
		public string NOTEDETAILSTITLE;
		public string NOTESTITLE;
		public string ERRTERMDATE;
		public string DENYPRECERTMATCHEK;
		public string HEDISPAYORTYPEID;
		public string MANAGEMENTSERVICEITEM;
		public string MATERNICHEK;
		public string DEPENDENTS;
		public string SAVEDMSGPLU;
		public string HEDISPLANTYPEID;
		public string INPATIENTREVIEW;
		public string INPATIENTREVIEWOTHER;
		public string OUTPATIENTREVIEW;
		public string OUTPATIENTREVIEWOTHER;
		public string REFERRAL;
		public string CONTACTS;
		public string CLONE;
		public string ADDMATERNICHEK;
		public string PLANID;
		public string CANTFINDRECORD;
		public string PLANPAGETITLE;
		public string BENEFITSERVICEPAGETITLE;
		public string MANAGEMENTSVCPAGETITLE;
		public string SPECIALPROCEDUREPAGETITLE;
		public string TRIGGERLISTPAGETITLE;
	}
}
