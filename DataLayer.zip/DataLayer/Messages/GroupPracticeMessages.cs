using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	[LanguageTable("Message", "MsgID", "LangID", "Text")]
	public class GroupPracticeMessages : ProviderMessages
	{
		public GroupPracticeMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		
		public string LOCATIONS;
		public string GROUPPRACTICEID;
		public string GROUPPRACTICENAME;
		public string GROUPPRACTICETYPEID;
		public string GROUPPRACTICETYPES;
		public string GROUPPRACTICETYPECODE;
		public string GROUPPRACTICETYPEDES;
		public string GroupPracticeTYPE;
		public string TYPEINFORMATION;
		public string NETWORKTYPES;
		public string FACILITYTYPES;
		public string GPRACTICEFOCUSTYPE;
		public string GROUPPRACTICEFOCUS;
		public string GPSERVICETYPEID;
		public string SERVICELOCATION;
		public string GROUPPRACTICELOCATIONID;
		public string SEARCH;
		public string ADDEDONFLY;
		public string STATUSCHANGETIME;
		public string PROVIDERLOCATIONS;
		public string PROVEXISTS;
		public string PROVIDERDATES;
		public string PROVIDERADDRESS;
		public string PROVIDERALTERNATEID;
		public string ERRTERMDATE;
		public string GROUPPRACTICEFORMTITLE;
		public string GROUPPRACTICELOCFORMTITLE;
		public string GROUPPRACTICESEARCHTITLE;
		public string ISNOTSET;
	}
}
