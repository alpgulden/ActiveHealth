using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Summary description for ReportMessages.
	/// </summary>
	public class ReportMessages: BaseMessages
	{
		private static ReportMessages messageIDs;

		public ReportMessages():base()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		public ReportMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public new static ReportMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)  
				messageIDs = new ReportMessages();
				return messageIDs;
			}
		}


		public string PRODUCTIONOPERATION;
		public string INPATIENT;
		public string OUTPATIENT;
		public string SAVINGS;
		public string REFERRAL;
		public string NETWORKANALYSIS;
		public string CAREMANAGEMENT;
		public string MATERNICHEK;
		public string MANAGEMENT;
		public string FORMSPECIFIC;
		public string DAILYWORKLIST;
		public string PATIENTCENSUSSUMMARY;
		public string UTILWITHNOAGGBYSUBGRP;
		public string ACTUTILWITHNOAGGBYSUBGRP;
		public string IPAUTHORIZATIONSBYSTATE;
		public string OUTPATIENTUTILWITHNOAGGBYSUBGRP;
		public string COSTCOMPSUMMARY;
		public string COSTCOMPDETAILS;
		public string SUMMARYOFINPATINETOUTPATIENTSAVINGS;
		public string REFERRALSUMMARYWITHNOAGGRBYSUBGRP;
		public string FACILITYNETWORKANALYSIS;
		public string PROVIDERNETWORKANALYSIS;
		public string SUMMARYOFCLOSEDCASES;
		public string OPENCMLOGBYUSER;
		public string OPENCMLOGBYORGLEVELS;
		public string POTENTIALLARGECASES;
		public string MULTIPLEADMISSIONREPORT;
		public string GENERALEDIT;
		public string ACTIVITYEDIT;
		public string INVOICEOFBILLABLEACTIVITY;
		public string CODETABLEREPORT;
		public string INTAKELOGWITHNOAGG;
		public string SINGLEEVENT;
		public string COSTCOMPSINGLEPATIENTPROB;
		public string CMSCOSTCOMP;
		public string REFERRALSTATISTICS;
		public string PLANID;
		public string SORGID;
		public string MORGID;
		public string ORGID;
		public string TEAMUSER;
		public string FROMDATE;
		public string ENDDATE;
		public string SUBTOTALBY;
		public string STATENAME;
		public string CMSTYPENAME;
		public string OUTLIERS;
		public string CODETABLE;
		public string NEWBORNDISCHARGEDWITHMOTHER;
		public string REPORT;
		public string PARAMETERS;
		public string PRINTTOPDF;
		public string EVENTSTATISTICS;
		public string MAJORGROUP;
		public string SUBGROUP;
		public string SUBSUBGROUP;
		public string SHOWDETAILS;
		public string READMITDAYS;
		public string SORTBY;
		public string CLINICALMANAGEMENTSERVICE;
		public string UTILIZATIONSTATISTICS;
		public string SAVEDREPORTS;
		public string OPENEVENTSPAGEBREAKAFTERSORG;
		public string OPENEVENTSPAGEBREAKAFTEREVENT;
		public string CLOSEDEVENTSPAGEBRAFTEREVENT;
		public string CLOSEDEVENTSPAGEBRAFTERSORG;
		public string OPENEVENTSPAGEBRAFTEREVENT;
		public string BYTEAMMORGORGSORGUSER;
		public string BYUSERFACMORGORGSORG;
		public string SUMMARYBYMORGORGSORG;
		public string SUMMARYBYUSERFACMORGORGSORG;
		public string SUMMARYBYFACMORGORGSORG;
		public string NEWCMLOGBYORGLEVELS;
		public string NEWCMLOGBYUSER;
		public string CLOSEDCMLOGBYORGLEVELS;
		public string CLOSEDCMLOGBYUSER;
		public string OPENMATERNICHEKLOGBYORGLEVELS;
		public string OPENMATERNICHEKLOGBYUSER;
		public string NEWMATERNICHEKLOGBYUSER;
		public string NEWMATERNICHEKLOGBYORGLEVELS;
		public string CLOSEDMATERNICHEKLOGBYUSER;
		public string CLOSEDMATERNICHEKLOGBYORGLEVELS;
		public string MATERNICHEKRISKTYPESTATISTICS;
		public string SAMEMAJORSUB;
		public string SELECTMAJORORSUB;
		public string RPTACTPATIENTSUBSC;
		public string RPTCLOSEDCMSEVENT;
		public string RPTCLOSEDEVENT;
		public string RPTCLOSEDIPEVENT;
		public string RPTOPENEVENT;
		public string RPTREFERRALS;
		public string SAMESUBSUBSUB;
		public string SAMEMAJORSUBSUB;
		public string SELECTMAJORORSUBSUB;
		public string DATES;
		public string REPORTTITLE;
		public string REPORTSTITLE;
		public string REPORTPARAMETERSTITLE;
	}
}
