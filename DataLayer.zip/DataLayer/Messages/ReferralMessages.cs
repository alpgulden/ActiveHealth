using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	public class ReferralMessages : PatientMessages
	{	
		private static ReferralMessages messageIDs;

		public ReferralMessages() : base()
		{
		}

		public new static ReferralMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new ReferralMessages();
				return messageIDs;
			}
		}

		public ReferralMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string REFERRAL;
		public string DXPX;
		public string CLINICAL;
		public string CLINICALTAB;
		public string CLINICALDETAIL;
		public string VIEWCLINICALS;
		public string VIEWREFERRALS;
		public string APPOINTMENTS;
		public string APPOINTMENTSTAB;
		public string REPORTS;
		public string REPORTSTAB;
		public string PCP;
		public string REFERREDFROM;
		public string REFERREDTO;
		public string PCPNETWORKID;
		public string REFERFROMNETWORKID;
		public string REFERTOPROVIDERNETWORKID;
		public string PHONE;
		public string PAGER;
		public string LOCATION;
//		public string SAVEITEM;
//		public string CANCELITEM;
		public string ADDREFERRER;
		public string ADDOTHER;
		public string ADDPCP;
		public string REFERRALID;
		public string REFERRALDESCRIPTION;
		public string REFERRALDETAILDATE;
		public string ELIGIBILIY;
		public string REFERRALTYPEID;
		public string ALTERNATEREFERRALID;
		public string VALIDSTARTDATE;
		public string VALIDENDDATE;
		public string REFERRALURGENCYID;
		public string AUTHORIZATIONDECISIONID;
		public string DECISIONREASONID;
		public string UNITQUANTITY;
		public string REASON;
		public string REFERRALSCHEDULEDBYID;
		public string APPOINTMENTDATE;
		public string UNITTYPEID;
		public string REFERRALDETAILID;
		public string REFERRALROLEID;
		public string REPORTENTRYNAME;
		public string REPORTRECEIVEDDATE;
		public string ERRVALIDDATE;
		public string REFERRALSTATUSID;
		public string FACILITY;
		public string PROVIDER;
		public string PROVIDERGROUPPRACTICE;
		public string DIAGNOSES;
		public string PROCEDURES;
		public string OUTCOMES;
		public string ADMINISTRATION;
		public string PCPID;
		public string PCPSPECIALTYID;
		public string PCPLOCATIONID;
		public string REFERREDFROMPROVIDERID;
		public string REFERREDFROMSPECIALTYID;
		public string REFERREDFROMLOCATIONID;
		public string REFERREDTOSPECIALTYID;
		public string REFERREDTOID;
		public string REFERREDTONETWORKID;
		public string REFERREDTOLOCATIONID;
		public string SUBSCRIBERCOVERAGE;
		public string PLANNAME;
		public string LINKPROBLEM;
		public string SUBSCRIBER;
		public string SSN;
		public string GROUP;
		public string OTHERPLAN;
		public string REFERRALSTARTDATE;
		public string ADDNEWAPPOINMENT;
		public string ADDNEWCLINICAL;
		public string REFERRERERROR;
		public string ERRAPPDATE;
		public string VIEWALL;
		public string REFERRALPOSSIBDUP;

	}
}
