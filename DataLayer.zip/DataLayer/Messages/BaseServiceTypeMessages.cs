using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	[LanguageTable("Message", "MsgID", "LangID", "Text")]
	public class BaseServiceTypeMessages : BaseMessages
	{
		public BaseServiceTypeMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string SELECTA;
		public string SERVICE;
		public string SERVICECODE;
		public string SERVICETYPES;
		public string SERVICETYPE;
		public string SERVICEDESC;
		public string SERVICETYPEINFORMATION;


	}
}
