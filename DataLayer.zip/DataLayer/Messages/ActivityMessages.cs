using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	public class ActivityMessages : PatientMessages
	{	
		private static ActivityMessages messageIDs;

		public ActivityMessages() : base()
		{
		}

		public new static ActivityMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new ActivityMessages();
				return messageIDs;
			}
		}

		public ActivityMessages(string langID): base(langID)
		{
			LoadFromTable();
		}
	
		public string AUTOACTIVITY;
		public string AUTOACTIVITYRULE;
		public string AUTOACTIVITYRULES;
		public string AUTOACTIVITYEXCEPTION;
		public string ACTIVITYRULEVIEW;
		public string ACTIVITYEXCEPTIONVIEW;
		public string ADDRULE;
		public string ADDEXCEPTION;
		public string ACTIVITYVALUES;
		public string CLONERULE;
		public string RULETYPEID;
		public string MORGORGSORGPLAN;
		public string ACTIVITYCOMPLETION;
		public string ACTIVITYTYPE;
		public string PHYSICIANREVIEWDETAIL;
		public string PRIORITY;
		public string FROMCOMPLETIONDATE;
		public string FROMDUEDATE;
		public string TOCOMPLETIONDATE;
		public string TODUEDATE;
		public string SORTFIELD;
		public string COMPLETEDBYUSERID;
		public string TOCOMLETIONDATE;
		public string REVIEW;
		public string LINKERRORMSG;
		public string AUTOACTIVITYVALUE;
		public string AUTOACTIVITYVALUES;
		public string ADDACTIVITYVALUE;
		public string ASSIGNEDUSERTEAM;
		public string ASSIGNEDTEAMNAME;
		public string ASSIGNEDUSER;
		public string ASSIGNEDUSERNAME;
		public string INTERVENTION;
		public string RATEUNITS;
		public string UNITS;
		public string TOTAL;
		public string COMPLETE;
		public string RULEID;
		public string EVENTSERVICECATEGORYID;
		public string REFERRALSERVICECATEGORYID;
		public string DECISIONTYPEID;
		public string CMSTYPEID;
		public string PLANMGMTSVCTYPEID;
		public string MORGID;
		public string ORGID;
		public string LASTNAMESTART;
		public string LASTNAMEEND;
		public string ZIPSTART;
		public string ZIPEND;
		public string STATEID;
		public string PRIMARYDIAGCODETYPE;
		public string PRIMARYDIAGSTART;
		public string PRIMARYDIAGEND;
		public string PRIMARYPROCCODETYPE;
		public string PRIMARYPROCSTART;
		public string PRIMARYPROCEND;
		public string FACILITYFEDTAXID;
		public string FACILITYNETWORKSTATUSID;
		public string PROVIDERFEDTAXID;
		public string PROVIDERNETWORKSTATUSID;
		public string REFERPROVIDERFEDTAXID;
		public string REFERPROVIDERNETWORKID;
		public string REFERPROVIDERNETWORKSTATUSID;
		public string EXCEPTIONID;
		public string GENERATEACTIVITY;
		public string AUTOACTIVITYNITIALIZATIONID;
		public string COMPLETIONID;
		public string DATESOURCE;
		public string DATEOFFSET;
		public string PRIORITYID;
		public string ASSIGNEDUSERID;
		public string ASSIGNEDTEAMID;
		public string REASSIGN;
		public string RESCHEDULE;
		public string ASSIGNEDTEAM;
		public string INTERVENTIONID;
		public string WORKLISTS;
		public string COMPLETIONCODE;
		public string ACTIVITYCLONED;
		public string PATIENTFIRSTNAME;
		public string PATIENTLASTNAME;
		public string MANAGEMENTSERVICETYPEID;
		public string MANAGEMENTSERVICETYPE;
		public string TOTALBILLABLEAMOUNT;
		public string INNETWORK;
		public string OUTNETWORK;
		public string BASEAMOUNT;
		public string BILLABLEAMOUNT;
		public string EXTENDEDAMOUNT;
		public string ASSIGNEDUSERTYPE;
		public string ACTIVITYPRIMARYTYPEID;
		public string WORKLIST;
		public string NOTAUTHORIZED;
		public string VIEWALL;
		public string NOTETYPEID;
		public string AUTOACTIVITYCLONEMSG;
		public string CODESTATUS;
		public string DUETIME;
		public string ACTIVITIESPAGETITLE;
		public string ORGANIZATIONID;
		public string WORKLISTPAGETITLE;
		public string TOTALS;
		public string CLINICALREVIEWDECISIONTYPECODEID;
		public string RULETYPE;
	}
}
