using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	public class DxPxMessages : BaseMessages
	{	
		private static DxPxMessages messageIDs;

		public DxPxMessages() : base()
		{
		}

		public new static DxPxMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new DxPxMessages();
				return messageIDs;
			}
		}

		public DxPxMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string MOMBABYCODES;
		public string RANGEDESCRIPTION;
		public string CODETYPE;
		public string DIAGORPROC;
		public string ENDCODE;
		public string MOMBABYCODEID;
		public string MOMORBABY;
		public string STARTCODE;
		public string MOMBABYCODE;
		public string DELETEDEPENDENCYMSGCODE;
		public string DELETEDMSG;
		public string ERRTERMDATE;
		public string MOMBABYCODETITLE;
		public string MOMBABYCODESEARCHTITLE;

		
	}
}
