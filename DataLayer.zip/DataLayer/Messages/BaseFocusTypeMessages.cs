using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	[LanguageTable("Message", "MsgID", "LangID", "Text")]
	public class BaseFocusTypeMessages : BaseMessages
	{
		public BaseFocusTypeMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string ACTIVE;
		public string FOCUSCODE;
		public string FOCUSDESC;
		public string NOTE;
		public string ADDRESSINFO;
		public string CITY;
		public string STREETADDR1;
		public string STREETADDR2;
		public string STATE;
		public string COUNTRY;
		public string COUNTY;
		public string ZIPCODE;
		public string PHONE1;
		public string PHONE2;
		public string PHONE3;
		public string FAX;
		public string DELIVERYMETHOD;
		public string ADD;
		public string OK;
		public string CANCEL;
		public string TERMINATE;
		public string TYPEINFORMATION;
		public string FOCUSTYPES;
		public string FOCUSTYPE;
		public string SELECTA;
		public string DESCRIPTION;
	}
}
