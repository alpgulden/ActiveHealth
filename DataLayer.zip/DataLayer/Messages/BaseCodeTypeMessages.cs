using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Summary description for BaseCodeTypeMessages.
	/// </summary>
	public class BaseCodeTypeMessages: BaseMessages
	{
		public BaseCodeTypeMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string CODETYPE;
		public string SELECTA;
		public string CODETYPES;
		public string CODE;
		public string DESCRIPTION;
		public string CODEINFORMATION;
		public string NOTEPAD;
		public string LINKEDMSG;
		public string BRACKETCLASSMSG;		
		public string ACTIVITYTYPESUBTYPEID;
		public string ACTIVITYPRIMARYTYPEID;
		public string CLINICALREVIEWDECISIONTYPE;
		public string ACTIVITYTYPEID;
		public string ACTIVITYSUBTYPEID;
		public string ACTIVITYTYPECODE;
		public string ACTIVITYSUBTYPECODE;
		public string ACTIVITYTYPEDESCRIPTION;
		public string ACTIVITYSUBTYPEDESCRIPTION;
		public string LINK;
		public string REMOVE;
		public string REMOVEMSG;
		public string CODEERR;
		public string OUTCOMEINDICATORID;
		public string PROBLEMSTATUSID;
		public string DELETEDEPENDENCYMSGCODE;
		public string RELATIONSHIPNAME;
		public string TEXTERR;
		public string APPEALREQUESTTYPE;
		public string PRIORITY;
		public string UB92SOURCE;
		public string CODESTATUS;
		public string HEDISRPTTYPE;
		public string HEDISRPTACUITY;
		public string RESOLUTIONACTION;
		public string DESCRIPTIONERR;
		public string SUBCODEERR;
		public string LINKEDFAIL;
		public string LINKEDSUCCESS;
		public string REPORTUNIT;
		public string CMSTYPE;
		public string MATRIXTYPE;
		public string SORTORDER;
		public string CODETABLES;
		public string SUBCODESTR;
		public string NOTAPPLICABLE;
		public string EXTCODE;
		public string REVIEWUNIT;
		public string FREQDURUNIT;
		public string REPORTUNITID;
		public string ISNEWBORN;
		public string SEVERITYORDER;
		public string DAYCONVERSION;
		public string GROUPTYPE;
		public string CLAIMSTATUS;
		public string HCIAREGION;
		public string HCIAGROUP;
		public string COSTSAVING;
	}
}
