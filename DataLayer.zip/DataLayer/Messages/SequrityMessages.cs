using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	public class SequrityMessages : BaseMessages
	{	
		private static SequrityMessages messageIDs;

		public SequrityMessages() : base()
		{
		}

		public new static SequrityMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new SequrityMessages();
				return messageIDs;
			}
		}

		public SequrityMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string GROUP;
		public string USER;
		public string FUNCTINONALACCESSLEVEL;
		public string DATAACCESSLEVEL;

	}
}
