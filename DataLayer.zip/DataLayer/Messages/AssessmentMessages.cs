using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	[LanguageTable("Message", "MsgID", "LangID", "Text")]
	public class AssessmentMessages : BaseMessages
	{
		private static AssessmentMessages messageIDs;

		public AssessmentMessages() : base()
		{
		}

		public AssessmentMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public new static AssessmentMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new AssessmentMessages();
				return messageIDs;
			}
		}

		public string QUESTIONEXTRAINFO;
		public string QUESTIONID;
		public string QUESTIONINDEXID;
		public string QUESTIONNAIRES;
		public string QUESTIONS;
		public string QRPR;
		public string QUESTION;
		public string QUESTIONSEARCH;
		public string PARENTQUESTION;
		public string PRQ;
		public string QUESTIONCONTENT;
		public string QUESTIONCONTROLTYPE;
		public string QUESTIONDETAIL;
		public string CONTENTOWNER;
		public string LOGIC;
		public string LOGICS;
		public string WEBLINK;
		public string WEBLINKID;
		public string ASSESSMENT;
		public string PRESENTATIONGROUPS;
		public string SEARCHCHILDORG;
		public string SEARCHRESULTS;
		public string INSTRUCTIONTEXT;
		public string QUESTIONTEXT;
		public string QUESTIONCONTROLTYPEID;
		public string ANSWER;
		public string ANSWERID;
		public string ANSWERS;
		public string QUESTIONNAIRETRIGGERID;
		public string QUESTIONNAIRETYPE;
		public string ASSIGNEDTEAM;
		public string CMSTYPE;
		public string QUESTIONNAIREID;
		public string DXPXTRIGGERS;
		public string SORT;
		public string ADDREMOVEPR;
		public string PRESENTATIONGROUPID;
		public string SORTORDER;
		public string QUESTIONNAIRESEARCH;
		public string CANCELSELECTIONS;
		public string SAVESELECTIONS;
		public string PICKPRESENTATIONGROUPS;
		public string TRIGGERS;
		public string SELECT;
		public string PRGROUPDESCRIPTION;
		public string PRSEARCH;
		public string LOGICSEARCH;
		public string LOGICDETAILS;
		public string LOGICID;
		public string LOGICTYPEID;
		public string LOGICTYPE;
		public string EXPRESSION;
		public string QRORGANIZATIONS;
		public string ANSWERRANGE;
		public string ANSWERRANGES;
		public string COMPONENTQUESTIONS;
		public string SUBQUESTIONS;
		public string SUBQUESTION;
		public string EXISTINGASSESSMENTS;
		public string ADDNEW;
		public string READONLYCOL;
		public string WEBLINKS;
		public string RETURNTOASSESSMENT;
		public string CURRENTRISKLEVEL;
		public string ANSWERRANGEID;
		public string HIGHOP;
		public string HIGHVALUE;
		public string LOWOP;
		public string LOWVALUE;
		public string PRESENTATIONLOGIC;
		public string ANSWERTEXT;
		public string ANSWERTYPEID;
		public string DATATYPEID;
		public string MAXVALUE;
		public string MINVALUE;
		public string ANSWERINDEXID;
		public string LEVELOFDISEASETYPEID;
		public string MEASUREMENTTYPEID;
		public string RISKTYPEID;
		public string SHOWQR;
		public string ANSWERCONTROLTYPE;
		public string REMOVE;
		public string ASSESSMENTVIEW;
		public string NOQUESTIONSTODISPLAY;
		public string NEXT;
		public string PREVIOUS; 
		public string PICKQUESTIONNAIRES;
		public string SHORTNOTE;
		public string RESETUSERBUTTON;
		public string RESETUSERHEADER;
		public string ORGANIZATION;
		public string CODETYPE;
		public string STARTCODE;
		public string CODEEND;
		public string DIAGORPROC;
		public string ENDCODE;
		public string TRIGGERITEM;
		public string SAVETRIGGER;
		public string QUESTIONNAIRE;
		public string DIAGNOSES;
		public string PROCEDURES;
		public string DEFICITTYPEID;
		public string GOALTYPEID;
		public string INTERVENTIONTYPEID;
		public string INTERVTEMPLATES;
		public string ACTIVITIES;
		public string ALLERGIES;
		public string CARERESOURCE;
		public string GENERAL;
		public string LETTERQUEUE;
		public string MATERNICHEK;
		public string MEASUREMENTS;
		public string MEDICATIONS;
		public string OUTCOMES;
		public string PACKINGLIST;
		public string PLANOFCARE;
		public string PROVIDERS;
		public string SUMMARY;
		public string VENDORS;
		public string PLANNAME;
		public string SUBSCRIBERNAME;
		public string MODIFIEDBY;
		public string ASSESSMENTGUID;
		public string BACKTOCMS;
		public string CCANSWERID;
		public string CCSOURCEID;
		public string ENROLLMENT;
		public string LETTERSET;
		public string LINKLETTERMATRIXES;
		public string MATRIXTYPE;
		public string SESSIONINDICATOR;
		public string UPDATE;
		public string CONTACTS;
		public string CODEVALUE;
		public string SEQUENCE;
		public string YEARS;
		public string ADDNEWICMTRIGGER;
		public string ICM;
		public string ATTRIBUTEID;
		public string COMPONENTID;
		public string VALUE;
		public string ICMTRIGGER;
		public string CATEGORY;
		public string INCLUDECCONLETTER;
		public string INCLUDENOCCONLETTER;
		public string PARAGRAPH;
		public string ICMPR;
		public string ICMQR;
		public string INTERVENTION;
		public string ADDREMOVEQUESTION;
		public string PICKQUESTIONS;
		public string READONLYWLERROR;
		public string INTRVTEMPLATE;
		public string CASEENDDATE;
		public string CASESTARTDATE;
		public string PRESENTATIONGROUP;
		public string CODEDESCRIPTION;
		public string ANDANSWERIS;
		public string ANSWERIS;
		public string STARTNEWASSESSMENT;
		public string CODEENDGTCODESTART;
		public string RESPONSES;
		public string DATE;
		public string AVAILABLE;
		public string BRANDNAME;
		public string RESPONSE;
		public string PRINTLETTERS;
		public string CHANGEASSESSMENTDATE;
		public string ASSESSMENTDATE;
		public string SAVE;
		public string ASSESSMENTDATEWTIME;
		public string INTERVENTIONS;
		public string DONOWLATER;
		public string TERMINATETIME;

		
		
	}

		
}
