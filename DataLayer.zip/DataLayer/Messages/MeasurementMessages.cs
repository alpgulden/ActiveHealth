using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	[LanguageTable("Message", "MsgID", "LangID", "Text")]
	public class MeasurementMessages : BaseMessages
	{
		
		private static MeasurementMessages messageIDs;

		public MeasurementMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public MeasurementMessages() : base()
		{
		}

		public static MeasurementMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new MeasurementMessages();
				return messageIDs;
			}
		}

		public string ADDMEASUREMENTLOD;
		public string ADDMEASUREMENTTYPE;
		public string LEVELOFDISEASE;
		public string FORMULA;
		public string HIGH;
		public string INSTRUCTIONTEXT;
		public string LODCODE;
		public string LOW;
		public string RANGE;
		public string RESULTISNUMERIC;
		public string SORTORDER;
		public string THRESHHOLDHIGH;
		public string THRESHHOLDLOW;
		public string UPDATE;
		public string NORMALS;
		public string LISTVALUE;
		public string ERRLODTHHIGH;
		public string NOPICKLISTVALUES;
	}
}
