using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Summary description for GuidelineMessages.
	/// </summary>
	public class GuidelineMessages: BaseMessages
	{
		private static GuidelineMessages messageIDs;

		public GuidelineMessages(): base()
		{
					
		}

		public GuidelineMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public new static GuidelineMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)  
				messageIDs = new GuidelineMessages();
				return messageIDs;
			}
		}

		public string GUIDELINECATEGORYPRODUCT;
		public string ADDNEW;
		public string LINK;
		public string GUIDELINESOURCESETID;
		public string PRODUCTCATEGORYGUIDELINE;
		public string INDICATORS;
		public string CODES;
		public string GUIDELINE;
		public string GUIDELINETIP;
		public string GUIDELINEINDICATORTIP;
		public string DIAGORPRC;
		public string CODETYPE;
		public string GUIDELINEINDICATORID;
		public string TEXT;
		public string SELECTABLE;
		public string NOTEREQUIRED;
		public string HIERARCHY;
		public string INSTRUCTION;
		public string DEFAULTNOTE;
		public string SORTSEQUENCE;
		public string TYPE1;
		public string TYPE2;
		public string SAVE;
		public string READONLYCOL;
		public string CHANGEDXCODE;
		public string CHANGEPXCODE;
		public string GUIDELINEPRODUCTID;
		public string GUIDELINECATEGORY;
		public string GUIDELINECATEGORYID;
		public string GUIDELINEID;
		public string GUIDELINEPRODUCT;
		public string TIP;
		public string GUIDELINESOURCESET;
		public string PRODUCT;
		public string REFERENCE;
		public string DISPLAYTEXT;
		public string DXORPX;
		public string SELECT;
		public string CATEGORYLABEL;
		public string EXPORTDATE;
		public string PRODUCTLABEL;
		public string SELECTION;
		public string MEDICALNOTE;
		public string CODEVALUE;
		public string CODEDESCRIPTION;
		public string EVENT;
		public string STARTDATE;
		public string ENDDATE;
		public string BACK;
		public string SUMMARY;
		public string CONTACTS;
		public string MEDICATIONS;
		public string ALLERGIES;
		public string ACTIVITIES;
		public string LETTERQUEUE;
		public string CASEENDDATE;
		public string CASESTARTDATE;
		public string GUIDELINEPRODUCTCATEGORYLINK;
		public string GUIDELINECATEGORYTITLE;
		public string GUIDELINEPRODUCTTITLE;
		public string GUIDELINEFORMTITLE;
		public string GUIDELINEREFFORMTITLE;
		public string GUIDELINEPRODUCTFORMTITLE;
		public string GUIDELINESELECTIONTITLE;
		public string GUIDELINESOURCESETTITLE;
		
	}
}
