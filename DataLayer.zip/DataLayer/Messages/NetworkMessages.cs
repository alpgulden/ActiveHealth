using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	[LanguageTable("Message", "MsgID", "LangID", "Text")]
	public class NetworkMessages : BaseMessages
	{
		private static NetworkMessages messageIDs;

		public NetworkMessages() : base()
		{
		}


		public NetworkMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string NETWORKS;
		public string NETWORKTYPE;
		public string TYPECODE;
		public string ALTERNATEID;
		public string NETWORKID;
		public string WEBURL;
		public string NETWORKNAME;
		public string NETWORKTYPECODES;
		public string NETWORKTYPECODE;
		public string NETWORKTYPEDESCRIPTION;
		public string TYPEINFORMATION;
		public string NETWORKTYPES;
		public string GROUPPRACTICETYPES;
		public string FACILITYTYPES;
		public string SEARCHBY;
		public string NULL;
		public string SELECT;
		public string SAVE;
		public string INACTIVATE;
		public string FOCUSTITLE;
		public string ERRTERMDATE;
		public string FOCUS;
		public string NETWORKTITLE;
		public string PROVIDERID;
		public string PROVIDERNAME;
		public string PROVIDERLOCATIONS;
		public string PROVIDERDATES;
		public string ASOFDATE;
		public string GPEXISTS;
		public string GROUPPRACTICELOCATIONS;
		public string GROUPPRACTICEDATES;
		public string GROUPPRACTICETITLE;
		public string GROUPPRACTICEID;
		public string GROUPPRACTICELOCATIONID;
		public string GROUPPRACTICENAME;
		public string FACEXISTS;
		public string FACILITYLOCATIONS;
		public string FACILITYDATES;
		public string FACILITYTITLE;
		public string FACILITYID;
		public string FACILITYLOCATIONID;
		public string FACILITYNAME;
		public string PLANID;
		public string PLANNAME;
		public string STARTDATE;
		public string ENDDATE;
		public string PLANDATES;
		public string PREFERENCELEVEL;
		public string PLANTITLE;
		public string FACILITYNETWORKLOCATIONEFFECTIVEDATES;
		public string PROVIDERNETWORKLOCATIONEFFECTIVEDATES;
		public string PLANNETWORKEFFECTIVEDATES;
		public string GPNETWORKLOCATIONEFFECTIVEDATES;
		public string ALTERNATEPLANID;
		public string NEXT;
		public string PREVIOUS;
		public string PROVEXISTS;
		public string NETWORKFORMTITLE;
		public string NETWORKSEARCHTITLE;

	}
}
