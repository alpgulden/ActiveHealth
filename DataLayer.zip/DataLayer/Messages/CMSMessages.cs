using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	[LanguageTable("Message", "MsgID", "LangID", "Text")]
	public class CMSMessages : PatientMessages
	{
		private static CMSMessages messageIDs;

		public CMSMessages() : base()
		{
		}

		public CMSMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public static CMSMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new CMSMessages();
				return messageIDs;
			}
		}

		public string MemberMatchRegex;

		public string GENERAL;
		public string CMSID;
		public string ASSESSMENT;
		public string CARERESOURCE;
		public string PACKINGLIST;
		public string PLANOFCARE;
		public string STARTDATE;
		public string CASEOPENREASONID;
		public string CASEENDDATE;
		public string CASESOURCEID;
		public string CASECONTINUEDREASONID;
		public string DATE;
		public string BYWHOM;
		public string CLIENTREPORTCONTACT;
		public string LOCATION;
		public string STATUS;
		public string ERRCMSDATE;
		public string ERRCMSSTARTDATE;
		public string ALTCMSID;
		public string INTENSITY;
		public string PHASE;
		public string PROGNOSIS;
		public string REASON;
		public string ACUITY;
		public string RISK;
		public string ADDDEFICIT;
		public string ADDGOAL;
		public string ADDINTERVENTION;
		public string CANCELITEM;
		public string COMMENT;
		public string DEFICITTYPEID;
		public string PRIORITY;
		public string REFERRALSTATUSID;
		public string ADDNEWRECORD;
		public string UPDATEITEM;
		public string ACTUALCOMPLETIONDATE;
		public string GOALTYPEID;
		public string OUTCOME;
		public string PROJECTEDCOMPLETIONDATE;
		public string TERM;
		public string INTERVENTIONTYPEID;
		public string ACTIVITYSUBTYPEID;
		public string COMPLETIONDATE;
		public string DUEDATE;
		public string MANAGEMENTSERVICETYPEID;
		public string AMOUNT;
		public string BASEUOMID;
		public string BILLABLE;
		public string TOTAL;
		public string UNITQUANTITY;
		public string ACTIVITYTYPE;
		public string ASSIGNEDTEAM;
		public string ASSIGNEDUSER;
		public string CALCULATE;
		public string DAYSOPEN;
		public string DELIVERYAGE;
		public string EDC;
		public string FIRSTPOSTPARTUMVISIT;
		public string FIRSTPRENATALVISIT;
		public string GESTAGE;
		public string LMP;
		public string DELIVERYDATE;
		public string UPDATE;
		public string YEARS;
		public string MATERNICHEK;
		public string LINKPROBLEM;
		public string PLANNAME;
		public string STATUSHISTORY;
		public string SUBSCRIBERCOVERAGE;
		public string MONTHS;
		public string PRINT;
		public string OUTCOMES;
		public string RESTORE;
		public string POCDEFICITDUPLICATE;
		public string POCGOALDUPLICATE;
		public string POCINTERVENTIONDUPLICATE;
		public string WEBLINKS;
		public string FACILITYID;
		public string FACILITYLOCATIONID;
		public string FACILITYTYPEID;
		public string ASSIGNEDTEAMANDUSER;
		public string FACILITYLOCATIONNETWORKID;
		public string ACTIVITIES;
		public string ALLERGIES;
		public string LETTERQUEUE;
		public string MEASUREMENTS;
		public string MEDICATIONS;
		public string PROVIDERS;
		public string PROVIDERVENDORS;
		public string SUBSCRIBERNAME;
		public string SUMMARY;
		public string VENDORS;
		public string ENROLLMENT;
		public string LOGIC;
		public string ORGANIZATIONID;
		public string ADDNEW;
		public string ATTACHED;
		public string CMSTYPE;
		public string RESETUSERBUTTON;
		public string UPDATETRIGGERS;
		public string SAVETRIGGER;
		public string QUESTIONNAIRE;
		public string ADMINISTRATION;
		public string GROUP;
		public string OTHERPLAN;
		public string SSN;
		public string SUBSCRIBER;
		public string PRIMARYTYPE;
		public string CONTACTS;
		public string WEEKS;
		public string DAYS;
		public string CRTACTIVITY;
		public string ACTIVITY;
		public string FILTERBY;
		public string PRINTEDDATE;
		public string REPRINT;
		public string ERRENDDATE;
		public string FROMDATE;
		public string TODATE;
		public string PRIMARYPROBLEMID;
		public string CHANGECOVERAGE;
		public string RUNREPORT;
		public string CASESTARTDATE;
		public string COSTRPT;
		public string PATIENTINFORMATION;
		public string STREETADDR3;
		public string MODIFIEDBY;
		public string INTERVENTION;
		public string INTERVENTIONBILLING;
		public string INTERVENTIONS;
		public string POCDEFICITS;
		public string POCGOALS;
		public string ALTERNATEPATIENTID;
		public string CALLERPHONE;
		public string HOMEPHONENUMBER;
		public string WORKPHONENUMBER;
		public string OTHER;
		public string TIME;
		public string PHONE;
		public string MATERNICHEKCOMPLICATIONID;
		public string COMPLETEDBYUSERID;
		public string ITEMS;
		public string DONTUSEASSMT;
	}

		
}
