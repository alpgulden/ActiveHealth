using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	public class SubscriberMessages : Language
	{
		private static SubscriberMessages messageIDs;

		public SubscriberMessages() : base()
		{
		}

		public static SubscriberMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new SubscriberMessages();
				return messageIDs;
			}
		}

		public SubscriberMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string ALTSUBSCRIBERID;
		public string DATEOFBIRTH;
		public string EFFDATE;
		public string FIRSTNAME;
		public string LASTNAME;
		public string MIDDLEINITIAL;
		public string NAMEPREFIX;
		public string NAMESUFFIX;
		public string ORGANIZATION;
		public string SOCIALSECURITY;
		public string TERMDATE;
	}
}
