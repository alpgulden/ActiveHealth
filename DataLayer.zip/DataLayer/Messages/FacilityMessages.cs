using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	[LanguageTable("Message", "MsgID", "LangID", "Text")]
	public class FacilityMessages : BaseMessages
	{
		
		public FacilityMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string ADDEDONFLY;
		public string ALTERNATEID;
		public string DATEACTIVE;
		public string FACILITYID;
		public string FACILITYTYPE;
		public string FEDERALTAXID;
		public string MEDICAREID;
		public string UPIN;
		public string FACILITYFOCUSID;
		public string FACILITYFOCUSTYPE;
		public string FACILITYLOCATIONID;
		public string FACILITYINFO;
		public string LOCATIONID;
		public string DATEINACTIVE;
		public string DATECREATED;
		public string SELECT;
		public string FACILITYLOCATIONSERVICEID;
		public string FACILITYLOCSERVICETYPE;
		public string SERVICE;
		public string SERVICECODE;
		public string LOCATIONS;
		public string FACILITYTYPEDESC;
		public string FACILITYTYPECODES;
		public string FACILITYTYPECODE;
		public string TYPEINFORMATION;
		public string NETWORKS;
		public string FOCUS;
		public string NOTES;
		public string NETWORKTYPES;
		public string FOCUSTYPE;
		public string GROUPPRACTICETYPES;
		public string FACILITYTYPES;
		public string SEARCHBY;
		public string OUTOFPOCKETFAMILY;
		public string FACILITYLOCATIONNETWORKID;
		public string SERVICELOCATION;
		public string SPECIFIEDNETWORK;
		public string ALLNETWORKS;
		public string STATUS;
		public string NETWORKID;
		public string NULL;
		public string FAXNUMBER;
		public string FACILITYTYPEID;
		public string FOCUSTITLE;
		public string SAVE;
		public string INACTIVATE;
		public string ADDLOCATION;
		public string SERVICETITLE;
		public string NETWORKTITLE;
		public string ASOFDATE;
		public string COPYFROMSERVICE;
		public string STATUSCHANGEDATE;
		public string CONTACTS;
		public string NETWORKNAME;
		public string NETWORKTYPE;
		public string NETWORKADDRESS;
		public string SELECTFACSERV;
		public string ERRTERMDATE;
		public string NEXT;
		public string PREVIOUS;
		public string ZIP;
		public string SELECTNETWORK;
		public string FACILITYFORMTITLE;
		public string FACILITYLOCATIONFORMTITLE;
		public string FACILITYSEARCHTITLE;
		public string PROVIDERSAVEDMSG;
		public string LOCATIONLOWER;	

	}
}
