using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.Messages
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	public class OrgMessages : BaseMessages
	{	
		private static OrgMessages messageIDs;

		public OrgMessages() : base()
		{
		}

		public new static OrgMessages MessageIDs
		{
			get
			{
				if (messageIDs == null)
					messageIDs = new OrgMessages();
				return messageIDs;
			}
		}

		public OrgMessages(string langID): base(langID)
		{
			LoadFromTable();
		}

		public string ORGANIZATIONDETAIL;
		public string ORGNAME;
		public string ALTERNATEID;
		public string CONTRACTEFFDATE;
		public string RENEWALDATE;
		public string ORGTYPE;
		public string SYNONYMUSEDBYMULTI;
		public string ORGFOCUSHISTORY;
		public string COPYCHILDORG;
		public string CREATECHILDORG;
		public string CANTFINDRECORD;
		public string ORGFOCUSCODE;
		public string ORGANIZATION;
		public string SEARCHBY;
		public string SYNONYM;
		public string ORGANIZATIONS;
		public string AVAILFOCUSCODES;
		public string ORGFOCUS;
		public string PHONEEXT1;
		public string PHONEEXT2;
		public string PHONEEXT3;
		public string ERRTERMDATE;
		public string INVALIDTERMDATE;
		public string FOCUS;
		public string SEARCHCHILDORG;
		public string SYNONYMS;
		public string ISPRIMARY;
		public string LINKEDPLANS;
		public string LINKPLAN;
		public string ALTGROUPID;
		public string ALTPLANID;
		public string ALTPLANNAME;
		public string CHECKELIGIBILITY;
		public string DRGTYPE;
		public string ELIGIBILITYADDANYWAY;
		public string PAYORGROUPID;
		public string PLANNAME;
		public string GUIDELINESOURCESET;
		public string LOSREGION;
		public string LOSYEAR;
		public string DRGVERSION;
		public string LINKEDPLAN;
		public string PLANS;
		public string SAVEDMSGPLU;
		public string PRIMARYSYNONYMID;
		public string CONTACTS;
		public string HEDISPLANTYPEID;
		public string ALLENROLLMENTS;
		public string ENROLLED;
		public string ENROLLMENTS;
		public string ENROLLMENT;
		public string ALTERNATEENROLLMENTID;
		public string CASESOURCEID;
		public string INSUREDS;
		public string MONTH;
		public string RATIO;
		public string TOTALMEMBERS;
		public string SORGPLANLIVES;
		public string MEMBERLIVES;
		public string LISTMEMBERLIVES;
		public string YEAR;
		public string MEMBERS;
		public string AVENUMOFINS;
		public string CALCDEPRATIO;
		public string AVETOTALMEM;
		public string FROM;
		public string TO;
		public string ORGANIZATIONPAGETITLE;
		public string ENROLLMENTPAGETITLE;
		public string MANAGEMENTSVCPAGETITLE;
		public string CALCULATE;
	}
}
