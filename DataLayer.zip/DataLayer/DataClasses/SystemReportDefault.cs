using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SystemReportDefaults]
	/// </summary>
	[SPUpdate("usp_UpdateSystemReportDefault")]
	[SPLoad("usp_LoadSystemReportDefault")]
	[TableMapping("SystemReportDefaults","systemReportDefaultsID")]
	public class SystemReportDefault : BaseData
	{
		[ColumnMapping("SystemReportDefaultsID",(int)0)]
		private readonly int systemReportDefaultsID;
		[ColumnMapping("PatientsNoSSN")]
		private bool patientsNoSSN;
		[ColumnMapping("PatientsNODOB")]
		private bool patientsNODOB;
		[ColumnMapping("SubscribersNOSSN")]
		private bool subscribersNOSSN;
		[ColumnMapping("ClosedIPEventsNoDRG")]
		private bool closedIPEventsNoDRG;
		[ColumnMapping("ClosedIPEventsDRG468_469_470")]
		private bool closedipeventsdrg468469470;
		[ColumnMapping("ClosedIPEventsNoLOS")]
		private bool closedIPEventsNoLOS;
		[ColumnMapping("ClosedEventsNoResolution")]
		private bool closedEventsNoResolution;
		[ColumnMapping("ClosedEventsNoSource")]
		private bool closedEventsNoSource;
		[ColumnMapping("ClosedIPEventsNoReview")]
		private bool closedIPEventsNoReview;
		[ColumnMapping("DuplicateStartDateEvents")]
		private bool duplicateStartDateEvents;
		[ColumnMapping("EventsRevDecDeny_or_ReferToPhys")]
		private bool eventsrevdecdenyOrRefertophys;
		[ColumnMapping("ClosedPhysRevMinutes0")]
		private bool closedPhysRevMinutes0;
		[ColumnMapping("ClosedEventsWithNoDx")]
		private bool closedEventsWithNoDx;
		[ColumnMapping("ActivitiesWithNoPCER")]
		private bool activitiesWithNoPCER;
		[ColumnMapping("ReferralsWithNoNumberofUnits")]
		private bool referralsWithNoNumberofUnits;
		[ColumnMapping("OpenCMSWithNoFutureActivities")]
		private bool openCMSWithNoFutureActivities;
		[ColumnMapping("CMS_EventsWithNoFacilities")]
		private bool cmsEventswithnofacilities;
		[ColumnMapping("CMS_EventsWithNoProvider")]
		private bool cmsEventswithnoprovider;
		[ColumnMapping("PhysicianReviewWithNoReason")]
		private bool physicianReviewWithNoReason;
		[ColumnMapping("ReferralWithNoReferTo")]
		private bool referralWithNoReferTo;
		[ColumnMapping("ReferralWithNoPCP")]
		private bool referralWithNoPCP;
		[ColumnMapping("MultiplePatientsSameSSN")]
		private bool multiplePatientsSameSSN;
		[ColumnMapping("MultipleSubscribersSameSSN")]
		private bool multipleSubscribersSameSSN;
		[ColumnMapping("OpenEventNoFutureActivities")]
		private bool openEventNoFutureActivities;
		[ColumnMapping("OpenEventWithEndDate")]
		private bool openEventWithEndDate;
		[ColumnMapping("ClosedEventInvalidProvider")]
		private bool closedEventInvalidProvider;
		[ColumnMapping("ClosedEventInvalidFacility")]
		private bool closedEventInvalidFacility;
		[ColumnMapping("ClosedEventNoEndDate")]
		private bool closedEventNoEndDate;
		[ColumnMapping("ClosedEventNoType")]
		private bool closedEventNoType;
		[ColumnMapping("ClosedIPEventStartEqualsEnd")]
		private bool closedIPEventStartEqualsEnd;
		[ColumnMapping("ClosedEventWithReviewReqNoRevDec")]
		private bool closedEventWithReviewReqNoRevDec;
		[ColumnMapping("ClosedIPEventActualLOStoobig")]
		private bool closedIPEventActualLOStoobig;
		[ColumnMapping("ClosedEventRequestedAmounttoobig")]
		private bool closedEventRequestedAmounttoobig;
		[ColumnMapping("EventNoStartDate")]
		private bool eventNoStartDate;
		[ColumnMapping("EventStartDateAfterSORGTermDate")]
		private bool eventStartDateAfterSORGTermDate;
		[ColumnMapping("EventRequestedAmount0")]
		private bool eventRequestedAmount0;	
		[ColumnMapping("EventStartDateBeforePatientDOB")]
		private bool eventStartDateBeforePatientDOB;
		[ColumnMapping("EventBlankReviewRequestUnitCost")]
		private bool eventBlankReviewRequestUnitCost;
		[ColumnMapping("EventReviewDecisionAmount0")]
		private bool eventReviewDecisionAmount0;
		[ColumnMapping("ClosedPhysicianReviewNoDecision")]
		private bool closedPhysicianReviewNoDecision;
		[ColumnMapping("ReferralWithNoReferredFromInfo")]
		private bool referralWithNoReferredFromInfo;
		[ColumnMapping("PatientWithUnknownGender")]
		private bool patientWithUnknownGender;
		[ColumnMapping("PatientWithNoFirstName")]
		private bool patientWithNoFirstName;
		[ColumnMapping("PatientWithNoLastName")]
		private bool patientWithNoLastName;
		[ColumnMapping("PhysicianReviewWithNoRequestDetail")]
		private bool physicianReviewWithNoRequestDetail;
	
		private static SystemReportDefault instance = null;

		private SystemReportDefault()
		{
			this.systemReportDefaultsID = 1;
		}

		public static SystemReportDefault GetInstance
		{
			get
			{
				if(instance == null)
					instance = new SystemReportDefault();
				if(instance.Load())
					return instance;
				else
					throw new Exception("System Report Record [SystemReportDefault] PK[1] is not present.");
			}
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int SystemReportDefaultsID
		{
			get { return this.systemReportDefaultsID; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool PatientsNoSSN
		{
			get { return this.patientsNoSSN; }
			set { this.patientsNoSSN = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool PatientsNODOB
		{
			get { return this.patientsNODOB; }
			set { this.patientsNODOB = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool SubscribersNOSSN
		{
			get { return this.subscribersNOSSN; }
			set { this.subscribersNOSSN = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedIPEventsNoDRG
		{
			get { return this.closedIPEventsNoDRG; }
			set { this.closedIPEventsNoDRG = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Closedipeventsdrg468469470
		{
			get { return this.closedipeventsdrg468469470; }
			set { this.closedipeventsdrg468469470 = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedIPEventsNoLOS
		{
			get { return this.closedIPEventsNoLOS; }
			set { this.closedIPEventsNoLOS = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedEventsNoResolution
		{
			get { return this.closedEventsNoResolution; }
			set { this.closedEventsNoResolution = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedEventsNoSource
		{
			get { return this.closedEventsNoSource; }
			set { this.closedEventsNoSource = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedIPEventsNoReview
		{
			get { return this.closedIPEventsNoReview; }
			set { this.closedIPEventsNoReview = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool DuplicateStartDateEvents
		{
			get { return this.duplicateStartDateEvents; }
			set { this.duplicateStartDateEvents = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool EventsrevdecdenyOrRefertophys
		{
			get { return this.eventsrevdecdenyOrRefertophys; }
			set { this.eventsrevdecdenyOrRefertophys = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedPhysRevMinutes0
		{
			get { return this.closedPhysRevMinutes0; }
			set { this.closedPhysRevMinutes0 = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedEventsWithNoDx
		{
			get { return this.closedEventsWithNoDx; }
			set { this.closedEventsWithNoDx = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ActivitiesWithNoPCER
		{
			get { return this.activitiesWithNoPCER; }
			set { this.activitiesWithNoPCER = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReferralsWithNoNumberofUnits
		{
			get { return this.referralsWithNoNumberofUnits; }
			set { this.referralsWithNoNumberofUnits = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool OpenCMSWithNoFutureActivities
		{
			get { return this.openCMSWithNoFutureActivities; }
			set { this.openCMSWithNoFutureActivities = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool CmsEventswithnofacilities
		{
			get { return this.cmsEventswithnofacilities; }
			set { this.cmsEventswithnofacilities = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool CmsEventswithnoprovider
		{
			get { return this.cmsEventswithnoprovider; }
			set { this.cmsEventswithnoprovider = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool PhysicianReviewWithNoReason
		{
			get { return this.physicianReviewWithNoReason; }
			set { this.physicianReviewWithNoReason = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReferralWithNoReferTo
		{
			get { return this.referralWithNoReferTo; }
			set { this.referralWithNoReferTo = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReferralWithNoPCP
		{
			get { return this.referralWithNoPCP; }
			set { this.referralWithNoPCP = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool MultiplePatientsSameSSN
		{
			get { return this.multiplePatientsSameSSN; }
			set { this.multiplePatientsSameSSN = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool MultipleSubscribersSameSSN
		{
			get { return this.multipleSubscribersSameSSN; }
			set { this.multipleSubscribersSameSSN = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool OpenEventNoFutureActivities
		{
			get { return this.openEventNoFutureActivities; }
			set { this.openEventNoFutureActivities = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool OpenEventWithEndDate
		{
			get { return this.openEventWithEndDate; }
			set { this.openEventWithEndDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedEventInvalidProvider
		{
			get { return this.closedEventInvalidProvider; }
			set { this.closedEventInvalidProvider = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedEventInvalidFacility
		{
			get { return this.closedEventInvalidFacility; }
			set { this.closedEventInvalidFacility = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedEventNoEndDate
		{
			get { return this.closedEventNoEndDate; }
			set { this.closedEventNoEndDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedEventNoType
		{
			get { return this.closedEventNoType; }
			set { this.closedEventNoType = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedIPEventStartEqualsEnd
		{
			get { return this.closedIPEventStartEqualsEnd; }
			set { this.closedIPEventStartEqualsEnd = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedEventWithReviewReqNoRevDec
		{
			get { return this.closedEventWithReviewReqNoRevDec; }
			set { this.closedEventWithReviewReqNoRevDec = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedIPEventActualLOStoobig
		{
			get { return this.closedIPEventActualLOStoobig; }
			set { this.closedIPEventActualLOStoobig = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedEventRequestedAmounttoobig
		{
			get { return this.closedEventRequestedAmounttoobig; }
			set { this.closedEventRequestedAmounttoobig = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool EventNoStartDate
		{
			get { return this.eventNoStartDate; }
			set { this.eventNoStartDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool EventStartDateAfterSORGTermDate
		{
			get { return this.eventStartDateAfterSORGTermDate; }
			set { this.eventStartDateAfterSORGTermDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool EventRequestedAmount0
		{
			get { return this.eventRequestedAmount0; }
			set { this.eventRequestedAmount0 = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool EventStartDateBeforePatientDOB
		{
			get { return this.eventStartDateBeforePatientDOB; }
			set { this.eventStartDateBeforePatientDOB = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool EventBlankReviewRequestUnitCost
		{
			get { return this.eventBlankReviewRequestUnitCost; }
			set { this.eventBlankReviewRequestUnitCost = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool EventReviewDecisionAmount0
		{
			get { return this.eventReviewDecisionAmount0; }
			set { this.eventReviewDecisionAmount0 = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClosedPhysicianReviewNoDecision
		{
			get { return this.closedPhysicianReviewNoDecision; }
			set { this.closedPhysicianReviewNoDecision = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReferralWithNoReferredFromInfo
		{
			get { return this.referralWithNoReferredFromInfo; }
			set { this.referralWithNoReferredFromInfo = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool PatientWithUnknownGender
		{
			get { return this.patientWithUnknownGender; }
			set { this.patientWithUnknownGender = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool PatientWithNoFirstName
		{
			get { return this.patientWithNoFirstName; }
			set { this.patientWithNoFirstName = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool PatientWithNoLastName
		{
			get { return this.patientWithNoLastName; }
			set { this.patientWithNoLastName = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool PhysicianReviewWithNoRequestDetail
		{
			get { return this.physicianReviewWithNoRequestDetail; }
			set { this.physicianReviewWithNoRequestDetail = value; }
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		private bool Load()
		{
			bool result = true;
			try
			{
				result = base.Load(systemReportDefaultsID);
			}
			catch(Exception ex)
			{
				result = false;
			}
			return result;
		}
	}
}
