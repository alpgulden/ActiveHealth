using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{	
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PackingListItem]
	/// </summary>
	
	[SPAutoGen("usp_GetAllPackingListItemsByActive","SelectAllByGivenArgsOrderBy.sptpl","sortOrder, ASC, active")]
	[SPAutoGen("usp_GetAllPackingListItems","SelectAll.sptpl","")]
	[SPAutoGen("usp_LoadAllPackingListItemsByCMSTypeIdActive","SelectAllByGivenArgs.sptpl","cMSTypeId, active")]
	[SPInsert("usp_InsertPackingListItem")]
	[SPUpdate("usp_UpdatePackingListItem")]
	[SPDelete("usp_DeletePackingListItem")]
	[SPLoad("usp_LoadPackingListItem")]
	[TableMapping("PackingListItem","packingListItemId")]
	public class PackingListItem : BaseData
	{
		[NonSerialized]
		private PackingListItemCollection parentPackingListItemCollection;
		[ColumnMapping("PackingListItemId",StereoType=DataStereoType.FK)]
		private int packingListItemId;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("SortOrder")]
		private int sortOrder;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CMSTypeId",StereoType=DataStereoType.FK)]
		private int cMSTypeId;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		private PackingListItemTriggerCollection packingListItemTriggers;

		private bool attached;
	
		public PackingListItem()
		{
			this.PrototypeInstance = true;	// will force "N/A" in CMSType combo.
			this.CMSTypeId = 0;
		}

		public PackingListItem(bool initNew) : this()
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[FieldDescription("@ID@")]
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PackingListItemId
		{
			get { return this.packingListItemId; }
			set { this.packingListItemId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=200)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[FieldDescription("@ACTIVE@")]
		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[FieldDescription("@CMSTYPE@")]
		[FieldValuesMember("LookupOf_CMSTypeId", "CMSTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int CMSTypeId
		{
			get { return this.cMSTypeId; }
			set { this.cMSTypeId = value; }
		}

		[FieldDescription("@ATTACHED@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool Attached
		{
			get { return this.attached; }
			set { this.attached = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int packingListItemId)
		{
			return base.Load(packingListItemId);
		}

		/// <summary>
		/// Parent PackingListItemCollection that contains this element
		/// </summary>
		public PackingListItemCollection ParentPackingListItemCollection
		{
			get
			{
				return this.parentPackingListItemCollection;
			}
			set
			{
				this.parentPackingListItemCollection = value; // parent is set when added to a collection
			}
		}

		public bool TriggerExists(PackingListItemTrigger trigger)
		{
			return trigger.GetPLItemTriggerByPLItemIdMorgOrgSorgPlanEnrollment(this.packingListItemId, trigger);
		}

		#region PackingListItemTriggers
		/// <summary>
		/// Child PackingListItemTriggers mapped to related rows of table PackingListItemTrigger where [PackingListItemId] = [PackingListItemId]
		/// </summary>
		[SPLoadChild("usp_LoadPackingListItemPackingListItemTrigger", "packingListItemId")]
		public PackingListItemTriggerCollection PackingListItemTriggers
		{
			get { return this.packingListItemTriggers; }
			set
			{
				this.packingListItemTriggers = value;
				if (value != null)
					value.ParentPackingListItem = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PackingListItemTriggers collection
		/// </summary>
		public void LoadPackingListItemTriggers(bool forceReload)
		{
			this.packingListItemTriggers = (PackingListItemTriggerCollection)PackingListItemTriggerCollection.LoadChildCollection("PackingListItemTriggers", this, typeof(PackingListItemTriggerCollection), packingListItemTriggers, forceReload, null);
		}

		/// <summary>
		/// Saves the PackingListItemTriggers collection
		/// </summary>
		public void SavePackingListItemTriggers()
		{
			PackingListItemTriggerCollection.SaveChildCollection(this.packingListItemTriggers, true);
		}

		/// <summary>
		/// Synchronizes the PackingListItemTriggers collection
		/// </summary>
		public void SynchronizePackingListItemTriggers()
		{
			PackingListItemTriggerCollection.SynchronizeChildCollection(this.packingListItemTriggers, true);
		}
		#endregion

		public CMSTypeCollection LookupOf_CMSTypeId
		{
			get
			{
				if (this.PrototypeInstance)
				{
					CMSTypeCollection col = new CMSTypeCollection();
					CMSType t = new CMSType();
						t.CMSTypeID = 0;
						t.Description = "N/A";
					col.AddRecord(t);
					col.CopyElementsFrom(CMSTypeCollection.ActiveCMSTypes, true, false);
					return col;
				}
				else
					return CMSTypeCollection.ActiveCMSTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.active = true;
		}		
	}

	/// <summary>
	/// Strongly typed collection of PackingListItem objects
	/// </summary>
	[ElementType(typeof(PackingListItem))]
	public class PackingListItemCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		private CMS cMS;

		public ActiveAdvice.DataLayer.CMS CMS
		{
			get { return this.cMS; }
			set { this.cMS = value; }
		}
		
		[NonSerialized]
		private CollectionIndexer indexBy_PackingListItemId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PackingListItem elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPackingListItemCollection = this;
			else
				elem.ParentPackingListItemCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PackingListItem elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PackingListItem this[int index]
		{
			get
			{
				return (PackingListItem)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PackingListItem)oldValue, false);
			SetParentOnElem((PackingListItem)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllPackingListItemsForSelection(int maxRecords, int cMSTypeId, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadAllPackingListItemsByCMSTypeIdActive", maxRecords, this, false, cMSTypeId, active);
		}

		/// <summary>
		/// Hashtable based index on packingListItemId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PackingListItemId
		{
			get
			{
				if (this.indexBy_PackingListItemId == null)
					this.indexBy_PackingListItemId = new CollectionIndexer(this, new string[] { "packingListItemId" }, true);
				return this.indexBy_PackingListItemId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on packingListItemId fields returns the object.  Uses the IndexBy_PackingListItemId indexer.
		/// </summary>
		public PackingListItem FindBy(int packingListItemId)
		{
			return (PackingListItem)this.IndexBy_PackingListItemId.GetObject(packingListItemId);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllPackingListItemsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPackingListItemsByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared PackingListItemCollection which is cached in NSGlobal
		/// </summary>
		public static PackingListItemCollection ActivePackingListItems
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PackingListItemCollection col = (PackingListItemCollection)NSGlobal.EnsureCachedObject("ActivePackingListItems", typeof(PackingListItemCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllPackingListItemsByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PackingListItem elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PackingListItem)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();	
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllPackingListItems(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPackingListItems", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared PackingListItemCollection which is cached in NSGlobal
		/// </summary>
		public static PackingListItemCollection AllPackingListItems
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PackingListItemCollection col = (PackingListItemCollection)NSGlobal.EnsureCachedObject("AllPackingListItems", typeof(PackingListItemCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllPackingListItems(-1);
				}
				return col;
			}
			
		}

		public void ResetAttachedByTriggerSignature()
		{
			foreach (PackingListItem item in this)
				item.Attached = false;
		}

		public void ResetAttachedByTriggerSignature(PackingListItemTrigger trigger)
		{
			foreach (PackingListItem item in this)
				item.Attached = item.TriggerExists(trigger);
		}

		/// <summary>
		/// Looks up by packingListItemId and returns Description value.  Uses the IndexBy_PackingListItemId indexer.
		/// </summary>
		public string Lookup_DescriptionByPackingListItemId(int packingListItemId)
		{
			return this.IndexBy_PackingListItemId.LookupStringMember("Description", packingListItemId);
		}

		/// <summary>
		/// Looks up by packingListItemId and returns Active value.  Uses the IndexBy_PackingListItemId indexer.
		/// </summary>
		public bool Lookup_ActiveByPackingListItemId(int packingListItemId)
		{
			return (bool)this.IndexBy_PackingListItemId.LookupMember("Active", packingListItemId);
		}
//
//		/// <summary>
//		/// Executes a stored procedure.
//		/// </summary>
//		public int LoadAllPackingListItems(int maxRecords)
//		{
//			this.Clear();
//			return SqlData.SPExecReadCol("usp_GetAllPackingListItems", maxRecords, this, false);
//		}
	}
}
