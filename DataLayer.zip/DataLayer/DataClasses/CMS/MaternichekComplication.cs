using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [MaternichekComplication]
	/// </summary>
	[SPAutoGen("usp_GetAllMaternichekComplication","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetAllMaternichekComplicationByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertMaternichekComplication")]
	[SPUpdate("usp_UpdateMaternichekComplication")]
	[SPDelete("usp_DeleteMaternichekComplication")]
	[SPLoad("usp_LoadMaternichekComplication")]
	[TableMapping("MaternichekComplication","maternichekComplicationID")]
	public class MaternichekComplication : BaseLookupWithNote
	{
		[NonSerialized]
		private MaternichekComplicationCollection parentMaternichekComplicationCollection;
		[ColumnMapping("MaternichekComplicationID",(int)0)]
		private int maternichekComplicationID;
		[ColumnMapping("NotePad")]
		private string notePad;


		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		public MaternichekComplication()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int MaternichekComplicationID
		{
			get { return this.maternichekComplicationID; }
			set { this.maternichekComplicationID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent MaternichekComplicationCollection that contains this element
		/// </summary>
		public MaternichekComplicationCollection ParentMaternichekComplicationCollection
		{
			get
			{
				return this.parentMaternichekComplicationCollection;
			}
			set
			{
				this.parentMaternichekComplicationCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of MaternichekComplication objects
	/// </summary>
	[ElementType(typeof(MaternichekComplication))]
	public class MaternichekComplicationCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_MaternichekComplicationID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MaternichekComplication elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMaternichekComplicationCollection = this;
			else
				elem.ParentMaternichekComplicationCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MaternichekComplication elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MaternichekComplication this[int index]
		{
			get
			{
				return (MaternichekComplication)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MaternichekComplication)oldValue, false);
			SetParentOnElem((MaternichekComplication)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Hashtable based index on maternichekComplicationID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_MaternichekComplicationID
		{
			get
			{
				if (this.indexBy_MaternichekComplicationID == null)
					this.indexBy_MaternichekComplicationID = new CollectionIndexer(this, new string[] { "maternichekComplicationID" }, true);
				return this.indexBy_MaternichekComplicationID;
			}
			
		}

		/// <summary>
		/// Looks up by maternichekComplicationID and returns Description value.  Uses the IndexBy_MaternichekComplicationID indexer.
		/// </summary>
		public string Lookup_DescriptionByMaternichekComplicationID(int maternichekComplicationID)
		{
			return this.IndexBy_MaternichekComplicationID.LookupStringMember("Description", maternichekComplicationID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllMaternichekComplicationByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllMaternichekComplicationByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared MaternichekComplicationCollection which is cached in NSGlobal
		/// </summary>
		public static MaternichekComplicationCollection ActiveMaternichekComplications
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				MaternichekComplicationCollection col = (MaternichekComplicationCollection)NSGlobal.EnsureCachedObject("ActiveMaternichekComplications", typeof(MaternichekComplicationCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllMaternichekComplicationByActive(-1, true);
				}
				return col;
			}
			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllMaternichekComplication", -1, this, false);
		}
	}
}
