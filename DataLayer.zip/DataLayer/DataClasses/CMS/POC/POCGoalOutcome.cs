using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [POCGoalOutcome]
	/// </summary>
	[SPAutoGen("usp_SearchPOCGoalOutcomesByCodeDescriptionActive","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllPOCGoalOutcomesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllPOCGoalOutcomes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertPOCGoalOutcome")]
	[SPUpdate("usp_UpdatePOCGoalOutcome")]
	[SPDelete("usp_DeletePOCGoalOutcome")]
	[SPLoad("usp_LoadPOCGoalOutcome")]
	[TableMapping("POCGoalOutcome","goalOutcomeId")]
	public class POCGoalOutcome : BaseLookupWithSubCodeSTR
	{
		[NonSerialized]
		private POCGoalOutcomeCollection parentPOCGoalOutcomeCollection;
		[ColumnMapping("GoalOutcomeId",StereoType=DataStereoType.FK)]
		private int goalOutcomeId;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("CodeStatus")]
		private string codeStatus;
		
		public static string OPEN = "POCGOOP";			//code for Open
		public static string COMPLETE = "POCGOCML";		//code for Complete

		public POCGoalOutcome()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GoalOutcomeId
		{
			get { return this.goalOutcomeId; }
			set { this.goalOutcomeId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldValuesMember("LookupOf_SubCodeStr", "Code", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, IsRequired=true)]
		public override string SubCodeStr
		{
			get { return this.codeStatus; }
			set { this.codeStatus = value; }
		}


		/// <summary>
		/// Parent POCGoalOutcomeCollection that contains this element
		/// </summary>
		public POCGoalOutcomeCollection ParentPOCGoalOutcomeCollection
		{
			get
			{
				return this.parentPOCGoalOutcomeCollection;
			}
			set
			{
				this.parentPOCGoalOutcomeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int goalOutcomeId)
		{
			return base.Load(goalOutcomeId);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool SearchPOCGoalOutcomesByCodeDescriptionActive(string code, string description, bool active)
		{
			return SqlData.SPExecReadObj("usp_SearchPOCGoalOutcomesByCodeDescriptionActive", this, false, code, description, active);
		}

		public FunctionalStatusCollection LookupOf_SubCodeStr
		{
			get
			{
				return FunctionalStatusCollection.AllFunctionalStatusCodes; // Acquire a shared instance from the static member of collection
			}
			set
			{}
		}
	}

	/// <summary>
	/// Strongly typed collection of POCGoalOutcome objects
	/// </summary>
	[ElementType(typeof(POCGoalOutcome))]
	public class POCGoalOutcomeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_GoalOutcomeId;
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(POCGoalOutcome elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPOCGoalOutcomeCollection = this;
			else
				elem.ParentPOCGoalOutcomeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (POCGoalOutcome elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public POCGoalOutcome this[int index]
		{
			get
			{
				return (POCGoalOutcome)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((POCGoalOutcome)oldValue, false);
			SetParentOnElem((POCGoalOutcome)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllPOCGoalOutcomesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPOCGoalOutcomesByActive", maxRecords, this, false, new object[]{active});
		}

		/// <summary>
		/// Accessor to a shared POCGoalOutcomeCollection which is cached in NSGlobal
		/// </summary>
		public static POCGoalOutcomeCollection ActivePOCGoalOutcomes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				POCGoalOutcomeCollection col = (POCGoalOutcomeCollection)NSGlobal.EnsureCachedObject("ActivePOCGoalOutcomes", typeof(POCGoalOutcomeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllPOCGoalOutcomesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns ID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_IDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("ID", code);
		}

		/// <summary>
		/// Hashtable based index on goalOutcomeId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_GoalOutcomeId
		{
			get
			{
				if (this.indexBy_GoalOutcomeId == null)
					this.indexBy_GoalOutcomeId = new CollectionIndexer(this, new string[] { "goalOutcomeId" }, true);
				return this.indexBy_GoalOutcomeId;
			}
			
		}

		/// <summary>
		/// Looks up by goalOutcomeId and returns CodeStatus value.  Uses the IndexBy_GoalOutcomeId indexer.
		/// </summary>
		public string Lookup_CodeStatusByGoalOutcomeId(int goalOutcomeId)
		{
			return this.IndexBy_GoalOutcomeId.LookupStringMember("CodeStatus", goalOutcomeId);
		}

		/// <summary>
		/// Looks up by goalOutcomeId and returns Code value.  Uses the IndexBy_GoalOutcomeId indexer.
		/// </summary>
		public string Lookup_CodeByGoalOutcomeId(int goalOutcomeId)
		{
			return this.IndexBy_GoalOutcomeId.LookupStringMember("Code", goalOutcomeId);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllPOCGoalOutcomes", -1, this, false);
		}

	}
}
