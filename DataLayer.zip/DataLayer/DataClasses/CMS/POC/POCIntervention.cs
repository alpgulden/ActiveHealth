using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [POCIntervention]
	/// </summary>
	[SPAutoGen("usp_LoadAllInterventionsByCMSId", null, ManuallyManaged=true)]
	[SPInsert("usp_InsertPOCIntervention")]
	[SPUpdate("usp_UpdatePOCIntervention")]
	[SPDelete("usp_DeletePOCIntervention")]
	[SPLoad("usp_LoadPOCIntervention")]
	[TableMapping("POCIntervention","pOCInterventionID")]
	public class POCIntervention : BasePOC
	{
		[NonSerialized]
		private POCInterventionCollection parentPOCInterventionCollection;
		[ColumnMapping("POCInterventionID",StereoType=DataStereoType.FK)]
		private int pOCInterventionID;
		[ColumnMapping("GoalID")]
		private int goalID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("DueDate")]
		private DateTime dueDate;
		[ColumnMapping("AssignedUserID",StereoType=DataStereoType.FK)]
		private int assignedUserID;
		[ColumnMapping("AssignedTeamID",StereoType=DataStereoType.FK)]
		private int assignedTeamID;
		[ColumnMapping("InterventionTypeID",StereoType=DataStereoType.FK)]
		private int interventionTypeID;
		[ColumnMapping("Comment")]
		private string comment;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ActivityID",StereoType=DataStereoType.FK)]
		private int activityID;
		[ColumnMapping("ManagementServiceItemID")]
		private int managementServiceItemID;
		[ColumnMapping("InterventionAmount",StereoType=DataStereoType.FK)]
		private int interventionAmount;
		[ColumnMapping("BaseUOMID",StereoType=DataStereoType.FK)]
		private int baseUOMID;
		[ColumnMapping("ManagementServiceRate")]
		private Decimal managementServiceRate;
		[ColumnMapping("IsBillable")]
		private bool isBillable;
		[ColumnMapping("BillableAmount")]
		private Decimal billableAmount;
		[ColumnMapping("ConversionUnitOfMeasureID")]
		private int conversionUnitOfMeasureID;
		[ColumnMapping("CompletionID",StereoType=DataStereoType.FK)] // Status
		private int completionID;
		[ColumnMapping("CompletionDate")]
		private DateTime completionDate;
		[ColumnMapping("BaseAmount")]
		private Decimal baseAmount;
		[ColumnMapping("ExtendedAmount")]
		private Decimal extendedAmount;
		[ColumnMapping("BaseConversionMultiplier")]
		private Decimal baseConversionMultiplier;
		[ColumnMapping("BaseConversionDivider")]
		private Decimal baseConversionDivider;
		[ColumnMapping("ActivitySubTypeID",StereoType=DataStereoType.FK)]
		private int activitySubTypeID;
		[ColumnMapping("StatusChangedBy",StereoType=DataStereoType.FK)]
		private int statusChangedBy;
		[ColumnMapping("StatusDate")]
		private DateTime statusDate;
		[ColumnMapping("CompletedBy",StereoType=DataStereoType.FK)]
		private int completedBy;
		[ColumnMapping("CompletionTime")]
		private DateTime completionTime;

		private int activityPrimaryTypeID;				// Not in table.  Used to filter Intervention type
		private ManagementServiceItem managementServiceItem;
		private Activity activity;
		private bool updateActivity;  // checked within InternalSave to save Activity;

		private int deficitId; //ID of parent POCDefict;
		private string goalType; // Goal Type of parent Goal
		private string deficitType; // Deficit Type of parent Deficit

		public static string COMPLETE = "COMP"; // POCInterventionStatus code for Complete

		public enum DateType
		{
			Due				= 1,
			Completion		= 2
		}
	
		public POCIntervention()
		{
			this.activityPrimaryTypeID = 0;
			this.updateActivity = true;
		}

		public POCIntervention(bool initNew) : this()
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int POCInterventionID
		{
			get { return this.pOCInterventionID; }
			set { this.pOCInterventionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int GoalID
		{
			get { return this.goalID; }
			set { this.goalID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=500)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DUEDATE@")]
		public System.DateTime DueDate
		{
			get { return this.dueDate; }
			set { this.dueDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedUserID
		{
			get { return this.assignedUserID; }
			set { this.assignedUserID = value; }
		}

		[FieldDescription("@ASSIGNEDUSER@")]
		public string AssignedUserName
		{
			get { return AAUserCollection.AllUsers.Lookup_LoginNameByUserId(this.assignedUserID); }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedTeamID
		{
			get { return this.assignedTeamID; }
			set { this.assignedTeamID = value; }
		}

		[FieldDescription("@ASSIGNEDTEAM@")]
		public string AssignedTeamName
		{
			get { return TeamCollection.AllTeams.Lookup_CodeByTeamId(this.assignedTeamID); }
		}
		
		[FieldValuesMember("LookupOf_InterventionTypeID", "ActivityTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@INTERVENTIONTYPEID@")]
		public int InterventionTypeID
		{
			get { return this.interventionTypeID; }
			set { this.interventionTypeID = value; }
		}

		/// <summary>
		/// Activity Type for the activity type id set.
		/// </summary>
		public ActivityType ActivityType
		{
			get
			{
				if (this.interventionTypeID == 0)
					return null;
				else
					return ActivityTypeCollection.ActiveActivityTypes.FindBy(interventionTypeID);
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldValuesMember("LookupOf_ActivityPrimaryTypeID", "ActivityPrimaryTypeID", "Description")]
		[FieldDescription("@PRIMARYTYPE@")]
		public int ActivityPrimaryTypeID
		{
			get { return this.activityPrimaryTypeID; }
			set { this.activityPrimaryTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Comment
		{
			get { return this.comment; }
			set { this.comment = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ActivityID
		{
			get { return this.activityID; }
			set { this.activityID = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@AMOUNT@")]
		public int InterventionAmount
		{
			get { return this.interventionAmount; }
			set { this.interventionAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@BASEUOMID@")]
		public int BaseUOMID
		{
			get { return this.baseUOMID; }
			set { this.baseUOMID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal ManagementServiceRate
		{
			get { return this.managementServiceRate; }
			set { this.managementServiceRate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@BILLABLE@")]
		public bool IsBillable
		{
			get { return this.isBillable; }
			set { this.isBillable = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		[FieldDescription("@TOTAL@")]
		public decimal BillableAmount
		{
			get { return this.billableAmount; }
			set { this.billableAmount = value; }
		}

		
		[FieldValuesMember("LookupOf_CompletionID", "ActivityCompletionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@STATUS@")]
		public int CompletionID
		{
			get { return this.completionID; }
			set { this.completionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@COMPLETIONDATE@")]
		public System.DateTime CompletionDate
		{
			get { return this.completionDate; }
			set { this.completionDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@RATE@")]
		public decimal BaseAmount
		{
			get { return this.baseAmount; }
			set { this.baseAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public decimal ExtendedAmount
		{
			get { return this.extendedAmount; }
			set { this.extendedAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal BaseConversionMultiplier
		{
			get { return this.baseConversionMultiplier; }
			set { this.baseConversionMultiplier = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal BaseConversionDivider
		{
			get { return this.baseConversionDivider; }
			set { this.baseConversionDivider = value; }
		}

		[FieldValuesMember("LookupOf_ActivitySubTypeID", "ActivitySubtypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@ACTIVITYSUBTYPEID@")]
		public int ActivitySubTypeID
		{
			get { return this.activitySubTypeID; }
			set { this.activitySubTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StatusDate
		{
			get { return this.statusDate; }
			set { this.statusDate = value; }
		}

		[FieldValuesMember("LookupOf_ManagementServiceItemID", "ManagementServiceItemId", "ServiceTypeDescription")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@MANAGEMENTSERVICETYPEID@")]
		public int ManagementServiceItemID
		{
			get { return this.managementServiceItemID; }
			set { this.managementServiceItemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@UNITQUANTITY@")]
		public int ConversionUnitOfMeasureID
		{
			get { return this.conversionUnitOfMeasureID; }
			set { this.conversionUnitOfMeasureID = value; }
		}

		[FieldValuesMember("LookupOf_UserID", "UserId", "LoginName")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CompletedBy
		{
			get { return this.completedBy; }
			set { this.completedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CompletionTime
		{
			get { return this.completionTime; }
			set { this.completionTime = value; }
		}

		#region Fields for displaying parent Deficit/Goal objects
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DeficitId
		{
			get { return this.deficitId; }
			set { this.deficitId = value;}
		}

		public string DeficitType
		{
			get { return this.deficitType; }
			set { this.deficitType = value; }
		}

		[FieldDescription("@DEFICITTYPEID@")]
		public string DeficitTypeGridDisplay
		{
			get { return string.Format("{0}- {1}", this.deficitType, this.deficitId); }
		}

		public string GoalType
		{
			get { return this.goalType; }
			set { this.goalType = value; }
		}

		[FieldDescription("@GOALTYPEID@")]
		public string GoalTypeGridDisplay
		{
			get{ return string.Format("{0}- {1}", this.goalType, this.goalID); }
		}
		#endregion

		public ActiveAdvice.DataLayer.ManagementServiceItem ManagementServiceItem
		{
			get 
			{ 
				if (this.managementServiceItem == null)
					this.managementServiceItem = new ManagementServiceItem();
				return this.managementServiceItem; 
			}
			set 
			{ 
				if (value != null)
				{
					this.managementServiceItem = value; 

					this.BaseUOMID = value.BaseUnitOfMeasureId;
					this.conversionUnitOfMeasureID = value.ConversionUnitOfMeasureId;
					this.isBillable = value.Billable;
					this.managementServiceRate = value.Rate;
					this.baseConversionMultiplier = value.Multiplier;
					this.baseConversionDivider = value.Divider;
				}
			}
		}

		public new void Save()
		{
			Save(true); // Activity always needs to be in sync
		}
		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public void Save(bool updateActivity)
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			//this.SqlData.EnsureTransaction();
			try
			{
				this.updateActivity = updateActivity;
				base.Save();
				
				//this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				//this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int pOCInterventionID)
		{
			return base.Load(pOCInterventionID);
		}

		/// <summary>
		/// Parent POCInterventionCollection that contains this element
		/// </summary>
		public POCInterventionCollection ParentPOCInterventionCollection
		{
			get
			{
				return this.parentPOCInterventionCollection;
			}
			set
			{
				this.parentPOCInterventionCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			bool wasDirty = this.IsDirty;
			base.InternalSave();
			if(wasDirty && this.updateActivity && this.Activity != null)
			{
				UpdateActivity();
				this.activity.SqlData.Transaction = this.sqlData.Transaction;
				this.activity.Save(false);  // Do NOT save this Intervention from within Activity.
				this.updateActivity = false;
			}
			// Save the child collections here.
		}

		#region Lookups
		public ActivityTypeCollection LookupOf_InterventionTypeID
		{
			get
			{
				if (this.activityPrimaryTypeID == 0)
					return ActivityTypeCollection.ActiveActivityTypes; // Acquire a shared instance from the static member of collection
				else
				{	//return ActivityTypes for selected ActivityTypeID	
					return ActivityTypeCollection.GetActiveActivityTypes(this.activityPrimaryTypeID); // Acquire a shared instance from the static member of collection
				}
			}
		}
		
		public ActivityCompletionCollection LookupOf_CompletionID
		{
			get
			{
				return ActivityCompletionCollection.ActiveActivityCompletions; // Acquire a shared instance from the static member of collection
			}
		}

		public ActivitySubTypeCollection LookupOf_ActivitySubTypeID
		{
			get
			{
				if (this.ActivityType == null)
					return ActivitySubTypeCollection.ActiveActivitySubTypes; // Return all subtypes
				else
					return this.ActivityType.GetActiveSubTypes();
			}
		}

		public ActivityPrimaryTypeCollection LookupOf_ActivityPrimaryTypeID
		{
			get
			{
				return ActivityPrimaryTypeCollection.ActiveActivityPrimaryTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ManagementServiceItemCollection LookupOf_ManagementServiceItemID
		{
			get
			{
				try
				{
					
					ManagementService mgmtSvc = ParentPOCInterventionCollection.ParentPOCGoal.ParentPOCGoalCollection.ParentPOCDeficit.ParentPOCDeficitCollection.ParentCMS.Plan.ManagementService;
					mgmtSvc.LoadManagementServiceItems(false);
					return mgmtSvc.ManagementServiceItems;
				}
				catch
				{
					//System.Diagnostics.Debug.WriteLine(ex);
					return null;
				}
			}
		}
		#endregion

		public bool Calculate()
		{
			bool result;
			result = CalculateBaseAndExtendedAmount(this.interventionAmount, this.managementServiceRate, 
				(decimal)this.baseConversionDivider, (decimal)this.baseConversionMultiplier, 
				ref this.baseAmount, ref this.extendedAmount);
			if (this.isBillable)
				this.billableAmount = this.extendedAmount;
			return result;
		}

		
		/// <summary>
		/// Indicated if Intervention is Completed, by looking at [ActivityCompletion].Code
		/// </summary>
		public bool IsInterventionCompleted
		{
			get { return this.Fmt_CompletionID == ActivityCompletion.COMP; }
		}

		/// <summary>
		/// Indicates if Intervention is Open, by looking at [ActivityCompletion].CodeStatus
		/// </summary>
		/// <returns></returns>
		public bool IsInterventionOpen
		{
			get
			{
				return ActivityCompletionCollection.ActiveActivityCompletions.Lookup_CodeStatusByActivityCompletionID(this.completionID) == FunctionalStatus.OPEN;
			}
		}

		#region Formatters
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public string Fmt_CompletionID
		{
			get { return ActivityCompletionCollection.ActiveActivityCompletions.Lookup_CodeByActivityCompletionID(this.completionID); }
			set { this.completionID = ActivityCompletionCollection.ActiveActivityCompletions.Lookup_ActivityCompletionIDByCode(value); }
		}

		public string Fmt_BaseUOMID
		{
			get 
			{ 
				if(this.baseUOMID == 0)
					return "";
				BaseUnitOfMeasureCollection.ActiveBaseUnitOfMeasures.IndexBy_BaseUnitOfMeasureId.Rebuild();
				return BaseUnitOfMeasureCollection.ActiveBaseUnitOfMeasures.Lookup_DescriptionByBaseUnitOfMeasureId(this.baseUOMID); 
			}
		}
		
		public string Fmt_ConversionUnitOfMeasureDescriptionByID
		{
			get 
			{
				if(this.conversionUnitOfMeasureID == 0)
					return "";
				ConversionUnitOfMeasureCollection.ActiveConversionUnitOfMeasures.IndexBy_ConversionUnitOfMeasureId.Rebuild();
				return ConversionUnitOfMeasureCollection.ActiveConversionUnitOfMeasures.Lookup_DescriptionByConversionUnitOfMeasureId(this.conversionUnitOfMeasureID); 
			}
		}
		#endregion
		
		#region Activity
		/// <summary>
		/// Creation and save of Activity.
		/// If Activity already exist just retun it and do nothing.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="patCov"></param>
		public void CreateActivityAndSave(Patient patient, DataLayer.PatientCoverage patCov, CMS cMS)
		{
			if(this.Activity != null)
				return;
			Activity act = new Activity(patient, true);
				act.InterventionID = this.POCInterventionID;
				act.PlanId = cMS.Plan.PlanId;
				act.CMSID = cMS.CMSID;
				act.ProblemId = cMS.PrimaryProblemID;
			this.activity = act;
			UpdateActivity();
			this.SaveNewActivity(patCov);
		}

		private void UpdateActivity()
		{
			DateTime dt = DateTime.Now;

			/* Fields to Update
			 * - Primary Type
			 * - Type
			 * - Description
			 * - Due Date
			 * - Assigned Team/User
			 * - Completion Code
			 * - SubType
			 * - UserID
			 * - Done Date/Time
			 * - Comment
			 * - Management Service Item
			 * - Amount
			 * - Units
			 * - Rate
			 * - Rate Units
			 * - Total
			 * - Billable
			 * */
			this.activity.PrimaryType = this.activityPrimaryTypeID;
			this.activity.ActivityTypeID = this.InterventionTypeID;
			this.activity.ActivityDescription = this.description;
			this.activity.DueDate = (this.dueDate > DateTime.MinValue ? this.dueDate : dt);
			this.activity.AssignedTeamID = this.assignedTeamID;
			this.activity.AssignedUserID = this.assignedUserID;
			this.activity.ActivityCompletionID = this.completionID;
//				if(this.Fmt_CompletionID == POCIntervention.COMPLETE)
//					this.activity.CompletionDate = dt;
//				else
					this.activity.CompletionDate = this.completionDate;
			this.activity.ActivitySubtypeID = this.activitySubTypeID;
			this.activity.CompletionNote = this.comment;
			this.activity.ManagementServiceItemID = this.managementServiceItemID;
			if(this.managementServiceItem != null)
				this.activity.ManagementServiceTypeId = this.managementServiceItem.ManagementServiceTypeId;
			this.activity.ActivityAmount = this.interventionAmount;
			this.activity.BaseUOMId = this.baseUOMID;
			this.activity.ManagementServiceRate = this.managementServiceRate;
			this.activity.IsBillable = this.isBillable;
			this.activity.BillableAmount = this.billableAmount;
			this.activity.ConversionUOMId = this.conversionUnitOfMeasureID;
			this.activity.BaseAmount = this.baseAmount;
			this.activity.ExtendedAmount = this.extendedAmount;
			this.activity.BaseConvMult = this.baseConversionMultiplier;
			this.activity.BaseConvDiv = this.baseConversionDivider;
			
		}

		public ActiveAdvice.DataLayer.Activity Activity
		{
			get
			{ 
				if(this.ActivityID == 0)
					return null;
				if(this.activity == null)
				{
					Activity act = new Activity();
					act.Load(this.activityID);
					this.activity = act;
				}
				return this.activity; 
			}
		}

		/// <summary>
		/// Save NEW Activity ONLY. Not New Activity will be saved in InternalSave()
		/// </summary>
		/// <param name="patCov"></param>
		private void SaveNewActivity(DataLayer.PatientCoverage patCov)
		{
			if(this.activity != null)
			{
				this.activity.Save(patCov);
				this.activityID = this.activity.ActivityID;
				this.Update();
			}
		}

		public void UpdateAndSaveActivity()
		{
			this.UpdateActivity();
			this.activity.Save(false);  // No need to save this Intervention from within Activity. This Intervention will be saved from Parent CMS.
		}
		#endregion

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.assignedUserID = AASecurityHelper.GetUserId;	// per Issue 1140
		}

		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			base.FillFromReader (sourceRdr, ignoreAssignmentError);

			// set correct primary type filter combo for current activity type
			SyncronizePrimaryTypeByInterventionType();
			
		}

		public void SyncronizePrimaryTypeByInterventionType()
		{
			// set correct primary type filter combo for current activity type
			if (this.interventionTypeID != 0)
			{
				ActivityType atype = ActivityTypeCollection.ActiveActivityTypes.FindBy(this.interventionTypeID);
				if (atype != null)
					this.activityPrimaryTypeID = atype.ActivityPrimaryTypeID;
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of POCIntervention objects
	/// </summary>
	[ElementType(typeof(POCIntervention))]
	public class POCInterventionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass, ICollectionElementFilter
	{
		private bool fillExtraFields = false;
		protected POCInterventionFilter filterObject;

		#region To be Removed
		protected int openWithAll = -1;

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int OpenWithAll
		{
			get { return this.openWithAll; }
			set { this.openWithAll = value; }
		}
		#endregion

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(POCIntervention elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPOCInterventionCollection = this;
			else
				elem.ParentPOCInterventionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (POCIntervention elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public POCIntervention this[int index]
		{
			get
			{
				return (POCIntervention)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((POCIntervention)oldValue, false);
			SetParentOnElem((POCIntervention)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(POCIntervention elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((POCIntervention)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Returns true if the collection contains the given object
		/// </summary>
		public bool Contains(POCIntervention elem)
		{
			return List.Contains(elem);
		}

		/// <summary>
		/// Parent POCGoal that contains this collection
		/// </summary>
		public POCGoal ParentPOCGoal
		{
			get { return this.ParentDataObject as POCGoal; }
			set { this.ParentDataObject = value; /* parent is set when contained by a POCGoal */ }
		}

		public bool IsPOCInterventionTypeInCollection(POCIntervention intrv, int type)
		{
			return IsPOCInterventionTypeInCollection(intrv, type, 0);
		}

		public bool IsPOCInterventionTypeInCollection(POCIntervention intrv, int type, int parentGoalId)
		{
			bool result = false;
			if (this.Count == 0 || type == 0) 
				return false;

			for (int i = 0; i < this.Count; i++)
			{
				if ( !(this[i].Equals(intrv) || this[i].POCInterventionID == intrv.POCInterventionID))
				{
					bool sameGoal = true;
					if(parentGoalId > 0)
					{
						sameGoal = this[i].GoalID == parentGoalId;
					}
					if (this[i].InterventionTypeID == type && sameGoal)
						return true;
					else
						result = false;
				}
			}
			return result;
		}

		public bool AreAllInterventionsResolved()
		{
			if(this.Count == 0)
				return false;

			int index = 0;
			bool toContinue = true;

			while(toContinue && index < this.Count)
			{
				if(this[index].Fmt_CompletionID == ActivityCompletion.COMP)
					index++;
				else
					toContinue = false;
			}
			return toContinue;
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set manually during  CMS.LoadPOCInterventions() */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadAllInterventionsByCMSId(int maxRecords, int cmsid)
		{
			this.Clear();
			fillExtraFields = true;
			return SqlData.SPExecReadCol("usp_LoadAllInterventionsByCMSId", maxRecords, this, false, new object[] { cmsid });
			fillExtraFields = false;
		}

		protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);
			// Fill the extra members on question object with the data from reader
			if (fillExtraFields)
			{
				((POCIntervention)data).DeficitId = rdr.GetInt32(rdr.GetOrdinal("DeficitId"));
				((POCIntervention)data).DeficitType = rdr.GetString(rdr.GetOrdinal("DeficitType"));
				((POCIntervention)data).GoalType = rdr.GetString(rdr.GetOrdinal("GoalType"));
			}
		}

		public static POCInterventionCollection GetPOCInterventionCollectionByCMSId(int cmsId)
		{
			POCInterventionCollection col = new POCInterventionCollection();
			col.LoadAllInterventionsByCMSId(-1, cmsId);
			return col;
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		public ActiveAdvice.DataLayer.POCInterventionFilter FilterObject
		{
			get { return this.filterObject; }
			set { this.filterObject = value; }
		}

		#region ICollectionElementFilter Members

		public bool FilterElement(int index)
		{
			if(this.filterObject == null)
			{
				/* Simple filtering based on openWithAll flag.
				 * No filter object is needed for that.
				 * Used at DGIForm.aspx.cs */
				if(this.openWithAll == -1)
					return true;
				bool visible = (this.openWithAll == 0 ? false : true);
			
				if (this[index].IsInterventionOpen && visible)
					return true;
				if (!this[index].IsInterventionOpen && !visible)
					return true;

				return false;
			}

			this.filterObject.CompareToObject = this[index];
			return this.filterObject.IsCompareToObjectVisible;
		}

		#endregion
	}

	[TableMapping("POCIntervention","pOCInterventionID")]
	public class POCInterventionFilter : POCIntervention
	{
		private POCIntervention compareToObject;
		private POCIntervention.DateType dateType;

		private DateTime filterDateFrom;
		private DateTime filterDateTo;	

		public POCInterventionFilter()
		{
		}

		public POCInterventionFilter(POCIntervention compareToObject)
		{
			this.compareToObject = compareToObject;
		}

		public ActiveAdvice.DataLayer.POCIntervention CompareToObject
		{
			get { return this.compareToObject; }
			set { this.compareToObject = value; }
		}

		public ActiveAdvice.DataLayer.POCIntervention.DateType DateType
		{
			get { return this.dateType; }
			set { this.dateType = value; }
		}

		[FieldValuesMember("LookupOf_openWithAll")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true, ValueForNull=(int)-1)]
		[FieldDescription("@STATUS@")]
		public override int OpenWithAll
		{
			get { return this.openWithAll; }
			set { this.openWithAll = value; }
		}

		[FieldDescription("@FROMDATE@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime FilterDateFrom
		{
			get { return this.filterDateFrom; }
			set { this.filterDateFrom = value; }
		}

		[FieldDescription("@TODATE@")]
		[ValidatorMember("Vld_FilterDateTo")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime FilterDateTo
		{
			get { return this.filterDateTo; }
			set { this.filterDateTo = value; }
		}
		
		#region Compare methods
		private bool IsTypeEqual
		{
			get
			{
				if(this.InterventionTypeID == 0)
					return true;
				return this.compareToObject.InterventionTypeID == this.InterventionTypeID;
			}
		}

		private bool IsStatusEqual
		{
			get
			{
				if(this.CompletionID == 0)
					return true;
				return this.compareToObject.CompletionID == this.CompletionID;
			}
		}

		private bool IsCompletedByEqual
		{
			get
			{
				if(this.CompletedBy == 0)
					return true;
				return this.compareToObject.CompletedBy == this.CompletedBy;
			}
		}

		private bool IsBilableEqual
		{
			get
			{
				if(!this.IsInterventionCompleted)
					return true; // IsBillable flag can ONLY be set on Completed Intervention
				return this.compareToObject.IsBillable == this.IsBillable;
			}
		}

		private bool IsDateEqual
		{
			get
			{
				if(this.filterDateFrom > this.filterDateTo)
					return true;
				if(this.dateType == POCIntervention.DateType.Due)
				{
					return this.compareToObject.DueDate >= this.filterDateFrom && 
						(this.filterDateTo > DateTime.MinValue && this.compareToObject.DueDate <= this.filterDateTo 
						 || this.filterDateTo == DateTime.MinValue);
				}
				else if(this.dateType == POCIntervention.DateType.Completion)
				{
					return this.compareToObject.CompletionDate >= this.filterDateFrom && 
						(this.filterDateTo > DateTime.MinValue && this.compareToObject.CompletionDate <= this.filterDateTo
						 || this.filterDateTo == DateTime.MinValue);
				}
				return true;
			}
		}

		private bool IsVisibleByActiveWithAll
		{
			get
			{
				if(this.openWithAll == -1)
					return true;

				bool visible = this.openWithAll == 1;
				bool isInterventionOpen = this.compareToObject.IsInterventionOpen;
			
				if (isInterventionOpen && visible)
					return true;
				return !isInterventionOpen && !visible;
			}
		}
		#endregion

		public bool IsCompareToObjectVisible
		{
			get
			{
				if(this.compareToObject == null)
					return true;
				return IsTypeEqual && IsStatusEqual && IsCompletedByEqual 
					&& IsBilableEqual && IsDateEqual && IsVisibleByActiveWithAll;
			}
		}

		[GenericScript("Vld_FilterDateTo", "@FilterDateTo@ != null && @FilterDateTo@ >= @FilterDateFrom@;")]
		public string Vld_FilterDateTo
		{
			get
			{
				return Messages.CMSMessages.MessageIDs.ERRENDDATE; // return warning prompt message or the warning in advance to be used by client validators
			}
			set {}
		}

	}
}
