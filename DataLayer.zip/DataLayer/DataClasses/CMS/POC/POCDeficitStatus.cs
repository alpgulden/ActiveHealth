using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [POCDeficitStatus]
	/// </summary>
	[SPAutoGen("usp_SearchPOCDeficitStatusesByCodeDescriptionActive","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllPOCDeficitStatusesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllPOCDeficitStatuses","SelectAll.sptpl","")]
	[SPInsert("usp_InsertPOCDeficitStatus")]
	[SPUpdate("usp_UpdatePOCDeficitStatus")]
	[SPDelete("usp_DeletePOCDeficitStatus")]
	[SPLoad("usp_LoadPOCDeficitStatus")]
	[TableMapping("POCDeficitStatus","deficitStatusId")]
	public class POCDeficitStatus : BaseLookupWithSubCodeSTR
	{
		[NonSerialized]
		private POCDeficitStatusCollection parentPOCDeficitStatusCollection;
		[ColumnMapping("DeficitStatusId",StereoType=DataStereoType.FK)]
		private int deficitStatusId;
		[ColumnMapping("CodeStatus")]					  
			private string codeStatus;
		[ColumnMapping("NotePad")]
		private string notePad;

		public static string OPEN = "OPEN";		// code for Open Status
		public static string CLOSED = "COMPL";	// cose for Completed Status
	
		public POCDeficitStatus()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int DeficitStatusId
		{
			get { return this.deficitStatusId; }
			set { this.deficitStatusId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldValuesMember("LookupOf_SubCodeStr", "Code", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, IsRequired=true)]
		public override string SubCodeStr
		{
			get { return this.codeStatus; }
			set { this.codeStatus = value; }
		}

		/// <summary>
		/// Parent POCDeficitStatusCollection that contains this element
		/// </summary>
		public POCDeficitStatusCollection ParentPOCDeficitStatusCollection
		{
			get
			{
				return this.parentPOCDeficitStatusCollection;
			}
			set
			{
				this.parentPOCDeficitStatusCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int deficitStatusId)
		{
			return base.Load(deficitStatusId);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool SearchPOCDeficitStatusesByCodeDescriptionActive(string code, string description, bool active)
		{
			return SqlData.SPExecReadObj("usp_SearchPOCDeficitStatusesByCodeDescriptionActive", this, false, code, description, active);
		}

		public FunctionalStatusCollection LookupOf_SubCodeStr
		{
			get
			{
				return FunctionalStatusCollection.AllFunctionalStatusCodes; // Acquire a shared instance from the static member of collection
			}
			set
			{}
		}
	}

	/// <summary>
	/// Strongly typed collection of POCDeficitStatus objects
	/// </summary>
	[ElementType(typeof(POCDeficitStatus))]
	public class POCDeficitStatusCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_DeficitStatusId;
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(POCDeficitStatus elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPOCDeficitStatusCollection = this;
			else
				elem.ParentPOCDeficitStatusCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (POCDeficitStatus elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public POCDeficitStatus this[int index]
		{
			get
			{
				return (POCDeficitStatus)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((POCDeficitStatus)oldValue, false);
			SetParentOnElem((POCDeficitStatus)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllPOCDeficitStatusesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPOCDeficitStatusesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared POCDeficitStatusCollection which is cached in NSGlobal
		/// </summary>
		public static POCDeficitStatusCollection ActivePOCDeficitStatuses
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				POCDeficitStatusCollection col = (POCDeficitStatusCollection)NSGlobal.EnsureCachedObject("ActivePOCDeficitStatuses", typeof(POCDeficitStatusCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllPOCDeficitStatusesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns DeficitStatusId value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_DeficitStatusIdByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("DeficitStatusId", code);
		}

		/// <summary>
		/// Hashtable based index on deficitStatusId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_DeficitStatusId
		{
			get
			{
				if (this.indexBy_DeficitStatusId == null)
					this.indexBy_DeficitStatusId = new CollectionIndexer(this, new string[] { "deficitStatusId" }, true);
				return this.indexBy_DeficitStatusId;
			}
			
		}

		/// <summary>
		/// Looks up by deficitStatusId and returns Code value.  Uses the IndexBy_DeficitStatusId indexer.
		/// </summary>
		public string Lookup_CodeByDeficitStatusId(int deficitStatusId)
		{
			return this.IndexBy_DeficitStatusId.LookupStringMember("Code", deficitStatusId);
		}

		/// <summary>
		/// Looks up by deficitStatusId and returns CodeStatus value.  Uses the IndexBy_DeficitStatusId indexer.
		/// </summary>
		public string Lookup_CodeStatusByDeficitStatusId(int deficitStatusId)
		{
			return this.IndexBy_DeficitStatusId.LookupStringMember("CodeStatus", deficitStatusId);
		}

		public override void LoadAll()
		{			
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllPOCDeficitStatuses", -1, this, false);
		}
	}
}
