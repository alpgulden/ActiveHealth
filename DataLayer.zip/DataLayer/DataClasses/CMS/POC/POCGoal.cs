using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [POCGoal]
	/// </summary>
	[SPInsert("usp_InsertPOCGoal")]
	[SPUpdate("usp_UpdatePOCGoal")]
	[SPDelete("usp_DeletePOCGoal")]
	[SPLoad("usp_LoadPOCGoal")]
	[TableMapping("POCGoal","goalId")]
	public class POCGoal : BaseData
	{
		[NonSerialized]
		private POCGoalCollection parentPOCGoalCollection;
		[ColumnMapping("GoalId",StereoType=DataStereoType.FK)]
		private int goalId;
		[ColumnMapping("DeficitId",StereoType=DataStereoType.FK)]
		private int deficitId;
		[ColumnMapping("ProjectedCompletionDate")]
		private DateTime projectedCompletionDate;
		[ColumnMapping("ActualCompletionDate")]
		private DateTime actualCompletionDate;
		[ColumnMapping("GoalTermId",StereoType=DataStereoType.FK)]
		private int goalTermId;
		[ColumnMapping("GoalOutcomeId",StereoType=DataStereoType.FK)]
		private int goalOutcomeId;
		[ColumnMapping("Comments")]
		private string comments;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("GoalTypeId",StereoType=DataStereoType.FK)]
		private int goalTypeId;
		[ColumnMapping("GoalReasonId",StereoType=DataStereoType.FK)]
		private int goalReasonId;
		[ColumnMapping("GoalTypeFFRM")]
		private string goalTypeFFRM;
		private POCInterventionCollection pOCInterventions;
	
		public POCGoal()
		{
		}
		
		public POCGoal(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GoalId
		{
			get { return this.goalId; }
			set { this.goalId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DeficitId
		{
			get { return this.deficitId; }
			set { this.deficitId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@PROJECTEDCOMPLETIONDATE@")]
		public System.DateTime ProjectedCompletionDate
		{
			get { return this.projectedCompletionDate; }
			set { this.projectedCompletionDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@ACTUALCOMPLETIONDATE@")]
		public System.DateTime ActualCompletionDate
		{
			get { return this.actualCompletionDate; }
			set { this.actualCompletionDate = value; }
		}

		[FieldValuesMember("LookupOf_GoalTermId", "GoalTermId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@TERM@")]
		public int GoalTermId
		{
			get { return this.goalTermId; }
			set { this.goalTermId = value; }
		}

		[FieldValuesMember("LookupOf_GoalOutcomeId", "GoalOutcomeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@OUTCOME@")]
		public int GoalOutcomeId
		{
			get { return this.goalOutcomeId; }
			set { this.goalOutcomeId = value; }
		}

		public string Fmt_GoalOutcomeId
		{
			get { return POCGoalOutcomeCollection.ActivePOCGoalOutcomes.Lookup_CodeByGoalOutcomeId(this.goalOutcomeId); }
			set { this.goalOutcomeId = POCGoalOutcomeCollection.ActivePOCGoalOutcomes.Lookup_IDByCode(value); }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=500)]
		[FieldDescription("@COMMENT@")]
		public string Comments
		{
			get { return this.comments; }
			set { this.comments = value; }
		}

		[FieldValuesMember("LookupOf_GoalTypeId", "GoalTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, ValueForNull=(int)0, IsRequired=true)]
		[FieldDescription("@GOALTYPEID@")]
		public int GoalTypeId
		{
			get { return this.goalTypeId; }
			set { this.goalTypeId = value; }
		}

		[FieldValuesMember("LookupOf_GoalReasonId", "GoalReasonId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@REASON@")]
		public int GoalReasonId
		{
			get { return this.goalReasonId; }
			set { this.goalReasonId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string GoalTypeFFRM
		{
			get { return this.goalTypeFFRM; }
			set { this.goalTypeFFRM = value; }
		}

		[FieldDescription("@GOALTYPEID@")]
		public string GoalType
		{
			get
			{
				if (goalTypeId == 0)
					return goalTypeFFRM;
				else
					return POCGoalTypeCollection.ActivePOCGoalTypes.Lookup_DescriptionByGoalTypeId(goalTypeId);
			}
		}

		public string INTERVENTIONSRESOVLED
		{
			get {return  "All Interventions are resolved for selected Goal "; }
		}

		/// <summary>
		/// Parent POCGoalCollection that contains this element
		/// </summary>
		public POCGoalCollection ParentPOCGoalCollection
		{
			get
			{
				return this.parentPOCGoalCollection;
			}
			set
			{
				this.parentPOCGoalCollection = value; // parent is set when added to a collection
			}
		}

		#region Lookups
		public POCGoalTypeCollection LookupOf_GoalTypeId
		{
			get
			{
				return POCGoalTypeCollection.ActivePOCGoalTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public POCGoalReasonCollection LookupOf_GoalReasonId
		{
			get
			{
				return POCGoalReasonCollection.ActivePOCGoalReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public POCGoalOutcomeCollection LookupOf_GoalOutcomeId
		{
			get
			{
				return POCGoalOutcomeCollection.ActivePOCGoalOutcomes; // Acquire a shared instance from the static member of collection
			}
		}

		public POCGoalTermCollection LookupOf_GoalTermId
		{
			get
			{
				return POCGoalTermCollection.ActivePOCGoalTerms; // Acquire a shared instance from the static member of collection
			}
		}
		#endregion

		/// <summary>
		/// Indicates if Goal is Open or not.
		/// </summary>
		/// <returns></returns>
		public bool IsGoalOpen
		{
			get
			{
				return POCGoalOutcomeCollection.ActivePOCGoalOutcomes.Lookup_CodeStatusByGoalOutcomeId(this.goalOutcomeId)== FunctionalStatus.OPEN;
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int goalId)
		{
			return base.Load(goalId);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			base.InternalSave();
			// Save the child collections here.
			SavePOCInterventions();
		}

		/// <summary>
		/// Child POCInterventions mapped to related rows of table POCIntervention where [GoalId] = [GoalID]
		/// </summary>
		[SPLoadChild("usp_LoadPOCGoalPOCIntervention", "goalID")]
		public POCInterventionCollection POCInterventions
		{
			get 
			{ 
				this.LoadPOCInterventions(false);
				return this.pOCInterventions; 
			}
			set
			{
				this.pOCInterventions = value;
				if (value != null)
					value.ParentPOCGoal = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the POCInterventions collection
		/// </summary>
		public void LoadPOCInterventions(bool forceReload)
		{
			this.pOCInterventions = (POCInterventionCollection)POCInterventionCollection.LoadChildCollection("POCInterventions", this, typeof(POCInterventionCollection), pOCInterventions, forceReload, null);
		}

		/// <summary>
		/// Saves the POCInterventions collection
		/// </summary>
		public void SavePOCInterventions()
		{
			POCInterventionCollection.SaveChildCollection(this.pOCInterventions, true);
		}

		/// <summary>
		/// Synchronizes the POCInterventions collection
		/// </summary>
		public void SynchronizePOCInterventions()
		{
			POCInterventionCollection.SynchronizeChildCollection(this.pOCInterventions, true);
		}
		
	}

	/// <summary>
	/// Strongly typed collection of POCGoal objects
	/// </summary>
	[ElementType(typeof(POCGoal))]
	public class POCGoalCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass, ICollectionElementFilter
	{
		[NonSerialized]
		private CollectionIndexer indexBy_GoalId;
		protected int openWithAll = -1;

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int OpenWithAll
		{
			get { return this.openWithAll; }
			set { this.openWithAll = value; }
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(POCGoal elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPOCGoalCollection = this;
			else
				elem.ParentPOCGoalCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (POCGoal elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public POCGoal this[int index]
		{
			get
			{
				return (POCGoal)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((POCGoal)oldValue, false);
			SetParentOnElem((POCGoal)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(POCGoal elem)
		{
			return AddRecord(elem);	
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((POCGoal)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Returns true if the collection contains the given object
		/// </summary>
		public bool Contains(POCGoal elem)
		{
			return List.Contains(elem);
		}

		/// <summary>
		/// Parent POCDeficit that contains this collection
		/// </summary>
		public POCDeficit ParentPOCDeficit
		{
			get { return this.ParentDataObject as POCDeficit; }
			set { this.ParentDataObject = value; /* parent is set when contained by a POCDeficit */ }
		}

		public bool IsPOCGoalTypeInCollection(POCGoal gl, int type)
		{
			bool result = false;
			if (this.Count == 0)
				return false;
			if (type == 0)
				return false;
			for (int i = 0; i < this.Count; i++)
			{
				if ( !this[i].Equals(gl))
				{
					if (this[i].GoalTypeId == type)
						return true;
					else
						result = false;
				}
			}
			return result;
		}

		public bool AreAllGoalsResolved()
		{
			if(this.Count == 0)
				return false;

			int index = 0;
			bool toContinue = true;

			while(toContinue && index < this.Count)
			{
				if(this[index].Fmt_GoalOutcomeId == POCGoalOutcome.COMPLETE)
					index++;
				else
					toContinue = false;
			}
			return toContinue;
		}

		#region ICollectionElementFilter Members

		public bool FilterElement(int index)
		{
			if(this.openWithAll == -1)
				return true;
			bool visible = (this.openWithAll == 0 ? false : true);
			
			if (this[index].IsGoalOpen && visible)
				return true;
			if (!this[index].IsGoalOpen && !visible)
				return true;
			return false;
		}

		#endregion

		/// <summary>
		/// Hashtable based index on goalId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_GoalId
		{
			get
			{
				if (this.indexBy_GoalId == null)
					this.indexBy_GoalId = new CollectionIndexer(this, new string[] { "goalId" }, true);
				return this.indexBy_GoalId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on goalId fields returns the object.  Uses the IndexBy_GoalId indexer.
		/// </summary>
		public POCGoal FindBy(int goalId)
		{
			return (POCGoal)this.IndexBy_GoalId.GetObject(goalId);
		}
	}
}
