using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [POCDeficitPriority]
	/// </summary>
	[SPAutoGen("usp_GetAllPOCDeficitPrioritiesByActive","CodeTableLoaderOrderBy.sptpl","sortOrder, ASC, active")]
	[SPAutoGen("usp_SearchPOCDeficitPrioritiesByCodeDescriptionActive","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllPOCDeficitPriorities","SelectAll.sptpl","")]
	[SPInsert("usp_InsertPOCDeficitPriority")]
	[SPUpdate("usp_UpdatePOCDeficitPriority")]
	[SPDelete("usp_DeletePOCDeficitPriority")]
	[SPLoad("usp_LoadPOCDeficitPriority")]
	[TableMapping("POCDeficitPriority","deficitPriorityId")]
	public class POCDeficitPriority : BaseLookupWithExtCode
	{
		[NonSerialized]
		private POCDeficitPriorityCollection parentPOCDeficitPriorityCollection;
		[ColumnMapping("DeficitPriorityId",StereoType=DataStereoType.FK)]
		private int deficitPriorityId;
		[ColumnMapping("SortOrder")]
		private int sortOrder;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public POCDeficitPriority()
		{
			this.sortOrder = 1; // issue # 724
		}

		public POCDeficitPriority(bool initNew) : this()
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int DeficitPriorityId
		{
			get { return this.deficitPriorityId; }
			set { this.deficitPriorityId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
		
		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		} 
		/// <summary>
		/// Parent POCDeficitPriorityCollection that contains this element
		/// </summary>
		public POCDeficitPriorityCollection ParentPOCDeficitPriorityCollection
		{
			get
			{
				return this.parentPOCDeficitPriorityCollection;
			}
			set
			{
				this.parentPOCDeficitPriorityCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool SearchPOCDeficitPrioritiesByCodeDescriptionActive(string code, string description, bool active)
		{
			return SqlData.SPExecReadObj("usp_SearchPOCDeficitPrioritiesByCodeDescriptionActive", this, false, code, description, active);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		[FieldDescription("@SORTORDER@")]
		public override string ExtCode
		{
			get { return this.sortOrder.ToString(); }
			set { this.sortOrder = int.Parse(value); }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.sortOrder=0;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}
	}

	/// <summary>
	/// Strongly typed collection of POCDeficitPriority objects
	/// </summary>
	[ElementType(typeof(POCDeficitPriority))]
	public class POCDeficitPriorityCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(POCDeficitPriority elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPOCDeficitPriorityCollection = this;
			else
				elem.ParentPOCDeficitPriorityCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (POCDeficitPriority elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public POCDeficitPriority this[int index]
		{
			get
			{
				return (POCDeficitPriority)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((POCDeficitPriority)oldValue, false);
			SetParentOnElem((POCDeficitPriority)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllPOCDeficitPrioritiesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPOCDeficitPrioritiesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared POCDeficitPriorityCollection which is cached in NSGlobal
		/// </summary>
		public static POCDeficitPriorityCollection ActivePOCDeficitPriorities
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				POCDeficitPriorityCollection col = (POCDeficitPriorityCollection)NSGlobal.EnsureCachedObject("ActivePOCDeficitPriorities", typeof(POCDeficitPriorityCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllPOCDeficitPrioritiesByActive(-1, true);
				}
				return col;
			}
			
		}

		public override void LoadAll()
		{			
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllPOCDeficitPriorities", -1, this, false);
		}
	}
}
