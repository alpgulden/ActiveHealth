using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSIntensities]
	/// </summary>
	[SPAutoGen("usp_SearchCMSIntensities","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllCMSIntensitiesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllCMSIntensities","SelectAll.sptpl","")]
	[SPInsert("usp_InsertCMSIntensity")]
	[SPUpdate("usp_UpdateCMSIntensity")]
	[SPDelete("usp_DeleteCMSIntensity")]
	[SPLoad("usp_LoadCMSIntensity")]
	[TableMapping("CMSIntensity","intensityId")]
	public class CMSIntensity : BaseLookupWithNote
	{
		[NonSerialized]
		private CMSIntensityCollection parentCMSIntensityCollection;
		[ColumnMapping("IntensityId",StereoType=DataStereoType.FK)]
		private int intensityId;
		[ColumnMapping("NotePad")]
		private string notePad;

	
		public CMSIntensity()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int IntensityId
		{
			get { return this.intensityId; }
			set { this.intensityId = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int intensityId)
		{
			return base.Load(intensityId);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int intensityId)
		{
			base.Delete(intensityId);		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active	= true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Parent CMSIntensityCollection that contains this element
		/// </summary>
		public CMSIntensityCollection ParentCMSIntensityCollection
		{
			get
			{
				return this.parentCMSIntensityCollection;
			}
			set
			{
				this.parentCMSIntensityCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Use this function to test Load method
		/// </summary>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void TestLoad()
		{
			CMSIntensity obj = new CMSIntensity();
			obj.Load(1);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(2);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(3);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(4);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
		
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of CMSIntensity objects
	/// </summary>
	[ElementType(typeof(CMSIntensity))]
	public class CMSIntensityCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSIntensity elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSIntensityCollection = this;
			else
				elem.ParentCMSIntensityCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSIntensity elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSIntensity this[int index]
		{
			get
			{
				return (CMSIntensity)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSIntensity)oldValue, false);
			SetParentOnElem((CMSIntensity)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		
		/// <summary>
		///  Load all Facility Focus Types.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllCMSIntensities", -1, this, false);
		}

		/// <summary>
		///  Searches for Focus Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchAllCMSIntensities", -1, this, false, code, description, active);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllCMSIntensitiesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllCMSIntensitiesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared CMSIntensityCollection which is cached in NSGlobal
		/// </summary>
		public static CMSIntensityCollection ActiveCMSIntensities
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				CMSIntensityCollection col = (CMSIntensityCollection)NSGlobal.EnsureCachedObject("ActiveCMSIntensities", typeof(CMSIntensityCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllCMSIntensitiesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
