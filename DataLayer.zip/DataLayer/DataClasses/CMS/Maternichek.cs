using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Maternichek]
	/// </summary>
	[SPAutoGen("usp_LoadMaternichekByCMSid","SelectAllByGivenArgs.sptpl","cMSId")]
	[SPInsert("usp_InsertMaternichek")]
	[SPUpdate("usp_UpdateMaternichek")]
	[SPDelete("usp_DeleteMaternichek")]
	[SPLoad("usp_LoadMaternichek")]
	[TableMapping("Maternichek","maternichekId")]
	public class Maternichek : BaseDataWithUserDefined
	{
		[ColumnMapping("MaternichekId",StereoType=DataStereoType.FK)]
		private int maternichekId;
		[ColumnMapping("CMSId")]
		private int cMSId;
		[ColumnMapping("LMPdate")]
		private DateTime lMPdate;
		[ColumnMapping("EDCdate")]
		private DateTime eDCdate;
		[ColumnMapping("GestationAge")]
		private int gestationAge;
		[ColumnMapping("DeliveryDate")]
		private DateTime deliveryDate;
		[ColumnMapping("FirstPrenatalVisit")]
		private DateTime firstPrenatalVisit;
		[ColumnMapping("FirstPostpartumVisit")]
		private DateTime firstPostpartumVisit;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("MaternichekComplicationID",StereoType=DataStereoType.FK)]
		private int maternichekComplicationID;

		
		private bool isCalculated = false;
		private int daysOpen;
		
		private CMS cMS;
		
		public const string CMSTYPE = "MC" ;
		public Maternichek()
		{
		}

		public Maternichek(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int MaternichekId
		{
			get { return this.maternichekId; }
			set { this.maternichekId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSId
		{
			get { return this.cMSId; }
			set { this.cMSId = value; }
		}
		
		public static int CMSTypeCodeId
		{
			get
			{
				return CMSTypeCollection.ActiveCMSTypes.Lookup_CMSTypeIDByCode(CMSTYPE);
			}
		}

		[FieldValuesMember("LookupOf_MaternichekComplicationID", "MaternichekComplicationID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int MaternichekComplicationID
		{
			get { return this.maternichekComplicationID; }
			set { this.maternichekComplicationID = value; }
		}
	
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@LMP@")]
		public System.DateTime LMPdate
		{	//�	If EDC is entered, and LMP is blank, then LMP is set as EDC � 280 days. 
			get 
			{ 
				if ( this.eDCdate > DateTime.MinValue & this.lMPdate == DateTime.MinValue)
					this.lMPdate = this.eDCdate.AddDays(-280);
				return this.lMPdate; 
			}
			set 
			{ 
				if (value > DateTime.MinValue)
				{	
					this.lMPdate = value; 
					this.eDCdate = DateTime.MinValue;
					DateTime dt = EDCdate;
					isCalculated = true;
				}
				else
					isCalculated = false;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]//, IsRequired=true)]
		[FieldDescription("@EDC@")]
		public System.DateTime EDCdate
		{	//�	If LMP is entered, and EDC is blank, EDC is set as LMP date plus 280 days
			get 
			{ 
				if ( this.lMPdate > DateTime.MinValue && this.eDCdate == DateTime.MinValue)
					this.eDCdate = this.lMPdate.AddDays(280);
				return this.eDCdate; 
			}
			set 
			{ 
				if (!isCalculated)
				{
					this.eDCdate = value; 
					this.lMPdate = DateTime.MinValue;
					DateTime dt = LMPdate;
				}
			}
		}

		#region Assessment methods
		/* These methods are used from Assessment module.
		 * Workflow is such that user updates single value (EDC or LMP) at a time.
		 * This change should recalculate the other field  */
		 
		public void UpdateFromEDC(System.DateTime edc)
		{
			this.eDCdate = edc;
			this.lMPdate = this.eDCdate.AddDays(-280);
		}

		public void UpdateFromLMP(System.DateTime lmp)
		{
			this.lMPdate = lmp;
			this.eDCdate = this.lMPdate.AddDays(280);
		}

		public int CalculateGestationalAgeForAssessment(DateTime lastVisit)
		{
			if (lastVisit > this.LMPdate)
				return lastVisit.Subtract(this.lMPdate).Days;
			else
				return 0;
		}

		public string GestationAgeDisplayForAssessment(DateTime lastVisit)
		{
			int gAge = this.CalculateGestationalAgeForAssessment(lastVisit);
			if( gAge == 0)
				return "@UNKNOWN@";
			int weeks = 0, days = 0;
			weeks = gAge / 7;
			days = gAge % 7;
			if(days > 4)
				weeks++;
			return String.Format("{0} {1}", weeks, Messages.CMSMessages.MessageIDs.WEEKS);
		}

		#endregion
		
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@GESTAGE@")]
		public int GestationAge
		{	
			// �	If delivery date is filled in, then  GestationAge is calculated based on delivery date
			// �	If delivery date is empty: GestationAge = current date - LMP
			get
			{
				if(this.eDCdate == DateTime.MinValue & this.lMPdate == DateTime.MinValue)
				{
					this.gestationAge = 0;
					return this.gestationAge;
				}
				DateTime lmp = this.LMPdate;
				if (this.deliveryDate == DateTime.MinValue)
				{
					if(lmp > DateTime.Now)
						this.gestationAge = 0;
					else
						this.gestationAge = DateTime.Now.Subtract(lmp).Days;
				}
				else if (this.deliveryDate > DateTime.MinValue)
				{
					if(lmp > this.deliveryDate )
						this.gestationAge = 0;
					else
						this.gestationAge = this.deliveryDate.Subtract(lmp).Days;
				}
				return this.gestationAge;
			}
		}
		
		[FieldDescription("@GESTAGE@")]
		public string GestationAgeDisplay
		{
			get
			{
				int gAge = this.GestationAge;
				if( gAge == 0)
					return "@UNKNOWN@";
				int weeks = 0, days = 0;
				weeks = gAge / 7;
				days = gAge % 7;
				if(days == 0)
					return String.Format("{0} {1}", weeks, Messages.CMSMessages.MessageIDs.WEEKS);
				else
					return String.Format("{0} {1} {2} {3}", weeks, Messages.CMSMessages.MessageIDs.WEEKS, days, Messages.CMSMessages.MessageIDs.DAYS);
			}
		}
		
		[FieldDescription("@DELIVERYAGE@")]
		public string DeliveryAge //mothers age at delivery date
		{	//mothers age at delivery date
			// �	If delivery date is filled in, then Delivery age is calculated based on delivery date
			// �	If delivery date is empty: Delivery age = EDC - patient's DOB
			get 
			{ 
				int years = 0, months = 0;
				if(CalculateDeliveryAge(ref years, ref months))
					return String.Format("{0} {1} {2} {3}", years, Messages.CMSMessages.MessageIDs.YEARS, months, Messages.CMSMessages.MessageIDs.MONTHS);
				else
					 return "@UNKNOWN@";
			}
		}


		public bool CalculateDeliveryAge(ref int years, ref int months)
		{
			if (this.CMS.ParentPatient.DateOfBirth == DateTime.MinValue
				|| (this.eDCdate == DateTime.MinValue & this.lMPdate == DateTime.MinValue))
				return false;
			
			if (this.deliveryDate == DateTime.MinValue && CMS.ParentPatient != null)
			{
				CalculateYearsMonths(this.CMS.ParentPatient.DateOfBirth, this.eDCdate, ref years, ref months);
				return true;
			}
			else if (this.deliveryDate > DateTime.MinValue && CMS.ParentPatient != null)
			{
				CalculateYearsMonths(this.CMS.ParentPatient.DateOfBirth, this.deliveryDate, ref years, ref months);
				return true;
			}

			return false;
		}

		[ValidatorMember("Vld_DeliveryDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DELIVERYDATE@")]
		public System.DateTime DeliveryDate
		{
			get { return this.deliveryDate; }
			set { this.deliveryDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@FIRSTPRENATALVISIT@")]
		public System.DateTime FirstPrenatalVisit
		{
			get { return this.firstPrenatalVisit; }
			set { this.firstPrenatalVisit = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@FIRSTPOSTPARTUMVISIT@")]
		public System.DateTime FirstPostpartumVisit
		{
			get { return this.firstPostpartumVisit; }
			set { this.firstPostpartumVisit = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int maternichekId)
		{
			return base.Load(maternichekId);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.
		}

		

		/// <summary>
		/// Contained CMS object
		/// </summary>
		public CMS CMS
		{
			get
			{
				return this.cMS;
			}
			set
			{
				this.cMS = value;
			}
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadMaternichekByCMSid(int cMSId)
		{
			return SqlData.SPExecReadObj("usp_LoadMaternichekByCMSid", this, false, cMSId);
		}

		[GenericScript("Vld_DeliveryDate", "@DeliveryDate@ != null && @LMPdate@ != null && @DeliveryDate@ > @LMPdate@;")]
		public string Vld_DeliveryDate
		{
			get
			{
				return "DeliveryDate must be greater than LMP!"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
			}
		}

		public MaternichekComplicationCollection LookupOf_MaternichekComplicationID
		{
			get
			{
				return MaternichekComplicationCollection.ActiveMaternichekComplications; // Acquire a shared instance from the static member of collection
			}
		}		
	}
}
