using System;
using System.Collections;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	#region DistinctDates
	/// <summary>
	/// Not mapped class used to represent an object model for result set of usp_GetAllDistinctPackingListItemSentDatesByCMSID
	/// Each item represents a different column for PackingListItem Sent grid
	/// </summary>
	[SPAutoGen("usp_GetAllDistinctPackingListItemSentDatesByCMSID", null, ManuallyManaged=true)]
	[TableMapping("PackingListItemSent", null)]
	public class DistinctDatePackingListItemSent : BaseData
	{
		[NonSerialized]
		private DistinctDatePackingListItemSentCollection parentDistinctDatePackingListItemSentCollection;
		
		[ColumnMapping("CreationTime")]
		protected DateTime creationTime;
		private int columnIndex;  // stores index of mapped to column. column which represents this.creationTime

		[FieldDescription("@CREATETIME@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreationTime
		{
			get { return this.creationTime; }
			set { this.creationTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ColumnIndex
		{
			get { return this.columnIndex; }
			set { this.columnIndex = value; }
		}

		public string DescriptionForGridHeader
		{
			get
			{
				return this.creationTime.ToShortDateString()+ "<br>" + this.creationTime.ToShortTimeString();
			}
		}

		public string DescriptionForCombo
		{
			get
			{
				return this.creationTime.ToShortDateString()+ " " + this.creationTime.ToShortTimeString();
			}
		}

		/// <summary>
		/// Parent DistinctDatePackingListItemSentCollection that contains this element
		/// </summary>
		public DistinctDatePackingListItemSentCollection ParentDistinctDatePackingListItemSentCollection
		{
			get
			{
				return this.parentDistinctDatePackingListItemSentCollection;
			}
			set
			{
				this.parentDistinctDatePackingListItemSentCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Compares Creation Time to one passed
		/// </summary>
		/// <param name="printedTime"></param>
		/// <param name="compareSeconds">True will cause up to a second comparison</param>
		/// <returns></returns>
		public bool CompareCreationTime(DateTime printedTime, bool compareSeconds)
		{
			if(compareSeconds)
				return this.CreationTime.Second == printedTime.Second && CompareCreationTime(printedTime, false);
			else
				return this.CreationTime.Date == printedTime.Date 
				&& this.CreationTime.Hour == printedTime.Hour
				&& this.CreationTime.Minute == printedTime.Minute;
		}
	}

	/// <summary>
	/// Strongly typed collection of DistinctDatePackingListItemSent objects
	/// </summary>
	[ElementType(typeof(DistinctDatePackingListItemSent))]
	public class DistinctDatePackingListItemSentCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_CreationTime;
		[NonSerialized]
		private CollectionIndexer indexBy_DateSent;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(DistinctDatePackingListItemSent elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentDistinctDatePackingListItemSentCollection = this;
			else
				elem.ParentDistinctDatePackingListItemSentCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (DistinctDatePackingListItemSent elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public DistinctDatePackingListItemSent this[int index]
		{
			get
			{
				return (DistinctDatePackingListItemSent)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((DistinctDatePackingListItemSent)oldValue, false);
			SetParentOnElem((DistinctDatePackingListItemSent)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadAllDistinctDatesPLISentByCMSId(int maxRecords, int cMSId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllDistinctPackingListItemSentDatesByCMSID", maxRecords, this, false, new object[] { cMSId });
		}

		public static DistinctDatePackingListItemSentCollection GetDistinctDatesByCMSId(int cMSId)
		{
			DistinctDatePackingListItemSentCollection col = new DistinctDatePackingListItemSentCollection();
			col.LoadAllDistinctDatesPLISentByCMSId(-1, cMSId);
			return col;
		}

		/// <summary>
		/// Hashtable based index on creationTime fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_CreationTime
		{
			get
			{
				if (this.indexBy_CreationTime == null)
					this.indexBy_CreationTime = new CollectionIndexer(this, new string[] { "creationTime" }, true);
				return this.indexBy_CreationTime;
			}
			
		}

		/// <summary>
		/// Hashtable based search on creationTime fields returns the object.  Uses the IndexBy_CreationTime indexer.
		/// </summary>
		public DistinctDatePackingListItemSent FindBy(System.DateTime creationTime)
		{
			return (DistinctDatePackingListItemSent)this.IndexBy_CreationTime.GetObject(creationTime);
		}
	}
	#endregion

	#region BasePackingListItemSent
	[TableMapping("PackingListItemSent", null)]
	public abstract class BasePackingListItemSent : DistinctDatePackingListItemSent
	{
		
		[ColumnMapping("PackingListItemId")]
		protected int packingListItemId;
		[ColumnMapping("CMSId", FillFlags = DataFiller.FillFlags.ObjectToData)]
		protected int cMSId;
		[ColumnMapping("AssessmentGUID", FillFlags = DataFiller.FillFlags.ObjectToData)]
		protected string assessmentGUID;

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSId
		{
			get { return this.cMSId; }
			set { this.cMSId = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PackingListItemId
		{
			get { return this.packingListItemId; }
			set { this.packingListItemId = value; }
		}

		//[FieldDescription("@Description@")]
		public string Description
		{
			get 
			{ 
				return PackingListItemCollection.AllPackingListItems.Lookup_DescriptionByPackingListItemId(this.packingListItemId);
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}
	}
	#endregion

	#region PackingListItemSent
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PackingListItemSent]
	/// </summary>
	[SPInsert("usp_InsertPackingListItemSent")]
	[SPUpdate("usp_UpdatePackingListItemSent")]
	[SPDelete("usp_DeletePackingListItemSent")]
	[SPLoad("usp_LoadPackingListItemSent")]
	[TableMapping("PackingListItemSent","packingListItemSentId")]
	public class PackingListItemSent : BasePackingListItemSent
	{
		[NonSerialized]
		private PackingListItemSentCollection parentPackingListItemSentCollection;
		[ColumnMapping("PackingListItemSentId",StereoType=DataStereoType.FK)]
		private int packingListItemSentId;
		[ColumnMapping("CreatedBy")]
		private int createdBy;

		public static int COLUMNSLIMIT = 37;	//limits number of columns for Packing List Items grid

		public PackingListItemSent()
		{
		}

		public PackingListItemSent(bool initNew) : this()
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public PackingListItemSent(bool initNew, int pliID, DateTime creationTime, int cMSId, string assmtGUID) : this(initNew)
		{
			this.packingListItemId = pliID;
			this.creationTime = creationTime;
			this.cMSId = cMSId;
			this.assessmentGUID = assmtGUID;
		}

		public PackingListItemSent(bool initNew, PackingListItemSentSelection obj, int cMSId, DateTime dt) 
			: this(initNew, obj.PackingListItemId, dt, cMSId, obj.AssessmentGUID)
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PackingListItemSentId
		{
			get { return this.packingListItemSentId; }
			set { this.packingListItemSentId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}
		
		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int packingListItemSentId)
		{
			return base.Load(packingListItemSentId);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Parent PackingListItemSentCollection that contains this element
		/// </summary>
		public PackingListItemSentCollection ParentPackingListItemSentCollection
		{
			get
			{
				return this.parentPackingListItemSentCollection;
			}
			set
			{
				this.parentPackingListItemSentCollection = value; // parent is set when added to a collection
			}
		}
	}


	/// <summary>
	/// Strongly typed collection of PackingListItemSent objects
	/// </summary>
	[ElementType(typeof(PackingListItemSent))]
	public class PackingListItemSentCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PackingListItemId;
		//private CollectionIndexer indexBy_CreationTime;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PackingListItemSent elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPackingListItemSentCollection = this;
			else
				elem.ParentPackingListItemSentCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PackingListItemSent elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PackingListItemSent this[int index]
		{
			get
			{
				return (PackingListItemSent)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PackingListItemSent)oldValue, false);
			SetParentOnElem((PackingListItemSent)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set 
			{ 
				this.ParentDataObject = value; /* parent is set when contained by a CMS */ 
				foreach (PackingListItemSent item in this)
				{
					item.CMSId = value.CMSID;
				}
			}
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PackingListItemSent elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PackingListItemSent)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Hashtable based index on packingListItemId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PackingListItemId
		{
			get
			{
				if (this.indexBy_PackingListItemId == null)
					this.indexBy_PackingListItemId = new CollectionIndexer(this, new string[] { "packingListItemId" }, true);
				return this.indexBy_PackingListItemId;
			}
			
		}

		/// <summary>
		/// Looks up by packingListItemId and returns true if item Exists, false otherwise
		/// </summary>
		public bool Exists(int packingListItemId)
		{
			if(this.IndexBy_PackingListItemId.IndexOf(packingListItemId) == -1)
				return false;
			return true;
		}

		/// <summary>
		/// Checks if Collection contains item with matching PLI ID and Creation Time (when it was printed)
		/// </summary>
		/// <param name="packingListItemId"></param>
		/// <param name="printedTime"></param>
		/// <returns>ColumnIndex for found item; -1 otherwise.</returns>
		public int Exists(int packingListItemId, DateTime creationTime)
		{
			foreach(PackingListItemSent item in this)
			{
				if(item.PackingListItemId == packingListItemId
					&& item.CompareCreationTime(creationTime, false))
					return item.ColumnIndex;
			}
			return -1;
		}
	}
	#endregion

	#region PackingListItemSentSelection
	/// <summary>
	/// Collection of this class is being populated by usp_GeneratePackingList.
	/// It is used to render PLIs grid and allows user to select PLIs to be printed
	/// </summary>
	[SPAutoGen("usp_GeneratePackingList", null, ManuallyManaged=true)]
	[TableMapping("PackingListItemSent", null)]
	public class PackingListItemSentSelection : BasePackingListItemSent
	{
		[NonSerialized]
		private PackingListItemSentSelectionCollection parentPackingListItemSentSelectionCollection;
		
		private bool isSelected, printable, isSelectedDefault;
		private string pLIDescription;
		private string logicExpression, rangeExpression;

		private string assessmentDescription;

		
		[ControlType(EnumControlTypes.CheckBox)]
		public bool IsSelected
		{
			get { return this.isSelected; }
			set { this.isSelected = value; }
		}

		/// <summary>
		/// Carries same state as IsSelected when loaded from store proc.
		/// MUST never be modified by page.
		/// Used to restore state of IsSelected to original(default) value.
		/// </summary>
		[ControlType(EnumControlTypes.CheckBox)]
		public bool IsSelectedDefault
		{
			get { return this.isSelectedDefault; }
			set { this.isSelectedDefault = value; }
		}

		public bool IsActive
		{
			get
			{
				return PackingListItemCollection.AllPackingListItems.Lookup_ActiveByPackingListItemId(this.PackingListItemId);
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LogicExpression
		{
			get { return this.logicExpression; }
			set { this.logicExpression = value; }
		}

		public bool Printable
		{
			get { return this.printable; }
			set { this.printable = value; }
		}

		public string RangeExpression
		{
			get { return this.rangeExpression; }
			set { this.rangeExpression = value; }
		}

		
		/// <summary>
		/// Parent PackingListItemSentSelectionCollection that contains this element
		/// </summary>
		public PackingListItemSentSelectionCollection ParentPackingListItemSentSelectionCollection
		{
			get
			{
				return this.parentPackingListItemSentSelectionCollection;
			}
			set
			{
				this.parentPackingListItemSentSelectionCollection = value; // parent is set when added to a collection
			}
		}

		
	}

	/// <summary>
	/// Strongly typed collection of PackingListItemSentSelection objects
	/// </summary>
	[ElementType(typeof(PackingListItemSentSelection))]
	public class PackingListItemSentSelectionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PackingListItemId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PackingListItemSentSelection elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPackingListItemSentSelectionCollection = this;
			else
				elem.ParentPackingListItemSentSelectionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PackingListItemSentSelection elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PackingListItemSentSelection this[int index]
		{
			get
			{
				return (PackingListItemSentSelection)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PackingListItemSentSelection)oldValue, false);
			SetParentOnElem((PackingListItemSentSelection)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadAllPackingListItemsSentByCMSidAssmtGUID(int maxRecords, int cMSId, string assessmentGUID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GeneratePackingList", maxRecords, this, false, new object[] { assessmentGUID, cMSId});
		}

		public static PackingListItemSentSelectionCollection GetPLISent(int cMSId, string assessmentGUID)
		{
			PackingListItemSentSelectionCollection col = new PackingListItemSentSelectionCollection();
			col.LoadAllPackingListItemsSentByCMSidAssmtGUID(-1, cMSId, assessmentGUID);
			return col;
		}

		protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);

			 bool isSelected = SQLDataDirect.GetFromDBValue(rdr["IsSelected"], false);
			((PackingListItemSentSelection)data).IsSelected = isSelected;
			((PackingListItemSentSelection)data).IsSelectedDefault = isSelected;
			((PackingListItemSentSelection)data).Printable = SQLDataDirect.GetFromDBValue(rdr["Printable"], false);
			((PackingListItemSentSelection)data).LogicExpression = SQLDataDirect.GetFromDBValue(rdr["LogicExpression"], null);
			((PackingListItemSentSelection)data).RangeExpression = SQLDataDirect.GetFromDBValue(rdr["RangeExpression"], null);
		}

		
		/// <summary>
		/// Repritns PLIs for specified date.
		/// </summary>
		/// <param name="dt"></param>
		/// <param name="cMSId"></param>
		/// <returns>New Collection of reprinted items whith CreationTime set to DateTime.Now</returns>
		public PackingListItemSentCollection Reprint(DateTime dt, int cMSId)
		{
			PackingListItemSentCollection col = new PackingListItemSentCollection();
			DateTime now = DateTime.Now;
			foreach(PackingListItemSentSelection data in this)
			{
				// Match CreationTime with passed time for up to a second
				// If equal create a new object and add it to a collection
				if(data.IsActive && data.Printable && data.CompareCreationTime(dt, false))
					col.Add(new PackingListItemSent(true, data, cMSId, now));
			}
			return col;
		}

		/// <summary>
		/// Adds DUMMY item based on passed param for the purpose of effectivly reprinting
		/// most recent printing date, by avoiding reload from DB.
		/// Only needed flags and CreationTime is set to enable reprint.
		/// </summary>
		/// <param name="item">Recently added PLI for printing</param>
		public void AddPackingListItemSent(PackingListItemSent item)
		{
			PackingListItemSentSelection newItem = new PackingListItemSentSelection();

			newItem.Printable = true;
			newItem.PackingListItemId = item.PackingListItemId;
			newItem.CreationTime = item.CreationTime;
			this.AddRecord(newItem);
		}
	}
	#endregion
}