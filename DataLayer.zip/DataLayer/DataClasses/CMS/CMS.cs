using System;
using NetsoftUSA.DataLayer;
using ActiveAdvice.Messages;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMS]
	/// </summary>
	[SPAutoGen("usp_LoadCMSByPOCInterventionId", null, ManuallyManaged=true)]
	[SPAutoGen("usp_SearchCMSsByAltCMSID","SelectAllByGivenArgsOrderBy.sptpl","alternateCMSID, ASC, alternateCMSID")]
	[SPAutoGen("usp_GetAllCMSesByPatientId","SelectAllByGivenArgs.sptpl","patientId", InjectOrderBy="ORDER BY [CMS].[CMSID] DESC", ManuallyManaged=true)]
	[SPAutoGen("usp_UpdateCMSLastValidationDate","UpdateGivenColsByPK.sptpl","lastValidationDate")]
	[SPInsert("usp_InsertCMS")]
	[SPUpdate("usp_UpdateCMS")]
	[SPDelete("usp_DeleteCMS")]
	[SPLoad("usp_LoadCMS")]
	[TableMapping("CMS","cMSID")]
	public class CMS : BaseForEventCMSReferral
	{
		[Copiable(false)]
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("AlternateCMSID")]
		private string alternateCMSID;
		[ColumnMapping("PrimaryProblemID",StereoType=DataStereoType.FK)]
		private int primaryProblemID;
		[ColumnMapping("CaseStartDate")]
		private DateTime caseStartDate;
		[ColumnMapping("CaseEndDate")]
		private DateTime caseEndDate;
		[ColumnMapping("CaseSourceID",StereoType=DataStereoType.FK)]
		private int caseSourceID;
		[ColumnMapping("CaseOpenReasonID",StereoType=DataStereoType.FK)]
		private int caseOpenReasonID;
		[ColumnMapping("CaseContinuedReasonID",StereoType=DataStereoType.FK)]
		private int caseContinuedReasonID;
		[ColumnMapping("CaseClosedReasonID",StereoType=DataStereoType.FK)]
		private int caseClosedReasonID;
		[ColumnMapping("PatientAuthorizerID",StereoType=DataStereoType.FK)]
		private int patientAuthorizerID;
		[ColumnMapping("PatientAuthorizationDate")]
		private DateTime patientAuthorizationDate;
		[ColumnMapping("ClientAuthorizerID",StereoType=DataStereoType.FK)]
		private int clientAuthorizerID;
		[ColumnMapping("ClientAuthorizationDate")]
		private DateTime clientAuthorizationDate;
		[ColumnMapping("CMSTypeID")]
		private int cMSTypeID;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("PrimaryProviderSpecialtyID",StereoType=DataStereoType.FK)]
		private int primaryProviderSpecialtyID;
		[ColumnMapping("PrimaryProviderLocationID",StereoType=DataStereoType.FK)]
		private int primaryProviderLocationID;
		[ColumnMapping("PrimaryProviderLocationNetworkID",StereoType=DataStereoType.FK)]
		private int primaryProviderLocationNetworkID;
		[ColumnMapping("PrimaryProviderNetworkStatus", ValueForNull=(int)-1)]
		private int primaryProviderNetworkStatus = -1;
		[ColumnMapping("PrimaryProviderLocationContactID",StereoType=DataStereoType.FK)]
		private int primaryProviderLocationContactID;
		[ColumnMapping("PrimaryFacilityTypeID",StereoType=DataStereoType.FK)]
		private int primaryFacilityTypeID;
		[ColumnMapping("PrimaryFacilityLocationID",StereoType=DataStereoType.FK)]
		private int primaryFacilityLocationID;
		[ColumnMapping("PrimaryFacilityLocationNetworkID",StereoType=DataStereoType.FK)]
		private int primaryFacilityLocationNetworkID;
		[ColumnMapping("PrimaryFacilityNetworkStatus", ValueForNull=(int)-1)]
		private int primaryFacilityNetworkStatus = -1;
		[ColumnMapping("PrimaryFacilityLocationContactID",StereoType=DataStereoType.FK)]
		private int primaryFacilityLocationContactID;
		[ColumnMapping("ProviderInNetwork")]
		private int providerInNetwork;
		[ColumnMapping("FacilityInNetwork")]
		private int facilityInNetwork;
		[ColumnMapping("PrimaryProviderID",StereoType=DataStereoType.FK)]
		private int primaryProviderID;
		[ColumnMapping("PrimaryFacilityID",StereoType=DataStereoType.FK)]
		private int primaryFacilityID;
		[ColumnMapping("ClientReportContact")]
		private string clientReportContact;
		[ColumnMapping("PatientSubscriberLogID",StereoType=DataStereoType.FK)]
		private int patientSubscriberLogID;
		[ColumnMapping("PlanSorgLogID",StereoType=DataStereoType.FK)]
		private int planSorgLogID;
		[ColumnMapping("PatientId")]
		private int patientId;
		[ColumnMapping("HomeContactPhone", StereoType=DataStereoType.USPhoneNumber)]
		private string homeContactPhone;
		[ColumnMapping("WorkContactPhone", StereoType=DataStereoType.USPhoneNumber)]
		private string workContactPhone;
		[ColumnMapping("WorkContactExt")]
		private string workContactExt;
		[ColumnMapping("OtherContactPhone", StereoType=DataStereoType.USPhoneNumber)]
		private string otherContactPhone;
		[ColumnMapping("OtherContactExt")]
		private string otherContactExt;
		[ColumnMapping("HomeContactTime")]
		private DateTime homeContactTime;
		[ColumnMapping("WorkContactTime")]
		private DateTime workContactTime;
		[ColumnMapping("OtherContactTime")]
		private DateTime otherContactTime;
		[ColumnMapping("LastValidationDate")]
		private DateTime lastValidationDate;


		private bool isLinkedToProblem;
		private DateTime startDateWhenLoaded;		// keeps track of the changes in startDate
		private DateTime reportDateFrom;			// used in POC reporting
		private DateTime reportDateTo;				// used in POC reporting

		private CMSCollection parentCMSCollection;
		private CMSEventCollection cMSEvents;
		private CMSStatusHistoryCollection cMSStatusHistories;
		private CMSStatusHistory cMSStatusHistory; // Most Recent History entry
		private Facility  fAcility;
		private POCDeficitCollection pOCDeficits;					// Facility Vendor entry
		private bool displayDetailedInfo;
		
		public const string CMSTYPE = "CM" ;
		public const string CARERESOURCECODE = "CR"; // event creation
		public const string DATEACTUAL = "A"; // event completion date

		private Plan plan;
		private PackingListItemSentCollection packingListItemsSent;
		private Maternichek maternichek;
		private PRRequestCollection pRRequests;
		private OutcomeCollection outcomes;
		private ProblemCollection problems;
		private CMSProblemCollection cMSProblems;
		private AssessmentCollection assessments;
		private CMSDiagnosticProcedureCollection cMSDiagnosticProcedures;

		private string primaryProblemDescription;

		// cached objects
		private PatientSubscriberLog patSubLog;	// cached patsub log object which
		private PlanSORGLog planSorgLog;
		private CMSFacilityCollection cMSFacilities;
		private CMSProviderCollection cMSProviders;
		private EventCollection events;	// cached plansorg log object which
		private ImageLinkCollection images;
		private POCInterventionCollection pOCInterventions;
		
		#region BaseForEventCMSReferral abstract methods overridden

		#region Display ERC Properties Overriden
		/// <summary>
		/// Alwas returns EnumERCType.Event.  This class represents an Event.
		/// </summary>
		public override EnumERCType ERCType
		{
			get { return EnumERCType.CMS; }
		}

		/// <summary>
		/// Alwas returns EnumERCType.Event.  This class represents an Event.
		/// </summary>
		public override string ERCTypeDisplay
		{
			get { return "@CMS@";}
		}

		public override string TypeDisplay
		{
			get 
			{
				if(StatusTypeIdDisplay > 0)
					return CMSStatusTypeCollection.ActiveCMSStatusTypes.Lookup_DescriptionByStatusTypeId(StatusTypeIdDisplay);
				else return "Not set";
			}
		}

		public int StatusTypeIdDisplay; // MUST be loaded ONLY by usp_GetAllCMSesByPatientId used by ERCDisplay properties in order NOT to load CMSStatusHistory For each CMS record
		public int StatusIdDisplay;		// MUST be loaded ONLY by usp_GetAllCMSesByPatientId used by ERCDisplay properties in order NOT to load CMSStatusHistory For each CMS record

		public override bool IsLinkedToProblem
		{
			get { return this.isLinkedToProblem; }
			set { this.isLinkedToProblem = value; }		// set after loading
		}

		public override string ERCDescription
		{
			get {return this.LookupOf_CMSTypeID.Lookup_DescriptionByCMSTypeID(this.CMSTypeID) + "-" + this.CMSID.ToString();  }
		}

		public override DateTime ERCServiceDate
		{
			get { return this.caseStartDate; }
		}

		public override DateTime ERCStartDate
		{
			get { return this.caseStartDate; }
		}

		public override DateTime ERCEndDate
		{
			get { return this.caseEndDate; }
		}

		public override string ERCStatusDisplay
		{
			get 
			{ 
				if (this.StatusIdDisplay > 0)
					return SystemStatusCollection.ActiveSystemStatuses.Lookup_DescriptionByStatusId(this.StatusIdDisplay); 
				else
					return "CMSStatusType is not set in this CMS.";
			}
		}

		public override int ERCStatusID
		{
			get { return this.LatestCMSStatusHistory.StatusId;}
			set { /*this.LatestCMSStatusHistory.StatusId; */}
		}

		public override bool ERCPhysicianReview
		{
			//get { return this.physicianReview; }
			get { return false; }
		}

		public override DateTime ERCLastValidationDate
		{
			get { return this.lastValidationDate; }
			set { this.lastValidationDate = value; }
		}

		public override void UpdateLastValidationDate()
		{
			UpdateCMSLastValidationDate(this.lastValidationDate);
		}

		#endregion

		/// <summary>
		/// Updates the last coverage validation date of this CMS
		/// and also sets the instance member lastValidationDate to the given date.
		/// </summary>
		public void UpdateCMSLastValidationDate(System.DateTime lastValidationDate)
		{
			SqlData.SPExecNonQuery("usp_UpdateCMSLastValidationDate", 
				new object[] { this.cMSID, SQLDataDirect.MakeDBValue(lastValidationDate) });
			this.lastValidationDate = lastValidationDate;
		}
		
		#region Outcomes Overriden
		/// <summary>
		/// Child Outcomes mapped to related rows of table Outcome where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadCMSOutcome", "cMSID")]
		public override OutcomeCollection Outcomes
		{
			get { return this.outcomes; }
			set
			{
				this.outcomes = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}
		
		/// <summary>
		/// Loads the Outcomes collection
		/// </summary>
		public override void LoadOutcomes(bool forceReload)
		{
			this.outcomes = (OutcomeCollection)OutcomeCollection.LoadChildCollection("Outcomes", this, typeof(OutcomeCollection), outcomes, forceReload, null);
		}

		/// <summary>
		/// Saves the Outcomes collection
		/// </summary>
		public override void SaveOutcomes()
		{
			OutcomeCollection.SaveChildCollection(this.outcomes, true);
		}

		/// <summary>
		/// Synchronizes the Outcomes collection
		/// </summary>
		public void SynchronizeOutcomes()
		{
			OutcomeCollection.SynchronizeChildCollection(this.outcomes, true);
		}
		#endregion
		
		#region Problems Overriden
		/// <summary>
		/// Child Problems mapped to related rows of table Problem where [CMSID] = [ProblemID]
		/// </summary>
		[SPLoadChild("usp_GetLinkedCMSProblems", "problemID")]
		public override ProblemCollection Problems
		{
			get { return this.problems; }
			set
			{
				this.problems = value;
			}
		}

		/// <summary>
		/// Loads the Problems collection
		/// </summary>
		public override void LoadProblems(bool forceReload)
		{
			this.problems = (ProblemCollection)ProblemCollection.LoadChildCollection("Problems", this, typeof(ProblemCollection), problems, forceReload, null);
		}

		/// <summary>
		/// Saves the Problems collection
		/// </summary>
		public override void SaveProblems()
		{
			ProblemCollection.SaveChildCollection(this.problems, true);
		}

		/// <summary>
		/// Synchronizes the Problems collection
		/// </summary>
		public void SynchronizeProblems()
		{
			ProblemCollection.SynchronizeChildCollection(this.problems, true);
		}
		#endregion

		#region ProblemLinks Overriden
		/// <summary>
		/// Child CMSProblems mapped to related rows of table CMSProblem where [CMSID] = [CMSId]
		/// </summary>
		[SPLoadChild("usp_LoadAllProblemLinksByCMSId", "cMSId", ManuallyManaged=true)]
		public override BaseERCProblemLinkCollection ERCProblemLinks
		{
			get { return this.cMSProblems; }
			set
			{
				this.cMSProblems = (CMSProblemCollection)value;
				if (value != null)
					value.ParentBaseForEventCMSReferral = this; // set this as a parent of the child collection
			}
		}
		
		/// <summary>
		/// Loads the CMSProblems collection
		/// </summary>
		public override void LoadERCProblemLinks(bool forceReload)
		{
			this.cMSProblems = (CMSProblemCollection)CMSProblemCollection.LoadChildCollection("ERCProblemLinks", this, typeof(CMSProblemCollection), cMSProblems, forceReload, null);
		}

		/// <summary>
		/// Saves the CMSProblems collection
		/// </summary>
		public override void SaveERCProblemLinks()
		{
			CMSProblemCollection.SaveChildCollection(((CMSProblemCollection)this.cMSProblems), false);
		}
		#endregion

		#region DxPx Overriden
		public override void SyncDiagnosticCodes(DiagnosticSelectCollection diagnostics)
		{
			this.LoadCMSDiagnosticProcedures(false);
			this.CMSDiagnosticProcedures.SyncFromSelections(diagnostics);
			this.SaveCMSDiagnosticProcedures();
		}

		public override void SyncProcedureCodes(ProcedureSelectCollection procedures)
		{
			this.LoadCMSDiagnosticProcedures(false);
			this.CMSDiagnosticProcedures.SyncFromSelections(procedures);
			this.SaveCMSDiagnosticProcedures();
		}

		public override DiagnosticSelectCollection CreateDiagnosticSelectionCollection()
		{
			this.LoadCMSDiagnosticProcedures(false);
			return this.CMSDiagnosticProcedures.CreateDiagnosticSelectionCollection();
		}

		public override ProcedureSelectCollection CreateProcedureSelectionCollection()
		{
			this.LoadCMSDiagnosticProcedures(false);
			return this.CMSDiagnosticProcedures.CreateProcedureSelectionCollection();
		}
		#endregion

		#region Images Overriden
		/// <summary>
		/// Child Outcomes mapped to related rows of table Outcome where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadCMSImages", "cMSID")]
		public override ImageLinkCollection Images
		{
			get { return this.images; }
			set
			{
				this.images = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}
				
		/// <summary>
		/// Loads the Outcomes collection
		/// </summary>
		public override void LoadImages(bool forceReload)
		{
			this.images = (ImageLinkCollection)ImageLinkCollection.LoadChildCollection("Images", this, typeof(ImageLinkCollection), images, forceReload, null);
		}

		/// <summary>
		/// Saves the Outcomes collection
		/// </summary>
		public override void SaveImages()
		{
			ImageLinkCollection.SaveChildCollection(this.images, true);
		}

		/// <summary>
		/// Synchronizes the Outcomes collection
		/// </summary>
		public void SynchronizeImages()
		{
			ImageLinkCollection.SynchronizeChildCollection(this.images, true);
		}

		#endregion

		#endregion


		/// <summary>
		/// Child ClinicalReviewRequests mapped to related rows of table ClinicalReviewRequest where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("", "cMSID")] // Custom: usp_LoadCMSPRRequests
		public override PRRequestCollection PRRequests
		{
			get { return this.pRRequests;}
			set
			{
				this.pRRequests = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PRRequests collection
		/// </summary>
		public override void LoadPRRequests(bool forceReload)
		{
			this.pRRequests = (PRRequestCollection)PRRequestCollection.LoadChildCollection("PRRequests", "usp_LoadCMSPRRequests", this, typeof(PRRequestCollection), pRRequests, forceReload, null);
		}

		/// <summary>
		/// Saves the PRRequests collection
		/// </summary>
		public override void SavePRRequests()
		{
			PRRequestCollection.SaveChildCollection(this.pRRequests, true);
		}

		/// <summary>
		/// Synchronizes the PRRequests collection
		/// </summary>
		public void SynchronizePRRequests()
		{
			PRRequestCollection.SynchronizeChildCollection(this.pRRequests, true);
		}


		public CMS()
		{
			this.cMSStatusHistory = null;
			this.pOCDeficits = null;
			this.providerInNetwork = this.facilityInNetwork = -1;
			this.displayDetailedInfo = false;
			this.maternichekId = -1;  // look below for description
			this.maternichek = null;
		}

		public CMS(bool initNew) : this()
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public CMS(bool initNew, Patient patient) : this(initNew)
		{
			this.ParentPatient = patient;
			if (this.patient != null)
				this.patientId = patient.PatientId;
		}

		/// <summary>
		/// Creates new CMS along with new Maternichek.
		/// Must only be used from UI when user creates Maternichek Case (patient summary page)
		/// </summary>
		/// <param name="initNew"></param>
		/// <param name="createMaternichek"></param>
		/// <param name="patient"></param>
		public CMS(bool initNew, bool createMaternichek, Patient patient) : this(initNew, patient)
		{
			if(!createMaternichek)
				return;

			AddMaternichek(true);
			this.CMSTypeID = Maternichek.CMSTypeCodeId;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, /*IsRequired=true,*/ ValueForNull = (int)0)]
		[FieldDescription("@CMSID@")]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		public static int CMSTypeCodeId
		{
			get { return CMSTypeCollection.ActiveCMSTypes.Lookup_CMSTypeIDByCode(CMSTYPE); }
		}
		
		[FieldDescription("@ALTCMSID@")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateCMSID
		{
			get { return this.alternateCMSID; }
			set { this.alternateCMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public override int PrimaryProblemID
		{
			get { return this.primaryProblemID; }
			set { this.primaryProblemID = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		[FieldDescription("@CASESTARTDATE@")]
		public System.DateTime CaseStartDate
		{
			get { return this.caseStartDate; }
			set { this.caseStartDate = value; }
		}

		[ValidatorMember("Vld_CaseEndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CaseEndDate
		{
			get { return this.caseEndDate; }
			set { this.caseEndDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DaysOpen
		{
			//BR01.9.1.2	The days open shall be calculated as follows
			// If End Date is present, then days open = end date � start date
			// If End Date not present, then days open = current date � start date
			get
			{
				if(this.caseEndDate > DateTime.MinValue)
					return this.caseEndDate.Subtract(this.caseStartDate).Days;
				else
					return DateTime.Now.Subtract(this.caseStartDate).Days;
			}
		}

		[FieldValuesMember("LookupOf_CaseSourceID", "CaseSourceID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CaseSourceID
		{
			get { return this.caseSourceID; }
			set { this.caseSourceID = value; }
		}

		[FieldValuesMember("LookupOf_CaseOpenReasonID", "CaseOpenReasonId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CaseOpenReasonID
		{
			get { return this.caseOpenReasonID; }
			set { this.caseOpenReasonID = value; }
		}

		[FieldValuesMember("LookupOf_CaseContinuedReasonID", "CaseContinuedReasonId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CaseContinuedReasonID
		{
			get { return this.caseContinuedReasonID; }
			set { this.caseContinuedReasonID = value; }
		}

		[FieldValuesMember("LookupOf_CaseClosedReasonID", "CaseClosedReasonId", "Description")]
		[FieldDescription("@REASON@")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CaseClosedReasonID
		{
			get { return this.caseClosedReasonID; }
			set { this.caseClosedReasonID = value; }
		}

		[FieldValuesMember("LookupOf_PatientAuthorizerID", "PatientAuthorizerId", "Description")]
		[FieldDescription("@BYWHOM@")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int PatientAuthorizerID
		{
			get { return this.patientAuthorizerID; }
			set { this.patientAuthorizerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DATE@")]
		public System.DateTime PatientAuthorizationDate
		{
			get { return this.patientAuthorizationDate; }
			set { this.patientAuthorizationDate = value; }
		}

		[FieldValuesMember("LookupOf_ClientAuthorizerID", "ClientAuthorizerId", "Description")]
		[FieldDescription("@BYWHOM@")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ClientAuthorizerID
		{
			get { return this.clientAuthorizerID; }
			set { this.clientAuthorizerID = value; }
		}

		[FieldDescription("@DATE@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ClientAuthorizationDate
		{
			get { return this.clientAuthorizationDate; }
			set { this.clientAuthorizationDate = value; }
		}

		[FieldValuesMember("LookupOf_CMSTypeID", "CMSTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int CMSTypeID
		{
			get { return this.cMSTypeID; }
			set { this.cMSTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[FieldDescription("@REFPROVIDERSPECIALTYID@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=0)]
		public int PrimaryProviderSpecialtyID
		{
			get { return this.primaryProviderSpecialtyID; }
			set { this.primaryProviderSpecialtyID = value; }
		}

		[FieldDescription("@REFPROVIDERLOCATIONID@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=0)]
		public int PrimaryProviderLocationID
		{
			get { return this.primaryProviderLocationID; }
			set { this.primaryProviderLocationID = value; }
		}

		[FieldDescription("@PROVIDERNETWORKID@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=0)]
		public int PrimaryProviderLocationNetworkID
		{
			get { return this.primaryProviderLocationNetworkID; }
			set { this.primaryProviderLocationNetworkID = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int PrimaryProviderNetworkStatus
		{
			get { return this.primaryProviderNetworkStatus; }
			set { this.primaryProviderNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PrimaryProviderLocationContactID
		{
			get { return this.primaryProviderLocationContactID; }
			set { this.primaryProviderLocationContactID = value; }
		}

		[FieldValuesMember("LookupOf_PrimaryFacilityTypeID", "FacilityTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@FACILITYTYPEID@")]
		public int PrimaryFacilityTypeID
		{
			get { return this.primaryFacilityTypeID; }
			set { this.primaryFacilityTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@FACILITYLOCATIONID@")]
		public int PrimaryFacilityLocationID
		{
			get 
			{ 
				return this.primaryFacilityLocationID; 
				
			}
			set { this.primaryFacilityLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@FACILITYLOCATIONNETWORKID@")]
		public int PrimaryFacilityLocationNetworkID
		{
			get { return this.primaryFacilityLocationNetworkID; }
			set { this.primaryFacilityLocationNetworkID = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int PrimaryFacilityNetworkStatus
		{
			get { return this.primaryFacilityNetworkStatus; }
			set { this.primaryFacilityNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PrimaryFacilityLocationContactID
		{
			get { return this.primaryFacilityLocationContactID; }
			set { this.primaryFacilityLocationContactID = value; }
		}

		[FieldDescription("@PROVIDER@")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PrimaryProviderID
		{
			get { return this.primaryProviderID; }
			set { this.primaryProviderID = value; }
		}

		[FieldDescription("@FACILITYID@")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PrimaryFacilityID
		{
			get { return this.primaryFacilityID; }
			set { this.primaryFacilityID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		[FieldDescription("@NAME@")]
		public string FacilityName
		{
			get 
			{ 
				// Facility Object will be passed to this object from pop-up search
				this.fAcility.Load(this.primaryFacilityID);
				return this.fAcility.Name;
			}
		}
		
		[FieldValuesMember("LookupOf_NetworkStatus")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)-1)]
		public int ProviderInNetwork
		{	//"1 - In Network; 0 - Out Network; -1(NULL) - Not specified"
			get { return this.providerInNetwork; }
			set { this.providerInNetwork = value; }
		}

		[FieldValuesMember("LookupOf_NetworkStatus")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)-1)]
		public int FacilityInNetwork
		{	//"1 - In Network; 0 - Out Network; -1(NULL) - Not specified"
			get { return this.facilityInNetwork; }
			set { this.facilityInNetwork = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		[FieldDescription("@CLIENTREPORTCONTACT@")]
		public string ClientReportContact
		{
			get { return this.clientReportContact; }
			set { this.clientReportContact = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public override int PatientSubscriberLogID
		{
			get { return this.patientSubscriberLogID; }
			set 
			{ 
				this.patientSubscriberLogID = value;
				this.patSubLog = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public override int PlanSORGLogID
		{
			get { return this.planSorgLogID; }
			set 
			{ 
				this.planSorgLogID = value; 
				this.planSorgLog = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public override int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		public ActiveAdvice.DataLayer.Plan Plan
		{
			get { return this.plan; }
			set { this.plan = value; }
		}

		public ActiveAdvice.DataLayer.Patient Patient
		{
			get 
			{ 
				return ParentPatient;
			}
		}

		[FieldDescription("@FROMDATE@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ReportDateFrom
		{
			get { return this.reportDateFrom; }
			set { this.reportDateFrom = value; }
		}

		[FieldDescription("@TODATE@")]
		[ValidatorMember("Vld_ReportDateTo")] //- turn on when RenderClientFunctions is fixed (silently renders all custom validator incorrectly)
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ReportDateTo
		{
			get { return this.reportDateTo; }
			set { this.reportDateTo = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool DisplayDetailedInfo
		{
			get { return this.displayDetailedInfo; }
			set { this.displayDetailedInfo = value; }
		}
		
		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (this.IsNew)
				return;

			writer.AddFieldsSubstituted(this, "@CMSID@", "@CMS@");
			writer.AddField(this, "AlternateCMSID");
			writer.AddField(this, "CaseStartDate");
			if(this.caseEndDate > DateTime.MinValue)
				writer.AddField(this, "CaseEndDate");
			
			if(this.displayDetailedInfo)
				writer.AddHeaderLabelandValue("Days Open", this.DaysOpen.ToString());
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			this.startDateWhenLoaded = this.caseStartDate;
		}

		public bool StartDateChanged
		{
			get
			{
				return this.startDateWhenLoaded != this.caseStartDate;
			}
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Link to or unlink from the given problem.
		/// If linkUnlink = true, link problem to this ERC.
		/// If linkUnlink = false, unklink problem from this ERC.
		/// Called by PatientSummary when Problem is linked.
		/// </summary>
		/// <param name="problem"></param>
		/// <param name="linkUnlink"></param>
		public override void LinkToProblem(Problem problem, bool linkUnlink)
		{
			if (this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "New CMS cannot be linked or unlinked!");
			if (problem.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "New problem cannot be linked or unlinked!");

			if (problem.ProblemID == this.primaryProblemID)
				if (!linkUnlink)
					throw new ActiveAdviceException(AAExceptionAction.None, "@CANTUNLINKPRIMARYPROBLEM@");

			// Ensure problem-CMS link
			CMSProblem cmsProblem = new CMSProblem(this.cMSID, problem.ProblemID, true);
			if (cmsProblem.ProblemCMSExists())		// linked
			{
				if (!linkUnlink)	// if unlink is requested
				{					// delete
					//cmsProblem.MarkDel();
					cmsProblem.Delete();
				}
			}
			else		// not linked
			{
				if (linkUnlink)		// if link is requrested
					cmsProblem.Insert();		// create the link
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public void Save(PatientCoverage patCov, Problem problem)
		{
			this.autoActivityManager = null;

			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			if (!this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "CMS.Save(problem) can be called only for a new CMS");
			
			if (ParentPatient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "A new CMS can be saved only in the context of a patient");

			if (patCov == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "A new CMS can be saved only in the context of a patient-subscriber-coverage");
			
			if (problem == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "The problem passed to the CMS.Save(problem) was null");
			
			if (problem.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "The problem passed to the CMS.Save(problem) is new.  It must exist in the db!");

			this.SqlData.EnsureTransaction();
			try
			{
				PlanSORGLog lastPlanSORGLog = PlanSORGLog.GetLastPlanSORGLogEntry(this.SqlData.Transaction, patCov.Plan, patCov.SORG);
				if (lastPlanSORGLog == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI,
						"No plan-sorg-log entry found for PlanID={0}, SORGID={1}", patCov.PlanID, patCov.SORGID);
				this.planSorgLogID = lastPlanSORGLog.PlanSorgLogId;

				
				PatientSubscriberLog lastPatSubLog = PatientSubscriberLog.GetLastPatientSubscriberLogEntry(this.SqlData.Transaction, patient, patCov);
				if (lastPatSubLog == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI,
						"No patient-subscriber-log entry found for PatientID={0}, PatientCoverageID={1}", patient.PatientId, patCov.PatientCoverageID);
				this.patientSubscriberLogID = lastPatSubLog.PatientSubscriberLogId;

				base.Save();

				// Create the Problem - CMS link
				this.primaryProblemID = problem.ProblemID;
				CMSProblem cMSProblem = new CMSProblem(this.cMSID, this.primaryProblemID, true);
				cMSProblem.SqlData.Transaction = this.SqlData.Transaction;
				cMSProblem.Insert();

				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Save method for an existing CMS.
		/// When an existing CMS is saved, no links get created.  So we don't need context.
		/// </summary>
		public new void Save()
		{
			this.autoActivityManager = null;

			if (this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must save a new CMS only in the context of a plan-sorg-log entry or a patient-subscriber-log entry");

			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI,
					"You must save an existing CMS only in the context of a patient");

			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();

				if (this.primaryProblemID != 0)
				{
					// Ensure problem-CMS link
					CMSProblem cMSProblem = new CMSProblem(this.cMSID, this.primaryProblemID, true);
					if (!cMSProblem.ProblemCMSExists())
					{
						cMSProblem.SqlData.Transaction = this.SqlData.Transaction;
						cMSProblem.Insert();
					}
				}
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}	
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			bool initialSave = this.IsNew;
			CheckBusinessRules();
			base.InternalSave();
			// Save the child collections here.			
			cMSStatusHistory.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			cMSStatusHistory.CMSId = this.cMSID;
			cMSStatusHistory.Save();

			if (this.maternichek != null )
			{
				maternichek.SqlData.Transaction = this.SqlData.Transaction;
				maternichek.CMSId = this.CMSID;
				maternichek.Save();
				this.maternichekId = this.maternichek.MaternichekId;
			}

			SavePackingListItemsSent();
			SavePOCDeficits();
			SaveOutcomes();
			SaveAssessments();

			#region Trigger AutoActivities - CM1

			PatientCoverage patCov = null;
			if (this.PatientSubscriberLog != null)
				patCov = this.PatientSubscriberLog.PatientCoverage;

			if (initialSave)
				AutoActivity_CMSInitialSave(patient, patCov);	// ES1

			#endregion

		}

		/// <summary>
		/// CM1	- CMS Initial Save
		/// This is triggered when the CMS is saved the first time by an insertion.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="patCov"></param>
		protected void AutoActivity_CMSInitialSave(Patient patient, PatientCoverage patCov)
		{
			autoActivityManager = new AutoActivityManager(patient, patCov, null, this);
			autoActivityManager.Execute(AutoActivityRuleType.CM1, this.SqlData.Transaction);
		}

		private void CheckBusinessRules()
		{
			string s = this.LatestCMSStatusHistory.StatusCode;
			
			if (this.caseEndDate == DateTime.MinValue && s == SystemStatus.DECLINED)
				throw new ActiveAdviceException("Case End Date is Required for selected case status!");
			if (this.caseEndDate == DateTime.MinValue && s == SystemStatus.CLOSED)
				throw new ActiveAdviceException("Case End Date is Required for selected case status!");

			if (this.caseEndDate != DateTime.MinValue)
			{
				if (this.caseStartDate == DateTime.MinValue) // BRO1.9.12 Start Date must be set if End Date is specified
					throw new ActiveAdviceException(CMSMessages.MessageIDs.ERRCMSSTARTDATE);
				if (this.caseEndDate.Date < this.caseStartDate.Date)  // BRO1.9.15 End Date can't be less than Start Date
					throw new ActiveAdviceException(CMSMessages.MessageIDs.ERRCMSDATE); 
			}	
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int cMSID)
		{
			return base.Load(cMSID);
		}

		public override bool LoadERC(int ercID)
		{
			return Load(ercID);
		}


		private bool LoadMostRecentCMSStatusHistory()
		{
			if(cMSID > 1)
				return this.cMSStatusHistory.GetMostRecentCMSStatusHistoryByCMSId(cMSID);
			else
				return false;
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int cMSID)
		{
			base.Delete(cMSID);		
		}
		
		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		
		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state
		}

		/// <summary>
		/// Parent CMSCollection that contains this element
		/// </summary>
		public CMSCollection ParentCMSCollection
		{
			get
			{
				return this.parentCMSCollection;
			}
			set
			{
				this.parentCMSCollection = value; // parent is set when added to a collection
			}
		}

		#region CMSEventCollection CMSEvents
		/// <summary>
		/// Child CMSEvents mapped to related rows of table CMSEvent where [CMSID] = [EventID]
		/// </summary>
		[SPLoadChild("usp_LoadCMSCMSEvent", "eventID")]
		public CMSEventCollection CMSEvents
		{
			get { return this.cMSEvents; }
			set
			{
				this.cMSEvents = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the CMSEvents collection
		/// </summary>
		public void LoadCMSEvents(bool forceReload)
		{
			this.cMSEvents = (CMSEventCollection)CMSEventCollection.LoadChildCollection("CMSEvents", this, typeof(CMSEventCollection), cMSEvents, forceReload, null);
		}

		/// <summary>
		/// Saves the CMSEvents collection
		/// </summary>
		public void SaveCMSEvents()
		{
			CMSEventCollection.SaveChildCollection(this.cMSEvents, true);
		}

		/// <summary>
		/// Synchronizes the CMSEvents collection
		/// </summary>
		public void SynchronizeCMSEvents()
		{
			CMSEventCollection.SynchronizeChildCollection(this.cMSEvents, true);
		}
		#endregion

		#region CMSStatusHistoryCollection CMSStatusHistories
		/// <summary>
		/// Child CMSStatusHistories mapped to related rows of table CMSStatusHistory where [CMSID] = [CMSId]
		/// </summary>
		[SPLoadChild("usp_LoadCMSCMSStatusHistory", "cMSId") /*make sure to add ORDER BY [CreateTime] DESC*/]
		public CMSStatusHistoryCollection CMSStatusHistories
		{
			get { return this.cMSStatusHistories; }
			set
			{
				this.cMSStatusHistories = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the CMSStatusHistories collection
		/// </summary>
		public void LoadCMSStatusHistories(bool forceReload)
		{
			this.cMSStatusHistories = (CMSStatusHistoryCollection)CMSStatusHistoryCollection.LoadChildCollection("CMSStatusHistories", this, typeof(CMSStatusHistoryCollection), cMSStatusHistories, forceReload, null);
		}

		/// <summary>
		/// Saves the CMSStatusHistories collection
		/// </summary>
		public void SaveCMSStatusHistories()
		{
			CMSStatusHistoryCollection.SaveChildCollection(this.cMSStatusHistories, true);
		}

		/// <summary>
		/// Synchronizes the CMSStatusHistories collection
		/// </summary>
		public void SynchronizeCMSStatusHistories()
		{
			CMSStatusHistoryCollection.SynchronizeChildCollection(this.cMSStatusHistories, true);
		}
		#endregion

		#region LookUp Properties
		public CMSTypeCollection LookupOf_CMSTypeID
		{
			get
			{
				return CMSTypeCollection.ActiveCMSTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public CaseOpenReasonCollection LookupOf_CaseOpenReasonID
		{
			get
			{
				return CaseOpenReasonCollection.ActiveCaseOpenReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public CaseContinuedReasonCollection LookupOf_CaseContinuedReasonID
		{
			get
			{
				return CaseContinuedReasonCollection.ActiveCaseContinuedReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public CaseClosedReasonCollection LookupOf_CaseClosedReasonID
		{
			get
			{
				return CaseClosedReasonCollection.ActiveCaseClosedReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public CaseSourceCollection LookupOf_CaseSourceID
		{
			get
			{
				return CaseSourceCollection.ActiveCaseSources; // Acquire a shared instance from the static member of collection
			}
		}

		public PatientAuthorizerCollection LookupOf_PatientAuthorizerID
		{
			get
			{
				return PatientAuthorizerCollection.ActivePatientAuthorizers; // Acquire a shared instance from the static member of collection
			}
		}

		public ClientAuthorizerCollection LookupOf_ClientAuthorizerID
		{
			get
			{
				return ClientAuthorizerCollection.ActiveClientAuthorizers; // Acquire a shared instance from the static member of collection
			}
		}

		public FacilityTypeCollection LookupOf_PrimaryFacilityTypeID
		{
			get
			{
				return FacilityTypeCollection.ActiveFacilityTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public object[,] LookupOf_NetworkStatus
		{
			get
			{
				return base.ValuesOf_NetworkStatuses; // Acquire a shared instance from the static member of collection
			}
		}
		#endregion

		#region LatestCMSStatusHistory
		public ActiveAdvice.DataLayer.CMSStatusHistory LatestCMSStatusHistory
		{
			get 
			{ 
				if (cMSStatusHistory == null)
				{
					this.cMSStatusHistory = new CMSStatusHistory();
					this.cMSStatusHistory.SqlData.Transaction = this.SqlData.Transaction;
					if (!this.LoadMostRecentCMSStatusHistory())
					{
						//mark CMSStatusHistory Object as new because Load failed
						this.cMSStatusHistory.MarkNew();
						this.cMSStatusHistory.CMSId = this.cMSID;
					}
				}

				return this.cMSStatusHistory; 
			}
			set
			{
				this.cMSStatusHistory = value;
			}
		}

		#endregion

		public ActiveAdvice.DataLayer.Facility PrimaryFacility
		{
			get
			{
				return this.fAcility;
			}
			
		}
		
		[GenericScript("Vld_CaseEndDate", "@CaseEndDate@ != null && @CaseEndDate@ >= @CaseStartDate@;")]
		public string Vld_CaseEndDate
		{
			get
			{
				return CMSMessages.MessageIDs.ERRCMSDATE; // return warning prompt message or the warning in advance to be used by client validators
			}
			set {}
		}

		[GenericScript("Vld_ReportDateTo", "@ReportDateTo@ != null && @ReportDateTo@ >= @ReportDateFrom@;")]
		public string Vld_ReportDateTo
		{
			get
			{
				return CMSMessages.MessageIDs.ERRENDDATE; // return warning prompt message or the warning in advance to be used by client validators
			}
			set {}
		}

		#region POCDeficit Collection
		/// <summary>
		/// Child POCDeficits mapped to related rows of table POCDeficit where [CMSID] = [CMSId]
		/// </summary>
		[SPLoadChild("usp_LoadCMSPOCDeficit", "cMSId")]
		public POCDeficitCollection POCDeficits
		{
			get
			{
				this.LoadPOCDeficits(false);
				return this.pOCDeficits; 
			}
			set
			{
				this.pOCDeficits = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the POCDeficits collection
		/// </summary>
		public void LoadPOCDeficits(bool forceReload)
		{
			this.pOCDeficits = (POCDeficitCollection)POCDeficitCollection.LoadChildCollection("POCDeficits", this, typeof(POCDeficitCollection), pOCDeficits, forceReload, null);
		}

		/// <summary>
		/// Saves the POCDeficits collection
		/// </summary>
		public void SavePOCDeficits()
		{
			POCDeficitCollection.SaveChildCollection(this.pOCDeficits, true);
		}

		/// <summary>
		/// Synchronizes the POCDeficits collection
		/// </summary>
		public void SynchronizePOCDeficits()
		{
			POCDeficitCollection.SynchronizeChildCollection(this.pOCDeficits, true);
		}
		#endregion

		#region PackingListItemSent Collection
		/// <summary>
		/// Child PackingListItemsSent mapped to related rows of table PackingListItemSent where [CMSID] = [CMSId]
		/// </summary>
		[SPLoadChild("usp_LoadCMSPackingListItemSent", "cMSId")]
		public PackingListItemSentCollection PackingListItemsSent
		{
			get { return this.packingListItemsSent; }
			set
			{
				this.packingListItemsSent = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PackingListItemSent collection
		/// </summary>
		public void LoadPackingListItemsSent(bool forceReload)
		{
			this.packingListItemsSent = (PackingListItemSentCollection)PackingListItemSentCollection.LoadChildCollection("PackingListItemsSent", this, typeof(PackingListItemSentCollection), packingListItemsSent, forceReload, null);
		}

		/// <summary>
		/// Saves the PackingListItemsSent collection
		/// </summary>
		public void SavePackingListItemsSent()
		{
			PackingListItemSentCollection.SaveChildCollection(this.packingListItemsSent, true);
		}

		/// <summary>
		/// Synchronizes the PackingListItemsSent collection
		/// </summary>
		public void SynchronizePackingListItemsSent()
		{
			PackingListItemSentCollection.SynchronizeChildCollection(this.packingListItemsSent, true);
		}
		#endregion

		#region Maternichek
		// this variable is used to optimize this.Maternichek
		// -1 = initial state = this.Maternichek was never accessed before
		//  0 = this has NO Maternichek related to it = this.Maternichek == null
		// >0 = PK of associated Maternichek
		private int maternichekId;

		/// <summary>
		/// Contained Maternichek object
		/// </summary>
		public Maternichek Maternichek
		{
			get
			{
				if(this.maternichekId == -1)
				{
					this.maternichekId = 0;

					if (this.patient.Gender != null && this.patient.Gender == GenderCode.Female)
					{
						Maternichek m = new Maternichek();
						if (cMSID > 0 && m.LoadMaternichekByCMSid(cMSID)) //new MC case already has Maternichek object initialized at this point. It was done with special constructor.
						{
							this.maternichek = m;
							this.maternichekId = m.MaternichekId;
							this.maternichek.CMS = this;
						}
					}
				}
				
				return this.maternichek;
			}
		}

		/// <summary>
		/// Adds new Maternichek object to existing CMS.
		/// Must be used from Assessment module.
		/// This operation must NOT update CMSTypeID in order to prevent user from seeing "Maternichek" tab in UI
		/// since user have not created Maternichek explicitly.
		/// </summary>
		/// <param name="initNew"></param>
		public void AddMaternichek(bool initNew)
		{
			if (ParentPatient.Gender != GenderCode.Female)
				return;
			
			this.maternichek = new Maternichek(initNew);
			this.maternichek.CMS = this;
			this.maternichek.CMSId = this.cMSID;
			this.maternichekId = 0;
		}

		/// <summary>
		/// IMPORTANT!!!!
		/// This method MUST NO be called from any module other than the Assessments
		/// </summary>
		public void RemoveMaternichek()
		{
			if (this.maternichek != null && this.maternichek.IsNew)
			{
				this.maternichek = null;
				this.maternichekId = 0;
			}
			else // Reload existing maternichek next time
			{
				this.maternichek = null;
				this.maternichekId = -1;
			}
		}
		#endregion

		#region Assessments Collection
		/// <summary>
		/// Child Assessments mapped to related rows of table Assessment where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadCMSAssessmentInOrder", "cMSID", ManuallyManaged=true)] // THIS IS NOT USED: SEE LoadAssessments
		public AssessmentCollection Assessments			// ORDER BY [Assessment].[CreateTime] DESC
		{
			get { return this.assessments; }
			set
			{
				this.assessments = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Assessments collection
		/// </summary>
		public void LoadAssessments(bool forceReload)
		{
			this.assessments = (AssessmentCollection)AssessmentCollection.LoadChildCollection("Assessments", "usp_LoadCMSAssessmentInOrder", this, typeof(AssessmentCollection), assessments, forceReload, null, new object[] {this.cMSID});
		}

		/// <summary>
		/// Saves the Assessments collection
		/// </summary>
		public void SaveAssessments()
		{
			AssessmentCollection.SaveChildCollection(this.assessments, true);
		}

		/// <summary>
		/// Synchronizes the Assessments collection
		/// </summary>
		public void SynchronizeAssessments()
		{
			AssessmentCollection.SynchronizeChildCollection(this.assessments, true);
		}
		#endregion
		
		#region Dx/Px Collection
		/// <summary>
		/// Child CMSDiagnosticProcedures mapped to related rows of table CMSDiagnosticProcedure where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadCMSCMSDiagnosticProcedure", "cMSID")]
		public CMSDiagnosticProcedureCollection CMSDiagnosticProcedures
		{
			get { return this.cMSDiagnosticProcedures; }
			set
			{
				this.cMSDiagnosticProcedures = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the CMSDiagnosticProcedures collection
		/// </summary>
		public void LoadCMSDiagnosticProcedures(bool forceReload)
		{
			this.cMSDiagnosticProcedures = (CMSDiagnosticProcedureCollection)CMSDiagnosticProcedureCollection.LoadChildCollection("CMSDiagnosticProcedures", this, typeof(CMSDiagnosticProcedureCollection), cMSDiagnosticProcedures, forceReload, null);
		}

		/// <summary>
		/// Saves the CMSDiagnosticProcedures collection
		/// </summary>
		public void SaveCMSDiagnosticProcedures()
		{
			CMSDiagnosticProcedureCollection.SaveChildCollection(this.cMSDiagnosticProcedures, true);
		}

		/// <summary>
		/// Synchronizes the CMSDiagnosticProcedures collection
		/// </summary>
		public void SynchronizeCMSDiagnosticProcedures()
		{
			CMSDiagnosticProcedureCollection.SynchronizeChildCollection(this.cMSDiagnosticProcedures, true);
		}
		#endregion


		public POCIntervention CheckForExistingDGI(InterventionTemplate interventionTemplate)
		{
			this.LoadPOCDeficits(false);

			foreach(POCDeficit deficit in this.POCDeficits)		
			{
				if (deficit.DeficitTypeID == interventionTemplate.POCDeficitTypeID)
				{
					deficit.LoadPOCGoals(false);
					foreach (POCGoal goal in deficit.POCGoals)
					{
						if (goal.GoalTypeId == interventionTemplate.POCGoalTypeID)
						{
							goal.LoadPOCInterventions(false);
							foreach (POCIntervention intervention in goal.POCInterventions)
							{
								if (intervention.InterventionTypeID == interventionTemplate.InterventionTypeID)
								{
									return intervention;
								}
							}
						}
					}
				}
			}
			return null;
		}



		/// <summary>
		/// This method given an intervention template finds the POCIntervention and trys to remove it.
		/// - If the intervention is already in the DB we're not supposed to delete it
		/// - If when the intervention is removed the goal that contains the that intervention is no longer needed
		///   (meaning it's a new goal that we just created and doesn't have any other interventions) we remove the goal as well
		/// - If when the goal is removed the deficit that contains the goal is no longer needed
		///	  (meaning it's a new deficit that we just created and doesn't have any other goals) we remove the deficit as well  	  
		/// </summary>
		/// <param name="iTemplate"></param>
		/// <returns></returns>
		public bool RemoveDGI(InterventionTemplate iTemplate) 
		{
			// Let's find the intervention
			POCIntervention intervention = CheckForExistingDGI(iTemplate);

			// If there is no intervention or if it's already in the DB we're not supposed to remove it.
			if (intervention == null || !intervention.IsNew) return false; 

			POCGoal goal = intervention.ParentPOCInterventionCollection.ParentPOCGoal;
			POCDeficit deficit = goal.ParentPOCGoalCollection.ParentPOCDeficit;
			
			// Since it's a new record we just need to remove it from the parent collection
			goal.POCInterventions.RemoveRecord(intervention);

			// Let's see if the goal has any more interventions if so we're not going to touch it
			foreach (POCIntervention currentIntervention in goal.POCInterventions)
			{
				if (!currentIntervention.IsNew || !currentIntervention.IsMarkedForDeletion) 
				{
					// There is at least one intervention that we cannot touch
					// Just leave and since we already removed the intervention return true
					return true;
				}
			}

			// If we came to this point that means goal doesn't have anymore interventions that we care about
			// Let's remove the goal
			deficit.POCGoals.RemoveRecord(goal);

			// Let's see if the deficit has any more goals if so we're not going to touch it
			foreach (POCGoal currentGoal in deficit.POCGoals)
			{
				if (!currentGoal.IsNew || !currentGoal.IsMarkedForDeletion) 
				{
					// There is at least one goal that we cannot touch
					// Just leave and since we already removed the intervention return true
					return true;
				}
			}
            
			// If we came to this point that means deficit doesn't have anymore goals that we care about
			// Let's remove the deficit
			this.POCDeficits.RemoveRecord(deficit);

            return true;
		}



		/// <summary>
		/// Ensures that a specific DGI is included in this CMS
		/// </summary>
		/// <param name="deficitTypeID"></param>
		/// <param name="goalTypeID"></param>
		/// <param name="interventionTypeID"></param>
		/// <returns></returns>
		public POCIntervention EnsureDGI(InterventionTemplate interventionTemplate)
		{
            POCDeficit newDeficit = null;
			POCGoal newGoal = null;
			POCIntervention newIntervention = null;

			this.LoadPOCDeficits(false);
			foreach(POCDeficit deficit in this.pOCDeficits)		
			{
				if (deficit.DeficitTypeID == interventionTemplate.POCDeficitTypeID)
				{
					// We've found an existing deficit that we can use
					// Check if it's marked for deletion, if so recover it
					if (deficit.IsMarkedForDeletion)
					{
						deficit.IsMarkedForDeletion = false;
					}

					deficit.LoadPOCGoals(false);
					foreach (POCGoal goal in deficit.POCGoals)
					{
						if (goal.GoalTypeId == interventionTemplate.POCGoalTypeID)
						{
							// We've found an existing goal that we can use
							// Check if it's marked for deletion, if so recover it
							if (goal.IsMarkedForDeletion) 
							{
								goal.IsMarkedForDeletion = false;
							}

							goal.LoadPOCInterventions(false);
							foreach (POCIntervention intervention in goal.POCInterventions)
							{
								if (intervention.InterventionTypeID == interventionTemplate.InterventionTypeID)
								{
									// Intervention already exits
									// Check if it's marked for deletion, if so recover it
									if (intervention.IsMarkedForDeletion)
									{
										intervention.IsMarkedForDeletion = false;
									}

									// Return what we have
									return intervention;
								}
							}

							// Deficit and Goal exists but Intervention is not there
							// So create the intervention
							newIntervention = new POCIntervention(true);
							newIntervention.GoalID = goal.GoalId;
							newIntervention.InterventionTypeID = interventionTemplate.InterventionTypeID;
							goal.POCInterventions.Add(newIntervention);
                            goal.IsDirty = true;
							deficit.IsDirty = true;

							return newIntervention;
						}
					}

					// Deficit exits but Goal and Intervention are not there
					// So create the Goal and Intervention

					newGoal = new POCGoal(true);
					newGoal.GoalTypeId = interventionTemplate.POCGoalTypeID;
					deficit.POCGoals.Add(newGoal);
					deficit.IsDirty = true;

					newIntervention = new POCIntervention(true);
					newIntervention.InterventionTypeID = interventionTemplate.InterventionTypeID;
					newGoal.POCInterventions.Add(newIntervention);
					return newIntervention;

				}
			}

			// DGI is not there
			// Create whole tree
			newDeficit = new POCDeficit(true, true);
			newDeficit.DeficitTypeID = interventionTemplate.POCDeficitTypeID;
			this.POCDeficits.Add(newDeficit);

			newGoal = new POCGoal(true);
			newGoal.GoalTypeId = interventionTemplate.POCGoalTypeID;
			newDeficit.POCGoals.Add(newGoal);

			newIntervention = new POCIntervention(true);
			newIntervention.InterventionTypeID = interventionTemplate.InterventionTypeID;
			newGoal.POCInterventions.Add(newIntervention);

			return newIntervention;
		}

		/// <summary>
		/// Returns the loaded and cached patient subscriber log entry
		/// </summary>
		public override PatientSubscriberLog PatientSubscriberLog
		{
			get
			{
				if (this.patSubLog == null)
					this.patSubLog = GetPatientSubscriberLog();
				return this.patSubLog;
			}
		}

		/// <summary>
		/// Loads and retuns the linked patient subscriber log entry
		/// </summary>
		/// <returns></returns>
		public PatientSubscriberLog GetPatientSubscriberLog()
		{
			if (this.patientSubscriberLogID == 0)
				return null;
			PatientSubscriberLog patSubLog = new PatientSubscriberLog();
			patSubLog.SqlData.Transaction = this.SqlData.Transaction;
			if (patSubLog.Load(this.patientSubscriberLogID))
				return patSubLog;
			else
				return null;
		}


		/// <summary>
		/// Returns the loaded and cached plan sorg log entry
		/// </summary>
		public override PlanSORGLog PlanSORGLog
		{
			get
			{
				if (this.planSorgLog == null)
					this.planSorgLog = GetPlanSorgLog();
				return this.planSorgLog;
			}
		}

		/// <summary>
		/// Loads and retuns the linked plan sorg log entry
		/// </summary>
		/// <returns></returns>
		public PlanSORGLog GetPlanSorgLog()
		{
			if (this.planSorgLogID == 0)
				return null;
			PlanSORGLog planSorgLog = new PlanSORGLog();
			planSorgLog.SqlData.Transaction = this.SqlData.Transaction;
			if (planSorgLog.Load(this.planSorgLogID))
				return planSorgLog;
			else
				return null;
		}

		#region CMSFacilities
		/// <summary>
		/// Child CMSFacilities mapped to related rows of table CMSFacility where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadCMSCMSFacility", "cMSID")]
		public CMSFacilityCollection CMSFacilities
		{
			get { return this.cMSFacilities; }
			set
			{
				this.cMSFacilities = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the CMSFacilities collection
		/// </summary>
		public void LoadCMSFacilities(bool forceReload)
		{
			this.cMSFacilities = (CMSFacilityCollection)CMSFacilityCollection.LoadChildCollection("CMSFacilities", this, typeof(CMSFacilityCollection), cMSFacilities, forceReload, null);
		}

		/// <summary>
		/// Saves the CMSFacilities collection
		/// </summary>
		public void SaveCMSFacilities()
		{
			CMSFacilityCollection.SaveChildCollection(this.cMSFacilities, true);
		}

		/// <summary>
		/// Synchronizes the CMSFacilities collection
		/// </summary>
		public void SynchronizeCMSFacilities()
		{
			CMSFacilityCollection.SynchronizeChildCollection(this.cMSFacilities, true);
		}
		#endregion

		#region CMSProviders
		/// <summary>
		/// Child CMSProviders mapped to related rows of table CMSProvider where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadCMSCMSProvider", "cMSID")]
		public CMSProviderCollection CMSProviders
		{
			get { return this.cMSProviders; }
			set
			{
				this.cMSProviders = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the CMSProviders collection
		/// </summary>
		public void LoadCMSProviders(bool forceReload)
		{
			this.cMSProviders = (CMSProviderCollection)CMSProviderCollection.LoadChildCollection("CMSProviders", this, typeof(CMSProviderCollection), cMSProviders, forceReload, null);
		}

		/// <summary>
		/// Saves the CMSProviders collection
		/// </summary>
		public void SaveCMSProviders()
		{
			CMSProviderCollection.SaveChildCollection(this.cMSProviders, true);
		}

		/// <summary>
		/// Synchronizes the CMSProviders collection
		/// </summary>
		public void SynchronizeCMSProviders()
		{
			CMSProviderCollection.SynchronizeChildCollection(this.cMSProviders, true);
		}
		#endregion		
		
		#region Events
		/// <summary>
		/// Creates and returns Event Object from given CMS object
		/// </summary>
		/// <param name="cMS"></param>
		/// <returns></returns>
		public static Event CreateEventFromCMS(CMS cMS)
		{
			if(cMS == null)
				return null;
			Event eventObj = new Event(cMS.patient, true);
			eventObj.CMSID = cMS.CMSID;
			eventObj.Description = cMS.LookupOf_CMSTypeID.Lookup_DescriptionByCMSTypeID(cMS.CMSTypeID);
			eventObj.EventSourceID = EventSourceCollection.ActiveEventSources.Lookup_EventSourceIDByCode(CARERESOURCECODE);
			eventObj.PhysicianReview = false;
			eventObj.MaternityEvent = false;
			eventObj.NewbornEvent = false;
			eventObj.PatientSubscriberLogID = cMS.PatientSubscriberLogID;
			eventObj.PrimaryProblemID = cMS.PrimaryProblemID;
			
			eventObj.AssignedTeamID = cMS.LatestCMSStatusHistory.AssignedTeamId;
			eventObj.AssignedUserID = cMS.LatestCMSStatusHistory.AssignedUserId;
			eventObj.CMSAutoGenerated = true;
			int i = DateActualProjectedCollection.ActiveDateActualProjectedCodes.Lookup_DateActualProjectedIDByCode(DATEACTUAL);
			eventObj.StartDateAP = i;
			eventObj.EndDateAP = i;
			eventObj.ProviderID = cMS.PrimaryProviderID;
			eventObj.FacilityID = cMS.PrimaryFacilityID;
			eventObj.FacilityTypeID = cMS.PrimaryFacilityTypeID;
			
			return eventObj;
		}
		

		/// <summary>
		/// Child Events mapped to related rows of table Event where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadCMSsEvent", "cMSID")]
		public EventCollection Events
		{
			get { return this.events; }
			set
			{
				this.events = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Events collection
		/// </summary>
		public void LoadEvents(bool forceReload)
		{
			this.events = (EventCollection)EventCollection.LoadChildCollection("Events", this, typeof(EventCollection), events, forceReload, null);
		}
		
		/// <summary>
		/// Saves the EventCollection collection
		/// </summary>
		public void SaveEvents()
		{
			EventCollection.SaveChildCollection(this.events, true);
		}

		/// <summary>
		/// Synchronizes the Events collection
		/// </summary>
		public void SynchronizeEvents()
		{
			EventCollection.SynchronizeChildCollection(this.events, true);
		}
		#endregion

		/// <summary>
		/// Calculate the total savings of clinical requests.
		/// We need to calculate this in memory since we keep them in collection and save at once.
		/// We pass the eventCurrentlyBeingEdited, because the req/decs for this event might have been
		/// changed in the UI.  The user will see the result for this change.
		/// </summary>
		/// <returns></returns>
		public Decimal CalculateClinicalRequestSavings(Event eventCurrentlyBeingEdited)
		{
			int eventIDtoSkip = 0;

			// If the requests of the given are being edited it should be excluded from the calcuations 
			// in the db.
			if (eventCurrentlyBeingEdited != null)
				if (!eventCurrentlyBeingEdited.IsNew)
					eventIDtoSkip = eventCurrentlyBeingEdited.EventID;

			object result = SqlData.SPExecScalar("usp_CalculateCMSClinicalRequestSavings", 
				new object[] { 
					SQLDataDirect.MakeDBValue( this.cMSID, (int)0),
					SQLDataDirect.MakeDBValue( eventIDtoSkip, (int)0) });

			decimal sum = 0;
			if (result != DBNull.Value)
				sum = Convert.ToDecimal( result );

			if (eventCurrentlyBeingEdited != null)	// if there's an event being edited, do the calculation in-memory for this event.
				sum += eventCurrentlyBeingEdited.CalculateClinicalRequestSavings();

			return sum;
		}

		#region Contact Info
		[FieldDescription("@HOMEPHONENUMBER@" + " " + "@CALLERPHONE@")]
		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=15)]
		public string HomeContactPhone
		{
			get { return this.homeContactPhone; }
			set { this.homeContactPhone = value; }
		}

		[FieldDescription("@WORKPHONENUMBER@" + " " + "@CALLERPHONE@")]
		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=15)]
		public string WorkContactPhone
		{
			get { return this.workContactPhone; }
			set { this.workContactPhone = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, MaxLength=5)]
		public string WorkContactExt
		{
			get { return this.workContactExt; }
			set { this.workContactExt = value; }
		}

		[FieldDescription("@OTHER@" + " " + "@CALLERPHONE@")]
		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=15)]
		public string OtherContactPhone
		{
			get { return this.otherContactPhone; }
			set { this.otherContactPhone = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, MaxLength=5)]
		public string OtherContactExt
		{
			get { return this.otherContactExt; }
			set { this.otherContactExt = value; }
		}

		[FieldDescription("@TIME@")]
		[ControlType(Macro=EnumControlTypeMacros.Time12, MaxLength=6)]
		public System.DateTime HomeContactTime
		{
			get { return this.homeContactTime; }
			set { this.homeContactTime = value; }
		}

		[FieldDescription("@TIME@")]
		[ControlType(Macro=EnumControlTypeMacros.Time12, MaxLength=6)]
		public System.DateTime WorkContactTime
		{
			get { return this.workContactTime; }
			set { this.workContactTime = value; }
		}

		[FieldDescription("@TIME@")]
		[ControlType(Macro=EnumControlTypeMacros.Time12, MaxLength=6)]
		public System.DateTime OtherContactTime
		{
			get { return this.otherContactTime; }
			set { this.otherContactTime = value; }
		}
		#endregion

		#region POCInterventions
		/// <summary>
		/// Child POCInterventions.
		/// Loaded by JOINing [POCDefict] with [POCGoal]
		/// </summary>
		public POCInterventionCollection POCInterventions
		{
			get { return this.pOCInterventions; }
			set
			{
				this.pOCInterventions = value;
				if (value != null)
					value.ParentCMS = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the POCInterventions collection
		/// </summary>
		public void LoadPOCInterventions(bool forceReload)
		{
			if(!forceReload && this.pOCInterventions != null)
				return;	// collection already loaded and user didn't force reload.
			
			this.pOCInterventions = POCInterventionCollection.GetPOCInterventionCollectionByCMSId(this.cMSID);
			this.pOCInterventions.ParentCMS = this;
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private bool LoadCMSByPOCInterventionId(int interventionId)
		{
			return SqlData.SPExecReadObj("usp_LoadCMSByPOCInterventionId", this, false, new object[] { interventionId });
		}

		public static CMS GetCMSByPOCInterventionId(int interventionId)
		{
			CMS cms = new CMS(false);
			if(cms.LoadCMSByPOCInterventionId(interventionId))
				return cms;
			return null;
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.CMSTypeID = CMS.CMSTypeCodeId;
			this.CaseStartDate = DateTime.Now;
			this.LatestCMSStatusHistory.StatusId = SystemStatusCollection.ActiveSystemStatuses.Lookup_StatusIdByCode(SystemStatus.OPEN);
			this.LatestCMSStatusHistory.AssignedUserId = AASecurityHelper.GetUserId;;

		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime LastValidationDate
		{
			get { return this.lastValidationDate; }
			set { this.lastValidationDate = value; }
		}

//		/// <summary>
//		/// Saves the POCInterventions collection
//		/// </summary>
//		public void SavePOCInterventions()
//		{
//			this.pOCInterventions.Save();
//		}
		#endregion


	}

	/// <summary>
	/// Strongly typed collection of CMS objects
	/// </summary>
	[ElementType(typeof(CMS))]
	public class CMSCollection : BaseCollectionForEventCMSReferral
	{
		private bool isGettingAllCMSesByPatientId = false;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMS elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSCollection = this;
			else
				elem.ParentCMSCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMS elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMS this[int index]
		{
			get
			{
				return (CMS)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMS)oldValue, false);
			SetParentOnElem((CMS)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(CMS elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((CMS)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int GetAllCMSesByPatientId(int maxRecords, int patientId)
		{
			this.Clear();
			isGettingAllCMSesByPatientId = true;
			return SqlData.SPExecReadCol("usp_GetAllCMSesByPatientIdWithDAFilter", maxRecords, this, false, patientId, SQLDataDirect.MakeDBValue(AASecurityHelper.GetUserId, (int)0));
			isGettingAllCMSesByPatientId = false;
		}

		protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);

			if(isGettingAllCMSesByPatientId)
			{
				// These fields are used by E/R/C grid on PatientSummary page
				((CMS)data).StatusTypeIdDisplay = SQLDataDirect.GetFromDBValue(rdr["StatusTypeIdDisplay"], 0);
				((CMS)data).StatusIdDisplay = SQLDataDirect.GetFromDBValue(rdr["StatusIdDisplay"], 0);
			}
		}

		public CMSCollection GetAllCMSesByPatientId(int patientId)
		{
			CMSCollection col = new CMSCollection();
			col.GetAllCMSesByPatientId(-1, patientId);
			return col;
		}

		/// <summary>
		/// Returns all the CMSs for a given patient object and also establishes the in-memory relations to 
		/// patient object.
		/// </summary>
		/// <param name="patient"></param>
		/// <returns></returns>
		public int LoadLinkedPatientCMSs(Patient patient)
		{
			return LoadLinkedPatientCMSs(-1, patient);
		}

		/// <summary>
		/// Load the CMSs of a given patient.
		/// </summary>
		public int LoadLinkedPatientCMSs(int maxRecords, Patient patient)
		{
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Linked patient CMSes can be loaded only in the context of a patient");
			this.Clear();
			int count = GetAllCMSesByPatientId(-1, patient.PatientId);
			// set the parent patients for all the events
			SetParentPatientObject(patient);

			return count;
		}

		/// <summary>
		/// Given a problem, this function determines if the CMS is linked or not
		/// </summary>
		/// <param name="problem"></param>
		public override void DetermineElementsLinkedToProblem(Problem problem)
		{
			problem.LoadProblemCMSes(false);
			problem.ProblemCMSes.IndexBy_CMSId.Rebuild();
			for (int i = 0; i < this.Count; i++)
			{
				CMS cms = this[i];

				CMSProblem cmsprob = problem.ProblemCMSes.FindByCMSID(cms.CMSID);
				cms.IsLinkedToProblem = cmsprob != null;	// if found, this is linked to the problem
			}
		}

		/// <summary>
		/// Search all events by the Alt-CMS ID
		/// </summary>
		public int SearchCMSsByAltCMSID(int maxRecords, string alternateCMSID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchCMSsByAltCMSID", maxRecords, this, false, 
				new object[] { SQLDataDirect.MakeDBValue( alternateCMSID ) });
		}

		public override int SearchByAltAuthorizationID(int maxRecords, string altAuthorizationID)
		{
			return SearchCMSsByAltCMSID(maxRecords, altAuthorizationID);
		}

	}

	
}
