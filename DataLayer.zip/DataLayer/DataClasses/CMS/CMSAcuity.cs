using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSAcuities]
	/// </summary>
	[SPAutoGen("usp_GetCMSAcuitiesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_SearchAllCMSAcuities","SelectAllByGivenArgs.sptpl","")]
	[SPAutoGen("usp_GetAllCMSAcuities","SelectAll.sptpl","")]
	[SPInsert("usp_InsertCMSAcuity")]
	[SPUpdate("usp_UpdateCMSAcuity")]
	[SPDelete("usp_DeleteCMSAcuity")]
	[SPLoad("usp_LoadCMSAcuity")]
	[TableMapping("CMSAcuity","acuityId")]
	public class CMSAcuity : BaseLookupWithNote
	{
		[NonSerialized]
		private CMSAcuityCollection parentCMSAcuityCollection;
		[ColumnMapping("AcuityId",StereoType=DataStereoType.FK)]
		private int acuityId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public CMSAcuity()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int AcuityId
		{
			get { return this.acuityId; }
			set { this.acuityId = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int acuityId)
		{
			return base.Load(acuityId);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int acuityId)
		{
			base.Delete(acuityId);		
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Parent CMSAcuityCollection that contains this element
		/// </summary>
		public CMSAcuityCollection ParentCMSAcuityCollection
		{
			get
			{
				return this.parentCMSAcuityCollection;
			}
			set
			{
				this.parentCMSAcuityCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active	= true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}
		
		/// <summary>
		/// Reads multiple objects of this type from source data reader into the given collection
		/// </summary>
		public int ReadCollection(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords, CMSAcuityCollection collection)
		{
			return SqlData.ReadCollection(sourceReader, maxRecords, collection, typeof(CMSPhase), true, false);
		}

		/// <summary>
		/// Use this function to test Load method
		/// </summary>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void TestLoad()
		{
			CMSAcuity obj = new CMSAcuity();
			obj.Load(1);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(2);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(3);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(4);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
		
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of CMSAcuity objects
	/// </summary>
	[ElementType(typeof(CMSAcuity))]
	public class CMSAcuityCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSAcuity elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSAcuityCollection = this;
			else
				elem.ParentCMSAcuityCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSAcuity elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSAcuity this[int index]
		{
			get
			{
				return (CMSAcuity)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSAcuity)oldValue, false);
			SetParentOnElem((CMSAcuity)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		

		/// <summary>
		///  Load all Facility Focus Types.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllCMSAcuities", -1, this, false);
		}

		/// <summary>
		///  Searches for Focus Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchAllCMSAcuities", -1, this, false, code, description, active);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadCMSAcuitiesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetCMSAcuitiesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared CMSAcuityCollection which is cached in NSGlobal
		/// </summary>
		public static CMSAcuityCollection ActiveCMSAcuities
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				CMSAcuityCollection col = (CMSAcuityCollection)NSGlobal.EnsureCachedObject("ActiveCMSAcuities", typeof(CMSAcuityCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadCMSAcuitiesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
