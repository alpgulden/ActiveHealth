using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSProvider]
	/// </summary>
	[SPInsert("usp_InsertCMSProvider")]
	[SPUpdate("usp_UpdateCMSProvider")]
	[SPDelete("usp_DeleteCMSProvider")]
	[SPLoad("usp_LoadCMSProvider")]
	[TableMapping("CMSProvider","cMSProviderID")]
	public class CMSProvider : BaseData
	{
		[NonSerialized]
		private CMSProviderCollection parentCMSProviderCollection;
		[ColumnMapping("CMSProviderID",(int)0)]
		private int cMSProviderID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]
		private int providerID;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

		private int providerSpecialtyID;
		private int providerLocationNetworkID;
		private bool providerNetworkStatus;
		private DateTime startDate;
	
		public CMSProvider()
		{
		}

		public CMSProvider(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int CMSProviderID
		{
			get { return this.cMSProviderID; }
			set { this.cMSProviderID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		#region Not Mapped Properties
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@REFPROVIDERSPECIALTYID@")]
		public int ProviderSpecialtyID
		{
			get { return this.providerSpecialtyID; }
			set { this.providerSpecialtyID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@PROVIDERNETWORKID@")]
		public int ProviderLocationNetworkID
		{
			get { return this.providerLocationNetworkID; }
			set { this.providerLocationNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderNetworkStatusInt
		{
			get { return (this.providerNetworkStatus ? 1 : 0); }
			set { this.providerNetworkStatus = (value == 1 ? true : false);}
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool ProviderNetworkStatus
		{
			get { return this.providerNetworkStatus; }
			set { this.providerNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}
		#endregion

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent CMSProviderCollection that contains this element
		/// </summary>
		public CMSProviderCollection ParentCMSProviderCollection
		{
			get
			{
				return this.parentCMSProviderCollection;
			}
			set
			{
				this.parentCMSProviderCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of CMSProvider objects
	/// </summary>
	[ElementType(typeof(CMSProvider))]
	public class CMSProviderCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSProvider elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSProviderCollection = this;
			else
				elem.ParentCMSProviderCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSProvider elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSProvider this[int index]
		{
			get
			{
				return (CMSProvider)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSProvider)oldValue, false);
			SetParentOnElem((CMSProvider)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(CMSProvider elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((CMSProvider)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}
	}
}
