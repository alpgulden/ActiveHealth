using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CaseSource]
	/// </summary>
	[SPAutoGen("usp_SearchCaseSourcesByCode","SearchByArgs.sptpl","code")]
	[SPAutoGen("usp_LoadCaseSourcesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_LoadAllCaseSources","SelectAll.sptpl","")]
	[SPInsert("usp_InsertCaseSource")]
	[SPUpdate("usp_UpdateCaseSource")]
	[SPDelete("usp_DeleteCaseSource")]
	[SPLoad("usp_LoadCaseSource")]
	[TableMapping("CaseSource","caseSourceID")]
	public class CaseSource : BaseLookupWithNote
	{
		[NonSerialized]
		private CaseSourceCollection parentCaseSourceCollection;
		[ColumnMapping("CaseSourceID",StereoType=DataStereoType.FK)]
		private int caseSourceID;
		[ColumnMapping("NotePad")]
		private string notePad;

		public CaseSource()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CaseSourceID
		{
			get { return this.caseSourceID; }
			set { this.caseSourceID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=8)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReadOnly
		{
			get { return this.readOnly; }
			set { this.readOnly = value; }
		}

		/// <summary>
		/// Parent CaseSourceCollection that contains this element
		/// </summary>
		public CaseSourceCollection ParentCaseSourceCollection
		{
			get
			{
				return this.parentCaseSourceCollection;
			}
			set
			{
				this.parentCaseSourceCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}
	}

	/// <summary>
	/// Strongly typed collection of CaseSource objects
	/// </summary>
	[ElementType(typeof(CaseSource))]
	public class CaseSourceCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CaseSource elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCaseSourceCollection = this;
			else
				elem.ParentCaseSourceCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CaseSource elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CaseSource this[int index]
		{
			get
			{
				return (CaseSource)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CaseSource)oldValue, false);
			SetParentOnElem((CaseSource)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadCaseSourcesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadCaseSourcesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared CaseSourceCollection which is cached in NSGlobal
		/// </summary>
		public static CaseSourceCollection ActiveCaseSources
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				CaseSourceCollection col = (CaseSourceCollection)NSGlobal.EnsureCachedObject("ActiveCaseSources", typeof(CaseSourceCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadCaseSourcesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_LoadAllCaseSources", -1, this, false);
		}	
	}
}
