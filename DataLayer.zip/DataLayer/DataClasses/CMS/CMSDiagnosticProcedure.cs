using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSDiagnosticProcedure]
	/// </summary>
	[SPInsert("usp_InsertCMSDiagnosticProcedure")]
	[SPUpdate("usp_UpdateCMSDiagnosticProcedure")]
	[SPDelete("usp_DeleteCMSDiagnosticProcedure")]
	[SPLoad("usp_LoadCMSDiagnosticProcedure")]
	[TableMapping("CMSDiagnosticProcedure","cMSDiagnosticProcedureID")]
	public class CMSDiagnosticProcedure : BaseData
	{
		[NonSerialized]
		private CMSDiagnosticProcedureCollection parentCMSDiagnosticProcedureCollection;
		[ColumnMapping("CMSDiagnosticProcedureID",(int)0)]
		private int cMSDiagnosticProcedureID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("DiagOrProc")]
		private string diagOrProc;
		[ColumnMapping("DxPxType")]
		private string dxPxType;
		[ColumnMapping("DxPxCode")]
		private string dxPxCode;
		[ColumnMapping("DSM4axis",StereoType=DataStereoType.FK)]
		private int dSM4axis;
		[ColumnMapping("ScheduledDate")]
		private DateTime scheduledDate;
		[ColumnMapping("SequenceID",StereoType=DataStereoType.FK)]
		private int sequenceID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public CMSDiagnosticProcedure()
		{

		}

		public CMSDiagnosticProcedure(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CMSDiagnosticProcedureID
		{
			get { return this.cMSDiagnosticProcedureID; }
			set { this.cMSDiagnosticProcedureID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string DiagOrProc
		{
			get { return this.diagOrProc; }
			set { this.diagOrProc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DxPxType
		{
			get { return this.dxPxType; }
			set { this.dxPxType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string DxPxCode
		{
			get { return this.dxPxCode; }
			set { this.dxPxCode = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DSM4axis
		{
			get { return this.dSM4axis; }
			set { this.dSM4axis = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ScheduledDate
		{
			get { return this.scheduledDate; }
			set { this.scheduledDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SequenceID
		{
			get { return this.sequenceID; }
			set { this.sequenceID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		/// <summary>
		/// Parent CMSDiagnosticProcedureCollection that contains this element
		/// </summary>
		public CMSDiagnosticProcedureCollection ParentCMSDiagnosticProcedureCollection
		{
			get
			{
				return this.parentCMSDiagnosticProcedureCollection;
			}
			set
			{
				this.parentCMSDiagnosticProcedureCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of CMSDiagnosticProcedure objects
	/// </summary>
	[ElementType(typeof(CMSDiagnosticProcedure))]
	public class CMSDiagnosticProcedureCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_DxPxCode;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSDiagnosticProcedure elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSDiagnosticProcedureCollection = this;
			else
				elem.ParentCMSDiagnosticProcedureCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSDiagnosticProcedure elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSDiagnosticProcedure this[int index]
		{
			get
			{
				return (CMSDiagnosticProcedure)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSDiagnosticProcedure)oldValue, false);
			SetParentOnElem((CMSDiagnosticProcedure)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(CMSDiagnosticProcedure elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((CMSDiagnosticProcedure)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}
		
		/// <summary>
		/// Hashtable based index on dxPxCode fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_DxPxCode
		{
			get
			{
				if (this.indexBy_DxPxCode == null)
					this.indexBy_DxPxCode = new CollectionIndexer(this, new string[] { "dxPxCode" }, true);
				return this.indexBy_DxPxCode;
			}
			
		}

		/// <summary>
		/// Hashtable based search on dxPxCode fields returns the object.  Uses the IndexBy_DxPxCode indexer.
		/// </summary>
		public CMSDiagnosticProcedure FindBy(string dxPxCode)
		{
			return (CMSDiagnosticProcedure)this.IndexBy_DxPxCode.GetObject(dxPxCode);
		}

		#region Dx/Px Transformation methods
		/// <summary>
		/// Updates this Collection from DiagnosticSelectCollection
		/// </summary>
		/// <param name="diagnostics"></param>
		public void SyncFromSelections(DiagnosticSelectCollection diagnostics)
		{
			this.IndexBy_DxPxCode.Rebuild();
			foreach(DiagnosticSelect diagnose in diagnostics)
			{
				CMSDiagnosticProcedure existingCMSDxpX = this.FindBy(diagnose.CodeValue);
				
				if (existingCMSDxpX == null & !diagnose.IsMarkedForDeletion & diagnose.IsNew)
				{	// Diagnose is not found - adding
					CMSDiagnosticProcedure toAdd = new CMSDiagnosticProcedure(true);
						toAdd.DxPxType = diagnose.CodeType;
						toAdd.DxPxCode = diagnose.CodeValue;
						toAdd.DiagOrProc = diagnose.CodeDxOrPx;
						toAdd.DSM4axis = diagnose.Axis;
						toAdd.SequenceID = diagnose.Sequence;
					toAdd.CMSID = this.ParentCMS.CMSID;
					this.Add(toAdd);
				}
				else if (existingCMSDxpX != null)
				{
					existingCMSDxpX.IsMarkedForDeletion =  diagnose.IsMarkedForDeletion;
					existingCMSDxpX.DSM4axis = diagnose.Axis; // can be modifed by user
					existingCMSDxpX.IsDirty = diagnose.IsDirty;
				}
			}
		}

		
		/// <summary>
		/// Updates this Collection from ProcedureSelectCollection
		/// </summary>
		/// <param name="procedures"></param>
		public void SyncFromSelections(ProcedureSelectCollection procedures)
		{
			this.IndexBy_DxPxCode.Rebuild();
			foreach(ProcedureSelect procedure in procedures)
			{
				CMSDiagnosticProcedure existingCMSDxpX = this.FindBy(procedure.CodeValue);
				
				if (existingCMSDxpX == null & !procedure.IsMarkedForDeletion & procedure.IsNew)
				{
					CMSDiagnosticProcedure toAdd = new CMSDiagnosticProcedure(true);
						toAdd.DxPxType = procedure.CodeType;
						toAdd.DxPxCode = procedure.CodeValue;
						toAdd.DiagOrProc = procedure.CodeDxOrPx;
						toAdd.SequenceID = procedure.Sequence;
						toAdd.ScheduledDate = procedure.Scheduled;
						toAdd.CMSID = this.ParentCMS.CMSID;
					this.Add(toAdd);
				}
				else if (existingCMSDxpX != null)
				{
					existingCMSDxpX.IsMarkedForDeletion =  procedure.IsMarkedForDeletion;
					existingCMSDxpX.ScheduledDate = procedure.Scheduled; // can be modifed by user
					existingCMSDxpX.IsDirty = procedure.IsDirty;
				}
			}
		}

		/// <summary>
		/// Creates DiagnosticSelectCollection from this Collection
		/// </summary>
		/// <returns></returns>
		public DiagnosticSelectCollection CreateDiagnosticSelectionCollection()
		{
			DiagnosticSelectCollection diagnoses = new DiagnosticSelectCollection();
			
			string errors = null;

			// accumulate all dxpx load errors and throw at one step
			for (int i = 0; i < this.Count; i++)
			{
				if (this[i].DiagOrProc == "D")
				{
					try
					{
						diagnoses.AddDiagFromCMS(this[i]);
					}
					catch(ActiveAdviceException aex)
					{
						if (aex.ExceptionResolution != EnumExceptionResolution.DxPxLoadError)
							throw aex;
						errors += aex.Message + "\r\n";
					}
				}
			}

			if (errors != null)
				throw new ActiveAdviceException(EnumExceptionResolution.DxPxLoadError, errors);

			return diagnoses;
		}

		/// <summary>
		/// Creates ProcedureSelectCollection from this Collection
		/// </summary>
		/// <returns></returns>
		public ProcedureSelectCollection CreateProcedureSelectionCollection()
		{
			ProcedureSelectCollection procedures = new ProcedureSelectCollection();

			string errors = null;

			for (int i = 0; i < this.Count; i++)
			{
				if (this[i].DiagOrProc == "P")
				{
					try
					{
						procedures.AddProcFromCMS(this[i]);
					}
					catch(ActiveAdviceException aex)
					{
						if (aex.ExceptionResolution != EnumExceptionResolution.DxPxLoadError)
							throw aex;
						errors += aex.Message + "\r\n";
					}
				}
			}

			if (errors != null)
				throw new ActiveAdviceException(EnumExceptionResolution.DxPxLoadError, errors);

			return procedures;
		}
		#endregion
	}
}
