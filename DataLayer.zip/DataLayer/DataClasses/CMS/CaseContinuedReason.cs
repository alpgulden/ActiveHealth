using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CaseContinuedReason]
	/// </summary>
	[SPAutoGen("usp_SearchCaseContinuedReasonsByCode","SearchByArgs.sptpl","code")]
	[SPAutoGen("usp_LoadCaseContinuedReasonsByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_LoadAllCaseContinuedReasons","SelectAll.sptpl","")]
	[SPInsert("usp_InsertCaseContinuedReason")]
	[SPUpdate("usp_UpdateCaseContinuedReason")]
	[SPDelete("usp_DeleteCaseContinuedReason")]
	[SPLoad("usp_LoadCaseContinuedReason")]
	[TableMapping("CaseContinuedReason","caseContinuedReasonId")]
	public class CaseContinuedReason : BaseLookupWithNote
	{
		[NonSerialized]
		private CaseContinuedReasonCollection parentCaseContinuedReasonCollection;
		[ColumnMapping("CaseContinuedReasonId",StereoType=DataStereoType.FK)]
		private int caseContinuedReasonId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public CaseContinuedReason()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CaseContinuedReasonId
		{
			get { return this.caseContinuedReasonId; }
			set { this.caseContinuedReasonId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=8)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReadOnly
		{
			get { return this.readOnly; }
			set { this.readOnly = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int caseContinuedReasonId)
		{
			return base.Load(caseContinuedReasonId);
		}

		/// <summary>
		/// Parent CaseContinuedReasonCollection that contains this element
		/// </summary>
		public CaseContinuedReasonCollection ParentCaseContinuedReasonCollection
		{
			get
			{
				return this.parentCaseContinuedReasonCollection;
			}
			set
			{
				this.parentCaseContinuedReasonCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of CaseContinuedReason objects
	/// </summary>
	[ElementType(typeof(CaseContinuedReason))]
	public class CaseContinuedReasonCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CaseContinuedReason elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCaseContinuedReasonCollection = this;
			else
				elem.ParentCaseContinuedReasonCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CaseContinuedReason elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CaseContinuedReason this[int index]
		{
			get
			{
				return (CaseContinuedReason)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CaseContinuedReason)oldValue, false);
			SetParentOnElem((CaseContinuedReason)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadCaseContinuedReasonsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadCaseContinuedReasonsByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared CaseContinuedReasonCollection which is cached in NSGlobal
		/// </summary>
		public static CaseContinuedReasonCollection ActiveCaseContinuedReasons
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				CaseContinuedReasonCollection col = (CaseContinuedReasonCollection)NSGlobal.EnsureCachedObject("ActiveCaseContinuedReasons", typeof(CaseContinuedReasonCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadCaseContinuedReasonsByActive(-1, true);
				}
				return col;
			}			
		}

		
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_LoadAllCaseContinuedReasons", -1, this, false);
		}	
	}
}
