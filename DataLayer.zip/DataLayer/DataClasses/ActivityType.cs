using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ActivityType]
	/// </summary>
	[SPAutoGen("usp_GetAllActivityTypesByPrimaryTypeIDActive","SelectAllByGivenArgs.sptpl","activityPrimaryTypeID, active")]
	[SPAutoGen("usp_GetAllActivityTypesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllActivityTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertActivityType")]
	[SPUpdate("usp_UpdateActivityType")]
	[SPDelete("usp_DeleteActivityType")]
	[SPLoad("usp_LoadActivityType")]
	[TableMapping("ActivityType","activityTypeID")]
	public class ActivityType : BaseLookupWithTwoSubCode
	{
		[NonSerialized]
		private ActivityTypeCollection parentActivityTypeCollection;
		[ColumnMapping("ActivityTypeID",StereoType=DataStereoType.FK)]
		private int activityTypeID;
		[ColumnMapping("ActivityPrimaryTypeID",StereoType=DataStereoType.FK)]
		private int activityPrimaryTypeID;
		[ColumnMapping("CostSaving",StereoType=DataStereoType.FK)]
		private int costSaving;
		[ColumnMapping("Notepad")]
		protected string notepad;
		private ActivityTypeSubTypeCollection activityTypeSubTypes;

		public ActivityType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ActivityType(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ActivityTypeID
		{
			get { return this.activityTypeID; }
			set { this.activityTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		public int ActivityPrimaryTypeID
		{
			get { return this.activityPrimaryTypeID; }
			set { this.activityPrimaryTypeID = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CostSaving
		{
			get { return this.costSaving; }
			set { this.costSaving = value; }
		}

		[FieldValuesMember("LookupOf_SubCodeID", "ActivityPrimaryTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@ACTIVITYPRIMARYTYPEID@")]
		public override int SubCodeID
		{
			get { return this.activityPrimaryTypeID; }
			set { this.activityPrimaryTypeID = value; }
		}

		[FieldValuesMember("ValuesOf_CostSaving")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@COSTSAVING@")]
		public override int SubCodeExtID
		{
			get { return this.costSaving; } 
			set { this.costSaving = value; }
		}

		public object[,] ValuesOf_CostSaving
		{
			get
			{
				return new object[,] {{1,"Yes"},{0,"No"}};
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int activityTypeID)
		{
			return base.Load(activityTypeID);
		}

		/// <summary>
		/// Parent ActivitySubTypeCollection that contains this element
		/// </summary>
		public override BaseTypeCollection ParentBaseTypeCollection
		{
			get
			{
				return this.parentActivityTypeCollection;
			}
			set
			{
				this.parentActivityTypeCollection = (ActivityTypeCollection)value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Returns all the activity sub types linked to this activity type.
		/// </summary>
		/// <returns></returns>
		public ActivitySubTypeCollection GetActiveSubTypes()
		{
			ActivitySubTypeCollection subTypes = new ActivitySubTypeCollection();
			subTypes.LoadAllActiveSubTypesForType(this.activityTypeID, true);
			return subTypes;
		}

		public ActivityPrimaryTypeCollection LookupOf_SubCodeID
		{
			get
			{
				return ActivityPrimaryTypeCollection.ActiveActivityPrimaryTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		/// <summary>
		/// Child ActivityTypeSubTypes mapped to related rows of table ActivityTypeSubType where [ActivityTypeID] = [ActivityTypeId]
		/// </summary>
		[SPLoadChild("usp_LoadActivityTypeActivityTypeSubType", "ActivityTypeId")]
		public override BaseDataCollectionClass BracketCodeTableChilderen
		{
			get { return this.activityTypeSubTypes; }
			set
			{
				this.activityTypeSubTypes = (ActivityTypeSubTypeCollection)value;
				if (value != null)
					((ActivityTypeSubTypeCollection)value).ParentActivityType = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ActivityTypeSubTypes collection
		/// </summary>
		public override void LoadBracketCodeTableChilderen(bool forceReload)
		{
			this.activityTypeSubTypes = (ActivityTypeSubTypeCollection)ActivityTypeSubTypeCollection.LoadChildCollection("BracketCodeTableChilderen", this, typeof(ActivityTypeSubTypeCollection), activityTypeSubTypes, forceReload, null);
		}

		/// <summary>
		/// Saves the ActivityTypeSubTypes collection
		/// </summary>
		public override void SaveBracketCodeTableChilderen()
		{
			ActivityTypeSubTypeCollection.SaveChildCollection(this.activityTypeSubTypes, true);
		}

		/// <summary>
		/// Synchronizes the ActivityTypeSubTypes collection
		/// </summary>
		public override void SynchronizeBracketCodeTableChilderen()
		{
			ActivityTypeSubTypeCollection.SynchronizeChildCollection(this.activityTypeSubTypes, true);
		}

	}

	/// <summary>
	/// Strongly typed collection of ActivityType objects
	/// </summary>
	[ElementType(typeof(ActivityType))]
	public class ActivityTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ActivityTypeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ActivityType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentBaseTypeCollection = this;
			else
				elem.ParentBaseTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ActivityType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ActivityType this[int index]
		{
			get
			{
				return (ActivityType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ActivityType)oldValue, false);
			SetParentOnElem((ActivityType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllActivityTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllActivityTypesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared ActivityTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ActivityTypeCollection ActiveActivityTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ActivityTypeCollection col = (ActivityTypeCollection)NSGlobal.EnsureCachedObject("ActiveActivityTypes", typeof(ActivityTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllActivityTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Accessor to a shared ActivityTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ActivityTypeCollection GetActiveActivityTypes(int primaryType)
		{
			bool initialize = false;
			// Get a cached instance of the collection
			ActivityTypeCollection col = (ActivityTypeCollection)NSGlobal.EnsureCachedObject("ActiveActivityTypes-" + primaryType.ToString(), typeof(ActivityTypeCollection), ref initialize);
			if (initialize)
			{
				// initialize the content of the collection
				col.GetAllActivityTypesByPrimaryTypeIDActive(-1, primaryType, true);
			}
			return col;
		}
		
		/// <summary>
		/// Hashtable based index on activityTypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ActivityTypeID
		{
			get
			{
				if (this.indexBy_ActivityTypeID == null)
					this.indexBy_ActivityTypeID = new CollectionIndexer(this, new string[] { "activityTypeID" }, true);
				return this.indexBy_ActivityTypeID;
			}
			
		}

		/// <summary>
		/// Looks up by activityTypeID and returns ActivityPrimaryTypeID value.  Uses the IndexBy_ActivityTypeID indexer.
		/// </summary>
		public int Lookup_ActivityPrimaryTypeIDByActivityTypeID(int activityTypeID)
		{
			return this.IndexBy_ActivityTypeID.LookupIntMember("ActivityPrimaryTypeID", activityTypeID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllActivityTypesByPrimaryTypeIDActive(int maxRecords, int activityPrimaryTypeID, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllActivityTypesByPrimaryTypeIDActive", maxRecords, this, false, 
				activityPrimaryTypeID, active);
		}

		/// <summary>
		/// Hashtable based search on activityTypeID fields returns the object.  Uses the IndexBy_ActivityTypeID indexer.
		/// </summary>
		public ActivityType FindBy(int activityTypeID)
		{
			return (ActivityType)this.IndexBy_ActivityTypeID.GetObject(activityTypeID);
		}

		/// <summary>
		///  Loads all Organization Types into collection.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllActivityTypes", -1, this, false);
		}

		/// <summary>
		/// Looks up by activityTypeID and returns Description value.  Uses the IndexBy_ActivityTypeID indexer.
		/// </summary>
		public string Lookup_DescriptionByActivityTypeID(int activityTypeID)
		{
			return this.IndexBy_ActivityTypeID.LookupStringMember("Description", activityTypeID);
		}

	
	}
}
