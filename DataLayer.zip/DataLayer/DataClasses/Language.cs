using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Languages]
	/// </summary>

	[SPAutoGen("usp_SearchLanguages","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllLanguages","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetLanguagesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertLanguage")]
	[SPUpdate("usp_UpdateLanguage")]
	[SPDelete("usp_DeleteLanguage")]
	[SPLoad("usp_LoadLanguage")]
	[TableMapping("Language","languageID")]
	public class Language : BaseLookupWithNote
	{
		[NonSerialized]
		private LanguageCollection parentLanguageCollection;
		[ColumnMapping("LanguageID",StereoType=DataStereoType.FK)]
		private int languageID;
		[ColumnMapping("Notepad")]
		private string notepad;
		

		public Language()
		{		
		}

		[ControlType(EnumControlTypes.TextBox)]
		[FieldDescription("Language ID")]
		public int LanguageID
		{
			get { return this.languageID; }
			set { this.languageID = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int languageID)
		{
			return base.Load(languageID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int languageID)
		{
			base.Delete(languageID);		
		}

		/// <summary>
		/// Parent LanguageCollection that contains this element
		/// </summary>
		public LanguageCollection ParentLanguageCollection
		{
			get
			{
				return this.parentLanguageCollection;
			}
			set
			{
				this.parentLanguageCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=200)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}
		
	}

	/// <summary>
	/// Strongly typed collection of Language objects
	/// </summary>
	[ElementType(typeof(Language))]
	public class LanguageCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_LanguageID;
		[NonSerialized]
		private CollectionIndexer indexBy_LanguageCode;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Language elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLanguageCollection = this;
			else
				elem.ParentLanguageCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Language elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Language this[int index]
		{
			get
			{
				return (Language)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Language)oldValue, false);
			SetParentOnElem((Language)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, Language elem)
		{
			List.Insert(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Language)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Language elem)
		{
			return List.Add(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(Language elem)
		{
			List.Remove(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((Language)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/* Don't use this.
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(string filter, string sort)
		{
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForType(typeof(Language), filter, sort);
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int SPLoad(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetLanguagesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetLanguagesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared LanguageCollection which is cached in NSGlobal.
		/// Returns a collection of active languages available.
		/// </summary>
		public static LanguageCollection ActiveLanguages
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LanguageCollection col = (LanguageCollection)NSGlobal.EnsureCachedObject("ActiveLanguages", typeof(LanguageCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetLanguagesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on languageCode fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_LanguageCode
		{
			get
			{
				if (this.indexBy_LanguageCode == null)
					this.indexBy_LanguageCode = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_LanguageCode;
			}
			
		}

		/// <summary>
		/// Hashtable based index on languageID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_LanguageID
		{
			get
			{
				if (this.indexBy_LanguageID == null)
					this.indexBy_LanguageID = new CollectionIndexer(this, new string[] { "languageID" }, true);
				return this.indexBy_LanguageID;
			}
			
		}


		/// <summary>
		///  Loads all Languages
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllLanguages", -1, this, false);
		}


		/// <summary>
		/// Searches for Languages matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchLanguages", -1, this, false, code, description, active);
		}


		/// <summary>
		/// Looks up by languageID and returns LanguageCode value.  Uses the IndexBy_LanguageID indexer.
		/// </summary>
		public string Lookup_LanguageCodeByLanguageID(int languageID)
		{
			return this.IndexBy_LanguageID.LookupStringMember("Code", languageID);
		}

		/// <summary>
		/// Looks up by languageCode and returns LanguageID value.  Uses the IndexBy_LanguageCode indexer.
		/// </summary>
		public int Lookup_LanguageIDByLanguageCode(string languageCode)
		{
			return this.IndexBy_LanguageCode.LookupIntMember("LanguageID", languageCode);
		}
	

	}
}

