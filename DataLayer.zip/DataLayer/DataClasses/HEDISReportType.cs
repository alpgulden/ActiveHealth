using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [HEDISReportType]
	/// </summary>
	[SPAutoGen("usp_LoadHedisReportTypeByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_LoadAllHedisReportType","SelectAll.sptpl","")]
	[SPDelete("usp_DeleteHEDISReportType")]
	[SPLoad("usp_LoadHEDISReportType")]
	[TableMapping("HEDISReportType","hEDISReportTypeID")]
	public class HEDISReportType : BaseLookupWithNote
	{
		[NonSerialized]
		private HEDISReportTypeCollection parentHEDISReportTypeCollection;
		[ColumnMapping("HEDISReportTypeID",(int)0)]
		private int hEDISReportTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public HEDISReportType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int HEDISReportTypeID
		{
			get { return this.hEDISReportTypeID; }
			set { this.hEDISReportTypeID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int hEDISReportTypeID)
		{
			return base.Load(hEDISReportTypeID);
		}

		/// <summary>
		/// Parent HEDISReportTypeCollection that contains this element
		/// </summary>
		public HEDISReportTypeCollection ParentHEDISReportTypeCollection
		{
			get
			{
				return this.parentHEDISReportTypeCollection;
			}
			set
			{
				this.parentHEDISReportTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of HEDISReportType objects
	/// </summary>
	[ElementType(typeof(HEDISReportType))]
	public class HEDISReportTypeCollection : BaseTypeCollection
	{
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_LoadAllHedisReportType", -1, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadHedisReportTypeByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadHedisReportTypeByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared HEDISReportTypeCollection which is cached in NSGlobal
		/// </summary>
		public static HEDISReportTypeCollection ActiveHEDISReportTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				HEDISReportTypeCollection col = (HEDISReportTypeCollection)NSGlobal.EnsureCachedObject("ActiveHEDISReportTypes", typeof(HEDISReportTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadHedisReportTypeByActive(-1, true);
				}
				return col;
			}			
		}	
	}
}
