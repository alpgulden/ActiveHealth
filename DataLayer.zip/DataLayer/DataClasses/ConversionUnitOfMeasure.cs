using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ConversionUnitOfMeasures]
	/// </summary>
	[SPAutoGen("usp_GetAllConversionUnitsOfMeasure","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetConversionUnitOfMeasuresByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertConversionUnitOfMeasure")]
	[SPUpdate("usp_UpdateConversionUnitOfMeasure")]
	[SPDelete("usp_DeleteConversionUnitOfMeasure")]
	[SPLoad("usp_LoadConversionUnitOfMeasure")]
	[TableMapping("ConversionUnitOfMeasure","conversionUnitOfMeasureId")]
	public class ConversionUnitOfMeasure : BaseLookupWithNote
	{
		[NonSerialized]
		private ConversionUnitOfMeasureCollection parentConversionUnitOfMeasureCollection;
		[ColumnMapping("ConversionUnitOfMeasureId",StereoType=DataStereoType.FK)]
		private int conversionUnitOfMeasureId;
		[ColumnMapping("NotePad")]
		private string notePad;

	
		public ConversionUnitOfMeasure()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ConversionUnitOfMeasure(int conversionUnitOfMeasureId, string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.conversionUnitOfMeasureId = conversionUnitOfMeasureId;
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ConversionUnitOfMeasureId
		{
			get { return this.conversionUnitOfMeasureId; }
			set { this.conversionUnitOfMeasureId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int conversionUnitOfMeasureId)
		{
			return base.Load(conversionUnitOfMeasureId);
		}

		/// <summary>
		/// Parent ConversionUnitOfMeasureCollection that contains this element
		/// </summary>
		public ConversionUnitOfMeasureCollection ParentConversionUnitOfMeasureCollection
		{
			get
			{
				return this.parentConversionUnitOfMeasureCollection;
			}
			set
			{
				this.parentConversionUnitOfMeasureCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}


	}

	/// <summary>
	/// Strongly typed collection of ConversionUnitOfMeasure objects
	/// </summary>
	[ElementType(typeof(ConversionUnitOfMeasure))]
	public class ConversionUnitOfMeasureCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ConversionUnitOfMeasureId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ConversionUnitOfMeasure elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentConversionUnitOfMeasureCollection = this;
			else
				elem.ParentConversionUnitOfMeasureCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ConversionUnitOfMeasure elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ConversionUnitOfMeasure this[int index]
		{
			get
			{
				return (ConversionUnitOfMeasure)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ConversionUnitOfMeasure)oldValue, false);
			SetParentOnElem((ConversionUnitOfMeasure)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadConversionUnitOfMeasuresByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetConversionUnitOfMeasuresByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ConversionUnitOfMeasureCollection which is cached in NSGlobal
		/// </summary>
		public static ConversionUnitOfMeasureCollection ActiveConversionUnitOfMeasures
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ConversionUnitOfMeasureCollection col = (ConversionUnitOfMeasureCollection)NSGlobal.EnsureCachedObject("ActiveConversionUnitOfMeasures", typeof(ConversionUnitOfMeasureCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadConversionUnitOfMeasuresByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Loads all Conversion Units Of Measures
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllConversionUnitsOfMeasure", -1, this, false);
		}

		/// <summary>
		/// Searches for Conversion Unit of Measures matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchConversionUnitOfMeasures", -1, this, false, code, description, active);
		}

		/// <summary>
		/// Hashtable based index on conversionUnitOfMeasureId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ConversionUnitOfMeasureId
		{
			get
			{
				if (this.indexBy_ConversionUnitOfMeasureId == null)
					this.indexBy_ConversionUnitOfMeasureId = new CollectionIndexer(this, new string[] { "conversionUnitOfMeasureId" }, true);
				return this.indexBy_ConversionUnitOfMeasureId;
			}
			
		}

		/// <summary>
		/// Looks up by conversionUnitOfMeasureId and returns Description value.  Uses the IndexBy_ConversionUnitOfMeasureId indexer.
		/// </summary>
		public string Lookup_DescriptionByConversionUnitOfMeasureId(int conversionUnitOfMeasureId)
		{
			return this.IndexBy_ConversionUnitOfMeasureId.LookupStringMember("Description", conversionUnitOfMeasureId);
		}
	}
}
