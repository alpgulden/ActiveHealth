using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LengthOfStay]
	/// </summary>
	[SPAutoGen("usp_GetLengthOfStayByIdentifiers","SelectAllByGivenArgs.sptpl","hciaPayorgroup, hciaRegion, dxPxType, summaryLevel, iCD9code, categoryCode, ageCategory")]
	[TableMapping("LengthOfStay")]
	public class LengthOfStay : BaseData
	{
		[NonSerialized]
		private LengthOfStayCollection parentLengthOfStayCollection;
		[ColumnMapping("LOSYear",StereoType=DataStereoType.FK)]
		private int lOSYear;
		[ColumnMapping("HCIAPayorGroup")]
		private string hciaPayorgroup;
		[ColumnMapping("HCIARegion")]
		private string hciaRegion;
		[ColumnMapping("DxPxType")]
		private string dxPxType;
		[ColumnMapping("SummaryLevel")]
		private string summaryLevel;
		[ColumnMapping("ICD9code")]
		private string iCD9code;
		[ColumnMapping("CategoryCode")]
		private string categoryCode;
		[ColumnMapping("AgeCategory")]
		private string ageCategory;
		[ColumnMapping("ObservedPatients",StereoType=DataStereoType.FK)]
		private int observedPatients;
		[ColumnMapping("AverageStay")]
		private decimal averageStay;
		[ColumnMapping("LOS_Variance")]
		private decimal losVariance;
		[ColumnMapping("LOS_10",StereoType=DataStereoType.FK)]
		private int los10;
		[ColumnMapping("LOS_10_PLUS")]
		private string los10Plus;
		[ColumnMapping("LOS_25",StereoType=DataStereoType.FK)]
		private int los25;
		[ColumnMapping("LOS_25_PLUS")]
		private string los25Plus;
		[ColumnMapping("LOS_50",StereoType=DataStereoType.FK)]
		private int los50;
		[ColumnMapping("LOS_50_PLUS")]
		private string los50Plus;
		[ColumnMapping("LOS_75",StereoType=DataStereoType.FK)]
		private int los75;
		[ColumnMapping("LOS_75_PLUS")]
		private string los75Plus;
		[ColumnMapping("LOS_90",StereoType=DataStereoType.FK)]
		private int los90;
		[ColumnMapping("LOS_90_PLUS")]
		private string los90Plus;
		[ColumnMapping("LOS_95",StereoType=DataStereoType.FK)]
		private int los95;
		[ColumnMapping("LOS_95_PLUS")]
		private string los95Plus;
		[ColumnMapping("LOS_99",StereoType=DataStereoType.FK)]
		private int los99;
		[ColumnMapping("LOS_99_PLUS")]
		private string los99Plus;
	
		public LengthOfStay()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LOSYear
		{
			get { return this.lOSYear; }
			set { this.lOSYear = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string HciaPayorgroup
		{
			get { return this.hciaPayorgroup; }
			set { this.hciaPayorgroup = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string HciaRegion
		{
			get { return this.hciaRegion; }
			set { this.hciaRegion = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string DxPxType
		{
			get { return this.dxPxType; }
			set { this.dxPxType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string SummaryLevel
		{
			get { return this.summaryLevel; }
			set { this.summaryLevel = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=7)]
		public string ICD9code
		{
			get { return this.iCD9code; }
			set { this.iCD9code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string CategoryCode
		{
			get { return this.categoryCode; }
			set { this.categoryCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string AgeCategory
		{
			get { return this.ageCategory; }
			set { this.ageCategory = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ObservedPatients
		{
			get { return this.observedPatients; }
			set { this.observedPatients = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal AverageStay
		{
			get { return this.averageStay; }
			set { this.averageStay = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal LosVariance
		{
			get { return this.losVariance; }
			set { this.losVariance = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los10
		{
			get { return this.los10; }
			set { this.los10 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los10Plus
		{
			get { return this.los10Plus; }
			set { this.los10Plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los25
		{
			get { return this.los25; }
			set { this.los25 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los25Plus
		{
			get { return this.los25Plus; }
			set { this.los25Plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los50
		{
			get { return this.los50; }
			set { this.los50 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los50Plus
		{
			get { return this.los50Plus; }
			set { this.los50Plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los75
		{
			get { return this.los75; }
			set { this.los75 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los75Plus
		{
			get { return this.los75Plus; }
			set { this.los75Plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los90
		{
			get { return this.los90; }
			set { this.los90 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los90Plus
		{
			get { return this.los90Plus; }
			set { this.los90Plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los95
		{
			get { return this.los95; }
			set { this.los95 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los95Plus
		{
			get { return this.los95Plus; }
			set { this.los95Plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los99
		{
			get { return this.los99; }
			set { this.los99 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los99Plus
		{
			get { return this.los99Plus; }
			set { this.los99Plus = value; }
		}

		/// <summary>
		/// Parent LengthOfStayCollection that contains this element
		/// </summary>
		public LengthOfStayCollection ParentLengthOfStayCollection
		{
			get
			{
				return this.parentLengthOfStayCollection;
			}
			set
			{
				this.parentLengthOfStayCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Load the length of stay record for the given values.
		/// </summary>
		public bool Load(string hciaPayorgroup, string hciaRegion, string dxPxType, string summaryLevel, string iCD9code, string categoryCode, string ageCategory)
		{
			return SqlData.SPExecReadObj("usp_GetLengthOfStayByIdentifiers", this, false, new object[] { hciaPayorgroup, hciaRegion, dxPxType, summaryLevel, iCD9code, categoryCode, ageCategory });
		}
	}

	/// <summary>
	/// Strongly typed collection of LengthOfStay objects
	/// </summary>
	[ElementType(typeof(LengthOfStay))]
	public class LengthOfStayCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LengthOfStay elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLengthOfStayCollection = this;
			else
				elem.ParentLengthOfStayCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LengthOfStay elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LengthOfStay this[int index]
		{
			get
			{
				return (LengthOfStay)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LengthOfStay)oldValue, false);
			SetParentOnElem((LengthOfStay)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}
}
