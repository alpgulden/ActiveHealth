using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [MeasurementTypePickList]
	/// </summary>
	[SPInsert("usp_InsertMeasurementTypePickList")]
	[SPUpdate("usp_UpdateMeasurementTypePickList")]
	[SPDelete("usp_DeleteMeasurementTypePickList")]
	[SPLoad("usp_LoadMeasurementTypePickList")]
	[TableMapping("MeasurementTypePickList","iD")]
	public class MeasurementTypePickList : BaseData
	{
		[NonSerialized]
		private MeasurementTypePickListCollection parentMeasurementTypePickListCollection;
		[ColumnMapping("ID",(int)0)]
		private int iD;
		[ColumnMapping("MeasurementTypeId",StereoType=DataStereoType.FK)]
		private int measurementTypeId;
		[ColumnMapping("PLValue")]
		private string pLValue;
		
	
		public MeasurementTypePickList()
		{
		}

		public MeasurementTypePickList(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ID
		{
			get { return this.iD; }
			set { this.iD = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int MeasurementTypeId
		{
			get { return this.measurementTypeId; }
			set { this.measurementTypeId = value; }
		}

		
		[FieldDescription("@LISTVALUE@")]
		[ControlType(EnumControlTypes.TextBox, /*ClientValidators=EnumClientValidators.Required,*/ MaxLength=50)]
		public string PLValue
		{
			get { return this.pLValue; }
			set { this.pLValue = value; }
		}
		

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent MeasurementTypePickListCollection that contains this element
		/// </summary>
		public MeasurementTypePickListCollection ParentMeasurementTypePickListCollection
		{
			get
			{
				return this.parentMeasurementTypePickListCollection;
			}
			set
			{
				this.parentMeasurementTypePickListCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of MeasurementTypePickList objects
	/// </summary>
	[ElementType(typeof(MeasurementTypePickList))]
	public class MeasurementTypePickListCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PLValue;
		[NonSerialized]
		private CollectionIndexer indexBy_MeasurementTypeId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MeasurementTypePickList elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMeasurementTypePickListCollection = this;
			else
				elem.ParentMeasurementTypePickListCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MeasurementTypePickList elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MeasurementTypePickList this[int index]
		{
			get
			{
				return (MeasurementTypePickList)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MeasurementTypePickList)oldValue, false);
			SetParentOnElem((MeasurementTypePickList)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(MeasurementTypePickList elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((MeasurementTypePickList)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent MeasurementType that contains this collection
		/// </summary>
		public MeasurementType ParentMeasurementType
		{
			get { return this.ParentDataObject as MeasurementType; }
			set { this.ParentDataObject = value; /* parent is set when contained by a MeasurementType */ }
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Hashtable based index on pLValue fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PLValue
		{
			get
			{
				if (this.indexBy_PLValue == null)
					this.indexBy_PLValue = new CollectionIndexer(this, new string[] { "pLValue" }, true);
				return this.indexBy_PLValue;
			}
			
		}

		/// <summary>
		/// Hashtable based search on pLValue fields returns the object.  Uses the IndexBy_PLValue indexer.
		/// </summary>
		public MeasurementTypePickList FindBy(string pLValue)
		{
			return (MeasurementTypePickList)this.IndexBy_PLValue.GetObject(pLValue);
		}
	}
}
