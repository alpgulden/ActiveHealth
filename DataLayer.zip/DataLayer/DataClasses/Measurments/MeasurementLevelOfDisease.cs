using System;

using NetsoftUSA.DataLayer;
using ActiveAdvice.Messages;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [MeasurementLevelOfDisease]
	/// </summary>
	[SPInsert("usp_InsertMeasurementLevelOfDisease")]
	[SPUpdate("usp_UpdateMeasurementLevelOfDisease")]
	[SPDelete("usp_DeleteMeasurementLevelOfDisease")]
	[SPLoad("usp_LoadMeasurementLevelOfDisease")]
	[TableMapping("MeasurementLevelOfDisease","measurementLevelOfDiseaseID")]
	public class MeasurementLevelOfDisease : BaseData
	{
		[NonSerialized]
		private MeasurementLevelOfDiseaseCollection parentMeasurementLevelOfDiseaseCollection;
		[ColumnMapping("MeasurementLevelOfDiseaseID",(int)0)]
		private int measurementLevelOfDiseaseID;
		[ColumnMapping("MeasurementTypeID",StereoType=DataStereoType.FK)]
		private int measurementTypeID;
		[ColumnMapping("LevelOfDiseaseTypeID",StereoType=DataStereoType.FK)]
		private int levelOfDiseaseTypeID;
		[ColumnMapping("LevelOfDisease")]
		private string levelOfDisease;
		[ColumnMapping("ThreshholdHigh")]
		private double threshholdHigh = double.NaN;
		[ColumnMapping("ThreshholdLow")]
		private double threshholdLow = double.NaN;

	
		public MeasurementLevelOfDisease()
		{
		}

		public MeasurementLevelOfDisease(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int MeasurementLevelOfDiseaseID
		{
			get { return this.measurementLevelOfDiseaseID; }
			set { this.measurementLevelOfDiseaseID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MeasurementTypeID
		{
			get { return this.measurementTypeID; }
			set { this.measurementTypeID = value; }
		}

		[FieldValuesMember("LookupOf_LevelOfDiseaseTypeID", "LevelOfDiseaseTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@LODCODE@")]
		public int LevelOfDiseaseTypeID
		{
			get { return this.levelOfDiseaseTypeID; }
			set { this.levelOfDiseaseTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, /*ClientValidators=EnumClientValidators.Required,*/ MaxLength=50)]
		[FieldDescription("@DESCRIPTION@")]
		public string LevelOfDisease
		{
			get { return this.levelOfDisease; }
			set { this.levelOfDisease = value; }
		}

		[ValidatorMember("Vld_ThreshholdHigh")]
		[FieldDescription("@THRESHHOLDHIGH@")]
		[ControlType(Macro=EnumControlTypeMacros.Double/*, ValueForNull=(int)0*/)]
		public double ThreshholdHigh
		{
			get { return this.threshholdHigh; }
			set { this.threshholdHigh = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double/*, ValueForNull=(int)0*/)]
		[FieldDescription("@THRESHHOLDLOW@")]
		public double ThreshholdLow
		{
			get { return this.threshholdLow; }
			set { this.threshholdLow = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent MeasurementLevelOfDiseaseCollection that contains this element
		/// </summary>
		public MeasurementLevelOfDiseaseCollection ParentMeasurementLevelOfDiseaseCollection
		{
			get
			{
				return this.parentMeasurementLevelOfDiseaseCollection;
			}
			set
			{
				this.parentMeasurementLevelOfDiseaseCollection = value; // parent is set when added to a collection
			}
		}

		public LevelOfDiseaseTypeCollection LookupOf_LevelOfDiseaseTypeID
		{
			get
			{
				return LevelOfDiseaseTypeCollection.ActiveLevelOfDiseaseTypes; // Acquire a shared instance from the static member of collection
			}
		}

		[GenericScript("Vld_ThreshholdHigh", "@ThreshholdHigh@ != null && @ThreshholdHigh@ > @ThreshholdLow@;")]
		public string Vld_ThreshholdHigh
		{
			get
			{
				return "@THRESHHOLDHIGH@" + " " + MeasurementMessages.MessageIDs.ERRLODTHHIGH + " " + "@THRESHHOLDLOW@";
			}
			set
			{}
		}
	}

	/// <summary>
	/// Strongly typed collection of MeasurementLevelOfDisease objects
	/// </summary>
	[ElementType(typeof(MeasurementLevelOfDisease))]
	public class MeasurementLevelOfDiseaseCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MeasurementLevelOfDisease elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMeasurementLevelOfDiseaseCollection = this;
			else
				elem.ParentMeasurementLevelOfDiseaseCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MeasurementLevelOfDisease elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MeasurementLevelOfDisease this[int index]
		{
			get
			{
				return (MeasurementLevelOfDisease)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MeasurementLevelOfDisease)oldValue, false);
			SetParentOnElem((MeasurementLevelOfDisease)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(MeasurementLevelOfDisease elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((MeasurementLevelOfDisease)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent MeasurementType that contains this collection
		/// </summary>
		public MeasurementType ParentMeasurementType
		{
			get { return this.ParentDataObject as MeasurementType; }
			set { this.ParentDataObject = value; /* parent is set when contained by a MeasurementType */ }
		}
	}
}
