using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [WCInjuryBodyPart]
	/// </summary>
	[SPAutoGen("usp_GetAllWCInjuryBodyPart","SelectAll.sptpl","")]
	[SPInsert("usp_InsertWCInjuryBodyPart")]
	[SPUpdate("usp_UpdateWCInjuryBodyPart")]
	[SPDelete("usp_DeleteWCInjuryBodyPart")]
	[SPLoad("usp_LoadWCInjuryBodyPart")]
	[TableMapping("WCInjuryBodyPart","injuryBodyPartId")]
	public class WCInjuryBodyPart : BaseLookupWithNote
	{
		[NonSerialized]
		private WCInjuryBodyPartCollection parentWCInjuryBodyPartCollection;
		[ColumnMapping("InjuryBodyPartId",(int)0)]
		private int injuryBodyPartId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public WCInjuryBodyPart()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int InjuryBodyPartId
		{
			get { return this.injuryBodyPartId; }
			set { this.injuryBodyPartId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent WCInjuryBodyPartCollection that contains this element
		/// </summary>
		public WCInjuryBodyPartCollection ParentWCInjuryBodyPartCollection
		{
			get
			{
				return this.parentWCInjuryBodyPartCollection;
			}
			set
			{
				this.parentWCInjuryBodyPartCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int injuryBodyPartId)
		{
			return base.Load(injuryBodyPartId);
		}
	}

	/// <summary>
	/// Strongly typed collection of WCInjuryBodyPart objects
	/// </summary>
	[ElementType(typeof(WCInjuryBodyPart))]
	public class WCInjuryBodyPartCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(WCInjuryBodyPart elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentWCInjuryBodyPartCollection = this;
			else
				elem.ParentWCInjuryBodyPartCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (WCInjuryBodyPart elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public WCInjuryBodyPart this[int index]
		{
			get
			{
				return (WCInjuryBodyPart)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((WCInjuryBodyPart)oldValue, false);
			SetParentOnElem((WCInjuryBodyPart)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllWCInjuryBodyPart", -1, this, false);
		}
	}
}
