using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Licensee]
	/// </summary>
	[SPAutoGen("usp_LoadAllLicensee","SelectAll.sptpl","")]
	[SPInsert("usp_InsertLicensee")]
	[SPUpdate("usp_UpdateLicensee")]
	[SPDelete("usp_DeleteLicensee")]
	[SPLoad("usp_LoadLicensee")]
	[TableMapping("Licensee","licenseeID")]
	public class Licensee : BaseData
	{
		[NonSerialized]
		private LicenseeCollection parentLicenseeCollection;
		[ColumnMapping("LicenseeID",(int)0)]
		private int licenseeID;
		[ColumnMapping("FullName")]
		private string fullName;
		[ColumnMapping("AbbreviatedName")]
		private string abbreviatedName;
		[ColumnMapping("AddressID",StereoType=DataStereoType.FK)]
		private int addressID;
		[ColumnMapping("DirLastName")]
		private string dirLastName;
		[ColumnMapping("DirFirstName")]
		private string dirFirstName;
		[ColumnMapping("DirMiddleName")]
		private string dirMiddleName;
		[ColumnMapping("DirPrefixID",StereoType=DataStereoType.FK)]
		private int dirPrefixID;
		[ColumnMapping("DirSuffix")]
		private string dirSuffix;
		[ColumnMapping("DirTitle")]
		private string dirTitle;
		[ColumnMapping("SuperPrefixID",StereoType=DataStereoType.FK)]
		private int superPrefixID;
		[ColumnMapping("SuperLastName")]
		private string superLastName;
		[ColumnMapping("SuperFirstName")]
		private string superFirstName;
		[ColumnMapping("SuperMiddleName")]
		private string superMiddleName;
		[ColumnMapping("SuperSuffix")]
		private string superSuffix;
		[ColumnMapping("SuperTitle")]
		private string superTitle;
		[ColumnMapping("AutoAuthURL")]
		private string autoAuthURL;
		[ColumnMapping("SMTPHost")]
		private string sMTPHost;
		[ColumnMapping("Disclaimer")]
		private string disclaimer;
		[ColumnMapping("Subject")]
		private string subject;
		[ColumnMapping("FaxServer")]
		private string faxServer;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		private Address address;
	
		public Licensee()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Licensee(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int LicenseeID
		{
			get { return this.licenseeID; }
			set { this.licenseeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=45)]
		public string FullName
		{
			get { return this.fullName; }
			set { this.fullName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string AbbreviatedName
		{
			get { return this.abbreviatedName; }
			set { this.abbreviatedName = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string DirLastName
		{
			get { return this.dirLastName; }
			set { this.dirLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string DirFirstName
		{
			get { return this.dirFirstName; }
			set { this.dirFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string DirMiddleName
		{
			get { return this.dirMiddleName; }
			set { this.dirMiddleName = value; }
		}

		[FieldValuesMember("LookupOf_DirPrefixID", "NamePrefixId", "Prefix")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int DirPrefixID
		{
			get { return this.dirPrefixID; }
			set { this.dirPrefixID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string DirSuffix
		{
			get { return this.dirSuffix; }
			set { this.dirSuffix = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string DirTitle
		{
			get { return this.dirTitle; }
			set { this.dirTitle = value; }
		}

		[FieldValuesMember("LookupOf_DirPrefixID", "NamePrefixId", "Prefix")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int SuperPrefixID
		{
			get { return this.superPrefixID; }
			set { this.superPrefixID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SuperLastName
		{
			get { return this.superLastName; }
			set { this.superLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SuperFirstName
		{
			get { return this.superFirstName; }
			set { this.superFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SuperMiddleName
		{
			get { return this.superMiddleName; }
			set { this.superMiddleName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string SuperSuffix
		{
			get { return this.superSuffix; }
			set { this.superSuffix = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SuperTitle
		{
			get { return this.superTitle; }
			set { this.superTitle = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string AutoAuthURL
		{
			get { return this.autoAuthURL; }
			set { this.autoAuthURL = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string SMTPHost
		{
			get { return this.sMTPHost; }
			set { this.sMTPHost = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Disclaimer
		{
			get { return this.disclaimer; }
			set { this.disclaimer = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string Subject
		{
			get { return this.subject; }
			set { this.subject = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string FaxServer
		{
			get { return this.faxServer; }
			set { this.faxServer = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int licenseeID)
		{
			return base.Load(licenseeID);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.addressID = 0;
		}

		/// <summary>
		/// Parent LicenseeCollection that contains this element
		/// </summary>
		public LicenseeCollection ParentLicenseeCollection
		{
			get
			{
				return this.parentLicenseeCollection;
			}
			set
			{
				this.parentLicenseeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Contained Address object
		/// </summary>
		[Contained]
		public Address Address
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.address = (Address)Address.EnsureContainedDataObject(this, typeof(Address), address, false, addressID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.address;
			}
			set
			{
				this.address = value;
				if (value != null) value.ParentLicensee = this; // set this as a parent of the child data class
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			//termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to load child and other objects that must be loaded with this object.
		/// </summary>
		protected override bool InternalLoad(params object[] keys)
		{
			// Do pre-load operations here.
			bool result = base.InternalLoad(keys);
			// Do post-load operations here.
			return result;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			this.Address.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
		{
			base.InternalSave();	// in that case, delete the base first
			Address.MarkDel();	// then allow the deletion of the conatined object
		}
			Address.IsNew = this.IsNew;	// make sure the contained object is new if the containing object is new
			Address.Save();
			this.addressID = Address.AddressID; // set the fk if the contained object was newly created
			/*if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
					{
						// user has changed term date, set the terminating user
						this.SetTerminatingUser();
					}*/
			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			 this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		public NamePrefixCollection LookupOf_DirPrefixID
		{
			get
			{
				return NamePrefixCollection.ActiveNamePrefixes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of Licensee objects
	/// </summary>
	[ElementType(typeof(Licensee))]
	public class LicenseeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllLicensee(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadAllLicensee", maxRecords, this, false);
		}

		

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Licensee elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLicenseeCollection = this;
			else
				elem.ParentLicenseeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Licensee elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Licensee this[int index]
		{
			get
			{
				return (Licensee)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Licensee)oldValue, false);
			SetParentOnElem((Licensee)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Accessor to a shared LicenseeCollection which is cached in NSGlobal
		/// </summary>
		public static Licensee Licensee
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LicenseeCollection col = (LicenseeCollection)NSGlobal.EnsureCachedObject("Licensee", typeof(LicenseeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllLicensee(1);
				}
				if (col.Count > 0)
					return col[0];
				else
					return null;
			}
			
		}
	}
}
