using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [IntakeAction]
	/// </summary>
	[SPAutoGen("usp_GetAllIntakeActions","SelectAll.sptpl","")]
	[SPLoad("usp_LoadIntakeAction")]
	[TableMapping("IntakeAction","code")]
	public class IntakeAction : BaseData
	{
		#region Action codes
		
		public const string ADDE = "ADDE"; // Add an Event
		public const string ADDQ = "ADDQ"; // Add Quickcert
		public const string ADDR = "ADDR"; // Add a Referral
		public const string AUTO = "AUTO"; // Request Auto Auth
		public const string NOPC = "NOPC"; // No precertification required
		public const string OTNA = "OTNA"; // Other - No Action
		public const string OTPS = "OTPS"; // Other - Go to Pt Summary
		public const string VERF = "VERF"; // Verified Information

		#endregion

		[NonSerialized]
		private IntakeActionCollection parentIntakeActionCollection;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
	
		public IntakeAction()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		/// <summary>
		/// Parent IntakeActionCollection that contains this element
		/// </summary>
		public IntakeActionCollection ParentIntakeActionCollection
		{
			get
			{
				return this.parentIntakeActionCollection;
			}
			set
			{
				this.parentIntakeActionCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of IntakeAction objects
	/// </summary>
	[ElementType(typeof(IntakeAction))]
	public class IntakeActionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(IntakeAction elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentIntakeActionCollection = this;
			else
				elem.ParentIntakeActionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (IntakeAction elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public IntakeAction this[int index]
		{
			get
			{
				return (IntakeAction)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((IntakeAction)oldValue, false);
			SetParentOnElem((IntakeAction)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllIntakeActions(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllIntakeActions", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared IntakeActionCollection which is cached in NSGlobal
		/// </summary>
		public static IntakeActionCollection AllIntakeActions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				IntakeActionCollection col = (IntakeActionCollection)NSGlobal.EnsureCachedObject("AllIntakeActions", typeof(IntakeActionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllIntakeActions(-1);
				}
				return col;
			}
			
		}
	}
}
