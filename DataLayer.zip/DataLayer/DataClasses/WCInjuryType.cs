using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [WCInjuryBodyPart]
	/// </summary>

	[SPAutoGen("usp_GetAllWCInjuryType","SelectAll.sptpl","")]
	[SPInsert("usp_InsertWCInjuryType")]
	[SPUpdate("usp_UpdateWCInjuryType")]
	[SPDelete("usp_DeleteWCInjuryType")]
	[SPLoad("usp_LoadWCInjuryType")]
	[TableMapping("WCInjuryType","injuryTypeId")]
	public class WCInjuryType : BaseLookupWithNote
	{
		[NonSerialized]
		private WCInjuryTypeCollection parentWCInjuryTypeCollection;
		[ColumnMapping("InjuryTypeId",(int)0)]
		private int injuryTypeId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public WCInjuryType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int InjuryTypeId
		{
			get { return this.injuryTypeId; }
			set { this.injuryTypeId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent WCInjuryTypeCollection that contains this element
		/// </summary>
		public WCInjuryTypeCollection ParentWCInjuryTypeCollection
		{
			get
			{
				return this.parentWCInjuryTypeCollection;
			}
			set
			{
				this.parentWCInjuryTypeCollection = value; // parent is set when added to a collection
			}
		}	
	
		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int injuryTypeId)
		{
			return base.Load(injuryTypeId);
		}
	}

	/// <summary>
	/// Strongly typed collection of WCInjuryType objects
	/// </summary>
	[ElementType(typeof(WCInjuryType))]
	public class WCInjuryTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(WCInjuryType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentWCInjuryTypeCollection = this;
			else
				elem.ParentWCInjuryTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (WCInjuryType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public WCInjuryType this[int index]
		{
			get
			{
				return (WCInjuryType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((WCInjuryType)oldValue, false);
			SetParentOnElem((WCInjuryType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllWCInjuryType", -1, this, false);
		}
	}
}
