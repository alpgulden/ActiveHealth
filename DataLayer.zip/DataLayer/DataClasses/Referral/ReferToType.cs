using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReferToType]
	/// </summary>
	[SPAutoGen("usp_GetReferToTypeByCode","SelectAllByGivenArgs.sptpl","code")]
	[SPAutoGen("usp_GetAllReferToType","SelectAll.sptpl","")]
	[SPInsert("usp_InsertReferToType")]
	[SPUpdate("usp_UpdateReferToType")]
	[SPDelete("usp_DeleteReferToType")]
	[SPLoad("usp_LoadReferToType")]
	[TableMapping("ReferToType","referToTypeID")]
	public class ReferToType : BaseLookupWithNote
	{
		[NonSerialized]
		private ReferToTypeCollection parentReferToTypeCollection;
		[ColumnMapping("ReferToTypeID",(int)0)]
		private int referToTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public const string PROVIDER = "PROV";
		public const string FACILITY = "FAC";
		public const string GROUPPRACTICE = "GRP";

		public ReferToType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ReferToTypeID
		{
			get { return this.referToTypeID; }
			set { this.referToTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}
		
		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int referToTypeID)
		{
			return base.Load(referToTypeID);
		}

		/// <summary>
		/// Parent ReferToTypeCollection that contains this element
		/// </summary>
		public ReferToTypeCollection ParentReferToTypeCollection
		{
			get
			{
				return this.parentReferToTypeCollection;
			}
			set
			{
				this.parentReferToTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadReferToTypeByCode(string code)
		{
			return SqlData.SPExecReadObj("usp_GetReferToTypeByCode", this, false, new object[] { code });
		}
	}

	/// <summary>
	/// Strongly typed collection of ReferToType objects
	/// </summary>
	[ElementType(typeof(ReferToType))]
	public class ReferToTypeCollection : BaseTypeCollection
	{

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllReferToType", -1, this, false);
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReferToType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReferToTypeCollection = this;
			else
				elem.ParentReferToTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ReferToType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReferToType this[int index]
		{
			get
			{
				return (ReferToType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReferToType)oldValue, false);
			SetParentOnElem((ReferToType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}
}
