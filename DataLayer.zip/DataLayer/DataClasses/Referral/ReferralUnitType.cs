using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReferralUnitTypes]
	/// </summary>
	/// 

	[SPAutoGen("usp_GetReferralUnitTypeByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllReferralUniteType","SelectAll.sptpl","")]
	[SPInsert("usp_InsertReferralUnitType")]
	[SPUpdate("usp_UpdateReferralUnitType")]
	[SPDelete("usp_DeleteReferralUnitType")]
	[SPLoad("usp_LoadReferralUnitType")]
	[TableMapping("ReferralUnitType","referralUnitTypeID")]
	public class ReferralUnitType : BaseLookupWithSubCode
	{
		[NonSerialized]
		private ReferralUnitTypeCollection parentReferralUnitTypeCollection;
		[ColumnMapping("ReferralUnitTypeID",StereoType=DataStereoType.FK)]
		private int referralUnitTypeID;
		[ColumnMapping("ReportUnitID",StereoType=DataStereoType.FK)]
		private int reportUnitID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ReferralUnitType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ReferralUnitTypeID
		{
			get { return this.referralUnitTypeID; }
			set { this.referralUnitTypeID = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent ReferralUnitTypeCollection that contains this element
		/// </summary>
		public ReferralUnitTypeCollection ParentReferralUnitTypeCollection
		{
			get
			{
				return this.parentReferralUnitTypeCollection;
			}
			set
			{
				this.parentReferralUnitTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReportUnitID
		{
			get { return this.reportUnitID; }
			set { this.reportUnitID = value; }
		}
		
		
		[FieldValuesMember("LookupOf_SubCodeID", "CodeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@REPORTUNIT@")]
		public override int SubCodeID
		{
			get { return this.reportUnitID; }
			set { this.reportUnitID = value; }
		}

		public ReportUnitCollection LookupOf_SubCodeID
		{
			get
			{
				return ReportUnitCollection.ActiveReportUnits; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of ReferralUnitType objects
	/// </summary>
	[ElementType(typeof(ReferralUnitType))]
	public class ReferralUnitTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReferralUnitType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReferralUnitTypeCollection = this;
			else
				elem.ParentReferralUnitTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ReferralUnitType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReferralUnitType this[int index]
		{
			get
			{
				return (ReferralUnitType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReferralUnitType)oldValue, false);
			SetParentOnElem((ReferralUnitType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadReferralUnitTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetReferralUnitTypeByActive", maxRecords, this, false, new object [] { active });
		}

		/// <summary>
		/// Accessor to a shared ReferralTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ReferralUnitTypeCollection ActiveReferralUnitTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ReferralUnitTypeCollection col = (ReferralUnitTypeCollection)NSGlobal.EnsureCachedObject("ActiveReferralUnitTypes", typeof(ReferralUnitTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					//col.GetFacilityFocusTypesByActive(-1, true);
					col.LoadReferralUnitTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Hashtable based search on code fields returns the object.  Uses the IndexBy_Code indexer.
		/// </summary>
		public ReferralUnitType FindBy(string code)
		{
			return (ReferralUnitType)this.IndexBy_Code.GetObject(code);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllReferralUniteType", -1, this, false);
		}
	}
}
