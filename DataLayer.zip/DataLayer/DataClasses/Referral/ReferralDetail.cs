using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReferralDetails]
	/// </summary>	
	[SPAutoGen("usp_GetLastDetailForReferral","SelectAllByGivenArgs.sptpl",
		 "referralID",
		 InjectPreOperation="SET ROWCOUNT 1  -- top record",
		 InjectOrderBy="ORDER BY [ReferralDetailID] DESC"
		 )]
	[SPInsert("usp_InsertReferralDetail")]
	[SPUpdate("usp_UpdateReferralDetail")]
	[SPDelete("usp_DeleteReferralDetail")]
	[SPLoad("usp_LoadReferralDetail")]	
	[TableMapping("ReferralDetail","referralDetailID")]
	public class ReferralDetail : BaseData
	{
		[NonSerialized]
		private ReferralDetailCollection parentReferralDetailCollection;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		private int referralID;
		[ColumnMapping("ReferralDetailDate")]
		private DateTime referralDetailDate;
		[ColumnMapping("Reason")]
		private string reason;
		[ColumnMapping("ReferralStatusID",StereoType=DataStereoType.FK)]
		private int referralStatusID;
		[ColumnMapping("ReferralStatusDate")]
		private DateTime referralStatusDate;
		[ColumnMapping("ValidStartDate")]
		private DateTime validStartDate;
		[ColumnMapping("ValidEndDate")]
		private DateTime validEndDate;
		[ColumnMapping("ReferralUrgencyID",StereoType=DataStereoType.FK)]
		private int referralUrgencyID;
		[ColumnMapping("DecisionReasonID",StereoType=DataStereoType.FK)]
		private int decisionReasonID;
		[ColumnMapping("UnitQuantity",StereoType=DataStereoType.FK)]
		private int unitQuantity;
		[ColumnMapping("UnitTypeID",StereoType=DataStereoType.FK)]
		private int unitTypeID;
		[ColumnMapping("UnitUnlimited")]
		private bool unitUnlimited;
		[ColumnMapping("ReferralAuthorizationDecisionID",StereoType=DataStereoType.FK)]
		private int referralAuthorizationDecisionID;
		[ColumnMapping("EligibilityID",StereoType=DataStereoType.FK)]
		private int eligibilityID;
		[ColumnMapping("EligibilityStatus")]
		private string eligibilityStatus;
		[ColumnMapping("EligibilityEffectiveDate")]
		private DateTime eligibilityEffectiveDate;
		[ColumnMapping("PhysicianReview")]
		private bool physicianReview;
		[ColumnMapping("ReportDateReceived")]
		private DateTime reportDateReceived;
		[ColumnMapping("EDI_Log_DetailID",StereoType=DataStereoType.FK)]
		private int ediLogDetailid;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("AlternateExtensionId")]
		private string alternateExtensionId;
		[ColumnMapping("PatientSubscriberLogID",StereoType=DataStereoType.FK)]
		private int patientSubscriberLogID;
		[ColumnMapping("PlanSORGLogID",StereoType=DataStereoType.FK)]
		private int planSORGLogID;
		[ColumnMapping("ReferralStatusChangedBy")]
		private int referralStatusChangedBy;
		private ReferralAppointmentCollection referralAppointments;
		private ReferralReportEntryCollection referralReportEntries;

		// fields to check for changes
		private int referralAuthorizationDecisionIDwhenLoaded = 0;

		public ReferralDetail()
		{			
		}

		public ReferralDetail(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
				this.referralDetailDate = DateTime.Today;
				this.PlanSORGLogID=10;
				this.PatientSubscriberLogID = 15;
				//this.ReferralStatusID = 1;
				this.ReferralStatusDate = DateTime.Today;
				this.ReferralStatusChangedBy =1 ;
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int referralDetailID)
		{
			return base.Load(referralDetailID);
		}

		protected override void InitializeToTrackChanges()
		{
			base.InitializeToTrackChanges ();

			this.referralAuthorizationDecisionIDwhenLoaded = this.referralAuthorizationDecisionID;
		}


		/// <summary>
		/// Parent ReferralDetailCollection that contains this element
		/// </summary>
		public ReferralDetailCollection ParentReferralDetailCollection
		{
			get
			{
				return this.parentReferralDetailCollection;
			}
			set
			{
				this.parentReferralDetailCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Load the Referral related to this Referral Detail and return it.
		/// </summary>
		/// <returns></returns>
		public Referral GetReferral()
		{
			if (this.parentReferralDetailCollection != null)
				if (this.parentReferralDetailCollection.ParentReferral != null)
					return this.parentReferralDetailCollection.ParentReferral;

			if (this.referralID == 0)
				return null;

			Referral referral = new Referral();
			referral.SqlData.Transaction = this.SqlData.Transaction;
			if (referral.Load(this.referralID))
				return referral;
			else
				return null;

		}
		
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime ReferralDetailDate
		{
			get { return this.referralDetailDate; }
			set { this.referralDetailDate = value; }
		}

		[FieldValuesMember("LookupOf_Reason", "StatusId", "Description")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Reason
		{
			get { return this.reason; }
			set { this.reason = value; }
		}

		[FieldValuesMember("LookupOf_ReferralStatusID", "StatusId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int ReferralStatusID
		{
			get { return this.referralStatusID; }
			set { this.referralStatusID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime ReferralStatusDate
		{
			get { return this.referralStatusDate; }
			set { this.referralStatusDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ValidStartDate
		{
			get { return this.validStartDate; }
			set { this.validStartDate = value; }
		}

		[ValidatorMember("Vld_ValidEndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ValidEndDate
		{
			get { return this.validEndDate; }
			set { this.validEndDate = value; }
		}

		[FieldValuesMember("LookupOf_ReferralUrgencyID", "ReferralUrgencyID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ReferralUrgencyID
		{
			get { return this.referralUrgencyID; }
			set { this.referralUrgencyID = value; }
		}

		[FieldValuesMember("LookupOf_DecisionReasonID", "DecisionReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int DecisionReasonID
		{
			get { return this.decisionReasonID; }
			set { this.decisionReasonID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int,IsRequired=true)]
		public int UnitQuantity
		{
			get { return this.unitQuantity; }
			set { this.unitQuantity = value; }
		}

		[FieldValuesMember("LookupOf_UnitTypeID", "ReferralUnitTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup,IsRequired=true)]
		public int UnitTypeID
		{
			get { return this.unitTypeID; }
			set { this.unitTypeID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool UnitUnlimited
		{
			get { return this.unitUnlimited; }
			set { this.unitUnlimited = value; }
		}

		[FieldValuesMember("LookupOf_ReferralAuthorizationDecisionID", "ReferralAuthorizationDecisionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@AUTHORIZATIONDECISIONID@")]
		public int ReferralAuthorizationDecisionID
		{
			get { return this.referralAuthorizationDecisionID; }
			set { this.referralAuthorizationDecisionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EligibilityID
		{
			get { return this.eligibilityID; }
			set { this.eligibilityID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string EligibilityStatus
		{
			get { return this.eligibilityStatus; }
			set { this.eligibilityStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EligibilityEffectiveDate
		{
			get { return this.eligibilityEffectiveDate; }
			set { this.eligibilityEffectiveDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool PhysicianReview
		{
			get { return this.physicianReview; }
			set { this.physicianReview = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ReportDateReceived
		{
			get { return this.reportDateReceived; }
			set { this.reportDateReceived = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EdiLogDetailid
		{
			get { return this.ediLogDetailid; }
			set { this.ediLogDetailid = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateExtensionId
		{
			get { return this.alternateExtensionId; }
			set { this.alternateExtensionId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientSubscriberLogID
		{
			get { return this.patientSubscriberLogID; }
			set { this.patientSubscriberLogID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PlanSORGLogID
		{
			get { return this.planSORGLogID; }
			set { this.planSORGLogID = value; }
		}

		/// <summary>
		/// Event Status checks are performed against this property.
		/// Example:
		///		if (eventObj.StatusCode == 
		/// </summary>
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public string StatusCode
		{
			get { return SystemStatusCollection.ActiveSystemStatuses.Lookup_CodeByStatusId(this.referralStatusID); }
			set { this.referralStatusID = SystemStatusCollection.ActiveSystemStatuses.Lookup_StatusIdByCode(value); }
		}

		/// <summary>
		/// Child ReferralAppointments mapped to related rows of table ReferralAppointments where [ReferralDetailID] = [ReferralDetailID]
		/// </summary>
		[SPLoadChild("usp_LoadReferralDetailReferralAppointments", "referralDetailID")]
		public ReferralAppointmentCollection ReferralAppointments
		{
			get { return this.referralAppointments; }
			set
			{
				this.referralAppointments = value;
				if (value != null)
					value.ParentReferralDetail = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ReferralAppointments collection
		/// </summary>
		public void LoadReferralAppointments(bool forceReload)
		{
			this.referralAppointments = (ReferralAppointmentCollection)ReferralAppointmentCollection.LoadChildCollection("ReferralAppointments", this, typeof(ReferralAppointmentCollection), referralAppointments, forceReload, null);
		}

		/// <summary>
		/// Saves the ReferralAppointments collection
		/// </summary>
		public void SaveReferralAppointments()
		{
			ReferralAppointmentCollection.SaveChildCollection(this.referralAppointments, true);
		}

		/// <summary>
		/// Synchronizes the ReferralAppointments collection
		/// </summary>
		public void SynchronizeReferralAppointments()
		{
			ReferralAppointmentCollection.SynchronizeChildCollection(this.referralAppointments, true);
		}

		/// <summary>
		/// Child ReferralReportEntries mapped to related rows of table ReferralReportEntries where [ReferralDetailID] = [ReferralDetailID]
		/// </summary>
		[SPLoadChild("usp_LoadReferralDetailReferralReportEntries", "referralDetailID")]
		public ReferralReportEntryCollection ReferralReportEntries
		{
			get { return this.referralReportEntries; }
			set
			{
				this.referralReportEntries = value;
				if (value != null)
					value.ParentReferralDetail = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ReferralReportEntries collection
		/// </summary>
		public void LoadReferralReportEntries(bool forceReload)
		{
			this.referralReportEntries = (ReferralReportEntryCollection)ReferralReportEntryCollection.LoadChildCollection("ReferralReportEntries", this, typeof(ReferralReportEntryCollection), referralReportEntries, forceReload, null);
		}

		/// <summary>
		/// Saves the ReferralReportEntries collection
		/// </summary>
		public void SaveReferralReportEntries()
		{
			ReferralReportEntryCollection.SaveChildCollection(this.referralReportEntries, true);
		}

		/// <summary>
		/// Synchronizes the ReferralReportEntries collection
		/// </summary>
		public void SynchronizeReferralReportEntries()
		{
			ReferralReportEntryCollection.SynchronizeChildCollection(this.referralReportEntries, true);
		}

		public ReferralAuthorizationDecisionCollection LookupOf_ReferralAuthorizationDecisionID
		{
			get
			{
				return ReferralAuthorizationDecisionCollection.ActiveReferralAuthorizationDecisions; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public DecisionReasonCollection LookupOf_DecisionReasonID
		{
			get
			{
				return DecisionReasonCollection.ActiveDecisionReason; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public ReferralUrgencyCollection LookupOf_ReferralUrgencyID
		{
			get
			{
				return ReferralUrgencyCollection.ActiveReferralUrgency; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public ReferralUnitTypeCollection LookupOf_UnitTypeID
		{
			get
			{
				return ReferralUnitTypeCollection.ActiveReferralUnitTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		[GenericScript("Vld_ValidEndDate", "@ValidEndDate@ != null && @ValidEndDate@ >= @ValidStartDate@;")]
		public string Vld_ValidEndDate
		{
			get
			{
				return "@ERRVALIDDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
			}
		}

		public SystemStatusCollection LookupOf_Reason
		{
			get
			{
				return SystemStatusCollection.ActiveSystemStatuses; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public SystemStatusCollection LookupOf_ReferralStatusID
		{
			get
			{
				return SystemStatusCollection.ActiveSystemStatuses; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralStatusChangedBy
		{
			get { return this.referralStatusChangedBy; }
			set { this.referralStatusChangedBy = value; }
		}

		/// <summary>
		/// Load the last referral detail for the given referral id
		/// </summary>
		public bool LoadLastDetailForReferral(int referralID)
		{
			return SqlData.SPExecReadObj("usp_GetLastDetailForReferral", this, false, new object[] { referralID });
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			bool authDecisionChanged = this.referralAuthorizationDecisionID != referralAuthorizationDecisionIDwhenLoaded;

			base.InternalSave();
			// Save the child collections here.

			#region Trigger AutoActivities - RD1 - Setting Referral Decision Type

			if (authDecisionChanged)
			{
				AutoActivity_SettingReferralDecisionType();
			}

			#endregion
		}

		/// <summary>
		/// RD1	- Setting Event Decision Type
		/// This is triggered when the referral detail authorization decision is changed.
		/// </summary>
		public void AutoActivity_SettingReferralDecisionType()
		{
			Referral referral = this.GetReferral();
			autoActivityManager = referral.EnsureAutoActivityManager();
			this.autoActivityManager.Execute(AutoActivityRuleType.RD1, this.SqlData.Transaction);
		}
	}

	/// <summary>
	/// Strongly typed collection of ReferralDetail objects
	/// </summary>
	[ElementType(typeof(ReferralDetail))]
	public class ReferralDetailCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReferralDetail elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReferralDetailCollection = this;
			else
				elem.ParentReferralDetailCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ReferralDetail elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReferralDetail this[int index]
		{
			get
			{
				return (ReferralDetail)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReferralDetail)oldValue, false);
			SetParentOnElem((ReferralDetail)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Referral that contains this collection
		/// </summary>
		public Referral ParentReferral
		{
			get { return this.ParentDataObject as Referral; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Referral */ }
		}
	}
}
