using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReferralReportEntries]
	/// </summary>
	[SPInsert("usp_InsertReferralReportEntry")]
	[SPUpdate("usp_UpdateReferralReportEntry")]
	[SPDelete("usp_DeleteReferralReportEntry")]
	[SPLoad("usp_LoadReferralReportEntry")]
	[TableMapping("ReferralReportEntry","referralReportEntryID")]
	public class ReferralReportEntry : BaseData
	{
		[ColumnMapping("ReferralReportEntryID",StereoType=DataStereoType.FK)]
		private int referralReportEntryID;
		[ColumnMapping("ReferralRoleID",StereoType=DataStereoType.FK)]
		private int referralRoleID;
		[ColumnMapping("ReportEntryName")]
		private string reportEntryName;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("ReportReceivedDate")]
		private DateTime reportReceivedDate;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[NonSerialized]
		private ReferralReportEntryCollection parentReferralReportEntryCollection;

		public ReferralReportEntry()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ReferralReportEntry(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public ReferralReportEntry(int referralRoleID, int referralDetailID, int createdBy, System.DateTime createTime)
		{
			this.NewRecord(); // initialize record state
			this.referralRoleID = referralRoleID;
			this.referralDetailID = referralDetailID;
			this.createdBy = createdBy;
			this.createTime = createTime;
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int referralReportEntryId)
		{
			return base.Load(referralReportEntryId);
		}


		/// <summary>
		/// Parent ReferralReportEntryCollection that contains this element
		/// </summary>
		public ReferralReportEntryCollection ParentReferralReportEntryCollection
		{
			get
			{
				return this.parentReferralReportEntryCollection;
			}
			set
			{
				this.parentReferralReportEntryCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ReferralReportEntryID
		{
			get { return this.referralReportEntryID; }
			set { this.referralReportEntryID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ReferralRoleID
		{
			get { return this.referralRoleID; }
			set { this.referralRoleID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string ReportEntryName
		{
			get { return this.reportEntryName; }
			set { this.reportEntryName = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ReportReceivedDate
		{
			get { return this.reportReceivedDate; }
			set { this.reportReceivedDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}


	}

	/// <summary>
	/// Strongly typed collection of ReferralReportEntry objects
	/// </summary>
	[ElementType(typeof(ReferralReportEntry))]
	public class ReferralReportEntryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReferralReportEntry elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReferralReportEntryCollection = this;
			else
				elem.ParentReferralReportEntryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ReferralReportEntry elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReferralReportEntry this[int index]
		{
			get
			{
				return (ReferralReportEntry)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReferralReportEntry)oldValue, false);
			SetParentOnElem((ReferralReportEntry)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Referral that contains this collection
		/// </summary>
		public Referral ParentReferral
		{
			get { return this.ParentDataObject as Referral; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Referral */ }
		}

		/// <summary>
		/// Parent ReferralDetail that contains this collection
		/// </summary>
		public ReferralDetail ParentReferralDetail
		{
			get { return this.ParentDataObject as ReferralDetail; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ReferralDetail */ }
		}
	}
}
