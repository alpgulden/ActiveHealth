using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProblemReferral]
	/// </summary>
	[SPAutoGen("usp_LoadAllByReferralId","SelectAllByGivenArgs.sptpl","referralId")]
	[SPAutoGen("usp_CountProblemReferral","CountAllByGivenArgs.sptpl","problemId, referralId")]/// 
	[SPLoad("usp_LoadProblemReferral")]
	[SPInsert("usp_InsertProblemReferral")]
	[SPDelete("usp_DeleteProblemReferral")]
	[TableMapping("ProblemReferral","problemId,referralId",true)]
	public class ProblemReferral : BaseERCProblemLink
	{
		[NonSerialized]
		private BaseERCProblemLinkCollection parentBaseERCProblemLinkCollection;

		[ColumnMapping("ProblemId",StereoType=DataStereoType.FK)]
		private int problemId;
		[ColumnMapping("ReferralId",StereoType=DataStereoType.FK)]
		private int referralId;
	

		#region BaseERCProblemLink abstract methods overridden
		public override int ERCId
		{
			get { return this.referralId; }
			//set { this.cMSId = value; }
		}
		
		public override int ProblemId
		{
			get { return this.problemId; }
			//set { this.problemId = value; }
		}

		public override BaseERCProblemLinkCollection ParentBaseERCProblemLinkCollection
		{
			get
			{
				return this.parentBaseERCProblemLinkCollection;
			}
			set
			{
				this.parentBaseERCProblemLinkCollection = (ProblemReferralCollection)value; // parent is set when added to a collection
			}
		}
		#endregion

		public ProblemReferral(int referralId, int problemid, bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			this.referralId = referralId;
			this.problemId = problemid;
		}


		public ProblemReferral()
		{
		}

		public ProblemReferral(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ReferralId
		{
			get { return this.referralId; }
			set { this.referralId = value; }
		}

//		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
//		public int ProblemId
//		{
//			get { return this.problemId; }
//			set { this.problemId = value; }
//		}

		/// <summary>
		/// Checks the existence of problem-CMS in the db.
		/// </summary>
		public bool ProblemReferralExists()
		{
			return (int)SqlData.SPExecScalar("usp_CountProblemReferral", this.problemId, this.referralId) > 0;
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete()
		{
			base.Delete(this.referralId, this.problemId);		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load()
		{
			return base.Load(this.referralId, this.problemId);
		}
	}

	/// <summary>
	/// Strongly typed collection of ProblemReferral objects
	/// </summary>
	[ElementType(typeof(ProblemReferral))]
	public class ProblemReferralCollection : BaseERCProblemLinkCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ReferralId;
		[NonSerialized]
		private CollectionIndexer indexBy_ProblemId;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProblemReferral elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentBaseERCProblemLinkCollection = this;
			else
				elem.ParentBaseERCProblemLinkCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProblemReferral elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProblemReferral this[int index]
		{
			get
			{
				return (ProblemReferral)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProblemReferral)oldValue, false);
			SetParentOnElem((ProblemReferral)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Hashtable based index on referralId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ReferralId
		{
			get
			{
				if (this.indexBy_ReferralId == null)
					this.indexBy_ReferralId = new CollectionIndexer(this, new string[] { "referralId" }, true);
				return this.indexBy_ReferralId;
			}
		}

		/// <summary>
		/// Hashtable based index on problemId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ProblemId
		{
			get
			{
				if (this.indexBy_ProblemId == null)
					this.indexBy_ProblemId = new CollectionIndexer(this, new string[] { "problemId" }, true);
				return this.indexBy_ProblemId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on referralId fields returns the object.  Uses the IndexBy_ReferralId indexer.
		/// </summary>
		public ProblemReferral FindByReferralID(int referralId)
		{
			return (ProblemReferral)this.IndexBy_ReferralId.GetObject(referralId);
		}

		/// <summary>
		/// Parent Referral that contains this collection
		/// </summary>
		public Referral ParentReferral
		{
			get { return this.ParentDataObject as Referral; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Referral */ }
		}

		/// <summary>
		/// Parent Problem that contains this collection
		/// </summary>
		public Problem ParentProblem
		{
			get { return this.ParentDataObject as Problem; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Problem */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ProblemReferral elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ProblemReferral)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Hashtable based search on problemId fields returns the object.  Uses the IndexBy_ProblemId indexer.
		/// </summary>
		public ProblemReferral FindByProblemId(int problemId)
		{
			return (ProblemReferral)this.IndexBy_ProblemId.GetObject(problemId);
		}

		#region Overrides BaseERCProblemLinkCollection
		public override void DetermineLinkedProblems(ProblemCollection problems)
		{
			this.IndexBy_ProblemId.Rebuild();
			foreach (Problem problem in problems)
			{
				if (FindByProblemId(problem.ProblemID) == null)
					problem.IsERCLinked = false;
				else
				{
					problem.IsERCLinked = true;
					if (this.ParentReferral.PrimaryProblemID == problem.ProblemID)
						problem.IsPrimary = true;
					else
						problem.IsPrimary = false;
				}
			}
		}

		public override void SynchronizeFromProblems(ProblemCollection problems)
		{
			this.IndexBy_ProblemId.Rebuild();
			foreach (Problem problem in problems)
			{ //Update Linkages based on problem 
				ProblemReferral problemReferral = FindByProblemId(problem.ProblemID);
				if (problem.IsERCLinked)
				{
					if (problemReferral == null)
					{	// If no linkage exists - create new one
						// otherwise do nothing
						problemReferral = new ProblemReferral(this.ParentReferral.ReferralID, problem.ProblemID, true);
						this.Add(problemReferral);
					}
				}
				if (!problem.IsERCLinked)
				{	
					if (problemReferral != null) // If linkage exists - delete it, otherwise do nothing
					{	// don't unlik primary problem
						if (this.ParentReferral.PrimaryProblemID != problem.ProblemID)
							problemReferral.MarkDel();
						else
							throw new ActiveAdviceException(AAExceptionAction.None, "Primary problem cannot be unlinked.");
					}
				}
			}// end of foreach
		}

		public override void SetPrimaryProblem(Problem problem)
		{
			this.ParentReferral.PrimaryProblemID = problem.ProblemID;
			problem.IsPrimary = true;
			this.IndexBy_ProblemId.Rebuild();
			if (FindByProblemId(problem.ProblemID) == null)
			{	//Create link if it wasn't there
				ProblemReferral problemReferral = new ProblemReferral(this.ParentReferral.ReferralID, problem.ProblemID, true);
				this.Add(problemReferral);
				this.SaveElements();
			}
			this.ParentReferral.Update();
		}
		#endregion
	}
}
