using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReferralScheduledBy]
	/// </summary>
	[SPAutoGen("usp_GetReferralScheduledByByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllReferralScheduledBy","SelectAll.sptpl","")]
	[SPInsert("usp_InsertReferralScheduledBy")]
	[SPUpdate("usp_UpdateReferralScheduledBy")]
	[SPDelete("usp_DeleteReferralScheduledBy")]
	[SPLoad("usp_LoadReferralScheduledBy")]
	[TableMapping("ReferralScheduledBy","referralScheduledById")]
	public class ReferralScheduledBy : BaseLookupWithNote
	{
		[ColumnMapping("ReferralScheduledById",StereoType=DataStereoType.FK)]
		private int referralScheduledById;
		[ColumnMapping("NotePad")]
		private string notePad;

		[NonSerialized]
		private ReferralScheduledByCollection parentReferralScheduledByCollection;

	
		public ReferralScheduledBy()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		/// <summary>
		/// Parent ReferralScheduledByCollection that contains this element
		/// </summary>
		public ReferralScheduledByCollection ParentReferralScheduledByCollection
		{
			get
			{
				return this.parentReferralScheduledByCollection;
			}
			set
			{
				this.parentReferralScheduledByCollection = value; // parent is set when added to a collection
			}
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ReferralScheduledById
		{
			get { return this.referralScheduledById; }
			set { this.referralScheduledById = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	
	}

	/// <summary>
	/// Strongly typed collection of ReferralScheduledBy objects
	/// </summary>
	[ElementType(typeof(ReferralScheduledBy))]
	public class ReferralScheduledByCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReferralScheduledBy elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReferralScheduledByCollection = this;
			else
				elem.ParentReferralScheduledByCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ReferralScheduledBy elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReferralScheduledBy this[int index]
		{
			get
			{
				return (ReferralScheduledBy)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReferralScheduledBy)oldValue, false);
			SetParentOnElem((ReferralScheduledBy)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetReferralScheduledByByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetReferralScheduledByByActive", maxRecords, this, false, new object [] { active });
		}

		/// <summary>
		/// Accessor to a shared ReferralScheduledByCollection which is cached in NSGlobal
		/// </summary>
		public static ReferralScheduledByCollection ActiveReferralScheduledBy
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ReferralScheduledByCollection col = (ReferralScheduledByCollection)NSGlobal.EnsureCachedObject("ActiveReferralScheduledBy", typeof(ReferralScheduledByCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetReferralScheduledByByActive(-1, true);
				}
				return col;
			}
			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllReferralScheduledBy", -1, this, false);
		}

	}
}
