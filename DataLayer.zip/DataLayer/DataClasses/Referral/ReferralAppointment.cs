using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReferralAppointments]
	/// </summary>	
	[SPInsert("usp_InsertReferralAppointment")]
	[SPUpdate("usp_UpdateReferralAppointment")]
	[SPDelete("usp_DeleteReferralAppointment")]
	[SPLoad("usp_LoadReferralAppointment")]
	[TableMapping("ReferralAppointment","referralAppointmentId")]
	public class ReferralAppointment : BaseData
	{
		[ColumnMapping("ReferralAppointmentId",StereoType=DataStereoType.FK)]
		private int referralAppointmentId;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("AppointmentDate")]
		private DateTime appointmentDate;
		[ColumnMapping("ReferralScheduledByID",StereoType=DataStereoType.FK)]
		private int referralScheduledByID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[NonSerialized]
		private ReferralAppointmentCollection parentReferralAppointmentCollection;
	

		public ReferralAppointment()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ReferralAppointment(bool initNew)
		{
			if (initNew)
			{ // initialize record if requested
				this.NewRecord();
				this.CreateTime = DateTime.Today;
			}
		}

		public ReferralAppointment(int referralDetailID, System.DateTime appointmentDate, int createdBy, System.DateTime createTime)
		{
			this.NewRecord(); // initialize record state
			this.referralDetailID = referralDetailID;
			this.appointmentDate =  appointmentDate;
			this.createdBy = createdBy;
			this.createTime = createTime;
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ReferralAppointmentId
		{
			get { return this.referralAppointmentId; }
			set { this.referralAppointmentId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ValidatorMember("Vld_AppointmentDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime AppointmentDate
		{
			get { return this.appointmentDate; }
			set { this.appointmentDate = value; }
		}

		[FieldValuesMember("LookupOf_ReferralScheduledByID", "ReferralScheduledById", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ReferralScheduledByID
		{
			get { return this.referralScheduledByID; }
			set { this.referralScheduledByID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[GenericScript("Vld_AppointmentDate", "@AppointmentDate@ != null && @AppointmentDate@ >= @CreateTime@;")]
		public string Vld_AppointmentDate
		{
			get
			{
				return "@ERRAPPDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int referralAppointmentId)
		{
			return base.Load(referralAppointmentId);
		}

		/// <summary>
		/// Parent ReferralAppointmentCollection that contains this element
		/// </summary>
		public ReferralAppointmentCollection ParentReferralAppointmentCollection
		{
			get
			{
				return this.parentReferralAppointmentCollection;
			}
			set
			{
				this.parentReferralAppointmentCollection = value; // parent is set when added to a collection
			}
		}


		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}

		public ReferralScheduledByCollection LookupOf_ReferralScheduledByID
		{
			get
			{
				return ReferralScheduledByCollection.ActiveReferralScheduledBy; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of ReferralAppointment objects
	/// </summary>
	[ElementType(typeof(ReferralAppointment))]
	public class ReferralAppointmentCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReferralAppointment elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReferralAppointmentCollection = this;
			else
				elem.ParentReferralAppointmentCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ReferralAppointment elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReferralAppointment this[int index]
		{
			get
			{
				return (ReferralAppointment)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReferralAppointment)oldValue, false);
			SetParentOnElem((ReferralAppointment)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Referral that contains this collection
		/// </summary>
		public Referral ParentReferral
		{
			get { return this.ParentDataObject as Referral; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Referral */ }
		}

		/// <summary>
		/// Parent ReferralDetail that contains this collection
		/// </summary>
		public ReferralDetail ParentReferralDetail
		{
			get { return this.ParentDataObject as ReferralDetail; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ReferralDetail */ }
		}

		public static void ClearAllReferralAppointmentsFromCache()
		{
			NSGlobal.ClearCache(typeof(ReferralAppointmentCollection),false);
		}
	}
}
