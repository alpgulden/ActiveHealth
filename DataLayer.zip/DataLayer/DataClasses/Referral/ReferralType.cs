using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReferralTypes]
	/// </summary>
	
	[SPAutoGen("usp_GetReferralTypeByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllReferralType","SelectAll.sptpl","")]
	[SPInsert("usp_InsertReferralType")]
	[SPUpdate("usp_UpdateReferralType")]
	[SPDelete("usp_DeleteReferralType")]
	[SPLoad("usp_LoadReferralType")]
	[TableMapping("ReferralType","referralTypeId")]
	public class ReferralType : BaseLookupWithNote
	{
		[NonSerialized]
		private ReferralTypeCollection parentReferralTypeCollection;
		[ColumnMapping("ReferralTypeId",StereoType=DataStereoType.FK)]
		private int referralTypeId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ReferralType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ReferralTypeId
		{
			get { return this.referralTypeId; }
			set { this.referralTypeId = value; }
		}
		
		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent ReferralTypeCollection that contains this element
		/// </summary>
		public ReferralTypeCollection ParentReferralTypeCollection
		{
			get
			{
				return this.parentReferralTypeCollection;
			}
			set
			{
				this.parentReferralTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ReferralType objects
	/// </summary>
	[ElementType(typeof(ReferralType))]
	public class ReferralTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		private CollectionIndexer indexBy_ReferralTypeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReferralType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReferralTypeCollection = this;
			else
				elem.ParentReferralTypeCollection = null;
		}

		protected override void OnClear()
		{
			foreach (ReferralType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReferralType this[int index]
		{
			get
			{
				return (ReferralType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReferralType)oldValue, false);
			SetParentOnElem((ReferralType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadReferralTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetReferralTypeByActive", maxRecords, this, false, new object [] { active });
		}

		/// <summary>
		/// Accessor to a shared ReferralTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ReferralTypeCollection ActiveReferralTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ReferralTypeCollection col = (ReferralTypeCollection)NSGlobal.EnsureCachedObject("ActiveReferralTypes", typeof(ReferralTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					//col.GetFacilityFocusTypesByActive(-1, true);
					col.LoadReferralTypesByActive(-1, true);
				}
				return col;
			}			
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}


		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ReferralTypeID
		{
			get
			{
				if (this.indexBy_ReferralTypeID == null)
					this.indexBy_ReferralTypeID = new CollectionIndexer(this, new string[] { "ReferralTypeId" }, true);
				return this.indexBy_ReferralTypeID;
			}
			
		}		
		
		/// <summary>
		/// Looks up by referralTypeID and returns Description value.  Uses the IndexBy_ReferralTypeID indexer.
		/// </summary>
		public string Lookup_ReferralTypeIdByReferralTypeID(int referralTypeID)
		{
			return this.IndexBy_ReferralTypeID.LookupStringMember("Description", referralTypeID);
		}

		/// <summary>
		/// Looks up by code and returns ReferralTypeId value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_ReferralTypeIdByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("ReferralTypeId", code);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllReferralType", -1, this, false);
		}
	}
}
