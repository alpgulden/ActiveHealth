using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReferralUrgency]
	/// </summary>
	[SPInsert("usp_InsertReferralUrgency")]
	[SPUpdate("usp_UpdateReferralUrgency")]
	[SPDelete("usp_DeleteReferralUrgency")]
	[SPLoad("usp_LoadReferralUrgency")]
	[SPAutoGen("usp_GetReferralUrgencyByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllReferralUrgency","SelectAll.sptpl","")]
	[TableMapping("ReferralUrgency","referralUrgencyID")]
	public class ReferralUrgency : BaseLookupWithNote
	{
		[ColumnMapping("ReferralUrgencyID")]
		private int referralUrgencyID;
		[ColumnMapping("NotePad")]
		private string notePad;

		[NonSerialized]
		private ReferralUrgencyCollection parentReferralUrgencyCollection;

		public ReferralUrgency()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		/// <summary>
		/// Parent ReferralUrgencyCollection that contains this element
		/// </summary>
		public ReferralUrgencyCollection ParentReferralUrgencyCollection
		{
			get
			{
				return this.parentReferralUrgencyCollection;
			}
			set
			{
				this.parentReferralUrgencyCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ReferralUrgencyID
		{
			get { return this.referralUrgencyID; }
			set { this.referralUrgencyID = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of ReferralUrgency objects
	/// </summary>
	[ElementType(typeof(ReferralUrgency))]
	public class ReferralUrgencyCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReferralUrgency elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReferralUrgencyCollection = this;
			else
				elem.ParentReferralUrgencyCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ReferralUrgency elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReferralUrgency this[int index]
		{
			get
			{
				return (ReferralUrgency)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReferralUrgency)oldValue, false);
			SetParentOnElem((ReferralUrgency)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadReferralUrgencyByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetReferralUrgencyByActive", maxRecords, this, false, new object [] { active });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllReferralUrgency(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetReferralUrgencyByActive", maxRecords, this, false,  new object [] { active });
		}

		/// <summary>
		/// Accessor to a shared ReferralUrgencyCollection which is cached in NSGlobal
		/// </summary>
		public static ReferralUrgencyCollection ActiveReferralUrgency
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ReferralUrgencyCollection col = (ReferralUrgencyCollection)NSGlobal.EnsureCachedObject("ReferralUrgency", typeof(ReferralUrgencyCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllReferralUrgency(-1,true);
				}
				return col;
			}			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllReferralUrgency", -1, this, false);
		}
	}
}
