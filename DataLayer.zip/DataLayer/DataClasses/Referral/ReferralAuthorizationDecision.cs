using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReferralAuthorizationDecisions]
	/// </summary>
	[SPAutoGen("usp_GetReferralAuthorizationDecisionByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllReferralAuthorizationDecision","SelectAll.sptpl","")]
	[SPInsert("usp_InsertReferralAuthorizationDecision")]
	[SPUpdate("usp_UpdateReferralAuthorizationDecision")]
	[SPDelete("usp_DeleteReferralAuthorizationDecision")]
	[SPLoad("usp_LoadReferralAuthorizationDecision")]
	[TableMapping("ReferralAuthorizationDecision","referralAuthorizationDecisionID")]
	public class ReferralAuthorizationDecision : BaseLookupWithSubCode
	{
		[ColumnMapping("ReferralAuthorizationDecisionID")]
		private int referralAuthorizationDecisionID;
		[ColumnMapping("ClinicalReviewDecisionTypeCodeID")]
		private int clinicalReviewDecisionTypeCodeID;
		[ColumnMapping("NotePad")]
		private string notePad;
		
		[NonSerialized]
		private ReferralAuthorizationDecisionCollection parentReferralAuthorizationDecisionCollection;
	
	
		public ReferralAuthorizationDecision()
		{
			//
			// TODO: Add constructor logic here
			//
		}	
		
		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
		
		[FieldValuesMember("LookupOf_SubCodeID", "ClinicalReviewDecisionTypeCodeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CLINICALREVIEWDECISIONTYPE@")]
		public override int SubCodeID
		{
			get { return this.clinicalReviewDecisionTypeCodeID; }
			set { this.clinicalReviewDecisionTypeCodeID = value; }
		}

		/// <summary>
		/// Parent ReferralAuthorizationDecisionCollection that contains this element
		/// </summary>
		public ReferralAuthorizationDecisionCollection ParentReferralAuthorizationDecisionCollection
		{
			get
			{
				return this.parentReferralAuthorizationDecisionCollection;
			}
			set
			{
				this.parentReferralAuthorizationDecisionCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ReferralAuthorizationDecisionID
		{
			get { return this.referralAuthorizationDecisionID; }
			set { this.referralAuthorizationDecisionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ClinicalReviewDecisionTypeCodeID
		{
			get { return this.clinicalReviewDecisionTypeCodeID; }
			set { this.clinicalReviewDecisionTypeCodeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		public ClinicalReviewDecisionTypeCodeCollection LookupOf_SubCodeID
		{
			get
			{
				return ClinicalReviewDecisionTypeCodeCollection.ActiveClinicalReviewDecisionTypeCodes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ReferralAuthorizationDecision objects
	/// </summary>
	[ElementType(typeof(ReferralAuthorizationDecision))]
	public class ReferralAuthorizationDecisionCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ReferralAuthorizationDecisionID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReferralAuthorizationDecision elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReferralAuthorizationDecisionCollection = this;
			else
				elem.ParentReferralAuthorizationDecisionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ReferralAuthorizationDecision elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReferralAuthorizationDecision this[int index]
		{
			get
			{
				return (ReferralAuthorizationDecision)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReferralAuthorizationDecision)oldValue, false);
			SetParentOnElem((ReferralAuthorizationDecision)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadReferralAuthorizationDecisionByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetReferralAuthorizationDecisionByActive", maxRecords, this, false,  new object [] { active });
		}

		/// <summary>
		/// Accessor to a shared ReferralAuthorizationDecisionCollection which is cached in NSGlobal
		/// </summary>
		public static ReferralAuthorizationDecisionCollection ActiveReferralAuthorizationDecisions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ReferralAuthorizationDecisionCollection col = (ReferralAuthorizationDecisionCollection)NSGlobal.EnsureCachedObject("ReferralAuthorizationDecisions", typeof(ReferralAuthorizationDecisionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadReferralAuthorizationDecisionByActive(-1,true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on referralAuthorizationDecisionID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ReferralAuthorizationDecisionID
		{
			get
			{
				if (this.indexBy_ReferralAuthorizationDecisionID == null)
					this.indexBy_ReferralAuthorizationDecisionID = new CollectionIndexer(this, new string[] { "referralAuthorizationDecisionID" }, true);
				return this.indexBy_ReferralAuthorizationDecisionID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on referralAuthorizationDecisionID fields returns the object.  Uses the IndexBy_ReferralAuthorizationDecisionID indexer.
		/// </summary>
		public ReferralAuthorizationDecision FindBy(int referralAuthorizationDecisionID)
		{
			return (ReferralAuthorizationDecision)this.IndexBy_ReferralAuthorizationDecisionID.GetObject(referralAuthorizationDecisionID);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllReferralAuthorizationDecision", -1, this, false);
		}
	}
}
