using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Referrals]
	/// </summary>
	/// 

	[SPAutoGen("usp_SearchReferralsByAltReferralID","SelectAllByGivenArgsOrderBy.sptpl","alternateReferralID, ASC, alternateReferralID")]
	[SPAutoGen("usp_GetLinkedPatientReferrals","SelectAllByGivenArgs.sptpl","patientId", InjectOrderBy="ORDER BY [Referral].[ReferralID] DESC")]		// we can now select directly by the patientId on Event
	[SPAutoGen("usp_GetReferralsByProblemId","SelectAllByGivenArgs.sptpl","primaryProblemID")]
	[SPAutoGen("usp_GetPossibleDuplicateReferrals","-SelectAllByGivenArgs.sptpl",		
		 "patientId, referralTypeID, pCPID, referredFromProviderID, referredToType, referredToID, referralStartDate",
		 InjectWhere="AND [Referral].[ReferralID] != @referralID  -- except the given event", InjectParameters="@referralID int", 
		 ManuallyManaged=true)]
	[SPAutoGen("usp_UpdateReferralLastValidationDate","UpdateGivenColsByPK.sptpl","lastValidationDate")]
	[SPExists("usp_ExistsReferral", ManuallyManaged=true)]
	[SPInsert("usp_InsertReferral")]
	[SPUpdate("usp_UpdateReferral")]
	[SPDelete("usp_DeleteReferral")]
	[SPLoad("usp_LoadReferral")]
	[TableMapping("Referral","referralID")]
	public class Referral : BaseForEventCMSReferral
	{
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		private int referralID;
		[ColumnMapping("AlternateReferralID")]
		private string alternateReferralID;
		[ColumnMapping("ReferralStartDate")]
		private DateTime referralStartDate;
		[ColumnMapping("ReferralDescription")]
		private string referralDescription;
		[ColumnMapping("ReferralTypeID",StereoType=DataStereoType.FK)]
		private int referralTypeID;
		[ColumnMapping("PCPSpecialtyID",StereoType=DataStereoType.FK)]
		private int pCPSpecialtyID;
		[ColumnMapping("PCPLocationID",StereoType=DataStereoType.FK)]
		private int pCPLocationID;
		[ColumnMapping("ReferredFromSpecialtyID",StereoType=DataStereoType.FK)]
		private int referredFromSpecialtyID;
		[ColumnMapping("ReferredFromLocationID",StereoType=DataStereoType.FK)]
		private int referredFromLocationID;
		[ColumnMapping("ReferredToSpecialtyID",StereoType=DataStereoType.FK)]
		private int referredToSpecialtyID;
		[ColumnMapping("ReferredToLocationID",StereoType=DataStereoType.FK)]
		private int referredToLocationID;
		[ColumnMapping("OtherPlanDescription")]
		private string otherPlanDescription;
		[ColumnMapping("PrimaryProblemID",StereoType=DataStereoType.FK)]
		private int primaryProblemID;
		[ColumnMapping("PCPID",StereoType=DataStereoType.FK)]
		private int pCPID;
		[ColumnMapping("PCPNetworkID",StereoType=DataStereoType.FK)]
		private int pCPNetworkID;
		[ColumnMapping("PCPNetworkStatus", ValueForNull=(int)-1)]
		private int pCPNetworkStatus = -1;
		[ColumnMapping("ReferredFromProviderID",StereoType=DataStereoType.FK)]
		private int referredFromProviderID;
		[ColumnMapping("ReferredFromNetworkID",StereoType=DataStereoType.FK)]
		private int referredFromNetworkID;
		[ColumnMapping("ReferredFromNetworkStatus", ValueForNull=(int)-1)]
		private int referredFromNetworkStatus = -1;
		[ColumnMapping("ReferredToID",StereoType=DataStereoType.FK)]
		private int referredToID;
		[ColumnMapping("ReferredToType",StereoType=DataStereoType.FK)]
		private int referredToType;
		[ColumnMapping("ReferredToNetworkID",StereoType=DataStereoType.FK)]
		private int referredToNetworkID;
		[ColumnMapping("ReferredToNetworkStatus", ValueForNull=(int)-1)]
		private int referredToNetworkStatus = -1;
		[ColumnMapping("PlanSorgLogID",StereoType=DataStereoType.FK)]
		private int planSorgLogID;
		[ColumnMapping("PatientSubscriberLogID",StereoType=DataStereoType.FK)]
		private int patientSubscriberLogID;
		[ColumnMapping("AdmittingDxType")]
		private string admittingDxType;
		[ColumnMapping("AdmittingDxCode")]
		private string admittingDxCode;
		[ColumnMapping("DRG_Type")]
		private string drgType;
		[ColumnMapping("DRG_Code")]
		private string drgCode;
		[ColumnMapping("DRG_Version")]
		private string drgVersion;
		[ColumnMapping("DSM4_AXIS5_Current",StereoType=DataStereoType.FK)]
		private int dsm4Axis5Current;
		[ColumnMapping("DSM4_AXIS5_Best",StereoType=DataStereoType.FK)]
		private int dsm4Axis5Best;
		[ColumnMapping("DSM4_AXIS5_Start",StereoType=DataStereoType.FK)]
		private int dsm4Axis5Start;
		[ColumnMapping("AssignedToUser",StereoType=DataStereoType.FK)]
		private int assignedToUser;
		[ColumnMapping("AssignedToTeam",StereoType=DataStereoType.FK)]
		private int assignedToTeam;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		private int patientId;
		[ColumnMapping("LastValidationDate")]
		private DateTime lastValidationDate;
		[NonSerialized]
		private ReferralCollection parentReferralCollection;


		private string pCPFullName;
		private string pCPFullLocation;
		private string pCPPhone;
		private string pCPFax;
		private string pCPPager;
		private string pCPSpecialtyDescription;

		private string referredFromPCPFullName;
		private string referredFromPCPFullLocation;
		private string referredFromPCPPhone;
		private string referredFromPCPFax;
		private string referredFromPCPPager;
		private string referredFromPCPSpecialtyDescription;

		private string referredToPCPFullName;
		private string referredToPCPFullLocation;
		private string referredToPCPPhone;
		private string referredToPCPFax;
		private string referredToPCPPager;
		private string referredToPCPSpecialtyDescription;

		private ReferralDetailCollection referralDetails;

		private bool isLinkedToProblem;

		private Plan plan;
		//private Patient patient;
		private OutcomeCollection outcomes;
		private ProblemCollection problems;
		private ImageLinkCollection images;

		private PatientSubscriberLog patSubLog;
		private PlanSORGLog planSorgLog;	// cached plansorg log object which
		private ProblemReferralCollection problemsReferral;
		private ReferralDetail lastDetail;

		private EventReferralDiagnoseCollection referralDiagnoses;
		private EventReferralProcedureCollection referralProcedures;
		
		private DateTime startDateWhenLoaded;		// keeps track of the changes in startDate
		
		private int referralTypeIDWhenLoaded;
		private int pCPIDWhenLoaded;
		private int referredFromProviderIDWhenLoaded;
		private int referredToTypeWhenLoaded;
		private int referredToIDWhenLoaded;

		#region BaseForEventCMSReferral abstract methods overridden

		#region Display ERC Properties Overriden
		/// <summary>
		/// Alwas returns EnumERCType.Event.  This class represents an Event.
		/// </summary>
		public override EnumERCType ERCType
		{
			get { return EnumERCType.Referral; }
		}

		/// <summary>
		/// Alwas returns EnumERCType.Event.  This class represents an Event.
		/// </summary>
		public override string ERCTypeDisplay
		{
			get { return "@REFERRAL@"; }
		}

		public override string TypeDisplay
		{
			get { return ReferralTypeCollection.ActiveReferralTypes.Lookup_ReferralTypeIdByReferralTypeID(this.referralTypeID);}
		}

		public override bool IsLinkedToProblem
		{
			get { return this.isLinkedToProblem; }
			set { this.isLinkedToProblem = value; }		// set after loading
		}

		public override string ERCDescription
		{
			get { return this.referralDescription; }
		}

		public override DateTime ERCServiceDate
		{
			get { return this.referralStartDate; }
		}

		public override DateTime ERCStartDate
		{
			get { return this.referralStartDate; } // this.startDate; }
		}

		public override DateTime ERCEndDate
		{
			get { return this.referralStartDate; } // this.endDate; }
		}

		public override string ERCStatusDisplay
		{
			get { return "";} //return SystemStatusCollection.ActiveSystemStatuses.Lookup_DescriptionByStatusId(this.referralDetails[0].ReferralStatusID); } // return SystemStatusCollection.ActiveSystemStatuses.Lookup_DescriptionByStatusId(this.statusID); }
		}

		// Change this implementation.  By the time, we don't know where to get Status ID from.
		public override int ERCStatusID
		{
			get 
			{ 
				if (this.LastDetail == null)
					return 0;
				else
					return this.LastDetail.ReferralStatusID; 
			}
			set { } //this.StatusID = value; }
		}

		public override bool ERCPhysicianReview
		{
			get { return false; } // this.physicianReview; }
		}

		public override DateTime ERCLastValidationDate
		{
			get { return this.lastValidationDate; }
			set { this.lastValidationDate = value; }
		}

		public override void UpdateLastValidationDate()
		{
			UpdateReferralLastValidationDate(this.lastValidationDate);
		}

		#endregion

		/// <summary>
		/// Updates the last coverage validation date of this CMS
		/// and also sets the instance member lastValidationDate to the given date.
		/// </summary>
		public void UpdateReferralLastValidationDate(System.DateTime lastValidationDate)
		{
			SqlData.SPExecNonQuery("usp_UpdateReferralLastValidationDate", 
				new object[] { this.referralID, SQLDataDirect.MakeDBValue(lastValidationDate) });
			this.lastValidationDate = lastValidationDate;
		}

		#region ProblemLinks Overriden
		/// <summary>
		/// Child CMSProblems mapped to related rows of table CMSProblem where [CMSID] = [CMSId]
		/// </summary>
		[SPLoadChild("usp_LoadAllProblemLinksByReferralId", "ReferralId", ManuallyManaged=true)]
		public override BaseERCProblemLinkCollection ERCProblemLinks
		{
			get { return this.problemsReferral; }
			set
			{
				this.problemsReferral = (ProblemReferralCollection)value;
				if (value != null)
					value.ParentBaseForEventCMSReferral = this; // set this as a parent of the child collection
			}
		}
		
		/// <summary>
		/// Loads the ProblemsReferral collection
		/// </summary>
		public override void LoadERCProblemLinks(bool forceReload)

		{
			this.problemsReferral = (ProblemReferralCollection)ProblemReferralCollection.LoadChildCollection("ERCProblemLinks", this, typeof(ProblemReferralCollection), problemsReferral, forceReload, null);
		}

		/// <summary>
		/// Saves the CMSProblems collection
		/// </summary>
		public override void SaveERCProblemLinks()
		{
			ProblemReferralCollection.SaveChildCollection(((ProblemReferralCollection)this.problemsReferral), false);
		}
		#endregion

		#region Outcomes Overriden
		/// <summary>
		/// Child Outcomes mapped to related rows of table Outcome where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadReferralOutcome", "referralID")]
		public override OutcomeCollection Outcomes
		{
			get { return this.outcomes; }
			set
			{
				this.outcomes = value;
				if (value != null)
					value.ParentReferral = this; // set this as a parent of the child collection
			}
		}
				
		/// <summary>
		/// Loads the Outcomes collection
		/// </summary>
		public override void LoadOutcomes(bool forceReload)
		{
			this.outcomes = (OutcomeCollection)OutcomeCollection.LoadChildCollection("Outcomes", this, typeof(OutcomeCollection), outcomes, forceReload, null);
		}

		/// <summary>
		/// Saves the Outcomes collection
		/// </summary>
		public override void SaveOutcomes()
		{
			OutcomeCollection.SaveChildCollection(this.outcomes, true);
		}

		/// <summary>
		/// Synchronizes the Outcomes collection
		/// </summary>
		public void SynchronizeOutcomes()
		{
			OutcomeCollection.SynchronizeChildCollection(this.outcomes, true);
		}

		#endregion	

		#region Images Overriden
		/// <summary>
		/// Child Outcomes mapped to related rows of table Outcome where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadReferralImages", "ReferralID")]
		public override ImageLinkCollection Images
		{
			get { return this.images; }
			set
			{
				this.images = value;
				if (value != null)
					value.ParentReferral = this; // set this as a parent of the child collection
			}
		}
		
		/// <summary>
		/// Loads the Outcomes collection
		/// </summary>
		public override void LoadImages(bool forceReload)
		{
			this.images = (ImageLinkCollection)ImageLinkCollection.LoadChildCollection("Images", this, typeof(ImageLinkCollection), images, forceReload, null);
		}

		/// <summary>
		/// Saves the Outcomes collection
		/// </summary>
		public override void SaveImages()
		{
			ImageLinkCollection.SaveChildCollection(this.images, true);
		}

		/// <summary>
		/// Synchronizes the Outcomes collection
		/// </summary>
		public void SynchronizeImages()
		{
			ImageLinkCollection.SynchronizeChildCollection(this.images, true);
		}

		#endregion


		#endregion

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int referralId)
		{
			return base.Load(referralId);
		}

		public override bool LoadERC(int ercID)
		{
			return Load(ercID);
		}

		[FieldValuesMember("ValuesOf_ReferralID")]
		[ControlType(Macro=EnumControlTypeMacros.Int,ValueForNull=(int)0)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string ReferralDescription
		{
			get { return this.referralDescription; }
			set { this.referralDescription = value; }
		}

		[FieldValuesMember("LookupOf_ReferralTypeID", "ReferralTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int ReferralTypeID
		{
			get { return this.referralTypeID; }
			set { this.referralTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PCPSpecialtyID
		{
			get { return this.pCPSpecialtyID; }
			set { this.pCPSpecialtyID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PCPLocationID
		{
			get { return this.pCPLocationID; }
			set { this.pCPLocationID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string OtherPlanDescription
		{
			get { return this.otherPlanDescription; }
			set { this.otherPlanDescription = value; }
		}

		public override string AdminOtherPlan
		{
			get
			{
				return this.OtherPlanDescription;
			}
			set
			{
				this.OtherPlanDescription = value;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public override int PrimaryProblemID
		{
			get { return this.primaryProblemID; }
			set { this.primaryProblemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PCPID
		{
			get { return this.pCPID; }
			set { this.pCPID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PCPNetworkID
		{
			get { return this.pCPNetworkID; }
			set { this.pCPNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int PCPNetworkStatus
		{
			get { return this.pCPNetworkStatus; }
			set { this.pCPNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public override int PlanSORGLogID
		{
			get { return this.planSorgLogID; }
			set { this.planSorgLogID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public override int PatientSubscriberLogID
		{
			get { return this.patientSubscriberLogID; }
			set 
			{ 
				this.patientSubscriberLogID = value; 
				this.patSubLog = null;
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string AdmittingDxType
		{
			get { return this.admittingDxType; }
			set { this.admittingDxType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string AdmittingDxCode
		{
			get { return this.admittingDxCode; }
			set { this.admittingDxCode = value; }
		}

		/// <summary>
		/// Returns a user-friendly display string for the admitting diagnostic code type and value.
		/// </summary>
		[ControlType(EnumControlTypes.TextBox)]
		public string AdmittingDiagCodeDisplay
		{
			get 
			{
				return DiagnosticSelectionData.FormatDxPxCodeDisplay(admittingDxType, admittingDxCode,  BaseDxPx.DxPxDiagnostic);
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public override string DrgType
		{
			get { return this.drgType; }
			set { this.drgType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public override string DrgCode
		{
			get { return this.drgCode; }
			set { this.drgCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public override string DrgVersion
		{
			get { return this.drgVersion; }
			set { this.drgVersion = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Dsm4Axis5Current
		{
			get { return this.dsm4Axis5Current; }
			set { this.dsm4Axis5Current = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Dsm4Axis5Best
		{
			get { return this.dsm4Axis5Best; }
			set { this.dsm4Axis5Best = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Dsm4Axis5Start
		{
			get { return this.dsm4Axis5Start; }
			set { this.dsm4Axis5Start = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedToUser
		{
			get { return this.assignedToUser; }
			set { this.assignedToUser = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedToTeam
		{
			get { return this.assignedToTeam; }
			set { this.assignedToTeam = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime ReferralStartDate
		{
			get { return this.referralStartDate; }
			set { this.referralStartDate = value; }
		}

		/// <summary>
		/// Returns the loaded and cached patient subscriber log entry
		/// </summary>
		public override PatientSubscriberLog PatientSubscriberLog
		{
			get
			{
				if (this.patSubLog == null)
					this.patSubLog = GetPatientSubscriberLog();
				return this.patSubLog;
			}
		}

		/// <summary>
		/// Returns the SORG of the patient subscriber log entry
		/// </summary>
		public override Organization SORG
		{
			get 
			{ 
				PatientSubscriberLog patSubLog = this.PatientSubscriberLog;
				if (patSubLog == null)
					return null;
				return patSubLog.SORG;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]


		/// <summary>
		/// contains the Provider LastName FirsName , Suffix 
		/// </summary>
		[FieldDescription("@PROVIDER@")]
		public string PCPFullName
		{
			get { return this.pCPFullName; }
			set { this.pCPFullName = value; }
		}

		/// <summary>
		/// contains the Provider Address Line (1,2,3) , City State Zip
		/// </summary>
		[FieldDescription("@LOCATION@")]
		public string PCPFullLocation
		{
			get { return this.pCPFullLocation; }
			set { this.pCPFullLocation = value; }
		}

		/// <summary>
		/// contains the Provider Phone property
		/// </summary>
		[FieldDescription("@PHONE@")]
		public string PCPPhone
		{
			get { return this.pCPPhone; }
			set { this.pCPPhone = value; }
		}

		/// <summary>
		/// contains the Provider Fax property
		/// </summary>
		[FieldDescription("@FAX@")]
		public string PCPFax
		{
			get { return this.pCPFax; }
			set { this.pCPFax = value; }
		}

		/// <summary>
		/// contains the Provider Pager property
		/// </summary>
		[FieldDescription("@PAGER@")]
		public string PCPPager
		{
			get { return this.pCPPager; }
			set { this.pCPPager = value; }
		}

		/// <summary>
		/// contains the Provider speciality description
		/// </summary>
		[FieldDescription("@SPECIALTY@")]
		public string PCPSpecialtyDescription
		{
			get { return this.pCPSpecialtyDescription; }
			set { this.pCPSpecialtyDescription = value; }
		}

		/// <summary>
		/// contains the Provider LastName FirsName , Suffix 
		/// </summary>
		[FieldDescription("@REFERREDFROM@")]
		public string ReferredFromPCPFullName
		{
			get { return this.referredFromPCPFullName; }
			set { this.referredFromPCPFullName = value; }
		}

		/// <summary>
		/// contains the Provider Address Line (1,2,3) , City State Zip
		/// </summary>
		[FieldDescription("@LOCATION@")]
		public string ReferredFromPCPFullLocation
		{
			get { return this.referredFromPCPFullLocation; }
			set { this.referredFromPCPFullLocation = value; }
		}

		/// <summary>
		/// contains the Provider Phone property
		/// </summary>
		[FieldDescription("@PHONE@")]
		public string ReferredFromPCPPhone
		{
			get { return this.referredFromPCPPhone; }
			set { this.referredFromPCPPhone = value; }
		}

		/// <summary>
		/// contains the Provider Fax property
		/// </summary>
		[FieldDescription("@FAX@")]
		public string ReferredFromPCPFax
		{
			get { return this.referredFromPCPFax; }
			set { this.referredFromPCPFax = value; }
		}

		/// <summary>
		/// contains the Provider Pager property
		/// </summary>
		[FieldDescription("@PAGER@")]
		public string ReferredFromPCPPager
		{
			get { return this.referredFromPCPPager; }
			set { this.referredFromPCPPager = value; }
		}

		/// <summary>
		/// contains the Provider speciality description
		/// </summary>
		[FieldDescription("@SPECIALTY@")]
		public string ReferredFromPCPSpecialtyDescription
		{
			get { return this.referredFromPCPSpecialtyDescription; }
			set { this.referredFromPCPSpecialtyDescription = value; }
		}

		/// <summary>
		/// contains the Provider LastName FirsName , Suffix 
		/// </summary>
		[FieldDescription("@REFERREDTO@")]
		public string ReferredToPCPFullName
		{
			get { return this.referredToPCPFullName; }
			set { this.referredToPCPFullName = value; }
		}

		/// <summary>
		/// contains the Provider Address Line (1,2,3) , City State Zip
		/// </summary>
		[FieldDescription("@LOCATION@")]
		public string ReferredToPCPFullLocation
		{
			get { return this.referredToPCPFullLocation; }
			set { this.referredToPCPFullLocation = value; }
		}

		/// <summary>
		/// contains the Provider Phone property
		/// </summary>
		[FieldDescription("@PHONE@")]
		public string ReferredToPCPPhone
		{
			get { return this.referredToPCPPhone; }
			set { this.referredToPCPPhone = value; }
		}

		/// <summary>
		/// contains the Provider Fax property
		/// </summary>
		[FieldDescription("@FAX@")]
		public string ReferredToPCPFax
		{
			get { return this.referredToPCPFax; }
			set { this.referredToPCPFax = value; }
		}

		/// <summary>
		/// contains the Provider Pager property
		/// </summary>
		[FieldDescription("@PAGER@")]
		public string ReferredToPCPPager
		{
			get { return this.referredToPCPPager; }
			set { this.referredToPCPPager = value; }
		}

		/// <summary>
		/// contains the Provider speciality description
		/// </summary>
		[FieldDescription("@SPECIALTY@")]
		public string ReferredToPCPSpecialtyDescription
		{
			get { return this.referredToPCPSpecialtyDescription; }
			set { this.referredToPCPSpecialtyDescription = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@REFERFROMNETWORKID@")]
		public int ReferredFromNetworkID
		{
			get { return this.referredFromNetworkID; }
			set { this.referredFromNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int ReferredFromNetworkStatus
		{
			get { return this.referredFromNetworkStatus; }
			set { this.referredFromNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferredToType
		{
			get { return this.referredToType; }
			set { this.referredToType = value; }
		}

		public int ReferredToOption
		{
			get { return this.referredToType>0?this.referredToType-1:1;}			
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int UserDefinedID
		{
			get { return this.userDefinedID; }
			set { this.userDefinedID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public override int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferredFromSpecialtyID
		{
			get { return this.referredFromSpecialtyID; }
			set { this.referredFromSpecialtyID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferredFromLocationID
		{
			get { return this.referredFromLocationID; }
			set { this.referredFromLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferredToSpecialtyID
		{
			get { return this.referredToSpecialtyID; }
			set { this.referredToSpecialtyID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferredToLocationID
		{
			get { return this.referredToLocationID; }
			set { this.referredToLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferredFromProviderID
		{
			get { return this.referredFromProviderID; }
			set { this.referredFromProviderID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferredToID
		{
			get { return this.referredToID; }
			set { this.referredToID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferredToNetworkID
		{
			get { return this.referredToNetworkID; }
			set { this.referredToNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int ReferredToNetworkStatus
		{
			get { return this.referredToNetworkStatus; }
			set { this.referredToNetworkStatus = value; }
		}

		/// <summary>
		/// Constractors
		/// </summary>		
		public Referral()
		{
		}

		public Referral(int referralTypeID)
		{
			this.NewRecord(); // initialize record state
			//this.referralTypeID = referralTypeID;
			
		}

		public Referral(int referralTypeID,int primaryProblemID)
		{
			Referral referal = new Referral(referralTypeID);
			this.primaryProblemID = primaryProblemID;
		}

		public Referral(int referralTypeID,int primaryProblemID,int pCPId)
		{
			Referral referal = new Referral(referralTypeID,primaryProblemID);
		}		

		public Referral(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();					
				// This was an old aproach to get provider 03/23/05..
				//this.PCPID=4;   // in order to test provider
				//FillProviderInfo(); // to get provider summary
		}

		/// <summary>
		/// Link to or unlink from the given problem.
		/// If linkUnlink = true, link problem to this ERC.
		/// If linkUnlink = false, unklink problem from this ERC.
		/// Called by PatientSummary when Problem is linked.
		/// </summary>
		/// <param name="problem"></param>
		/// <param name="linkUnlink"></param>
		public override void LinkToProblem(Problem problem, bool linkUnlink)
		{
			if (this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "New referral cannot be linked or unlinked!");
			if (problem.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "New problem cannot be linked or unlinked!");

			if (problem.ProblemID == this.primaryProblemID)
				if (!linkUnlink)
					throw new ActiveAdviceException(AAExceptionAction.None, "@CANTUNLINKPRIMARYPROBLEM@");

			// Ensure problem-referral link
			ProblemReferral problemReferral = new ProblemReferral(this.referralID, problem.ProblemID, true);
			if (problemReferral.ProblemReferralExists())		// linked
			{
				if (!linkUnlink)	// if unlink is requested
				{					// delete
					//problemReferral.MarkDel();
					problemReferral.Delete();
				}
			}
			else		// not linked
			{
				if (linkUnlink)		// if link is requrested
					problemReferral.Insert();		// create the link
			}
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public void Save(PatientCoverage patCov, Problem problem)
		{
			this.autoActivityManager = null;

			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			if (!this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Referral.Save(problem) can be called only for a new Referral");
			
			if (this.Patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "A new Referral can be saved only in the context of a patient");

			if (patCov == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "A new Referral can be saved only in the context of a patient-subscriber-coverage");
			
			if (problem == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "The problem passed to the Referral.Save(problem) was null");
			
			if (problem.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "The problem passed to the Referral.Save(problem) is new.  It must exist in the db!");

			this.SqlData.EnsureTransaction();
			try
			{
				PlanSORGLog lastPlanSORGLog = PlanSORGLog.GetLastPlanSORGLogEntry(this.SqlData.Transaction, patCov.Plan, patCov.SORG);
				if (lastPlanSORGLog == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI,
						"No plan-sorg-log entry found for PlanID={0}, SORGID={1}", patCov.PlanID, patCov.SORGID);
				this.planSorgLogID = lastPlanSORGLog.PlanSorgLogId;

				
				PatientSubscriberLog lastPatSubLog = PatientSubscriberLog.GetLastPatientSubscriberLogEntry(this.SqlData.Transaction, patient, patCov);
				if (lastPatSubLog == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI,
						"No patient-subscriber-log entry found for PatientID={0}, PatientCoverageID={1}", patient.PatientId, patCov.PatientCoverageID);
				this.patientSubscriberLogID = lastPatSubLog.PatientSubscriberLogId;

				base.Save();

				// Create the Problem - CMS link
				this.primaryProblemID = problem.ProblemID;

				ProblemReferral problemReferral = new ProblemReferral(this.referralID, this.primaryProblemID, true);
				problemReferral.SqlData.Transaction = this.SqlData.Transaction;
				problemReferral.Insert();

				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			this.autoActivityManager = null;

			if (this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must save a new Referral only in the context of a plan-sorg-log entry or a patient-subscriber-log entry");

			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI,
					"You must save an existing Referral only in the context of a patient");

			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();

				if (this.primaryProblemID != 0)
				{
					// Ensure problem-referral link
					ProblemReferral problemReferral = new ProblemReferral(this.referralID, this.primaryProblemID, true);
					if (!problemReferral.ProblemReferralExists())
					{
						problemReferral.SqlData.Transaction = this.SqlData.Transaction;
						problemReferral.Insert();
					}
				}

				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}	
		}

		public AutoActivityManager EnsureAutoActivityManager()
		{
			if (this.autoActivityManager == null)
			{
				if (this.PatientSubscriberLog != null)
					autoActivityManager = new AutoActivityManager(this.Patient, this.PatientSubscriberLog.PatientCoverage, this.GetPrimaryProblem(), this);
			}
			return this.autoActivityManager;
		}

		/// <summary>
		/// Parent ReferralCollection that contains this element
		/// </summary>
		public ReferralCollection ParentReferralCollection
		{
			get
			{
				return this.parentReferralCollection;
			}
			set
			{
				this.parentReferralCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child ReferralDetails mapped to related rows of table ReferralDetails where [ReferralID] = [ReferralID]
		/// </summary>
		[SPLoadChild("usp_LoadReferralDetails", "referralID")]
		public ReferralDetailCollection ReferralDetails
		{
			get { return this.referralDetails; }
			set
			{
				this.referralDetails = value;
				if (value != null)
					value.ParentReferral = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ReferralDetails collection
		/// </summary>
		public void LoadReferralDetails(bool forceReload)
		{
			this.referralDetails = (ReferralDetailCollection)ReferralDetailCollection.LoadChildCollection("ReferralDetails", this, typeof(ReferralDetailCollection), referralDetails, forceReload, null);
		}

		/// <summary>
		/// Saves the ReferralDetails collection
		/// </summary>
		public void SaveReferralDetails()
		{
			ReferralDetailCollection.SaveChildCollection(this.referralDetails, true);
		}

		/// <summary>
		/// Synchronizes the ReferralDetails collection
		/// </summary>
		public void SynchronizeReferralDetails()
		{
			ReferralDetailCollection.SynchronizeChildCollection(this.referralDetails, true);
		}

		/// <summary>
		/// ReferralTypeCollection Lookup
		/// </summary>
		public ReferralTypeCollection LookupOf_ReferralTypeID
		{
			get
			{
				return ReferralTypeCollection.ActiveReferralTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public ActiveAdvice.DataLayer.ReferralDetailCollection[] ValuesOf_ReferralDetails
		{
			get
			{
				return new ActiveAdvice.DataLayer.ReferralDetailCollection[] { }; // return possible field values
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.createTime = DateTime.Now;
			this.referralStartDate = DateTime.Today;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

//		public override void FillSummaryText(SummaryWriter writer)
//		{
//			base.FillSummaryText (writer);
//			writer.AddFieldsOnNewLine(this,"referralID" , "referralDescription");
//		}

		/// <summary>
		/// Fill provider properties 
		/// provider name, location , Phone, fax, pager, speciality and network properties
		/// </summary>
		public void FillProviderInfo()
		{
			this.pCPFullName = "";
			this.pCPFullLocation = "";
			this.pCPPhone = "";
			this.pCPFax = "";
			this.pCPPager = "";
			this.PCPSpecialtyDescription="";
			if(this.ReferredFromProviderID!=0)
			{
				Provider provider = new Provider();
				provider.Load(this.ReferredFromProviderID);
				this.ReferredFromPCPFullName =provider.LastName + " " + provider.FirstName; //+ " ," +  provider.Suffix;  //Name
			}
			if(this.PCPID!=0)
			{
				Provider provider = new Provider();
				provider.Load(this.PCPID);
				this.PCPFullName =provider.LastName + " " + provider.FirstName; //+ " ," +  provider.Suffix;  //Name
			}
		}

		protected override void InitializeToTrackChanges()
		{
			// track the change of statusID.
			this.startDateWhenLoaded = this.referralStartDate;

			// duplicate checking should also occur also when these change
			this.referralTypeIDWhenLoaded = this.referralTypeID;
			this.pCPIDWhenLoaded = this.pCPID;
			this.referredFromProviderIDWhenLoaded = this.referredFromProviderID;
			this.referredToTypeWhenLoaded = this.referredToType;
			this.referredToIDWhenLoaded = this.referredToID;
			base.InitializeToTrackChanges ();
		}


		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// track the change of statusID.
			this.startDateWhenLoaded = this.referralStartDate;

			// duplicate checking should also occur also when these change
			this.referralTypeIDWhenLoaded = this.referralTypeID;
			this.pCPIDWhenLoaded = this.pCPID;
			this.referredFromProviderIDWhenLoaded = this.referredFromProviderID;
			this.referredToTypeWhenLoaded = this.referredToType;
			this.referredToIDWhenLoaded = this.referredToID;
		}

		public bool StartDateChanged
		{
			get
			{
				return this.startDateWhenLoaded != this.referralStartDate;
			}
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		public ActiveAdvice.DataLayer.Plan Plan
		{
			get { return this.plan; }
			set { this.plan = value; }
		}

//		/// <summary>
//		/// Loads and retuns the linked patient
//		/// </summary>
//		/// <returns></returns>
//		public Patient GetPatient()
//		{
//			if (this.patientId == 0)
//				return null;
//			Patient patient = new Patient();
//			patient.SqlData.Transaction = this.SqlData.Transaction;
//			if (patient.Load(this.patientId))
//				return patient;
//			else
//				return null;
//		}

		/// <summary>
		/// Sets/Returns the Patient linked to event.
		/// All operations that require patient context use this object.
		/// </summary>
		public Patient Patient
		{
			get 
			{ 
//				if (patient == null)
//					patient = this.GetPatient();
//				return patient;
				return this.ParentPatient;
			}
			//set { this.patient = value;	}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				//writer.AddFields(this, "CMSID");
				//writer.AddHeaderLabelandValue("Case ID", CMSID.ToString());
				writer.StartNewLineInSection();
				writer.AddHeaderLabelandValueOnSameLine("Referral ID", ReferralID.ToString());
				//writer.AddFieldsOnNewLine(this, "ContactID", "LastName", "FirstName");
				//writer.AddField(this, "DaysOpen");
				//writer.AddHeaderLabelandValueOnSameLine("Days Open", this.DaysOpen.ToString());
				
				writer.EndLineInSection();
			}
		}

		/// <summary>
		/// Child EventDiagnoses mapped to related rows of table EventReferralDiagnose where [EventID] = [EventID]
		/// </summary>
		[SPLoadChild("usp_LoadReferralDiagnoses", "ReferralId")]
		public override EventReferralDiagnoseCollection EventReferralDiagnoses
		{
			get { return this.referralDiagnoses; }
			set
			{
				this.referralDiagnoses = value;
				if (value != null)
					value.ParentReferral = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the EventDiagnoses collection
		/// </summary>
		public override void LoadEventReferralDiagnoses(bool forceReload)
		{
			this.EventReferralDiagnoses = (EventReferralDiagnoseCollection)EventReferralDiagnoseCollection.LoadChildCollection("EventReferralDiagnoses", this, typeof(EventReferralDiagnoseCollection), referralDiagnoses, forceReload, null);
		}

		/// <summary>
		/// Saves the EventDiagnoses collection
		/// </summary>
		public override void SaveEventReferralDiagnoses()
		{
			EventReferralDiagnoseCollection.SaveChildCollection(this.referralDiagnoses, true);
		}

		/// <summary>
		/// Synchronizes the EventDiagnoses collection
		/// </summary>
		public void SynchronizeEventReferralDiagnoses()
		{
			EventReferralDiagnoseCollection.SynchronizeChildCollection(this.referralDiagnoses, true);
		}

		/// <summary>
		/// Child ReferralProcedures mapped to related rows of table EventReferralProcedure where [ReferralID] = [ReferralID]
		/// </summary>
		[SPLoadChild("usp_LoadReferralProcedures", "ReferralId")]
		public override EventReferralProcedureCollection EventReferralProcedures
		{
			get { return this.referralProcedures; }
			set
			{
				this.referralProcedures = value;
				if (value != null)
					value.ParentReferral = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ReferralProcedures collection
		/// </summary>
		public override void LoadEventReferralProcedures(bool forceReload)
		{
			this.EventReferralProcedures = (EventReferralProcedureCollection)EventReferralProcedureCollection.LoadChildCollection("EventReferralProcedures", this, typeof(EventReferralProcedureCollection), referralProcedures, forceReload, null);
		}

		/// <summary>
		/// Saves the EventProcedures collection
		/// </summary>
		public override void SaveEventReferralProcedures()
		{
			EventReferralProcedureCollection.SaveChildCollection(this.referralProcedures, true);
		}

		/// <summary>
		/// Synchronizes the EventProcedures collection
		/// </summary>
		public void SynchronizeReferralProcedures()
		{
			EventReferralProcedureCollection.SynchronizeChildCollection(this.referralProcedures, true);
		}

		public override void SyncDiagnosticCodes(DiagnosticSelectCollection diagnostics)
		{
			this.LoadEventReferralDiagnoses(false);
			this.EventReferralDiagnoses.SyncFromSelections(diagnostics);
			
			this.CalculateDRGData(this.Patient);
			
			this.SqlData.EnsureTransaction();
			try
			{
				if (!this.IsNew)
					this.Save();
				this.SaveEventReferralDiagnoses();
				AutoActivity_CodingDxPx(AutoActivityRuleType.CD2, diagnostics);
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}	
		}

		public override void SyncProcedureCodes(ProcedureSelectCollection procedures)
		{
			this.LoadEventReferralProcedures(false);
			this.EventReferralProcedures.SyncFromSelections(procedures);
			
			try
			{
				this.CalculateDRGData(this.Patient);
			}
			catch
			{
				// we'll save even though we can't calculate
			}

			this.SqlData.EnsureTransaction();
			try
			{
				this.SaveEventReferralProcedures();
				AutoActivity_CodingDxPx(AutoActivityRuleType.CP2, procedures);
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}	
		}

		public override DiagnosticSelectCollection CreateDiagnosticSelectionCollection()
		{
			this.LoadEventReferralDiagnoses(false);
			return this.EventReferralDiagnoses.CreateSelectionCollection();
		}

		public override ProcedureSelectCollection CreateProcedureSelectionCollection()
		{
			this.LoadEventReferralProcedures(false);
			return this.EventReferralProcedures.CreateSelectionCollection();
		}

		/// <summary>
		/// Loads and retuns the linked patient subscriber log entry
		/// </summary>
		/// <returns></returns>
		public PatientSubscriberLog GetPatientSubscriberLog()
		{
			if (this.patientSubscriberLogID == 0)
				return null;
			PatientSubscriberLog patSubLog = new PatientSubscriberLog();
			patSubLog.SqlData.Transaction = this.SqlData.Transaction;
			if (patSubLog.Load(this.patientSubscriberLogID))
				return patSubLog;
			else
				return null;
		}

		/// <summary>
		/// Returns the loaded and cached plan sorg log entry
		/// </summary>
		public override PlanSORGLog PlanSORGLog
		{
			get
			{
				if (this.planSorgLog == null)
					this.planSorgLog = GetPlanSorgLog();
				return this.planSorgLog;
			}
		}

		/// <summary>
		/// Loads and retuns the linked plan sorg log entry
		/// </summary>
		/// <returns></returns>
		public PlanSORGLog GetPlanSorgLog()
		{
			if (this.planSorgLogID == 0)
				return null;
			PlanSORGLog planSorgLog = new PlanSORGLog();
			planSorgLog.SqlData.Transaction = this.SqlData.Transaction;
			if (planSorgLog.Load(this.planSorgLogID))
				return planSorgLog;
			else
				return null;
		}

		/// <summary>
		/// Get the last referral detail for the event
		/// </summary>
		/// <returns></returns>
		public ReferralDetail GetLastDetail()
		{
			if (this.IsNew)
				return null;
			ReferralDetail lastDetail = new ReferralDetail();
			lastDetail.SqlData.Transaction = this.SqlData.Transaction;
			if (lastDetail.LoadLastDetailForReferral(this.referralID))
				return lastDetail;
			else
				return null;
		}

		/// <summary>
		/// Loaded and cached last referral detail
		/// </summary>
		public ReferralDetail LastDetail
		{
			get
			{
				if (lastDetail == null)
					lastDetail = GetLastDetail();
				return lastDetail;
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string AlternateReferralID
		{
			get { return this.alternateReferralID; }
			set { this.alternateReferralID = value; }
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			bool initialSave = this.IsNew;

			base.InternalSave();
			
			// Save the child collections here.
			

			#region Trigger AutoActivities - RS1

			PatientCoverage patCov = null;
			if (this.PatientSubscriberLog != null)
				patCov = this.PatientSubscriberLog.PatientCoverage;

			if (initialSave)
				AutoActivity_ReferralInitialSave(patient, patCov);	// RS1

			#endregion

		}

		/// <summary>
		/// RS1	- Referral Initial Save
		/// This is triggered when the referral is saved the first time by an insertion.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="patCov"></param>
		protected void AutoActivity_ReferralInitialSave(Patient patient, PatientCoverage patCov)
		{
			autoActivityManager = new AutoActivityManager(patient, patCov, null, this);
			autoActivityManager.Execute(AutoActivityRuleType.RS1, this.SqlData.Transaction);
		}


		/// <summary>
		/// Determines whether the referral already exists based on the following fields:
		///	   patientID,             (implicit rule)
		///    referralTypeID, 
		///    pCPID, 
		///    referredFromProviderID,
		///    referredToType, 		
		///    referredToID, 
		///    referralStartDate
		/// The current can be excluded from the check.  For instance,
		/// if there's only one referral with those fields in the database, 
		/// and excludingThis = true, this function
		/// will return false.
		/// </summary>
		public bool ExistsReferral(bool excludingThis)
		{
			if (excludingThis)
			{
				// The direct call to the stored procedure will pass eventID
				// of this referral for exclusion from the check.
				return Convert.ToBoolean( SqlData.SPExecScalar("usp_ExistsReferral", this, false) );
			}
			else
			{
				// pass eventID = DBNull so that it won't exclude this event from the check.
				return Convert.ToBoolean(
					SqlData.SPExecScalar("usp_ExistsReferral", this, false, 
					new string[] {"referralID"},
					new object[] { DBNull.Value } ) 
					);
			}

		}

		/// <summary>
		/// Returns true if the referral is duplicate in the database.
		/// 
		/// This is a specialized version of ExistsReferral(bool excludingThis).
		/// This method uses calls ExistsReferral with excludingThis=true, thus
		/// excluding this referral from check.
		/// </summary>
		/// <returns></returns>
		public bool DuplicateCheck()
		{
			// Duplicate checking must occur only if the record is new,
			// or at least one of the following fields was changed.
			if (this.IsNew ||
				this.startDateWhenLoaded != this.referralStartDate ||
				this.referralTypeIDWhenLoaded != this.referralTypeID ||
				this.pCPIDWhenLoaded != this.pCPID ||
				this.referredFromProviderIDWhenLoaded != this.referredFromProviderID ||
				this.referredToTypeWhenLoaded != this.referredToType ||
				this.referredToIDWhenLoaded != this.referredToID)
				return ExistsReferral(true);
			else
				return false;
		}

		/// <summary>
		/// Load possible duplicate referrals for this referral in the context of the patient.
		///	The duplicate referrals are the ones whose following fields match:
		///	   patientID,             (implicit rule)
		///    referralTypeID, 
		///    pCPID, 
		///    referredFromProviderID,
		///    referredToType, 		
		///    referredToID, 
		///    referralStartDate
		/// and whose referralID is not the same as the given referral's.
		/// </summary>
		/// <returns></returns>
		public ReferralCollection GetPossibleDuplicateReferrals()
		{
			ReferralCollection col = new ReferralCollection();
			// testing
			//col.AddRecord(this);
			//return col;
			col.LoadPossibleDuplicateReferrals(this);
			if (col.Count > 0)
				return col;
			else
				return null;
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime LastValidationDate
		{
			get { return this.lastValidationDate; }
			set { this.lastValidationDate = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of Referral objects
	/// </summary>
	[ElementType(typeof(Referral))]
	public class ReferralCollection : BaseCollectionForEventCMSReferral
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Referral elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReferralCollection = this;
			else
				elem.ParentReferralCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Referral elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Referral this[int index]
		{
			get
			{
				return (Referral)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Referral)oldValue, false);
			SetParentOnElem((Referral)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadReferralsByProblemId(int maxRecords, int primaryProblemID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetReferralsByProblemId", maxRecords, this, false, primaryProblemID);
		}

		
		/// <summary>
		/// Returns all the Referrals for a given patient object and also establishes the in-memory relations to 
		/// patient object.
		/// </summary>
		/// <param name="patient"></param>
		/// <returns></returns>
		public int LoadLinkedPatientReferrals(Patient patient)
		{
			return LoadLinkedPatientReferrals(-1, patient);
		}

		/// <summary>
		/// Load the referrals of a given patient.
		/// </summary>
		public int LoadLinkedPatientReferrals(int maxRecords, Patient patient)
		{
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Linked patient referrals can be loaded only in the context of a patient");
			this.Clear();
			int count = SqlData.SPExecReadCol("usp_GetLinkedPatientReferralsWithDAFilter", maxRecords, this, false, patient.PatientId, SQLDataDirect.MakeDBValue(AASecurityHelper.GetUserId, (int)0));

			// set the parent patients for all the events
			SetParentPatientObject(patient);

			return count;
		}

		/// <summary>
		/// Given a problem, this function determines if the event is linked or not
		/// </summary>
		/// <param name="problem"></param>
		public override void DetermineElementsLinkedToProblem(Problem problem)
		{
			problem.LoadProblemReferrals(false);
			problem.ProblemReferrals.IndexBy_ReferralId.Rebuild();
			for (int i = 0; i < this.Count; i++)
			{
				Referral referral = this[i];

				ProblemReferral probRef = problem.ProblemReferrals.FindByReferralID(referral.ReferralID);
				referral.IsLinkedToProblem = probRef != null;	// if found, this is linked to the problem
			}
		}

		/// <summary>
		/// Load all possible duplicates for the event.  The duplicate events are the ones
		/// whose following fields match:
		///	   patientID,             (implicit rule)
		///    referralTypeID, 
		///    pCPID, 
		///    referredFromProviderID,
		///    referredToType, 		
		///    referredToID, 
		///    referralStartDate
		/// and whose eventID is not the same as the given event's.
		/// </summary>
		public int LoadPossibleDuplicateReferrals(Referral obj)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPossibleDuplicateReferrals", -1, this, obj, false);
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Referral elem)
		{
			return AddRecord(elem);
		}

		
		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Referral)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Search all events by the Alt-Referral ID
		/// </summary>
		public int SearchReferralsByAltReferralID(int maxRecords, string alternateReferralID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchReferralsByAltReferralID", maxRecords, this, false, 
				new object[] { SQLDataDirect.MakeDBValue( alternateReferralID ) });
		}

		public override int SearchByAltAuthorizationID(int maxRecords, string altAuthorizationID)
		{
			return SearchReferralsByAltReferralID(maxRecords, altAuthorizationID);
		}
	}
}
