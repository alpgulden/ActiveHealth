using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReferralRoles]
	/// </summary>
	[SPAutoGen("usp_GetReferralRoleByCode","SelectAllByGivenArgs.sptpl","code")]
	[SPAutoGen("usp_GetReferralRoleByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllReferralRole","SelectAll.sptpl","")]
	[SPInsert("usp_InsertReferralRole")]
	[SPUpdate("usp_UpdateReferralRole")]
	[SPDelete("usp_DeleteReferralRole")]
	[SPLoad("usp_LoadReferralRole")]
	[TableMapping("ReferralRole","referralRoleID")]
	public class ReferralRole : BaseLookupWithNote
	{
		[NonSerialized]
		private ReferralRoleCollection parentReferralRoleCollection;
		[ColumnMapping("ReferralRoleID",StereoType=DataStereoType.FK)]
		private int referralRoleID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ReferralRole()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ReferralRoleID
		{
			get { return this.referralRoleID; }
			set { this.referralRoleID = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent ReferralRoleCollection that contains this element
		/// </summary>
		public ReferralRoleCollection ParentReferralRoleCollection
		{
			get
			{
				return this.parentReferralRoleCollection;
			}
			set
			{
				this.parentReferralRoleCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadReferralRoleByCode(string code)
		{
			return SqlData.SPExecReadObj("usp_GetReferralRoleByCode", this, false, new object[] { code });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>

	}

	/// <summary>
	/// Strongly typed collection of ReferralRole objects
	/// </summary>
	[ElementType(typeof(ReferralRole))]
	public class ReferralRoleCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReferralRole elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReferralRoleCollection = this;
			else
				elem.ParentReferralRoleCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ReferralRole elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReferralRole this[int index]
		{
			get
			{
				return (ReferralRole)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReferralRole)oldValue, false);
			SetParentOnElem((ReferralRole)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public int LoadReferralRoleByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetReferralRoleByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ReferralRoleCollection which is cached in NSGlobal
		/// </summary>
		public static ReferralRoleCollection ActiveReferralRoles
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ReferralRoleCollection col = (ReferralRoleCollection)NSGlobal.EnsureCachedObject("ReferralRoles", typeof(ReferralRoleCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadReferralRoleByActive(-1, true);
				}
				return col;
			}			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllReferralRole", -1, this, false);
		}
	}
}
