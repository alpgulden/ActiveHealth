using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OrganizationEnrollment]
	/// </summary>
	[SPInsert("usp_InsertOrganizationEnrollment")]
	[SPDelete("usp_DeleteOrganizationEnrollment")]
	[SPLoad("usp_LoadOrganizationEnrollment")]
	[TableMapping("OrganizationEnrollment","organizationID,enrollmentID",true)]
	public class OrganizationEnrollment : BaseData
	{
		[NonSerialized]
		private OrganizationEnrollmentCollection parentOrganizationEnrollmentCollection;
		[ColumnMapping("OrganizationID")]
		private int organizationID;
		[ColumnMapping("EnrollmentID")]
		private int enrollmentID;
	
		public OrganizationEnrollment()
		{
		}

		public OrganizationEnrollment(int organizationID, int enrollmentID)
		{
			this.NewRecord(); // initialize record state
			this.organizationID = organizationID;
			this.enrollmentID = enrollmentID;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OrganizationID
		{
			get { return this.organizationID; }
			set { this.organizationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EnrollmentID
		{
			get { return this.enrollmentID; }
			set { this.enrollmentID = value; }
		}

		/// <summary>
		/// Parent OrganizationEnrollmentCollection that contains this element
		/// </summary>
		public OrganizationEnrollmentCollection ParentOrganizationEnrollmentCollection
		{
			get
			{
				return this.parentOrganizationEnrollmentCollection;
			}
			set
			{
				this.parentOrganizationEnrollmentCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// The description of enrollment that corresponds to the linked enrollment ID.
		/// Looked up from the loaded-cached collection of active enrollments.
		/// </summary>
		public string Description
		{
			get { return EnrollmentCollection.AllEnrollmentsByValidDateRange.Lookup_DescriptionByEnrollmentID(this.enrollmentID); }
		}
	}

	/// <summary>
	/// Strongly typed collection of OrganizationEnrollment objects
	/// </summary>
	[ElementType(typeof(OrganizationEnrollment))]
	public class OrganizationEnrollmentCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_OrganizationID_EnrollmentID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OrganizationEnrollment elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOrganizationEnrollmentCollection = this;
			else
				elem.ParentOrganizationEnrollmentCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OrganizationEnrollment elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OrganizationEnrollment this[int index]
		{
			get
			{
				return (OrganizationEnrollment)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OrganizationEnrollment)oldValue, false);
			SetParentOnElem((OrganizationEnrollment)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(OrganizationEnrollment elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((OrganizationEnrollment)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Hashtable based index on organizationID, enrollmentID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_OrganizationID_EnrollmentID
		{
			get
			{
				if (this.indexBy_OrganizationID_EnrollmentID == null)
					this.indexBy_OrganizationID_EnrollmentID = new CollectionIndexer(this, new string[] { "organizationID", "enrollmentID" }, true);
				return this.indexBy_OrganizationID_EnrollmentID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on organizationID, enrollmentID fields returns the object.  Uses the IndexBy_OrganizationID_EnrollmentID indexer.
		/// </summary>
		public OrganizationEnrollment FindBy(int organizationID, int enrollmentID)
		{
			return (OrganizationEnrollment)this.IndexBy_OrganizationID_EnrollmentID.GetObject(organizationID, enrollmentID);
		}

		/// <summary>
		/// Parent Organization that contains this collection
		/// </summary>
		public Organization ParentOrganization
		{
			get { return this.ParentDataObject as Organization; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Organization */ }
		}
	}
}
