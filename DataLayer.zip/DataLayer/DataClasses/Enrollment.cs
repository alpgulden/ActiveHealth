using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Enrollment]
	/// </summary>
	// Custom: usp_LoadEnrollmentsByOrganizationID
	// Custom: [SPAutoGen("usp_LoadAllEnrollmentsByOrganizationId","SelectRelatedFromLinkedTable.sptpl","OrganizationEnrollment, enrollmentID, organizationID")]
	// Custom: [SPAutoGen("usp_GetAllActiveEnrollments","SelectAll.sptpl","")]
	//[SPAutoGen("usp_GetLinkedOrganizationEnrollments","SelectRelatedFromLinkedTable.sptpl","OrganizationEnrollment, enrollmentID, organizationID")]
	[SPAutoGen("usp_GetEnrollmentByAlternateID","SelectAllByGivenArgs.sptpl","alternateEnrollmentID")]
	[SPAutoGen("usp_GetAllEnrollments","SelectAll.sptpl","")]
	[SPInsert("usp_InsertEnrollment")]
	[SPUpdate("usp_UpdateEnrollment")]
	[SPDelete("usp_DeleteEnrollment")]
	[SPLoad("usp_LoadEnrollment")]
	[TableMapping("Enrollment","enrollmentID")]
	public class Enrollment : BaseData
	{
		[NonSerialized]
		private EnrollmentCollection parentEnrollmentCollection;
		[ColumnMapping("EnrollmentID",StereoType=DataStereoType.FK)]
		private int enrollmentID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("AlternateEnrollmentID")]
		private string alternateEnrollmentID;
		private OrganizationCollection organizations;

		// non-db members
		private bool enrolled;	// Set when showing linked enrollments to a speecific organization.

		private DateTime termDateWhenLoaded;	// track changes to termination date.
	
		public Enrollment()
		{
		}

		public Enrollment(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EnrollmentID
		{
			get { return this.enrollmentID; }
			set { this.enrollmentID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@TERMDATE@")]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int enrollmentID)
		{
			return base.Load(enrollmentID);
		}

		/// <summary>
		/// Parent EnrollmentCollection that contains this element
		/// </summary>
		public EnrollmentCollection ParentEnrollmentCollection
		{
			get
			{
				return this.parentEnrollmentCollection;
			}
			set
			{
				this.parentEnrollmentCollection = value; // parent is set when added to a collection
			}
		}

		
		/// <summary>
		/// Child Organizations mapped to related rows of table Organization where [EnrollmentID] = [OrganizationID]
		/// </summary>
		[SPLoadChild("usp_LoadAllOrganizationsByEnrollmentId", "enrollmentID")]
		public OrganizationCollection Organizations
		{
			get { return this.organizations; }
			set
			{
				this.organizations = value;
				if (value != null)
					value.ParentEnrollment = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Organizations collection
		/// </summary>
		public void LoadOrganizations(bool forceReload)
		{
			this.organizations = (OrganizationCollection)OrganizationCollection.LoadChildCollection("Organizations", this, typeof(OrganizationCollection), organizations, forceReload, null);
		}
		
		/// <summary>
		/// Saves the Organizations collection
		/// </summary>
		public void SaveOrganizations()
		{
			OrganizationCollection.SaveChildCollection(this.organizations, true);
		}

		/// <summary>
		/// Synchronizes the Organizations collection
		/// </summary>
		public void SynchronizeOrganizations()
		{
			OrganizationCollection.SynchronizeChildCollection(this.organizations, true);
		}

		/// <summary>
		/// Parent PackingListItemTrigger that contains this object
		/// </summary>
		public PackingListItemTrigger ParentPackingListItemTrigger
		{
			get { return this.ParentDataObject as PackingListItemTrigger; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PackingListItemTrigger */ }
		}

		[ControlType(EnumControlTypes.TextBox, /*ClientValidators=EnumClientValidators.Required, per Issue 791*/ MaxLength=30)]
		public string AlternateEnrollmentID
		{
			get { return this.alternateEnrollmentID; }
			set { this.alternateEnrollmentID = value; }
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.effectiveDate = DateTime.Today;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}

			base.InternalSave();
			// Save the child collections here.
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Enrolled
		{
			get { return this.enrolled; }
			set { this.enrolled = value; }
		}

		/// <summary>
		/// Load the enrollment by given alternateEnrollmentID
		/// </summary>
		public bool LoadEnrollmentByAlternateID(string alternateEnrollmentID)
		{
			return SqlData.SPExecReadObj("usp_GetEnrollmentByAlternateID", this, false, new object[] { alternateEnrollmentID });
		}

		public static Enrollment GetEnrollmentByAlternateID(string alternateEnrollmentID)
		{
			Enrollment enrollment = new Enrollment();
			if (enrollment.LoadEnrollmentByAlternateID(alternateEnrollmentID))
				return enrollment;
			else
				return null;
		}

		public static int LookupEnrollmentIDByAlternateID(string alternateEnrollmentID)
		{
			Enrollment enrollment = GetEnrollmentByAlternateID(alternateEnrollmentID);
			if (enrollment == null)
				return 0;
			else
				return enrollment.EnrollmentID;
		}

	}

	/// <summary>
	/// Strongly typed collection of Enrollment objects
	/// </summary>
	[ElementType(typeof(Enrollment))]
	public class EnrollmentCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_EnrollmentID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Enrollment elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEnrollmentCollection = this;
			else
				elem.ParentEnrollmentCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Enrollment elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Enrollment this[int index]
		{
			get
			{
				return (Enrollment)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Enrollment)oldValue, false);
			SetParentOnElem((Enrollment)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Organization that contains this collection
		/// </summary>
		public Organization ParentOrganization
		{
			get { return this.ParentDataObject as Organization; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Organization */ }
		}

		/// <summary>
		/// Load valid enrollments by today.
		/// </summary>
		public int LoadAllActiveEnrollments(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllActiveEnrollments", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared EnrollmentCollection which is cached in NSGlobal
		/// </summary>
		public static EnrollmentCollection AllEnrollmentsByValidDateRange
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				EnrollmentCollection col = (EnrollmentCollection)NSGlobal.EnsureCachedObject("AllEnrollmentsByValidDateRange", typeof(EnrollmentCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllActiveEnrollments(-1);
				}
				return col;
			}
		}

		/// <summary>
		/// Clear the cached enrollments.
		/// </summary>
		public static void ClearAllEnrollmentsByValidDateRange()
		{
			NSGlobal.ClearCache(typeof(EnrollmentCollection), true);
		}


		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllEnrollmentsByValidDateRangeAndOrganization(int organizationID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadEnrollmentsByOrganizationID", -1, this, false, new object[] {organizationID});
		}


		/// <summary>
		/// Hashtable based index on enrollmentID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_EnrollmentID
		{
			get
			{
				if (this.indexBy_EnrollmentID == null)
					this.indexBy_EnrollmentID = new CollectionIndexer(this, new string[] { "enrollmentID" }, true);
				return this.indexBy_EnrollmentID;
			}
			
		}

		/// <summary>
		/// Looks up by enrollmentID and returns Description value.  Uses the IndexBy_EnrollmentID indexer.
		/// </summary>
		public string Lookup_DescriptionByEnrollmentID(int enrollmentID)
		{
			return this.IndexBy_EnrollmentID.LookupStringMember("Description", enrollmentID);
		}

		/// <summary>
		/// Hashtable based search on enrollmentID fields returns the object.  Uses the IndexBy_EnrollmentID indexer.
		/// </summary>
		public Enrollment FindBy(int enrollmentID)
		{
			return (Enrollment)this.IndexBy_EnrollmentID.GetObject(enrollmentID);
		}

		public void MarkLinkedEnrollments(Organization organization)
		{
			// ensure linkages.
			organization.LoadOrganizationEnrollments(false);

			// first unmark all 
			for (int i = 0; i < this.Count; i++)
				this[i].Enrolled = false;

			// marked linked
			for (int i = 0; i < organization.OrganizationEnrollments.Count; i++)
			{
				OrganizationEnrollment oe = organization.OrganizationEnrollments[i];
				Enrollment e = this.FindBy(oe.EnrollmentID);
				if (e != null)
					e.Enrolled = true;
			}
		}

		/// <summary>
		/// Syncronize the linkages using this collection
		/// </summary>
		/// <param name="organization"></param>
		public void SynchronizeLinkedEnrollments(Organization organization)
		{
			// ensure linkages.
			organization.LoadOrganizationEnrollments(false);
			organization.OrganizationEnrollments.IndexBy_OrganizationID_EnrollmentID.Rebuild();

			for (int i = 0; i < this.Count; i++)
			{
				Enrollment e = this[i];
				if (e.Enrolled)
				{
					// make sure there's a link
					OrganizationEnrollment oe = organization.OrganizationEnrollments.FindBy(organization.OrganizationID, e.EnrollmentID);
					if (oe == null)
					{
						// if not exists
						organization.OrganizationEnrollments.Add(new OrganizationEnrollment(organization.OrganizationID, e.EnrollmentID));
					}
				}
				else
				{
					// was unlinked.
					OrganizationEnrollment oe = organization.OrganizationEnrollments.FindBy(organization.OrganizationID, e.EnrollmentID);
					if (oe != null)
					{
						// exists in the linkages.  mark for deletion.
						oe.MarkDel();
					}

				}
			}

		}

		/// <summary>
		/// Load all the enrollments in the system.
		/// </summary>
		public int LoadAllEnrollments(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllEnrollments", maxRecords, this, false);
		}


	}
}
