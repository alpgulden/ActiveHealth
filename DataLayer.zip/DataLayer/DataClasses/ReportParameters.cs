using System;
using System.Reflection;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for ReportParameters.
	/// </summary>
	[TableMapping(null)]
	public class ReportParameters:BaseData
	{
		public ReportParameters()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		private int morgID;
		private int orgID;
		private int sorgID;
		private int planID;
		private string planName;
		private int teamID;
		private int userID;
		private int dateType;
		private System.DateTime endDate;
		private System.DateTime fromDate;
		private int stateID;
		private int cmsTypeID;
		private string outliers;
		private bool newBornDischargedWithMother;
		private string stateName;
		private string cmsTypeName;
		private string codeTable;
		private string subtotalBy;
		private string subGroup;
		private string majorGroup;
		private int readmitDays;
		private string sortBy;
		private string subSubGroup;
		private int		 dates;
		private bool showDetails;
		private string organizationPath;
		private string assessmentGUID;

		//Added by Alp 01/02/06 for Worklist Report.		
		
		private int rowCount;
		private string sortField;
		[ColumnMapping("fromDueDate")]
		private string fromDueDate;
		[ColumnMapping("toDueDate")]
		private string toDueDate;
		[ColumnMapping("fromCompletionDate")]
		private string fromCompletionDate;		
		[ColumnMapping("toCompletionDate")]
		private string toCompletionDate;
		[ColumnMapping("patientId")]
		private int patientId;
		[ColumnMapping("cMSID")]
		private int cMSID;
		[ColumnMapping("problemId")]
		private int problemId;
		[ColumnMapping("eventID")]
		private int eventID;
		[ColumnMapping("referralID")]
		private int referralID;
		[ColumnMapping("referralDetailID")]
		private int referralDetailID;
		[ColumnMapping("reviewID")]
		private int reviewID;
		[ColumnMapping("pRRequestID")]
		private int pRRequestID;
		[ColumnMapping("pRReviewID")]
		private int pRReviewID;
		[ColumnMapping("pRProviderDecisionID")]
		private int pRProviderDecisionID;
		[ColumnMapping("activityTypeID")]
		private int activityTypeID;		
		private int activityPriority;
		[ColumnMapping("activityCompletionID")]
		private int activityCompletionID;		
		private Boolean isBillable;
		[ColumnMapping("assignedTeamID")]
		private int assignedTeamID;
		[ColumnMapping("assignedUserID")]
		private int assignedUserID;
		[ColumnMapping("completedByUserID")]
		private int completedByUserID;
		[ColumnMapping("activityPrimaryTypeID")]
		private int activityPrimaryTypeID;		
		private string codeStatus;
		//

		// Letter Queue Stuff
		private BaseLetterQueue batchLetterQueue;
		private int reportAction;
		private object isEnvelope;
		private object isDuplex;


		[ControlType(EnumControlTypes.TextBox)]
		public string OrganizationPath
		{
			get { return this.organizationPath; }
			set { this.organizationPath = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Dates
		{
			get { return this.dates; }
			set { this.dates = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MorgID
		{
			get { return this.morgID; }
			set { this.morgID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int OrgID
		{
			get { return this.orgID; }
			set { this.orgID = value; }
		}
		
	
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SorgID
		{
			get { return this.sorgID; }
			set { this.sorgID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanID
		{
			get { return this.planID; }
			set { this.planID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PlanName
		{
			get { return this.planName; }
			set { this.planName = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TeamID
		{
			get { return this.teamID; }
			set { this.teamID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int UserID
		{
			get { return this.userID; }
			set { this.userID = value; }
		}

		[FieldValuesMember("ValuesOf_DateType")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int DateType
		{
			get { return this.dateType; }
			set { this.dateType = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime FromDate
		{
			get { return this.fromDate; }
			set { this.fromDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int StateID
		{
			get { return this.stateID; }
			set { this.stateID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CmsTypeID
		{
			get { return this.cmsTypeID; }
			set { this.cmsTypeID = value; }
		}

		[FieldValuesMember("ValuesOf_Outliers")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string Outliers
		{
			get { return this.outliers; }
			set { this.outliers = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool NewBornDischargedWithMother
		{
			get { return this.newBornDischargedWithMother; }
			set { this.newBornDischargedWithMother = value; }
		}

		[FieldValuesMember("ValuesOf_CodeTable")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string CodeTable
		{
			get { return this.codeTable; }
			set { this.codeTable = value; }
		}
		[FieldValuesMember("ValuesOf_SubtotalBy")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string SubtotalBy
		{
			get { return this.subtotalBy; }
			set { this.subtotalBy = value; }
		}

		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}
	
	//Added by Alp 01/02/06 for Worklist Report.
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RowCount
		{
			get { return this.rowCount; }
			set { this.rowCount = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SortField
		{
			get { return this.sortField; }
			set { this.sortField = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public string FromDueDate
		{
			get { return this.fromDueDate; }
			set { this.fromDueDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public string ToDueDate
		{
			get { return this.toDueDate; }
			set { this.toDueDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public string FromCompletionDate
		{
			get { return this.fromCompletionDate; }
			set { this.fromCompletionDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public string ToCompletionDate
		{
			get { return this.toCompletionDate; }
			set { this.toCompletionDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProblemId
		{
			get { return this.problemId; }
			set { this.problemId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReviewID
		{
			get { return this.reviewID; }
			set { this.reviewID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PRRequestID
		{
			get { return this.pRRequestID; }
			set { this.pRRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PRReviewID
		{
			get { return this.pRReviewID; }
			set { this.pRReviewID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PRProviderDecisionID
		{
			get { return this.pRProviderDecisionID; }
			set { this.pRProviderDecisionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ActivityTypeID
		{
			get { return this.activityTypeID; }
			set { this.activityTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ActivityPriority
		{
			get { return this.activityPriority; }
			set { this.activityPriority = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ActivityCompletionID
		{
			get { return this.activityCompletionID; }
			set { this.activityCompletionID = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedTeamID
		{
			get { return this.assignedTeamID; }
			set { this.assignedTeamID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedUserID
		{
			get { return this.assignedUserID; }
			set { this.assignedUserID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CompletedByUserID
		{
			get { return this.completedByUserID; }
			set { this.completedByUserID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ActivityPrimaryTypeID
		{
			get { return this.activityPrimaryTypeID; }
			set { this.activityPrimaryTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string CodeStatus
		{
			get { return this.codeStatus; }
			set { this.codeStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.TrueFalse)]
		public Boolean IsBillable
		{
			get { return this.isBillable; }
			set { this.isBillable = value; }
		}		

	//
	
		public string SorgName
		{
			get
			{
				if(this.sorgID == 0)
					return null;
				else
				{
					Organization org = new Organization();
					org.Load(sorgID);
					if(org.IsSubOrganization)
						return org.Name;
					else
						return null;
				}
			}
		}

		public string OrgName
		{
			get
			{
				if(this.sorgID == 0)
					return null;
				else
				{
					Organization org = new Organization();
					org.Load(sorgID);
					if(org.IsMasterOrganization)
						return null;
					else if(org.IsSubOrganization)
					{
						if(org.ParentOrganization == null)
							return null;
						return org.ParentOrganization.Name;
					}
					else
						return org.Name;
				}

			}
		}

		public string MorgName
		{
			get
			{
				if(this.sorgID == 0)
					return null;
				Organization org = new Organization();
				org.Load(sorgID);
				if(org.IsMasterOrganization)
					return org.Name;
				else if(org.IsSubOrganization)
				{
					if(org.ParentOrganization == null)
						return null;
					if(org.ParentOrganization.ParentOrganization == null)
						return null;
					return org.ParentOrganization.ParentOrganization.Name;
				}
				else
				{
					if(org.ParentOrganization == null)
						return null;
					return org.ParentOrganization.Name;
				}
			}
		}

		public string TeamName
		{
			get
			{
				if(this.teamID == 0)
					return null;
				Team team = new Team();
				team.Load(teamID);
				return team.Code;
			}
		}

		public string UserName
		{
			get
			{
				if(this.userID == 0)
					return null;
				AAUser user = new AAUser();
				user.Load(userID);
				return user.LoginName;
			}
		}

		[FieldValuesMember("LookupOf_StateName","Code","Code")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string StateName
		{
			get { return this.stateName; }
			set { this.stateName = value; }
		}

		[FieldValuesMember("LookupOf_CMSTypeName","Description","Description")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string CmsTypeName
		{
			get { return this.cmsTypeName; }
			set { this.cmsTypeName = value; }
		}

		public StateCollection LookupOf_StateName
		{
			get
			{
				return	StateCollection.AllStates;
			}
		}

		public CMSStatusTypeCollection LookupOf_CMSTypeName
		{
			get
			{
				return CMSStatusTypeCollection.ActiveCMSStatusTypes;//.ActiveCMSTypes;
			}
		}

		public string[,] ValuesOf_CodeTable
		{
			get
			{
				return new string[,]{{"CodeTable1","CodeTable1"},{"CodeTable2","CodeTable2"}};
			}
		}

		public string[,] ValuesOf_SubtotalBy
		{
			get
			{
				return new string[,] {{"MORG","MORG"},{"ORG","ORG"},{"SORG","SORG"},{"Plan","Plan"}};
			}
		}

		public string[,] ValuesOf_Outliers
		{
			get
			{
				return new string[,] {{" ","Include"},{"I","Exclude"},{"O","Only"}};
			}
		}

		public object[,] ValuesOf_DateType
		{
			get
			{
				return new object[,] {{0,"Single Value"},{1,"Range"}};
			}
		}

		public string[,] ValuesOf_SubGroup
		{
			get
			{
				return new string[,]{{"Call Reason","Call Reason"},{"Resolution","Resolution"},{"Source","Source"},{"UserID","UserID"}};
			}
		}
		public string[,] ValuesOf_MajorGroup
		{
			get
			{
				return new string[,]{{"Call Reason","Call Reason"},{"Resolution","Resolution"},{"Source","Source"},{"UserID","UserID"}};
			}
		}
		public string[,] ValuesOf_SortBy
		{
			get
			{
				return new string[,]{{"UserID","UserID"},{"ErrorType","ErrorType"},{"PatientID","PatientID"}};
			}
		}
		public string[,] ValuesOf_SubSubGroup
		{
			get
			{
				return new string[,]{{"Call Reason","Call Reason"},{"Resolution","Resolution"},{"Source","Source"},{"UserID","UserID"}};
			}
		}
		
		[FieldValuesMember("ValuesOf_SubGroup")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string SubGroup
		{
			get { return this.subGroup; }
			set { this.subGroup = value; }
		}

		[FieldValuesMember("ValuesOf_MajorGroup")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string MajorGroup
		{
			get { return this.majorGroup; }
			set { this.majorGroup = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReadmitDays
		{
			get { return this.readmitDays; }
			set { this.readmitDays = value; }
		}

		[FieldValuesMember("ValuesOf_SortBy")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string SortBy
		{
			get { return this.sortBy; }
			set { this.sortBy = value; }
		}

		[FieldValuesMember("ValuesOf_SubSubGroup")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string SubSubGroup
		{
			get { return this.subSubGroup; }
			set { this.subSubGroup = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool ShowDetails
		{
			get { return this.showDetails; }
			set { this.showDetails = value; }
		}

		public object getVal(string propertyName)
		{
			Type thisType = this.GetType();
			PropertyInfo[] properties = thisType.GetProperties();
			for (int i=0; i < properties.GetUpperBound(0); i++)
			{
				if (properties[i].Name.ToLower() == propertyName.ToLower())
				{
					return properties[i].GetValue(this,null);
					break;
				}
			}
			return null;
		}

		public ActiveAdvice.DataLayer.BaseLetterQueue BatchLetterQueue
		{
			get { return this.batchLetterQueue; }
			set { this.batchLetterQueue = value; }
		}

		public int ReportAction
		{
			get { return this.reportAction; }
			set { this.reportAction = value; }
		}

		public object IsEnvelope
		{
			get { return this.isEnvelope; }
			set { this.isEnvelope = value; }
		}

		public object IsDuplex
		{
			get { return this.isDuplex; }
			set { this.isDuplex = value; }
		}
	}
}
