using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SystemControlValues]
	/// </summary>
	[SPUpdate("usp_UpdateSystemControlValue")]
	[SPLoad("usp_LoadSystemControlValue")]
	[TableMapping("SystemControlValues", "ID")]
	public sealed class SystemControlValue : BaseData
	{
		[ColumnMapping("ID")]
		private readonly int iD;
		[ColumnMapping("DatabaseVersion")]				// no UI
		private string databaseVersion;
		[ColumnMapping("DatabaseVersionDate")]			// no UI
		private DateTime databaseVersionDate;
		[ColumnMapping("CheckEligibility")]				// done
		private bool checkEligibility;
		[ColumnMapping("EligibilityAddAnyway")]			// done
		private bool eligibilityAddAnyway;
		[ColumnMapping("DRGTypeID",StereoType=DataStereoType.FK)]		// done
		private int dRGTypeID;
		[ColumnMapping("DRGVersionCode")]				// no UI
		private string dRGVersionCode;
		[ColumnMapping("DRGVersion", (int)0)]			// done
		private int dRGVersion;
		[ColumnMapping("LOSRegionID",StereoType=DataStereoType.FK)]		// done
		private int lOSRegionID;
		[ColumnMapping("LOSPayorGroupID",StereoType=DataStereoType.FK)]	// done
		private int lOSPayorGroupID;
		[ColumnMapping("LOSYear")]						// done
		private int lOSYear;
		[ColumnMapping("GuidelineSourceSetID",StereoType=DataStereoType.FK)]	// no UI
		private int guidelineSourceSetID;
		[ColumnMapping("MomMinimumAge")]				// done
		private int momMinimumAge;
		[ColumnMapping("MomMaximumAge")]				// done
		private int momMaximumAge;
		[ColumnMapping("BabyMaximumAge")]				// done
		private int babyMaximumAge;
		[ColumnMapping("UseGrouper")]					// done
		private bool useGrouper;
		[ColumnMapping("UseLOSTables")]					// done
		private bool useLOSTables;
		[ColumnMapping("CloneBaby")]					// done
		private bool cloneBaby;
		[ColumnMapping("AddProviderOnTheFly")]			// done
		private bool addProviderOnTheFly;
		[ColumnMapping("AddFacilityOnTheFly")]			// done
		private bool addFacilityOnTheFly;
		[ColumnMapping("AddGroupPracticeOnTheFly")]		// done
		private bool addGroupPracticeOnTheFly;
		[ColumnMapping("Country")]						// no UI   // skip
		private string country;
		[ColumnMapping("EventTypeID",StereoType=DataStereoType.FK)]		// no UI 
		private int eventTypeID;
		[ColumnMapping("AutoCreateProblem1")]			// done
		private bool autoCreateProblem1;
		[ColumnMapping("Problem1DescriptionID",StereoType=DataStereoType.FK)]	// no UI
		private int problem1DescriptionID;
		[ColumnMapping("AutoCreateProblem2")]			// done
		private bool autoCreateProblem2;
		[ColumnMapping("Problem2DescriptionID",StereoType=DataStereoType.FK)]	// no UI
		private int problem2DescriptionID;
		[ColumnMapping("ProviderState")]				// no UI
		private string providerState;
		[ColumnMapping("ShowHints")]					// done
		private bool showHints;	
		[ColumnMapping("EventActualProjected")]			// no UI
		private string eventActualProjected;
		[ColumnMapping("LOSTriggerDays")]				// done
		private int lOSTriggerDays;
		[ColumnMapping("ReferralGoodForDays")]			// no UI
		private int referralGoodForDays;
		[ColumnMapping("LOSOutlierPercent")]			// done
		private Decimal lOSOutlierPercent;
		[ColumnMapping("LOSReviewPercent")]				// done
		private Decimal lOSReviewPercent;
		[ColumnMapping("LivesInputLevel")]				// no UI
		private string livesInputLevel;
		[ColumnMapping("ReferralReasonEditable")]		// done
		private bool referralReasonEditable;
		[ColumnMapping("EDI_HIPAAReady")]				// no UI
		private bool ediHipaaready;
		[ColumnMapping("EditLateSetting")]				// no UI
		private int editLateSetting;
		[ColumnMapping("FFRMProblemDescription")]		// done
		private bool fFRMProblemDescription;
		[ColumnMapping("FFRMDeficitDescription")]		// done
		private bool fFRMDeficitDescription;
		[ColumnMapping("FFRMGoalDescription")]			// done
		private bool fFRMGoalDescription;
		[ColumnMapping("FFRMMeasurementDescription")]	// done
		private bool fFRMMeasurementDescription;
		[ColumnMapping("AssessmentContentOwnerID",StereoType=DataStereoType.FK)]	// done
		private int assessmentContentOwnerID;
		[ColumnMapping("SpellcheckConfigDirectory")]	// done
		private string spellcheckConfigDirectory;
		[ColumnMapping("TimeoutPeriod")]				// done
		private int timeoutPeriod;
		[ColumnMapping("EnableICMMedications")]			// done
		private bool enableICMMedications;
		[ColumnMapping("PasswordLifeTime")]				// done
		private int passwordLifeTime;
		[ColumnMapping("DisplayExistingAssessmentsOnInitialAssessment")]		// no UI
		private bool displayExistingAssessmentsOnInitialAssessment;
		[ColumnMapping("IPCost")]						// done
		private int iPCost;
		[ColumnMapping("OPCost")]						// done
		private int oPCost;
		[ColumnMapping("ImageLibraryPath")]				// done
		private string imageLibraryPath;
		[ColumnMapping("CMReportLetterTemplateID",StereoType=DataStereoType.FK)]	// done
		private int cMReportLetterTemplateID;
		[ColumnMapping("MATReportLetterTemplateID",StereoType=DataStereoType.FK)]	// done
		private int mATReportLetterTemplateID;
		[ColumnMapping("HidePackingListTab")]
		private bool hidePackingListTab;
		[ColumnMapping("HideProviderVendorTab")]
		private bool hideProviderVendorTab;
		[ColumnMapping("ActivityEditLateSetting",StereoType=DataStereoType.FK)]
		private int activityEditLateSetting;
		[ColumnMapping("IsCMTypeRequired")]
		private bool isCMTypeRequired;
		[ColumnMapping("DisplayPRPaymentInfo")]
		private bool displayPRPaymentInfo;
		[ColumnMapping("LOMIProviderLocationID",StereoType=DataStereoType.FK)]
		private int lOMIProviderLocationID;
		[ColumnMapping("LOMIProviderID",StereoType=DataStereoType.FK)]
		private int lOMIProviderID;

		private static SystemControlValue instance = null;
		private static bool isInstanceLoaded = false;
	
		private SystemControlValue()
		{
			this.iD = 1;
		}

		public static SystemControlValue GetInstance
		{
			get
			{			
				if(instance == null)
				{
					instance = new SystemControlValue();
				}
				if(isInstanceLoaded)
					return instance;
				if(instance.Load())
				{
					isInstanceLoaded = true;
					return instance;
				}
				else
					throw new Exception("System Values Record [SystemControlValues] PK[1] is not present.");
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ID
		{
			get { return iD; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string DatabaseVersion
		{
			get { return this.databaseVersion; }
			set { this.databaseVersion = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DatabaseVersionDate
		{
			get { return this.databaseVersionDate; }
			set { this.databaseVersionDate = value; }
		}

		[FieldDescription("@CHECKELIGIBILITY@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool CheckEligibility
		{
			get { return this.checkEligibility; }
			set { this.checkEligibility = value; }
		}

		[FieldDescription("@ELIGIBILITYADDANYWAY@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool EligibilityAddAnyway
		{
			get { return this.eligibilityAddAnyway; }
			set { this.eligibilityAddAnyway = value; }
		}

		[FieldDescription("@DRGTYPE@")]
		[FieldValuesMember("LookupOf_DRGTypeID", "CodeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int DRGTypeID
		{
			get { return this.dRGTypeID; }
			set { this.dRGTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		[FieldDescription("@DRGVERSIONCODE@")]
		public string DRGVersionCode
		{
			get { return this.dRGVersionCode; }
			set { this.dRGVersionCode = value; }
		}

		[FieldDescription("@DRGVERSION@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int DRGVersion
		{
			get { return this.dRGVersion; }
			set { this.dRGVersion = value; }
		}

		[FieldDescription("@LOSREGION@")]
		[FieldValuesMember("LookupOf_LOSRegionID", "HciaRegionid", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int LOSRegionID
		{
			get { return this.lOSRegionID; }
			set { this.lOSRegionID = value; }
		}

		[FieldDescription("@PAYORGROUPID@")]
		[FieldValuesMember("LookupOf_LOSPayorGroupID", "LengthOfStayPayorGroupID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int LOSPayorGroupID
		{
			get { return this.lOSPayorGroupID; }
			set { this.lOSPayorGroupID = value; }
		}

		[FieldDescription("@LOSYEAR@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int LOSYear
		{
			get { return this.lOSYear; }
			set { this.lOSYear = value; }
		}

		[FieldDescription("@GUIDELINESOURCESET@")]
		[FieldValuesMember("LookupOf_GuidelineSourceSetID", "GuidelineSourceSetID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int GuidelineSourceSetID
		{
			get { return this.guidelineSourceSetID; }
			set { this.guidelineSourceSetID = value; }
		}

		[FieldDescription("@CODEFROM@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int MomMinimumAge
		{
			get { return this.momMinimumAge; }
			set { this.momMinimumAge = value; }
		}

		[ValidatorMember("Vld_MomMaximumAge")]
		[FieldDescription("@CODETO@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int MomMaximumAge
		{
			get { return this.momMaximumAge; }
			set { this.momMaximumAge = value; }
		}

		[FieldDescription("@BABY@"+" "+"@MAXIMUM@"+" "+"@AGE@"+" ("+"@MONTHS@"+")")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int BabyMaximumAge
		{
			get { return this.babyMaximumAge; }
			set { this.babyMaximumAge = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool UseGrouper
		{
			get { return this.useGrouper; }
			set { this.useGrouper = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool UseLOSTables
		{
			get { return this.useLOSTables; }
			set { this.useLOSTables = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool CloneBaby
		{
			get { return this.cloneBaby; }
			set { this.cloneBaby = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool AddProviderOnTheFly
		{
			get { return this.addProviderOnTheFly; }
			set { this.addProviderOnTheFly = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool AddFacilityOnTheFly
		{
			get { return this.addFacilityOnTheFly; }
			set { this.addFacilityOnTheFly = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool AddGroupPracticeOnTheFly
		{
			get { return this.addGroupPracticeOnTheFly; }
			set { this.addGroupPracticeOnTheFly = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=200)]
		public string Country
		{
			get { return this.country; }
			set { this.country = value; }
		}

		[FieldValuesMember("LookupOf_EventTypeID", "EventTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int EventTypeID
		{
			get { return this.eventTypeID; }
			set { this.eventTypeID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool AutoCreateProblem1
		{
			get { return this.autoCreateProblem1; }
			set { this.autoCreateProblem1 = value; }
		}

		[FieldValuesMember("LookupOf_Problem1DescriptionID", "CodeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int Problem1DescriptionID
		{
			get { return this.problem1DescriptionID; }
			set { this.problem1DescriptionID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool AutoCreateProblem2
		{
			get { return this.autoCreateProblem2; }
			set { this.autoCreateProblem2 = value; }
		}

		[FieldValuesMember("LookupOf_Problem1DescriptionID", "CodeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int Problem2DescriptionID
		{
			get { return this.problem2DescriptionID; }
			set { this.problem2DescriptionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string ProviderState
		{
			get { return this.providerState; }
			set { this.providerState = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool ShowHints
		{
			get { return this.showHints; }
			set { this.showHints = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string EventActualProjected
		{
			get { return this.eventActualProjected; }
			set { this.eventActualProjected = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int LOSTriggerDays
		{
			get { return this.lOSTriggerDays; }
			set { this.lOSTriggerDays = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ReferralGoodForDays
		{
			get { return this.referralGoodForDays; }
			set { this.referralGoodForDays = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal LOSOutlierPercent
		{
			get { return this.lOSOutlierPercent; }
			set { this.lOSOutlierPercent = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal LOSReviewPercent
		{
			get { return this.lOSReviewPercent; }
			set { this.lOSReviewPercent = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string LivesInputLevel
		{
			get { return this.livesInputLevel; }
			set { this.livesInputLevel = value; }
		}

		[FieldDescription("@REFERRAL@"+" "+"@REASON@"+" "+"@EDITABLE@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool ReferralReasonEditable
		{
			get { return this.referralReasonEditable; }
			set { this.referralReasonEditable = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool EdiHipaaready
		{
			get { return this.ediHipaaready; }
			set { this.ediHipaaready = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int EditLateSetting
		{
			get { return this.editLateSetting; }
			set { this.editLateSetting = value; }
		}

		[FieldDescription("@PROBLEMDESCRIPTION@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool FFRMProblemDescription
		{
			get { return this.fFRMProblemDescription; }
			set { this.fFRMProblemDescription = value; }
		}

		[FieldDescription("@DEFICITDESCR@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool FFRMDeficitDescription
		{
			get { return this.fFRMDeficitDescription; }
			set { this.fFRMDeficitDescription = value; }
		}

		[FieldDescription("@GOALDESC@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool FFRMGoalDescription
		{
			get { return this.fFRMGoalDescription; }
			set { this.fFRMGoalDescription = value; }
		}

		[FieldDescription("@MEASUREMENT@"+" "+"@DESCRIPTION@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool FFRMMeasurementDescription
		{
			get { return this.fFRMMeasurementDescription; }
			set { this.fFRMMeasurementDescription = value; }
		}

		[FieldDescription("@ASSESSMENTCONTENTSOURCE@")]
		[FieldValuesMember("LookupOf_AssessmentContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int AssessmentContentOwnerID
		{
			get { return this.assessmentContentOwnerID; }
			set { this.assessmentContentOwnerID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=500)]
		public string SpellcheckConfigDirectory
		{
			get { return this.spellcheckConfigDirectory; }
			set { this.spellcheckConfigDirectory = value; }
		}

		[FieldDescription("@TIMEOUTPERIOD@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int TimeoutPeriod
		{
			get { return this.timeoutPeriod; }
			set { this.timeoutPeriod = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool EnableICMMedications
		{
			get { return this.enableICMMedications; }
			set { this.enableICMMedications = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PasswordLifeTime
		{
			get { return this.passwordLifeTime; }
			set { this.passwordLifeTime = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool DisplayExistingAssessmentsOnInitialAssessment
		{
			get { return this.displayExistingAssessmentsOnInitialAssessment; }
			set { this.displayExistingAssessmentsOnInitialAssessment = value; }
		}

		[FieldDescription("@INPATIENT@"+" "+"@DEFAULTCOST@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int IPCost
		{
			get { return this.iPCost; }
			set { this.iPCost = value; }
		}

		[FieldDescription("@OUTPATIENT@"+" "+"@DEFAULTCOST@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int OPCost
		{
			get { return this.oPCost; }
			set { this.oPCost = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=500)]
		public string ImageLibraryPath
		{
			get { return this.imageLibraryPath; }
			set { this.imageLibraryPath = value; }
		}

		[FieldDescription("@CASEMANAGEMENTLETTERTEMPLATE@")]
		[FieldValuesMember("LookupOf_CMReportLetterTemplateID", "LetterTemplateID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CMReportLetterTemplateID
		{
			get { return this.cMReportLetterTemplateID; }
			set { this.cMReportLetterTemplateID = value; }
		}

		[FieldDescription("@MATERNICHEKLETTERTEMPLATE@")]
		[FieldValuesMember("LookupOf_MATReportLetterTemplateID", "LetterTemplateID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int MATReportLetterTemplateID
		{
			get { return this.mATReportLetterTemplateID; }
			set { this.mATReportLetterTemplateID = value; }
		}

		[FieldDescription("@HIDEPACKINGLISTTAB@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool HidePackingListTab
		{
			get { return this.hidePackingListTab; }
			set { this.hidePackingListTab = value; }
		}
		
		[FieldDescription("@HIDEPROVIDERVENDORTAB@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool HideProviderVendorTab
		{
			get { return this.hideProviderVendorTab; }
			set { this.hideProviderVendorTab = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ActivityEditLateSetting
		{
			get { return this.activityEditLateSetting; }
			set { this.activityEditLateSetting = value; }
		}
	
		[FieldDescription("@CMTYPEREQUIRED@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool IsCMTypeRequired
		{
			get { return this.isCMTypeRequired; }
			set { this.isCMTypeRequired = value; }
		}

		#region Labels
		[FieldDescription("@MOTHER@"+" "+"@AGE@"+" "+"@RANGE@")]
		private readonly string MomAgeLabel = "";
		#endregion

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		private bool Load()
		{
			bool result = true;
			try
			{
				result = base.Load(iD);
			}
			catch(Exception ex)
			{
				result = false;
			}
			return result;
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();
			SystemControlValue.isInstanceLoaded = false; // forces reload from DB
		}

		#region Lookups
		public DRGTypeCollection LookupOf_DRGTypeID
		{
			get
			{
				return DRGTypeCollection.ActiveDRGTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public GuidelineSourceSetCollection LookupOf_GuidelineSourceSetID
		{
			get
			{
				return GuidelineSourceSetCollection.ActiveGuidelineSourceSets; // Acquire a shared instance from the static member of collection
			}
		}

		public EventTypeCollection LookupOf_EventTypeID
		{
			get
			{
				return EventTypeCollection.ActiveEventTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ProblemDescriptionCollection LookupOf_Problem1DescriptionID
		{
			get
			{
				return ProblemDescriptionCollection.ActiveProblemDescriptions; // Acquire a shared instance from the static member of collection
			}
		}

		public ContentOwnerCollection LookupOf_AssessmentContentOwnerID
		{
			get
			{
				
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
		}

		public LengthOfStayRegionCollection LookupOf_LOSRegionID
		{
			get
			{
				return LengthOfStayRegionCollection.ActiveLengthOfStayRegions; // Acquire a shared instance from the static member of collection
			}
		}

		public LengthOfStayPayorGroupCollection LookupOf_LOSPayorGroupID
		{
			get
			{
				return LengthOfStayPayorGroupCollection.ActiveLengthOfStayPayorGroups; // Acquire a shared instance from the static member of collection
			}
		}

		public LetterTemplateCollection LookupOf_CMReportLetterTemplateID
		{
			get
			{
				LetterTemplate searcher = new LetterTemplate();
				searcher.MatrixTypeID = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCode(MatrixType.CASEMANAGEMENT);
				return LetterTemplateCollection.GetFromSearch(searcher);
			}
		}

		public LetterTemplateCollection LookupOf_MATReportLetterTemplateID
		{
			get
			{
				LetterTemplate searcher = new LetterTemplate();
				searcher.MatrixTypeID = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCode(MatrixType.MATERNICHEK);
				return LetterTemplateCollection.GetFromSearch(searcher);
			}
		}
		#endregion

		
		[GenericScript("Vld_MomMaximumAge", "@MomMaximumAge@ != null && @MomMaximumAge@ > @MomMinimumAge@;")]
		public string Vld_MomMaximumAge
		{
			get
			{
				return "MomMaximumAge must be greater than MomMinimumAge!";
			}
			set
			{}
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool DisplayPRPaymentInfo
		{
			get { return this.displayPRPaymentInfo; }
			set { this.displayPRPaymentInfo = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LOMIProviderLocationID
		{
			get { return this.lOMIProviderLocationID; }
			set { this.lOMIProviderLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LOMIProviderID
		{
			get { return this.lOMIProviderID; }
			set { this.lOMIProviderID = value; }
		}
	}
}
