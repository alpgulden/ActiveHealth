using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NoteTerminationReason]
	/// </summary>
	[TableMapping("NoteTerminationReason","noteTerminationReasonID")]
	public class NoteTerminationReason : BaseLookupStandard
	{
		[ColumnMapping("NoteTerminationReasonID",(int)0)]
		private int noteTerminationReasonID;
	
		public NoteTerminationReason()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NoteTerminationReasonID
		{
			get { return this.noteTerminationReasonID; }
			set { this.noteTerminationReasonID = value; }
		}
	}
}
