using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for BaseFocusType.
	/// </summary>
	// Pseudo table mapping for BaseFocusType, attributes will be overwritten by derived classes.
	[TableMapping("ProviderFocusType","ProviderFocusTypeID")]
	public  class BaseFocusType: NetsoftUSA.DataLayer.BaseDataClass
	{

		[ColumnMapping("FocusCode",ValuesForNull.NullObject)]
		protected string focusCode;
		[ColumnMapping("Focus",ValuesForNull.NullObject)]
		protected string focus;
		[ColumnMapping("Inactive")]
		protected bool inactive;
		[ColumnMapping("Note",ValuesForNull.NullObject)]
		protected string note;

		protected EntityType parentEntity;
		public  EntityType Entity
		{
			get { return this.parentEntity; }
			set { this.parentEntity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=10)]
		public string FocusCode
		{
			get { return this.focusCode; }
			set { this.focusCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=100)]
		public string Focus
		{
			get { return this.focus; }
			set { this.focus = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Inactive
		{
			get 
			{ return this.inactive;
			}
			set { 
				this.inactive = value;
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		public BaseFocusType()
		{
			
		}
	}
}
