using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SpecialyStatus]
	/// </summary>
	[SPInsert("usp_InsertSpecialyStatus")]
	[SPUpdate("usp_UpdateSpecialyStatus")]
	[SPDelete("usp_DeleteSpecialyStatus")]
	[SPLoad("usp_LoadSpecialyStatus")]
	[TableMapping("SpecialyStatus","specialtyStatusID")]
	public class SpecialyStatus : BaseDataClass
	{
		[ColumnMapping("SpecialyStatusDescription")]
		private string specialyStatusDescription;
		[ColumnMapping("SpecialtyStatusID",(int)0)]
		private int specialtyStatusID;
	
		public SpecialyStatus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int SpecialtyStatusID
		{
			get { return this.specialtyStatusID; }
			set { this.specialtyStatusID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=25)]
		public string SpecialyStatusDescription
		{
			get { return this.specialyStatusDescription; }
			set { this.specialyStatusDescription = value; }
		}

		public override SQLDataDirect SqlData
		{
			get
			{
				if (this.sqlData == null)
					this.sqlData = SQLDataDirect.CreateSqlDataForType(typeof(SpecialyStatus));
				return this.sqlData;
			}
			set
			{
				this.sqlData = value;
			}
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Reads multiple objects of this type from source data reader into the given collection
		/// </summary>
		public int ReadCollection(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords, System.Collections.IList collection)
		{
			return SqlData.ReadCollection(sourceReader, maxRecords, collection, typeof(SpecialyStatus), true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int specialtyStatusID)
		{
			return base.Load(specialtyStatusID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int specialtyStatusID)
		{
			base.Delete(specialtyStatusID);		
		}

		/// <summary>
		/// Parent ProviderSpecialty that contains this object
		/// </summary>
		public ProviderSpecialty ParentProviderSpecialty
		{
			get { return this.ParentDataObject as ProviderSpecialty; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ProviderSpecialty */ }
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}
	}
}
