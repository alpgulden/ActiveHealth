using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSCategory]
	/// </summary>
	[SPAutoGen("usp_GetAllCMSCategory","SelectAll.sptpl","")]
	[SPInsert("usp_InsertCMSCategory")]
	[SPUpdate("usp_UpdateCMSCategory")]
	[SPDelete("usp_DeleteCMSCategory")]
	[SPLoad("usp_LoadCMSCategory")]
	[TableMapping("CMSCategory","cMSCategoryID")]
	public class CMSCategory : BaseLookupWithNote
	{
		[NonSerialized]
		private CMSCategoryCollection parentCMSCategoryCollection;
		[ColumnMapping("CMSCategoryID",(int)0)]
		private int cMSCategoryID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public CMSCategory()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CMSCategoryID
		{
			get { return this.cMSCategoryID; }
			set { this.cMSCategoryID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent CMSCategoryCollection that contains this element
		/// </summary>
		public CMSCategoryCollection ParentCMSCategoryCollection
		{
			get
			{
				return this.parentCMSCategoryCollection;
			}
			set
			{
				this.parentCMSCategoryCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int cMSCategoryID)
		{
			return base.Load(cMSCategoryID);
		}
	}

	/// <summary>
	/// Strongly typed collection of CMSCategory objects
	/// </summary>
	[ElementType(typeof(CMSCategory))]
	public class CMSCategoryCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSCategory elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSCategoryCollection = this;
			else
				elem.ParentCMSCategoryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSCategory elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSCategory this[int index]
		{
			get
			{
				return (CMSCategory)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSCategory)oldValue, false);
			SetParentOnElem((CMSCategory)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllCMSCategory", -1, this, false);
		}
	}
}
