using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ActivitySubType]
	/// </summary>
	[SPAutoGen("usp_GetAllActiveSubTypesForType","SelectRelatedFromLinkedTable.sptpl","ActivityTypeSubType, activitySubTypeId, activityTypeId", InjectOrderBy="ORDER BY [ActivitySubType].[Description]")]
	[SPAutoGen("usp_GetAllActivitySubTypesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllActivitySubTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertActivitySubType")]
	[SPUpdate("usp_UpdateActivitySubType")]
	[SPDelete("usp_DeleteActivitySubType")]
	[SPLoad("usp_LoadActivitySubType")]
	[TableMapping("ActivitySubType","activitySubtypeID")]
	public class ActivitySubType : BaseLookupWithNote
	{
		[NonSerialized]
		private ActivitySubTypeCollection parentActivitySubTypeCollection;
		[ColumnMapping("ActivitySubtypeID",StereoType=DataStereoType.FK)]
		private int activitySubtypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
		private ActivityTypeSubTypeCollection activityTypeSubTypes;
	
		public ActivitySubType()
		{

		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ActivitySubtypeID
		{
			get { return this.activitySubtypeID; }
			set { this.activitySubtypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int activitySubtypeID)
		{
			return base.Load(activitySubtypeID);
		}

		/// <summary>
		/// Parent ActivitySubTypeCollection that contains this element
		/// </summary>
		public override BaseTypeCollection ParentBaseTypeCollection
		{
			get
			{
				return this.parentActivitySubTypeCollection;
			}
			set
			{
				this.parentActivitySubTypeCollection = (ActivitySubTypeCollection)value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child ActivityTypeSubTypes mapped to related rows of table ActivityTypeSubType where [ActivitySubtypeID] = [ActivitySubTypeId]
		/// </summary>
		[SPLoadChild("usp_LoadActivitySubTypeActivityTypeSubType", "ActivitySubTypeId")]
		public override BaseDataCollectionClass BracketCodeTableChilderen
		{
			get { return this.activityTypeSubTypes; }
			set
			{
				this.activityTypeSubTypes = (ActivityTypeSubTypeCollection)value;
				if (value != null)
					((ActivityTypeSubTypeCollection)value).ParentActivitySubType= this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ActivityTypeSubTypes collection
		/// </summary>
		public override void LoadBracketCodeTableChilderen(bool forceReload)
		{
			this.activityTypeSubTypes = (ActivityTypeSubTypeCollection)ActivityTypeSubTypeCollection.LoadChildCollection("BracketCodeTableChilderen", this, typeof(ActivityTypeSubTypeCollection), activityTypeSubTypes, forceReload, null);
		}

		/// <summary>
		/// Saves the ActivityTypeSubTypes collection
		/// </summary>
		public override void SaveBracketCodeTableChilderen()
		{
			ActivityTypeSubTypeCollection.SaveChildCollection(this.activityTypeSubTypes, true);
		}

		/// <summary>
		/// Synchronizes the ActivityTypeSubTypes collection
		/// </summary>
		public override void SynchronizeBracketCodeTableChilderen()
		{
			ActivityTypeSubTypeCollection.SynchronizeChildCollection(this.activityTypeSubTypes, true);
		}
	}

	/// <summary>
	/// Strongly typed collection of ActivitySubType objects
	/// </summary>
	[ElementType(typeof(ActivitySubType))]
	public class ActivitySubTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ActivitySubtypeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ActivitySubType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentBaseTypeCollection = this;
			else
				elem.ParentBaseTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ActivitySubType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ActivitySubType this[int index]
		{
			get
			{
				return (ActivitySubType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ActivitySubType)oldValue, false);
			SetParentOnElem((ActivitySubType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllActivitySubTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllActivitySubTypesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared ActivitySubTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ActivitySubTypeCollection ActiveActivitySubTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ActivitySubTypeCollection col = (ActivitySubTypeCollection)NSGlobal.EnsureCachedObject("ActiveActivitySubTypes", typeof(ActivitySubTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllActivitySubTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Load the active subtypes for the given activity type.
		/// </summary>
		public int LoadAllActiveSubTypesForType(int activityTypeId, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllActiveSubTypesForType", -1, this, false, new object[] { activityTypeId});
		}
		
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllActivitySubTypes", -1, this, false);
		}

		public override void SynchronizeCollection(BaseTypeCollection col)
		{	
			foreach (ActivitySubType activitySubTypeitem in this)
				activitySubTypeitem.IsMarkedForDeletion=false;

			foreach (ActivityTypeSubType item in (ActivityTypeSubTypeCollection)col)
			{
				ActivitySubType activitySubType = this.FindBy(item.ActivitySubTypeId);
				if (activitySubType != null && !item.IsMarkedForDeletion)
					activitySubType.IsMarkedForDeletion= true;
			}
		}

		/// <summary>
		/// Hashtable based index on activitySubtypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ActivitySubtypeID
		{
			get
			{
				if (this.indexBy_ActivitySubtypeID == null)
					this.indexBy_ActivitySubtypeID = new CollectionIndexer(this, new string[] { "activitySubtypeID" }, true);
				return this.indexBy_ActivitySubtypeID;
			}			
		}

		/// <summary>
		/// Hashtable based search on activitySubtypeID fields returns the object.  Uses the IndexBy_ActivitySubtypeID indexer.
		/// </summary>
		public ActivitySubType FindBy(int activitySubtypeID)
		{
			return (ActivitySubType)this.IndexBy_ActivitySubtypeID.GetObject(activitySubtypeID);
		}
	}
}
