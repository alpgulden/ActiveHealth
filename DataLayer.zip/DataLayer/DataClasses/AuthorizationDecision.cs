using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [AuthorizationDecisions]
	/// </summary>
	
	[SPAutoGen("usp_GetAuthorizationDecisionsByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllAuthorizationDecisions","SelectAll.sptpl","active")]
	[SPInsert("usp_InsertAuthorizationDecision")]
	[SPUpdate("usp_UpdateAuthorizationDecision")]
	[SPDelete("usp_DeleteAuthorizationDecision")]
	[SPLoad("usp_LoadAuthorizationDecision")]
	[TableMapping("AuthorizationDecision","authorizationDecisionId")]
	public class AuthorizationDecision 
	{
		[NonSerialized]
		private AuthorizationDecisionCollection parentAuthorizationDecisionCollection;
		[ColumnMapping("AuthorizationDecisionId",StereoType=DataStereoType.FK)]
		private int authorizationDecisionId;
	
		public AuthorizationDecision()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int AuthorizationDecisionId
		{
			get { return this.authorizationDecisionId; }
			set { this.authorizationDecisionId = value; }
		}

		/// <summary>
		/// Parent AuthorizationDecisionCollection that contains this element
		/// </summary>
		public AuthorizationDecisionCollection ParentAuthorizationDecisionCollection
		{
			get
			{
				return this.parentAuthorizationDecisionCollection;
			}
			set
			{
				this.parentAuthorizationDecisionCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of AuthorizationDecision objects
	/// </summary>
	[ElementType(typeof(AuthorizationDecision))]
	public class AuthorizationDecisionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AuthorizationDecision elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAuthorizationDecisionCollection = this;
			else
				elem.ParentAuthorizationDecisionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AuthorizationDecision elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AuthorizationDecision this[int index]
		{
			get
			{
				return (AuthorizationDecision)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AuthorizationDecision)oldValue, false);
			SetParentOnElem((AuthorizationDecision)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAuthorizationDecisionByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAuthorizationDecisionsByActive", maxRecords, this, false,  new object [] { active });
		}

		/// <summary>
		/// Accessor to a shared ReferralTypeCollection which is cached in NSGlobal
		/// </summary>
		public static AuthorizationDecisionCollection ActiveAuthorizationDecision
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				AuthorizationDecisionCollection col = (AuthorizationDecisionCollection)NSGlobal.EnsureCachedObject("ActiveAuthorizationDecision", typeof(AuthorizationDecisionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					//col.GetFacilityFocusTypesByActive(-1, true);
					col.LoadAuthorizationDecisionByActive(-1, true);
				}
				return col;
			}			
		}
	}
}
