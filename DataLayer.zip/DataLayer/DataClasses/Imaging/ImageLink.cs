using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ImageLink]
	/// </summary>
	
	[SPAutoGen("usp_GetActiveImageLinksByPRId","SelectAllByGivenArgs.sptpl","patientID, pRRequestID, active")]
	[SPAutoGen("usp_GetActiveImageLinksByCMSId","SelectAllByGivenArgs.sptpl","patientID, cMSID, active")]
	[SPAutoGen("usp_GetActiveImageLinksByReferralId","SelectAllByGivenArgs.sptpl","patientID, referralID, active")]
	[SPAutoGen("usp_GetActiveImageLinksByEventId","SelectAllByGivenArgs.sptpl","patientID, eventID, active")]
	[SPAutoGen("usp_GetActiveImageLinksByPatientId","SelectAllByGivenArgs.sptpl","patientID, active")]
	[SPAutoGen("usp_GetImageLinksByImageId","SelectAllByGivenArgs.sptpl","imageBaseID, patientID")]
	[SPAutoGen("usp_GetImageLinksByPRId","SelectAllByGivenArgs.sptpl","patientID, pRRequestID")]
	[SPAutoGen("usp_GetImageLinksByCMSId","SelectAllByGivenArgs.sptpl","patientID, cMSID,active")]	
	[SPAutoGen("usp_GetImageLinksByReferralId","SelectAllByGivenArgs.sptpl","patientID, referralID")]
	[SPAutoGen("usp_GetImageLinksByEventId","SelectAllByGivenArgs.sptpl","patientID, eventID")]
	[SPAutoGen("usp_GetImageLinksByPatientId","SelectAllByGivenArgs.sptpl","patientID")]

	[SPInsert("usp_InsertImageLink")]
	[SPUpdate("usp_UpdateImageLink")]
	[SPDelete("usp_DeleteImageLink")]
	[SPLoad("usp_LoadImageLink")]
	[TableMapping("ImageLink","imageLinkID")]
	public class ImageLink : BaseData
	{
		[NonSerialized]
		private ImageLinkCollection parentImageLinkCollection;
		[ColumnMapping("ImageLinkID",(int)0)]
		private int imageLinkID;
		[ColumnMapping("EventID",(int)0)]
		private int eventID;
		[ColumnMapping("PatientID",(int)0)]
		private int patientID;
		[ColumnMapping("CMSID",(int)0)]
		private int cMSID;
		[ColumnMapping("ImageBaseID",(int)0)]
		private int imageBaseID;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",(int)0)]
		private int modifiedBy;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("ReferralID",(int)0)]
		private int referralID;
		[ColumnMapping("PRRequestID",(int)0)]
		private int pRRequestID;
		[ColumnMapping("SortOrder")]
		private int sortOrder;
	
		private ImageBase parentImageBase;
		private Patient parentPatient;
		private PRRequest parentPRRequest;
		private Event parentEvent;
		private Referral parentReferral;
		private CMS parentCMS;

		public ImageLink()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ImageLink(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public ImageLink(bool initNew,int ImageBaseID, int patientID)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();			
			this.ImageBaseID = ImageBaseID;
			this.PatientID = patientID;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ImageLinkID
		{
			get { return this.imageLinkID; }
			set { this.imageLinkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ImageBaseID
		{
			get { return this.imageBaseID; }
			set { this.imageBaseID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PRRequestID
		{
			get { return this.pRRequestID; }
			set { this.pRRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		public int IDOfLink
		{
			get
			{
				if(this.ParentPRRequest!=null)
					return this.pRRequestID;
				else if(this.ParentEvent!=null)
					return this.eventID;
				else if(this.ParentReferral!=null)
					return this.referralID;
				else 
					return this.cMSID;
			}
		}

		public string NameOfLink
		{
			get
			{
				if(this.ParentPRRequest!=null)
					return "Physician Review Request";
				else if(this.ParentEvent!=null)
					return "Event";
				else if(this.ParentReferral!=null)
					return "Referral";
				else 
					return "CMS";
			}
		}

		public string Description
		{
			get{return this.ParentImageBase.Description; }
		}

		public string DescriptionOfLink
		{
			get{
				if(this.ParentPRRequest!=null)
					return this.DescriptionOfPRRequest;
				else if(this.ParentEvent!=null)
					return this.DescriptionOfEvent;
				else if(this.ParentReferral!=null)
					return this.DescriptionOfReferral;
				else 
					return this.DescriptionOfCMS;
			}
		}

		public string DescriptionOfPRRequest
		{
			// need to get description. 
			get{return this.ParentPRRequest.PRRequestID.ToString(); }
		}

		public string DescriptionOfEvent
		{
			get{return this.ParentEvent.ERCDescription; }
		}

		public string DescriptionOfReferral
		{
			get{return this.ParentReferral.ERCDescription; }
		}

		public string DescriptionOfCMS
		{
			get{return this.ParentCMS.ERCDescription; }
		}

		public ImageBase ParentImageBase
		{
			get 
			{ 
				if (this.parentImageBase == null)
					this.parentImageBase = GetParentImageBase();
				return this.parentImageBase;
			}
		}

		public Patient ParentPatient
		{
			get 
			{ 
				if (this.parentPatient == null)
					this.parentPatient= GetParentPatient();
				return this.parentPatient;
			}
		}

		public PRRequest ParentPRRequest
		{
			get 
			{ 
				if (this.parentPRRequest == null)
					this.parentPRRequest = GetParentPRRequest();
				return this.parentPRRequest;
			}
		}

		public Event ParentEvent
		{
			get 
			{ 
				if (this.parentEvent == null)
					this.parentEvent = GetParentEvent();
				return this.parentEvent;
			}
		}

		public Referral ParentReferral
		{
			get 
			{ 
				if (this.parentReferral == null)
					this.parentReferral = GetParentReferral();
				return this.parentReferral;
			}
		}

		public CMS ParentCMS
		{
			get 
			{ 
				if (this.parentCMS == null)
					this.parentCMS = GetParentCMS();
				return this.parentCMS;
			}
		}

		public ImageBase GetParentImageBase()
		{
			if (this.imageBaseID == 0)
				return null;
			else
			{
				ImageBase img = new ImageBase();
				if (img.Load(this.imageBaseID))
					return img;
				else
					return null;
			}
		}

		public Patient GetParentPatient()
		{
			if (this.patientID == 0)
				return null;
			else
			{
				Patient patient = new Patient();
				if (patient.Load(this.patientID))
					return patient;
				else
					return null;
			}
		}

		public PRRequest GetParentPRRequest()
		{
			if (this.pRRequestID == 0)
				return null;
			else
			{
				PRRequest prr = new PRRequest();
				if (prr.Load(this.pRRequestID))
					return prr;
				else
					return null;
			}
		}

		public Event GetParentEvent()
		{
			if (this.eventID == 0)
				return null;
			else
			{
				Event e = new Event();
				if (e.Load(this.ParentPatient,this.eventID))
					return e;
				else
					return null;
			}
		}

		public Referral GetParentReferral()
		{
			if (this.referralID == 0)
				return null;
			else
			{
				Referral refe = new Referral();
				if (refe.Load(this.referralID))
					return refe;
				else
					return null;
			}
		}

		public CMS GetParentCMS()
		{
			if (this.cMSID == 0)
				return null;
			else
			{
				CMS cms = new CMS();
				if (cms.Load(this.cMSID))
					return cms;
				else
					return null;
			}
		}


		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Parent ImageLinkCollection that contains this element
		/// </summary>
		public ImageLinkCollection ParentImageLinkCollection
		{
			get
			{
				return this.parentImageLinkCollection;
			}
			set
			{
				this.parentImageLinkCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int imageLinkID)
		{
			return base.Load(imageLinkID);
		}
	}

	/// <summary>
	/// Strongly typed collection of ImageLink objects
	/// </summary>
	[ElementType(typeof(ImageLink))]
	public class ImageLinkCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ImageBaseID_ReferralID;
		[NonSerialized]
		private CollectionIndexer indexBy_ImageBaseID_CMSID;
		[NonSerialized]
		private CollectionIndexer indexBy_ImageBaseID_EventID;
		[NonSerialized]
		private CollectionIndexer indexBy_ImageBaseID_PatientID;
		[NonSerialized]
		private CollectionIndexer indexBy_ImageBaseID_PRRequestID;
		/// <summary>
		/// Parent Image that contains this collection
		/// </summary>
		public ImageBase ParentImageBase
		{
			get { return this.ParentDataObject as ImageBase; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Image */ }
		}
	
		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Event ParentEvent
		{
			get { return this.ParentDataObject as Event; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}

			/// <summary>
			/// Parent Referral that contains this collection
			/// </summary>
			public Referral ParentReferral
		{
			get { return this.ParentDataObject as Referral; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Referral */ }
		}

			/// <summary>
			/// Parent CMS that contains this collection
			/// </summary>
			public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}

		/// <summary>
		/// Parent PRRequest that contains this collection
		/// </summary>
		public PRRequest ParentPRRequest
		{
			get { return this.ParentDataObject as PRRequest; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PRRequest */ }
		}

		/// <summary>
		/// Parent Patient that contains this collection
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.ParentDataObject as Patient; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ImageLink elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentImageLinkCollection = this;
			else
				elem.ParentImageLinkCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ImageLink elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ImageLink this[int index]
		{
			get
			{
				return (ImageLink)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ImageLink)oldValue, false);
			SetParentOnElem((ImageLink)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadImageLinksByPatientId(int maxRecords, int patientID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetImageLinksByPatientId", maxRecords, this, false, new object[] { patientID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadImageLinksByEventId(int maxRecords, int patientID, int eventID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetImageLinksByEventId", maxRecords, this, false, new object[] { patientID, eventID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadImageLinksByReferralId(int maxRecords, int patientID, int referralID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetImageLinksByReferralId", maxRecords, this, false, new object[] { patientID, referralID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadImageLinksByCMSId(int maxRecords, int patientID, int cMSID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetImageLinksByCMSId", maxRecords, this, false, new object[] { patientID, cMSID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadImageLinksByPRRId(int maxRecords, int patientID, int pRRequestID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetImageLinksByPRRId", maxRecords, this, false, new object[] { patientID, pRRequestID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadImageLinksByImageId(int maxRecords, int imageBaseID,int patientID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetImageLinksByImageId", maxRecords, this, false, new object[] { imageBaseID ,patientID});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveImageLinksByPatientId(int maxRecords, int patientID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveImageLinksByPatientId", maxRecords, this, false, new object[] { patientID, true });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveImageLinksByEventId(int maxRecords, int patientID, int eventID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveImageLinksByEventId", maxRecords, this, false, new object[] { patientID, eventID ,true});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveImageLinksByReferralId(int maxRecords, int patientID, int referralID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveImageLinksByReferralId", maxRecords, this, false, new object[] { patientID, referralID ,true});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveImageLinksByCMSId(int maxRecords, int patientID, int cMSID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveImageLinksByCMSId", maxRecords, this, false, new object[] { patientID, cMSID ,true});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveImageLinksByPRRId(int maxRecords, int patientID, int pRRequestID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveImageLinksByPRId", maxRecords, this, false, new object[] { patientID, pRRequestID, true });
		}

		/// <summary>
		/// Hashtable based index on imageBaseID, pRRequestID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ImageBaseID_PRRequestID
		{
			get
			{
				if (this.indexBy_ImageBaseID_PRRequestID == null)
					this.indexBy_ImageBaseID_PRRequestID = new CollectionIndexer(this, new string[] { "imageBaseID", "pRRequestID" }, true);
				return this.indexBy_ImageBaseID_PRRequestID;
			}			
		}

		/// <summary>
		/// Hashtable based index on imageBaseID, patientID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ImageBaseID_PatientID
		{
			get
			{
				if (this.indexBy_ImageBaseID_PatientID == null)
					this.indexBy_ImageBaseID_PatientID = new CollectionIndexer(this, new string[] { "imageBaseID", "patientID" }, true);
				return this.indexBy_ImageBaseID_PatientID;
			}			
		}

		/// <summary>
		/// Hashtable based index on imageBaseID, eventID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ImageBaseID_EventID
		{
			get
			{
				if (this.indexBy_ImageBaseID_EventID == null)
					this.indexBy_ImageBaseID_EventID = new CollectionIndexer(this, new string[] { "imageBaseID", "eventID" }, true);
				return this.indexBy_ImageBaseID_EventID;
			}			
		}

		/// <summary>
		/// Hashtable based index on imageBaseID, cMSID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ImageBaseID_CMSID
		{
			get
			{
				if (this.indexBy_ImageBaseID_CMSID == null)
					this.indexBy_ImageBaseID_CMSID = new CollectionIndexer(this, new string[] { "imageBaseID", "cMSID" }, true);
				return this.indexBy_ImageBaseID_CMSID;
			}			
		}

		/// <summary>
		/// Hashtable based index on imageBaseID, referralID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ImageBaseID_ReferralID
		{
			get
			{
				if (this.indexBy_ImageBaseID_ReferralID == null)
					this.indexBy_ImageBaseID_ReferralID = new CollectionIndexer(this, new string[] { "imageBaseID", "referralID" }, true);
				return this.indexBy_ImageBaseID_ReferralID;
			}			
		}

		/// <summary>
		/// Hashtable based search on imageBaseID, pRRequestID fields returns the object.  Uses the IndexBy_ImageBaseID_PRRequestID indexer.
		/// </summary>
		public ImageLink FindBy(int imageBaseID, int ID,int indicator)
		{
			switch(indicator)
			{
				case 1:
					return (ImageLink)this.IndexBy_ImageBaseID_PatientID.GetObject(imageBaseID, ID);
					break;
				case 2:
					return (ImageLink)this.IndexBy_ImageBaseID_EventID.GetObject(imageBaseID, ID);
					break;
				case 3:
					return (ImageLink)this.IndexBy_ImageBaseID_CMSID.GetObject(imageBaseID, ID);					
					break;
				case 4:					
					return (ImageLink)this.IndexBy_ImageBaseID_ReferralID.GetObject(imageBaseID, ID);
					break;
				case 5:
					return (ImageLink)this.IndexBy_ImageBaseID_PRRequestID.GetObject(imageBaseID, ID);					
					break;
			}
			return null;
		}

	}
}
