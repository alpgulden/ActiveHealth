using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Image]
	/// </summary>
	[SPInsert("usp_InsertImage")]
	[SPUpdate("usp_UpdateImage")]
	[SPDelete("usp_DeleteImage")]
	[SPLoad("usp_LoadImage")]
	[TableMapping("Image","imageID")]
	public class Image : BaseData
	{
		[ColumnMapping("ImageID",(int)0)]
		private int imageID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("ImageByte")]
		private Byte[] imageByte;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		private ImageLinkCollection imageLinks;
	
		public Image()
		{
		}
		
		public Image(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ImageID
		{
			get { return this.imageID; }
			set { this.imageID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}


		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Child ImageLinks mapped to related rows of table ImageLink where [ImageID] = [ImageID]
		/// </summary>
		[SPLoadChild("usp_LoadImageImageLink", "imageID")]
		public ImageLinkCollection ImageLinks
		{
			get { return this.imageLinks; }
			set
			{
				this.imageLinks = value;
				if (value != null)
					value.ParentImage = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ImageLinks collection
		/// </summary>
		public void LoadImageLinks(bool forceReload)
		{
			this.imageLinks = (ImageLinkCollection)ImageLinkCollection.LoadChildCollection("ImageLinks", this, typeof(ImageLinkCollection), imageLinks, forceReload, null);
		}

		/// <summary>
		/// Saves the ImageLinks collection
		/// </summary>
		public void SaveImageLinks()
		{
			ImageLinkCollection.SaveChildCollection(this.imageLinks, true);
		}

		/// <summary>
		/// Synchronizes the ImageLinks collection
		/// </summary>
		public void SynchronizeImageLinks()
		{
			ImageLinkCollection.SynchronizeChildCollection(this.imageLinks, true);
		}

		public byte[] ImageByte
		{
			get { return this.imageByte; }
			set { this.imageByte = value; }
		}
	}
}
