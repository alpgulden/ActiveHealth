using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [AssessmentScoringQuestionnaireTrigger]
	/// ManuallyManaged=true
	/// [SPAutoGen("usp_SearchAssmtScoringQRTriggers","SearchByArgs.sptpl","activeWithAll:active, questionnaireID, cMSTypeID, componentID, attributeID, valueID, createdBy")]
	/// [SPAutoGen("usp_GetAllAssmtScoringQRTriggers","SelectAll.sptpl","")]
	/// above store procs using following code in addition to standartly generated one:
	/// 
	/// -- join columns
	/// [Questionnaire].[Description] as QuestionnaireDescription, [contentowner].[Description] as ContentOwnerDescription FROM [AssessmentScoringQuestionnaireTrigger]
	/// LEFT JOIN [Questionnaire] ON AssessmentScoringQuestionnaireTrigger.QuestionnaireID = [Questionnaire].QuestionnaireID
	/// LEFT JOIN [contentowner] ON [Questionnaire].ContentOwnerID = [contentowner].ContentOwnerID
	///	
	/// </summary>
	[SPAutoGen("usp_SearchAssmtScoringQRTriggers", "SearchByArgs.sptpl", ManuallyManaged=true)]
	[SPAutoGen("usp_GetAllAssmtScoringQRTriggers", "SelectAll.sptpl", ManuallyManaged=true)]
	[SPInsert("usp_InsertAssessmentScoringQuestionnaireTrigger")]
	[SPUpdate("usp_UpdateAssessmentScoringQuestionnaireTrigger")]
	[SPDelete("usp_DeleteAssessmentScoringQuestionnaireTrigger")]
	[SPLoad("usp_LoadAssessmentScoringQuestionnaireTrigger")]
	[TableMapping("AssessmentScoringQuestionnaireTrigger","assessmentScoringQuestionnaireTriggerID")]
	public class AssessmentScoringQuestionnaireTrigger : BaseAssessment
	{
		[NonSerialized]
		private AssessmentScoringQuestionnaireTriggerCollection parentAssessmentScoringQuestionnaireTriggerCollection;
		[ColumnMapping("AssessmentScoringQuestionnaireTriggerID",(int)0)]
		private int assessmentScoringQuestionnaireTriggerID;
		[ColumnMapping("QuestionnaireID",StereoType=DataStereoType.FK)]
		private int questionnaireID;
		[ColumnMapping("CMSTypeID",StereoType=DataStereoType.FK)]
		private int cMSTypeID;
		[ColumnMapping("ComponentID",StereoType=DataStereoType.FK)]
		private int componentID;
		[ColumnMapping("AttributeID",StereoType=DataStereoType.FK)]
		private int attributeID;
		[ColumnMapping("ValueID",StereoType=DataStereoType.FK)]
		private int valueID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;


		[ColumnMapping("QuestionnaireDescription", JoinColumn="Description", JoinRelation="AssessmentScoringQuestionnaireTrigger.QuestionnaireID = [Questionnaire].QuestionnaireID", SQLGen=SQLGenerationFlags.NoInsertUpdate)]
		private string questionnaireDescription;

		[ColumnMapping("ContentOwnerDescription", JoinColumn="Description", JoinRelation="[Questionnaire].ContentOwnerID = [contentowner].ContentOwnerID", SQLGen=SQLGenerationFlags.NoInsertUpdate)]
		private string contentOwnerDescription;
	
		public AssessmentScoringQuestionnaireTrigger()
		{
		}

		public AssessmentScoringQuestionnaireTrigger(bool initNew)
		{
			if (initNew)// initialize record if requested
			{
				this.NewRecord();
				this.active = true;
			}
		}
		
		public AssessmentScoringQuestionnaireTrigger(Questionnaire questionnaire)
		{
			this.NewRecord();
			this.active = true;
			this.questionnaireID = questionnaire.QuestionnaireID;
			this.cMSTypeID = questionnaire.CMSTypeID;
		}
		
		public AssessmentScoringQuestionnaireTrigger(Questionnaire questionnaire, int componentID, int attributeID, int valueID)
		{
			this.NewRecord();
			this.active = true;
			this.questionnaireID = questionnaire.QuestionnaireID;
			this.cMSTypeID = questionnaire.CMSTypeID;
			this.componentID = componentID;
			this.attributeID = attributeID;
			this.valueID = valueID;
		}

		[FieldDescription("@ID@")]
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int AssessmentScoringQuestionnaireTriggerID
		{
			get { return this.assessmentScoringQuestionnaireTriggerID; }
			set { this.assessmentScoringQuestionnaireTriggerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)0)]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value;	}
		}

		#region Joined Collumns
		[ControlType(EnumControlTypes.TextBox, ValueForNull="")]
		public string QuestionnaireDescription
		{
			get { return this.questionnaireDescription; }
		}

		[FieldDescription("@CONTENTOWNER@")]
		[ControlType(EnumControlTypes.TextBox, ValueForNull="")]
		public string ContentOwnerDescription
		{
			get { return this.contentOwnerDescription; }
		}
		#endregion

		[FieldDescription("@CMSTYPE@")]
		[FieldValuesMember("LookupOf_CMSTypeID", "CMSTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int CMSTypeID
		{
			get { return this.cMSTypeID; }
			//set { this.cMSTypeID = value; }
		}

		[FieldValuesMember("LookupOf_ComponentID", "ScoringLoadComponentID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int ComponentID
		{
			get { return this.componentID; }
			set { this.componentID = value; }
		}

		[FieldValuesMember("LookupOf_AttributeID", "ScoringLoadAttributeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int AttributeID
		{
			get { return this.attributeID; }
			set { this.attributeID = value; }
		}

		[FieldDescription("@VALUE@")]
		[FieldValuesMember("LookupOf_ValueID", "ScoringLoadValueID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ValueID
		{
			get { return this.valueID; }
			set { this.valueID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set 
			{ 
				this.active = value; 
				if(this.active)
				{
					this.terminateTime = DateTime.MinValue;
					this.terminatedBy = 0;
				}
			}
		}

		[FieldValuesMember("LookupOf_TerminatedBy", "UserId", "LoginName")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[FieldDescription("@TERMINATEDBY@")]
		[ControlType(EnumControlTypes.TextBox)]
		public string TerminatedByName
		{
			get { return FormatUserForDisplay(this.terminatedBy); }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				if(this.questionnaireID > 0)
				{
					Questionnaire q = new Questionnaire();
					if(q.Load(this.questionnaireID))
						this.cMSTypeID = q.CMSTypeID;
					else
						throw new ActiveAdviceException(AAExceptionAction.DisableUI, "A Questionnaire with ID " + this.questionnaireID + " doesn not exist");
				}
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent AssessmentScoringQuestionnaireTriggerCollection that contains this element
		/// </summary>
		public AssessmentScoringQuestionnaireTriggerCollection ParentAssessmentScoringQuestionnaireTriggerCollection
		{
			get
			{
				return this.parentAssessmentScoringQuestionnaireTriggerCollection;
			}
			set
			{
				this.parentAssessmentScoringQuestionnaireTriggerCollection = value; // parent is set when added to a collection
			}
		}

		public void SetTerminatingUser()
		{
			this.SetTerminatingUser();
		}

		#region Lookups
		public ScoringLoadComponentCollection LookupOf_ComponentID
		{
			get
			{
				return ScoringLoadComponentCollection.ActiveScoringLoadComponents; // Acquire a shared instance from the static member of collection
			}
		}

		public ScoringLoadAttributeCollection LookupOf_AttributeID
		{
			get
			{
				return ScoringLoadAttributeCollection.ActiveScoringLoadAttributes; // Acquire a shared instance from the static member of collection
			}
		}

		public ScoringLoadValueCollection LookupOf_ValueID
		{
			get
			{
				return ScoringLoadValueCollection.ActiveScoringLoadValues; // Acquire a shared instance from the static member of collection
			}
		}

		public CMSTypeCollection LookupOf_CMSTypeID
		{
			get
			{
				return CMSTypeCollection.ActiveCMSTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public AAUserCollection LookupOf_TerminatedBy
		{
			get
			{
				return AAUserCollection.AllUsers; // Acquire a shared instance from the static member of collection
			}
			set
			{}
		}
		#endregion
	}

	/// <summary>
	/// Strongly typed collection of AssessmentScoringQuestionnaireTrigger objects
	/// </summary>
	[ElementType(typeof(AssessmentScoringQuestionnaireTrigger))]
	public class AssessmentScoringQuestionnaireTriggerCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_QuestionnaireID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AssessmentScoringQuestionnaireTrigger elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAssessmentScoringQuestionnaireTriggerCollection = this;
			else
				elem.ParentAssessmentScoringQuestionnaireTriggerCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AssessmentScoringQuestionnaireTrigger elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AssessmentScoringQuestionnaireTrigger this[int index]
		{
			get
			{
				return (AssessmentScoringQuestionnaireTrigger)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AssessmentScoringQuestionnaireTrigger)oldValue, false);
			SetParentOnElem((AssessmentScoringQuestionnaireTrigger)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(AssessmentScoringQuestionnaireTrigger elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((AssessmentScoringQuestionnaireTrigger)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(AssessmentScoringQuestionnaireTrigger elem)
		{
			//RemoveRecord(elem);		
			elem.Active = false;
			elem.SetTerminatingUser();
			
		}

		#region AllAssessmentScoringQuestionnaireTriggers
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadAllAssmtScoringQRTriggers(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllAssmtScoringQRTriggers", maxRecords, this, false);
		}

		public static AssessmentScoringQuestionnaireTriggerCollection AllAssessmentScoringQuestionnaireTriggers()
		{
			AssessmentScoringQuestionnaireTriggerCollection col = new AssessmentScoringQuestionnaireTriggerCollection();
			col.LoadAllAssmtScoringQRTriggers(-1);
			return col;
		}
		#endregion

		#region GetFromSearch
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchAssmtScoringQRTriggers(int maxRecords, AssessmentScoringQuestionnaireTrigger searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchAssmtScoringQRTriggers", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}

		public static AssessmentScoringQuestionnaireTriggerCollection GetFromSearch(AssessmentScoringQuestionnaireTrigger searcher)
		{
			AssessmentScoringQuestionnaireTriggerCollection col = new AssessmentScoringQuestionnaireTriggerCollection();
			col.SearchAssmtScoringQRTriggers(-1, searcher);
			return col;
		}
		#endregion

		/// <summary>
		/// Hashtable based index on questionnaireID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionnaireID
		{
			get
			{
				if (this.indexBy_QuestionnaireID == null)
					this.indexBy_QuestionnaireID = new CollectionIndexer(this, new string[] { "questionnaireID" }, true);
				return this.indexBy_QuestionnaireID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on questionnaireID fields returns the object.  Uses the IndexBy_QuestionnaireID indexer.
		/// </summary>
		public AssessmentScoringQuestionnaireTrigger FindBy(int questionnaireID)
		{
			return (AssessmentScoringQuestionnaireTrigger)this.IndexBy_QuestionnaireID.GetObject(questionnaireID);
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

//		public void SynchronizeFromSelectableCollection(QuestionnaireCollection questionnaires, int componentID, int attributeID, int valueID)
//		{
//			AssessmentScoringQuestionnaireTrigger existingTrigger = null;
//			this.indexBy_QuestionnaireID.Rebuild();
//
//			foreach(Questionnaire questionnaire in questionnaires)
//			{
//				existingTrigger = this.FindBy(questionnaire.QuestionnaireID);
//
//				if (((SelectableQuestionnaire)questionnaire).Selected)
//				{
//					if(existingTrigger == null)
//					{	// Selected Questionnaire is not linked to this - Adding
//						AssessmentScoringQuestionnaireTrigger elemToAdd = new AssessmentScoringQuestionnaireTrigger(questionnaire, componentID, attributeID, valueID);
//						this.Add(elemToAdd);
//					}
//					else if(!existingTrigger.Active) //
//						existingTrigger.Active = true;
//				}
//				else if(!((SelectableQuestionnaire)questionnaire).Selected)
//				{
//					if(existingTrigger != null)
//						// Selected Questionnare is linked to this - Inactivating
//						this.Remove(existingTrigger);
//				}
//				existingTrigger = null;
//			}// end of foreach in questionnaires
//		}

	}
}
