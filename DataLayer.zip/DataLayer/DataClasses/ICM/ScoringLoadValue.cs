using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ScoringLoadValue]
	/// </summary>
	[SPAutoGen("usp_GetAllScoringLoadValuesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllScoringLoadValues","SelectAll.sptpl","")]
	[SPInsert("usp_InsertScoringLoadValue")]
	[SPUpdate("usp_UpdateScoringLoadValue")]
	[SPDelete("usp_DeleteScoringLoadValue")]
	[SPLoad("usp_LoadScoringLoadValue")]
	[TableMapping("ScoringLoadValue","scoringLoadValueID")]
	public class ScoringLoadValue : BaseLookupWithNote
	{
		[NonSerialized]
		private ScoringLoadValueCollection parentScoringLoadValueCollection;
		[ColumnMapping("ScoringLoadValueID",(int)0)]
		private int scoringLoadValueID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ScoringLoadValue()
		{
		}

		public ScoringLoadValue(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ScoringLoadValueID
		{
			get { return this.scoringLoadValueID; }
			set { this.scoringLoadValueID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		} 

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent ScoringLoadValueCollection that contains this element
		/// </summary>
		public ScoringLoadValueCollection ParentScoringLoadValueCollection
		{
			get
			{
				return this.parentScoringLoadValueCollection;
			}
			set
			{
				this.parentScoringLoadValueCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ScoringLoadValue objects
	/// </summary>
	[ElementType(typeof(ScoringLoadValue))]
	public class ScoringLoadValueCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ScoringLoadValueID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ScoringLoadValue elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentScoringLoadValueCollection = this;
			else
				elem.ParentScoringLoadValueCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ScoringLoadValue elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ScoringLoadValue this[int index]
		{
			get
			{
				return (ScoringLoadValue)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ScoringLoadValue)oldValue, false);
			SetParentOnElem((ScoringLoadValue)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ScoringLoadValue elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ScoringLoadValue)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Hashtable based index on scoringLoadValueID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ScoringLoadValueID
		{
			get
			{
				if (this.indexBy_ScoringLoadValueID == null)
					this.indexBy_ScoringLoadValueID = new CollectionIndexer(this, new string[] { "scoringLoadValueID" }, true);
				return this.indexBy_ScoringLoadValueID;
			}
			
		}

		/// <summary>
		/// Looks up by scoringLoadValueID and returns Description value.  Uses the IndexBy_ScoringLoadValueID indexer.
		/// </summary>
		public string Lookup_DescriptionByScoringLoadValueID(int scoringLoadValueID)
		{
			return this.IndexBy_ScoringLoadValueID.LookupStringMember("Description", scoringLoadValueID);
		}

		/// <summary>
		/// Looks up by scoringLoadValueID and returns Code value.  Uses the IndexBy_ScoringLoadValueID indexer.
		/// </summary>
		public string Lookup_CodeByScoringLoadValueID(int scoringLoadValueID)
		{
			return this.IndexBy_ScoringLoadValueID.LookupStringMember("Code", scoringLoadValueID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllScoringLoadValuesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllScoringLoadValuesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ScoringLoadValueCollection which is cached in NSGlobal
		/// </summary>
		public static ScoringLoadValueCollection ActiveScoringLoadValues
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ScoringLoadValueCollection col = (ScoringLoadValueCollection)NSGlobal.EnsureCachedObject("ActiveScoringLoadValues", typeof(ScoringLoadValueCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllScoringLoadValuesByActive(-1, true);
				}
				return col;
			}
			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllScoringLoadValues", -1, this, false);
		}
	}
}
