using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ScoringLoadParagraph]
	/// </summary>
	[SPAutoGen("usp_GetAllScoringLoadParagraphsByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllScoringLoadParagraphs","SelectAll.sptpl","")]
	[SPInsert("usp_InsertScoringLoadParagraph")]
	[SPUpdate("usp_UpdateScoringLoadParagraph")]
	[SPDelete("usp_DeleteScoringLoadParagraph")]
	[SPLoad("usp_LoadScoringLoadParagraph")]
	[TableMapping("ScoringLoadParagraph","scoringLoadParagraphID")]
	public class ScoringLoadParagraph : BaseData
	{
		[NonSerialized]
		private ScoringLoadParagraphCollection parentScoringLoadParagraphCollection;
		[ColumnMapping("ScoringLoadParagraphID",(int)0)]
		private int scoringLoadParagraphID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("ParagraphID",StereoType=DataStereoType.FK)]
		private int paragraphID;
		[ColumnMapping("Active")]
		private bool active;
	
		public ScoringLoadParagraph()
		{
		}

		public ScoringLoadParagraph(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ScoringLoadParagraphID
		{
			get { return this.scoringLoadParagraphID; }
			set { this.scoringLoadParagraphID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ParagraphID
		{
			get { return this.paragraphID; }
			set { this.paragraphID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent ScoringLoadParagraphCollection that contains this element
		/// </summary>
		public ScoringLoadParagraphCollection ParentScoringLoadParagraphCollection
		{
			get
			{
				return this.parentScoringLoadParagraphCollection;
			}
			set
			{
				this.parentScoringLoadParagraphCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ScoringLoadParagraph objects
	/// </summary>
	[ElementType(typeof(ScoringLoadParagraph))]
	public class ScoringLoadParagraphCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ScoringLoadParagraph elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentScoringLoadParagraphCollection = this;
			else
				elem.ParentScoringLoadParagraphCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ScoringLoadParagraph elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ScoringLoadParagraph this[int index]
		{
			get
			{
				return (ScoringLoadParagraph)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ScoringLoadParagraph)oldValue, false);
			SetParentOnElem((ScoringLoadParagraph)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ScoringLoadParagraph elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ScoringLoadParagraph)value, true);
			base.OnInsertComplete (index, value);		
		}

		#region AllParagraphs
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllScoringLoadParagraphs(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllScoringLoadParagraphs", maxRecords, this, false);
		}

		public static ScoringLoadParagraphCollection GetAll()
		{
			ScoringLoadParagraphCollection col = new ScoringLoadParagraphCollection();
			col.LoadAllScoringLoadParagraphs(-1);
			return col;
		}
		#endregion

		#region ActiveScoringLoadParagraphs
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadAllScoringLoadParagraphsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllScoringLoadParagraphsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ScoringLoadParagraphCollection which is cached in NSGlobal
		/// </summary>
		public static ScoringLoadParagraphCollection ActiveScoringLoadParagraphs
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ScoringLoadParagraphCollection col = (ScoringLoadParagraphCollection)NSGlobal.EnsureCachedObject("ActiveScoringLoadParagraphs", typeof(ScoringLoadParagraphCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllScoringLoadParagraphsByActive(-1, true);
				}
				return col;
			}
		}
		#endregion
	}
}
