using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ScoringLoadAttribute]
	/// </summary>
	[SPAutoGen("usp_GetAllScoringLoadAttributesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllScoringLoadAttributes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertScoringLoadAttribute")]
	[SPUpdate("usp_UpdateScoringLoadAttribute")]
	[SPDelete("usp_DeleteScoringLoadAttribute")]
	[SPLoad("usp_LoadScoringLoadAttribute")]
	[TableMapping("ScoringLoadAttribute","scoringLoadAttributeID")]
	public class ScoringLoadAttribute : BaseLookupWithSubCode
	{
		[NonSerialized]
		private ScoringLoadAttributeCollection parentScoringLoadAttributeCollection;
		[ColumnMapping("ScoringLoadAttributeID",(int)0)]
		private int scoringLoadAttributeID;
		[ColumnMapping("Priority",StereoType=DataStereoType.FK)]
		private int priority;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ScoringLoadAttribute()
		{
		}

		public ScoringLoadAttribute(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ScoringLoadAttributeID
		{
			get { return this.scoringLoadAttributeID; }
			set { this.scoringLoadAttributeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Priority
		{
			get { return this.priority; }
			set { this.priority = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		} 

		[FieldValuesMember("LookupOf_SubCodeID")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@PRIORITY@")]
		public override int SubCodeID
		{
			get { return this.priority; }
			set { this.priority = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent ScoringLoadAttributeCollection that contains this element
		/// </summary>
		public ScoringLoadAttributeCollection ParentScoringLoadAttributeCollection
		{
			get
			{
				return this.parentScoringLoadAttributeCollection;
			}
			set
			{
				this.parentScoringLoadAttributeCollection = value; // parent is set when added to a collection
			}
		}

		public int[] LookupOf_SubCodeID
		{
			get
			{
				return new int[] { 1 , 2, 3};
			}
		}		
	}

	/// <summary>
	/// Strongly typed collection of ScoringLoadAttribute objects
	/// </summary>
	[ElementType(typeof(ScoringLoadAttribute))]
	public class ScoringLoadAttributeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ScoringLoadAttributeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ScoringLoadAttribute elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentScoringLoadAttributeCollection = this;
			else
				elem.ParentScoringLoadAttributeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ScoringLoadAttribute elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ScoringLoadAttribute this[int index]
		{
			get
			{
				return (ScoringLoadAttribute)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ScoringLoadAttribute)oldValue, false);
			SetParentOnElem((ScoringLoadAttribute)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ScoringLoadAttribute elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ScoringLoadAttribute)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllScoringLoadAttributesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllScoringLoadAttributesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ScoringLoadAttributeCollection which is cached in NSGlobal
		/// </summary>
		public static ScoringLoadAttributeCollection ActiveScoringLoadAttributes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ScoringLoadAttributeCollection col = (ScoringLoadAttributeCollection)NSGlobal.EnsureCachedObject("ActiveScoringLoadAttributes", typeof(ScoringLoadAttributeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllScoringLoadAttributesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on scoringLoadAttributeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ScoringLoadAttributeID
		{
			get
			{
				if (this.indexBy_ScoringLoadAttributeID == null)
					this.indexBy_ScoringLoadAttributeID = new CollectionIndexer(this, new string[] { "scoringLoadAttributeID" }, true);
				return this.indexBy_ScoringLoadAttributeID;
			}
			
		}

		/// <summary>
		/// Looks up by scoringLoadAttributeID and returns Description value.  Uses the IndexBy_ScoringLoadAttributeID indexer.
		/// </summary>
		public string Lookup_DescriptionByScoringLoadAttributeID(int scoringLoadAttributeID)
		{
			return this.IndexBy_ScoringLoadAttributeID.LookupStringMember("Description", scoringLoadAttributeID);
		}

		/// <summary>
		/// Looks up by scoringLoadAttributeID and returns Code value.  Uses the IndexBy_ScoringLoadAttributeID indexer.
		/// </summary>
		public string Lookup_CodeByScoringLoadAttributeID(int scoringLoadAttributeID)
		{
			return this.IndexBy_ScoringLoadAttributeID.LookupStringMember("Code", scoringLoadAttributeID);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllScoringLoadAttributes", -1, this, false);
		}
	}
}
