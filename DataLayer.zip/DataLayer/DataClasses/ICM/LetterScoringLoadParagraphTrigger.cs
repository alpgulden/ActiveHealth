using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterScoringLoadParagraphTrigger]
	/// </summary>
	[SPAutoGen("usp_SearchLetterScoringLoadParagraphTriggers","SearchByArgs.sptpl","activeWithAll:active, assessmentCategoryID, assessmentParagraphID, attributeID, morgID, orgID, sorgID, createdBy")]
	[SPInsert("usp_InsertLetterScoringLoadParagraphTrigger")]
	[SPUpdate("usp_UpdateLetterScoringLoadParagraphTrigger")]
	[SPDelete("usp_DeleteLetterScoringLoadParagraphTrigger")]
	[SPLoad("usp_LoadLetterScoringLoadParagraphTrigger")]
	[TableMapping("LetterScoringLoadParagraphTrigger","letterScoringLoadParagraphTriggerID")]
	public class LetterScoringLoadParagraphTrigger : BaseMOS
	{
		[NonSerialized]
		private LetterScoringLoadParagraphTriggerCollection parentLetterScoringLoadParagraphTriggerCollection;
		[ColumnMapping("LetterScoringLoadParagraphTriggerID",(int)0)]
		private int letterScoringLoadParagraphTriggerID;
		[ColumnMapping("AssessmentCategoryID",StereoType=DataStereoType.FK)]
		protected int assessmentCategoryID;
		[ColumnMapping("AssessmentParagraphID",StereoType=DataStereoType.FK)]
		protected int assessmentParagraphID;
		[ColumnMapping("AttributeID",StereoType=DataStereoType.FK)]
		private int attributeID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("IncludeCCOnLetter")]
		protected bool includeCCOnLetter;
		[ColumnMapping("IncludeNoCCOnLetter")]
		protected bool includeNoCCOnLetter;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;

		//[ColumnMapping("ParagraphDescription", JoinColumn="Description", JoinRelation="LetterScoringLoadParagraphTrigger.assessmentParagraphID = [assessmentParagraph].assessmentParagraphID")]
		//private string paragraphDescription;
	
		public LetterScoringLoadParagraphTrigger()
		{
		}

		public LetterScoringLoadParagraphTrigger(bool initNew)
		{
			if (initNew) // initialize record if requested
			{
				this.NewRecord();
				this.active = true;
			}
		}

		[FieldDescription("@ID@")]
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int LetterScoringLoadParagraphTriggerID
		{
			get { return this.letterScoringLoadParagraphTriggerID; }
			set { this.letterScoringLoadParagraphTriggerID = value; }
		}

		[FieldDescription("@CATEGORY@")]
		[FieldValuesMember("LookupOf_AssessmentCategoryID", "AssessmentCategoryID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int AssessmentCategoryID
		{
			get { return this.assessmentCategoryID; }
			set { this.assessmentCategoryID = value; }
		}

		[FieldDescription("@PARAGRAPH@")]
		[FieldValuesMember("LookupOf_AssessmentParagraphID", "AssessmentParagraphID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int AssessmentParagraphID
		{
			get { return this.assessmentParagraphID; }
			set { this.assessmentParagraphID = value; }
		}

//		[FieldDescription("@PARAGRAPH@")]
//		public string AssessmentParagraphDescription
//		{
//			get { return this.paragraphDescription; }
//		}

		[FieldValuesMember("LookupOf_AttributeID", "ScoringLoadAttributeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int AttributeID
		{
			get { return this.attributeID; }
			set { this.attributeID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IncludeCCOnLetter
		{
			get { return this.includeCCOnLetter; }
			set { this.includeCCOnLetter = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IncludeNoCCOnLetter
		{
			get { return this.includeNoCCOnLetter; }
			set { this.includeNoCCOnLetter = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent LetterScoringLoadParagraphTriggerCollection that contains this element
		/// </summary>
		public LetterScoringLoadParagraphTriggerCollection ParentLetterScoringLoadParagraphTriggerCollection
		{
			get
			{
				return this.parentLetterScoringLoadParagraphTriggerCollection;
			}
			set
			{
				this.parentLetterScoringLoadParagraphTriggerCollection = value; // parent is set when added to a collection
			}
		}

		#region Lookups
		public AssessmentCategoryCollection LookupOf_AssessmentCategoryID
		{
			get
			{
				return AssessmentCategoryCollection.ActiveAssessmentCategories; // Acquire a shared instance from the static member of collection
			}
		}

		public AssessmentParagraphCollection LookupOf_AssessmentParagraphID
		{
			get
			{
				AssessmentParagraphCollection col = new AssessmentParagraphCollection();
				col.LoadAssessmentParagraphByCategory(-1, this.assessmentCategoryID, true);
				return col;
			}
		}

		public ScoringLoadAttributeCollection LookupOf_AttributeID
		{
			get
			{
				return ScoringLoadAttributeCollection.ActiveScoringLoadAttributes; // Acquire a shared instance from the static member of collection
			}
		}
		#endregion
	}

	/// <summary>
	/// Strongly typed collection of LetterScoringLoadParagraphTrigger objects
	/// </summary>
	[ElementType(typeof(LetterScoringLoadParagraphTrigger))]
	public class LetterScoringLoadParagraphTriggerCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterScoringLoadParagraphTrigger elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterScoringLoadParagraphTriggerCollection = this;
			else
				elem.ParentLetterScoringLoadParagraphTriggerCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterScoringLoadParagraphTrigger elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterScoringLoadParagraphTrigger this[int index]
		{
			get
			{
				return (LetterScoringLoadParagraphTrigger)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterScoringLoadParagraphTrigger)oldValue, false);
			SetParentOnElem((LetterScoringLoadParagraphTrigger)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterScoringLoadParagraphTrigger elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterScoringLoadParagraphTrigger)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchLetterScoringLoadParagraphTriggers(int maxRecords, LetterScoringLoadParagraphTrigger searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchLetterScoringLoadParagraphTriggers", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}

		public static LetterScoringLoadParagraphTriggerCollection GetFromSearch(LetterScoringLoadParagraphTrigger searcher)
		{
			LetterScoringLoadParagraphTriggerCollection col = new LetterScoringLoadParagraphTriggerCollection();
			col.SearchLetterScoringLoadParagraphTriggers(-1, searcher);
			return col;
		}

		public int GetLetterScoringLoadParagraphTriggersByCategory(int categoryID)
		{
			this.Clear();

			return SqlData.SPExecReadCol("usp_GetLetterScoringLoadParagraphTriggersByCategory", -1, this, false, new object[] {categoryID});
		}


		/// <summary>
		/// Hashtable based search on assessmentCategoryID, assessmentParagraphID, includeCCOnLetter, includeNoCCOnLetter fields returns the object.  Uses the IndexBy_AssessmentCategoryID_AssessmentParagraphID_IncludeCCOnLetter_IncludeNoCCOnLetter indexer.
		/// </summary>
		public LetterScoringLoadParagraphTrigger FindBy(int assessmentCategoryID, int assessmentParagraphID, bool includeCCOnLetter, bool includeNoCCOnLetter)
		{
			foreach (LetterScoringLoadParagraphTrigger trigger in this)
			{
				if (trigger.AssessmentCategoryID == assessmentCategoryID && trigger.AssessmentParagraphID == assessmentParagraphID && trigger.IncludeCCOnLetter == includeCCOnLetter && trigger.IncludeNoCCOnLetter == includeNoCCOnLetter)
					return trigger;
			}

			return null;
		}

	}
}
