using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ScoringLoadQuestionnaire]
	/// </summary>
	[SPAutoGen("usp_GetAllScoringLoadQuestionnairesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllScoringLoadQuestionnaires","SelectAll.sptpl","")]
	[SPInsert("usp_InsertScoringLoadQuestionnaire")]
	[SPUpdate("usp_UpdateScoringLoadQuestionnaire")]
	[SPDelete("usp_DeleteScoringLoadQuestionnaire")]
	[SPLoad("usp_LoadScoringLoadQuestionnaire")]
	[TableMapping("ScoringLoadQuestionnaire","scoringLoadQuestionnaireID")]
	public class ScoringLoadQuestionnaire : BaseData
	{
		[NonSerialized]
		private ScoringLoadQuestionnaireCollection parentScoringLoadQuestionnaireCollection;
		[ColumnMapping("ScoringLoadQuestionnaireID",(int)0)]
		private int scoringLoadQuestionnaireID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("QuestionnaireID",StereoType=DataStereoType.FK)]
		private int questionnaireID;
		[ColumnMapping("Active")]
		private bool active;
	
		public ScoringLoadQuestionnaire()
		{
		}

		public ScoringLoadQuestionnaire(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ScoringLoadQuestionnaireID
		{
			get { return this.scoringLoadQuestionnaireID; }
			set { this.scoringLoadQuestionnaireID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent ScoringLoadQuestionnaireCollection that contains this element
		/// </summary>
		public ScoringLoadQuestionnaireCollection ParentScoringLoadQuestionnaireCollection
		{
			get
			{
				return this.parentScoringLoadQuestionnaireCollection;
			}
			set
			{
				this.parentScoringLoadQuestionnaireCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ScoringLoadQuestionnaire objects
	/// </summary>
	[ElementType(typeof(ScoringLoadQuestionnaire))]
	public class ScoringLoadQuestionnaireCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ScoringLoadQuestionnaire elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentScoringLoadQuestionnaireCollection = this;
			else
				elem.ParentScoringLoadQuestionnaireCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ScoringLoadQuestionnaire elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ScoringLoadQuestionnaire this[int index]
		{
			get
			{
				return (ScoringLoadQuestionnaire)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ScoringLoadQuestionnaire)oldValue, false);
			SetParentOnElem((ScoringLoadQuestionnaire)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ScoringLoadQuestionnaire elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ScoringLoadQuestionnaire)value, true);
			base.OnInsertComplete (index, value);		
		}

		#region All
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadAllScoringLoadQuestionnaires(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllScoringLoadQuestionnaires", maxRecords, this, false);
		}

		public static ScoringLoadQuestionnaireCollection GetAll()
		{
			ScoringLoadQuestionnaireCollection col = new ScoringLoadQuestionnaireCollection();
			col.LoadAllScoringLoadQuestionnaires(-1);
			return col;
		}
		#endregion

		#region ActiveScoringLoadQuestionnaires
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadAllScoringLoadQuestionnairesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllScoringLoadQuestionnairesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ScoringLoadQuestionnaireCollection which is cached in NSGlobal
		/// </summary>
		public static ScoringLoadQuestionnaireCollection ActiveScoringLoadQuestionnaires
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ScoringLoadQuestionnaireCollection col = (ScoringLoadQuestionnaireCollection)NSGlobal.EnsureCachedObject("ActiveScoringLoadQuestionnaires", typeof(ScoringLoadQuestionnaireCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllScoringLoadQuestionnairesByActive(-1, true);
				}
				return col;
			}
		}
		#endregion
	}
}
