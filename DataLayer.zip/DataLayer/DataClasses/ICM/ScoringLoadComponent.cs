using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ScoringLoadComponent]
	/// </summary>
	[SPAutoGen("usp_GetAllScoringLoadComponentsByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllScoringLoadComponents","SelectAll.sptpl","")]
	[SPInsert("usp_InsertScoringLoadComponent")]
	[SPUpdate("usp_UpdateScoringLoadComponent")]
	[SPDelete("usp_DeleteScoringLoadComponent")]
	[SPLoad("usp_LoadScoringLoadComponent")]
	[TableMapping("ScoringLoadComponent","scoringLoadComponentID")]
	public class ScoringLoadComponent : BaseLookupWithNote
	{
		[NonSerialized]
		private ScoringLoadComponentCollection parentScoringLoadComponentCollection;
		[ColumnMapping("ScoringLoadComponentID",(int)0)]
		private int scoringLoadComponentID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ScoringLoadComponent()
		{
		}

		public ScoringLoadComponent(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ScoringLoadComponentID
		{
			get { return this.scoringLoadComponentID; }
			set { this.scoringLoadComponentID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		} 

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent ScoringLoadComponentCollection that contains this element
		/// </summary>
		public ScoringLoadComponentCollection ParentScoringLoadComponentCollection
		{
			get
			{
				return this.parentScoringLoadComponentCollection;
			}
			set
			{
				this.parentScoringLoadComponentCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ScoringLoadComponent objects
	/// </summary>
	[ElementType(typeof(ScoringLoadComponent))]
	public class ScoringLoadComponentCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ScoringLoadComponentID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ScoringLoadComponent elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentScoringLoadComponentCollection = this;
			else
				elem.ParentScoringLoadComponentCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ScoringLoadComponent elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ScoringLoadComponent this[int index]
		{
			get
			{
				return (ScoringLoadComponent)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ScoringLoadComponent)oldValue, false);
			SetParentOnElem((ScoringLoadComponent)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ScoringLoadComponent elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ScoringLoadComponent)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Hashtable based index on scoringLoadComponentID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ScoringLoadComponentID
		{
			get
			{
				if (this.indexBy_ScoringLoadComponentID == null)
					this.indexBy_ScoringLoadComponentID = new CollectionIndexer(this, new string[] { "scoringLoadComponentID" }, true);
				return this.indexBy_ScoringLoadComponentID;
			}
			
		}

		/// <summary>
		/// Looks up by scoringLoadComponentID and returns Code value.  Uses the IndexBy_ScoringLoadComponentID indexer.
		/// </summary>
		public string Lookup_CodeByScoringLoadComponentID(int scoringLoadComponentID)
		{
			return this.IndexBy_ScoringLoadComponentID.LookupStringMember("Code", scoringLoadComponentID);
		}

		/// <summary>
		/// Looks up by scoringLoadComponentID and returns Description value.  Uses the IndexBy_ScoringLoadComponentID indexer.
		/// </summary>
		public string Lookup_DescriptionByScoringLoadComponentID(int scoringLoadComponentID)
		{
			return this.IndexBy_ScoringLoadComponentID.LookupStringMember("Description", scoringLoadComponentID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllScoringLoadComponentsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllScoringLoadComponentsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ScoringLoadComponentCollection which is cached in NSGlobal
		/// </summary>
		public static ScoringLoadComponentCollection ActiveScoringLoadComponents
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ScoringLoadComponentCollection col = (ScoringLoadComponentCollection)NSGlobal.EnsureCachedObject("ActiveScoringLoadComponents", typeof(ScoringLoadComponentCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllScoringLoadComponentsByActive(-1, true);
				}
				return col;
			}
			
		}

		public override void LoadAll()		
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllScoringLoadComponents", -1, this, false);
		}		
	}
}
