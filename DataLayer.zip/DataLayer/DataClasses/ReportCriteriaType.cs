using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReportCriteriaType]
	/// </summary>
	[SPAutoGen("usp_GetAllReportCriteriaType","SelectAll.sptpl","")]
	[SPInsert("usp_InsertReportCriteriaType")]
	[SPUpdate("usp_UpdateReportCriteriaType")]
	[SPDelete("usp_DeleteReportCriteriaType")]
	[SPLoad("usp_LoadReportCriteriaType")]
	[TableMapping("ReportCriteriaType","reportCriteriaTypeID")]
	public class ReportCriteriaType : BaseLookupWithNote
	{
		[NonSerialized]
		private ReportCriteriaTypeCollection parentReportCriteriaTypeCollection;
		[ColumnMapping("ReportCriteriaTypeID",(int)0)]
		private int reportCriteriaTypeID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ReportCriteriaType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ReportCriteriaTypeID
		{
			get { return this.reportCriteriaTypeID; }
			set { this.reportCriteriaTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent ReportCriteriaTypeCollection that contains this element
		/// </summary>
		public ReportCriteriaTypeCollection ParentReportCriteriaTypeCollection
		{
			get
			{
				return this.parentReportCriteriaTypeCollection;
			}
			set
			{
				this.parentReportCriteriaTypeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ReportCriteriaType objects
	/// </summary>
	[ElementType(typeof(ReportCriteriaType))]
	public class ReportCriteriaTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReportCriteriaType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReportCriteriaTypeCollection = this;
			else
				elem.ParentReportCriteriaTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ReportCriteriaType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReportCriteriaType this[int index]
		{
			get
			{
				return (ReportCriteriaType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReportCriteriaType)oldValue, false);
			SetParentOnElem((ReportCriteriaType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllReportCriteriaType", -1, this, false);
		}
	}
}
