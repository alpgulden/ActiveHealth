using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// ImportData
	/// This class is responsible for modules that input data
	/// into the ActiveAdvice system.
	/// </summary>
	[TableMapping("CMS","cMSID")]
	public class ImportData : NetsoftUSA.DataLayer.BaseDataClass
	{
		public ImportData()
		{
			//
			// TODO: Add constructor logic here
			//
		}// end of constructor ImportData()

		/// <summary>
		/// ProviderFileName
		/// property that contains the filename to read provider information from.
		/// </summary>
		private string providerFileName;
		[FieldDescription("@PROVIDERFILENAME@")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string ProviderFileName
		{
			get { return this.providerFileName; }
			set { this.providerFileName = value; }
		}// end of property ProviderFileName

		private string providerInBox;
		[FieldDescription("@PROVIDERINBOX@")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string ProviderInBox
		{
			get { return this.providerInBox; }
			set { this.providerInBox = value; }
		}// end of property ProviderInBox

	}// end of class ImportDate()
}// end of namespace

