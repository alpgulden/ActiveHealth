using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	// This code is based on Pascal file 'LOSCoder.pas'.

	/*  Changes in the original Pascal source.
	 *   --------------- ---------- --------------------------------------------------
		 Keith Wood      06/09/1997 New module
		 Keith Wood      10/10/1997 SCR418 Call always produces 'Error in LOS calculation'
		 Keith Wood      12/18/1997 SCR698 Implement V diagnosis code logic
                            SCR1078 Get date of birth from patient record not log
		 Keith Wood      02/11/1998 SCR1280 Compare at 95% percentile before 10%
		 Keith Wood      02/19/1998 SCR1319 Get LOS details from plan/sorg breaker
		 Keith Wood      12/02/1998 SCR1779 Don't use year in finding LOS data
		 Dave Henrickson 02/16/1999 SCR2392 Calculate LOS info from DMS4 codes
		 Dave Henrickson 03/14/2000 SCR3045 Tighten LOS error checking 
	 * 
	 */

	/// <summary>
	/// Data class that wraps the entity access functionality to table [DRGCode]
	/// </summary>
	public struct LOSDetails 
	{
		public int ObservedPatients;
		public double AverageStay;
		public string Variance;
		public string[] Percentiles;		// 0..6

		public void ImportLOS(LengthOfStay los)
		{
			// { Copy values into LOS object }
			this.ObservedPatients = los.ObservedPatients;
			this.AverageStay = (double)los.AverageStay;
			this.Variance = los.LosVariance.ToString();
			this.Percentiles = new string[7];
			this.Percentiles[0] = Convert.ToString( los.Los10 ) + los.Los10Plus;
			this.Percentiles[1] = Convert.ToString( los.Los25 ) + los.Los25Plus;
			this.Percentiles[2] = Convert.ToString( los.Los50 ) + los.Los50Plus;
			this.Percentiles[3] = Convert.ToString( los.Los75 ) + los.Los75Plus;
			this.Percentiles[4] = Convert.ToString( los.Los90 ) + los.Los90Plus;
			this.Percentiles[5] = Convert.ToString( los.Los95 ) + los.Los95Plus;
			this.Percentiles[6] = Convert.ToString( los.Los99 ) + los.Los99Plus;
		}
	}

	public class LOSData
	{
		public const string UNKNOWN = null;
		public const string NOTAPPLICABLE = "N/A";
		public const string UNKONWNAGECATEGORY = "0";  // { Flag for unknown age category }
		
		public int FLOSYear;
		string FPayGroup;
		string FRegionCode;
		string FICD9Diagnosis;
		string FICD9Procedure;
		string FCategoryCode;
		DateTime FDOB;
		string FAgeCategory;
		public int FObservedPatients;
		public double FAverageStay;
		string FVariance;
		string[] FPercentiles = new string[7];

		public LOSData()
		{
		}

		// { Get Percentiles property from internal array }
		public string GetPercentiles(int percentage)
		{
			int i;
			switch(percentage)
			{
				case 10:  i = 1; break;
				case 25:  i = 2; break;
				case 50:  i = 3; break;
				case 75:  i = 4; break;
				case 90:  i = 5; break;
				case 95:  i = 6; break;
				case 99:  i = 7; break;
				default: i = 0; break;
			}
			if (i == 0)
				return UNKNOWN;		// unknown
			else
			{
				string percentile = FPercentiles[i - 1];
				if (percentile == null || percentile == "")
					return NOTAPPLICABLE;
				else
					return percentile; 
			}
		}

		public bool GetPercentiles(int percentage, ref int losValue, ref string losPlus)
		{
			string s = GetPercentiles(percentage);
			if (s == UNKNOWN)
				return false;
			if (s == NOTAPPLICABLE)
				return false;
			losValue = int.Parse(s);
			string slosValue = losValue.ToString();
			losPlus = s.Substring(slosValue.Length);		// get the rest into losPlus
			return true;
		}

		// { Compute the "age" category based on patient's weight -
		// impute weight if passed as zero }
		public string CalcBirthWeight(double rNewbornGrams, DiagnosticSelectCollection lstDiagnoses)
		{
			int i;
			string Result = UNKONWNAGECATEGORY;		// set to unknown by default
			int newbornGrams = (int)rNewbornGrams;
			if (newbornGrams <= 0)
			{
				// check for diagnostic codes to find age category
				for (i = 0; i < lstDiagnoses.Count; i++)
				{
					if ((!lstDiagnoses[i].IsMarkedForDeletion && !lstDiagnoses[i].IsNewlyDeletedInDB) &&
						(String.Compare(lstDiagnoses[i].CodeValue, "764.01") >= 0) &&
						(String.Compare(lstDiagnoses[i].CodeValue, "765.19") <= 0))
					{
						// { Impute birthweight from last digit of diagnosis }
						switch (lstDiagnoses[i].CodeValue[6])
						{
							case '1':
							case '2':
							case '3': Result = "1"; break;
							case '4':
							case '5': Result = "2"; break;
							case '6': Result = "3"; break;
							case '7':
							case '8': Result = "4"; break;
							case '9': Result = "5"; break;
						}
						if (Result != UNKONWNAGECATEGORY)
							return Result;
					}
				}
			}
			else
			{
				// newborn grams > 0,
				// calcuate the age category from newborn grams.
				if (newbornGrams >= 1 && newbornGrams <= 999) Result = "1";
				else if (newbornGrams >= 1000 && newbornGrams <= 1499) Result = "2";
				else if (newbornGrams >= 1500 && newbornGrams <= 1749) Result = "3";
				else if (newbornGrams >= 1750 && newbornGrams <= 2499) Result = "4";
				else Result = "5";
			}
			return Result;
		}

		// { Compute the age category based on payor group and region code
		// and date of birth and reference date }
		public string CalcAgeCategory(string sPayGroup, string sRegionCode, DateTime dDateOfBirth, DateTime dAsAtDate)
		{
			int iYears = 0, iMonths = 0, iDays = 0;
			if (!BaseData.CalculateYearsMonthsDays( dDateOfBirth, dAsAtDate, ref iYears, ref iMonths, ref iDays))
				return UNKONWNAGECATEGORY;
				
			// { Set age category for different groups and regions }
			if (iYears < 0)
				return UNKONWNAGECATEGORY;
			else
			{
				if (sPayGroup == "0") // { None }
				{
					if ((String.Compare(sRegionCode, "2") >= 0) && (String.Compare(sRegionCode, "6") <= 0 )) //  { US and regional }
					{
						if (iYears >= 0 && iYears <= 19) return "1";
						else if (iYears >= 20 && iYears <= 34) return "2";
						else if (iYears >= 35 && iYears <= 49) return "3";
						else if (iYears >= 50 && iYears <= 64) return "4";
						else return "5";
					}
					else if (sRegionCode == "7") //  { Pediatric }
					{
						if (iYears == 0)
						{
							if (iDays <= 27)
								return "1";
							else
								return "2";
						}
						else if (iYears >= 1 && iYears <= 5) return "3";
						else if (iYears >= 6 && iYears <= 12) return "4";
						else if (iYears >= 13 && iYears <= 19) return "5";
						else return UNKONWNAGECATEGORY;
					}
					else if (sRegionCode == "8") //  { Geriatric }
					{
						if (iYears < 65)
							return UNKONWNAGECATEGORY;
						else
						{
							if (iYears >= 65 && iYears <= 69) return "1";
							if (iYears >= 70 && iYears <= 74) return "2";
							if (iYears >= 75 && iYears <= 79) return "3";
							if (iYears >= 80 && iYears <= 84) return "4";
							else return "5";
						}
					}
					else     //                       { Unknown region code }
						return UNKONWNAGECATEGORY;
				}
				else if (sPayGroup == "1") //  { Medicare }
				{
					if (iYears >= 0 && iYears <= 69) return "1";
					else if (iYears >= 70 && iYears <= 74) return "2";
					else if (iYears >= 75 && iYears <= 79) return "3";
					else if (iYears >= 80 && iYears <= 84) return "4";
					else return "5";
				}
				else if (sPayGroup == "2" || sPayGroup == "3") //  { Medicaid/Blue Cross/Private Insurance }
				{
					if (iYears >= 0 && iYears <= 17) return "1";
					else if (iYears >= 18 && iYears <= 34) return "2";
					else if (iYears >= 35 && iYears <= 49) return "3";
					else if (iYears >= 50 && iYears <= 69) return "4";
					else return "5";
				}
				else if (sPayGroup == "5") //  { Workers' Compensation }
				{
					if (iYears < 16) return UNKONWNAGECATEGORY;
					else if (iYears >= 16 && iYears <= 34) return "1";
					else if (iYears >= 35 && iYears <= 44) return "2";
					else if (iYears >= 45 && iYears <= 54) return "3";
					else if (iYears >= 55 && iYears <= 64) return "4";
					else return "5";
				}
				else //  { Unknown pay group }
					return UNKONWNAGECATEGORY;
			}
		}

		/// <summary>
		/// Extract summary level from code - up to and including period 
		/// </summary>
		/// <param name="sCode"></param>
		/// <returns></returns>
		public string SummaryLevel(string sCode)
		{
			if (sCode == null)
				return null;
			int iPos = sCode.IndexOf('.', 0);
			if (iPos < 0)
				return sCode;
			else
				return sCode.Substring(0, iPos + 1);		// include '.'
		}

		// { Extract LOS data from the table depending on the values passed in }
		public void CalculateLOSData(PlanSORGLog planSorgLog, Patient patient,
			DiagnosticSelectCollection lstDiagnoses, ProcedureSelectCollection lstProcedures,
			DateTime dAsAtDate, double rNewbornGrams)
		{
			if (dAsAtDate == DateTime.MinValue)
				throw new ActiveAdviceException(AAExceptionAction.None, "No date of service!");

			int dxCount = lstDiagnoses.CountValidCodes();
			int pxCount = lstProcedures.CountValidCodes();

			int i;
			string sICD9Diagnosis, sICD9Procedure;
			LOSDetails recDX = new LOSDetails(), recPX = new LOSDetails();

			// FORK 1.1
			PlanSORG planSORG = planSorgLog.GetPlanSORG();
			FPayGroup = planSORG.HCIA_PayorGroup;
			FRegionCode = planSORG.HCIA_LOSRegion;
			// END FORK 1.1

			if (FPayGroup == null || FPayGroup == "")
				throw new ActiveAdviceException(AAExceptionAction.None, "Missing HCIA Payor Group");

			if (FRegionCode == null || FRegionCode == "")
				throw new ActiveAdviceException(AAExceptionAction.None, "Missing HCIA Region Code");

			FDOB = patient.DateOfBirth;

			if (FDOB == DateTime.MinValue)
				throw new ActiveAdviceException(AAExceptionAction.None, "Missing Patient Date of Birth");

			// find first ICD9 diag and proc
			FICD9Diagnosis = lstDiagnoses.FindICD9Diagnosis();  // handles both icd9/dsm4 codes - dkh
			FICD9Procedure = lstProcedures.FindICD9Procedure();

			// find los group values on the ICD9 code table for diag and proc
			ICD9Code diagicd9Code = new ICD9Code();
			if (FICD9Diagnosis != null)
			{
				if (!diagicd9Code.Load(FICD9Diagnosis, BaseDxPx.DxPxDiagnostic))
					throw new ActiveAdviceException(AAExceptionAction.None, "Code {0} not found!", FICD9Diagnosis);
				FICD9Diagnosis = diagicd9Code.LOSGroup;
				if (FICD9Diagnosis == null || FICD9Diagnosis == "")
					throw new ActiveAdviceException(AAExceptionAction.None, "Missing LOS Group for {0}!", diagicd9Code.Code);
			}

			ICD9Code procicd9Code = new ICD9Code();
			if (FICD9Procedure != null)
			{
				if (!procicd9Code.Load(FICD9Procedure, BaseDxPx.DxPxProcedure))
					throw new ActiveAdviceException(AAExceptionAction.None, "Code {0} not found!", FICD9Procedure);
				FICD9Procedure = procicd9Code.LOSGroup;
				if (FICD9Procedure == null || FICD9Procedure == "")
					throw new ActiveAdviceException(AAExceptionAction.None, "Missing LOS Group for {0}!", procicd9Code.Code);
			}

			// { Category indicates number of diagnoses and procedures:
			// 0 = 1 DX, 0 PX, 1 = 1 DX, 1+ PX, 3 = 2+ DX, 0 PX, 4 = 2+ DX, 1+ PX }
			i = 3 * (dxCount > 1 ? 1 : 0);
			if (pxCount > 0)
				i++;
			FCategoryCode = i.ToString();
			// { If primary diagnosis is V30 - V39 then calculate "age" fom birthweight }
			if (FICD9Diagnosis != null && FICD9Diagnosis.Substring(1, 2) == "V3")
				FAgeCategory = CalcBirthWeight(rNewbornGrams, lstDiagnoses);
			else	// { Otherwise calculate age from group, region and actual age }
				FAgeCategory = CalcAgeCategory(FPayGroup, FRegionCode, FDOB, dAsAtDate);
    
			if (FAgeCategory == UNKONWNAGECATEGORY)
			{
				throw new ActiveAdviceException(AAExceptionAction.None, "Start date cannot precede Date of Birth!");
			}

			// { query LOS for diag }
			LengthOfStay losDX = null;
			if (FICD9Diagnosis != null)
			{
				losDX = new LengthOfStay();
				if (!losDX.Load(FPayGroup, FRegionCode, "D", "2", FICD9Diagnosis, FCategoryCode, FAgeCategory))
				{
					// query for summary diagnosis
					if (!losDX.Load(FPayGroup, FRegionCode, "D", "1", SummaryLevel(FICD9Diagnosis), FCategoryCode, FAgeCategory))
						losDX = null; //throw new ActiveAdviceException(AAExceptionAction.None, "No LOS record found!");
				}
			}
			bool bFoundDX = losDX != null;
			if (bFoundDX)
			{
				recDX.ImportLOS(losDX);
				this.FLOSYear = losDX.LOSYear;
			}

			// { query LOS for proc }
			LengthOfStay losPX = null;
			if (FICD9Procedure != null)
			{
				losPX = new LengthOfStay();
				if (!losPX.Load(FPayGroup, FRegionCode, "P", "2", FICD9Procedure, FCategoryCode, FAgeCategory))
				{
					// query for summary diagnosis
					if (!losPX.Load(FPayGroup, FRegionCode, "P", "1", SummaryLevel(FICD9Procedure), FCategoryCode, FAgeCategory))
						losPX = null; //throw new ActiveAdviceException(AAExceptionAction.None, "No LOS record found!");
				}
			}
			bool bFoundPX = losPX != null;
			if (bFoundPX)
			{
				recPX.ImportLOS(losPX);
				this.FLOSYear = losPX.LOSYear;
			}

			// The strings are being compared for numeric values!!!
			// This code is directly converted from pascal original.
			// This may be a bug in the original code.
			// { Set output properties based on what was found }
			if (bFoundDX && bFoundPX)
			{
				if (String.Compare( recDX.Percentiles[2], recPX.Percentiles[2]) < 0)      // { 50% }
					recDX = recPX;
				else if (recDX.Percentiles[2] == recPX.Percentiles[2])
				{
					if (String.Compare(recDX.Percentiles[5], recPX.Percentiles[5]) < 0)  // { 95% }
						recDX = recPX;
					else if (recDX.Percentiles[5] == recPX.Percentiles[5])
					{
						if (String.Compare(recDX.Percentiles[0], recPX.Percentiles[0]) < 0)   // { 10% }
							recDX = recPX;
					}
				}
				FObservedPatients = recDX.ObservedPatients;
				FVariance = recDX.Variance;
				FAverageStay = recDX.AverageStay;
				FPercentiles = recDX.Percentiles;
			}
			else if (bFoundDX)
			{
				FObservedPatients = recDX.ObservedPatients;
				FVariance = recDX.Variance;
				FAverageStay = recDX.AverageStay;
				FPercentiles = recDX.Percentiles;
			}
			else if (bFoundPX)
			{
				FObservedPatients = recPX.ObservedPatients;
				FVariance = recPX.Variance;
				FAverageStay = recPX.AverageStay;
				FPercentiles = recPX.Percentiles;
			}
			else
			{
				
				throw new ActiveAdviceException(AAExceptionAction.None, 
					String.Format("No LOS data found!  Please check PlanSORG which refers to HCIARegion={0} and  HCIAPayorGroup={1}.",
						/*FORK 1.1*/planSORG.HCIA_LOSRegionWithCode, /*FORK 1.1*/planSORG.HCIA_PayorGroupWithCode ));
			}
		}
	}
}
