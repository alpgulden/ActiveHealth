using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NoteType]
	/// </summary>
	[SPAutoGen("usp_GetNoteTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertNoteType")]
	[SPUpdate("usp_UpdateNoteType")]
	[SPDelete("usp_DeleteNoteType")]
	[SPLoad("usp_LoadNoteType")]
	[TableMapping("NoteType","noteTypeID")]
	public class NoteType : BaseLookupStandard
	{
		[NonSerialized]
		private NoteTypeCollection parentNoteTypeCollection;
		[ColumnMapping("NoteTypeID",(int)0)]
		private int noteTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public NoteType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NoteTypeID
		{
			get { return this.noteTypeID; }
			set { this.noteTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int noteTypeID)
		{
			return base.Load(noteTypeID);
		}

		/// <summary>
		/// Parent NoteTypeCollection that contains this element
		/// </summary>
		public NoteTypeCollection ParentNoteTypeCollection
		{
			get
			{
				return this.parentNoteTypeCollection;
			}
			set
			{
				this.parentNoteTypeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of NoteType objects
	/// </summary>
	[ElementType(typeof(NoteType))]
	public class NoteTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(NoteType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNoteTypeCollection = this;
			else
				elem.ParentNoteTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (NoteType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public NoteType this[int index]
		{
			get
			{
				return (NoteType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((NoteType)oldValue, false);
			SetParentOnElem((NoteType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadNoteTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetNoteTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared NoteTypeCollection which is cached in NSGlobal
		/// </summary>
		public static NoteTypeCollection ActiveNoteTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				NoteTypeCollection col = (NoteTypeCollection)NSGlobal.EnsureCachedObject("ActiveNoteTypes", typeof(NoteTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadNoteTypesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
