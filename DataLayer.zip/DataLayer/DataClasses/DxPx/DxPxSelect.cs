using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	[Flags]
	public enum EnumDxPxFlag
	{
		CMTrigger = 1,
		DMTrigger = 2,
		OPReview = 4,
		IPReview = 8,
		OPReviewOther = 16,
		IPReviewOther = 32,
		Referral = 64
	}
	/// <summary>
	/// Base class for Diagnostic or Procedure selection in the zippycoder.
	/// 
	/// These base classes are not directly used.
	/// After a code is selected from the UI,
	/// a new DiagnoticSelect or ProcedureSelect is constructed and added into either
	/// DiagnosticSelectCollection, or ProcedureSelectCollection.
	/// 
	/// </summary>
	[TableMapping("ICD9Code", null, true)]
	public class DxPxSelect : BaseData
	{
		protected int sourceCollectionIndex = -1;			// This is the index in the collection when this selection was first created
		protected string codeDxOrPx;
		protected string codeType;
		protected string codeValue;
		protected string codeDescription;
		protected string codeLongDescription;
		protected int sequence;								// sequance number specified by the user to order the data
		protected EnumDxPxFlag flags;

		protected int parentSelectionIndex = -1;					// If true this is just a mapping code, don't update it

		public DxPxSelect()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Construct a code selection for ICD9 code.
		/// ICD9 can be both D or P
		/// </summary>
		/// <param name="code"></param>
		public DxPxSelect(ICD9Code code)
		{
			ImportStandardFields(code);
		}

		protected virtual void ImportStandardFields(BaseDxPx code)
		{
			if (code.IsMarkedForDeletion)
				this.MarkDel();
			this.codeDxOrPx = code.DxOrPx;
			this.codeValue = code.CodeValue;
			this.codeDescription = code.CodeDescription;
			this.codeLongDescription = code.CodeLongDescription;
			this.codeType = code.CodeType;
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string CodeDxOrPx
		{
			get { return this.codeDxOrPx; }
			set { this.codeDxOrPx = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string CodeType
		{
			get { return this.codeType; }
			set { this.codeType = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string CodeValue
		{
			get { return this.codeValue; }
			set { this.codeValue = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string CodeDescription
		{
			get { return this.codeDescription; }
			set { this.codeDescription = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string CodeLongDescription
		{
			get { return this.codeLongDescription; }
			set { this.codeLongDescription = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SourceCollectionIndex
		{
			get { return this.sourceCollectionIndex; }
			set { this.sourceCollectionIndex = value; }
		}

		public int ParentSelectionIndex
		{
			get { return this.parentSelectionIndex; }
			set { this.parentSelectionIndex = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Sequence
		{
			get { return this.sequence; }
			set 
			{
				if (this.sequence != value)		// only to be able to save
					this.MarkDirty();
				this.sequence = value; 
			}
		}

		public EnumDxPxFlag Flags
		{
			get { return this.flags; }
			set { this.flags = value; }
		}

		/// <summary>
		/// Create a bit-significant flags from the given
		/// seperate bool values.
		/// </summary>
		/// <param name="CMTrigger"></param>
		/// <param name="DMTrigger"></param>
		/// <param name="OPReview"></param>
		/// <param name="IPReview"></param>
		/// <param name="OPReviewOther"></param>
		/// <param name="IPReviewOther"></param>
		/// <param name="Referral"></param>
		/// <returns></returns>
		public static EnumDxPxFlag MakeDxPxFlags(bool CMTrigger, bool DMTrigger, bool OPReview, bool IPReview, bool OPReviewOther, bool IPReviewOther, bool Referral)
		{
			return
				(EnumDxPxFlag)
				(
					(CMTrigger ? (int)EnumDxPxFlag.CMTrigger : 0) |
					(DMTrigger ? (int)EnumDxPxFlag.DMTrigger : 0) |
					(OPReview ? (int)EnumDxPxFlag.OPReview : 0) |
					(IPReview ? (int)EnumDxPxFlag.IPReview : 0) |
					(OPReviewOther ? (int)EnumDxPxFlag.OPReviewOther : 0) |
					(IPReviewOther ? (int)EnumDxPxFlag.IPReviewOther : 0) |
					(Referral ? (int)EnumDxPxFlag.Referral : 0)
				);
		}

		/// <summary>
		/// Extract the boolean values from the given bit-significant flags.
		/// </summary>
		/// <param name="flags"></param>
		/// <param name="CMTrigger"></param>
		/// <param name="DMTrigger"></param>
		/// <param name="OPReview"></param>
		/// <param name="IPReview"></param>
		/// <param name="OPReviewOther"></param>
		/// <param name="IPReviewOther"></param>
		/// <param name="Referral"></param>
		public static void ExtractDxPxFlags(EnumDxPxFlag flags, ref bool CMTrigger, ref bool DMTrigger, ref bool OPReview, ref bool IPReview, ref bool OPReviewOther, ref bool IPReviewOther, ref bool Referral)
		{
			CMTrigger = (flags & EnumDxPxFlag.CMTrigger) != 0;
			DMTrigger = (flags & EnumDxPxFlag.DMTrigger) != 0;
			OPReview = (flags & EnumDxPxFlag.OPReview) != 0;
			IPReview = (flags & EnumDxPxFlag.IPReview) != 0;
			OPReviewOther = (flags & EnumDxPxFlag.OPReviewOther) != 0;
			IPReviewOther = (flags & EnumDxPxFlag.IPReviewOther) != 0;
			Referral = (flags & EnumDxPxFlag.Referral) != 0;
		}

		/// <summary>
		/// Check the trigger items from the linked plansorg.
		/// If there's any related trigger item code range, use the CM and DM trigger flags.
		/// </summary>
		/// <param name="erc"></param>
		public void SetFlagsByRelatedTriggerItem(BaseForEventCMSReferral erc)
		{
			if (erc == null)
				return;
			// Check if there's any related trigger items in the linked plan of ERC.
			int planTriggerListID = erc.PlanSORGLog.PlanTriggerListId;
			TriggerItemCollection triggerItemsInRange = new TriggerItemCollection();
			triggerItemsInRange.LoadTriggerItemsInCodeRange(this.CodeDxOrPx, this.CodeType, this.CodeValue, erc.ERCStartDate, planTriggerListID);
			if (triggerItemsInRange.Count > 0)
			{
				// a related trigger item found.  use it.
				TriggerItem ti = triggerItemsInRange[0];
				if (ti.CareManagement)
					this.flags |= EnumDxPxFlag.CMTrigger;		// set the CM flag.
				if (ti.DiseaseManagement)
					this.flags |= EnumDxPxFlag.DMTrigger;		// set the DM flag.
			}
		}

		/// <summary>
		/// Check the special procedure items from the linked plansorg.
		/// If there's any related special procedure item code range, use the OPReview, IPReview, OPReviewOther, IPReviewOther, Referral
		/// </summary>
		/// <param name="erc"></param>
		public void SetFlagsByRelatedSpecialProcedureItem(BaseForEventCMSReferral erc)
		{
			if (erc == null)
				return;
			// Check if there's any special procedure items in the linked plan of ERC.
			int planTriggerListID = erc.PlanSORGLog.PlanTriggerListId;
			SpecialProcedureItemCollection specProcItemsInRange = new SpecialProcedureItemCollection();
			specProcItemsInRange.LoadSpecialProcedurItemsInCodeRange(this.CodeDxOrPx, this.CodeType, this.CodeValue, erc.ERCStartDate, planTriggerListID);
			if (specProcItemsInRange.Count > 0)
			{
				// a related special procedure item found.  use it.
				SpecialProcedureItem spi = specProcItemsInRange[0];
				if (spi.InPatientReview)
					this.flags |= EnumDxPxFlag.IPReview;		// set the IPReview flag.
				if (spi.OutPatientReview)
					this.flags |= EnumDxPxFlag.OPReview;		// set the OPReview flag.
				if (spi.InPatientReviewOther)
					this.flags |= EnumDxPxFlag.IPReviewOther;		// set the IPReviewOther flag.
				if (spi.OutPatientReviewOther)
					this.flags |= EnumDxPxFlag.OPReviewOther;		// set the OPReviewOther flag.
				if (spi.Referral)
					this.flags |= EnumDxPxFlag.Referral;			// set the Referal flag.
			}
		}

		/// <summary>
		/// Loads and returns the associated diagnostic or procedure code.
		/// </summary>
		/// <returns></returns>
		public BaseDxPx GetDxPxCode()
		{
			return DxPxCodeClassFactory.CreateAndLoadDxPxInstance(this.codeType, this.codeValue, this.codeDxOrPx);
		}
	}

	/// <summary>
	/// Base collection object to hold selected diagnosis or procedure codes
	/// This class is not concrete.  Use an actual implementation for
	/// either Diagnostic or Procedure
	/// </summary>
	[ElementType(typeof(DxPxSelect))]
	public abstract class DxPxSelectCollection : BaseDataCollection
	{
		public DxPxSelectCollection()
		{
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public DxPxSelect this[int index]
		{
			get
			{
				return (DxPxSelect)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		public abstract int Add(BaseDxPx codeObj);

		/// <summary>
		/// Add a new selection based on the given DxPx code.
		/// </summary>
		/// <param name="codeObj"></param>
		/// <returns></returns>
		public int AddAsNewSelection(BaseDxPx codeObj, bool linked)
		{
			int newSequence = 10;
			if (this.Count > 0)
			{
				newSequence = this[ this.Count - 1 ].Sequence + (linked ? 1 : 10);
			}

			int i = this.Add(codeObj);
			if (i >= 0)
			{
				this[i].MarkNew();
				this[i].Sequence = newSequence;
			}

			return i;
		}

		/// <summary>
		/// Add as new selection and also set the parent selection index.
		/// This is used to add mapped codes.
		/// </summary>
		/// <param name="codeObj"></param>
		/// <param name="parentSelectionIndex"></param>
		/// <returns></returns>
		public int AddAsNewSelection(BaseDxPx codeObj, int parentSelectionIndex)
		{
			int i = AddAsNewSelection(codeObj, parentSelectionIndex >= 0);
			DxPxSelect dxPx = null;
			if (i >= 0)
			{
				dxPx = (DxPxSelect)this.GetAt(i);
				dxPx.ParentSelectionIndex = parentSelectionIndex;
			}

			ProcedureSelect px = dxPx as ProcedureSelect;

			if (px != null)		// if the newly added code is a procedure, link the parent of it to this
			{
				if (dxPx != null && parentSelectionIndex >= 0 && parentSelectionIndex < this.Count)
				{
					// the mapped code is set to the parent procedure as linked code type and linked code
					ProcedureSelect parentPx = (ProcedureSelect)this[parentSelectionIndex];

					parentPx.LinkedPxType = px.CodeType;
					parentPx.LinkedPxCode = px.CodeValue;
				}
			}

			return i;
		}

		public int IndexOf(DxPxSelect sel)
		{
			for (int i = 0; i < this.Count; i++)
			{
				if (sel == this[i])
					return i;
			}
			return -1;
		}

		/// <summary>
		/// Sorts the collection by the sequence values.
		/// </summary>
		public void SortBySequence()
		{
			DxPxSelectCollection cloneCol = (DxPxSelectCollection)this.Clone(true, false);
			CollectionUtil.SortBy(this, true, false, new string[] { "sequence" });
			
			// Rearrange parent selection indices as they may have been changed
			for (int i = 0; i < cloneCol.Count; i++)
			{
				DxPxSelect sel = cloneCol[i];
				if (sel.ParentSelectionIndex >= 0)		// if there's a parent, find it's new collection index and set
				{
					DxPxSelect parentSelection = cloneCol[sel.ParentSelectionIndex];
					// Find the new index of the item.
					int newParentIndex = this.IndexOf(parentSelection);
					sel.ParentSelectionIndex = newParentIndex;
				}
			}
		}

		public void Enumerate()
		{
			CollectionUtil.EnumerateCollectionMember(this, "Sequence", 10, 10);
		}

		public void RearrangeLinkedSequences()
		{
			for (int i = 0; i < this.Count; i++)
			{
				DxPxSelect sel = this[i];
				if (sel.ParentSelectionIndex >= 0)
					sel.Sequence = this[sel.ParentSelectionIndex].Sequence + 1;
			}
		}

		public int GetPreviousMainItemIndex(int index)
		{
			for (int i = index - 1; i >= 0; i--)
			{
				DxPxSelect sel = this[i];
				if (sel.ParentSelectionIndex < 0)
					return i;
			}
			return -1;
		}

		public DxPxSelect GetPreviousMainItem(int index)
		{
			int i = GetPreviousMainItemIndex(index);
			if (i >= 0)
                return this[i];
			else
				return null;
		}

		public int GetNextMainItemIndex(int index)
		{
			for (int i = index + 1; i < this.Count; i++)
			{
				DxPxSelect sel = this[i];
				if (sel.ParentSelectionIndex < 0)
					return i;
			}
			return -1;
		}

		public DxPxSelect GetNextMainItem(int index)
		{
			int i = GetNextMainItemIndex(index);
			if (i >= 0)
				return this[i];
			else
				return null;
		}

	}


	/// <summary>
	/// This class is used to hold information for the selected diagnostic codes.
	/// </summary>
	public class DiagnosticSelect : DxPxSelect
	{
		[NonSerialized]
		private DiagnosticSelectCollection parentDiagnosticSelectCollection;
		private int axis;

		public DiagnosticSelect()
		{
			this.codeDxOrPx = BaseDxPx.DxPxDiagnostic;
		}


		/// <summary>
		/// Construct a code selection for any given 
		/// diagnosis or procedure code
		/// </summary>
		/// <param name="code"></param>
		public DiagnosticSelect(BaseDxPx code)
		{
			if (code.DxOrPx != BaseDxPx.DxPxDiagnostic)
				throw new ActiveAdviceException(AAExceptionAction.None, "Diagnostic selection can only be constructed for a diagnostic code object");
			ImportStandardFields(code);
		}

		/// <summary>
		/// Construct a code selection for DSM4 code.
		/// </summary>
		/// <param name="code"></param>
		public DiagnosticSelect(DSM4Code code)
		{
			ImportStandardFields(code);
		}

		protected override void ImportStandardFields(BaseDxPx code)
		{
			base.ImportStandardFields (code);

			if (this.IsDSM4Asix4Code)
				this.axis = 4;
		}

		[FieldValuesMember("ValuesOf_Axis")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int Axis
		{
			get { return this.axis; }
			set 
			{
				if (this.codeType == BaseDxPx.CodeTypeDSM4)
					if (this.codeValue != null)
						if (this.codeValue.Length >= 5)
							if (this.codeValue.Substring(0, 5) == "AXIS4")
							{
								this.axis = 4;		// if the axis code has AXIS4 prefix, set axis to 4 automatically
								return;
							}
				this.axis = value;
			}
		}

		/// <summary>
		/// Parent DiagnosticSelectCollection that contains this element
		/// </summary>
		public DiagnosticSelectCollection ParentDiagnosticSelectCollection
		{
			get
			{
				return this.parentDiagnosticSelectCollection;
			}
			set
			{
				this.parentDiagnosticSelectCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Returns true, if this is a selection of DSM4, Axis4 code.
		/// </summary>
		public bool IsDSM4Asix4Code
		{
			get
			{
				if (this.codeType == BaseDxPx.CodeTypeDSM4 &&
					this.codeValue != null && this.codeValue.StartsWith("AXIS4"))
					return true;
				else
					return false;
			}
		}

		public int[] ValuesOf_Axis
		{
			get
			{
				switch (this.codeType)
				{
					case BaseDxPx.CodeTypeDSM4:
					{
						if (this.IsDSM4Asix4Code)
							return new int[] { 4 };		// Axis values for DSM4 AXIS4 code
						else
							return new int[] { 1, 2 };	// Axis values for other DSM4 codes
					}
					case BaseDxPx.CodeTypeICD9:
						return new int[] { 3 };			// return possible field values
					default:
						return new int[] { };			// possible cases
				}
			}
		}

		/// <summary>
		/// Diagnostic code for display.  
		/// For DSM4, the first 6 characters if 7 characters or more found.
		/// Otherwise returns all characters.
		/// </summary>
		public string DisplayCode
		{
			get 
			{ 
				if (this.codeType != BaseDxPx.CodeTypeDSM4)
					return this.codeValue;

				// if DSM4, return only first 6 characters.
				if (this.codeValue == null)
					return null;
				if (this.codeValue.Length < 7)
					return this.codeValue;
				return this.codeValue.Substring(0, 6);		// only first 6 chars.
			}
		}

	}

	/// <summary>
	/// This class is used to hold information for the selected procedure codes.
	/// </summary>
	public class ProcedureSelect : DxPxSelect
	{
		[NonSerialized]
		private ProcedureSelectCollection parentProcedureSelectCollection;
		private string modifier1;
		private string modifier2;
		private string modifier3;
		private DateTime scheduled;
		private string linkedPxType;			// the mapped procedure
		private string linkedPxCode;
		
		public ProcedureSelect()
		{
			this.codeDxOrPx = BaseDxPx.DxPxProcedure;
		}

		/// <summary>
		/// Construct a code selection for any given 
		/// diagnosis or procedure code
		/// </summary>
		/// <param name="code"></param>
		public ProcedureSelect(BaseDxPx code)
		{
			if (code.DxOrPx != BaseDxPx.DxPxProcedure)
				throw new ActiveAdviceException(AAExceptionAction.None, "Procedure selection can only be constructed for a procedure code object");
			ImportStandardFields(code);
		}

		/// <summary>
		/// Construct a code selection for CPT code.
		/// </summary>
		/// <param name="code"></param>
		public ProcedureSelect(CPTCode code)
		{
			ImportStandardFields(code);
		}

		/// <summary>
		/// Construct a code selection for DENTAL code.
		/// </summary>
		/// <param name="code"></param>
		public ProcedureSelect(DentalCode code)
		{
			ImportStandardFields(code);
		}

		/// <summary>
		/// Construct a code selection for HCPCS code.
		/// </summary>
		/// <param name="code"></param>
		public ProcedureSelect(HCPCSCode code)
		{
			ImportStandardFields(code);
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string Modifier1
		{
			get { return this.modifier1; }
			set { this.modifier1 = value; }
		}
		
		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string Modifier2
		{
			get { return this.modifier2; }
			set { this.modifier2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string Modifier3
		{
			get { return this.modifier3; }
			set { this.modifier3 = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime Scheduled
		{
			get { return this.scheduled; }
			set { this.scheduled = value; }
		}

		private string FormatModifier(string modifier)
		{
			if (modifier == "__")
				return null;
			else
				return modifier.PadLeft(2, '_');
		}

		[ControlType(EnumControlTypes.TextBox, InputMask="CC-CC-CC")]
		public string Modifiers
		{
			get
			{
				return String.Format("{0}-{1}-{2}", FormatModifier(this.modifier1), FormatModifier(this.modifier2), FormatModifier(this.modifier3));
			}
			set
			{
				if (value == null)
				{
					this.modifier1 = null;
					this.modifier2 = null;
					this.modifier3 = null;
				}
				else
				{
					string s = value.Replace('_', ' '); // " " + value + " ";
					string[] terms = s.Split('-');
					this.modifier1 = terms[0].Trim();
					if (terms.Length > 1)
						this.modifier2 = terms[1].Trim();
					if (terms.Length > 2)
						this.modifier3 = terms[2].Trim();
				}

			}
		}

		/// <summary>
		/// Parent ProcedureSelectCollection that contains this element
		/// </summary>
		public ProcedureSelectCollection ParentProcedureSelectCollection
		{
			get
			{
				return this.parentProcedureSelectCollection;
			}
			set
			{
				this.parentProcedureSelectCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LinkedPxType
		{
			get { return this.linkedPxType; }
			set { this.linkedPxType = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LinkedPxCode
		{
			get { return this.linkedPxCode; }
			set { this.linkedPxCode = value; }
		}

		public string ProcedureTypeAndCode
		{
			get
			{
				return String.Format("{0}-{1}", this.codeType , this.codeValue);
			}
		}

		public string ProcedureFullDescription
		{
			get
			{
				return String.Format("{0} {1}-{2}", this.codeType, this.codeValue, this.codeDescription);
			}
		}

	}

	/// <summary>
	/// Extra data that is kept on the diagnostic selection collection.
	/// </summary>
	[TableMapping(null)]
	public class DiagnosticSelectionData : BaseData
	{
		// when list of diagnostic codes is being selected by the user, 
		// an admitting diagnostic code can be set
		private string admittingDiagnosisType;
		private string admittingDiagnosisCode;
		private string admittingDiagCodeDisplay;

		private int dSM4Axis5Best = -1;				// -1 is null
		private int dSM4Axis5Start = -1;
		private int dSM4Axis5Current = -1;

		private DiagnosticSelectCollection parentDiagnosticSelections;

		[ControlType(EnumControlTypes.TextBox)]
		public string AdmittingDiagnosisType
		{
			get { return this.admittingDiagnosisType; }
			set 
			{ 
				this.admittingDiagnosisType = value; 
				this.admittingDiagCodeDisplay = null;
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string AdmittingDiagnosisCode
		{
			get { return this.admittingDiagnosisCode; }
			set 
			{ 
				this.admittingDiagnosisCode = value; 
				this.admittingDiagCodeDisplay = null;
			}
		}

		public static string FormatDxPxCodeDisplay(string type, string code, string dxOrPx)
		{
			string codeDisplay = null;
			if (type == null || code == null)
				codeDisplay = null;
			else
			{
				BaseDxPx dxPx = DxPxCodeClassFactory.CreateAndLoadDxPxInstance(type, code, dxOrPx);
				if (dxPx != null)
					codeDisplay = dxPx.CodeDescription;
			}
			return codeDisplay;
		}

		/// <summary>
		/// Returns a user-friendly display string for the admitting diagnostic code type and value.
		/// </summary>
		[ControlType(EnumControlTypes.TextBox)]
		public string AdmittingDiagCodeDisplay
		{
			get 
			{
				if (admittingDiagCodeDisplay == null)
				{
					admittingDiagCodeDisplay = FormatDxPxCodeDisplay(admittingDiagnosisType, admittingDiagnosisCode,  BaseDxPx.DxPxDiagnostic);
				}
				return this.admittingDiagCodeDisplay;
			}
		}

		public ActiveAdvice.DataLayer.DiagnosticSelectCollection ParentDiagnosticSelections
		{
			get { return this.parentDiagnosticSelections; }
			set { this.parentDiagnosticSelections = value; }
		}

		[FieldValuesMember("ValuesOf_DSM4Axis5")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ClientValidators=EnumClientValidators.Integer, ValueForNull=(int)-1, MinValue=0, MaxValue=100)]
		public int DSM4Axis5Best
		{
			get { return this.dSM4Axis5Best; }
			set { this.dSM4Axis5Best = value; }
		}

		[FieldValuesMember("ValuesOf_DSM4Axis5")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ClientValidators=EnumClientValidators.Integer, ValueForNull=(int)-1, MinValue=0, MaxValue=100)]
		public int DSM4Axis5Start
		{
			get { return this.dSM4Axis5Start; }
			set { this.dSM4Axis5Start = value; }
		}

		[FieldValuesMember("ValuesOf_DSM4Axis5")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ClientValidators=EnumClientValidators.Integer, ValueForNull=(int)-1, MinValue=0, MaxValue=100)]
		public int DSM4Axis5Current
		{
			get { return this.dSM4Axis5Current; }
			set { this.dSM4Axis5Current = value; }
		}

		public object[,] ValuesOf_DSM4Axis5
		{
			get
			{
				return new object[,] 
					{ 
						{ (int)0, "0 Inadequate information" },
						{ (int)10, "1..10 Persistent danger to self or others" },
						{ (int)20, "11..20 Some danger to self or others" },
						{ (int)30, "21..30 Serious impairment in judgment" },
						{ (int)40, "31..40 Major impairment in several areas" },
						{ (int)50, "41..50 Serious symptoms or impairment" },
						{ (int)60, "51..60 Moderate symptoms or impairment" },
						{ (int)70, "61..70 Some mild symptoms or impairment" },
						{ (int)80, "71..80 Transient symptoms or slight impairment" },
						{ (int)90, "81..90 Absent or minimal symptoms" },
						{ (int)100, "91..100 Superior functioning" }
						/*
						{ (int)0, "0 Inadequate information" },
						{ (int)10, "1-10 Persistent danger to self or others" },
						{ (int)20, "Some danger to self or others" },
						{ (int)30, "Serious impairment in judgment" },
						{ (int)40, "Major impairment in several areas" },
						{ (int)50, "Serious symptoms or impairment" },
						{ (int)60, "Moderate symptoms or impairment" },
						{ (int)70, "Some mild symptoms or impairment" },
						{ (int)80, "Transient symptoms or slight impairment" },
						{ (int)90, "Absent or minimal symptoms" },
						{ (int)100, "Superior functioning" }*/
					}; // return possible field values
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of DiagnosticSelect objects
	/// </summary>
	[ElementType(typeof(DiagnosticSelect))]
	public class DiagnosticSelectCollection : DxPxSelectCollection
	{
		private DiagnosticSelectionData data;			// admitting diag type, code data.

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(DiagnosticSelect elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentDiagnosticSelectCollection = this;
			else
				elem.ParentDiagnosticSelectCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (DiagnosticSelect elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public DiagnosticSelect this[int index]
		{
			get
			{
				return (DiagnosticSelect)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((DiagnosticSelect)oldValue, false);
			SetParentOnElem((DiagnosticSelect)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Make a new selection object for the passed code object
		/// and add to collection.
		/// </summary>
		/// <param name="codeObj"></param>
		public override int Add(BaseDxPx codeObj)
		{
			DiagnosticSelect diagSel = new DiagnosticSelect(codeObj);
			return this.AddRecord(diagSel);
		}

		/// <summary>
		/// Create a diagnostic selection object from the given
		/// EventReferrralDiagnose to be hold in this collection
		/// </summary>
		/// <param name="diagnose"></param>
		/// <returns></returns>
		public int Add(EventReferralDiagnose diagnose, int sourceIndex)
		{
			BaseDxPx code = diagnose.GetDiagnosticObject();
			if (code == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "The selected code '{0}' can't be found in the database", diagnose.DiagnosisCode);
			int index = this.Add(code);

			DiagnosticSelect sel = this[index];
			// copy flags
			sel.IsMarkedForDeletion = diagnose.IsMarkedForDeletion;
			sel.IsNew = diagnose.IsNew;
			sel.IsDirty = diagnose.IsDirty;

			sel.SourceCollectionIndex = sourceIndex;
			diagnose.CopyMembersToSelection(sel);
			//sel.Flag = diagnose.

			return index;
			
		}
		
		/// <summary>
		/// Create a diagnostic selection object from the given
		/// CMSDiagnosticProcedure to be hold in this collection
		/// </summary>
		/// <param name="diagnose"></param>
		public void AddDiagFromCMS(CMSDiagnosticProcedure diagnose)
		{
			BaseDxPx code = DxPxCodeClassFactory.CreateAndLoadDxPxInstance(diagnose.DxPxType, diagnose.DxPxCode, BaseDxPx.DxPxDiagnostic);
			if (code == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "The selected code '{0}' can't be found in the database", diagnose.DxPxCode);
			int index = this.Add(code);

			DiagnosticSelect sel = this[index];

			// copy flags
			sel.IsMarkedForDeletion = diagnose.IsMarkedForDeletion;
			sel.IsNew = diagnose.IsNew;
			sel.IsDirty = diagnose.IsDirty;
			sel.Axis = diagnose.DSM4axis;
			sel.Sequence = diagnose.SequenceID;
		}

		
		/// <summary>
		/// Extra selection data like the admitting diag type and code
		/// </summary>
		public ActiveAdvice.DataLayer.DiagnosticSelectionData Data
		{
			get 
			{ 
				// Ensure the object is always created
				if (this.data == null)
				{
					this.data = new DiagnosticSelectionData();
					this.data.ParentDiagnosticSelections = this;
				}
				return this.data;
			}
		}

		// { Find first ICD9/DSM4 diagnosis. }
		public string FindICD9Diagnosis()
		{
			for (int i = 0; i < this.Count; i++)
			{	
				if (!this[i].IsMarkedForDeletion && !this[i].IsNewlyDeletedInDB)
				{
					if (this[i].CodeType == BaseDxPx.CodeTypeICD9)
						return this[i].CodeValue;
					else if (this[i].CodeType == BaseDxPx.CodeTypeDSM4 && this[i].Axis < 3)
					{
						// accept dsm4 code just as if was really an icd9 code, but need to
						// truncate it to 6 characters first to conform with icd9 standard - dkh
						string code = this[i].CodeValue;
						if (code.Length < 6)		// this is normally not possible
							return code.Trim();
						else
							return code.Substring(0, 6).Trim();
					}
				}
			}
			return null;
		}

		// Count only valid codes
		public int CountValidCodes()
		{
			int count = 0;
			for (int i = 0; i < this.Count; i++)
			{
				if (!this[i].IsMarkedForDeletion && !this[i].IsNewlyDeletedInDB)
				{
					count++;
				}
			}
			return count;
		}
	}

	/// <summary>
	/// Strongly typed collection of ProcedureSelect objects
	/// </summary>
	[ElementType(typeof(ProcedureSelect))]
	public class ProcedureSelectCollection : DxPxSelectCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProcedureSelect elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProcedureSelectCollection = this;
			else
				elem.ParentProcedureSelectCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProcedureSelect elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProcedureSelect this[int index]
		{
			get
			{
				return (ProcedureSelect)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProcedureSelect)oldValue, false);
			SetParentOnElem((ProcedureSelect)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Make a new selection object for the passed code object
		/// and add to collection.
		/// </summary>
		/// <param name="codeObj"></param>
		public override int Add(BaseDxPx codeObj)
		{
			ProcedureSelect procSel = new ProcedureSelect(codeObj);
			return this.AddRecord(procSel);
		}

		/// <summary>
		/// Create a procedure selection object from the given
		/// EventReferrralProcedure to be hold in this collection
		/// </summary>
		/// <param name="procedure"></param>
		/// <returns></returns>
		public int Add(EventReferralProcedure procedure, int sourceIndex)
		{
			BaseDxPx code = procedure.GetProcedureObject();
			int index = this.Add(code);
			ProcedureSelect sel = this[index];

			// copy flags
			sel.IsMarkedForDeletion = procedure.IsMarkedForDeletion;
			sel.IsNew = procedure.IsNew;
			sel.IsDirty = procedure.IsDirty;

			sel.SourceCollectionIndex = sourceIndex;
			procedure.CopyMembersToSelection(sel);

			if (procedure.LinkedPxType != null && procedure.LinkedPxCode != null)
			{
				// if there's a linked procedure code, add it too.
			
				BaseDxPx linkedCode = procedure.GetLinkedProcedureObject();
				int linkedIndex = this.Add(linkedCode);
				ProcedureSelect linkedSel = this[linkedIndex];		// just for display purpose
				linkedSel.ParentSelectionIndex = index;		// the procedure selection object that's referring to this.
				linkedSel.SourceCollectionIndex = linkedIndex;
				linkedSel.Sequence = sel.Sequence + 1;		// just after the parent
			}

			return index;
		}

		/// <summary>
		/// Create a procedure selection object from the given
		/// CMSDiagnosticProcedure to be hold in this collection
		/// </summary>
		/// <param name="diagnose"></param>
		public void AddProcFromCMS(CMSDiagnosticProcedure diagnose)
		{
			BaseDxPx code = DxPxCodeClassFactory.CreateAndLoadDxPxInstance(diagnose.DxPxType, diagnose.DxPxCode, BaseDxPx.DxPxProcedure);
			if (code == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "The selected code '{0}' can't be found in the database", diagnose.DxPxCode);
			int index = this.Add(code);

			ProcedureSelect sel = this[index];

			// copy flags
			sel.IsMarkedForDeletion = diagnose.IsMarkedForDeletion;
			sel.IsNew = diagnose.IsNew;
			sel.IsDirty = diagnose.IsDirty;
			sel.Sequence = diagnose.SequenceID;
		}

		// { Find first ICD9 procedure }
		public string FindICD9Procedure()
		{
			for (int i = 0; i < this.Count; i++)
			{
				if (!this[i].IsMarkedForDeletion && !this[i].IsNewlyDeletedInDB)
				{
					if (this[i].CodeType == BaseDxPx.CodeTypeICD9)
						return this[i].CodeValue;
					if (this[i].LinkedPxType == BaseDxPx.CodeTypeICD9)
						return this[i].LinkedPxCode;
				}
			}
			return null;
		}

		// Count only valid codes.  The LOS calculation depends on the number of 
		// non-linked, valid codes.
		public int CountValidCodes()
		{
			int count = 0;
			for (int i = 0; i < this.Count; i++)
			{
				if (!this[i].IsMarkedForDeletion && !this[i].IsNewlyDeletedInDB && (this[i].ParentSelectionIndex < 0 /* FORK 1.0 */) )
				{
					count++;
				}
			}
			return count;
		}

		/// <summary>
		/// Sorts the collection by the codeDescription members.
		/// </summary>
		public void SortBy_CodeDescription(bool ascending, bool ignoreCase)
		{
			CollectionUtil.SortBy(this, ascending, ignoreCase, new string[] { "codeDescription" });		
		}
	}
}
