using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CPTCode]
	/// </summary>
	[SPAutoGen("usp_GetLinkedCPTCodesForICD9Code","SelectRelatedFromLinkedTable.sptpl","ICD9toCPTMapping, cPTCode, iCD9Code, diagOrProc")]
	/*[SPAutoGen("usp_SearchCPTCodes","SearchByArgs.sptpl","cPTCode, shortTitle, active",
		 InjectPreOperation="SET ROWCOUNT @rowCount  -- limit the records returned",
		 InjectWhere="AND [CPTCode].[CPTCode] >= @startCode -- page start",
		 InjectParameters="@rowCount int, @startCode varchar(20)")]*/
	[SPAutoGen("usp_SearchCPTCodes",null, ManuallyManaged=true)]
	[SPAutoGen("usp_GetActiveCPTCodes","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllCPTCodes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertCPTCode")]
	[SPUpdate("usp_UpdateCPTCode")]
	[SPDelete("usp_DeleteCPTCode")]
	[SPLoad("usp_LoadCPTCode")]
	[TableMapping("CPTCode","cPTCode",true)]
	public class CPTCode : BaseDxPx
	{
		[NonSerialized]
		private CPTCodeCollection parentCPTCodeCollection;
		[ColumnMapping("CPTCode")]
		private string cPTCode;
		[ColumnMapping("ICD9Code1")]
		private string iCD9Code1;
		[ColumnMapping("ICD9Code2")]
		private string iCD9Code2;
		[ColumnMapping("TableIndicator")]
		private string tableIndicator;
		[ColumnMapping("ASCPaymentGroup")]
		private string aSCPaymentGroup;
		[ColumnMapping("ListBGroup1")]
		private string listBGroup1;
		[ColumnMapping("ListBGroup2")]
		private string listBGroup2;
		[ColumnMapping("ShortTitle")]
		private string shortTitle;
		[ColumnMapping("LongTitle")]
		private string longTitle;
		[ColumnMapping("Active")]
		private bool active = true;
		[ColumnMapping("CPTTip")]
		private string cPTTip;
	
		public CPTCode()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string Code
		{
			get { return this.cPTCode; }
			set { this.cPTCode = value; }
		}

		public CPTCode(string cPTCode, string shortTitle, string longTitle)
		{
			this.NewRecord(); // initialize record state
			this.cPTCode = cPTCode;
			this.shortTitle = shortTitle;
			this.longTitle = longTitle;
		}

		public CPTCode(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		#region BaseDxPx overridables

		public override string CodeType
		{
			get { return CodeTypeCPT; }
			set { throw new ActiveAdviceException(AAExceptionAction.None, "You can't set code type for CPT"); }
		}

		public override string DxOrPx
		{
			get { return DxPxProcedure; }
			set { throw new ActiveAdviceException(AAExceptionAction.None, "You can't set dx/px for CPT"); }
		}

		public override string CodeDescription
		{
			get { return this.shortTitle; }
			set { this.shortTitle = value; }
		}

		public override string CodeLongDescription
		{
			get { return this.longTitle; }
			set { this.longTitle = value; }
		}

		public override string CodeValue
		{
			get { return this.Code; }
			set { this.Code = value; }
		}

		public override bool Incomplete
		{
			get { return false; }
			set { }
		}


		#endregion


		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string ICD9Code1
		{
			get { return this.iCD9Code1; }
			set { this.iCD9Code1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string ICD9Code2
		{
			get { return this.iCD9Code2; }
			set { this.iCD9Code2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string TableIndicator
		{
			get { return this.tableIndicator; }
			set { this.tableIndicator = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string ASCPaymentGroup
		{
			get { return this.aSCPaymentGroup; }
			set { this.aSCPaymentGroup = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=3)]
		public string ListBGroup1
		{
			get { return this.listBGroup1; }
			set { this.listBGroup1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=3)]
		public string ListBGroup2
		{
			get { return this.listBGroup2; }
			set { this.listBGroup2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string ShortTitle
		{
			get { return this.shortTitle; }
			set { this.shortTitle = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string LongTitle
		{
			get { return this.longTitle; }
			set { this.longTitle = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string CPTTip
		{
			get { return this.cPTTip; }
			set { this.cPTTip = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public override bool Load(string cPTCode)
		{
			return base.Load(cPTCode);
		}

		/// <summary>
		/// Parent CPTCodeCollection that contains this element
		/// </summary>
		public CPTCodeCollection ParentCPTCodeCollection
		{
			get
			{
				return this.parentCPTCodeCollection;
			}
			set
			{
				this.parentCPTCodeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Return all the mapped ICD9 codes for this CPT code
		/// </summary>
		/// <returns></returns>
		public ICD9CodeCollection GetMappedICD9Codes()
		{
			if (this.cPTCode != null)
			{
				ICD9CodeCollection icd9col = new ICD9CodeCollection();
				if (icd9col.LoadLinkedICD9CodesForCPTCode(-1, this.cPTCode) > 0)
					return icd9col;
			}
			return null;
		}

	}

	/// <summary>
	/// Strongly typed collection of CPTCode objects
	/// </summary>
	[ElementType(typeof(CPTCode))]
	public class CPTCodeCollection : BaseDxPxCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CPTCode elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCPTCodeCollection = this;
			else
				elem.ParentCPTCodeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CPTCode elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CPTCode this[int index]
		{
			get
			{
				return (CPTCode)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CPTCode)oldValue, false);
			SetParentOnElem((CPTCode)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads all active CPT codes.
		/// </summary>
		public int LoadActiveCPTCodes(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveCPTCodes", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllCPTCodes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllCPTCodes", maxRecords, this, false);
		}

		/// <summary>
		/// Search cpt codes by given args
		/// </summary>
		public int SearchCPTCodes(int maxRecords, string startCode, string cPTCode, string shortTitle, bool active)
		{
			return this.SearchCPTCodes(maxRecords, startCode, cPTCode, shortTitle, active,false,0);
		}

		/// <summary>
		/// Search cpt codes by given args
		/// </summary>
		public int SearchCPTCodes(int maxRecords, string startCode, string cPTCode, string shortTitle, bool active, bool guidelineLinkedOnly, int guidelineSourceSetID)
		{
			string storedProcName = "usp_SearchCPTCodes";
			if (guidelineLinkedOnly)
				storedProcName = "usp_SearchCPTGuidelineCodes";
			this.Clear();
			
				return SqlData.SPExecReadCol(storedProcName, -1, this, false, 
					new object[] { 
									 maxRecords < 0 ? 0 : maxRecords,
									 startCode,
									 SQLDataDirect.MakeDBValue(cPTCode), 
									 SQLDataDirect.MakeDBValue(shortTitle), 
									 SQLDataDirect.MakeDBValue( active, false),
									 SQLDataDirect.MakeDBValue(guidelineSourceSetID,0)});
		
		}

		/// <summary>
		/// Search the active CPT Codes by the given args
		/// </summary>
		/// <param name="maxRecords"></param>
		/// <param name="cPTCode"></param>
		/// <param name="shortTitle"></param>
		/// <returns></returns>
		public int SearchCPTCodes(int maxRecords, string startCode, string cPTCode, string shortTitle)
		{
			return SearchCPTCodes(maxRecords, startCode, cPTCode, shortTitle, true);
		}

		#region BaseDxPxCollection overrides
		
		
		public override int Search(string code, string diagOrProc, string description, bool guidelineLinkedOnly, int guidelineSourceSetID)
		{
			// ignore diagOrProc, CPT is always procedure
			return this.SearchCPTCodes(BaseDxPxCollection.MAXRECORDS, "", code, description, true, guidelineLinkedOnly, guidelineSourceSetID);
		}

		public override int SearchNext(string code, string diagOrProc, string description, bool guidelineLinkedOnly, int guidelineSourceSetID)
		{
			if (this.Count > 0)
			{
				CPTCode last = this[this.Count - 1];
				//return this.SearchICD9Codes(BaseDxPxCollection.MAXRECORDS, last.Code, last.DiagOrProc, code, diagOrProc, description);
				return this.SearchCPTCodes(BaseDxPxCollection.MAXRECORDS, last.Code, code, description,true, guidelineLinkedOnly,guidelineSourceSetID);
			}
			return 0;
		}

		#endregion

		/// <summary>
		/// For a given ICD9 code, finds all the linked CPT codes and loads them into the collection.
		/// </summary>
		public int LoadLinkedCPTCodesForICD9Code(int maxRecords, string iCD9Code, string diagOrProc)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetLinkedCPTCodesForICD9Code", maxRecords, this, false, new object[] { iCD9Code, diagOrProc });
		}

		/// <summary>
		/// For a given ICD9 procedure code, finds all the linked CPT codes and loads them into the collection.
		/// </summary>
		/// <param name="maxRecords"></param>
		/// <param name="iCD9Code"></param>
		/// <returns></returns>
		public int LoadLinkedCPTCodesForICD9Code(int maxRecords, string iCD9procedureCode)
		{
			return LoadLinkedCPTCodesForICD9Code(maxRecords, iCD9procedureCode, BaseDxPx.DxPxProcedure);
		}

	}
}
