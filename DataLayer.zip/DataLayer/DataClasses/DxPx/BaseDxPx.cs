using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Flags that determine whether this code can be used for diag or proc
	/// </summary>
	/*public enum EnumDiagOrProc
	{
		Diagnostic = 1,
		Procedure = 2
	}*/

	/// <summary>
	/// Base for all Diagnostic or Procedure Codes.
	/// The deriving classes must implement some abstract methods.
	/// 
	/// Diagnostic Types are:   ICD9, DSM4
	/// Procedure Types are:    ICD9, CPT, DENTAL, HCPCS
	/// </summary>
	public abstract class BaseDxPx : BaseData
	{
		// Dx or Px
		public const string DxPxDiagnostic = "D";
		public const string DxPxProcedure = "P";

		// Code Types
		public const string CodeTypeDSM4 = "DSM4";
		public const string CodeTypeICD9 = "ICD9";
		public const string CodeTypeCPT = "CPT";
		public const string CodeTypeDENTAL = "DENT";		// Dental
		public const string CodeTypeHCPCS = "HCPC";

		public BaseDxPx()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region Overridables

		public abstract string CodeType
		{
			get; set;
		}

		public abstract string DxOrPx
		{
			get; set;
		}

		public abstract string CodeDescription
		{
			get; set;
		}

		public abstract string CodeLongDescription
		{
			get; set;
		}

		public abstract string CodeValue
		{
			get; set;
		}

		public abstract bool Incomplete
		{
			get; set;
		}

		public virtual bool Load(string code)
		{
			return base.Load(code);
		}

		public BaseDxPxCollection GetCorrespondingOtherCodes()
		{
			// Find if there's any other corresponding codes and return them
			return null;
		}

		#endregion

		/// <summary>
		/// Returns true if this record is a diagnostic code.
		/// </summary>
		public bool IsDiagnostic
		{
			get { return this.DxOrPx == DxPxDiagnostic; }
		}

		/// <summary>
		/// Returns true if this record is a procedure code.
		/// </summary>
		public bool IsProcedure
		{
			get { return this.DxOrPx == DxPxProcedure; }
		}

		/// <summary>
		/// Determines whether a given code type can be diagnostic type
		/// </summary>
		/// <param name="CodeType"></param>
		/// <returns></returns>
		public static bool IsDiagnosticCodeType(string CodeType)
		{
			switch(CodeType)
			{
				case CodeTypeICD9:
				case CodeTypeDSM4:
					return true;
				default:
					return false;
			}
		}

		/// <summary>
		/// Determines whether a given code type can be procedure type
		/// </summary>
		/// <param name="CodeType"></param>
		/// <returns></returns>
		public static bool IsProcedureCodeType(string CodeType)
		{
			switch(CodeType)
			{
				case CodeTypeICD9:
				case CodeTypeCPT:
				case CodeTypeDENTAL:
				case CodeTypeHCPCS:
					return true;
				default:
					return false;
			}
		}

		/// <summary>
		/// Given the diag or proc ('D' or 'P') value, returns possible code types and their descriptions.
		/// </summary>
		/// <param name="diagProc"></param>
		/// <returns></returns>
		public static string[,] GetValuesOfCodeType(string diagProc)
		{
			switch (diagProc)
			{
				case "D":
					return new string[,] { { BaseDxPx.CodeTypeICD9, BaseDxPx.CodeTypeICD9}, { BaseDxPx.CodeTypeDSM4, BaseDxPx.CodeTypeDSM4 } }; // return possible field values
				case "P":
					return new string[,] { { BaseDxPx.CodeTypeICD9, BaseDxPx.CodeTypeICD9}, { BaseDxPx.CodeTypeCPT, BaseDxPx.CodeTypeCPT}, { BaseDxPx.CodeTypeDENTAL, BaseDxPx.CodeTypeDENTAL}, { BaseDxPx.CodeTypeHCPCS, BaseDxPx.CodeTypeHCPCS }}; // return possible field values
				default:
					return new string[,] { { BaseDxPx.CodeTypeICD9, BaseDxPx.CodeTypeICD9}, { BaseDxPx.CodeTypeDSM4, BaseDxPx.CodeTypeDSM4 }, { BaseDxPx.CodeTypeCPT, BaseDxPx.CodeTypeCPT }, { BaseDxPx.CodeTypeDENTAL, BaseDxPx.CodeTypeDENTAL}, { BaseDxPx.CodeTypeHCPCS, BaseDxPx.CodeTypeHCPCS } }; // return possible field values
			}
		}
	}

	public class DxPxSearcher : BaseDxPx
	{
		private string codeType;
		private string dxOrPx;
		private string codeDescription;
		private string codeLongDescription;
		private string codeValue;
		private bool incomplete;

		public DxPxSearcher()
		{
		}

		public DxPxSearcher(string dxOrPx)
		{
			this.SetMembersNull(true, true);
			this.dxOrPx = dxOrPx;
		}

		#region BaseDxPx overridables

		[ControlType(Macro=EnumControlTypeMacros.StringLookup, ControlType=EnumControlTypes.RadioButtonBox | EnumControlTypes.ComboBox )]
		[FieldValuesMember("ValuesOf_CodeType")]
		public override string CodeType
		{
			get { return codeType; }
			set { this.codeType = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.StringLookup, ControlType=EnumControlTypes.RadioButtonBox | EnumControlTypes.ComboBox )]
		[FieldValuesMember("ValuesOf_DxOrPx")]
		public override string DxOrPx
		{
			get { return dxOrPx; }
			set { this.dxOrPx = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		[FieldDescription("@DESCRIPTION@")]
		public override string CodeDescription
		{
			get { return codeDescription; }
			set { this.codeDescription = value; }
		}

		public override string CodeLongDescription
		{
			get { return this.codeLongDescription; }
			set { this.codeLongDescription = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		[FieldDescription("@CODE@")]
		public override string CodeValue
		{
			get { return codeValue; }
			set { this.codeValue = value; }
		}

		public override bool Incomplete
		{
			get { return incomplete; }
			set { this.incomplete = value; }
		}

		#endregion

		// General valuesof functions
		public new string[,] ValuesOf_CodeType
		{
			get
			{
				return BaseDxPx.GetValuesOfCodeType(this.dxOrPx);
			}
		}
		public string[,] ValuesOf_DxOrPx
		{
			get
			{
				return new string[,]{{"D","Dx"},{"P","Px"}};
			}
		}
	}


	/// <summary>
	/// This is the base collection class for all dx or px codes.
	/// This collection can hold elements of any dx or px code.
	/// </summary>
	[ElementType(typeof(BaseDxPx))]
	public class BaseDxPxCollection : BaseDataCollection
	{
		protected Patient patient;

		public const int MAXRECORDS = 50;		//  -1 = unlimited

		public virtual int Search(string code, string diagOrProc, string description, bool guidelineLinkedOnly, int guidelineSourceSetID)
		{
			throw new Exception("Search method not implemeted by " + this.GetType().Name);
		}

		public virtual int SearchNext(string code, string diagOrProc, string description, bool guidelineLinkedOnly, int guidelineSourceSetID)
		{
			throw new Exception("SearchNext method not implemeted by " + this.GetType().Name);
		}

		/// <summary>
		/// Used in the search context.
		/// </summary>
		public ActiveAdvice.DataLayer.Patient Patient
		{
			get { return this.patient; }
			set { this.patient = value; }
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public BaseDxPx this[int index]
		{
			get
			{
				return (BaseDxPx)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(BaseDxPx elem)
		{
			return AddRecord(elem);
		}

	}

}
