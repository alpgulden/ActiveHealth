using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// This class creates the appropriate collection or data class for the given type of
	/// Dx or Px code type.
	/// </summary>
	public class DxPxCodeClassFactory
	{
		public static BaseDxPx CreateDxPxInstance(string codeType, bool initNew)
		{
			codeType = codeType.Trim();
			switch(codeType)
			{
				case BaseDxPx.CodeTypeCPT:
					return new CPTCode(initNew);
				case BaseDxPx.CodeTypeDENTAL:
					return new DentalCode(initNew);
				case BaseDxPx.CodeTypeDSM4:
					return new DSM4Code(initNew);
				case BaseDxPx.CodeTypeHCPCS:
					return new HCPCSCode(initNew);
				case BaseDxPx.CodeTypeICD9:
					return new ICD9Code(initNew);

				default:
					throw new ActiveAdviceException(AAExceptionAction.None, "DxPxCodeClassFactory can't create the specified code type {0}", codeType);
			}
		}

		public static BaseDxPx CreateAndLoadDxPxInstance(string codeType, string code, string dxOrPx)
		{
			// Create corresponding code object for the passed code type
			BaseDxPx codeObj = CreateDxPxInstance(codeType, false);
			if (codeObj is ICD9Code)
				codeObj.DxOrPx = dxOrPx;
			if (codeObj.Load(code))	// loads from the corresponding code table
				return codeObj;
			else
				throw new ActiveAdviceException(EnumExceptionResolution.DxPxLoadError, String.Format( "'{0}' '{1}' Code '{2}' not found in database.", dxOrPx, codeType, code) );
				//return null;	// couldn't find the code in the corresponding code table
		}

		public static BaseDxPxCollection CreateDxPxCollection(string codeType)
		{
			switch(codeType)
			{
				case BaseDxPx.CodeTypeCPT:
					return new CPTCodeCollection();
				case BaseDxPx.CodeTypeDENTAL:
					return new DentalCodeCollection();
				case BaseDxPx.CodeTypeDSM4:
					return new DSM4CodeCollection();
				case BaseDxPx.CodeTypeHCPCS:
					return new HCPCSCodeCollection();
				case BaseDxPx.CodeTypeICD9:
					return new ICD9CodeCollection();

				default:
					throw new ActiveAdviceException(AAExceptionAction.None, "DxPxCodeClassFactory can't create the specified code collection {0}", codeType);
			}
		}

		public static DxPxSelectCollection CreateCodeSelectCollection(string dxPx)
		{
			switch(dxPx)
			{
				case BaseDxPx.DxPxDiagnostic:
					return new DiagnosticSelectCollection();
				case BaseDxPx.DxPxProcedure:
					return new ProcedureSelectCollection();

				default:
					throw new ActiveAdviceException(AAExceptionAction.None, "DxPxCodeClassFactory can't create the specified code select collection {0}", dxPx);
			}
		}

	}
}
