using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SubscriberCoverageHistory]
	/// </summary>
	[SPAutoGen("usp_GetLatestSubscriberCoverageHistoryRecord","SelectTop1.sptpl","subscriberCoveragesHistoryID, DESC, subscriberCoverageID")]
	[SPInsert("usp_InsertSubscriberCoverageHistory")]
	[SPUpdate("usp_UpdateSubscriberCoverageHistory")]
	[SPDelete("usp_DeleteSubscriberCoverageHistory")]
	[SPLoad("usp_LoadSubscriberCoverageHistory")]
	[TableMapping("SubscriberCoverageHistory","subscriberCoveragesHistoryID")]
	public class SubscriberCoverageHistory : BaseData
	{
		[NonSerialized]
		private SubscriberCoverageHistoryCollection parentSubscriberCoverageHistoryCollection;
		[ColumnMapping("SubscriberCoveragesHistoryID",StereoType=DataStereoType.FK)]
		private int subscriberCoveragesHistoryID;
		[ColumnMapping("SubscriberCoverageID")]
		private int subscriberCoverageID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;

		// 
		private DateTime termDateWhenLoaded;

		public SubscriberCoverageHistory()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public SubscriberCoverageHistory(SubscriberCoverage subscriberCoverage)
		{
			if (subscriberCoverage == null)
				throw new Exception("SubscriberCoverageHistory can be created only in the context of a SubscriberCoverage");

			this.NewRecord();

			this.subscriberCoverageID = subscriberCoverage.SubscriberCoverageId;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int SubscriberCoveragesHistoryID
		{
			get { return this.subscriberCoveragesHistoryID; }
			set { this.subscriberCoveragesHistoryID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberCoverageID
		{
			get { return this.subscriberCoverageID; }
			set { this.subscriberCoverageID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value.Date; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value.Date; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value.Date; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int subscriberCoveragesHistoryID)
		{
			return base.Load(subscriberCoveragesHistoryID);
		}

		/// <summary>
		/// Parent SubscriberCoverageHistoryCollection that contains this element
		/// </summary>
		public SubscriberCoverageHistoryCollection ParentSubscriberCoverageHistoryCollection
		{
			get
			{
				return this.parentSubscriberCoverageHistoryCollection;
			}
			set
			{
				this.parentSubscriberCoverageHistoryCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Load the latest SubscriberCoverageHistory record for a given subscriber coverage
		/// </summary>
		public bool LoadLatest(int subscriberCoverageID)
		{
			return SqlData.SPExecReadObj("usp_GetLatestSubscriberCoverageHistoryRecord", this, false, subscriberCoverageID);
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}

			base.InternalSave();
			// Save the child collections here.
		}

	}

	/// <summary>
	/// Strongly typed collection of SubscriberCoverageHistory objects
	/// </summary>
	[ElementType(typeof(SubscriberCoverageHistory))]
	public class SubscriberCoverageHistoryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SubscriberCoverageHistory elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSubscriberCoverageHistoryCollection = this;
			else
				elem.ParentSubscriberCoverageHistoryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SubscriberCoverageHistory elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SubscriberCoverageHistory this[int index]
		{
			get
			{
				return (SubscriberCoverageHistory)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SubscriberCoverageHistory)oldValue, false);
			SetParentOnElem((SubscriberCoverageHistory)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent SubscriberCoverage that contains this collection
		/// </summary>
		public SubscriberCoverage ParentSubscriberCoverage
		{
			get { return this.ParentDataObject as SubscriberCoverage; }
			set { this.ParentDataObject = value; /* parent is set when contained by a SubscriberCoverage */ }
		}
	}
}
