using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SubscriberCoverages]
	/// </summary>
	[SPInsert("usp_InsertSubscriberCoverage")]
	[SPUpdate("usp_UpdateSubscriberCoverage")]
	[SPDelete("usp_DeleteSubscriberCoverage")]
	[SPLoad("usp_LoadSubscriberCoverage")]
	[TableMapping("SubscriberCoverage","subscriberCoverageId")]
	public class SubscriberCoverage : BaseData
	{
		[NonSerialized]
		private SubscriberCoverageCollection parentSubscriberCoverageCollection;
		[ColumnMapping("SubscriberCoverageId",StereoType=DataStereoType.FK)]
		private int subscriberCoverageId;
		[ColumnMapping("SubscriberId",StereoType=DataStereoType.FK)]
		private int subscriberId;
		[ColumnMapping("SORGId",StereoType=DataStereoType.FK)]
		private int sORGId;
		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)]
		private int planId;
		[ColumnMapping("AlternateGroupId")]
		private string alternateGroupId;
		[ColumnMapping("AlternateInsuranceId")]
		private string alternateInsuranceId;
		[ColumnMapping("IsPrimary")]
		private bool isPrimary;
		[ColumnMapping("AlternateSubscriberId")]
		private string alternateSubscriberId;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("SubscriberEligibiliyID",StereoType=DataStereoType.FK)]
		private int subscriberEligibiliyID;

		// The Subscriber-Plan relationship never gets updated
		// So we can keep object references
		private Subscriber subscriber;		// the parent patient
		private Plan plan;
		private Organization sorg;
		private SubscriberCoverageHistoryCollection subscriberCoverageHistories;			// this is also given when the link is created

		private SubscriberCoverageHistory latestCoverageInHistory;
		
		public SubscriberCoverage()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Use this constructor when you want to create a link between a specific [Subscriber]
		/// and a specific [Plan] int the context of a given sorg
		/// </summary>
		/// <param name="patientId"></param>
		/// <param name="subscriberId"></param>
		public SubscriberCoverage(Subscriber subscriber, Plan plan, Organization sorg)
		{
			this.NewRecord(); // initialize record state
			SetRelationship(subscriber, plan, sorg);
		}

		public SubscriberCoverage(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public void SetRelationship(Subscriber subscriber, Plan plan, Organization sorg)
		{
			if (subscriber == null)
				throw new Exception("Subscriber not specified for SubscriberCoverage");
			if (plan == null)
				throw new Exception("Plan not specified for SubscriberCoverage");
			if (sorg == null)
				throw new Exception("SORG not specified for SubscriberCoverage");
			// Create a link
			this.subscriberId = subscriber.SubscriberId;
			this.subscriber = subscriber;
			this.planId = plan.PlanId;
			this.plan = plan;
			this.sORGId = sorg.OrganizationID;
			this.sorg = sorg;
		}

		public void SetSubscriberRelationship(Subscriber subscriber)
		{
			if (subscriber == null)
				throw new Exception("Subscriber not specified for SubscriberCoverage");
			this.subscriberId = subscriber.SubscriberId;
		}

		/// <summary>
		/// Primary key for this SubscriberCoverage.
		/// </summary>
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int SubscriberCoverageId
		{
			get { return this.subscriberCoverageId; }
			set { this.subscriberCoverageId = value; }
		}

		//[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberId
		{
			get { return this.subscriberId; }
			//set { this.subscriberId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SORGId
		{
			get { return this.sORGId; }
			set 
			{ 
				this.sORGId = value; 
				this.sorg = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PlanId
		{
			get { return this.planId; }
			set 
			{ 
				this.planId = value; 
				this.plan = null;
			}
		}

		/// <summary>
		/// Loads and returns the associated plan.
		/// </summary>
		/// <returns></returns>
		public Plan GetPlan()
		{
			if (this.planId == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.planId))
				return plan;
			else
				return null;
		}

		public Plan Plan
		{
			get
			{
				if (this.plan == null)
				{
					if (this.parentSubscriberCoverageCollection != null)
						this.plan = this.parentSubscriberCoverageCollection.ParentPlan;
					if (this.plan == null)
						this.plan = GetPlan();
				}
				return this.plan;
			}
		}

		/// <summary>
		/// Loads and returns the associated subscriber.
		/// </summary>
		/// <returns></returns>
		public Subscriber GetSubscriber()
		{
			if (this.subscriberId == 0)
				return null;
			Subscriber subs = new Subscriber();
			if (subs.Load(this.subscriberId))
				return subs;
			else
				return null;
		}

		public Subscriber Subscriber
		{
			get
			{
				if (this.subscriber == null)
				{
					if (this.parentSubscriberCoverageCollection != null)
						this.subscriber = this.parentSubscriberCoverageCollection.ParentSubscriber;
					if (this.subscriber == null)
						this.subscriber = GetSubscriber();
				}
				return this.subscriber;
			}
		}

		/// <summary>
		/// Loads and returns the associated sorg.
		/// </summary>
		/// <returns></returns>
		public Organization GetSORG()
		{
			if (this.sORGId == 0)
				return null;
			Organization sorg = new Organization();
			if (sorg.Load(this.sORGId))
				return sorg;
			else
				return null;
		}

		public Organization SORG
		{
			get
			{
				if (this.sorg == null)
					this.sorg = GetSORG();
				return this.sorg;
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int subscriberCoverageId)
		{
			return base.Load(subscriberCoverageId);
		}

		/// <summary>
		/// Parent SubscriberCoverageCollection that contains this element
		/// </summary>
		public SubscriberCoverageCollection ParentSubscriberCoverageCollection
		{
			get
			{
				return this.parentSubscriberCoverageCollection;
			}
			set
			{
				this.parentSubscriberCoverageCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		[FieldDescription("@ALTGROUPID@")]
		public string AlternateGroupId
		{
			get { return this.alternateGroupId; }
			set { this.alternateGroupId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateInsuranceId
		{
			get { return this.alternateInsuranceId; }
			set { this.alternateInsuranceId = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IsPrimary
		{
			get { return this.isPrimary; }
			set { this.isPrimary = value; }
		}

		/*[FieldValuesMember("LookupOf_OtherInsuranceTypeId", "InsuranceTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int OtherInsuranceTypeId
		{
			get { return this.otherInsuranceTypeId; }
			set { this.otherInsuranceTypeId = value; }
		}

		[FieldValuesMember("LookupOf_OtherInsuranceStatusId", "InsuranceStatusId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int OtherInsuranceStatusId
		{
			get { return this.otherInsuranceStatusId; }
			set { this.otherInsuranceStatusId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string OtherInsuranceName
		{
			get { return this.otherInsuranceName; }
			set { this.otherInsuranceName = value; }
		}*/

		public InsuranceTypeCollection LookupOf_OtherInsuranceTypeId
		{
			get
			{
				return InsuranceTypeCollection.ActiveInsuranceTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public InsuranceStatusCollection LookupOf_OtherInsuranceStatusId
		{
			get
			{
				return InsuranceStatusCollection.ActiveInsuranceStatuses; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			//this.effectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateSubscriberId
		{
			get { return this.alternateSubscriberId; }
			set { this.alternateSubscriberId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberEligibiliyID
		{
			get { return this.subscriberEligibiliyID; }
			set { this.subscriberEligibiliyID = value; }
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			if (!this.IsMarkedForDeletion)
			{
				if (this.SORG == null)
					throw new Exception("Can't save the SubscriberCoverage without a SORG");
				if (!this.SORG.IsSubOrganization)
					throw new Exception("Can only save the SubscriberCoverage with a SORG");
			}

			base.InternalSave();
			// Save the child collections here.

			KeepCoverageHistory();
		}

		/// <summary>
		/// This will check if a new record is needed into the subscriber coverage history
		/// and will create a history entry if necessary.
		/// </summary>
		private void KeepCoverageHistory()
		{
			SubscriberCoverageHistory history = this.LatestCoverageInHistory;
			if (history.IsNew)
			{
				history.SqlData.Transaction = this.SqlData.Transaction;
				history.SubscriberCoverageID = this.subscriberCoverageId;
				history.Save();
			}
			else
			{
				// updating
				// save only if the history was changed
				SubscriberCoverageHistory latestInDB = this.GetLatestCoverageInHistory();
				if (latestInDB == null || !latestInDB.EqualsMappedMembers(history, false))
				{
					// there's a change, or there was no log entry in the db so far.
					history = (SubscriberCoverageHistory)history.Clone();
					history.SqlData.Transaction = this.SqlData.Transaction;
					history.Save();
				}
			}
		}

		public string PlanName
		{
			get 
			{ 
				if (this.Plan == null)
					return null;
				else
					return this.Plan.Name;
			}
		}

		/// <summary>
		/// Child CoverageHistory mapped to related rows of table SubscriberCoverageHistory where [SubscriberCoverageId] = [SubscriberCoverageID]
		/// Whenever the coverage changes a new record is added.
		/// </summary>
		[SPLoadChild("usp_LoadSubscriberCoverageHistoryRecords", "subscriberCoverageID")]
		public SubscriberCoverageHistoryCollection CoverageHistory
		{
			get { return this.subscriberCoverageHistories; }
			set
			{
				this.subscriberCoverageHistories = value;
				if (value != null)
					value.ParentSubscriberCoverage = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the SubscriberCoverageHistories collection
		/// </summary>
		public void LoadSubscriberCoverageHistories(bool forceReload)
		{
			this.subscriberCoverageHistories = (SubscriberCoverageHistoryCollection)SubscriberCoverageHistoryCollection.LoadChildCollection("SubscriberCoverageHistories", this, typeof(SubscriberCoverageHistoryCollection), subscriberCoverageHistories, forceReload, null);
		}

		/// <summary>
		/// Saves the SubscriberCoverageHistories collection
		/// </summary>
		public void SaveSubscriberCoverageHistories()
		{
			SubscriberCoverageHistoryCollection.SaveChildCollection(this.subscriberCoverageHistories, true);
		}

		/// <summary>
		/// Synchronizes the SubscriberCoverageHistories collection
		/// </summary>
		public void SynchronizeSubscriberCoverageHistories()
		{
			SubscriberCoverageHistoryCollection.SynchronizeChildCollection(this.subscriberCoverageHistories, true);
		}

		/// <summary>
		/// Returns the latest coverage in history.
		/// If this record is new, a new one is automatically created.
		/// </summary>
		public SubscriberCoverageHistory LatestCoverageInHistory
		{
			get
			{
				if (this.latestCoverageInHistory == null)
				{
					if (this.IsNew || this.IsNewlyInsertedInDB)
						this.latestCoverageInHistory = null;
					else
						this.latestCoverageInHistory = GetLatestCoverageInHistory();

					// if nothing was found, just create new history entry
					if (this.latestCoverageInHistory == null)
						this.latestCoverageInHistory = new SubscriberCoverageHistory(this);
				}

				return this.latestCoverageInHistory;
			}
		}

		/// <summary>
		/// Load the latest SubscriberCoverageHistory record for this SubscriberCoverage
		/// and return it.
		/// </summary>
		/// <returns></returns>
		public SubscriberCoverageHistory GetLatestCoverageInHistory()
		{
			SubscriberCoverageHistory latestCovInHis = new SubscriberCoverageHistory();
			if (latestCovInHis.LoadLatest(this.subscriberCoverageId))
				return latestCovInHis;
			else
				return null;
		}

	}

	/// <summary>
	/// Strongly typed collection of SubscriberCoverage objects
	/// </summary>
	[ElementType(typeof(SubscriberCoverage))]
	public class SubscriberCoverageCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_SubscriberCoverageId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SubscriberCoverage elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSubscriberCoverageCollection = this;
			else
				elem.ParentSubscriberCoverageCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SubscriberCoverage elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SubscriberCoverage this[int index]
		{
			get
			{
				return (SubscriberCoverage)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SubscriberCoverage)oldValue, false);
			SetParentOnElem((SubscriberCoverage)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(SubscriberCoverage elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((SubscriberCoverage)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent Subscriber that contains this collection
		/// </summary>
		public Subscriber ParentSubscriber
		{
			get { return this.ParentDataObject as Subscriber; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Subscriber */ }
		}

		/// <summary>
		/// Parent Plan that contains this collection
		/// </summary>
		public Plan ParentPlan
		{
			get { return this.ParentDataObject as Plan; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Plan */ }
		}

		/// <summary>
		/// Hashtable based index on subscriberCoverageId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_SubscriberCoverageId
		{
			get
			{
				if (this.indexBy_SubscriberCoverageId == null)
					this.indexBy_SubscriberCoverageId = new CollectionIndexer(this, new string[] { "subscriberCoverageId" }, true);
				return this.indexBy_SubscriberCoverageId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on subscriberCoverageId fields returns the collection index.  Uses the IndexBy_SubscriberCoverageId indexer.
		/// </summary>
		public int IndexOf(int subscriberCoverageId)
		{
			return this.IndexBy_SubscriberCoverageId.IndexOf(subscriberCoverageId);
		}

	}


	/// <summary>
	/// This is a joined version of subscriber-coveage, used in the search.
	/// </summary>
	[SPAutoGen("usp_SearchSubscriberCoverages","SearchSubsCov.sptpl","")]
	[TableMapping("SubscriberCoverage","subscriberCoverageId")]
	public class SubscriberCoverageBrief : BaseData
	{
		[ColumnMapping("SubscriberId")]
		private int subscriberId;
		[NonSerialized]
		private SubscriberCoverageBriefCollection parentSubscriberCoverageBriefCollection;
		[ColumnMapping("SubscriberCoverageId",StereoType=DataStereoType.FK)]
		private int subscriberCoverageId;
		[ColumnMapping("SORGId",StereoType=DataStereoType.FK)]
		private int sORGId;
		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)]
		private int planId;
		[ColumnMapping("AlternatePlanId")]
		private string alternatePlanId;
		[ColumnMapping("Name")]
		private string name;
		[ColumnMapping("City")]
		private string city;
		[ColumnMapping("State")]
		private string state;
		[ColumnMapping("Zip",StereoType=DataStereoType.USZipCode)]
		private string zip;
		[ColumnMapping("LastName")]
		private string lastName;
		[ColumnMapping("FirstName")]
		private string firstName;
		[ColumnMapping("SocialSecurityNumber",StereoType=DataStereoType.USSSN)]
		private string socialSecurityNumber;
		//private Byte[] socialSecurityNumber;

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		[FieldDescription("@LASTNAME@")]
		public string LastName
		{
			get { return this.lastName; }
			set { this.lastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		[FieldDescription("@FIRSTNAME@")]
		public string FirstName
		{
			get { return this.firstName; }
			set { this.firstName = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USSSN, MaxLength=20)]
		[FieldDescription("@SOCIALSECURITY@")]
		public string SocialSecurityNumber
		{
			get { return this.socialSecurityNumber; }
			set 
			{
				this.socialSecurityNumber =  value ; 
				if (this.socialSecurityNumber != null)
					if (Formatting.RemoveChars(this.socialSecurityNumber, ' ', '-') == "")
						this.socialSecurityNumber = null;
			}
			//get { return DecryptSSN(this.socialSecurityNumber); }
			//set { this.socialSecurityNumber = EncryptSSN(value); }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		[FieldDescription("@CITY@")]
		public string City
		{
			get { return this.city; }
			set { this.city = value; }
			
		}

		[ControlType(Macro=EnumControlTypeMacros.USState, MaxLength=2)]
		[FieldDescription("@STATE@")]
		public string State
		{
			get { return this.state; }
			set { this.state = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USZipCode, MaxLength=5, InputMask="#####-####")]
		[FieldDescription("@ZIPCODE@")]
		public string Zip
		{
			get { return this.zip; }
			set 
			{
				this.zip = value; 
				if (this.zip != null)
					if (this.zip.Trim() == "-")
						this.zip = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternatePlanId
		{
			get { return this.alternatePlanId; }
			set { this.alternatePlanId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberCoverageId
		{
			get { return this.subscriberCoverageId; }
			set { this.subscriberCoverageId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SORGId
		{
			get { return this.sORGId; }
			set { this.sORGId = value; }
		}

		/// <summary>
		/// Parent SubscriberCoverageBriefCollection that contains this element
		/// </summary>
		public SubscriberCoverageBriefCollection ParentSubscriberCoverageBriefCollection
		{
			get
			{
				return this.parentSubscriberCoverageBriefCollection;
			}
			set
			{
				this.parentSubscriberCoverageBriefCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberId
		{
			get { return this.subscriberId; }
			set { this.subscriberId = value; }
		}

		public Subscriber GetSubscriber()
		{
			if (this.subscriberId == 0)
				return null;
			Subscriber subscriber = new Subscriber();
			if (subscriber.Load(this.subscriberId))
				return subscriber;
			return null;
		}

		public SubscriberCoverage GetSubscriberCoverage()
		{
			if (this.subscriberCoverageId == 0)
				return null;
			SubscriberCoverage subscriberCoverage = new SubscriberCoverage();
			if (subscriberCoverage.Load(this.subscriberCoverageId))
				return subscriberCoverage;
			return null;
		}

		public Plan GetPlan()
		{
			if (this.planId == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.planId))
				return plan;
			return null;
		}

	}

	/// <summary>
	/// Strongly typed collection of SubscriberCoverageBrief objects
	/// </summary>
	[ElementType(typeof(SubscriberCoverageBrief))]
	public class SubscriberCoverageBriefCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SubscriberCoverageBrief elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSubscriberCoverageBriefCollection = this;
			else
				elem.ParentSubscriberCoverageBriefCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SubscriberCoverageBrief elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SubscriberCoverageBrief this[int index]
		{
			get
			{
				return (SubscriberCoverageBrief)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SubscriberCoverageBrief)oldValue, false);
			SetParentOnElem((SubscriberCoverageBrief)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Search for the subscriber-coverages and bring a joined summary.
		/// </summary>
		public int SearchSubscriberCoverages(int maxRecords, SubscriberCoverageBrief searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchSubscriberCoverages", maxRecords, this, searcher, false);
		}
	}
}
