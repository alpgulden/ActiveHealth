using System;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Collections;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Subscribers]
	/// The Subscriber is the person who "holds" the Insurance
	/// Plan. Subscribers can have dependents, who become Patients.
	/// For the proper tracking of coverage, all Patients must reference their
	/// Subscriber. There can be multiple Subscribers for a given patient
	/// (i.e. Father/Mother covering a child), and a Subscriber can also
	/// be a Patient.
	/// </summary>
	[SPInsert("usp_InsertSubscriber")]
	[SPUpdate("usp_UpdateSubscriber")]
	[SPDelete("usp_DeleteSubscriber")]
	[SPLoad("usp_LoadSubscriber")]
	[TableMapping("Subscriber","subscriberId")]
	public class Subscriber : BaseDataWithUserDefined
	{
		[NonSerialized]
		private SubscriberCollection parentSubscriberCollection;
		[ColumnMapping("SubscriberId",StereoType=DataStereoType.FK)]
		private int subscriberId;
		[ColumnMapping("LastName")]
		private string lastName;
		[ColumnMapping("FirstName")]
		private string firstName;
		[ColumnMapping("MiddleInitial")]
		private string middleInitial;
		[ColumnMapping("NamePrefixId",StereoType=DataStereoType.FK)]
		private int namePrefixId;
		[ColumnMapping("NameSuffix")]
		private string nameSuffix;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("uuid")]
		private Guid uuid;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("DateOfBirth")]
		private DateTime dateOfBirth;
		[ColumnMapping("SocialSecurityNumber",StereoType=DataStereoType.USSSN)]
		private string socialSecurityNumber;
		//private byte[] socialSecurityNumber;
		[ColumnMapping("AddressID",StereoType=DataStereoType.FK)]
		private int addressID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("MedicareID")]
		private string medicareID;
		[ColumnMapping("MedicaidID")]
		private string medicaidID;
		[ColumnMapping("Gender",StereoType=DataStereoType.Gender)]
		private string gender;
		private Address address;

		//private DateTime termDateWhenLoaded;
	
		public Subscriber()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Subscriber(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();		
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int SubscriberId
		{
			get { return this.subscriberId; }
			set { this.subscriberId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, IsRequired=true, MaxLength=30)]
		[FieldDescription("@LASTNAME@")]
		public string LastName
		{
			get { return this.lastName; }
			set { this.lastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, IsRequired=true, MaxLength=30)]
		[FieldDescription("@FIRSTNAME@")]
		public string FirstName
		{
			get { return this.firstName; }
			set { this.firstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		[FieldDescription("@MIDDLEINITIAL@")]
		public string MiddleInitial
		{
			get { return this.middleInitial; }
			set { this.middleInitial = value; }
		}

		[FieldValuesMember("LookupOf_NamePrefixId", "NamePrefixId", "Prefix")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@NAMEPREFIX@")]
		public int NamePrefixId
		{
			get { return this.namePrefixId; }
			set { this.namePrefixId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		[FieldDescription("@NAMESUFFIX@")]
		public string NameSuffix
		{
			get { return this.nameSuffix; }
			set { this.nameSuffix = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DATEOFBIRTH@")]
		public System.DateTime DateOfBirth
		{
			get { return this.dateOfBirth; }
			set { this.dateOfBirth = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USSSN)]
		[FieldDescription("@SOCIALSECURITY@")]
		public string SocialSecurityNumber
		{
			get { return this.socialSecurityNumber; }
			set 
			{ 
				this.socialSecurityNumber = ParseSSN( value );
			}
			//get { return DecryptSSN(this.socialSecurityNumber); }
			//set { this.socialSecurityNumber = EncryptSSN(value); }
		}

		/*
		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// 
		/// The subscriber can never be saved by itself.  It always requires a patient and patientCoverage
		/// context.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}*/

		/// <summary>
		/// Save the subscriber with all the given links.
		/// Subscriber and coverage is saved but patient is not saved!
		/// </summary>
		public void Save(Patient patient, PatientCoverage patientCoverage)
		{
			Save(patient, patientCoverage, false);
		}

		/// <summary>
		/// Save the subscriber with all the given links.
		/// Subscriber and coverage is saved and patient is saved only if savePatientInTransaction = true.
		/// </summary>
		public void Save(Patient patient, PatientCoverage patientCoverage, bool savePatientInTransaction)
		{
			Save(patient, patientCoverage, null, savePatientInTransaction);
		}

		/// <summary>
		/// Save the subscriber with all the given links.
		/// Subscriber and coverage is saved and patient is saved only if savePatientInTransaction = true.
		/// </summary>
		public void Save(Patient patient, PatientCoverage patientCoverage, IntakeLog intakeLog, bool savePatientInTransaction)
		{
			if (patientCoverage == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "A patient coverage must be passed to Subscriber.Save");

			if (patientCoverage.SORGID == 0)
				throw new ActiveAdviceException(AAExceptionAction.None, "PatientCoverage doesn't have a SORGID set.");

			if (patientCoverage.PlanID == 0)
				throw new ActiveAdviceException(AAExceptionAction.None, "PatientCoverage doesn't have a PlanID set.");

			bool patientNew = patient.IsNew;

			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				// Generally, if the patient is new, savePatient is passed true.
				if (savePatientInTransaction)
				{
					patient.SqlData.Transaction = this.SqlData.Transaction;
					patient.Save();
				}

				base.Save();
				// Set the linkages.  The subscriber has been saved and its id is ready now.
				// The other components of the linkage (
				// has already been established from the UI.
				//subscriberCoverage.SetSubscriberRelationship(this);
				// include the save of subscriber-coverage into transaction
				//subscriberCoverage.SqlData.Transaction = this.SqlData.Transaction;
				//subscriberCoverage.Save();
				// the subscriber-coverage is created and has an id now.
				//patientCoverage.SetRelationship(patient, subscriberCoverage);	// we can create a link to patient
				// include the save of patient-subscriber-coverage into transaction
				patientCoverage.SqlData.Transaction = this.SqlData.Transaction;
				patientCoverage.SetRelationship(patient, this);		// set the patient and subscriber linkages.  sorg and plan is already selected in the ui
				patientCoverage.Save();
				// The subscriber-coverage and patient-subscriber-coverage is now in DB
				// Create the Patient-Subscriber-Log using these
				KeepPatientSubscriberLog(patient, patientCoverage);

				// if saving the patient too, and the patient is new, create two default problems.
				if (savePatientInTransaction)
				{
					if (patientNew)		// if the patient is new, create two default problems: Unknown and Wellness.
					{
						#region Trigger AutoActivities - PT1 - Patient Initial Save

						patient.SqlData.Transaction = this.SqlData.Transaction;
						patient.AutoActivity_PatientInitialSave(patientCoverage);
						patient.SqlData.Transaction = null;


						#endregion

						Problem problem = null;

						// Wellness
						problem = new Problem(patient);
						//problem.ProblemDescription = "Wellness";		// we might need to use a ProblemDescriptionID instead!
						problem.ProblemDescriptionCode = ProblemDescription.WELL;
						problem.SqlData.Transaction = this.SqlData.Transaction;
						problem.Save(patientCoverage);

						// Unknown
						problem = new Problem(patient);
						//problem.ProblemDescription = "Unknown";
						problem.ProblemDescriptionCode = ProblemDescription.UNKN;
						problem.SqlData.Transaction = this.SqlData.Transaction;
						problem.Save(patientCoverage);

						patient.PatientProblems = null;	// invalidate in-memory problems collection
					}
				}

				if (intakeLog != null)
				{
					intakeLog.SqlData.Transaction = this.SqlData.Transaction;
					intakeLog.Save(); //patient, this, patientCoverage);
				}

				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}
		
		private void KeepPatientSubscriberLog(Patient patient, PatientCoverage patientCoverage)
		{
			// Create a new log entry, and compare with the existing last log entry to decide
			// whether a new log entry must be created or not.
			//if (subscriberCoverage.LatestCoverageInHistory == null || subscriberCoverage.IsNew)
			//	throw new Exception("No subscriber-coverage-history entry found for this subscriber-coverage!");

			PatientSubscriberLog patSubLog = new PatientSubscriberLog(patient, this, patientCoverage.LatestCoverageData, patientCoverage);
			//PatientSubscriberLog lastPatSubLog = PatientSubscriberLog.GetLastPatientSubscriberLogEntry(patient, patientCoverage); 

			// after talking to Harry, I changed the logging algorithm:
			//    we avoided field by field change detection.  just create a log entry whenever saved.
			bool logEntryRequired = true; // false;

			/*if (lastPatSubLog == null)	// no log entry found
				logEntryRequired = true;	// create one
			else
			{
				// a log entry was found
				// check if it's the same with the newly created one

				string[] excludedMembers = CollectionUtil.JoinArrays(patSubLog.PKFields, 
					new string[] { 
						"creationDate", 
						"patientCreationDate",
						"patientModificationDate",
						"subscriberCreationDate",
						"subscriberModificationDate",
						"subscriberCoverageCreateTime", 
						"subscriberCoverageModifyTime" } );

				if (!patSubLog.EqualsMappedMembers(lastPatSubLog, false, excludedMembers ))
					logEntryRequired = true;	// the log entry to be created has changed.
			}*/

			if (logEntryRequired)
			{
				// a log entry must be created
				patSubLog.SqlData.Transaction = this.SqlData.Transaction;
				patSubLog.Save();
			}

		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int subscriberId)
		{
			return base.Load(subscriberId);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			//this.effectiveDate = DateTime.Today;
			this.addressID = 0;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}

		/// <summary>
		/// Contained Address object
		/// </summary>
		[Contained]
		public Address Address
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.address = (Address)Address.EnsureContainedDataObject(this, typeof(Address), address, false, addressID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.address;
			}
			set
			{
				this.address = value;
				if (value != null) value.ParentSubscriber = this; // set this as a parent of the child data class
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			//termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to load child and other objects that must be loaded with this object.
		/// </summary>
		protected override bool InternalLoad(params object[] keys)
		{
			// Do pre-load operations here.
			bool result = base.InternalLoad(keys);
			// Do post-load operations here.
			return result;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			this.Address.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			{
				base.InternalSave();	// in that case, delete the base first
				Address.MarkDel();	// then allow the deletion of the conatined object
			}
			Address.IsNew = this.IsNew;	// make sure the contained object is new if the containing object is new
			Address.Save();
			this.addressID = Address.AddressID; // set the fk if the contained object was newly created
			/*if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}*/
			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Parent SubscriberCollection that contains this element
		/// </summary>
		public SubscriberCollection ParentSubscriberCollection
		{
			get
			{
				return this.parentSubscriberCollection;
			}
			set
			{
				this.parentSubscriberCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Use this function to test CRUD operations on this class
		/// </summary>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void TestCRUDOperations()
		{
			for (int i = 0; i < 100; i++)
			{
				Subscriber obj = new Subscriber();  // Use appropriate constructor
				obj.NewRecord();
				// Do other initializations on the object;
				obj.Save();
				Debug.WriteLine("Saved Subscriber PK="+obj.PKString);
				Debug.Assert(obj.Load(), "Load failed for Subscriber PK="+obj.PKString);
				Debug.WriteLine("Loaded Subscriber PK="+obj.PKString);
				// do some change in the properties
				obj.Save();
				Debug.WriteLine("Updated Subscriber PK="+obj.PKString);
				obj.MarkDel();  // Mark for deletion
				obj.Save();  // Delete it
				Debug.WriteLine("Deleted Subscriber PK="+obj.PKString);
			}
		
		}

		public NamePrefixCollection LookupOf_NamePrefixId
		{
			get
			{
				return NamePrefixCollection.ActiveNamePrefixes; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string MedicareID
		{
			get { return this.medicareID; }
			set { this.medicareID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string MedicaidID
		{
			get { return this.medicaidID; }
			set { this.medicaidID = value; }
		}

		[FieldValuesMember("ValuesOf_Gender")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, MaxLength=1)]
		[FieldDescription("@GENDER@")]
		public string Gender
		{
			get { return this.gender; }
			set { this.gender = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox|EnumControlTypes.ComboBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@NAME@")]
		public string Fmt_FullName
		{
			get { return FormatFNameLName(this.lastName, this.firstName); }
		}


		/// <summary>
		/// USE CASE ID: UC3.5
		/// TITLE: CREATE PATIENT COVERAGE
		/// REQUIREMENT ID: 1.8.4.6,1.8.4.7, 1.8.4.8
		/// Step 4.a.ii
		/// </summary>
		/// <param name="elig"></param>
		public void ImportFromEligibility(Eligibility elig)
		{
			//if (!elig.IsSubscriber)
			//	throw new ActiveAdviceException(AAExceptionAction.None, "Can't import subscriber from eligibility record of a patient");

			this.AsOfDate = elig.AsOfDate;
			this.FirstName = elig.FirstName;
			this.LastName = elig.LastName;
			this.Address.ImportFromEligibility(elig);
			this.SocialSecurityNumber = elig.MemberSSN;
			this.DateOfBirth = elig.MemberDOB;
			this.Gender = elig.MemberGender;
			this.MiddleInitial = elig.MiddleInitial;
			this.NameSuffix = elig.NameSuffix;
			this.MedicareID = elig.MedicareId;
			this.MedicaidID = elig.MedicaidId;
		}

		public void ImportFromPatient(Patient patient)
		{
			this.FirstName = patient.FirstName;
			this.LastName = patient.LastName;
			this.MiddleInitial = patient.MiddleInitial;
			this.NamePrefixId = patient.NamePrefixId;
			this.NameSuffix = patient.NameSuffix;
			this.Gender = patient.Gender;
			this.DateOfBirth = patient.DateOfBirth;
			this.SocialSecurityNumber = patient.SocialSecurityNumber;
		}

		public System.Guid Uuid
		{
			get { return this.uuid; }
			set { this.uuid = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of Subscriber objects
	/// </summary>
	[ElementType(typeof(Subscriber))]
	public class SubscriberCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Subscriber elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSubscriberCollection = this;
			else
				elem.ParentSubscriberCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Subscriber elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Subscriber this[int index]
		{
			get
			{
				return (Subscriber)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Subscriber)oldValue, false);
			SetParentOnElem((Subscriber)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}



	/// <summary>
	/// This is a compact joined version of subscriber-address, used in the search.
	/// </summary>
	[SPAutoGen("usp_SearchSubscribers","SearchSubsribers.sptpl","", ManuallyManaged=true)]
	[TableMapping("Subscriber","patientCoverageID")]
	public class SubscriberBrief : BaseData
	{
		private ArrayList pageStartStack = null;		// used to store page start values in paging.

		[NonSerialized]
		private SubscriberBriefCollection parentSubscriberBriefCollection;
		[ColumnMapping("City")]
		private string city;
		[ColumnMapping("State",StereoType=DataStereoType.USState)]
		private string state;
		[ColumnMapping("Zip",StereoType=DataStereoType.USZipCode)]
		private string zip;
		[ColumnMapping("SocialSecurityNumber",StereoType=DataStereoType.USSSN)]
		private string socialSecurityNumber;
		[ColumnMapping("FirstName")]
		private string firstName;
		[ColumnMapping("SubscriberId",StereoType=DataStereoType.FK)]
		private int subscriberId;
		[ColumnMapping("PatientCoverageID",StereoType=DataStereoType.FK)]
		private int patientCoverageID;
		[ColumnMapping("LastName")]
		private string lastName;
		[ColumnMapping("RelationShipID",StereoType=DataStereoType.FK)]
		private int relationShipID;
		[ColumnMapping("AlternatePatientID")]
		private string alternatePatientID;
		[ColumnMapping("AlternateSubscriberID")]
		private string alternateSubscriberID;

		[ControlType(Macro=EnumControlTypeMacros.USSSN, MaxLength=20)]
		[FieldDescription("@SOCIALSECURITY@")]
		public string SocialSecurityNumber
		{
			get { return this.socialSecurityNumber; }
			set 
			{
				this.socialSecurityNumber =  ParseSSN( value );
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string FirstName
		{
			get { return this.firstName; }
			set { this.firstName = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberId
		{
			get { return this.subscriberId; }
			set { this.subscriberId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string LastName
		{
			get { return this.lastName; }
			set { this.lastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string City
		{
			get { return this.city; }
			set { this.city = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USState, MaxLength=2)]
		public string State
		{
			get { return this.state; }
			set { this.state = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USZipCode, MaxLength=5, InputMask="#####-####")]
		[FieldDescription("@ZIPCODE@")]
		public string Zip
		{
			get { return this.zip; }
			set 
			{
				this.zip = value; 
				if (this.zip != null)
					if (this.zip.Trim() == "-")
						this.zip = null;
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternatePatientID
		{
			get { return this.alternatePatientID; }
			set { this.alternatePatientID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateSubscriberID
		{
			get { return this.alternateSubscriberID; }
			set { this.alternateSubscriberID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientCoverageID
		{
			get { return this.patientCoverageID; }
			set { this.patientCoverageID = value; }
		}

		[FieldValuesMember("LookupOf_RelationShipID", "RelationshipId", "RelationshipName")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int RelationShipID
		{
			get { return this.relationShipID; }
			set { this.relationShipID = value; }
		}

		public Subscriber GetSubscriber()
		{
			if (this.subscriberId == 0)
				return null;
			Subscriber subscriber = new Subscriber();
			if (subscriber.Load(this.subscriberId))
				return subscriber;
			return null;
		}

		public RelationshipTypeCollection LookupOf_RelationShipID
		{
			get
			{
				return RelationshipTypeCollection.ActiveRelationshipTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Parent SubscriberBriefCollection that contains this element
		/// </summary>
		public SubscriberBriefCollection ParentSubscriberBriefCollection
		{
			get
			{
				return this.parentSubscriberBriefCollection;
			}
			set
			{
				this.parentSubscriberBriefCollection = value; // parent is set when added to a collection
			}
		}

		public ArrayList PageStartStack
		{
			get 
			{ 
				if (this.pageStartStack == null)
					this.pageStartStack = new ArrayList();
				return this.pageStartStack; 
			}
			set { this.pageStartStack = value;	}
		}

	}

	/// <summary>
	/// Strongly typed collection of SubscriberBrief objects
	/// </summary>
	[ElementType(typeof(SubscriberBrief))]
	public class SubscriberBriefCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		public const int MAXRECORDS = 50;		//  -1 = unlimited

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SubscriberBrief elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSubscriberBriefCollection = this;
			else
				elem.ParentSubscriberBriefCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SubscriberBrief elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SubscriberBrief this[int index]
		{
			get
			{
				return (SubscriberBrief)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SubscriberBrief)oldValue, false);
			SetParentOnElem((SubscriberBrief)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
		
		/// <summary>
		/// Search for the subscribers-address and bring a joined summary.
		/// </summary>
		public int SearchSubscribers(int startPatientCoverageID, string startLastName, string startFirstName, SubscriberBrief searcher)
		{
			this.Clear();

			int maxRecords = MAXRECORDS;

			return SqlData.SPExecReadCol(60, "usp_SearchSubscribers", -1, this, searcher, false,
				new string[] { "rowCount", "startPatientCoverageID", "startLastName", "startFirstName" },
				new object[] { maxRecords < 0 ? 0 : maxRecords, startPatientCoverageID, startLastName, startFirstName } );
		}

	}

}
