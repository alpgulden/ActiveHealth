using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	public enum EnumERCType
	{
		All = -1,
		Undefined = 0,
		Event = 1,
		Referral = 2,
		CMS = 3,
	}

	[TableMapping("Patient","patientId")]
	public class ERCLinkMove: BaseDataWithUserDefined
	{
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		protected int patientId;
		// added by Burag C. on 02/14/06 
		public  void MoveERC(BaseData tranInitiator, int newPatientID, int newProblemID, int oldPatientID, int oldProblemID,  int eventReferralID, EnumERCType ercType,int subscriberLogID, int planSorgLogID, int userID, out string message)
		{
			bool initTran = false; // Indicates whether this method started the transaction or not.
			message = "";
			
			SqlParameter pr = new SqlParameter("@p_Result_Message",SqlDbType.VarChar,4000,ParameterDirection.InputOutput,true,0,0,null,System.Data.DataRowVersion.Default,message);
						
			
				

			string ercT = "E";
			switch (ercType)
			{
				case EnumERCType.CMS:
					ercT = "C";
					break;
				case EnumERCType.Event:
					ercT = "E";
					break;
				default:
				case EnumERCType.Referral:
					ercT = "R";
					break;
			}

			string []parameters = {	"p_New_Pt_ID",
									  "p_New_Problem_ID",
									  "p_Old_Pt_ID",
									  "p_Old_Problem_ID",
									  "p_Event_Ref_ID",
									  "p_Evt_Ref_Flag",
									  "p_User_id",
									  "p_Sub_Pat_Log_id",
									  "p_Plan_Sorg_Log_id",
									  "p_Result_Message" };
			object []values = {newPatientID, 
								  newProblemID, 
								  oldPatientID, 
								  oldProblemID, 
								  eventReferralID, 
								  ercT,
								  userID,
								  subscriberLogID, 
								  planSorgLogID, 
								  pr			
							  };					

			this.SqlData.UseTransaction(tranInitiator);
			SqlCommand cmd = this.SqlData.MakeSQLCommand("usp_ChangePatientEventReferral",parameters, values);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Transaction = this.SqlData.Transaction.SqlTransaction;
			//cmd.Connection = cmd.Transaction.Connection;
			cmd.ExecuteNonQuery();
			this.sqlData.CommitTransaction();

			//this.SqlData.ExecuteProcedure("usp_ChangePatientEventReferral",parameters, values);

			
			
			message = pr.Value.ToString();			
		}
	}


	/// <summary>
	/// Common properties and behavior of Event, CMS and Referral classes
	/// </summary>	
	[TableMapping("Event","eventID")]
	public abstract class BaseForEventCMSReferral : BaseDataWithUserDefined, IImageOwner
	{
		public BaseForEventCMSReferral()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		// track changes to DRG calculation result
		private bool drgResultChanged = false;

		// must be set after load
		protected Patient patient;
		protected BaseERCProblemLinkCollection baseERCProblemLinks;

		protected ArrayList drgMessageLog;

		protected Exception drgCalcEx = null;		// DRG Calculation exception if any

		/// <summary>
		/// Loads and retuns the linked patient
		/// </summary>
		/// <returns></returns>
		public Patient GetParentPatient()
		{
			if (this.PatientId == 0)
				return null;
			Patient patient = new Patient();
			patient.SqlData.Transaction = this.SqlData.Transaction;
			if (patient.Load(this.PatientId))
				return patient;
			else
				return null;
		}

		// FORK 1.1
		/// <summary>
		/// Loads and retuns the linked patient
		/// </summary>
		/// <returns></returns>
		public Patient GetParentPatientWithDataFilter()
		{
			if (this.PatientId == 0)
				return null;
			Patient patient = new Patient();
			patient.SqlData.Transaction = this.SqlData.Transaction;

			if (patient.LoadPatientwithDASecurity(this.PatientId))
				return patient;
			else
				return null;
		}
	

		/// <summary>
		/// Sets/Returns the Patient linked to event
		/// All operations that require patient context use this object.
		/// </summary>
		public Patient ParentPatient
		{
			get 
			{ 
				if (patient == null)
					patient = this.GetParentPatient();
				return patient;
			}
			set { this.patient = value;	}
		}

		// FORK 1.1
		/// <summary>
		/// Sets/Returns the Patient linked to event, referral and CMS with execute data filter
		/// All operations that require patient context use this object.
		/// </summary>
		public Patient ParentPatientWithDataFilter
		{
			get 
			{ 
				if (patient == null)
					patient = this.GetParentPatientWithDataFilter();
				return patient;
			}
			set { this.patient = value;	}
		}

		public Problem GetPrimaryProblem()
		{
			if (this.PrimaryProblemID == 0)
				return null;
			else
			{
				Problem problem = new Problem();
				problem.SqlData.Transaction = this.SqlData.Transaction;
				if (problem.Load(this.PrimaryProblemID))
					return problem;
				else
					return null;
			}
		}

		protected override void InitializeToTrackChanges()
		{
			base.InitializeToTrackChanges ();

			this.drgResultChanged = false;
		}


		/// <summary>
		/// Generic method to access EventID, CMSID, or ReferralID
		/// </summary>
		[FieldDescription("@ID@")]
		public int ID
		{
			get
			{
				object o = this.PK[0];
				if (o is DBNull || o == null)
					return 0;
				else
					return (int)o;
			}
			set
			{
				if (value == 0)
					this.PK = new object[] { DBNull.Value };
				else
					this.PK = new object[] { value };
			}
		}

	

		/*public virtual void Save(PatientCoverage patientCoverage, Problem problem)
		{
			this.Save(
		}*/

		/// <summary>
		/// Virtual method overridden by Event, Referral and CMS to reveal their identity
		/// </summary>
		public abstract EnumERCType ERCType
		{
			get;
		}

		/// <summary>
		/// Virtual method overridden by Event, Referral and CMS to reveal which one of these it is.
		/// </summary>
		[FieldDescription("@ERCTYPE@")]
		public abstract string ERCTypeDisplay
		{
			get;
		}

		/// <summary>
		/// Virtual method overridden by Event, Referral and CMS to reveal its type.
		/// </summary>
		[FieldDescription("@TYPE@")]
		public abstract string TypeDisplay
		{
			get;
		}

		/// <summary>
		/// Virtual method overridden by Event, Referral and CMS to reveal if it's linked to a problem or not.
		/// </summary>
		[FieldDescription("@LINKED@")]
		public abstract bool IsLinkedToProblem
		{
			get; set;
		}

		[FieldDescription("@DESCRIPTION@")]
		public abstract string ERCDescription
		{
			get;
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@SERVICEDATE@")]
		public abstract DateTime ERCServiceDate
		{
			get;
		}


		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@START@")]
		public abstract DateTime ERCStartDate
		{
			get;
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@END@")]
		public abstract DateTime ERCEndDate
		{
			get;
		}

		[FieldDescription("@ERCSTATUS@")]
		public abstract string ERCStatusDisplay
		{
			get;
		}

		[FieldDescription("@ERCSTATUS@")]
		public abstract int ERCStatusID
		{
			get;
			set;
		}

		[FieldDescription("@STATUSCODE@")]
		public string ERCStatusCode
		{
			get { return SystemStatusCollection.ActiveSystemStatuses.Lookup_CodeByStatusId(this.ERCStatusID); }
			set { this.ERCStatusID = SystemStatusCollection.ActiveSystemStatuses.Lookup_StatusIdByCode(value); }
		}

		[FieldDescription("@PR@")]
		public abstract bool ERCPhysicianReview
		{
			get;
		}

		public abstract DateTime ERCLastValidationDate
		{
			get;
			set;
		}

		public abstract int PrimaryProblemID
		{
			get; set;
		}

		public abstract void UpdateLastValidationDate();

		/// <summary>
		/// Returns true if the event-cms-referral requires
		/// coverage validation before when viewing
		/// for today.  This function will return true once a day.
		/// The coverage validation will call UpdateLastValidationDate()
		/// virtual method to notify event-referral-cms to update
		/// its last validation date in the db directly.
		/// </summary>
		/// <returns></returns>
		public bool RequiresCoverageValidationForToday()
		{
			//			if(this.ERCType==typeof(Referral))  // not check status code for referral				
			//				return (DateTime.Today > this.ERCLastValidationDate);
			//			else
			return (this.ERCStatusCode == SystemStatus.OPEN) && 
				(DateTime.Today > this.ERCLastValidationDate);
		}

		/// <summary>
		/// Link to or unlink from the given problem.
		/// If linkUnlink = true, link problem to this ERC.
		/// If linkUnlink = false, unklink problem from this ERC.
		/// </summary>
		/// <param name="problem"></param>
		/// <param name="linkUnlink"></param>
		public abstract void LinkToProblem(Problem problem, bool linkUnlink);

		public abstract bool LoadERC(int ercID);

		public virtual PRRequestCollection PRRequests
		{
			get
			{
				throw new Exception("No PhysicianReviews");
			}
			set
			{
				throw new Exception("No PhysicianReviews");
			}
		}

		public virtual void LoadPRRequests(bool foreReload)
		{
			throw new Exception("No PhysicianReviews");
		}

		public virtual void SavePRRequests()
		{
			throw new Exception("No PhysicianReviews");
		}

		public virtual OutcomeCollection Outcomes
		{
			get
			{
				throw new Exception("No Outcomes");
			}
			set
			{
				throw new Exception("No Outcomes");
			}
		}

		public virtual void LoadOutcomes(bool foreReload)
		{
			throw new Exception("No Outcomes");
		}

		public virtual void SaveOutcomes()
		{
			throw new Exception("No Outcomes");
		}

		public virtual EventReferralDiagnoseCollection EventReferralDiagnoses
		{
			get
			{
				throw new Exception("No EventReferralDiagnoses");
			}
			set
			{
				throw new Exception("No EventReferralDiagnoses");
			}
		}

		public virtual void LoadEventReferralDiagnoses(bool foreReload)
		{
			throw new Exception("No EventReferralDiagnoses");
		}

		public virtual void SaveEventReferralDiagnoses()
		{
			throw new Exception("No EventReferralDiagnoses");
		}

		public virtual EventReferralProcedureCollection EventReferralProcedures
		{
			get
			{
				throw new Exception("No EventReferralProcedures");
			}
			set
			{	
				throw new Exception("No EventReferralProcedures");
			}
		}

		public virtual void LoadEventReferralProcedures(bool foreReload)
		{
			throw new Exception("No EventReferralProcedures");
		}

		public virtual void SaveEventReferralProcedures()
		{
			throw new Exception("No EventReferralProcedures");
		}


		public virtual ProblemCollection Problems
		{
			get
			{
				throw new Exception("No Problems");
			}
			set
			{
				throw new Exception("No Problems");
			}
		}
		
		public virtual void LoadProblems(bool forceReload)
		{
			throw new Exception("No Problems");
		}

		public virtual void SaveProblems()
		{
			throw new Exception("No Problems");
		}
		
		public virtual BaseERCProblemLinkCollection ERCProblemLinks
		{
			get { throw new Exception("No BaseERCProblemLinks"); }
			set { throw new Exception("No BaseERCProblemLinks"); }
		}
		
		public virtual void LoadERCProblemLinks(bool forceReload)
		{
			throw new Exception("BaseERCProblemLinks not implemented");
		}

		public virtual void SaveERCProblemLinks()
		{
			throw new Exception("BaseERCProblemLinks not implemented");
		}

		public virtual ImageLinkCollection Images
		{
			get
			{
				throw new Exception("No Images");
			}
			set
			{
				throw new Exception("No Images");
			}
		}

		public virtual void LoadImages(bool foreReload)
		{
			throw new Exception("No Images");
		}

		public virtual void SaveImages()
		{
			throw new Exception("No Images");
		}

		/// <summary>
		/// Event, Referral and CMS must override this to implement diagnostic selection loading
		/// </summary>
		/// <param name="diagnostics"></param>
		public virtual void SyncDiagnosticCodes(DiagnosticSelectCollection diagnostics)
		{
			throw new Exception("SyncDiagnosticCodes not implemented");
		}

		/// <summary>
		/// Event, Referral and CMS must override this to implement procedure selection loading
		/// </summary>
		/// <param name="procedures"></param>
		public virtual void SyncProcedureCodes(ProcedureSelectCollection procedures)
		{
			throw new Exception("SyncProcedureCodes not implemented");
		}

		public void SyncDxPxCodes(DxPxSelectCollection selections)
		{
			if (selections is DiagnosticSelectCollection)
				SyncDiagnosticCodes(selections as DiagnosticSelectCollection);
			else
				SyncProcedureCodes(selections as ProcedureSelectCollection);

		}

		public virtual DiagnosticSelectCollection CreateDiagnosticSelectionCollection()
		{
			return null;
		}

		public virtual ProcedureSelectCollection CreateProcedureSelectionCollection()
		{
			return null;
		}

		#region DRG Related virtual methods/properties

		/// <summary>
		/// Calculate the DRG data and set DRGTypem, Code and Version fields.
		/// Currently only Event and Referral support this calculation.
		/// </summary>
		/// <param name="patient"></param>
		public bool CalculateDRGData(Patient patient)
		{
			drgMessageLog = null;
			this.drgCalcEx = null;
			try
			{
				//throw new ActiveAdviceException("CalculateDRGData not supported by " + this.GetType().Name);
				//this.DrgType = null;
				//this.DrgCode = null;
				//this.DrgVersion = null;

				// Get shared grouper instance
				GrouperHIPAA drgGrouper = CustomGrouper.DrgGrouper;
			
				// lock the usage of drgGrouper for exclusive use.
				// allow single acces at all times!
				lock(drgGrouper)
				{
					drgGrouper.Initialize();
					drgGrouper.InputPatientAndERC(patient, this);
					bool result = drgGrouper.CalculateGroup();

					drgMessageLog = (ArrayList)drgGrouper.MessageLog.Clone();	// make a copy of messages

					if (!result)
					{
						throw new ActiveAdviceException("DRG Calculation Error: " + drgGrouper.ReturnMessage);
					}
					else
					{
						if (drgGrouper.DRG != "000")
						{
							string drgType = drgGrouper.GrouperTypeString;
							string drgVersion = drgGrouper.VersionCode;
							string drgCode = drgGrouper.DRG;
							if (drgCode == "000")
							{
								drgCode = null;
							}

							// set the changed flag if the drg calculation result has been changed
							if (drgType != this.DrgType
								|| drgVersion != this.DrgVersion
								|| drgCode != this.DrgCode)
								drgResultChanged = true;

							this.DrgType = drgType;
							this.DrgVersion = drgVersion;
							this.DrgCode = drgCode;
						}
						else
						{
							// "000" result was returned!
							drgMessageLog.Add("DRG was successfull, but returned empty result.  Keeping old values.");
						}
					}
				}
			}
			catch(Exception ex)
			{
				this.drgCalcEx = ex;
				return false;
			}
			return true;
		}

		/// <summary>
		/// Calculate DRG and if the results have changed,
		/// save the ERC object.
		/// </summary>
		/// <param name="patient"></param>
		public bool CalculateAndSaveDRGData(Patient patient)
		{
			this.CalculateDRGData(patient);
			if (!this.IsNew && this.DRGResultChanged)		// Save only if the result has been changed
			{
				this.SqlData.EnsureTransaction();
				try
				{
					base.Save();
					this.SqlData.CommitTransaction();

					return true;	// recalculated and saved
				}
				catch
				{
					this.SqlData.RollbackTransaction();
					throw;
				}
			}
			return false;	// not recalculated
		}

		/// <summary>
		/// Returns true if the CalculateDRGData has changed the drg result.
		/// This flag is reset to false only after load and save.
		/// </summary>
		public bool DRGResultChanged
		{
			get
			{
				return drgResultChanged;
			}
		}

		public virtual string DrgType
		{
			get { return null; }
			set { }
		}

		public virtual string DrgCode
		{
			get { return null; }
			set { }
		}

		public virtual string DrgVersion
		{
			get { return null; }
			set { }
		}

		#endregion

		#region Properties used by Administration

		// Event, Referral and CMS should override these and return and set correct properties related to them.

		public virtual int AdminPlanID
		{
			get { return 0; }
			set { }
		}

		public virtual string AdminGroup
		{
			get { return null; }
			set { }
		}

		public virtual string AdminOtherPlan
		{
			get { return null; }
			set { }
		}

		public virtual Organization SORG
		{
			get { return null; }
		}

		public abstract int PatientId
		{
			get; set;
		}

		public virtual PatientSubscriberLog PatientSubscriberLog
		{
			get { return null; }
		}

		public virtual int PatientSubscriberLogID
		{
			get { return 0; }
			set { }
		}

		public virtual PlanSORGLog PlanSORGLog
		{
			get { return null; }
		}

		public virtual int PlanSORGLogID
		{
			get { return 0; }
			set { }
		}

		#endregion

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.ERCStatusCode = SystemStatus.OPEN;		// a new event is always open
		}

		/// <summary>
		/// Links this ERC with a new patient coverage but doesn't commit the change to the db.
		/// </summary>
		/// <param name="newPatientCoverage"></param>
		public void ChangeCoverage(PatientCoverage newPatientCoverage)
		{
			PatientSubscriberLog currentPatSubLog = this.PatientSubscriberLog;
			if (currentPatSubLog == null || currentPatSubLog.PatientCoverageID != newPatientCoverage.PatientCoverageID)
			{
				// The coverage was changed

				// Relink to the PatientSubscriberLog entry
				PatientSubscriberLog lastPatSubLog = PatientSubscriberLog.GetLastPatientSubscriberLogEntry(null, this.ParentPatient, newPatientCoverage);
				if (lastPatSubLog == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI,
						"No patient-subscriber-log entry found for PatientID={0}, PatientCoverageID={1}", this.ParentPatient.PatientId, newPatientCoverage.PatientCoverageID);
				this.PatientSubscriberLogID = lastPatSubLog.PatientSubscriberLogId;
				//this.PatientSubscriberLog = lastPatSubLog;
			
				// Relink to the PlanSorgLog entry
				PlanSORGLog lastPlanSorgLog = PlanSORGLog.GetLastPlanSORGLogEntry(null, newPatientCoverage.PlanID, newPatientCoverage.SORGID);
				if (lastPlanSorgLog == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI,
						"No plan-sorg-log entry found for PlanID={0}, SORGID={1}", newPatientCoverage.PlanID, newPatientCoverage.SORGID);
				this.PlanSORGLogID = lastPlanSorgLog.PlanSorgLogId;
				//this.planSorgLog = lastPlanSorgLog;

				this.MarkDirty();
			}
		}

		public int AgeYearsAtStartDate
		{
			get
			{
				return CalculateYears(patient.DateOfBirth, this.ERCStartDate);
			}
		}

		public int AgeMonthsAtStartDate
		{
			get
			{
				return CalculateYears(patient.DateOfBirth, this.ERCStartDate);
			}
		}

		public bool CanbeMomAtStartDate
		{
			get
			{
				if (this.patient.Gender != GenderCode.Female)
					return false;
				if (this.AgeYearsAtStartDate >= 12)
					return true;
				else
					return false;
			}
		}

		public bool CanbeBabyAtStartDate
		{
			get
			{
				int ageMonthsAtStartDate = this.AgeMonthsAtStartDate;
				if (ageMonthsAtStartDate >= 0 && ageMonthsAtStartDate <= 12)
					return true;
				else
					return false;
			}
		}

		public bool IsMom
		{
			get
			{
				if (!this.CanbeMomAtStartDate)
					return false;
				MomBabyCodeCollection mombabycodes = new MomBabyCodeCollection();
				string mb = mombabycodes.FindMomBabyRanges(this, true, false);
				if (mb == null)
					return false;
				return mb.IndexOf("M") >= 0; 
			}
		}

		public bool IsBaby
		{
			get
			{
				if (!this.CanbeBabyAtStartDate)
					return false;
				MomBabyCodeCollection mombabycodes = new MomBabyCodeCollection();
				string mb = mombabycodes.FindMomBabyRanges(this, false, true);
				if (mb == null)
					return false;
				return mb.IndexOf("B") >= 0; 
			}
		}

		public bool CheckUserDxPxPermission()
		{
			// Just check if there's any ruled out diagnostic or procedure code.
			// If found one, return false to indicate that the user has no permission.

			if (AASecurityHelper.IsAdminRole)
				return true;

			DiagnosticSelectCollection diags = this.CreateDiagnosticSelectionCollection();
			SecurityGroupDiagnosisLevelCollection diagRangeFilters = AASecurityHelper.AAUser.DiagnosticRangeFilters;
			foreach (DiagnosticSelect diag in diags)
			{
				if (diagRangeFilters.IsCodeRuledOutByAFilter(diag.CodeType, diag.CodeValue))
					return false;
			}

			ProcedureSelectCollection procs = this.CreateProcedureSelectionCollection();
			SecurityGroupProcedureLevelCollection procRangeFilters = AASecurityHelper.AAUser.ProcedureRangeFilters;
			foreach (ProcedureSelect proc in procs)
			{
				if (procRangeFilters.IsCodeRuledOutByAFilter(proc.CodeType, proc.CodeValue))
					return false;
			}

			return true;
		}

		public void AutoActivity_CodingDxPx(string ruleType, DxPxSelectCollection dxPxBeingCoded)
		{
			this.autoActivityManager = new AutoActivityManager(this.patient, this.PatientSubscriberLog.PatientCoverage, null, this);
			foreach (DxPxSelect dxpx in dxPxBeingCoded)
			{
				if (dxpx.IsNew)
				{
					// being coded.
					autoActivityManager.DxPx = dxpx;
					autoActivityManager.Execute(ruleType, this.SqlData.Transaction);
				}
			}
		}

		public override string UserFriendlyDescription
		{
			get { return String.Format("{0} {1}", this.ERCTypeDisplay, this.PKString); }
		}

		public System.Exception DrgCalcEx
		{
			get { return this.drgCalcEx; }
		}

		public ArrayList DRGMessageLog
		{
			get { return this.drgMessageLog; }
			set { this.drgMessageLog = value; }
		}

	}

	/// <summary>
	/// Event, CMS, and Referral must derive from this abstract class
	/// and override the abstract methods.
	/// </summary>
	[ElementType(typeof(BaseForEventCMSReferral))]
	public abstract class BaseCollectionForEventCMSReferral : BaseDataCollection, ICollectionElementFilter
	{
		private bool filterLinkedOnly = false;			// filter only linked problems when displaying in grid

		/*protected abstract int LoadPatientERC(Patient patient);

		public int Load(Patient patient)
		{
			int count = LoadPatientERC(patient);
			foreach(BaseForEventCMSReferral erc in this)
			{
				erc.ParentPatient = patient;
			}

			return count;
		}*/

		public abstract void DetermineElementsLinkedToProblem(Problem problem);

		// set the parent patients for all the events.
		/// <summary>
		/// Sets the parent patients for all the events.
		/// Event, CMS or Referral collections call this just after loading the records for a given Patient object.
		/// After this step, the in-memory relationship between these objects and the Patient will be established.
		/// </summary>
		/// <param name="patient"></param>
		protected void SetParentPatientObject(Patient patient)
		{
			foreach(BaseForEventCMSReferral erc in this)
			{
				erc.ParentPatient = patient;
			}
		}

		#region ICollectionElementFilter Members

		public bool FilterElement(int index)
		{
			if (!filterLinkedOnly)
				return true;

			BaseForEventCMSReferral erc = (BaseForEventCMSReferral)this.GetAt(index);
			return erc.IsLinkedToProblem;
		}

		#endregion

		/// <summary>
		/// Filter only 
		/// </summary>
		public bool FilterLinkedOnly
		{
			get { return this.filterLinkedOnly; }
			set { this.filterLinkedOnly = value; }
		}

		/// <summary>
		/// Searches by Alt Event ID, Alt CMS ID or Alt Referral ID depending on the
		/// concrete class.
		/// </summary>
		public abstract int SearchByAltAuthorizationID(int maxRecords, string altAuthorizationID);

		/// <summary>
		/// Sorts the collection by the ERC ID.
		/// </summary>
		public void SortByID(bool ascending, bool ignoreCase)
		{
			CollectionUtil.SortBy(this, ascending, ignoreCase, new string[] { "ID" });		
		}

		/// <summary>
		/// Sorts the collection by CreateTime
		/// </summary>
		public void SortByStartDate(bool ascending, bool ignoreCase)
		{
			CollectionUtil.SortBy(this, ascending, ignoreCase, new string[] { "ERCStartDate" });
		}

	}

	/// <summary>
	/// A concrete collection that can contain any of Event/Referral/CMS
	/// </summary>
	public class ERCContainerCollection : BaseCollectionForEventCMSReferral
	{
		public override void DetermineElementsLinkedToProblem(Problem problem)
		{
			throw new NotImplementedException("ERCContainerCollection is intended to contain Event/Referral/CMS objects only");
		}

		public override int SearchByAltAuthorizationID(int maxRecords, string altAuthorizationID)
		{
			throw new NotImplementedException("ERCContainerCollection is intended to contain Event/Referral/CMS objects only");
		}

		public override BaseDataClass NewRecord(bool initAsNewRecord)
		{
			if (initAsNewRecord)
				return new Event(null, true);
			else
				return new Event();
		}

	}

}
