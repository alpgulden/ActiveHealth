using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for BaseOrganization.
	/// </summary>
	public class BaseMOS : BaseAssessment
	{
		[ColumnMapping("MorgID",StereoType=DataStereoType.FK)]
		protected int morgID;
		[ColumnMapping("OrgID",StereoType=DataStereoType.FK)]
		protected int orgID;
		[ColumnMapping("SorgID",StereoType=DataStereoType.FK)]
		protected int sorgID;

		protected int organizationId;
		protected string organizationPath;
		protected Organization organization;

		protected string morgName;
		protected string orgName;
		protected string sorgName;

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int MorgID
		{
			get { return this.morgID; }
			set { this.morgID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int OrgID
		{
			get { return this.orgID; }
			set { this.orgID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int SorgID
		{
			get { return this.sorgID; }
			set { this.sorgID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string OrganizationPath
		{
			get { return this.organizationPath; }
			set { this.organizationPath = value; }
		}
		
		[FieldDescription("@ORGANIZATION@")]
		public string OrganizationNameGridDisplay
		{
			get
			{
				this.OrganizationId = this.OrganizationId; // sets OrganizationID and Loads Organization
				if (this.organization.OrganizationID > 0)
					return this.organization.Name + " (" + this.organization.OrganizationLevel.Code + ")";
				else
					return "All";
			}
		}

		[FieldDescription("@ORGANIZATION@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int OrganizationId
		{
			get 
			{ 
				if(this.sorgID > 0)
				{
					this.organizationId = this.sorgID;
				}
				else if(this.orgID > 0)
				{
					this.organizationId = this.orgID;
				}
				else if(this.morgID > 0)
				{
					this.organizationId = this.morgID;
				}
				if (this.organizationId > 0)
					return this.organizationId;
				else
					return 0;	
			}
			set 
			{ 
				this.organizationId = value; 
				//determine level of given Organization and set ID's accordingly
				this.organization = new Organization();
				if ( this.organizationId == 0)
				{
					this.morgID = 0;
					this.orgID = 0;
					this.sorgID = 0;
					return;
				}
				
				if (this.organization.Load(this.organizationId))
				{
					switch (this.organization.OrganizationLevel.Code)
					{
						case "MORG":
							this.morgID = this.organizationId;
							this.orgID = 0;
							this.sorgID = 0;
							this.morgName = this.organization.Name;
							this.orgName = null;
							this.sorgName = null;
							break;
						case "ORG":
							this.morgID = this.organization.ParentOrganization.OrganizationID;
							this.orgID = this.organizationId;
							this.sorgID = 0;
							this.morgName = this.organization.Name;
							this.orgName = this.organization.ParentOrganization.Name;
							this.sorgName = null;
							break;
						case "SORG":
							this.morgID = this.organization.ParentOrganization.ParentOrganization.OrganizationID;
							this.orgID = this.organization.ParentOrganization.OrganizationID;
							this.sorgID = this.organizationId;
							this.morgName = this.organization.Name;
							this.orgName = this.organization.ParentOrganization.Name;
							this.sorgName = this.organization.ParentOrganization.ParentOrganization.Name;
							break;
						default:
							return;
					}
				}
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string MorgName
		{
			get { return this.morgName; }
			set { this.morgName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string OrgName
		{
			get { return this.orgName; }
			set { this.orgName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SorgName
		{
			get { return this.sorgName; }
			set { this.sorgName = value; }
		}
	}
}