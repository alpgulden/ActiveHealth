using System;
using System.IO;
using System.Collections;
using System.Runtime.InteropServices;
using System.Text;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using NetsoftUSA.Security;
using Tx4oleLib;

namespace ActiveAdvice.DataLayer
{
	public class SelectableFaxQueue : BaseData
	{
		private bool selected;
		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}

		public enum FaxQueueType
		{
			All  = 0,
			Succesful	   = 1,
			Error	   =  2
		}

		public enum FaxQueueUserFilterType
		{
			ForUser	=	0,
			ForAll		=	1,
			Undefined	=	2
		}
	} 
	
	

	/// <summary>
	/// Summary description for SelectableFaxQueue.
	/// Use this as a base for Fax Queues
	///  for now, a concrete one as well
	/// </summary>
	[TableMapping("","",true)]
	public class BaseFaxQueue : SelectableFaxQueue
	{
		public static string faxDirName = ConfigHelper.GetConfigValue("FaxDirName");
		public static string faxCoverDirName = ConfigHelper.GetConfigValue("FaxCoverDirName");

		public static bool SendQueueItemToFax(int queueID, FaxInfo faxInfo, string user)
		{
			LetterCustomText customText = new LetterCustomText(true);

			try
			{
				bool bRet = customText.Load(queueID);
				if (!bRet)
					throw (new ApplicationException("Load Custom Text Failed"));


				Debug.Assert(customText.CustomText != null);

				// now we prepare the pages
				string baseFileName = user + "_" + queueID;
				string cmdFileName = baseFileName + ".txt";
				string attachmentFileBaseName = baseFileName;
				string attachmentFileName = attachmentFileBaseName + ".rtf";
				string attachmentFullFileName = faxCoverDirName + "\\" + attachmentFileName;
				string cmdFullFileName = faxDirName + "\\" + cmdFileName;

				StringBuilder sb = new StringBuilder();
				sb.Append( "::"  + faxInfo.ToFName + "," + faxInfo.ToCompany + ","  + faxInfo.ToLName + "," + faxInfo.ToFaxNo + "\r\n");
				sb.Append( "::A="  + attachmentFileName + "," + "S=" + faxInfo.Subject + "," + "FH=" + faxInfo.FromCompany + "\r\n");
				sb.Append( "::Letter: "  + attachmentFileBaseName + "\r\n");
				sb.Append( ":: "  + faxInfo.Disclaimer);
				
				Debug.WriteLine(sb.ToString());				

				StreamWriter sw = null;
				sw = new StreamWriter(new FileStream(attachmentFullFileName,FileMode.Create));
				sw.Write(customText.CustomText.ToString());
				sw.Close();

				// write cmd file
				sw = new StreamWriter(new FileStream(cmdFullFileName,FileMode.Create));
				sw.Write(sb.ToString());
				sw.Close();
			}
			catch(Exception ex)
			{
				throw(ex);
			}
			finally
			{
			}

			return true;
		}


		/// <summary>
		/// Sends fax without the need of a queue item
		/// </summary>
		/// <param name="queueID"></param>
		/// <param name="faxInfo"></param>
		/// <param name="user"></param>
		/// <returns></returns>
		public static bool SendDirectFax(FaxInfo faxInfo, string user)
		{
			try
			{

				Debug.Assert(faxInfo.Attachment != null);

				// now we prepare the pages
				string baseFileName = user + "_" + DateTime.Now.Ticks.ToString();
				string cmdFileName = baseFileName + ".txt";
				string attachmentFileBaseName = baseFileName;
				string attachmentFileName = attachmentFileBaseName + ".rtf";
				string attachmentFullFileName = faxCoverDirName + "\\" + attachmentFileName;
				string cmdFullFileName = faxDirName + "\\" + cmdFileName;

				StringBuilder sb = new StringBuilder();
				sb.Append( "::"  + faxInfo.ToFName + "," + faxInfo.ToCompany + ","  + faxInfo.ToLName + "," + faxInfo.ToFaxNo + "\r\n");
				sb.Append( "::A="  + attachmentFileName + "," + "S=" + faxInfo.Subject + "," + "FH=" + faxInfo.FromCompany + "\r\n");
				sb.Append( "::Letter: "  + attachmentFileBaseName + "\r\n");
				sb.Append( ":: "  + faxInfo.Disclaimer);
				
				Debug.WriteLine(sb.ToString());				

				StreamWriter sw = null;
				sw = new StreamWriter(new FileStream(attachmentFullFileName,FileMode.Create));
				sw.Write(faxInfo.Attachment);
				sw.Close();

				// write cmd file
				sw = new StreamWriter(new FileStream(cmdFullFileName,FileMode.Create));
				sw.Write(sb.ToString());
				sw.Close();
			}
			catch(Exception ex)
			{
				throw(ex);
			}
			finally
			{
			}

			return true;
		}


		[ColumnMapping("")]
		protected int queueID;

		protected string userID;
		protected string logFile;
		protected string status;
		protected DateTime timeUpdated;

		public BaseFaxQueue()
		{
		}

		protected override void NewRecord()
		{
			base.NewRecord ();

			if (this.queueID == 0) // If it's not already set
				this.queueID = (int)SqlData.SPExecScalar("usp_GenerateNextID", 1);
		}

		#region properties
		[FieldDescription("Queue ID")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QueueID
		{
			get { return this.queueID; }
			set { this.queueID = value; }
		}

		[FieldDescription("Log File")]
		[ControlType(Macro=EnumControlTypeMacros.URL, IsRequired=true, ValueForNull=(string)(""))]
		public string LogFile
		{
			get { return this.logFile; }
			set { this.logFile = value; }
		}

		[FieldDescription("@USER@")]
		[ControlType(Macro=EnumControlTypeMacros.None, IsRequired=true, ValueForNull=(string)(""))]
		public string User
		{
			get { return this.userID; }
			set { this.userID = value; }
		}

		[FieldDescription("@STATUS@")]
		[ControlType(Macro=EnumControlTypeMacros.None, IsRequired=true)]
		public string StatusDisplayString
		{
			get { return MapStatusURLString(); }
		}

		[FieldDescription("@STATUS@")]
		[ControlType(Macro=EnumControlTypeMacros.None, IsRequired=false)]
		public string Status
		{
			get { return this.status; }
			set { this.status = value; }
		}


		[FieldDescription("Review")]
		[ControlType(Macro=EnumControlTypeMacros.None, IsRequired=false)]
		public string PreviewString
		{
			get { return MapPreviewURLString(); }
			set { }
		}


		[FieldDescription("Time Updated")]
		//[FieldDescription("@TIMEUPDATED@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime, IsRequired=true)]
		public System.DateTime TimeUpdated
		{
			get { return this.timeUpdated; }
			set { this.timeUpdated = value; }
		}
		#endregion


		private static string targeturlViewLog = "FaxLogView.aspx?Mode=VIEWLOG";
		private static string targeturlPreview = "FaxPreView.aspx?Mode=RTFFILE";
		private int popupWidth = 770;
		private int popupHeight = 520;
		private string MapStatusURLString()
		{
					string fullURL = String.Format("{0}&PARAM1={1}",  targeturlViewLog,this.logFile);
					string parameters   = String.Format("'width={0},height={1},resizable=0,titlebar=1,toolbar=0,scrollbars=0,status=0'", popupWidth,popupHeight);
					string statusURL =  "<a href=\"#\" onclick=\"window.open('" 
									+ fullURL
									+ "', 'VIEWLOG',"
									+ parameters
									+" ); return false;\" target=\"VIEWLOG\">" 
									+ this.status
									+ "</a>";
					return statusURL;
		}

		private string MapPreviewURLString()
		{
			// BDS - no longer needed
			return "";

//			// find out rtf file name
//			string strRFTFile = "";
//			char[] token1 = {'.'};
//			string[] s1 = this.logFile.Split(token1);
//			if (s1.Length >= 2) 
//			{
//				strRFTFile = s1[0] + ".rtf";
//			}
//
//			string fullURL = String.Format("{0}&PARAM1={1}&PARAM2={2}",  targeturlPreview,strRFTFile, this.queueID);
//			string parameters   = String.Format("'width={0},height={1},resizable=0,titlebar=1,toolbar=0,scrollbars=0,status=0'", popupWidth,popupHeight);
//			string statusURL =  "<a href=\"#\" onclick=\"window.open('" 
//				+ fullURL
//				+ "', 'PREVIEW',"
//				+ parameters
//				+" ); return false;\" target=\"PREVIEW\">" 
//				+ "REVIEW"
//				+ "</a>";
//			return statusURL;
		}
		
		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// do nothing
		}

		// concrete overrides
		public BaseFaxQueue(BaseFaxQueue bfq)
		{
			this.CopyMembersFrom(bfq, true, true, false);
			this.NewRecord();

			// Preserve the same QueueID
			this.queueID = bfq.QueueID;
		}

		public BaseFaxQueue(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			this.timeUpdated = DateTime.Now;
		}
		
	}



	/// <summary>
	/// Strongly typed collection of BaseFaxQueue objects
	/// </summary>
	[ElementType(typeof(BaseFaxQueue))]
	public class BaseFaxQueueCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		public static int MAXRECORDS = 15;

		[NonSerialized]
		private CollectionIndexer indexBy_QueueID;
	
		private static string OK_STATUS = "OK";
		private static string ERR_STATUS = "ERR";

		public virtual int LoadAllFaxQueueItems(
									DateTime startUpdateTime, string startUser,
									BaseFaxQueue.FaxQueueType queueType, 
									BaseFaxQueue.FaxQueueUserFilterType userFilterType, string user)
		{

			BaseFaxQueueCollection col = new BaseFaxQueueCollection();

			col.Clear();

			BaseFaxQueue item = null;

			
			string[] files = Directory.GetFiles(BaseFaxQueue.faxDirName);

			char[] token1 = {'_'};
			char[] token2 = {'.'};
			for (int i=0;i<files.Length;i++)
			{
				string logName = (new FileInfo(files[i])).Name;

				string[] s1 = logName.Split(token1);
				if (s1.Length < 2) continue;

				string[] s2 = s1[1].Split(token2);
				if (s1.Length < 2) continue;

				item = new BaseFaxQueue();
				item.User = s1[0];
				item.TimeUpdated = (new FileInfo(BaseFaxQueue.faxDirName +  "\\" + logName)).LastWriteTime;
				item.LogFile = logName;

				try 
				{
					item.QueueID = int.Parse(s2[0]);
				}
				catch(Exception exp)
				{
					item.QueueID = 0;
				}

				if (s2[1].ToUpper().CompareTo(OK_STATUS) == 0)
					item.Status = OK_STATUS;
				else if (s2[1].ToUpper().CompareTo(ERR_STATUS) == 0)
					item.Status = ERR_STATUS;
				else
					continue;

				if ( (queueType == BaseFaxQueue.FaxQueueType.Error && item.Status == OK_STATUS)
					|| 
					(queueType == BaseFaxQueue.FaxQueueType.Succesful && item.Status == ERR_STATUS))
					continue;

				if ( (userFilterType == BaseFaxQueue.FaxQueueUserFilterType.ForUser && item.User != user))
					continue;

				col.Add(item);
			}

			// now we sort
			col.InnerList.Sort(new BaseFaxQueueComparer());
			
			// get our guy
			this.Clear();
			int iCopied = 0;
			for (int i=0;i<col.Count;i++)
			{
				if (col[i].TimeUpdated <= startUpdateTime)
				{
					this.Add(col[i]);
					if (++iCopied >= BaseFaxQueueCollection.MAXRECORDS)
						break;
				}
			}

			return 0;
		}

		public void DeleteSelected()
		{
			try 
			{
				for (int i=this.List.Count-1;i>=0;i--)
				{
					if (((SelectableFaxQueue)this.List[i]).Selected)
					{
						Debug.WriteLine( ((BaseFaxQueue)this.List[i]).QueueID );
						string logFileName = BaseFaxQueue.faxDirName + "\\" + ((BaseFaxQueue)this.List[i]).LogFile;
						File.Delete(logFileName);
						this.RemoveAt(i);
					}
				}
			}
			catch(Exception exp)
			{
					throw exp;
			}
			finally
			{
			}
		}

		public void SetSelectedFromCollection(BaseFaxQueueCollection selected)
		{
			BaseFaxQueue existing = null;
			foreach (BaseFaxQueue item in this)
			{
				existing = selected.FindBy(item.QueueID);
				if (existing != null && !existing.IsMarkedForDeletion)
					((SelectableFaxQueue)item).Selected = true;
				else
					((SelectableFaxQueue)item).Selected = false;
			}
		}


		protected override void OnClear()
		{
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public BaseFaxQueue this[int index]
		{
			get
			{
				return (BaseFaxQueue)List[index];
			}
			set
			{
				List[index] = value;
			}
		}


		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			base.OnSetComplete (index, oldValue, newValue);		
		}


		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(BaseFaxQueue elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			//SetParentOnElem((LetterNonPrintedQueue)value, true);
			base.OnInsertComplete (index, value);		
		}



		/// <summary>
		/// Hashtable based index on queueID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QueueID
		{
			get
			{
				if (this.indexBy_QueueID == null)
					this.indexBy_QueueID = new CollectionIndexer(this, new string[] { "queueID" }, true);
				return this.indexBy_QueueID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on queueID fields returns the object.  Uses the IndexBy_QueueID indexer.
		/// </summary>
		public BaseFaxQueue FindBy(int queueID)
		{
			return (BaseFaxQueue)this.IndexBy_QueueID.GetObject(queueID);
		}


	}


	public class BaseFaxQueueComparer : IComparer 
	{
		public BaseFaxQueueComparer() 
		{
		}
		public int Compare(object x, object y) 
		{
			BaseFaxQueue item1 = (BaseFaxQueue)x;
			BaseFaxQueue item2 = (BaseFaxQueue)y;

			int returnVal= item1.TimeUpdated < item2.TimeUpdated ? 1: -1;
			if (item1.TimeUpdated == item2.TimeUpdated)
				returnVal = 0;

			return returnVal;
		}
	}
}

