using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	[SPAutoGen("usp_GetAllLetterGraphics","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetActiveLetterGraphics","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertLetterGraphic")]
	[SPUpdate("usp_UpdateLetterGraphic")]
	[SPLoad("usp_LoadLetterGraphic")]
	[TableMapping("LetterGraphic","graphicID")]
	public class LetterGraphic : BaseData
	{
		[NonSerialized]
		private LetterGraphicCollection parentLetterGraphicCollection;
		[ColumnMapping("GraphicID",StereoType=DataStereoType.FK)]
		private int graphicID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("FileLocation")]
		private string fileLocation;
		[ColumnMapping("Active")]
		private bool active = true;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public LetterGraphic()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public LetterGraphic(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GraphicID
		{
			get { return this.graphicID; }
			set { this.graphicID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1000)]
		public string FileLocation
		{
			get { return this.fileLocation; }
			set { this.fileLocation = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}


		/// <summary>
		/// Parent LetterGraphicCollection that contains this element
		/// </summary>
		public LetterGraphicCollection ParentLetterGraphicCollection
		{
			get
			{
				return this.parentLetterGraphicCollection;
			}
			set
			{
				this.parentLetterGraphicCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

	}

	/// <summary>
	/// Strongly typed collection of LetterGraphic objects
	/// </summary>
	[ElementType(typeof(LetterGraphic))]
	public class LetterGraphicCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterGraphic elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterGraphicCollection = this;
			else
				elem.ParentLetterGraphicCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterGraphic elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterGraphic this[int index]
		{
			get
			{
				return (LetterGraphic)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterGraphic)oldValue, false);
			SetParentOnElem((LetterGraphic)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllLetterGraphics(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLetterGraphics", maxRecords, this, false, new object[] {});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveLetterGraphics(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveLetterGraphics", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared LetterGraphicCollection which is cached in NSGlobal
		/// </summary>
		public static LetterGraphicCollection AllActiveLetterGraphics
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LetterGraphicCollection col = (LetterGraphicCollection)NSGlobal.EnsureCachedObject("AllActiveLetterGraphics", typeof(LetterGraphicCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadActiveLetterGraphics(-1, true);
				}
				return col;
			}
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterGraphic elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterGraphic)value, true);
			base.OnInsertComplete (index, value);		
		}


	}
}
