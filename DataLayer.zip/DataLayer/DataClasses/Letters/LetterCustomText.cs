using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	[SPDelete("usp_DeleteLetterCustomText")]
	[SPInsert("usp_InsertLetterCustomText")]
	[SPUpdate("usp_UpdateLetterCustomText")]
	[SPLoad("usp_LoadLetterCustomText")]
	[TableMapping("LetterCustomText","queueID",true)]
	public class LetterCustomText : BaseData
	{
		[ColumnMapping("QueueID")]
		private int queueID;
		[ColumnMapping("CustomText")]
		private string customText;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public LetterCustomText()
		{
		}

		public LetterCustomText(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QueueID
		{
			get { return this.queueID; }
			set { this.queueID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2147483647)]
		public string CustomText
		{
			get { return this.customText; }
			set { this.customText = value; }
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int queueID)
		{
			return base.Load(queueID);
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

	}
}
