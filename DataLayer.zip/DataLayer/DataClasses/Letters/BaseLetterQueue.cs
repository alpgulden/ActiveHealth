using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	
	public class SelectableLetterQueue : BaseLetterMOSP
	{
		private bool selected;

		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}
	} 
	
	
	public enum LetterQueueType
	{
		Undefined  = 0,
		Printed	   = 1,
		NotPrinted = 2,
		Draft	   = 3
	}
	
	/// <summary>
	/// Summary description for BaseLetterQueue.
	/// Use this as a base for Letter Queues
	/// </summary>
	[TableMapping("","queueID",true)]
	public class BaseLetterQueue : SelectableLetterQueue
	{
	
		[ColumnMapping("QueueID")]
		protected int queueID;
		[ColumnMapping("LetterTemplateID",StereoType=DataStereoType.FK)]
		protected int letterTemplateID;
		[ColumnMapping("UserID",StereoType=DataStereoType.FK)]
		protected int userID;
		[ColumnMapping("TeamID",StereoType=DataStereoType.FK)]
		protected int teamID;
		[ColumnMapping("ReceiverTypeID",StereoType=DataStereoType.FK)]
		protected int receiverTypeID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		protected int eventID;
		[ColumnMapping("EventDate", ValuesForNull.NullDateTime)]
		protected DateTime eventDate;
		[ColumnMapping("ProblemID",StereoType=DataStereoType.FK)]
		protected int problemID;
		[ColumnMapping("RequestID",StereoType=DataStereoType.FK)]
		protected int requestID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		protected int patientID;
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		protected int referralID;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		protected int referralDetailID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		protected int cMSID;
		[ColumnMapping("AssessmentGUID")]
		protected string assessmentGUID;
		[ColumnMapping("AssessmentDate")]
		protected DateTime assessmentDate;
		[ColumnMapping("ClinicalReviewDecisionID",StereoType=DataStereoType.FK)]
		protected int clinicalReviewDecisionID;
		[ColumnMapping("Version",StereoType=DataStereoType.FK)]
		protected int version;
		[ColumnMapping("MatrixTypeID",StereoType=DataStereoType.FK)]
		protected int matrixTypeID;
		[ColumnMapping("AttributePriority",StereoType=DataStereoType.FK)]
		protected int attributePriority;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;

		protected LetterCustomText letterCustomText;
		
		protected DateTime dateFrom;
		protected DateTime dateTo;
		
		protected LetterTemplate letterTemplate;

		public BaseLetterQueue()
		{
		}

		protected override void NewRecord()
		{
			base.NewRecord ();

//			if (this.queueID == 0) // If it's not already set
//				this.queueID = System.Guid.NewGuid().ToString("N");
		}

		public LetterCustomText LetterCustomText
		{
			get { return letterCustomText; }
			set { letterCustomText = value; }
		}

		public void LoadLetterCustomText(bool forceReload)
		{
			if (letterCustomText == null || forceReload)
			{
				LetterCustomText tmpletterCustomText = new LetterCustomText(true);
				if (tmpletterCustomText.Load(this.queueID))
					this.letterCustomText = tmpletterCustomText;
				else
					this.letterCustomText = new LetterCustomText(true);
			}
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QueueID
		{
			get { return this.queueID; }
			set { this.queueID = value; }
		}

		[FieldDescription("@LETTERTEMPLATE@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LetterTemplateID
		{
			get { return this.letterTemplateID; }
			set { this.letterTemplateID = value; }
		}

		[FieldDescription("@USER@")]
		[FieldValuesMember("LookupOf_UserID", "UserId", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int UserID
		{
			get { return this.userID; }
			set { this.userID = value; }
		}
		
		[FieldDescription("@USER@")]
		[ControlType(EnumControlTypes.TextBox)]
		public string UserName
		{
			get { return FormatUserForDisplay(this.userID); }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int TeamID
		{
			get { return this.teamID; }
			set { this.teamID = value; }
		}

		
		[FieldValuesMember("LookupOf_ReceiverTypeID", "ReceiverTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int ReceiverTypeID
		{
			get { return this.receiverTypeID; }
			set { this.receiverTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[FieldDescription("@GENERATIONDATE@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EventDate
		{
			get { return this.eventDate; }
			set { this.eventDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProblemID
		{
			get { return this.problemID; }
			set { this.problemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int RequestID
		{
			get { return this.requestID; }
			set { this.requestID = value; }
		}

		[FieldDescription("@PATIENT@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AssessmentDate
		{
			get { return this.assessmentDate; }
			set { this.assessmentDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int Version
		{
			get { return this.version; }
			set { this.version = value; }
		}

		[FieldValuesMember("LookupOf_MatrixTypeID", "MatrixTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int MatrixTypeID
		{
			get { return this.matrixTypeID; }
			set { this.matrixTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int AttributePriority
		{
			get { return this.attributePriority; }
			set { this.attributePriority = value; }
		}

		[FieldDescription("@STARTDATE@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DateFrom
		{
			get { return this.dateFrom; }
			set { this.dateFrom = value; }
		}

		[FieldDescription("@ENDDATE@")]
		[ValidatorMember("Vld_DateTo")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DateTo
		{
			get { return this.dateTo; }
			set { this.dateTo = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ClinicalReviewDecisionID
		{
			get { return this.clinicalReviewDecisionID; }
			set { this.clinicalReviewDecisionID = value; }
		}



		#region Virtual Properties & Methods
		public virtual LetterQueueType LQType
		{
			get { throw new Exception("No LetterQueueType"); }
		}

		[FieldDescription("@ID@")]
		public virtual int LQID
		{
			get { throw new Exception("No LetterQueueId"); }
		}

		[FieldDescription("@STATUS@")]
		public virtual string StatusGridDisplay
		{
			get { return " - "; }
		}

		public virtual bool LoadLetterQueue(int queueID)
		{
			throw new Exception("No LoadLetterQueue()");
		}
		#endregion

		#region Lookups
		public LetterReceiverTypeCollection LookupOf_ReceiverTypeID
		{
			get
			{
				return LetterReceiverTypeCollection.ActiveLetterReceiverTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public AAUserCollection LookupOf_UserID
		{
			get
			{
				return AAUserCollection.AllUsers; // Acquire a shared instance from the static member of collection
			}
		}

		public MatrixTypeCollection LookupOf_MatrixTypeID
		{
			get
			{
				return MatrixTypeCollection.ActiveMatrixTypes; // Acquire a shared instance from the static member of collection
			}
		}
		#endregion

		[GenericScript("Vld_DateTo", "@DateTo@ != null && @DateTo@ >= @DateFrom@;")]
		public string Vld_DateTo
		{
			get
			{
				return "End Date must be greater than Start date"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set {}
		}

		public ActiveAdvice.DataLayer.LetterTemplate LetterTemplate
		{
			get 
			{ 
				if(this.letterTemplate == null)
					this.letterTemplate = new LetterTemplate(this.LetterTemplateID, this.version);
				
				return this.letterTemplate; 
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			if (this.queueID == 0)
				this.queueID = (int)SqlData.SPExecScalar("usp_GenerateNextID", 1);

			base.InternalSave();
			
			if (this.letterCustomText != null)
			{
				this.letterCustomText.QueueID = this.queueID;
				this.letterCustomText.Save();
			}
		}


		public int GetNewBatchNumber()
		{
			return (int)SqlData.SPExecScalar("usp_GenerateNextID", 2 /* Batch Number */);
		}

		public void CreateBatchLogParameters(int reportAction, object isDuplex, object isEnvelope)
		{	
			object dateFrom = (this.DateFrom == DateTime.MinValue? (object)null: (object)this.DateFrom);
			object dateTo = (this.DateTo == DateTime.MinValue? (object)null: (object)this.DateTo);

			if (this is LetterPrintedQueue)
				SqlData.SPExecNonQuery("usp_CreateBatchLogParameters", (LetterPrintedQueue)this, false, new string[] {"reportaction", "dateFrom", "dateTo", "isDuplex", "isEnvelope", "dateTypeFilter"}, new object[] {reportAction, dateFrom, dateTo, isDuplex, isEnvelope, ((LetterPrintedQueue)this).DateTypeFilter} );
			else if (this is LetterNonPrintedQueue)
				SqlData.SPExecNonQuery("usp_CreateBatchLogParameters", (LetterNonPrintedQueue)this, false, new string[] {"reportaction", "dateFrom", "dateTo", "isDuplex", "isEnvelope"}, new object[] {reportAction, dateFrom, dateTo, isDuplex, isEnvelope} );
			else
				SqlData.SPExecNonQuery("usp_CreateBatchLogParameters", (BaseLetterQueue)this, false, new string[] {"reportaction", "dateFrom", "dateTo", "isDuplex", "isEnvelope"}, new object[] {reportAction, dateFrom, dateTo, isDuplex, isEnvelope} );

		}

	}

	/// <summary>
	/// Strongly typed collection of BaseLetterQueue objects
	/// This is a base Collection for LetterPrinted/LetterNotPrinted/LetterDraft Queues Collections
	/// </summary>
	[ElementType(typeof(BaseLetterQueue))]
	public abstract class BaseLetterQueueCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass, ICollectionElementFilter
	{
		[NonSerialized]
		private CollectionIndexer indexBy_QueueID;

		protected bool fillExtraFields = false;
		protected bool preSelect = false;
	
		public abstract int LoadAllLetters(int maxRecords);
		public abstract void Save();
		
		public static int MAXRECORDS = 200;

		protected bool filterSelected = false;

		public bool FilterSelected
		{
			get { return this.filterSelected; }
			set { this.filterSelected = value; }
		}

		public bool FillExtraFields
		{
			set { this.fillExtraFields = value; }
		}

		public bool PreSelect
		{
			get { return this.preSelect; }
			set { this.preSelect = value; }
		}

		public void SetSelectedFromCollection(BaseLetterQueueCollection selected)
		{
			BaseLetterQueue existing = null;
			foreach (BaseLetterQueue blq in this)
			{
				existing = selected.FindBy(blq.QueueID);
				if (existing != null && !existing.IsMarkedForDeletion)
					((SelectableLetterQueue)blq).Selected = true;
				else
					((SelectableLetterQueue)blq).Selected = false;
			}
		}

		public virtual BaseLetterQueueCollection GetFromSearch(BaseLetterQueue searcher, object isDuplex, object isEnvelope)
		{
			throw new Exception("GetFromSearch() not implemented");
		}

		public virtual void CreateFromCollectionAndSave(BaseLetterQueueCollection toBePrinted, bool overrideDelivery, bool delivery, Printer printerTo, bool newBatchNumber)
		{
			throw new Exception("CreateFromCollectionAndSave() not implemented");
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public BaseLetterQueue this[int index]
		{
			get
			{
				return (BaseLetterQueue)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		/// <summary>
		/// Hashtable based index on queueID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QueueID
		{
			get
			{
				if (this.indexBy_QueueID == null)
					this.indexBy_QueueID = new CollectionIndexer(this, new string[] { "queueID" }, true);
				return this.indexBy_QueueID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on queueID fields returns the object.  Uses the IndexBy_QueueID indexer.
		/// </summary>
		public BaseLetterQueue FindBy(int queueID)
		{
			return (BaseLetterQueue)this.IndexBy_QueueID.GetObject(queueID);
		}

		#region ICollectionElementFilter Members

		public bool FilterElement(int index)
		{
			return (!filterSelected || this[index].Selected);
		}

		#endregion

	}
}
