using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	// Custom DO NOT MODIFY with the Addin
	[SPAutoGen("usp_GetActiveLetterComplexDataByMatrixType","SelectAllByGivenArgs.sptpl","active", ManuallyManaged=true)]
	[SPAutoGen("usp_GetActiveLetterComplexData","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertLetterComplex")]
	[SPUpdate("usp_UpdateLetterComplex")]
	[SPLoad("usp_LoadLetterComplex")]
	[TableMapping("LetterComplex","letterComplexID")]
	public class LetterComplex : LetterMergeField
	{
		[NonSerialized]
		private LetterComplexCollection parentLetterComplexCollection;
		[ColumnMapping("LetterComplexID",StereoType=DataStereoType.FK)]
		private int letterComplexID;
		[ColumnMapping("HeaderText")]
		private string headerText;
		private LetterComplexFieldCollection letterComplexFields;
	
		public LetterComplex()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LetterComplexID
		{
			get { return this.letterComplexID; }
			set { this.letterComplexID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string HeaderText
		{
			get { return this.headerText; }
			set { this.headerText = value; }
		}


		/// <summary>
		/// Parent LetterComplexCollection that contains this element
		/// </summary>
		public LetterComplexCollection ParentLetterComplexCollection
		{
			get
			{
				return this.parentLetterComplexCollection;
			}
			set
			{
				this.parentLetterComplexCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child LetterComplexFields mapped to related rows of table LetterComplexField where [LetterComplexID] = [LetterComplexID]
		/// </summary>
		[SPLoadChild("", "letterComplexID")] // See LoadLetterComplexFields method for custom implementation
		public LetterComplexFieldCollection LetterComplexFields
		{
			get { return this.letterComplexFields; }
			set
			{
				this.letterComplexFields = value;
				if (value != null)
					value.ParentLetterComplex = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the LetterComplexFields collection
		/// </summary>
		public void LoadLetterComplexFields(bool forceReload)
		{
			this.letterComplexFields = (LetterComplexFieldCollection)LetterComplexFieldCollection.LoadChildCollection("LetterComplexFields", "usp_LoadLetterComplexFieldsInOrder", this, typeof(LetterComplexFieldCollection), letterComplexFields, forceReload, null);
		}

		/// <summary>
		/// Saves the LetterComplexFields collection
		/// </summary>
		public void SaveLetterComplexFields()
		{
			LetterComplexFieldCollection.SaveChildCollection(this.letterComplexFields, true);
		}

		/// <summary>
		/// Synchronizes the LetterComplexFields collection
		/// </summary>
		public void SynchronizeLetterComplexFields()
		{
			LetterComplexFieldCollection.SynchronizeChildCollection(this.letterComplexFields, true);
		}

		//public void DetectRequestDecisionContext(MergeContext mergeContext)
		//{
		//	TxHelper.DetectRequestDecisionContextByFilters(mergeContext, this.filter1, this.filter2, this.filter3, this.filter4, this.filter5);
		//}
	}

	/// <summary>
	/// Strongly typed collection of LetterComplex objects
	/// </summary>
	[ElementType(typeof(LetterComplex))]
	public class LetterComplexCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_MatrixTypeID_Shortcut;
		[NonSerialized]
		private CollectionIndexer indexBy_LetterComplexID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterComplex elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterComplexCollection = this;
			else
				elem.ParentLetterComplexCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterComplex elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterComplex this[int index]
		{
			get
			{
				return (LetterComplex)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterComplex)oldValue, false);
			SetParentOnElem((LetterComplex)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveLetterComplexData(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveLetterComplexData", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared LetterComplexCollection which is cached in NSGlobal
		/// </summary>
		public static LetterComplexCollection ActiveLetterComplexData
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LetterComplexCollection col = (LetterComplexCollection)NSGlobal.EnsureCachedObject("ActiveLetterComplexData", typeof(LetterComplexCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadActiveLetterComplexData(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadByMatrixType(int matrixTypeID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveLetterComplexDataByMatrixType", -1, this, false, new object[] { matrixTypeID, true });
		}


		/// <summary>
		/// Hashtable based index on letterComplexID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_LetterComplexID
		{
			get
			{
				if (this.indexBy_LetterComplexID == null)
					this.indexBy_LetterComplexID = new CollectionIndexer(this, new string[] { "letterComplexID" }, true);
				return this.indexBy_LetterComplexID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on letterComplexID fields returns the object.  Uses the IndexBy_LetterComplexID indexer.
		/// </summary>
		public LetterComplex FindBy(int letterComplexID)
		{
			return (LetterComplex)this.IndexBy_LetterComplexID.GetObject(letterComplexID);
		}

		/// <summary>
		/// Hashtable based index on matrixTypeID, shortcut fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_MatrixTypeID_Shortcut
		{
			get
			{
				if (this.indexBy_MatrixTypeID_Shortcut == null)
					this.indexBy_MatrixTypeID_Shortcut = new CollectionIndexer(this, new string[] { "matrixTypeID", "shortcut" }, true);
				return this.indexBy_MatrixTypeID_Shortcut;
			}
			
		}

		/// <summary>
		/// Hashtable based search on matrixTypeID, shortcut fields returns the object.  Uses the IndexBy_MatrixTypeID_Shortcut indexer.
		/// </summary>
		public LetterComplex FindBy(int matrixTypeID, string shortcut)
		{
			return (LetterComplex)this.IndexBy_MatrixTypeID_Shortcut.GetObject(matrixTypeID, shortcut);
		}

	}
}
