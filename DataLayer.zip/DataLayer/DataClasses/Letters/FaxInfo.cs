using System;
using System.Collections;
using NetsoftUSA.DataLayer;
using System.Diagnostics;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// 
	/// </summary>
	[SPInsert("")]
	[SPUpdate("")]
	[SPLoad("usp_LoadFaxInfo")]
	[TableMapping("","")]
	[Serializable]
	public class FaxInfo : BaseData
	{
		[ColumnMapping("",(int)0)]
		protected int faxInfoID;

		[ColumnMapping("ToFName")]
		protected string toFName;

		[ColumnMapping("ToLName")]
		protected string toLName;

		[ColumnMapping("ToFaxNo")]
		protected string toFaxNo;

		[ColumnMapping("ToCompany")]
		protected string toCompany;

		[ColumnMapping("FromCompany")]
		protected string fromCompany;
		
		[ColumnMapping("Subject")]
		protected string subject;

		[ColumnMapping("Disclaimer")]
		protected string disclaimer;

		[ColumnMapping("QueueID")]
		protected int queueID;

		protected string attachment;

		public FaxInfo()
		{
			//
			// TODO: Add constructor logic here
			//

			if (LicenseeCollection.Licensee != null)
			{
				this.Disclaimer = LicenseeCollection.Licensee.Disclaimer;
				this.FromCompany = LicenseeCollection.Licensee.FullName;
			}
			else
			{
				this.fromCompany = "Active Health Management";
				this.disclaimer = "Standard AHM Disclaimer";
			}

		}

		public FaxInfo(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = "";
			return s;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int FaxInfoID
		{
			get { return this.faxInfoID; }
			set { this.faxInfoID = value; }
		}

		[FieldDescription("To First Name")]
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		public string ToFName
		{
			get { return this.toFName; }
			set { this.toFName= Formatting.CapitalizeFirstLetter(value); }
		}

		[FieldDescription("To Last Name")]
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		public string ToLName
		{
			get { return this.toLName; }
			set { this.toLName = Formatting.CapitalizeFirstLetter(value); }
		}

		[FieldDescription("To Fax No")]
		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, ClientValidators=EnumClientValidators.Required, MaxLength=15)]
		public string ToFaxNo
		{
			get { return this.toFaxNo; }
			set { this.toFaxNo = value; }
		}

		[FieldDescription("To Company")]
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=128)]
		public string ToCompany
		{
			get { return this.toCompany; }
			set { this.toCompany = value; }
		}

		[FieldDescription("From Company")]
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=128)]
		public string FromCompany
		{
			get { return this.fromCompany; }
			set { this.fromCompany = value; }
		}

		[FieldDescription("Subject")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=128)]
		public string Subject
		{
			get { return this.subject; }
			set { this.subject = value; }
		}

		[FieldDescription("Disclaimer")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Disclaimer
		{
			get { return this.disclaimer; }
			set { this.disclaimer = value; }
		}

		[FieldDescription("Attachment")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Attachment
		{
			get { return this.attachment; }
			set { this.attachment = value; }
		}

		//[ControlType(EnumControlTypes.n, MaxLength=1000)]
		public int QueueID
		{
			get { return this.queueID; }
			set { this.queueID = value; }
		}


		/// <summary>
		/// Check if valid for save.
		/// </summary>
		public bool ValidateForSend()
		{
			if (!this.IsNew)
				return true;
			
			return true;
		}


		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
		}


		/// <summary>
		/// Given receivertype and patient context this method fills in the Fax Info
		/// </summary>
		/// <param name="receiverTypeID"></param>
		/// <param name="patientID"></param>
		/// <param name="referralID"></param>
		/// <param name="eventID"></param>
		/// <param name="cMSID"></param>
		/// <returns></returns>
		public bool FillFromReceiver(int receiverTypeID, int patientID, int referralID, int eventID, int cMSID)
		{
			SqlDataReader reader = null;
			try 
			{
				reader = SqlData.SPExecRead("usp_GetReceiver", new object[] {receiverTypeID, patientID, referralID, eventID, cMSID});

				string firstName,lastName,faxNo;

				if (reader["FirstName"] != DBNull.Value && (firstName = reader["FirstName"].ToString()) != "")
					this.ToFName = firstName;
				if (reader["LastName"] != DBNull.Value && (lastName = reader["LastName"].ToString()) != "")
					this.ToLName = lastName;
				if (reader["FaxNumber"] != DBNull.Value && (faxNo = reader["FaxNumber"].ToString()) != "")
					this.ToFaxNo = faxNo;
				
				return true;
			}
			catch(Exception ex)
			{
				return false;
			}
		}

	}
}
