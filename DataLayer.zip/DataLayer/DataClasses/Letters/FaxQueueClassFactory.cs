using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for FaxQueueClassFactory.
	/// </summary>
	public class FaxQueueClassFactory
	{
		#region Object Factories
		public static BaseFaxQueue CreateFaxQueue()
		{
				return new BaseFaxQueue();
		}

		// may need creation methods
		#endregion

		#region Collection Factories
		public static BaseFaxQueueCollection CreateFaxQueueCollection()
		{
				return new BaseFaxQueueCollection();
		}

		public static BaseFaxQueueCollection CreateFaxQueueCollectionAndLoad(
				DateTime startUpdateTime, string startUser,
				BaseFaxQueue.FaxQueueType queueType, BaseFaxQueue.FaxQueueUserFilterType filterType, string user)
		{
			BaseFaxQueueCollection lqc = CreateFaxQueueCollection();
			lqc.LoadAllFaxQueueItems(startUpdateTime, startUser,queueType, filterType, user);

			return lqc;
		}

		#endregion
	}
}


