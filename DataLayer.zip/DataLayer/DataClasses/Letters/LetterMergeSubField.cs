using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	[SPInsert("usp_InsertLetterMergeSubField")]
	[SPUpdate("usp_UpdateLetterMergeSubField")]
	[SPLoad("usp_LoadLetterMergeSubField")]
	[TableMapping("LetterMergeSubField","letterMergeSubFieldID")]
	public class LetterMergeSubField : BaseData
	{
		[NonSerialized]
		private LetterMergeSubFieldCollection parentLetterMergeSubFieldCollection;
		[ColumnMapping("LetterMergeSubFieldID",StereoType=DataStereoType.FK)]
		private int letterMergeSubFieldID;
		[ColumnMapping("LetterMergeFieldID",StereoType=DataStereoType.FK)]
		private int letterMergeFieldID;
		[ColumnMapping("HeaderText")]
		private string headerText;
		[ColumnMapping("ColumnPosition",StereoType=DataStereoType.FK)]
		private int columnPosition;
	
		public LetterMergeSubField()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LetterMergeSubFieldID
		{
			get { return this.letterMergeSubFieldID; }
			set { this.letterMergeSubFieldID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LetterMergeFieldID
		{
			get { return this.letterMergeFieldID; }
			set { this.letterMergeFieldID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=100)]
		public string HeaderText
		{
			get { return this.headerText; }
			set { this.headerText = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ColumnPosition
		{
			get { return this.columnPosition; }
			set { this.columnPosition = value; }
		}

		/// <summary>
		/// Parent LetterMergeSubFieldCollection that contains this element
		/// </summary>
		public LetterMergeSubFieldCollection ParentLetterMergeSubFieldCollection
		{
			get
			{
				return this.parentLetterMergeSubFieldCollection;
			}
			set
			{
				this.parentLetterMergeSubFieldCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of LetterMergeSubField objects
	/// </summary>
	[ElementType(typeof(LetterMergeSubField))]
	public class LetterMergeSubFieldCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterMergeSubField elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterMergeSubFieldCollection = this;
			else
				elem.ParentLetterMergeSubFieldCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterMergeSubField elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterMergeSubField this[int index]
		{
			get
			{
				return (LetterMergeSubField)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterMergeSubField)oldValue, false);
			SetParentOnElem((LetterMergeSubField)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent LetterMergeField that contains this collection
		/// </summary>
		public LetterMergeField ParentLetterMergeField
		{
			get { return this.ParentDataObject as LetterMergeField; }
			set { this.ParentDataObject = value; /* parent is set when contained by a LetterMergeField */ }
		}
	}
}
