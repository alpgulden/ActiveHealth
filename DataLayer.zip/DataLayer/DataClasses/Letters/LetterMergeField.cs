using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	// Custom DO NOT MODIFY with the Addin
	// [SPAutoGen("usp_GetActiveLetterMergeFieldsByMatrixType","SelectAllByGivenArgs.sptpl","active", InjectWhere="AND [LetterMergeField].[MatrixTypeID] = @matrixTypeID OR [LetterMergeField].[MatrixTypeID] IS NULL", InjectParameters="matrixTypeID")]
	[SPAutoGen("usp_GetActiveLetterMergeFields","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertLetterMergeField")]
	[SPUpdate("usp_UpdateLetterMergeField")]
	[SPDelete("usp_DeleteLetterMergeField")]
	[SPLoad("usp_LoadLetterMergeField")]
	[TableMapping("LetterMergeField","letterMergeFieldID")]
	public class LetterMergeField : BaseData
	{
		[NonSerialized]
		protected LetterMergeFieldCollection parentLetterMergeFieldCollection;
		[ColumnMapping("LetterMergeFieldID",StereoType=DataStereoType.FK)]
		private int letterMergeFieldID;
		[ColumnMapping("Origin")]
		protected string origin;
		[ColumnMapping("Description")]
		protected string description;
		[ColumnMapping("Shortcut")]
		protected string shortcut;
		[ColumnMapping("Filter1")]
		protected string filter1;
		[ColumnMapping("Filter2")]
		protected string filter2;
		[ColumnMapping("Filter3")]
		protected string filter3;
		[ColumnMapping("Filter4")]
		protected string filter4;
		[ColumnMapping("Filter5")]
		protected string filter5;
		[ColumnMapping("MatrixTypeID",StereoType=DataStereoType.FK)]
		protected int matrixTypeID;
		[ColumnMapping("Active")]
		protected bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;

		// set after DetectRequestDecisionContext
		protected bool requestContext;
		protected bool decisionContext;
	
		public LetterMergeField()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LetterMergeFieldID
		{
			get { return this.letterMergeFieldID; }
			set { this.letterMergeFieldID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Origin
		{
			get { return this.origin; }
			set { this.origin = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		public string Shortcut
		{
			get { return this.shortcut; }
			set { this.shortcut = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Filter1
		{
			get { return this.filter1; }
			set { this.filter1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Filter2
		{
			get { return this.filter2; }
			set { this.filter2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Filter3
		{
			get { return this.filter3; }
			set { this.filter3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Filter4
		{
			get { return this.filter4; }
			set { this.filter4 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Filter5
		{
			get { return this.filter5; }
			set { this.filter5 = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MatrixTypeID
		{
			get { return this.matrixTypeID; }
			set { this.matrixTypeID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Parent LetterMergeFieldCollection that contains this element
		/// </summary>
		public LetterMergeFieldCollection ParentLetterMergeFieldCollection
		{
			get
			{
				return this.parentLetterMergeFieldCollection;
			}
			set
			{
				this.parentLetterMergeFieldCollection = value; // parent is set when added to a collection
			}
		}

		public void DetectRequestDecisionContext(MergeContext mergeContext)
		{
			TxHelper.DetectRequestDecisionContextByFilters(ref requestContext, ref decisionContext, this.filter1, this.filter2, this.filter3, this.filter4, this.filter5);
			if (requestContext)
				mergeContext.RequestContext = true;
			if (decisionContext)
				mergeContext.DecisionContext = true;
		}

		public bool RequestContext
		{
			get { return this.requestContext; }
			//set { this.requestContext = value; }
		}

		public bool DecisionContext
		{
			get { return this.decisionContext; }
			//set { this.decisionContext = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of LetterMergeField objects
	/// </summary>
	[ElementType(typeof(LetterMergeField))]
	public class LetterMergeFieldCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_MatrixTypeID_Shortcut;
		[NonSerialized]
		private CollectionIndexer indexBy_LetterMergeFieldID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterMergeField elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterMergeFieldCollection = this;
			else
				elem.ParentLetterMergeFieldCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterMergeField elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterMergeField this[int index]
		{
			get
			{
				return (LetterMergeField)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterMergeField)oldValue, false);
			SetParentOnElem((LetterMergeField)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}




		/// <summary>
		/// Hashtable based index on letterMergeFieldID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_LetterMergeFieldID
		{
			get
			{
				if (this.indexBy_LetterMergeFieldID == null)
					this.indexBy_LetterMergeFieldID = new CollectionIndexer(this, new string[] { "letterMergeFieldID" }, true);
				return this.indexBy_LetterMergeFieldID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on letterMergeFieldID fields returns the object.  Uses the IndexBy_LetterMergeFieldID indexer.
		/// </summary>
		public LetterMergeField FindBy(int letterMergeFieldID)
		{
			return (LetterMergeField)this.IndexBy_LetterMergeFieldID.GetObject(letterMergeFieldID);
		}

		/// <summary>
		/// Hashtable based index on matrixTypeID, shortcut fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_MatrixTypeID_Shortcut
		{
			get
			{
				if (this.indexBy_MatrixTypeID_Shortcut == null)
					this.indexBy_MatrixTypeID_Shortcut = new CollectionIndexer(this, new string[] { "matrixTypeID", "shortcut" }, true);
				return this.indexBy_MatrixTypeID_Shortcut;
			}
			
		}

		/// <summary>
		/// Hashtable based search on matrixTypeID, shortcut fields returns the object.  Uses the IndexBy_MatrixTypeID_Shortcut indexer.
		/// </summary>
		public LetterMergeField FindBy(int matrixTypeID, string shortcut)
		{
			return (LetterMergeField)this.IndexBy_MatrixTypeID_Shortcut.GetObject(matrixTypeID, shortcut);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveLetterMergeFields(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveLetterMergeFields", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared LetterMergeFieldCollection which is cached in NSGlobal
		/// </summary>
		public static LetterMergeFieldCollection ActiveLetterMergeFields
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LetterMergeFieldCollection col = (LetterMergeFieldCollection)NSGlobal.EnsureCachedObject("ActiveLetterMergeFields", typeof(LetterMergeFieldCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadActiveLetterMergeFields(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadByMatrixType(int matrixTypeID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveLetterMergeFieldsByMatrixType", -1, this, false, new object[] { matrixTypeID, true });
		}


	}
}
