using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterDraftQueue]
	/// </summary>

	[SPAutoGen("usp_GetAllLettersDraftQueue","SelectAll.sptpl","")]
	[SPInsert("usp_InsertLetterDraftQueue")]
	[SPUpdate("usp_UpdateLetterDraftQueue")]
	[SPDelete("usp_DeleteLetterDraftQueue")]
	[SPLoad("usp_LoadLetterDraftQueue")]
	[TableMapping("LetterDraftQueue","queueID",true)]
	public class LetterDraftQueue : BaseLetterQueue 
	{

		private LetterDraftQueueCollection parentLetterDraftQueueCollection;


		#region overriden methods from BaseLetterQueue
		public override int LQID
		{
			get { return this.queueID; }
		}

		public override LetterQueueType LQType
		{
			get { return LetterQueueType.Draft; }
		}

		public override bool LoadLetterQueue(int queueID)
		{
			//return base.LoadLetterQueue (queueID);
			return this.Load(queueID);
		}
		#endregion

		public LetterDraftQueue()
		{
		}

		public LetterDraftQueue(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent LetterDraftQueueCollection that contains this element
		/// </summary>
		public LetterDraftQueueCollection ParentLetterDraftQueueCollection
		{
			get
			{
				return this.parentLetterDraftQueueCollection;
			}
			set
			{
				this.parentLetterDraftQueueCollection = value; // parent is set when added to a collection
			}
		}


		public int GetLetterCount(object isDuplex, object isEnvelope)
		{
			object dateFrom = (this.DateFrom == DateTime.MinValue? (object)null: (object)this.DateFrom);
			object dateTo = (this.DateTo == DateTime.MinValue? (object)null: (object)this.DateTo);

			object ret = SqlData.SPExecScalar("usp_ManageLetterNonPrintedQueue", this, false, 
				new string[] {"action", "dateFrom", "dateTo", "isDuplex", "isEnvelope"},
				new object[] {2 /*Count*/, dateFrom, dateTo, isDuplex, isEnvelope});
			return SQLDataDirect.GetFromDBValue(ret, 0);
		}
	}

	/// <summary>
	/// Strongly typed collection of LetterDraftQueue objects
	/// </summary>
	[ElementType(typeof(LetterDraftQueue))]
	public class LetterDraftQueueCollection : BaseLetterQueueCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterDraftQueue elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterDraftQueueCollection = this;
			else
				elem.ParentLetterDraftQueueCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterDraftQueue elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterDraftQueue this[int index]
		{
			get
			{
				return (LetterDraftQueue)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterDraftQueue)oldValue, false);
			SetParentOnElem((LetterDraftQueue)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterDraftQueue elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterDraftQueue)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public override void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public override int LoadAllLetters(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLetterDraftQueue", maxRecords, this, false);
		}

		public void DeleteSelectedAndSave()
		{
			foreach(LetterDraftQueue ldf in this)
			{
				ldf.IsMarkedForDeletion = (((SelectableLetterQueue)ldf).Selected ? true : false);
			}
			this.Save();
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchLettersDraftQueue(int maxRecords, LetterDraftQueue searcher, object isDuplex, object isEnvelope)
		{
			object dateFrom = (searcher.DateFrom == DateTime.MinValue? (object)null: (object)searcher.DateFrom);
			object dateTo = (searcher.DateTo == DateTime.MinValue? (object)null: (object)searcher.DateTo);
			this.Clear();

			this.ElementType = typeof(LetterDraftQueueSearchResult);
			
			return SqlData.SPExecReadCol("usp_ManageLetterDraftQueue", maxRecords, this, searcher, false,
				new string[] {"dateFrom", "dateTo", "isDuplex", "isEnvelope", "rowCount"}, new object[] {dateFrom, dateTo, isDuplex, isEnvelope, MAXRECORDS});
		}

		public override BaseLetterQueueCollection GetFromSearch(BaseLetterQueue searcher, object isDuplex, object isEnvelope)
		{
			this.SearchLettersDraftQueue(-1, searcher as LetterDraftQueue, isDuplex, isEnvelope);
			return this; 
		}

		protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);
			if (this.preSelect)
				((LetterDraftQueue)data).Selected = true;
		}

	}

	[SPAutoGen("usp_SearchLetterDraftQueue", null, ManuallyManaged=true)]
	public class LetterDraftQueueSearchResult : LetterDraftQueue
	{
		[NonSerialized]
		private LetterDraftQueueSearchResultCollection parentLetterDraftQueueSearchResultCollection;
		[ColumnMapping("PatientName")]
		private string patientName;
		[ColumnMapping("LetterTemplateName")]
		private string letterTemplateName;
		[ColumnMapping("ReceiverTypeDescription")]
		private string receiverTypeDescription;
		[ColumnMapping("AssessmentID", StereoType=DataStereoType.FK)]
		private int assessmentID;
		[ColumnMapping("MatrixTypeCode")]
		private string matrixTypeCode;
		[ColumnMapping("LetterFormTypeCode")]
		private string letterFormTypeCode;
		[ColumnMapping("PlanDisplayName")]
		private string planDisplayName;

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientName
		{
			get { return this.patientName; }
			set { this.patientName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LetterTemplateName
		{
			get { return this.letterTemplateName; }
			set { this.letterTemplateName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string ReceiverTypeDescription
		{
			get { return this.receiverTypeDescription; }
			set { this.receiverTypeDescription = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int AssessmentID
		{
			get { return this.assessmentID; }
			set { this.assessmentID = value; }
		}

		/// <summary>
		/// Parent LetterDraftQueueSearchResultCollection that contains this element
		/// </summary>
		public LetterDraftQueueSearchResultCollection ParentLetterDraftQueueSearchResultCollection
		{
			get
			{
				return this.parentLetterDraftQueueSearchResultCollection;
			}
			set
			{
				this.parentLetterDraftQueueSearchResultCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string MatrixTypeCode
		{
			get { return this.matrixTypeCode; }
			set { this.matrixTypeCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LetterFormTypeCode
		{
			get { return this.letterFormTypeCode; }
			set { this.letterFormTypeCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PlanDisplayName
		{
			get { return this.planDisplayName; }
			set { this.planDisplayName = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of LetterDraftQueueSearchResult objects
	/// </summary>
	[ElementType(typeof(LetterDraftQueueSearchResult))]
	public class LetterDraftQueueSearchResultCollection : LetterDraftQueueCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterDraftQueueSearchResult elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterDraftQueueSearchResultCollection = this;
			else
				elem.ParentLetterDraftQueueSearchResultCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterDraftQueueSearchResult elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterDraftQueueSearchResult this[int index]
		{
			get
			{
				return (LetterDraftQueueSearchResult)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterDraftQueueSearchResult)oldValue, false);
			SetParentOnElem((LetterDraftQueueSearchResult)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}

}
