using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{	
	public enum SessionIndicator
	{
		Initial = 1,
		All		= 2 
	}

	public class BaseLetterMOSP : BaseMOS
	{
		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
		protected int planID;

		protected string planName;

		protected int activeWithTerminatedAndAll = -1;
		protected Plan plan;

		[FieldValuesMember("LookupOf_ActiveWithTerminatedAndAll")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true, ValueForNull=(int)-1)]
		[FieldDescription("@ACTIVE@")]
		public int ActiveWithTerminatedAndAll
		{
			get { return this.activeWithTerminatedAndAll; }
			set { this.activeWithTerminatedAndAll = value; }
		}


		public object[,] LookupOf_ActiveWithTerminatedAndAll
		{
			get
			{
				return base.ValuesOf_ActiveWithTerminatedAndAll; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@PLAN@")]
		public int PlanID
		{
			get { return this.planID; }
			set 
			{ 
				this.planID = value; 
				this.plan = null;			// cause reload of plan
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PlanName
		{
			get 
			{
				if (this.Plan == null)
					return null;				// no plan.
				return this.Plan.Name; 
			}
		}

		/// <summary>
		/// Loaded and cached Plan
		/// </summary>
		public Plan Plan
		{
			get
			{
				if (this.plan == null)
					this.plan = GetPlan();
				return this.plan;
			}
			set
			{
				this.plan = value;
				if (value == null)
					this.planID = 0;
				else
					this.planID = plan.PlanId;
			}
		}

		/// <summary>
		/// Loads and returns the associated Plan.
		/// </summary>
		/// <returns></returns>
		public Plan GetPlan()
		{
			if (this.planID == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.planID))
				return plan;
			else
				return null;
		}
	}
	
	/// <summary>
	/// Summary description for SelectableLetterMatrix.
	/// </summary>
	public class SelectableLetterMatrix : LetterMatrix
	{
		private bool selected;

		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterMatrix]
	/// Uses customized version of
	/// ("usp_SearchLetterMatrix","SearchByArgs.sptpl","letterSetID, matrixTypeID, sessionIndicator, morgID, orgID, sorgID, planID, referralTypeID, eventTypeID, clinicalReviewDecisionTypeID, clinicalReviewDecisionReasonID, enrollmentID")]
	/// </summary>
	[SPAutoGen("usp_SearchLetterMatrix", null, ManuallyManaged=true)]
	[SPInsert("usp_InsertLetterMatrix")]
	[SPUpdate("usp_UpdateLetterMatrix")]
	[SPLoad("usp_LoadLetterMatrix")]
	[TableMapping("LetterMatrix","matrixID")]
	public class LetterMatrix : BaseLetterMOSP
	{
		[NonSerialized]
		protected LetterMatrixCollection parentLetterMatrixCollection;
		[ColumnMapping("MatrixID",(int)0)]
		protected int matrixID;
		[ColumnMapping("MatrixTypeID",StereoType=DataStereoType.FK)]
		protected int matrixTypeID;
		[ColumnMapping("LetterSetID",StereoType=DataStereoType.FK)]
		protected int letterSetID;
		[ColumnMapping("EnrollmentID",StereoType=DataStereoType.FK)]
		protected int enrollmentID;
		[ColumnMapping("TerminationDate")]
		protected DateTime terminationDate;
		[ColumnMapping("Description")]
		protected string description;
		[ColumnMapping("SessionIndicator",StereoType=DataStereoType.FK)]
		protected int sessionIndicator;
		[ColumnMapping("EventTypeID",StereoType=DataStereoType.FK)]
		protected int eventTypeID;
		[ColumnMapping("ClinicalReviewDecisionTypeID",StereoType=DataStereoType.FK)]
		protected int clinicalReviewDecisionTypeID;
		[ColumnMapping("ClinicalReviewDecisionReasonID",StereoType=DataStereoType.FK)]
		protected int clinicalReviewDecisionReasonID;
		[ColumnMapping("ReferralTypeID",StereoType=DataStereoType.FK)]
		protected int referralTypeID;
		[ColumnMapping("ReferralUnitID",StereoType=DataStereoType.FK)]
		protected int referralUnitID;
		[ColumnMapping("LetterTypeID",StereoType=DataStereoType.FK)]
		protected int letterTypeID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		protected int referralDetailID;
		[ColumnMapping("FacilityState")]
		protected string facilityState;
		[ColumnMapping("ReviewNumber",StereoType=DataStereoType.FK)]
		protected int reviewNumber;
		[ColumnMapping("TerminateTime")]
		protected DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		protected int terminatedBy;
		[ColumnMapping("ReferralDetailText")]
		protected string referralDetailText;


		private DateTime terminateDateWhenLoaded;
		private LetterMatrixExceptionCollection letterMatrixExceptions; // used to determine if LetterMatrix is being terminated
	
		public LetterMatrix()
		{
		}

		public LetterMatrix(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public LetterMatrix(int matrixID)
		{
			this.NewRecord(); // initialize record state
			this.Load(matrixID);
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int MatrixID
		{
			get { return this.matrixID; }
			set { this.matrixID = value; }
		}

		[FieldValuesMember("LookupOf_MatrixTypeID", "MatrixTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true, ValueForNull=(int)0)]
		[FieldDescription("@MATRIXTYPE@")]
		public int MatrixTypeID
		{
			get { return this.matrixTypeID; }
			set { this.matrixTypeID = value; }
		}

		[FieldValuesMember("LookupOf_LetterSetID", "LetterSetID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true, ValueForNull=(int)0)]
		[FieldDescription("@LETTERSET@")]
		public int LetterSetID
		{
			get { return this.letterSetID; }
			set { this.letterSetID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255, IsRequired=true)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@TERMINATIONDATE@")]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[FieldDescription("@ENROLLMENT@")]
		public string EnrollmentIDGridDisplay
		{
			get
			{
				if (this.enrollmentID == 0)
					return "All";
				else
					return EnrollmentCollection.AllEnrollmentsByValidDateRange.Lookup_DescriptionByEnrollmentID(this.enrollmentID);
				
			}
		}
		
		[FieldValuesMember("LookupOf_EnrollmentId", "EnrollmentID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@ENROLLMENT@")]
		public int EnrollmentID
		{
			get { return this.enrollmentID; }
			set { this.enrollmentID = value; }
		}
		
		[FieldValuesMember("ValuesOf_SessionIndicator")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@SESSIONINDICATOR@")]
		public int SessionIndicator
		{
			get { return this.sessionIndicator; }
			set { this.sessionIndicator = value; }
		}

		[FieldDescription("@SESSIONINDICATOR@")]
		public string SessionIndicatorGridDisplay
		{
			get
			{
				switch (this.sessionIndicator)
				{
					case (int)DataLayer.SessionIndicator.All:
						return "A";
					case (int)DataLayer.SessionIndicator.Initial:
						return "I";
					default:
						return " ";
				}
			}
		}

		[FieldValuesMember("LookupOf_EventTypeID", "EventTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int EventTypeID
		{
			get { return this.eventTypeID; }
			set { this.eventTypeID = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewDecisionTypeID", "ClinicalReviewDecisionTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@REVIEWDECISIONTYPEID@")]
		public int ClinicalReviewDecisionTypeID
		{
			get { return this.clinicalReviewDecisionTypeID; }
			set { this.clinicalReviewDecisionTypeID = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewDecisionReasonID", "ClinicalReviewDecisionReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@REVIEWDECISIONREASONID@")]
		public int ClinicalReviewDecisionReasonID
		{
			get { return this.clinicalReviewDecisionReasonID; }
			set { this.clinicalReviewDecisionReasonID = value; }
		}

		[FieldValuesMember("LookupOf_ReferralTypeID", "ReferralTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@REFERRALTYPEID@")]
		public int ReferralTypeID
		{
			get { return this.referralTypeID; }
			set { this.referralTypeID = value; }
		}

		[FieldValuesMember("LookupOf_ReferralUnitID", "ReferralUnitTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@REFERRALUNITID@")]
		public int ReferralUnitID
		{
			get { return this.referralUnitID; }
			set { this.referralUnitID = value; }
		}

		[FieldValuesMember("LookupOf_LetterTypeID", "LetterMatrixTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int LetterTypeID
		{
			get { return this.letterTypeID; }
			set { this.letterTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReviewNumber
		{
			get { return this.reviewNumber; }
			set { this.reviewNumber = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string ReferralDetailText
		{
			get { return this.referralDetailText; }
			set { this.referralDetailText = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USState, MaxLength=2)]
		[FieldDescription("@STATEFACILITY@")]
		public string FacilityState
		{
			get { return this.facilityState; }
			set { this.facilityState = value; }
		}

		#region DB Methods
		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int matrixID)
		{
			return base.Load(matrixID);
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{	
			if (this.terminationDate != this.terminateDateWhenLoaded)
				this.SetTerminatingUser();  // If Termination Time was provided 
// Duplicate check is done on db level
//			else if(!this.isMarkedForDeletion)
//			{  // DO NOT check for duplicate if Termination Time was changed
//				if(this.HasDuplicate())
//					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Same Letter Matrix already exist. ");
//			}
			base.InternalSave();
			// Save the child collections here.

			if(LetterMatrixExceptions != null)
			{
				LetterMatrixExceptions.SqlData.Transaction = this.SqlData.Transaction;
				SaveLetterMatrixExceptions();
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);
			this.terminateDateWhenLoaded = this.terminationDate;
		}
		#endregion

		/// <summary>
		/// Parent LetterMatrixCollection that contains this element
		/// </summary>
		public LetterMatrixCollection ParentLetterMatrixCollection
		{
			get
			{
				return this.parentLetterMatrixCollection;
			}
			set
			{
				this.parentLetterMatrixCollection = value; // parent is set when added to a collection
			}
		}

		#region Lookups
		public ClinicalReviewDecisionTypeCollection LookupOf_ClinicalReviewDecisionTypeID
		{
			get
			{
				if (this.PrototypeInstance)
					return ClinicalReviewDecisionTypeCollection.ActiveClinicalReviewDecisionTypes;
				else
				{
					ClinicalReviewDecisionTypeCollection col = new ClinicalReviewDecisionTypeCollection();
					ClinicalReviewDecisionType obj = new ClinicalReviewDecisionType();
					obj.ClinicalReviewDecisionTypeID = 0;
					obj.Description = "All";
					col.AddRecord(obj);
					col.CopyElementsFrom(ClinicalReviewDecisionTypeCollection.ActiveClinicalReviewDecisionTypes, true, false);
					return col;
				}
			}
		}

		public ClinicalReviewDecisionReasonCollection LookupOf_ClinicalReviewDecisionReasonID
		{
			get
			{
				if (this.PrototypeInstance)
					return ClinicalReviewDecisionReasonCollection.ActiveClinicalReviewDecisionReasons;
				else
				{
					ClinicalReviewDecisionReasonCollection col = new ClinicalReviewDecisionReasonCollection();
					ClinicalReviewDecisionReason obj = new ClinicalReviewDecisionReason();
					obj.ClinicalReviewDecisionReasonID = 0;
					obj.Description = "All";
					col.AddRecord(obj);
					col.CopyElementsFrom(ClinicalReviewDecisionReasonCollection.ActiveClinicalReviewDecisionReasons, true, false);
					return col;
				}
			}
		}

		public EventTypeCollection LookupOf_EventTypeID
		{
			get
			{
				if (this.PrototypeInstance)
					return EventTypeCollection.ActiveEventTypes;
				else
				{
					EventTypeCollection col = new EventTypeCollection();
					EventType obj = new EventType();
					obj.EventTypeID = 0;
					obj.Description = "All";
					col.AddRecord(obj);
					col.CopyElementsFrom(EventTypeCollection.ActiveEventTypes, true, false);
					return col;
				}
			}
		}

		public ReferralTypeCollection LookupOf_ReferralTypeID
		{
			get
			{
				if (this.PrototypeInstance)
					return ReferralTypeCollection.ActiveReferralTypes;
				else
				{
					ReferralTypeCollection col = new ReferralTypeCollection();
					ReferralType obj = new ReferralType();
					obj.ReferralTypeId = 0;
					obj.Description = "All";
					col.AddRecord(obj);
					col.CopyElementsFrom(ReferralTypeCollection.ActiveReferralTypes, true, false);
					return col;
				}
			}
		}

		public ReferralUnitTypeCollection LookupOf_ReferralUnitID
		{
			get
			{
				if (this.PrototypeInstance)
					return ReferralUnitTypeCollection.ActiveReferralUnitTypes;
				else
				{
					ReferralUnitTypeCollection col = new ReferralUnitTypeCollection();
					ReferralUnitType obj = new ReferralUnitType();
					obj.ReferralUnitTypeID = 0;
					obj.Description = "All";
					col.AddRecord(obj);
					col.CopyElementsFrom(ReferralUnitTypeCollection.ActiveReferralUnitTypes, true, false);
					return col;
				}
			}
		}

		public LetterMatrixTypeCollection LookupOf_LetterTypeID
		{
			get
			{
				return LetterMatrixTypeCollection.ActiveLetterMatrixTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public MatrixTypeCollection LookupOf_MatrixTypeID
		{
			get
			{
				return MatrixTypeCollection.ActiveMatrixTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public object[,] ValuesOf_SessionIndicator
		{
			get
			{
				return new object[,] { { (int)DataLayer.SessionIndicator.All, "All"}, 
									   { (int)DataLayer.SessionIndicator.Initial, "Initial"}};
			}
		}

		public LetterSetCollection LookupOf_LetterSetID
		{
			get
			{
				if (this.PrototypeInstance)
					return LetterSetCollection.ActiveLetterSets;
				else
				{
					LetterSetCollection col = new LetterSetCollection();
					col.LoadAllLetterSetsByLetterMatrixType(-1, this.matrixTypeID, true);
					return col;
				}
			}
		}

		public EnrollmentCollection LookupOf_EnrollmentId
		{
			get
			{
				if (this.PrototypeInstance)
					return EnrollmentCollection.AllEnrollmentsByValidDateRange;
				else
				{
					EnrollmentCollection col = new EnrollmentCollection();
					col.LoadAllEnrollmentsByValidDateRangeAndOrganization(this.organizationId);
				
					Enrollment e = new Enrollment();
					e.EnrollmentID = 0;
					e.Description = "All";
					col.InsertRecord(0, e);

					return col;
				}
			}
		}
		#endregion

		/// <summary>
		/// Verifies if LetterMatrix already exist.
		/// </summary>
		/// <returns>true if duplicate found</returns>
		private bool HasDuplicate()
		{
			/*�	Check for active, duplicate matrices. A duplicate matrix will have the same:
				o	Letter Set ID
				o	Matrix Type
				o	Session Indicator
				o	Morg ID (if any)
				o	Org ID (if any)
				o	Sorg ID (if any)
				o	Plan ID (if any)
				o	Referral Type (if any)
				o	Event Type (if any)
				o	Decision Type (if any)
				o	Decision Reason (if any)*/
			
			LetterMatrixCollection col = LetterMatrixCollection.GetFromSearch(this);
			return col.Count > 0;
		}

		#region LetterMatrixExceptions
		/// <summary>
		/// Child LetterMatrixExceptions mapped to related rows of table LetterMatrixException where [MatrixID] = [MatrixID]
		/// </summary>
		[SPLoadChild("usp_LoadLetterMatrixLetterMatrixException", "matrixID")]
		public LetterMatrixExceptionCollection LetterMatrixExceptions
		{
			get { return this.letterMatrixExceptions; }
			set
			{
				this.letterMatrixExceptions = value;
				if (value != null)
					value.ParentLetterMatrix = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the LetterMatrixExceptions collection
		/// </summary>
		public void LoadLetterMatrixExceptions(bool forceReload)
		{
			this.letterMatrixExceptions = (LetterMatrixExceptionCollection)LetterMatrixExceptionCollection.LoadChildCollection("LetterMatrixExceptions", this, typeof(LetterMatrixExceptionCollection), letterMatrixExceptions, forceReload, null);
		}

		/// <summary>
		/// Saves the LetterMatrixExceptions collection
		/// </summary>
		public void SaveLetterMatrixExceptions()
		{
			LetterMatrixExceptionCollection.SaveChildCollection(this.letterMatrixExceptions, true);
		}

		/// <summary>
		/// Synchronizes the LetterMatrixExceptions collection
		/// </summary>
		public void SynchronizeLetterMatrixExceptions()
		{
			LetterMatrixExceptionCollection.SynchronizeChildCollection(this.letterMatrixExceptions, true);
		}
		#endregion


		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			if(!this.IsNew)
				writer.AddFields(this, "MatrixID", "Description");
		}
	}

	/// <summary>
	/// Strongly typed collection of LetterMatrix objects
	/// </summary>
	[ElementType(typeof(LetterMatrix))]
	public class LetterMatrixCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_MatrixID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterMatrix elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterMatrixCollection = this;
			else
				elem.ParentLetterMatrixCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterMatrix elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterMatrix this[int index]
		{
			get
			{
				return (LetterMatrix)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterMatrix)oldValue, false);
			SetParentOnElem((LetterMatrix)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterMatrix elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterMatrix)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		///	BR01.34.1.3	System shall not delete a Letter Matrix. A Letter Matrix can be rendered inactive by setting its termination date.
		/// </summary>
		private int SearchLetterMatrix(int maxRecords, LetterMatrix searcher)
		{
			object activeWithTerminatedAndAll = (object)searcher.ActiveWithTerminatedAndAll;
			this.Clear();
			this.ElementType = typeof(SelectableLetterMatrix);
			return SqlData.SPExecReadCol("usp_SearchLetterMatrix", maxRecords, this, searcher, false, new string[] {"activeWithTerminatedAndAll"}, new object[] {activeWithTerminatedAndAll});
		}

		public static LetterMatrixCollection GetFromSearch(LetterMatrix searcher)
		{
			LetterMatrixCollection col = new LetterMatrixCollection();
			col.SearchLetterMatrix(-1, searcher);
			return col;
		}

		public void SetSelectedFromCollection(QuestionnaireLetterMatrixCollection col)
		{
			QuestionnaireLetterMatrix existing = null;
			foreach (LetterMatrix lm in this)
			{
				existing = col.FindByMatrixID(lm.MatrixID);
				if (existing != null && !existing.IsMarkedForDeletion)
					((SelectableLetterMatrix)lm).Selected = true;
				else
					((SelectableLetterMatrix)lm).Selected = false;
			}
		}

		/// <summary>
		/// Hashtable based index on matrixID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_MatrixID
		{
			get
			{
				if (this.indexBy_MatrixID == null)
					this.indexBy_MatrixID = new CollectionIndexer(this, new string[] { "matrixID" }, true);
				return this.indexBy_MatrixID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on matrixID fields returns the object.  Uses the IndexBy_MatrixID indexer.
		/// </summary>
		public LetterMatrix FindBy(int matrixID)
		{
			return (LetterMatrix)this.IndexBy_MatrixID.GetObject(matrixID);
		}
	}
}
