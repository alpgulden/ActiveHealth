using System;
using NetsoftUSA.DataLayer;
using System.Collections;
using System.Data.SqlClient;
using System.Collections;
using System.Diagnostics;
using Microsoft.ApplicationBlocks.Data;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for LetterGenerator.
	/// </summary>
	[TableMapping(null)]
	public class LetterGenerator : BaseData
	{
		public bool GenerateEventLetters(int session, Patient patient, Event eventObj, ClinicalReviewRequest request, ClinicalReviewDecision decision, bool checkLetterDecision)
		{
			// Get the MOSP info from CMS record
			PatientSubscriberLog pLog = eventObj.PatientSubscriberLog;
			int sorgID = pLog.SORGId;
			int orgID = pLog.SORG.ParentOrganizationID;
			int morgID = pLog.SORG.ParentOrganization.ParentOrganizationID;
			int planID = pLog.PlanId;

			LetterTemplateCollection letterTemplates = new LetterTemplateCollection();

            int requestID = (request == null) ? 0 : request.ClinicalReviewRequestID;
			int decisionID = (decision == null) ? 0 : decision.ClinicalReviewDecisionID;

			if (sorgID == 0 || orgID == 0 || morgID == 0)
				throw new ActiveAdviceException("Organization information is required for letter processing.");

			if (planID == 0)
				throw new ActiveAdviceException("Plan information is required for letter processing.");

			if (requestID == 0 || decisionID == 0)
				throw new ActiveAdviceException("Request and decision information is required for letter processing.");

			// Run the stored proc to load letter templates for the event letters to be generated
			SqlData.SPExecReadCol("usp_GenerateDecisionLetters", -1, letterTemplates, false, new object[] { requestID, session, decisionID, checkLetterDecision });
 			
			TxHelper txHelper = new TxHelper();
			txHelper.Initialize();
			txHelper.SetPageLayout(TxHelper.PageSize.USLetter);

			LetterNonPrintedQueueCollection queueCol = new LetterNonPrintedQueueCollection();
			LetterNonPrintedQueue queue;

			MergeContext mergeContext = null;

			// Go thru the templates and create a draft record for each of them
			foreach (LetterTemplate template in letterTemplates)
			{

				// Load it into txHelper
				txHelper.LoadText(template.LetterTemplateBody.Body, TxHelper.TextFormat.RTF);

				// Create a merge context
				mergeContext = new MergeContext(template.MatrixTypeID);

				if (AASecurityHelper.GetUserId != 0)
					mergeContext.AddFilterValue(MergeFilter.USERID, AASecurityHelper.GetUserId);
				if (eventObj != null)
				{
					mergeContext.AddFilterValue(MergeFilter.EVENTID, eventObj.EventID);
					if (eventObj.PrimaryProblemID != 0)
						mergeContext.AddFilterValue("PROBLEMID", eventObj.PrimaryProblemID);
				}
				if (request != null)
					mergeContext.AddFilterValue(MergeFilter.REQUESTID, request.ClinicalReviewRequestID);
				if (decision != null)
					mergeContext.AddFilterValue(MergeFilter.DECISIONID, decision.ClinicalReviewDecisionID);
				if (patient != null)
					mergeContext.AddFilterValue(MergeFilter.PATIENTID, patient.PatientId);

				mergeContext.Patient = patient;
				mergeContext.ERC = eventObj;

				txHelper.StartMerge(mergeContext);

				if (txHelper.ErrorMessages.Count > 0)
					throw new ActiveAdviceException("An error occured during letter processing. At least one of the letters was not processed.");
			
				// Create new draft record and add it to the collection
				queue = new LetterNonPrintedQueue(true);
				queueCol.AddRecord(queue);

				// Set the properties on the draft record
				// This the generation date NOT the date of the event
				// queue.EventDate = eventObj.CreateTime;
				queue.EventID = eventObj.EventID;
				queue.RequestID = requestID;
				queue.ClinicalReviewDecisionID = decisionID;
				queue.ProblemID = eventObj.PrimaryProblemID;
				queue.LoadLetterCustomText(true);
				queue.LetterCustomText.CustomText = txHelper.GetText(TxHelper.TextFormat.RTF);
				queue.LetterTemplateID = template.LetterTemplateID;
				queue.Version = template.Version;
				queue.MatrixTypeID = template.MatrixTypeID;
				queue.OrganizationId = sorgID;
				queue.PatientID = patient.PatientId;
				queue.PlanID = planID;
				queue.ReceiverTypeID = template.ReceiverTypeID;
				queue.UserID = AASecurityHelper.GetUserId;
			}

			if (queueCol.Count > 0)
			{
				queueCol.Save();
				return true;
			}


			return false;

		}

		public bool GenerateReferralLetters(Patient patient, Referral referral, ReferralDetail referralDetail, int session)
		{
			ClinicalReviewDecision decision = null;

			// Get the MOSP info from CMS record
			PatientSubscriberLog pLog = referral.PatientSubscriberLog;
			int sorgID = pLog.SORGId;
			int orgID = pLog.SORG.ParentOrganizationID;
			int morgID = pLog.SORG.ParentOrganization.ParentOrganizationID;
			int planID = pLog.PlanId;

			int referralID = (referral == null) ? 0 : referral.ReferralID;
			int referralDetailID = (referralDetail == null) ? 0 : referralDetail.ReferralDetailID;

			if (sorgID == 0 || orgID == 0 || morgID == 0)
				throw new ActiveAdviceException("Organization information is required for letter processing.");

			if (planID == 0)
				throw new ActiveAdviceException("Plan information is required for letter processing.");

			if (referralID == 0 || referralDetailID == 0)
				throw new ActiveAdviceException("Referral and referral detail information is required for letter processing.");


			LetterTemplateCollection letterTemplates = new LetterTemplateCollection();
            
			// Run the stored proc to load letter templates for the referral letters to be generated
			SqlData.SPExecReadCol("usp_GenerateReferralLetters", -1, letterTemplates, false, new object[] {referralDetail.ReferralDetailID, session});

			TxHelper txHelper = new TxHelper();
			txHelper.Initialize();
			txHelper.SetPageLayout(TxHelper.PageSize.USLetter);

			LetterNonPrintedQueueCollection queueCol = new LetterNonPrintedQueueCollection();
			LetterNonPrintedQueue queue;
			MergeContext mergeContext = null;

			// Go thru the templates and create a draft record for each of them
			foreach (LetterTemplate template in letterTemplates)
			{
				// Load it into txHelper
				txHelper.LoadText(template.LetterTemplateBody.Body, TxHelper.TextFormat.RTF);

				// Create a merge context
				mergeContext = new MergeContext(template.MatrixTypeID);

				if (AASecurityHelper.GetUserId != 0)
					mergeContext.AddFilterValue(MergeFilter.USERID, AASecurityHelper.GetUserId);
				if (referral != null)
					mergeContext.AddFilterValue(MergeFilter.REFERRALID, referral.ReferralID);
				if (referralDetail != null)
					mergeContext.AddFilterValue(MergeFilter.REFERRALDETAILID, referralDetail.ReferralDetailID);
				if (patient != null)
					mergeContext.AddFilterValue(MergeFilter.PATIENTID, patient.PatientId);

				mergeContext.Patient = patient;
				mergeContext.ERC = referral;

				txHelper.StartMerge(mergeContext);

				if (txHelper.ErrorMessages.Count > 0)
					throw new ActiveAdviceException("An error occured during letter processing. At least one of the letters was not processed.");

			
				// Create new draft record and add it to the collection
				queue = new LetterNonPrintedQueue(true);
				queueCol.AddRecord(queue);

				// Set the properties on the draft record
				queue.ReferralDetailID = referralDetail.ReferralDetailID;
				queue.ReferralID = referral.ReferralID;
				queue.ProblemID = referral.PrimaryProblemID;

				queue.LoadLetterCustomText(true);
				queue.LetterCustomText.CustomText = txHelper.GetText(TxHelper.TextFormat.RTF);
				queue.LetterTemplateID = template.LetterTemplateID;
				queue.Version = template.Version;
				queue.MatrixTypeID = template.MatrixTypeID;
				queue.OrganizationId = sorgID;
				queue.PatientID = patient.PatientId;
				queue.PlanID = planID;
				queue.ReceiverTypeID = template.ReceiverTypeID;
				queue.UserID = AASecurityHelper.GetUserId;
			}

			if (queueCol.Count > 0)
			{
				queueCol.Save();
				return true;
			}


			return false;
		}


		public bool GenerateAssessmentLetters(AssessmentContext assessmentContext)
		{

			Assessment assessment = assessmentContext.Assessment;
			CMS cMS = assessmentContext.CMS;

			// Get the MOSP info from CMS record
			PatientSubscriberLog pLog = cMS.PatientSubscriberLog;
			int sorgID = pLog.SORGId;
			int orgID = pLog.SORG.ParentOrganizationID;
			int morgID = pLog.SORG.ParentOrganization.ParentOrganizationID;
			int planID = pLog.PlanId;

			if (sorgID == 0 || orgID == 0 || morgID == 0)
				throw new ActiveAdviceException("Organization information is required for letter processing.");

			if (planID == 0)
				throw new ActiveAdviceException("Plan information is required for letter processing.");

			if (assessmentContext == null)
				throw new ActiveAdviceException("Assessment information is required for letter processing.");

			// Find the matching matrix type
			int matrixTypeID = MatrixTypeCollection.ActiveMatrixTypes.Lookup_MatrixTypeIDByCMSTypeID(cMS.CMSTypeID);

			LetterTemplateCollection letterTemplates = new LetterTemplateCollection();
            
			// Run the stored proc to load letter templates for the assessment letters to be generated
			SqlData.SPExecReadCol("usp_GetAssessmentLettersToGenerate", -1, letterTemplates, false, new object[] {assessment.AssessmentGUID, matrixTypeID, morgID, orgID, sorgID, planID});
 			
			TxHelper txHelper = new TxHelper();
			txHelper.Initialize();
			txHelper.SetPageLayout(TxHelper.PageSize.USLetter);

			LetterDraftQueueCollection draftCol = new LetterDraftQueueCollection();
			LetterDraftQueue draft;
			MergeContext mergeContext = null;

			// Go thru the templates and create a draft record for each of them
			foreach (LetterTemplate template in letterTemplates)
			{

				// Load it into txHelper
				txHelper.LoadText(template.LetterTemplateBody.Body, TxHelper.TextFormat.RTF);

				// Create a merge context
				mergeContext = new MergeContext(template.MatrixTypeID);

				if (AASecurityHelper.GetUserId != 0)
					mergeContext.AddFilterValue(MergeFilter.USERID, AASecurityHelper.GetUserId);
				if (cMS.CMSID != 0)
					mergeContext.MergeFilterValues.Add(MergeFilter.CMSID, cMS.CMSID);
				if (assessment.AssessmentGUID != null)
					mergeContext.AddFilterValue(MergeFilter.ASSESSMENTGUID, assessment.AssessmentGUID);
				if (planID != 0)
					mergeContext.AddFilterValue(MergeFilter.PLANID, planID);
				if (assessmentContext.CMS.Patient != null)
					mergeContext.AddFilterValue(MergeFilter.PATIENTID, assessmentContext.CMS.Patient.PatientId);
					
				mergeContext.AddFilterValue(MergeFilter.PROBLEMID, assessmentContext.CMS.PrimaryProblemID);

				mergeContext.AssessmentContext = assessmentContext;
				mergeContext.Patient = assessmentContext.CMS.Patient;
				mergeContext.ERC = assessmentContext.CMS;

				txHelper.StartMerge(mergeContext);

				if (txHelper.ErrorMessages.Count > 0)
					throw new ActiveAdviceException("An error occured during letter processing. At least one of the letters was not processed.");

			
				// Create new draft record and add it to the collection
				draft = new LetterDraftQueue(true);
				draftCol.AddRecord(draft);

				// Set the properties on the draft record
				draft.AssessmentDate = assessment.CreateTime;
				draft.AssessmentGUID = assessment.AssessmentGUID;
				draft.CMSID = cMS.CMSID;

				draft.LoadLetterCustomText(true);
				draft.LetterCustomText.CustomText = txHelper.GetText(TxHelper.TextFormat.RTF);
				draft.LetterTemplateID = template.LetterTemplateID;
				draft.Version = template.Version;
				draft.MatrixTypeID = matrixTypeID;
				draft.OrganizationId = sorgID;
				draft.PatientID = cMS.PatientId;
				draft.PlanID = planID;
				draft.ReceiverTypeID = template.ReceiverTypeID;
				draft.UserID = AASecurityHelper.GetUserId;
			}

			if (draftCol.Count > 0)
			{
				draftCol.Save();
				return true;
			}


			return false;
		}

		

		public int GetNextBatchNumberToProcess()
		{
			object val = SqlData.SPExecScalar("usp_GetNextBatchNumberToProcess", this, false);
			if (val == DBNull.Value)
				return -1;
			else
				return (int)val;
		}

		public LetterPrintedQueueCollection GetNextSetFromQueueToProcess(int batchNumber, int letterType)
		{
			LetterPrintedQueueCollection col = new LetterPrintedQueueCollection();
			SqlData.SPExecReadCol("usp_GetNextSetFromQueueToProcess", -1, col, this, false, new string[] {"batchNumber", "letterType"}, new object[] {batchNumber, letterType});
			return col;
		}

	
		private static PrinterCollection printerCollection = null;

		private PrinterCollection PrinterCollectionAll
		{
			get
			{
				if (printerCollection == null)
				{
					printerCollection = new PrinterCollection();
					printerCollection.LoadAll();
				}
				return printerCollection;
			}
		}

		public void ProcessQueue()
		{
			// Get the number of next batch to be printed
			int batchNumber = 0;

			// Cache the templates, so that there is no need to get them from the DB everytime
			Hashtable letterTemplates = new Hashtable(50);

			// Create and initialize a Text Control object
			TxHelper txHelper = null;

			try
			{
				txHelper = new TxHelper();
				txHelper.Initialize();
				txHelper.SetPageLayout(TxHelper.PageSize.A4);

				LetterPrintedQueueCollection col = null; 
				LetterPrintedQueue qItem = null;
				LetterTemplate template = null;
				MergeContext mergeContext = null;
				bool isICMLetter = false;
				bool useLetterTemplate = false;
				int iCMMatrixTypeID = LetterMatrixTypeCollection.ActiveLetterMatrixTypes.Lookup_LetterMatrixTypeIDByCode("ICM");

				// Find the default printer
				Printer defaultPrinter = null;
				for (int i=0; i < PrinterCollectionAll.Count; i++)
				{
					if (this.PrinterCollectionAll[i].IsDefault == true)
					{
						defaultPrinter = (PrinterCollectionAll[i]); break;
					}
				}
				if (defaultPrinter == null)
					if (PrinterCollectionAll.Count > 0)	// cannot find match
						defaultPrinter = (PrinterCollectionAll[0]);	// just use the first one
					else
					{
						if (!EventLog.SourceExists("LetterQueue") )
							EventLog.CreateEventSource("LetterQueue", "ActiveAdvice");
						EventLog.WriteEntry("LetterQueue", "There is no default printer set.", EventLogEntryType.Error);
						return;
					}


				// Get the next batch number in the queue
				batchNumber = GetNextBatchNumberToProcess();

				// If there is a batch to be printed
				while (batchNumber >= 0)
				{
					/*	Regular - 0
						Duplex - 1 
						Envelope - 2
					*/
					// It's better to print same format letters together
					for (int letterType = 0; letterType < 3; letterType++) // Regular, Duplex, Envelope
					{
						// Get the letters of type letterType for this batch
						col = GetNextSetFromQueueToProcess(batchNumber, letterType);
			
						// For each letter
						for (int index = 0; index < col.Count; index++)
						{
							try
							{
								// Check to see if thread is being canceled and exit if so...
								if (this.Cancel) // are we being canceled?
								{
									this.IsCanceled = true;
									return;
								}

								qItem = col[index];

								qItem.LoadLetterCustomText(false);


								// We need to decide if this is an ICM letter 
								// NOTE: There might be additional checks later on
								isICMLetter = (qItem.LetterMatrixTypeID > 0 && qItem.LetterMatrixTypeID == iCMMatrixTypeID);

								// Decide whether to use the letter templatebody or customtext on the queue item
								useLetterTemplate = (qItem.LetterCustomText == null || qItem.LetterCustomText.IsNew || qItem.LetterCustomText.CustomText.Length == 0);

								// Decide whether to load the letter template
								if (true /* We need this for duplex flag anyway: isICMLetter || useLetterTemplate*/)
								{
									// Get the template
									string key = qItem.LetterTemplateID.ToString() + "|" + qItem.Version.ToString();

									// First look for the template in the cache
									if (letterTemplates.Contains(key))
										template = (LetterTemplate)letterTemplates[key]; // Get the template from cache
									else // If it's not there load it from the db
									{
										template = qItem.LetterTemplate;	// Reload it from DB
										// Store it in the cache for later use
										letterTemplates.Add(key, template);
									}
								}

								// Look for the intro letter number on the letter template
								// This is an additional check
								// NOTE: We didn't have to load the whole template, could have just run a stored proc to check the intro letter number
								isICMLetter = (isICMLetter && (template.IntroLetterNumber > 0));

								if (useLetterTemplate)
								{
									// Load the template text into txHelper
									txHelper.LoadText(template.LetterTemplateBody.Body, TxHelper.TextFormat.RTF);
									// Create a merge context
									mergeContext = new MergeContext(template.MatrixTypeID);
								}
								else
								{
									txHelper.LoadText(qItem.LetterCustomText.CustomText, TxHelper.TextFormat.RTF);
									// Create a merge context
									mergeContext = new MergeContext(qItem.MatrixTypeID);
								}

								mergeContext.UseICMTriggers = isICMLetter;

								// Set the letter queue and get the context from it
								mergeContext.LetterQueue = qItem;
								mergeContext.GetMergeFilterValuesFromQueue();
						
								// Start the merge process
								txHelper.StartMerge(mergeContext);

								if (txHelper.ErrorMessages.Count > 0)
									throw new ActiveAdviceException("An error occured during merge.");

								qItem.LetterCustomText.CustomText = txHelper.GetText(TxHelper.TextFormat.RTF);

								if (qItem.Delivery) // Mail-Print
								{
									Printer foundPrinter = null;
									if (qItem.PrinterID != 0)
									{
										string printerShareName;
										int itemPrinterToID = qItem.PrinterID;
 
										// Try to find preferred printer
										foundPrinter = PrinterCollectionAll.FindBy(itemPrinterToID);
										// If not use the default printer
									}
									if (foundPrinter == null) foundPrinter = defaultPrinter;
										
									bool isEnvelope = (template.FormTypeID == LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_FormTypeIDByCode(LetterFormType.ENVELOPE));

									txHelper.Print(foundPrinter, "Letter Batch Process, BatchNumber: " + batchNumber, template.Duplex, isEnvelope);
								}
								else
								{
									FaxInfo faxInfo = new FaxInfo();
									try
									{
										if (faxInfo.FillFromReceiver(qItem.ReceiverTypeID,qItem.PatientID, qItem.ReferralID, qItem.EventID, qItem.CMSID)
											&& faxInfo.ToFName != null && faxInfo.ToLName != null && faxInfo.ToFaxNo != null)
										{

											if (BaseFaxQueue.SendQueueItemToFax(qItem.QueueID, faxInfo, AASecurityHelper.UserName))
												qItem.Status = LetterPrintedQueueStatus.Faxed;
											else
												qItem.Status = LetterPrintedQueueStatus.ErrorFaxing;
										}
										else
										{
											qItem.Status = LetterPrintedQueueStatus.ErrorFaxing;
										}
									}
									catch(Exception ex)
									{	
										qItem.Status = LetterPrintedQueueStatus.ErrorFaxing;
									}
									finally
									{	
										faxInfo = null;
									}
								}

								if (qItem.Status != LetterPrintedQueueStatus.Error && qItem.Status != LetterPrintedQueueStatus.ErrorFaxing) // If no errors up to this point
								{
									if (mergeContext.UseICMTriggers && mergeContext.ParagraphsIncluded.Count > 0 && qItem.CMSID > 0)
									{
										SqlConnection conn = null;
										try
										{
											if (mergeContext.ParagraphsIncluded.Count > 0)
											{
												// Create a single connection and use that for all queries for performance reasons 
												conn = new SqlConnection(NSGlobal.ConnectionString);
												conn.Open();
											}

											for (int ix = 0; ix < mergeContext.ParagraphsIncluded.Count; ix++)
											{
												SqlHelper.ExecuteNonQuery(0, conn, "usp_UpdateScoringLoadParagraphStatus", qItem.CMSID, (int)mergeContext.ParagraphsIncluded[ix], false);
											}
										}
										catch(Exception ex)
										{
											if (!EventLog.SourceExists("LetterQueue") )
												EventLog.CreateEventSource("LetterQueue", "ActiveAdvice");
											string msg = ex.Message;
											if (ex.InnerException != null)
												msg += " [" + ex.InnerException.Message + "]";
											else
												msg += " [no inner exception!]";
											EventLog.WriteEntry("LetterQueue", msg, EventLogEntryType.Error);

										}
										finally
										{
											if (conn != null && conn.State != System.Data.ConnectionState.Closed)
												conn.Close();
										}
									}
								}

								// Change the status to printed if we are pending, otherwise keep
								// our error
								if (qItem.Status == LetterPrintedQueueStatus.Pending)
									qItem.Status = LetterPrintedQueueStatus.Printed;

								qItem.BatchRunDate = DateTime.Now;
								qItem.Save();
							}
							catch(Exception ex)
							{
								if (!EventLog.SourceExists("LetterQueue") )
									EventLog.CreateEventSource("LetterQueue", "ActiveAdvice");
								string msg = ex.Message;
								if (ex.InnerException != null)
									msg += " [" + ex.InnerException.Message + "]";
								else
									msg += " [no inner exception!]";
								EventLog.WriteEntry("LetterQueue", msg, EventLogEntryType.Error);

								// Change the status to error
								if (qItem != null)
								{
									qItem.Status = LetterPrintedQueueStatus.Error;
									qItem.BatchRunDate = DateTime.Now;
									qItem.Save();
								}
							}
							finally
							{

							}
						}

					}

					// Get the next batch number and continue
					int previous_batchNumber = batchNumber;
					batchNumber = GetNextBatchNumberToProcess();
					if ( (previous_batchNumber == batchNumber) && (batchNumber != 0) )
					{
						// We have a problem, the items in this
						// batch are causing a loop that will "hang"
						// the service. We need to mark all the 
						// items in this batch as 'failed'
						SqlData.SPExecNonQuery("usp_InvalidBatchNumber", new object[] { previous_batchNumber });
						batchNumber = GetNextBatchNumberToProcess();
					}
				}


			}
			catch(Exception ex)
			{
				if (!EventLog.SourceExists("LetterQueue") )
					EventLog.CreateEventSource("LetterQueue", "ActiveAdvice");
				string msg = ex.Message;
				if (ex.InnerException != null)
					msg += " [" + ex.InnerException.Message + "]";
				else
					msg += " [no inner exception!]";
				EventLog.WriteEntry("LetterQueue", msg, EventLogEntryType.Error);
				return;
			}
			finally
			{
				if (txHelper != null)
					txHelper.Dispose();
			}
		}



		#region Cancel Logic
		protected bool canceled = false;
		/// <summary>
		/// Cancel
		/// Set this property to inform the object that it is being 
		/// canceled from another thread. Note that the variable is
		/// lock'd to avoid thread problems...
		/// </summary>
		public bool Cancel
		{
			set
			{
				lock(this)
				{
					canceled = value;
				}
			}
			get
			{
				bool c;
				lock(this)
				{
					c = canceled;
				}
				return c;
			}
		}

		protected bool iscanceled = false;
		/// <summary>
		/// IsCanceled
		/// Returns 'true' to acknowledge that the Cancel
		/// has been received and the object is cleaning up
		/// and canceling.
		/// </summary>
		public bool IsCanceled
		{
			get
			{
				bool c;
				lock(this)
				{
					c = iscanceled;
				}

				return c; 
			}
			set
			{
				lock(this)
				{
					iscanceled = value;
				}
			}
		}
		#endregion

	}
}
