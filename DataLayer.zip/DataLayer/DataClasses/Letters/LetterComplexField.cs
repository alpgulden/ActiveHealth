using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	[SPInsert("usp_InsertLetterComplexField")]
	[SPUpdate("usp_UpdateLetterComplexField")]
	[SPLoad("usp_LoadLetterComplexField")]
	[TableMapping("LetterComplexField","letterComplexFieldID")]
	public class LetterComplexField : BaseData
	{
		[NonSerialized]
		private LetterComplexFieldCollection parentLetterComplexFieldCollection;
		[ColumnMapping("LetterComplexFieldID",StereoType=DataStereoType.FK)]
		private int letterComplexFieldID;
		[ColumnMapping("LetterComplexID",StereoType=DataStereoType.FK)]
		private int letterComplexID;
		[ColumnMapping("Shortcut")]
		private string shortcut;
		[ColumnMapping("HeaderText")]
		private string headerText;
		[ColumnMapping("SortOrder",StereoType=DataStereoType.FK)]
		private int sortOrder;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public LetterComplexField()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LetterComplexFieldID
		{
			get { return this.letterComplexFieldID; }
			set { this.letterComplexFieldID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LetterComplexID
		{
			get { return this.letterComplexID; }
			set { this.letterComplexID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		public string Shortcut
		{
			get { return this.shortcut; }
			set { this.shortcut = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string HeaderText
		{
			get { return this.headerText; }
			set { this.headerText = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		/// <summary>
		/// Parent LetterComplexFieldCollection that contains this element
		/// </summary>
		public LetterComplexFieldCollection ParentLetterComplexFieldCollection
		{
			get
			{
				return this.parentLetterComplexFieldCollection;
			}
			set
			{
				this.parentLetterComplexFieldCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of LetterComplexField objects
	/// </summary>
	[ElementType(typeof(LetterComplexField))]
	public class LetterComplexFieldCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterComplexField elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterComplexFieldCollection = this;
			else
				elem.ParentLetterComplexFieldCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterComplexField elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterComplexField this[int index]
		{
			get
			{
				return (LetterComplexField)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterComplexField)oldValue, false);
			SetParentOnElem((LetterComplexField)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent LetterComplex that contains this collection
		/// </summary>
		public LetterComplex ParentLetterComplex
		{
			get { return this.ParentDataObject as LetterComplex; }
			set { this.ParentDataObject = value; /* parent is set when contained by a LetterComplex */ }
		}
	}
}
