using System;

using NetsoftUSA.DataLayer;
using System.Data.SqlClient;
using System.Collections;

namespace ActiveAdvice.DataLayer
{
	public enum LetterPrintedQueueStatus
	{
		Error      = -1,
		Pending	   = 1,
		Printed    = 2,
		Faxed	   = 3,
		ErrorFaxing = 4
	}

	public enum LetterPrintedQueueDateType
	{
		Generation	= 1,
		Printed		= 2
	}
	
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterPrintedQueue]
	/// </summary>

	[SPDelete("usp_DeleteLetterPrintedQueue")]
	[SPAutoGen("usp_GetAllLettersPrintedQueue","SelectAll.sptpl","")]
	[SPInsert("usp_InsertLetterPrintedQueue")]
	[SPLoad("usp_LoadLetterPrintedQueue")]
	[SPUpdate("usp_UpdateLetterPrintedQueue")]
	[TableMapping("LetterPrintedQueue","queueID",true)]
	public class LetterPrintedQueue : BaseLetterQueue
	{
		[ColumnMapping("BatchNumber", (int)-1)]
		protected int batchNumber = -1;
		[ColumnMapping("BatchRunDate", ValuesForNull.NullDateTime)]
		protected DateTime batchRunDate;
		[ColumnMapping("Delivery", true)]
		protected bool delivery = true; //TRUE - printed; FALSE - faxed.
		[ColumnMapping("Status",StereoType=DataStereoType.FK)]
		protected int status;  
		
		[ColumnMapping("PrinterID",StereoType=DataStereoType.FK)]
		protected int printerID;
		[ColumnMapping("LetterMatrixTypeID",StereoType=DataStereoType.FK)]
		protected int letterMatrixTypeID;

		protected int dateTypeFilter;

		private LetterPrintedQueueCollection parentLetterPrintedQueueCollection;
		
		#region overriden methods from BaseLetterQueue
		public override int LQID
		{
			get { return this.queueID; }
		}

		public override LetterQueueType LQType
		{
			get { return LetterQueueType.Printed; }
		}

		public override string StatusGridDisplay
		{
			get
			{
				return this.Status.ToString();
			}
		}
		
		public override bool LoadLetterQueue(int queueID)
		{
			//return base.LoadLetterQueue (queueID);
			return this.Load(queueID);
		}
		#endregion

		public LetterPrintedQueue()
		{
		}

		public LetterPrintedQueue(BaseLetterQueue blq, int batchNumber)
		{
			this.CopyMembersFrom(blq, true, true, false);
			this.NewRecord();

			this.batchNumber = batchNumber;

			// Preserve the same QueueID
			this.queueID = blq.QueueID;

			#if DEBUG
			this.eventDate = (this.eventDate == DateTime.MinValue ? DateTime.Now : this.eventDate);
			this.userID = (this.userID < 1 ? 1 : this.userID);
			#endif
		}

		public LetterPrintedQueue(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}


		[FieldDescription("@BATCHNUMBER@")]
		[FieldValuesMember("ValuesOf_BatchNumber")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)-1)]
		public int BatchNumber
		{
			get { return this.batchNumber; }
			set { this.batchNumber = value; }
		}

		[FieldDescription("@BATCHNUMBER@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int BatchNumberDisplay
		{
			get { return this.batchNumber; }
		}

		[FieldDescription("@PRINTDATE@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime BatchRunDate
		{
			get { return this.batchRunDate; }
			set { this.batchRunDate = value; }
		}

		[FieldValuesMember("ValuesOf_DeliveryMethod")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool Delivery
		{
			get { return this.delivery; }
			set { this.delivery = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)0)]
		public LetterPrintedQueueStatus Status
		{
			get { return (LetterPrintedQueueStatus)this.status; }
			set { this.status = (int)value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EventDate
		{
			get { return this.eventDate; }
			set { this.eventDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AssessmentDate
		{
			get { return this.assessmentDate; }
			set { this.assessmentDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public LetterPrintedQueueDateType DateTypeFilter
		{
			get { return (LetterPrintedQueueDateType)this.dateTypeFilter; }
			set { this.dateTypeFilter = (int)value; }
		}

		[FieldValuesMember("LookupOf_PrinterList", "PrinterID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=false)]
		public int PrinterID
		{
			get { return this.printerID; }
			set { this.printerID = value; }
		}

		/// <summary>
		/// Parent LetterPrintedQueueCollection that contains this element
		/// </summary>
		public LetterPrintedQueueCollection ParentLetterPrintedQueueCollection
		{
			get
			{
				return this.parentLetterPrintedQueueCollection;
			}
			set
			{
				this.parentLetterPrintedQueueCollection = value; // parent is set when added to a collection
			}
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}


		protected override void InternalSave()
		{
			// If we're saving a record to the printed queue and there's no batchnumber assigned to it
			// That means this is an individual letter, but we still don't want batchnumber to be null.
			if (this.IsNew && this.batchNumber == -1)
				this.batchNumber = 0;

			base.InternalSave ();
		}


		public int[] ValuesOf_BatchNumber
		{
			get 
			{
				ArrayList lst = new ArrayList();
				int[] values;
				SqlData.SPExecReadArrayList("usp_GetBatchNumbers", -1, lst, new string[]  {"BatchNumber"}); 
				if (lst.Count > 0)
				{
					values = new int[lst.Count];
					lst.CopyTo(values);
					return values;
				}
				
				return null;
				
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LetterMatrixTypeID
		{
			get { return this.letterMatrixTypeID; }
			set { this.letterMatrixTypeID = value; }
		}



		public int GetLetterCount(object isDuplex, object isEnvelope)
		{
			object dateFrom = (this.DateFrom == DateTime.MinValue? (object)null: (object)this.DateFrom);
			object dateTo = (this.DateTo == DateTime.MinValue? (object)null: (object)this.DateTo);
			int dateTimeFilter = (int)this.DateTypeFilter;
			if(dateFrom == null & dateTo == null)
				dateTimeFilter = 0;

			object ret = SqlData.SPExecScalar("usp_ManageLetterPrintedQueue", this, false, 
				new string[] {"action", "dateFrom", "dateTo", "dateTypeFilter", "isDuplex", "isEnvelope"},
				new object[] {2 /*Count*/, dateFrom, dateTo, dateTimeFilter, isDuplex, isEnvelope});
				return SQLDataDirect.GetFromDBValue(ret, 0);
		}


		public int CreateBatch(object isDuplex, object isEnvelope, int batchNumber, int printerID)
		{
			object dateFrom = (this.DateFrom == DateTime.MinValue? (object)null: (object)this.DateFrom);
			object dateTo = (this.DateTo == DateTime.MinValue? (object)null: (object)this.DateTo);
			object objprinterID = (printerID == 0? (object)null : (object)printerID);
			int dateTimeFilter = (int)this.DateTypeFilter;
			if(dateFrom == null & dateTo == null)
				dateTimeFilter = 0;

			object ret = SqlData.SPExecScalar("usp_ManageLetterPrintedQueue", this, false, 
				new string[] {"action", "dateFrom", "dateTo", "dateTypeFilter", "isDuplex", "isEnvelope", "IbatchNumber", "Istatus", "IprinterID", "IcreatedBy"},
				new object[] {3 /*Batch*/, dateFrom, dateTo, dateTimeFilter, isDuplex, isEnvelope, batchNumber, (int)LetterPrintedQueueStatus.Pending, objprinterID, AASecurityHelper.GetUserId});
			return SQLDataDirect.GetFromDBValue(ret, 0);
		}

		public int ReRunBatch(int batchNumber, int printerID)
		{
			object dateFrom = (this.DateFrom == DateTime.MinValue? (object)null: (object)this.DateFrom);
			object dateTo = (this.DateTo == DateTime.MinValue? (object)null: (object)this.DateTo);
			object objprinterID = (printerID == 0? (object)null : (object)printerID);
			int dateTimeFilter = (int)this.DateTypeFilter;
			if(dateFrom == null & dateTo == null)
				dateTimeFilter = 0;

			object ret = SqlData.SPExecScalar("usp_ManageLetterPrintedQueue", this, false, 
				new string[] {"action", "dateFrom", "dateTo", "dateTypeFilter", "IbatchNumber", "Istatus", "IprinterID", "IcreatedBy"},
				new object[] {4 /*Batch*/, dateFrom, dateTo, dateTimeFilter, batchNumber, (int)LetterPrintedQueueStatus.Pending, objprinterID, AASecurityHelper.GetUserId});
			return SQLDataDirect.GetFromDBValue(ret, 0);
		}

			
	}

	/// <summary>
	/// Strongly typed collection of LetterPrintedQueue objects
	/// </summary>
	[ElementType(typeof(LetterPrintedQueue))]
	public class LetterPrintedQueueCollection : BaseLetterQueueCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_QueueID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterPrintedQueue elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterPrintedQueueCollection = this;
			else
				elem.ParentLetterPrintedQueueCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterPrintedQueue elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterPrintedQueue this[int index]
		{
			get
			{
				return (LetterPrintedQueue)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterPrintedQueue)oldValue, false);
			SetParentOnElem((LetterPrintedQueue)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterPrintedQueue elem)
		{
			return AddRecord(elem);
		}
		
		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public override void Save()
		{
			this.SaveElements();		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterPrintedQueue)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public override int LoadAllLetters(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLettersPrintedQueue", maxRecords, this, false);
		}

		
		public int ReRunBatch(int batchNumber)
		{
			return (int)SqlData.SPExecScalar("usp_ReRunBatch", batchNumber);
		}

		

		/// <summary>
		/// Creates sorted collection of letters for priting.
		/// Letters are sorted by type (LetterTemplate): 1) Simplex letters 2) Duplex Letters 3) Envelopes
		/// End collection will be saved to [LetterPrintedQueue] with "NotPrinted" status set.
		/// Batch number will be assigned.
		/// </summary>
		/// <param name="toBePrinted">Input Collection: LetterNonPrintedQueue</param>
		/// <param name="batchRunDate">Date when batch was started</param>
		/// <param name="delivery">True - Printing. False - Faxing.</param>
		/// <returns></returns>
		public override void CreateFromCollectionAndSave(BaseLetterQueueCollection toBePrinted, bool overrideDelivery, bool delivery, Printer printerTo, bool newBatchNumber)
		{
			bool fromAnotherQueue = !(toBePrinted is LetterPrintedQueueCollection);

			int batchNumber = 0;
			
			// Decide whether to get the next batch number
			if (newBatchNumber)
				batchNumber = (int)SqlData.SPExecScalar("usp_GenerateNextID", 2 /* Batch Number */);
			
			LetterPrintedQueueCollection duplex = null; 
			LetterPrintedQueueCollection simplex = null; 
			LetterPrintedQueueCollection envelopes = null; 
			LetterPrintedQueue letterPrintedQueue = null;

			if (fromAnotherQueue)
			{
				duplex = new LetterPrintedQueueCollection();
				simplex = new LetterPrintedQueueCollection();
				envelopes = new LetterPrintedQueueCollection();
			}

			foreach(BaseLetterQueue blq in toBePrinted)
			{
				if(!blq.IsMarkedForDeletion && (!(blq is SelectableLetterQueue) || ((SelectableLetterQueue)blq).Selected) && blq.LetterTemplate != null)
				{
					// generates LetterPrintedQueue object from BaseLetterQueue object of passed collection
					if (fromAnotherQueue)
						letterPrintedQueue = new LetterPrintedQueue(blq, batchNumber);
					else
						letterPrintedQueue = blq as LetterPrintedQueue;
					
					// If there is no batchnumber or we want to override the existings one
					if (newBatchNumber || letterPrintedQueue.BatchNumber == -1)
						letterPrintedQueue.BatchNumber = batchNumber;

					letterPrintedQueue.QueueID = blq.QueueID;
					letterPrintedQueue.LetterCustomText = blq.LetterCustomText;
					letterPrintedQueue.Status = LetterPrintedQueueStatus.Pending;

					// BDS set the print setting
					letterPrintedQueue.PrinterID = printerTo.PrinterID;

					// Find the delivery method Fax or Print
					if (!overrideDelivery)
					{
						SqlDataReader reader = null;
						try 
						{
							reader = SqlData.SPExecRead("usp_GetReceiver", new object[] {blq.PatientID, blq.ReferralID, blq.EventID, blq.CMSID});
					
							if (reader["DeliveryMethod"] != DBNull.Value && reader["DeliveryMethod"].ToString() == "F")
								letterPrintedQueue.Delivery = false;
							else
								letterPrintedQueue.Delivery = true;
						}
						catch
						{	letterPrintedQueue.Delivery = true;}
						finally
						{	
							if(reader != null)
								reader.Close();	
						}
					}
					else
						letterPrintedQueue.Delivery = delivery;

					if (fromAnotherQueue)
					{
						if(!(blq.LetterTemplate.FormTypeID == LetterFormTypeCollection.ActiveLetterFormTypes.Lookup_FormTypeIDByCode(LetterFormType.ENVELOPE)))
						{
							if(!blq.LetterTemplate.Duplex)
								simplex.Add(letterPrintedQueue);
							else
								duplex.Add(letterPrintedQueue);
						}
						else
							envelopes.Add(letterPrintedQueue);
						blq.MarkDel();
					}
				}
			}// end of foreach
			
			if (fromAnotherQueue)
			{
				// combine 3 separate collections into a single one
				if(simplex.Count > 0) 
					this.CopyElementsFrom(simplex, true, true);
				if(duplex.Count > 0)
					this.CopyElementsFrom(duplex, true, true);
				if(envelopes.Count > 0)
					this.CopyElementsFrom(envelopes, true, true);
			}

			this.Save();
			//return this as LetterPrintedQueueCollection;
		}

//		private void ReRunBatch()
//		{
//			foreach(BaseLetterQueue blq in this)
//			{
//				if(!blq.IsMarkedForDeletion && ((SelectableLetterQueue)blq).Selected && blq.LetterTemplate != null)
//				{
//					(blq as LetterPrintedQueue).Status = LetterPrintedQueueStatus.Pending;
//				}
//			}
//		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchLetterPrintedQueue(int maxRecords, LetterPrintedQueue searcher, object isDuplex, object isEnvelope)
		{
			object dateFrom = (searcher.DateFrom == DateTime.MinValue? (object)null: (object)searcher.DateFrom);
			object dateTo = (searcher.DateTo == DateTime.MinValue? (object)null: (object)searcher.DateTo);
			if(dateFrom == null & dateTo == null)
				searcher.DateTypeFilter = 0;
			this.Clear();

			this.ElementType = typeof(LetterPrintedQueueSearchResult);
            			
			return SqlData.SPExecReadCol("usp_ManageLetterPrintedQueue", maxRecords, this, searcher, false,
				new string[] {"dateFrom", "dateTo", "isDuplex", "isEnvelope", "dateTypeFilter", "rowCount"}, new object[] {dateFrom, dateTo, isDuplex, isEnvelope, searcher.DateTypeFilter, MAXRECORDS});
		}

		public override BaseLetterQueueCollection GetFromSearch(BaseLetterQueue searcher, object isDuplex, object isEnvelope)
		{
			this.SearchLetterPrintedQueue(-1, searcher as LetterPrintedQueue, isDuplex, isEnvelope);
			return this;
		}

		protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);
			if (this.preSelect)
				((LetterPrintedQueue)data).Selected = true;
		}


	}


	[SPAutoGen("usp_SearchLetterPrintedQueue", null, ManuallyManaged=true)]
	public class LetterPrintedQueueSearchResult : LetterPrintedQueue
	{
		[NonSerialized]
		private LetterPrintedQueueSearchResultCollection parentLetterPrintedQueueSearchResultCollection;
		[ColumnMapping("PatientName")]
		private string patientName;
		[ColumnMapping("LetterTemplateName")]
		private string letterTemplateName;
		[ColumnMapping("LetterSetID", StereoType=DataStereoType.FK)]
		private int letterSetID;
		[ColumnMapping("LetterSetName")]
		private string letterSetName;
		[ColumnMapping("ReceiverTypeCode")]
		private string receiverTypeCode;
		[ColumnMapping("ReceiverTypeDescription")]
		private string receiverTypeDescription;
		[ColumnMapping("LetterFormTypeCode")]
		private string letterFormTypeCode;
		[ColumnMapping("LetterFormTypeDescription")]
		private string letterFormTypeDescription;
		[ColumnMapping("AssessmentID", StereoType=DataStereoType.FK)]
		private int assessmentID;
		[ColumnMapping("MatrixTypeCode")]
		private string matrixTypeCode;
		[ColumnMapping("PlanDisplayName")]
		private string planDisplayName;

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientName
		{
			get { return this.patientName; }
			set { this.patientName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LetterTemplateName
		{
			get { return this.letterTemplateName; }
			set { this.letterTemplateName = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LetterSetID
		{
			get { return this.letterSetID; }
			set { this.letterSetID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LetterSetName
		{
			get { return this.letterSetName; }
			set { this.letterSetName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string ReceiverTypeCode
		{
			get { return this.receiverTypeCode; }
			set { this.receiverTypeCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string ReceiverTypeDescription
		{
			get { return this.receiverTypeDescription; }
			set { this.receiverTypeDescription = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LetterFormTypeCode
		{
			get { return this.letterFormTypeCode; }
			set { this.letterFormTypeCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LetterFormTypeDescription
		{
			get { return this.letterFormTypeDescription; }
			set { this.letterFormTypeDescription = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int AssessmentID
		{
			get { return this.assessmentID; }
			set { this.assessmentID = value; }
		}
 
		[ControlType(EnumControlTypes.TextBox)]
		public string MatrixTypeCode
		{
			get { return this.matrixTypeCode; }
			set { this.matrixTypeCode = value; }
		}

		/// <summary>
		/// Parent LetterPrintedQueueSearchResultCollection that contains this element
		/// </summary>
		public LetterPrintedQueueSearchResultCollection ParentLetterPrintedQueueSearchResultCollection
		{
			get
			{
				return this.parentLetterPrintedQueueSearchResultCollection;
			}
			set
			{
				this.parentLetterPrintedQueueSearchResultCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PlanDisplayName
		{
			get { return this.planDisplayName; }
			set { this.planDisplayName = value; }
		}



	}

	/// <summary>
	/// Strongly typed collection of LetterPrintedQueueSearchResult objects
	/// </summary>
	[ElementType(typeof(LetterPrintedQueueSearchResult))]
	public class LetterPrintedQueueSearchResultCollection : LetterPrintedQueueCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterPrintedQueueSearchResult elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterPrintedQueueSearchResultCollection = this;
			else
				elem.ParentLetterPrintedQueueSearchResultCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterPrintedQueueSearchResult elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterPrintedQueueSearchResult this[int index]
		{
			get
			{
				return (LetterPrintedQueueSearchResult)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterPrintedQueueSearchResult)oldValue, false);
			SetParentOnElem((LetterPrintedQueueSearchResult)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}

}
