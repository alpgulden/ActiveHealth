using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [MatrixType]
	/// </summary>
	[SPAutoGen("usp_GetAllMatrixTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetAllMatrixTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertMatrixType")]
	[SPUpdate("usp_UpdateMatrixType")]
	[SPDelete("usp_DeleteMatrixType")]
	[SPLoad("usp_LoadMatrixType")]
	[TableMapping("MatrixType","matrixTypeID")]
	public class MatrixType : BaseLookupWithSubCode
	{
		[NonSerialized]
		private MatrixTypeCollection parentMatrixTypeCollection;
		[ColumnMapping("MatrixTypeID",(int)0)]
		private int matrixTypeID;
		[ColumnMapping("CMSTypeID",StereoType=DataStereoType.FK)]
		private int cMSTypeID;
		[ColumnMapping("NotePad")]
		private string notePad;
		
		public const string CASEMANAGEMENT = "CMGT";
		public const string EVENT_CLINICALREVIEW = "E&CR";
		public const string REFERRAL = "REFR";
		public const string DISEASEMANAGEMENT = "DISM";
		public const string MATERNICHEK = "MC";
		

		public MatrixType()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int MatrixTypeID
		{
			get { return this.matrixTypeID; }
			set { this.matrixTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldValuesMember("LookupOf_SubCodeID", "CMSTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@CMSTYPE@")]
		public override int SubCodeID
		{
			get { return this.cMSTypeID; }
			set { this.cMSTypeID = value; }
		}

		/// <summary>
		/// Parent MatrixTypeCollection that contains this element
		/// </summary>
		public MatrixTypeCollection ParentMatrixTypeCollection
		{
			get
			{
				return this.parentMatrixTypeCollection;
			}
			set
			{
				this.parentMatrixTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSTypeID
		{
			get { return this.cMSTypeID; }
			set { this.cMSTypeID = value; }
		}

		public CMSTypeCollection LookupOf_SubCodeID
		{
			get
			{
				return CMSTypeCollection.ActiveCMSTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of MatrixType objects
	/// </summary>
	[ElementType(typeof(MatrixType))]
	public class MatrixTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		[NonSerialized]
		private CollectionIndexer indexBy_MatrixTypeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MatrixType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMatrixTypeCollection = this;
			else
				elem.ParentMatrixTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MatrixType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MatrixType this[int index]
		{
			get
			{
				return (MatrixType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MatrixType)oldValue, false);
			SetParentOnElem((MatrixType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllMatrixTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllMatrixTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared MatrixTypeCollection which is cached in NSGlobal
		/// </summary>
		public static MatrixTypeCollection ActiveMatrixTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				MatrixTypeCollection col = (MatrixTypeCollection)NSGlobal.EnsureCachedObject("ActiveMatrixTypes", typeof(MatrixTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllMatrixTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on matrixTypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_MatrixTypeID
		{
			get
			{
				if (this.indexBy_MatrixTypeID == null)
					this.indexBy_MatrixTypeID = new CollectionIndexer(this, new string[] { "matrixTypeID" }, true);
				return this.indexBy_MatrixTypeID;
			}
			
		}

		/// <summary>
		/// Looks up by matrixTypeID and returns Code value.  Uses the IndexBy_MatrixTypeID indexer.
		/// </summary>
		public string Lookup_CodeByMatrixTypeID(int matrixTypeID)
		{
			return this.IndexBy_MatrixTypeID.LookupStringMember("Code", matrixTypeID);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns MatrixTypeID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_MatrixTypeIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("MatrixTypeID", code);
		}

		/// <summary>
		/// Hashtable based search on matrixTypeID fields returns the object.  Uses the IndexBy_MatrixTypeID indexer.
		/// </summary>
		public MatrixType FindBy(int matrixTypeID)
		{
			return (MatrixType)this.IndexBy_MatrixTypeID.GetObject(matrixTypeID);
		}


		/// <summary>
		/// Looks up by cMSTypeID and returns MatrixTypeID value.
		/// </summary>
		public int Lookup_MatrixTypeIDByCMSTypeID(int cMSTypeID)
		{
			foreach (MatrixType matrixType in this)
			{
				if (matrixType.CMSTypeID == cMSTypeID)
					return matrixType.MatrixTypeID;
			}

			return -1;
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllMatrixTypes", -1, this, false);
		}


	}
}
