using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterMatrixType]
	/// </summary>
	[SPAutoGen("usp_GetAllLetterMatrixTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetAllLetterMatrixTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertLetterMatrixType")]
	[SPUpdate("usp_UpdateLetterMatrixType")]
	[SPLoad("usp_LoadLetterMatrixType")]
	[TableMapping("LetterMatrixType","letterMatrixTypeID")]
	public class LetterMatrixType : BaseLookupWithNote
	{
		[NonSerialized]
		private LetterMatrixTypeCollection parentLetterMatrixTypeCollection;
		[ColumnMapping("LetterMatrixTypeID",(int)0)]
		private int letterMatrixTypeID;
		[ColumnMapping("NotePad")]
		private string notePad;

		
		public LetterMatrixType()
		{
		}

		public LetterMatrixType(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int LetterMatrixTypeID
		{
			get { return this.letterMatrixTypeID; }
			set { this.letterMatrixTypeID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent LetterMatrixTypeCollection that contains this element
		/// </summary>
		public LetterMatrixTypeCollection ParentLetterMatrixTypeCollection
		{
			get
			{
				return this.parentLetterMatrixTypeCollection;
			}
			set
			{
				this.parentLetterMatrixTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of LetterMatrixType objects
	/// </summary>
	[ElementType(typeof(LetterMatrixType))]
	public class LetterMatrixTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		[NonSerialized]
		private CollectionIndexer indexBy_LetterMatrixTypeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterMatrixType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterMatrixTypeCollection = this;
			else
				elem.ParentLetterMatrixTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterMatrixType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterMatrixType this[int index]
		{
			get
			{
				return (LetterMatrixType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterMatrixType)oldValue, false);
			SetParentOnElem((LetterMatrixType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterMatrixType elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterMatrixType)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllLetterMatrixTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLetterMatrixTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared LetterMatrixTypeCollection which is cached in NSGlobal
		/// </summary>
		public static LetterMatrixTypeCollection ActiveLetterMatrixTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LetterMatrixTypeCollection col = (LetterMatrixTypeCollection)NSGlobal.EnsureCachedObject("ActiveLetterMatrixTypes", typeof(LetterMatrixTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllLetterMatrixTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on letterMatrixTypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_LetterMatrixTypeID
		{
			get
			{
				if (this.indexBy_LetterMatrixTypeID == null)
					this.indexBy_LetterMatrixTypeID = new CollectionIndexer(this, new string[] { "letterMatrixTypeID" }, true);
				return this.indexBy_LetterMatrixTypeID;
			}
			
		}

		/// <summary>
		/// Looks up by letterMatrixTypeID and returns Code value.  Uses the IndexBy_LetterMatrixTypeID indexer.
		/// </summary>
		public string Lookup_CodeByLetterMatrixTypeID(int letterMatrixTypeID)
		{
			return this.IndexBy_LetterMatrixTypeID.LookupStringMember("Code", letterMatrixTypeID);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllLetterMatrixTypes", -1, this, false);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns LetterMatrixTypeID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_LetterMatrixTypeIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("LetterMatrixTypeID", code);
		}
	}

	
}
