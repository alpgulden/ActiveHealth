using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterNonPrintedQueue]
	/// </summary>

	[SPAutoGen("usp_GetAllLettersNonPrintedQueue","SelectAll.sptpl","")]
	[SPInsert("usp_InsertLetterNonPrintedQueue")]
	[SPUpdate("usp_UpdateLetterNonPrintedQueue")]
	[SPDelete("usp_DeleteLetterNonPrintedQueue")]
	[SPLoad("usp_LoadLetterNonPrintedQueue")]
	[TableMapping("LetterNonPrintedQueue","queueID",true)]
	public class LetterNonPrintedQueue : BaseLetterQueue
	{
		[ColumnMapping("LetterMatrixTypeID",StereoType=DataStereoType.FK)]
		protected int letterMatrixTypeID;
		protected LetterNonPrintedQueueCollection parentLetterNonPrintedQueueCollection;
		
		#region overriden methods from BaseLetterQueue
		public override int LQID
		{
			get { return this.queueID; }
		}

		public override LetterQueueType LQType
		{
			get { return LetterQueueType.NotPrinted; }
		}

		public override bool LoadLetterQueue(int queueID)
		{
			//return base.LoadLetterQueue (queueID);
			return this.Load(queueID);
		}
		#endregion

		
		public LetterNonPrintedQueue()
		{
			
		}
			
		public LetterNonPrintedQueue(BaseLetterQueue blq)
		{
			this.CopyMembersFrom(blq, true, true, false);
			this.NewRecord();
		}

		public LetterNonPrintedQueue(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			//this.eventDate = DateTime.Now;
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			if(this.eventDate == DateTime.MinValue)
				this.eventDate = DateTime.Now;
			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Parent LetterNonPrintedQueueCollection that contains this element
		/// </summary>
		public LetterNonPrintedQueueCollection ParentLetterNonPrintedQueueCollection
		{
			get
			{
				return this.parentLetterNonPrintedQueueCollection;
			}
			set
			{
				this.parentLetterNonPrintedQueueCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LetterMatrixTypeID
		{
			get { return this.letterMatrixTypeID; }
			set { this.letterMatrixTypeID = value; }
		}

		public int GetLetterCount(object isDuplex, object isEnvelope)
		{
			object dateFrom = (this.DateFrom == DateTime.MinValue? (object)null: (object)this.DateFrom);
			object dateTo = (this.DateTo == DateTime.MinValue? (object)null: (object)this.DateTo);

			object ret = SqlData.SPExecScalar("usp_ManageLetterNonPrintedQueue", this, false, 
				new string[] {"action", "dateFrom", "dateTo", "isDuplex", "isEnvelope"},
				new object[] {2 /*Count*/, dateFrom, dateTo, isDuplex, isEnvelope});
			return SQLDataDirect.GetFromDBValue(ret, 0);
		}

		public int CreateBatch(object isDuplex, object isEnvelope, int batchNumber, int printerID)
		{
			object dateFrom = (this.DateFrom == DateTime.MinValue? (object)null: (object)this.DateFrom);
			object dateTo = (this.DateTo == DateTime.MinValue? (object)null: (object)this.DateTo);
			object objprinterID = (printerID == 0? (object)null : (object)printerID);

			object ret = SqlData.SPExecScalar("usp_ManageLetterNonPrintedQueue", this, false, 
				new string[] {"action", "dateFrom", "dateTo", "isDuplex", "isEnvelope", "IbatchNumber", "Istatus", "IprinterID", "IcreatedBy"},
				new object[] {3 /*Batch*/, dateFrom, dateTo, isDuplex, isEnvelope, batchNumber, (int)LetterPrintedQueueStatus.Pending, objprinterID, AASecurityHelper.GetUserId});
			return SQLDataDirect.GetFromDBValue(ret, 0);
		}

	}

	/// <summary>
	/// Strongly typed collection of LetterNonPrintedQueue objects
	/// </summary>
	[ElementType(typeof(LetterNonPrintedQueue))]
	public class LetterNonPrintedQueueCollection : BaseLetterQueueCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterNonPrintedQueue elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterNonPrintedQueueCollection = this;
			else
				elem.ParentLetterNonPrintedQueueCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterNonPrintedQueue elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterNonPrintedQueue this[int index]
		{
			get
			{
				return (LetterNonPrintedQueue)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterNonPrintedQueue)oldValue, false);
			SetParentOnElem((LetterNonPrintedQueue)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterNonPrintedQueue elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterNonPrintedQueue)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public override int LoadAllLetters(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLettersNonPrintedQueue", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchLetterNonPrintedQueue(int maxRecords, LetterNonPrintedQueue searcher, object isDuplex, object isEnvelope)
		{
			object dateFrom = (searcher.DateFrom == DateTime.MinValue? (object)null: (object)searcher.DateFrom);
			object dateTo = (searcher.DateTo == DateTime.MinValue? (object)null: (object)searcher.DateTo);
			this.Clear();
			
			this.ElementType = typeof(LetterNonPrintedQueueSearchResult);

			//return SqlData.SPExecReadCol("usp_SearchLetterNonPrintedQueue", maxRecords, this, searcher, false);
			return SqlData.SPExecReadCol("usp_ManageLetterNonPrintedQueue", maxRecords, this, searcher, false,
				new string[] {"dateFrom", "dateTo", "isDuplex", "isEnvelope", "rowCount"}, new object[] {dateFrom, dateTo, isDuplex, isEnvelope, MAXRECORDS});
		}

		public override BaseLetterQueueCollection GetFromSearch(BaseLetterQueue searcher, object isDuplex, object isEnvelope)
		{
			this.SearchLetterNonPrintedQueue(-1, searcher as LetterNonPrintedQueue, isDuplex, isEnvelope);
			return this;
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public override void Save()
		{
			this.SaveElements();		
		}


		public void DeleteSelectedAndSave()
		{
			foreach(LetterNonPrintedQueue lnpq in this)
			{
				lnpq.IsMarkedForDeletion = (((SelectableLetterQueue)lnpq).Selected ? true : false);
			}
			this.Save();
		}

		public override void CreateFromCollectionAndSave(BaseLetterQueueCollection toBePrinted, bool overrideDelivery, bool delivery, Printer printerTo, bool newBatchNumber)
		{
			if(!(toBePrinted is LetterDraftQueueCollection))
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Only LetterDraftQueue Collection can be converted to LetterNonPrintedQueue Collection");

			foreach(BaseLetterQueue blq in toBePrinted)
			{
				if(!blq.IsMarkedForDeletion && ((SelectableLetterQueue)blq).Selected && blq.LetterTemplate != null)
				{
					// generates LetterNonPrintedQueue object from BaseLetterQueue object of passed collection
					LetterNonPrintedQueue letterNonPrintedQueue = new LetterNonPrintedQueue(blq);
					letterNonPrintedQueue.CreateTime = (blq as LetterDraftQueue).CreateTime;
					letterNonPrintedQueue.QueueID = blq.QueueID;
					letterNonPrintedQueue.LetterCustomText = blq.LetterCustomText;
					
					this.Add(letterNonPrintedQueue);
					blq.MarkDel();
				}
			}// end of foreach
			this.Save();
		}

		protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);
			if (this.preSelect)
				((LetterNonPrintedQueue)data).Selected = true;
		}


	}


	[SPAutoGen("usp_SearchLetterNonPrintedQueue", null, ManuallyManaged=true)]
	public class LetterNonPrintedQueueSearchResult : LetterNonPrintedQueue
	{
		[NonSerialized]
		private LetterNonPrintedQueueSearchResultCollection parentLetterNonPrintedQueueSearchResultCollection;
		[ColumnMapping("PatientName")]
		private string patientName;
		[ColumnMapping("LetterTemplateName")]
		private string letterTemplateName;
		[ColumnMapping("LetterSetID", StereoType=DataStereoType.FK)]
		private int letterSetID;
		[ColumnMapping("LetterSetName")]
		private string letterSetName;
		[ColumnMapping("ReceiverTypeCode")]
		private string receiverTypeCode;
		[ColumnMapping("ReceiverTypeDescription")]
		private string receiverTypeDescription;
		[ColumnMapping("LetterFormTypeCode")]
		private string letterFormTypeCode;
		[ColumnMapping("LetterFormTypeDescription")]
		private string letterFormTypeDescription;
		[ColumnMapping("AssessmentID", StereoType=DataStereoType.FK)]
		private int assessmentID;
		[ColumnMapping("MatrixTypeCode")]
		private string matrixTypeCode;
		[ColumnMapping("PlanDisplayName")]
		private string planDisplayName;

		[ColumnMapping("MorgDisplayName")]
		private string morgDisplayName;
		[ColumnMapping("OrgDisplayName")]
		private string orgDisplayName;
		[ColumnMapping("SorgDisplayName")]
		private string sorgDisplayName;

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientName
		{
			get { return this.patientName; }
			set { this.patientName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LetterTemplateName
		{
			get { return this.letterTemplateName; }
			set { this.letterTemplateName = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LetterSetID
		{
			get { return this.letterSetID; }
			set { this.letterSetID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LetterSetName
		{
			get { return this.letterSetName; }
			set { this.letterSetName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string ReceiverTypeCode
		{
			get { return this.receiverTypeCode; }
			set { this.receiverTypeCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string ReceiverTypeDescription
		{
			get { return this.receiverTypeDescription; }
			set { this.receiverTypeDescription = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LetterFormTypeCode
		{
			get { return this.letterFormTypeCode; }
			set { this.letterFormTypeCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LetterFormTypeDescription
		{
			get { return this.letterFormTypeDescription; }
			set { this.letterFormTypeDescription = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int AssessmentID
		{
			get { return this.assessmentID; }
			set { this.assessmentID = value; }
		}

		/// <summary>
		/// Parent LetterNonPrintedQueueSearchResultCollection that contains this element
		/// </summary>
		public LetterNonPrintedQueueSearchResultCollection ParentLetterNonPrintedQueueSearchResultCollection
		{
			get
			{
				return this.parentLetterNonPrintedQueueSearchResultCollection;
			}
			set
			{
				this.parentLetterNonPrintedQueueSearchResultCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string MatrixTypeCode
		{
			get { return this.matrixTypeCode; }
			set { this.matrixTypeCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PlanDisplayName
		{
			get { return this.planDisplayName; }
			set { this.planDisplayName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string MorgDisplayName
		{
			get { return this.morgDisplayName; }
			set { this.morgDisplayName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string OrgDisplayName
		{
			get { return this.orgDisplayName; }
			set { this.orgDisplayName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SorgDisplayName
		{
			get { return this.sorgDisplayName; }
			set { this.sorgDisplayName = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of LetterNonPrintedQueueSearchResult objects
	/// </summary>
	[ElementType(typeof(LetterNonPrintedQueueSearchResult))]
	public class LetterNonPrintedQueueSearchResultCollection : LetterNonPrintedQueueCollection
	{
		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterNonPrintedQueueSearchResult this[int index]
		{
			get
			{
				return (LetterNonPrintedQueueSearchResult)List[index];
			}
			set
			{
				List[index] = value;
			}
		}
	}

}
