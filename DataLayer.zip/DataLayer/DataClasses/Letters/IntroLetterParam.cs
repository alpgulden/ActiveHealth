using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	public enum IntroLetterNumber
	{
		CCLetter	 = 0,
		IntroLetter1 = 1,
		IntroLetter2 = 2,
		IntroLetter3 = 3
	}
	
	/// <summary>
	/// Summary description for IntroLetterParam.
	/// </summary>
	[TableMapping(null)]
	public class IntroLetterParam : BaseData
	{
		private int morgID;
		private int orgID;
		private DateTime scoringLoadDate;
		private IntroLetterNumber introletterNumber;
		private int userID;
		
		
		
		private string morgPath;
		private string orgPath;

		public IntroLetterParam()
		{
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int MorgID
		{
			get { return this.morgID; }
			set { this.morgID = value;}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int OrgID
		{
			get { return this.orgID; }
			set { this.orgID = value;}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ScoringLoadDate
		{
			get { return this.scoringLoadDate; }
			set { this.scoringLoadDate = value; }
		}

		public IntroLetterNumber IntroletterNumber
		{
			get { return this.introletterNumber; }
			set { this.introletterNumber = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string MorgPath
		{
			get { return this.morgPath; }
			set { this.morgPath = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string OrgPath
		{
			get { return this.orgPath; }
			set { this.orgPath = value; }
		}
		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public void IntroLetterGeneration()
		{
			int introletternum = (int)this.introletterNumber;
			this.userID = AASecurityHelper.GetUserId;
			SqlData.SPExecNonQuery(1800, "usp_IntroLetterGeneration",
				new object[] {SQLDataDirect.MakeDBValue(this.morgID, DBNull.Value), 
								 SQLDataDirect.MakeDBValue(this.orgID, DBNull.Value), 
								 SQLDataDirect.MakeDBValue(introletternum, DBNull.Value), 
								 SQLDataDirect.MakeDBValue(this.scoringLoadDate, DateTime.MinValue),
								 SQLDataDirect.MakeDBValue(this.userID, DBNull.Value)
							  });
		}

		
	}
}
