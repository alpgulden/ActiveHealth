using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Printers]
	/// </summary>
	[SPInsert("")]
	[SPUpdate("")]
	[SPDelete("")]
	[SPLoad("usp_LoadPrinter")]
	[TableMapping("PrinterList","PrinterID")]
	public class Printer : NetsoftUSA.DataLayer.BaseDataClass
	{
		[NonSerialized]
		private PrinterCollection parentPrinterCollection;
		[ColumnMapping("PrinterID",StereoType=DataStereoType.PK)]
		private int printerID;
		[ColumnMapping("PrinterName")]
		private string printerName;
		[ColumnMapping("ServerName")]
		private string serverName;
		[ColumnMapping("PrinterShareName")]
		private string printerShareName;
		[ColumnMapping("IsDefault")]
		private bool isDefault = false;
		

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.None, MaxLength=255)]
		public string Description
		{
			//get { return this.printerShareName + " on " + this.ServerName; }
			get { return "\\\\" + this.serverName + "\\" +  this.printerName; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		public string PrinterName
		{
			get { return this.printerName; }
			set { this.printerName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		public string ServerName
		{
			get { return this.serverName; }
			set { this.serverName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		public string PrinterShareName
		{
			get { return this.printerShareName; }
			set { this.printerShareName = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IsDefault
		{
			get { return this.isDefault; }
			set { this.isDefault = value; }
		}

		[FieldValuesMember("LookupOf_PrinterID", "PrinterID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup,IsRequired=true)]
		[FieldDescription("@PRINTERID@")]
		public int PrinterID
		{
			get { return this.printerID; }
			set { this.printerID = value; }
		}

		public void New()
		{
			//this.PrinterID = 0;
			this.NewRecord(); // initialize record state
		}

		/// <summary>
		/// Parent PrinterCollection that contains this element
		/// </summary>
		public PrinterCollection ParentPrinterCollection
		{
			get
			{
				return this.parentPrinterCollection;
			}
			set
			{
				this.parentPrinterCollection = value; // parent is set when added to a collection
			}
		}


		public PrinterCollection LookupOf_PrinterID
		{
			get
			{
				return PrinterCollection.AllPrinters; // Acquire a shared instance from the static member of collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of Printer objects
	/// </summary>
	[ElementType(typeof(Printer))]
	public class PrinterCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PrinterID;
		[NonSerialized]
		private CollectionIndexer indexBy_ParentPrinterCollection;
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		public Printer this[int index]
		{
			get
			{
				return (Printer)List[index];
			}
			set
			{
				List[index] = value;
			}
		}


		/// <summary>
		///  Loads all Languages
		/// </summary>
		public void LoadAll()
		{
			try 
			{
				SqlData.SPExecReadCol("usp_GetAllPrinters", -1, this, false);
			}
			catch(Exception exp)
			{
				throw exp;
			}
			finally
			{
			}
		}


		public static PrinterCollection AllPrinters
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PrinterCollection col = (PrinterCollection)NSGlobal.EnsureCachedObject("AllPrinters", typeof(PrinterCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAll();
				}
				return col;
			}
		}


		/// <summary>
		/// Hashtable based index on parentPrinterCollection fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ParentPrinterCollection
		{
			get
			{
				if (this.indexBy_ParentPrinterCollection == null)
					this.indexBy_ParentPrinterCollection = new CollectionIndexer(this, new string[] { "parentPrinterCollection" }, true);
				return this.indexBy_ParentPrinterCollection;
			}
			
		}

		/// <summary>
		/// Hashtable based index on printerID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PrinterID
		{
			get
			{
				if (this.indexBy_PrinterID == null)
					this.indexBy_PrinterID = new CollectionIndexer(this, new string[] { "printerID" }, true);
				return this.indexBy_PrinterID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on printerID fields returns the object.  Uses the IndexBy_PrinterID indexer.
		/// </summary>
		public Printer FindBy(int printerID)
		{
			return (Printer)this.IndexBy_PrinterID.GetObject(printerID);
		}

		
	}
}

