using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterSet]
	/// </summary>
	[SPAutoGen("usp_GetAllLetterSetsByLetterMatrixType","SelectAllByGivenArgs.sptpl","matrixTypeID, active")]
	[SPAutoGen("usp_GetAllLetterSets","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetAllLetterSetsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertLetterSet")]
	[SPUpdate("usp_UpdateLetterSet")]
	[SPLoad("usp_LoadLetterSet")]
	[TableMapping("LetterSet","letterSetID")]
	public class LetterSet : BaseData
	{
		[NonSerialized]
		private LetterSetCollection parentLetterSetCollection;
		[ColumnMapping("LetterSetID",(int)0)]
		private int letterSetID;
		[ColumnMapping("MatrixTypeID",StereoType=DataStereoType.FK)]
		private int matrixTypeID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active = true;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		private LetterTemplateCollection letterTemplates;
	
		public LetterSet()
		{
		}

		public LetterSet(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int LetterSetID
		{
			get { return this.letterSetID; }
			set { this.letterSetID = value; }
		}

		[FieldValuesMember("LookupOf_MatrixTypeID", "MatrixTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int MatrixTypeID
		{
			get { return this.matrixTypeID; }
			set { this.matrixTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255, IsRequired=true)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int letterSetID)
		{
			return base.Load(letterSetID);
		}

		/// <summary>
		/// Parent LetterSetCollection that contains this element
		/// </summary>
		public LetterSetCollection ParentLetterSetCollection
		{
			get
			{
				return this.parentLetterSetCollection;
			}
			set
			{
				this.parentLetterSetCollection = value; // parent is set when added to a collection
			}
		}

		public MatrixTypeCollection LookupOf_MatrixTypeID
		{
			get
			{
				return MatrixTypeCollection.ActiveMatrixTypes; // Acquire a shared instance from the static member of collection
			}
		}

		#region LetterTemplates
		/// <summary>
		/// Child LetterTemplates mapped to related rows of table LetterTemplate where [LetterSetID] = [LetterSetID]
		/// </summary>
		[SPLoadChild("usp_LoadLetterSetLetterTemplate", "letterSetID")]
		public LetterTemplateCollection LetterTemplates
		{
			get { return this.letterTemplates; }
			set
			{
				this.letterTemplates = value;
				if (value != null)
					value.ParentLetterSet = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the LetterTemplates collection
		/// </summary>
		public void LoadLetterTemplates(bool forceReload)
		{
			this.letterTemplates = (LetterTemplateCollection)LetterTemplateCollection.LoadChildCollection("LetterTemplates", this, typeof(LetterTemplateCollection), letterTemplates, forceReload, null);
		}

		/// <summary>
		/// Saves the LetterTemplates collection
		/// </summary>
		public void SaveLetterTemplates()
		{
			LetterTemplateCollection.SaveChildCollection(this.letterTemplates, true);
		}

		/// <summary>
		/// Synchronizes the LetterTemplates collection
		/// </summary>
		public void SynchronizeLetterTemplates()
		{
			LetterTemplateCollection.SynchronizeChildCollection(this.letterTemplates, true);
		}
		#endregion
	}

	/// <summary>
	/// Strongly typed collection of LetterSet objects
	/// </summary>
	[ElementType(typeof(LetterSet))]
	public class LetterSetCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterSet elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterSetCollection = this;
			else
				elem.ParentLetterSetCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterSet elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterSet this[int index]
		{
			get
			{
				return (LetterSet)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterSet)oldValue, false);
			SetParentOnElem((LetterSet)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterSet elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterSet)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllLetterSetsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLetterSetsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared LetterSetCollection which is cached in NSGlobal
		/// </summary>
		public static LetterSetCollection ActiveLetterSets
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LetterSetCollection col = (LetterSetCollection)NSGlobal.EnsureCachedObject("ActiveLetterSets", typeof(LetterSetCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllLetterSetsByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllLetterSets()
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLetterSets", -1, this, false);
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllLetterSetsByLetterMatrixType(int maxRecords, int matrixTypeID, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLetterSetsByLetterMatrixType", maxRecords, this, false, new object[] { matrixTypeID, active });
		}
	}
}
