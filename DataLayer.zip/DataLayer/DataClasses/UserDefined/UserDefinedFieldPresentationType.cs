using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [UserDefinedFieldPresentationType]
	/// </summary>
	[SPAutoGen("usp_GetAllUserDefinedFieldPresentationTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetUDPresentationTypeByCode","SelectAllByGivenArgs.sptpl","code")]
	[SPAutoGen("usp_GetUserDefinedFieldPresentationTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertUserDefinedFieldPresentationType")]
	[SPUpdate("usp_UpdateUserDefinedFieldPresentationType")]
	[SPDelete("usp_DeleteUserDefinedFieldPresentationType")]
	[SPLoad("usp_LoadUserDefinedFieldPresentationType")]
	[TableMapping("UserDefinedFieldPresentationType","userDefinedFieldPresentationTypeID")]
	public class UserDefinedFieldPresentationType : BaseLookupWithNote
	{
		[NonSerialized]
		private UserDefinedFieldPresentationTypeCollection parentUserDefinedFieldPresentationTypeCollection;
		[ColumnMapping("UserDefinedFieldPresentationTypeID",(int)0)]
		private int userDefinedFieldPresentationTypeID;
		[ColumnMapping("NotePad")]
		private string notePad;
		
	
		public UserDefinedFieldPresentationType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int UserDefinedFieldPresentationTypeID
		{
			get { return this.userDefinedFieldPresentationTypeID; }
			set { this.userDefinedFieldPresentationTypeID = value; }
		}

		/// <summary>
		/// Parent UserDefinedFieldPresentationTypeCollection that contains this element
		/// </summary>
		public UserDefinedFieldPresentationTypeCollection ParentUserDefinedFieldPresentationTypeCollection
		{
			get
			{
				return this.parentUserDefinedFieldPresentationTypeCollection;
			}
			set
			{
				this.parentUserDefinedFieldPresentationTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Parent UserDefinedField that contains this object
		/// </summary>
		public UserDefinedField ParentUserDefinedField
		{
			get { return this.ParentDataObject as UserDefinedField; }
			set { this.ParentDataObject = value; /* parent is set when contained by a UserDefinedField */ }
		}

		

		/// <summary>
		/// Loads the object specified by parameters from table
		/// </summary>
		public bool Load(string code)
		{
			// TODO: Specify stored procedure name correctly.
			return SqlData.SPExecReadObj("usp_Load" + this.RootName, this, false, code);
		}

		

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadUDPresentationTypeByCode(string code)
		{
			return SqlData.SPExecReadObj("usp_GetUDPresentationTypeByCode", this, false, new object[] { code });
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
		
	}

	/// <summary>
	/// Strongly typed collection of UserDefinedFieldPresentationType objects
	/// </summary>
	[ElementType(typeof(UserDefinedFieldPresentationType))]
	public class UserDefinedFieldPresentationTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_UserDefinedFieldPresentationTypeID;
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(UserDefinedFieldPresentationType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentUserDefinedFieldPresentationTypeCollection = this;
			else
				elem.ParentUserDefinedFieldPresentationTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (UserDefinedFieldPresentationType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, UserDefinedFieldPresentationType elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((UserDefinedFieldPresentationType)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(UserDefinedFieldPresentationType elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Load user defined field presentation types either active or inactive
		/// </summary>
		public int LoadUserDefinedFieldPresentationTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetUserDefinedFieldPresentationTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared UserDefinedFieldPresentationTypeCollection which is cached in NSGlobal
		/// </summary>
		public static UserDefinedFieldPresentationTypeCollection ActiveUserDefinedFieldPresentationTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				UserDefinedFieldPresentationTypeCollection col = (UserDefinedFieldPresentationTypeCollection)NSGlobal.EnsureCachedObject("ActiveUserDefinedFieldPresentationTypes", typeof(UserDefinedFieldPresentationTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadUserDefinedFieldPresentationTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns UserDefinedFieldPresentationTypeID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_UserDefinedFieldPresentationTypeIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("UserDefinedFieldPresentationTypeID", code);
		}

		/// <summary>
		/// Hashtable based index on userDefinedFieldPresentationTypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_UserDefinedFieldPresentationTypeID
		{
			get
			{
				if (this.indexBy_UserDefinedFieldPresentationTypeID == null)
					this.indexBy_UserDefinedFieldPresentationTypeID = new CollectionIndexer(this, new string[] { "userDefinedFieldPresentationTypeID" }, true);
				return this.indexBy_UserDefinedFieldPresentationTypeID;
			}
			
		}

		/// <summary>
		/// Looks up by userDefinedFieldPresentationTypeID and returns Code value.  Uses the IndexBy_UserDefinedFieldPresentationTypeID indexer.
		/// </summary>
		public string Lookup_CodeByUserDefinedFieldPresentationTypeID(int userDefinedFieldPresentationTypeID)
		{
			return this.IndexBy_UserDefinedFieldPresentationTypeID.LookupStringMember("Code", userDefinedFieldPresentationTypeID);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllUserDefinedFieldPresentationTypes", -1, this, false);
		}
	}
}
