using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [UserDefinedList]
	/// </summary>
	[SPDelete("usp_DeleteUserDefinedList")]
	[SPAutoGen("usp_GetAllUserDefinedLists","SelectAll.sptpl","")]
	[SPInsert("usp_InsertUserDefinedList")]
	[SPUpdate("usp_UpdateUserDefinedList")]
	[SPLoad("usp_LoadUserDefinedList")]
	[TableMapping("UserDefinedList","userDefinedListID")]
	public class UserDefinedList : BaseData
	{
		[NonSerialized]
		private UserDefinedListCollection parentUserDefinedListCollection;
		[ColumnMapping("UserDefinedListID",(int)0)]
		private int userDefinedListID;
		[ColumnMapping("ListName")]
		private string listName;
		private UserDefinedFieldPresentationValueCollection userDefinedFieldPresentationValues;
		private UserDefinedFieldPresentationValueCollection activeUserDefinedFieldPresentationValues;
		public UserDefinedList()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public UserDefinedList(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int UserDefinedListID
		{
			get { return this.userDefinedListID; }
			set { this.userDefinedListID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string ListName
		{
			get { return this.listName; }
			set { this.listName = value; }
		}

		/// <summary>
		/// Parent UserDefinedListCollection that contains this element
		/// </summary>
		public UserDefinedListCollection ParentUserDefinedListCollection
		{
			get
			{
				return this.parentUserDefinedListCollection;
			}
			set
			{
				this.parentUserDefinedListCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int userDefinedListID)
		{
			return base.Load(userDefinedListID);
		}

		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}

		/// <summary>
		/// Child UserDefinedFieldPresentationValues mapped to related rows of table UserDefinedFieldPresentationValue where [UserDefinedListID] = [UserDefinedListID]
		/// </summary>
		[SPLoadChild("usp_LoadUserDefinedListUserDefinedFieldPresentationValue", "userDefinedListID")]
		public UserDefinedFieldPresentationValueCollection UserDefinedFieldPresentationValues
		{
			get { return this.userDefinedFieldPresentationValues; }
			set
			{
				this.userDefinedFieldPresentationValues = value;
				if (value != null)
					value.ParentUserDefinedList = this; // set this as a parent of the child collection
			}
		}

		public UserDefinedFieldPresentationValueCollection ActiveUserDefinedFieldPresentationValues
		{
			get
			{
				return this.activeUserDefinedFieldPresentationValues;
			}
			set
			{
				this.activeUserDefinedFieldPresentationValues = value;
			}
		}

		public void LoadActiveUserDefinedFieldPresentationValues()
		{
			this.activeUserDefinedFieldPresentationValues = new UserDefinedFieldPresentationValueCollection();
			this.activeUserDefinedFieldPresentationValues.LoadActiveUserDefinedFieldPresentationValues(-1,this.userDefinedListID,true);
		}
		/// <summary>
		/// Loads the UserDefinedFieldPresentationValues collection
		/// </summary>
		public void LoadUserDefinedFieldPresentationValues(bool forceReload)
		{
			this.userDefinedFieldPresentationValues = (UserDefinedFieldPresentationValueCollection)UserDefinedFieldPresentationValueCollection.LoadChildCollection("UserDefinedFieldPresentationValues", this, typeof(UserDefinedFieldPresentationValueCollection), userDefinedFieldPresentationValues, forceReload, null);
		}

		/// <summary>
		/// Saves the UserDefinedFieldPresentationValues collection
		/// </summary>
		public void SaveUserDefinedFieldPresentationValues()
		{
			UserDefinedFieldPresentationValueCollection.SaveChildCollection(this.userDefinedFieldPresentationValues, true);
		}

		/// <summary>
		/// Synchronizes the UserDefinedFieldPresentationValues collection
		/// </summary>
		public void SynchronizeUserDefinedFieldPresentationValues()
		{
			UserDefinedFieldPresentationValueCollection.SynchronizeChildCollection(this.userDefinedFieldPresentationValues, true);
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.
			this.SaveUserDefinedFieldPresentationValues();
		}
	}

	/// <summary>
	/// Strongly typed collection of UserDefinedList objects
	/// </summary>
	[ElementType(typeof(UserDefinedList))]
	public class UserDefinedListCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(UserDefinedList elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentUserDefinedListCollection = this;
			else
				elem.ParentUserDefinedListCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (UserDefinedList elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public UserDefinedList this[int index]
		{
			get
			{
				return (UserDefinedList)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((UserDefinedList)oldValue, false);
			SetParentOnElem((UserDefinedList)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, UserDefinedList elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((UserDefinedList)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(UserDefinedList elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllUserDefinedLists(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllUserDefinedLists", maxRecords, this, false);
		}

		
	}
}
