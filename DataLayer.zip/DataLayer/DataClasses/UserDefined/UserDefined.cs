using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [UserDefined]
	/// </summary>
	[SPInsert("usp_InsertUserDefined")]
	[SPDelete("usp_DeleteUserDefined")]
	[SPUpdate("usp_UpdateUserDefined")]
	[SPLoad("usp_LoadUserDefined")]
	[TableMapping("UserDefined","userDefinedID")]
	public class UserDefined : BaseData
	{
		[ColumnMapping("UserDefinedID",(int)0)]
		private int userDefinedID;
		[ColumnMapping("UDEF1")]
		private string uDEF1;
		[ColumnMapping("UDEF2")]
		private string uDEF2;
		[ColumnMapping("UDEF3")]
		private string uDEF3;
		[ColumnMapping("UDEF4")]
		private string uDEF4;
		[ColumnMapping("UDEF5")]
		private string uDEF5;
		[ColumnMapping("UDEF6")]
		private string uDEF6;
		[ColumnMapping("UDEF7")]
		private string uDEF7;
		[ColumnMapping("UDEF8")]
		private string uDEF8;
		[ColumnMapping("UDEF9")]
		private string uDEF9;
		[ColumnMapping("UDEF10")]
		private string uDEF10;
		[ColumnMapping("UDEF11")]
		private string uDEF11;
		[ColumnMapping("UDEF12")]
		private string uDEF12;
		[ColumnMapping("UDEF13")]
		private string uDEF13;
		[ColumnMapping("UDEF14")]
		private string uDEF14;
		[ColumnMapping("CreatedBy", StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy", StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public UserDefined()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public UserDefined(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int UserDefinedID
		{
			get { return this.userDefinedID; }
			set { this.userDefinedID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF1
		{
			get { return this.uDEF1; }
			set { this.uDEF1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF2
		{
			get { return this.uDEF2; }
			set { this.uDEF2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF3
		{
			get { return this.uDEF3; }
			set { this.uDEF3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF4
		{
			get { return this.uDEF4; }
			set { this.uDEF4 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF5
		{
			get { return this.uDEF5; }
			set { this.uDEF5 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF6
		{
			get { return this.uDEF6; }
			set { this.uDEF6 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF7
		{
			get { return this.uDEF7; }
			set { this.uDEF7 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF8
		{
			get { return this.uDEF8; }
			set { this.uDEF8 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF9
		{
			get { return this.uDEF9; }
			set { this.uDEF9 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF10
		{
			get { return this.uDEF10; }
			set { this.uDEF10 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF11
		{
			get { return this.uDEF11; }
			set { this.uDEF11 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF12
		{
			get { return this.uDEF12; }
			set { this.uDEF12 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF13
		{
			get { return this.uDEF13; }
			set { this.uDEF13 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string UDEF14
		{
			get { return this.uDEF14; }
			set { this.uDEF14 = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int userDefinedID)
		{
			return base.Load(userDefinedID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int userDefinedID)
		{
			base.Delete(userDefinedID);		
		}

		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here

				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent Plan that contains this object
		/// </summary>
		public BaseDataWithUserDefined ParentBaseDataWithUserDefined
		{
			get { return this.ParentDataObject as BaseDataWithUserDefined; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Plan */ }
		}
	}
}
