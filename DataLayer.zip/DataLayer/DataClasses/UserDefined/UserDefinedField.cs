using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [UserDefinedField]
	/// </summary>
	[SPAutoGen("usp_GetNextFieldNumber","","")]
	[SPAutoGen("usp_GetActiveUserDefinedFields","SelectAllByGivenArgsOrderBy.sptpl","userDefinedFieldNumber, ASC, userDefinedEntityID, active")]
	[SPExists("usp_ExistsUserDefinedField")]
	[SPInsert("usp_InsertUserDefinedField")]
	[SPUpdate("usp_UpdateUserDefinedField")]
	[SPDelete("usp_DeleteUserDefinedField")]
	[SPLoad("usp_LoadUserDefinedField")]
	[TableMapping("UserDefinedField","userDefinedFieldID")]
	public class UserDefinedField : BaseData
	{
		[NonSerialized]
		private UserDefinedFieldCollection parentUserDefinedFieldCollection;
		[ColumnMapping("UserDefinedFieldID",(int)0)]
		private int userDefinedFieldID;
		[ColumnMapping("UserDefinedEntityID",StereoType=DataStereoType.FK)]
		private int userDefinedEntityID;
		[ColumnMapping("UserDefinedFieldPresentationTypeID",StereoType=DataStereoType.FK)]
		private int userDefinedFieldPresentationTypeID;
		[ColumnMapping("UserDefinedFieldNumber")]
		private int userDefinedFieldNumber;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("Required")]
		private bool required;
		[ColumnMapping("Label")]
		private string label;
		[ColumnMapping("UserDefinedListID",StereoType=DataStereoType.FK)]
		private int userDefinedListID;
		[ColumnMapping("MaskedEditValue")]
		private string maskedEditValue;
		private UserDefinedFieldPresentationType userDefinedFieldPresentationType;
	
		public UserDefinedField()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public UserDefinedField(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int UserDefinedFieldID
		{
			get { return this.userDefinedFieldID; }
			set { this.userDefinedFieldID = value; }
		}

		/// <summary>
		/// Parent UserDefinedFieldCollection that contains this element
		/// </summary>
		public UserDefinedFieldCollection ParentUserDefinedFieldCollection
		{
			get
			{
				return this.parentUserDefinedFieldCollection;
			}
			set
			{
				this.parentUserDefinedFieldCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int UserDefinedEntityID
		{
			get { return this.userDefinedEntityID; }
			set { this.userDefinedEntityID = value; }
		}

		[FieldValuesMember("LookupOf_UserDefinedFieldPresentationTypeID", "UserDefinedFieldPresentationTypeID", "Code")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@PRESENTATIONTYPE@")]
		public int UserDefinedFieldPresentationTypeID
		{
			get { return this.userDefinedFieldPresentationTypeID; }
			set { this.userDefinedFieldPresentationTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int,MinValue=1,MaxValue=14 , IsRequired=true)]
		public int UserDefinedFieldNumber
		{
			get { return this.userDefinedFieldNumber; }
			set { this.userDefinedFieldNumber = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Required
		{
			get { return this.required; }
			set { this.required = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=200)]
		public string Label
		{
			get { return this.label; }
			set { this.label = value; }
		}
		[FieldValuesMember("LookupOf_UserDefinedListID", "UserDefinedListID", "ListName")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup,IsRequired=true)]
		public int UserDefinedListID
		{
			get { return this.userDefinedListID; }
			set { this.userDefinedListID = value; }
		}

		public UserDefinedFieldPresentationTypeCollection LookupOf_UserDefinedFieldPresentationTypeID
		{
			get
			{
				return UserDefinedFieldPresentationTypeCollection.ActiveUserDefinedFieldPresentationTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public UserDefinedListCollection LookupOf_UserDefinedListID
		{
			get
			{
				UserDefinedListCollection col = new UserDefinedListCollection();
				col.LoadAllUserDefinedLists(-1);
				return col;
			}
		}
		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int userDefinedFieldID)
		{
			return base.Load(userDefinedFieldID);
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64,IsRequired=true)]
		public string MaskedEditValue
		{
			get { return this.maskedEditValue; }
			set { this.maskedEditValue = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public string UserDefinedEntityName
		{
			get { return UserDefinedEntityCollection.AllUserDefinedEntities.Lookup_EntityNameByUserDefinedEntityID(this.userDefinedEntityID); }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public object LoadNextFieldNumber(int userDefinedEntityID)
		{
			return SqlData.SPExecScalar("usp_GetNextFieldNumber",  new object[] { userDefinedEntityID });
		}

		public string UserDefinedFieldPresentationTypeCode
		{
			get { return UserDefinedFieldPresentationTypeCollection.ActiveUserDefinedFieldPresentationTypes.Lookup_CodeByUserDefinedFieldPresentationTypeID(this.userDefinedFieldPresentationTypeID); }
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
		
			writer.AddFieldOnNewLine(this, "UserDefinedEntityName");
				//writer.AddFieldOnNewLine(this, "ProblemDescriptionToDisplay", "@PROBLEM@");
		}

	}

	/// <summary>
	/// Strongly typed collection of UserDefinedField objects
	/// </summary>
	[ElementType(typeof(UserDefinedField))]
	public class UserDefinedFieldCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_UserDefinedFieldNumber;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(UserDefinedField elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentUserDefinedFieldCollection = this;
			else
				elem.ParentUserDefinedFieldCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (UserDefinedField elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public UserDefinedField this[int index]
		{
			get
			{
				return (UserDefinedField)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((UserDefinedField)oldValue, false);
			SetParentOnElem((UserDefinedField)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(UserDefinedField elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((UserDefinedField)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent UserDefinedEntity that contains this collection
		/// </summary>
		public UserDefinedEntity ParentUserDefinedEntity
		{
			get { return this.ParentDataObject as UserDefinedEntity; }
			set { this.ParentDataObject = value; /* parent is set when contained by a UserDefinedEntity */ }
		}

		/// <summary>
		/// Hashtable based index on userDefinedFieldNumber fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_UserDefinedFieldNumber
		{
			get
			{
				if (this.indexBy_UserDefinedFieldNumber == null)
					this.indexBy_UserDefinedFieldNumber = new CollectionIndexer(this, new string[] { "userDefinedFieldNumber" }, true);
				return this.indexBy_UserDefinedFieldNumber;
			}
			
		}

		/// <summary>
		/// Hashtable based search on userDefinedFieldNumber fields returns the object.  Uses the IndexBy_UserDefinedFieldNumber indexer.
		/// </summary>
		public UserDefinedField FindBy(int userDefinedFieldNumber)
		{
			return (UserDefinedField)this.IndexBy_UserDefinedFieldNumber.GetObject(userDefinedFieldNumber);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveUserDefinedFields(int maxRecords, int userDefinedEntityID, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveUserDefinedFields", maxRecords, this, false, new object[] { userDefinedEntityID, active });
		}
	}

}
