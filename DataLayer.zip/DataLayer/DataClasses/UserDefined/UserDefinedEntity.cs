using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [UserDefinedEntity]
	/// </summary>
	[SPAutoGen("usp_GetUserDefinedEntitiesByName","SelectAllByGivenArgs.sptpl","entityName")]
	[SPInsert("usp_InsertUserDefinedEntity")]
	[SPUpdate("usp_UpdateUserDefinedEntity")]
	[SPDelete("usp_DeleteUserDefinedEntity")]
	[SPLoad("usp_LoadUserDefinedEntity")]
	[SPAutoGen("usp_GetAllUserDefinedEntities","SelectAll.sptpl","")]
	[TableMapping("UserDefinedEntity","userDefinedEntityID")]
	public class UserDefinedEntity : BaseData
	{
		[NonSerialized]
		private UserDefinedEntityCollection parentUserDefinedEntityCollection;
		[ColumnMapping("UserDefinedEntityID",(int)0)]
		private int userDefinedEntityID;
		[ColumnMapping("EntityName")]
		private string entityName;
		[ColumnMapping("NumberFields")]
		private int numberFields;
		private UserDefinedFieldCollection userDefinedFields;
		private UserDefinedFieldCollection activeUserDefinedFields;
	
		public UserDefinedEntity()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int UserDefinedEntityID
		{
			get { return this.userDefinedEntityID; }
			set { this.userDefinedEntityID = value; }
		}

        /// <summary>
		/// Parent UserDefinedEntityCollection that contains this element
		/// </summary>
		public UserDefinedEntityCollection ParentUserDefinedEntityCollection
		{
			get
			{
				return this.parentUserDefinedEntityCollection;
			}
			set
			{
				this.parentUserDefinedEntityCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string EntityName
		{
			get { return this.entityName; }
			set { this.entityName = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int NumberFields
		{
			get { return this.numberFields; }
			set { this.numberFields = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int userDefinedEntityID)
		{
			return base.Load(userDefinedEntityID);
		}

		
		/// <summary>
		/// Child UserDefinedFields mapped to related rows of table UserDefinedField where [UserDefinedEntityID] = [UserDefinedEntityID]
		/// </summary>
		[SPLoadChild("usp_LoadUserDefinedEntityFields", "userDefinedEntityID")]
		public UserDefinedFieldCollection UserDefinedFields
		{
			get { return this.userDefinedFields; }
			set
			{
				this.userDefinedFields = value;
				if (value != null)
					value.ParentUserDefinedEntity = this; // set this as a parent of the child collection
			}
		}

		public UserDefinedFieldCollection ActiveUserDefinedFields
		{
			get{return this.activeUserDefinedFields;}
			set{
				this.activeUserDefinedFields = value;
				}
		}
		public bool LoadActiveUserDefinedFields(bool forceReload)
		{
			try
			{
				if (activeUserDefinedFields == null || forceReload)
				{
					activeUserDefinedFields = new UserDefinedFieldCollection();
					activeUserDefinedFields.LoadActiveUserDefinedFields(-1,this.userDefinedEntityID,true);
				}
				return true;
			}
			catch(Exception ex)
			{
				return false;
			}
			
		}
		/// <summary>
		/// Loads the UserDefinedFields collection
		/// </summary>
		public void LoadUserDefinedFields(bool forceReload)
		{
			this.userDefinedFields = (UserDefinedFieldCollection)UserDefinedFieldCollection.LoadChildCollection("UserDefinedFields", this, typeof(UserDefinedFieldCollection), userDefinedFields, forceReload, null);
		}

		/// <summary>
		/// Saves the UserDefinedFields collection
		/// </summary>
		public void SaveUserDefinedFields()
		{
			UserDefinedFieldCollection.SaveChildCollection(this.userDefinedFields, true);
		}

		/// <summary>
		/// Synchronizes the UserDefinedFields collection
		/// </summary>
		public void SynchronizeUserDefinedFields()
		{
			UserDefinedFieldCollection.SynchronizeChildCollection(this.userDefinedFields, true);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadUserDefinedEntitiesByName(string entityName)
		{
			return SqlData.SPExecReadObj("usp_GetUserDefinedEntitiesByName", this, false, new object[] { entityName });
		}

		///<summary>
		///static member to get entity & userdefined field 
		///called from UserDefined userControl to load metadata(entity & fields)
		///</summary>
		public static UserDefinedEntity GetMetaData(string entityname)
		{
			string key = "UserDefinedEntity_" + entityname;
			Object obj =NSGlobal.GetCachedObject(key);
			UserDefinedEntity entity = obj as UserDefinedEntity;
			//if entity is not in cache load it and store it in global cache	
			if(entity == null)
			{
				entity = new UserDefinedEntity();
				entity.LoadUserDefinedEntitiesByName(entityname);
				entity.LoadActiveUserDefinedFields(false);
				NSGlobal.CacheObject(key,entity);
			}
			return entity;
		}
		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFieldOnNewLine(this, "EntityName");
				//writer.AddFieldOnNewLine(this, "ProblemDescriptionToDisplay", "@PROBLEM@");
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of UserDefinedEntity objects
	/// </summary>
	[ElementType(typeof(UserDefinedEntity))]
	public class UserDefinedEntityCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_UserDefinedEntityID;
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		/// <param name="maxRecords">if set to -1, loads all records</param>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// loads all the user defined entities in collection
		/// </summary>
		public int LoadAllUserDefinedEntities(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllUserDefinedEntities", maxRecords, this, false);

			/*
			
			UserDefinedEntity e = new UserDefinedEntity();
			e.LoadUserDefinedFields(false);
			e.UserDefinedFields.Add(new UserDefinedField(true));
			e.UserDefinedFields.MarkDel(0);
			e.SaveUserDefinedFields();

			foreach (UserDefinedField field in e.UserDefinedFields)
				if (field.IsMarkedForDeletion )
					;
			*/
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(UserDefinedEntity elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentUserDefinedEntityCollection = this;
			else
				elem.ParentUserDefinedEntityCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (UserDefinedEntity elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public UserDefinedEntity this[int index]
		{
			get
			{
				return (UserDefinedEntity)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((UserDefinedEntity)oldValue, false);
			SetParentOnElem((UserDefinedEntity)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, UserDefinedEntity elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((UserDefinedEntity)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Accessor to a shared UserDefinedEntityCollection which is cached in NSGlobal
		/// </summary>
		public static UserDefinedEntityCollection AllUserDefinedEntities
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				UserDefinedEntityCollection col = (UserDefinedEntityCollection)NSGlobal.EnsureCachedObject("AllUserDefinedEntities", typeof(UserDefinedEntityCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllUserDefinedEntities(-1);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on userDefinedEntityID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_UserDefinedEntityID
		{
			get
			{
				if (this.indexBy_UserDefinedEntityID == null)
					this.indexBy_UserDefinedEntityID = new CollectionIndexer(this, new string[] { "userDefinedEntityID" }, true);
				return this.indexBy_UserDefinedEntityID;
			}
			
		}

		/// <summary>
		/// Looks up by userDefinedEntityID and returns EntityName value.  Uses the IndexBy_UserDefinedEntityID indexer.
		/// </summary>
		public string Lookup_EntityNameByUserDefinedEntityID(int userDefinedEntityID)
		{
			return this.IndexBy_UserDefinedEntityID.LookupStringMember("EntityName", userDefinedEntityID);
		}

		
	
	}
}
