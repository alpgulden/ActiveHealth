using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [UserDefinedFieldPresentationValue]
	/// </summary>
	[SPAutoGen("usp_GetActiveUserDefinedFieldPresentationValues","SelectAllByGivenArgs.sptpl","userDefinedListID, active")]
	[SPInsert("usp_InsertUserDefinedFieldPresentationValue")]
	[SPUpdate("usp_UpdateUserDefinedFieldPresentationValue")]
	[SPDelete("usp_DeleteUserDefinedFieldPresentationValue")]
	[SPLoad("usp_LoadUserDefinedFieldPresentationValue")]
	[TableMapping("UserDefinedFieldPresentationValue","userDefinedFieldPresentationValueID")]
	public class UserDefinedFieldPresentationValue : BaseData
	{
		[NonSerialized]
		private UserDefinedFieldPresentationValueCollection parentUserDefinedFieldPresentationValueCollection;
		[ColumnMapping("UserDefinedFieldPresentationValueID",(int)0)]
		private int userDefinedFieldPresentationValueID;
		[ColumnMapping("UserDefinedListID",StereoType=DataStereoType.FK)]
		private int userDefinedListID;
		[ColumnMapping("Value")]
		private string value;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("SortOrder",StereoType=DataStereoType.FK)]
		private int sortOrder;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
		
	
		public UserDefinedFieldPresentationValue()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public UserDefinedFieldPresentationValue(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public UserDefinedFieldPresentationValue(int userDefinedListID)
		{
			this.NewRecord(); // initialize record state
			this.userDefinedListID = userDefinedListID;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int UserDefinedFieldPresentationValueID
		{
			get { return this.userDefinedFieldPresentationValueID; }
			set { this.userDefinedFieldPresentationValueID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int UserDefinedListID
		{
			get { return this.userDefinedListID; }
			set { this.userDefinedListID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Value
		{
			get { return this.value; }
			set { this.value = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		/// <summary>
		/// Parent UserDefinedFieldPresentationValueCollection that contains this element
		/// </summary>
		public UserDefinedFieldPresentationValueCollection ParentUserDefinedFieldPresentationValueCollection
		{
			get
			{
				return this.parentUserDefinedFieldPresentationValueCollection;
			}
			set
			{
				this.parentUserDefinedFieldPresentationValueCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=100)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int userDefinedFieldPresentationValueID)
		{
			return base.Load(userDefinedFieldPresentationValueID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int userDefinedFieldPresentationValueID)
		{
			base.Delete(userDefinedFieldPresentationValueID);		
		}

		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}
	}

	/// <summary>
	/// Strongly typed collection of UserDefinedFieldPresentationValue objects
	/// </summary>
	[ElementType(typeof(UserDefinedFieldPresentationValue))]
	public class UserDefinedFieldPresentationValueCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_UserDefinedFieldPresentationValueID;
		
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(UserDefinedFieldPresentationValue elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentUserDefinedFieldPresentationValueCollection = this;
			else
				elem.ParentUserDefinedFieldPresentationValueCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (UserDefinedFieldPresentationValue elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public UserDefinedFieldPresentationValue this[int index]
		{
			get
			{
				return (UserDefinedFieldPresentationValue)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((UserDefinedFieldPresentationValue)oldValue, false);
			SetParentOnElem((UserDefinedFieldPresentationValue)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, UserDefinedFieldPresentationValue elem)
		{
			List.Insert(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((UserDefinedFieldPresentationValue)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(UserDefinedFieldPresentationValue elem)
		{
			return List.Add(elem);
		}

		/// <summary>
		/// Parent UserDefinedList that contains this collection
		/// </summary>
		public UserDefinedList ParentUserDefinedList
		{
			get { return this.ParentDataObject as UserDefinedList; }
			set { this.ParentDataObject = value; /* parent is set when contained by a UserDefinedList */ }
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(UserDefinedFieldPresentationValue elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((UserDefinedFieldPresentationValue)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Hashtable based index on userDefinedFieldPresentationValueID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_UserDefinedFieldPresentationValueID
		{
			get
			{
				if (this.indexBy_UserDefinedFieldPresentationValueID == null)
					this.indexBy_UserDefinedFieldPresentationValueID = new CollectionIndexer(this, new string[] { "userDefinedFieldPresentationValueID" }, true);
				return this.indexBy_UserDefinedFieldPresentationValueID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on userDefinedFieldPresentationValueID fields returns the collection index.  Uses the IndexBy_UserDefinedFieldPresentationValueID indexer.
		/// </summary>
		public int IndexOf(int userDefinedFieldPresentationValueID)
		{
			return this.IndexBy_UserDefinedFieldPresentationValueID.IndexOf(userDefinedFieldPresentationValueID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveUserDefinedFieldPresentationValues(int maxRecords, int userDefinedListID, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveUserDefinedFieldPresentationValues", maxRecords, this, false, new object[] { userDefinedListID, active });
		}

		
		

	}
}
