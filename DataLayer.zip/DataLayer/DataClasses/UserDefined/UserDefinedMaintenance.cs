using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for UserDefinedMaintenance.
	/// </summary>
	[TableMapping(null)]
	public class UserDefinedMaintenance
	{
		public UserDefinedMaintenance()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		private int userDefinedEntityID;

		[FieldValuesMember("LookupOf_UserDefinedEntityID", "UserDefinedEntityID", "EntityName")]
		[ControlType(EnumControlTypes.ComboBox, ValueForNull=(int)0,ClientValidators=EnumClientValidators.Required)]
		public int UserDefinedEntityID
		{
			get { return this.userDefinedEntityID; }
			set { this.userDefinedEntityID = value; }
		}

		public UserDefinedEntityCollection LookupOf_UserDefinedEntityID
		{
			get
			{
				//				this.parentUserDefinedEntityCollection.LoadAllUserDefinedEntities(100);
				
				return UserDefinedEntityCollection.AllUserDefinedEntities;
			}
		}
	}
}
