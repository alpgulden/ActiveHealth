using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [FunctionalStatus]
	/// </summary>
	[SPAutoGen("usp_GetAllFunctionalStatusCodes","SelectAll.sptpl","")]
	[SPLoad("usp_LoadFunctionalStatus")]
	[TableMapping("FunctionalStatus","code")]
	public class FunctionalStatus : BaseData
	{
		#region Functional Status Codes for programmatic access

		public const string OPEN = "OPEN";
		public const string CLOS = "CLOS";
		public const string TERM = "TERM";

		#endregion

		[NonSerialized]
		private FunctionalStatusCollection parentFunctionalStatusCollection;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
	
		public FunctionalStatus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(string code)
		{
			return base.Load(code);
		}

		/// <summary>
		/// Parent FunctionalStatusCollection that contains this element
		/// </summary>
		public FunctionalStatusCollection ParentFunctionalStatusCollection
		{
			get
			{
				return this.parentFunctionalStatusCollection;
			}
			set
			{
				this.parentFunctionalStatusCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of FunctionalStatus objects
	/// </summary>
	[ElementType(typeof(FunctionalStatus))]
	public class FunctionalStatusCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(FunctionalStatus elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentFunctionalStatusCollection = this;
			else
				elem.ParentFunctionalStatusCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (FunctionalStatus elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public FunctionalStatus this[int index]
		{
			get
			{
				return (FunctionalStatus)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((FunctionalStatus)oldValue, false);
			SetParentOnElem((FunctionalStatus)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllFunctionalStatusCodes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllFunctionalStatusCodes", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared FunctionalStatusCollection which is cached in NSGlobal
		/// </summary>
		public static FunctionalStatusCollection AllFunctionalStatusCodes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				FunctionalStatusCollection col = (FunctionalStatusCollection)NSGlobal.EnsureCachedObject("AllFunctionalStatusCodes", typeof(FunctionalStatusCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllFunctionalStatusCodes(-1);
				}
				return col;
			}
			
		}
	}
}
