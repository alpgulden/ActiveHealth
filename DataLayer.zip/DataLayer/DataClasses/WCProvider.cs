using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [WCProvider]
	/// </summary>
	[SPAutoGen("usp_GetAllWCProvider","SelectAll.sptpl","")]
	[SPInsert("usp_InsertWCProvider")]
	[SPUpdate("usp_UpdateWCProvider")]
	[SPDelete("usp_DeleteWCProvider")]
	[SPLoad("usp_LoadWCProvider")]
	[TableMapping("WCProvider","providerId")]
	public class WCProvider : BaseLookupWithNote
	{
		[NonSerialized]
		private WCProviderCollection parentWCProviderCollection;
		[ColumnMapping("ProviderId",(int)0)]
		private int providerId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public WCProvider()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ProviderId
		{
			get { return this.providerId; }
			set { this.providerId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent WCProviderCollection that contains this element
		/// </summary>
		public WCProviderCollection ParentWCProviderCollection
		{
			get
			{
				return this.parentWCProviderCollection;
			}
			set
			{
				this.parentWCProviderCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int providerId)
		{
			return base.Load(providerId);
		}
	}

	/// <summary>
	/// Strongly typed collection of WCProvider objects
	/// </summary>
	[ElementType(typeof(WCProvider))]
	public class WCProviderCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(WCProvider elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentWCProviderCollection = this;
			else
				elem.ParentWCProviderCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (WCProvider elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public WCProvider this[int index]
		{
			get
			{
				return (WCProvider)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((WCProvider)oldValue, false);
			SetParentOnElem((WCProvider)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllWCProvider", -1, this, false);
		}
	}
}
