using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [HEDISAcuityType]
	/// </summary>
	[SPAutoGen("usp_LoadHEDISAcuityTypeByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_LoadAllHEDISAcuityType","SelectAll.sptpl","")]
	[SPInsert("usp_InsertHEDISAcuityType")]
	[SPUpdate("usp_UpdateHEDISAcuityType")]
	[SPDelete("usp_DeleteHEDISAcuityType")]
	[SPLoad("usp_LoadHEDISAcuityType")]
	[TableMapping("HEDISAcuityType","hEDISAcuityTypeID")]
	public class HEDISAcuityType : BaseLookupWithNote
	{
		[NonSerialized]
		private HEDISAcuityTypeCollection parentHEDISAcuityTypeCollection;
		[ColumnMapping("HEDISAcuityTypeID",(int)0)]
		private int hEDISAcuityTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public HEDISAcuityType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int HEDISAcuityTypeID
		{
			get { return this.hEDISAcuityTypeID; }
			set { this.hEDISAcuityTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		
		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Parent HEDISAcuityTypeCollection that contains this element
		/// </summary>
		public HEDISAcuityTypeCollection ParentHEDISAcuityTypeCollection
		{
			get
			{
				return this.parentHEDISAcuityTypeCollection;
			}
			set
			{
				this.parentHEDISAcuityTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int hEDISAcuityTypeID)
		{
			return base.Load(hEDISAcuityTypeID);
		}
	}

	/// <summary>
	/// Strongly typed collection of HEDISAcuityType objects
	/// </summary>
	[ElementType(typeof(HEDISAcuityType))]
	public class HEDISAcuityTypeCollection : BaseTypeCollection
	{


		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadHEDISAcuityTypeByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadHEDISAcuityTypeByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared HEDISAcuityTypeCollection which is cached in NSGlobal
		/// </summary>
		public static HEDISAcuityTypeCollection ActiveHEDISAcuityTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				HEDISAcuityTypeCollection col = (HEDISAcuityTypeCollection)NSGlobal.EnsureCachedObject("ActiveHEDISAcuityTypes", typeof(HEDISAcuityTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadHEDISAcuityTypeByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
