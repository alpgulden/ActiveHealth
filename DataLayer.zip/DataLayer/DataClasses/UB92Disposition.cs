using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [UB92Disposition]
	/// </summary>
	[SPAutoGen("usp_GetActiveUB92DispositionByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllUB92Disposition","SelectAll.sptpl","")]
	[SPInsert("usp_InsertUB92Disposition")]
	[SPUpdate("usp_UpdateUB92Disposition")]
	[SPDelete("usp_DeleteUB92Disposition")]
	[SPLoad("usp_LoadUB92Disposition")]
	[TableMapping("UB92Disposition","uB92DispositionID")]
	public class UB92Disposition : BaseLookupWithNote
	{
		[NonSerialized]
		private UB92DispositionCollection parentUB92DispositionCollection;
		[NonSerialized]
		private SQLDataDirect sqlData;
		[ColumnMapping("UB92DispositionID",(int)0)]
		private int uB92DispositionID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public UB92Disposition()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int UB92DispositionID
		{
			get { return this.uB92DispositionID; }
			set { this.uB92DispositionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public void Save()
		{
			SqlData.UpdateOrInsertObj(this, true, false);		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int uB92DispositionID)
		{
			return SqlData.SelectObj(this, new object[] {uB92DispositionID}, true, false);
		}

		/// <summary>
		/// Parent UB92DispositionCollection that contains this element
		/// </summary>
		public UB92DispositionCollection ParentUB92DispositionCollection
		{
			get
			{
				return this.parentUB92DispositionCollection;
			}
			set
			{
				this.parentUB92DispositionCollection = value; // parent is set when added to a collection
			}
		}

		public override SQLDataDirect SqlData
		{
			get
			{
				if (this.sqlData == null)
					this.sqlData = SQLDataDirect.CreateSqlDataForType(typeof(UB92Disposition),false);
				return this.sqlData;
			}
			set
			{
				this.sqlData = value;
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of UB92Disposition objects
	/// </summary>
	[ElementType(typeof(UB92Disposition))]
	public class UB92DispositionCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(UB92Disposition elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentUB92DispositionCollection = this;
			else
				elem.ParentUB92DispositionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (UB92Disposition elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public UB92Disposition this[int index]
		{
			get
			{
				return (UB92Disposition)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((UB92Disposition)oldValue, false);
			SetParentOnElem((UB92Disposition)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllUB92Disposition", -1, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveUB92DispositionByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveUB92DispositionByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared UB92DispositionCollection which is cached in NSGlobal
		/// </summary>
		public static UB92DispositionCollection ActiveUB92Dispositions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				UB92DispositionCollection col = (UB92DispositionCollection)NSGlobal.EnsureCachedObject("ActiveUB92Dispositions", typeof(UB92DispositionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadActiveUB92DispositionByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
