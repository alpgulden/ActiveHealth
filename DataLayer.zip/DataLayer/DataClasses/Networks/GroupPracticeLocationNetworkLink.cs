using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeLocationNetwork]
	/// </summary>
	[SPAutoGen("usp_GetAllNetworkByGroupPracticeLocationID","SelectAllByGivenArgs.sptpl","groupPracticeLocationID")]
	[SPInsert("usp_InsertGroupPracticeLocationNetworkLink")]
	[SPUpdate("usp_UpdateGroupPracticeLocationNetworkLink")]
	[SPDelete("usp_DeleteGroupPracticeLocationNetworkLink")]
	[SPExists("usp_ExistsGroupPracticeLocationNetworkLink")]
	[SPLoad("usp_LoadGroupPracticeLocationNetworkLink")]
	[TableMapping("GroupPracticeLocationNetwork","groupPracticeLocationNetworkID")]
	public class GroupPracticeLocationNetworkLink : BaseData
	{
		[NonSerialized]
		private GroupPracticeLocationNetworkLinkCollection parentGroupPracticeLocationNetworkLinkCollection;
		[ColumnMapping("GroupPracticeLocationNetworkID",(int)0)]
		private int groupPracticeLocationNetworkID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("GroupPracticeLocationID",(int)0)]
		private int groupPracticeLocationID;
		[ColumnMapping("NetworkID",StereoType=DataStereoType.FK)]
		private int networkID;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("AlternateID")]
		private string alternateID;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		private GroupPracticeLocationNetworkHistoryCollection effectiveDatesHistory;
		private DateTime terminatedTimeWhenLoaded;
		private GroupPracticeLocation groupPracticeLocation;
		private int filterPlanID;

		public int FilterPlanID
		{
			get { return this.filterPlanID; }
			set { this.filterPlanID = value;}
		}

		public GroupPracticeLocationNetworkLink()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public string NetworkName
		{
			get 
			{ 
				Network net = new Network();
				net.Load(this.NetworkID);
				return net.Name;
			}
		}

		public string NetworkType
		{
			get 
			{
				Network		net		= new Network();
				net.Load(this.NetworkID);
				NetworkType netType = new NetworkType();
				netType.Load(net.TypeID);
				return netType.Description;
			}
		}
		
		public string NetworkAddress
		{
			get 
			{
				Network net = new Network();
				Address addr = new Address();
				net.Load(this.NetworkID);
				addr.Load(net.AddressID);
				return addr.ToString();
			}
		}

		
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public int Code
		{
			get { return this.groupPracticeLocationNetworkID ; }
			//set { this.providerLocationNetworkID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public string Description
		{
			get { return this.NetworkName;  }
			//set { this.NetworkName = value; }
		}
	
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public int GroupPracticeLocationNetworkID
		{
			get { return this.groupPracticeLocationNetworkID; }
			set { this.groupPracticeLocationNetworkID = value; }
		}

		

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int GroupPracticeLocationID
		{
			get { return this.groupPracticeLocationID; }
			set { this.groupPracticeLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int,ValueForNull=0, IsRequired=true)]
		public int NetworkID
		{
			get { return this.networkID; }
			set { this.networkID = value; }
		}
		public void New()
		{
			this.ModifiedBy = 1;
			//this.CreatedBy  = 1;
			this.NewRecord(); // initialize record state
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}
		public int GroupPracticeID
		{
			get 
			{
				GroupPracticeLocation gpNet = new GroupPracticeLocation();
				gpNet.Load(groupPracticeLocationID);
				return gpNet.GroupPracticeID;
			}
		}
		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// track the change of statusID.
			this.terminatedTimeWhenLoaded = this.terminateTime;
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				
				if ((this.terminateTime != DateTime.MinValue) || (this.terminateTime != this.terminatedTimeWhenLoaded))
				{
					// status changed.
					this.SetTerminatingUser();
				}

				base.Save();

				if (this.EffectiveDatesHistory != null)
					this.SaveEffectiveDatesHistory();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPracticeLocationNetworkID)
		{
			return base.Load(groupPracticeLocationNetworkID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupPracticeLocationNetworkID)
		{
			base.Delete(groupPracticeLocationNetworkID);		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active		= true;
			this.asOfDate	= DateTime.Now;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}


		/// <summary>
		/// Parent GroupPracticeLocationNetworkLinkCollection that contains this element
		/// </summary>
		public GroupPracticeLocationNetworkLinkCollection ParentGroupPracticeLocationNetworkLinkCollection
		{
			get
			{
				return this.parentGroupPracticeLocationNetworkLinkCollection;
			}
			set
			{
				this.parentGroupPracticeLocationNetworkLinkCollection = value; // parent is set when added to a collection
			}
		}

		

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[FieldValuesMember("LookupOf_NetwokSearchID","NetworkID","Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup,ValueForNull=(int)0)]
		[FieldDescription("@NETWORKID@")]
		public int NetworkSearchID
		{
			get { return this.networkID; }
			set { this.NetworkID = value; }
		}

		public NetworkCollection LookupOf_NetwokSearchID
		{
			get
			{
				if (filterPlanID == 0)
					return NetworkCollection.Networks;
				else // Load Networks by PlanID
				{
					// Load by PlanID
					NetworkCollection netCol = new NetworkCollection();
					netCol.LoadAllNetworksByPlanID(this.filterPlanID);
					return netCol;
				}
			}
		}

		/// <summary>
		/// Child EffectiveDatesHistory mapped to related rows of table ProviderLocationNetworkHistory where [ProviderLocationNetworkID] = [ProviderLocationNetworkID]
		/// </summary>
		[SPLoadChild("usp_LoadGroupPracticeLocationNetworkLinkHistory", "groupPracticeLocationNetworkID")]
		public GroupPracticeLocationNetworkHistoryCollection EffectiveDatesHistory
		{
			get { return this.effectiveDatesHistory; }
			set
			{
				this.effectiveDatesHistory = value;
				if (value != null)
				{
					value.ParentGroupPracticeLocationNetworkLink = this; // set this as a parent of the child collection

				}	
			}
		}
		/// <summary>
		/// Loads the EffectiveDatesHistory collection
		/// </summary>
		public void LoadEffectiveDatesHistory(bool forceReload)
		{
			if (this.effectiveDatesHistory != null)
				this.effectiveDatesHistory.Clear();
			this.effectiveDatesHistory = (GroupPracticeLocationNetworkHistoryCollection)GroupPracticeLocationNetworkHistoryCollection.LoadChildCollection("EffectiveDatesHistory", this, typeof(GroupPracticeLocationNetworkHistoryCollection), effectiveDatesHistory, forceReload, null);

			// -- Add the current effective date from this record 
			// -- if removed, current effective date set on GPLocNetLink record wont be displayed
			// -- in the grid.
			GroupPracticeLocationNetworkHistory grpDate = new  GroupPracticeLocationNetworkHistory();
			grpDate.Active			= this.Active;
			grpDate.AsOfDate		= this.AsOfDate;
			grpDate.EffectiveDate	= this.EffectiveDate;
			grpDate.TerminationDate = this.TerminationDate;
			grpDate.IsNew = grpDate.IsDirty = false;
			this.effectiveDatesHistory.Add(grpDate);
		}
			
		/// <summary>
		/// Saves the EffectiveDatesHistory collection
		/// </summary>
		public void SaveEffectiveDatesHistory()
		{
			GroupPracticeLocationNetworkHistoryCollection.SaveChildCollection(this.effectiveDatesHistory, true);
		}
		
		/// <summary>
		/// Synchronizes the EffectiveDatesHistory collection
		/// </summary>
		public void SynchronizeEffectiveDatesHistory()
		{
			GroupPracticeLocationNetworkHistoryCollection.SynchronizeChildCollection(this.effectiveDatesHistory, true);
		}
		public GroupPracticeLocation GroupPracticeLocation
		{
			get
			{
				if(this.groupPracticeLocationID == 0)
					return null;
				if(this.groupPracticeLocation == null)
				{
					groupPracticeLocation = new GroupPracticeLocation();
					groupPracticeLocation.Load(groupPracticeLocationID);
					
				}
				return groupPracticeLocation;
			}
		}
	}
	
	/// <summary>
	/// Strongly typed collection of GroupPracticeLocationNetworkLink objects
	/// </summary>
	[ElementType(typeof(GroupPracticeLocationNetworkLink))]
	public class GroupPracticeLocationNetworkLinkCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		public const int MAXRECORDS = 10;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPracticeLocationNetworkLink elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeLocationNetworkLinkCollection = this;
			else
				elem.ParentGroupPracticeLocationNetworkLinkCollection = null;		
		}
		

		protected override void OnClear()
		{
			foreach (GroupPracticeLocationNetworkLink elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPracticeLocationNetworkLink this[int index]
		{
			get
			{
				return (GroupPracticeLocationNetworkLink)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPracticeLocationNetworkLink)oldValue, false);
			SetParentOnElem((GroupPracticeLocationNetworkLink)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent GroupPracticeLocation that contains this collection
		/// </summary>
		public GroupPracticeLocation ParentGroupPracticeLocation
		{
			get { return this.ParentDataObject as GroupPracticeLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GroupPracticeLocation */ }
		}

		/// <summary>
		/// Parent Network that contains this collection
		/// </summary>
		public Network ParentNetwork
		{
			get { return this.ParentDataObject as Network; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Network */ }
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GroupPracticeLocationNetworkLink elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeLocationNetworkLink)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPracticeLocationNetworkLink elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeLocationNetworkLink)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllNetworkByGroupPracticeLocationID(int maxRecords, int groupPracticeLocationID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllNetworkByGroupPracticeLocationID", maxRecords, this, false, groupPracticeLocationID);
		}

	}
}
