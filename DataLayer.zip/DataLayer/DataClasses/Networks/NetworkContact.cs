using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NetworkContact]
	/// </summary>
	[SPInsert("usp_InsertNetworkContact")]
	[SPLoad("usp_LoadNetworkContact")]
	[TableMapping("NetworkContact","networkID,contactID",true)]
	[TableLinkageAttribute(typeof(Network), "networkID", typeof(Contact), "contactID")]
	public class NetworkContact : BaseLinkageClass
	{
		[NonSerialized]
		private NetworkContactCollection parentNetworkContactCollection;
		[ColumnMapping("NetworkID",(int)0)]
		private int networkID;
		[ColumnMapping("ContactID",(int)0)]
		private int contactID;
	
		public NetworkContact()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NetworkID
		{
			get { return this.networkID; }
			set { this.networkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ContactID
		{
			get { return this.contactID; }
			set { this.contactID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent NetworkContactCollection that contains this element
		/// </summary>
		public NetworkContactCollection ParentNetworkContactCollection
		{
			get
			{
				return this.parentNetworkContactCollection;
			}
			set
			{
				this.parentNetworkContactCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of NetworkContact objects
	/// </summary>
	[ElementType(typeof(NetworkContact))]
	public class NetworkContactCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(NetworkContact elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNetworkContactCollection = this;
			else
				elem.ParentNetworkContactCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (NetworkContact elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public NetworkContact this[int index]
		{
			get
			{
				return (NetworkContact)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((NetworkContact)oldValue, false);
			SetParentOnElem((NetworkContact)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Network that contains this collection
		/// </summary>
		public Network ParentNetwork
		{
			get { return this.ParentDataObject as Network; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Network */ }
		}
	}
}
