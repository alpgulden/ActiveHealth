using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NetworkPlans]
	/// </summary>
	[SPInsert("usp_InsertNetworkPlan")]
	[SPUpdate("usp_UpdateNetworkPlan")]
	[SPDelete("usp_DeleteNetworkPlan")]
	[SPLoad("usp_LoadNetworkPlan")]
	[TableMapping("NetworkPlans","networkPlanID")]
	public class NetworkPlan : BaseData
	{
		[NonSerialized]
		private NetworkPlanCollection parentNetworkPlanCollection;
		[ColumnMapping("NetworkPlanID",(int)0)]
		private int networkPlanID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("NoteID")]
		private int noteID;
		[ColumnMapping("PreferenceLevel")]
		private int preferenceLevel;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("NetworkID")]
		private int networkID;
		[ColumnMapping("PlanId")]
		private int planId;
	
		public NetworkPlan()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NetworkPlanID
		{
			get { return this.networkPlanID; }
			set { this.networkPlanID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=100)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int NoteID
		{
			get { return this.noteID; }
			set { this.noteID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PreferenceLevel
		{
			get { return this.preferenceLevel; }
			set { this.preferenceLevel = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int NetworkID
		{
			get { return this.networkID; }
			set { this.networkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int networkPlanID)
		{
			return base.Load(networkPlanID);
		}

		/// <summary>
		/// Parent NetworkPlanCollection that contains this element
		/// </summary>
		public NetworkPlanCollection ParentNetworkPlanCollection
		{
			get
			{
				return this.parentNetworkPlanCollection;
			}
			set
			{
				this.parentNetworkPlanCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of NetworkPlan objects
	/// </summary>
	[ElementType(typeof(NetworkPlan))]
	public class NetworkPlanCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(NetworkPlan elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNetworkPlanCollection = this;
			else
				elem.ParentNetworkPlanCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (NetworkPlan elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public NetworkPlan this[int index]
		{
			get
			{
				return (NetworkPlan)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((NetworkPlan)oldValue, false);
			SetParentOnElem((NetworkPlan)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(NetworkPlan elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((NetworkPlan)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
