using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for NetworkPlanSummary.
	/// </summary>
	[TableMapping(null,"NetworkPlanID")]
	public class NetworkPlanSummary:BaseData
	{
		[ColumnMapping("AddressID",StereoType=DataStereoType.FK)]
		private int addressID;
		[ColumnMapping("Line1")]
		private string line1;
		[ColumnMapping("Line2")]
		private string line2;
		[ColumnMapping("City")]
		private string city;
		[ColumnMapping("State")]
		private string state;
		[ColumnMapping("Zip",StereoType=DataStereoType.USZipCode)]
		private string zip;
		[ColumnMapping("County")]
		private string county;
		[ColumnMapping("Country")]
		private string country;
		[NonSerialized]
		private NetworkPlanSummaryCollection parentNetworkPlanSummaryCollection;
		[ColumnMapping("NetworkPlanID",StereoType=DataStereoType.FK)]
		private int networkPlanID;
		[ColumnMapping("PreferenceLevel",StereoType=DataStereoType.FK)]
		private int preferenceLevel;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)]
		private int planId;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("AlternatePlanId")]
		private string alternatePlanId;
		[ColumnMapping("Name")]
		private string name;
	
		public NetworkPlanSummary()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int NetworkPlanID
		{
			get { return this.networkPlanID; }
			set { this.networkPlanID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PreferenceLevel
		{
			get { return this.preferenceLevel; }
			set { this.preferenceLevel = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		/// <summary>
		/// Parent NetworkPlanSummaryCollection that contains this element
		/// </summary>
		public NetworkPlanSummaryCollection ParentNetworkPlanSummaryCollection
		{
			get
			{
				return this.parentNetworkPlanSummaryCollection;
			}
			set
			{
				this.parentNetworkPlanSummaryCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Line1
		{
			get { return this.line1; }
			set { this.line1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Line2
		{
			get { return this.line2; }
			set { this.line2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string City
		{
			get { return this.city; }
			set { this.city = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string State
		{
			get { return this.state; }
			set { this.state = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USZipCode, MaxLength=10)]
		public string Zip
		{
			get { return this.zip; }
			set { this.zip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string County
		{
			get { return this.county; }
			set { this.county = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Country
		{
			get { return this.country; }
			set { this.country = value; }
		}


		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		public  string Address
		{
			get
			{
				return
					this.line1 + "\r\n" +
					this.line2 + "\r\n" + 
					this.city + ", " + this.County + ", " + this.State + ", " + this.Zip + "\r\n" +
					this.Country ;
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternatePlanId
		{
			get { return this.alternatePlanId; }
			set { this.alternatePlanId = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of NetworkPlanSummary objects
	/// </summary>
	[ElementType(typeof(NetworkPlanSummary))]
	public class NetworkPlanSummaryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		public int LoadPlanNetworkSummary(int maxRecords,int networkID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPlanNetworkSummary", maxRecords, this, false,new object[]{networkID});
		}

	}
}
