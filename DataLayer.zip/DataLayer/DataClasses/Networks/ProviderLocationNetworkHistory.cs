using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProviderLocationNetworkHistory]
	/// </summary>
	[SPInsert("usp_InsertProviderLocationNetworkHistory")]
	[SPUpdate("usp_UpdateProviderLocationNetworkHistory")]
	[SPDelete("usp_DeleteProviderLocationNetworkHistory")]
	[SPLoad("usp_LoadProviderLocationNetworkHistory")]
	[TableMapping("ProviderLocationNetworkHistory","providerLocationNetworkHistoryID")]
	public class ProviderLocationNetworkHistory : BaseData
	{
		[NonSerialized]
		private ProviderLocationNetworkHistoryCollection parentProviderLocationNetworkHistoryCollection;
		[ColumnMapping("ProviderLocationNetworkHistoryID",(int)0)]
		private int providerLocationNetworkHistoryID;
		[ColumnMapping("ProviderLocationNetworkID",(int)0)]
		private int providerLocationNetworkID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("TerminatedBy",(int)0)]
		private int terminatedBy;
		[ColumnMapping("Active")]
		private bool active;
		
		
	
		public ProviderLocationNetworkHistory()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ProviderLocationNetworkHistoryID
		{
			get { return this.providerLocationNetworkHistoryID; }
			set { this.providerLocationNetworkHistoryID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ProviderLocationNetworkID
		{
			get { return this.providerLocationNetworkID; }
			set { this.providerLocationNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int providerLocationNetworkHistoryID)
		{
			return base.Load(providerLocationNetworkHistoryID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int providerLocationNetworkHistoryID)
		{
			base.Delete(providerLocationNetworkHistoryID);		
		}

		/// <summary>
		/// Parent ProviderLocationNetworkHistoryCollection that contains this element
		/// </summary>
		public ProviderLocationNetworkHistoryCollection ParentProviderLocationNetworkHistoryCollection
		{
			get
			{
				return this.parentProviderLocationNetworkHistoryCollection;
			}
			set
			{
				this.parentProviderLocationNetworkHistoryCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ProviderLocationNetworkHistory objects
	/// </summary>
	[ElementType(typeof(ProviderLocationNetworkHistory))]
	public class ProviderLocationNetworkHistoryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProviderLocationNetworkHistory elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProviderLocationNetworkHistoryCollection = this;
			else
				elem.ParentProviderLocationNetworkHistoryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProviderLocationNetworkHistory elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProviderLocationNetworkHistory this[int index]
		{
			get
			{
				return (ProviderLocationNetworkHistory)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProviderLocationNetworkHistory)oldValue, false);
			SetParentOnElem((ProviderLocationNetworkHistory)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ProviderLocationNetworkHistory elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ProviderLocationNetworkHistory)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(ProviderLocationNetworkHistory elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((ProviderLocationNetworkHistory)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Update the Status for Provider Location Network table for the given providerLocationNetworkID based on the effective and Termination dates.
		/// </summary>
		public int UpdateStatusForProviderLocationNetworkHistory(int maxRecords, ProviderLocationNetworkHistory  provLocationNetworkhistory,int providerLocationNetworkID)
		{
			this.Clear();
			return SqlData.SPExecNonQuery("usp_UpdateStatusForProviderLocationNetworkHistory1",provLocationNetworkhistory,false,
				new string[] { "providerLocationNetworkID" },
				new object[] { providerLocationNetworkID } );
			//return SqlData.SPExecNonQuery("usp_UpdateStatusForProviderLocationNetworkHistory", maxRecords, this, provLocationNetwork, false);
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();
			//UpdateStatusForProviderLocationNetworkHistory
			
		}

		/* Don't use this.
		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL( object param)
		{
			SQLParser sql = new SQLParser("select * from [ProviderLocationNetworkHistory] " +
			"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/
		
		/// <summary>
		/// Parent ProviderLocationNetworkLink that contains this collection
		/// </summary>
		public ProviderLocationNetworkLink ParentProviderLocationNetworkLink
		{
			get { return this.ParentDataObject as ProviderLocationNetworkLink; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ProviderLocationNetworkLink */ }
		}
	}
}
