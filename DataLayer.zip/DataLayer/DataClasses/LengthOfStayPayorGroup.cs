using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LengthOfStayPayorGroups]
	/// </summary>
	[SPAutoGen("usp_GetAllLengthOfStayPayorGroups","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetLengthOfStayPayorGroupsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertLengthOfStayPayorGroup")]
	[SPUpdate("usp_UpdateLengthOfStayPayorGroup")]
	[SPDelete("usp_DeleteLengthOfStayPayorGroup")]
	[SPLoad("usp_LoadLengthOfStayPayorGroup")]
	[TableMapping("LengthOfStayPayorGroup","lengthOfStayPayorGroupID")]
	public class LengthOfStayPayorGroup : BaseLookupWithSubCodeSTR
	{
		[NonSerialized]
		private LengthOfStayPayorGroupCollection parentLengthOfStayPayorGroupCollection;
		[ColumnMapping("LengthOfStayPayorGroupID",StereoType=DataStereoType.FK)]
		private int lengthOfStayPayorGroupID;
		[ColumnMapping("Notepad")]
		private string notepad;
		[ColumnMapping("HCIAGroup")]
		private string hCIAGroup;
	
		public LengthOfStayPayorGroup()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int LengthOfStayPayorGroupID
		{
			get { return this.lengthOfStayPayorGroupID; }
			set { this.lengthOfStayPayorGroupID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int lengthOfStayPayorGroupID)
		{
			return base.Load(lengthOfStayPayorGroupID);
		}

		/// <summary>
		/// Parent LengthOfStayPayorGroupCollection that contains this element
		/// </summary>
		public LengthOfStayPayorGroupCollection ParentLengthOfStayPayorGroupCollection
		{
			get
			{
				return this.parentLengthOfStayPayorGroupCollection;
			}
			set
			{
				this.parentLengthOfStayPayorGroupCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string HCIAGroup
		{
			get { return this.hCIAGroup; }
			set { this.hCIAGroup = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=200)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldValuesMember("ValueOf_SubCodeStr")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		[FieldDescription("@HCIAGROUP@")]
		public override string SubCodeStr
		{
			get { return this.hCIAGroup;}
			set	{ this.hCIAGroup = value; }
		}

		public object [,] ValueOf_SubCodeStr
		{
			get
			{
				return new object[,] {{"N","Not Applicable"},{"3","BC Private Insurance"},{"2","Medicaid"},{"1","Medicare"},{"0","None"},{"5","Workers Compensation"}};
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of LengthOfStayPayorGroup objects
	/// </summary>
	[ElementType(typeof(LengthOfStayPayorGroup))]
	public class LengthOfStayPayorGroupCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_HCIAGroup;
		[NonSerialized]
		private CollectionIndexer indexBy_LengthOfStayPayorGroupID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LengthOfStayPayorGroup elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLengthOfStayPayorGroupCollection = this;
			else
				elem.ParentLengthOfStayPayorGroupCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LengthOfStayPayorGroup elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LengthOfStayPayorGroup this[int index]
		{
			get
			{
				return (LengthOfStayPayorGroup)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LengthOfStayPayorGroup)oldValue, false);
			SetParentOnElem((LengthOfStayPayorGroup)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadLengthOfStayPayorGroupsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetLengthOfStayPayorGroupsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared LengthOfStayPayorGroupCollection which is cached in NSGlobal
		/// </summary>
		public static LengthOfStayPayorGroupCollection ActiveLengthOfStayPayorGroups
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LengthOfStayPayorGroupCollection col = (LengthOfStayPayorGroupCollection)NSGlobal.EnsureCachedObject("ActiveLengthOfStayPayorGroups", typeof(LengthOfStayPayorGroupCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadLengthOfStayPayorGroupsByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on lengthOfStayPayorGroupID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_LengthOfStayPayorGroupID
		{
			get
			{
				if (this.indexBy_LengthOfStayPayorGroupID == null)
					this.indexBy_LengthOfStayPayorGroupID = new CollectionIndexer(this, new string[] { "lengthOfStayPayorGroupID" }, true);
				return this.indexBy_LengthOfStayPayorGroupID;
			}
			
		}

		/// <summary>
		/// Looks up by lengthOfStayPayorGroupID and returns HCIAGroup value.  Uses the IndexBy_LengthOfStayPayorGroupID indexer.
		/// </summary>
		public string Lookup_HCIAGroupByLengthOfStayPayorGroupID(int lengthOfStayPayorGroupID)
		{
			return this.IndexBy_LengthOfStayPayorGroupID.LookupStringMember("HCIAGroup", lengthOfStayPayorGroupID);
		}

		/// <summary>
		/// Hashtable based index on hCIAGroup fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_HCIAGroup
		{
			get
			{
				if (this.indexBy_HCIAGroup == null)
					this.indexBy_HCIAGroup = new CollectionIndexer(this, new string[] { "hCIAGroup" }, true);
				return this.indexBy_HCIAGroup;
			}
		}

		/// <summary>
		/// Looks up by hCIAGroup and returns LengthOfStayPayorGroupID value.  Uses the IndexBy_HCIAGroup indexer.
		/// </summary>
		public int Lookup_LengthOfStayPayorGroupIDByHCIAGroup(string hCIAGroup)
		{
			return this.IndexBy_HCIAGroup.LookupIntMember("LengthOfStayPayorGroupID", hCIAGroup);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllLengthOfStayPayorGroups", -1, this, false);
		}

		/// <summary>
		/// Looks up by lengthOfStayPayorGroupID and returns Code value.  Uses the IndexBy_LengthOfStayPayorGroupID indexer.
		/// </summary>
		public string Lookup_CodeByLengthOfStayPayorGroupID(int lengthOfStayPayorGroupID)
		{
			return this.IndexBy_LengthOfStayPayorGroupID.LookupStringMember("Code", lengthOfStayPayorGroupID);
		}
	}
}
