using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [FacilityFocusTypes]
	/// </summary>
	[SPAutoGen("usp_SearchFacilityFocusTypes","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllFacilityFocusTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetFacilityFocusTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertFacilityFocusType")]
	[SPUpdate("usp_UpdateFacilityFocusType")]
	[SPDelete("usp_DeleteFacilityFocusType")]
	[SPLoad("usp_LoadFacilityFocusType")]
	[TableMapping("FacilityFocusType","facilityFocusTypeID")]
	public class FacilityFocusType : BaseLookupWithNote
	{
		[NonSerialized]
		private FacilityFocusTypeCollection parentFacilityFocusTypeCollection;
		[ColumnMapping("FacilityFocusTypeID",(int)0)]
		private int facilityFocusTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public FacilityFocusType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int FacilityFocusTypeID
		{
			get { return this.facilityFocusTypeID; }
			set { this.facilityFocusTypeID = value; }
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int facilityFocusTypeID)
		{
			return base.Load(facilityFocusTypeID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int facilityFocusTypeID)
		{
			base.Delete(facilityFocusTypeID);		
		}

		/// <summary>
		/// Parent FacilityFocusTypeCollection that contains this element
		/// </summary>
		public FacilityFocusTypeCollection ParentFacilityFocusTypeCollection
		{
			get
			{
				return this.parentFacilityFocusTypeCollection;
			}
			set
			{
				this.parentFacilityFocusTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active	= true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of FacilityFocusType objects
	/// </summary>
	[ElementType(typeof(FacilityFocusType))]
	public class FacilityFocusTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(FacilityFocusType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentFacilityFocusTypeCollection = this;
			else
				elem.ParentFacilityFocusTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (FacilityFocusType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public FacilityFocusType this[int index]
		{
			get
			{
				return (FacilityFocusType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((FacilityFocusType)oldValue, false);
			SetParentOnElem((FacilityFocusType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetFacilityFocusTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetFacilityFocusTypesByActive", maxRecords, this, false,new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared FacilityFocusTypeCollection which is cached in NSGlobal
		/// </summary>
		public static FacilityFocusTypeCollection ActiveFacilityFocusTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				FacilityFocusTypeCollection col = (FacilityFocusTypeCollection)NSGlobal.EnsureCachedObject("ActiveFacilityFocusTypes", typeof(FacilityFocusTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetFacilityFocusTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Load all Facility Focus Types.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllFacilityFocusTypes", -1, this, false);
		}

		/// <summary>
		///  Searches for Focus Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchFacilityFocusTypes", -1, this, false, code, description, active);
		}
	}
}
