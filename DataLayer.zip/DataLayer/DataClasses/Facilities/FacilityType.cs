using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [FacilityTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllFacilityTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetFacilityTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertFacilityType")]
	[SPUpdate("usp_UpdateFacilityType")]
	[SPDelete("usp_DeleteFacilityType")]
	[SPLoad("usp_LoadFacilityType")]
	[TableMapping("FacilityType","facilityTypeID")]
	public class FacilityType : BaseLookupWithNote
	{
		[NonSerialized]
		private FacilityTypeCollection parentFacilityTypeCollection;
		[ColumnMapping("FacilityTypeID",(int)0)]
		private int facilityTypeID;
		[ColumnMapping("NotePad")]
		private string notePad;

		public FacilityType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int FacilityTypeID
		{
			get { return this.facilityTypeID; }
			set { this.facilityTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
		
		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		} 

		/// <summary>
		/// Parent FacilityTypeCollection that contains this element
		/// </summary>
		public FacilityTypeCollection ParentFacilityTypeCollection
		{
			get
			{
				return this.parentFacilityTypeCollection;
			}
			set
			{
				this.parentFacilityTypeCollection = value; // parent is set when added to a collection
			}
		}


		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int facilityTypeID)
		{
			return base.Load(facilityTypeID);
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int facilityTypeID)
		{
			base.Delete(facilityTypeID);		
		}



		/// <summary>
		/// Returns the Facility type description for the given type ID.
		/// </summary>
		/// <param name="providerID"></param>
		/// <returns></returns>
		public static string GetFacilityTypeByID(int facilityTypeID)
		{
			if (facilityTypeID == 0)
				return null;
			FacilityType facilityType = new FacilityType();
			if (facilityType.Load(facilityTypeID))
				return facilityType.Description;
			else
				return null;
		}

	}

	/// <summary>
	/// Strongly typed collection of FacilityType objects
	/// </summary>
	[ElementType(typeof(FacilityType))]
	public class FacilityTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(FacilityType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentFacilityTypeCollection = this;
			else
				elem.ParentFacilityTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (FacilityType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public FacilityType this[int index]
		{
			get
			{
				return (FacilityType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((FacilityType)oldValue, false);
			SetParentOnElem((FacilityType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(FacilityType elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((FacilityType)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(FacilityType elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((FacilityType)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadFacilityTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetFacilityTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared FacilityTypeCollection which is cached in NSGlobal
		/// </summary>
		public static FacilityTypeCollection ActiveFacilityTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				FacilityTypeCollection col = (FacilityTypeCollection)NSGlobal.EnsureCachedObject("ActiveFacilityTypes", typeof(FacilityTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadFacilityTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		public override  void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllFacilityTypes", -1, this, false);
		}

		/// <summary>
		///   Searches for Facility Types matching the given criteria.
		/// </summary>
		/// 
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchFacilityTypes", -1, this, false, code, description, active);
		}

	}
}
