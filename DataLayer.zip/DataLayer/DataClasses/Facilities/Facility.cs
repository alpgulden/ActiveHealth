using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Facilities]
	/// </summary>
	[SPAutoGen("usp_GetFacilitiyByAlternateID","SelectAllByGivenArgs.sptpl","alternateID")]
	[SPExists("usp_ExistsFacility")]
	[SPInsert("usp_InsertFacility")]
	[SPUpdate("usp_UpdateFacility")]
	[SPDelete("usp_DeleteFacility")]
	[SPLoad("usp_LoadFacility")]
	[TableMapping("Facility","facilityID")]
	public class Facility : BaseDataWithUserDefined
	{

		[NonSerialized]
		private FacilityCollection parentFacilityCollection;
		[ColumnMapping("AlternateID")]
		private string alternateID;
		[ColumnMapping("Name")]
		private string name;
		[ColumnMapping("AddedOnTheFly")]
		private bool addedOnTheFly;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("DateActive")]
		private DateTime dateActive;
		[ColumnMapping("CreatedBy",(int)0)]
		private int createdBy;
		[ColumnMapping("FacilityID",(int)0)]
		private int facilityID;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",(int)0)]
		private int modifiedBy;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("FacilityTypeID",(int)0)]
		private int facilityTypeID;
		[ColumnMapping("Email")]
		private string email;
		[ColumnMapping("StatusChangetime")]
		private DateTime statusChangetime;
		[ColumnMapping("StatusChangedBy",(int)0)]
		private int statusChangedBy;
		[ColumnMapping("DeliveryMethod")]
		private string deliveryMethod;
		[ColumnMapping("FaxNumber")]
		private string faxNumber;
		private FacilityLocationCollection locations;
		private FacilityFocusCollection focuses;
		private bool activeStatusWhenLoaded;

		[ColumnMapping("CreatedByName", JoinColumn="LoginName", JoinRelation="Facility.CreatedBy = [AAUser].UserId", SQLGen=SQLGenerationFlags.NoInsert|SQLGenerationFlags.NoUpdate|SQLGenerationFlags.NoSelect)]
		private string createdByStr;
		[ColumnMapping("ModifiedByName", JoinColumn="LoginName", JoinRelation="Facility.ModifiedBy = [AAUser].UserId", SQLGen=SQLGenerationFlags.NoInsert|SQLGenerationFlags.NoUpdate|SQLGenerationFlags.NoSelect)]
		private string modifiedByStr;

		public string CreatedByStr
		{
			get { return this.createdByStr; }
		}

		public string ModifiedByStr
		{
			get { return this.modifiedByStr; }
		}

		[ColumnMapping("StatusChangedByName", JoinColumn="LoginName", JoinRelation="Facility.StatusChangedBy = [AAUser].UserId", SQLGen=SQLGenerationFlags.NoInsert|SQLGenerationFlags.NoUpdate|SQLGenerationFlags.NoSelect)]
		private string statusChangedByStr;
		public string StatusChangedByStr
		{
			get { return this.statusChangedByStr; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=10,ClientScriptForConditionalRequired="GetElemValue('DeliveryMethodStr') == 'F'", IsRequired=true)]
		public string FaxNumber
		{
			get { return this.faxNumber; }
			set { this.faxNumber = value; }
		}
		
		public Facility(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public Facility()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		[FieldValuesMember("LookupOf_TypeID", "FacilityTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup,ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@FACILITYTYPEID@")]
		public int TypeID
		{
			get { return this.facilityTypeID ; }
			set { this.facilityTypeID = value; }
		}
		
		public FacilityTypeCollection LookupOf_TypeID
		{
			get
			{
				return FacilityTypeCollection.ActiveFacilityTypes ; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public string FacilityType
		{
			get 
			{
				FacilityType facType = new FacilityType();
				facType.Load(this.FacilityTypeID);
				return facType.Description;
			}
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		[FieldDescription("@FACILITYID@")]
		public int FacilityID
		{
			get { return this.facilityID; }
			set { this.facilityID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		[FieldDescription("@ALTERNATEID@")]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		[FieldDescription("@NAME@")]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

	
		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@ADDEDONFLY@")]
		public bool AddedOnTheFly
		{
			get { return this.addedOnTheFly; }
			set { this.addedOnTheFly = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@ACTIVE@")]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DATEACTIVE@")]
		public System.DateTime DateActive
		{
			get { return this.dateActive; }
			set { this.dateActive = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		[FieldDescription("@NOTE@")]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		/*[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@MODIFYTIME@")]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}*/

		[FieldValuesMember("LookupOf_FacilityTypeID", "FacilityTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@FACILITYTYPE@")]
		public int FacilityTypeID
		{
			get { return this.facilityTypeID; }
			set { this.facilityTypeID = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}
		

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			
			if (FacilityID == 0)
				return;
			
			writer.AddFieldsOnNewLine(this, "FacilityID",  "Name");			
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// track the change of statusID.
			this.activeStatusWhenLoaded = this.active;
		}

		protected override void InternalSave()
		{
			try
			{
				if (this.FacilityID != 0) // update
				{
					//this.SqlData.EnsureTransaction();
					try
					{
						if (this.active != this.activeStatusWhenLoaded)
						{
							// status changed.
							this.SetStatusChangingUser();
						}

						base.InternalSave();

						this.SaveFocuses();
						this.SaveLocations();
						
						/*
						if (Focuses != null)
						{
							// Update Focuses
							for (int i=0; i < this.Focuses.Count; i++)
								focuses[i].FacilityID = this.FacilityID;
								this.SaveFocuses();
						}*/


						/*
						if (this.Locations  != null)
						{
							this.SaveLocations();
						}
						*/
						//this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
					}
					catch(Exception ex)
					{
						//this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
						// Failure handling code here
						string msg = ex.Message;
						throw; // always re-throw exception to notify the client
					}	

					
				}
				else // New Record
				{
					
					try
					{
						
						base.InternalSave();
						//this.SqlData.EnsureTransaction();
						this.LoadLocations(false);
						// Add New Location
						AddEmptyLocation();
						this.Locations[0].FacilityID = this.FacilityID;
						
						this.SaveLocations();

						/*
						if (Focuses != null)
						{
							// Update Focuses
							for (int i=0; i < this.Focuses.Count; i++)
								focuses[i].FacilityID = this.FacilityID;
						}*/

						//this.focuses.SqlData.Transaction = this.SqlData.Transaction;
						this.SaveFocuses();

						//this.sqlData.CommitTransaction();
						/*this.groupPracticeLinks.SqlData.UseTransaction(this.sqlData.Transaction);
						this.groupPracticeLinks.Save();*/
					}
					catch (Exception ex)
					{
						//this.sqlData.RollbackTransaction();
						string msg = ex.Message;
						throw;
					}
				}
				
			}
			catch (Exception ex)
			{
				throw new Exception("An error occured while updating Facility: " + ex.Message);
			}
		}

		/// <summary>
		///  Adds a new, empty location to Locations collection.
		///  It is used for newly inserted Providers (must have one location).
		/// </summary>
		private void AddEmptyLocation()
		{
			Address servAddr = new Address();
			Address billAddr = new Address();
			Address mailAddr = new Address();
			Location loc = new Location();
			loc.New();
			
			loc.BillingAddress = billAddr;
			loc.BillingAddress.New();
			loc.ServiceAddress = servAddr;
			loc.ServiceAddress.New();
			loc.MailingAddress = mailAddr;
			loc.MailingAddress.New();


			FacilityLocation facLoc = new FacilityLocation(true);
			//facLoc.New();
			// Created By Info. Replace the 1 with actual code.
			facLoc.CreateTime		 = DateTime.Now;
			facLoc.CreatedBy		 = 1;
			facLoc.Location			 = loc;
			

			this.Locations.Add(facLoc);
		}

	


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int facilityID)
		{
			bool result = false;
			result = base.Load(facilityID);
			this.LoadLocations(false);
			return result;
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int facilityID)
		{
			base.Delete(facilityID);		
		}

		public FacilityTypeCollection LookupOf_FacilityTypeID
		{
			get
			{
				return FacilityTypeCollection.ActiveFacilityTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		/// <summary>
		/// Child Locations mapped to related rows of table FacilityLocations where [FacilityID] = [FacilityID]
		/// </summary>
		[SPLoadChild("usp_LoadFacilityLocations", "facilityID")]
		public FacilityLocationCollection Locations
		{
			get { return this.locations; }
			set
			{
				this.locations = value;
				value.ParentFacility = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Locations collection
		/// </summary>
		public void LoadLocations(bool forceReload)
		{
			this.locations = (FacilityLocationCollection)FacilityLocationCollection.LoadChildCollection("Locations", this, typeof(FacilityLocationCollection), locations, forceReload, null);
		}

		/// <summary>
		/// Saves the Locations collection
		/// </summary>
		public void SaveLocations()
		{
			FacilityLocationCollection.SaveChildCollection(this.locations, true);
		}

		/// <summary>
		/// Synchronizes the Locations collection
		/// </summary>
		public void SynchronizeLocations()
		{
			FacilityLocationCollection.SynchronizeChildCollection(this.locations, true);
		}

		/// <summary>
		/// Child Focuses mapped to related rows of table FacilityFocuses where [FacilityID] = [FacilityID]
		/// </summary>
		[SPLoadChild("usp_LoadFacilityFocuses", "facilityID")]
		public FacilityFocusCollection Focuses
		{
			get { return this.focuses; }
			set
			{
				this.focuses = value;
				value.ParentFacility = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Focuses collection
		/// </summary>
		public void LoadFocuses(bool forceReload)
		{
			this.focuses = (FacilityFocusCollection)FacilityFocusCollection.LoadChildCollection("Focuses", this, typeof(FacilityFocusCollection), focuses, forceReload, null);
		}

		/// <summary>
		/// Saves the Focuses collection
		/// </summary>
		public void SaveFocuses()
		{
			FacilityFocusCollection.SaveChildCollection(this.focuses, true);
		}

		/// <summary>
		/// Synchronizes the Focuses collection
		/// </summary>
		public void SynchronizeFocuses()
		{
			FacilityFocusCollection.SynchronizeChildCollection(this.focuses, true);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active	= true;
			
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}
		
		//[ValidatorMember("vldEmail")]
		[ControlType(Macro=EnumControlTypeMacros.Email, MaxLength=255, ClientScriptForConditionalRequired="GetElemValue('DeliveryMethodStr') == 'E'", IsRequired=true)]
		[FieldDescription("@EMAIL@")]
		public string Email
		{
			get { return this.email; }
			set { this.email = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StatusChangeTime
		{
			get { return this.statusChangetime ; }
			set { this.statusChangetime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1, ClientValidators=EnumClientValidators.Required)]
		public string DeliveryMethod
		{
			get { return this.deliveryMethod; }
			set { this.deliveryMethod = value; }
		}
		[FieldValuesMember("ValuesOf_DeliveryMethodStr")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@DELIVERYMETHOD@")]
		public string DeliveryMethodStr
		{
			get { return this.deliveryMethod ; }
			set { this.deliveryMethod = value; }
		}
		/// <summary>
		/// Returns all possible values and descriptions for delivery methods
		/// </summary>
		public string[,] ValuesOf_DeliveryMethodStr
		{
			get
			{
				return new string[,] { 
					{ "E", EnumDeliveryMethod.Email.ToString() },
					{ "F", EnumDeliveryMethod.Fax.ToString() },
					{ "M", EnumDeliveryMethod.Mail.ToString() } }; // return possible field values
			}
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state
		}

		/// <summary>
		/// Parent FacilityCollection that contains this element
		/// </summary>
		public FacilityCollection ParentFacilityCollection
		{
			get
			{
				return this.parentFacilityCollection;
			}
			set
			{
				this.parentFacilityCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Returns the Facility name for the given facility ID.
		/// </summary>
		/// <param name="facilityID"></param>
		/// <returns></returns>
		public static string GetFacilityNameByID(int facilityID)
		{
			if (facilityID == 0)
				return null;
			Facility facility = new Facility();
			if (facility.Load(facilityID))
				return facility.Name;
			else
				return null;
		}

		public static string GetFacilityFaxByID(int facilityID)
		{
			if (facilityID == 0)
				return null;
			Facility facility = new Facility();
			if (facility.Load(facilityID))
				return facility.FaxNumber;
			else
				return null;
		}

		public static string GetServiceLocationPhoneByFacilityLocationID(int facilityLocationID)
		{
			if (facilityLocationID == 0)
				return null;
			FacilityLocation facloc = new FacilityLocation();
			if(!facloc.Load(facilityLocationID))
				return null;
			return facloc.Phone;
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadFacilityByAlternateID(string alternateID)
		{
			return SqlData.SPExecReadObj("usp_GetFacilitiyByAlternateID", this, false, new object[] { alternateID });
		}
}

	/// <summary>
	/// Strongly typed collection of Facility objects
	/// </summary>
	[ElementType(typeof(Facility))]
	public class FacilityCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		public const int MAXRECORDS = 10;

		/// <summary>
		/// Accessor to a shared FacilityCollection which is cached in NSGlobal
		/// </summary>
		public static FacilityCollection Facilities
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				FacilityCollection col = (FacilityCollection)NSGlobal.EnsureCachedObject("Facilities", typeof(FacilityCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.Clear();
				}
				return col;
			}
		}
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Facility elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentFacilityCollection = this;
			else
				elem.ParentFacilityCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Facility elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Facility this[int index]
		{
			get
			{
				return (Facility)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Facility)oldValue, false);
			SetParentOnElem((Facility)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, Facility elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Facility)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Facility elem)
		{
			return AddRecord(elem);
		}
		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(Facility elem)
		{
			RemoveRecord(elem);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchFacilities(int startFacilityId, string startName, Facility facilityInfo,FacilityLocationNetworkLink facilityNetwork,NetworkPlanLink netPlan,FacilityFocus facilityFocus,FacilityLocationService facilityService,Address facilityLocation, string federaltaxid)
		{
			int maxRecords = MAXRECORDS;
			netPlan.NetworkID = facilityNetwork.NetwokSearchID;
			object [] prms = {facilityInfo, facilityFocus, facilityService, facilityLocation, facilityNetwork, netPlan};
			this.Clear();
			if (netPlan.PlanId == 0)
				return SqlData.SPExecReadCol("usp_SearchFacilities", -1,this, prms, true,
					new string[] { "rowCount", "startFacilityId", "startName", "effectiveDate", "AlternateID", "federaltaxid" },
					new object[] { maxRecords < 0 ? 0 : maxRecords, startFacilityId, startName, SQLDataDirect.MakeDBValue(facilityNetwork.EffectiveDate), facilityInfo.AlternateID, federaltaxid });
			else
				return SqlData.SPExecReadCol("usp_SearchFacilityByPlanID", -1, this, prms, true,
					new string[] { "rowCount", "startFacilityId", "startName", "AlternateID", "federaltaxid"},
					new object[] { maxRecords < 0 ? 0 : maxRecords, startFacilityId, startName, facilityInfo.AlternateID, federaltaxid });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadFacilitiyByAlternateID(int maxRecords, string alternateID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetFacilitiyByAlternateID", maxRecords, this, false, new object[] { alternateID });
		}
	}
}
