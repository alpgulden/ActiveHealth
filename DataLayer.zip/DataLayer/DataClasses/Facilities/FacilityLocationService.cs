using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [FacilityLocationServices]
	/// </summary>
	[SPInsert("usp_InsertFacilityLocationService")]
	[SPUpdate("usp_UpdateFacilityLocationService")]
	[SPDelete("usp_DeleteFacilityLocationService")]
	[SPLoad("usp_LoadFacilityLocationService")]
	[TableMapping("FacilityLocationService","facilityLocationServiceID")]
	public class FacilityLocationService : BaseData
	{
		[NonSerialized]
		private FacilityLocationServiceCollection parentFacilityLocationServiceCollection;
		[ColumnMapping("FacilityLocationServiceID",(int)0)]
		private int facilityLocationServiceID;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy", (int)0)]
		private int createdBy;
		[ColumnMapping("FacilityLocationID")]
		private int facilityLocationID;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("TerminatedBy", (int)0)]		// must define value for null, otherwise it'll try to write 0 to db!
		private int terminatedBy;
		[ColumnMapping("FacilityLocationServiceTypeID")]
		private int facilityLocationServiceTypeID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
	
		public FacilityLocationService()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@FACILITYLOCATIONSERVICEID@")]
		public int FacilityLocationServiceID
		{
			get { return this.facilityLocationServiceID; }
			set { this.facilityLocationServiceID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@CREATETIME@")]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@CREATEDBY@")]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@FACILITYLOCATIONID@")]
		public int FacilityLocationID
		{
			get { return this.facilityLocationID; }
			set { this.facilityLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@TERMDATE@")]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@TERMINATEDBY@")]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[FieldValuesMember("LookupOf_FacilityLocationServiceTypeID", "FacilityLocationServiceTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@FACILITYLOCSERVICETYPE@")]
		public int FacilityLocationServiceTypeID
		{
			get { return this.facilityLocationServiceTypeID; }
			set { this.facilityLocationServiceTypeID = value; }
		}
		public string DateCreated
		{
			get { return this.CreateTime.Date.ToShortDateString(); }
		}

		public string Description
		{
			get 
			{
				FacilityLocationServiceType provServType = new FacilityLocationServiceType();
				provServType.Load(this.FacilityLocationServiceTypeID );
				return provServType.Description;
			}
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int facilityLocationServiceID)
		{
			return base.Load(facilityLocationServiceID);
		}
		
		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int facilityLocationServiceID)
		{
			base.Delete(facilityLocationServiceID);		
		}

		/// <summary>
		/// Parent FacilityLocationServiceCollection that contains this element
		/// </summary>
		public FacilityLocationServiceCollection ParentFacilityLocationServiceCollection
		{
			get
			{
				return this.parentFacilityLocationServiceCollection;
			}
			set
			{
				this.parentFacilityLocationServiceCollection = value; // parent is set when added to a collection
			}
		}

		public FacilityLocationServiceTypeCollection LookupOf_FacilityLocationServiceTypeID
		{
			get
			{
				return FacilityLocationServiceTypeCollection.ActiveFacilityLocationServiceTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}
	
		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of FacilityLocationService objects
	/// </summary>
	[ElementType(typeof(FacilityLocationService))]
	public class FacilityLocationServiceCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		private CollectionIndexer indexBy_FacilityLocationServiceID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(FacilityLocationService elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentFacilityLocationServiceCollection = this;
			else
				elem.ParentFacilityLocationServiceCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (FacilityLocationService elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public FacilityLocationService this[int index]
		{
			get
			{
				return (FacilityLocationService)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((FacilityLocationService)oldValue, false);
			SetParentOnElem((FacilityLocationService)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(FacilityLocationService elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((FacilityLocationService)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(FacilityLocationService elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((FacilityLocationService)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Parent FacilityLocation that contains this collection
		/// </summary>
		public FacilityLocation ParentFacilityLocation
		{
			get { return this.ParentDataObject as FacilityLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a FacilityLocation */ }
		}
		/// <summary>
		/// Hashtable based index on providerLocationServiceID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_FacilityLocationServiceID
		{
			get
			{
				if (this.indexBy_FacilityLocationServiceID == null)
					this.indexBy_FacilityLocationServiceID  = new CollectionIndexer(this, new string[] { "facilityLocationServiceID" }, true);
				return this.indexBy_FacilityLocationServiceID ;
			}
			
		}

		/// <summary>
		/// Hashtable based search on providerLocationServiceID fields returns the object.  Uses the IndexBy_ProviderLocationServiceID indexer.
		/// </summary>
		public FacilityLocationService FindBy(int facilityLocationServiceID)
		{
			return (FacilityLocationService)this.IndexBy_FacilityLocationServiceID.GetObject(facilityLocationServiceID);
		}

	}
}
