using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EligibilityPCP]
	/// </summary>
	[SPAutoGen("usp_GetEligibilityPCPsByEligibilityIDPlanID","-SelectAllByGivenArgs.sptpl","eligibilityId, planID", ManuallyManaged=true)]
	[SPInsert("usp_InsertEligibilityPCP")]
	[SPLoad("usp_LoadEligibilityPCP")]
	[TableMapping("EligibilityPCP","eligibilityPCPID")]
	public class EligibilityPCP : BaseData
	{
		[ColumnMapping("EligibilityPCPID",StereoType=DataStereoType.PK)]
		private int eligibilityPCPID;
		[NonSerialized]
		private EligibilityPCPCollection parentEligibilityPCPCollection;
		[ColumnMapping("EligibilityId",(int)0)]
		private int eligibilityId;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("PCPId",StereoType=DataStereoType.FK)]
		private int pCPId;
		[ColumnMapping("PCPTypeId",StereoType=DataStereoType.FK)]
		private int pCPTypeId;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("Status")]
		private string status;					// this is not network status
		[ColumnMapping("ChangeDate")]
		private DateTime changeDate;
		[ColumnMapping("PCPSpecialtyID",StereoType=DataStereoType.FK)]
		private int pCPSpecialtyID;
		[ColumnMapping("PCPLocationID",StereoType=DataStereoType.FK)]
		private int pCPLocationID;
		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
		private int planID;

		private Provider provider;

		ProviderLocation providerLocation;		// loaded and cached provider location object that corresponds to pCPId, pCPLocationID
		ProviderSpecialty  providerSpecialty;		// loaded and cached provider location object that corresponds to pCPId, pCPLocationID
	
		public EligibilityPCP()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EligibilityId
		{
			get { return this.eligibilityId; }
			set { this.eligibilityId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PCPId
		{
			get { return this.pCPId; }
			set 
			{ 
				this.pCPId = value; 
				this.providerLocation = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PCPTypeId
		{
			get { return this.pCPTypeId; }
			set { this.pCPTypeId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string Status
		{
			get { return this.status; }
			set { this.status = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ChangeDate
		{
			get { return this.changeDate; }
			set { this.changeDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PCPSpecialtyID
		{
			get { return this.pCPSpecialtyID; }
			set { this.pCPSpecialtyID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PCPLocationID
		{
			get { return this.pCPLocationID; }
			set 
			{ 
				this.pCPLocationID = value; 
				this.providerLocation = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PlanID
		{
			get { return this.planID; }
			set { this.planID = value; }
		}

		public string ProviderFullName
		{
			get{ return this.Provider.FullName;}		
		}

		public int ProviderLocationDesc
		{
			get{ return this.ProviderLocation.LocationID;}
			set{ this.ProviderLocation.LocationID=value;}
		}

		public string ProviderSpecialtyDesc
		{
			get{ return this.ProviderSpecialty.Description;}
		}

		public Provider Provider
		{
			get
			{
				if (this.provider == null)
					this.provider = GetProvider();
				return this.provider;
			}
		}

		public Provider GetProvider()
		{
			if (this.pCPId == 0)
				return null;

			Provider pro = new Provider();
			if (pro.Load(pCPId))
				return pro;
			else
				return null;
		}

		public ProviderSpecialty ProviderSpecialty
		{
			get
			{
				if (this.providerSpecialty == null)
					this.providerSpecialty = GetProviderSpecialty();
				return this.providerSpecialty;
			}
		}

		public ProviderSpecialty GetProviderSpecialty()
		{
			if (this.pCPSpecialtyID== 0)
				return null;
			if (this.pCPId == 0)
				return null;

			ProviderSpecialty provSpec = new ProviderSpecialty();
			if (provSpec.Load(pCPId, pCPSpecialtyID))
				return provSpec;
			else
				return null;
		}


		/// <summary>
		/// Parent EligibilityPCPCollection that contains this element
		/// </summary>
		public EligibilityPCPCollection ParentEligibilityPCPCollection
		{
			get
			{
				return this.parentEligibilityPCPCollection;
			}
			set
			{
				this.parentEligibilityPCPCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eligibilityId, int planID, int pCPId)
		{
			return base.Load(eligibilityId,planID,pCPId);
		}

		/// <summary>
		/// Loaded and caced provider location that corresponds to the pCPID, pCPLocationID
		/// </summary>
		public ProviderLocation ProviderLocation
		{
			get
			{
				if (this.providerLocation == null)
					this.providerLocation = GetProviderLocation();
				return this.providerLocation;
			}
		}

		/// <summary>
		/// Load the associated ProviderLocation object based on the
		/// pCPID, pCPLocationID.
		/// </summary>
		/// <returns></returns>
		public ProviderLocation GetProviderLocation()
		{
			if (this.pCPLocationID == 0)
				return null;
			if (this.pCPId == 0)
				return null;

			ProviderLocation provLoc = new ProviderLocation();
			if (provLoc.Load(pCPId, pCPLocationID))
				return provLoc;
			else
				return null;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EligibilityPCPID
		{
			get { return this.eligibilityPCPID; }
			set { this.eligibilityPCPID = value; }
		}

		
	}

	/// <summary>
	/// Strongly typed collection of EligibilityPCP objects
	/// </summary>
	[ElementType(typeof(EligibilityPCP))]
	public class EligibilityPCPCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EligibilityPCP elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEligibilityPCPCollection = this;
			else
				elem.ParentEligibilityPCPCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EligibilityPCP elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EligibilityPCP this[int index]
		{
			get
			{
				return (EligibilityPCP)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EligibilityPCP)oldValue, false);
			SetParentOnElem((EligibilityPCP)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(EligibilityPCP elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((EligibilityPCP)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent Eligibility that contains this collection
		/// </summary>
		public Eligibility ParentEligibility
		{
			get { return this.ParentDataObject as Eligibility; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Eligibility */ }
		}

		/// <summary>
		/// Parent EligibilityPlan that contains this collection
		/// </summary>
		public EligibilityPlan ParentEligibilityPlan
		{
			get { return this.ParentDataObject as EligibilityPlan; }
			set { this.ParentDataObject = value; /* parent is set when contained by a EligibilityPlan */ }
		}

		/// <summary>
		/// Load all eligibility records for the given EligibilityID and PlanID.
		/// </summary>
		public int LoadEligibilityPCPsByEligibilityIDPlanID(int maxRecords, int eligibilityId, int planID, DateTime dateOfService)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetEligibilityPCPsByEligibilityIDPlanID", maxRecords, this, false, new object[] { eligibilityId, planID, dateOfService });
		}
	}
}

