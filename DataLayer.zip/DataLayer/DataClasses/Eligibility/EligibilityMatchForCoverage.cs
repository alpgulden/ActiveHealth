using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Used to contain rows returned from usp_GetEligibilityRecordsForPatient
	/// </summary>
	[TableMapping("Eligibility","patientCoverageID,eligibilityID")]
	public class EligibilityMatchForCoverage : BaseData
	{
		#region Constants for MatchedBy column

		public const string MatchedBySSN = "SSN";
		public const string MatchedByPatientEligibilityID = "PatientEligibilityID";

		#endregion

		[NonSerialized]
		private EligibilityMatchForCoverageCollection parentEligibilityMatchForCoverageCollection;
		[ColumnMapping("EligibilityID",(int)0)]				// Eligibility.EligibilityID
		private int eligibilityID;
		[ColumnMapping("PatientEligibilityID",(int)0)]		// PatientCoverage.PatientEligibilityID
		private int patientEligibilityID;
		[ColumnMapping("PatientCoverageID",(int)0)]			// PatientCoverage.PatientCoverageID
		private int patientCoverageID;

		
		[ColumnMapping("IsValidCoverage")]
		private bool isValidCoverage;
		[ColumnMapping("matchedBy")]
		private string matchedBy;
	
		// loaded and cached objects
		private Eligibility eligibility;
		private PatientCoverage patientCoverage;

		public EligibilityMatchForCoverage()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int EligibilityID
		{
			get { return this.eligibilityID; }
			set { this.eligibilityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PatientEligibilityID
		{
			get { return this.patientEligibilityID; }
			set { this.patientEligibilityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PatientCoverageID
		{
			get { return this.patientCoverageID; }
			set { this.patientCoverageID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool IsValidCoverage
		{
			get { return this.isValidCoverage; }
			set { this.isValidCoverage = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string MatchedBy
		{
			get { return this.matchedBy; }
			set { this.matchedBy = value; }
		}

		/// <summary>
		/// Load and return the eligibility record for the patient
		/// </summary>
		/// <returns></returns>
		public Eligibility GetEligibility()
		{
			if (this.eligibilityID == 0)
				return null;
			Eligibility eligibility = new Eligibility();
			if (eligibility.Load(this.eligibilityID))
				return eligibility;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached patient eligibility object.
		/// </summary>
		public Eligibility PatientEligibility
		{
			get 
			{
				if (this.eligibility == null)
					this.eligibility = GetEligibility();
				return this.eligibility;
			}
		}

		
		/// <summary>
		/// Load and return the patient coverage record for the patient
		/// </summary>
		/// <returns></returns>
		public PatientCoverage GetPatientCoverage()
		{
			if (this.patientCoverageID == 0)
				return null;
			PatientCoverage patientCoverage = new PatientCoverage();
			if (patientCoverage.Load(this.patientCoverageID))
				return patientCoverage;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached PatientCoverage object.
		/// </summary>
		public PatientCoverage PatientCoverage
		{
			get 
			{
				if (this.patientCoverage == null)
					this.patientCoverage = GetPatientCoverage();
				return this.patientCoverage;
			}
		}

		/// <summary>
		/// Parent EligibilityMatchForCoverageCollection that contains this element
		/// </summary>
		public EligibilityMatchForCoverageCollection ParentEligibilityMatchForCoverageCollection
		{
			get
			{
				return this.parentEligibilityMatchForCoverageCollection;
			}
			set
			{
				this.parentEligibilityMatchForCoverageCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of EligibilityMatchForCoverage objects
	/// </summary>
	[ElementType(typeof(EligibilityMatchForCoverage))]
	public class EligibilityMatchForCoverageCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EligibilityMatchForCoverage elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEligibilityMatchForCoverageCollection = this;
			else
				elem.ParentEligibilityMatchForCoverageCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EligibilityMatchForCoverage elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EligibilityMatchForCoverage this[int index]
		{
			get
			{
				return (EligibilityMatchForCoverage)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EligibilityMatchForCoverage)oldValue, false);
			SetParentOnElem((EligibilityMatchForCoverage)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Load matching eligibility records for the patient coverages.
		/// </summary>
		public int LoadEligibilityRecordsForPatient(DateTime serviceDate, Patient patient)
		{
			if (patient.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "Can't find eligibility records for a new patient");

			this.Clear();
			return SqlData.SPExecReadCol("usp_GetEligibilityRecordsForPatient", -1, this, false, new object[] 
				{ 
					serviceDate, 
					patient.PatientId
				} );
		}

		public EligibilityMatchForCoverage FindMatchingValidEligibilityForCoverage(int patientCoverageID)
		{
			EligibilityMatchForCoverage lastEligMatchedByEligID = null;
			EligibilityMatchForCoverage lastEligMatchedBySSN = null;
			foreach (EligibilityMatchForCoverage eligMatch in this)
			{
				if (eligMatch.IsValidCoverage)
				{
					if (patientCoverageID != 0)		// check only for the passed patient coverage
						if (eligMatch.PatientCoverageID != patientCoverageID)
							continue;

					switch (eligMatch.MatchedBy)
					{
						case EligibilityMatchForCoverage.MatchedByPatientEligibilityID:
							lastEligMatchedByEligID = eligMatch;
							break;
						case EligibilityMatchForCoverage.MatchedBySSN:
							lastEligMatchedBySSN = eligMatch;
							break;
						default:
							// unkown field value
							throw new ActiveAdviceException(AAExceptionAction.None, "Unknown value for MatchedBy = {0}", eligMatch.MatchedBy);
					}
				}	
			}

			if (lastEligMatchedByEligID != null)
				return lastEligMatchedByEligID;		// return last match by eligibility
			if (lastEligMatchedBySSN != null)
				return lastEligMatchedBySSN;		// return last macth by SSN

			return null;							// no match
		}

	}

}
