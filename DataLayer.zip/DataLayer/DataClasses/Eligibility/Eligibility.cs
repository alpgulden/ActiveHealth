using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Eligibility]
	/// </summary>
	[SPAutoGen("usp_GetEligibilityByAlternateIdAndSorgandMembershipId","SelectAllByGivenArgs.sptpl","alternateSubscriberID, sORGID, membershipId")]
	[SPAutoGen("usp_GetEligibilityByAlternateIdAndSorgandMembershipId","SelectAllByGivenArgs.sptpl","alternateSubscriberID, sORGID, membershipId")]
	[SPAutoGen("usp_GetEligibilityByAlternateIdAndSorg","SelectAllByGivenArgs.sptpl","alternateSubscriberID, sORGID, membershipId")]
	[SPAutoGen("usp_ExistsPatientForEligibilityID",null,ManuallyManaged=true)]
	[SPAutoGen("usp_GetAllEligibilities","SelectAll.sptpl","")]
	[SPAutoGen("usp_SelectAllByMembershipID","SelectAllByGivenArgs.sptpl","membershipId")]
	[SPLoad("usp_LoadEligibility")]
	[TableMapping("Eligibility","eligibilityId")]
	public class Eligibility : BaseData
	{
		[NonSerialized]
		protected EligibilityCollection parentEligibilityCollection;
		[ColumnMapping("EligibilityId",(int)0)]			// copy to patient or subscriber elig id of coverage
		protected int eligibilityId;
		[ColumnMapping("AsOfDate")]
		protected DateTime asOfDate;
		[ColumnMapping("FirstName")]
		protected string firstName;
		[ColumnMapping("LastName")]
		protected string lastName;
		[ColumnMapping("MembershipId")]					// copy to Alternateid of coverage
		protected string membershipId;
		[ColumnMapping("MemberAddress1")]
		protected string memberAddress1;
		[ColumnMapping("MemberAddress2")]
		protected string memberAddress2;
		[ColumnMapping("MemberAddress3")]
		protected string memberAddress3;
		[ColumnMapping("MemberCity")]
		protected string memberCity;
		[ColumnMapping("MemberState")]
		protected string memberState;
		[ColumnMapping("MemberCountry")]
		protected string memberCountry;
		[ColumnMapping("MemberPostalCode")]
		protected string memberPostalCode;
		[ColumnMapping("MemberDOB")]
		protected DateTime memberDOB;
		[ColumnMapping("MemberGender")]
		protected string memberGender;
		[ColumnMapping("MemberSSN")]
		protected string memberSSN;
		[ColumnMapping("MemberSORGId")]
		protected string memberSORGId;
		[ColumnMapping("MemberEffectiveDate")]
		protected DateTime memberEffectiveDate;
		[ColumnMapping("IsSubscriber")]
		protected bool isSubscriber;
		[ColumnMapping("MedicaidId")]
		protected string medicaidId;
		[ColumnMapping("MedicareId")]
		protected string medicareId;
		[ColumnMapping("MemberMORGId")]
		protected string memberMORGId;
		[ColumnMapping("MemberORGId")]
		protected string memberORGId;
		[ColumnMapping("HomePhoneNumber")]
		protected string homePhoneNumber;
		[ColumnMapping("WorkPhoneNumber")]
		protected string workPhoneNumber;
		[ColumnMapping("WorkPhoneExtension")]
		protected string workPhoneExtension;
		[ColumnMapping("Fax")]
		protected string fax;
		[ColumnMapping("FaxExtension")]
		protected string faxExtension;
		[ColumnMapping("Email")]
		protected string email;
		[ColumnMapping("Race")]
		protected string race;
		[ColumnMapping("EligibilityTerminationDate")]
		protected DateTime eligibilityTerminationDate;
		[ColumnMapping("PlanTerminationDate")]
		protected DateTime planTerminationDate;
		[ColumnMapping("MemberCounty")]
		protected string memberCounty;
		[ColumnMapping("AlternateInsuranceID")]
		protected string alternateInsuranceID;
		[ColumnMapping("MORGID",StereoType=DataStereoType.FK)]
		protected int mORGID;
		[ColumnMapping("ORGID",StereoType=DataStereoType.FK)]
		protected int oRGID;
		[ColumnMapping("SORGID",StereoType=DataStereoType.FK)]
		protected int sORGID;
		[ColumnMapping("MiddleInitial")]
		protected string middleInitial;
		[ColumnMapping("NameSuffix")]
		protected string nameSuffix;
		[ColumnMapping("RelationshipID",StereoType=DataStereoType.FK)]
		protected int relationshipID;
		[ColumnMapping("HomePhoneExtension")]
		protected string homePhoneExtension;
		[ColumnMapping("AlternateSubscriberID")]
		protected string alternateSubscriberID;
		[ColumnMapping("NamePrefixID",StereoType=DataStereoType.FK)]
		protected int namePrefixID;
	
		private EligibilityPlanCollection eligibilityPlans;
		private Organization organization;
		private NamePrefix nameprefix;

		// loaded and cached objects
		private Organization parentSORG;
		private EligibilityPCPCollection eligibilityPCPs;
	
		public Eligibility()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EligibilityId
		{
			get { return this.eligibilityId; }
			set { this.eligibilityId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string FirstName
		{
			get { return this.firstName; }
			set { this.firstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string LastName
		{
			get { return this.lastName; }
			set { this.lastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string MembershipId
		{
			get { return this.membershipId; }
			set { this.membershipId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string MemberAddress1
		{
			get { return this.memberAddress1; }
			set { this.memberAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string MemberAddress2
		{
			get { return this.memberAddress2; }
			set { this.memberAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string MemberAddress3
		{
			get { return this.memberAddress3; }
			set { this.memberAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string MemberCity
		{
			get { return this.memberCity; }
			set { this.memberCity = value; }
		}

		//[FieldValuesMember("LookupOf_MemberState", "StateID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.USState, MaxLength=15)]
		public string MemberState
		{
			get { return this.memberState; }
			set { this.memberState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MemberCountry
		{
			get { return this.memberCountry; }
			set { this.memberCountry = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USZipCode, MaxLength=10)]
		public string MemberPostalCode
		{
			get { return this.memberPostalCode; }
			set { this.memberPostalCode = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MemberDOB
		{
			get { return this.memberDOB; }
			set { this.memberDOB = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Gender, MaxLength=1)]
		public string MemberGender
		{
			get { return this.memberGender; }
			set { this.memberGender = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USSSN, MaxLength=64)]
		public string MemberSSN
		{
			get { return this.memberSSN; }
			set { this.memberSSN = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string MemberSORGId
		{
			get { return this.memberSORGId; }
			set { this.memberSORGId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime MemberEffectiveDate
		{
			get { return this.memberEffectiveDate; }
			set { this.memberEffectiveDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IsSubscriber
		{
			get { return this.isSubscriber; }
			set { this.isSubscriber = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MedicaidId
		{
			get { return this.medicaidId; }
			set { this.medicaidId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MedicareId
		{
			get { return this.medicareId; }
			set { this.medicareId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string MemberMORGId
		{
			get { return this.memberMORGId; }
			set { this.memberMORGId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string MemberORGId
		{
			get { return this.memberORGId; }
			set { this.memberORGId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=20)]
		public string HomePhoneNumber
		{
			get { return this.homePhoneNumber; }
			set { this.homePhoneNumber = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=20)]
		public string WorkPhoneNumber
		{
			get { return this.workPhoneNumber; }
			set { this.workPhoneNumber = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string WorkPhoneExtension
		{
			get { return this.workPhoneExtension; }
			set { this.workPhoneExtension = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=20)]
		public string Fax
		{
			get { return this.fax; }
			set { this.fax = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string FaxExtension
		{
			get { return this.faxExtension; }
			set { this.faxExtension = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Email, MaxLength=60)]
		public string Email
		{
			get { return this.email; }
			set { this.email = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string Race
		{
			get { return this.race; }
			set { this.race = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EligibilityTerminationDate
		{
			get { return this.eligibilityTerminationDate; }
			set { this.eligibilityTerminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PlanTerminationDate
		{
			get { return this.planTerminationDate; }
			set { this.planTerminationDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MemberCounty
		{
			get { return this.memberCounty; }
			set { this.memberCounty = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateInsuranceID
		{
			get { return this.alternateInsuranceID; }
			set { this.alternateInsuranceID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MORGID
		{
			get { return this.ParentSORG.ParentOrganization.ParentOrganization.OrganizationID; }
			set { this.ParentSORG.ParentOrganization.ParentOrganization.OrganizationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ORGID
		{
			get{ return this.ParentSORG.ParentOrganization.OrganizationID;}
			set{ this.ParentSORG.ParentOrganization.OrganizationID=value;}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)0)]
		public int SORGID
		{
			get { return this.sORGID; }
			set { this.sORGID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string MiddleInitial
		{
			get { return this.middleInitial; }
			set { this.middleInitial = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string NameSuffix
		{
			get { return this.nameSuffix; }
			set { this.nameSuffix = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RelationshipID
		{
			get { return this.relationshipID; }
			set { this.relationshipID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string HomePhoneExtension
		{
			get { return this.homePhoneExtension; }
			set { this.homePhoneExtension = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=30)]
		public string AlternateSubscriberID
		{
			get { return this.alternateSubscriberID; }
			set { this.alternateSubscriberID = value; }
		}

		[FieldDescription("@PREFIX@")]
		public string Prefix
		{
			get{ return this.NamePrefix.Description;}
			set{ this.NamePrefix.Description=value;}
		}

		public string SORGName
		{
			get{ return this.ParentSORG.Name;}
			set{ this.ParentSORG.Name=value;}
		}
		
		public string ORGName
		{
			get{ return this.ParentSORG.ParentOrganization.Name;}
			set{ this.ParentSORG.ParentOrganization.Name=value;}
		}

		public string MORGName
		{
			get{ return this.ParentSORG.ParentOrganization.ParentOrganization.Name;}
			set{ this.ParentSORG.ParentOrganization.ParentOrganization.Name=value;}
		}

		public NamePrefix NamePrefix
		{
			get 
			{ 
				if (this.nameprefix == null)
					this.nameprefix = GetNamePrefix();
				return this.nameprefix;
			}
		}

		public NamePrefix GetNamePrefix()
		{
			if (this.namePrefixID == 0)
				return null;
			else
			{
				NamePrefix nameprefix = new NamePrefix();
				if (nameprefix.Load(this.namePrefixID))
					return nameprefix;
				else
					return null;			
			}
		}

		public Organization ParentSORG
		{
			get 
			{ 
				if (this.parentSORG == null)
					this.parentSORG= GetSorg();
				return this.parentSORG;
			}
		}

		public Organization GetSorg()
		{
			if (this.SORGID == 0)
				return null;
			else
			{
				Organization org = new Organization();
				if (org.Load(this.SORGID))
					return org;					
				else
					return null;			
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eligibilityId)
		{
			return base.Load(eligibilityId);
		}
		

		/// <summary>
		/// Parent EligibilityCollection that contains this element
		/// </summary>
		public EligibilityCollection ParentEligibilityCollection
		{
			get
			{
				return this.parentEligibilityCollection;
			}
			set
			{
				this.parentEligibilityCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Child EligibilityPlans mapped to related rows of table EligibilityPlan where [EligibilityId] = [EligibilityId]
		/// </summary>
		[SPLoadChild("usp_LoadEligibilityPlans", "eligibilityId")]
		public EligibilityPlanCollection EligibilityPlans
		{
			get { return this.eligibilityPlans; }
			set
			{
				this.eligibilityPlans = value;
				if (value != null)
					value.ParentEligibility = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the EligibilityPlans collection
		/// </summary>
		public void LoadEligibilityPlans(bool forceReload)
		{
			this.eligibilityPlans = (EligibilityPlanCollection)EligibilityPlanCollection.LoadChildCollection("EligibilityPlans", this, typeof(EligibilityPlanCollection), eligibilityPlans, forceReload, null);
		}

		/// <summary>
		/// Saves the EligibilityPlans collection
		/// </summary>
		public void SaveEligibilityPlans()
		{
			EligibilityPlanCollection.SaveChildCollection(this.eligibilityPlans, true);
		}

		/// <summary>
		/// Synchronizes the EligibilityPlans collection
		/// </summary>
		public void SynchronizeEligibilityPlans()
		{
			EligibilityPlanCollection.SynchronizeChildCollection(this.eligibilityPlans, true);
		}

		public EligibilityPCPCollection GetAllEligibilityPCPs(DateTime dateOfService, int planID)
		{
			EligibilityPCPCollection eligPCPs = new EligibilityPCPCollection();
			eligPCPs.LoadEligibilityPCPsByEligibilityIDPlanID(-1, this.eligibilityId, planID, dateOfService);
			if (eligPCPs.Count > 0)
				return eligPCPs;
			else
				return null;
		}

		/// <summary>
		/// Load and return the sorg record.
		/// </summary>
		/// <returns></returns>
		public Organization GetSORG()
		{
			if (this.sORGID == 0)
				return null;
			Organization sorg = new Organization();
			if (sorg.Load(this.sORGID))
				return sorg;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached sorg object.
		/// </summary>
		public Organization SORG
		{
			get 
			{
				if (this.parentSORG == null)
					this.parentSORG = GetSORG();
				return this.parentSORG;
			}
		}

		public StateCollection LookupOf_MemberState
		{
			get
			{
				return StateCollection.AllStates; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}


		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NamePrefixID
		{
			get { return this.namePrefixID; }
			set { this.namePrefixID = value; }
		}

		/// <summary>
		/// Child EligibilityPCPs mapped to related rows of table EligibilityPCP where [EligibilityId] = [EligibilityId]
		/// </summary>
		[SPLoadChild("usp_LoadEligibilityEligibilityPCP", "eligibilityId")]
		public EligibilityPCPCollection EligibilityPCPs
		{
			get { return this.eligibilityPCPs; }
			set
			{
				this.eligibilityPCPs = value;
				if (value != null)
					value.ParentEligibility = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the EligibilityPCPs collection
		/// </summary>
		public void LoadEligibilityPCPs(bool forceReload)
		{
			this.eligibilityPCPs = (EligibilityPCPCollection)EligibilityPCPCollection.LoadChildCollection("EligibilityPCPs", this, typeof(EligibilityPCPCollection), eligibilityPCPs, forceReload, null);
		}

		/// <summary>
		/// Saves the EligibilityPCPs collection
		/// </summary>
		public void SaveEligibilityPCPs()
		{
			EligibilityPCPCollection.SaveChildCollection(this.eligibilityPCPs, true);
		}

		/// <summary>
		/// Synchronizes the EligibilityPCPs collection
		/// </summary>
		public void SynchronizeEligibilityPCPs()
		{
			EligibilityPCPCollection.SynchronizeChildCollection(this.eligibilityPCPs, true);
		}

		/// <summary>
		/// Returns the PatientID if any existing patient is found in the system for the given eligibilityID.
		/// </summary>
		public int ExistsPatientInTheSystem()
		{
			// FORK 1.0	--> usp_ExistsPatientForEligibilityID was changed.
			object val = SqlData.SPExecScalar("usp_ExistsPatientForEligibilityID", new object[] { this.eligibilityId });
			if (val is DBNull)
				return 0;
			else
				return Convert.ToInt32( val );
		}

		// FORK 1.0

		// <summary>
		/// Returns the patients that has a coverage linked to the given eligibilityID.
		/// </summary>
		public PatientSearchResultCollection GetExistingPatientsInTheSystem()
		{
			PatientSearchResultCollection existingPatients = new PatientSearchResultCollection();
			existingPatients.LoadPatientsLinkedToEligibility(this.eligibilityId);
			return existingPatients;
		}

		// END FORK 1.0

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadEligibilityByAlternateIdAndSorgandMembershipId(string alternateSubscriberID, int sORGID, string membershipId)
		{
			return SqlData.SPExecReadObj("usp_GetEligibilityByAlternateIdAndSorgandMembershipId", this, false, new object[] { alternateSubscriberID, sORGID, membershipId });
		}


	}

	/// <summary>
	/// Strongly typed collection of Eligibility objects
	/// </summary>
	[ElementType(typeof(Eligibility))]
	public class EligibilityCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Eligibility elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEligibilityCollection = this;
			else
				elem.ParentEligibilityCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Eligibility elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Eligibility this[int index]
		{
			get
			{
				return (Eligibility)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Eligibility)oldValue, false);
			SetParentOnElem((Eligibility)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SelectAllByMembershipID(int maxRecords, string membershipId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllByMembershipID", maxRecords, this, false, new object[] { membershipId });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllEligibilities(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllEligibilities", maxRecords, this, false);
		}

	}

	/// <summary>
	/// Eligibility joined with eligilibity plan.
	/// Includes subscriber related fields under members with prefix 'Subscriber'
	/// </summary>
	public class EligibilityMainResult : Eligibility
	{
		[ColumnMapping("SubscriberFirstName")]
		protected string subscriberFirstName;
		[ColumnMapping("SubscriberLastName")]
		protected string subscriberLastName;
		[ColumnMapping("SubscriberMembershipId")]
		protected string subscriberMembershipId;		
		[ColumnMapping("SubscriberMemberSSN")]
		protected string subscriberMemberSSN;

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberFirstName
		{
			get { return this.subscriberFirstName; }
			set { this.subscriberFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberLastName
		{
			get { return this.subscriberLastName; }
			set { this.subscriberLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberMembershipId
		{
			get { return this.subscriberMembershipId; }
			set { this.subscriberMembershipId = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberMemberSSN
		{
			get { return this.subscriberMemberSSN; }
			set { this.subscriberMemberSSN = value; }
		}
	}

	[ElementType(typeof(EligibilityMainResult))]
	public class EligibilityMainResultCollection : EligibilityCollection
	{

		/// <summary>
		/// Free Search for eligibilities and load the collection.
		/// </summary>
		public int SearchFreeEligibilities(int maxRecords, EligibilitySearcher searcher)
		{
			if (searcher.SortField == null)
				searcher.SortField = searcher.PKFields[0];
			
			string[] extraParamNames = new string[] { "rowCount"};
			object[] extraParamValues = new object[] { maxRecords < 0 ? 0 : maxRecords, SQLDataDirect.MakeDBValue(AASecurityHelper.GetUserId, (int)0)};

			this.Clear();				
			return SqlData.SPExecReadCol("usp_SearchFreeEligibilitiesWithDAFilter", maxRecords, this, searcher, false,extraParamNames, extraParamValues);
		}

		/// <summary>
		/// Exact Search  for eligibilities
		/// </summary>
		public int SearchExactEligibilities(int maxRecords, EligibilitySearcher searcher,string field,string val)
		{
			searcher.SortField = searcher.PKFields[0];
			
			string[] extraParamNames = new string[] { "rowCount", "fieldname","val" };
			object[] extraParamValues = new object[] { maxRecords < 0 ? 0 : maxRecords, field , val };

			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchExactEligibilities", maxRecords, this, searcher, false, extraParamNames, extraParamValues);
		}

	}

	/// <summary>
	/// Derives from Eligibility and contains extra fields that are
	/// used only in the search.
	/// </summary>
	public class EligibilitySearcher : Eligibility
	{

		[ColumnMapping(null)]
		private string sortField;

		public EligibilitySearcher()
		{
			this.SetMembersNull(true, true);
		}

		[FieldValuesMember("ValuesOf_SortField")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string SortField
		{
			get { return this.sortField; }
			set { this.sortField = value; }
		}

		public string[,] ValuesOf_SortField
		{
			get
			{
				return new string[,] 
				{
					{ "lastName", "LastName" },
					{ "firstName", "FirstName" },
					{ "memberSSN", "MemberSSN" },
					//{ "SubscriberSSN", "SubscriberSSN"},
					{ "membershipId", "MembershipID" },
					{ "alternateSubscriberID", "AltSubcriberID" },
					{ "medicareId", "MedicareID" },
					{ "medicaidId", "MedicaidID" },
					{ "memberSSN", "MemberSSN" }
				};
			}
		}
	}

}
