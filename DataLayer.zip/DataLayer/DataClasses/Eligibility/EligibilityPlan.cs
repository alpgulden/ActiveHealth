using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EligibilityPlan]
	/// </summary>
	[SPAutoGen("usp_GetEligibilityPlan","SelectAllByGivenArgs.sptpl","eligibilityId, active, planId")]
	[SPInsert("usp_InsertEligibilityPlan")]
	[SPLoad("usp_LoadEligibilityPlan")]
	[TableMapping("EligibilityPlan", "EligibilityPlanID")]
	public class EligibilityPlan : BaseData
	{
		[ColumnMapping("EligibilityPlanID")]
		private int eligibilityPlanID;
		[NonSerialized]
		private EligibilityPlanCollection parentEligibilityPlanCollection;
		[ColumnMapping("EligibilityId",(int)0)]
		private int eligibilityId;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("PlanTypeId",StereoType=DataStereoType.FK)]
		private int planTypeId;
		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)]
		private int planId;
		[ColumnMapping("AlternateGroupID")]
		private string alternateGroupID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("Status")]
		private string status;
		[ColumnMapping("ChangeDate")]
		private DateTime changeDate;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("EnrollmentID",StereoType=DataStereoType.FK)]
		private int enrollmentID;
		[ColumnMapping("AlternateEnrollmentID")]
		private string alternateEnrollmentID;
	
		private Plan plan;
		private PlanType planType;

		public EligibilityPlan()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EligibilityId
		{
			get { return this.eligibilityId; }
			set { this.eligibilityId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanTypeId
		{
			get { return this.planTypeId; }
			set { this.planTypeId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateGroupID
		{
			get { return this.alternateGroupID; }
			set { this.alternateGroupID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string Status
		{
			get { return this.status; }
			set { this.status = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ChangeDate
		{
			get { return this.changeDate; }
			set { this.changeDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EnrollmentID
		{
			get { return this.enrollmentID; }
			set { this.enrollmentID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateEnrollmentID
		{
			get { return this.alternateEnrollmentID; }
			set { this.alternateEnrollmentID = value; }
		}

		public string PlanName
		{
			get{ return this.Plan.Name;}
			set{ this.Plan.Name=value;}
		}

		public string PlanTypeDescription
		{
			get{ return this.PlanType.Description;}
			set{ this.PlanType.Description=value;}
		}

		public Plan Plan
		{
			get 
			{ 
				if (this.plan== null)
					this.plan= GetPlan();
				return this.plan;
			}
		}

		public Plan GetPlan()
		{
			if (this.planId == 0)
				return null;
			else
			{
				Plan plan = new Plan();
				if (plan.Load(this.planId))
					return plan;
				else
					return null;			
			}
		}

		public PlanType PlanType
		{
			get 
			{ 
				if (this.planType== null)
					this.planType= GetPlanType();
				return this.planType;
			}
		}

		public PlanType GetPlanType()
		{
			if (this.planTypeId== 0)
				return null;
			else
			{
				PlanType planType = new PlanType();
				if (planType.Load(this.planTypeId))
					return planType ;
				else
					return null;			
			}
		}

		/// <summary>
		/// Parent EligibilityPlanCollection that contains this element
		/// </summary>
		public EligibilityPlanCollection ParentEligibilityPlanCollection
		{
			get
			{
				return this.parentEligibilityPlanCollection;
			}
			set
			{
				this.parentEligibilityPlanCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EligibilityPlanID
		{
			get { return this.eligibilityPlanID; }
			set { this.eligibilityPlanID = value; }
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eligibilityPlanID)
		{
			return base.Load(eligibilityPlanID);
		}

	}

	/// <summary>
	/// Strongly typed collection of EligibilityPlan objects
	/// </summary>
	[ElementType(typeof(EligibilityPlan))]
	public class EligibilityPlanCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EligibilityPlan elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEligibilityPlanCollection = this;
			else
				elem.ParentEligibilityPlanCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EligibilityPlan elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EligibilityPlan this[int index]
		{
			get
			{
				return (EligibilityPlan)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EligibilityPlan)oldValue, false);
			SetParentOnElem((EligibilityPlan)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(EligibilityPlan elem)
		{
			return List.Add(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((EligibilityPlan)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent Eligibility that contains this collection
		/// </summary>
		public Eligibility ParentEligibility
		{
			get { return this.ParentDataObject as Eligibility; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Eligibility */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadEligibilityPlan(int maxRecords, int eligibilityId, bool active, int planId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetEligibilityPlan", maxRecords, this, false, new object[] { eligibilityId, active, planId });
		}

	}
}
