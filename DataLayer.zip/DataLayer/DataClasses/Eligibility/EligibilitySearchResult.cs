using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Used to search eligibilty from Intake.
	/// </summary>
	[SPAutoGen("usp_SearchEligibility","SelectAllByGivenArgs.sptpl",null, ManuallyManaged=true)]
	[TableMapping("Eligibility","patientEligibilityID,subscriberEligibilityID,patientPlanID")]
	public class EligibilitySearchResult : BaseData
	{
		[NonSerialized]
		private EligibilitySearchResultCollection parentEligibilitySearchResultCollection;
		[ColumnMapping("PatientEligibilityID",(int)0)]
		private int patientEligibilityID;
		[ColumnMapping("SubscriberEligibilityID",(int)0)]
		private int subscriberEligibilityID;
		[ColumnMapping("PatientPlanID",(int)0)]
		private int patientPlanID;
		[ColumnMapping("EligibilityPlanID",(int)0)]
		private int eligibilityPlanID;

		[ColumnMapping("PatientSSN")]
		private string patientSSN;
		[ColumnMapping("PatientLastName")]
		private string patientLastName;
		[ColumnMapping("PatientFirstName")]
		private string patientFirstName;
		[ColumnMapping("PatientMembershipID")]
		private string patientMembershipID;

		[ColumnMapping("SubscriberSSN")]
		private string subscriberSSN;
		[ColumnMapping("SubscriberLastName")]
		private string subscriberLastName;
		[ColumnMapping("SubscriberFirstName")]
		private string subscriberFirstName;
		[ColumnMapping("SubscriberMembershipID")]
		private string subscriberMembershipID;

		[ColumnMapping("PlanEffectiveDate")]
		private DateTime planEffectiveDate;
		[ColumnMapping("PlanTerminationDate")]
		private DateTime planTerminationDate;
		
		[ColumnMapping("IsValidCoverage")]
		private bool isValidCoverage;
		
	
		// loaded and cached objects
		private Plan patientPlan;
		private Eligibility patientEligibility;
		private Eligibility subscriberEligibility;
		private EligibilityPlan patientEligibilityPlan;

		public EligibilitySearchResult()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PatientEligibilityID
		{
			get { return this.patientEligibilityID; }
			set { this.patientEligibilityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int SubscriberEligibilityID
		{
			get { return this.subscriberEligibilityID; }
			set { this.subscriberEligibilityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PatientPlanID
		{
			get { return this.patientPlanID; }
			set { this.patientPlanID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientSSN
		{
			get { return this.patientSSN; }
			set { this.patientSSN = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientLastName
		{
			get { return this.patientLastName; }
			set { this.patientLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientFirstName
		{
			get { return this.patientFirstName; }
			set { this.patientFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientMembershipID
		{
			get { return this.patientMembershipID; }
			set { this.patientMembershipID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberSSN
		{
			get { return this.subscriberSSN; }
			set { this.subscriberSSN = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberLastName
		{
			get { return this.subscriberLastName; }
			set { this.subscriberLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberFirstName
		{
			get { return this.subscriberFirstName; }
			set { this.subscriberFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberMembershipID
		{
			get { return this.subscriberMembershipID; }
			set { this.subscriberMembershipID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PlanEffectiveDate
		{
			get { return this.planEffectiveDate; }
			set { this.planEffectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PlanTerminationDate
		{
			get { return this.planTerminationDate; }
			set { this.planTerminationDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool IsValidCoverage
		{
			get { return this.isValidCoverage; }
			set { this.isValidCoverage = value; }
		}

		/// <summary>
		/// Load and return the eligibility record for the patient
		/// </summary>
		/// <returns></returns>
		public Eligibility GetPatientEligibility()
		{
			if (this.patientEligibilityID == 0)
				return null;
			Eligibility eligibility = new Eligibility();
			if (eligibility.Load(this.patientEligibilityID))
				return eligibility;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached patient eligibility object.
		/// </summary>
		public Eligibility PatientEligibility
		{
			get 
			{
				if (this.patientEligibility == null)
					this.patientEligibility = GetPatientEligibility();
				return this.patientEligibility;
			}
		}

		/// <summary>
		/// Load and return the eligibility record for the subscriber
		/// </summary>
		/// <returns></returns>
		public Eligibility GetSubscriberEligibility()
		{
			if (this.subscriberEligibilityID == 0)
				return null;
			Eligibility subscriber = new Eligibility();
			if (subscriber.Load(this.subscriberEligibilityID))
				return subscriber;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached subscriber eligibility object.
		/// </summary>
		public Eligibility SubscriberEligibility
		{
			get 
			{
				if (this.subscriberEligibility == null)
					this.subscriberEligibility = GetSubscriberEligibility();
				return this.subscriberEligibility;
			}
		}

		/// <summary>
		/// Load and return the eligibility plan record for the patient
		/// </summary>
		/// <returns></returns>
		public EligibilityPlan GetPatientEligibilityPlan()
		{
			if (this.patientPlanID == 0)
				return null;
			EligibilityPlan eligPlan = new EligibilityPlan();
			if (eligPlan.Load(this.eligibilityPlanID))
				return eligPlan;
			else
				return null;
		}

		/// <summary>
		/// Loaded and cached Eligibility Plan selected for the patient
		/// </summary>
		public ActiveAdvice.DataLayer.EligibilityPlan PatientEligibilityPlan
		{
			get 
			{ 
				if (this.patientEligibilityPlan == null)
					this.patientEligibilityPlan = GetPatientEligibilityPlan();
				return this.patientEligibilityPlan;
			}
		}

		/// <summary>
		/// Load and return the plan record for the patient
		/// </summary>
		/// <returns></returns>
		public Plan GetPatientPlan()
		{
			if (this.patientPlanID == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.patientPlanID))
				return plan;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached plan object.
		/// </summary>
		public Plan PatientPlan
		{
			get 
			{
				if (this.patientPlan == null)
					this.patientPlan = GetPatientPlan();
				return this.patientPlan;
			}
		}

		/// <summary>
		/// Parent EligibilitySearchResultCollection that contains this element
		/// </summary>
		public EligibilitySearchResultCollection ParentEligibilitySearchResultCollection
		{
			get
			{
				return this.parentEligibilitySearchResultCollection;
			}
			set
			{
				this.parentEligibilitySearchResultCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of EligibilitySearchResult objects
	/// </summary>
	[ElementType(typeof(EligibilitySearchResult))]
	public class EligibilitySearchResultCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EligibilitySearchResult elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEligibilitySearchResultCollection = this;
			else
				elem.ParentEligibilitySearchResultCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EligibilitySearchResult elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EligibilitySearchResult this[int index]
		{
			get
			{
				return (EligibilitySearchResult)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EligibilitySearchResult)oldValue, false);
			SetParentOnElem((EligibilitySearchResult)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Search the eligibility.
		/// </summary>
		public int SearchEligibility(int maxRows, DateTime serviceDate, string patientMembershipID, string patientSSN, string patientLName, string patientFName, /* FORK 1.0 */ DateTime patientDOB, /* FORK 1.0 */ string patientGender, string subscriberSSN, string subscriberLName, string subscriberFName, int sorgID, int planID)
		{
			this.Clear();
			// FORK 1.0 -->  usp_SearchEligibility
			return SqlData.SPExecReadCol(60, "usp_SearchEligibilityWithDAFilter", -1, this, false, new object[] 
				{ 
					maxRows,
					serviceDate, 
					SQLDataDirect.MakeDBValue(patientMembershipID), 
					SQLDataDirect.MakeDBValue(patientSSN), 
					SQLDataDirect.MakeDBValue(patientLName), 
					SQLDataDirect.MakeDBValue(patientFName), 
					// FORK 1.0
					SQLDataDirect.MakeDBValue(patientDOB),
					SQLDataDirect.MakeDBValue(patientGender), 
					// END FORK 1.0
					SQLDataDirect.MakeDBValue(subscriberSSN), 
					SQLDataDirect.MakeDBValue(subscriberLName), 
					SQLDataDirect.MakeDBValue(subscriberFName),
					SQLDataDirect.MakeDBValue(sorgID, (int)0),
					SQLDataDirect.MakeDBValue(planID, (int)0),
					SQLDataDirect.MakeDBValue(AASecurityHelper.GetUserId, (int)0)
				} );
		}
	}

	
/*
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SelectAllByMembershipID(int maxRecords, string membershipId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllByMembershipID", maxRecords, this, false, new object[] { membershipId });
		}
*/
}
