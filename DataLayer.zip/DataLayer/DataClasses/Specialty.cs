using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Specialties]
	/// </summary>
	[SPExists("usp_ExistsSpecialty")]
	[SPAutoGen("usp_GetAllSpecialties","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetSpecialtiesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertSpecialty")]
	[SPUpdate("usp_UpdateSpecialty")]
	[SPDelete("usp_DeleteSpecialty")]
	[SPLoad("usp_LoadSpecialty")]
	[TableMapping("Specialty","specialtyID")]
	public class Specialty : BaseLookupWithNote
	{
		[NonSerialized]
		private SpecialtyCollection parentSpecialtyCollection;
		[ColumnMapping("SpecialtyID",StereoType=DataStereoType.FK)]
		private int specialtyID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public Specialty()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox)]
		public int SpecialtyID
		{
			get { return this.specialtyID; }
			set { this.specialtyID = value; }
		}


		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int specialtyID)
		{
			return base.Load(specialtyID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int specialtyID)
		{
			base.Delete(specialtyID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public new void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Parent SpecialtyCollection that contains this element
		/// </summary>
		public SpecialtyCollection ParentSpecialtyCollection
		{
			get
			{
				return this.parentSpecialtyCollection;
			}
			set
			{
				this.parentSpecialtyCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}


		/// <summary>
		/// Returns the Specialty Description for the given specialty ID.
		/// </summary>
		/// <param name="providerID"></param>
		/// <returns></returns>
		public static string GetSpecialtyByID(int specialtyID)
		{
			if (specialtyID == 0)
				return null;
			Specialty specialty = new Specialty();
			if (specialty.Load(specialtyID))
				return specialty.Description;
			else
				return null;
		}
	}

	/// <summary>
	/// Strongly typed collection of Specialty objects
	/// </summary>
	[ElementType(typeof(Specialty))]
	public class SpecialtyCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Specialty elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSpecialtyCollection = this;
			else
				elem.ParentSpecialtyCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Specialty elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Specialty this[int index]
		{
			get
			{
				return (Specialty)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Specialty)oldValue, false);
			SetParentOnElem((Specialty)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, Specialty elem)
		{
			List.Insert(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Specialty)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Specialty elem)
		{
			return List.Add(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(Specialty elem)
		{
			List.Remove(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((Specialty)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/* Don't use this.
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(string filter, string sort)
		{
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForType(typeof(Specialty), filter, sort);
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/
		
		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetSpecialtiesByActive(bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetSpecialtiesByActive", -1, this, false, new object[] { active });
		}
		/// <summary>
		///  Load All Group Practice Focus Types.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllSpecialties", -1, this, false);
		}

		/// <summary>
		/// Searches for Group Practice Service Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchProviderSpecialties", -1, this, false, code, description, active);
		}

		/// <summary>
		/// Accessor to a shared SpecialtyCollection which is cached in NSGlobal
		/// </summary>
		public static SpecialtyCollection ActiveSpecialties
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				SpecialtyCollection col = (SpecialtyCollection)NSGlobal.EnsureCachedObject("ActiveSpecialties", typeof(SpecialtyCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetSpecialtiesByActive(true);
				}
				return col;
			}
			
		}
	}
}
