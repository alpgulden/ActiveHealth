using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SecurityGroupOrganizationLevel]
	/// </summary>
	[SPAutoGen("usp_LoadSecurityGroupOrganizationLevelByLevelID","SelectAllByGivenArgs.sptpl","organizationLevelID, groupID")]
	[SPInsert("usp_InsertSecurityGroupOrganizationLevel")]
	[SPUpdate("usp_UpdateSecurityGroupOrganizationLevel")]
	[SPDelete("usp_DeleteSecurityGroupOrganizationLevel")]
	[SPLoad("usp_LoadSecurityGroupOrganizationLevel")]
	[TableMapping("SecurityGroupOrganizationLevel","groupOrganizationLevelID")]
	public class SecurityGroupOrganizationLevel : SecurityGroupDALevel
	{
		[NonSerialized]
		private SecurityGroupOrganizationLevelCollection parentSecurityGroupOrganizationLevelCollection;	
		[ColumnMapping("GroupOrganizationLevelID",(int)0)]
		private int groupOrganizationLevelID;
		[ColumnMapping("OrganizationID")]
		private int organizationID;
		[ColumnMapping("OrganizationLevelID")]
		private int organizationLevelID;

		private string name;
		private OrganizationSummary organizationSummary;

		public SecurityGroupOrganizationLevel()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public SecurityGroupOrganizationLevel(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();			
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GroupOrganizationLevelID
		{
			get { return this.groupOrganizationLevelID; }
			set { this.groupOrganizationLevelID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OrganizationID
		{
			get { return this.organizationID; }
			set { this.organizationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OrganizationLevelID
		{
			get { return this.organizationLevelID; }
			set { this.organizationLevelID = value; }
		}

		public string Name
		{
			get 
			{ 
				if (this.name == null)
					this.name = this.OrganizationSummary.Name;
				return this.name; 
			}
			set { this.name = value; }
		}


		/// <summary>
		/// Parent SecurityGroupOrganizationLevelCollection that contains this element
		/// </summary>
		public SecurityGroupOrganizationLevelCollection ParentSecurityGroupOrganizationLevelCollection
		{
			get
			{
				return this.parentSecurityGroupOrganizationLevelCollection;
			}
			set
			{
				this.parentSecurityGroupOrganizationLevelCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Contained Organizations object
		/// </summary>
		[Contained]
		public OrganizationSummary OrganizationSummary
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.organizationSummary = (OrganizationSummary)OrganizationSummary.EnsureContainedDataObject(this, typeof(OrganizationSummary), organizationSummary, false, organizationID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.organizationSummary;
			}
			set
			{
				this.organizationSummary = value;
				if (value != null) value.ParentSecurityGroupOrganizationLevel = this; // set this as a parent of the child data class
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of SecurityGroupOrganizationLevel objects
	/// </summary>
	[ElementType(typeof(SecurityGroupOrganizationLevel))]
	public class SecurityGroupOrganizationLevelCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_OrganizationID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SecurityGroupOrganizationLevel elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSecurityGroupOrganizationLevelCollection = this;
			else
				elem.ParentSecurityGroupOrganizationLevelCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SecurityGroupOrganizationLevel elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SecurityGroupOrganizationLevel)oldValue, false);
			SetParentOnElem((SecurityGroupOrganizationLevel)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSecurityGroupOrganizationLevelByLevelID(int maxRecords, int organizationLevelID,int groupID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadSecurityGroupOrganizationLevelByLevelID", maxRecords, this, false, new object [] { organizationLevelID,groupID});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSecurityGroupOrganizationLevelByLevelIDAndFilter(int maxRecords, int organizationLevelID,int groupID,string filter)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadSecurityGroupOrganizationLevelByLevelIDAndFilter", maxRecords, this, false, new object [] { organizationLevelID,groupID,filter});
		}		

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSecurityGroupOrganizationLevels(int maxRecords, int groupID, int organizationLevelID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadSecurityGroupOrganizationLevels", maxRecords, this, false, groupID, organizationLevelID);
		}

		public void SynchronizeOrganizationLevelsFromSelectableCollection(int groupID, OrganizationSummaryCollection organizations,bool notequal,bool all)
		{	
			if(!all)
			{
				foreach (OrganizationSummary organization in organizations)
				{
					if (organization.Selected)
					{
						SecurityGroupOrganizationLevel existingOrganizationLevel = this.FindBy(organization.OrganizationID);
						if (existingOrganizationLevel == null)
						{
							SecurityGroupOrganizationLevel newOrganizationLevel = null;
							newOrganizationLevel = new SecurityGroupOrganizationLevel(true);
							newOrganizationLevel.GroupID = groupID;
							newOrganizationLevel.OrganizationID = organization.OrganizationID;
							newOrganizationLevel.OrganizationLevelID= organization.OrganizationLevelID;
							newOrganizationLevel.Name = organization.Name;						
							newOrganizationLevel.Equal = !notequal;
							newOrganizationLevel.AllRecords = all;
							this.AddRecord(newOrganizationLevel);
						}
						else if (existingOrganizationLevel.IsMarkedForDeletion)
						{
							existingOrganizationLevel.IsMarkedForDeletion = false;
						}
					}
				}

				foreach (SecurityGroupOrganizationLevel securityGroupOrganizationLevel in this)
				{					
					OrganizationSummary organization = null;
					if(securityGroupOrganizationLevel.OrganizationID==0)
						securityGroupOrganizationLevel.MarkDel();
					else
					{
						organization = organizations.FindBy(securityGroupOrganizationLevel.OrganizationID);
						if (!organization.Selected)						
							securityGroupOrganizationLevel.MarkDel();
						else 
						{
							if(securityGroupOrganizationLevel.Equal == notequal) // if current !equal changed
							{
								securityGroupOrganizationLevel.Equal = !notequal;
								securityGroupOrganizationLevel.MarkDirty();
							}
							if(this[0].AllRecords != all) // if current !all changed // checking only first record is enough
							{
								securityGroupOrganizationLevel.AllRecords = all;
								securityGroupOrganizationLevel.MarkDirty();
							}
						}
					}					
				}
			}
			else
			{				
				this.Clear();
				SecurityGroupOrganizationLevel newOrganizationLevel = null;
				newOrganizationLevel = new SecurityGroupOrganizationLevel(true);
				newOrganizationLevel.GroupID = groupID;
				newOrganizationLevel.OrganizationID = 0;
				newOrganizationLevel.OrganizationLevelID= organizations[0].OrganizationLevelID;
				newOrganizationLevel.Name = "ALL";						
				newOrganizationLevel.Equal = true;
				newOrganizationLevel.AllRecords = all;
				this.AddRecord(newOrganizationLevel);
			}

		}

//			public void SynchronizeOrganizationLevelsFromSelectableCollection(int groupID, OrganizationSummaryCollection organizations,bool notequal,bool all)
//			{		
//				foreach (OrganizationSummary organization in organizations)
//				{
//					if (organization.Selected)
//					{
//						SecurityGroupOrganizationLevel existingOrganizationLevel = this.FindBy(organization.OrganizationID);
//						if (existingOrganizationLevel == null)
//						{
//							SecurityGroupOrganizationLevel newOrganizationLevel = null;
//							newOrganizationLevel = new SecurityGroupOrganizationLevel(true);
//							newOrganizationLevel.GroupID = groupID;
//							newOrganizationLevel.OrganizationID = organization.OrganizationID;
//							newOrganizationLevel.OrganizationLevelID= organization.OrganizationLevelID;
//							newOrganizationLevel.Name = organization.Name;						
//							newOrganizationLevel.Equal = !notequal;
//							this.AddRecord(newOrganizationLevel);
//						}
//						else if (existingOrganizationLevel.IsMarkedForDeletion)
//						{
//							existingOrganizationLevel.IsMarkedForDeletion = false;
//						}
//					}
//				}
//
//				foreach (SecurityGroupOrganizationLevel securityGroupOrganizationLevel in this)
//				{
//					OrganizationSummary organization = null;
//					organization = organizations.FindBy(securityGroupOrganizationLevel.OrganizationID);
//					if (!organization.Selected)
//					{
//						securityGroupOrganizationLevel.MarkDel();
//					}
//					else 
//					{
//						if(!securityGroupOrganizationLevel.Equal != notequal) // if current !equal changed
//						{
//							securityGroupOrganizationLevel.Equal = !notequal;
//							securityGroupOrganizationLevel.MarkDirty();
//						}
//						if(securityGroupOrganizationLevel.AllRecords != all) // if current !all changed
//						{
//							securityGroupOrganizationLevel.AllRecords = all;
//							securityGroupOrganizationLevel.MarkDirty();
//						}
//					}
//				}
//			}
////			foreach (OrganizationSummary organization in organizations)
////			{
////				if(organization.IsDirty)
////				{
////					if(organization.Selected) 
////					{
////						SecurityGroupOrganizationLevel existingOrganizationLevel = this.FindBy(organization.OrganizationID);
////						if (existingOrganizationLevel == null)  // add item to the collection
////						{
////							SecurityGroupOrganizationLevel newOrganizationLevel = null;
////							newOrganizationLevel = new SecurityGroupOrganizationLevel(true);
////							newOrganizationLevel.GroupID = groupID;
////							newOrganizationLevel.OrganizationID = organization.OrganizationID;
////							newOrganizationLevel.OrganizationLevelID= organization.OrganizationLevelID;
////							newOrganizationLevel.Name = organization.Name;
////							//newOrganizationLevel.Permission = (int)EnumPermission.Admin;
////							this.AddRecord(newOrganizationLevel);
////							organization.IsDirty = false;
////						}
////					}
////					else
////					{
////						SecurityGroupOrganizationLevel existingOrganizationLevel = this.FindBy(organization.OrganizationID);
////						if (existingOrganizationLevel != null)  // add item to the collection
////							existingOrganizationLevel.MarkDel();
////					}
////				}
////			}
//		//}

		protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);
			try
			{
				((SecurityGroupOrganizationLevel)data).Name = rdr["Name"].ToString();
			}
			catch(Exception ex)
			{}
		}

//		public override int AddRecord(BaseDataClass data)
//		{
//			int ret = base.AddRecord (data);
//			ResetIndexers();
//			return ret;
//		}

//		private void ResetIndexers()
//		{
//			// Rebuild indexers
//			// TODO: Remove this when the library automatically supports this feature
//			indexBy_OrganizationID = null;
//		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SecurityGroupOrganizationLevel this[int index]
		{
			get
			{
				return (SecurityGroupOrganizationLevel)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		/// <summary>
		/// Hashtable based index on organizationID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_OrganizationID
		{
			get
			{
				if (this.indexBy_OrganizationID == null)
					this.indexBy_OrganizationID = new CollectionIndexer(this, new string[] { "organizationID" }, true);
				return this.indexBy_OrganizationID;
			}			
		}

		/// <summary>
		/// Hashtable based search on organizationID fields returns the object.  Uses the IndexBy_OrganizationID indexer.
		/// </summary>
		public SecurityGroupOrganizationLevel FindBy(int organizationID)
		{			
			if(this.IndexBy_OrganizationID!=null)
				this.IndexBy_OrganizationID.Rebuild();
			return (SecurityGroupOrganizationLevel)this.IndexBy_OrganizationID.GetObject(organizationID);
		}
	}

}
