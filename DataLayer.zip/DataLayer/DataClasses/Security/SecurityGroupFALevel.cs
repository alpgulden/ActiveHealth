using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	public enum EnumPermission
	{
		Admin = 0,
		ReadOnly = 1,
		FullAccess = 2		
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [SecurityGroupFALevel]
	/// </summary>
	[SPAutoGen("usp_GetAllFALevels","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetFALevelByGroupID","SelectAllByGivenArgs.sptpl","groupID")]
	[SPInsert("usp_InsertSecurityGroupFALevel")]
	[SPUpdate("usp_UpdateSecurityGroupFALevel")]
	[SPDelete("usp_DeleteSecurityGroupFALevel")]
	[SPLoad("usp_LoadSecurityGroupFALevel")]
	[TableMapping("SecurityGroupFALevel","groupID,fALevelID",true)]
	public class SecurityGroupFALevel : BaseData
	{
		[NonSerialized]
		private SecurityGroupFALevelCollection parentSecurityGroupFALevelCollection;
		[ColumnMapping("GroupID",StereoType=DataStereoType.FK)]
		private int groupID;		

		[ColumnMapping("FALevelID",StereoType=DataStereoType.FK)]
		private int fALevelID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("Permission")]
		private int permission;

		private SecurityFALevel securityFALevel;
		private bool readOnly;
		private bool fullAccess;
		private string fALevelName;

		public SecurityGroupFALevel()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public SecurityGroupFALevel(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		protected override void NewRecord()
		{
			base.NewRecord();
			this.createTime = DateTime.Now;
			this.createdBy	= createdBy;		
		}

		[FieldValuesMember("LookupOf_GroupID", "GroupID", "GroupName")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@GROUP@")]
		public int GroupCombo
		{
			get { return this.groupID; }
			set { this.groupID = value; }
		}

		public int GroupID
		{
			get { return this.groupID; }
			set { this.groupID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int FALevelID
		{
			get { return this.fALevelID; }
			set { this.fALevelID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int Permission
		{
			get { return this.permission; }
			set { this.permission = value; }
		}

		[FieldDescription("@READONLYCOL@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool ReadOnly
		{
			get {return this.readOnly;}
			set {this.readOnly=value;}
		}

		[FieldDescription("@FULLACCESS@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool FullAccess
		{
			get {return this.fullAccess;}
			set {this.fullAccess =value;}
		}

		[FieldDescription("@FALEVELNAME@")]
		[ControlType(EnumControlTypes.TextBox)]
		public string FALevelName
		{
			get {return this.fALevelName;}
			set {this.fALevelName=this.SecurityFALevel.FALevelName;}
		}		

		/// <summary>
		/// Parent SecurityGroupFALevelCollection that contains this element
		/// </summary>
		public SecurityGroupFALevelCollection ParentSecurityGroupFALevelCollection
		{
			get
			{
				return this.parentSecurityGroupFALevelCollection;
			}
			set
			{
				this.parentSecurityGroupFALevelCollection = value; // parent is set when added to a collection
			}
		}

		public SecurityFALevel SecurityFALevel
		{
			get
			{
				if (this.securityFALevel == null)
					this.securityFALevel = this.GetLinkedSecurityFALevel();
				return this.securityFALevel;
			}
		}

		public SecurityFALevel GetLinkedSecurityFALevel()
		{
			if (FALevelID == 0)
				return null;
			SecurityFALevel securityFALevel = new SecurityFALevel();
			if (SecurityFALevel.Load(this.fALevelID))
				return securityFALevel;
			else
				return null;
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			switch (this.permission)
			{
				case (int)EnumPermission.ReadOnly:
					this.readOnly=true;
					this.fullAccess =false;
					break;
				case (int)EnumPermission.FullAccess:
					this.fullAccess =true;
					this.readOnly=false;
					break;
			}
		}

		public SecurityGroupCollection LookupOf_GroupID
		{
			get
			{
				return SecurityGroupCollection.AllSecurityGroups; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}
		
	}

	/// <summary>
	/// Strongly typed collection of SecurityGroupFALevel objects
	/// </summary>
	[ElementType(typeof(SecurityGroupFALevel))]
	public class SecurityGroupFALevelCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_FALevelID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SecurityGroupFALevel elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSecurityGroupFALevelCollection = this;
			else
				elem.ParentSecurityGroupFALevelCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SecurityGroupFALevel elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SecurityGroupFALevel this[int index]
		{
			get
			{
				return (SecurityGroupFALevel)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SecurityGroupFALevel)oldValue, false);
			SetParentOnElem((SecurityGroupFALevel)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSelectedFALevelByGroup(int maxRecords, int groupID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadSelectedFALevelByGroup", maxRecords, this, false, new object [] { groupID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSelectedBuiltinFALevelsByGroup(int maxRecords, int groupID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadSelectedBuiltinFALevelsByGroup", maxRecords, this, false, new object [] { groupID });
		}	

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllFALevels(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllFALevels", maxRecords, this, false);
		}

		/// <summary>
		/// Hashtable based index on roleID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_FALevelID
		{
			get
			{
				if (this.indexBy_FALevelID == null)
					this.indexBy_FALevelID = new CollectionIndexer(this, new string[] { "FALevelID" }, true);
				return this.indexBy_FALevelID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on roleID fields returns the object.  Uses the IndexBy_RoleID indexer.
		/// </summary>
		public SecurityGroupFALevel FindBy(int FALevelID)
		{
			if(indexBy_FALevelID!=null)
				this.indexBy_FALevelID.Rebuild();
			return (SecurityGroupFALevel)this.IndexBy_FALevelID.GetObject(FALevelID);
		}


		public void SynchronizeBuildinFALevelsFromSelectableCollection(int groupID, SecurityFALevelCollection securityFALevelCol)
		{	
			this.LoadSelectedBuiltinFALevelsByGroup(-1,groupID);
			foreach (SecurityFALevel securityFALevel in securityFALevelCol)
			{
				if(securityFALevel.IsDirty)
				{
					if(securityFALevel.Selected) 
					{
						SecurityGroupFALevel existingFALevel = this.FindBy(securityFALevel.FALevelID);
						if (existingFALevel == null)  // add item to the collection
						{
							SecurityGroupFALevel newSecurityGroupFALevel = null;
							newSecurityGroupFALevel = new SecurityGroupFALevel(true);
							newSecurityGroupFALevel.GroupID = groupID;
							newSecurityGroupFALevel.FALevelID = securityFALevel.FALevelID;
							newSecurityGroupFALevel.Permission = (int)EnumPermission.Admin;
							this.AddRecord(newSecurityGroupFALevel);
						}
					}
					else
					{
						SecurityGroupFALevel existingFALevel = this.FindBy(securityFALevel.FALevelID);
						if (existingFALevel != null)  // add item to the collection
							existingFALevel.MarkDel();
					}
				}
			}
		}

		public void SynchronizeFALevelsFromSelectableCollection(int groupID, SecurityFALevelCollection securityFALevelCol)
		{
			foreach (SecurityFALevel securityFALevel in securityFALevelCol)
			{
				if(securityFALevel.FullAccess || securityFALevel.ReadOnly) 
				{
					SecurityGroupFALevel existingFALevel = this.FindBy(securityFALevel.FALevelID);
					if (existingFALevel == null)
					{
						SecurityGroupFALevel newSecurityGroupFALevel = null;
						newSecurityGroupFALevel = new SecurityGroupFALevel(true);
						newSecurityGroupFALevel.GroupID = groupID;
						newSecurityGroupFALevel.FALevelID = securityFALevel.FALevelID;
						if(securityFALevel.ReadOnly)
							newSecurityGroupFALevel.Permission=(int)EnumPermission.ReadOnly;
						if(securityFALevel.FullAccess) // if both selected FullAccess will applied.
							newSecurityGroupFALevel.Permission=(int)EnumPermission.FullAccess;
						newSecurityGroupFALevel.IsDirty=true;
						this.AddRecord(newSecurityGroupFALevel);
					}
					else if (existingFALevel.IsMarkedForDeletion)
					{
						existingFALevel.IsMarkedForDeletion = false;
					}
				}
			}

			foreach (SecurityGroupFALevel securityGroupFALevel in this)
			{
				SecurityFALevel securityFALevel = null;
				if(securityGroupFALevel.FALevelID==0)
				{
					securityGroupFALevel.IsMarkedForDeletion = false;
					securityGroupFALevel.IsDirty=true;
				}
				else
				{
					securityFALevel = securityFALevelCol.FindBy(securityGroupFALevel.FALevelID);
					securityGroupFALevel.IsDirty=true;
					if(securityFALevel.ReadOnly)
						securityGroupFALevel.Permission=(int)EnumPermission.ReadOnly;
					else if(securityFALevel.FullAccess) // if both selected FullAccess will applied.
						securityGroupFALevel.Permission=(int)EnumPermission.FullAccess;
					else
						securityGroupFALevel.MarkDel();
				}
			}

		}
//		
//		public override int AddRecord(BaseDataClass data)
//		{
//			int ret = base.AddRecord (data);
//			// Rebuild indexers 
//			// TODO: Remove this when the library automatically supports this feature
//			indexBy_FALevelID.Rebuild();
//			return ret;
//		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
	}
}
