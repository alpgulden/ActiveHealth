using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	public enum EnumUserStatus
	{
		//Admin = 0,
		Normal = 1,
		Suspended = 2
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [AAUser]
	/// </summary>	
	///[SPAutoGen("usp_LoadSecurityGroupUser","SelectRelatedFromLinkedTableWithFilter.sptpl","SecurityGroupUser, UserID, GroupID,UserId ")]
	[SPAutoGen("usp_GetActiveAAUser","SelectAllByGivenArgs.sptpl","status", InjectOrderBy="ORDER BY name")]
	[SPAutoGen("usp_GetByLoginName","SelectAllByGivenArgs.sptpl","loginName")]
	[SPAutoGen("usp_GetAllAAUser","SelectAll.sptpl","")]
	[SPAutoGen("usp_LoadSecurityGroupUsers","SelectRelatedFromLinkedTable.sptpl","SecurityGroupUser, UserID, GroupID")]	
	[SPInsert("usp_InsertAAUser")]
	[SPUpdate("usp_UpdateAAUser")]
	[SPDelete("usp_DeleteAAUser")]
	[SPLoad("usp_LoadAAUser")]
	[TableMapping("AAUser","userId")]
	public class AAUser : BaseData
	{
		[NonSerialized]
		private AAUserCollection parentAAUserCollection;
		[ColumnMapping("UserId",StereoType=DataStereoType.FK)]
		private int userId;
		[ColumnMapping("Name")]
		private string name;
		[ColumnMapping("LoginName")]
		private string loginName;
		[ColumnMapping("Password")]
		private string password;
		[ColumnMapping("Location")]
		private string location;
		[ColumnMapping("Phone",StereoType=DataStereoType.USPhoneNumber)]
		private string phone;
		[ColumnMapping("Extention")]
		private string extention;
		[ColumnMapping("FailedLogins")]
		private int failedLogins;
		[ColumnMapping("Status",StereoType=DataStereoType.FK)]
		private int status;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("PasswordDate")]
		private DateTime passwordDate;
		[ColumnMapping("Salt")]
		private string salt;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]
		private int providerID;
		private string newPassword;

		private SecurityGroupUserCollection securityGroupUsers;
		private SecurityGroup securityGroup;
		private TeamUserCollection teamUsers;

		private SecurityGroupProcedureLevelCollection procedureRangeFilters;
		private SecurityGroupDiagnosisLevelCollection diagnosticRangeFilters;

		public AAUser()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public AAUser(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			this.active = true;
		
		}

		/// <summary>
		/// Force reload the cached data and collections.
		/// Whenever user information was changed this method is called by the security 
		/// to allow currently logged in user to be notified.
		/// </summary>
		public void InvalidateData()
		{
			// force reload the following collections.
			this.procedureRangeFilters = null;
			this.diagnosticRangeFilters = null;
		}

		protected override void NewRecord()
		{
			base.NewRecord();
			this.createTime = DateTime.Now;
			this.CreatedBy = 1;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int UserId
		{
			get { return this.userId; }
			set { this.userId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		public string LoginName
		{
			get { return this.loginName; }
			set { this.loginName = value; }
		}

		[FieldDescription("@NEWPASSWORD@")]
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=40)]
		public string Password
		{
			get { return this.password; }
			set { this.password = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=40)]
		public string NewPassword
		{
			get { return this.newPassword; }
			set { this.newPassword = value; }
		}
		

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Location
		{
			get { return this.location; }
			set { this.location = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=10)]
		public string Phone
		{
			get { return this.phone; }
			set { this.phone = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int FailedLogins
		{
			get { return this.failedLogins; }
			set { this.failedLogins = value; }
		}

		[FieldValuesMember("ValuesOf_Status")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int Status
		{
			get { return this.status; }
			set { this.status = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PasswordDate
		{
			get { return this.passwordDate; }
			set { this.passwordDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string Salt
		{
			get { return this.salt; }
			set { this.salt = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch(Exception ex)
			{	
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw;
				//throw new Exception("Problem occured while saving the form." + ex.Message);
			}

		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int userId)
		{
			return base.Load(userId);
		}

		/// <summary>
		/// Parent AAUserCollection that contains this element
		/// </summary>
		public AAUserCollection ParentAAUserCollection
		{
			get
			{
				return this.parentAAUserCollection;
			}
			set
			{
				this.parentAAUserCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Return the linked group.  This group must be linked to a single group only.
		/// If there are more than 1 group linked, this is an invalid case, and this
		/// property will throw an exception.
		/// </summary>
		public SecurityGroup SecurityGroup
		{
			get
			{
				// The security group was either given at the construction of this problem as a new problem
				// or loaded from the db.
				if (this.securityGroup==null)
				{
					SecurityGroupUser securityGroupUser = this.SecurityGroupUser;
					if (securityGroupUser != null)
						this.SecurityGroup = securityGroupUser.SecurityGroup;
				}
				return this.securityGroup;
			}
			set
			{
				if (this.securityGroup != null)
					throw new Exception("An existing link to a security group can't be changed on the active advise user object");
				this.securityGroup = value;
			}
		}

		/// <summary>
		/// Child SecurityGroupUsers mapped to related rows of table SecurityGroupUser where [UserId] = [UserID]
		/// </summary>
		[SPLoadChild("usp_LoadAAUserSecurityGroups", "userID")]
		public SecurityGroupUserCollection SecurityGroupUsers
		{
			get { return this.securityGroupUsers; }
			set
			{
				this.securityGroupUsers = value;
				if (value != null)
					value.ParentAAUser = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Returns the actual collection of users linked to this group.
		/// </summary>
		/// <returns></returns>
		public SecurityGroupCollection GetLinkedGroups()
		{
			SecurityGroupCollection securityGroupCol = new SecurityGroupCollection();
			securityGroupCol.LoadLinkedSecurityGroups(this);
			return securityGroupCol;
		}

		/// <summary>
		/// Loads the SecurityGroupUsers collection
		/// </summary>
		public void LoadSecurityGroupUsers(bool forceReload)
		{
			this.securityGroupUsers = (SecurityGroupUserCollection)SecurityGroupUserCollection.LoadChildCollection("SecurityGroupUsers", this, typeof(SecurityGroupUserCollection), securityGroupUsers, forceReload, null);
		}

		/// <summary>
		/// Saves the SecurityGroupUsers collection
		/// </summary>
		public void SaveSecurityGroupUsers()
		{
			SecurityGroupUserCollection.SaveChildCollection(this.securityGroupUsers, true);
		}

		/// <summary>
		/// Synchronizes the SecurityGroupUsers collection
		/// </summary>
		public void SynchronizeSecurityGroupUsers()
		{
			SecurityGroupUserCollection.SynchronizeChildCollection(this.securityGroupUsers, true);
		}

		public SecurityGroupUser SecurityGroupUser
		{
			get
			{
				LoadSecurityGroupUsers(false);
				if (this.SecurityGroupUsers.Count > 0)
				{
					return this.SecurityGroupUsers[0];
				}

				return null;		// no patient-problem link
			}
		}

		public object[,] ValuesOf_Status
		{
			get
			{
				return new object[,] {
					//{(int)EnumUserStatus.Admin, "ADMIN" },
					{(int)EnumUserStatus.Normal, "NORMAL"} ,
					{(int)EnumUserStatus.Suspended, "SUSPENDED" }
				};
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string Extention
		{
			get { return this.extention; }
			set { this.extention = value; }
		}


		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=100)]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		/// <summary>
		/// Child TeamUsers mapped to related rows of table TeamUser where [UserId] = [UserId]
		/// </summary>
		[SPLoadChild("usp_LoadAAUserTeamUser", "userId")]
		public TeamUserCollection TeamUsers
		{
			get { return this.teamUsers; }
			set
			{
				this.teamUsers = value;
				if (value != null)
					value.ParentAAUser = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the TeamUsers collection
		/// </summary>
		public void LoadTeamUsers(bool forceReload)
		{
			this.teamUsers = (TeamUserCollection)TeamUserCollection.LoadChildCollection("TeamUsers", this, typeof(TeamUserCollection), teamUsers, forceReload, null);
		}

		/// <summary>
		/// Saves the TeamUsers collection
		/// </summary>
		public void SaveTeamUsers()
		{
			TeamUserCollection.SaveChildCollection(this.teamUsers, true);
		}

		/// <summary>
		/// Synchronizes the TeamUsers collection
		/// </summary>
		public void SynchronizeTeamUsers()
		{
			TeamUserCollection.SynchronizeChildCollection(this.teamUsers, true);
		}

		/// <summary>
		/// Returns the procedure range filters for this user.
		/// </summary>
		/// <returns></returns>
		public SecurityGroupProcedureLevelCollection GetProcedureRangeFilters()
		{
			SecurityGroupProcedureLevelCollection rangeFilters = new SecurityGroupProcedureLevelCollection();
			rangeFilters.LoadProcedureRangeFiltersForUser(this.UserId);
			return rangeFilters;
		}

		/// <summary>
		/// Loaded and cached procedure range filters collection
		/// </summary>
		public SecurityGroupProcedureLevelCollection ProcedureRangeFilters
		{
			get
			{
				if (procedureRangeFilters == null)
					procedureRangeFilters = GetProcedureRangeFilters();
				return procedureRangeFilters;
			}
		}

		/// <summary>
		/// Returns the diagnostic range filters for this user.
		/// </summary>
		/// <returns></returns>
		public SecurityGroupDiagnosisLevelCollection GetDiagnosticRangeFilters()
		{
			SecurityGroupDiagnosisLevelCollection rangeFilters = new SecurityGroupDiagnosisLevelCollection();
			rangeFilters.LoadDiagnosticRangeFiltersForUser(this.UserId);
			return rangeFilters;
		}

		/// <summary>
		/// Loaded and cached diagnostic range filters collection
		/// </summary>
		public SecurityGroupDiagnosisLevelCollection DiagnosticRangeFilters
		{
			get
			{
				if (diagnosticRangeFilters == null)
					diagnosticRangeFilters = GetDiagnosticRangeFilters();
				return diagnosticRangeFilters;
			}
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadByLoginName(string loginName)
		{
			return SqlData.SPExecReadObj("usp_GetByLoginName", this, false, new object[] { loginName });
		}


		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of AAUser objects
	/// </summary>
	[ElementType(typeof(AAUser))]
	public class AAUserCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_UserId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AAUser elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAAUserCollection = this;
			else
				elem.ParentAAUserCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AAUser elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AAUser this[int index]
		{
			get
			{
				return (AAUser)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AAUser)oldValue, false);
			SetParentOnElem((AAUser)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		
		/// <summary>
		/// Executes a stored procedure and load the collection.
		/// </summary>
		public int GetAllAAUsers(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllAAUser", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSecurityGroupUsers(int maxRecords, int groupId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadSecurityGroupUsers", maxRecords, this, false, groupId);
		}

		public int LoadLinkedSecurityGroupUsers(SecurityGroup securityGroup)
		{
			if (securityGroup == null)
				throw new Exception("No security group was specified to LoadSecurityGroupUsers");

			if (securityGroup.IsNew)
			{
				this.Clear();
				return 0;
			}

			int count = LoadSecurityGroupUsers(-1, securityGroup.GroupID);
			for (int i = 0; i < this.Count; i++)
			{
				this[i].SecurityGroup = securityGroup;
			}
			return count;
		}

		/// <summary>
		/// Accessor to a shared AAUserCollection which is cached in NSGlobal
		/// </summary>
		public static AAUserCollection AllUsers
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				AAUserCollection col = (AAUserCollection)NSGlobal.EnsureCachedObject("AllUsers", typeof(AAUserCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllAAUsers(-1);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on userId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_UserId
		{
			get
			{
				if (this.indexBy_UserId == null)
					this.indexBy_UserId = new CollectionIndexer(this, new string[] { "userId" }, true);
				return this.indexBy_UserId;
			}
			
		}

		/// <summary>
		/// Looks up by userId and returns LoginName value.  Uses the IndexBy_UserId indexer.
		/// </summary>
		public string Lookup_LoginNameByUserId(int userId)
		{
			return this.IndexBy_UserId.LookupStringMember("LoginName", userId);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveAAUser(int maxRecords, int status)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveAAUser", maxRecords, this, false, new object[] { status });
		}

	}
}
