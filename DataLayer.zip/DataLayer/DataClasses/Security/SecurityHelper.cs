using System;
using System.Data;
using System.Web.Security;
using System.Security.Cryptography;
using System.Data.SqlClient;
using NetsoftUSA.Security.Cryptography;
using System.Collections;
using Microsoft.ApplicationBlocks.Data;
using System.Security.Principal;
using NetsoftUSA.DataLayer;
using System.Web;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for SecurityHelper.
	/// </summary>
	public class AASecurityHelper
	{
		public const string CurrentlyLoggedInUserCacheKey = "__CurrentlyLoggedInUser__";

		public AASecurityHelper()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static void Logout()
		{
			#region Clear cached AAUser object -- Added by Ilkay

			ResetAAUser();

			#endregion

			//remove Login Name from Session
			RemoveSessionKey = 	LOGIN_NAME;

			//remove principal from cache
			RemoveCachedPrincipalByUserId = GetUserId;

			//Remove auth cookie
			FormsAuthentication.SignOut();
			
			// Clear session contents
			HttpContext.Current.Session.Contents.Clear();
			// and kill it
			HttpContext.Current.Session.Abandon();
		}

		public static void Logout(string urlRedirect)
		{
			Logout();

			string strRedirectUrl;

			if(urlRedirect.Length > 0)
			{				
				strRedirectUrl = urlRedirect;			
			}
			else
			{
				strRedirectUrl = defaultRedirectUrl;
			}

			HttpContext.Current.Response.Redirect(strRedirectUrl);

		}

		#region Role methods
		
		public static string[] GetRoles(int iUserId)
		{
			// Retrieves the user's list of roles from the database
			// and returns an array that can be used to create a principal object
			string conString = NetsoftUSA.Security.WebApplication.ConnectionString;
			string strSP = "usp_GetRolesByUserId";

			ArrayList roleArray = new ArrayList();

			SqlDataReader reader = null;

			SqlConnection cnn = null;
			try
			{
				// Don't use ExecuteReader with string connection.  The connection is left open!
				cnn = new SqlConnection(conString);
				reader = SqlHelper.ExecuteReader(0, cnn,
					strSP, new SqlParameter("@UserId", iUserId));

				if (!reader.HasRows)
				{
					return null;
				}
				// Return output parameters from returned data stream
				while (reader.Read())
				{
					roleArray.Add(reader.GetString(0));
				}

			}
			/*catch(Exception ex)
			{
				// No need for this.
				throw new ActiveAdviceException(AAExceptionAction.None, ex.Message, "");	
			}*/
			finally
			{
				// Always close the reader and connection seperately.
				if (reader != null)
					reader.Close();
				if (cnn != null)
					cnn.Close();
			}
			
			return (string[]) roleArray.ToArray(typeof(string));
		}
		
		private static bool HasRole(string strAARole, bool bIncludeAdminOrFull)
		{
			//send bIncludeAdminOrFull= true for role with FULL flag  
			// like role: AASecurityHelper.MATERNICHEK
			if(bIncludeAdminOrFull && (IsAdminRole || IsFullRole)) 
				return  true;
							
			return IsInRole(strAARole);
		}

		public static bool HasFullAccessRole(string strAARole)
		{
			//include checking Builtin Roles: Administrator and Full			
			return HasRole(strAARole, true);
		}

		public static bool IsInRole(string strAARole)
		{
			IPrincipal p = HttpContext.Current.User;				
			return p.IsInRole(strAARole);
		}
		


		#endregion Role methods

		#region Permission consts

		private const string READ_ONLY = "Read Only";
		public const string FULL = "Full";
		public const string ADMIN = "Administrator";
		
		public const string CODE_TABLES = "Code Tables Full";
		public const string INTAKE = "Intake Full";
		public const string PATIENT_SUMMARY = "Patient Summary Full";
		public const string PATIENT_INFORMATION = "Patient Information Full";
		public const string PROBLEMS = "Problems Full";
		public const string EVENTS = "Events Full";
		public const string REVIEWS = "Reviews Full";
		public const string DIAGNOSTICS_PROCEDURES = "Diagnostics & Procedures Full";
		public const string REFERRALS = "Referrals Full";
		public const string CLINICAL_MGMT_SERVICE = "Clinical Management Service Full";
		public const string ERCLINK = "ERC Link Full";

		public const string CARE_MANAGEMENT = "Care Management Full";
		public const string MATERNICHEK = "Maternichek Full";
		public const string WORKERS_COMP = "Workers Compensation Full";
		public const string GUIDELINES = "Guidelines Full";
		public const string REPORTS = "Reports Full";
		public const string CONTACTS = "Contacts Full";
		public const string WORKLISTS = "Worklists Full";
		public const string ACTIVITIES = "Activities Full";
		public const string NOTES = "Notes Full";
		//public const string SYS_ADMIN_UTILITIES = "System Administration & Utilities Full";

		public const string PLAN = "Plan Full";
		public const string PROVIDER = "Provider Full";
		public const string LETTER_SETUP = "Letter Setup Full";
		public const string LETTER_GENERATE_BATCH = "Letter Generate Batch Full";
		public const string LETTER_SEND = "Letter Send Full";
		public const string MEDICATIONS = "Medications Full";
		public const string MEASUREMENTS = "Measurements Full";
		public const string ALLERGIES = "Allergies Full";
		public const string LETTER_DRAFT_QUEUE = "Letter Draft Queue Full";	
		public const string FILE_MAINTENANCE = "File Maintenance Full";

		public const string ASSESSMENTS_MAINT = "Assessments Maintenance Full";
		public const string CMS_MAINT = "CMS Maintenance Full";
		public const string IMPORT_EXPORT_MAINT = "Import Export Maintenance Full";
		public const string USER_DEFINED_MAINT = "User Defined Maintenance Full";
		public const string AUTO_ACTIVITIES_MAINT = "Auto Activities Maintenance Full";
		public const string GUIDELINES_MAINT = "Guidelines Maintenance Full";
		public const string TEAMS_MAINT = "Teams Maintenance Full";
		public const string ENROLLMENTS_MAINT = "Enrollments Maintenance Full";
		public const string SYSTEM_SETTINGS = "System Settings Full";
		public const string ORGANIZATIONS = "Organizations Full";

		public const string ELIGIBILITY_SEARCH = "Eligibility Search Full";
		public const string AD_HOC_LETTERS = "Ad Hoc Letters Full";
		
		// added by Burag C. on 03/03/06 for ERC Move Access.
		public const string MOVEERC_MAINTENANCE = "Move Event, Referral, CMS Maintenance Full";

		#endregion Permission 

		#region Static variables and contants

		public const string CACHED_PRINCIPAL ="CachedPrincipal";	//cached principal by UserId 

		public const string LOGIN_NAME = "LoginName";

		public static string defaultRedirectUrl; // set in Global.asax "PatientSearch.aspx";		

		public const string READ_ONLY_DB ="ReadOnlyDB";		// key in web.config

		#endregion Static variables and contants

		#region Static Properties 

		/// <summary>
		/// GetUserID
		/// If this value is not set, it will retrieve the userid from the
		/// context. Therefore the Service will set this value to what it
		/// wants to be used.
		/// </summary>
		static int getuserid = 0;
		public static int GetUserId
		{
			get
			{
				if (0 == getuserid)
				{
					string userId = "";
					int iUserID = 0;
					if(HttpContext.Current.Request.IsAuthenticated)
					{
						IIdentity ID = HttpContext.Current.User.Identity;
			
						if(ID.AuthenticationType == "Forms")			
						{
							userId = ID.Name;
							iUserID = Int32.Parse(userId);				
						}
					}

					return iUserID;
				}

				return getuserid;
			}
			set { getuserid = value; }
		}

		public static string UserName
		{
			get
			{	

				if(HttpContext.Current.Session == null || 
					HttpContext.Current.Session[LOGIN_NAME] == null) return "";

				return HttpContext.Current.Session[LOGIN_NAME].ToString();
			}

			set
			{
				HttpContext.Current.Session[LOGIN_NAME] = value;
			}
		}

		public static IIdentity GetIdentity
		{
			get
			{
				IIdentity ID = null;
				
				if(HttpContext.Current.Request.IsAuthenticated)
				{
					ID = HttpContext.Current.User.Identity;
				}
			
				return ID;
			}
		}


		public static int SessionTimeOut
		{
			get
			{
				if(HttpContext.Current.Session == null) return 20;		
				return HttpContext.Current.Session.Timeout;
			}
		}

		//VS
		//strTimer = String.Format("<script language='javascript'>setTimeout(\"__doPostBack('','');\", '{0}');</script>", (this.Session.Timeout * 60000)  ); // 60000 = 1 minutes. 
		//Response.Write(AASecurityHelper.TimeoutJS);
		public static string TimeoutJS
		{
			get
			{	
				string strTimer = String.Format("<script language='javascript'>setTimeout(\"__doPostBack('','');\", '{0}');</script>",
					(SessionTimeOut * 60000)  ); // 60000 = 1 minutes. 

				return strTimer;
			}
		}

		public static int CachedPrincipalTimeOut
		{
			get
			{	
				// set cached principaltimeout more than Session Timeout				
				if(HttpContext.Current.Session == null) return 30;		
				return HttpContext.Current.Session.Timeout + 10;
			}
		}

		
		public static string RemoveSessionKey
		{
			set
			{
				if(HttpContext.Current.Session != null)
					HttpContext.Current.Session.Remove(value);
			}
		}

		
		public static int RemoveCachedPrincipalByUserId
		{
			set
			{
				#region Remove cached AAUser object -- added by ilkay

				ResetAAUser(value);

				#endregion

				if(HttpContext.Current.Cache != null && value > 0)
				{
					string key = CACHED_PRINCIPAL + value.ToString();
					HttpContext.Current.Cache.Remove(key);
				}
			}
		}


		public static bool IsAdminRole
		{
			get
			{
				IPrincipal p = HttpContext.Current.User;				
				return p.IsInRole(AASecurityHelper.ADMIN);
			}
		}

		public static bool IsFullRole
		{
			get
			{
				IPrincipal p = HttpContext.Current.User;				
				return p.IsInRole(AASecurityHelper.FULL);
			}
		}

		#region Cached AAUser Object for access to security object model -- Added by Ilkay

		/// <summary>
		/// -- Added by Ilkay
		/// 
		/// Loads, caches and returns the currently logged in AAUser object.
		/// Business Layer or UI Layer objects can use this to get security
		/// related information from AAUser object.
		/// </summary>
		public static AAUser AAUser
		{
			get
			{
				int userID = GetUserId;
				System.Web.SessionState.HttpSessionState session = null;
				
				if (HttpContext.Current != null)
					session = HttpContext.Current.Session;
				AAUser user = null;

				// check whether there's an already cached user.
				if (session != null)
					user = (AAUser)session[CurrentlyLoggedInUserCacheKey];
				else
					user = (AAUser)NSGlobal.GetCachedObject(CurrentlyLoggedInUserCacheKey + userID.ToString());	// this cache is not user specific
				
				if (user != null)
				{
					// There's a cached object.  Check it's validity by comparing with current userID.  This would normally never occur!
					if (user.UserId != userID)
					{
						// There's a conflict.  Just attempt reloading the object for new userID.
						user = null;	// this will force reload in the next step
					}
				}

				if (user == null)  // No valid user in the cache.
				{
					if (userID == 0)
						user = new AAUser(true); // non-existant user.  Still make a user object available for convenience.  IsNew = true will reveal this was a null user.
					else
					{
						// try to load the user object
						user = new AAUser();
						user.Load(userID);		// if can't load just ignore.  IsNew = false will reveal that this id couldn't be loaded.
					}

					// if there's a session, cache the object to session.
					// otherwise cache the object to global cache with a user specific key.
					if (session != null)
						session[CurrentlyLoggedInUserCacheKey] = user;
					else
						NSGlobal.CacheObject(CurrentlyLoggedInUserCacheKey + userID.ToString(), user);
				}
				
				return user;
			}

		}

		/// <summary>
		/// Reset the currently loggend in user by removing the cached AAUser object
		/// </summary>
		public static void ResetAAUser()
		{
			ResetAAUser(GetUserId);
		}

		/// <summary>
		/// Reset the currently loggend in user by removing the cached AAUser object
		/// </summary>
		public static void ResetAAUser(int userID)
		{
			// -- Added by Ilkay

			System.Web.SessionState.HttpSessionState session = HttpContext.Current.Session;
			// check whether there's an already cached user.
			if (session != null)
				session.Remove(CurrentlyLoggedInUserCacheKey);
			else
				NSGlobal.CacheObject(CurrentlyLoggedInUserCacheKey + userID.ToString(), null);	// this cache is not user specific
		}
		

		#endregion Cached AAUser Object for access to security object model -- Added by Ilkay

		#endregion Static Properties 

		#region Utility Methods
		public static string dbGetString(SqlDataReader reader, int intField)
		{
			string rtnString = "";
			if(!reader.IsDBNull( intField ))
			{
				rtnString = reader.GetString(intField);
			}
			return rtnString;
		}

		public static string HashPasswordWithSalt(string password, string salt)
		{
			return FormsAuthentication.HashPasswordForStoringInConfigFile(
				String.Concat(password, salt), HASH_PWD_FORMAT);

		}		

		
		#endregion Utility Methods

		#region Constants
		private const string HASH_PWD_FORMAT = "SHA1";

		#endregion Constants

		#region Authentication Methods

		
		public static int VerifyPasswordWithUserId(string suppliedLoginName,
			string suppliedPassword , ref string salt , ref string errMsg)
		{
			/*
			
			AAUser user = new AAUser();
			if (user.Load(suppliedLoginName))
				if (user.VerifyPassword(suppliedPassword))
					return true;
				//throw new ActiveAdviceException(AAExceptionAction.None, "user {0} not found", user.LoginName)
			*/

			bool passwordMatch = false;
			bool loginFound = false;
			string conString = NetsoftUSA.Security.WebApplication.ConnectionString;

			string strSP = "usp_getPassword";
			SqlDataReader reader = null;
			int userID = -1;
			string dbPasswordHash = "";
			//string salt = "";
			int status = -1;
			bool active = false;
			int failedlogins = -1;
			int iRtn = -1;

			SqlConnection cnn = null;
			try
			{
				// Don't use ExecuteReader with string connection.  The connection is left open!
				cnn = new SqlConnection(conString);
				reader = SqlHelper.ExecuteReader(0, cnn,
					strSP, new SqlParameter("@LoginName", suppliedLoginName));

				reader.Read(); // Advance to the one and only row
	
				loginFound = reader.HasRows;
				if (!loginFound)
				{
					errMsg = "Invalid User Name.";
					return iRtn;
				}
				else
				{
					// Return output parameters from returned data stream
					userID = reader.GetInt32(0);
					dbPasswordHash = reader.GetString(1);
					salt = dbGetString(reader,2);	//reader.GetString(2);
					status =  reader.GetInt32(3);
					active = reader.GetBoolean(4);
					failedlogins = reader.GetInt32(5);
					//reader.Close();		// we always close in the finally block
				}
				if (!active)
				{
					
					errMsg = "Account is not Active. Please contact your system administrator.";
					return iRtn;
					
				}
				if (status!= 1)
				{
					
					errMsg = "Account is locked out. Please contact your system administrator.";
					return iRtn;
				}
					
				// Hash pwd and salt from DB
				//VS temp: only for old (not hashed) pwd
				// it could be problem for those passwords that were not hashed in DB
				//string dbPasswordHash = HashPasswordWithSalt(dbPassword, salt);

				string hashedPasswordWithSalt = HashPasswordWithSalt(suppliedPassword, salt);
					
				// Now verify them.
				passwordMatch = hashedPasswordWithSalt.Equals(dbPasswordHash);


				//If Login failed we need to update the counter for the failed login attempts
				//Do not update/reset for "read only"
				bool readOnlyDB = NetsoftUSA.Security.ConfigHelper.GetConfigValueBool(READ_ONLY_DB, false);				
				if (!passwordMatch)
				{
					if (!readOnlyDB)
					{
						strSP = "usp_UpdateFailedLogin";
					
						int iRtn2 = SqlHelper.ExecuteNonQuery(0, conString,
							strSP, new SqlParameter("@LoginName", suppliedLoginName));

					}
					errMsg = "Invalid Password.";
				}
				else
				{ 
					if (!readOnlyDB)
					{
						strSP = "usp_ResetFailedLogin";

						int iRtn3 = SqlHelper.ExecuteNonQuery(0, conString,
							strSP, new SqlParameter("@LoginName", suppliedLoginName));
					}
					//Success with verification - return UserId to store in Auth ticket
					iRtn = userID;
					
				}

			}
			catch (Exception ex)
			{
				// We always close in the finally block.
				//if(reader !=null && !reader.IsClosed) reader.Close();
				errMsg = ex.Message;
			}
			finally
			{
				// Always close the reader and connection seperately.
				if (reader != null)
					reader.Close();
				if (cnn != null)
					cnn.Close();
			}
			//return -1 if error or UserId from DB if success
			return iRtn;
		}


		public static int ChangePasswordWithUserId(string suppliedLoginName,
			string suppliedOldPassword, string suppliedNewPassword  , ref string errMsg)
		{
			/*
			
			AAUser user = new AAUser();
			if (user.Load(suppliedLoginName))
				if (user.VerifyPassword(suppliedPassword))
					return true;
				//throw new ActiveAdviceException(AAExceptionAction.None, "user {0} not found", user.LoginName)
			*/

			//bool passwordMatch = false;
			bool loginFound = false;
			string conString = NetsoftUSA.Security.WebApplication.ConnectionString;
			
			string strSP = "usp_ChangePassword";
			SqlConnection cnn = null;
			SqlDataReader reader = null;
			int userID = -1;
					
			int iRtn = -1;
			
			string saltFromDb = "";

			//before SP call we need verify old password and hash new password
			
			try
			{	
		
				int iRtn1 = VerifyPasswordWithUserId(suppliedLoginName, suppliedOldPassword, ref saltFromDb, ref errMsg);

				if(iRtn1 > 0)
				{
					// user verified, continue changing password
					userID = iRtn1;
				}
				else if(errMsg.Length>0)
				{
					return iRtn;
				}
				else
				{
					errMsg = "Invalid User Name or Old Password. Please contact your system administrator.";
					return iRtn;
				}

				//after verification hash old and new password using salt fron DB
				suppliedOldPassword = HashPasswordWithSalt(suppliedOldPassword, saltFromDb);
				suppliedNewPassword = HashPasswordWithSalt(suppliedNewPassword, saltFromDb);


				// Don't use ExecuteReader with string connection.  The connection is left open!
				cnn = new SqlConnection(conString);
				reader = SqlHelper.ExecuteReader(0, cnn,
					strSP, new SqlParameter("@LoginName", suppliedLoginName),
					new SqlParameter("@OldPassword", suppliedOldPassword),
					new SqlParameter("@NewPassword", suppliedNewPassword) );

				reader.Read(); // Advance to the one and only row

				loginFound = reader.HasRows;
				if (!loginFound)
				{
					errMsg = "Invalid User Name or Old Password.";
					return iRtn;
				}
				else
				{
					// Return output parameters from returned data stream
					userID = reader.GetInt32(0);
					
					//reader.Close();
				}

				if(iRtn1 > 0 && errMsg.Length == 0)
					iRtn = userID;	//OK, return UserId and create Authenticated ticket

			}
			/*catch(Exception ex)
			{
				//if(reader !=null && !reader.IsClosed) reader.Close();	// we always close in the finally block
				throw new ActiveAdviceException(AAExceptionAction.None, ex.Message, suppliedLoginName);	<<-- ex.Message has no parameters, suppliedLoginName wouldn't be used
			}*/
			finally
			{
				// Always close the reader and connection seperately.
				if (reader != null)
					reader.Close();
				if (cnn != null)
					cnn.Close();
			}
				
				
			return iRtn;

		}

		
		

		#endregion Auth Methods


	}
}
