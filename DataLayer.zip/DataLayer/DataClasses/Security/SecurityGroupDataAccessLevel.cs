using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	public class SecurityGroupDataAccessLevel : BaseDataClass
	{
	
		[ColumnMapping("GroupID")]
		private int groupID;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;

		private bool selected;

		public SecurityGroupDataAccessLevel()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[FieldValuesMember("LookupOf_GroupID", "GroupID", "GroupID")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int GroupID
		{
			get { return this.groupID; }
			set { this.groupID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		// using in to the grid.
		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}

		public SecurityGroupCollection LookupOf_GroupID
		{
			get
			{
				return SecurityGroupCollection.AllSecurityGroups; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}


	}
}
