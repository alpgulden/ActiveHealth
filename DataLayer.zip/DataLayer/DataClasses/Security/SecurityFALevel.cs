using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SecurityFALevel]
	/// </summary>
	
	[SPAutoGen("usp_LoadAllSecurityFALevels","SelectAll.sptpl","")]
	[SPAutoGen("usp_LoadSecurityFALevelsByBuiltin","SelectAllByGivenArgs.sptpl","builtin")]
	[SPLoad("usp_LoadSecurityFALevel")]
	[SPInsert("usp_InsertSecurityFALevel")]
	[SPUpdate("usp_UpdateSecurityFALevel")]
	[SPDelete("usp_DeleteSecurityFALevel")]	
	[TableMapping("SecurityFALevel","fALevelID")]
	public class SecurityFALevel : BaseDataClass
	{
		[FormatterFunction("Fmt_parentSecurityFALevelCollection")]
		[NonSerialized]
		private SecurityFALevelCollection parentSecurityFALevelCollection;
		[ColumnMapping("FALevelID",StereoType=DataStereoType.FK)]
		private int fALevelID;
		[ColumnMapping("FALevelName")]
		private string fALevelName;
		[ColumnMapping("FALevelDescription")]
		private string fALevelDescription;
		[ColumnMapping("Builtin")]
		private bool builtin;
		private SecurityGroupFALevel securityGroupFALevel;
		private bool selected;
		private bool readOnly;
		private bool fullAccess;

		public SecurityFALevel()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int FALevelID
		{
			get { return this.fALevelID; }
			set { this.fALevelID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=100)]
		public string FALevelName
		{
			get { return this.fALevelName; }
			set { this.fALevelName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string FALevelDescription
		{
			get { return this.fALevelDescription; }
			set { this.fALevelDescription = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Builtin
		{
			get { return this.builtin; }
			set { this.builtin = value; }
		}

		[FieldDescription("@ASSIGNED@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool Selected
		{
			get { return this.selected;}
			set { this.selected = value;}
		}

		[FieldDescription("@READONLYCOL@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool ReadOnly
		{
			get {return this.readOnly;}
			set {this.readOnly=value;}
		}

		[FieldDescription("@FULLACCESS@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool FullAccess
		{
			get {return this.fullAccess;}
			set {this.fullAccess =value;}
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int fALevelID)
		{
			return base.Load(fALevelID);
		}

		/// <summary>
		/// Parent SecurityFALevelCollection that contains this element
		/// </summary>
		public SecurityFALevelCollection ParentSecurityFALevelCollection
		{
			get
			{
				return this.parentSecurityFALevelCollection;
			}
			set
			{
				this.parentSecurityFALevelCollection = value; // parent is set when added to a collection
			}
		}

		public string Fmt_parentSecurityFALevelCollection(ActiveAdvice.DataLayer.SecurityFALevelCollection parentSecurityFALevelCollection, bool withValue)
		{
			return Convert.ToString(parentSecurityFALevelCollection);
		}

	}

	/// <summary>
	/// Strongly typed collection of SecurityFALevel objects
	/// </summary>
	[ElementType(typeof(SecurityFALevel))]
	public class SecurityFALevelCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_FALevelID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SecurityFALevel elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSecurityFALevelCollection = this;
			else
				elem.ParentSecurityFALevelCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SecurityFALevel elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SecurityFALevel this[int index]
		{
			get
			{
				return (SecurityFALevel)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SecurityFALevel)oldValue, false);
			SetParentOnElem((SecurityFALevel)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent SecurityGroupFALevel that contains this collection
		/// </summary>
		public SecurityGroupFALevel ParentSecurityGroupFALevel
		{
			get { return this.ParentDataObject as SecurityGroupFALevel; }
			set { this.ParentDataObject = value; /* parent is set when contained by a SecurityGroupFALevel */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSecurityFALevelsByBuiltin(int maxRecords, int builtin)
		{
			this.Clear();                    
			return SqlData.SPExecReadCol("usp_LoadSecurityFALevelsByBuiltin", maxRecords, this, false, builtin);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllSecurityFALevels(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadAllSecurityFALevels", maxRecords, this, false);
		}

		public void SetSelectedFALevelsFromCollection(SecurityGroupFALevelCollection fALevels)
		{
			foreach (SecurityFALevel securityFALevel in this)
			{
				if (fALevels.FindBy(securityFALevel.FALevelID) != null)
					securityFALevel.Selected= true;
			}
		}

		public void SetPermitionFALevelsFromCollection(SecurityGroupFALevelCollection fALevels)
		{
			foreach (SecurityFALevel securityFALevel in this)
			{
				if (fALevels.FindBy(securityFALevel.FALevelID) != null)
				{
					securityFALevel.ReadOnly=fALevels.FindBy(securityFALevel.FALevelID).ReadOnly;
					securityFALevel.FullAccess=fALevels.FindBy(securityFALevel.FALevelID).FullAccess;
				}
			}
		}

		/// <summary>
		/// Hashtable based index on roleID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_FALevelID
		{
			get
			{
				if (this.indexBy_FALevelID == null)
					this.indexBy_FALevelID = new CollectionIndexer(this, new string[] { "FALevelID" }, true);
				return this.indexBy_FALevelID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on roleID fields returns the object.  Uses the IndexBy_RoleID indexer.
		/// </summary>
		public SecurityFALevel FindBy(int FALevelID)
		{
			return (SecurityFALevel)this.IndexBy_FALevelID.GetObject(FALevelID);
		}

	}
}
