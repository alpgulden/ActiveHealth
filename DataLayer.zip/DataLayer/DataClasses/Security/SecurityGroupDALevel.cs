using System;
using System.Data.SqlClient;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	[TableMapping("SecurityGroupOrganizationLevel","groupOrganizationLevelID")]
	public class SecurityGroupDALevel : BaseData
	{	
		[ColumnMapping("GroupID")]
		protected int groupID;

		[ColumnMapping("Equal")]
		protected bool equal;

		[ColumnMapping("AllRecords")]
		protected bool allRecords;

		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;

		private string item;
		private int itemID;
		protected bool selected;

		private Organization organization;

		[NonSerialized]
		private SecurityGroupDALevelCollection parentSecurityGroupDALevelCollection;

		public SecurityGroupDALevel()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public SecurityGroupDALevel(string Item)
		{
			this.Item=Item;
		}

		public SecurityGroupDALevel(string Item, int ItemID)
		{
			this.Item=Item;
			this.ItemID=ItemID;
		}

		[FieldValuesMember("LookupOf_GroupID", "GroupID", "GroupName")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@GROUPID@")]
		public int GroupID
		{
			get { return this.groupID; }
			set { this.groupID = value; }
		}


		public int ItemID
		{
			get { return this.itemID; }
			set { this.itemID = value; }
		}

		public string Item
		{
			get { return this.item; }
			set { this.item = value; }
		}

		[FieldDescription("@NOTEQUAL@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool Equal
		{
			get { return this.equal; }
			set { this.equal = value; }
		}

		[FieldDescription("@ALL@")]
		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool AllRecords
		{
			get { return this.allRecords; }
			set { this.allRecords = value; }
		}

		[FieldDescription("@ASSIGNED@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		public Organization Organization
		{
			get { return organization;}
			set { this.organization = value;}
		}

		public SecurityGroupCollection LookupOf_GroupID
		{
			get
			{
				return SecurityGroupCollection.AllSecurityGroups; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		/// <summary>
		/// Parent SecurityFALevelCollection that contains this element
		/// </summary>
		public SecurityGroupDALevelCollection ParentSecurityGroupDALevelCollection
		{
			get
			{
				return this.parentSecurityGroupDALevelCollection;
			}
			set
			{
				this.parentSecurityGroupDALevelCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of SecurityFALevel objects
	/// </summary>
	[ElementType(typeof(SecurityGroupDALevel))]
	public class SecurityGroupDALevelCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_DALevelID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SecurityGroupDALevel elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSecurityGroupDALevelCollection = this;
			else
				elem.ParentSecurityGroupDALevelCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SecurityGroupDALevel elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SecurityGroupDALevel this[int index]
		{
			get
			{
				return (SecurityGroupDALevel)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SecurityGroupDALevel)oldValue, false);
			SetParentOnElem((SecurityGroupDALevel)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent SecurityGroupFALevel that contains this collection
		/// </summary>
		public SecurityGroupDALevel ParentSecurityGroupDALevel
		{
			get { return this.ParentDataObject as SecurityGroupDALevel; }
			set { this.ParentDataObject = value; /* parent is set when contained by a SecurityGroupFALevel */ }
		}		

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllDALevels(int maxRecords)
		{
			this.Clear();
			int cnt=0;
//			SqlDataReader rdrOrganizations;
//			SqlDataReader rdrPlan;
//			SqlDataReader rdrDX;
//			SqlDataReader rdrPX;
//			SecurityGroupDALevelCollection col=new SecurityGroupDALevelCollection();			
		
//			SqlDataReader rdrOrganizations = SqlData.SPExecRead("usp_LoadSecurityGroupOrganizationLevels", maxRecords, this, false,new object[] {GroupID});
//			SqlDataReader rdrPlan = SqlData.SPExecRead("usp_LoadSecurityGroupPlanLevels", maxRecords, this, false,new object[] {GroupID});
//			SqlDataReader rdrDX = SqlData.SPExecRead("usp_LoadSecurityGroupProcedureLevels", maxRecords, this, false,new object[] {GroupID});
//			SqlDataReader rdrPX = SqlData.SPExecRead("usp_LoadSecurityGroupDiagnosisLevels", maxRecords, this, false,new object[] {GroupID});
			try
			{
//				if (rdrOrganizations != null)
//				{
//					while (rdrOrganizations.Read()) 
//					{
						SecurityGroupDALevel newItem=new SecurityGroupDALevel();
						newItem.ItemID = 1;
						newItem.Item = "Master Organizaion";
						this.AddRecord(newItem);
						newItem.ItemID = 2;
						newItem.Item = "Organization";
						this.AddRecord(newItem);
						newItem.ItemID = 3;
						newItem.Item = "Sub Organization";
						this.AddRecord(newItem);
//					}
//				}
//				if (rdrPlan != null)
//				{
//					if (rdrPlan.Read()) 
//					{
						newItem.ItemID = 4;
						newItem.Item = "Plan";
						this.AddRecord(newItem);						
//					}
//				}
//				if (rdrDX != null)
//				{
//					if (rdrDX.Read()) 
//					{
						newItem.ItemID = 5;
						newItem.Item = "Diagnosis";
						this.AddRecord(newItem);
//					}
//				}
//				if (rdrPX != null)
//				{
//					while (rdrPX.Read()) 
//					{
						newItem.ItemID = 8;
						newItem.Item = "Procedures";
						this.AddRecord(newItem);
//					}
//				}
			}
			catch(Exception ex)
			{
				throw new ActiveAdviceException(AAExceptionAction.None,"Empty Collection");
			}
//			finally
//			{
//				if (rdrOrganizations != null)
//					rdrOrganizations.Close();
//				if (rdrPlan != null)
//					rdrPlan.Close();
//				if (rdrDX != null)
//					rdrDX.Close();
//				if (rdrPX != null)
//					rdrPX.Close();
//			}
			return this.Count;
		}

//		/// <summary>
//		/// Accessor to a shared OrganizationSummaryCollection which is cached in NSGlobal
//		/// </summary>
//		public static SecurityGroupDALevelCollection SecurityGroupDALevels
//		{
//			get
//			{
//				bool initialize = false;
//				// Get a cached instance of the collection
//				SecurityGroupDALevelCollection col = (SecurityGroupDALevelCollection)NSGlobal.EnsureCachedObject("SecurityGroupDALevels", typeof(SecurityGroupDALevelCollection), ref initialize);
//				if (initialize)
//				{
//					// initialize the content of the collection
//					col.GetAllDALevels(maxRecords, groupID);
//				}
//				return col;
//			}			
//		}
	}
}
