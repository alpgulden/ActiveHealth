using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SecurityGroupUser]
	/// </summary>
	[SPInsert("usp_InsertSecurityGroupUser")]
	[SPUpdate("usp_UpdateSecurityGroupUser")]
	[SPDelete("usp_DeleteSecurityGroupUser")]
	[SPLoad("usp_LoadSecurityGroupUser")]
	[TableMapping("SecurityGroupUser","groupID,userID",true)]
	public class SecurityGroupUser : BaseData
	{
		[NonSerialized]
		private SecurityGroupUserCollection parentSecurityGroupUserCollection;
	
		[ColumnMapping("GroupID",StereoType=DataStereoType.FK)]
		private int groupID=0;
		[ColumnMapping("UserID",StereoType=DataStereoType.FK)]
		private int userID=0;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;

		private AAUser aAUser;
		private SecurityGroup securityGroup;

		private string loginName;
		private string groupName;

		public SecurityGroupUser(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public SecurityGroupUser()
		{
		}

		public SecurityGroupUser(int GroupID,int UserID,AAUser aAUser)
		{
			this.NewRecord(); // initialize record state
			this.aAUser = aAUser;
			this.groupID = GroupID;
			this.userID = UserID;
		}

		public SecurityGroupUser(int GroupID,int UserID,SecurityGroup securityGroup)
		{
			this.NewRecord(); // initialize record state
			this.securityGroup = securityGroup;
			this.groupID = GroupID;
			this.userID = UserID;
		}

		public SecurityGroupUser(int groupID, int userID)
		{
			this.NewRecord(); // initialize record state
			this.groupID = groupID;
			this.userID = userID;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int GroupID
		{
			get { return this.groupID; }
			set { this.groupID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int UserID
		{
			get { return this.userID; }
			set { this.userID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		public string LoginName
		{
			get{
				if (this.loginName == null)
					if(this.AAUser!=null)
						this.loginName = this.AAUser.LoginName;
				else
						this.loginName = "";
				return this.loginName; 
			}
			set{this.loginName = value;}
		}

		public string GroupName
		{
			get
			{
				if (this.groupName == null)
					if(this.SecurityGroup!=null)
						this.groupName = this.SecurityGroup.GroupName;
					else
						this.groupName ="NA";
				return this.groupName; 
			}
			set{this.groupName = value;}
		}

		/// <summary>
		/// Loads and returns the associated security group.
		/// </summary>
		/// <returns></returns>
		public SecurityGroup GetSecurityGroup()
		{
			if (this.groupID == 0)
				return null;
			SecurityGroup securityGroup = new SecurityGroup();
			if (securityGroup.Load(this.groupID))
				return securityGroup;
			else
				return null;
		}

		/// <summary>
		/// Returns the linked patient object.  This was either passed
		/// in the constructor, or it's loaded from the security group table.
		/// </summary>
		public SecurityGroup SecurityGroup
		{
			get
			{
				if (this.securityGroup == null)
				{
					if (this.parentSecurityGroupUserCollection != null)
						this.securityGroup = this.parentSecurityGroupUserCollection.ParentSecurityGroup;
					if (this.securityGroup == null)
						this.securityGroup = GetSecurityGroup();
//					if (this.securityGroup != null)
//					{
//						if (this.securityGroup.AAUser == null)
//							this.securityGroup.AAUser = this.AAUser;
//					}
				}
				return this.securityGroup;
			}
		}

		/// <summary>
		/// Loads and returns the associated problem.
		/// </summary>
		/// <returns></returns>
		public AAUser GetAAUser()
		{
			if (this.userID == 0)
				return null;
			AAUser aAUser = new AAUser();
			if (aAUser.Load(this.userID))
				return aAUser;
			else
				return null;
		}

		/// <summary>
		/// Returns the linked problem object.  This was either passed
		/// in the constructor, or it's loaded from the Problem table.
		/// </summary>
		public AAUser AAUser
		{
			get
			{
				if (this.aAUser == null)
				{
					// try to get the problem from the parent patientProblemCollection
					if (this.parentSecurityGroupUserCollection != null)
						this.aAUser = this.parentSecurityGroupUserCollection.ParentAAUser;
					// try to get the problem from the db
					if (this.aAUser == null)
						this.aAUser = GetAAUser();
//					// establish in-memory relationship to patient if not already established
//					if (this.aAUser != null)
//					{
//						if (this.aAUser.SecurityGroup == null)
//							this.aAUser.SecurityGroup = this.SecurityGroup;		// establish the in-memory relationship of the patient and the problem
//					}
				}
				return this.aAUser;
			}
		}

		/// <summary>
		/// Parent SecurityGroupUserCollection that contains this element
		/// </summary>
		public SecurityGroupUserCollection ParentSecurityGroupUserCollection
		{
			get
			{
				return this.parentSecurityGroupUserCollection;
			}
			set
			{
				this.parentSecurityGroupUserCollection = value; // parent is set when added to a collection
			}
		}


	}

	/// <summary>
	/// Strongly typed collection of SecurityGroupUser objects
	/// </summary>
	[ElementType(typeof(SecurityGroupUser))]
	public class SecurityGroupUserCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SecurityGroupUser elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSecurityGroupUserCollection = this;
			else
				elem.ParentSecurityGroupUserCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SecurityGroupUser elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SecurityGroupUser this[int index]
		{
			get
			{
				return (SecurityGroupUser)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SecurityGroupUser)oldValue, false);
			SetParentOnElem((SecurityGroupUser)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent SecurityGroup that contains this collection
		/// </summary>
		public SecurityGroup ParentSecurityGroup
		{
			get { return this.ParentDataObject as SecurityGroup; }
			set { this.ParentDataObject = value; /* parent is set when contained by a SecurityGroup */ }
		}

		/// <summary>
		/// Parent AAUser that contains this collection
		/// </summary>
		public AAUser ParentAAUser
		{
			get { return this.ParentDataObject as AAUser; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AAUser */ }
		}
	}
}
