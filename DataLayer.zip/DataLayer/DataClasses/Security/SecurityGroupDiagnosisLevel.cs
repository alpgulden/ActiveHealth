using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SecurityGroupDiagnosisLevel]
	/// 
	/// Manualy sps:  usp_GetDiagnosticRangeFiltersForUser
	/// </summary>
	[SPAutoGen("usp_LoadSecurityGroupDiagnosisLevelByGroupID","SelectAllByGivenArgs.sptpl","groupID")]
	[SPAutoGen("usp_LoadSecurityGroupDiagnosisLevelByCodeType","SelectAllByGivenArgs.sptpl","diagnosisCodeType, groupID")]
	[SPInsert("usp_InsertSecurityGroupDiagnosisLevel")]
	[SPUpdate("usp_UpdateSecurityGroupDiagnosisLevel")]
	[SPDelete("usp_DeleteSecurityGroupDiagnosisLevel")]
	[SPLoad("usp_LoadSecurityGroupDiagnosisLevel")]
	[TableMapping("SecurityGroupDiagnosisLevel","groupDiagnosisLevelID")]
	public class SecurityGroupDiagnosisLevel : SecurityGroupDALevel
	{
		[NonSerialized]
		private SecurityGroupDiagnosisLevelCollection parentSecurityGroupDiagnosisLevelCollection;
		[ColumnMapping("GroupDiagnosisLevelID",StereoType=DataStereoType.FK)]
		private int groupDiagnosisLevelID;
		[ColumnMapping("DiagnosisFrom")]
		private string diagnosisFrom;
		[ColumnMapping("DiagnosisTo")]
		private string diagnosisTo;
		[ColumnMapping("DiagnosisCodeType")]
		private string diagnosisCodeType;

		private string name;
	
		public SecurityGroupDiagnosisLevel()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public SecurityGroupDiagnosisLevel(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GroupDiagnosisLevelID
		{
			get { return this.groupDiagnosisLevelID; }
			set { this.groupDiagnosisLevelID = value; }
		}

		[FieldDescription("@CODEFROM@")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string DiagnosisFrom
		{
			get { return this.diagnosisFrom; }
			set { this.diagnosisFrom = value; }
		}

		[FieldDescription("@CODETO@")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string DiagnosisTo
		{
			get { return this.diagnosisTo; }
			set { this.diagnosisTo = value; }
		}

		[ControlType(EnumControlTypes.TextBox, IsRequired=true)]
		public string DiagnosisCodeType
		{
			get { return this.diagnosisCodeType; }
			set { this.diagnosisCodeType = value; }
		}

		public string Name
		{
			get { 
				if(this.AllRecords)
					return "ALL";
				else
					return this.diagnosisCodeType + ":" + this.diagnosisFrom + "-" + this.diagnosisTo; }
			set { this.name = value; }
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupDiagnosisLevelID)
		{
			return base.Load(groupDiagnosisLevelID);
		}

		/// <summary>
		/// Parent SecurityGroupDiagnosisLevelCollection that contains this element
		/// </summary>
		public SecurityGroupDiagnosisLevelCollection ParentSecurityGroupDiagnosisLevelCollection
		{
			get
			{
				return this.parentSecurityGroupDiagnosisLevelCollection;
			}
			set
			{
				this.parentSecurityGroupDiagnosisLevelCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}
	}

	/// <summary>
	/// Strongly typed collection of SecurityGroupDiagnosisLevel objects
	/// </summary>
	[ElementType(typeof(SecurityGroupDiagnosisLevel))]
	public class SecurityGroupDiagnosisLevelCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SecurityGroupDiagnosisLevel elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSecurityGroupDiagnosisLevelCollection = this;
			else
				elem.ParentSecurityGroupDiagnosisLevelCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SecurityGroupDiagnosisLevel elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SecurityGroupDiagnosisLevel this[int index]
		{
			get
			{
				return (SecurityGroupDiagnosisLevel)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SecurityGroupDiagnosisLevel)oldValue, false);
			SetParentOnElem((SecurityGroupDiagnosisLevel)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSecurityGroupDiagnosisLevelByCodeType(int maxRecords, string diagnosisCodeType, int groupID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadSecurityGroupDiagnosisLevelByCodeType", maxRecords, this, false, diagnosisCodeType, groupID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSecurityGroupDiagnosisLevelByGroupID(int maxRecords, int groupID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadSecurityGroupDiagnosisLevelByGroupID", maxRecords, this, false, groupID);
		}

		/// <summary>
		/// Load the collection with security range filters for a specific user.
		/// </summary>
		public int LoadDiagnosticRangeFiltersForUser(int userID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetDiagnosticRangeFiltersForUser", -1, this, false, new object[] { userID });
		}

		/// <summary>
		/// If the given code is ruled out by any filter, this returns true
		/// </summary>
		/// <param name="codeType"></param>
		/// <param name="code"></param>
		/// <returns></returns>
		public bool IsCodeRuledOutByAFilter(string codeType, string code)
		{
			bool included = true;	// if there's no definition, assume included.
			int count = 0;
			// check if included
			for (int i = 0; i < this.Count; i++)
			{
				SecurityGroupDiagnosisLevel filter = this[i];
				if (filter.DiagnosisCodeType == codeType)	// check only given codetype
				{
					if (count == 0 && filter.Equal)	// including-filter found.  set the default to included = false, because the defined explicit ranges will dominate
						included = false;
					count ++;
					bool inrange = BaseData.IsCodeInRange(code, filter.DiagnosisFrom, filter.DiagnosisTo);
					if (inrange)   // include/exclude only if in range
						included = filter.Equal;  // if included-range true, if excluded-range false.
				}
			}
			if (count == 0)	// no filter means all records
				included = true;
			return !included;
		}

	}
}
