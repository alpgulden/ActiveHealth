using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SecurityGroup]
	/// </summary>
	[SPAutoGen("usp_GetAllSecurityGroups","SelectAll.sptpl","", InjectOrderBy="ORDER BY groupName")]
	[SPAutoGen("usp_LoadSecurityGroups","SelectRelatedFromLinkedTable.sptpl","SecurityGroupUser, GroupID, UserID")]
	[SPAutoGen("usp_LoadSecurityGroupByUserID","SelectRelatedFromLinkedTableWithFilter.sptpl","SecurityGroupUser, GroupID, UserID, GroupID")]
	[SPInsert("usp_InsertSecurityGroup")]
	[SPUpdate("usp_UpdateSecurityGroup")]
	[SPDelete("usp_DeleteSecurityGroup")]
	[SPLoad("usp_LoadSecurityGroup")]
	[TableMapping("SecurityGroup","groupID")]
	public class SecurityGroup : BaseData
	{
		[NonSerialized]
		private SecurityGroupCollection parentSecurityGroupCollection;
		[ColumnMapping("GroupID",StereoType=DataStereoType.FK)]
		private int groupID;
		[ColumnMapping("GroupName")]
		private string groupName;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		private SecurityGroupUserCollection securityGroupUsers;
		private AAUser aAUser;
	
		public SecurityGroup()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public SecurityGroup(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GroupID
		{
			get { return this.groupID; }
			set { this.groupID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=100, IsRequired=true)]
		public string GroupName
		{
			get { return this.groupName; }
			set { this.groupName = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4000)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.createTime = DateTime.Now;
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch(Exception ex)
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw;
				//throw new Exception("Problem occured while saving the form." + ex.Message);
			}		
		}

		/// <summary>
		/// Parent SecurityGroupCollection that contains this element
		/// </summary>
		public SecurityGroupCollection ParentSecurityGroupCollection
		{
			get
			{
				return this.parentSecurityGroupCollection;
			}
			set
			{
				this.parentSecurityGroupCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Return the linked users.  This group must be linked to a single user only.
		/// If there are more than 1 user linked, this is an invalid case, and this
		/// property will throw an exception.
		/// </summary>
		public AAUser AAUser
		{
			get
			{
				// The security group was either given at the construction of this problem as a new problem
				// or loaded from the db.
				if (this.aAUser==null)
				{
					SecurityGroupUser securityGroupUser = this.SecurityGroupUser;
					if (securityGroupUser != null)
						this.aAUser = securityGroupUser.AAUser;
				}
				return this.aAUser;
			}
			set
			{
				if (this.aAUser != null)
					throw new Exception("An existing link to a user can't be changed on the security user object");
				this.aAUser = value;
			}
		}
		/// <summary>
		/// Child SecurityGroupUsers mapped to related rows of table SecurityGroupUser where [GroupID] = [GroupID]
		/// </summary>
		[SPLoadChild("usp_LoadSecurityGroupUsers", "groupID")]
		public SecurityGroupUserCollection SecurityGroupUsers
		{
			get { return this.securityGroupUsers; }
			set
			{
				this.securityGroupUsers = value;
				if (value != null)
					value.ParentSecurityGroup = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Returns the actual collection of users linked to this group.
		/// </summary>
		/// <returns></returns>
		public AAUserCollection GetLinkedUsers()
		{
			AAUserCollection aAUserCol = new AAUserCollection();
			aAUserCol.LoadLinkedSecurityGroupUsers(this);
			return aAUserCol;
		}

		/// <summary>
		/// Loads the SecurityGroupUsers collection
		/// </summary>
		public void LoadSecurityGroupUsers(bool forceReload)
		{
			this.securityGroupUsers = (SecurityGroupUserCollection)SecurityGroupUserCollection.LoadChildCollection("SecurityGroupUsers", this, typeof(SecurityGroupUserCollection), securityGroupUsers, forceReload, null);
		}

		/// <summary>
		/// Saves the SecurityGroupUsers collection
		/// </summary>
		public void SaveSecurityGroupUsers()
		{
			SecurityGroupUserCollection.SaveChildCollection(this.securityGroupUsers, true);
		}

		/// <summary>
		/// Synchronizes the SecurityGroupUsers collection
		/// </summary>
		public void SynchronizeSecurityGroupUsers()
		{
			SecurityGroupUserCollection.SynchronizeChildCollection(this.securityGroupUsers, true);
		}

		public SecurityGroupUser SecurityGroupUser
		{
			get
			{
				LoadSecurityGroupUsers(false);
				if (this.SecurityGroupUsers.Count > 0)
				{
					return this.SecurityGroupUsers[0];
				}

				return null;		// no patient-problem link
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupID)
		{
			return base.Load(groupID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupID)
		{
			base.Delete(groupID);		
		}
	}

	/// <summary>
	/// Strongly typed collection of SecurityGroup objects
	/// </summary>
	[ElementType(typeof(SecurityGroup))]
	public class SecurityGroupCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SecurityGroup elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSecurityGroupCollection = this;
			else
				elem.ParentSecurityGroupCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SecurityGroup elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SecurityGroup this[int index]
		{
			get
			{
				return (SecurityGroup)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SecurityGroup)oldValue, false);
			SetParentOnElem((SecurityGroup)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllSecurityGroups(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllSecurityGroups", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSecurityGroups(int maxRecords, int userId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadSecurityGroups", maxRecords, this, false, userId);
		}

		public int LoadLinkedSecurityGroups(AAUser aAUser)
		{
			if (aAUser == null)
				throw new Exception("No security group was specified to LoadSecurityGroups");

			if (aAUser.IsNew)
			{
				this.Clear();
				return 0;
			}

			int count = LoadSecurityGroups(-1, aAUser.UserId);
			for (int i = 0; i < this.Count; i++)
			{
				this[i].AAUser = aAUser;
			}
			return count;
		}

		/// <summary>
		/// Accessor to a shared SecurityGroupCollection which is cached in NSGlobal
		/// </summary>
		public static SecurityGroupCollection AllSecurityGroups
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				SecurityGroupCollection col = (SecurityGroupCollection)NSGlobal.EnsureCachedObject("AllSecurityGroups", typeof(SecurityGroupCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllSecurityGroups(-1);
				}
				return col;
			}
		}

		public static void ClearAllSecurityGroupsFromCache()
		{
			NSGlobal.ClearCache(typeof(SecurityGroupCollection),false);
		}
	}
}
