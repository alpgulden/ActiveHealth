using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SecurityGroupPlanLevel]
	/// </summary>
	[SPInsert("usp_InsertSecurityGroupPlanLevel")]
	[SPUpdate("usp_UpdateSecurityGroupPlanLevel")]
	[SPDelete("usp_DeleteSecurityGroupPlanLevel")]
	[SPLoad("usp_LoadSecurityGroupPlanLevel")]
	[TableMapping("SecurityGroupPlanLevel","groupPlanLevelID")]
	public class SecurityGroupPlanLevel : SecurityGroupDALevel
	{
		[NonSerialized]
		private SecurityGroupPlanLevelCollection parentSecurityGroupPlanLevelCollection;
		[ColumnMapping("GroupPlanLevelID")]
		private int groupPlanLevelID;
		[ColumnMapping("PlanID")]
		private int planID;
	
		private string name;
		private PlanSummary planSummary;

		public SecurityGroupPlanLevel()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public SecurityGroupPlanLevel(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();	
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GroupPlanLevelID
		{
			get { return this.groupPlanLevelID; }
			set { this.groupPlanLevelID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PlanID
		{
			get { return this.planID; }
			set { this.planID = value; }
		}

		public string Name
		{
			get 
			{ 
				if (this.name == null)
					this.name = this.PlanSummary.Name;
				return this.name; 
			}
			set { this.name = value; }
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPlanLevelID)
		{
			return base.Load(groupPlanLevelID);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Parent SecurityGroupPlanLevelCollection that contains this element
		/// </summary>
		public SecurityGroupPlanLevelCollection ParentSecurityGroupPlanLevelCollection
		{
			get
			{
				return this.parentSecurityGroupPlanLevelCollection;
			}
			set
			{
				this.parentSecurityGroupPlanLevelCollection = value; // parent is set when added to a collection
			}
		}


		/// <summary>
		/// Contained Plans object
		/// </summary>
		[Contained]
		public PlanSummary PlanSummary
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.PlanSummary = (PlanSummary)PlanSummary.EnsureContainedDataObject(this, typeof(PlanSummary), planSummary, false, planID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.planSummary;
			}
			set
			{

				this.planSummary = value;
				if (value != null) value.ParentSecurityGroupPlanLevel = this; // set this as a parent of the child data class
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of SecurityGroupPlanLevel objects
	/// </summary>
	[ElementType(typeof(SecurityGroupPlanLevel))]
	public class SecurityGroupPlanLevelCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PlanID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SecurityGroupPlanLevel elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSecurityGroupPlanLevelCollection = this;
			else
				elem.ParentSecurityGroupPlanLevelCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SecurityGroupPlanLevel elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SecurityGroupPlanLevel this[int index]
		{
			get
			{
				return (SecurityGroupPlanLevel)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SecurityGroupPlanLevel)oldValue, false);
			SetParentOnElem((SecurityGroupPlanLevel)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Sorts the collection by the groupID, planID members.
		/// </summary>
		public void SortBy_GroupID_PlanID(bool ascending, bool ignoreCase)
		{
			CollectionUtil.SortBy(this, ascending, ignoreCase, new string[] { "groupID", "planID" });		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSecurityGroupPlanLevels(int maxRecords, int groupID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadSecurityGroupPlanLevels", maxRecords, this, false, groupID);
		}

		public void SynchronizePlanLevelsFromSelectableCollection(int groupID, PlanSummaryCollection plans,bool notequal,bool all)
		{	
			if(!all)
			{
				foreach (PlanSummary plan in plans)
				{
					if (plan.Selected)
					{
						SecurityGroupPlanLevel existingPlanLevel = this.FindBy(plan.PlanId);
						if (existingPlanLevel == null)
						{
							SecurityGroupPlanLevel newPlanLevel = null;
							newPlanLevel = new SecurityGroupPlanLevel(true);
							newPlanLevel.GroupID = groupID;
							newPlanLevel.PlanID= plan.PlanId;
							newPlanLevel.Name = plan.Name;						
							newPlanLevel.Equal = !notequal;
							newPlanLevel.AllRecords = all;
							this.AddRecord(newPlanLevel);
						}
						else if (existingPlanLevel.IsMarkedForDeletion)
						{
							existingPlanLevel.IsMarkedForDeletion = false;
						}
					}
				}

				foreach (SecurityGroupPlanLevel securityGroupPlanLevel in this)
				{
					PlanSummary plan = null;
					if(securityGroupPlanLevel.PlanID==0)
						securityGroupPlanLevel.MarkDel();
					else
					{
						plan = plans.FindBy(securityGroupPlanLevel.PlanID);
						if (!plan.Selected)
						{
							securityGroupPlanLevel.MarkDel();
						}
						else 
						{
							if(securityGroupPlanLevel.Equal == notequal) // if current !equal changed
							{
								securityGroupPlanLevel.Equal = !notequal;
								securityGroupPlanLevel.MarkDirty();
							}
							if(this[0].AllRecords != all) // if current !all changed // checking only first record is enough
							{
								securityGroupPlanLevel.AllRecords = all;
								securityGroupPlanLevel.MarkDirty();
							}
						}
					}
				}
			}
			else
			{				
				this.Clear();
				SecurityGroupPlanLevel newPlanLevel = null;
				newPlanLevel = new SecurityGroupPlanLevel(true);
				newPlanLevel.GroupID = groupID;
				newPlanLevel.PlanID= 0;
				newPlanLevel.Name = "ALL";						
				newPlanLevel.Equal = true;
				newPlanLevel.AllRecords = all;
				this.AddRecord(newPlanLevel);
			}
		}

		public void SynchronizePlanLevelsFromSelectableCollection(int groupID, PlanSummaryCollection plans,bool notequal)
		{	
			foreach (PlanSummary plan in plans)
			{
				if (plan.Selected)
				{
					SecurityGroupPlanLevel existingPlanLevel = this.FindBy(plan.PlanId);
					if (existingPlanLevel == null)
					{
						SecurityGroupPlanLevel newPlanLevel = null;
						newPlanLevel = new SecurityGroupPlanLevel(true);
						newPlanLevel.GroupID = groupID;
						newPlanLevel.PlanID= plan.PlanId;
						newPlanLevel.Name = plan.Name;						
						newPlanLevel.Equal = !notequal;
						this.AddRecord(newPlanLevel);
					}
					else if (existingPlanLevel.IsMarkedForDeletion)
					{
						existingPlanLevel.IsMarkedForDeletion = false;
					}
				}
			}

			foreach (SecurityGroupPlanLevel securityGroupPlanLevel in this)
			{
				PlanSummary plan = null;
				plan = plans.FindBy(securityGroupPlanLevel.PlanID);
				if (!plan.Selected)
				{
					securityGroupPlanLevel.MarkDel();
				}
			}
		}
//			foreach (PlanSummary plan in plans)
//			{
//				if(plan.IsDirty)
//				{
//					if(plan.Selected) 
//					{
//						SecurityGroupPlanLevel existingPlanLevel = this.FindBy(plan.PlanId);
//						if (existingPlanLevel == null)  // add item to the collection
//						{
//							SecurityGroupPlanLevel newPlanLevel = null;
//							newPlanLevel = new SecurityGroupPlanLevel(true);
//							newPlanLevel.GroupID = groupID;
//							newPlanLevel.PlanID = plan.PlanId;
//							newPlanLevel.Name = plan.Name;
//							//newPlanLevel.Permission = (int)EnumPermission.Admin;
//							this.AddRecord(newPlanLevel);
//						}
//					}
//					else
//					{
//						SecurityGroupPlanLevel existingPlanLevel = this.FindBy(plan.PlanId);
//						if (existingPlanLevel != null)  // add item to the collection
//							existingPlanLevel.MarkDel();
//					}
//				}
//			}
//		}

		/// <summary>
		/// Hashtable based index on planID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PlanID
		{
			get
			{
				if (this.indexBy_PlanID == null)
					this.indexBy_PlanID = new CollectionIndexer(this, new string[] { "planID" }, true);
				return this.indexBy_PlanID;
			}			
		}

//		public override int AddRecord(BaseDataClass data)
//		{
//			int ret = base.AddRecord (data);
//			ResetIndexers();
//			return ret;
//		}
//
//		private void ResetIndexers()
//		{
//			// Rebuild indexers
//			// TODO: Remove this when the library automatically supports this feature
//			indexBy_PlanID = null;
//		}

		/// <summary>
		/// Hashtable based search on PlanID fields returns the object.  Uses the IndexBy_PlanID indexer.
		/// </summary>
		public SecurityGroupPlanLevel FindBy(int PlanID)
		{
			if(this.IndexBy_PlanID!=null)
				this.IndexBy_PlanID.Rebuild();
			return (SecurityGroupPlanLevel)this.IndexBy_PlanID.GetObject(PlanID);
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
	}
}
