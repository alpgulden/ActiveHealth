using System;
using System.Data.SqlClient;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeProviders]
	/// </summary>
	[SPExists("usp_ExistsGroupPracticeProviderLink")]
	[SPLoad("usp_LoadGroupPracticeProviderLink")]
	[SPInsert("usp_InsertGroupPracticeProviderLink")]
	[SPUpdate("usp_UpdateGroupPracticeProviderLink")]
	[SPDelete("usp_DeleteGroupPracticeProviderLink")]

	[TableMapping("GroupPracticeProvider","groupPracticeProviderID")]
	public class GroupPracticeProviderLink : BaseData
	{
		[NonSerialized]
		private GroupPracticeProviderLinkCollection parentGroupPracticeProviderLinkCollection;
		[ColumnMapping("GroupPracticeProviderID",StereoType=DataStereoType.FK)]
		private int groupPracticeProviderID;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]
		private int providerID;
		[ColumnMapping("GroupPracticeLocationID",StereoType=DataStereoType.FK)]
		private int groupPracticeLocationID;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("EffDate")]
		private DateTime effDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("GroupPracticeID")]
		private int groupPracticeID;
		[ColumnMapping("Active")]
		private bool active;
		private GroupPracticeProviderHistoryCollection effectiveDateHistory;


		
		[ColumnMapping("CreatedByName", JoinColumn="LoginName", JoinRelation="GroupPracticeProvider.CreatedBy = [AAUser].UserID")]
		private string createdByStr;
		public string CreatedByStr
		{
			get { return this.createdByStr; }
		}



		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GroupPracticeID
		{
			get { return this.groupPracticeID; }
			set { this.groupPracticeID = value; }
		}


		[FieldDescription("@ACTIVE@")]
		public bool ActiveLocation
		{
			get
			{
				GroupPracticeLocation gpLoc = new GroupPracticeLocation();
				gpLoc.Load(this.GroupPracticeLocationID);
				return gpLoc.Location.Active;
				}
		}
		
		[FieldDescription("@ACTIVE@")]
		public bool ActiveProviderLocation
		{
			get
			{
				ProviderLocation provLoc = new ProviderLocation();
				provLoc.Load(this.ProviderLocationID);
				return provLoc.Location.Active;
			}
		}


		public string GroupPracticeName
		{
			get 
			{
				GroupPractice gp = new GroupPractice();
				gp.Load(this.GroupPracticeID);
				return gp.Name;
			}
		}
		
		public string ProviderName
		{
			get 
			{
				Provider prov = new Provider();
				prov.Load(this.ProviderID);
				return prov.FullName;
			}
		}

		public string GroupPracticeType
		{
			get 
			{
				GroupPractice gp = new GroupPractice();
				gp.Load(this.GroupPracticeID);
				GroupPracticeType gpType = new GroupPracticeType();
				gpType.Load(gp.TypeID);
				return gpType.Description;
			}
		}

		public string GroupPracticeAlternateID
		{
			get 
			{
				GroupPractice gp = new GroupPractice();
				gp.Load(this.GroupPracticeID);
				return gp.AlternateID;
			}
		}

		public string ProviderAlternateID
		{
			get 
			{
				Provider prov = new Provider();
				prov.Load (this.ProviderID);
				return prov.AlternateID;
			}
		}

		public GroupPracticeProviderLink()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		//[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@GROUPPRACTICEPROVIDERID@")]
		public int GroupPracticeProviderID
		{
			get { return this.groupPracticeProviderID; }
			set { this.groupPracticeProviderID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int GroupPracticeLocationID
		{
			get { return this.groupPracticeLocationID; }
			set { this.groupPracticeLocationID = value; }
		}



		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Reads multiple objects of this type from source data reader into the given collection
		/// </summary>
		public int ReadCollection(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords, System.Collections.IList collection)
		{
			return SqlData.ReadCollection(sourceReader, maxRecords, collection, typeof(GroupPracticeProviderLink), true, false);
		}


		public void UpdateEffectiveDates(DateTime startDate, DateTime endDate)
		{
			try
			{
				
				GroupPracticeProviderHistory dateHistory = new GroupPracticeProviderHistory();
				// Prepare the "history" record first.
				dateHistory.New();
				dateHistory.AsOfDate						= this.AsOfDate;
				dateHistory.EffectiveDate					= this.EffDate;
				dateHistory.TerminationDate					= this.TerminationDate;
				dateHistory.Active							= this.Active;
				dateHistory.GroupPracticeProviderID			= this.GroupPracticeProviderID;
				this.EffectiveDateHistory.Add(dateHistory);
				
				// Update the current record
				this.Active = ((endDate <= DateTime.Today.Date) || (endDate < startDate)) ? false : true;
				this.AsOfDate	= DateTime.Now;
				this.EffDate	= startDate;
				this.TerminationDate = endDate;


				this.Update();
			}
			catch (SqlException sqlEx)
			{
				throw new ActiveAdviceException(AAExceptionAction.None, "An error occured while updating the record",sqlEx);
			}
			catch (Exception ex)
			{
			
				throw new ActiveAdviceException(AAExceptionAction.None, "An error occurred", ex);
			}
		}

	
		public string GroupPracticeAddress
		{
			get 
			{
				GroupPracticeLocation gpLoc = new GroupPracticeLocation();
				gpLoc.Load(this.GroupPracticeLocationID);
				return gpLoc.Location.ServiceAddress.ToString();
			}
		}
		
		public string ProviderAddress
		{
			get 
			{
				ProviderLocation provLoc = new ProviderLocation();
				provLoc.Load(this.ProviderLocationID);
				return provLoc.Location.ServiceAddress.ToString();
			}
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			if (this.EffectiveDateHistory != null)
				this.EffectiveDateHistory.Save();
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPracticeProviderID)
		{
			bool result = false;
			result = base.Load(groupPracticeProviderID);
			this.LoadEffectiveDateHistory(false);
			return result;
		}
		
		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupPracticeProviderID)
		{
			base.Delete(groupPracticeProviderID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Parent GroupPracticeProviderLinkCollection that contains this element
		/// </summary>
		public GroupPracticeProviderLinkCollection ParentGroupPracticeProviderLinkCollection
		{
			get
			{
				return this.parentGroupPracticeProviderLinkCollection;
			}
			set
			{
				this.parentGroupPracticeProviderLinkCollection = value; // parent is set when added to a collection
			}
		}



		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EffDate
		{
			get { return this.effDate; }
			set { this.effDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}



		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Child EffectiveDateHistory mapped to related rows of table GroupPracticeProviderHistory where [GroupPracticeProviderID] = [GroupPracticeProviderID]
		/// </summary>
		[SPLoadChild("usp_LoadGroupPracticeEffectiveDates", "groupPracticeProviderID")]
		public GroupPracticeProviderHistoryCollection EffectiveDateHistory
		{
			get { return this.effectiveDateHistory; }
			set
			{
				this.effectiveDateHistory = value;
				if (value != null)
					value.ParentGroupPracticeProviderLink = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the EffectiveDateHistory collection
		/// </summary>
		public void LoadEffectiveDateHistory(bool forceReload)
		{
			this.effectiveDateHistory = (GroupPracticeProviderHistoryCollection)GroupPracticeProviderHistoryCollection.LoadChildCollection("EffectiveDateHistory", this, typeof(GroupPracticeProviderHistoryCollection), effectiveDateHistory, forceReload, null);
		}

		/// <summary>
		/// Saves the EffectiveDateHistory collection
		/// </summary>
		public void SaveEffectiveDateHistory()
		{
			GroupPracticeProviderHistoryCollection.SaveChildCollection(this.effectiveDateHistory, true);
		}

		/// <summary>
		/// Synchronizes the EffectiveDateHistory collection
		/// </summary>
		public void SynchronizeEffectiveDateHistory()
		{
			GroupPracticeProviderHistoryCollection.SynchronizeChildCollection(this.effectiveDateHistory, true);
		}

		/// <summary>
		/// Do pre and post-update operations of the object here.
		/// </summary>
		protected override void InternalUpdate()
		{
			this.EffectiveDateHistory.Save();
			base.InternalUpdate(); // always call this to ensure record flags gets updated properly.	
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			try
			{
				//this.sqlData.EnsureTransaction();
				base.InternalSave();
				if (this.EffectiveDateHistory != null)
				{
					this.EffectiveDateHistory.SqlData.Transaction = this.SqlData.Transaction;
					this.EffectiveDateHistory.Save();
				}
			}
			catch (Exception ex)
			{
				this.sqlData.RollbackTransaction();
				throw;
			}
		}


	}

	/// <summary>
	/// Strongly typed collection of GroupPracticeProviderLink objects
	/// </summary>
	[ElementType(typeof(GroupPracticeProviderLink))]
	public class GroupPracticeProviderLinkCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_GroupPracticeProviderID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPracticeProviderLink elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeProviderLinkCollection = this;
			else
				elem.ParentGroupPracticeProviderLinkCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPracticeProviderLink elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPracticeProviderLink this[int index]
		{
			get
			{
				return (GroupPracticeProviderLink)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPracticeProviderLink)oldValue, false);
			SetParentOnElem((GroupPracticeProviderLink)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, GroupPracticeProviderLink elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeProviderLink)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GroupPracticeProviderLink elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPracticeProviderLink elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeProviderLink)value, false);
			base.OnRemoveComplete (index, value);		
		}


		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
		
			this.SaveElements();		
		}


		/* Don't use this.  It was using Dynamic SQL!
		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL( object param)
		{
			SQLParser sql = new SQLParser("select * from [GroupPracticeProviders] " +
			"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Parent Provider that contains this collection
		/// </summary>
		public Provider ParentProvider
		{
			get { return this.ParentDataObject as Provider; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Provider */ }
		}

		/// <summary>
		/// Parent GroupPractice that contains this collection
		/// </summary>
		public GroupPractice ParentGroupPractice
		{
			get { return this.ParentDataObject as GroupPractice; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GroupPractice */ }
		}


		/// <summary>
		/// Parent GroupPracticeLocation that contains this collection
		/// </summary>
		public GroupPracticeLocation ParentGroupPracticeLocation
		{
			get { return this.ParentDataObject as GroupPracticeLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GroupPracticeLocation */ }
		}

		
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter);
		}

		/// <summary>
		/// Hashtable based index on groupPracticeProviderID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_GroupPracticeProviderID
		{
			get
			{
				if (this.indexBy_GroupPracticeProviderID == null)
					this.indexBy_GroupPracticeProviderID = new CollectionIndexer(this, new string[] { "groupPracticeProviderID" }, true);
				return this.indexBy_GroupPracticeProviderID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on groupPracticeProviderID fields returns the object.  Uses the IndexBy_GroupPracticeProviderID indexer.
		/// </summary>
		public GroupPracticeProviderLink FindBy(int groupPracticeProviderID)
		{
			return (GroupPracticeProviderLink)this.IndexBy_GroupPracticeProviderID.GetObject(groupPracticeProviderID);
		}



	}
}
