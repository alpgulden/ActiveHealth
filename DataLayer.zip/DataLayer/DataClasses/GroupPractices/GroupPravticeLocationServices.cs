using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeLocationServices]
	/// </summary>
	[SPInsert("usp_InsertGroupPravticeLocationServices")]
	[SPUpdate("usp_UpdateGroupPravticeLocationServices")]
	[SPDelete("usp_DeleteGroupPravticeLocationServices")]
	[SPLoad("usp_LoadGroupPravticeLocationServices")]
	[TableMapping("GroupPracticeLocationServices","groupPracticeServiceID")]
	public class GroupPravticeLocationServices : BaseData
	{
		[NonSerialized]
		private GroupPravticeLocationServicesCollection parentGroupPravticeLocationServicesCollection;
		[ColumnMapping("GroupPracticeServiceID",(int)-1)]
		private int groupPracticeServiceID;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;

		[ColumnMapping("CreatedBy",(int)0)]
		private int createdBy;
		[ColumnMapping("LastModified")]
		private DateTime lastModified;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("ModifiedTime")]
		private DateTime modifiedTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("GroupPracticeServiceTypeID",(int)0)]
		private int groupPracticeServiceTypeID;
		[ColumnMapping("GroupPracticeLocationID",(int)0)]
		private int groupPracticeLocationID;
	
		public GroupPravticeLocationServices()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public int GroupPracticeServiceID
		{
			get { return this.groupPracticeServiceID; }
			set { this.groupPracticeServiceID = value; }
		}


		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime LastModified
		{
			get { return this.lastModified; }
			set { this.lastModified = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifiedTime
		{
			get { return this.modifiedTime; }
			set { this.modifiedTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int GroupPracticeServiceTypeID
		{
			get { return this.groupPracticeServiceTypeID; }
			set { this.groupPracticeServiceTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int GroupPracticeLocationID
		{
			get { return this.groupPracticeLocationID; }
			set { this.groupPracticeLocationID = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPracticeServiceID)
		{
			return base.Load(groupPracticeServiceID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupPracticeServiceID)
		{
			base.Delete(groupPracticeServiceID);		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.createdBy					= 0;
			this.createTime					= DateTime.Now;
			this.effectiveDate				= DateTime.Now;
			this.groupPracticeLocationID	= 0;
			this.groupPracticeServiceID		= 0;
			this.groupPracticeServiceTypeID	= 0;

			
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		/// <summary>
		/// Parent GroupPravticeLocationServicesCollection that contains this element
		/// </summary>
		public GroupPravticeLocationServicesCollection ParentGroupPravticeLocationServicesCollection
		{
			get
			{
				return this.parentGroupPravticeLocationServicesCollection;
			}
			set
			{
				this.parentGroupPravticeLocationServicesCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of GroupPravticeLocationServices objects
	/// </summary>
	[ElementType(typeof(GroupPravticeLocationServices))]
	public class GroupPravticeLocationServicesCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPravticeLocationServices elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPravticeLocationServicesCollection = this;
			else
				elem.ParentGroupPravticeLocationServicesCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPravticeLocationServices elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPravticeLocationServices this[int index]
		{
			get
			{
				return (GroupPravticeLocationServices)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPravticeLocationServices)oldValue, false);
			SetParentOnElem((GroupPravticeLocationServices)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, GroupPravticeLocationServices elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GroupPravticeLocationServices)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GroupPravticeLocationServices elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPravticeLocationServices elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPravticeLocationServices)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL( /*object param*/)
		{
			SQLParser sql = new SQLParser("select * from [GroupPracticeLocationServices] " +
			"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Parent GroupPracticeLocation that contains this collection
		/// </summary>
		public GroupPracticeLocation ParentGroupPracticeLocation
		{
			get { return this.ParentDataObject as GroupPracticeLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GroupPracticeLocation */ }
		}


	}
}
