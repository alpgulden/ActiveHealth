using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeProviderHistory]
	/// </summary>
	[SPInsert("usp_InsertGroupPracticeProviderHistory")]
	[SPUpdate("usp_UpdateGroupPracticeProviderHistory")]
	[SPDelete("usp_DeleteGroupPracticeProviderHistory")]
	[SPLoad("usp_LoadGroupPracticeProviderHistory")]
	[TableMapping("GroupPracticeProviderHistory","GroupPracticeProviderHistoryID")]
	public class GroupPracticeProviderHistory : BaseData
	{
		[NonSerialized]
		private GroupPracticeProviderHistoryCollection parentGroupPracticeProviderHistoryCollection;
		[ColumnMapping("GroupPracticeProviderHistoryID",StereoType=DataStereoType.FK)]
		private int groupPracticeProviderHistoryID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("GroupPracticeProviderID",StereoType=DataStereoType.FK)]
		private int groupPracticeProviderID;
	
		public GroupPracticeProviderHistory()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int GroupPracticeProviderHistoryID
		{
			get { return this.groupPracticeProviderHistoryID; }
			set { this.groupPracticeProviderHistoryID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}


		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		/// <summary>
		/// Parent GroupPracticeProviderHistoryCollection that contains this element
		/// </summary>
		public GroupPracticeProviderHistoryCollection ParentGroupPracticeProviderHistoryCollection
		{
			get
			{
				return this.parentGroupPracticeProviderHistoryCollection;
			}
			set
			{
				this.parentGroupPracticeProviderHistoryCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int GroupPracticeProviderID
		{
			get { return this.groupPracticeProviderID; }
			set { this.groupPracticeProviderID = value; }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}
		public bool Load(int groupPracticeProviderHistoryID)
		{
			return base.Load(groupPracticeProviderHistoryID);
		}
		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}
	}

	/// <summary>
	/// Strongly typed collection of GroupPracticeProviderHistory objects
	/// </summary>
	[ElementType(typeof(GroupPracticeProviderHistory))]
	public class GroupPracticeProviderHistoryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPracticeProviderHistory elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeProviderHistoryCollection = this;
			else
				elem.ParentGroupPracticeProviderHistoryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPracticeProviderHistory elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPracticeProviderHistory this[int index]
		{
			get
			{
				return (GroupPracticeProviderHistory)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPracticeProviderHistory)oldValue, false);
			SetParentOnElem((GroupPracticeProviderHistory)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, GroupPracticeProviderHistory elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeProviderHistory)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GroupPracticeProviderHistory elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Returns true if the collection contains the given object
		/// </summary>
		public bool Contains(GroupPracticeProviderHistory elem)
		{
			return List.Contains(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPracticeProviderHistory elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeProviderHistory)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Parent GroupPracticeProviderLink that contains this collection
		/// </summary>
		public GroupPracticeProviderLink ParentGroupPracticeProviderLink
		{
			get { return this.ParentDataObject as GroupPracticeProviderLink; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GroupPracticeProviderLink */ }
		}
		
		/// <summary>
		/// Update the Status for Provider Location Network table for the given providerLocationNetworkID based on the effective and Termination dates.
		/// </summary>
		public int UpdateStatusForGroupPracticeProviderHistory(int maxRecords, GroupPracticeProviderHistory  groupPracticeProviderHistory,int groupPracticeProviderID)
		{
			this.Clear();
			return SqlData.SPExecNonQuery("usp_UpdateStatusForGroupPracticeProviderHistory",groupPracticeProviderHistory,false,
				new string[] { "groupPracticeProviderID" },
				new object[] { groupPracticeProviderID } );
			//return SqlData.SPExecNonQuery("usp_UpdateStatusForProviderLocationNetworkHistory", maxRecords, this, provLocationNetwork, false);
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
	}
}
