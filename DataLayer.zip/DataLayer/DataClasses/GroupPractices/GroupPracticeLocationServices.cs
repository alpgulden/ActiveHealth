using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeLocationServices]
	/// </summary>
	/// 
	
	[SPInsert("usp_InsertGroupPravticeLocationServices")]
	[SPUpdate("usp_UpdateGroupPravticeLocationServices")]
	[SPDelete("usp_DeleteGroupPravticeLocationServices")]
	[SPLoad("usp_LoadGroupPravticeLocationServices")]
	[TableMapping("GroupPracticeLocationService","groupPracticeServiceID")]
	public class GroupPracticeLocationService : NetsoftUSA.DataLayer.BaseDataClass
	{
		[NonSerialized]
		private GroupPracticeLocationServiceCollection parentGroupPracticeLocationServiceCollection;
		[ColumnMapping("GroupPracticeServiceID",StereoType=DataStereoType.FK)]
		private int groupPracticeServiceID;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;

		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("LastModified")]
		private DateTime lastModified;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;

		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("GroupPracticeServiceTypeID",StereoType=DataStereoType.FK)]
		private int groupPracticeServiceTypeID;
		[ColumnMapping("GroupPracticeLocationID",StereoType=DataStereoType.FK)]
		private int groupPracticeLocationID;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("TerminatedBy")]
		private int terminatedBy;

		
		[ColumnMapping("CreatedByName", JoinColumn="LoginName", JoinRelation="GroupPracticeLocationService.CreatedBy = [AAUser].UserID")]
		private string createdByStr;
		[ColumnMapping("ModifiedByName", JoinColumn="LoginName", JoinRelation="GroupPracticeLocationService.ModifiedBy = [AAUser].UserID")]
		private string modifiedByStr;
		[ColumnMapping("TerminatedByName", JoinColumn="LoginName", JoinRelation="GroupPracticeLocationService.TerminatedBy = [AAUser].UserID")]
		private string terminatedByStr;

		public string CreatedByString
		{
			get { return this.createdByStr; }
		}

		public string ModifiedByString
		{
			get { return this.modifiedByStr; }
		}

		public string TerminatedByString
		{
			get { return this.terminatedByStr; }
		}

		public GroupPracticeLocationService()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public int GroupPracticeServiceID
		{
			get { return this.groupPracticeServiceID; }
			set { this.groupPracticeServiceID = value; }
		}


		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime LastModified
		{
			get { return this.lastModified; }
			set { this.lastModified = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get {return true;}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[FieldValuesMember("LookupOf_GroupPracticeServiceTypeID", "GroupPracticeServiceTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int GroupPracticeServiceTypeID
		{
			get { return this.groupPracticeServiceTypeID; }
			set { this.groupPracticeServiceTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int GroupPracticeLocationID
		{
			get { return this.groupPracticeLocationID; }
			set { this.groupPracticeLocationID = value; }
		}
		
		public string Description
		{
			get 
			{
				GroupPracticeServiceType gpServType = new GroupPracticeServiceType();
				gpServType.Load(this.groupPracticeServiceTypeID );
				return gpServType.Description;
			}
		}
		public string DateCreated
		{
			get { return this.CreateTime.Date.ToShortDateString(); }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}
		
		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
				this.ModifiedBy = 1;
				this.CreatedBy  = 1;
				this.TerminatedBy = 1;
				this.NewRecord(); // initialize record state
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPracticeServiceID)
		{
			return base.Load(groupPracticeServiceID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupPracticeServiceID)
		{
			base.Delete(groupPracticeServiceID);		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.createdBy					= 0;
			this.createTime					= DateTime.Now;
			this.effectiveDate				= DateTime.Now;
			this.groupPracticeLocationID	= 0;
			this.groupPracticeServiceID		= 0;
			this.groupPracticeServiceTypeID	= 0;
			
			
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}


//		/// <summary>
//		///  Inactivates the current service..
//		/// </summary>
//		public void Inactivate()
//		{
//			this.Save();
//			base.SetInactivatingUser();
//		}

		/// <summary>
		/// Parent GroupPravticeLocationServicesCollection that contains this element
		/// </summary>
		public GroupPracticeLocationServiceCollection ParentGroupPracticeLocationServiceCollection
		{
			get
			{
				return this.parentGroupPracticeLocationServiceCollection;
			}
			set
			{
				this.parentGroupPracticeLocationServiceCollection = value; // parent is set when added to a collection
			}
		}


		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		public GroupPracticeServiceTypeCollection LookupOf_GroupPracticeServiceTypeID
		{
			get
			{
				return GroupPracticeServiceTypeCollection.ActiveGroupPracticeServiceTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of GroupPravticeLocationServices objects
	/// </summary>
	[ElementType(typeof(GroupPracticeLocationService))]
	public class GroupPracticeLocationServiceCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_GroupPracticeServiceID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPracticeLocationService elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeLocationServiceCollection = this;
			else
				elem.ParentGroupPracticeLocationServiceCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPracticeLocationService elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPracticeLocationService this[int index]
		{
			get
			{
				return (GroupPracticeLocationService)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPracticeLocationService)oldValue, false);
			SetParentOnElem((GroupPracticeLocationService)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, GroupPracticeLocationService elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeLocationService)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GroupPracticeLocationService elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPracticeLocationService elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeLocationService)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
		
	
		/* Don't use this.
		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL( object param)
		{
			SQLParser sql = new SQLParser("select * from [GroupPracticeLocationService] " +
			"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Parent GroupPracticeLocation that contains this collection
		/// </summary>
		public GroupPracticeLocation ParentGroupPracticeLocation
		{
			get { return this.ParentDataObject as GroupPracticeLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GroupPracticeLocation */ }
		}
		
		
		/// <summary>
		/// Hashtable based index on providerLocationServiceID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_GroupPracticeServiceID
		{						 
			get
			{
				if (this.indexBy_GroupPracticeServiceID == null)
					this.indexBy_GroupPracticeServiceID = new CollectionIndexer(this, new string[] { "groupPracticeServiceID" }, true);
				return this.indexBy_GroupPracticeServiceID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on providerLocationServiceID fields returns the object.  Uses the IndexBy_ProviderLocationServiceID indexer.
		/// </summary>
		public GroupPracticeLocationService FindBy(int GroupPracticeServiceID)
		{
			return (GroupPracticeLocationService)this.IndexBy_GroupPracticeServiceID.GetObject(GroupPracticeServiceID);
		}

	}
}
