using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeLocations]
	/// </summary>
	[SPAutoGen("usp_SelectAllGroupPracticeLocationsByGroupPracticeID","SelectAllByGivenArgs.sptpl","groupPracticeID")]
	[ColumnsMappingMode(ColumnMappingModes.MappedOnly | ColumnMappingModes.Public | ColumnMappingModes.NonPublic)]
	[SPInsert("usp_InsertGroupPracticeLocation")]
	[SPUpdate("usp_UpdateGroupPracticeLocation")]
	[SPDelete("usp_DeleteGroupPracticeLocation")]
	[SPLoad("usp_LoadGroupPracticeLocation")]
	[TableMapping("GroupPracticeLocation","groupPracticeLocationID")]
	public class GroupPracticeLocation : BaseLocation, IContactOwner
	{
		[NonSerialized]
		private GroupPracticeLocationCollection parentGroupPracticeLocationCollection;
		[ColumnMapping("GroupPracticeLocationID",StereoType=DataStereoType.FK)]
		private int groupPracticeLocationID;
		[ColumnMapping("GroupPracticeID",StereoType=DataStereoType.FK)]
		private int groupPracticeID;
		private GroupPracticeLocationServiceCollection services;

		private GroupPracticeProviderLinkCollection providers;
		private GroupPracticeLocationNetworkLinkCollection networks;
		private GroupPracticeLocationContactCollection groupPracticeLocationContacts;
	

	
		public GroupPracticeLocation()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		/// <summary>
		/// Standard initializing constructor
		/// </summary>
		/// <param name="initNew"></param>
		public GroupPracticeLocation(bool initNew)
		{
			if (initNew)
				this.NewRecord();
		}

	
		/// <summary>
		///  Returns the name of parent GroupPractice
		/// </summary>
		/// <returns>Name of Group Practice</returns>
		public string GetGroupPracticeName()
		{
			if (this.groupPracticeID != 0)
			{
				GroupPractice gp = new GroupPractice();
				gp.Load(this.groupPracticeID);
				return gp.Name;
			}
			else
				return null;

		}

		public string ServiceLocation 
		{
			get 
			{ 
				if (this.Location.ServiceAddress != null)
					return this.location.ServiceAddress.Line1 + " " + this.location.ServiceAddress.Line2 + "," + this.location.ServiceAddress.City + "," + this.location.ServiceAddress.State + "," + this.location.ServiceAddress.Zip; 
				else
					return null;
			}
		}
		
		public string Phone
		{
			get 
			{
				return this.Location.ServiceAddress.PhoneNumber1;
			}
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GroupPracticeLocationID
		{
			get { return this.groupPracticeLocationID; }
			set { this.groupPracticeLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int GroupPracticeID
		{
			get { return this.groupPracticeID; }
			set { this.groupPracticeID = value; }
		}

		

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			
			if (GroupPracticeID == 0)
				return;
			GroupPractice grp = new GroupPractice();
			grp.Load(GroupPracticeID);
			
			writer.AddFieldsOnNewLine(this, "GroupPracticeLocationID","ServiceLocation");
			writer.AddField(this.Location, "FederalTaxID");
			writer.AddField(this, "AlternateID");
			

			
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
//				this.Location.Save();
//				if (this.Services != null)
//					this.SaveServices();
//				if (this.Providers != null)
//					this.SaveProviders();
//				if (this.networks != null)
//					this.SaveNetworks();
//				this.locationID = this.location.LocationID;
//				base.Save();

				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}
	  

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPracticeLocationID)
		{
			return base.Load(groupPracticeLocationID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupPracticeLocationID)
		{
			base.Delete(groupPracticeLocationID);		
		}
		
		/// <summary>
		/// Executes a stored procedure usp_GetStatusForGroupPracticeLocationNetwork which retrieves the Network Status based on Plan ID, Start Date and Location ID 
		/// </summary>
		public object GetStatusForGroupPracticeLocationNetworks(int planId,DateTime startDate,int locationID)
		{
			return SqlData.SPExecScalar("usp_GetStatusForGroupPracticeLocationNetwork", new object[] { planId,startDate,locationID });
		}



		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Parent GroupPracticeLocationCollection that contains this element
		/// </summary>
		public GroupPracticeLocationCollection ParentGroupPracticeLocationCollection
		{
			get
			{
				return this.parentGroupPracticeLocationCollection;
			}
			set
			{
				this.parentGroupPracticeLocationCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{

			base.NewRecord();
			this.groupPracticeID = 0;
			this.locationID		 = 0;
			this.CreateTime	= DateTime.Now;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

//		/// <summary>
//		/// Contained Location object
//		/// </summary>
//		public Location Location
//		{
//			get
//			{
//				// Ensure contained data object is loaded or created as new.
//				this.location = (Location)Location.EnsureContainedDataObject(this, typeof(Location), location, false, locationID );
//				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
//				// To save this object when the parent is saved, override InternalSave method.
//				return this.location;
//			}
//		}


		
		
		/// <summary>
		/// Child Services mapped to related rows of table GroupPracticeLocationServices where [GroupPracticeLocationID] = [GroupPracticeLocationID]
		/// </summary>
		[SPLoadChild("usp_LoadGroupPracticeLocationGroupPracticeLocationServices", "groupPracticeLocationID")]
		public GroupPracticeLocationServiceCollection Services
		{
			get { return this.services; }
			set
			{
				this.services = value;
				value.ParentGroupPracticeLocation = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Services collection
		/// </summary>
		public void LoadServices(bool forceReload)
		{
			this.services = (GroupPracticeLocationServiceCollection)GroupPracticeLocationServiceCollection.LoadChildCollection("Services", this, typeof(GroupPracticeLocationServiceCollection), services, forceReload, null);
		}

		/// <summary>
		/// Saves the Services collection
		/// </summary>
		public void SaveServices()
		{
			GroupPracticeLocationServiceCollection.SaveChildCollection(this.services, true);
		}

		/// <summary>
		/// Synchronizes the Services collection
		/// </summary>
		public void SynchronizeServices()
		{
			GroupPracticeLocationServiceCollection.SynchronizeChildCollection(this.services, true);
		}

		/// <summary>
		/// Child Providers mapped to related rows of table GroupPracticeProviders where [GroupPracticeLocationID] = [GroupPracticeLocationID]
		/// </summary>
		[SPLoadChild("usp_LoadGroupPracticeProviders", "groupPracticeLocationID")]
		public GroupPracticeProviderLinkCollection Providers
		{
			get { return this.providers; }
			set
			{
				this.providers = value;
				value.ParentGroupPracticeLocation = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Providers collection
		/// </summary>
		public void LoadProviders(bool forceReload)
		{
			this.providers = (GroupPracticeProviderLinkCollection)GroupPracticeProviderLinkCollection.LoadChildCollection("Providers", this, typeof(GroupPracticeProviderLinkCollection), providers, forceReload, null);
		}

		/// <summary>
		/// Saves the Providers collection
		/// </summary>
		public void SaveProviders()
		{
			GroupPracticeProviderLinkCollection.SaveChildCollection(this.providers, true);
		}

		/// <summary>
		/// Synchronizes the Providers collection
		/// </summary>
		public void SynchronizeProviders()
		{
			GroupPracticeProviderLinkCollection.SynchronizeChildCollection(this.providers, true);
		}
		
		/// <summary>
		/// Retrieve the group Practice Network Information and returns the GroupPracticeNetworkLink object 
		/// </summary>
		/// <returns></returns>
		public GroupPracticeLocationNetworkLink GetGroupPracticeNetwork()
		{
			if (this.groupPracticeLocationID == 0)
				return null;
			GroupPracticeLocationNetworkLinkCollection groupPracticeNetworkLink = new GroupPracticeLocationNetworkLinkCollection();
			groupPracticeNetworkLink.GetAllNetworkByGroupPracticeLocationID(-1,this.groupPracticeLocationID); 
			
			if (groupPracticeNetworkLink.Count == 0)
				return null;

			if (groupPracticeNetworkLink.Count > 1)
				throw new ActiveAdviceException(AAExceptionAction.None, "There are more than 1 Group Practice Networks for chosen Group Practice{0}", groupPracticeID);

			return groupPracticeNetworkLink[0];
		}






		/// <summary>
		/// Child Networks mapped to related rows of table GroupPracticeLocationNetworks where [GroupPracticeLocationID] = [GroupPracticeLocationID]
		/// </summary>
		[SPLoadChild("usp_LoadGroupPracticeLocationGroupPracticeLocationNetworks", "groupPracticeLocationID")]
		public GroupPracticeLocationNetworkLinkCollection Networks
		{
			get { return this.networks; }
			set
			{
				this.networks = value;
				value.ParentGroupPracticeLocation = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Networks collection
		/// </summary>
		public void LoadNetworks(bool forceReload)
		{
			this.networks = (GroupPracticeLocationNetworkLinkCollection)GroupPracticeLocationNetworkLinkCollection.LoadChildCollection("Networks", this, typeof(GroupPracticeLocationNetworkLinkCollection), networks, forceReload, null);
		}

		/// <summary>
		/// Saves the Networks collection
		/// </summary>
		public void SaveNetworks()
		{
			GroupPracticeLocationNetworkLinkCollection.SaveChildCollection(this.networks, true);
		}

		/// <summary>
		/// Synchronizes the Networks collection
		/// </summary>
		public void SynchronizeNetworks()
		{
			GroupPracticeLocationNetworkLinkCollection.SynchronizeChildCollection(this.networks, true);
		}

	
		/// <summary>
		/// Child GroupPracticeLocationContacts mapped to related rows of table GroupPracticeLocationContact where [GroupPracticeLocationID] = [GroupPracticeLocationID]
		/// </summary>
		[SPLoadChild("usp_LoadGroupPracticeLocationContacts", "groupPracticeLocationID")]
		public GroupPracticeLocationContactCollection GroupPracticeLocationContacts
		{
			get { return this.groupPracticeLocationContacts; }
			set
			{
				this.groupPracticeLocationContacts = value;
				if (value != null)
					value.ParentGroupPracticeLocation = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the GroupPracticeLocationContacts collection
		/// </summary>
		public void LoadGroupPracticeLocationContacts(bool forceReload)
		{
			this.groupPracticeLocationContacts = (GroupPracticeLocationContactCollection)GroupPracticeLocationContactCollection.LoadChildCollection("GroupPracticeLocationContacts", this, typeof(GroupPracticeLocationContactCollection), groupPracticeLocationContacts, forceReload, null);
		}

		/// <summary>
		/// Saves the GroupPracticeLocationContacts collection
		/// </summary>
		public void SaveGroupPracticeLocationContacts()
		{
			GroupPracticeLocationContactCollection.SaveChildCollection(this.groupPracticeLocationContacts, true);
		}

		/// <summary>
		/// Synchronizes the GroupPracticeLocationContacts collection
		/// </summary>
		public void SynchronizeGroupPracticeLocationContacts()
		{
			GroupPracticeLocationContactCollection.SynchronizeChildCollection(this.groupPracticeLocationContacts, true);
		}

		#region IContactOwner Members

		public BaseDataCollectionClass GetContacts()
		{
			if (GroupPracticeLocationContacts == null) LoadGroupPracticeLocationContacts(false);
			return GroupPracticeLocationContacts;
		}

		public void LoadContacts(bool forceLoad)
		{
			this.LoadGroupPracticeLocationContacts(forceLoad);
		}

		public void SaveContacts()
		{
			this.SaveGroupPracticeLocationContacts();
		}

		public ContactOwnerType ContactOwnerType
		{
			get
			{
				return ContactOwnerType.GroupPracticeLocation;
			}
		}

		#endregion

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
				
			//this.Location.SqlData.UseTransaction(this.sqlData.Transaction);
			this.Location.Save();
			//this.sqlData.EnsureTransaction();	// Don't open transaction in InternalSave.  Start your transaction in Custom Save method!
			this.CreatedBy	= 1;
			this.CreateTime	= DateTime.Now;
			if (this.services != null)
			{
				this.Services.SqlData.Transaction = this.SqlData.Transaction;
				this.SaveServices();
			}
			if (this.networks != null)
			{
				this.Networks.SqlData.Transaction = this.SqlData.Transaction;
				this.SaveNetworks();
			}
			this.locationID = this.Location.LocationID;			
			
			base.InternalSave();
			//this.sqlData.CommitTransaction();

			// Save the contained objects that must be saved first.
		}
	}

	/// <summary>
	/// Strongly typed collection of GroupPracticeLocation objects
	/// </summary>
	[ElementType(typeof(GroupPracticeLocation))]
	public class GroupPracticeLocationCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPracticeLocation elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeLocationCollection = this;
			else
				elem.ParentGroupPracticeLocationCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPracticeLocation elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPracticeLocation this[int index]
		{
			get
			{
				return (GroupPracticeLocation)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPracticeLocation)oldValue, false);
			SetParentOnElem((GroupPracticeLocation)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
		
		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, GroupPracticeLocation elem)
		{
			List.Insert(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeLocation)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GroupPracticeLocation elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPracticeLocation elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeLocation)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}
		
		/* Don't use this.
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(string filter, string sort)
		{
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForType(typeof(GroupPracticeLocation), filter, sort);
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Parent GroupPractice that contains this collection
		/// </summary>
		public GroupPractice ParentGroupPractice
		{
			get { return this.ParentDataObject as GroupPractice; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GroupPractice */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SelectAllGroupPracticeLocationsByGroupPracticeID(int maxRecords, int groupPracticeID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllGroupPracticeLocationsByGroupPracticeID", maxRecords, this, false, new object[] { groupPracticeID });
		}

		public void LoadLocationsWithFilter(int NetworkID, int GroupPracticeID, Address Addr, int planID, DateTime effectiveDate)
		{
			GroupPractice grpPrac = new GroupPractice();
			grpPrac.GroupPracticeID = GroupPracticeID;
			object[] prms = { Addr, NetworkID, grpPrac};
			this.Clear();
			this.SqlData.SPExecReadCol("usp_LoadGroupPracticeLocationWithFilter",-1,this, prms, true, new string[] { "NetworkID", "PlanID", "EffectiveDate" }, new object[] { NetworkID, planID, SQLDataDirect.MakeDBValue(effectiveDate)});
		}

		public void LoadLocationsWithFilter(int GroupPracticeID, Address Addr)
		{
			GroupPractice grpPrac = new GroupPractice();
			grpPrac.GroupPracticeID = GroupPracticeID;
			object[] prms = { Addr, grpPrac};
			this.Clear();
			this.SqlData.SPExecReadCol("usp_LoadGroupPracticeLocationWithFilter",-1,this, prms, true);
		}
	}
}
