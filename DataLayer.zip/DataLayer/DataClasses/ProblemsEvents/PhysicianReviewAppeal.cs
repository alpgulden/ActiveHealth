using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianReviewDecision]
	/// </summary>
	[SPInsert("usp_InsertPhysicianReviewAppeal")]
	[SPUpdate("usp_UpdatePhysicianReviewAppeal")]
	[SPLoad("usp_LoadPhysicianReviewAppeal")]
	[TableMapping("PhysicianReviewAppeal","physicianReviewAppealID")]
	public class PhysicianReviewAppeal : BaseDataWithUserDefined
	{
		[NonSerialized]
		private PhysicianReviewAppealCollection parentPhysicianReviewAppealCollection;
		[ColumnMapping("PhysicianReviewAppealID",StereoType=DataStereoType.FK)]
		private int physicianReviewAppealID;
		[ColumnMapping("PhysicianReviewRequestDetailID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestDetailID;
		[ColumnMapping("AuthFormReceivedDate")]
		private DateTime authFormReceivedDate;
		[ColumnMapping("MedRecordReleaseSentDate")]
		private DateTime medRecordReleaseSentDate;
		[ColumnMapping("MedRecordReceivedDate")]
		private DateTime medRecordReceivedDate;
		[ColumnMapping("AppealRequestedByTypeID",StereoType=DataStereoType.FK)]
		private int appealRequestedByTypeID;
		[ColumnMapping("AppealStartDate")]
		private DateTime appealStartDate;
		[ColumnMapping("AppealEndDate")]
		private DateTime appealEndDate;
		[ColumnMapping("ClientRequestInformationDate")]
		private DateTime clientRequestInformationDate;
		[ColumnMapping("ClientReceivedInformationDate")]
		private DateTime clientReceivedInformationDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public PhysicianReviewAppeal()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianReviewAppeal(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PhysicianReviewAppealID
		{
			get { return this.physicianReviewAppealID; }
			set { this.physicianReviewAppealID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PhysicianReviewRequestDetailID
		{
			get { return this.physicianReviewRequestDetailID; }
			set { this.physicianReviewRequestDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AuthFormReceivedDate
		{
			get { return this.authFormReceivedDate; }
			set { this.authFormReceivedDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MedRecordReleaseSentDate
		{
			get { return this.medRecordReleaseSentDate; }
			set { this.medRecordReleaseSentDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MedRecordReceivedDate
		{
			get { return this.medRecordReceivedDate; }
			set { this.medRecordReceivedDate = value; }
		}
		
		
		[FieldValuesMember("LookupOf_AppealRequestedByTypeID", "PhysicianReviewAppealRequestByTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@REQUESTEDBY@")]
		public int AppealRequestedByTypeID
		{
			get { return this.appealRequestedByTypeID; }
			set { this.appealRequestedByTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AppealStartDate
		{
			get { return this.appealStartDate; }
			set { this.appealStartDate = value; }
		}
		
		[ValidatorMember("Vld_AppealEndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AppealEndDate
		{
			get { return this.appealEndDate; }
			set { this.appealEndDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ClientRequestInformationDate
		{
			get { return this.clientRequestInformationDate; }
			set { this.clientRequestInformationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ClientReceivedInformationDate
		{
			get { return this.clientReceivedInformationDate; }
			set { this.clientReceivedInformationDate = value; }
		}

		/// <summary>
		/// Parent PhysicianReviewRequestDetail that contains this object
		/// </summary>
		public PhysicianReviewRequestDetail ParentPhysicianReviewRequestDetail
		{
			get { return this.ParentDataObject as PhysicianReviewRequestDetail; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PhysicianReviewRequestDetail */ }
		}

		/// <summary>
		/// Parent PhysicianReviewAppealCollection that contains this element
		/// </summary>
		public PhysicianReviewAppealCollection ParentPhysicianReviewAppealCollection
		{
			get
			{
				return this.parentPhysicianReviewAppealCollection;
			}
			set
			{
				this.parentPhysicianReviewAppealCollection = value; // parent is set when added to a collection
			}
		}


		// General validator props
		[GenericScript("Vld_AppealEndDate", "@AppealEndDate@ != null && @AppealEndDate@ >= @AppealStartDate@;")]
		protected string Vld_AppealEndDate
		{
			get
			{
				return "@ERRENDDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
				/*DateTime terminationDate = (DateTime)this.Get("terminationDate");
				DateTime effectiveDate = (DateTime)this.Get("effectiveDate");
				if (terminationDate != DateTime.MinValue && !(terminationDate >= effectiveDate))
					throw new ValidationException("TerminationDate", Vld_TerminationDate);  // throw validation exception if failed (don't set the member) 
					*/

				// Can't validate on the server, because the depended 2 members are not filled yet.
			}
		}


		public PhysicianReviewDecisionCollection LookupOf_PhysicianReviewDecisionID
		{
			get
			{
				return PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewAppealRequestByTypeCollection LookupOf_AppealRequestedByTypeID
		{
			get
			{
				return PhysicianReviewAppealRequestByTypeCollection.ActivePhysicianReviewAppealRequestByTypes; // Acquire a shared instance from the static member of collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of PhysicianReviewAppeal objects
	/// </summary>
	[ElementType(typeof(PhysicianReviewAppeal))]
	public class PhysicianReviewAppealCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianReviewAppeal elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianReviewAppealCollection = this;
			else
				elem.ParentPhysicianReviewAppealCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianReviewAppeal elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianReviewAppeal this[int index]
		{
			get
			{
				return (PhysicianReviewAppeal)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianReviewAppeal)oldValue, false);
			SetParentOnElem((PhysicianReviewAppeal)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent PhysicianReviewRequestDetail that contains this collection
		/// </summary>
		public PhysicianReviewRequestDetail ParentPhysicianReviewRequestDetail
		{
			get { return this.ParentDataObject as PhysicianReviewRequestDetail; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PhysicianReviewRequestDetail */ }
		}
	}

}
