using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianReviewDecision]
	/// </summary>
	[SPInsert("usp_InsertPRReview")]
	[SPUpdate("usp_UpdatePRReview")]
	[SPLoad("usp_LoadPRReview")]
	[TableMapping("PRReview","pRReviewID")]
	public class PRReview : BaseDataWithUserDefined
	{
		[NonSerialized]
		private PRReviewCollection parentPRReviewCollection;
		[ColumnMapping("PRReviewID",StereoType=DataStereoType.FK)]
		private int pRReviewID;
		[ColumnMapping("PRRequestID",StereoType=DataStereoType.FK)]
		private int pRRequestID;
		[ColumnMapping("AuthFormReceivedDate")]
		private DateTime authFormReceivedDate;
		[ColumnMapping("MedRecordReleaseSentDate")]
		private DateTime medRecordReleaseSentDate;
		[ColumnMapping("MedRecordReceivedDate")]
		private DateTime medRecordReceivedDate;
		[ColumnMapping("AppealRequestedByTypeID",StereoType=DataStereoType.FK)]
		private int appealRequestedByTypeID;
		[ColumnMapping("AppealStartDate")]
		private DateTime appealStartDate;
		[ColumnMapping("AppealEndDate")]
		private DateTime appealEndDate;
		[ColumnMapping("ClientRequestInformationDate")]
		private DateTime clientRequestInformationDate;
		[ColumnMapping("ClientReceivedInformationDate")]
		private DateTime clientReceivedInformationDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy; 
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("PhysicianReviewRequestDetailTypeID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestDetailTypeID;
		[ColumnMapping("ParentReviewID",StereoType=DataStereoType.FK)]
		private int parentReviewID;
		[ColumnMapping("PhysicianReviewDecisionID",StereoType=DataStereoType.FK)]
		private int physicianReviewDecisionID;
		private PRProviderDecisionCollection pRProviderDecisions;
	
		private PRReview parentReview;

		public PRReview()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PRReview(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public PRReview(bool initNew, bool initDefaultValues) : this(initNew)
		{
			if (initDefaultValues)
			{
				// Default Start Date is Now
				this.AppealStartDate = DateTime.Now;
				this.PhysicianReviewRequestDetailTypeID = PhysicianReviewRequestDetailTypeCollection.ActivePhysicianReviewRequestDetailTypes.Lookup_PhysicianReviewRequestDetailTypeIDByCode(PhysicianReviewRequestDetailType.PR);
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PRReviewID
		{
			get { return this.pRReviewID; }
			set { this.pRReviewID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PRRequestID
		{
			get { return this.pRRequestID; }
			set { this.pRRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AuthFormReceivedDate
		{
			get { return this.authFormReceivedDate; }
			set { this.authFormReceivedDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MedRecordReleaseSentDate
		{
			get { return this.medRecordReleaseSentDate; }
			set { this.medRecordReleaseSentDate = value; }
		}

		[ValidatorMember("Vld_MedRecordReceivedDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MedRecordReceivedDate
		{
			get { return this.medRecordReceivedDate; }
			set { this.medRecordReceivedDate = value; }
		}
		
		
		[FieldValuesMember("LookupOf_AppealRequestedByTypeID", "PhysicianReviewAppealRequestByTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@REQUESTEDBY@")]
		public int AppealRequestedByTypeID
		{
			get { return this.appealRequestedByTypeID; }
			set { this.appealRequestedByTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime)]
		[FieldDescription("@APPEALSTARTDATE@")]
		public System.DateTime AppealStartDate
		{
			get { return this.appealStartDate; }
			set { this.appealStartDate = value; }
		}
		
		[ValidatorMember("Vld_AppealEndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime)]
		[FieldDescription("@APPEALENDDATE@")]
		public System.DateTime AppealEndDate
		{
			get { return this.appealEndDate; }
			set { this.appealEndDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ClientRequestInformationDate
		{
			get { return this.clientRequestInformationDate; }
			set { this.clientRequestInformationDate = value; }
		}

		[ValidatorMember("Vld_MedRecordReceivedDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ClientReceivedInformationDate
		{
			get { return this.clientReceivedInformationDate; }
			set { this.clientReceivedInformationDate = value; }
		}


		public PRProviderDecision GetMostRecentProviderDecision()
		{
			PRProviderDecision latestProviderDecision = null;
			this.LoadPRProviderDecisions(false);
			if (this.pRProviderDecisions.Count > 0)
			{
				latestProviderDecision = this.pRProviderDecisions[0];
				foreach (PRProviderDecision providerDecision in this.pRProviderDecisions) // We want only active ones
					if (providerDecision.Active && providerDecision.CreateTime > latestProviderDecision.CreateTime) latestProviderDecision = providerDecision;
			}

			return latestProviderDecision;
		}

		public bool IsMostRecentProviderDecision(PRProviderDecision providerDecision)
		{
			PRProviderDecision latestProviderDecision = GetMostRecentProviderDecision();
			return (latestProviderDecision == null || (providerDecision.PRProviderDecisionID == latestProviderDecision.PRProviderDecisionID));
		}

		public bool CanChangeReviewType()
		{
			if (this.IsNew) return true;

			PRReview parentReview = this.ParentReview;
			if (parentReview == null) return false; // This is the first review
				
			// Unless the PRActionType on the previous decision is NewPreview, return false
			PhysicianReviewDecision dec = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.GetByID(parentReview.PhysicianReviewDecisionID);            
			return (dec.PRActionType == PhysicianReviewDecision.NEWPRREVIEW);
		}

		public PRReview GetParentReview()
		{
			PRReview parentReview = null;
			if (this.ParentReviewID == 0 || this.parentPRReviewCollection == null) return parentReview; 

			return this.parentPRReviewCollection.GetByID(this.ParentReviewID);
		}

		public PRReview ParentReview
		{
			get 
			{
				if (parentReview == null)
					parentReview = GetParentReview();
				return parentReview;
			}
			set { parentReview = value; }
		}

		/// <summary>
		/// Parent PRRequest that contains this object
		/// </summary>
		public PRRequest ParentPRRequest
		{
			get { return this.ParentDataObject as PRRequest; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PRRequest */ }
		}

		/// <summary>
		/// Parent PRReviewCollection that contains this element
		/// </summary>
		public PRReviewCollection ParentPRReviewCollection
		{
			get
			{
				return this.parentPRReviewCollection;
			}
			set
			{
				this.parentPRReviewCollection = value; // parent is set when added to a collection
			}
		}


		// General validator props
		[GenericScript("Vld_AppealEndDate", "@AppealEndDate@ != null && @AppealEndDate@ >= @AppealStartDate@;")]
		protected string Vld_AppealEndDate
		{
			get
			{
				return "@ERRENDDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
			}
		}


		[GenericScript("Vld_MedRecordReceivedDate", "@MedRecordReceivedDate@ != null && @MedRecordReceivedDate@ >= @MedRecordReleaseSentDate@;")]
		protected string Vld_MedRecordReceivedDate
		{
			get
			{
				return "@ERRMEDRECDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
			}
		}

		[GenericScript("Vld_ClientReceivedInformationDate", "@ClientReceivedInformationDate@ != null && @ClientReceivedInformationDate@ >= @ClientRequestInformationDate@;")]
		protected string Vld_ClientReceivedInformationDate
		{
			get
			{
				return "@ERRMEDRECDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
			}
		}



		public PhysicianReviewDecisionCollection LookupOf_PhysicianReviewDecisionID
		{
			get
			{
				return PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewAppealRequestByTypeCollection LookupOf_AppealRequestedByTypeID
		{
			get
			{
				return PhysicianReviewAppealRequestByTypeCollection.ActivePhysicianReviewAppealRequestByTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Child PRProviderDecisions mapped to related rows of table PRProviderDecision where [PRReviewID] = [PRReviewID]
		/// </summary>
		[SPLoadChild("", "pRReviewID")]
		public PRProviderDecisionCollection PRProviderDecisions
		{
			get { return this.pRProviderDecisions; }
			set
			{
				this.pRProviderDecisions = value;
				if (value != null)
					value.ParentPRReview = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PRProviderDecisions collection
		/// </summary>
		public void LoadPRProviderDecisions(bool forceReload)
		{
			this.pRProviderDecisions = (PRProviderDecisionCollection)PRProviderDecisionCollection.LoadChildCollection("PRProviderDecisions", "usp_LoadPRReviewPRProviderDecisions", this, typeof(PRProviderDecisionCollection), pRProviderDecisions, forceReload, null);
		}

		/// <summary>
		/// Saves the PRProviderDecisions collection
		/// </summary>
		public void SavePRProviderDecisions()
		{
			PRProviderDecisionCollection.SaveChildCollection(this.pRProviderDecisions, true);
		}

		/// <summary>
		/// Synchronizes the PRProviderDecisions collection
		/// </summary>
		public void SynchronizePRProviderDecisions()
		{
			PRProviderDecisionCollection.SynchronizeChildCollection(this.pRProviderDecisions, true);
		}

		[FieldValuesMember("LookupOf_PhysicianReviewRequestDetailTypeID", "PhysicianReviewRequestDetailTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int PhysicianReviewRequestDetailTypeID
		{
			get { return this.physicianReviewRequestDetailTypeID; }
			set { this.physicianReviewRequestDetailTypeID = value; }
		}

		protected override void InternalSave()
		{
			base.InternalSave();
			// Save the child collections here.

			// save child tables that are managed in-memory
			this.SavePRProviderDecisions();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ParentReviewID
		{
			get { return this.parentReviewID; }
			set { this.parentReviewID = value; }
		}

		public PhysicianReviewRequestDetailTypeCollection LookupOf_PhysicianReviewRequestDetailTypeID
		{
			get
			{
				PhysicianReviewRequestDetailTypeCollection col = new PhysicianReviewRequestDetailTypeCollection();
				col.LoadPhysicianReviewRequestDetailTypesByActive(-1, true);
				col.PReviousReviewTypecode = "";
				PRReview review = this.ParentReview;
				if (review != null)
				{
					PhysicianReviewRequestDetailType reviewType = PhysicianReviewRequestDetailTypeCollection.ActivePhysicianReviewRequestDetailTypes.FindBy(review.PhysicianReviewRequestDetailTypeID);
					if (reviewType != null)
					{
						col.PReviousReviewTypecode = reviewType.Code;
					}
				}
				return col;
			}
		}

		public bool IsAppeal()
		{
			PhysicianReviewRequestDetailType dType = PhysicianReviewRequestDetailTypeCollection.ActivePhysicianReviewRequestDetailTypes.FindBy(this.physicianReviewRequestDetailTypeID);
			return (dType != null && dType.SubCodeExtStr == "APPL");
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int pRReviewID)
		{
			return base.Load(pRReviewID);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PhysicianReviewDecisionID
		{
			get { return this.physicianReviewDecisionID; }
			set { this.physicianReviewDecisionID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		

	}

	/// <summary>
	/// Strongly typed collection of PRReview objects
	/// </summary>
	[ElementType(typeof(PRReview))]
	public class PRReviewCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PRReview elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPRReviewCollection = this;
			else
				elem.ParentPRReviewCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PRReview elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PRReview this[int index]
		{
			get
			{
				return (PRReview)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PRReview)oldValue, false);
			SetParentOnElem((PRReview)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}


		/// <summary>
		/// Parent PRRequest that contains this collection
		/// </summary>
		public PRRequest ParentPRRequest
		{
			get { return this.ParentDataObject as PRRequest; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PRRequest */ }
		}


		public PRReview GetByID(int pRReviewID)
		{
			foreach (PRReview review in this)
			{
				if (review.PRReviewID == pRReviewID) return review;
			}

			return null;
		}
	}

}
