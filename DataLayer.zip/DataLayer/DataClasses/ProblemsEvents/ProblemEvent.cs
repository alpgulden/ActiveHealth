using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProblemEvent]
	/// </summary>
	[SPAutoGen("usp_DeleteProblemEventByProblemIDEventID","DeleteByGivenArgs.sptpl","problemId, eventID")]
	[SPAutoGen("usp_LoadAllProblemEventLinksByEventId","SelectAllByGivenArgs.sptpl","eventID")]
	[SPAutoGen("usp_CountProblemEvent","CountAllByGivenArgs.sptpl","problemId, eventID")]
	[SPInsert("usp_InsertProblemEvent")]
	[SPUpdate("usp_UpdateProblemEvent")]
	[SPDelete("usp_DeleteProblemEvent")]
	[SPLoad("usp_LoadProblemEvent")]
	[TableMapping("ProblemEvent","problemEventID")]
	//public class ProblemEvent : BaseData
	public class ProblemEvent : BaseERCProblemLink
	{
		[NonSerialized]
		private ProblemEventCollection parentProblemEventCollection;
		[ColumnMapping("ProblemEventID",StereoType=DataStereoType.FK)]
		private int problemEventID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		private int patientId;
		[ColumnMapping("ProblemId",StereoType=DataStereoType.FK)]
		private int problemId;

		// linked problem and event objects
		private Problem problem;
		private Event eventObj;
		private Patient patient;
	
		#region BaseERCProblemLink abstract methods overridden
		public override int ERCId
		{
			get { return this.eventID; }
			//set { this.cMSId = value; }
		}
		
		public override int ProblemId
		{
			get { return this.problemId; }
			//set { this.problemId = value; }
		}

		public override BaseERCProblemLinkCollection ParentBaseERCProblemLinkCollection
		{
			get
			{
				return (BaseERCProblemLinkCollection)this.parentProblemEventCollection;
			}
			set
			{
				this.parentProblemEventCollection = (ProblemEventCollection)value; // parent is set when added to a collection
			}
		}
		#endregion
		
		public ProblemEvent()
		{
		}
		
		public ProblemEvent(int eventId, int problemId, int patientId, bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			this.eventID = eventId;
			this.problemId = problemId;
			this.patientId = patientId;
		}

		public ProblemEvent(Patient patient, Problem problem, Event eventObj)
		{
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "The ProblemEvent must be created in the context of a patient");

			if (problem == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "The ProblemEvent must be created in the context of a problem");

			if (eventObj == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "A null event was passed to the ProblemEvent");

			this.NewRecord(); // initialize record state
			this.patient = patient;
			this.patientId = patient.PatientId;
			this.problem = problem;
			this.problemId = problem.ProblemID;
			this.eventObj = eventObj;
			this.eventID = eventObj.EventID;
		}

		public ProblemEvent(int patientId, int problemId, int eventID)
		{
			this.patientId = patientId;
			this.problemId = problemId;
			this.eventID = eventID;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ProblemEventID
		{
			get { return this.problemEventID; }
			set { this.problemEventID = value; }
		}

//		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
//		public int EventID
//		{
//			get { return this.eventID; }
//			set 
//			{ 
//				this.eventID = value; 
//				this.eventObj = null;	// force reload of the eventObj
//			}
//		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientId
		{
			get { return this.patientId; }
			//set { this.patientId = value; }
		}

		
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EventID
		{
			get { return this.eventID; }
			//set { this.patientId = value; }
		}

//		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
//		public int ProblemId
//		{
//			get { return this.problemId; }
//			/*set 
//			{
//				this.problemId = value; 
//				this.problem = null;
//			}*/
//		}

		public Problem Problem
		{
			get
			{
				if (this.problem == null)
					if (this.parentProblemEventCollection != null)
						this.problem = this.parentProblemEventCollection.ParentProblem;

				if (this.problem == null)
					this.problem = GetProblem();

				return this.problem;
			}
		}

		/// <summary>
		/// Loads and returns the associated problem.
		/// </summary>
		/// <returns></returns>
		public Problem GetProblem()
		{
			if (this.problemId == 0)
				return null;
			Problem problem = new Problem();
			if (problem.Load(this.problemId))
				return problem;
			else
				return null;
		}

		public Event Event
		{
			get
			{
				if (this.eventObj == null)
					this.eventObj = GetEvent();

				return this.eventObj;
			}
		}

		/// <summary>
		/// Loads and returns the associated event.
		/// </summary>
		/// <returns></returns>
		public Event GetEvent()
		{
			if (this.eventID == 0)
				return null;
			Event eventObj = new Event();
			if (eventObj.Load(this.patient, this.eventID))
				return eventObj;
			else
				return null;
		}

		public Patient Patient
		{
			get
			{
				if (this.patient == null)
					if (this.Problem != null)				// try to get from Problem
						if (this.Problem.Patient != null)
							this.patient = this.Patient;

				if (this.patient == null)
					this.patient = GetPatient();

				return this.patient;
			}
		}

		/// <summary>
		/// Loads and returns the parent patient.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientId == 0)
				return null;
			Patient patient = new Patient();
			if (patient.Load(this.patientId))
				return patient;
			else
				return null;
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int problemEventID)
		{
			return base.Load(problemEventID);
		}

		/// <summary>
		/// Parent ProblemEventCollection that contains this element
		/// </summary>
		public ProblemEventCollection ParentProblemEventCollection
		{
			get
			{
				return this.parentProblemEventCollection;
			}
			set
			{
				this.parentProblemEventCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Checks the existence of problemevent in the db
		/// </summary>
		public bool ProblemEventExists()
		{
			return (int)SqlData.SPExecScalar("usp_CountProblemEvent", this.problemId, this.eventID) > 0;
		}

		/// <summary>
		/// Deletes the given problem-event link for the given problem and event id.
		/// </summary>
		public void Delete(int problemId, int eventID)
		{
			SqlData.SPExecNonQuery("usp_DeleteProblemEventByProblemIDEventID", new object[] { problemId, eventID });
		}

	}

	/// <summary>
	/// Strongly typed collection of ProblemEvent objects
	/// </summary>
	[ElementType(typeof(ProblemEvent))]
	//public class ProblemEventCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	public class ProblemEventCollection : BaseERCProblemLinkCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ProblemId;
		[NonSerialized]
		private CollectionIndexer indexBy_EventID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProblemEvent elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProblemEventCollection = this;
			else
				elem.ParentProblemEventCollection = null;		
		}
		
		private void SetParentOnElem(BaseERCProblemLink elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentBaseERCProblemLinkCollection = this;
			else
				elem.ParentBaseERCProblemLinkCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProblemEvent elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProblemEvent this[int index]
		{
			get
			{
				return (ProblemEvent)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProblemEvent)oldValue, false);
			SetParentOnElem((ProblemEvent)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Problem that contains this collection
		/// </summary>
		public Problem ParentProblem
		{
			get { return this.ParentDataObject as Problem; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Problem */ }
		}

		/// <summary>
		/// Hashtable based index on eventID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_EventID
		{
			get
			{
				if (this.indexBy_EventID == null)
					this.indexBy_EventID = new CollectionIndexer(this, new string[] { "eventID" }, true);
				return this.indexBy_EventID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on eventID fields returns the object.  Uses the IndexBy_EventID indexer.
		/// </summary>
		public ProblemEvent FindByEventID(int eventID)
		{
			return (ProblemEvent)this.IndexBy_EventID.GetObject(eventID);
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ProblemEvent elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ProblemEvent)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Hashtable based index on problemId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ProblemId
		{
			get
			{
				if (this.indexBy_ProblemId == null)
					this.indexBy_ProblemId = new CollectionIndexer(this, new string[] { "problemId" }, true);
				return this.indexBy_ProblemId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on problemId fields returns the object.  Uses the IndexBy_ProblemId indexer.
		/// </summary>
		public ProblemEvent FindByProblemId(int problemId)
		{
			return (ProblemEvent)this.IndexBy_ProblemId.GetObject(problemId);
		}

		#region Overrides BaseERCProblemLinkCollection
		public override void DetermineLinkedProblems(ProblemCollection problems)
		{
			this.IndexBy_ProblemId.Rebuild();
			foreach (Problem problem in problems)
			{
				if (FindByProblemId(problem.ProblemID) == null)
					problem.IsERCLinked = false;
				else
				{
					problem.IsERCLinked = true;
					if (this.ParentEvent.PrimaryProblemID == problem.ProblemID)
						problem.IsPrimary = true;
					else
						problem.IsPrimary = false;
				}
			}
		}

		public override void SynchronizeFromProblems(ProblemCollection problems)
		{
			this.IndexBy_ProblemId.Rebuild();
			foreach (Problem problem in problems)
			{ //Update Linkages based on problem 
				ProblemEvent problemEvent = FindByProblemId(problem.ProblemID);
				if (problem.IsERCLinked)
				{
					if (problemEvent == null)
					{	// If no linkage exists - create new one
						// otherwise do nothing
						problemEvent = new ProblemEvent(this.ParentEvent.EventID, problem.ProblemID, this.ParentEvent.PatientId, true);
						this.Add(problemEvent);
					}
				}
				if (!problem.IsERCLinked)
				{	
					if (problemEvent != null) // If linkage exists - delete it, otherwise do nothing
					{	// don't unlik primary problem
						if (this.ParentEvent.PrimaryProblemID != problem.ProblemID)
							problemEvent.MarkDel();
						else
							throw new ActiveAdviceException(AAExceptionAction.None, "Primary problem cannot be unlinked.");
					}
				}
			}// end of foreach
		}

		public override void SetPrimaryProblem(Problem problem)
		{
			this.ParentEvent.PrimaryProblemID = problem.ProblemID;
			problem.IsPrimary = true;
			this.IndexBy_ProblemId.Rebuild();
			if (FindByProblemId(problem.ProblemID) == null)
			{	//Create link if it wasn't there
				ProblemEvent problemEvent = new ProblemEvent(this.ParentEvent.EventID, problem.ProblemID, this.ParentEvent.PatientId, true);
				this.Add(problemEvent);
				this.SaveElements();
			}
			this.ParentEvent.Update();		// event is never new.
		}
		#endregion

		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Event ParentEvent
		{
			get { return this.ParentDataObject as Event; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}
	}
}
