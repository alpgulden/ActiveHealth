using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ClinicalReviewDurUnit]
	/// </summary>
	[SPAutoGen("usp_LoadClinicalReviewDurUnitbyCode","SelectAllByGivenArgs.sptpl","code")]
	[SPAutoGen("usp_GetClinicalReviewDurUnits","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetClinicalReviewDurUnitsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertClinicalReviewDurUnit")]
	[SPUpdate("usp_UpdateClinicalReviewDurUnit")]
	[SPDelete("usp_DeleteClinicalReviewDurUnit")]
	[SPLoad("usp_LoadClinicalReviewDurUnit")]
	[TableMapping("ClinicalReviewDurUnit","clinicalReviewDurUnitID")]
	public class ClinicalReviewDurUnit : BaseLookupWithSubCodeSTR
	{
		[NonSerialized]
		private ClinicalReviewDurUnitCollection parentClinicalReviewDurUnitCollection;
		[ColumnMapping("ClinicalReviewDurUnitID",StereoType=DataStereoType.FK)]
		private int clinicalReviewDurUnitID;
		[ColumnMapping("DaysConversion")]
		private Decimal daysConversion;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public ClinicalReviewDurUnit()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ClinicalReviewDurUnit(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ClinicalReviewDurUnitID
		{
			get { return this.clinicalReviewDurUnitID; }
			set { this.clinicalReviewDurUnitID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double, IsRequired=true)]
		public decimal DaysConversion
		{
			get { return this.daysConversion; }
			set { this.daysConversion = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}
				
		[FieldValuesMember("ValueOf_SubCodeStr")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, IsRequired=true)]
		[FieldDescription("@DAYCONVERSION@")]
		public override string SubCodeStr
		{
			get { return String.Format("{0:D}",this.daysConversion.ToString());}
			set	{ this.daysConversion = decimal.Parse(value); }
		}

		public object[,] ValueOf_SubCodeStr
		{
			get
			{
				return new object[,] {{"1.000","Days"},{"0.042","Hours"},{"7.000","Weeks"},{"-111.000","Months"},{"1.000","Visit"}};
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int clinicalReviewDurUnitID)
		{
			return base.Load(clinicalReviewDurUnitID);
		}

		/// <summary>
		/// Parent ClinicalReviewDurUnitCollection that contains this element
		/// </summary>
		public ClinicalReviewDurUnitCollection ParentClinicalReviewDurUnitCollection
		{
			get
			{
				return this.parentClinicalReviewDurUnitCollection;
			}
			set
			{
				this.parentClinicalReviewDurUnitCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Loads the object specified by parameters from table
		/// </summary>
		public bool Load(string code)
		{
			// TODO: Specify stored procedure name correctly.
			return SqlData.SPExecReadObj("usp_LoadClinicalReviewDurUnitbyCode", this, false, code);
		}
	}

	/// <summary>
	/// Strongly typed collection of ClinicalReviewDurUnit objects
	/// </summary>
	[ElementType(typeof(ClinicalReviewDurUnit))]
	public class ClinicalReviewDurUnitCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClinicalReviewDurUnit elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClinicalReviewDurUnitCollection = this;
			else
				elem.ParentClinicalReviewDurUnitCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClinicalReviewDurUnit elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClinicalReviewDurUnit this[int index]
		{
			get
			{
				return (ClinicalReviewDurUnit)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClinicalReviewDurUnit)oldValue, false);
			SetParentOnElem((ClinicalReviewDurUnit)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadClinicalReviewDurUnitsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetClinicalReviewDurUnitsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ClinicalReviewDurUnitCollection which is cached in NSGlobal
		/// </summary>
		public static ClinicalReviewDurUnitCollection ActiveClinicalReviewDurUnits
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ClinicalReviewDurUnitCollection col = (ClinicalReviewDurUnitCollection)NSGlobal.EnsureCachedObject("ActiveClinicalReviewDurUnits", typeof(ClinicalReviewDurUnitCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadClinicalReviewDurUnitsByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Hashtable based search on code fields returns the object.  Uses the IndexBy_Code indexer.
		/// </summary>
		public ClinicalReviewDurUnit FindBy(string code)
		{
			return (ClinicalReviewDurUnit)this.IndexBy_Code.GetObject(code);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetClinicalReviewDurUnits", -1, this, false);
		}	

	}
}
