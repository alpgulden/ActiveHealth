using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianReviewDecision]
	/// </summary>
	[SPInsert("usp_InsertPhysicianReviewRequest")]
	[SPUpdate("usp_UpdatePhysicianReviewRequest")]
	[SPLoad("usp_LoadPhysicianReviewRequest")]
	[TableMapping("PhysicianReviewRequest","physicianReviewRequestID")]
	public class PhysicianReviewRequest : BaseDataWithUserDefined, IImageOwner
	{
		[NonSerialized]
		private PhysicianReviewRequestCollection parentPhysicianReviewRequestCollection;
		[ColumnMapping("PhysicianReviewRequestID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("PhysicianReviewRequestReasonID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestReasonID;
		[ColumnMapping("PhysicianReviewDecisionID",StereoType=DataStereoType.FK)]
		private int physicianReviewDecisionID;
		[ColumnMapping("PhysicianReviewRequestStatusID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestStatusID;
		[ColumnMapping("StatusChangedBy",StereoType=DataStereoType.FK)]
		private int statusChangedBy;
		[ColumnMapping("StatusChangeTime")]
		private DateTime statusChangeTime;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("ProblemID",StereoType=DataStereoType.FK)]
		private int problemID;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("StartDate")]
		private DateTime startDate = DateTime.Now; // Current Date Time
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ClinicalReviewDecisionID",StereoType=DataStereoType.FK)]
		private int clinicalReviewDecisionID;
		private PhysicianReviewRequestDetailCollection physicianReviewRequestDetails;
	
		private int statusIDWhenLoaded;
		private PhysicianReviewRequestDetailCollection physicianRequestDetails;				// keeps track of the changes in status
		private ImageLinkCollection images;
		private AutoActivityManager autoActivityManager;
		private Patient patient;

		public PhysicianReviewRequest()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianReviewRequest(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int physicianReviewRequestID)
		{
			return base.Load(physicianReviewRequestID);
		}

		/// <summary>
		/// Create a physician review linked to the given clinical decision
		/// </summary>
		/// <param name="initNew"></param>
		public PhysicianReviewRequest(ClinicalReviewDecision clinicalDecision)
		{
			this.NewRecord();
			this.clinicalReviewDecisionID = clinicalDecision.ClinicalReviewDecisionID;
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// track the change of statusID.
			this.statusIDWhenLoaded = this.physicianReviewRequestStatusID;
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@PHYSICIANREVIEWREQUESTID@")]
		public int PhysicianReviewRequestID
		{
			get { return this.physicianReviewRequestID; }
			set { this.physicianReviewRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewRequestReasonID", "PhysicianReviewRequestReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@REQUESTREASON@")]
		public int PhysicianReviewRequestReasonID
		{
			get { return this.physicianReviewRequestReasonID; }
			set { this.physicianReviewRequestReasonID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewDecisionID", "PhysicianReviewDecisionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@DECISION@")]
		public int PhysicianReviewDecisionID
		{
			get { return this.physicianReviewDecisionID; }
			set { this.physicianReviewDecisionID = value; }
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime StatusChangeTime
		{
			get { return this.statusChangeTime; }
			set { this.statusChangeTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProblemID
		{
			get { return this.problemID; }
			set { this.problemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}


		[ValidatorMember("Vld_EndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime, ClientScriptForConditionalRequired="GetElemValue('PhysicianReviewDecisionID') != ''")]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ClinicalReviewDecisionID
		{
			get { return this.clinicalReviewDecisionID; }
			set { this.clinicalReviewDecisionID = value; }
		}

		/// <summary>
		/// Parent PhysicianReviewRequestCollection that contains this element
		/// </summary>
		public PhysicianReviewRequestCollection ParentPhysicianReviewRequestCollection
		{
			get
			{
				return this.parentPhysicianReviewRequestCollection;
			}
			set
			{
				this.parentPhysicianReviewRequestCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child PhysicianReviewRequestDetails mapped to related rows of table PhysicianReviewRequestDetail where [PhysicianReviewRequestID] = [PhysicianReviewRequestID]
		/// </summary>
		[SPLoadChild("usp_LoadPhysicianReviewRequestDetails", "physicianReviewRequestID")]
		public PhysicianReviewRequestDetailCollection PhysicianReviewRequestDetails
		{
			get { return this.physicianReviewRequestDetails; }
			set
			{
				this.physicianReviewRequestDetails = value;
				if (value != null)
					value.ParentPhysicianReviewRequest = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PhysicianReviewRequestDetails collection
		/// </summary>
		public void LoadPhysicianReviewRequestDetails(bool forceReload)
		{
			this.physicianReviewRequestDetails = (PhysicianReviewRequestDetailCollection)PhysicianReviewRequestDetailCollection.LoadChildCollection("PhysicianReviewRequestDetails", this, typeof(PhysicianReviewRequestDetailCollection), physicianReviewRequestDetails, forceReload, null);
		}

		/// <summary>
		/// Saves the PhysicianReviewRequestDetails collection
		/// </summary>
		public void SavePhysicianReviewRequestDetails()
		{
			PhysicianReviewRequestDetailCollection.SaveChildCollection(this.physicianReviewRequestDetails, true);
		}

		/// <summary>
		/// Synchronizes the PhysicianReviewRequestDetails collection
		/// </summary>
		public void SynchronizePhysicianReviewRequestDetails()
		{
			PhysicianReviewRequestDetailCollection.SynchronizeChildCollection(this.physicianReviewRequestDetails, true);
		}


		#region Images Overriden
		/// <summary>
		/// Child Images mapped to related rows of table PhysicianReviewRequest where [PhysicianReviewRequestID] = [PhysicianReviewRequestID]
		/// </summary>
		[SPLoadChild("usp_LoadPhysicianReviewRequestImages", "physicianReviewRequestID")]
		public ImageLinkCollection Images
		{
			get { return this.images; }
			set
			{
				this.images = value;
				if (value != null)
					value.ParentPhysicianReviewRequest = this; // set this as a parent of the child collection
			}
		}
				
		/// <summary>
		/// Loads the Outcomes collection
		/// </summary>
		public void LoadImages(bool forceReload)
		{
			this.images = (ImageLinkCollection)ImageLinkCollection.LoadChildCollection("Images", this, typeof(ImageLinkCollection), images, forceReload, null);
		}

		/// <summary>
		/// Saves the Outcomes collection
		/// </summary>
		public void SaveImages()
		{
			ImageLinkCollection.SaveChildCollection(this.images, true);
		}

		/// <summary>
		/// Synchronizes the Outcomes collection
		/// </summary>
		public void SynchronizeImages()
		{
			ImageLinkCollection.SynchronizeChildCollection(this.images, true);
		}

		#endregion



		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			bool initialSave = this.IsNew;

			if (this.IsNew || this.physicianReviewRequestStatusID != this.statusIDWhenLoaded)
			{
				// status changed.
				this.SetStatusChangingUser();
			}

			base.InternalSave();

			#region Trigger AutoActivities - ER2, ER5
			
			if (initialSave)
			{
				PatientCoverage patCov = null;

				if (this.eventID != 0)
				{
					// access event and use it's context
					Event eventObj = this.GetEvent();
					autoActivityManager = this.parentPhysicianReviewRequestCollection.EnsureAutoActivityManager(eventObj.Patient, eventObj);
					AutoActivity_PhysicianReviewRequestForEventInitialSave();	// ER2
				}
				else if (this.referralDetailID != 0)
				{
					// access referral and use it's context.
					ReferralDetail refDetail = this.GetReferralDetail();
					if (refDetail != null)
					{
						Referral referral = refDetail.GetReferral();
						if (referral != null)
						{
							autoActivityManager = this.parentPhysicianReviewRequestCollection.EnsureAutoActivityManager(referral.Patient, referral);
							AutoActivity_PhysicianReviewRequestForReferralInitialSave();	// ER5
						}
					}
				}
			}

			#endregion

			// Save the child collections here.

			// save child tables that are managed in-memory
			this.SavePhysicianReviewRequestDetails();
		}

		/// <summary>
		/// ER2	- Physician Review for Event Initial Save
		/// This is triggered when a new physician review is saved for an event.
		/// </summary>
		public void AutoActivity_PhysicianReviewRequestForEventInitialSave()
		{
			autoActivityManager.Execute(AutoActivityRuleType.ER2, this.SqlData.Transaction);
		}

		/// <summary>
		/// ER5	- Physician Review for Referral Initial Save
		/// This is triggered when a new physician review is saved for a referral detail.
		/// </summary>
		public void AutoActivity_PhysicianReviewRequestForReferralInitialSave()
		{
			autoActivityManager.Execute(AutoActivityRuleType.ER5, this.SqlData.Transaction);
		}


		/// <summary>
		/// Load the patient related to this physician review and return it.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientID == 0)
				return null;

			Patient patient = new Patient();
			patient.SqlData.Transaction = this.SqlData.Transaction;
			if (patient.Load(patientID))
				return patient;
			else
				return null;

		}

		/// <summary>
		/// Load and cache the patient related to this physician review request.
		/// </summary>
		public Patient Patient
		{
			get 
			{ 
				if (this.patient == null)
					this.patient = GetPatient();
				return this.patient; 
			}
		}
		
		/// <summary>
		/// Load the event related to this physician and return it.
		/// </summary>
		/// <returns></returns>
		public Event GetEvent()
		{
			if (this.parentPhysicianReviewRequestCollection != null)
				if (this.parentPhysicianReviewRequestCollection.ParentEvent != null)
					return this.parentPhysicianReviewRequestCollection.ParentEvent;

			if (this.eventID == 0)
				return null;

			Event eventObj = new Event();
			eventObj.SqlData.Transaction = this.SqlData.Transaction;
			if (eventObj.Load(this.Patient, eventID))
				return eventObj;
			else
				return null;

		}

		/// <summary>
		/// Load the Referral Detail related to this physician and return it.
		/// </summary>
		/// <returns></returns>
		public ReferralDetail GetReferralDetail()
		{
			if (this.referralDetailID == 0)
				return null;

			ReferralDetail refDetail = new ReferralDetail();
			refDetail.SqlData.Transaction = this.SqlData.Transaction;
			if (refDetail.Load(this.referralDetailID))
				return refDetail;
			else
				return null;

		}


		public PhysicianReviewRequestReasonCollection LookupOf_PhysicianReviewRequestReasonID
		{
			get
			{
				return PhysicianReviewRequestReasonCollection.ActivePhysicianReviewRequestReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewDecisionCollection LookupOf_PhysicianReviewDecisionID
		{
			get
			{
				return PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewRequestStatusCollection LookupOf_PhysicianReviewRequestStatusID
		{
			get
			{
				return PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses; // Acquire a shared instance from the static member of collection
			}
		}


		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.StatusCode = SystemStatus.OPEN;
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public string StatusCode
		{
			get { return PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_CodeByPhysicianReviewRequestStatusID(this.physicianReviewRequestStatusID); }
			set { this.physicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(value); }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewRequestStatusID", "PhysicianReviewRequestStatusID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int PhysicianReviewRequestStatusID
		{
			get { return this.physicianReviewRequestStatusID; }
			set { this.physicianReviewRequestStatusID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}


		public static PhysicianReviewRequest CreatePhysicianReviewRequest(Event eventObj, CMS cMS, ClinicalReviewDecision clinicalDecision)
		{
			PhysicianReviewRequest request = new PhysicianReviewRequest(clinicalDecision);
			if (eventObj != null)
			{
				request.EventID = eventObj.EventID;
				request.PatientID = eventObj.PatientId;
				eventObj.LoadPhysicianReviewRequests(false);
				eventObj.PhysicianReviewRequests.Add(request);
			}
			if (cMS != null)
			{
				request.CMSID = cMS.CMSID;
				request.PatientID = cMS.PatientId;
				cMS.LoadPhysicianReviewRequests(false);
				cMS.PhysicianReviewRequests.Add(request);
			}
			return request;
		}

		
		public static PhysicianReviewRequest CreateLOMIDenial(Event eventObj, CMS cMS, ClinicalReviewDecision clinicalDecision)
		{
			PhysicianReviewRequest request = CreatePhysicianReviewRequest(eventObj, cMS, clinicalDecision);
			request.StartDate = DateTime.Now; // Current Date Time
			request.PhysicianReviewRequestReasonID = PhysicianReviewRequestReasonCollection.ActivePhysicianReviewRequestReasons.Lookup_PhysicianReviewRequestReasonIDByCode(PhysicianReviewRequestReason.URREVIEW); // UR Review
			request.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.CLOSED); // Closed
			request.EndDate = DateTime.Now; // Current Date Time
			request.PhysicianReviewDecisionID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.LOMIDenial); // LOMI Denial

			PhysicianReviewRequestDetail detail = new PhysicianReviewRequestDetail(true);

			// Get LOMI Provider info
			int providerLocationID = SystemControlValue.GetInstance.LOMIProviderLocationID;
			if (providerLocationID != 0)
			{
				Location location = new Location();
				location.Load(providerLocationID);
				
				ProviderLocation providerLocation = new ProviderLocation();
				//providerLocation.Load();

				// TODO: There's more
			}
				
			detail.StartDate = request.StartDate;
			detail.PhysicianReviewRequestDetailTypeID = PhysicianReviewRequestDetailTypeCollection.ActivePhysicianReviewRequestDetailTypes.Lookup_PhysicianReviewRequestDetailTypeIDByCode(PhysicianReviewRequestDetailType.LOMI);
			detail.EndDate = request.EndDate;
			detail.PhysicianReviewDecisionID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.LOMIDenial); // LOMI Denial
			detail.PhysicianDecisionReasonID = PhysicianDecisionReasonCollection.ActivePhysicianDecisionReasons.Lookup_PhysicianDecisionReasonIDByCode(PhysicianDecisionReason.LOMI); // LOMI
			detail.PhysicianDecisionRoleID = PhysicianDecisionRoleCollection.ActivePhysicianDecisionRoles.Lookup_PhysicianDecisionRoleIDByCode(PhysicianDecisionRole.NA); // N/A

			request.LoadPhysicianReviewRequestDetails(false);
			request.PhysicianReviewRequestDetails.Add(detail); // Add detail record to the parent request object

			// Save to the database
			request.Save();

			return request;
        }


		public static void ChangeLOMIDenialToRAPP(Event eventObj, CMS cMS, ClinicalReviewDecision clinicalDecision) //, PhysicianReviewRequest request
		{
			PhysicianReviewRequest request = null;
			if (!request.GetLatestPhysicianReviewRequestFromClinicalReviewDecision(clinicalDecision))
				request = CreatePhysicianReviewRequest(eventObj, cMS, clinicalDecision);
					
			request.EndDate = clinicalDecision.ModifyTime; // Get clinical review decision's modify date time
			request.PhysicianReviewDecisionID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.RAPP); // Approved on Reconsideration
			request.ModifiedBy = clinicalDecision.ModifiedBy;
			request.ModifyTime = clinicalDecision.ModifyTime;

			request.LoadPhysicianReviewRequestDetails(false);
            
			if (request.PhysicianReviewRequestDetails.Count > 0)
			{
				PhysicianReviewRequestDetail detail = request.PhysicianReviewRequestDetails[0];
				detail.EndDate = clinicalDecision.ModifyTime; // Get clinical review decision's modify date time
				detail.PhysicianReviewDecisionID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.RAPP); // Approved on Reconsideration
				detail.PhysicianDecisionReasonID = PhysicianDecisionReasonCollection.ActivePhysicianDecisionReasons.Lookup_PhysicianDecisionReasonIDByCode(PhysicianDecisionReason.MEDN); // Medically Necessary
				detail.ModifiedBy = clinicalDecision.ModifiedBy;
				detail.ModifyTime = clinicalDecision.ModifyTime;
			}
			
			// Save to the database
			request.Save();
		}


		public static PhysicianReviewRequest ChangeLOMIDenialToRFPR(Event eventObj, CMS cMS, ClinicalReviewDecision clinicalDecision) //, PhysicianReviewRequest request
		{
			PhysicianReviewRequest request = new PhysicianReviewRequest();
			if (!request.GetLatestPhysicianReviewRequestFromClinicalReviewDecision(clinicalDecision))
				request = CreatePhysicianReviewRequest(eventObj, cMS, clinicalDecision);

			request.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.RECONPENDING); // Reconsideration Pending
			request.EndDate = DateTime.MinValue;
			request.ModifiedBy = clinicalDecision.ModifiedBy;
			request.ModifyTime = clinicalDecision.ModifyTime;
			return request;
		}

		
		public bool GetLatestPhysicianReviewRequestFromClinicalReviewDecision(ClinicalReviewDecision clinicalDecision)
		{
			object request = SqlData.SPExecScalar("usp_GetLatestPhysicianReviewRequestFromClinicalReviewDecision", clinicalDecision.ClinicalReviewDecisionID, false);
			if (request != null)
			{
				return this.Load((int)request);
			}

			return false;
		}

	}

	/// <summary>
	/// Strongly typed collection of PhysicianReviewRequest objects
	/// </summary>
	[ElementType(typeof(PhysicianReviewRequest))]
	public class PhysicianReviewRequestCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		
		private AutoActivityManager autoActivityManager;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianReviewRequest elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianReviewRequestCollection = this;
			else
				elem.ParentPhysicianReviewRequestCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianReviewRequest elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianReviewRequest this[int index]
		{
			get
			{
				return (PhysicianReviewRequest)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianReviewRequest)oldValue, false);
			SetParentOnElem((PhysicianReviewRequest)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Event ParentEvent
		{
			get { return this.ParentDataObject as Event; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}


		public ActiveAdvice.DataLayer.AutoActivityManager AutoActivityManager
		{
			get { return this.autoActivityManager; }
			set { this.autoActivityManager = value; }
		}

		public AutoActivityManager EnsureAutoActivityManager(Patient patient, BaseForEventCMSReferral erc)
		{
			if (this.autoActivityManager == null)
			{
				if (erc.PatientSubscriberLog != null)
					autoActivityManager = new AutoActivityManager(patient, erc.PatientSubscriberLog.PatientCoverage, erc.GetPrimaryProblem(), erc);
			}
			return this.autoActivityManager;
		}

		/// <summary>
		/// Load all physician reviews of the patient.
		/// </summary>
		public int LoadPatientPhysicianReviewRequests(int maxRecords, int patientID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientPhysicianReviewRequests", maxRecords, this, false, new object[] { patientID });
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PhysicianReviewRequest elem)
		{
			return AddRecord(elem);
		}
	}
}
