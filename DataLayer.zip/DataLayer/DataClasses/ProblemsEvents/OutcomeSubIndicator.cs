using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OutcomeSubIndicator]
	/// </summary>
	[SPAutoGen("usp_GetOutcomeSubIndicators","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetOutcomeSubIndicatorsByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetOutcomeSubindicatorsByOutcomeIndicatorID", null, ManuallyManaged=true)]
	[SPInsert("usp_InsertOutcomeSubIndicator")]
	[SPUpdate("usp_UpdateOutcomeSubIndicator")]
	[SPDelete("usp_DeleteOutcomeSubIndicator")]
	[SPLoad("usp_LoadOutcomeSubIndicator")]
	[TableMapping("OutcomeSubIndicator","outcomeSubIndicatorID")]
	public class OutcomeSubIndicator : BaseLookupWithNote
	{
		[NonSerialized]
		private OutcomeSubIndicatorCollection parentOutcomeSubIndicatorCollection;
		[ColumnMapping("OutcomeSubIndicatorID",StereoType=DataStereoType.FK)]
		private int outcomeSubIndicatorID;
		[ColumnMapping("Notepad")]
		private string notepad;
		private OutcomeIndicatorSubIndicatorCollection outcomeIndicatorSubIndicators;
	
		public OutcomeSubIndicator()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public OutcomeSubIndicator(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OutcomeSubIndicatorID
		{
			get { return this.outcomeSubIndicatorID; }
			set { this.outcomeSubIndicatorID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int outcomeSubIndicatorID)
		{
			return base.Load(outcomeSubIndicatorID);
		}

		/// <summary>
		/// Parent OutcomeSubIndicatorCollection that contains this element
		/// </summary>
		public OutcomeSubIndicatorCollection ParentOutcomeSubIndicatorCollection
		{
			get
			{
				return this.parentOutcomeSubIndicatorCollection;
			}
			set
			{
				this.parentOutcomeSubIndicatorCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child OutcomeIndicatorSubIndicators mapped to related rows of table OutcomeIndicatorSubIndicator where [OutcomeSubIndicatorID] = [OutcomeSubIndicatorId]
		/// </summary>
		[SPLoadChild("usp_LoadOutcomeSubIndicatorOutcomeIndicatorSubIndicator", "outcomeSubIndicatorId")]
		public override BaseDataCollectionClass BracketCodeTableChilderen
		{
			get { return this.outcomeIndicatorSubIndicators; }
			set
			{
				this.outcomeIndicatorSubIndicators = (OutcomeIndicatorSubIndicatorCollection)value;
				if (value != null)
					((OutcomeIndicatorSubIndicatorCollection)value).ParentOutcomeSubIndicator = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the OutcomeIndicatorSubIndicators collection
		/// </summary>
		public override void LoadBracketCodeTableChilderen(bool forceReload)
		{
			this.outcomeIndicatorSubIndicators = (OutcomeIndicatorSubIndicatorCollection)OutcomeIndicatorSubIndicatorCollection.LoadChildCollection("BracketCodeTableChilderen", this, typeof(OutcomeIndicatorSubIndicatorCollection), outcomeIndicatorSubIndicators, forceReload, null);
		}

		/// <summary>
		/// Saves the OutcomeIndicatorSubIndicators collection
		/// </summary>
		public override void SaveBracketCodeTableChilderen()
		{
			OutcomeIndicatorSubIndicatorCollection.SaveChildCollection(this.outcomeIndicatorSubIndicators, true);
		}

		/// <summary>
		/// Synchronizes the OutcomeIndicatorSubIndicators collection
		/// </summary>
		public override void SynchronizeBracketCodeTableChilderen()
		{
			OutcomeIndicatorSubIndicatorCollection.SynchronizeChildCollection(this.outcomeIndicatorSubIndicators, true);
		}
	}

	/// <summary>
	/// Strongly typed collection of OutcomeSubIndicator objects
	/// </summary>
	[ElementType(typeof(OutcomeSubIndicator))]
	public class OutcomeSubIndicatorCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_OutcomeSubIndicatorID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OutcomeSubIndicator elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOutcomeSubIndicatorCollection = this;
			else
				elem.ParentOutcomeSubIndicatorCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OutcomeSubIndicator elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OutcomeSubIndicator this[int index]
		{
			get
			{
				return (OutcomeSubIndicator)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OutcomeSubIndicator)oldValue, false);
			SetParentOnElem((OutcomeSubIndicator)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadOutcomeSubIndicatorsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOutcomeSubIndicatorsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared OutcomeSubIndicatorCollection which is cached in NSGlobal
		/// </summary>
		public static OutcomeSubIndicatorCollection ActiveOutcomeSubIndicators
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				OutcomeSubIndicatorCollection col = (OutcomeSubIndicatorCollection)NSGlobal.EnsureCachedObject("ActiveOutcomeSubIndicators", typeof(OutcomeSubIndicatorCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadOutcomeSubIndicatorsByActive(-1, true);
				}
				return col;
			}			
		}
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetOutcomeSubIndicators", -1, this, false);
		}
	
		public override void SynchronizeCollection(BaseTypeCollection col)
		{	
			foreach (OutcomeSubIndicator outcomeSubIndicator in this)
				outcomeSubIndicator.IsMarkedForDeletion=false;

			foreach (OutcomeIndicatorSubIndicator item in (OutcomeIndicatorSubIndicatorCollection)col)
			{
				OutcomeSubIndicator outcomeSubIndicator = this.FindBy(item.OutcomeSubIndicatorId);
				if (outcomeSubIndicator != null && !item.IsMarkedForDeletion)
					outcomeSubIndicator.IsMarkedForDeletion= true;
			}
		}

		/// <summary>
		/// Hashtable based index on outcomeSubIndicatorID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_OutcomeSubIndicatorID
		{
			get
			{
				if (this.indexBy_OutcomeSubIndicatorID == null)
					this.indexBy_OutcomeSubIndicatorID = new CollectionIndexer(this, new string[] { "outcomeSubIndicatorID" }, true);
				return this.indexBy_OutcomeSubIndicatorID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on outcomeSubIndicatorID fields returns the object.  Uses the IndexBy_OutcomeSubIndicatorID indexer.
		/// </summary>
		public OutcomeSubIndicator FindBy(int outcomeSubIndicatorID)
		{
			return (OutcomeSubIndicator)this.IndexBy_OutcomeSubIndicatorID.GetObject(outcomeSubIndicatorID);
		}

		/// <summary>
		/// Load outcome sub-indicators for the given indicator
		/// </summary>
		public int LoadOutcomeSubindicatorsByOutcomeIndicatorID(int outcomeIndicatorID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOutcomeSubindicatorsByOutcomeIndicatorID", -1, this, false, new object[] { outcomeIndicatorID });
		}
	}
}
