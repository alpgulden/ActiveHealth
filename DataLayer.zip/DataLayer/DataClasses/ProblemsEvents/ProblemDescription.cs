using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProblemDescription]
	/// </summary>
	[SPAutoGen("usp_GetAllProblemDescriptions","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetProblemDescriptionsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertProblemDescription")]
	[SPUpdate("usp_UpdateProblemDescription")]
	[SPDelete("usp_DeleteProblemDescription")]
	[SPLoad("usp_LoadProblemDescription")]
	[TableMapping("ProblemDescription","codeId")]
	public class ProblemDescription : BaseLookupWithNote
	{
		#region ProblemDescription code constants

		public const string ICM = "ICM";	// Informed Care Management
		public const string OTHR = "OTHR";	// Other
		public const string UNKN = "UNKN";	// Unknown
		public const string WELL = "WELL";	// Wellness
		public const string EDI = "EDI";	// EDI Review Requests

		#endregion

		[NonSerialized]
		private ProblemDescriptionCollection parentProblemDescriptionCollection;
		[ColumnMapping("CodeId",StereoType=DataStereoType.FK)]
		private int codeId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ProblemDescription()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ProblemDescription(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CodeId
		{
			get { return this.codeId; }
			set { this.codeId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent ProblemDescriptionCollection that contains this element
		/// </summary>
		public ProblemDescriptionCollection ParentProblemDescriptionCollection
		{
			get
			{
				return this.parentProblemDescriptionCollection;
			}
			set
			{
				this.parentProblemDescriptionCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int codeId)
		{
			return base.Load(codeId);
		}
	}

	/// <summary>
	/// Strongly typed collection of ProblemDescription objects
	/// </summary>
	[ElementType(typeof(ProblemDescription))]
	public class ProblemDescriptionCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		[NonSerialized]
		private CollectionIndexer indexBy_CodeId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProblemDescription elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProblemDescriptionCollection = this;
			else
				elem.ParentProblemDescriptionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProblemDescription elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProblemDescription this[int index]
		{
			get
			{
				return (ProblemDescription)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProblemDescription)oldValue, false);
			SetParentOnElem((ProblemDescription)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadProblemDescriptionsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetProblemDescriptionsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ProblemDescriptionCollection which is cached in NSGlobal
		/// </summary>
		public static ProblemDescriptionCollection ActiveProblemDescriptions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ProblemDescriptionCollection col = (ProblemDescriptionCollection)NSGlobal.EnsureCachedObject("ActiveProblemDescriptions", typeof(ProblemDescriptionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadProblemDescriptionsByActive(-1, true);
				}
				return col;
			}
		}

		/// <summary>
		/// Hashtable based index on codeId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_CodeId
		{
			get
			{
				if (this.indexBy_CodeId == null)
					this.indexBy_CodeId = new CollectionIndexer(this, new string[] { "codeId" }, true);
				return this.indexBy_CodeId;
			}
			
		}

		/// <summary>
		/// Looks up by codeId and returns Description value.  Uses the IndexBy_CodeId indexer.
		/// </summary>
		public string Lookup_DescriptionByCodeId(int codeId)
		{
			return this.IndexBy_CodeId.LookupStringMember("Description", codeId);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns CodeId value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_CodeIdByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("CodeId", code);
		}

		/// <summary>
		/// Looks up by codeId and returns Code value.  Uses the IndexBy_CodeId indexer.
		/// </summary>
		public string Lookup_CodeByCodeId(int codeId)
		{
			return this.IndexBy_CodeId.LookupStringMember("Code", codeId);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllProblemDescriptions", -1, this, false);
		}
	}
}
