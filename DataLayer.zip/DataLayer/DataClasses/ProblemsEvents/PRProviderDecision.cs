using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianReviewDecision]
	/// </summary>
	[SPInsert("usp_InsertPRProviderDecision")]
	[SPUpdate("usp_UpdatePRProviderDecision")]
	[SPLoad("usp_LoadPRProviderDecision")]
	[TableMapping("PRProviderDecision","pRProviderDecisionID")]
	public class PRProviderDecision : BaseDataWithUserDefined
	{
		[NonSerialized]
		private PRProviderDecisionCollection parentPRProviderDecisionCollection;
		[ColumnMapping("PRProviderDecisionID",StereoType=DataStereoType.FK)]
		private int pRProviderDecisionID;
		[ColumnMapping("PRReviewID",StereoType=DataStereoType.FK)]
		private int pRReviewID;
		[ColumnMapping("ProviderNetworkID",StereoType=DataStereoType.FK)]
		private int providerNetworkID;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]
		private int providerID;
		[ColumnMapping("ProviderSpecialtyID",StereoType=DataStereoType.FK)]
		private int providerSpecialtyID;
		[ColumnMapping("PhysicianDecisionRoleID",StereoType=DataStereoType.FK)]
		private int physicianDecisionRoleID;
		[ColumnMapping("PhysicianReviewDecisionID",StereoType=DataStereoType.FK)]
		private int physicianReviewDecisionID;
		[ColumnMapping("PhysicianDecisionReasonID",StereoType=DataStereoType.FK)]
		private int physicianDecisionReasonID;
		[ColumnMapping("StartDate")]
		private DateTime startDate = DateTime.Now;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("SpokeToProvider")]
		private bool spokeToProvider = false;
		[ColumnMapping("SpokeToProviderDate")]
		private DateTime spokeToProviderDate;
		[ColumnMapping("ExplainedAppealsProcess")]
		private bool explainedAppealsProcess = false;
		[ColumnMapping("ExplainedAppealsProcessDate")]
		private DateTime explainedAppealsProcessDate;
		[ColumnMapping("MinutesSpent")]
		private int minutesSpent = 0;
		[ColumnMapping("TransactionNumber")]
		private string transactionNumber;
		[ColumnMapping("CheckNumber")]
		private string checkNumber;
		[ColumnMapping("GeneratePayable")]
		private bool generatePayable = false;
		[ColumnMapping("GeneratePayableDate")]
		private DateTime generatePayableDate;
		[ColumnMapping("CheckAmount")]
		private Decimal checkAmount = decimal.MinValue;
		[ColumnMapping("DateGenerated")]
		private DateTime dateGenerated;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("Active")]
		private bool active = true;

		private int oldPhysicianReviewDecisionID;

		private PRReview pRReview;

		public PRReview PRReview
		{
			get 
			{ 
				if (this.pRReviewID != 0)
				{
					PRReview review = new PRReview();
					review.Load(this.pRReviewID);
					return pRReview; 
				}
				return null;
			}
			set { pRReview = value; }
		}

		public PRProviderDecision()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PRProviderDecision(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public PRProviderDecision(bool initNew, bool initDefaultValues) : this(initNew)
		{
			if (initDefaultValues)
			{
				// Default Start Date is Now
				this.StartDate = DateTime.Now;
				this.UseProviderFromContext();
			}
		}

		public void UseProviderFromContext()
		{
			PopulateProviderFields(AASecurityHelper.AAUser.ProviderID, AASecurityHelper.AAUser.ProviderLocationID);
		}

		public void UseLOMIProvider()
		{
			PopulateProviderFields(SystemControlValue.GetInstance.LOMIProviderID, SystemControlValue.GetInstance.LOMIProviderLocationID);
		}

		private void PopulateProviderFields(int providerID, int providerLocationID)
		{
			if (providerID != 0)
			{
				Provider provider = new Provider();
				provider.Load(providerID);
				if (provider.ProviderID != 0)
				{
					this.ProviderID = provider.ProviderID;

					if (provider.PrimarySpecialty != null)
						this.ProviderSpecialtyID = provider.PrimarySpecialty.ProviderSpecialtyID;
				}
					
				if (providerLocationID != 0)
				{
					ProviderLocation providerLocation = new ProviderLocation();
					providerLocation.Load(providerLocationID);

					if (providerLocation.ProviderLocationID != 0)
					{
						this.ProviderLocationID = providerLocation.ProviderLocationID;
					}
				}
			}     
		}

		protected override void InitializeToTrackChanges()
		{
			base.InitializeToTrackChanges ();
			oldPhysicianReviewDecisionID = this.physicianReviewDecisionID;
		}

		
		public bool IsDecisionChanged()
		{
			return (oldPhysicianReviewDecisionID != this.physicianReviewDecisionID);
		}
        

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PRProviderDecisionID
		{
			get { return this.pRProviderDecisionID; }
			set { this.pRProviderDecisionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PRReviewID
		{
			get { return this.pRReviewID; }
			set { this.pRReviewID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderNetworkID
		{
			get { return this.providerNetworkID; }
			set { this.providerNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderSpecialtyID
		{
			get { return this.providerSpecialtyID; }
			set { this.providerSpecialtyID = value; }
		}

		// this is not in the table!!!
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderNetworkStatusID
		{
			get { return 0; }
			set { }
		}


		[FieldValuesMember("LookupOf_PhysicianDecisionRoleID", "PhysicianDecisionRoleID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int PhysicianDecisionRoleID
		{
			get { return this.physicianDecisionRoleID; }
			set { this.physicianDecisionRoleID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewDecisionID", "PhysicianReviewDecisionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@DECISION@")]
		public int PhysicianReviewDecisionID
		{
			get { return this.physicianReviewDecisionID; }
			set { this.physicianReviewDecisionID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianDecisionReasonID", "PhysicianDecisionReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ClientScriptForConditionalRequired="GetElemValue('DecPhysicianReviewDecisionID') != ''", IsRequired=true)]
		[FieldDescription("@DECISIONREASON@")]
		public int PhysicianDecisionReasonID
		{
			get { return this.physicianDecisionReasonID; }
			set { this.physicianDecisionReasonID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime, IsRequired=true)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ValidatorMember("Vld_EndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime, ClientScriptForConditionalRequired="GetElemValue('DecPhysicianReviewDecisionID') != ''", IsRequired=true)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool SpokeToProvider
		{
			get { return this.spokeToProvider; }
			set { this.spokeToProvider = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ExplainedAppealsProcess
		{
			get { return this.explainedAppealsProcess; }
			set { this.explainedAppealsProcess = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MinutesSpent
		{
			get { return this.minutesSpent; }
			set { this.minutesSpent = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string TransactionNumber
		{
			get { return this.transactionNumber; }
			set { this.transactionNumber = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string CheckNumber
		{
			get { return this.checkNumber; }
			set { this.checkNumber = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool GeneratePayable
		{
			get { return this.generatePayable; }
			set { this.generatePayable = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime GeneratePayableDate
		{
			get { return this.generatePayableDate; }
			set { this.generatePayableDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		public decimal CheckAmount
		{
			get { return this.checkAmount; }
			set { this.checkAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DateGenerated
		{
			get { return this.dateGenerated; }
			set { this.dateGenerated = value; }
		}

		[FieldDescription("@PROVIDER@")]
		public string ProviderName
		{
			get 
			{
				return Provider.GetProviderFullNameWithPrefixByID(this.providerID);
			}
		}

		[FieldDescription("@SPECIALTY@")]
		public string SpecialtyName
		{
			get 
			{
				return ProviderSpecialty.GetProviderSpecialtyDescriptionByID(this.providerSpecialtyID);
			}
		}

		[GenericScript("Vld_EndDate", "@EndDate@ >= @StartDate@;")]
		protected string Vld_EndDate
		{
			get
			{
				return "@ERRENDDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
				/*DateTime terminationDate = (DateTime)this.Get("terminationDate");
				DateTime effectiveDate = (DateTime)this.Get("effectiveDate");
				if (terminationDate != DateTime.MinValue && !(terminationDate >= effectiveDate))
					throw new ValidationException("TerminationDate", Vld_TerminationDate);  // throw validation exception if failed (don't set the member) 
					*/

				// Can't validate on the server, because the depended 2 members are not filled yet.
			}
		}




		/// <summary>
		/// Parent PRProviderDecisionCollection that contains this element
		/// </summary>
		public PRProviderDecisionCollection ParentPRProviderDecisionCollection
		{
			get
			{
				return this.parentPRProviderDecisionCollection;
			}
			set
			{
				this.parentPRProviderDecisionCollection = value; // parent is set when added to a collection
			}
		}


		[ControlType(Macro=EnumControlTypeMacros.ShortDate, ClientScriptForConditionalRequired="GetElem('SpokeToProvider').checked", IsRequired=true)]
		[FieldDescription("@SPOKETOPROVIDERDATE@")]
		public System.DateTime SpokeToProviderDate
		{
			get { return this.spokeToProviderDate; }
			set { this.spokeToProviderDate = value; }
		}
		[ControlType(Macro=EnumControlTypeMacros.ShortDate, ClientScriptForConditionalRequired="GetElem('ExplainedAppealsProcess').checked", IsRequired=true)]
		[FieldDescription("@EXPLAINEDAPPEALSPROCESSDATE@")]
		public System.DateTime ExplainedAppealsProcessDate
		{
			get { return this.explainedAppealsProcessDate; }
			set { this.explainedAppealsProcessDate = value; }
		}

		public PhysicianDecisionRoleCollection LookupOf_PhysicianDecisionRoleID
		{
			get
			{
				return PhysicianDecisionRoleCollection.ActivePhysicianDecisionRoles; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewDecisionCollection LookupOf_PhysicianReviewDecisionID
		{
			get
			{
				return PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianDecisionReasonCollection LookupOf_PhysicianDecisionReasonID
		{
			get
			{
				return PhysicianDecisionReasonCollection.ActivePhysicianDecisionReasons; // Acquire a shared instance from the static member of collection
			}
		}



		public bool CheckProvider()
		{
			int denialID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.DENIAL);

			PRProviderDecisionCollection col = this.parentPRProviderDecisionCollection;
			if (col != null && col.Count > 1)
			{
				foreach (PRProviderDecision decision in col)
				{
					if (decision == this) continue;
					
					if (decision.PhysicianReviewDecisionID == denialID && decision.ProviderID == this.ProviderID)
						return false;
				}
			}

			return true;    
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int pRProviderDecisionID)
		{
			return base.Load(pRProviderDecisionID);
		}

		
		#region PRReview Fields

		[FieldValuesMember("LookupOf_PhysicianReviewRequestDetailTypeID", "PhysicianReviewRequestDetailTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int PhysicianReviewRequestDetailTypeID
		{
			get 
			{ 
				if (this.parentPRProviderDecisionCollection != null && this.parentPRProviderDecisionCollection.ParentPRReview != null)
					return this.parentPRProviderDecisionCollection.ParentPRReview.PhysicianReviewRequestDetailTypeID; 
				else
					return 0;
			}
			set
			{
			}
		}


		public PhysicianReviewRequestDetailTypeCollection LookupOf_PhysicianReviewRequestDetailTypeID
		{
			get
			{
				return PhysicianReviewRequestDetailTypeCollection.ActivePhysicianReviewRequestDetailTypes; // Acquire a shared instance from the static member of collection
			}
		}

		#endregion

	}

	/// <summary>
	/// Strongly typed collection of PRProviderDecision objects
	/// </summary>
	[ElementType(typeof(PRProviderDecision))]
	public class PRProviderDecisionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass, ICollectionElementFilter
	{

		private string activeFilter = "";
		public string ActiveFilter
		{
			get { return this.activeFilter; }
			set { this.activeFilter = value; }
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PRProviderDecision elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPRProviderDecisionCollection = this;
			else
				elem.ParentPRProviderDecisionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PRProviderDecision elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PRProviderDecision this[int index]
		{
			get
			{
				return (PRProviderDecision)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PRProviderDecision)oldValue, false);
			SetParentOnElem((PRProviderDecision)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}


		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PRProviderDecision elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Parent PRReview that contains this collection
		/// </summary>
		public PRReview ParentPRReview
		{
			get { return this.ParentDataObject as PRReview; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PRReview */ }
		}

		#region ICollectionElementFilter Members

		public bool FilterElement(int index)
		{
			return (activeFilter == "" || (activeFilter == "1" && this[index].Active) || (activeFilter == "0" && !this[index].Active));
		}

		#endregion
	}

}
