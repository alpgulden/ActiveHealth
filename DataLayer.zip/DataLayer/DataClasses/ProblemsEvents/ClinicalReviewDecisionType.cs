using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ClinicalReviewDecisionType]
	/// </summary>
	[SPAutoGen("usp_GetClinicalReviewDecisionTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetClinicalReviewDecisionTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertClinicalReviewDecisionType")]
	[SPUpdate("usp_UpdateClinicalReviewDecisionType")]
	[SPDelete("usp_DeleteClinicalReviewDecisionType")]
	[SPLoad("usp_LoadClinicalReviewDecisionType")]
	[TableMapping("ClinicalReviewDecisionType","clinicalReviewDecisionTypeID")]
	public class ClinicalReviewDecisionType : BaseLookupWithSubCode
	{
		#region Clinical Review Decision Type Constants for programmatic use

		public const string DENIED = "DENY";
		public const string RFPR = "RFPR";
		public const string NOTI = "NOTI";
		public const string RAPP = "RAPP";
		public const string TRAK = "TRAK";
		public const string APPR = "APPR";

		#endregion

		[NonSerialized]
		private ClinicalReviewDecisionTypeCollection parentClinicalReviewDecisionTypeCollection;
		[ColumnMapping("ClinicalReviewDecisionTypeID",StereoType=DataStereoType.FK)]
		private int clinicalReviewDecisionTypeID;
		[ColumnMapping("ClinicalReviewDecisionTypeCodeID")]
		private int clinicalReviewDecisionTypeCodeID;
		[ColumnMapping("Notepad")]
		private string notepad;

		
	
		public ClinicalReviewDecisionType()
		{
		}

		public ClinicalReviewDecisionType(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ClinicalReviewDecisionTypeID
		{
			get { return this.clinicalReviewDecisionTypeID; }
			set { this.clinicalReviewDecisionTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ClinicalReviewDecisionTypeCodeID
		{
			get { return this.clinicalReviewDecisionTypeCodeID; }
			set { this.clinicalReviewDecisionTypeCodeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldValuesMember("LookupOf_SubCodeID", "ClinicalReviewDecisionTypeCodeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CLINICALREVIEWDECISIONTYPE@")]
		public override int SubCodeID
		{
			get { return this.clinicalReviewDecisionTypeCodeID; }
			set { this.clinicalReviewDecisionTypeCodeID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int clinicalReviewDecisionTypeID)
		{
			return base.Load(clinicalReviewDecisionTypeID);
		}

		/// <summary>
		/// Parent ClinicalReviewDecisionTypeCollection that contains this element
		/// </summary>
		public ClinicalReviewDecisionTypeCollection ParentClinicalReviewDecisionTypeCollection
		{
			get
			{
				return this.parentClinicalReviewDecisionTypeCollection;
			}
			set
			{
				this.parentClinicalReviewDecisionTypeCollection = value; // parent is set when added to a collection
			}
		}

		public ClinicalReviewDecisionTypeCodeCollection LookupOf_SubCodeID
		{
			get
			{
				return ClinicalReviewDecisionTypeCodeCollection.ActiveClinicalReviewDecisionTypeCodes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ClinicalReviewDecisionType objects
	/// </summary>
	[ElementType(typeof(ClinicalReviewDecisionType))]
	public class ClinicalReviewDecisionTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		[NonSerialized]
		private CollectionIndexer indexBy_ClinicalReviewDecisionTypeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClinicalReviewDecisionType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClinicalReviewDecisionTypeCollection = this;
			else
				elem.ParentClinicalReviewDecisionTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClinicalReviewDecisionType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClinicalReviewDecisionType this[int index]
		{
			get
			{
				return (ClinicalReviewDecisionType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClinicalReviewDecisionType)oldValue, false);
			SetParentOnElem((ClinicalReviewDecisionType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadClinicalReviewDecisionTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetClinicalReviewDecisionTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ClinicalReviewDecisionTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ClinicalReviewDecisionTypeCollection ActiveClinicalReviewDecisionTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ClinicalReviewDecisionTypeCollection col = (ClinicalReviewDecisionTypeCollection)NSGlobal.EnsureCachedObject("ActiveClinicalReviewDecisionTypes", typeof(ClinicalReviewDecisionTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadClinicalReviewDecisionTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on clinicalReviewDecisionTypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ClinicalReviewDecisionTypeID
		{
			get
			{
				if (this.indexBy_ClinicalReviewDecisionTypeID == null)
					this.indexBy_ClinicalReviewDecisionTypeID = new CollectionIndexer(this, new string[] { "clinicalReviewDecisionTypeID" }, true);
				return this.indexBy_ClinicalReviewDecisionTypeID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on clinicalReviewDecisionTypeID fields returns the object.  Uses the IndexBy_ClinicalReviewDecisionTypeID indexer.
		/// </summary>
		public ClinicalReviewDecisionType FindBy(int clinicalReviewDecisionTypeID)
		{
			return (ClinicalReviewDecisionType)this.IndexBy_ClinicalReviewDecisionTypeID.GetObject(clinicalReviewDecisionTypeID);
		}

		/// <summary>
		/// Looks up by clinicalReviewDecisionTypeID and returns Code value.  Uses the IndexBy_ClinicalReviewDecisionTypeID indexer.
		/// </summary>
		public string Lookup_CodeByClinicalReviewDecisionTypeID(int clinicalReviewDecisionTypeID)
		{
			return this.IndexBy_ClinicalReviewDecisionTypeID.LookupStringMember("Code", clinicalReviewDecisionTypeID);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns ClinicalReviewDecisionTypeID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_ClinicalReviewDecisionTypeIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("ClinicalReviewDecisionTypeID", code);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetClinicalReviewDecisionTypes", -1, this, false);
		}	
	}
}
