using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ClinicalReviewDecisionReason]
	/// </summary>
	[SPAutoGen("usp_GetClinicalReviewDecisionReasons","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetClinicalReviewDecisionReasonsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertClinicalReviewDecisionReason")]
	[SPUpdate("usp_UpdateClinicalReviewDecisionReason")]
	[SPDelete("usp_DeleteClinicalReviewDecisionReason")]
	[SPLoad("usp_LoadClinicalReviewDecisionReason")]
	[TableMapping("ClinicalReviewDecisionReason","clinicalReviewDecisionReasonID")]
	public class ClinicalReviewDecisionReason : BaseLookupWithNote
	{

		#region Clinical Review Decision Type Constants for programmatic use

		public const string LOMI = "LOMI";

		#endregion

		[NonSerialized]
		private ClinicalReviewDecisionReasonCollection parentClinicalReviewDecisionReasonCollection;
		[ColumnMapping("ClinicalReviewDecisionReasonID",StereoType=DataStereoType.FK)]
		private int clinicalReviewDecisionReasonID;
		[ColumnMapping("Notepad")]
		private string notepad;
		
		public ClinicalReviewDecisionReason()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ClinicalReviewDecisionReason(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ClinicalReviewDecisionReasonID
		{
			get { return this.clinicalReviewDecisionReasonID; }
			set { this.clinicalReviewDecisionReasonID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int clinicalReviewDecisionReasonID)
		{
			return base.Load(clinicalReviewDecisionReasonID);
		}

		/// <summary>
		/// Parent ClinicalReviewDecisionReasonCollection that contains this element
		/// </summary>
		public ClinicalReviewDecisionReasonCollection ParentClinicalReviewDecisionReasonCollection
		{
			get
			{
				return this.parentClinicalReviewDecisionReasonCollection;
			}
			set
			{
				this.parentClinicalReviewDecisionReasonCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ClinicalReviewDecisionReason objects
	/// </summary>
	[ElementType(typeof(ClinicalReviewDecisionReason))]
	public class ClinicalReviewDecisionReasonCollection : BaseTypeCollection
	{

		[NonSerialized]
		private CollectionIndexer indexBy_ClinicalReviewDecisionReasonID;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClinicalReviewDecisionReason elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClinicalReviewDecisionReasonCollection = this;
			else
				elem.ParentClinicalReviewDecisionReasonCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClinicalReviewDecisionReason elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClinicalReviewDecisionReason this[int index]
		{
			get
			{
				return (ClinicalReviewDecisionReason)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		/// <summary>
		/// Hashtable based index on clinicalReviewDecisionTypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ClinicalReviewDecisionReasonID
		{
			get
			{
				if (this.indexBy_ClinicalReviewDecisionReasonID == null)
					this.indexBy_ClinicalReviewDecisionReasonID = new CollectionIndexer(this, new string[] { "clinicalReviewDecisionReasonID" }, true);
				return this.indexBy_ClinicalReviewDecisionReasonID;
			}			
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClinicalReviewDecisionReason)oldValue, false);
			SetParentOnElem((ClinicalReviewDecisionReason)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadClinicalReviewDecisionReasonsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetClinicalReviewDecisionReasonsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ClinicalReviewDecisionReasonCollection which is cached in NSGlobal
		/// </summary>
		public static ClinicalReviewDecisionReasonCollection ActiveClinicalReviewDecisionReasons
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ClinicalReviewDecisionReasonCollection col = (ClinicalReviewDecisionReasonCollection)NSGlobal.EnsureCachedObject("ActiveClinicalReviewDecisionReasons", typeof(ClinicalReviewDecisionReasonCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadClinicalReviewDecisionReasonsByActive(-1, true);
				}
				return col;
			}			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetClinicalReviewDecisionReasons", -1, this, false);
		}	

		/// <summary>
		/// Looks up by clinicalReviewDecisionReasonID and returns Code value.  Uses the IndexBy_ClinicalReviewDecisionReasonID indexer.
		/// </summary>
		public string Lookup_CodeByClinicalReviewReasonID(int clinicalReviewDecisionReasonID)
		{
			return this.IndexBy_ClinicalReviewDecisionReasonID.LookupStringMember("Code", clinicalReviewDecisionReasonID);
		}
	}
}
