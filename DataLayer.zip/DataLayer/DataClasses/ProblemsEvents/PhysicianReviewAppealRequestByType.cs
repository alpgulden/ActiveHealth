using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianReviewAppealRequestByType]
	/// </summary>
	[SPAutoGen("usp_GetPhysicianReviewAppealRequestByTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetPhysicianReviewAppealRequestByTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertPhysicianReviewAppealRequestByType")]
	[SPUpdate("usp_UpdatePhysicianReviewAppealRequestByType")]
	[SPDelete("usp_DeletePhysicianReviewAppealRequestByType")]
	[SPLoad("usp_LoadPhysicianReviewAppealRequestByType")]
	[TableMapping("PhysicianReviewAppealRequestByType","physicianReviewAppealRequestByTypeID")]
	public class PhysicianReviewAppealRequestByType : BaseLookupWithNote
	{
		[NonSerialized]
		private PhysicianReviewAppealRequestByTypeCollection parentPhysicianReviewAppealRequestByTypeCollection;
		[ColumnMapping("PhysicianReviewAppealRequestByTypeID",StereoType=DataStereoType.FK)]
		private int physicianReviewAppealRequestByTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public PhysicianReviewAppealRequestByType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianReviewAppealRequestByType(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PhysicianReviewAppealRequestByTypeID
		{
			get { return this.physicianReviewAppealRequestByTypeID; }
			set { this.physicianReviewAppealRequestByTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int physicianReviewAppealRequestByTypeID)
		{
			return base.Load(physicianReviewAppealRequestByTypeID);
		}

		/// <summary>
		/// Parent PhysicianReviewAppealRequestByTypeCollection that contains this element
		/// </summary>
		public PhysicianReviewAppealRequestByTypeCollection ParentPhysicianReviewAppealRequestByTypeCollection
		{
			get
			{
				return this.parentPhysicianReviewAppealRequestByTypeCollection;
			}
			set
			{
				this.parentPhysicianReviewAppealRequestByTypeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PhysicianReviewAppealRequestByType objects
	/// </summary>
	[ElementType(typeof(PhysicianReviewAppealRequestByType))]
	public class PhysicianReviewAppealRequestByTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianReviewAppealRequestByType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianReviewAppealRequestByTypeCollection = this;
			else
				elem.ParentPhysicianReviewAppealRequestByTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianReviewAppealRequestByType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianReviewAppealRequestByType this[int index]
		{
			get
			{
				return (PhysicianReviewAppealRequestByType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianReviewAppealRequestByType)oldValue, false);
			SetParentOnElem((PhysicianReviewAppealRequestByType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPhysicianReviewAppealRequestByTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPhysicianReviewAppealRequestByTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PhysicianReviewAppealRequestByTypeCollection which is cached in NSGlobal
		/// </summary>
		public static PhysicianReviewAppealRequestByTypeCollection ActivePhysicianReviewAppealRequestByTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PhysicianReviewAppealRequestByTypeCollection col = (PhysicianReviewAppealRequestByTypeCollection)NSGlobal.EnsureCachedObject("ActivePhysicianReviewAppealRequestByTypes", typeof(PhysicianReviewAppealRequestByTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPhysicianReviewAppealRequestByTypesByActive(-1, true);
				}
				return col;
			}			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetPhysicianReviewAppealRequestByTypes", -1, this, false);
		}
	}
}
