using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OutcomeRisk]
	/// </summary>
	[SPAutoGen("usp_GetOutcomeRisks","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetOutcomeRisksByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertOutcomeRisk")]
	[SPUpdate("usp_UpdateOutcomeRisk")]
	[SPDelete("usp_DeleteOutcomeRisk")]
	[SPLoad("usp_LoadOutcomeRisk")]
	[TableMapping("OutcomeRisk","outcomeRiskID")]
	public class OutcomeRisk : BaseLookupWithNote
	{
		[NonSerialized]
		private OutcomeRiskCollection parentOutcomeRiskCollection;
		[ColumnMapping("OutcomeRiskID",StereoType=DataStereoType.FK)]
		private int outcomeRiskID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public OutcomeRisk()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public OutcomeRisk(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OutcomeRiskID
		{
			get { return this.outcomeRiskID; }
			set { this.outcomeRiskID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int outcomeRiskID)
		{
			return base.Load(outcomeRiskID);
		}

		/// <summary>
		/// Parent OutcomeRiskCollection that contains this element
		/// </summary>
		public OutcomeRiskCollection ParentOutcomeRiskCollection
		{
			get
			{
				return this.parentOutcomeRiskCollection;
			}
			set
			{
				this.parentOutcomeRiskCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of OutcomeRisk objects
	/// </summary>
	[ElementType(typeof(OutcomeRisk))]
	public class OutcomeRiskCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OutcomeRisk elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOutcomeRiskCollection = this;
			else
				elem.ParentOutcomeRiskCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OutcomeRisk elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OutcomeRisk this[int index]
		{
			get
			{
				return (OutcomeRisk)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OutcomeRisk)oldValue, false);
			SetParentOnElem((OutcomeRisk)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadOutcomeRisksByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOutcomeRisksByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared OutcomeRiskCollection which is cached in NSGlobal
		/// </summary>
		public static OutcomeRiskCollection ActiveOutcomeRisks
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				OutcomeRiskCollection col = (OutcomeRiskCollection)NSGlobal.EnsureCachedObject("ActiveOutcomeRisks", typeof(OutcomeRiskCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadOutcomeRisksByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
