using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OutcomeIndicatorSubIndicator]
	/// </summary>
	[SPAutoGen("usp_GetOutcomeIndicatorSubIndicatorByOutcomSubIndicatorId","SelectAllByGivenArgs.sptpl","outcomeSubIndicatorId")]
	[SPAutoGen("usp_GetOutcomeIndicatorSubIndicatorByOutcomeIndicatorId","SelectAllByGivenArgs.sptpl","outcomeIndicatorId")]
	[SPAutoGen("usp_GetAllOutcomeIndicatorSubIndicator","SelectAll.sptpl","")]
	[SPInsert("usp_InsertOutcomeIndicatorSubIndicator")]
	[SPUpdate("usp_UpdateOutcomeIndicatorSubIndicator")]
	[SPDelete("usp_DeleteOutcomeIndicatorSubIndicator")]
	[SPLoad("usp_LoadOutcomeIndicatorSubIndicator")]
	[TableMapping("OutcomeIndicatorSubIndicator","outcomeIndicatorSubIndicatorId")]
	public class OutcomeIndicatorSubIndicator : BaseCodeBracket
	{
		[NonSerialized]
		private OutcomeIndicatorSubIndicatorCollection parentOutcomeIndicatorSubIndicatorCollection;
		[ColumnMapping("OutcomeIndicatorSubIndicatorId",StereoType=DataStereoType.FK)]
		private int outcomeIndicatorSubIndicatorId;
		[ColumnMapping("OutcomeIndicatorId")]
		private int outcomeIndicatorId;
		[ColumnMapping("OutcomeSubIndicatorId")]
		private int outcomeSubIndicatorId;

		private OutcomeIndicator parentOutcomeIndicator;
		private OutcomeSubIndicator parentOutcomeSubIndicator;
	
		public OutcomeIndicatorSubIndicator()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public OutcomeIndicatorSubIndicator(int outcomeIndicatorId, int outcomeSubIndicatorId)
		{
			this.NewRecord(); // initialize record state
			this.outcomeIndicatorId = outcomeIndicatorId;
			this.outcomeSubIndicatorId = outcomeSubIndicatorId;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OutcomeIndicatorSubIndicatorId
		{
			get { return this.outcomeIndicatorSubIndicatorId; }
			set { this.outcomeIndicatorSubIndicatorId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OutcomeIndicatorId
		{
			get { return this.outcomeIndicatorId; }
			set { this.outcomeIndicatorId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OutcomeSubIndicatorId
		{
			get { return this.outcomeSubIndicatorId; }
			set { this.outcomeSubIndicatorId = value; }
		}

		[FieldDescription("@OUTCOMEINDICATORID@")]
		public override int CodeTypeID
		{
			get { return this.outcomeIndicatorId; }
			set { this.outcomeIndicatorId = value; }
		}

		[FieldDescription("@OUTCOMESUBINDICATORID@")]
		public override int LinkedCodeTypeID
		{
			get { return this.outcomeSubIndicatorId; }
			set { this.outcomeSubIndicatorId = value; }
		}

		[FieldDescription("@OUTCOMEINDICATORCODE@")]
		public override string Code1
		{
			get 
			{ 
				if(this.ParentOutcomeIndicator!=null)
					return this.parentOutcomeIndicator.Code;
				else
					return null;
			}
		}

		[FieldDescription("@OUTCOMESUBINDICATORCODE@")]
		public override string Code2
		{
			get 
			{
				if(this.ParentOutcomeSubIndicator!=null)
					return this.parentOutcomeSubIndicator.Code;
				else
					return null;
			}			
		}
		[FieldDescription("@OUTCOMEINDICATORDESCRIPTION@")]
		public override string Description1
		{
			get 
			{
				if(this.ParentOutcomeIndicator!=null)
					return this.parentOutcomeIndicator.Description;
				else
					return null;
			}			
		}

		[FieldDescription("@OUTCOMESUBINDICATORDESCRIPTION@")]
		public override string Description2
		{
			get 
			{
				if(this.ParentOutcomeSubIndicator!=null)
					return this.parentOutcomeSubIndicator.Description;
				else
					return null;
			}			
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int outcomeIndicatorSubIndicatorId)
		{
			return base.Load(outcomeIndicatorSubIndicatorId);
		}

		/// <summary>
		/// Parent OutcomeIndicatorSubIndicatorCollection that contains this element
		/// </summary>
		public OutcomeIndicatorSubIndicatorCollection ParentOutcomeIndicatorSubIndicatorCollection
		{
			get
			{
				return this.parentOutcomeIndicatorSubIndicatorCollection;
			}
			set
			{
				this.parentOutcomeIndicatorSubIndicatorCollection = value; // parent is set when added to a collection
			}
		}

		public OutcomeIndicator ParentOutcomeIndicator
		{
			get 
			{ 
				if (this.parentOutcomeIndicator == null)
					this.parentOutcomeIndicator = GetOutcomeIndicator();
				return this.parentOutcomeIndicator;
			}
		}

		public OutcomeIndicator GetOutcomeIndicator()
		{
			if (this.outcomeIndicatorId == 0)
				return null;
			else
			{
				OutcomeIndicator a = new OutcomeIndicator();
				if (a.Load(this.outcomeIndicatorId))
					return a;
				else
					return null;
			}
		}


		public OutcomeSubIndicator ParentOutcomeSubIndicator
		{
			get 
			{ 
				if (this.parentOutcomeSubIndicator == null)
					this.parentOutcomeSubIndicator= GetOutcomeSubIndicator();
				return this.parentOutcomeSubIndicator;
			}
		}

		public OutcomeSubIndicator GetOutcomeSubIndicator()
		{
			if (this.outcomeSubIndicatorId == 0)
				return null;
			else
			{
				OutcomeSubIndicator a = new OutcomeSubIndicator();
				if (a.Load(this.outcomeSubIndicatorId))
					return a;
				else
					return null;
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of OutcomeIndicatorSubIndicator objects
	/// </summary>
	[ElementType(typeof(OutcomeIndicatorSubIndicator))]
	public class OutcomeIndicatorSubIndicatorCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_OutcomeIndicatorId_OutcomeSubIndicatorId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OutcomeIndicatorSubIndicator elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOutcomeIndicatorSubIndicatorCollection = this;
			else
				elem.ParentOutcomeIndicatorSubIndicatorCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OutcomeIndicatorSubIndicator elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OutcomeIndicatorSubIndicator this[int index]
		{
			get
			{
				return (OutcomeIndicatorSubIndicator)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OutcomeIndicatorSubIndicator)oldValue, false);
			SetParentOnElem((OutcomeIndicatorSubIndicator)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Hashtable based index on outcomeIndicatorId, outcomeSubIndicatorId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_OutcomeIndicatorId_OutcomeSubIndicatorId
		{
			get
			{
				if (this.indexBy_OutcomeIndicatorId_OutcomeSubIndicatorId == null)
					this.indexBy_OutcomeIndicatorId_OutcomeSubIndicatorId = new CollectionIndexer(this, new string[] { "outcomeIndicatorId", "outcomeSubIndicatorId" }, true);
				return this.indexBy_OutcomeIndicatorId_OutcomeSubIndicatorId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on outcomeIndicatorId, outcomeSubIndicatorId fields returns the collection index.  Uses the IndexBy_OutcomeIndicatorId_OutcomeSubIndicatorId indexer.
		/// </summary>
		public int IndexOf(int outcomeIndicatorId, int outcomeSubIndicatorId)
		{
			return this.IndexBy_OutcomeIndicatorId_OutcomeSubIndicatorId.IndexOf(outcomeIndicatorId, outcomeSubIndicatorId);
		}

		/// <summary>
		/// Hashtable based search on outcomeIndicatorId, outcomeSubIndicatorId fields returns the object.  Uses the IndexBy_OutcomeIndicatorId_OutcomeSubIndicatorId indexer.
		/// </summary>
		public OutcomeIndicatorSubIndicator FindBy(int outcomeIndicatorId, int outcomeSubIndicatorId)
		{
			return (OutcomeIndicatorSubIndicator)this.IndexBy_OutcomeIndicatorId_OutcomeSubIndicatorId.GetObject(outcomeIndicatorId, outcomeSubIndicatorId);
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Parent OutcomeIndicator that contains this collection
		/// </summary>
		public OutcomeIndicator ParentOutcomeIndicator
		{
			get { return this.ParentDataObject as OutcomeIndicator; }
			set { this.ParentDataObject = value; /* parent is set when contained by a OutcomeIndicator */ }
		}

		/// <summary>
		/// Parent OutcomeIndicatorSubIndicator that contains this collection
		/// </summary>
		public OutcomeIndicatorSubIndicator ParentOutcomeIndicatorSubIndicator
		{
			get { return this.ParentDataObject as OutcomeIndicatorSubIndicator; }
			set { this.ParentDataObject = value; /* parent is set when contained by a OutcomeIndicatorSubIndicator */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllOutcomeIndicatorSubIndicator(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllOutcomeIndicatorSubIndicator", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadOutcomeIndicatorSubIndicatorByOutcomeIndicatorId(int maxRecords, int outcomeIndicatorId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOutcomeIndicatorSubIndicatorByOutcomeIndicatorId", maxRecords, this, false, new object[] { outcomeIndicatorId });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadOutcomeIndicatorSubIndicatorByOutcomSubIndicatorId(int maxRecords, int outcomeSubIndicatorId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOutcomeIndicatorSubIndicatorByOutcomSubIndicatorId", maxRecords, this, false, new object[] { outcomeSubIndicatorId });
		}

		/// <summary>
		/// Parent OutcomeSubIndicator that contains this collection
		/// </summary>
		public OutcomeSubIndicator ParentOutcomeSubIndicator
		{
			get { return this.ParentDataObject as OutcomeSubIndicator; }
			set { this.ParentDataObject = value; /* parent is set when contained by a OutcomeSubIndicator */ }
		}

		public void MyMarkDel(OutcomeIndicatorSubIndicator obj)
		{			
			obj.MarkDel();
			IndexBy_OutcomeIndicatorId_OutcomeSubIndicatorId.Rebuild();
		}
	}
}
