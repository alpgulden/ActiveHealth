using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Outcome]
	/// </summary>
	[SPInsert("usp_InsertOutcome")]
	[SPUpdate("usp_UpdateOutcome")]
	[SPDelete("usp_DeleteOutcome")]
	[SPLoad("usp_LoadOutcome")]
	[TableMapping("Outcome","outcomeID")]
	public class Outcome : BaseDataWithUserDefined
	{
		[NonSerialized]
		private OutcomeCollection parentOutcomeCollection;
		[ColumnMapping("OutcomeID",StereoType=DataStereoType.FK)]
		private int outcomeID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("Type",StereoType=DataStereoType.FK)]								// lookup
		private int type;
		[ColumnMapping("OutcomeIndicatorID",StereoType=DataStereoType.FK)]				// lookup
		private int outcomeIndicatorID;
		[ColumnMapping("Subindicator",StereoType=DataStereoType.FK)]						// lookup
		private int subindicator;
		[ColumnMapping("OutcomeCodeID",StereoType=DataStereoType.FK)]					// lookup
		private int outcomeCodeID;
		[ColumnMapping("OutcomeDate")]
		private DateTime outcomeDate;
		[ColumnMapping("ResultFrom",StereoType=DataStereoType.FK)]						// lookup
		private int resultFrom;
		[ColumnMapping("Comment")]
		private string comment;
		[ColumnMapping("OutcomeReasonID",StereoType=DataStereoType.FK)]					// lookup
		private int outcomeReasonID;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		private int patientId;
		[ColumnMapping("ProblemId",StereoType=DataStereoType.FK)]
		private int problemId;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("OutcomeRiskID",StereoType=DataStereoType.FK)]			// lookup
		private int outcomeRiskID;
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		private int referralID;	
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		
	
		public Outcome()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Outcome(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OutcomeID
		{
			get { return this.outcomeID; }
			set { this.outcomeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[FieldValuesMember("LookupOf_Type", "OutcomeTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int Type
		{
			get { return this.type; }
			set { this.type = value; }
		}

		[FieldValuesMember("LookupOf_OutcomeIndicatorID", "OutcomeIndicatorID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int OutcomeIndicatorID
		{
			get { return this.outcomeIndicatorID; }
			set { this.outcomeIndicatorID = value; }
		}

		[FieldValuesMember("LookupOf_Subindicator", "OutcomeSubIndicatorID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int Subindicator
		{
			get { return this.subindicator; }
			set { this.subindicator = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime OutcomeDate
		{
			get { return this.outcomeDate; }
			set { this.outcomeDate = value; }
		}

		[FieldValuesMember("LookupOf_ResultFrom", "OutcomeResultFromID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ResultFrom
		{
			get { return this.resultFrom; }
			set { this.resultFrom = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Comment
		{
			get { return this.comment; }
			set { this.comment = value; }
		}

		[FieldValuesMember("LookupOf_OutcomeReasonID", "OutcomeReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int OutcomeReasonID
		{
			get { return this.outcomeReasonID; }
			set { this.outcomeReasonID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProblemId
		{
			get { return this.problemId; }
			set { this.problemId = value; }
		}

		[FieldValuesMember("LookupOf_OutcomeRiskID", "OutcomeRiskID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int OutcomeRiskID
		{
			get { return this.outcomeRiskID; }
			set { this.outcomeRiskID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		

		/// <summary>
		/// Parent OutcomeCollection that contains this element
		/// </summary>
		public OutcomeCollection ParentOutcomeCollection
		{
			get
			{
				return this.parentOutcomeCollection;
			}
			set
			{
				this.parentOutcomeCollection = value; // parent is set when added to a collection
			}
		}

		[FieldValuesMember("LookupOf_OutcomeCodeID", "OutcomeCodeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int OutcomeCodeID
		{
			get { return this.outcomeCodeID; }
			set { this.outcomeCodeID = value; }
		}

		public OutcomeTypeCollection LookupOf_Type
		{
			get
			{
				return OutcomeTypeCollection.ActiveOutcomeTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int outcomeID)
		{
			return base.Load(outcomeID);
		}

		public OutcomeIndicatorCollection LookupOf_OutcomeIndicatorID
		{
			get
			{
				if (this.type == 0)
					return OutcomeIndicatorCollection.ActiveOutcomeIndicators; // Acquire a shared instance from the static member of collection
				else
				{
					// load the indicators related to outcome type.
					OutcomeIndicatorCollection indicators = new OutcomeIndicatorCollection();
					indicators.LoadOutcomeIndicatorsByOutcomeType(this.type);
					return indicators;
				}
			}
		}

		public OutcomeSubIndicatorCollection LookupOf_Subindicator
		{
			get
			{
				if (this.type == 0)
					return OutcomeSubIndicatorCollection.ActiveOutcomeSubIndicators; // Acquire a shared instance from the static member of collection
				else
				{
					// load the indicators related to outcome type.
					OutcomeSubIndicatorCollection subindicators = new OutcomeSubIndicatorCollection();
					subindicators.LoadOutcomeSubindicatorsByOutcomeIndicatorID(this.OutcomeIndicatorID);
					return subindicators;
				}
			}
		}

		public OutcomeCodeCollection LookupOf_OutcomeCodeID
		{
			get
			{
				return OutcomeCodeCollection.ActiveOutcomeCodes; // Acquire a shared instance from the static member of collection
			}
		}

		public OutcomeResultFromCollection LookupOf_ResultFrom
		{
			get
			{
				return OutcomeResultFromCollection.ActiveOutcomeResultFroms; // Acquire a shared instance from the static member of collection
			}
		}

		public OutcomeReasonCollection LookupOf_OutcomeReasonID
		{
			get
			{
				return OutcomeReasonCollection.ActiveOutcomeReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public OutcomeRiskCollection LookupOf_OutcomeRiskID
		{
			get
			{
				return OutcomeRiskCollection.ActiveOutcomeRisks; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of Outcome objects
	/// </summary>
	[ElementType(typeof(Outcome))]
	public class OutcomeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Outcome elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOutcomeCollection = this;
			else
				elem.ParentOutcomeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Outcome elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Outcome this[int index]
		{
			get
			{
				return (Outcome)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Outcome)oldValue, false);
			SetParentOnElem((Outcome)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Outcome elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Outcome)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Event ParentEvent
		{
			get { return this.ParentDataObject as Event; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}

		/// <summary>
		/// Parent Referral that contains this collection
		/// </summary>
		public Referral ParentReferral
		{
			get { return this.ParentDataObject as Referral; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Referral */ }
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}
	}
}
