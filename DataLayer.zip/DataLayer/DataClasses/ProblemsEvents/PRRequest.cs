using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for PRRequest.
	/// </summary>
	[SPInsert("usp_InsertPRRequest")]
	[SPUpdate("usp_UpdatePRRequest")]
	[SPLoad("usp_LoadPRRequest")]
	[TableMapping("PRRequest","pRRequestID")]
	public class PRRequest : BaseDataWithUserDefined, IImageOwner
	{
		[NonSerialized]
		private PRRequestCollection parentPRRequestCollection;
		[ColumnMapping("PRRequestID",StereoType=DataStereoType.FK)]
		private int pRRequestID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("PhysicianReviewRequestReasonID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestReasonID;
		[ColumnMapping("PhysicianReviewDecisionID",StereoType=DataStereoType.FK)]
		private int physicianReviewDecisionID;
		[ColumnMapping("PhysicianReviewRequestStatusID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestStatusID;
		[ColumnMapping("StatusChangedBy",StereoType=DataStereoType.FK)]
		private int statusChangedBy;
		[ColumnMapping("StatusChangeTime")]
		private DateTime statusChangeTime;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("ProblemID",StereoType=DataStereoType.FK)]
		private int problemID;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("StartDate")]
		private DateTime startDate = DateTime.Now; // Current Date Time
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ClinicalReviewDecisionID",StereoType=DataStereoType.FK)]
		private int clinicalReviewDecisionID;
		private PRReviewCollection pRReviews;
	
		private int statusIDWhenLoaded;
		private PRReviewCollection physicianReviews;				// keeps track of the changes in status
		private ImageLinkCollection images;
		private AutoActivityManager autoActivityManager;
		private Patient patient;

		public PRRequest()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PRRequest(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int pRRequestID)
		{
			return base.Load(pRRequestID);
		}

		/// <summary>
		/// This method returns on of the constants set in PhysicianReviewDecision
		/// Currently:
		/// NoAction
		/// NewPreview
		/// NewProviderDecision
		/// </summary>
		/// <returns></returns>
		public string LastPRActionType()
		{
			PRReview review = this.GetMostRecentReview();
			if (review == null) return null;

			PhysicianReviewDecision dec = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.GetByID(review.PhysicianReviewDecisionID);            
			if (dec != null)
				return dec.PRActionType;
			else
				return null;
		}

		public bool CanAddNewPR()
		{
			this.LoadPRReviews(false);

			if (this.PRReviews.Count >= 5) return false;

			string lastPRActionType = LastPRActionType();
			return (lastPRActionType == PhysicianReviewDecision.NEWPRREVIEW || lastPRActionType == PhysicianReviewDecision.NEWPRDECISION);
		}

		public void CreateNewPR(ref PRReview review, ref PRProviderDecision decision)
		{
			review = null; decision = null;
			string actionType = LastPRActionType();
			if (actionType == PhysicianReviewDecision.NOACTION) return;

			PRReview latestReview = this.GetMostRecentReview();

			if (actionType == PhysicianReviewDecision.NEWPRREVIEW)
			{
				review = new PRReview(true, false);
				review.ParentReviewID = latestReview.PRReviewID;
				review.AppealStartDate = DateTime.Now;
				decision = new PRProviderDecision(true, true);
				review.LoadPRProviderDecisions(false);
				review.PRProviderDecisions.InsertRecord(0, decision);
			}
			else if (actionType == PhysicianReviewDecision.NEWPRDECISION)
			{
				review = latestReview;
				decision = new PRProviderDecision(true, true);
				review.LoadPRProviderDecisions(false);
				review.PRProviderDecisions.InsertRecord(0, decision);
			}
		}

		/// <summary>
		/// Create a physician review linked to the given clinical decision
		/// </summary>
		/// <param name="initNew"></param>
		public static PRRequest CreatePRRequest(Event eventObj, CMS cMS, ClinicalReviewDecision clinicalDecision)
		{
			DateTime today = DateTime.Now;
			PRRequest request = new PRRequest(true);
			request.StartDate = today;
			request.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.OPEN);

			request.clinicalReviewDecisionID = clinicalDecision.ClinicalReviewDecisionID;

			if (eventObj != null)
			{
				request.EventID = eventObj.EventID;
				request.PatientID = eventObj.PatientId;
				eventObj.LoadPRRequests(false);
				eventObj.PRRequests.InsertRecord(0, request);	
			}
			if (cMS != null)
			{
				request.CMSID = cMS.CMSID;
				request.PatientID = cMS.PatientId;
				cMS.LoadPRRequests(false);
				cMS.PRRequests.InsertRecord(0, request);	
			}

			return request;
		}

		public static PRRequest CreateNewPRTree(Event eventObj, CMS cMS, ClinicalReviewDecision clinicalDecision)
		{
			PRRequest request = CreatePRRequest(eventObj, cMS, clinicalDecision);
			
			// Add the initial PRReview
			PRReview review = new PRReview(true, true);
			request.LoadPRReviews(false);
			request.PRReviews.AddRecord(review);

			// Add the initial PRProviderDecision
			PRProviderDecision decision = new PRProviderDecision(true, true);
			review.LoadPRProviderDecisions(false);
			review.PRProviderDecisions.AddRecord(decision);

			return request;
		}

        public static PRRequest CreateNewPRTreeForLOMI(Event eventObj, CMS cMS, ClinicalReviewDecision clinicalDecision)
		{
			PRRequest request = CreatePRRequest(eventObj, cMS, clinicalDecision);

			DateTime now = DateTime.Now;

			request.StartDate = now; // Current Date Time
			request.PhysicianReviewRequestReasonID = PhysicianReviewRequestReasonCollection.ActivePhysicianReviewRequestReasons.Lookup_PhysicianReviewRequestReasonIDByCode(PhysicianReviewRequestReason.URREVIEW); // UR Review
			request.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.CLOSED); // Closed
			request.EndDate = now; // Current Date Time
			request.PhysicianReviewDecisionID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.LOMIDenial); // LOMI Denial

			PRReview review = new PRReview(true);

			review.AppealStartDate = now;
			review.AppealEndDate = now;
			review.PhysicianReviewRequestDetailTypeID = PhysicianReviewRequestDetailTypeCollection.ActivePhysicianReviewRequestDetailTypes.Lookup_PhysicianReviewRequestDetailTypeIDByCode(PhysicianReviewRequestDetailType.LOMI);
			review.PhysicianReviewDecisionID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.LOMIDenial); // LOMI Denial

			request.LoadPRReviews(false);
			request.PRReviews.InsertRecord(0, review); // Add review record to the parent request object

			PRProviderDecision decision = new PRProviderDecision(true);
			decision.PhysicianReviewDecisionID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.LOMIDenial); // LOMI Denial
			decision.PhysicianDecisionReasonID = PhysicianDecisionReasonCollection.ActivePhysicianDecisionReasons.Lookup_PhysicianDecisionReasonIDByCode(PhysicianDecisionReason.LOMI);
			decision.PhysicianDecisionRoleID = PhysicianDecisionRoleCollection.ActivePhysicianDecisionRoles.Lookup_PhysicianDecisionRoleIDByCode(PhysicianDecisionRole.NA); // N/A
			decision.UseLOMIProvider();
			decision.StartDate = now;
			decision.EndDate = now;

			review.LoadPRProviderDecisions(false);
			review.PRProviderDecisions.InsertRecord(0, decision);

			// Save to the database
			request.Save();

			return request;

		}

		
		public static void ChangeLOMIDenialToRAPP(Event eventObj, CMS cMS, ClinicalReviewDecision clinicalDecision)
		{
			PRRequest request = null;
			PRReview review = null;
			PRProviderDecision decision = null;

			if (!request.GetLatestPRRequestFromClinicalReviewDecision(clinicalDecision)) // If there's no request associated with this clinicaldecision there's nothing to do
				return;
					
			request.EndDate = clinicalDecision.ModifyTime; // Get clinical review decision's modify date time
			request.PhysicianReviewDecisionID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.RAPP); // Approved on Reconsideration
			request.ModifiedBy = clinicalDecision.ModifiedBy;
			request.ModifyTime = clinicalDecision.ModifyTime;
			request.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.CLOSED); // Closed

			request.LoadPRReviews(false);

			if (request.PRReviews.Count > 0)
			{
				review = request.GetMostRecentReview(); // Latest one is on top
				review.AppealEndDate = clinicalDecision.ModifyTime; // Get clinical review decision's modify date time
				review.PhysicianReviewDecisionID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.RAPP); // Approved on Reconsideration
				review.ModifiedBy = clinicalDecision.ModifiedBy;
				review.ModifyTime = clinicalDecision.ModifyTime;
			}

			if (review.PRProviderDecisions.Count > 0)
			{	
				decision = review.GetMostRecentProviderDecision(); // Latest one is on top
				decision.PhysicianReviewDecisionID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.RAPP); // Approved on Reconsideration
				decision.PhysicianDecisionReasonID = PhysicianDecisionReasonCollection.ActivePhysicianDecisionReasons.Lookup_PhysicianDecisionReasonIDByCode(PhysicianDecisionReason.MEDN); // Medically Necessary
				decision.EndDate = clinicalDecision.ModifyTime;
				decision.ModifiedBy = clinicalDecision.ModifiedBy;
				decision.ModifyTime = clinicalDecision.ModifyTime;
			}

			// Save to the database
			request.Save();
		}


		public static PRRequest ChangeLOMIDenialToRFPR(Event eventObj, CMS cMS, ClinicalReviewDecision clinicalDecision)
		{
			PRRequest request = new PRRequest();
			if (!request.GetLatestPRRequestFromClinicalReviewDecision(clinicalDecision))  // If there's no request associated with this clinicaldecision there's nothing to do
				return null;

			request.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.RECONPENDING); // Reconsideration Pending
			request.EndDate = DateTime.MinValue;
			request.ModifiedBy = clinicalDecision.ModifiedBy;
			request.ModifyTime = clinicalDecision.ModifyTime;
			return request;
		}

		protected override void InitializeToTrackChanges()
		{
			base.InitializeToTrackChanges ();

			// track the change of statusID.
			this.statusIDWhenLoaded = this.physicianReviewRequestStatusID;
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@PHYSICIANREVIEWREQUESTID@")]
		public int PRRequestID
		{
			get { return this.pRRequestID; }
			set { this.pRRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewRequestReasonID", "PhysicianReviewRequestReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@REQUESTREASON@")]
		public int PhysicianReviewRequestReasonID
		{
			get { return this.physicianReviewRequestReasonID; }
			set { this.physicianReviewRequestReasonID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewDecisionID", "PhysicianReviewDecisionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@DECISION@")]
		public int PhysicianReviewDecisionID
		{
			get { return this.physicianReviewDecisionID; }
			set { this.physicianReviewDecisionID = value; }
		}

		public string PhysicianReviewDecisionDisplay
		{
			get 
			{ 
				PhysicianReviewDecision dec = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.GetByID(this.physicianReviewDecisionID); 
				if (dec != null) return dec.Description;
				return null;
			}
			set
			{
			}
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime StatusChangeTime
		{
			get { return this.statusChangeTime; }
			set { this.statusChangeTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProblemID
		{
			get { return this.problemID; }
			set { this.problemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}


		[ValidatorMember("Vld_EndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime, ClientScriptForConditionalRequired="GetElemValue('PhysicianReviewDecisionID') != ''")]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ClinicalReviewDecisionID
		{
			get { return this.clinicalReviewDecisionID; }
			set { this.clinicalReviewDecisionID = value; }
		}


		public PRReview GetMostRecentReview()
		{
			PRReview latestReview = null;
			this.LoadPRReviews(false);
			if (this.pRReviews.Count > 0)
			{
				latestReview = this.pRReviews[0];
				foreach (PRReview review in this.pRReviews)
					if (review.CreateTime > latestReview.CreateTime) latestReview = review;
			}

			return latestReview;
		}

		public bool IsMostRecentReview(PRReview review)
		{
			PRReview latestReview = GetMostRecentReview();
			return (latestReview == null || (review.PRReviewID == latestReview.PRReviewID));
		}


		public void UpdateStatusInfo()
		{
			UpdateStatusInfo(null);
		}
		
		public void UpdateStatusInfo(PRReview review)
		{
			if (this.IsNew)
			{
				if (this.PhysicianReviewRequestStatusID == 0) // If it's already selected don't override
				{
					if (this.PhysicianReviewRequestReasonID == PhysicianReviewRequestReasonCollection.ActivePhysicianReviewRequestReasons.Lookup_PhysicianReviewRequestReasonIDByCode(PhysicianReviewRequestReason.URREVIEW))
						this.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.URREVIEWPENDING);
					else if (this.PhysicianReviewRequestReasonID == PhysicianReviewRequestReasonCollection.ActivePhysicianReviewRequestReasons.Lookup_PhysicianReviewRequestReasonIDByCode(PhysicianReviewRequestReason.CMREVIEW))
						this.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.CMREVIEWPENDING);
				}
			}
			else if (review != null) // here we want to override
			{
					if (review.PhysicianReviewDecisionID != 0) // If there's a decision then the Status must be closed
						this.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.CLOSED);
					else
					{
						switch (PhysicianReviewRequestDetailTypeCollection.ActivePhysicianReviewRequestDetailTypes.Lookup_CodeByPhysicianReviewRequestDetailTypeID(review.PhysicianReviewRequestDetailTypeID))
						{
							case PhysicianReviewRequestDetailType.RECONSIDERATION:
							case PhysicianReviewRequestDetailType.RECONSIDERATION2:
								this.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.RECONPENDING);
								break;
							case PhysicianReviewRequestDetailType.APPEALEXPEDITED:
								this.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.EXPEDITEDAPPEALPENDING);
								break;
							case PhysicianReviewRequestDetailType.APPEAL:
								this.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.STANDARDAPPEALPENDING);
								break;
							case PhysicianReviewRequestDetailType.APPEAL2:
							case PhysicianReviewRequestDetailType.APPEALEXPEDITED2:
								this.PhysicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(PhysicianReviewRequestStatus.SECONDAPPEALPENDING);
								break;
						}
					}
				}
		}


		/// <summary>
		/// Parent PRRequestCollection that contains this element
		/// </summary>
		public PRRequestCollection ParentPRRequestCollection
		{
			get
			{
				return this.parentPRRequestCollection;
			}
			set
			{
				this.parentPRRequestCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child PRReviews mapped to related rows of table PRReview where [PRRequestID] = [PRRequestID]
		/// </summary>
		[SPLoadChild("", "pRRequestID")] // Custom: usp_LoadPRRequestPRReviews
		public PRReviewCollection PRReviews
		{
			get { return this.pRReviews; }
			set
			{
				this.pRReviews = value;
				if (value != null)
					value.ParentPRRequest = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PRReviews collection
		/// </summary>
		public void LoadPRReviews(bool forceReload)
		{
			this.pRReviews = (PRReviewCollection)PRReviewCollection.LoadChildCollection("PRReviews", "usp_LoadPRRequestPRReviews", this, typeof(PRReviewCollection), pRReviews, forceReload, null);
		}

		/// <summary>
		/// Saves the PRReviews collection
		/// </summary>
		public void SavePRReviews()
		{
			PRReviewCollection.SaveChildCollection(this.pRReviews, true);
		}

		/// <summary>
		/// Synchronizes the PRReviews collection
		/// </summary>
		public void SynchronizePRReviews()
		{
			PRReviewCollection.SynchronizeChildCollection(this.pRReviews, true);
		}


		#region Images Overriden
		/// <summary>
		/// Child Images mapped to related rows of table PRRequest where [PRRequestID] = [PRRequestID]
		/// </summary>
		[SPLoadChild("usp_LoadPRRequestImages", "pRRequestID")]
		public ImageLinkCollection Images
		{
			get { return this.images; }
			set
			{
				this.images = value;
				if (value != null)
					value.ParentPRRequest = this; // set this as a parent of the child collection
			}
		}
				
		/// <summary>
		/// Loads the Outcomes collection
		/// </summary>
		public void LoadImages(bool forceReload)
		{
			this.images = (ImageLinkCollection)ImageLinkCollection.LoadChildCollection("Images", this, typeof(ImageLinkCollection), images, forceReload, null);
		}

		/// <summary>
		/// Saves the Outcomes collection
		/// </summary>
		public void SaveImages()
		{
			ImageLinkCollection.SaveChildCollection(this.images, true);
		}

		/// <summary>
		/// Synchronizes the Outcomes collection
		/// </summary>
		public void SynchronizeImages()
		{
			ImageLinkCollection.SynchronizeChildCollection(this.images, true);
		}

		#endregion



		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			bool initialSave = this.IsNew;

			if (this.IsNew || this.physicianReviewRequestStatusID != this.statusIDWhenLoaded)
			{
				// status changed.
				this.SetStatusChangingUser();
			}

			base.InternalSave();

			#region Trigger AutoActivities - ER2, ER5
			
			if (initialSave)
			{
				PatientCoverage patCov = null;

				if (this.eventID != 0)
				{
					// access event and use it's context
					Event eventObj = this.GetEvent();
					autoActivityManager = this.parentPRRequestCollection.EnsureAutoActivityManager(eventObj.Patient, eventObj);
					AutoActivity_PRRequestForEventInitialSave();	// ER2
				}
				else if (this.referralDetailID != 0)
				{
					// access referral and use it's context.
					ReferralDetail refDetail = this.GetReferralDetail();
					if (refDetail != null)
					{
						Referral referral = refDetail.GetReferral();
						if (referral != null)
						{
							autoActivityManager = this.parentPRRequestCollection.EnsureAutoActivityManager(referral.Patient, referral);
							AutoActivity_PRRequestForReferralInitialSave();	// ER5
						}
					}
				}
			}

			#endregion

			// Save the child collections here.

			// save child tables that are managed in-memory
			this.SavePRReviews();
		}

		/// <summary>
		/// ER2	- Physician Review for Event Initial Save
		/// This is triggered when a new physician review is saved for an event.
		/// </summary>
		public void AutoActivity_PRRequestForEventInitialSave()
		{
			autoActivityManager.Execute(AutoActivityRuleType.ER2, this.SqlData.Transaction);
		}

		/// <summary>
		/// ER5	- Physician Review for Referral Initial Save
		/// This is triggered when a new physician review is saved for a referral detail.
		/// </summary>
		public void AutoActivity_PRRequestForReferralInitialSave()
		{
			autoActivityManager.Execute(AutoActivityRuleType.ER5, this.SqlData.Transaction);
		}


		/// <summary>
		/// Load the patient related to this physician review and return it.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientID == 0)
				return null;

			Patient patient = new Patient();
			patient.SqlData.Transaction = this.SqlData.Transaction;
			if (patient.Load(patientID))
				return patient;
			else
				return null;

		}

		/// <summary>
		/// Load and cache the patient related to this physician review request.
		/// </summary>
		public Patient Patient
		{
			get 
			{ 
				if (this.patient == null)
					this.patient = GetPatient();
				return this.patient; 
			}
		}
		
		/// <summary>
		/// Load the event related to this physician and return it.
		/// </summary>
		/// <returns></returns>
		public Event GetEvent()
		{
			if (this.parentPRRequestCollection != null)
				if (this.parentPRRequestCollection.ParentEvent != null)
					return this.parentPRRequestCollection.ParentEvent;

			if (this.eventID == 0)
				return null;

			Event eventObj = new Event();
			eventObj.SqlData.Transaction = this.SqlData.Transaction;
			if (eventObj.Load(this.Patient, eventID))
				return eventObj;
			else
				return null;

		}

		/// <summary>
		/// Load the Referral Detail related to this physician and return it.
		/// </summary>
		/// <returns></returns>
		public ReferralDetail GetReferralDetail()
		{
			if (this.referralDetailID == 0)
				return null;

			ReferralDetail refDetail = new ReferralDetail();
			refDetail.SqlData.Transaction = this.SqlData.Transaction;
			if (refDetail.Load(this.referralDetailID))
				return refDetail;
			else
				return null;

		}


		public PhysicianReviewRequestReasonCollection LookupOf_PhysicianReviewRequestReasonID
		{
			get
			{
				return PhysicianReviewRequestReasonCollection.ActivePhysicianReviewRequestReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewDecisionCollection LookupOf_PhysicianReviewDecisionID
		{
			get
			{
				return PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewRequestStatusCollection LookupOf_PhysicianReviewRequestStatusID
		{
			get
			{
				return PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses; // Acquire a shared instance from the static member of collection
			}
		}


		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.StatusCode = SystemStatus.OPEN;
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public string StatusCode
		{
			get { return PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_CodeByPhysicianReviewRequestStatusID(this.physicianReviewRequestStatusID); }
			set { this.physicianReviewRequestStatusID = PhysicianReviewRequestStatusCollection.ActivePhysicianReviewRequestStatuses.Lookup_PhysicianReviewRequestStatusIDByCode(value); }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewRequestStatusID", "PhysicianReviewRequestStatusID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int PhysicianReviewRequestStatusID
		{
			get { return this.physicianReviewRequestStatusID; }
			set { this.physicianReviewRequestStatusID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}
		
		public bool GetLatestPRRequestFromClinicalReviewDecision(ClinicalReviewDecision clinicalDecision)
		{
			object request = SqlData.SPExecScalar("usp_GetLatestPRRequestFromClinicalReviewDecision", new object[] {clinicalDecision.ClinicalReviewDecisionID});
			if (request != null)	
			{
				return this.Load((int)request);
			}

			return false;
		}


	}

	/// <summary>
	/// Strongly typed collection of PRRequest objects
	/// </summary>
	[ElementType(typeof(PRRequest))]
	public class PRRequestCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		
		private AutoActivityManager autoActivityManager;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PRRequest elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPRRequestCollection = this;
			else
				elem.ParentPRRequestCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PRRequest elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PRRequest this[int index]
		{
			get
			{
				return (PRRequest)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PRRequest)oldValue, false);
			SetParentOnElem((PRRequest)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}


		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Event ParentEvent
		{
			get { return this.ParentDataObject as Event; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}


		public ActiveAdvice.DataLayer.AutoActivityManager AutoActivityManager
		{
			get { return this.autoActivityManager; }
			set { this.autoActivityManager = value; }
		}

		public AutoActivityManager EnsureAutoActivityManager(Patient patient, BaseForEventCMSReferral erc)
		{
			if (this.autoActivityManager == null)
			{
				if (erc.PatientSubscriberLog != null)
					autoActivityManager = new AutoActivityManager(patient, erc.PatientSubscriberLog.PatientCoverage, erc.GetPrimaryProblem(), erc);
			}
			return this.autoActivityManager;
		}

		/// <summary>
		/// Load all physician reviews of the patient.
		/// </summary>
		public int LoadPatientPRRequests(int maxRecords, int patientID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientPRRequests", maxRecords, this, false, new object[] { patientID });
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PRRequest elem)
		{
			return AddRecord(elem);
		}
	}
}
