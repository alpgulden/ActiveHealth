using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianReviewDecision]
	/// </summary>
	[SPInsert("usp_InsertPhysicianReviewRequestDetail")]
	[SPUpdate("usp_UpdatePhysicianReviewRequestDetail")]
	[SPLoad("usp_LoadPhysicianReviewRequestDetail")]
	[TableMapping("PhysicianReviewRequestDetail","physicianReviewRequestDetailID")]
	public class PhysicianReviewRequestDetail : BaseDataWithUserDefined
	{
		[NonSerialized]
		private PhysicianReviewRequestDetailCollection parentPhysicianReviewRequestDetailCollection;
		[ColumnMapping("PhysicianReviewRequestDetailID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestDetailID;
		[ColumnMapping("PhysicianReviewRequestID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestID;
		[ColumnMapping("ProviderNetworkID",StereoType=DataStereoType.FK)]
		private int providerNetworkID;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]
		private int providerID;
		[ColumnMapping("ProviderSpecialtyID",StereoType=DataStereoType.FK)]
		private int providerSpecialtyID;
		[ColumnMapping("PhysicianDecisionRoleID",StereoType=DataStereoType.FK)]
		private int physicianDecisionRoleID;
		[ColumnMapping("PhysicianReviewDecisionID",StereoType=DataStereoType.FK)]
		private int physicianReviewDecisionID;
		[ColumnMapping("PhysicianDecisionReasonID",StereoType=DataStereoType.FK)]
		private int physicianDecisionReasonID;
		[ColumnMapping("PhysicianReviewRequestDetailTypeID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestDetailTypeID;
		[ColumnMapping("StartDate")]
		private DateTime startDate = DateTime.Now;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("SpokeToProvider")]
		private bool spokeToProvider;
		[ColumnMapping("SpokeToProviderDate")]
		private DateTime spokeToProviderDate;
		[ColumnMapping("ExplainedAppealsProcess")]
		private bool explainedAppealsProcess;
		[ColumnMapping("ExplainedAppealsProcessDate")]
		private DateTime explainedAppealsProcessDate;
		[ColumnMapping("MinutesSpent")]
		private int minutesSpent = 0;
		[ColumnMapping("TransactionNumber")]
		private string transactionNumber;
		[ColumnMapping("CheckNumber")]
		private string checkNumber;
		[ColumnMapping("GeneratePayable")]
		private bool generatePayable = false;
		[ColumnMapping("GeneratePayableDate")]
		private DateTime generatePayableDate;
		[ColumnMapping("CheckAmount")]
		private Decimal checkAmount = decimal.MinValue;
		[ColumnMapping("DateGenerated")]
		private DateTime dateGenerated;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		private PhysicianReviewAppeal physicianReviewAppeal;
		private PhysicianReviewAppealCollection physicianReviewAppeals;
	
		public PhysicianReviewRequestDetail()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianReviewRequestDetail(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PhysicianReviewRequestDetailID
		{
			get { return this.physicianReviewRequestDetailID; }
			set { this.physicianReviewRequestDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PhysicianReviewRequestID
		{
			get { return this.physicianReviewRequestID; }
			set { this.physicianReviewRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderNetworkID
		{
			get { return this.providerNetworkID; }
			set { this.providerNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderSpecialtyID
		{
			get { return this.providerSpecialtyID; }
			set { this.providerSpecialtyID = value; }
		}

		// this is not in the table!!!
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderNetworkStatusID
		{
			get { return 0; }
			set { }
		}


		[FieldValuesMember("LookupOf_PhysicianDecisionRoleID", "PhysicianDecisionRoleID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int PhysicianDecisionRoleID
		{
			get { return this.physicianDecisionRoleID; }
			set { this.physicianDecisionRoleID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewDecisionID", "PhysicianReviewDecisionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@DECISION@")]
		public int PhysicianReviewDecisionID
		{
			get { return this.physicianReviewDecisionID; }
			set { this.physicianReviewDecisionID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianDecisionReasonID", "PhysicianDecisionReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ClientScriptForConditionalRequired="GetElemValue('DecPhysicianReviewDecisionID') != ''", IsRequired=true)]
		[FieldDescription("@DECISIONREASON@")]
		public int PhysicianDecisionReasonID
		{
			get { return this.physicianDecisionReasonID; }
			set { this.physicianDecisionReasonID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewRequestDetailTypeID", "PhysicianReviewRequestDetailTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@REQUESTTYPE@")]
		public int PhysicianReviewRequestDetailTypeID
		{
			get { return this.physicianReviewRequestDetailTypeID; }
			set { this.physicianReviewRequestDetailTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime, IsRequired=true)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ValidatorMember("Vld_EndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime, ClientScriptForConditionalRequired="GetElemValue('DecPhysicianReviewDecisionID') != ''", IsRequired=true)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool SpokeToProvider
		{
			get { return this.spokeToProvider; }
			set { this.spokeToProvider = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ExplainedAppealsProcess
		{
			get { return this.explainedAppealsProcess; }
			set { this.explainedAppealsProcess = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MinutesSpent
		{
			get { return this.minutesSpent; }
			set { this.minutesSpent = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string TransactionNumber
		{
			get { return this.transactionNumber; }
			set { this.transactionNumber = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string CheckNumber
		{
			get { return this.checkNumber; }
			set { this.checkNumber = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool GeneratePayable
		{
			get { return this.generatePayable; }
			set { this.generatePayable = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime GeneratePayableDate
		{
			get { return this.generatePayableDate; }
			set { this.generatePayableDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		public decimal CheckAmount
		{
			get { return this.checkAmount; }
			set { this.checkAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DateGenerated
		{
			get { return this.dateGenerated; }
			set { this.dateGenerated = value; }
		}

		[FieldDescription("@PROVIDER@")]
		public string ProviderName
		{
			get 
			{
				return Provider.GetProviderFullNameWithPrefixByID(this.providerID);
			}
		}

		[FieldDescription("@SPECIALTY@")]
		public string SpecialtyName
		{
			get 
			{
				return ProviderSpecialty.GetProviderSpecialtyDescriptionByID(this.providerSpecialtyID);
			}
		}

		[GenericScript("Vld_EndDate", "@EndDate@ >= @StartDate@;")]
		protected string Vld_EndDate
		{
			get
			{
				return "@ERRENDDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
				/*DateTime terminationDate = (DateTime)this.Get("terminationDate");
				DateTime effectiveDate = (DateTime)this.Get("effectiveDate");
				if (terminationDate != DateTime.MinValue && !(terminationDate >= effectiveDate))
					throw new ValidationException("TerminationDate", Vld_TerminationDate);  // throw validation exception if failed (don't set the member) 
					*/

				// Can't validate on the server, because the depended 2 members are not filled yet.
			}
		}

			
		#region Appeal Details

		public System.DateTime AuthFormReceivedDate
		{
			get 
			{ 
				if (this.PhysicianReviewAppeal != null)
					return this.PhysicianReviewAppeal.AuthFormReceivedDate;
				else
					return DateTime.MinValue;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MedRecordReleaseSentDate
		{
			get 
			{ 
				if (this.PhysicianReviewAppeal != null)
					return this.PhysicianReviewAppeal.MedRecordReleaseSentDate; 
				else
					return DateTime.MinValue;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MedRecordReceivedDate
		{
			get 
			{ 
				if (this.PhysicianReviewAppeal != null)
					return this.PhysicianReviewAppeal.MedRecordReceivedDate; 
				else
					return DateTime.MinValue;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AppealRequestedByTypeID
		{
			get 
			{ 
				if (this.PhysicianReviewAppeal != null)
					return this.PhysicianReviewAppeal.AppealRequestedByTypeID;
				else
					return 0;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AppealStartDate
		{
			get 
			{ 
				if (this.PhysicianReviewAppeal != null)
					return this.PhysicianReviewAppeal.AppealStartDate;
				else
					return DateTime.MinValue;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AppealEndDate
		{
			get 
			{ 
				if (this.PhysicianReviewAppeal != null)
					return this.PhysicianReviewAppeal.AppealEndDate; 
				else
					return DateTime.MinValue;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ClientRequestInformationDate
		{
			get 
			{ 
				if (this.PhysicianReviewAppeal != null)
					return this.PhysicianReviewAppeal.ClientRequestInformationDate;
				else
					return DateTime.MinValue;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ClientReceivedInformationDate
		{
			get 
			{ 
				if (this.PhysicianReviewAppeal != null)
					return this.PhysicianReviewAppeal.ClientReceivedInformationDate; 
				else
					return DateTime.MinValue;
			}
		}

		#endregion



		/// <summary>
		/// Parent PhysicianReviewRequestDetailCollection that contains this element
		/// </summary>
		public PhysicianReviewRequestDetailCollection ParentPhysicianReviewRequestDetailCollection
		{
			get
			{
				return this.parentPhysicianReviewRequestDetailCollection;
			}
			set
			{
				this.parentPhysicianReviewRequestDetailCollection = value; // parent is set when added to a collection
			}
		}


		public void EnsurePhysicianReviewAppeal()
		{
			this.LoadPhysicianReviewAppeals(false);
			if (this.physicianReviewAppeals.Count == 0)
			{
				PhysicianReviewAppeal appeal = new PhysicianReviewAppeal(true);
				this.physicianReviewAppeals.AddRecord(appeal);
			}
			else if (this.physicianReviewAppeals[0].IsMarkedForDeletion)
			{
				this.physicianReviewAppeals[0].IsMarkedForDeletion = false;
			}
		}

		public void RemovePhysicianReviewAppeal()
		{
			if (this.physicianReviewAppeals.Count > 0)
				this.physicianReviewAppeals.MarkAllDel();
		}
		
		public PhysicianReviewAppeal PhysicianReviewAppeal
		{
			get 
			{
				LoadPhysicianReviewAppeals(false);
				if (this.physicianReviewAppeals.Count > 0 && !this.physicianReviewAppeals[0].IsMarkedForDeletion)
					return this.physicianReviewAppeals[0];
				return null;
			}	
		}
		
		/// <summary>
		/// Child PhysicianReviewAppeals mapped to related rows of table PhysicianReviewAppeal where [PhysicianReviewRequestDetailID] = [PhysicianReviewRequestDetailID]
		/// </summary>
		[SPLoadChild("usp_LoadPhysicianReviewAppeals", "physicianReviewRequestDetailID")]
		public PhysicianReviewAppealCollection PhysicianReviewAppeals
		{
			get { return this.physicianReviewAppeals; }
			set
			{
				this.physicianReviewAppeals = value;
				if (value != null)
					value.ParentPhysicianReviewRequestDetail = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PhysicianReviewAppeals collection
		/// </summary>
		public void LoadPhysicianReviewAppeals(bool forceReload)
		{
			this.physicianReviewAppeals = (PhysicianReviewAppealCollection)PhysicianReviewAppealCollection.LoadChildCollection("PhysicianReviewAppeals", this, typeof(PhysicianReviewAppealCollection), physicianReviewAppeals, forceReload, null);
		}

		/// <summary>
		/// Saves the PhysicianReviewAppeals collection
		/// </summary>
		public void SavePhysicianReviewAppeals()
		{
			PhysicianReviewAppealCollection.SaveChildCollection(this.physicianReviewAppeals, true);
		}

		/// <summary>
		/// Synchronizes the PhysicianReviewAppeals collection
		/// </summary>
		public void SynchronizePhysicianReviewAppeals()
		{
			PhysicianReviewAppealCollection.SynchronizeChildCollection(this.physicianReviewAppeals, true);
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, ClientScriptForConditionalRequired="GetElem('SpokeToProvider').checked", IsRequired=true)]
		public System.DateTime SpokeToProviderDate
		{
			get { return this.spokeToProviderDate; }
			set { this.spokeToProviderDate = value; }
		}
		[ControlType(Macro=EnumControlTypeMacros.ShortDate, ClientScriptForConditionalRequired="GetElem('ExplainedAppealsProcess').checked", IsRequired=true)]
		public System.DateTime ExplainedAppealsProcessDate
		{
			get { return this.explainedAppealsProcessDate; }
			set { this.explainedAppealsProcessDate = value; }
		}

		public bool isAppeal()
		{
			PhysicianReviewRequestDetailType dType = PhysicianReviewRequestDetailTypeCollection.ActivePhysicianReviewRequestDetailTypes.FindBy(this.physicianReviewRequestDetailTypeID);
			return (dType != null && dType.SubCodeExtStr == "APPL");
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			base.InternalSave();

			this.LoadPhysicianReviewAppeals(false);
			// If the request type is not appeal anymore, remove the appeal record.
			if (!this.isAppeal() && this.physicianReviewAppeals.Count > 0)
			{
				RemovePhysicianReviewAppeal();
			}

			this.SavePhysicianReviewAppeals();
		}


		public PhysicianDecisionRoleCollection LookupOf_PhysicianDecisionRoleID
		{
			get
			{
				return PhysicianDecisionRoleCollection.ActivePhysicianDecisionRoles; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewDecisionCollection LookupOf_PhysicianReviewDecisionID
		{
			get
			{
				return PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianDecisionReasonCollection LookupOf_PhysicianDecisionReasonID
		{
			get
			{
				return PhysicianDecisionReasonCollection.ActivePhysicianDecisionReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewRequestDetailTypeCollection LookupOf_PhysicianReviewRequestDetailTypeID
		{
			get
			{
				return PhysicianReviewRequestDetailTypeCollection.ActivePhysicianReviewRequestDetailTypes; // Acquire a shared instance from the static member of collection
			}
		}


		public bool CheckProvider()
		{
			int denialID = PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions.Lookup_PhysicianReviewDecisionIDByCode(PhysicianReviewDecision.DENIAL);

		    PhysicianReviewRequestDetailCollection col = this.parentPhysicianReviewRequestDetailCollection;
			if (col != null && col.Count > 1)
			{
				foreach (PhysicianReviewRequestDetail detail in col)
				{
					if (detail == this) continue;
					
					if (detail.PhysicianReviewDecisionID == denialID && detail.ProviderID == this.ProviderID)
						return false;
				}
			}

			return true;    
		}

	}

	/// <summary>
	/// Strongly typed collection of PhysicianReviewRequestDetail objects
	/// </summary>
	[ElementType(typeof(PhysicianReviewRequestDetail))]
	public class PhysicianReviewRequestDetailCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianReviewRequestDetail elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianReviewRequestDetailCollection = this;
			else
				elem.ParentPhysicianReviewRequestDetailCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianReviewRequestDetail elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianReviewRequestDetail this[int index]
		{
			get
			{
				return (PhysicianReviewRequestDetail)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianReviewRequestDetail)oldValue, false);
			SetParentOnElem((PhysicianReviewRequestDetail)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent PhysicianReviewRequest that contains this collection
		/// </summary>
		public PhysicianReviewRequest ParentPhysicianReviewRequest
		{
			get { return this.ParentDataObject as PhysicianReviewRequest; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PhysicianReviewRequest */ }
		}


		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PhysicianReviewRequestDetail elem)
		{
			return AddRecord(elem);
		}
	}

}
