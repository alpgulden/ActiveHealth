using System;

using System.Diagnostics;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Event]
	/// Event is the root record of a health-related incident. Events become the core around which all other patient health-related information associated with a particular incident is organized. Events are always associated with a Problem; in addition, an Event can be associated with Care Management Cases. An Event shall encapsulate care-related information such as:
	/// �	Diagnoses & Procedures
	/// �	Clinical Reviews
	/// �	Outcomes
	/// �	PCP/Referring Provider information
	/// �	Consulting Provider information
	/// �	Administrative information
	/// 
	/// Events can be created manually by the User, in response to a Resolution during Intake Log entry, or generated automatically by the System during Care Resource entry.
	/// </summary>
	[SPAutoGen("usp_SearchEventsByAltEventID","SelectAllByGivenArgsOrderBy.sptpl","altEventID, ASC, altEventID")]
	[SPAutoGen("usp_GetAllEventsByPatientID","SelectAllByGivenArgs.sptpl","patientId")]
	[SPAutoGen("usp_GetMostRecentEventForPatient","SelectTop1.sptpl","eventID, DESC, patientId")]
	[SPAutoGen("usp_GetEventByCMSID","SelectAllByGivenArgs.sptpl","cMSID")]
	[SPAutoGen("usp_UpdateEventLastValidationDate","UpdateGivenColsByPK.sptpl","lastValidationDate")]
	[SPAutoGen("usp_HasEventOpenActivities", null, ManuallyManaged=true)]
	[SPAutoGen("usp_GetPossibleDuplicateEvents","-SelectAllByGivenArgs.sptpl",
		"patientId, eventTypeID, providerID, facilityID, providerGroupID, startDate",
		InjectWhere="AND [Event].[EventID] != @eventID  -- except the given event", InjectParameters="@eventID int", 
		ManuallyManaged=true)]
	[SPAutoGen("usp_GetLinkedPatientEvents","SelectAllByGivenArgs.sptpl","patientId", InjectOrderBy="ORDER BY [Event].[EventID] DESC")]		// we can now select directly by the patientId on Event
	[SPInsert("usp_InsertEvent")]
	[SPUpdate("usp_UpdateEvent")]
	[SPDelete("usp_DeleteEvent")]
	[SPLoad("usp_LoadEvent")]
	[SPExists("usp_ExistsEvent", ManuallyManaged=true)]
	[TableMapping("Event","eventID")]
	public class Event : BaseForEventCMSReferral
	{
		[NonSerialized]
		private EventCollection parentEventCollection;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("AltEventID")]
		private string altEventID;
		[ColumnMapping("PrimaryProblemID",StereoType=DataStereoType.FK)]
		private int primaryProblemID;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("StartDateAP",StereoType=DataStereoType.FK)]
		private int startDateAP;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("EndDateAP",StereoType=DataStereoType.FK)]
		private int endDateAP;
		[ColumnMapping("EventTypeID",StereoType=DataStereoType.FK)]
		private int eventTypeID;
		[ColumnMapping("StatusID",StereoType=DataStereoType.FK)]
		private int statusID;
		[ColumnMapping("StatusChangedBy",StereoType=DataStereoType.FK)]
		private int statusChangedBy;
		[ColumnMapping("StatusChangeTime")]
		private DateTime statusChangeTime;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("EventSourceID",StereoType=DataStereoType.FK)]
		private int eventSourceID;
		[ColumnMapping("Resolution",StereoType=DataStereoType.FK)]
		private int resolution;
		[ColumnMapping("AssignedUserID",StereoType=DataStereoType.FK)]
		private int assignedUserID;
		[ColumnMapping("AssignedTeamID",StereoType=DataStereoType.FK)]
		private int assignedTeamID;
		[ColumnMapping("LateCallIn")]
		private bool lateCallIn;
		[ColumnMapping("NotifyDate")]
		private DateTime notifyDate;
		[ColumnMapping("AdmittingDiagnosisType")]
		private string admittingDiagnosisType;
		[ColumnMapping("AdmittingDiagnosisCode")]
		private string admittingDiagnosisCode;
		[ColumnMapping("OTPlanDescription")]
		private string oTPlanDescription;
		[ColumnMapping("FacilityTypeID",StereoType=DataStereoType.FK)]
		private int facilityTypeID;
		[ColumnMapping("FacilityNetworkStatus", ValueForNull=(int)-1)]
		private int facilityNetworkStatus = -1;
		[ColumnMapping("FacilityID",StereoType=DataStereoType.FK)]
		private int facilityID;
		[ColumnMapping("FacilityLocationID",StereoType=DataStereoType.FK)]
		private int facilityLocationID;
		[ColumnMapping("FacilityNetworkID",StereoType=DataStereoType.FK)]
		private int facilityNetworkID;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]
		private int providerID;
		[ColumnMapping("ProviderNetworkID",StereoType=DataStereoType.FK)]
		private int providerNetworkID;
		[ColumnMapping("ProviderSpecialtyID",StereoType=DataStereoType.FK)]
		private int providerSpecialtyID;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("ProviderNetworkStatus", ValueForNull=(int)-1)]
		private int providerNetworkStatus = -1;
		[ColumnMapping("ProviderGroupID",StereoType=DataStereoType.FK)]
		private int providerGroupID;
		[ColumnMapping("ProviderGroupTypeID",StereoType=DataStereoType.FK)]
		private int providerGroupTypeID;
		[ColumnMapping("ProviderGroupLocationID",StereoType=DataStereoType.FK)]
		private int providerGroupLocationID;
		[ColumnMapping("ProviderGroupNetworkID",StereoType=DataStereoType.FK)]
		private int providerGroupNetworkID;
		[ColumnMapping("ProviderGroupNetworkStatus", ValueForNull=(int)-1)]
		private int providerGroupNetworkStatus = -1;
		[ColumnMapping("PCPID",StereoType=DataStereoType.FK)]
		private int pCPID;
		[ColumnMapping("PCPSpecialtyID",StereoType=DataStereoType.FK)]
		private int pCPSpecialtyID;
		[ColumnMapping("PCPLocationID",StereoType=DataStereoType.FK)]
		private int pCPLocationID;
		[ColumnMapping("PCPNetworkID",StereoType=DataStereoType.FK)]
		private int pCPNetworkID;
		[ColumnMapping("PCPNetworkStatus", ValueForNull=(int)-1)]
		private int pCPNetworkStatus = -1;
		[ColumnMapping("PCPGroupID",StereoType=DataStereoType.FK)]
		private int pCPGroupID;
		[ColumnMapping("PCPGroupTypeID",StereoType=DataStereoType.FK)]
		private int pCPGroupTypeID;
		[ColumnMapping("PCPGroupLocationID",StereoType=DataStereoType.FK)]
		private int pCPGroupLocationID;
		[ColumnMapping("PCPGroupNetworkID",StereoType=DataStereoType.FK)]
		private int pCPGroupNetworkID;
		[ColumnMapping("PCPGroupNetworkStatus", ValueForNull=(int)-1)]
		private int pCPGroupNetworkStatus = -1;
		[ColumnMapping("RefProviderID",StereoType=DataStereoType.FK)]
		private int refProviderID;
		[ColumnMapping("RefProviderSpecialtyID",StereoType=DataStereoType.FK)]
		private int refProviderSpecialtyID;
		[ColumnMapping("RefProviderLocationID",StereoType=DataStereoType.FK)]
		private int refProviderLocationID;
		[ColumnMapping("RefProviderNetworkID",StereoType=DataStereoType.FK)]
		private int refProviderNetworkID;
		[ColumnMapping("RefProviderNetworkStatus", ValueForNull=(int)-1)]
		private int refProviderNetworkStatus = -1;
		[ColumnMapping("RefProviderGroupID",StereoType=DataStereoType.FK)]
		private int refProviderGroupID;
		[ColumnMapping("RefProviderGroupTypeID",StereoType=DataStereoType.FK)]
		private int refProviderGroupTypeID;
		[ColumnMapping("RefProviderGroupLocationID",StereoType=DataStereoType.FK)]
		private int refProviderGroupLocationID;
		[ColumnMapping("RefProviderGroupNetworkID",StereoType=DataStereoType.FK)]
		private int refProviderGroupNetworkID;
		[ColumnMapping("RefProviderGroupNetworkStatus", ValueForNull=(int)-1)]
		private int refProviderGroupNetworkStatus = -1;
		[ColumnMapping("PhysicianReview")]
		private bool physicianReview;
		[ColumnMapping("MaternityEvent")]
		private bool maternityEvent;
		[ColumnMapping("Maternity1stPreVisit")]
		private DateTime maternity1stPreVisit;
		[ColumnMapping("MaternityPostpartumVisit")]
		private DateTime maternityPostpartumVisit;
		[ColumnMapping("MaternityLMPDate")]
		private DateTime maternityLMPDate;
		[ColumnMapping("MaternityEDCDate")]
		private DateTime maternityEDCDate;
		[ColumnMapping("MaternityCalcGestation",StereoType=DataStereoType.FK)]
		private int maternityCalcGestation;
		[ColumnMapping("MaternityNumBabiesExp",StereoType=DataStereoType.FK)]
		private int maternityNumBabiesExp;
		[ColumnMapping("MaternityGravida",StereoType=DataStereoType.FK)]
		private int maternityGravida;
		[ColumnMapping("MaternityPara",StereoType=DataStereoType.FK)]
		private int maternityPara;
		[ColumnMapping("MaternityEctopic",StereoType=DataStereoType.FK)]
		private int maternityEctopic;
		[ColumnMapping("MaternityAB",StereoType=DataStereoType.FK)]
		private int maternityAB;
		[ColumnMapping("ParentEventID",StereoType=DataStereoType.FK)]
		private int parentEventID;
		[ColumnMapping("NewbornEvent")]
		private bool newbornEvent;
		[ColumnMapping("ClonedBaby")]
		private bool clonedBaby;
		[ColumnMapping("DischSameMom")]
		private bool dischSameMom;
		[ColumnMapping("NewbornGestate",StereoType=DataStereoType.FK)]
		private int newbornGestate;
		[ColumnMapping("NewbornLBS",StereoType=DataStereoType.FK)]
		private int newbornLBS;
		[ColumnMapping("NewbornOz",StereoType=DataStereoType.FK)]
		private int newbornOz;
		[ColumnMapping("NewbornGrams",StereoType=DataStereoType.FK)]
		private int newbornGrams;
		[ColumnMapping("NewbornLength")]
		private Decimal newbornLength;
		[ColumnMapping("NewbornAPGAR1Min",StereoType=DataStereoType.FK)]
		private int newbornAPGAR1Min;
		[ColumnMapping("NewbornAPGAR5Mins",StereoType=DataStereoType.FK)]
		private int newbornAPGAR5Mins;
		[ColumnMapping("DrgType")]
		private string drgType;
		[ColumnMapping("DrgVersion")]
		private string drgVersion;
		[ColumnMapping("DrgCode")]
		private string drgCode;
		[ColumnMapping("LOSPayorGroup",StereoType=DataStereoType.FK)]
		private int lOSPayorGroup;
		[ColumnMapping("LOSRegion",StereoType=DataStereoType.FK)]
		private int lOSRegion;
		[ColumnMapping("LOSYear",StereoType=DataStereoType.FK)]
		private int lOSYear;
		[ColumnMapping("LOS_10",StereoType=DataStereoType.FK)]
		private int los10;
		[ColumnMapping("LOS_10PLUS")]
		private string los10plus;
		[ColumnMapping("LOS_25",StereoType=DataStereoType.FK)]
		private int los25;
		[ColumnMapping("LOS_25PLUS")]
		private string los25plus;
		[ColumnMapping("LOS_50",StereoType=DataStereoType.FK)]
		private int los50;
		[ColumnMapping("LOS_50PLUS")]
		private string los50plus;
		[ColumnMapping("LOS_75",StereoType=DataStereoType.FK)]
		private int los75;
		[ColumnMapping("LOS_75PLUS")]
		private string los75plus;
		[ColumnMapping("LOS_90",StereoType=DataStereoType.FK)]
		private int los90;
		[ColumnMapping("LOS_90PLUS")]
		private string los90plus;
		[ColumnMapping("LOS_95",StereoType=DataStereoType.FK)]
		private int los95;
		[ColumnMapping("LOS_95PLUS")]
		private string los95plus;
		[ColumnMapping("LOS_99",StereoType=DataStereoType.FK)]
		private int los99;
		[ColumnMapping("LOS_99PLUS")]
		private string los99plus;
		[ColumnMapping("ServiceDate")]
		private DateTime serviceDate;
		[ColumnMapping("PatientSubscriberLogID",StereoType=DataStereoType.FK)]
		private int patientSubscriberLogID;
		[ColumnMapping("PlanSorgLogID",StereoType=DataStereoType.FK)]
		private int planSorgLogID;
		[ColumnMapping("Newborn1stPedVisit")]
		private DateTime newborn1stPedVisit;
		[ColumnMapping("NewbornDCCondition",StereoType=DataStereoType.FK)]
		private int newbornDCCondition;
		[ColumnMapping("LOSObservedPatients",StereoType=DataStereoType.FK)]
		private int lOSObservedPatients;
		[ColumnMapping("LOSAverageStay")]
		private Decimal lOSAverageStay;
		[ColumnMapping("DSM4Axis5Current",StereoType=DataStereoType.FK,ValueForNull=(int)-1)]
		private int dSM4Axis5Current = -1;
		[ColumnMapping("DSM4Axis5Best",StereoType=DataStereoType.FK,ValueForNull=(int)-1)]
		private int dSM4Axis5Best = -1;
		[ColumnMapping("DSM4Axis5Start",StereoType=DataStereoType.FK,ValueForNull=(int)-1)]
		private int dSM4Axis5Start = -1;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;								// the CMS that this event is linked to
		[ColumnMapping("ContactID",StereoType=DataStereoType.FK)]
		private int contactID;							// the Contact ID for the Provider or Facility selected on the Care Resource tab in CMS.  It automatically gets applied to the Event table when the user selects to add a new Resource, thus creating an Event, on the Care Resource tab in CM.
		[ColumnMapping("ResourceType",StereoType=DataStereoType.FK)]
		private int resourceType;
		[ColumnMapping("ProviderInNetwork", ValueForNull=(int)-1)]
		private int providerInNetwork;
		[ColumnMapping("FacilityInNetwork", ValueForNull=(int)-1)]
		private int facilityInNetwork;
		[ColumnMapping("CMSAutoGenerated")]
		private bool cMSAutoGenerated;				// set true when generated from CMS
		[ColumnMapping("AutoGenCMSID",StereoType=DataStereoType.FK)]
		private int autoGenCMSID;					// the CMSID that generated this event
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]						// parent patient
		private int patientId;
		[ColumnMapping("LastValidationDate")]
		private DateTime lastValidationDate;
		[ColumnMapping("ReferToCode")]
		private string referToCode;

		private int statusIDWhenLoaded;				// keeps track of the changes in status

		private int eventTypeIDWhenLoaded;			// keeps track of the changes in eventTypeID
		private DateTime startDateWhenLoaded;		// keeps track of the changes in startDate

		private int providerIDWhenLoaded;
		private int facilityIDWhenLoaded;
		private int providerGroupIDWhenLoaded;

		// track changes in LOS calc result
		private int _los10, _los25, _los50, _los75, _los90, _los95, _los99;
		private string _los10plus, _los25plus, _los50plus, _los75plus, _los90plus, _los99plus;
		private decimal _lOSAverageStay;
		private int _lOSObservedPatients;
		private int _lOSYear;

		protected Exception losCalcEx = null;		// DRG Calculation exception if any
		

		private bool isLinkedToProblem;
		private Contact contact;

		private ClinicalReviewRequestCollection clinicalReviewRequests;
		private PRRequestCollection pRRequests;
		private OutcomeCollection outcomes;
		private EventConsultingProviderCollection eventConsultingProviders;
		private EventReferralDiagnoseCollection eventDiagnoses;
		private EventReferralProcedureCollection eventProcedures;
		private ImageLinkCollection images;

		// cached objects
		private PatientSubscriberLog patSubLog;	// cached patsub log object which
		private PlanSORGLog planSorgLog;	// cached plansorg log object which
		private ProblemEventCollection problemEvents;		
		private ClinicalReviewDecision lastDecision;		// last clinical review decision

		public Event()
		{
			this.providerInNetwork = this.facilityInNetwork = -1;
		}

		public Event(Patient patient, bool initNew) : this()
		{
			//if (patient == null)
			//	throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You can create an event only in the context of a patient");

			if (initNew) // initialize record if requested
				this.NewRecord();
			this.patient = patient;
			if (this.patient != null)
				this.patientId = patient.PatientId;
		}

		public Event(int cMSID) : this()
		{
			this.LoadEventByCMSID(cMSID);
		}

		#region BaseForEventCMSReferral abstract methods overridden

		/// <summary>
		/// Alwas returns EnumERCType.Event.  This class represents an Event.
		/// </summary>
		public override EnumERCType ERCType
		{
			get { return EnumERCType.Event; }
		}

		/// <summary>
		/// Alwas returns EnumERCType.Event.  This class represents an Event.
		/// </summary>
		public override string ERCTypeDisplay
		{
			get { return "@EVENT@"; }
		}

		public override string TypeDisplay
		{
			get { return EventTypeCollection.ActiveEventTypes.Lookup_DescriptionByEventTypeID(this.eventTypeID); }
		}

		public override bool IsLinkedToProblem
		{
			get { return this.isLinkedToProblem; }
			set { this.isLinkedToProblem = value; }		// set after loading
		}

		public override string ERCDescription
		{
			get { return this.description; }
		}

		public override DateTime ERCServiceDate
		{
			get { return this.startDate; }		// The serviceDate seems to be redundant 
		}

		public override DateTime ERCStartDate
		{
			get { return this.startDate; }
		}

		public override DateTime ERCEndDate
		{
			get { return this.endDate; }
		}

		public override string ERCStatusDisplay
		{
			get { return SystemStatusCollection.ActiveSystemStatuses.Lookup_DescriptionByStatusId(this.statusID); }
		}

		public override int ERCStatusID
		{
			get { return this.statusID; }
			set { this.StatusID = value; }
		}

		public override DateTime ERCLastValidationDate
		{
			get { return this.lastValidationDate; }
			set { this.LastValidationDate = value; }
		}

		public override void UpdateLastValidationDate()
		{
			UpdateEventLastValidationDate(this.lastValidationDate);
		}

		public override bool ERCPhysicianReview
		{
			get { return this.physicianReview; }
		}

		public override void SyncDiagnosticCodes(DiagnosticSelectCollection diagnostics)
		{
			this.LoadEventReferralDiagnoses(false);
			this.EventDiagnoses.SyncFromSelections(diagnostics);
			
			this.CalculateLOSData();
			this.CalculateDRGData(this.Patient);

			this.SqlData.EnsureTransaction();
			try
			{
				if (!this.IsNew)
					this.Save();
				this.SaveEventReferralDiagnoses();
				AutoActivity_CodingDxPx(AutoActivityRuleType.CD1, diagnostics);
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}	
		}

		public override void SyncProcedureCodes(ProcedureSelectCollection procedures)
		{
			this.LoadEventProcedures(false);
			this.EventProcedures.SyncFromSelections(procedures);

			this.CalculateLOSData();
			this.CalculateDRGData(this.Patient);

			this.SqlData.EnsureTransaction();
			try
			{
				this.SaveEventReferralProcedures();
				AutoActivity_CodingDxPx(AutoActivityRuleType.CP1, procedures);
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}	
		}

		public override DiagnosticSelectCollection CreateDiagnosticSelectionCollection()
		{
			this.LoadEventReferralDiagnoses(false);
			return this.EventDiagnoses.CreateSelectionCollection();
		}

		public override ProcedureSelectCollection CreateProcedureSelectionCollection()
		{
			this.LoadEventReferralProcedures(false);
			return this.EventProcedures.CreateSelectionCollection();
		}
		
		/// <summary>
		/// Child ProblemEvents mapped to related rows of table ProblemEvent where [EventID] = [EventID]
		/// </summary>
		[SPLoadChild("usp_LoadAllProblemEventLinksByEventId", "eventID", ManuallyManaged=true)]
			//public ProblemEventCollection ProblemEvents
		public override BaseERCProblemLinkCollection ERCProblemLinks
		{
			get { return (BaseERCProblemLinkCollection)this.problemEvents; }
			set
			{
				this.problemEvents = (ProblemEventCollection)value;
				if (value != null)
					value.ParentBaseForEventCMSReferral = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ProblemEvents collection
		/// </summary>
		public override void LoadERCProblemLinks(bool forceReload)
		{
			this.problemEvents = (ProblemEventCollection)ProblemEventCollection.LoadChildCollection("ERCProblemLinks", this, typeof(ProblemEventCollection), problemEvents, forceReload, null);
		}

		/// <summary>
		/// Saves the ProblemEvents collection
		/// </summary>
		public override void SaveERCProblemLinks()
		{
			ProblemEventCollection.SaveChildCollection(this.problemEvents, true);
		}

		/// <summary>
		/// Synchronizes the ProblemEvents collection
		/// </summary>
		public void SynchronizeProblemEvents()
		{
			ProblemEventCollection.SynchronizeChildCollection(((ProblemEventCollection)this.problemEvents), true);
		}
		#endregion

		/// <summary>
		/// Calculate LOS Data
		/// </summary>
		public bool CalculateLOSData()
		{
			this.losCalcEx = null;
			try
			{
				DiagnosticSelectCollection lstDiagnoses = CreateDiagnosticSelectionCollection();
				lstDiagnoses.SortBySequence();
				ProcedureSelectCollection lstProcedures = CreateProcedureSelectionCollection();
				lstProcedures.SortBySequence();

				if (this.PlanSORGLog == null)
				{
					this.losCalcEx = new ActiveAdviceException(AAExceptionAction.None, "No PlanSORGLog linked to event");
					return false;
				}

				// FORK 1.0
				if (lstDiagnoses.CountValidCodes() == 0 && lstProcedures.CountValidCodes() == 0)
				{
					// no warning just set values to 0.
					this.los10 = 0; this.los10plus = null;
					this.los25 = 0; this.los25plus = null;
					this.los50 = 0; this.los50plus = null;
					this.los75 = 0; this.los75plus = null;
					this.los90 = 0; this.los90plus = null;
					this.los95 = 0; this.los95plus = null;
					this.los99 = 0; this.los99plus = null;
					this.lOSAverageStay = 0;
					this.lOSObservedPatients = 0;
					this.lOSYear = 0;
					return true;
				}
				// END FORK 1.0

				LOSData losData = new LOSData();
				losData.CalculateLOSData(this.PlanSORGLog, this.patient, lstDiagnoses, lstProcedures, this.ERCServiceDate, this.newbornGrams);
				losData.GetPercentiles(10, ref this.los10, ref this.los10plus);
				losData.GetPercentiles(25, ref this.los25, ref this.los25plus);
				losData.GetPercentiles(50, ref this.los50, ref this.los50plus);
				losData.GetPercentiles(75, ref this.los75, ref this.los75plus);
				losData.GetPercentiles(90, ref this.los90, ref this.los90plus);
				losData.GetPercentiles(95, ref this.los95, ref this.los95plus);
				losData.GetPercentiles(99, ref this.los99, ref this.los99plus);
				this.lOSAverageStay = (decimal)losData.FAverageStay;
				this.lOSObservedPatients = losData.FObservedPatients;
				this.lOSYear = losData.FLOSYear;
			}
			catch(Exception ex)
			{
				this.losCalcEx = ex;		// just save the exception and continue
				return false;
			}
			return true;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string AltEventID
		{
			get { return this.altEventID; }
			set { this.altEventID = value; }
		}

		[FieldValuesMember("LookupOf_PatientProblems", "ProblemID", "ProblemDescriptionToDisplay")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public override int PrimaryProblemID
		{
			get { return this.primaryProblemID; }
			set { this.primaryProblemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[FieldValuesMember("LookupOf_DateAP", "DateActualProjectedID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int StartDateAP
		{
			get { return this.startDateAP; }
			set { this.startDateAP = value; }
		}

		[ValidatorMember("Vld_EndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[FieldValuesMember("LookupOf_DateAP", "DateActualProjectedID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int EndDateAP
		{
			get { return this.endDateAP; }
			set { this.endDateAP = value; }
		}

		[FieldValuesMember("LookupOf_EventTypeID", "EventTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int EventTypeID
		{
			get { return this.eventTypeID; }
			set { this.eventTypeID = value; }
		}

		/// <summary>
		/// This is exactly the same as public int EventTypeID
		/// Created for CareResourceForm.aspx because of different naming.
		/// </summary>
		[FieldDescription("@SERVICETYPE@")]
		[FieldValuesMember("LookupOf_EventTypeID", "EventTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int ServiceTypeID
		{
			get { return this.eventTypeID; }
			set { this.eventTypeID = value; }
		}

		[FieldValuesMember("LookupOf_StatusID", "StatusId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int StatusID
		{
			get { return this.statusID; }
			set { this.statusID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public DateTime StatusChangeTime
		{
			get { return this.statusChangeTime; }
			set { this.statusChangeTime = value; }
		}

		/// <summary>
		/// String to be displayed for status changed date and user.
		/// </summary>
		public string StatusChangedDisplay
		{
			get { return FormatStatusChangeForDisplay(this.statusChangeTime, this.statusChangedBy); }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[FieldValuesMember("LookupOf_Resolution", "EventResolutionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int Resolution
		{
			get { return this.resolution; }
			set { this.resolution = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int AssignedUserID
		{
			get { return this.assignedUserID; }
			set { this.assignedUserID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int AssignedTeamID
		{
			get { return this.assignedTeamID; }
			set { this.assignedTeamID = value; }
		}

		public string AssignedTeamAndUserDisplay
		{
			get { return FormatTeamAndUserForDisplay( this.assignedTeamID, this.assignedUserID); }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool LateCallIn
		{
			get { return this.lateCallIn; }
			set { this.lateCallIn = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime NotifyDate
		{
			get { return this.notifyDate; }
			set { this.notifyDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string AdmittingDiagnosisType
		{
			get { return this.admittingDiagnosisType; }
			set { this.admittingDiagnosisType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string AdmittingDiagnosisCode
		{
			get { return this.admittingDiagnosisCode; }
			set { this.admittingDiagnosisCode = value; }
		}

		/// <summary>
		/// Returns a user-friendly display string for the admitting diagnostic code type and value.
		/// </summary>
		[ControlType(EnumControlTypes.TextBox)]
		public string AdmittingDiagCodeDisplay
		{
			get 
			{
				return DiagnosticSelectionData.FormatDxPxCodeDisplay(admittingDiagnosisType, admittingDiagnosisCode,  BaseDxPx.DxPxDiagnostic);
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string OTPlanDescription
		{
			get { return this.oTPlanDescription; }
			set { this.oTPlanDescription = value; }
		}

		public override string AdminOtherPlan
		{
			get
			{
				return this.OTPlanDescription;
			}
			set
			{
				this.OTPlanDescription = value;
			}
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int FacilityTypeID
		{
			get { return this.facilityTypeID; }
			set { this.facilityTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int FacilityNetworkStatus
		{
			get { return this.facilityNetworkStatus; }
			set { this.facilityNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=0)]
		public int FacilityID
		{
			get { return this.facilityID; }
			set { this.facilityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int FacilityLocationID
		{
			get { return this.facilityLocationID; }
			set { this.facilityLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=0)]
		public int FacilityNetworkID
		{
			get { return this.facilityNetworkID; }
			set { this.facilityNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=0)]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderNetworkID
		{
			get { return this.providerNetworkID; }
			set { this.providerNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderSpecialtyID
		{
			get { return this.providerSpecialtyID; }
			set { this.providerSpecialtyID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int ProviderNetworkStatus
		{
			get { return this.providerNetworkStatus; }
			set { this.providerNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderGroupID
		{
			get { return this.providerGroupID; }
			set { this.providerGroupID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderGroupTypeID
		{
			get { return this.providerGroupTypeID; }
			set { this.providerGroupTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderGroupLocationID
		{
			get { return this.providerGroupLocationID; }
			set { this.providerGroupLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderGroupNetworkID
		{
			get { return this.providerGroupNetworkID; }
			set { this.providerGroupNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int ProviderGroupNetworkStatus
		{
			get { return this.providerGroupNetworkStatus; }
			set { this.providerGroupNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PCPID
		{
			get { return this.pCPID; }
			set { this.pCPID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PCPSpecialtyID
		{
			get { return this.pCPSpecialtyID; }
			set { this.pCPSpecialtyID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PCPLocationID
		{
			get { return this.pCPLocationID; }
			set { this.pCPLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PCPNetworkID
		{
			get { return this.pCPNetworkID; }
			set { this.pCPNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int PCPNetworkStatus
		{
			get { return this.pCPNetworkStatus; }
			set { this.pCPNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PCPGroupID
		{
			get { return this.pCPGroupID; }
			set { this.pCPGroupID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PCPGroupTypeID
		{
			get { return this.pCPGroupTypeID; }
			set { this.pCPGroupTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PCPGroupLocationID
		{
			get { return this.pCPGroupLocationID; }
			set { this.pCPGroupLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PCPGroupNetworkID
		{
			get { return this.pCPGroupNetworkID; }
			set { this.pCPGroupNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int PCPGroupNetworkStatus
		{
			get { return this.pCPGroupNetworkStatus; }
			set { this.pCPGroupNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int RefProviderID
		{
			get { return this.refProviderID; }
			set { this.refProviderID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int RefProviderSpecialtyID
		{
			get { return this.refProviderSpecialtyID; }
			set { this.refProviderSpecialtyID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int RefProviderLocationID
		{
			get { return this.refProviderLocationID; }
			set { this.refProviderLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int RefProviderNetworkID
		{
			get { return this.refProviderNetworkID; }
			set { this.refProviderNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int RefProviderNetworkStatus
		{
			get { return this.refProviderNetworkStatus; }
			set { this.refProviderNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int RefProviderGroupID
		{
			get { return this.refProviderGroupID; }
			set { this.refProviderGroupID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int RefProviderGroupTypeID
		{
			get { return this.refProviderGroupTypeID; }
			set { this.refProviderGroupTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@GROUPLOCATION@")]
		public int RefProviderGroupLocationID
		{
			get { return this.refProviderGroupLocationID; }
			set { this.refProviderGroupLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@GROUPNETWORK@")]
		public int RefProviderGroupNetworkID
		{
			get { return this.refProviderGroupNetworkID; }
			set { this.refProviderGroupNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int RefProviderGroupNetworkStatus
		{
			get { return this.refProviderGroupNetworkStatus; }
			set { this.refProviderGroupNetworkStatus = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool PhysicianReview
		{
			get { return this.physicianReview; }
			set { this.physicianReview = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool MaternityEvent
		{
			get { return this.maternityEvent; }
			set { this.maternityEvent = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime Maternity1stPreVisit
		{
			get { return this.maternity1stPreVisit; }
			set { this.maternity1stPreVisit = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MaternityPostpartumVisit
		{
			get { return this.maternityPostpartumVisit; }
			set { this.maternityPostpartumVisit = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MaternityLMPDate
		{
			get { return this.maternityLMPDate; }
			set { this.maternityLMPDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MaternityEDCDate
		{
			get { return this.maternityEDCDate; }
			set { this.maternityEDCDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MaternityCalcGestation
		{
			get { return this.maternityCalcGestation; }
			set { this.maternityCalcGestation = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MaternityNumBabiesExp
		{
			get { return this.maternityNumBabiesExp; }
			set { this.maternityNumBabiesExp = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MaternityGravida
		{
			get { return this.maternityGravida; }
			set { this.maternityGravida = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MaternityPara
		{
			get { return this.maternityPara; }
			set { this.maternityPara = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MaternityEctopic
		{
			get { return this.maternityEctopic; }
			set { this.maternityEctopic = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MaternityAB
		{
			get { return this.maternityAB; }
			set { this.maternityAB = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ParentEventID
		{
			get { return this.parentEventID; }
			set { this.parentEventID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool NewbornEvent
		{
			get { return this.newbornEvent; }
			set { this.newbornEvent = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ClonedBaby
		{
			get { return this.clonedBaby; }
			set { this.clonedBaby = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool DischSameMom
		{
			get { return this.dischSameMom; }
			set { this.dischSameMom = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NewbornGestate
		{
			get { return this.newbornGestate; }
			set { this.newbornGestate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NewbornLBS
		{
			get { return this.newbornLBS; }
			set { this.newbornLBS = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NewbornOz
		{
			get { return this.newbornOz; }
			set { this.newbornOz = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NewbornGrams
		{
			get { return this.newbornGrams; }
			set { this.newbornGrams = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal NewbornLength
		{
			get { return this.newbornLength; }
			set { this.newbornLength = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NewbornAPGAR1Min
		{
			get { return this.newbornAPGAR1Min; }
			set { this.newbornAPGAR1Min = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NewbornAPGAR5Mins
		{
			get { return this.newbornAPGAR5Mins; }
			set { this.newbornAPGAR5Mins = value; }
		}

		[FieldValuesMember("LookupOf_DRGType", "CodeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, MaxLength=4)]
		public override string DrgType
		{
			get { return this.drgType; }
			set { this.drgType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public override string DrgVersion
		{
			get { return this.drgVersion; }
			set { this.drgVersion = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public override string DrgCode
		{
			get { return this.drgCode; }
			set { this.drgCode = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LOSPayorGroup
		{
			get { return this.lOSPayorGroup; }
			set { this.lOSPayorGroup = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LOSRegion
		{
			get { return this.lOSRegion; }
			set { this.lOSRegion = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LOSYear
		{
			get { return this.lOSYear; }
			set { this.lOSYear = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los10
		{
			get { return this.los10; }
			set { this.los10 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los10plus
		{
			get { return this.los10plus; }
			set { this.los10plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los25
		{
			get { return this.los25; }
			set { this.los25 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los25plus
		{
			get { return this.los25plus; }
			set { this.los25plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los50
		{
			get { return this.los50; }
			set { this.los50 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los50plus
		{
			get { return this.los50plus; }
			set { this.los50plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los75
		{
			get { return this.los75; }
			set { this.los75 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los75plus
		{
			get { return this.los75plus; }
			set { this.los75plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los90
		{
			get { return this.los90; }
			set { this.los90 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los90plus
		{
			get { return this.los90plus; }
			set { this.los90plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los95
		{
			get { return this.los95; }
			set { this.los95 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los95plus
		{
			get { return this.los95plus; }
			set { this.los95plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Los99
		{
			get { return this.los99; }
			set { this.los99 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string Los99plus
		{
			get { return this.los99plus; }
			set { this.los99plus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ServiceDate
		{
			get { return this.serviceDate; }
			set { this.serviceDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public override int PatientSubscriberLogID
		{
			get { return this.patientSubscriberLogID; }
			set 
			{ 
				this.patientSubscriberLogID = value; 
				this.patSubLog = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public override int PlanSORGLogID
		{
			get { return this.planSorgLogID; }
			set 
			{ 
				this.planSorgLogID = value;
				this.planSorgLog = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime Newborn1stPedVisit
		{
			get { return this.newborn1stPedVisit; }
			set { this.newborn1stPedVisit = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NewbornDCCondition
		{
			get { return this.newbornDCCondition; }
			set { this.newbornDCCondition = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LOSObservedPatients
		{
			get { return this.lOSObservedPatients; }
			set { this.lOSObservedPatients = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal LOSAverageStay
		{
			get { return this.lOSAverageStay; }
			set { this.lOSAverageStay = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int,ValueForNull=-1)]
		public int DSM4Axis5Current
		{
			get { return this.dSM4Axis5Current; }
			set { this.dSM4Axis5Current = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int,ValueForNull=-1)]
		public int DSM4Axis5Best
		{
			get { return this.dSM4Axis5Best; }
			set { this.dSM4Axis5Best = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int,ValueForNull=-1)]
		public int DSM4Axis5Start
		{
			get { return this.dSM4Axis5Start; }
			set { this.dSM4Axis5Start = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ContactID
		{
			get { return this.contactID; }
			set 
			{ 
				this.contactID = value; 
				this.contact = null;
			}
		}

		#region Contact
		public Contact Contact
		{
			get 
			{ 
				if(this.contactID < 1)
					return null;
				if(this.contact == null);
				{
					Contact c = new Contact();
					if(c.Load(this.contactID))
						this.contact = c;
				}
				return this.contact;
			}
			set 
			{
				this.contact = value;
				this.contactID = value == null ? 0 : value.ContactID;
			}
		}

		public string ContactName
		{
			get { return Contact == null ? string.Empty : Contact.Name; }
		}
		#endregion

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ResourceType
		{
			get { return this.resourceType; }
			set { this.resourceType = value; }
		}
		
		[FieldValuesMember("LookupOf_NetworkStatus")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)-1)]
		public int ProviderInNetwork
		{	//"1 - In Network; 0 - Out Network; -1(NULL) - Not specified"
			get { return this.providerInNetwork; }
			set { this.providerInNetwork = value; }
		}

		[FieldValuesMember("LookupOf_NetworkStatus")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)-1)]
		public int FacilityInNetwork
		{	//"1 - In Network; 0 - Out Network; -1(NULL) - Not specified"
			get { return this.facilityInNetwork; }
			set { this.facilityInNetwork = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool CMSAutoGenerated
		{
			get { return this.cMSAutoGenerated; }
			set { this.cMSAutoGenerated = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AutoGenCMSID
		{
			get { return this.autoGenCMSID; }
			set { this.autoGenCMSID = value; }
		}

		[FieldValuesMember("LookupOf_EventSourceID", "EventSourceID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int EventSourceID
		{
			get { return this.eventSourceID; }
			set { this.eventSourceID = value; }
		}

		[GenericScript("LengthOfStayDisplay", "@EndDate@==null ? DiffDays(@StartDate@, new Date()) : DiffDays(@StartDate@, @EndDate@)")]
		public string LengthOfStayDisplay
		{
			get 
			{ 
				if (this.startDate == DateTime.MinValue)
					return "";
				if (this.endDate == DateTime.MinValue)
					return (DateTime.Today - this.startDate).Days.ToString();
				else
					return (this.endDate - this.startDate).Days.ToString();
			}
		}

		#region Lookups
		public DRGTypeCollection LookupOf_DRGType
		{
			get
			{
				return DRGTypeCollection.ActiveDRGTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public EventResolutionCollection LookupOf_Resolution
		{
			get
			{
				return EventResolutionCollection.ActiveEventResolutions; // Acquire a shared instance from the static member of collection
			}
		}

		public EventTypeCollection LookupOf_EventTypeID
		{
			get
			{
				return EventTypeCollection.ActiveEventTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public EventSourceCollection LookupOf_EventSourceID
		{
			get
			{
				return EventSourceCollection.ActiveEventSources; // Acquire a shared instance from the static member of collection
			}
		}

		public SystemStatusCollection LookupOf_StatusID
		{
			get
			{
				return SystemStatusCollection.ActiveSystemStatuses; // Acquire a shared instance from the static member of collection
			}
		}

		public DateActualProjectedCollection LookupOf_DateAP
		{
			get
			{
				return DateActualProjectedCollection.ActiveDateActualProjectedCodes; // Acquire a shared instance from the static member of collection
			}
		}

		public object[,] LookupOf_NetworkStatus
		{
			get
			{
				return base.ValuesOf_NetworkStatuses; // Acquire a shared instance from the static member of collection
			}
		}
		#endregion

		/// <summary>
		/// The collection lookup method that returns all the linked problems for the
		/// patient of this event.
		/// </summary>
		public ProblemCollection LookupOf_PatientProblems
		{
			get
			{
				if (this.patient == null)
					return null;

				return this.patient.GetLinkedProblems();
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);
		}

		protected override void InitializeToTrackChanges()
		{
			base.InitializeToTrackChanges();
			// track the change of statusID.
			this.eventTypeIDWhenLoaded = this.eventTypeID;
			this.statusIDWhenLoaded = this.statusID;
			this.startDateWhenLoaded = this.startDate;

			// duplicate checking should also occur also when these change
			this.providerIDWhenLoaded = this.providerID;
			this.facilityIDWhenLoaded = this.facilityID;
			this.providerGroupIDWhenLoaded = this.providerGroupID;

			// track changes to LOS results
			this._los10 = los10;
			this._los25 = los25;
			this._los50 = los50;
			this._los75 = los75;
			this._los90 = los90;
			this._los95 = los95;
			this._los99 = los99;
			this._los10plus = los10plus;
			this._los25plus = los25plus;
			this._los50plus = los50plus;
			this._los75plus = los75plus;
			this._los90plus = los90plus;
			this._los99plus = los99plus;
			this._lOSAverageStay = lOSAverageStay;
			this._lOSObservedPatients = lOSObservedPatients;
			this._lOSYear = lOSYear;
		}

		public bool LOSResultChanged
		{
			get
			{
				// track changes to LOS results
				return this._los10 != los10 
					|| this._los25 != los25
					|| this._los50 != los50
					|| this._los75 != los75
					|| this._los90 != los90
					|| this._los95 != los95
					|| this._los99 != los99
					|| this._los10plus != los10plus
					|| this._los25plus != los25plus
					|| this._los50plus != los50plus
					|| this._los75plus != los75plus
					|| this._los90plus != los90plus
					|| this._los99plus != los99plus
					|| this._lOSAverageStay != lOSAverageStay
					|| this._lOSObservedPatients != lOSObservedPatients
					|| this._lOSYear != lOSYear;
			}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			writer.AddFieldsSubstituted(this, "@ID@-@Description@", "@EVENT@");
			writer.AddField(this, "StartDate");
			writer.AddField(this, "EndDate");
		}

		public bool StartDateChanged
		{
			get
			{
				return this.startDateWhenLoaded != this.startDate;
			}
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Link to or unlink from the given problem.
		/// If linkUnlink = true, link problem to this ERC.
		/// If linkUnlink = false, unklink problem from this ERC.
		/// Called by PatientSummary when Problem is linked.
		/// </summary>
		/// <param name="problem"></param>
		/// <param name="linkUnlink"></param>
		public override void LinkToProblem(Problem problem, bool linkUnlink)
		{
			if (this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "New event cannot be linked or unlinked!");
			if (problem.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "New problem cannot be linked or unlinked!");

			if (problem.ProblemID == this.primaryProblemID)
				if (!linkUnlink)
					throw new ActiveAdviceException(AAExceptionAction.None, "@CANTUNLINKPRIMARYPROBLEM@");

			// Ensure problem-event link
			ProblemEvent problemEvent = new ProblemEvent(this.patientId, problem.ProblemID, this.eventID);
			problemEvent.SqlData.Transaction = this.SqlData.Transaction;
			if (problemEvent.ProblemEventExists())		// linked
			{
				if (!linkUnlink)	// if unlink is requested
				{					// delete
					problemEvent.Delete(problemEvent.ProblemId, problemEvent.EventID);
				}
			}
			else		// not linked
			{
				if (linkUnlink)		// if link is requrested
				{
					problemEvent.MarkNew();
					problemEvent.Save();		// create the link
				}
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// �	Check to make sure that the End Date has been specified if the status of the event is Closed.
			if (this.StatusCode == SystemStatus.CLOSED)
				if (this.endDate == DateTime.MinValue)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "@ENDDATEREQFORCLOS@");

			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			bool initialSave = this.IsNew;
			bool statusChanged = false;
			if (this.IsNew || this.statusID != this.statusIDWhenLoaded)
			{
				// status changed.
				this.SetStatusChangingUser();
				statusChanged  = true;
			}

			base.InternalSave();

			// Save the child collections here.

			// save child tables that are managed in-memory
			// Save all clinical review requests if any
			
			PatientCoverage patCov = null;
			if (this.PatientSubscriberLog != null)
				patCov = this.PatientSubscriberLog.PatientCoverage;

			autoActivityManager = new AutoActivityManager(this.Patient, patCov, null, this);	// decisions also use this autoactivity manager.

			this.SaveClinicalReviewRequests();

			#region Trigger AutoActivities - ES1, ER3, ER4
			
			if (initialSave)
				AutoActivity_EventInitialSave();	// ES1

			// BR01.2.18	When an event is closed that has open activities associated with it, 
			// the System shall evaluate Closing Event and Closing Event with Open Activities 
			// rules and exceptions.

			// is closing?
			if (statusChanged && this.StatusCode == SystemStatus.CLOSED)		// the event can be closed when created!
			{
				AutoActivity_EventClosingEvent();	// ER3
				// If the event is not new, check if the event has any open activities.
				if (!initialSave && HasEventOpenActivities())
					AutoActivity_EventClosingEventWithOpenActivities();	// ER4
			}

			#endregion
		}

		// Event can't be loaded without a patient!!
		/*/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eventID)
		{
			return base.Load(eventID);
		}*/

		/// <summary>
		/// Event can't be loaded without a patient!!
		/// Load an event and also establish the in-memory relationship to its parent patient.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="eventID"></param>
		/// <returns></returns>
		public bool Load(Patient patient, int eventID)
		{
			this.patient = patient;
			if (this.patient != null)
				this.patientId = patient.PatientId;
			return Load(eventID);
		}

		/// <summary>
		/// If you load the event without patient, you won't be able to save and do some other tasks
		/// that require patient-contex.
		/// </summary>
		/// <param name="eventID"></param>
		/// <returns></returns>
		public bool LoadWithoutPatient(int eventID)
		{
			this.patient = null;
			return Load(eventID);
		}

		/// <summary>
		/// Load the most recent event in the database for this patient.
		/// </summary>
		public bool LoadMostRecentEventForPatient(Patient patient)
		{
			this.patient = patient;
			this.patientId = patient.PatientId;

			return SqlData.SPExecReadObj("usp_GetMostRecentEventForPatient", this, false, new object[] { patientId });
		}

		public override bool LoadERC(int ercID)
		{
			return Load(this.patient, ercID);
		}

		/// <summary>
		/// Save method for a new event.
		/// This method must be used only when a new event is to created
		/// in the context of an existing patient, patient-subscriber-coverage and problem
		/// </summary>
		/// <param name="patCov"></param>
		public void Save(PatientCoverage patCov, Problem problem)
		{
			this.autoActivityManager = null;

			if (!this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Event.Save(problem) can be called only for a new event");

			if (this.Patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "A new event can be saved only in the context of a patient");

			if (patCov == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "A new event can be saved in the context of a patient-subscriber-coverage");

			if (problem == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "The problem passed to the Event.Save(problem) was null");

			if (problem.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "The problem passed to the Event.Save(problem) is new.  It must exist in the db!");

			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				// Create the PatientSubscriberLogID and the PlanSORGLogID that associates this event to 
				// the latest log entries.

				PlanSORGLog lastPlanSORGLog = PlanSORGLog.GetLastPlanSORGLogEntry(this.SqlData.Transaction, patCov.Plan, patCov.SORG);
				if (lastPlanSORGLog == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI,
						"No plan-sorg-log entry found for PlanID={0}, SORGID={1}", patCov.PlanID, patCov.SORGID);
				this.planSorgLogID = lastPlanSORGLog.PlanSorgLogId;

				PatientSubscriberLog lastPatSubLog = PatientSubscriberLog.GetLastPatientSubscriberLogEntry(this.SqlData.Transaction, patient, patCov);
				if (lastPatSubLog == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI,
						"No patient-subscriber-log entry found for PatientID={0}, PatientCoverageID={1}", patient.PatientId, patCov.PatientCoverageID);
				this.patientSubscriberLogID = lastPatSubLog.PatientSubscriberLogId;

				base.Save();

				// Create the Problem - Event link
				ProblemEvent problemEvent = new ProblemEvent(patient, problem, this);
				problemEvent.SqlData.Transaction = this.SqlData.Transaction;
				problemEvent.Save();

				this.primaryProblemID = problem.ProblemID;

				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// ES1	- Event Initial Save
		/// This is triggered when the event is saved the first time by an insertion.
		/// </summary>
		public void AutoActivity_EventInitialSave()
		{
			autoActivityManager.Execute(AutoActivityRuleType.ES1, this.SqlData.Transaction);
		}

		/// <summary>
		/// ER3	- Closing Event
		/// This is triggered when the event is saved with closed status.
		/// </summary>
		public void AutoActivity_EventClosingEvent()
		{
			autoActivityManager.Execute(AutoActivityRuleType.ER3, this.SqlData.Transaction);
		}

		/// <summary>
		/// ER4	- Closing Event with Open Activities
		/// This is triggered when the event is saved with closed status.
		/// </summary>
		public void AutoActivity_EventClosingEventWithOpenActivities()
		{
			autoActivityManager.Execute(AutoActivityRuleType.ER4, this.SqlData.Transaction);
		}

		public AutoActivityManager EnsureAutoActivityManager()
		{
			if (this.autoActivityManager == null)
			{
				if (this.PatientSubscriberLog != null)
                    autoActivityManager = new AutoActivityManager(this.Patient, this.PatientSubscriberLog.PatientCoverage, this.GetPrimaryProblem(), this);
			}
			return this.autoActivityManager;
		}

		/// <summary>
		/// Save method for an existing event.
		/// When an existing event is saved, no links get created.  So we don't need Problem or CMS context.
		/// Checks if there's a link to the primary problem and if not, creates one in the context of the given patient.
		/// </summary>
		public new void Save()
		{
			this.autoActivityManager = null;

			if (this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You must save a new event only in the context of a Problem or a CMS");

			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI,
					"You must save an existing event only in the context of a patient");

			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();

				if (this.primaryProblemID != 0)
				{
					// Ensure problem-event link
					ProblemEvent problemEvent = new ProblemEvent(patient.PatientId, this.primaryProblemID, this.eventID);
					problemEvent.SqlData.Transaction = this.SqlData.Transaction;
					if (!problemEvent.ProblemEventExists())
					{
						problemEvent.MarkNew();
						problemEvent.SqlData.Transaction = this.SqlData.Transaction;
						problemEvent.Save();
					}
				}

				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent EventCollection that contains this element
		/// </summary>
		public EventCollection ParentEventCollection
		{
			get
			{
				return this.parentEventCollection;
			}
			set
			{
				this.parentEventCollection = value; // parent is set when added to a collection
			}
		}

		public bool HasClinicalRequests
		{
			get
			{
				return (this.clinicalReviewRequests != null) && (this.clinicalReviewRequests.Count > 0);
			}
		}

		/// <summary>
		/// Child ClinicalReviewRequests mapped to related rows of table ClinicalReviewRequest where [EventID] = [EventID]
		/// </summary>
		[SPLoadChild("usp_LoadEventClinicalReviewRequests", "eventID")]
		public ClinicalReviewRequestCollection ClinicalReviewRequests
		{
			get { return this.clinicalReviewRequests; }
			set
			{
				this.clinicalReviewRequests = value;
				if (value != null)
					value.ParentEvent = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ClinicalReviewRequests collection
		/// </summary>
		public void LoadClinicalReviewRequests(bool forceReload)
		{
			this.clinicalReviewRequests = (ClinicalReviewRequestCollection)ClinicalReviewRequestCollection.LoadChildCollection("ClinicalReviewRequests", this, typeof(ClinicalReviewRequestCollection), clinicalReviewRequests, forceReload, null);
		}

		/// <summary>
		/// Saves the ClinicalReviewRequests collection
		/// </summary>
		public void SaveClinicalReviewRequests()
		{
			ClinicalReviewRequestCollection.SaveChildCollection(this.clinicalReviewRequests, true);
		}

		/// <summary>
		/// Synchronizes the ClinicalReviewRequests collection
		/// </summary>
		public void SynchronizeClinicalReviewRequests()
		{
			ClinicalReviewRequestCollection.SynchronizeChildCollection(this.clinicalReviewRequests, true);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public override int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		/// <summary>
		/// Event Status checks are performed against this property.
		/// Example:
		///		if (eventObj.StatusCode == 
		/// </summary>
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public string StatusCode
		{
			get { return SystemStatusCollection.ActiveSystemStatuses.Lookup_CodeByStatusId(this.statusID); }
			set { this.statusID = SystemStatusCollection.ActiveSystemStatuses.Lookup_StatusIdByCode(value); }
		}

		/// <summary>
		/// Child PRRequests mapped to related rows of table PRRequest where [EventID] = [EventID]
		/// </summary>
		[SPLoadChild("", "eventID")] // Custom: usp_LoadEventPRRequests
		public override PRRequestCollection PRRequests
		{
			get { return this.pRRequests; }
			set
			{
				this.pRRequests = value;
				if (value != null)
					value.ParentEvent = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PRRequests collection
		/// </summary>
		public override void LoadPRRequests(bool forceReload)
		{
			this.pRRequests = (PRRequestCollection)PRRequestCollection.LoadChildCollection("PRRequests", "usp_LoadEventPRRequests", this, typeof(PRRequestCollection), pRRequests, forceReload, null);
		}

		/// <summary>
		/// Saves the PRRequests collection
		/// </summary>
		public override void SavePRRequests()
		{
			PRRequestCollection.SaveChildCollection(this.pRRequests, true);
		}

		/// <summary>
		/// Synchronizes the PRRequests collection
		/// </summary>
		public void SynchronizePRRequests()
		{
			PRRequestCollection.SynchronizeChildCollection(this.pRRequests, true);
		}

		/// <summary>
		/// Child Outcomes mapped to related rows of table Outcome where [EventID] = [EventID]
		/// </summary>
		[SPLoadChild("usp_LoadEventOutcomes", "eventID")]
		public override OutcomeCollection Outcomes
		{
			get { return this.outcomes; }
			set
			{
				this.outcomes = value;
				if (value != null)
					value.ParentEvent = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Outcomes collection
		/// </summary>
		public override void LoadOutcomes(bool forceReload)
		{
			this.outcomes = (OutcomeCollection)OutcomeCollection.LoadChildCollection("Outcomes", this, typeof(OutcomeCollection), outcomes, forceReload, null);
		}

		/// <summary>
		/// Saves the Outcomes collection
		/// </summary>
		public override void SaveOutcomes()
		{
			OutcomeCollection.SaveChildCollection(this.outcomes, true);
		}

		/// <summary>
		/// Synchronizes the Outcomes collection
		/// </summary>
		public void SynchronizeOutcomes()
		{
			OutcomeCollection.SynchronizeChildCollection(this.outcomes, true);
		}


		#region Images Overriden
		/// <summary>
		/// Child Outcomes mapped to related rows of table Outcome where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadEventImages", "eventID")]
		public override ImageLinkCollection Images
		{
			get { return this.images; }
			set
			{
				this.images = value;
				if (value != null)
					value.ParentEvent = this; // set this as a parent of the child collection
			}
		}
				
		/// <summary>
		/// Loads the Outcomes collection
		/// </summary>
		public override void LoadImages(bool forceReload)
		{
			this.images = (ImageLinkCollection)ImageLinkCollection.LoadChildCollection("Images", this, typeof(ImageLinkCollection), images, forceReload, null);
		}

		/// <summary>
		/// Saves the Outcomes collection
		/// </summary>
		public override void SaveImages()
		{
			ImageLinkCollection.SaveChildCollection(this.images, true);
		}

		/// <summary>
		/// Synchronizes the Outcomes collection
		/// </summary>
		public void SynchronizeImages()
		{
			ImageLinkCollection.SynchronizeChildCollection(this.images, true);
		}

		#endregion


		/// <summary>
		/// Child EventConsultingProviders mapped to related rows of table EventConsultingProvider where [EventID] = [EventID]
		/// </summary>
		[SPLoadChild("usp_LoadEventConsultingProviders", "eventID")]
		public EventConsultingProviderCollection EventConsultingProviders
		{
			get { return this.eventConsultingProviders; }
			set
			{
				this.eventConsultingProviders = value;
				if (value != null)
					value.ParentEvent = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the EventConsultingProviders collection
		/// </summary>
		public void LoadEventConsultingProviders(bool forceReload)
		{
			this.eventConsultingProviders = (EventConsultingProviderCollection)EventConsultingProviderCollection.LoadChildCollection("EventConsultingProviders", this, typeof(EventConsultingProviderCollection), eventConsultingProviders, forceReload, null);
		}

		/// <summary>
		/// Saves the EventConsultingProviders collection
		/// </summary>
		public void SaveEventConsultingProviders()
		{
			EventConsultingProviderCollection.SaveChildCollection(this.eventConsultingProviders, true);
		}

		/// <summary>
		/// Synchronizes the EventConsultingProviders collection
		/// </summary>
		public void SynchronizeEventConsultingProviders()
		{
			EventConsultingProviderCollection.SynchronizeChildCollection(this.eventConsultingProviders, true);
		}

		/// <summary>
		/// Child EventDiagnoses mapped to related rows of table EventReferralDiagnose where [EventID] = [EventID]
		/// </summary>
		[SPLoadChild("usp_LoadEventDiagnoses", "eventID")]
		public EventReferralDiagnoseCollection EventDiagnoses
		{
			get { return this.eventDiagnoses; }
			set
			{
				this.eventDiagnoses = value;
				if (value != null)
					value.ParentEvent = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the EventDiagnoses collection
		/// </summary>
		public void LoadEventDiagnoses(bool forceReload)
		{
			this.eventDiagnoses = (EventReferralDiagnoseCollection)EventReferralDiagnoseCollection.LoadChildCollection("EventDiagnoses", this, typeof(EventReferralDiagnoseCollection), eventDiagnoses, forceReload, null);
		}

		public override EventReferralDiagnoseCollection EventReferralDiagnoses
		{
			get { return this.EventDiagnoses; }
			set { this.EventDiagnoses = value; }
		}

		/// <summary>
		/// Loads the EventDiagnoses collection
		/// </summary>
		public override void LoadEventReferralDiagnoses(bool forceReload)
		{
			LoadEventDiagnoses(false);
		}

		/// <summary>
		/// Saves the EventDiafgnoses collection
		/// </summary>
		public void SaveEventDiagnoses()
		{
			EventReferralDiagnoseCollection.SaveChildCollection(this.eventDiagnoses, true);
		}

		/// <summary>
		/// Saves the EventDiagnoses collection
		/// </summary>
		public override void SaveEventReferralDiagnoses()
		{
			SaveEventDiagnoses();
		}

		/// <summary>
		/// Synchronizes the EventDiagnoses collection
		/// </summary>
		public void SynchronizeEventDiagnoses()
		{
			EventReferralDiagnoseCollection.SynchronizeChildCollection(this.eventDiagnoses, true);
		}

		/// <summary>
		/// Child EventProcedures mapped to related rows of table EventReferralProcedure where [EventID] = [EventID]
		/// </summary>
		[SPLoadChild("usp_LoadEventProcedures", "eventID")]
		public EventReferralProcedureCollection EventProcedures
		{
			get { return this.eventProcedures; }
			set
			{
				this.eventProcedures = value;
				if (value != null)
					value.ParentEvent = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the EventProcedures collection
		/// </summary>
		public void LoadEventProcedures(bool forceReload)
		{
			this.eventProcedures = (EventReferralProcedureCollection)EventReferralProcedureCollection.LoadChildCollection("EventProcedures", this, typeof(EventReferralProcedureCollection), eventProcedures, forceReload, null);
		}

		public override EventReferralProcedureCollection EventReferralProcedures
		{
			get { return this.EventProcedures; }
			set { this.EventProcedures = value; }
		}

		/// <summary>
		/// Loads the EventProcedures collection
		/// </summary>
		public override void LoadEventReferralProcedures(bool forceReload)
		{
			this.eventProcedures = (EventReferralProcedureCollection)EventReferralProcedureCollection.LoadChildCollection("EventProcedures", this, typeof(EventReferralProcedureCollection), eventProcedures, forceReload, null);
		}

		/// <summary>
		/// Saves the EventProcedures collection
		/// </summary>
		public void SaveEventProcedures()
		{
			EventReferralProcedureCollection.SaveChildCollection(this.eventProcedures, true);
		}

		/// <summary>
		/// Saves the EventProcedures collection
		/// </summary>
		public override void SaveEventReferralProcedures()
		{
			EventReferralProcedureCollection.SaveChildCollection(this.eventProcedures, true);
		}

		/// <summary>
		/// Synchronizes the EventProcedures collection
		/// </summary>
		public void SynchronizeEventProcedures()
		{
			EventReferralProcedureCollection.SynchronizeChildCollection(this.eventProcedures, true);
		}

		/// <summary>
		/// Determines whether the event already exists based on the following fields:
		///	   patientID,             (implicit rule)
		///    eventTypeID, 
		///    providerID, 
		///    facilityID, 
		///    providerGroupID, 
		///    startDate
		/// The current can be excluded from the check.  For instance,
		/// if there's only one event with those fields in the database, 
		/// and excludingThis = true, this function
		/// will return false.
		/// </summary>
		public bool ExistsEvent(bool excludingThis)
		{
			if (excludingThis)
			{
				// The direct call to the stored procedure will pass eventID
				// of this event for exclusion from the check.
				return Convert.ToBoolean( SqlData.SPExecScalar("usp_ExistsEvent", this, false) );
			}
			else
			{
				// pass eventID = DBNull so that it won't exclude this event from the check.
				return Convert.ToBoolean(
					SqlData.SPExecScalar("usp_ExistsEvent", this, false, 
					new string[] {"eventID"},
					new object[] { DBNull.Value } ) 
					);
			}

		}

		/// <summary>
		/// Returns true if the event is duplicate in the database.
		/// 
		/// This is a specialized version of ExistsEvent(bool excludingThis).
		/// This method uses calls ExistsEvent with excludingThis=true, thus
		/// excluding this event from check.
		/// </summary>
		/// <returns></returns>
		public bool DuplicateCheck()
		{
			// Duplicate checking must occur only if the record is new,
			// or at least one of the following fields was changed.
			if (this.IsNew ||
				this.eventTypeIDWhenLoaded != this.eventTypeID ||
				this.startDateWhenLoaded != this.startDate ||
				this.providerIDWhenLoaded != this.providerID ||
				this.facilityIDWhenLoaded != this.facilityID ||
				this.providerGroupIDWhenLoaded != this.providerGroupID)
				return ExistsEvent(true);
			else
				return false;
		}

		/// <summary>
		/// Load possible duplicate events for this event in the context of the patient.
		///	The duplicate events are the ones whose following fields match:
		///    patientID,             (implicit rule)
		///    eventTypeID, 
		///    providerID, 
		///    facilityID, 
		///    providerGroupID, 
		///    startDate
		/// and whose eventID is not the same as the given event's.
		/// </summary>
		/// <returns></returns>
		public EventCollection GetPossibleDuplicateEvents()
		{
			EventCollection col = new EventCollection();
			// testing
			//col.AddRecord(this);
			//return col;
			col.LoadPossibleDuplicateEvents(this);
			if (col.Count > 0)
				return col;
			else
				return null;
		}

		/// <summary>
		/// Loads and retuns the linked patient subscriber log entry
		/// </summary>
		/// <returns></returns>
		public PatientSubscriberLog GetPatientSubscriberLog()
		{
			if (this.patientSubscriberLogID == 0)
				return null;
			PatientSubscriberLog patSubLog = new PatientSubscriberLog();
			patSubLog.SqlData.Transaction = this.SqlData.Transaction;
			if (patSubLog.Load(this.patientSubscriberLogID))
				return patSubLog;
			else
				return null;
		}

		/// <summary>
		/// Returns the loaded and cached patient subscriber log entry
		/// </summary>
		public override PatientSubscriberLog PatientSubscriberLog
		{
			get
			{
				if (this.patSubLog == null)
					this.patSubLog = GetPatientSubscriberLog();
				return this.patSubLog;
			}
		}

		/// <summary>
		/// Returns the loaded and cached plan sorg log entry
		/// </summary>
		public override PlanSORGLog PlanSORGLog
		{
			get
			{
				if (this.planSorgLog == null)
					this.planSorgLog = GetPlanSorgLog();
				return this.planSorgLog;
			}
		}

		/// <summary>
		/// Loads and retuns the linked plan sorg log entry
		/// </summary>
		/// <returns></returns>
		public PlanSORGLog GetPlanSorgLog()
		{
			if (this.planSorgLogID == 0)
				return null;
			PlanSORGLog planSorgLog = new PlanSORGLog();
			planSorgLog.SqlData.Transaction = this.SqlData.Transaction;
			if (planSorgLog.Load(this.planSorgLogID))
				return planSorgLog;
			else
				return null;
		}

		/// <summary>
		/// Loads and retuns the linked patient
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientId == 0)
				return null;
			Patient patient = new Patient();
			patient.SqlData.Transaction = this.SqlData.Transaction;
			if (patient.Load(this.patientId))
				return patient;
			else
				return null;
		}

		/// <summary>
		/// Sets/Returns the Patient linked to event
		/// All operations that require patient context use this object.
		/// </summary>
		public Patient Patient
		{
			get 
			{ 
				//return os.GetBy(typeof(patient), this.patientId);
				if (patient == null)
					patient = this.GetPatient();
				return patient;
			}
			set { this.patient = value;	}
		}

		/// <summary>
		/// Returns the SORG of the patient subscriber log entry
		/// </summary>
		public override Organization SORG
		{
			get 
			{ 
				PatientSubscriberLog patSubLog = this.PatientSubscriberLog;
				if (patSubLog == null)
					return null;
				return patSubLog.SORG;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime LastValidationDate
		{
			get { return this.lastValidationDate; }
			set { this.lastValidationDate = value; }
		}

		/// <summary>
		/// Updates the last coverage validation date of this event
		/// and also sets the instance member lastValidationDate to the given date.
		/// </summary>
		public void UpdateEventLastValidationDate(System.DateTime lastValidationDate)
		{
			SqlData.SPExecNonQuery("usp_UpdateEventLastValidationDate", 
				new object[] { this.eventID, SQLDataDirect.MakeDBValue(lastValidationDate) });
			this.lastValidationDate = lastValidationDate;
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.startDate = DateTime.Today;
			this.notifyDate = DateTime.Today;
			this.serviceDate = DateTime.Today;
			this.StartDateAPCode = DateActualProjected.ACTUAL;
			this.EndDateAPCode = DateActualProjected.ACTUAL;
			this.StatusCode = SystemStatus.OPEN;
			this.assignedUserID = AASecurityHelper.GetUserId;
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadEventByCMSID(int cMSID)
		{
			return SqlData.SPExecReadObj("usp_GetEventByCMSID", this, false, new object[] { cMSID });
		}

		[GenericScript("Vld_EndDate", "@EndDate@ != null && @EndDate@ >= @StartDate@;")]
		public string Vld_EndDate
		{
			get
			{
				return "@ERRENDDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
				/*
				if (false) // server side validation code here
					throw new ValidationException("EndDate", "Validation failed for EndDate");  // throw validation exception if failed (don't set the member) 
				*/
			}
		}

		/// <summary>
		/// Get the last decision for the event
		/// </summary>
		/// <returns></returns>
		public ClinicalReviewDecision GetLastDecision()
		{
			if (this.IsNew)
				return null;
			ClinicalReviewDecision lastDec = new ClinicalReviewDecision();
			lastDec.SqlData.Transaction = this.SqlData.Transaction;
			if (lastDec.LoadLastDecisionForEvent(this.eventID))
				return lastDec;
			else
				return null;
		}

		/// <summary>
		/// Loaded and cached last clinical review decision
		/// </summary>
		public ClinicalReviewDecision LastDecision
		{
			get
			{
				if (lastDecision == null)
					lastDecision = GetLastDecision();
				return lastDecision;
			}
		}

		public string StartDateAPCode
		{
			get { return DateActualProjectedCollection.ActiveDateActualProjectedCodes.Lookup_CodeByDateActualProjectedID(this.startDateAP); }
			set { this.startDateAP = DateActualProjectedCollection.ActiveDateActualProjectedCodes.Lookup_DateActualProjectedIDByCode(value); }
		}

		public string EndDateAPCode
		{
			get { return DateActualProjectedCollection.ActiveDateActualProjectedCodes.Lookup_CodeByDateActualProjectedID(this.endDateAP); }
			set { this.endDateAP = DateActualProjectedCollection.ActiveDateActualProjectedCodes.Lookup_DateActualProjectedIDByCode(value); }
		}

		/// <summary>
		/// Calculate the total savings of clinical requests.
		/// We need to calculate this in memory since we keep them in collection and save at once.
		/// </summary>
		/// <returns></returns>
		public Decimal CalculateClinicalRequestSavings()
		{
			this.LoadClinicalReviewRequests(false);
			decimal sumSavings = 0;
			foreach (ClinicalReviewRequest req in this.ClinicalReviewRequests)
			{
				if (!req.IsMarkedForDeletion)	// include in the sum only if not deleted
					sumSavings += req.SavingsValue;
			}
			return sumSavings;
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		public Decimal Savings
		{
			get{ return CalculateClinicalRequestSavings(); }
		}

		/// <summary>
		/// Check if the event has any open activities.
		/// </summary>
		public bool HasEventOpenActivities(int eventID)
		{
			return Convert.ToBoolean( SqlData.SPExecScalar("usp_HasEventOpenActivities", new object[] { eventID }) );
		}		

		/// <summary>
		/// Check if this event has any open activities.
		/// </summary>
		public bool HasEventOpenActivities()
		{
			return HasEventOpenActivities(this.eventID);
		}		

		/// <summary>
		/// Generate letters for all the clinical requests of the event.
		/// </summary>
		public bool GenerateLetters(bool checkLetterDecision)
		{
			LetterGenerator let = new LetterGenerator();

			this.LoadClinicalReviewRequests(false);
			bool result = false;
			int session = 1;
			foreach (ClinicalReviewRequest req in this.ClinicalReviewRequests)
			{
				req.LoadClinicalReviewDecisions(false);

				foreach (ClinicalReviewDecision dec in req.ClinicalReviewDecisions)
				{
					if (dec.LettersShouldBeGenerated)	// letter generation allowed by user?
						if (let.GenerateEventLetters(session, patient, this, req, dec, checkLetterDecision))
						{
							result = true;
							dec.TriggerGenerateLetter = false;	// reset trigger generation on insert
						}

					session = 2;
				}
			}
			return result;
		}

		public ClinicalReviewDecision GetFirstDecision()
		{
			this.LoadClinicalReviewRequests(false);
			
			foreach (ClinicalReviewRequest req in this.ClinicalReviewRequests)
			{
				req.LoadClinicalReviewDecisions(false);

				if (req.ClinicalReviewDecisions.Count > 0)
					return req.ClinicalReviewDecisions[0];
				else
					return null;
			}
			return null;
		}
		
		/// <summary>
		/// Create a copy of this event.
		/// Copied subcomponents are:
		///		UserDefined, ClinicalReviewRequests
		/// </summary>
		/// <returns></returns>
		public Event CreateCopyOfEvent()
		{
			Event eve = new Event(this.patient, true);
			this.CopyMappedMembersTo(eve, false, false, false);
			this.MarkNew();
			this.UserDefined.CopyMappedMembersTo(eve.UserDefined, false, false, false);		// deep copy, mark new

			// copy clinical reviews
			this.LoadClinicalReviewRequests(false);
			eve.LoadClinicalReviewRequests(false);
			this.ClinicalReviewRequests.CopyElementsTo(eve.ClinicalReviewRequests, false, true);	// deep copy, mark new

			/*// copy consulting providers
			this.LoadEventConsultingProviders(false);
			eve.LoadEventConsultingProviders(false);
			this.EventConsultingProviders.CopyElementsTo(eve.EventConsultingProviders, false, true);	// deep copy, mark new

			// copy diagnoses
			this.LoadEventDiagnoses(false);
			eve.LoadEventDiagnoses(false);
			this.EventDiagnoses.CopyElementsTo(eve.EventDiagnoses, false, true);		// deep copy, mark new

			// copy procedures
			this.LoadEventProcedures(false);
			eve.LoadEventProcedures(false);
			this.EventProcedures.CopyElementsTo(eve.EventProcedures, false, true);		// deep copy, mark new

			// copy outcomes
			this.LoadOutcomes(false);
			eve.LoadOutcomes(false);
			this.Outcomes.CopyElementsTo(eve.Outcomes, false, true);		// deep copy, mark new

			// copy physician reviews
			this.LoadPRRequests(false);
			eve.LoadPRRequests(false);
			this.PRRequests.CopyElementsTo(eve.PRRequests, false, true);		// deep copy, mark new
			*/

			return eve;
		}

		#region CareResource
		/// <summary>
		/// Stores last modifed data from following: Provider, Facility or Group Practice
		/// References [ReferToType].Code
		/// Used only in context of Care Resource
		/// </summary>
		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string ReferToCode
		{
			get { return this.referToCode; }
			set { this.referToCode = value; }
		}

		public string ProviderName
		{
			get
			{
				string tmp = this.referToCode;
				this.referToCode = ReferToType.PROVIDER;
				string result = ResourceName;
				this.referToCode = tmp; // restoring old value;
				return result;
			}
		}

		public string FacilityName
		{
			get
			{
				string tmp = this.referToCode;
				this.referToCode = ReferToType.FACILITY;
				string result = ResourceName;
				this.referToCode = tmp; // restoring old value;
				return result;
			}
		}

		[FieldDescription("@RESOURCENAME@")]
		public string ResourceName
		{
			get
			{ 
				switch(this.referToCode)
				{
					case ReferToType.FACILITY:
						return Facility.GetFacilityNameByID(this.facilityID);
						break;
					case ReferToType.PROVIDER:
						return Provider.GetProviderFullNameWithPrefixByID(this.providerID);
						break;
					case ReferToType.GROUPPRACTICE:
						return GroupPractice.GetGroupPracticeNameByID(this.providerGroupID);
						break;
					default:
						return string.Empty;
				}
			}
		}

		[FieldDescription("@RESOURCE@" + " @PHONE@")]
		public string ResourcePhone
		{
			get
			{ 
				switch(this.referToCode)
				{
					case ReferToType.FACILITY:
						return Facility.GetServiceLocationPhoneByFacilityLocationID(this.facilityLocationID);
						break;
					case ReferToType.PROVIDER:
						return Provider.GetServiceLocationPhoneByProviderLocationID(this.providerLocationID);
						break;
					case ReferToType.GROUPPRACTICE:
						return GroupPractice.GetServiceLocationPhoneByGroupPracticeLocationID(this.providerGroupLocationID);
						break;
					default:
						return string.Empty;
				}
			}
		}

		[FieldDescription("@CONTACTNAME@")]
		public string ResourceContactName
		{
			get
			{ 
				switch(this.referToCode)
				{
					case ReferToType.FACILITY:
						return Contact.GetLatestContactNameByFacilityLocationId(this.facilityLocationID);
						break;
					case ReferToType.PROVIDER:
						return Contact.GetLatestContactNameByProviderLocationId(this.providerLocationID);
						break;
					case ReferToType.GROUPPRACTICE:
						return Contact.GetLatestContactNameByGroupPracticeLocationId(this.providerGroupLocationID);
						break;
					default:
						return string.Empty;
				}
			}
		}
		#endregion

		/// <summary>
		/// Has event any denied decisions?
		/// </summary>
		public bool HasEventDeniedDecisions()
		{
			return Convert.ToBoolean( SqlData.SPExecScalar("usp_HasEventDeniedDecisions", new object[] { this.eventID }) );
		}

		public System.Exception LosCalcEx
		{
			get { return this.losCalcEx; }
		}
		

	}

	/// <summary>
	/// Strongly typed collection of Event objects
	/// </summary>
	[ElementType(typeof(Event))]
	public class EventCollection : BaseCollectionForEventCMSReferral
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Event elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEventCollection = this;
			else
				elem.ParentEventCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Event elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Event this[int index]
		{
			get
			{
				return (Event)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Event)oldValue, false);
			SetParentOnElem((Event)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		
		/// <summary>
		/// Returns all the Events for a given patient object and also establishes the in-memory relations to 
		/// patient object.
		/// </summary>
		/// <param name="patient"></param>
		/// <returns></returns>
		public int LoadLinkedPatientEvents(Patient patient)
		{
			return LoadLinkedPatientEvents(-1, patient);
		}

		/// <summary>
		/// Load the events of a given patient.
		/// </summary>
		public int LoadLinkedPatientEvents(int maxRecords, Patient patient)
		{
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Linked patient events can be loaded only in the context of a patient");
			this.Clear();
			int count = SqlData.SPExecReadCol("usp_GetLinkedPatientEventsWithDAFilter", maxRecords, this, false, patient.PatientId, SQLDataDirect.MakeDBValue(AASecurityHelper.GetUserId, (int)0));

			// set the parent patients for all the events
			SetParentPatientObject(patient);

			return count;
		}

		/// <summary>
		/// Given a problem, this function determines if the event is linked or not
		/// </summary>
		/// <param name="problem"></param>
		public override void DetermineElementsLinkedToProblem(Problem problem)
		{
			problem.LoadProblemEvents(false);
			problem.ProblemEvents.IndexBy_EventID.Rebuild();
			for (int i = 0; i < this.Count; i++)
			{
				Event eve = this[i];

				ProblemEvent probEve = problem.ProblemEvents.FindByEventID(eve.EventID);
				eve.IsLinkedToProblem = probEve != null;	// if found, this is linked to the problem
			}
		}

		/// <summary>
		/// Load all possible duplicates for the event.  The duplicate events are the ones
		/// whose following fields match:
		///    patientID,             (implicit rule)
		///    eventTypeID, 
		///    providerID, 
		///    facilityID, 
		///    providerGroupID, 
		///    startDate
		/// and whose eventID is not the same as the given event's.
		/// </summary>
		public int LoadPossibleDuplicateEvents(Event eventObj)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPossibleDuplicateEvents", -1, this, eventObj, false);
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadAllEventsByPatientID(int maxRecords, int patientId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllEventsByPatientID", maxRecords, this, false, new object[] { patientId });
		}

		public static EventCollection LoadAllEventsByPatientID(int patientId)
		{
			EventCollection col = new EventCollection();
			col.LoadAllEventsByPatientID(-1, patientId);
			return col;
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Event elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Event)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Search all events by the Alt-Event ID
		/// </summary>
		public int SearchEventsByAltEventID(int maxRecords, string altEventID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchEventsByAltEventID", maxRecords, this, false, 
				new object[] { SQLDataDirect.MakeDBValue( altEventID ) });
		}

		public override int SearchByAltAuthorizationID(int maxRecords, string altAuthorizationID)
		{
			return SearchEventsByAltEventID(maxRecords, altAuthorizationID);
		}

	}


	/// BR01.4.1	Events shall be associated with a Problem or a Care Management Case.
	/// BR01.4.2	Users shall be able to assign or reassign an Event to a Team or User.
	/// BR01.4.3	Users can add Activities to an Event.
	/// BR01.4.4	An Event must have a Start Date, End Date, Type and Status
	/// BR01.4.5	Events shall have one or more Problems. One problem must be designated the Primary Problem.
	/// BR01.4.6	The Primary Problem of an Event can be reassigned.
	/// BR01.4.7	The System shall track the last modification date for Events.
	/// BR01.4.8	Events shall contain Provider information that will persist. 
	///				Users shall be able to edit the Provider information at any time independent 
	///				from the Patient plan information.
	///	BR01.4.9	Events shall contain Facility information that will persist. System will provide 
	///				Facility Information storage. If value is not found in System, Users shall be able to add 
	///				or edit Facility information.
	///	BR01.4.10	Events may contain Group Practice information that will persist. Users shall be able to edit 
	///				the Group Practice Information at any time.
	///	BR01.4.11	Events may contain Referral Provider Information that will persist.
	///	BR01.4.12	Events may contain Preferred Care Provider (PCP) information that will persist.
	///	BR01.4.13	Events shall have 0 or more Diagnostic & Procedure codes.
	///	BR01.4.14	Events shall have 0 or more Requests. A Request is a patient�s or provider�s desire for 
	///				a specified level of care.
	///	BR01.4.15	Events shall be able to display a calculated total of associated Requests.
	///	BR01.4.16	Requests shall have Decisions. A Decision is a response to a specified level of care. 
	///				A Decision may approve all, some or none of the requested care.
	///	BR0.1.4.17	Events shall have Length-Of-Stay (LOS) information that will persist. This information can 
	///				be used as a basis for Decisions.
	///	BR01.4.18	Users shall be able to view LOS distribution data as guidance for Requests. System shall incorporate 
	///				this information from a third-party source.
	///	BR01.4.19	Events may have one or more Outcomes. An Outcome is the final result of an event, i.e. the 
	///				status of the patient�s healthcare. For example an Outcome might state that the patient 
	///				�recovered and returned home�, or an Outcome might indicate, �patient coverage exhausted�.
	///	BR01.4.20	Users shall be able to make copies of an existing Event.
	///	BR01.4.21	Events may have Referrer Information. The event shall persist the Referrer information. 
	///				The Referrer information shall include a Referring Provider and/or Referring provider group.
	///	BR01.4.22	Events shall have Subscriber information and persist this data. A Subscriber is the principal 
	///				insured associated with a Health Plan.
	///	BR01.4.23	Events shall have the attributes described in Table 1.4.1 �Attributes of Events�.
	///	BR01.4.24	Events shall provide a method to check for duplication.
	///	BR01.4.25	The System shall generate length-of-stay information for reporting purposes using the Event�s Start 
	///				and End dates.
	///	BR01.4.26	Events shall verify eligibility when a Start date is entered.
	///	BR01.4.27	System shall allow reassignment of an Event to a different Patient, including all information 
	///				related to the Event (i.e. Notes, Activities, Guidelines, etc.).
	///	BR01.4.28	System shall update the Status Date when the User changes the Status field.
	///	BR01.4.29	System shall set the Notify Date to the Event Creation date when the Event is created.
	///	BR01.4.30	Events shall have 0 or 1 Outcomes. The attributes of an Outcome are listed in Table 1.4.2 
	///				�Attributes of an Outcome�
	///	BR01.4.31	System shall ensure that when an Event status is changed to CLOSED, there is a valid End Date for the Event.
	///	BR01.4.32	System shall set the Notify date to the date the Event is created. User shall be able to modify 
	///				this date at any time.
	///	BR01.4.33	System shall verify the eligibility status of the Patient at least once per day when the Event 
	///				is opened, or whenever the Start Date for the Event is modified.
	///	BR01.4.34	System shall check for duplication of Event entry using the following criteria:
	///				�	Event Type
	///				�	Provider
	///				�	Facility
	///				�	Provider Group
	///				�	Event Start Date
	///				System can require an exact match or be configured to allow a specific leeway of +/- day 
	///				interval for the Event Start date.
	///	BR01.4.35	System shall create MA EDI out-bound file if Event is flagged as being sourced from a MA EDI input.

}
