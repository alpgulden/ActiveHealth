using System;

using System.Diagnostics;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{

	/// <summary>
	/// Contains the clinical review summary calculation result
	/// returned by usp_CalculateClinicalReviewTotals.
	/// </summary>
	[SPAutoGen("usp_CalculateClinicalReviewTotals", null, ManuallyManaged=true)]
	[TableMapping(null)]
	public class ClinicalReviewTotal : BaseData
	{
		#region Group by codes that are accepted by usp_CalculateClinicalReviewTotals

		public const string GROUPBYDECISIONTYPE = "DT";
		public const string GROUPBYDECISIONCODETYPE = "DCT";

		#endregion

		[NonSerialized]
		private ClinicalReviewTotalCollection parentClinicalReviewTotalCollection;
	
		public ClinicalReviewTotal()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ColumnMapping("ReqAmount")]
		private decimal reqAmount;
		[ColumnMapping("ReqUOMID")]
		private int reqUOMID;
		[ColumnMapping("DecAmount")]
		private decimal decAmount;
		[ColumnMapping("DecUOMID")]
		private int decUOMID;
		[ColumnMapping("ActualAmount")]
		private decimal actualAmount;
		[ColumnMapping("DecisionTypeOrCodeID")]
		private int decisionTypeOrCodeID;

		/// <summary>
		/// Parent ClinicalReviewTotalCollection that contains this element
		/// </summary>
		public ClinicalReviewTotalCollection ParentClinicalReviewTotalCollection
		{
			get
			{
				return this.parentClinicalReviewTotalCollection;
			}
			set
			{
				this.parentClinicalReviewTotalCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal ReqAmount
		{
			get { return this.reqAmount; }
			set { this.reqAmount = value; }
		}

		[FieldValuesMember("LookupOf_ReqUOMID", "ClinicalReviewUnitID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ReqUOMID
		{
			get { return this.reqUOMID; }
			set { this.reqUOMID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal DecAmount
		{
			get { return this.decAmount; }
			set { this.decAmount = value; }
		}

		[FieldValuesMember("LookupOf_DecUOMID", "ClinicalReviewUnitID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int DecUOMID
		{
			get { return this.decUOMID; }
			set { this.decUOMID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal ActualAmount
		{
			get { return this.actualAmount; }
			set { this.actualAmount = value; }
		}

		// Boty DecisionTypeID and DecisionTypeCodeID properties map to decisionTypeOrCodeID returned the usp_CalculateClinicalReviewTotals.
		// Grouping determined which is to be used by UI.
		[FieldValuesMember("LookupOf_DecisionTypeID", "ClinicalReviewDecisionTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int DecisionTypeID
		{
			get { return this.decisionTypeOrCodeID; }
			set { this.decisionTypeOrCodeID = value; }
		}

		// Boty DecisionTypeID and DecisionTypeCodeID properties map to decisionTypeOrCodeID returned the usp_CalculateClinicalReviewTotals.
		// Grouping determined which is to be used by UI.
		[FieldValuesMember("LookupOf_DecisionTypeCodeID", "ClinicalReviewDecisionTypeCodeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@APPROVEDDENIED@")]
		public int DecisionTypeCodeID
		{
			get { return this.decisionTypeOrCodeID; }
			set { this.decisionTypeOrCodeID = value; }
		}

		public ClinicalReviewUnitCollection LookupOf_ReqUOMID
		{
			get
			{
				return ClinicalReviewUnitCollection.ActiveClinicalReviewUnits; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewUnitCollection LookupOf_DecUOMID
		{
			get
			{
				return ClinicalReviewUnitCollection.ActiveClinicalReviewUnits; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDecisionTypeCollection LookupOf_DecisionTypeID
		{
			get
			{
				return ClinicalReviewDecisionTypeCollection.ActiveClinicalReviewDecisionTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDecisionTypeCodeCollection LookupOf_DecisionTypeCodeID
		{
			get
			{
				return ClinicalReviewDecisionTypeCodeCollection.ActiveClinicalReviewDecisionTypeCodes;	// Acquire a shared instance from the static member of collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of ClinicalReviewTotal objects
	/// </summary>
	[ElementType(typeof(ClinicalReviewTotal))]
	public class ClinicalReviewTotalCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClinicalReviewTotal elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClinicalReviewTotalCollection = this;
			else
				elem.ParentClinicalReviewTotalCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClinicalReviewTotal elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClinicalReviewTotal this[int index]
		{
			get
			{
				return (ClinicalReviewTotal)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClinicalReviewTotal)oldValue, false);
			SetParentOnElem((ClinicalReviewTotal)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calculate clinical review totals:
		///		ClinicalReviewTypeID, ReqUOMID, DecUOMID	if groupBy = 'DT'
		///		ClinicalReviewTypeCodeID, ReqUOMID, DecUOMID	if groupBy = 'DCT'
		/// </summary>
		public int CalculateClinicalReviewTotals(int eventID, string groupBy)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_CalculateClinicalReviewTotals", -1, this, false, 
				new object[] { eventID, groupBy });
		}
	}
}
