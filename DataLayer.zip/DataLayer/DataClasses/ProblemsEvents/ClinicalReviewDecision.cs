using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ClinicalReviewDecision]
	/// </summary>
	[SPAutoGen("usp_GetLastDecisionForEvent","JoinWithParentFilterParentLoadChild.sptpl",
			"ClinicalReviewRequest, clinicalReviewRequestID, clinicalReviewRequestID, eventID",
			InjectPreOperation="SET ROWCOUNT 1  -- top record",
			InjectOrderBy="ORDER BY [ClinicalReviewDecision].[ClinicalReviewDecisionID] DESC"
		 )]
	[SPInsert("usp_InsertClinicalReviewDecision")]
	[SPUpdate("usp_UpdateClinicalReviewDecision")]
	[SPDelete("usp_DeleteClinicalReviewDecision")]
	[SPLoad("usp_LoadClinicalReviewDecision")]
	[TableMapping("ClinicalReviewDecision","clinicalReviewDecisionID")]
	public class ClinicalReviewDecision : BaseDataWithUserDefined
	{
		[NonSerialized]
		private ClinicalReviewDecisionCollection parentClinicalReviewDecisionCollection;
		[ColumnMapping("ClinicalReviewDecisionID",StereoType=DataStereoType.FK)]
		private int clinicalReviewDecisionID;
		[ColumnMapping("ClinicalReviewRequestID",StereoType=DataStereoType.FK)]
		private int clinicalReviewRequestID;
		[ColumnMapping("EventProcedureID",StereoType=DataStereoType.FK)]
		private int eventProcedureID;
		[ColumnMapping("ClinicalReviewDecisionTypeID",StereoType=DataStereoType.FK)]		// lookup
		private int clinicalReviewDecisionTypeID;
		[ColumnMapping("ClinicalReviewDecisionReasonID",StereoType=DataStereoType.FK)]	// lookup
		private int clinicalReviewDecisionReasonID;
		[ColumnMapping("DecAmount")]
		private decimal decAmount = decimal.MinValue;
		[ColumnMapping("DecUOMID",StereoType=DataStereoType.FK)]
		private int decUOMID;
		[ColumnMapping("Comment")]
		private string comment;
		[ColumnMapping("ActualEndDate")]
		private DateTime actualEndDate;
		[ColumnMapping("ClinicalReviewDescriptionID",StereoType=DataStereoType.FK)]		// lookup
		private int clinicalReviewDescriptionID;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("ActualAmount")]
		private int actualAmount;
		[ColumnMapping("UnitCost", StereoType=DataStereoType.Currency)]
		private Decimal unitCost;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("PercentUnitDisc")]
		private int percentUnitDisc;
		[ColumnMapping("FreqUOMID",StereoType=DataStereoType.FK)]	// lookup
		private int freqUOMID;
		[ColumnMapping("FreqAmount")]
		private int freqAmount;
		[ColumnMapping("DurationAmount")]
		private int durationAmount;
		[ColumnMapping("DurationUOMID",StereoType=DataStereoType.FK)]		// lookup
		private int durationUOMID;
		[ColumnMapping("LinkedProcedureType")]
		private string linkedProcedureType;
		[ColumnMapping("LinkedProcedureCode")]
		private string linkedProcedureCode;
		[ColumnMapping("ClinicalRationale")]
		private string clinicalRationale;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

		private int amount=0;

		private bool createLOMIDenial=false;
		private bool changeLOMIDenialToRAPP=false;
		private bool changeLOMIDenialToRFPR=false;
		private bool createPhysicianReviewRequest=false;

//		// pending resolution to Issue 643.
//		// If removed update CRUD stor procs and usp_LoadClinicalReviewRequestDecisions
//		[ColumnMapping("ProcedureCode", JoinColumn="ProcedureCode", JoinRelation="ClinicalReviewDecision.EventProcedureID = [EventReferralProcedure].EventProcedureID", SQLGen=SQLGenerationFlags.NoInsertUpdate)]
//		private string procedureCode;
//
//		[ColumnMapping("ProcedureType", JoinColumn="ProcedureType", JoinRelation="ClinicalReviewDecision.EventProcedureID = [EventReferralProcedure].EventProcedureID", SQLGen=SQLGenerationFlags.NoInsertUpdate)]
//		private string procedureType;

		private bool generateLetter = true;		// specified by user
		private bool triggerGenerateLetter = false;		// set to true after insert, or externally

		// fields to check for changes to decide whether letters should be generated
		private int clinicalReviewDecisionTypeIDwhenLoaded = 0;
		private int clinicalReviewDecisionReasonIDwhenLoaded = 0;		
		private string linkedProcedureCodewhenLoaded = null;		
		private decimal decAmountwhenLoaded = decimal.MinValue;
		private int decUOMIDwhenLoaded = 0;
		private int clinicalReviewDescriptionIDwhenLoaded = 0;
		private decimal unitCostwhenLoaded = 0;
		private int percentUnitDiscwhenLoaded = 0;
		private int freqAmountwhenLoaded = 0;
		private int freqUOMIDwhenLoaded = 0;
		private int durationAmountwhenLoaded = 0;
		private int durationUOMIDwhenLoaded = 0;
		private int actualAmountwhenLoaded = 0;
		private DateTime actualEndDatewhenLoaded;

		private ClinicalReviewRequest parentRequest;		// we need this for calculations.
		
		private Event eventObj;				// the event object that's in the context
		private CMS cMS;					// CMS object to use when in CareResource to load its Procedures

		private string clinicalReviewDecisionPrevValue;			// keeps track of the changes in eventTypeID
		private string clinicalReviewReasonPrevValue;		// keeps track of the changes in startDate

		public ClinicalReviewDecision()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ClinicalReviewDecision(ClinicalReviewRequest parentRequest, bool initNew)
		{
			this.parentRequest = parentRequest;
			if (initNew) // initialize record if requested
				this.NewRecord();
			// FORK 1.1 
			// this code added by Alp 01/11/06
			// Assigning Start and End Date from Event class.
			// Set Decision UOM to parent request's Request UOM
			Event eve = (Event)parentRequest.ParentClinicalReviewRequestCollection.ParentEvent;
			EventType eveTyp = new EventType();
//			ClinicalReviewUnit cRU = new ClinicalReviewUnit();
//			cRU.Load("DAYS");
			eveTyp.Load(eve.EventTypeID);
			this.DecUOMID = parentRequest.ReqUOMID;
			if(eveTyp!=null)
			{
				if(eveTyp.HEDISRptType.Trim()=="IP")
				{
					this.StartDate = eve.StartDate;
//					if(cRU!=null)
//						this.DecUOMID = cRU.ClinicalReviewUnitID;
				}
				if(eveTyp.HEDISRptType.Trim()=="OP")
				{
					this.StartDate = eve.StartDate;
					this.EndDate = eve.StartDate;
				}
			}
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@DECISIONID@")]
		public int ClinicalReviewDecisionID
		{
			get { return this.clinicalReviewDecisionID; }
			set { this.clinicalReviewDecisionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]	
		public int ClinicalReviewRequestID
		{
			get { return this.clinicalReviewRequestID; }
			set { this.clinicalReviewRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EventProcedureID
		{
			get { return this.eventProcedureID; }
			set { this.eventProcedureID = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewDecisionTypeID", "ClinicalReviewDecisionTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@DECISIONTYPE@")]
		public int ClinicalReviewDecisionTypeID
		{
			get { return this.clinicalReviewDecisionTypeID; }
			set { this.clinicalReviewDecisionTypeID = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewDecisionReasonID", "ClinicalReviewDecisionReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@DECISIONREASON@")]
		public int ClinicalReviewDecisionReasonID
		{
			get { return this.clinicalReviewDecisionReasonID; }
			set { this.clinicalReviewDecisionReasonID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public decimal DecAmount
		{
			get { return this.decAmount; }
			set { this.decAmount = value; }
		}

		public decimal DecAmountValue
		{
			get { return this.decAmount == decimal.MinValue ? 0 : this.decAmount; }
		}

		[FieldValuesMember("LookupOf_DecUOMID", "ClinicalReviewUnitID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int DecUOMID
		{
			get { return this.decUOMID; }
			set { this.decUOMID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Comment
		{
			get { return this.comment; }
			set { this.comment = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ActualEndDate
		{
			get { return this.actualEndDate; }
			set { this.actualEndDate = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewDescriptionID", "ClinicalReviewDescriptionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@DESCRIPTION@")]
		public int ClinicalReviewDescriptionID
		{
			get { return this.clinicalReviewDescriptionID; }
			set { this.clinicalReviewDescriptionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ActualAmount
		{
			get { return this.actualAmount; }
			set { this.actualAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		public decimal UnitCost
		{
			get { return this.unitCost; }
			set { this.unitCost = value; }
		}

		public decimal UnitCostValue
		{
			get { return this.unitCost == decimal.MinValue ? 0 : this.UnitCost ; }
		}

		[ValidatorMember("Vld_EndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PercentUnitDisc
		{
			get { return this.percentUnitDisc; }
			set { this.percentUnitDisc = value; }
		}

		[FieldValuesMember("LookupOf_FreqUOMID", "ClinicalReviewFreqUnitID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int FreqUOMID
		{
			get { return this.freqUOMID; }
			set { this.freqUOMID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int FreqAmount
		{
			get { return this.freqAmount; }
			set { this.freqAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DurationAmount
		{
			get { return this.durationAmount; }
			set { this.durationAmount = value; }
		}

		[FieldValuesMember("LookupOf_DurationUOMID", "ClinicalReviewDurUnitID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int DurationUOMID
		{
			get { return this.durationUOMID; }
			set { this.durationUOMID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string LinkedProcedureType
		{
			get { return this.linkedProcedureType; }
			set { this.linkedProcedureType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string LinkedProcedureCode
		{
			get { return this.linkedProcedureCode; }
			set { this.linkedProcedureCode = value; }
		}

		public string ClinicalReviewDecisionPrevValue
		{
			get { return this.clinicalReviewDecisionPrevValue; }
			set { this.clinicalReviewDecisionPrevValue = value; }
		}
		
		public string ClinicalReviewReasonPrevValue
		{
			get { return this.clinicalReviewReasonPrevValue; }
			set { this.clinicalReviewReasonPrevValue = value; }
		}

//		[ControlType(EnumControlTypes.TextBox, ValueForNull="")]
//		public string ProcedureCode
//		{
//			get { return this.procedureCode; }
//		}
//
//		[ControlType(EnumControlTypes.TextBox, ValueForNull="")]
//		public string ProcedureType
//		{
//			get { return this.procedureType; }
//		}

		[FieldValuesMember("LookupOf_LinkedProcedureTypeAndCode", "ProcedureTypeAndCode", "ProcedureFullDescription")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		[FieldDescription("@LINKEDPROCEDURECODE@")]
		public string LinkedProcedureTypeAndCode
		{
			get
			{
				if (linkedProcedureType == null && linkedProcedureCode == null)
					return null;
				else
					return String.Format("{0}-{1}", linkedProcedureType, linkedProcedureCode);
			}
			set
			{
				this.linkedProcedureType = null;
				this.linkedProcedureCode = null;
				if (value != null)
				{
					int i = value.IndexOf('-');
					if (i >= 0)
					{
						this.linkedProcedureType = value.Substring(0, i);		// before -
						this.linkedProcedureCode = value.Substring(i + 1);		// after -
					}
				}
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000, ClientValidators=EnumClientValidators.Required)]
		public string ClinicalRationale
		{
			get { return this.clinicalRationale; }
			set { this.clinicalRationale = value; }
		}


		/*/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}*/

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int clinicalReviewDecisionID)
		{
			return base.Load(clinicalReviewDecisionID);
		}

		/// <summary>
		/// Parent ClinicalReviewDecisionCollection that contains this element
		/// </summary>
		public ClinicalReviewDecisionCollection ParentClinicalReviewDecisionCollection
		{
			get
			{
				return this.parentClinicalReviewDecisionCollection;
			}
			set
			{
				this.parentClinicalReviewDecisionCollection = value; // parent is set when added to a collection
			}
		}

		public ClinicalReviewDecisionTypeCollection LookupOf_ClinicalReviewDecisionTypeID
		{
			get
			{
				return ClinicalReviewDecisionTypeCollection.ActiveClinicalReviewDecisionTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDecisionReasonCollection LookupOf_ClinicalReviewDecisionReasonID
		{
			get
			{
				return ClinicalReviewDecisionReasonCollection.ActiveClinicalReviewDecisionReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDescriptionCollection LookupOf_ClinicalReviewDescriptionID
		{
			get
			{
				return ClinicalReviewDescriptionCollection.ActiveClinicalReviewDescriptions; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewFreqUnitCollection LookupOf_FreqUOMID
		{
			get
			{
				return ClinicalReviewFreqUnitCollection.ActiveClinicalReviewFreqUnits; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDurUnitCollection LookupOf_DurationUOMID
		{
			get
			{
				return ClinicalReviewDurUnitCollection.ActiveClinicalReviewDurUnits; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewUnitCollection LookupOf_DecUOMID
		{
			get
			{
				return ClinicalReviewUnitCollection.ActiveClinicalReviewUnits; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// The Event object to be used in the context of this object
		/// </summary>
		public ActiveAdvice.DataLayer.Event EventObj
		{
			get 
			{ 
				if (this.eventObj == null)
				{
					// try getting it from the parents
					ClinicalReviewDecisionCollection decisions = this.parentClinicalReviewDecisionCollection;
					if (decisions != null && decisions.ParentClinicalReviewRequest != null)
					{
						ClinicalReviewRequestCollection requests = decisions.ParentClinicalReviewRequest.ParentClinicalReviewRequestCollection;
						if (requests != null)
							this.eventObj = requests.ParentEvent;
					}
				}
				return this.eventObj; 
			}
			set { this.eventObj = value; }
		}

		public void SetCMSForCareResource(CMS cMS)
		{
			this.cMS = cMS;
		}

		/// <summary>
		/// Returns Linked Procedures
		/// 1. In case where CMS object is set (Care Resource) return cMS.CMSDiagnosticProcedures
		/// 2. In all other cases return EventObj.EventReferralProcedures
		/// </summary>
		public ProcedureSelectCollection LookupOf_LinkedProcedureTypeAndCode
		{
			get
			{
				ProcedureSelectCollection procSelCol = null;
				if(this.cMS != null)
				{
					cMS.LoadCMSDiagnosticProcedures(false);
					procSelCol = cMS.CMSDiagnosticProcedures.CreateProcedureSelectionCollection();
				}
				else if (this.EventObj != null)
				{
					this.EventObj.LoadEventProcedures(false);
					procSelCol = this.EventObj.EventReferralProcedures.CreateSelectionCollection();
				}

				if (procSelCol != null)
					procSelCol.SortBy_CodeDescription(true, true);

				return procSelCol;
			}
		}

		/// <summary>
		/// Load the last decision for an event
		/// </summary>
		public bool LoadLastDecisionForEvent(int eventID)
		{
			return SqlData.SPExecReadObj("usp_GetLastDecisionForEvent", new object[] { this /*, other objects to be filled */ }, false, new object[] { eventID });
		}

		/// <summary>
		/// Calculate unit cost based on the parent request.UnitCost and percentUnitDisc.
		/// </summary>
		/// <param name="request"></param>
		public void CalculateUnitCostFromUnitDiscount(ClinicalReviewRequest request)
		{
			if (request.UnitCost == decimal.MinValue)
				this.unitCost = decimal.MinValue;
			else
				this.unitCost = request.UnitCost * (1 - (decimal)this.percentUnitDisc / 100);
		}

		/// <summary>
		/// Calculate percent discount based on the parent request.UnitCost and unit cost.
		/// </summary>
		/// <param name="request"></param>
		public void CalculatePercentUnitDiscFromUnitCost(ClinicalReviewRequest request)
		{
			decimal diff = request.UnitCost - this.UnitCost;
			if (request.UnitCost == 0)
				this.percentUnitDisc = 0;
			else
				this.percentUnitDisc = (int)decimal.Round(diff / request.UnitCost * 100, 0);
		}

		public ClinicalReviewRequest ParentRequest
		{
			get 
			{ 
				if (this.parentRequest == null)
					if (this.parentClinicalReviewDecisionCollection != null)
						this.parentRequest = this.parentClinicalReviewDecisionCollection.ParentClinicalReviewRequest;
				return this.parentRequest;
			}
		}

		/// <summary>
		/// Returns the parent request's unit cost.
		/// </summary>
		public decimal RequestUnitCost
		{
			get { return ParentRequest.UnitCost; }
		}

		/// <summary>
		/// Letter generation allowed by user?
		/// </summary>
		[ControlType(EnumControlTypes.CheckBox)]
		public bool GenerateLetter
		{
			get { return this.generateLetter; }
			set { this.generateLetter = value; }
		}

		
		public int Amount
		{
			get { return this.amount; }
			set { this.amount = value; }
		}

		/// <summary>
		/// Does PR need to be created? CreateLOMIDenial function trigered this is true
		/// </summary>		
		public bool CreateLOMIDenial
		{
			get { return this.createLOMIDenial; }
			set { this.createLOMIDenial = value; }
		}


		/// <summary>
		/// Does PR need to be created? ChangeLOMIDenialToRAPP function trigered this is true
		/// </summary>		
		public bool ChangeLOMIDenialToRAPP
		{
			get { return this.changeLOMIDenialToRAPP; }
			set { this.changeLOMIDenialToRAPP = value; }
		}

		/// <summary>
		/// Does PR need to be created? CreateLOMIDenialToRFPF function trigered this is true
		/// </summary>		
		public bool ChangeLOMIDenialToRFPR
		{
			get { return this.changeLOMIDenialToRFPR; }
			set { this.changeLOMIDenialToRFPR = value; }
		}


		/// <summary>
		/// Does PR need to be created? CreateLOMIDenialToRFPF function trigered this is true
		/// </summary>		
		public bool CreatePhysicianReviewRequest
		{
			get { return this.createPhysicianReviewRequest; }
			set { this.createPhysicianReviewRequest = value; }
		}

		/// <summary>
		/// Returns true, if the fields that trigger letter generation have been changed,
		/// and the user allowed letter generation.
		/// </summary>
		public bool LettersShouldBeGenerated
		{
			get
			{
				bool lettersShouldBeGenerated = 
					this.triggerGenerateLetter ||			// becomes true when the decision was just inserted
					clinicalReviewDecisionTypeIDwhenLoaded != clinicalReviewDecisionTypeID ||
					clinicalReviewDecisionReasonIDwhenLoaded != clinicalReviewDecisionReasonID ||
					linkedProcedureCodewhenLoaded != linkedProcedureCode ||
					decAmountwhenLoaded != decAmount ||
					decUOMIDwhenLoaded != decUOMID ||
					clinicalReviewDescriptionIDwhenLoaded != clinicalReviewDescriptionID ||
					unitCostwhenLoaded != unitCost ||
					percentUnitDiscwhenLoaded != percentUnitDisc ||
					freqAmountwhenLoaded != freqAmount ||
					freqUOMIDwhenLoaded != freqUOMID ||
					durationAmountwhenLoaded != durationAmount ||
					durationUOMIDwhenLoaded != durationUOMID ||
					actualAmountwhenLoaded != actualAmount ||
					actualEndDatewhenLoaded != actualEndDate;
				return lettersShouldBeGenerated && generateLetter;
			}
		}
		

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);
		}

		protected override void InitializeToTrackChanges()
		{
			base.InitializeToTrackChanges ();

			SaveStateForTrackingChanges();
		}


		public void SaveStateForTrackingChanges()
		{
			// save the state of variables that trigger letter generation
			clinicalReviewDecisionTypeIDwhenLoaded = clinicalReviewDecisionTypeID;
			clinicalReviewDecisionPrevValue = this.ClinicalReviewDecisionTypeCode;
			clinicalReviewReasonPrevValue = this.ClinicalReviewDecisionReasonCode;
			clinicalReviewDecisionReasonIDwhenLoaded = clinicalReviewDecisionReasonID;		
			linkedProcedureCodewhenLoaded = linkedProcedureCode;		
			decAmountwhenLoaded = decAmount;
			decUOMIDwhenLoaded = decUOMID;
			clinicalReviewDescriptionIDwhenLoaded = clinicalReviewDescriptionID;
			unitCostwhenLoaded = unitCost;
			percentUnitDiscwhenLoaded = percentUnitDisc;
			freqAmountwhenLoaded = freqAmount;
			freqUOMIDwhenLoaded = freqUOMID;
			durationAmountwhenLoaded = durationAmount;
			durationUOMIDwhenLoaded = durationUOMID;
			actualAmountwhenLoaded = actualAmount;
			actualEndDatewhenLoaded = actualEndDate;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			triggerGenerateLetter = false;		// will become true if inserted
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			bool decisionChanged = this.clinicalReviewDecisionTypeID != clinicalReviewDecisionTypeIDwhenLoaded;

			base.InternalSave();
			// Save the child collections here.

			#region Trigger AutoActivities - ED1 - Setting Event Decision Type

			if (decisionChanged)
			{
				AutoActivity_SettingEventDecisionType();
			}

			#endregion
		}

		protected override object InternalInsert()
		{
			object o = base.InternalInsert ();
			triggerGenerateLetter = true;
			return o;
		}

		protected override void RecoverRecordState()
		{
			base.RecoverRecordState ();
			triggerGenerateLetter = false;
		}

		/// <summary>
		/// ED1	- Setting Event Decision Type
		/// This is triggered when the clinical review decision type is changed.
		/// </summary>
		public void AutoActivity_SettingEventDecisionType()
		{
			autoActivityManager = this.EventObj.EnsureAutoActivityManager();
			this.autoActivityManager.Execute(AutoActivityRuleType.ED1, this.SqlData.Transaction);
		}

		public string ClinicalReviewDecisionTypeCode
		{
			get { return ClinicalReviewDecisionTypeCollection.ActiveClinicalReviewDecisionTypes.Lookup_CodeByClinicalReviewDecisionTypeID(this.clinicalReviewDecisionTypeID); }
			set { this.clinicalReviewDecisionTypeID = ClinicalReviewDecisionTypeCollection.ActiveClinicalReviewDecisionTypes.Lookup_ClinicalReviewDecisionTypeIDByCode(value); }
		}

		public string ClinicalReviewDecisionReasonCode
		{
			get { return ClinicalReviewDecisionReasonCollection.ActiveClinicalReviewDecisionReasons.Lookup_CodeByClinicalReviewReasonID(this.clinicalReviewDecisionReasonID); }
			set { this.clinicalReviewDecisionTypeID = ClinicalReviewDecisionTypeCollection.ActiveClinicalReviewDecisionTypes.Lookup_ClinicalReviewDecisionTypeIDByCode(value); }
		}

		public bool IsDenied
		{
			get{return this.ClinicalReviewDecisionTypeCode == ClinicalReviewDecisionType.DENIED;}
		}

		public bool IsApproved
		{
			get{return this.ClinicalReviewDecisionTypeCode == ClinicalReviewDecisionType.APPR;}
		}


		public bool TriggerGenerateLetter
		{
			get { return this.triggerGenerateLetter; }
			set { this.triggerGenerateLetter = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ClinicalReviewDecision objects
	/// </summary>
	[ElementType(typeof(ClinicalReviewDecision))]
	public class ClinicalReviewDecisionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass, ICollectionElementFilter
	{
		public const int MAXRECORDS = 4;
		private CollectionPager pager = null;

		[NonSerialized]
		private CollectionIndexer indexBy_ClinicalReviewDecisionID;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClinicalReviewDecision elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClinicalReviewDecisionCollection = this;
			else
				elem.ParentClinicalReviewDecisionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClinicalReviewDecision elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		#region ICollectionElementFilter Members

		/// <summary>
		/// only 2-3 request displayed on the grid. Rest will reach by navigation buttons.
		/// </summary>
		/// <param name="index"></param>
		/// <returns></returns>
			
		public bool FilterElement(int index)
		{
//			if(index>3)
//				return false;
//			else
				return true;
		}

		#endregion


		
		/// <summary>
		/// Hashtable based index on clinicalReviewDecisionID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ClinicalReviewDecisionID
		{
			get
			{
				if (this.indexBy_ClinicalReviewDecisionID == null)
					this.indexBy_ClinicalReviewDecisionID= new CollectionIndexer(this, new string[] { "clinicalReviewDecisionID" }, true);
				return this.indexBy_ClinicalReviewDecisionID;
			}
			
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClinicalReviewDecision this[int index]
		{
			get
			{
				return (ClinicalReviewDecision)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClinicalReviewDecision)oldValue, false);
			SetParentOnElem((ClinicalReviewDecision)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent ClinicalReviewRequest that contains this collection
		/// </summary>
		public ClinicalReviewRequest ParentClinicalReviewRequest
		{
			get { return this.ParentDataObject as ClinicalReviewRequest; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ClinicalReviewRequest */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ClinicalReviewDecision elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ClinicalReviewDecision)value, true);
			base.OnInsertComplete (index, value);		
		}

		public CollectionPager Pager
		{
			get { return this.pager; }
			set { this.pager = value; }
		}

		
		public int CurrentIndex(ClinicalReviewDecision obj)
		{
			return this.IndexBy_ClinicalReviewDecisionID.IndexOfObject(obj);
		}

	}
}
