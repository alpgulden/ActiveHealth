using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EventResolution]
	/// </summary>
	[SPAutoGen("usp_GetAllEventResolutions","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetEventResolutionsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertEventResolution")]
	[SPUpdate("usp_UpdateEventResolution")]
	[SPDelete("usp_DeleteEventResolution")]
	[SPLoad("usp_LoadEventResolution")]
	[TableMapping("EventResolution","eventResolutionID")]
	public class EventResolution : BaseLookupWithSubCode
	{
		[NonSerialized]
		private EventResolutionCollection parentEventResolutionCollection;
		[ColumnMapping("EventResolutionID",StereoType=DataStereoType.FK)]
		private int eventResolutionID;
		[ColumnMapping("UB92Disposition",StereoType=DataStereoType.FK)]
		private int uB92Disposition;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public EventResolution()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EventResolutionID
		{
			get { return this.eventResolutionID; }
			set { this.eventResolutionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int UB92Disposition
		{
			get { return this.uB92Disposition; }
			set { this.uB92Disposition = value; }
		}

		public int UB92DispositionAsInt
		{
			get 
			{
				return this.uB92Disposition;
			}
			set 
			{ 
				this.uB92Disposition = value;
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Parent EventResolutionCollection that contains this element
		/// </summary>
		public EventResolutionCollection ParentEventResolutionCollection
		{
			get
			{
				return this.parentEventResolutionCollection;
			}
			set
			{
				this.parentEventResolutionCollection = value; // parent is set when added to a collection
			}
		}

		[FieldValuesMember("LookupOf_SubCodeID", "UB92DispositionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@UB92DISPOSION@")]
		public override int SubCodeID
		{
			get { return this.uB92Disposition; }
			set { this.uB92Disposition = value; }
		}

		public UB92DispositionCollection LookupOf_SubCodeID
		{
			get
			{
				return UB92DispositionCollection.ActiveUB92Dispositions; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of EventResolution objects
	/// </summary>
	[ElementType(typeof(EventResolution))]
	public class EventResolutionCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_EventResolutionID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EventResolution elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEventResolutionCollection = this;
			else
				elem.ParentEventResolutionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EventResolution elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EventResolution this[int index]
		{
			get
			{
				return (EventResolution)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EventResolution)oldValue, false);
			SetParentOnElem((EventResolution)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadEventResolutionsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetEventResolutionsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared EventResolutionCollection which is cached in NSGlobal
		/// </summary>
		public static EventResolutionCollection ActiveEventResolutions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				EventResolutionCollection col = (EventResolutionCollection)NSGlobal.EnsureCachedObject("ActiveEventResolutions", typeof(EventResolutionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadEventResolutionsByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on eventResolutionID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_EventResolutionID
		{
			get
			{
				if (this.indexBy_EventResolutionID == null)
					this.indexBy_EventResolutionID = new CollectionIndexer(this, new string[] { "eventResolutionID" }, true);
				return this.indexBy_EventResolutionID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on eventResolutionID fields returns the object.  Uses the IndexBy_EventResolutionID indexer.
		/// </summary>
		public EventResolution FindBy(int eventResolutionID)
		{
			return (EventResolution)this.IndexBy_EventResolutionID.GetObject(eventResolutionID);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllEventResolutions", -1, this, false);
		}
	}
}
