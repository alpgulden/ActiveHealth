using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OutcomeIndicator]
	/// </summary>
	[SPAutoGen("usp_GetOutcomeIndicatorsByOutcomeType","SelectAllByGivenArgsOrderBy.sptpl","description, ASC, outcomeType")]
	[SPAutoGen("usp_GetOutcomeIndicators","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetOutcomeIndicatorsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertOutcomeIndicator")]
	[SPUpdate("usp_UpdateOutcomeIndicator")]
	[SPDelete("usp_DeleteOutcomeIndicator")]
	[SPLoad("usp_LoadOutcomeIndicator")]
	[TableMapping("OutcomeIndicator","outcomeIndicatorID")]
	public class OutcomeIndicator : BaseLookupWithSubCode
	{
		[NonSerialized]
		private OutcomeIndicatorCollection parentOutcomeIndicatorCollection;
		[ColumnMapping("OutcomeIndicatorID",StereoType=DataStereoType.FK)]
		private int outcomeIndicatorID;
		[ColumnMapping("OutcomeType")]
		private int outcomeType;
		[ColumnMapping("Notepad")]
		private string notepad;
		private OutcomeIndicatorSubIndicatorCollection outcomeIndicatorSubIndicators;
	
		public OutcomeIndicator()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public OutcomeIndicator(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OutcomeIndicatorID
		{
			get { return this.outcomeIndicatorID; }
			set { this.outcomeIndicatorID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OutcomeType
		{
			get { return this.outcomeType; }
			set { this.outcomeType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}
		
		[FieldValuesMember("LookupOf_SubCodeID", "OutcomeTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@OUTCOMETYPE@")]
		public override int SubCodeID
		{
			get { return this.outcomeType; }
			set { this.outcomeType = value; }
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int outcomeIndicatorID)
		{
			return base.Load(outcomeIndicatorID);
		}

		/// <summary>
		/// Parent OutcomeIndicatorCollection that contains this element
		/// </summary>
		public OutcomeIndicatorCollection ParentOutcomeIndicatorCollection
		{
			get
			{
				return this.parentOutcomeIndicatorCollection;
			}
			set
			{
				this.parentOutcomeIndicatorCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child OutcomeIndicatorSubIndicators mapped to related rows of table OutcomeIndicatorSubIndicator where [OutcomeIndicatorID] = [OutcomeIndicatorId]
		/// </summary>
		[SPLoadChild("usp_LoadOutcomeIndicatorOutcomeIndicatorSubIndicator", "outcomeIndicatorId")]
		public override BaseDataCollectionClass BracketCodeTableChilderen
		{
			get { return this.outcomeIndicatorSubIndicators; }
			set
			{
				this.outcomeIndicatorSubIndicators = (OutcomeIndicatorSubIndicatorCollection)value;
				if (value != null)
					((OutcomeIndicatorSubIndicatorCollection)value).ParentOutcomeIndicator = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the OutcomeIndicatorSubIndicators collection
		/// </summary>
		public override void LoadBracketCodeTableChilderen(bool forceReload)
		{
			this.outcomeIndicatorSubIndicators = (OutcomeIndicatorSubIndicatorCollection)OutcomeIndicatorSubIndicatorCollection.LoadChildCollection("BracketCodeTableChilderen", this, typeof(OutcomeIndicatorSubIndicatorCollection), outcomeIndicatorSubIndicators, forceReload, null);
		}

		/// <summary>
		/// Saves the OutcomeIndicatorSubIndicators collection
		/// </summary>
		public override void SaveBracketCodeTableChilderen()
		{
			OutcomeIndicatorSubIndicatorCollection.SaveChildCollection(this.outcomeIndicatorSubIndicators, true);
		}

		/// <summary>
		/// Synchronizes the OutcomeIndicatorSubIndicators collection
		/// </summary>
		public override void SynchronizeBracketCodeTableChilderen()
		{
			OutcomeIndicatorSubIndicatorCollection.SynchronizeChildCollection(this.outcomeIndicatorSubIndicators, true);
		}

		public OutcomeTypeCollection LookupOf_SubCodeID
		{
			get
			{
				return OutcomeTypeCollection.ActiveOutcomeTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of OutcomeIndicator objects
	/// </summary>
	[ElementType(typeof(OutcomeIndicator))]
	public class OutcomeIndicatorCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OutcomeIndicator elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOutcomeIndicatorCollection = this;
			else
				elem.ParentOutcomeIndicatorCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OutcomeIndicator elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OutcomeIndicator this[int index]
		{
			get
			{
				return (OutcomeIndicator)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OutcomeIndicator)oldValue, false);
			SetParentOnElem((OutcomeIndicator)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadOutcomeIndicatorsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOutcomeIndicatorsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared OutcomeIndicatorCollection which is cached in NSGlobal
		/// </summary>
		public static OutcomeIndicatorCollection ActiveOutcomeIndicators
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				OutcomeIndicatorCollection col = (OutcomeIndicatorCollection)NSGlobal.EnsureCachedObject("ActiveOutcomeIndicators", typeof(OutcomeIndicatorCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadOutcomeIndicatorsByActive(-1, true);
				}
				return col;
			}			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetOutcomeIndicators", -1, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadOutcomeIndicatorsByOutcomeType(int outcomeType)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOutcomeIndicatorsByOutcomeType", -1, this, false, new object[] { outcomeType });
		}	
	}
}
