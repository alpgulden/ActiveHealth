using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianDecisionReason]
	/// </summary>
	[SPAutoGen("usp_GetPhysicianDecisionReasons","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetPhysicianDecisionReasonsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertPhysicianDecisionReason")]
	[SPUpdate("usp_UpdatePhysicianDecisionReason")]
	[SPDelete("usp_DeletePhysicianDecisionReason")]
	[SPLoad("usp_LoadPhysicianDecisionReason")]
	[TableMapping("PhysicianDecisionReason","physicianDecisionReasonID")]
	public class PhysicianDecisionReason : BaseLookupWithNote
	{
		[NonSerialized]
		private PhysicianDecisionReasonCollection parentPhysicianDecisionReasonCollection;
		[ColumnMapping("PhysicianDecisionReasonID",StereoType=DataStereoType.FK)]
		private int physicianDecisionReasonID;
		[ColumnMapping("Notepad")]
		private string notepad;

		public static string LOMI = "LOMI";
		public static string MEDN = "MEDN"; // Medically Necessary
	
		public PhysicianDecisionReason()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianDecisionReason(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PhysicianDecisionReasonID
		{
			get { return this.physicianDecisionReasonID; }
			set { this.physicianDecisionReasonID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int physicianDecisionReasonID)
		{
			return base.Load(physicianDecisionReasonID);
		}

		/// <summary>
		/// Parent PhysicianDecisionReasonCollection that contains this element
		/// </summary>
		public PhysicianDecisionReasonCollection ParentPhysicianDecisionReasonCollection
		{
			get
			{
				return this.parentPhysicianDecisionReasonCollection;
			}
			set
			{
				this.parentPhysicianDecisionReasonCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PhysicianDecisionReason objects
	/// </summary>
	[ElementType(typeof(PhysicianDecisionReason))]
	public class PhysicianDecisionReasonCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianDecisionReason elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianDecisionReasonCollection = this;
			else
				elem.ParentPhysicianDecisionReasonCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianDecisionReason elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianDecisionReason this[int index]
		{
			get
			{
				return (PhysicianDecisionReason)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianDecisionReason)oldValue, false);
			SetParentOnElem((PhysicianDecisionReason)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPhysicianDecisionReasonsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPhysicianDecisionReasonsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PhysicianDecisionReasonCollection which is cached in NSGlobal
		/// </summary>
		public static PhysicianDecisionReasonCollection ActivePhysicianDecisionReasons
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PhysicianDecisionReasonCollection col = (PhysicianDecisionReasonCollection)NSGlobal.EnsureCachedObject("ActivePhysicianDecisionReasons", typeof(PhysicianDecisionReasonCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPhysicianDecisionReasonsByActive(-1, true);
				}
				return col;
			}			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetPhysicianDecisionReasons", -1, this, false);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns PhysicianDecisionReasonID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_PhysicianDecisionReasonIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("PhysicianDecisionReasonID", code);
		}	
	}
}
