using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianReview]
	/// </summary>
	[SPAutoGen("usp_GetPatientPhysicianReviews", null, ManuallyManaged=true)]
	[SPInsert("usp_InsertPhysicianReview")]
	[SPUpdate("usp_UpdatePhysicianReview")]
	[SPDelete("usp_DeletePhysicianReview")]
	[SPLoad("usp_LoadPhysicianReview")]
	[TableMapping("PhysicianReview","physicianReviewID")]
	public class PhysicianReview : BaseDataWithUserDefined,IImageOwner
	{
		[NonSerialized]
		private PhysicianReviewCollection parentPhysicianReviewCollection;
		[ColumnMapping("PhysicianReviewID",StereoType=DataStereoType.FK)]
		private int physicianReviewID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("PhysicianReviewRequestReasonID",StereoType=DataStereoType.FK)]			// lookup
		private int physicianReviewRequestReasonID;
		[ColumnMapping("PhysicianReviewDecisionID",StereoType=DataStereoType.FK)]				// lookup
		private int physicianReviewDecisionID;
		[ColumnMapping("StatusID",StereoType=DataStereoType.FK)]									// lookup
		private int statusID;
		[ColumnMapping("StatusChangedBy",StereoType=DataStereoType.FK)]
		private int statusChangedBy;
		[ColumnMapping("StatusChangeTime")]
		private DateTime statusChangeTime;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("ProblemID",StereoType=DataStereoType.FK)]
		private int problemID;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ClinicalReviewDecisionID",StereoType=DataStereoType.FK)]		// what's this???  is it physicianReviewDecisionID?
		private int clinicalReviewDecisionID;
		
		private int statusIDWhenLoaded;
		private PhysicianRequestCollection physicianRequests;				// keeps track of the changes in status
		private ImageLinkCollection images;
		private AutoActivityManager autoActivityManager;
		private Patient patient;
	
		public PhysicianReview()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianReview(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}
		
		/// <summary>
		/// Create a physician review linked to the given clinical decision
		/// </summary>
		/// <param name="initNew"></param>
		public PhysicianReview(ClinicalReviewDecision clinicalDecision)
		{
			this.NewRecord();
			this.clinicalReviewDecisionID = clinicalDecision.ClinicalReviewDecisionID;
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// track the change of statusID.
			this.statusIDWhenLoaded = this.statusID;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			bool initialSave = this.IsNew;

			if (this.IsNew || this.statusID != this.statusIDWhenLoaded)
			{
				// status changed.
				this.SetStatusChangingUser();
			}

			base.InternalSave();

			#region Trigger AutoActivities - ER2, ER5
			
			if (initialSave)
			{
				PatientCoverage patCov = null;

				if (this.eventID != 0)
				{
					// access event and use it's context
					Event eventObj = this.GetEvent();
					autoActivityManager = this.parentPhysicianReviewCollection.EnsureAutoActivityManager(eventObj.Patient, eventObj);
					AutoActivity_PhysicianReviewForEventInitialSave();	// ER2
				}
				else if (this.referralDetailID != 0)
				{
					// access referral and use it's context.
					ReferralDetail refDetail = this.GetReferralDetail();
					if (refDetail != null)
					{
						Referral referral = refDetail.GetReferral();
						if (referral != null)
						{
							autoActivityManager = this.parentPhysicianReviewCollection.EnsureAutoActivityManager(referral.Patient, referral);
							AutoActivity_PhysicianReviewForReferralInitialSave();	// ER5
						}
					}
				}
			}

			#endregion

			// Save the child collections here.

			// save child tables that are managed in-memory
			this.SavePhysicianRequests();
		}

		/// <summary>
		/// ER2	- Physician Review for Event Initial Save
		/// This is triggered when a new physician review is saved for an event.
		/// </summary>
		public void AutoActivity_PhysicianReviewForEventInitialSave()
		{
			autoActivityManager.Execute(AutoActivityRuleType.ER2, this.SqlData.Transaction);
		}

		/// <summary>
		/// ER5	- Physician Review for Referral Initial Save
		/// This is triggered when a new physician review is saved for a referral detail.
		/// </summary>
		public void AutoActivity_PhysicianReviewForReferralInitialSave()
		{
			autoActivityManager.Execute(AutoActivityRuleType.ER5, this.SqlData.Transaction);
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@REVIEWID@")]
		public int PhysicianReviewID
		{
			get { return this.physicianReviewID; }
			set { this.physicianReviewID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewRequestReasonID", "PhysicianReviewRequestReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@REQUESTREASON@")]
		public int PhysicianReviewRequestReasonID
		{
			get { return this.physicianReviewRequestReasonID; }
			set { this.physicianReviewRequestReasonID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewDecisionID", "PhysicianReviewDecisionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@DECISION@")]
		public int PhysicianReviewDecisionID
		{
			get { return this.physicianReviewDecisionID; }
			set { this.physicianReviewDecisionID = value; }
		}

		[FieldValuesMember("LookupOf_StatusID", "StatusId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int StatusID
		{
			get { return this.statusID; }
			set { this.statusID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime StatusChangeTime
		{
			get { return this.statusChangeTime; }
			set { this.statusChangeTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProblemID
		{
			get { return this.problemID; }
			set { this.problemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ValidatorMember("Vld_EndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		// what's this?
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ClinicalReviewDecisionID
		{
			get { return this.clinicalReviewDecisionID; }
			set { this.clinicalReviewDecisionID = value; }
		}

		/// <summary>
		/// Load the patient related to this physician review and return it.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientID == 0)
				return null;

			Patient patient = new Patient();
			patient.SqlData.Transaction = this.SqlData.Transaction;
			if (patient.Load(patientID))
				return patient;
			else
				return null;

		}

		/// <summary>
		/// Load and cache the patient related to this physician review.
		/// </summary>
		public Patient Patient
		{
			get 
			{ 
				if (this.patient == null)
					this.patient = GetPatient();
				return this.patient; 
			}
		}
		
		/// <summary>
		/// Load the event related to this physician and return it.
		/// </summary>
		/// <returns></returns>
		public Event GetEvent()
		{
			if (this.parentPhysicianReviewCollection != null)
				if (this.parentPhysicianReviewCollection.ParentEvent != null)
					return this.parentPhysicianReviewCollection.ParentEvent;

			if (this.eventID == 0)
				return null;

			Event eventObj = new Event();
			eventObj.SqlData.Transaction = this.SqlData.Transaction;
			if (eventObj.Load(this.Patient, eventID))
				return eventObj;
			else
				return null;

		}

		/// <summary>
		/// Load the Referral Detail related to this physician and return it.
		/// </summary>
		/// <returns></returns>
		public ReferralDetail GetReferralDetail()
		{
			//if (this.parentPhysicianReviewCollection != null)
			//	if (this.parentPhysicianReviewCollection.ParentEvent != null)
			//		return this.parentPhysicianReviewCollection.ParentReferralDetail;

			if (this.referralDetailID == 0)
				return null;

			ReferralDetail refDetail = new ReferralDetail();
			refDetail.SqlData.Transaction = this.SqlData.Transaction;
			if (refDetail.Load(this.referralDetailID))
				return refDetail;
			else
				return null;

		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int physicianReviewID)
		{
			return base.Load(physicianReviewID);
		}

		/// <summary>
		/// Parent PhysicianReviewCollection that contains this element
		/// </summary>
		public PhysicianReviewCollection ParentPhysicianReviewCollection
		{
			get
			{
				return this.parentPhysicianReviewCollection;
			}
			set
			{
				this.parentPhysicianReviewCollection = value; // parent is set when added to a collection
			}
		}

		public PhysicianReviewRequestReasonCollection LookupOf_PhysicianReviewRequestReasonID
		{
			get
			{
				return PhysicianReviewRequestReasonCollection.ActivePhysicianReviewRequestReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewDecisionCollection LookupOf_PhysicianReviewDecisionID
		{
			get
			{
				return PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions; // Acquire a shared instance from the static member of collection
			}
		}

		public SystemStatusCollection LookupOf_StatusID
		{
			get
			{
				return SystemStatusCollection.ActiveSystemStatuses; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Child PhysicianRequests mapped to related rows of table PhysicianRequest where [PhysicianReviewID] = [PhysicianReviewID]
		/// </summary>
		[SPLoadChild("usp_LoadPhysicianReviewRequests", "physicianReviewID")]
		public PhysicianRequestCollection PhysicianRequests
		{
			get { return this.physicianRequests; }
			set
			{
				this.physicianRequests = value;
				if (value != null)
					value.ParentPhysicianReview = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PhysicianRequests collection
		/// </summary>
		public void LoadPhysicianRequests(bool forceReload)
		{
			this.physicianRequests = (PhysicianRequestCollection)PhysicianRequestCollection.LoadChildCollection("PhysicianRequests", this, typeof(PhysicianRequestCollection), physicianRequests, forceReload, null);
		}

		/// <summary>
		/// Saves the PhysicianRequests collection
		/// </summary>
		public void SavePhysicianRequests()
		{
			PhysicianRequestCollection.SaveChildCollection(this.physicianRequests, true);
		}

		/// <summary>
		/// Synchronizes the PhysicianRequests collection
		/// </summary>
		public void SynchronizePhysicianRequests()
		{
			PhysicianRequestCollection.SynchronizeChildCollection(this.physicianRequests, true);
		}

		#region Images Overriden
		/// <summary>
		/// Child Outcomes mapped to related rows of table Outcome where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadPhysicianReviewImages", "physicianReviewID")]
		public ImageLinkCollection Images
		{
			get { return this.images; }
			set
			{
				this.images = value;
				if (value != null)
					value.ParentPhysicianReview = this; // set this as a parent of the child collection
			}
		}
				
		/// <summary>
		/// Loads the Outcomes collection
		/// </summary>
		public void LoadImages(bool forceReload)
		{
			this.images = (ImageLinkCollection)ImageLinkCollection.LoadChildCollection("Images", this, typeof(ImageLinkCollection), images, forceReload, null);
		}

		/// <summary>
		/// Saves the Outcomes collection
		/// </summary>
		public void SaveImages()
		{
			ImageLinkCollection.SaveChildCollection(this.images, true);
		}

		/// <summary>
		/// Synchronizes the Outcomes collection
		/// </summary>
		public void SynchronizeImages()
		{
			ImageLinkCollection.SynchronizeChildCollection(this.images, true);
		}

		#endregion

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.StatusCode = SystemStatus.OPEN;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public string StatusCode
		{
			get { return SystemStatusCollection.ActiveSystemStatuses.Lookup_CodeByStatusId(this.statusID); }
			set { this.statusID = SystemStatusCollection.ActiveSystemStatuses.Lookup_StatusIdByCode(value); }
		}
	}

	/// <summary>
	/// Strongly typed collection of PhysicianReview objects
	/// </summary>
	[ElementType(typeof(PhysicianReview))]
	public class PhysicianReviewCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		private AutoActivityManager autoActivityManager;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianReview elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianReviewCollection = this;
			else
				elem.ParentPhysicianReviewCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianReview elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianReview this[int index]
		{
			get
			{
				return (PhysicianReview)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianReview)oldValue, false);
			SetParentOnElem((PhysicianReview)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Event ParentEvent
		{
			get { return this.ParentDataObject as Event; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PhysicianReview elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PhysicianReview)value, true);
			base.OnInsertComplete (index, value);		
		}

		public ActiveAdvice.DataLayer.AutoActivityManager AutoActivityManager
		{
			get { return this.autoActivityManager; }
			set { this.autoActivityManager = value; }
		}

		public AutoActivityManager EnsureAutoActivityManager(Patient patient, BaseForEventCMSReferral erc)
		{
			if (this.autoActivityManager == null)
			{
				if (erc.PatientSubscriberLog != null)
					autoActivityManager = new AutoActivityManager(patient, erc.PatientSubscriberLog.PatientCoverage, erc.GetPrimaryProblem(), erc);
			}
			return this.autoActivityManager;
		}

		protected override void SaveAsChild(bool removeDeleted)
		{
			this.autoActivityManager = null;	// reset auto-activity manager

			base.SaveAsChild (removeDeleted);
		}

		/// <summary>
		/// Load all physician reviews of the patient.
		/// </summary>
		public int LoadPatientPhysicianReviews(int maxRecords, int patientID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientPhysicianReviews", maxRecords, this, false, new object[] { patientID });
		}


	}
}
