using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ClinicalReviewUnit]
	/// </summary>
	[SPAutoGen("usp_GetClinicalReviewUnitbyCode","SelectAllByGivenArgs.sptpl","code")]
	[SPAutoGen("usp_GetClinicalReviewUnits","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetClinicalReviewUnitsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertClinicalReviewUnit")]
	[SPUpdate("usp_UpdateClinicalReviewUnit")]
	[SPDelete("usp_DeleteClinicalReviewUnit")]
	[SPLoad("usp_LoadClinicalReviewUnit")]
	[TableMapping("ClinicalReviewUnit","clinicalReviewUnitID")]
	public class ClinicalReviewUnit : BaseLookupWithTwoSubCode
	{
		[NonSerialized]
		private ClinicalReviewUnitCollection parentClinicalReviewUnitCollection;
		[ColumnMapping("ClinicalReviewUnitID",StereoType=DataStereoType.FK)]
		private int clinicalReviewUnitID;
		[ColumnMapping("ReportUnitID")]
		private int reportUnitID;
		[ColumnMapping("FreqDurUnit")]
		private bool freqDurUnit;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ClinicalReviewUnit()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ClinicalReviewUnit(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ClinicalReviewUnitID
		{
			get { return this.clinicalReviewUnitID; }
			set { this.clinicalReviewUnitID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ReportUnitID
		{
			get { return this.reportUnitID; }
			set { this.reportUnitID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool FreqDurUnit
		{
			get { return this.freqDurUnit; }
			set { this.freqDurUnit = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldValuesMember("LookupOf_SubCodeStr", "CodeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@REPORTUNITID@")]
		public override int SubCodeID
		{
			get { return this.reportUnitID; }
			set { this.reportUnitID = value; }
		}


		[FieldValuesMember("ValuesOf_FreqDurUnit")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@FREQDURUNIT@")]
		public override int SubCodeExtID
		{
			get { if(this.freqDurUnit)
					return 1;
				  else
					return 2;
			}
			set { if(value==1)
					 this.freqDurUnit = true;
					else
					  this.freqDurUnit = false; 
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int clinicalReviewUnitID)
		{
			return base.Load(clinicalReviewUnitID);
		}

		/// <summary>
		/// Parent ClinicalReviewUnitCollection that contains this element
		/// </summary>
		public ClinicalReviewUnitCollection ParentClinicalReviewUnitCollection
		{
			get
			{
				return this.parentClinicalReviewUnitCollection;
			}
			set
			{
				this.parentClinicalReviewUnitCollection = value; // parent is set when added to a collection
			}
		}

		public object[,] ValuesOf_FreqDurUnit
		{
			get
			{
				return new object[,] {{1,"Show Frequency and Duration Fields"},{2,"Do Not Show Frequency and Duration Fields"}};
			}
		}

		public ReportUnitCollection LookupOf_SubCodeStr
		{
			get
			{
				return ReportUnitCollection.ActiveReportUnits; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		/// <summary>
		/// Loads the object specified by parameters from table
		/// </summary>
		public bool Load(string code)
		{
			// TODO: Specify stored procedure name correctly.
			return SqlData.SPExecReadObj("usp_GetClinicalReviewUnitbyCode", this, false, code);
		}
	}

	/// <summary>
	/// Strongly typed collection of ClinicalReviewUnit objects
	/// </summary>
	[ElementType(typeof(ClinicalReviewUnit))]
	public class ClinicalReviewUnitCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClinicalReviewUnit elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClinicalReviewUnitCollection = this;
			else
				elem.ParentClinicalReviewUnitCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClinicalReviewUnit elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClinicalReviewUnit this[int index]
		{
			get
			{
				return (ClinicalReviewUnit)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClinicalReviewUnit)oldValue, false);
			SetParentOnElem((ClinicalReviewUnit)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadClinicalReviewUnitsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetClinicalReviewUnitsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ClinicalReviewUnitCollection which is cached in NSGlobal
		/// </summary>
		public static ClinicalReviewUnitCollection ActiveClinicalReviewUnits
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ClinicalReviewUnitCollection col = (ClinicalReviewUnitCollection)NSGlobal.EnsureCachedObject("ActiveClinicalReviewUnits", typeof(ClinicalReviewUnitCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadClinicalReviewUnitsByActive(-1, true);
				}
				return col;
			}			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetClinicalReviewUnits", -1, this, false);
		}
	}
}
