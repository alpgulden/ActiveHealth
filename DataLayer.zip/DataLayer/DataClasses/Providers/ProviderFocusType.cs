using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProviderFocusTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllProviderFocusTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetProviderFocusTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertProviderFocusType")]
	[SPUpdate("usp_UpdateProviderFocusType")]
	[SPDelete("usp_DeleteProviderFocusType")]
	[SPLoad("usp_LoadProviderFocusType")]
	[TableMapping("ProviderFocusType","providerFocusTypeID")]
	public class ProviderFocusType : BaseLookupWithNote
	{
		[NonSerialized]
		private ProviderFocusTypeCollection parentProviderFocusTypeCollection;
		[FieldValuesMember("LookupOf_providerFocusTypeID", "ProviderFocusTypeID", "Focus")]
		[ColumnMapping("ProviderFocusTypeID",StereoType=DataStereoType.FK)]
		private int providerFocusTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
		
		
		public ProviderFocusType()
		{			
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]	
		public int ProviderFocusTypeID
		{
			get { return this.providerFocusTypeID; }
			set { this.providerFocusTypeID = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int providerFocusTypeID)
		{
			return base.Load(providerFocusTypeID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int providerFocusTypeID)
		{
			
			base.Delete(providerFocusTypeID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Parent ProviderFocusTypeCollection that contains this element
		/// </summary>
		public ProviderFocusTypeCollection ParentProviderFocusTypeCollection
		{
			get
			{
				return this.parentProviderFocusTypeCollection;
			}
			set
			{
				this.parentProviderFocusTypeCollection = value; // parent is set when added to a collection
			}
		}

		public ProviderFocusTypeCollection LookupOf_providerFocusTypeID
		{
			get
			{
				return ProviderFocusTypeCollection.ActiveProviderFocusTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ProviderFocusType objects
	/// </summary>
	[ElementType(typeof(ProviderFocusType))]
	public class ProviderFocusTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProviderFocusType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProviderFocusTypeCollection = this;
			else
				elem.ParentProviderFocusTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProviderFocusType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProviderFocusType this[int index]
		{
			get
			{
				return (ProviderFocusType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProviderFocusType)oldValue, false);
			SetParentOnElem((ProviderFocusType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadProviderFocusTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetProviderFocusTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ProviderFocusTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ProviderFocusTypeCollection ActiveProviderFocusTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ProviderFocusTypeCollection col = (ProviderFocusTypeCollection)NSGlobal.EnsureCachedObject("ActiveProviderFocusTypes", typeof(ProviderFocusTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadProviderFocusTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///   Load all Provider Focus Types.
		/// </summary>
		/// 
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllProviderFocusTypes", -1, this, false);
		}

	
		/// <summary>
		/// Searches for Provider Focus Types matching the given criteria.
		/// </summary>
		/// 
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchProviderFocusTypes", -1, this, false, code, description, active);
		}

 
		
	}
}
