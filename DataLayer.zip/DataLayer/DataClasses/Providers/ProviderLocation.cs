using System;
using ActiveAdvice.DataLayer;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProviderLocations]
	/// </summary>
	[SPAutoGen("usp_GetProviderLocationsByProviderID","SelectAllByGivenArgs.sptpl","providerID")]
	[SPAutoGen("usp_GetProviderLocationByProviderIDLocationID","SelectAllByGivenArgs.sptpl","providerID, locationID")]
	[SPExists("usp_ExistsProviderLocation")]
	[SPInsert("usp_InsertProviderLocation")]
	[SPUpdate("usp_UpdateProviderLocation")]
	[SPDelete("usp_DeleteProviderLocation")]
	[SPLoad("usp_LoadProviderLocation")]
	[TableMapping("ProviderLocation","providerLocationID")]
	public class ProviderLocation : BaseLocation, IContactOwner
	{
		[NonSerialized]
		private ProviderLocationCollection parentProviderLocationCollection;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("ProviderID")]
		private int providerID;

		private ProviderLocationServiceCollection services;
		private ProviderLocationNetworkLinkCollection networks;
		

		private ProviderLocationContactCollection providerLocationContacts;
		
		
	

		public ProviderLocation()
		{
			
		}

		/// <summary>
		/// Standard initializing constructor
		/// </summary>
		/// <param name="initNew"></param>
		public ProviderLocation(bool initNew)
		{
			if (initNew)
			{
				this.NewRecord();
				this.CreateTime = DateTime.Now;
			}
		}

		[FieldDescription("@ADDRESS@")]
		public string ServiceLocation
		{
			get 
			{
				return this.Location.FullAddress;
			}

		}

		//[FieldDescription("@Phone@")]
		public string Phone
		{
			get 
			{
				return this.Location.ServiceAddress.PhoneNumber1;
			}

		}


		
		[FieldDescription("@LOCATIONID@")]
		[ControlType(EnumControlTypes.TextBox)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}



		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			if (this.services != null)
				this.Services.Save();
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}
		}


		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			
			if (ProviderID == 0)
				return;
			Provider prov = new Provider();
			prov.Load(ProviderID);
			
			writer.AddFieldsOnNewLine(this, "ProviderLocationID","ServiceLocation");
			writer.AddField(this.Location, "FederalTaxID");
			writer.AddField(this, "AlternateID");

			
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int providerLocationID)
		{
			return base.Load(providerLocationID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int providerLocationID)
		{
			base.Delete(providerLocationID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state
			this.location = null;
			
		}



		/// <summary>
		/// Loads the Services collection
		/// </summary>
		public void LoadServices(bool forceReload)
		{
			this.services = (ProviderLocationServiceCollection)ProviderLocationServiceCollection.LoadChildCollection("Services", this, typeof(ProviderLocationServiceCollection), services, forceReload, null);
		}

		/// <summary>
		/// Saves the Services collection
		/// </summary>
		public void SaveServices()
		{
			ProviderLocationServiceCollection.SaveChildCollection(this.services, true);
		}



		/// <summary>
		/// Parent ProviderLocationCollection that contains this element
		/// </summary>
		public ProviderLocationCollection ParentProviderLocationCollection
		{
			get
			{
				return this.parentProviderLocationCollection;
			}
			set
			{
				this.parentProviderLocationCollection = value; // parent is set when added to a collection
			}
		}





		/// <summary>
		/// Child Services mapped to related rows of table ProviderLocationServices where [ProviderLocationID] = [ProviderLocationID]
		/// </summary>
		[SPLoadChild("usp_LoadProviderLocationServices", "ProviderLocationID")]
		public ProviderLocationServiceCollection Services
		{
			get { return this.services; }
			set
			{
				this.services = value;
				value.ParentProviderLocation = this; // set this as a parent of the child collection
			}
		}


		/// <summary>
		/// Synchronizes the Services collection
		/// </summary>
		public void SynchronizeServices()
		{
			ProviderLocationServiceCollection.SynchronizeChildCollection(this.services, true);
		}

		/// <summary>
		/// Child Networks mapped to related rows of table ProviderLocationNetworks where [ProviderLocationID] = [ProviderLocationID]
		/// </summary>
		[SPLoadChild("usp_LoadProviderLocationProviderLocationNetworks", "providerLocationID")]
		public ProviderLocationNetworkLinkCollection Networks
		{
			get { return this.networks; }
			set
			{
				this.networks = value;
				value.ParentProviderLocation = this; // set this as a parent of the child collection
					
			}
		}
			

		/// <summary>
		/// Executes a stored procedure usp_GetStatusForProviderLocationNetwork which retrieves the Network Status based on Plan ID, Start Date and Location ID 
		/// </summary>
		public object GetStatusForProviderLocationNetworks(int planId,DateTime startDate,int locationID)
		{
			return SqlData.SPExecScalar("usp_GetStatusForProviderLocationNetwork", new object[] { planId,startDate,locationID });
		}

		//		public ProviderLocationNetworkLinkCollection NetworkStatus
		//		{
		//			get { return this.networkStatus; }
		//			set
		//			{
		//				this.networkStatus = value;
		//				value.ParentProviderLocation = this; // set this as a parent of the child collection
		//					
		//			}
		//		}


		/// <summary>
		/// Loads the Networks collection
		/// </summary>
		public void LoadNetworks(bool forceReload)
		{
			if (this.networks != null)
				this.networks.Clear();
			this.networks = (ProviderLocationNetworkLinkCollection)ProviderLocationNetworkLinkCollection.LoadChildCollection("Networks", this, typeof(ProviderLocationNetworkLinkCollection), networks, forceReload,null);
		}
		
		

		/// <summary>
		/// Saves the Networks collection
		/// </summary>
		public void SaveNetworks()
		{
			ProviderLocationNetworkLinkCollection.SaveChildCollection(this.networks, true);
		}

		/// <summary>
		/// Synchronizes the Networks collection
		/// </summary>
		public void SynchronizeNetworks()
		{
			ProviderLocationNetworkLinkCollection.SynchronizeChildCollection(this.networks, true);
		}
		
		/// <summary>
		/// Child ProviderLocationContacts mapped to related rows of table ProviderLocationContact where [ProviderLocationID] = [ProviderLocationID]
		/// </summary>
		[SPLoadChild("usp_LoadProviderLocationContacts", "providerLocationID")]
		public ProviderLocationContactCollection ProviderLocationContacts
		{
			get { return this.providerLocationContacts; }
			set
			{
				this.providerLocationContacts = value;
				if (value != null)
					value.ParentProviderLocation = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ProviderLocationContacts collection
		/// </summary>
		public void LoadProviderLocationContacts(bool forceReload)
		{
			this.providerLocationContacts = (ProviderLocationContactCollection)ProviderLocationContactCollection.LoadChildCollection("ProviderLocationContacts", this, typeof(ProviderLocationContactCollection), providerLocationContacts, forceReload, null);
		}

		/// <summary>
		/// Saves the ProviderLocationContacts collection
		/// </summary>
		public void SaveProviderLocationContacts()
		{
			ProviderLocationContactCollection.SaveChildCollection(this.providerLocationContacts, true);
		}

		/// <summary>
		/// Synchronizes the ProviderLocationContacts collection
		/// </summary>
		public void SynchronizeProviderLocationContacts()
		{
			ProviderLocationContactCollection.SynchronizeChildCollection(this.providerLocationContacts, true);
		}

		#region IContactOwner Members

		public BaseDataCollectionClass GetContacts()
		{
			if (ProviderLocationContacts == null) LoadProviderLocationContacts(false);
			return ProviderLocationContacts;
		}

		public void LoadContacts(bool forceLoad)
		{
			this.LoadProviderLocationContacts(forceLoad);
		}

		public void SaveContacts()
		{
			this.SaveProviderLocationContacts();
		}

		public ContactOwnerType ContactOwnerType
		{
			get
			{
				return ContactOwnerType.ProviderLocation;
			}
		}

		#endregion

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			//this.Location.SqlData.UseTransaction(this.sqlData.Transaction);
			this.Location.SqlData.Transaction = this.SqlData.Transaction;
			this.Location.Save();
			//this.sqlData.EnsureTransaction();	// Don't open transaction in InternalSave.  Start your transaction in Custom Save method!
			this.CreatedBy	= 1;
			this.CreateTime	= DateTime.Now;

			this.SaveServices();
			this.SaveNetworks();

			/*	// No need to check for null and pass transaction.  This is automatic for child save as above.
			if (this.services != null)
			{
				this.Services.SqlData.Transaction = this.SqlData.Transaction;
				this.SaveServices();
			}
			if (this.networks != null)
			{
				this.Networks.SqlData.Transaction = this.SqlData.Transaction;
				this.SaveNetworks();
			}
			*/
			this.locationID = this.Location.LocationID;			
			
			base.InternalSave();
			//this.sqlData.CommitTransaction();
			
		}

		/// <summary>
		/// Load the provider location by the given providerID and locationID
		/// </summary>
		public bool Load(int providerID, int locationID)
		{
			return SqlData.SPExecReadObj("usp_GetProviderLocationByProviderIDLocationID", 
				this, false, new object[] { providerID, locationID });
		}
	}

	/// <summary>
	/// Strongly typed collection of ProviderLocation objects
	/// </summary>
	[ElementType(typeof(ProviderLocation))]
	public class ProviderLocationCollection : BaseLocationCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProviderLocation elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProviderLocationCollection = this;
			else
				elem.ParentProviderLocationCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProviderLocation elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProviderLocation this[int index]
		{
			get
			{
				return (ProviderLocation)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProviderLocation)oldValue, false);
			SetParentOnElem((ProviderLocation)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, ProviderLocation elem)
		{
			List.Insert(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ProviderLocation)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ProviderLocation elem)
		{
			return List.Add(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(ProviderLocation elem)
		{
			List.Remove(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((ProviderLocation)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/* Don't use this.
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(string filter, string sort)
		{
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForType(typeof(ProviderLocation), filter, sort);
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int SPLoad(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Parent Provider that contains this collection
		/// </summary>
		public Provider ParentProvider
		{
			get { return this.ParentDataObject as Provider; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Provider */ }
		}

		public void LoadLocationsWithFilter(int NetworkID, int ProviderID, Address addr, int planID, DateTime startDate)
		{
			Provider prov = new Provider();
			prov.ProviderID = ProviderID;
			object[] prms = {addr, NetworkID, prov, startDate};
			this.Clear();
			this.SqlData.SPExecReadCol("usp_LoadProviderLocationWithFilter",-1,this, prms, true, new string[] { "NetworkID", "PlanID","StartDate" }, new object[] { NetworkID, planID, SQLDataDirect.MakeDBValue(startDate)});
	}

		public void LoadLocationsWithFilter(int ProviderID, Address Addr)
		{
			Provider prov = new Provider();
			prov.ProviderID = ProviderID;
			object[] prms = { Addr, prov};
			this.Clear();
			this.SqlData.SPExecReadCol("usp_LoadProviderLocationWithFilter",-1,this, prms, true);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadProviderLocationsByProviderID(int maxRecords, int providerID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetProviderLocationsByProviderID", maxRecords, this, false, new object[] { providerID });
		}
	}
}
