using System;
using ActiveAdvice.DataLayer;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProviderFocuses]
	/// </summary>
	[SPInsert("usp_InsertProviderFocus")]
	[SPUpdate("usp_UpdateProviderFocus")]
	[SPDelete("usp_DeleteProviderFocus")]
	[SPLoad("usp_LoadProviderFocus")]
	[TableMapping("ProviderFocus","providerFocusID")]
	public class ProviderFocus : BaseData
	{
		[NonSerialized]
		private ProviderFocusCollection parentProviderFocusCollection;
		[ColumnMapping("ProviderFocusID",StereoType=DataStereoType.FK)]
		private int providerFocusID;
		[ColumnMapping("CreatedBy")]
		private int createdBy;

		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;

		[ColumnMapping("ProviderID")]
		private int providerID;
		[ColumnMapping("ProviderFocusTypeID",StereoType=DataStereoType.FK)]
		private int providerFocusTypeID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("TerminatedBy")]
		private int terminatedBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;

		[ColumnMapping("CreatedByName", JoinColumn="LoginName", JoinRelation="ProviderFocus.CreatedBy = [AAUser].UserID")]
		private string createdByStr;
		[ColumnMapping("ModifiedByName", JoinColumn="LoginName", JoinRelation="ProviderFocus.ModifiedBy = [AAUser].UserID")]
		private string modifiedByStr;
		[ColumnMapping("TerminatedByName", JoinColumn="LoginName", JoinRelation="ProviderFocus.TerminatedBy = [AAUser].UserID")]
		private string terminatedByStr;
		public string CreatedByStr
		{
			get { return this.createdByStr; }
		}

		public string ModifiedByStr
		{
			get { return this.modifiedByStr; }
		}

		public string TerminatedByStr
		{
			get { return this.terminatedByStr; }
		}
	
		public ProviderFocus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox,StereoType=DataStereoType.FK)]
		public int ProviderFocusID
		{
			get { return this.providerFocusID; }
			set { this.providerFocusID = value; }
		}




		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@CREATEDBY@")]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@ProviderID@")]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[FieldValuesMember("LookupOf_ProviderFocusTypeID", "ProviderFocusTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("Focus Type")]
		public int ProviderFocusTypeID
		{
			get { return this.providerFocusTypeID; }
			set { this.providerFocusTypeID = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int providerFocusID)
		{
			return base.Load(providerFocusID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int providerFocusID)
		{
			base.Delete(providerFocusID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Parent ProviderFocusCollection that contains this element
		/// </summary>
		public ProviderFocusCollection ParentProviderFocusCollection
		{
			get
			{
				return this.parentProviderFocusCollection;
			}
			set
			{
				this.parentProviderFocusCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		public ProviderFocusTypeCollection LookupOf_ProviderFocusTypeID
		{
			get
			{
				return ProviderFocusTypeCollection.ActiveProviderFocusTypes; // Acquire a shared instance from the static member of collection
			}
			set 
			{
				// remove
			}
		}

		[FieldDescription("@CODE@")]
		public string Code
		{
			get 
			{ 
				ProviderFocusType pfocusType = new ProviderFocusType();
				pfocusType.Load(this.providerFocusTypeID);
				return pfocusType.Code;
			}
		}

		[FieldDescription("@DESCRIPTION@")]
		public string Description
		{
			get 
			{
				ProviderFocusType pfocusType = new ProviderFocusType();
				pfocusType.Load(this.providerFocusTypeID);
				return pfocusType.Description;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@EFFECTIVEDATE@")]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
			[FieldDescription("@TERMINATIONDATE@")]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		[FieldDescription("@CREATETIME@")]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ProviderFocus objects
	/// </summary>
	[ElementType(typeof(ProviderFocus))]
	public class ProviderFocusCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProviderFocus elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProviderFocusCollection = this;
			else
				elem.ParentProviderFocusCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProviderFocus elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProviderFocus this[int index]
		{
			get
			{
				return (ProviderFocus)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProviderFocus)oldValue, false);
			SetParentOnElem((ProviderFocus)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, ProviderFocus elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ProviderFocus)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ProviderFocus elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(ProviderFocus elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((ProviderFocus)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/* Don't use this.
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(string filter, string sort)
		{
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForType(typeof(ProviderFocus), filter, sort);
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int SPLoad(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/* Don't use this.  It was using Dynamic SQL!
		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL( object param)
		{
			SQLParser sql = new SQLParser("select * from [ProviderFocuses] " +
			"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Parent Provider that contains this collection
		/// </summary>
		public Provider ParentProvider
		{
			get { return this.ParentDataObject as Provider; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Provider */ }
		}
	}
}
