using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProviderLanguages]
	/// </summary>
	[SPInsert("usp_InsertProviderLanguage")]
	[SPUpdate("usp_UpdateProviderLanguage")]
	[SPDelete("usp_DeleteProviderLanguage")]
	[SPLoad("usp_LoadProviderLanguage")]
	[TableMapping("ProviderLanguage","ProviderLanguageID")]
	public class ProviderLanguage : NetsoftUSA.DataLayer.BaseDataClass
	{
		[ColumnMapping("ProviderLanguageID",StereoType=DataStereoType.FK)]
		private int providerLanguageID;
		[ColumnMapping("ProviderID")]
		private int providerID;
		[ColumnMapping("LanguageID",StereoType=DataStereoType.FK)]
		private int languageID;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[NonSerialized]
		private ProviderLanguageCollection parentProviderLanguageCollection;

		[ColumnMapping("CreatedByName", JoinColumn="LoginName", JoinRelation="ProviderLanguage.CreatedBy = [AAUser].UserID")]
		private string createdByStr;
		public string CreatedByStr
		{
			get { return this.createdByStr; }
		}


	
		public ProviderLanguage()
		{
			//
			// TODO: Add constructor logic here
			//
		}




		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@PROVIDERID@")]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[FieldValuesMember("LookupOf_LanguageID", "LanguageID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@LANGUAGEID@")]
		public int LanguageID
		{
			get { return this.languageID; }
			set { this.languageID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@CREATETIME@")]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@CREATEDBY@")]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		///  Method returns the Language Description for current ProviderLanguage class
		/// </summary>
		/// <returns>Language Description</returns>
		public string Language
		{
			get 
			{
				Language lang = new Language();
				lang.Load(this.LanguageID);
				return lang.Description;	
			}
		}

		[FieldDescription("@CODE@")]
		public string Code
		{
			get 
			{ 
				Language lang = new Language();
				lang.Load(this.LanguageID);
				return lang.Code; }

		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int providerLanguageID)
		{
			return base.Load(providerLanguageID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int providerLanguageID)
		{
			base.Delete(providerLanguageID);		
		}

		/// <summary>
		/// Parent ProviderLanguageCollection that contains this element
		/// </summary>
		public ProviderLanguageCollection ParentProviderLanguageCollection
		{
			get
			{
				return this.parentProviderLanguageCollection;
			}
			set
			{
				this.parentProviderLanguageCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderLanguageID
		{
			get { return this.providerLanguageID; }
			set { this.providerLanguageID = value; }
		}

		public LanguageCollection LookupOf_LanguageID
		{
			get
			{
				return LanguageCollection.ActiveLanguages; // Acquire a shared instance from the static member of collection
			}
		}




	}

	/// <summary>
	/// Strongly typed collection of ProviderLanguage objects
	/// </summary>
	[ElementType(typeof(ProviderLanguage))]
	public class ProviderLanguageCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProviderLanguage elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProviderLanguageCollection = this;
			else
				elem.ParentProviderLanguageCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProviderLanguage elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProviderLanguage this[int index]
		{
			get
			{
				return (ProviderLanguage)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProviderLanguage)oldValue, false);
			SetParentOnElem((ProviderLanguage)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, ProviderLanguage elem)
		{
			List.Insert(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ProviderLanguage)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ProviderLanguage elem)
		{
			return List.Add(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(ProviderLanguage elem)
		{
			List.Remove(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((ProviderLanguage)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/* Don't use this.
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(string filter, string sort)
		{
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForType(typeof(ProviderLanguage), filter, sort);
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int SPLoad(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Parent Provider that contains this collection
		/// </summary>
		public Provider ParentProvider
		{
			get { return this.ParentDataObject as Provider; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Provider */ }
		}




	}
}
