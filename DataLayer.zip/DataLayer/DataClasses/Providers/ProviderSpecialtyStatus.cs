using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProviderSpecialtyStatus]
	/// </summary>
	[SPInsert("usp_InsertProviderSpecialtyStatus")]
	[SPUpdate("usp_UpdateProviderSpecialtyStatus")]
	[SPDelete("usp_DeleteProviderSpecialtyStatus")]
	[TableMapping("ProviderSpecialtyStatus","providerSpecialtyStatusID")]
	public class ProviderSpecialtyStatus : BaseDataClass
	{
		[ColumnMapping("ProviderSpecialtyStatusID",(int)0)]
		private int providerSpecialtyStatusID;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
	
		public ProviderSpecialtyStatus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ProviderSpecialtyStatusID
		{
			get { return this.providerSpecialtyStatusID; }
			set { this.providerSpecialtyStatusID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}




		/// <summary>
		/// Reads multiple objects of this type from source data reader into the given collection
		/// </summary>
		public int ReadCollection(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords, System.Collections.IList collection)
		{
			return SqlData.ReadCollection(sourceReader, maxRecords, collection, typeof(ProviderSpecialtyStatus), true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int providerSpecialtyStatusID)
		{
			return base.Load(providerSpecialtyStatusID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int providerSpecialtyStatusID)
		{
			base.Delete(providerSpecialtyStatusID);		
		}

		/// <summary>
		/// Parent ProviderSpecialty that contains this object
		/// </summary>
		public ProviderSpecialty ParentProviderSpecialty
		{
			get { return this.ParentDataObject as ProviderSpecialty; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ProviderSpecialty */ }
		}
	}
}
