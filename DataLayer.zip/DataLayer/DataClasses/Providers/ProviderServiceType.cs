using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProviderServiceTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllProviderServiceTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetProviderLocationServiceTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertProviderServiceType")]
	[SPUpdate("usp_UpdateProviderServiceType")]
	[SPDelete("usp_DeleteProviderServiceType")]
	[SPLoad("usp_LoadProviderServiceType")]
	[TableMapping("ProviderServiceType","providerServiceTypeID")]
	public class ProviderServiceType : BaseLookupWithNote
	{
		[NonSerialized]
		private ProviderServiceTypeCollection parentProviderServiceTypeCollection;
		[ColumnMapping("ProviderServiceTypeID",StereoType=DataStereoType.FK)]
		private int providerServiceTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public ProviderServiceType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ProviderServiceTypeID
		{
			get { return this.providerServiceTypeID; }
			set { this.providerServiceTypeID = value; }
			
		}


	

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Reads multiple objects of this type from source data reader into the given collection
		/// </summary>
		public int ReadCollection(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords, System.Collections.IList collection)
		{
			return SqlData.ReadCollection(sourceReader, maxRecords, collection, typeof(ProviderServiceType), true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			base.Save();		
			NSGlobal.ClearCache();
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int providerServiceTypeID)
		{
			return base.Load(providerServiceTypeID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int providerServiceTypeID)
		{
			base.Delete(providerServiceTypeID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{

			this.NewRecord(); // initialize record state
			
		}



		/// <summary>
		/// Parent ProviderServiceTypeCollection that contains this element
		/// </summary>
		public ProviderServiceTypeCollection ParentProviderServiceTypeCollection
		{
			get
			{
				return this.parentProviderServiceTypeCollection;
			}
			set
			{
				this.parentProviderServiceTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active	= true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of ProviderServiceType objects
	/// </summary>
	[ElementType(typeof(ProviderServiceType))]
	public class ProviderServiceTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProviderServiceType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProviderServiceTypeCollection = this;
			else
				elem.ParentProviderServiceTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProviderServiceType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProviderServiceType this[int index]
		{
			get
			{
				return (ProviderServiceType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProviderServiceType)oldValue, false);
			SetParentOnElem((ProviderServiceType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, ProviderServiceType elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ProviderServiceType)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ProviderServiceType elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(ProviderServiceType elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((ProviderServiceType)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/* Don't use this.
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(string filter, string sort)
		{
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForType(typeof(ProviderServiceType), filter, sort,);
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int SPLoad(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/* Don't use this.
		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL( object param)
		{
			SQLParser sql = new SQLParser("select * from [ProviderServiceTypes] " +
			"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadProviderLocationServiceTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetProviderLocationServiceTypesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared ProviderServiceTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ProviderServiceTypeCollection ActiveProviderServiceTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ProviderServiceTypeCollection col = (ProviderServiceTypeCollection)NSGlobal.EnsureCachedObject("ActiveProviderServiceTypes", typeof(ProviderServiceTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadProviderLocationServiceTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Loads all Provider Service Types
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllProviderServiceTypes", -1, this, false);
		}

		/// <summary>
		/// Searches for Provider Service Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchProviderServiceTypes", -1, this, false, code, description, active);
		}
	}
}
