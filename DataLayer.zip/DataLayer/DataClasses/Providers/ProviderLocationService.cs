using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProviderLocationServices]
	/// </summary>
	[SPInsert("usp_InsertProviderLocationService")]
	[SPUpdate("usp_UpdateProviderLocationService")]
	[SPDelete("usp_DeleteProviderLocationService")]
	[SPLoad("usp_LoadProviderLocationService")]
	[TableMapping("ProviderLocationService","providerLocationServiceID")]
	public class ProviderLocationService : NetsoftUSA.DataLayer.BaseDataClass
	{
		[NonSerialized]
		private ProviderLocationServiceCollection parentProviderLocationServiceCollection;
		[ColumnMapping("ProviderLocationServiceID",StereoType=DataStereoType.FK)]
		private int providerLocationServiceID;
		[ColumnMapping("CreateTime",ValuesForNull.NullDateTime)]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("TerminateTime",ValuesForNull.NullDateTime)]
		private DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;

		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("ProviderServiceTypeID",StereoType=DataStereoType.FK)]
		private int providerServiceTypeID;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;

		[ColumnMapping("CreatedByName", JoinColumn="LoginName", JoinRelation="ProviderLocationService.CreatedBy = [AAUser].UserID")]
		private string createdByStr;
		[ColumnMapping("ModifiedByName", JoinColumn="LoginName", JoinRelation="ProviderLocationService.ModifiedBy = [AAUser].UserID")]
		private string modifiedByStr;
		[ColumnMapping("TerminatedByName", JoinColumn="LoginName", JoinRelation="ProviderLocationService.TerminatedBy = [AAUser].UserID")]
		private string terminatedByStr;

		public string CreatedByString
		{
			get { return this.createdByStr; }
		}

		public string ModifiedByString
		{
			get { return this.modifiedByStr; }
		}

		public string TerminatedByString
		{
			get { return this.terminatedByStr; }
		}

	
		public ProviderLocationService()
		{
		
		}

		public string DateCreated
		{
			get { return this.CreateTime.Date.ToShortDateString(); }
		}

		public string Description
		{
			get 
			{
				ProviderServiceType provServType = new ProviderServiceType();
				provServType.Load(this.ProviderServiceTypeID);
				return provServType.Description;
			}
		}


		[ControlType(EnumControlTypes.TextBox)]
		[FieldDescription("@ProviderLocationServiceID@")]
		public int ProviderLocationServiceID
		{
			get { return this.providerLocationServiceID; }
			set { this.providerLocationServiceID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DATEADDED@")]
		public System.DateTime CreateTime
		{
			get { return this.createTime.Date; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@ADDEDBY@")]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@TerminateTime@")]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime.Date;; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@TerminatedBy@")]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}


		[FieldValuesMember("LookupOf_ProviderServiceTypeID", "ProviderServiceTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@SERVICETYPEID@")]
		public int ProviderServiceTypeID
		{
			get { return this.providerServiceTypeID; }
			set { this.providerServiceTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@PROVIDERLOCATIONID@")]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int providerLocationServiceID)
		{
			return base.Load(providerLocationServiceID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int providerLocationServiceID)
		{
			base.Delete(providerLocationServiceID);		
		}

		/// <summary>
		/// Parent ProviderLocationServiceCollection that contains this element
		/// </summary>
		public ProviderLocationServiceCollection ParentProviderLocationServiceCollection
		{
			get
			{
				return this.parentProviderLocationServiceCollection;
			}
			set
			{
				this.parentProviderLocationServiceCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates/Inserts/Deletes/Loads a record depending on its status flags.
		/// </summary>
		public new void Synchronize()
		{
			base.Synchronize();		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.ModifiedBy = 0;
			this.CreatedBy  = 0;
			this.TerminatedBy = 0;
			this.NewRecord(); // initialize record state

		}

		public ProviderServiceTypeCollection LookupOf_ProviderServiceTypeID
		{
			get
			{
				return ProviderServiceTypeCollection.ActiveProviderServiceTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate.Date; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate.Date; }
			set { this.terminationDate = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ProviderLocationService objects
	/// </summary>
	[ElementType(typeof(ProviderLocationService))]
	public class ProviderLocationServiceCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ProviderLocationServiceID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProviderLocationService elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProviderLocationServiceCollection = this;
			else
				elem.ParentProviderLocationServiceCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProviderLocationService elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProviderLocationService this[int index]
		{
			get
			{
				return (ProviderLocationService)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProviderLocationService)oldValue, false);
			SetParentOnElem((ProviderLocationService)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, ProviderLocationService elem)
		{
			List.Insert(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ProviderLocationService)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ProviderLocationService elem)
		{
			return List.Add(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(ProviderLocationService elem)
		{
			List.Remove(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((ProviderLocationService)value, false);
			base.OnRemoveComplete (index, value);		
		}



		/// <summary>
		/// Parent ProviderLocation that contains this collection
		/// </summary>
		public ProviderLocation ParentProviderLocation
		{
			get { return this.ParentDataObject as ProviderLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ProviderLocation */ }
		}

		/* Don't use this.
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(string filter, string sort)
		{
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForType(typeof(ProviderLocationService), filter, sort);
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int SPLoad(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Calls Synchronize methods of all collection elements.
		/// </summary>
		public void Synchronize()
		{
			this.SynchronizeElements();		
		}

		/// <summary>
		/// Hashtable based index on providerLocationServiceID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ProviderLocationServiceID
		{
			get
			{
				if (this.indexBy_ProviderLocationServiceID == null)
					this.indexBy_ProviderLocationServiceID = new CollectionIndexer(this, new string[] { "providerLocationServiceID" }, true);
				return this.indexBy_ProviderLocationServiceID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on providerLocationServiceID fields returns the object.  Uses the IndexBy_ProviderLocationServiceID indexer.
		/// </summary>
		public ProviderLocationService FindBy(int providerLocationServiceID)
		{
			return (ProviderLocationService)this.IndexBy_ProviderLocationServiceID.GetObject(providerLocationServiceID);
		}
	}
}
