using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProviderLocationContact]
	/// </summary>
	[SPInsert("usp_InsertProviderLocationContact")]
	[SPLoad("usp_LoadProviderLocationContact")]
	[TableMapping("ProviderLocationContact","providerLocationID,contactID",true)]
	[TableLinkageAttribute(typeof(ProviderLocation), "providerLocationID", typeof(Contact), "contactID")]
	public class ProviderLocationContact : BaseLinkageClass
	{
		[NonSerialized]
		private ProviderLocationContactCollection parentProviderLocationContactCollection;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("ContactID",StereoType=DataStereoType.FK)]
		private int contactID;
	
		public ProviderLocationContact()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ContactID
		{
			get { return this.contactID; }
			set { this.contactID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent ProviderLocationContactCollection that contains this element
		/// </summary>
		public ProviderLocationContactCollection ParentProviderLocationContactCollection
		{
			get
			{
				return this.parentProviderLocationContactCollection;
			}
			set
			{
				this.parentProviderLocationContactCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ProviderLocationContact objects
	/// </summary>
	[ElementType(typeof(ProviderLocationContact))]
	public class ProviderLocationContactCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProviderLocationContact elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProviderLocationContactCollection = this;
			else
				elem.ParentProviderLocationContactCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProviderLocationContact elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProviderLocationContact this[int index]
		{
			get
			{
				return (ProviderLocationContact)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProviderLocationContact)oldValue, false);
			SetParentOnElem((ProviderLocationContact)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent ProviderLocation that contains this collection
		/// </summary>
		public ProviderLocation ParentProviderLocation
		{
			get { return this.ParentDataObject as ProviderLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ProviderLocation */ }
		}
	}


}
