using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	public enum ProviderSpecialtyBoardStatus
	{
		CERTIFIED	= 1,
		NOTELIGIBLE = 2,
	    ELIGIBLE    = 3,
	    UNKNOWN		= 4
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [ProviderSpecialties]
	/// </summary>
	[SPAutoGen("usp_GetProviderLocationByProviderIDSpecialtyID","SelectAllByGivenArgs.sptpl","providerID, specialtyID")]
	[SPAutoGen("usp_GetPrimarySpecialtyByProviderIDPrimary","SelectAllByGivenArgs.sptpl","providerID, primary")]
	[SPInsert("usp_InsertProviderSpecialty")]
	[SPUpdate("usp_UpdateProviderSpecialty")]
	[SPDelete("usp_DeleteProviderSpecialty")]
	[SPLoad("usp_LoadProviderSpecialty")]
	[TableMapping("ProviderSpecialty","providerSpecialtyID")]
	public class ProviderSpecialty : BaseData 
	{
		[ColumnMapping("ProviderSpecialtyID")]
		private int providerSpecialtyID;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]
		private int providerID;
		[ColumnMapping("SpecialtyID",StereoType=DataStereoType.FK)]
		private int specialtyID;
		[ColumnMapping("Primary")]
		private bool primary;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("BoardStatus")]
		private int boardStatus;
		[NonSerialized]
		protected ProviderSpecialtyCollection parentProviderSpecialtyCollection;

		[ColumnMapping("CreatedByName", JoinColumn="LoginName", JoinRelation="ProviderSpecialty.CreatedBy = [AAUser].UserID")]
		private string createdByStr;

		[FieldDescription("@CREATEDBY@")]
		public string CreatedByStr
		{
			get { return this.createdByStr; }
		}

	
		public ProviderSpecialty()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox)]
		public int ProviderSpecialtyID
		{
			get { return this.providerSpecialtyID; }
			set { this.providerSpecialtyID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public int Code
		{
			get { return this.providerSpecialtyID; }
			//set { this.providerSpecialtyID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@ISPRIMARY@")]
		public bool Primary
		{
			get { return this.primary; }
			set { this.primary = value; }
		}



		[FieldDescription("@DESCRIPTION@")]
		public string Description
		{
			get 
			{
				Specialty specialty = new Specialty();
				specialty.Load(this.specialtyID);
				return specialty.Description;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@PROVIDERID@")]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[FieldValuesMember("LookupOf_SpecialtyID", "SpecialtyID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@SPECIALTYID@")]
		public int SpecialtyID
		{
			get { return this.specialtyID; }
			set { this.specialtyID = value; }
		}

		
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@SPECIALTYID@")]
		public int ID
		{
			get { return this.specialtyID; }
			set { this.specialtyID = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		///  Changes the status of current Specialty. Takes in three parameters
		///  returns true if the operation succeeds.
		/// </summary>
		/// <param name="startDate">New start date</param>
		/// <param name="endDate">New end date</param>
		/// <param name="boardStatus">Board Status</param>
		/// <returns>Returns true if operation succeeds false otherwise.</returns>
		public bool ChangeStatus(DateTime startDate, DateTime endDate, int boardStatus)
		{
			bool operationResult = true;
			try 
			{
				this.StartDate		= startDate;
				this.EndDate		= endDate;
				this.BoardStatus	= boardStatus;
				
			}
			catch (Exception ex)
			{
				throw new Exception("Could not update specialty status: " + ex.Message);
				
			}
			return operationResult;
			

		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int providerSpecialtyID)
		{
			return base.Load(providerSpecialtyID);			
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int providerSpecialtyID)
		{
			base.Delete(providerSpecialtyID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Parent ProviderSpecialtyCollection that contains this element
		/// </summary>
		public ProviderSpecialtyCollection ParentProviderSpecialtyCollection
		{
			get
			{
				return this.parentProviderSpecialtyCollection;
			}
			set
			{
				this.parentProviderSpecialtyCollection = value; // parent is set when added to a collection
			}
		}

		[GenericScript("Vld_EndDate", "@EndDate@ != null && @EndDate@ >= @StartDate@;")]
		protected string Vld_EndDate
		{
			get
			{
				return "@ERRTERMDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
				/*DateTime terminationDate = (DateTime)this.Get("terminationDate");
				DateTime effectiveDate = (DateTime)this.Get("effectiveDate");
				if (terminationDate != DateTime.MinValue && !(terminationDate >= effectiveDate))
					throw new ValidationException("TerminationDate", Vld_TerminationDate);  // throw validation exception if failed (don't set the member) 
					*/

				// Can't validate on the server, because the depended 2 members are not filled yet.
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@CREATETIME@")]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		[FieldDescription("@CREATEDBY@")]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}


		public SpecialtyCollection LookupOf_SpecialtyID
		{
			get
			{
				return SpecialtyCollection.ActiveSpecialties; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		
		[ValidatorMember("Vld_EndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}


	
		
	
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public int BoardStatus
		{
			get { return this.boardStatus; }
			set { this.boardStatus = value; }
		}

		[FieldValuesMember("ValuesOf_BoardStatus")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string BoardStatusStr
		{
			get { return this.boardStatus.ToString(); }
			set { 
				switch (value)
				{
					case "0":
						this.boardStatus = 0;
						break;
					case "1":
						this.boardStatus = 1;
						break;
					case "2":
						this.boardStatus = 2;
						break;
					
					case "3":
					default:
						this.boardStatus = 3;
						break;
				}
			 }
		}

		public string Fmt_BoardStatus(int BoardStatus, bool withValue)
		{
			switch (BoardStatus)
			{
				case 0:
					return ProviderSpecialtyBoardStatus.CERTIFIED.ToString();
				case 1:
					return ProviderSpecialtyBoardStatus.ELIGIBLE.ToString();
				case 2:
					return ProviderSpecialtyBoardStatus.NOTELIGIBLE.ToString();
				case 3:
					return ProviderSpecialtyBoardStatus.UNKNOWN.ToString();
				default:
					return null;
			}
		}

		public string[,] ValuesOf_BoardStatus
		{
			get
			{
				return new string[,] { 
					{ "0", ProviderSpecialtyBoardStatus.CERTIFIED.ToString() },
					{ "1", ProviderSpecialtyBoardStatus.ELIGIBLE.ToString() },
					{ "2", ProviderSpecialtyBoardStatus.NOTELIGIBLE.ToString() },
					{ "3", ProviderSpecialtyBoardStatus.UNKNOWN.ToString() }}; // return possible field values
			}	
		
		}

		/// <summary>
		/// Returns the Provider specialty description for the given provider specialty ID.
		/// </summary>
		/// <param name="providerID"></param>
		/// <returns></returns>
		public static string GetProviderSpecialtyDescriptionByID(int providerSpecialtyID)
		{
			if (providerSpecialtyID == 0)
				return null;
			ProviderSpecialty providerSpecialty = new ProviderSpecialty();
			if (providerSpecialty.Load(providerSpecialtyID))
				return providerSpecialty.Description;
			else
				return null;
		}
		
		/// <summary>
		/// Load the provider location by the given providerID and locationID
		/// </summary>
		public bool Load(int providerID, int specialtyID)
		{
			return SqlData.SPExecReadObj("usp_GetProviderLocationByProviderIDSpecialtyID", 
				this, false, new object[] { providerID, specialtyID });
		}

	}

	/// <summary>
	/// Strongly typed collection of ProviderSpecialty objects
	/// </summary>
	[ElementType(typeof(ProviderSpecialty))]
	public class ProviderSpecialtyCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ProviderSpecialty elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProviderSpecialtyCollection = this;
			else
				elem.ParentProviderSpecialtyCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ProviderSpecialty elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ProviderSpecialty this[int index]
		{
			get
			{
				return (ProviderSpecialty)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ProviderSpecialty)oldValue, false);
			SetParentOnElem((ProviderSpecialty)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, ProviderSpecialty elem)
		{
			List.Insert(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ProviderSpecialty)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ProviderSpecialty elem)
		{
			return List.Add(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(ProviderSpecialty elem)
		{
			List.Remove(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((ProviderSpecialty)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/* Don't use this.
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(string filter, string sort)
		{
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForType(typeof(ProviderSpecialty), filter, sort);
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int SPLoad(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/* Don't use this.  It was using Dynamic SQL!
		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL(object param)
		{
			SQLParser sql = new SQLParser("select * from [ProviderSpecialties] " +
			"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Parent Provider that contains this collection
		/// </summary>
		public Provider ParentProvider
		{
			get { return this.ParentDataObject as Provider; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Provider */ }
		}

		/// <summary>
		/// Find the primary specialty for the given provider id.  A single record is expected to be loaded.
		/// </summary>
		public int LoadPrimarySpecialtyByProviderIDPrimary(int maxRecords, int providerID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPrimarySpecialtyByProviderIDPrimary", maxRecords, this, false, new object[] { providerID, true });
		}

	
	}
}
