using System;
using System.Data;
using ActiveAdvice.DataLayer;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	public enum EnumDeliveryMethod
	{
		None = 0,
		Mail = 1,
		Email = 2,
		Fax = 3
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [Providers]
	/// </summary>
	
	//Unmanaged:  [SPAutoGen("usp_SearchProvidersByPlanID","SearchProvider.sptpl","")]
	//Unmanaged:  [SPAutoGen("usp_SearchProviders","SearchProvider.sptpl","")]
	[SPAutoGen("usp_SelectAllProvidersByAlternateID","SelectAllByGivenArgs.sptpl","alternateID")]
	[SPExists("usp_ExistsProvider")]
	[SPInsert("usp_InsertProvider")]
	[SPUpdate("usp_UpdateProvider")]
	[SPDelete("usp_DeleteProvider")]
	[SPLoad("usp_LoadProvider")]
	[TableMapping("Provider","providerID")]
	public class Provider : BaseDataWithUserDefined
	{



		[NonSerialized]
		private ProviderCollection parentProviderCollection;
		// TODO Add GroupPracticeProviderLinkCollection
		[ColumnMapping("AlternateID")]
		private string alternateID;
		[ColumnMapping("FirstName")]
		private string firstName;
		[ColumnMapping("LastName")]
		private string lastName;
		[ColumnMapping("MiddleInitial")]
		private string middleInitial;
		[ColumnMapping("PrefixId",StereoType=DataStereoType.FK)]
		private int prefixId;
		[ColumnMapping("Beeper",StereoType=DataStereoType.USPhoneNumber)]
		private string beeper;
		[ColumnMapping("BeeperExtension")]
		private string beeperExtension;
		[ColumnMapping("Email")]
		private string email;
		[ColumnMapping("Gender",StereoType=DataStereoType.Gender)]
		private string gender;
		[ColumnMapping("PhysicianReview", (int)-1)]
		private int physicianReview;
		[ColumnMapping("AddedOnTheFly")]
		private bool addedOnTheFly;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("DateActive")]
		private DateTime dateActive;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]
		private int providerID;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("StatusChangeDate")]
		private DateTime statusChangeDate;
		[ColumnMapping("StatusChangedBy",StereoType=DataStereoType.FK)]
		private int statusChangedBy;
		[ColumnMapping("DeliveryMethod")]
		private string deliveryMethod;
		[ColumnMapping("Suffix")]
		private string suffix;
		[ColumnMapping("FaxNumber",StereoType=DataStereoType.USPhoneNumber)]
		private string faxNumber;
		[ColumnMapping("StateOfLicensure")]
		private string stateOfLicensure;
		[ColumnMapping("LicenseNumber")]
		private string licenseNumber;

		private ProviderLanguageCollection providerLanguages;
		private ProviderSpecialtyCollection specialties;
		private ProviderLocationCollection locations;
		private ProviderFocusCollection focuses;
		private GroupPracticeProviderLinkCollection groupPracticeLinks;
		private GroupPracticeCollection				groupPractices;

		private Address address;
		private Location location;
	
		private ProviderSpecialty primarySpecialty;		// the primary specialty loaded and cached for this provider


		[ColumnMapping("CreatedByName", JoinColumn="LoginName", JoinRelation="Provider.CreatedBy = [AAUser].UserId", SQLGen=SQLGenerationFlags.NoInsert|SQLGenerationFlags.NoUpdate|SQLGenerationFlags.NoSelect)]
		private string createdByStr;
		public string CreatedByStr
		{
			get { return this.createdByStr; }
		}

		[ColumnMapping("ModifiedByName", JoinColumn="LoginName", JoinRelation="Provider.ModifiedBy = [AAUser].UserId", SQLGen=SQLGenerationFlags.NoInsert|SQLGenerationFlags.NoUpdate|SQLGenerationFlags.NoSelect)]
		private string modifiedByStr;
		public string ModifiedByStr
		{
			get { return this.modifiedByStr; }
		}

		[ColumnMapping("StatusChangedByName", JoinColumn="LoginName", JoinRelation="Provider.StatusChangedBy = [AAUser].UserId", SQLGen=SQLGenerationFlags.NoInsert|SQLGenerationFlags.NoUpdate|SQLGenerationFlags.NoSelect)]
		private string statusChangedByStr;
		public string StatusChangedByStr
		{
			get { return this.statusChangedByStr; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=10, ClientScriptForConditionalRequired="GetElemValue('DeliveryMethodStr') == 'F'", IsRequired=true)]
		public string FaxNumber
		{
			get { return this.faxNumber; }
			set { this.faxNumber = value; }
		}



		public Provider()
		{
			
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@PROVIDERID@")]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		[FieldDescription("@ALTERNATEID@")]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=25)]
		[FieldDescription("@FIRSTNAME@")]
		public string FirstName
		{
			get { return this.firstName; }
			set { this.firstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=25)]
		[FieldDescription("@LASTNAME@")]
		public string LastName
		{
			get { return this.lastName; }
			set { this.lastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		[FieldDescription("@MIDDLEINITIAL@")]
		public string MiddleInitial
		{
			get { return this.middleInitial; }
			set { this.middleInitial = value; }
		}	

		[FieldDescription("@NAME@")]
		public string FullName
		{
			get { return this.FirstName + " " + this.LastName; }
		}

		[FieldDescription("@NAME@")]
		public string FullNameWithPrefix
		{
			get 
			{ 
				if (this.Prefix == null)
					return this.FullName;
				else
                    return this.Prefix + " " + this.FullName; 
			}
		}
		
		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=15)]
		[FieldDescription("@BEEPER@")]
		public string Beeper
		{
			get { return this.beeper; }
			set { this.beeper = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=5)]
		[FieldDescription("@EXTENSION@")]
		public string BeeperExtension
		{
			get { return this.beeperExtension; }
			set { this.beeperExtension = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Email, MaxLength=255, ClientScriptForConditionalRequired="GetElemValue('DeliveryMethodStr') == 'E'", IsRequired=true)]
		[FieldDescription("@EMAIL@")]
		public string Email
		{
			get { return this.email; }
			set { this.email = value; }
		}

		[FieldValuesMember("ValuesOf_Gender")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, MaxLength=1)]
		[FieldDescription("@GENDER@")]
		public string Gender
		{
			get { return this.gender; }
			set { this.gender = value; }
		}
		
	
		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@PHYSICIANREVIEW@")]
		public bool PhysicianReview
		{
			get 
			{
				switch (this.physicianReview)
				{
					case 1:
						return true;
						break;
					default:
						return false;
						break;					
				} 
			}
			set 
			{
				if (value)
					  this.physicianReview = 1;
				  else
					  this.physicianReview = 0;
			}
		}

	

		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@ADDEDONFLY@")]
		public bool AddedOnTheFly
		{
			get { return this.addedOnTheFly; }
			set { this.addedOnTheFly = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@ACTIVE@")]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DATEACTIVE@")]
		public System.DateTime DateActive
		{
			get { return this.dateActive; }
			set { this.dateActive = value; }
		}

		public GroupPracticeCollection GroupPractices
		{
			set { this.groupPractices = value; } 
			get { return this.groupPractices; }
		}


		

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		[FieldDescription("@NOTE@")]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}
		
		/// <summary>
		/// Contained Address object
		/// </summary>
		[Contained]
		public Address Address
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.address = (Address)Address.EnsureContainedDataObject(this, typeof(Address), address, false,this.location.ServiceAddressID );

				
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.address ;
			}
			set
			{
				this.address  = value;
				//if (value != null) value = this; // set this as a parent of the child data class
			}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			
			if (ProviderID == 0)
				return;
			
			writer.AddFieldsOnNewLine(this, "ProviderID",  "FullName");			
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}
		

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}	
		}

		protected override void InternalSave()
		{
			//try				// Don't do this kind of exception wrapping.  UI is responsible for central translation and representation of excetions
			//{
				if (this.ProviderID != 0) // update
				{
					base.InternalSave();

					// These will do..  No need to use exception handling if you're not targeting a specific exception.
					// Child collections must be saved with their save method on the parent!
					this.SaveProviderLanguages();	
					this.SaveLocations();			
					this.SaveFocuses();				
					this.SaveGroupPracticeLinks();
					this.SaveSpecialties();

					//this.SqlData.EnsureTransaction();	// Don't open transaction in InternalSave.  Start your transaction in Custom Save method!
					//try
					//{
						

						/*
						if (this.ProviderLanguages != null)
						{
							providerLanguages.SqlData.Transaction = this.SqlData.Transaction;
							this.ProviderLanguages.Save();
						}
						*/
						/*
						if (this.Locations != null)
						{
							
							this.locations.SqlData.Transaction = this.SqlData.Transaction;
							this.Locations.Save();
						}
						if (Focuses != null)
						{
							// Update Focuses
							for (int i=0; i < this.Focuses.Count; i++)
							{
								focuses[i].ProviderID = this.ProviderID;
								this.focuses.SqlData.Transaction = this.SqlData.Transaction;
								this.focuses.Save();
							}
						}
						if (this.GroupPracticeLinks != null)
						{
							this.groupPracticeLinks.SqlData.Transaction = this.SqlData.Transaction;
							this.GroupPracticeLinks.Save();
						}
						if (this.Specialties != null)
						{
							this.specialties.SqlData.Transaction = this.SqlData.Transaction;
							this.Specialties.Save();
						}
						*/
						//this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed

					/*}				// Don't do this kind of exception wrapping.  UI is responsible for central translation and representation of excetions
					catch(Exception ex)
					{
						//this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
						// Failure handling code here
						throw; // always re-throw exception to notify the client
					}*/	

					
				}
				else // New Record
				{
					
					//try					// Don't do this kind of exception wrapping.  UI is responsible for central translation and representation of excetions
					//{
						
						base.InternalSave();
						//this.SqlData.EnsureTransaction();	// Don't open transaction in InternalSave.  Start your transaction in Custom Save method!
						this.LoadLocations(false);				// fixed!  it was using LoadLocations() which was using Dynamic SQL!
						// Add New Location
						AddEmptyLocation();
						this.Locations[0].ProviderID = this.ProviderID;
						
						this.SaveLocations();			// Child collections must be saved with their save method on the parent!
						//this.Locations.Save();

						this.SaveSpecialties();
						this.SaveProviderLanguages();
						this.SaveFocuses();
						// this.SaveGroupPracticeLinks();		// The save of grouppractice links were commented out in the original code below. 

						
					/*
						// Update Specialties
						if (Specialties != null)
						{
							for (int i=0; i < this.Specialties.Count; i++)
								specialties[i].ProviderID = this.ProviderID;
						}

						if (ProviderLanguages != null)
						{
							// Update Languages
							for (int i=0; i < this.ProviderLanguages.Count; i++)
								providerLanguages[i].ProviderID = this.ProviderID;
						}

						if (Focuses != null)
						{
							// Update Focuses
							for (int i=0; i < this.Focuses.Count; i++)
								focuses[i].ProviderID = this.ProviderID;
						}
					*/
						/*// Update GroupPractices
						for (int i=0; i < this.GroupPracticeLinks.Count; i++)
							groupPracticeLinks[i].ProviderID = this.ProviderID;*/

						/*this.Specialties.SqlData.Transaction = this.SqlData.Transaction;
						this.specialties.Save();
						this.providerLanguages.SqlData.Transaction = this.SqlData.Transaction;
						this.providerLanguages.Save();
						this.focuses.SqlData.Transaction = this.SqlData.Transaction;
						this.focuses.Save();*/

						//this.sqlData.CommitTransaction();
						/*this.groupPracticeLinks.SqlData.UseTransaction(this.sqlData.Transaction);
						this.groupPracticeLinks.Save();*/

					/*}					// Don't do this kind of exception wrapping.  UI is responsible for central translation and representation of excetions
					catch (Exception ex)
					{
						//this.sqlData.RollbackTransaction();
						throw;
					}*/
					
					

				}
			
			/* // Don't do this kind of exception wrapping.  UI is responsible for central translation and representation of excetions
			}
			catch (Exception ex)
			{
				
				//throw new Exception("An error occured while updating Provider: " + ex.Message);
				throw;
			}*/
		}

		/// <summary>
		///  Adds a new, empty location to Locations collection.
		///  It is used for newly inserted Providers (must have one location).
		/// </summary>
		private void AddEmptyLocation()
		{
			Address servAddr = new Address();
			Address billAddr = new Address();
			Address mailAddr = new Address();
			Location loc = new Location();
			loc.New();
			
			loc.BillingAddress = billAddr;
			loc.BillingAddress.New();
			loc.ServiceAddress = servAddr;
			loc.ServiceAddress.New();
			loc.MailingAddress = mailAddr;
			loc.MailingAddress.New();


			ProviderLocation provLoc = new ProviderLocation();
			provLoc.New();
			// Created By Info. Replace the 1 with actual code.
			provLoc.CreateTime		 = DateTime.Now;
			provLoc.CreatedBy		 = 1;
			provLoc.Location = loc;

			this.Locations.Add(provLoc);
		}


		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int providerID)
		{
			bool result = base.Load(providerID);
			this.ProviderID = providerID;
			this.LoadLocations(true);
			
			return result;
		}


		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int providerID)
		{
			base.Delete(providerID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Loads the object specified by parameters from table
		/// </summary>
		public bool Load()
		{
			
			bool result = false;
			result = SqlData.SPExecReadObj("usp_Load" + this.RootName, this, false );
			this.LoadLocations(true);
			return result;
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "}\r\n";
			return s;

		}

		/// <summary>
		/// Child ProviderLanguages mapped to related rows of table ProviderLanguages where [ProviderID] = [ProviderID]
		/// </summary>
		[SPLoadChild("usp_LoadProviderProviderLanguages", "providerID")]
		public ProviderLanguageCollection ProviderLanguages
		{
			get { return this.providerLanguages; }
			set
			{
				this.providerLanguages = value;
				value.ParentProvider = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ProviderLanguages collection
		/// </summary>
		public void LoadProviderLanguages(bool forceReload)
		{
			this.providerLanguages = (ProviderLanguageCollection)ProviderLanguageCollection.LoadChildCollection("ProviderLanguages", this, typeof(ProviderLanguageCollection), providerLanguages, forceReload, null);
		}

		/// <summary>
		/// Saves the ProviderLanguages collection
		/// </summary>
		public void SaveProviderLanguages()
		{
			ProviderLanguageCollection.SaveChildCollection(this.providerLanguages, true);
		}

		/// <summary>
		/// Synchronizes the ProviderLanguages collection
		/// </summary>
		public void SynchronizeProviderLanguages()
		{
			ProviderLanguageCollection.SynchronizeChildCollection(this.providerLanguages, true);
		}

		/// <summary>
		/// Child Specialties mapped to related rows of table ProviderSpecialties where [ProviderID] = [ProviderID]
		/// </summary>
		[SPLoadChild("usp_LoadProviderProviderSpecialties", "ProviderID")]
		public ProviderSpecialtyCollection Specialties
		{
			get { return this.specialties; }
			set
			{
				this.specialties = value;
				value.ParentProvider = this; // set this as a parent of the child collection
			}
		}

		/* Don't use this.  It was using Dynamic SQL!
		public void LoadSpecialties()
		{
			ProviderSpecialtyCollection specialties = new ProviderSpecialtyCollection();
			specialties.Load("ProviderID=" + this.ProviderID, "SpecialtyID");
			this.specialties = specialties;
		}*/

		/// <summary>
		/// Loads the Specialties collection
		/// </summary>
		public void LoadSpecialties(bool forceReload)
		{
			this.specialties = (ProviderSpecialtyCollection)ProviderSpecialtyCollection.LoadChildCollection("Specialties", this, typeof(ProviderSpecialtyCollection), specialties, forceReload, null);
		}

		/* Don't use this.  It was using Dynamic SQL!
		 * public void LoadLanguages()
		{
			ProviderLanguageCollection languages = new ProviderLanguageCollection();
			//languages.Load("ProviderID=" + this.ProviderID, "LanguageID");
			this.providerLanguages = languages;

		}*/


		/// <summary>
		/// Saves the Specialties collection
		/// </summary>
		public void SaveSpecialties()
		{
			ProviderSpecialtyCollection.SaveChildCollection(this.specialties, true);
		}

		/// <summary>
		/// Synchronizes the Specialties collection
		/// </summary>
		public void SynchronizeSpecialties()
		{
			ProviderSpecialtyCollection.SynchronizeChildCollection(this.specialties, true);
		}

		/// <summary>
		/// Child Locations mapped to related rows of table ProviderLocations where [ProviderID] = [ProviderID]
		/// </summary>
		[SPLoadChild("usp_LoadProviderProviderLocations", "providerID")]
		public ProviderLocationCollection Locations
		{
			get { return this.locations; }
			set
			{
				this.locations = value;
				value.ParentProvider = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Locations collection
		/// </summary>
		public void LoadLocations(bool forceReload)
		{
			
			this.locations = (ProviderLocationCollection)ProviderLocationCollection.LoadChildCollection("Locations", this, typeof(ProviderLocationCollection), locations, forceReload, null);
		}

		/// <summary>
		/// Saves the Locations collection
		/// </summary>
		public void SaveLocations()
		{
			ProviderLocationCollection.SaveChildCollection(this.locations, true);
		}

		/// <summary>
		/// Synchronizes the Locations collection
		/// </summary>
		public void SynchronizeLocations()
		{
			ProviderLocationCollection.SynchronizeChildCollection(this.locations, true);
		}

		/// <summary>
		/// Child Focuses mapped to related rows of table ProviderFocuses where [ProviderID] = [ProviderID]
		/// </summary>
		[SPLoadChild("usp_LoadProviderProviderFocuses", "ProviderID")]
		public ProviderFocusCollection Focuses
		{
			get { return this.focuses; }
			set
			{
				this.focuses = value;
				value.ParentProvider = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Focuses collection
		/// </summary>
		public void LoadFocuses(bool forceReload)
		{
			this.focuses = (ProviderFocusCollection)ProviderFocusCollection.LoadChildCollection("Focuses", this, typeof(ProviderFocusCollection), focuses, forceReload, null);
		}

		/// <summary>
		/// Saves the Focuses collection
		/// </summary>
		public void SaveFocuses()
		{
			ProviderFocusCollection.SaveChildCollection(this.focuses, true);
		}

		/// <summary>
		/// Synchronizes the Focuses collection
		/// </summary>
		public void SynchronizeFocuses()
		{
			ProviderFocusCollection.SynchronizeChildCollection(this.focuses, true);
		}


		/* Don't use this.  It was using Dynamic SQL!
		public void LoadLocations()
		{
			ProviderLocationCollection locations = new ProviderLocationCollection();
			locations.Load("ProviderID=" + this.ProviderID.ToString(),"LocationID");
			this.Locations	= locations;
		}
		*/

		[FieldValuesMember("LookupOf_PrefixId", "NamePrefixId", "Prefix")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@PREFIX@")]
		public int PrefixId
		{
			get { return this.prefixId; }
			set { this.prefixId = value; }
		}

		public string Prefix
		{
			get 
			{ 
				NamePrefix prefix = null;
				if (prefixId != 0)
					prefix = NamePrefixCollection.ActiveNamePrefixes.FindBy(this.prefixId); 
				if (prefix == null) return null;
				return prefix.Prefix;
			}
		}


		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active = true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Child GroupPractices mapped to related rows of table GroupPracticeProviders where [ProviderID] = [ProviderID]
		/// </summary>
		[SPLoadChild("usp_LoadProviderGroupPractices", "ProviderID")]
		public GroupPracticeProviderLinkCollection GroupPracticeLinks
		{
			get { return this.groupPracticeLinks; }
			set
			{
				this.groupPracticeLinks = value;
				value.ParentProvider = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the GroupPractices collection
		/// </summary>
		public void LoadGroupPracticeLinks(bool forceReload)
		{
			this.groupPracticeLinks = (GroupPracticeProviderLinkCollection)GroupPracticeProviderLinkCollection.LoadChildCollection("GroupPracticeLinks", this, typeof(GroupPracticeProviderLinkCollection), groupPracticeLinks, forceReload, null);
		}

		/// <summary>
		/// Saves the GroupPractices collection
		/// </summary>
		public void SaveGroupPracticeLinks()
		{
			GroupPracticeProviderLinkCollection.SaveChildCollection(this.groupPracticeLinks, true);
		}

		/// <summary>
		/// Parent ProviderCollection that contains this element
		/// </summary>
		public ProviderCollection ParentProviderCollection
		{
			get
			{
				return this.parentProviderCollection;
			}
			set
			{
				this.parentProviderCollection = value; // parent is set when added to a collection
			}
		}

		public NamePrefixCollection LookupOf_PrefixId
		{
			get
			{
				return NamePrefixCollection.ActiveNamePrefixes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}



		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StatusChangeDate
		{
			get { return this.statusChangeDate; }
			set { this.statusChangeDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1,ClientValidators=EnumClientValidators.Required)]
		public string DeliveryMethod
		{
			get { return this.deliveryMethod; }
			set { this.deliveryMethod = value; }
		}

		[FieldValuesMember("ValuesOf_DeliveryMethodStr")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@DELIVERYMETHOD@")]
		public string DeliveryMethodStr
		{
			get { return this.deliveryMethod; }
			set { this.deliveryMethod = value; }
		}
		/// <summary>
		/// Returns all possible values and descriptions for delivery methods
		/// </summary>
		public string[,] ValuesOf_DeliveryMethodStr
		{
			get
			{
				return new string[,] { 
					{ "E", EnumDeliveryMethod.Email.ToString() },
					{ "F", EnumDeliveryMethod.Fax.ToString() },
					{ "M", EnumDeliveryMethod.Mail.ToString() } }; // return possible field values
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string Suffix
		{
			get { return this.suffix; }
			set { this.suffix = value; }
		}
		
		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public void LoadGroupPractices()
		{
			GroupPracticeCollection gpCol = new GroupPracticeCollection();
			gpCol.SqlData.SPExecReadCol("usp_LoadProviderGroupPractice", -1, gpCol,  true,new object[] { this.providerID } );

			// for all MarkDel GPLink check the group practice ID if matches remove from collection
			for (int j=0; j < gpCol.Count; j++)
			{
				bool removeCurrentGP = true;
				for (int i=0; i < this.GroupPracticeLinks.Count; i++)
				{
					if (GroupPracticeLinks[i].GroupPracticeID == gpCol[j].GroupPracticeID)
					{
						if (GroupPracticeLinks[i].IsMarkedForDeletion && removeCurrentGP)
							removeCurrentGP = true;
						else
							removeCurrentGP = false;
					}
				}
				if (removeCurrentGP)
					gpCol.MarkDirty(j);
			}

			foreach (GroupPractice gp in gpCol)
			{
				if (gp.IsDirty)
					gpCol.Remove(gp);
			}
			

			this.GroupPractices = gpCol;
		}		

		/// <summary>
		/// Returns the Provider fullname for the given provider ID.
		/// </summary>
		/// <param name="providerID"></param>
		/// <returns></returns>
		public static string GetProviderFullNameByID(int providerID)
		{
			if (providerID == 0)
				return null;
			Provider provider = new Provider();
			if (provider.Load(providerID))
				return provider.FullName;
			else
				return null;
		}

		public static string GetProviderFullNameWithPrefixByID(int providerID)
		{
			if (providerID == 0)
				return null;
			Provider provider = new Provider();
			if (provider.Load(providerID))
				return provider.FullNameWithPrefix;
			else
				return null;
		}

		public static string GetProviderFaxByID(int providerID)
		{
			if (providerID == 0)
				return null;
			Provider provider = new Provider();
			if (provider.Load(providerID))
				return provider.FaxNumber;
			else
				return null;
		}

		public static string GetServiceLocationPhoneByProviderLocationID(int providerLocationID)
		{
			if (providerLocationID == 0)
				return null;
			ProviderLocation provloc = new ProviderLocation();
			if(!provloc.Load(providerLocationID))
				return null;
			return provloc.Phone;
		}

		/// <summary>
		/// Return the primary specialty object by querying the ProviderSpecialty table.
		/// </summary>
		/// <returns></returns>
		public ProviderSpecialty GetPrimarySpecialty()
		{
			if (this.providerID == 0)
				return null;
			ProviderSpecialtyCollection primarySpecs = new ProviderSpecialtyCollection();
			primarySpecs.LoadPrimarySpecialtyByProviderIDPrimary(-1, this.providerID);
			if (primarySpecs.Count == 0)
				return null;

			if (primarySpecs.Count > 1)
				throw new ActiveAdviceException(AAExceptionAction.None, "There are more than 1 primary specialties for provider {0}", providerID);

			return primarySpecs[0];
		}

		/// <summary>
		/// Loaded and cached primary specialty for this provider.
		/// </summary>
		public ProviderSpecialty PrimarySpecialty
		{
			get 
			{ 
				if (primarySpecialty == null)
					this.primarySpecialty = GetPrimarySpecialty();
				return this.primarySpecialty;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.USState, MaxLength=2)]
		[FieldDescription("@STATEOFLICENSURE@")]
		public string StateOfLicensure
		{
			get { return this.stateOfLicensure; }
			set { this.stateOfLicensure = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		[FieldDescription("@LICENSENUMBER@")]
		public string LicenseNumber
		{
			get { return this.licenseNumber; }
			set { this.licenseNumber = value; }
		}




	}

	/// <summary>
	/// Strongly typed collection of Provider objects
	/// </summary>
	[ElementType(typeof(Provider))]
	public class ProviderCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		public const int MAXRECORDS = 10;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Provider elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProviderCollection = this;
			else
				elem.ParentProviderCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Provider elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}
		
		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Provider elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(Provider elem)
		{
			RemoveRecord(elem);		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Provider this[int index]
		{
			get
			{
				return (Provider)List[index];
			}
			set
			{
				List[index] = value;
			}
		}


		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Provider)oldValue, false);
			SetParentOnElem((Provider)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchProviders(int startProviderId, string startLastName, string startFirstName, Provider providerInfo, ProviderLocationNetworkLink providerNetwork, NetworkPlanLink netPlan, ProviderLanguage providerLanguage, ProviderFocus providerFocus, ProviderLocationService providerService, ProviderSpecialty providerSpecialty, Address providerLocation)
		{
			int maxRecords = MAXRECORDS;
			object [] prms = { providerInfo, providerFocus, providerLanguage, providerNetwork, providerSpecialty, providerService, providerLocation, netPlan};
			this.Clear();
			if (netPlan.PlanId == 0)
				return SqlData.SPExecReadCol("usp_SearchProviders", -1,this, prms, true, 
					//new string[] { "email" },
					//new object[] { providerInfo.GetDB("email") });
					new string[] { "rowCount", "startProviderId", "startLastName", "startFirstName", "email","networkID","effectiveDate","alternateID" },
					new object[] { maxRecords < 0 ? 0 : maxRecords, startProviderId, startLastName, startFirstName, providerInfo.GetDB("email"),providerNetwork.GetDB("networkID"),providerNetwork.GetDB("effectiveDate"),providerInfo.GetDB("alternateID") });
			else
				return SqlData.SPExecReadCol(300, "usp_SearchProvidersByPlanID", -1, this, prms, true,
					new string[] { "rowCount", "startProviderId", "startLastName", "startFirstName", "email","networkID","effectiveDate","alternateID" },
					new object[] { maxRecords < 0 ? 0 : maxRecords, startProviderId, startLastName, startFirstName, providerInfo.GetDB("email"),providerNetwork.GetDB("networkID"),providerNetwork.GetDB("effectiveDate"),providerInfo.GetDB("alternateID") });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SelectAllProvidersByAlternateID(int maxRecords, string alternateID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllProvidersByAlternateID", maxRecords, this, false, new object[] { alternateID });
		}


	}
}
