using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NotePage]
	/// </summary>
	[SPInsert("usp_InsertNotePage")]
	[SPUpdate("usp_UpdateNotePage")]
	[SPDelete("usp_DeleteNotePage")]
	[SPLoad("usp_LoadNotePage")]
	[TableMapping("NotePage","noteID",true)]
	public class NotePage : BaseData
	{
		[NonSerialized]
		private NotePageCollection parentNotePageCollection;
		[ColumnMapping("NoteID",StereoType=DataStereoType.FK)]
		private int noteID;
		[ColumnMapping("IsRTF")]
		private bool isRTF = true;
		[ColumnMapping("NoteText")]
		private string noteText;
	
		public NotePage()
		{
		}

		public NotePage(string noteText)
		{
			this.NewRecord(); // initialize record state
			this.noteText = noteText;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NoteID
		{
			get { return this.noteID; }
			set { this.noteID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1000)]
		public string NoteText
		{
			get { return this.noteText; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1000)]
		public string TextASCII
		{	
			set { this.noteText = value; this.isRTF = false; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1000)]
		public string TextRTF
		{
			set { this.noteText = value; this.isRTF = true; }
		}

		[FieldDescription("1 - RTF; 0 - ASCII")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool IsRTF
		{
			get { return this.isRTF; }
		}

		/// <summary>
		/// Parent NotePageCollection that contains this element
		/// </summary>
		public NotePageCollection ParentNotePageCollection
		{
			get
			{
				return this.parentNotePageCollection;
			}
			set
			{
				this.parentNotePageCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Parent Note that contains this object
		/// </summary>
		public Note ParentNote
		{
			get { return this.ParentDataObject as Note; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Note */ }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		

	}

	/// <summary>
	/// Strongly typed collection of NotePage objects
	/// </summary>
	[ElementType(typeof(NotePage))]
	public class NotePageCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(NotePage elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNotePageCollection = this;
			else
				elem.ParentNotePageCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (NotePage elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public NotePage this[int index]
		{
			get
			{
				return (NotePage)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((NotePage)oldValue, false);
			SetParentOnElem((NotePage)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Note that contains this collection
		/// </summary>
		public Note ParentNote
		{
			get { return this.ParentDataObject as Note; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Note */ }
		}
	}
	
}
