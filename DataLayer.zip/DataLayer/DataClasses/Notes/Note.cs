using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Note]
	/// </summary>
	[SPAutoGen("usp_SearchNotes", null, ManuallyManaged=true)]
	[SPInsert("usp_InsertNote")]
	[SPUpdate("usp_UpdateNote")]
	[SPDelete("usp_DeleteNote")]
	[SPLoad("usp_LoadNote")]
	[TableMapping("Note","noteID")]
	public class Note : BaseAssessment
	{
		[NonSerialized]
		private NoteCollection parentNoteCollection;
		[ColumnMapping("NoteID",StereoType=DataStereoType.FK)]
		private int noteID;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		private int patientId;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("ProblemId",StereoType=DataStereoType.FK)]
		private int problemId;
		[ColumnMapping("ReferralId",StereoType=DataStereoType.FK)]
		private int referralId;
		[ColumnMapping("CMSId",StereoType=DataStereoType.FK)]
		private int cMSId;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("PRRequestID",StereoType=DataStereoType.FK)]
		private int pRRequestID;
		[ColumnMapping("PRReviewID",StereoType=DataStereoType.FK)]
		private int pRReviewID;
		[ColumnMapping("PRProviderDecisionID",StereoType=DataStereoType.FK)]
		private int pRProviderDecisionID;
		[ColumnMapping("NoteTerminationReasonID",StereoType=DataStereoType.FK)]
		private int noteTerminationReasonID;
		[ColumnMapping("NoteTypeID",StereoType=DataStereoType.FK)]
		private int noteTypeID;
		[ColumnMapping("MedicalNoteBrief")]
		private string medicalNoteBrief;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("AppendID",StereoType=DataStereoType.FK)]
		private int appendID;
		[ColumnMapping("AppendDate")]
		private DateTime appendDate;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;

		private NotePage notePage;
		private Patient patient;
		private DateTime dateFrom;
		private DateTime dateTo;
		private int dateSelection;

		private PatientCoverage selectedPatientCoverage;		// used by auto activity rule

		public Note()
		{
		}

		public Note(bool initNew) : this()
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/// <summary>
		/// Create not for the given Patient
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="initNew"></param>
		public Note(Patient patient, bool initNew) : this(initNew)
		{	
			this.patient = patient;
			this.patientId = patient.PatientId;
		}

		[FieldDescription("@ID@")]
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NoteID
		{
			get { return this.noteID; }
			set { this.noteID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientId
		{
			get { return this.patientId; }
		}

		[FieldDescription("@EVENT@")]
		[FieldValuesMember("LookupOf_EventID", "EventID", "ERCDescription")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[FieldDescription("@PROBLEM@")]
		[FieldValuesMember("LookupOf_ProblemId", "ProblemID", "ProblemDescriptionToDisplay")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ProblemId
		{
			get { return this.problemId; }
			set { this.problemId = value; }
		}

		[FieldDescription("@REFERRAL@")]
		[FieldValuesMember("LookupOf_ReferralId", "ReferralID", "ERCDescription")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ReferralId
		{
			get { return this.referralId; }
			set { this.referralId = value; }
		}

		[FieldDescription("@CMS@")]
		[FieldValuesMember("LookupOf_CMSId", "CMSID", "ERCDescription")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CMSId
		{
			get { return this.cMSId; }
			set { this.cMSId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[FieldDescription("@MEDICATIONTERMINATION@")]
		[FieldValuesMember("LookupOf_NoteTerminationReasonID", "NoteTerminationReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int NoteTerminationReasonID
		{
			get { return this.noteTerminationReasonID; }
			set { this.noteTerminationReasonID = value; }
		}

		[FieldDescription("@NOTETYPE@")]
		[FieldValuesMember("LookupOf_NoteTypeID", "NoteTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int NoteTypeID
		{
			get { return this.noteTypeID; }
			set { this.noteTypeID = value; }
		}

		[FieldDescription("@NOTE@")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=128)]
		public string MedicalNoteBrief
		{
			get 
			{	return this.medicalNoteBrief; }
			set 
			{ 
				if(value.Length > 128)
				{
					this.medicalNoteBrief = value.Substring(0, 123);
					this.medicalNoteBrief += "...";
				}
				else
					this.medicalNoteBrief = value;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldValuesMember("LookupOf_UserID", "UserId", "LoginName")]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AppendID
		{
			get { return this.appendID; }
			set { this.appendID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AppendDate
		{
			get { return this.appendDate; }
			set { this.appendDate = value; }
		}

		/// <summary>
		/// Load the patient related to this note and return it.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientId == 0)
				return null;

			Patient patient = new Patient();
			patient.SqlData.Transaction = this.SqlData.Transaction;
			if (patient.Load(patientId))
				return patient;
			else
				return null;
		}

		/// <summary>
		/// Load and cache the patient related to this note.
		/// </summary>
		public Patient Patient
		{
			get 
			{ 
				if (this.patient == null)
					this.patient = GetPatient();
				return this.patient; 
			}
		}

		/// <summary>
		/// Load the event related to this note and return it.
		/// </summary>
		/// <returns></returns>
		public Event GetEvent()
		{
			if (this.eventID == 0)
				return null;

			Event eventObj = new Event();
			eventObj.SqlData.Transaction = this.SqlData.Transaction;
			if (eventObj.Load(this.Patient, eventID))
				return eventObj;
			else
				return null;
		}

		/// <summary>
		/// Load the referral related to this note and return it.
		/// </summary>
		/// <returns></returns>
		public Referral GetReferral()
		{
			if (this.referralId == 0)
				return null;

			Referral referral = new Referral();
			referral.SqlData.Transaction = this.SqlData.Transaction;
			if (referral.Load(referralId))
				return referral;
			else
				return null;
		}

		/// <summary>
		/// Load the cms related to this note and return it.
		/// </summary>
		/// <returns></returns>
		public CMS GetCMS()
		{
			if (this.cMSId == 0)
				return null;

			CMS cms = new CMS();
			cms.SqlData.Transaction = this.SqlData.Transaction;
			if (cms.Load(cMSId))
				return cms;
			else
				return null;
		}

		/// <summary>
		/// Load the problem related to this note and return it.
		/// </summary>
		/// <returns></returns>
		public Problem GetProblem()
		{
			if (this.problemId == 0)
				return null;

			Problem problem= new Problem();
			problem.SqlData.Transaction = this.SqlData.Transaction;
			if (problem.Load(problemId))
				return problem;
			else
				return null;
		}

		[FieldDescription("@FROMDATE@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DateFrom
		{
			get { return this.dateFrom; }
			set { this.dateFrom = value; }
		}

		[FieldDescription("@TODATE@")]
		[ValidatorMember("Vld_DateTo")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DateTo
		{
			get { return this.dateTo; }
			set { this.dateTo = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DateSelection
		{
			get { return this.dateSelection; }
			set { this.dateSelection = value; }
		}

		public static Note CreateNoteFromNoteAndSet(Note note)
		{
			Note newNote = new Note(note.patient, true);
			newNote.EventID = note.EventID;
			newNote.ProblemId = note.ProblemId;
			newNote.ReferralId = note.ReferralDetailID;
			newNote.PRRequestID = note.PRRequestID;
			newNote.PRReviewID = note.PRReviewID;
			newNote.PRProviderDecisionID = note.PRProviderDecisionID;
			newNote.CMSId = note.CMSId;
			newNote.ReferralDetailID = note.ReferralDetailID;
			return newNote;
		}

		public void Activate()
		{
			this.terminateTime = DateTime.MinValue;
			this.terminatedBy = 0;
			this.noteTerminationReasonID = 0;
		}

		public void Terminate()
		{
			this.SetTerminatingUser();
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int noteID)
		{
			return base.Load(noteID);
		}

		/// <summary>
		/// Parent NoteCollection that contains this element
		/// </summary>
		public NoteCollection ParentNoteCollection
		{
			get
			{
				return this.parentNoteCollection;
			}
			set
			{
				this.parentNoteCollection = value; // parent is set when added to a collection
			}
		}

		#region Lookups
		public NoteTypeCollection LookupOf_NoteTypeID
		{
			get
			{
				return NoteTypeCollection.ActiveNoteTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public NoteTerminationReasonCollection LookupOf_NoteTerminationReasonID
		{
			get
			{
				return NoteTerminationReasonCollection.ActiveNoteTerminationReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public ProblemCollection LookupOf_ProblemId
		{
			get
			{
				if(this.Patient == null)
					return new ProblemCollection();
				return this.patient.GetLinkedProblems();
			}
		}

		public CMSCollection LookupOf_CMSId
		{
			get
			{
				if(this.Patient == null)
					return new CMSCollection();
				return this.patient.GetLinkedCMSs();
			}
		}

		public EventCollection LookupOf_EventID
		{
			get
			{
				if(this.Patient == null)
					return new EventCollection();
				return this.patient.GetLinkedEvents();
			}
		}

		public ReferralCollection LookupOf_ReferralId
		{
			get
			{
				if(this.Patient == null)
					return new ReferralCollection();
				return this.patient.GetLinkedReferrals();
			}
		}

//		public AAUserCollection LookupOf_CreatedBy
//		{
//			get
//			{
//				return AAUserCollection.AllUsers; // Acquire a shared instance from the static member of collection
//			}
//		}
		#endregion

		/// <summary>
		/// Contained NotePage object
		/// </summary>
		[Contained]
		public NotePage NotePage
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.notePage = (NotePage)NotePage.EnsureContainedDataObject(this, typeof(NotePage), notePage, false, noteID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.notePage;
			}
			set
			{
				this.notePage = value;
				if (value != null) value.ParentNote = this; // set this as a parent of the child data class
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
				this.NotePage.MarkDel();	// then allow the deletion of the conatined object

			bool initialSave = this.IsNew;
			
			base.InternalSave();

			#region Trigger AutoActivities - NT1 - Note Initial Save

			if (initialSave)
				AutoActivity_NoteInitialSave();

			#endregion

			if(this.NotePage.NoteID == 0)
				this.NotePage.NoteID = this.noteID;
			
			this.NotePage.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			this.NotePage.Save();
		}

		/// <summary>
		/// NT1	- Note Initial Save
		/// This is triggered when a new note is saved
		/// </summary>
		public void AutoActivity_NoteInitialSave()
		{
			autoActivityManager = new AutoActivityManager(this.Patient, this.selectedPatientCoverage, this);
			autoActivityManager.Execute(AutoActivityRuleType.NT1, this.SqlData.Transaction);
		}

		[GenericScript("Vld_DateTo", "@DateTo@ != null && @DateTo@ >= @DateFrom@;")]
		public string Vld_DateTo
		{
			get
			{
				return "Date To must be greater than Date From!"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{}
		}

		public string AppendedByAndSet()
		{
			//[ The following note was appended on 05/19/2005 at 5:40:20 PM by HCOLLINS: ] 
			DateTime dt = DateTime.Now;
			this.appendDate = dt;
			this.appendID = DataLayer.AASecurityHelper.GetUserId;

			string str = "[ The following note was appended on " + dt.ToShortDateString() + " by " + DataLayer.AASecurityHelper.UserName + " : ]";
			return str;
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddHeaderLabelandValue("Note ID", this.noteID.ToString());
			}
		}

		/// <summary>
		/// Set this if saving in the context other than event or problem before saving
		/// </summary>
		public ActiveAdvice.DataLayer.PatientCoverage SelectedPatientCoverage
		{
			get { return this.selectedPatientCoverage; }
			set { this.selectedPatientCoverage = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PRRequestID
		{
			get { return this.pRRequestID; }
			set { this.pRRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PRReviewID
		{
			get { return this.pRReviewID; }
			set { this.pRReviewID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PRProviderDecisionID
		{
			get { return this.pRProviderDecisionID; }
			set { this.pRProviderDecisionID = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of Note objects
	/// </summary>
	[ElementType(typeof(Note))]
	public class NoteCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Note elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNoteCollection = this;
			else
				elem.ParentNoteCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Note elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Note this[int index]
		{
			get
			{
				return (Note)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Note)oldValue, false);
			SetParentOnElem((Note)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchNotes(int maxRecords, Note searcher)
		{
			string[] extraParamNames = new string[] { "activeWithAll", "dateFrom", "dateTo" , "userid"};
			object[] extraParamValues = new object[] { 
														 (object)searcher.ActiveWithAll,
														 searcher.DateFrom == DateTime.MinValue ? DBNull.Value : (object)searcher.DateFrom,
														 searcher.DateTo   == DateTime.MinValue ? DBNull.Value : (object)searcher.DateTo,
														 SQLDataDirect.MakeDBValue(AASecurityHelper.GetUserId, (int)0)};
			

			this.Clear();
	//		return SqlData.SPExecReadCol("usp_SearchNotes", maxRecords, this, searcher, false, extraParamNames, extraParamValues);
			return SqlData.SPExecReadCol("usp_SearchNotesWithDAFilter", maxRecords, this, searcher, false, 
				extraParamNames, extraParamValues);
			
		}

		public static NoteCollection GetFromSearch(Note searcher)
		{
			NoteCollection col = new NoteCollection();
			col.SearchNotes(-1, searcher);
			return col;
		}
	}
}
