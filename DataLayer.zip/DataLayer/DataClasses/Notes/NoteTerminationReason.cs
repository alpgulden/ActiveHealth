using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NoteTerminationReason]
	/// </summary>
	[SPAutoGen("usp_GetAllNoteTerminationReasons","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetAllNoteTerminationReasonsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertNoteTerminationReason")]
	[SPUpdate("usp_UpdateNoteTerminationReason")]
	[SPDelete("usp_DeleteNoteTerminationReason")]
	[SPLoad("usp_LoadNoteTerminationReason")]
	[TableMapping("NoteTerminationReason","noteTerminationReasonID")]
	public class NoteTerminationReason : BaseLookupWithNote
	{
		[NonSerialized]
		private NoteTerminationReasonCollection parentNoteTerminationReasonCollection;
		[ColumnMapping("NoteTerminationReasonID",(int)0)]
		private int noteTerminationReasonID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public NoteTerminationReason()
		{
		}

		public NoteTerminationReason(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NoteTerminationReasonID
		{
			get { return this.noteTerminationReasonID; }
			set { this.noteTerminationReasonID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Parent NoteTerminationReasonCollection that contains this element
		/// </summary>
		public NoteTerminationReasonCollection ParentNoteTerminationReasonCollection
		{
			get
			{
				return this.parentNoteTerminationReasonCollection;
			}
			set
			{
				this.parentNoteTerminationReasonCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of NoteTerminationReason objects
	/// </summary>
	[ElementType(typeof(NoteTerminationReason))]
	public class NoteTerminationReasonCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(NoteTerminationReason elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNoteTerminationReasonCollection = this;
			else
				elem.ParentNoteTerminationReasonCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (NoteTerminationReason elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public NoteTerminationReason this[int index]
		{
			get
			{
				return (NoteTerminationReason)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((NoteTerminationReason)oldValue, false);
			SetParentOnElem((NoteTerminationReason)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(NoteTerminationReason elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((NoteTerminationReason)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllNoteTerminationReasonsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllNoteTerminationReasonsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared NoteTerminationReasonCollection which is cached in NSGlobal
		/// </summary>
		public static NoteTerminationReasonCollection ActiveNoteTerminationReasons
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				NoteTerminationReasonCollection col = (NoteTerminationReasonCollection)NSGlobal.EnsureCachedObject("ActiveNoteTerminationReasons", typeof(NoteTerminationReasonCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllNoteTerminationReasonsByActive(-1, true);
				}
				return col;
			}			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllNoteTerminationReasons", -1, this, false);
		}
	}
}
