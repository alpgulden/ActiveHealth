using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GuidelineCategory]
	/// </summary>
	[SPAutoGen("usp_GetActiveGuidelineCategoriesForProduct","SelectRelatedFromLinkedTableWithFilter.sptpl","GuidelineProductCategoryLink, guidelineCategoryID, guidelineProductID, active")]
	[SPAutoGen("usp_GetActiveGuidelineCategories","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllGuidelineCategories","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetGuidelineCategoriesForProductSS","SearchLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineCategoryID, guidelineProductID, guidelineSourceSetID")]
	[SPAutoGen("usp_GetGuidelineCategoriesForGuidelineSS","SearchLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineCategoryID, guidelineID, guidelineSourceSetID")]
	[SPAutoGen("usp_GetGuidelineCategoriesForGuidelineProductSS","SelectRelatedFromLinkedTable2ColBreakerFilter.sptpl","GuidelineProductCategoryLink, guidelineCategoryID, guidelineID, guidelineProductID, guidelineSourceSetID")]
	[SPAutoGen("usp_GetGuidelineCategoriesForGuidelineProduct","SelectRelatedFromLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineCategoryID, guidelineID, guidelineProductID")]
	[SPAutoGen("usp_GetGuidelineCategoriesForProduct","SelectRelatedFromLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineCategoryID, guidelineProductID")]
	[SPAutoGen("usp_GetGuidelineCategoriesForGuideline","SelectRelatedFromLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineCategoryID, guidelineID")]
	[SPAutoGen("usp_GetGuidelineCategoriesForSS","SelectAllByGivenArgs.sptpl","guidelineSourceSetID")]
	[SPInsert("usp_InsertGuidelineCategory")]
	[SPUpdate("usp_UpdateGuidelineCategory")]
	[SPDelete("usp_DeleteGuidelineCategory")]
	[SPLoad("usp_LoadGuidelineCategory")]
	[TableMapping("GuidelineCategory","guidelineCategoryID")]
	public class GuidelineCategory : BaseData
	{
		[NonSerialized]
		private GuidelineCategoryCollection parentGuidelineCategoryCollection;
		[ColumnMapping("GuidelineCategoryID",(int)0)]
		private int guidelineCategoryID;
		[ColumnMapping("GuidelineSourceSetID",StereoType=DataStereoType.FK)]
		private int guidelineSourceSetID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public GuidelineCategory()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public GuidelineCategory(int guidelineSourceSetID)
		{
			this.NewRecord(); // initialize record state
			this.guidelineSourceSetID = guidelineSourceSetID;
		}

		public GuidelineCategory(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GuidelineCategoryID
		{
			get { return this.guidelineCategoryID; }
			set { this.guidelineCategoryID = value; }
		}

		/// <summary>
		/// Parent GuidelineCategoryCollection that contains this element
		/// </summary>
		public GuidelineCategoryCollection ParentGuidelineCategoryCollection
		{
			get
			{
				return this.parentGuidelineCategoryCollection;
			}
			set
			{
				this.parentGuidelineCategoryCollection = value; // parent is set when added to a collection
			}
		}

		[FieldValuesMember("LookupOf_guidelineSourceSetID", "GuidelineSourceSetID", "Note")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int GuidelineSourceSetID
		{
			get { return this.guidelineSourceSetID; }
			set { this.guidelineSourceSetID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

	

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}


		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int guidelineCategoryID)
		{
			return base.Load(guidelineCategoryID);
		}

	
		public GuidelineSourceSetCollection LookupOf_guidelineSourceSetID
		{
			get
			{
				return GuidelineSourceSetCollection.ActiveGuidelineSourceSets; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

	

	}

	/// <summary>
	/// Strongly typed collection of GuidelineCategory objects
	/// </summary>
	[ElementType(typeof(GuidelineCategory))]
	public class GuidelineCategoryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Parent GuidelineSourceSet that contains this collection
		/// </summary>
		public GuidelineSourceSet ParentGuidelineSourceSet
		{
			get { return this.ParentDataObject as GuidelineSourceSet; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GuidelineSourceSet */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineCategoriesForSS(int maxRecords, int guidelineSourceSetID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineCategoriesForSS", maxRecords, this, false, new object[] { guidelineSourceSetID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineCategoriesForProductSS(int maxRecords, int guidelineSourceSetID,int guidelineProductID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineCategoriesForProductSS", maxRecords, this, false, new object[] { guidelineProductID,guidelineSourceSetID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineCategoriesForGuidelineSS(int maxRecords, int guidelineSourceSetID,int guidelineID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineCategoriesForGuidelineSS", maxRecords, this, false, new object[] {guidelineID, guidelineSourceSetID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineCategoriesForGuidelineProductSS(int maxRecords, int guidelineSourceSetID,int guidelineProductID,int guidelineID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineCategoriesForGuidelineProductSS", maxRecords, this, false, new object[] { guidelineID,guidelineProductID,guidelineSourceSetID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineCategoriesForGuidelineProduct(int maxRecords,int guidelineProductID,int guidelineID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineCategoriesForGuidelineProduct", maxRecords, this, false,new object[]{guidelineID,guidelineProductID});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineCategoriesForProduct(int maxRecords,int guidelineProductID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineCategoriesForProduct", maxRecords, this, false,new object[]{guidelineProductID});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineCategoriesForGuideline(int maxRecords,int guidelineID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineCategoriesForGuideline", maxRecords, this, false,new object[]{guidelineID});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllGuidelineCategories(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllGuidelineCategories", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveGuidelineCategories(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveGuidelineCategories", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveGuidelineCategoriesForProduct(int maxRecords, int guidelineProductID, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveGuidelineCategoriesForProduct", maxRecords, this, false, new object[] {guidelineProductID, active });
		}
	}
}
