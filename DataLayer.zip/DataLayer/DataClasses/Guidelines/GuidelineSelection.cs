using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GuidelineSelection]
	/// </summary>
	[SPInsert("usp_InsertGuidelineSelection")]
	[SPUpdate("usp_UpdateGuidelineSelection")]
	[SPDelete("usp_DeleteGuidelineSelection")]
	[SPLoad("usp_LoadGuidelineSelection")]
	[TableMapping("GuidelineSelection","guidelineSelectionID")]
	public class GuidelineSelection : BaseData
	{
		[NonSerialized]
		private GuidelineSelectionCollection parentGuidelineSelectionCollection;
		[ColumnMapping("GuidelineSelectionID",(int)0)]
		private int guidelineSelectionID;
		[ColumnMapping("GuidelineIndicatorID",StereoType=DataStereoType.FK)]
		private int guidelineIndicatorID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		private int referralID;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("ProblemID",StereoType=DataStereoType.FK)]
		private int problemID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
	
		public GuidelineSelection()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GuidelineSelectionID
		{
			get { return this.guidelineSelectionID; }
			set { this.guidelineSelectionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int GuidelineIndicatorID
		{
			get { return this.guidelineIndicatorID; }
			set { this.guidelineIndicatorID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProblemID
		{
			get { return this.problemID; }
			set { this.problemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int guidelineSelectionID)
		{
			return base.Load(guidelineSelectionID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int guidelineSelectionID)
		{
			base.Delete(guidelineSelectionID);		
		}

		/// <summary>
		/// Parent GuidelineSelectionCollection that contains this element
		/// </summary>
		public GuidelineSelectionCollection ParentGuidelineSelectionCollection
		{
			get
			{
				return this.parentGuidelineSelectionCollection;
			}
			set
			{
				this.parentGuidelineSelectionCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.IsNew = true;
			this.NewRecord(); // initialize record state

		}
	}

	/// <summary>
	/// Strongly typed collection of GuidelineSelection objects
	/// </summary>
	[ElementType(typeof(GuidelineSelection))]
	public class GuidelineSelectionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GuidelineSelection elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGuidelineSelectionCollection = this;
			else
				elem.ParentGuidelineSelectionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GuidelineSelection elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GuidelineSelection this[int index]
		{
			get
			{
				return (GuidelineSelection)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GuidelineSelection)oldValue, false);
			SetParentOnElem((GuidelineSelection)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, GuidelineSelection elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GuidelineSelection)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GuidelineSelection elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
	}
}
