using System;

using NetsoftUSA.DataLayer;
using System.Text;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GuidelineIndicator]
	/// </summary>
	[SPAutoGen("usp_LoadActiveGuidelineIndicators","SelectAllByGivenArgs.sptpl","guidelineID, active")]
	[SPAutoGen("usp_GetIndicatorsForGuideline","SelectAllByGivenArgs.sptpl","guidelineID")]
	[SPExists("usp_ExistsGuidelineIndicator")]
	[SPInsert("usp_InsertGuidelineIndicator")]
	[SPUpdate("usp_UpdateGuidelineIndicator")]
	[SPDelete("usp_DeleteGuidelineIndicator")]
	[SPLoad("usp_LoadGuidelineIndicator")]
	[TableMapping("GuidelineIndicator","guidelineIndicatorID")]
	public class GuidelineIndicator : BaseData
	{
		[NonSerialized]
		private GuidelineIndicatorCollection parentGuidelineIndicatorCollection;
		[ColumnMapping("GuidelineIndicatorID",(int)0)]
		private int guidelineIndicatorID;
		[ColumnMapping("GuidelineID",StereoType=DataStereoType.FK)]
		private int guidelineID;
		[ColumnMapping("Hierarchy",StereoType=DataStereoType.FK)]
		private int hierarchy;
		[ColumnMapping("Text")]
		private string text;
		[ColumnMapping("Selectable")]
		private bool selectable;
		[ColumnMapping("NoteRequired")]
		private bool noteRequired;
		[ColumnMapping("Instruction")]
		private string instruction;
		[ColumnMapping("DefaultNote")]
		private string defaultNote;
		[ColumnMapping("SortSequence",StereoType=DataStereoType.FK)]
		private int sortSequence;
		[ColumnMapping("Type1")]
		private string type1;
		[ColumnMapping("Type2")]
		private string type2;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		private GuidelineIndicatorTipCollection guidelineIndicatorTips;
	
		public GuidelineIndicator()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public GuidelineIndicator(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GuidelineIndicatorID
		{
			get { return this.guidelineIndicatorID; }
			set { this.guidelineIndicatorID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int GuidelineID
		{
			get { return this.guidelineID; }
			set { this.guidelineID = value; }
		}

		
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int Hierarchy
		{
			get { return this.hierarchy; }
			set { this.hierarchy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=250)]
		public string Text
		{
			get { if (this.text != null)
					  return System.Web.HttpUtility.HtmlEncode(this.text.Trim());
				else
				  return this.text;}
			set { this.text = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Selectable
		{
			get { return this.selectable; }
			set { this.selectable = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool NoteRequired
		{
			get { return this.noteRequired; }
			set { this.noteRequired = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=160)]
		public string Instruction
		{
			get { return this.instruction; }
			set { this.instruction = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=160)]
		public string DefaultNote
		{
			get { return this.defaultNote; }
			set { this.defaultNote = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SortSequence
		{
			get { return this.sortSequence; }
			set { this.sortSequence = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=5)]
		public string Type1
		{
			get { return this.type1; }
			set { this.type1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=5)]
		public string Type2
		{
			get { return this.type2; }
			set { this.type2 = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}
		[ControlType(EnumControlTypes.TextBox)]
		public string DisplayText
		{
			get
			{
				StringBuilder sb = new StringBuilder();
				for(int i=0; i<this.hierarchy;i++)
					sb.Append("&nbsp;&nbsp;");
				sb.Append(this.hierarchy.ToString());
				sb.Append(")");
				sb.Append(this.text);
				return sb.ToString();
			}

		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int guidelineIndicatorID)
		{
			return base.Load(guidelineIndicatorID);
		}

		/// <summary>
		/// Parent GuidelineIndicatorCollection that contains this element
		/// </summary>
		public GuidelineIndicatorCollection ParentGuidelineIndicatorCollection
		{
			get
			{
				return this.parentGuidelineIndicatorCollection;
			}
			set
			{
				this.parentGuidelineIndicatorCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child GuidelineIndicatorTips mapped to related rows of table GuidelineIndicatorTip where [GuidelineIndicatorID] = [GuidelineIndicatorID]
		/// </summary>
		[SPLoadChild("usp_LoadGuidelineIndicatorGuidelineIndicatorTip", "guidelineIndicatorID")]
		public GuidelineIndicatorTipCollection GuidelineIndicatorTips
		{
			get { return this.guidelineIndicatorTips; }
			set
			{
				this.guidelineIndicatorTips = value;
				if (value != null)
					value.ParentGuidelineIndicator = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the GuidelineIndicatorTips collection
		/// </summary>
		public void LoadGuidelineIndicatorTips(bool forceReload)
		{
			this.guidelineIndicatorTips = (GuidelineIndicatorTipCollection)GuidelineIndicatorTipCollection.LoadChildCollection("GuidelineIndicatorTips", this, typeof(GuidelineIndicatorTipCollection), guidelineIndicatorTips, forceReload, null);
		}

		/// <summary>
		/// Saves the GuidelineIndicatorTips collection
		/// </summary>
		public void SaveGuidelineIndicatorTips()
		{
			GuidelineIndicatorTipCollection.SaveChildCollection(this.guidelineIndicatorTips, true);
		}

	
		/// <summary>
		/// Synchronizes the GuidelineIndicatorTips collection
		/// </summary>
		public void SynchronizeGuidelineIndicatorTips()
		{
			GuidelineIndicatorTipCollection.SynchronizeChildCollection(this.guidelineIndicatorTips, true);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.
			SaveGuidelineIndicatorTips();
			
		}

				
	}

	/// <summary>
	/// Strongly typed collection of GuidelineIndicator objects
	/// </summary>
	[ElementType(typeof(GuidelineIndicator))]
	public class GuidelineIndicatorCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Parent Guideline that contains this collection
		/// </summary>
		public Guideline ParentGuideline
		{
			get { return this.ParentDataObject as Guideline; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Guideline */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadIndicatorsForGuideline(int maxRecords, int guidelineID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetIndicatorsForGuideline", maxRecords, this, false, new object[] { guidelineID });
		}

		/// <summary>
		/// Returns true if the collection contains the given object
		/// </summary>
		public bool Contains(GuidelineIndicator elem)
		{
			return List.Contains(elem);
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GuidelineIndicator elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGuidelineIndicatorCollection = this;
			else
				elem.ParentGuidelineIndicatorCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GuidelineIndicator elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GuidelineIndicator this[int index]
		{
			get
			{
				return (GuidelineIndicator)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GuidelineIndicator)oldValue, false);
			SetParentOnElem((GuidelineIndicator)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}
}
