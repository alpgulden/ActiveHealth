using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GuidelineCode]
	/// </summary>
	[SPAutoGen("usp_GetGuidelineCodesForGuideline","SelectAllByGivenArgs.sptpl","guidelineID")]
	[SPInsert("usp_InsertGuidelineCode")]
	[SPUpdate("usp_UpdateGuidelineCode")]
	[SPDelete("usp_DeleteGuidelineCode")]
	[SPLoad("usp_LoadGuidelineCode")]
	[TableMapping("GuidelineCode","guidelineCodeID")]
	public class GuidelineCode : BaseData
	{
		[NonSerialized]
		private GuidelineCodeCollection parentGuidelineCodeCollection;
		[ColumnMapping("GuidelineCodeID",(int)0)]
		private int guidelineCodeID;
		[ColumnMapping("GuidelineID",StereoType=DataStereoType.FK)]
		private int guidelineID;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("DiagOrPrc")]
		private string diagOrPrc;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("ReadOnly")]
		private bool readOnly;
		[ColumnMapping("CodeType")]
		private string codeType;
	
		public GuidelineCode()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public GuidelineCode(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GuidelineCodeID
		{
			get { return this.guidelineCodeID; }
			set { this.guidelineCodeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int GuidelineID
		{
			get { return this.guidelineID; }
			set { this.guidelineID = value; }
		}


		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=16)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string DiagOrPrc
		{
			get { return this.diagOrPrc; }
			set { this.diagOrPrc = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReadOnly
		{
			get { return this.readOnly; }
			set { this.readOnly = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string CodeType
		{
			get { return this.codeType; }
			set { this.codeType = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int guidelineCodeID)
		{
			return base.Load(guidelineCodeID);
		}

		/// <summary>
		/// Parent GuidelineCodeCollection that contains this element
		/// </summary>
		public GuidelineCodeCollection ParentGuidelineCodeCollection
		{
			get
			{
				return this.parentGuidelineCodeCollection;
			}
			set
			{
				this.parentGuidelineCodeCollection = value; // parent is set when added to a collection
			}
		}
		public void CopyMembersFromSelection(DiagnosticSelect sel)
		{
			this.codeType = sel.CodeType;
			this.code = sel.CodeValue;
			this.diagOrPrc = BaseDxPx.DxPxDiagnostic;
			
			// copy flags
			this.IsMarkedForDeletion = sel.IsMarkedForDeletion;
			this.IsNew = sel.IsNew;
			this.IsDirty = sel.IsDirty;
		}

		public void CopyMembersFromSelection(ProcedureSelect sel)
		{
			this.codeType = sel.CodeType;
			this.code = sel.CodeValue;
			this.diagOrPrc = BaseDxPx.DxPxProcedure;
			
			// copy flags
			this.IsMarkedForDeletion = sel.IsMarkedForDeletion;
			this.IsNew = sel.IsNew;
			this.IsDirty = sel.IsDirty;
		}

	}

	/// <summary>
	/// Strongly typed collection of GuidelineCode objects
	/// </summary>
	[ElementType(typeof(GuidelineCode))]
	public class GuidelineCodeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Parent GuidelineSourceSet that contains this collection
		/// </summary>
		public GuidelineSourceSet ParentGuidelineSourceSet
		{
			get { return this.ParentDataObject as GuidelineSourceSet; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GuidelineSourceSet */ }
		}

		/// <summary>
		/// Parent Guideline that contains this collection
		/// </summary>
		public Guideline ParentGuideline
		{
			get { return this.ParentDataObject as Guideline; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Guideline */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineCodesForGuideline(int maxRecords, int guidelineID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineCodesForGuideline", maxRecords, this, false, new object[] { guidelineID });
		}

		public DxPxSelectCollection CreateDxPxCollection(string DiagOrProc)
		{
			if(DiagOrProc == BaseDxPx.DxPxDiagnostic)
			{
				DiagnosticSelectCollection dsc = new DiagnosticSelectCollection();
				for (int i = 0; i < this.Count; i++)
				{
					GuidelineCode c = this[i];
					if (c.DiagOrPrc == BaseDxPx.DxPxDiagnostic)
					{
						BaseDxPx dxpx = DxPxCodeClassFactory.CreateAndLoadDxPxInstance(c.CodeType, c.Code, BaseDxPx.DxPxDiagnostic);
						int iSel =dsc.Add(dxpx);
						DxPxSelect sel = dsc[iSel];
						sel.SourceCollectionIndex = i;
					}
				}
				return dsc;
			}
			else
			{
				ProcedureSelectCollection psc = new ProcedureSelectCollection();
				for (int i = 0; i < this.Count; i++)
				{
					GuidelineCode c = this[i];
					if (c.DiagOrPrc == BaseDxPx.DxPxProcedure)
					{
						BaseDxPx dxpx = DxPxCodeClassFactory.CreateAndLoadDxPxInstance(c.CodeType, c.Code, BaseDxPx.DxPxProcedure);
						int iSel = psc.Add(dxpx);
						DxPxSelect sel = psc[iSel];
						sel.SourceCollectionIndex = i;
					}
				}
				return psc;
			}
		}

		public void SyncFromSelections(DiagnosticSelectCollection diagnostics)
		{
			for (int i = 0; i < diagnostics.Count; i++)
			{
				DiagnosticSelect sel = diagnostics[i];
				GuidelineCode diag = null;
				if (sel.ParentSelectionIndex < 0)		// this is just a linked element used for display purpose.
				{
					if (sel.IsNew)
					{
						diag = new GuidelineCode(true);
						this.AddRecord(diag);
					}
					else
					{
						if (sel.SourceCollectionIndex < 0)
							throw new ActiveAdviceException(AAExceptionAction.None, "Source collection index is not on the selection, can't update back");
						diag = this[sel.SourceCollectionIndex];
					}

					if (diag != null)
						diag.CopyMembersFromSelection(sel);
				}
			}
		}

		public void SyncFromSelections(ProcedureSelectCollection procedures)
		{
			for (int i = 0; i < procedures.Count; i++)
			{
				ProcedureSelect sel = procedures[i];
				GuidelineCode proc = null;
				if (sel.ParentSelectionIndex < 0)		// this is just a linked element used for display purpose.
				{
					if (sel.IsNew)
					{
						proc = new GuidelineCode(true);
						this.AddRecord(proc);
					}
					else
					{
						if (sel.SourceCollectionIndex < 0)
							throw new ActiveAdviceException(AAExceptionAction.None, "Source collection index is not on the selection, can't update back");
						proc = this[sel.SourceCollectionIndex];
					}

					if (proc != null)
						proc.CopyMembersFromSelection(sel);
				}
			}
		}


		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GuidelineCode elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGuidelineCodeCollection = this;
			else
				elem.ParentGuidelineCodeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GuidelineCode elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GuidelineCode this[int index]
		{
			get
			{
				return (GuidelineCode)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GuidelineCode)oldValue, false);
			SetParentOnElem((GuidelineCode)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

	}
}
