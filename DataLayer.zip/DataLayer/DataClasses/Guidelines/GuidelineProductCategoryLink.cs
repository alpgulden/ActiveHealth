using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GuidelineProductCategoryLink]
	/// </summary>
	[SPInsert("usp_InsertGuidelineProductCategoryLink")]
	[SPUpdate("usp_UpdateGuidelineProductCategoryLink")]
	[SPDelete("usp_DeleteGuidelineProductCategoryLink")]
	[SPLoad("usp_LoadGuidelineProductCategoryLink")]
	[TableMapping("GuidelineProductCategoryLink","GuidelineCategoryID,GuidelineID,GuidelineProductID",true)]
	public class GuidelineProductCategoryLink : BaseData
	{
		[NonSerialized]
		private GuidelineProductCategoryLinkCollection parentGuidelineProductCategoryLinkCollection;
		[ColumnMapping("GuidelineCategoryID",StereoType=DataStereoType.FK)]
		private int guidelineCategoryID;
		[ColumnMapping("GuidelineID",StereoType=DataStereoType.FK)]
		private int guidelineID;
		[ColumnMapping("GuidelineProductID",StereoType=DataStereoType.FK)]
		private int guidelineProductID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public GuidelineProductCategoryLink()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public GuidelineProductCategoryLink(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GuidelineCategoryID
		{
			get { return this.guidelineCategoryID; }
			set { this.guidelineCategoryID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int GuidelineID
		{
			get { return this.guidelineID; }
			set { this.guidelineID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int GuidelineProductID
		{
			get { return this.guidelineProductID; }
			set { this.guidelineProductID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int guidelineCategoryID)
		{
			return base.Load(guidelineCategoryID);
		}

		/// <summary>
		/// Parent GuidelineProductCategoryLinkCollection that contains this element
		/// </summary>
		public GuidelineProductCategoryLinkCollection ParentGuidelineProductCategoryLinkCollection
		{
			get
			{
				return this.parentGuidelineProductCategoryLinkCollection;
			}
			set
			{
				this.parentGuidelineProductCategoryLinkCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of GuidelineProductCategoryLink objects
	/// </summary>
	[ElementType(typeof(GuidelineProductCategoryLink))]
	public class GuidelineProductCategoryLinkCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
	}
}
