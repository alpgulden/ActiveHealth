using System;
using System.Text;
using System.Web;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GuidelineSourceSet]
	/// </summary>
	[SPAutoGen("usp_GetAllGuidelineSourceSets","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetGuidelineSourceSetsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertGuidelineSourceSet")]
	[SPUpdate("usp_UpdateGuidelineSourceSet")]
	[SPDelete("usp_DeleteGuidelineSourceSet")]
	[SPLoad("usp_LoadGuidelineSourceSet")]
	[TableMapping("GuidelineSourceSet","guidelineSourceSetID")]
	public class GuidelineSourceSet : BaseData
	{
		[NonSerialized]
		private GuidelineSourceSetCollection parentGuidelineSourceSetCollection;
		[ColumnMapping("GuidelineSourceSetID",StereoType=DataStereoType.FK)]
		private int guidelineSourceSetID;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("ProductLabel")]
		private string productLabel;
		[ColumnMapping("CategoryLabel")]
		private string categoryLabel;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("ExportDate")]
		private DateTime exportDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ReadOnly")]
		private bool readOnly;
		private GuidelineCollection guidelines;
		private GuidelineProductCollection guidelineProducts;
		private GuidelineCategoryCollection guidelineCategories;
//		private GuidelineCodeCollection guidelineCodes;
	
		public GuidelineSourceSet()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public GuidelineSourceSet(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GuidelineSourceSetID
		{
			get { return this.guidelineSourceSetID; }
			set { this.guidelineSourceSetID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=12)]
		public string ProductLabel
		{
			get { return this.productLabel; }
			set { this.productLabel = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=12)]
		public string CategoryLabel
		{
			get { return this.categoryLabel; }
			set { this.categoryLabel = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { if (this.note != null)
					  return System.Web.HttpUtility.HtmlEncode(note).Trim();
				  else
					  return this.note; }
			set { this.note = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ExportDate
		{
			get { return this.exportDate; }
			set { this.exportDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Parent GuidelineSourceSetCollection that contains this element
		/// </summary>
		public GuidelineSourceSetCollection ParentGuidelineSourceSetCollection
		{
			get
			{
				return this.parentGuidelineSourceSetCollection;
			}
			set
			{
				this.parentGuidelineSourceSetCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int guidelineSourceSetID)
		{
			return base.Load(guidelineSourceSetID);
		}

		/// <summary>
		/// Child Guidelines mapped to related rows of table Guideline where [GuidelineSourceSetID] = [GuidelineSourceSetID]
		/// </summary>
		[SPLoadChild("usp_LoadGuidelineSourceSetGuideline", "guidelineSourceSetID")]
		public GuidelineCollection Guidelines
		{
			get { return this.guidelines; }
			set
			{
				this.guidelines = value;
				if (value != null)
					value.ParentGuidelineSourceSet = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Guidelines collection
		/// </summary>
		public void LoadGuidelines(bool forceReload)
		{
			this.guidelines = (GuidelineCollection)GuidelineCollection.LoadChildCollection("Guidelines", this, typeof(GuidelineCollection), guidelines, forceReload, null);
		}

		/// <summary>
		/// Saves the Guidelines collection
		/// </summary>
		public void SaveGuidelines()
		{
			GuidelineCollection.SaveChildCollection(this.guidelines, true);
		}

		/// <summary>
		/// Synchronizes the Guidelines collection
		/// </summary>
		public void SynchronizeGuidelines()
		{
			GuidelineCollection.SynchronizeChildCollection(this.guidelines, true);
		}

		/// <summary>
		/// Child GuidelineProducts mapped to related rows of table GuidelineProduct where [GuidelineSourceSetID] = [GuidelineSourceSetID]
		/// </summary>
		[SPLoadChild("usp_LoadGuidelineSourceSetGuidelineProduct", "guidelineSourceSetID")]
		public GuidelineProductCollection GuidelineProducts
		{
			get { return this.guidelineProducts; }
			set
			{
				this.guidelineProducts = value;
				if (value != null)
					value.ParentGuidelineSourceSet = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the GuidelineProducts collection
		/// </summary>
		public void LoadGuidelineProducts(bool forceReload)
		{
			this.guidelineProducts = (GuidelineProductCollection)GuidelineProductCollection.LoadChildCollection("GuidelineProducts", this, typeof(GuidelineProductCollection), guidelineProducts, forceReload, null);
		}

		/// <summary>
		/// Saves the GuidelineProducts collection
		/// </summary>
		public void SaveGuidelineProducts()
		{
			GuidelineProductCollection.SaveChildCollection(this.guidelineProducts, true);
		}

		/// <summary>
		/// Synchronizes the GuidelineProducts collection
		/// </summary>
		public void SynchronizeGuidelineProducts()
		{
			GuidelineProductCollection.SynchronizeChildCollection(this.guidelineProducts, true);
		}

		/// <summary>
		/// Child GuidelineCategories mapped to related rows of table GuidelineCategory where [GuidelineSourceSetID] = [GuidelineSourceSetID]
		/// </summary>
		[SPLoadChild("usp_LoadGuidelineSourceSetGuidelineCategory", "guidelineSourceSetID")]
		public GuidelineCategoryCollection GuidelineCategories
		{
			get { return this.guidelineCategories; }
			set
			{
				this.guidelineCategories = value;
				if (value != null)
					value.ParentGuidelineSourceSet = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the GuidelineCategories collection
		/// </summary>
		public void LoadGuidelineCategories(bool forceReload)
		{
			this.guidelineCategories = (GuidelineCategoryCollection)GuidelineCategoryCollection.LoadChildCollection("GuidelineCategories", this, typeof(GuidelineCategoryCollection), guidelineCategories, forceReload, null);
		}

		/// <summary>
		/// Saves the GuidelineCategories collection
		/// </summary>
		public void SaveGuidelineCategories()
		{
			GuidelineCategoryCollection.SaveChildCollection(this.guidelineCategories, true);
		}

		/// <summary>
		/// Synchronizes the GuidelineCategories collection
		/// </summary>
		public void SynchronizeGuidelineCategories()
		{
			GuidelineCategoryCollection.SynchronizeChildCollection(this.guidelineCategories, true);
		}

		/// <summary>
		/// Child GuidelineCodes mapped to related rows of table GuidelineCode where [GuidelineSourceSetID] = [GuidelineSourceSetID]
		/// </summary>
//		[SPLoadChild("usp_LoadGuidelineSourceSetGuidelineCode", "guidelineSourceSetID")]
//		public GuidelineCodeCollection GuidelineCodes
//		{
//			get { return this.guidelineCodes; }
//			set
//			{
//				this.guidelineCodes = value;
//				if (value != null)
//					value.ParentGuidelineSourceSet = this; // set this as a parent of the child collection
//			}
//		}

//		/// <summary>
//		/// Loads the GuidelineCodes collection
//		/// </summary>
//		public void LoadGuidelineCodes(bool forceReload)
//		{
//			this.guidelineCodes = (GuidelineCodeCollection)GuidelineCodeCollection.LoadChildCollection("GuidelineCodes", this, typeof(GuidelineCodeCollection), guidelineCodes, forceReload, null);
//		}
//
//		/// <summary>
//		/// Saves the GuidelineCodes collection
//		/// </summary>
//		public void SaveGuidelineCodes()
//		{
//			GuidelineCodeCollection.SaveChildCollection(this.guidelineCodes, true);
//		}
//
//		/// <summary>
//		/// Synchronizes the GuidelineCodes collection
//		/// </summary>
//		public void SynchronizeGuidelineCodes()
//		{
//			GuidelineCodeCollection.SynchronizeChildCollection(this.guidelineCodes, true);
//		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReadOnly
		{
			get { return this.readOnly; }
			set { this.readOnly = value; }
		}

	

	}

	/// <summary>
	/// Strongly typed collection of GuidelineSourceSet objects
	/// </summary>
	[ElementType(typeof(GuidelineSourceSet))]
	public class GuidelineSourceSetCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_GuidelineSourceSetID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GuidelineSourceSet elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGuidelineSourceSetCollection = this;
			else
				elem.ParentGuidelineSourceSetCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GuidelineSourceSet elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GuidelineSourceSet this[int index]
		{
			get
			{
				return (GuidelineSourceSet)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GuidelineSourceSet)oldValue, false);
			SetParentOnElem((GuidelineSourceSet)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineSourceSetsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineSourceSetsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared GuidelineSourceSetCollection which is cached in NSGlobal
		/// </summary>
		public static GuidelineSourceSetCollection ActiveGuidelineSourceSets
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				GuidelineSourceSetCollection col = (GuidelineSourceSetCollection)NSGlobal.EnsureCachedObject("ActiveGuidelineSourceSets", typeof(GuidelineSourceSetCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadGuidelineSourceSetsByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on guidelineSourceSetID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_GuidelineSourceSetID
		{
			get
			{
				if (this.indexBy_GuidelineSourceSetID == null)
					this.indexBy_GuidelineSourceSetID = new CollectionIndexer(this, new string[] { "guidelineSourceSetID" }, true);
				return this.indexBy_GuidelineSourceSetID;
			}
			
		}

		/// <summary>
		/// Looks up by guidelineSourceSetID and returns Note value.  Uses the IndexBy_GuidelineSourceSetID indexer.
		/// </summary>
		public string Lookup_NoteByGuidelineSourceSetID(int guidelineSourceSetID)
		{
			return this.IndexBy_GuidelineSourceSetID.LookupStringMember("Note", guidelineSourceSetID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllGuidelineSourceSets(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllGuidelineSourceSets", maxRecords, this, false);
		}

		public static void ClearFromCache()
		{
			NSGlobal.ClearCache(typeof(GuidelineSourceSetCollection), false);
		}

	}
}
