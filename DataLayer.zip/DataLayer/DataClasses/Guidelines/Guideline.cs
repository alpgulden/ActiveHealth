using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Guideline]
	/// </summary>
	[SPAutoGen("usp_GetActiveGuidelinesForProduct","SelectRelatedFromLinkedTableWithFilter.sptpl","GuidelineProductCategoryLink, guidelineID, guidelineProductID, active")]
	[SPAutoGen("usp_GetActiveGuidelinesForCategory","SelectRelatedFromLinkedTableWithFilter.sptpl","GuidelineProductCategoryLink, guidelineID, guidelineCategoryID, active")]
	[SPAutoGen("usp_GetActiveGuidelinesForProductCategory","SelectRelatedFromLinkedTable2ColBreakerFilter.sptpl","GuidelineProductCategoryLink, guidelineID, guidelineProductID, guidelineCategoryID, active")]
	[SPAutoGen("usp_GetActiveGuidelinesForProductCategorySS","SelectRelatedFromLinkedTable2ColBreakerFilter.sptpl","GuidelineProductCategoryLink, guidelineID, guidelineProductID, guidelineCategoryID, guidelineSourceSetID, active")]
	[SPAutoGen("usp_GetActiveGuidelinesForSS","SelectAllByGivenArgs.sptpl","active, guidelineSourceSetID")]
	[SPAutoGen("usp_GetActiveGuidelines","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetGuidelinesForSourceSet","SelectAllByGivenArgs.sptpl","guidelineSourceSetID")]
	[SPAutoGen("usp_GetAllGuidelinesForCode","SelectRelatedFromLinkedTable.sptpl","GuidelineCode, GuidelineID, Code, CodeType, DiagOrPrc")]
	[SPDelete("usp_DeleteGuideline")]
	[SPAutoGen("usp_LoadAllGuidelines","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetLinkedGuidelinesForProductCategorySS","SelectRelatedFromLinkedTable2ColBreakerFilter.sptpl","GuidelineProductCategoryLink, guidelineID, guidelineProductID, guidelineCategoryID, guidelineSourceSetID")]
	[SPAutoGen("usp_GetGuidelinesForCategorySourceSet","SearchLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineID, guidelineCategoryID, guidelineSourceSetID")]
	[SPAutoGen("usp_GetLinkedGuidelinesForProductCategory","SelectRelatedFromLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineID, guidelineProductID, guidelineCategoryID")]
	[SPAutoGen("usp_GetGuidelinesForProductSourceSet","SearchLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineID, guidelineProductID, guidelineSourceSetID")]
	[SPAutoGen("usp_GetLinkedGuidelinesForCategory","SelectRelatedFromLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineID, guidelineCategoryID")]
	[SPAutoGen("usp_GetLinkedGuidelinesForProduct","SelectRelatedFromLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineID, guidelineProductID")]
	[SPInsert("usp_InsertGuideline")]
	[SPUpdate("usp_UpdateGuideline")]
	[SPLoad("usp_LoadGuideline")]
	[TableMapping("Guideline","guidelineID")]
	public class Guideline : BaseData
	{
		[NonSerialized]
		private GuidelineCollection parentGuidelineCollection;
		[ColumnMapping("GuidelineID",(int)0)]
		private int guidelineID;
		[ColumnMapping("GuidelineSourceSetID",StereoType=DataStereoType.FK)]
		private int guidelineSourceSetID;
		[ColumnMapping("Text")]
		private string text;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		
		private GuidelineIndicatorCollection guidelineIndicators;
		private GuidelineCodeCollection guidelineCodes;
		private GuidelineTipCollection guidelineTips;
	
		public Guideline()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Guideline(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GuidelineID
		{
			get { return this.guidelineID; }
			set { this.guidelineID = value; }
		}
		[FieldValuesMember("LookupOf_guidelineSourceSetID", "GuidelineSourceSetID", "Note")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int GuidelineSourceSetID
		{
			get { return this.guidelineSourceSetID; }
			set { this.guidelineSourceSetID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=80)]
		public string Text
		{
			get {if(this.text != null)
					  return this.text.Trim();
				else
					return this.text; }
			set { this.text = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}


		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent GuidelineCollection that contains this element
		/// </summary>
		public GuidelineCollection ParentGuidelineCollection
		{
			get
			{
				return this.parentGuidelineCollection;
			}
			set
			{
				this.parentGuidelineCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int guidelineID)
		{
			return base.Load(guidelineID);
		}

		

		/// <summary>
		/// Child GuidelineIndicators mapped to related rows of table GuidelineIndicator where [GuidelineID] = [GuidelineID]
		/// </summary>
		[SPLoadChild("usp_LoadGuidelineGuidelineIndicator", "guidelineID")]
		public GuidelineIndicatorCollection GuidelineIndicators
		{
			get { return this.guidelineIndicators; }
			set
			{
				this.guidelineIndicators = value;
				if (value != null)
					value.ParentGuideline = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the GuidelineIndicators collection
		/// </summary>
		public void LoadGuidelineIndicators(bool forceReload)
		{
			this.guidelineIndicators = (GuidelineIndicatorCollection)GuidelineIndicatorCollection.LoadChildCollection("GuidelineIndicators", this, typeof(GuidelineIndicatorCollection), guidelineIndicators, forceReload, null);
		}

		/// <summary>
		/// Loads the GuidelineIndicators collection active only
		/// </summary>
		public void LoadGuidelineIndicatorsActiveOnly(bool forceReload)
		{
			this.guidelineIndicators = (GuidelineIndicatorCollection)GuidelineIndicatorCollection.LoadChildCollection( "GuidelineIndicators", "usp_LoadActiveGuidelineIndicators", this, typeof(GuidelineIndicatorCollection), guidelineIndicators, forceReload, null,new object[]{this.guidelineID,true} );
		}

		/// <summary>
		/// Saves the GuidelineIndicators collection
		/// </summary>
		public void SaveGuidelineIndicators()
		{
			GuidelineIndicatorCollection.SaveChildCollection(this.guidelineIndicators, true);
		}

		/// <summary>
		/// Synchronizes the GuidelineIndicators collection
		/// </summary>
		public void SynchronizeGuidelineIndicators()
		{
			GuidelineIndicatorCollection.SynchronizeChildCollection(this.guidelineIndicators, true);
		}

		/// <summary>
		/// Child GuidelineCodes mapped to related rows of table GuidelineCode where [GuidelineID] = [GuidelineID]
		/// </summary>
		[SPLoadChild("usp_LoadGuidelineGuidelineCode", "guidelineID")]
		public GuidelineCodeCollection GuidelineCodes
		{
			get { return this.guidelineCodes; }
			set
			{
				this.guidelineCodes = value;
				if (value != null)
					value.ParentGuideline = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the GuidelineCodes collection
		/// </summary>
		public void LoadGuidelineCodes(bool forceReload)
		{
			this.guidelineCodes = (GuidelineCodeCollection)GuidelineCodeCollection.LoadChildCollection("GuidelineCodes", this, typeof(GuidelineCodeCollection), guidelineCodes, forceReload, null);
		}

		/// <summary>
		/// Saves the GuidelineCodes collection
		/// </summary>
		public void SaveGuidelineCodes()
		{
			GuidelineCodeCollection.SaveChildCollection(this.guidelineCodes, true);
		}

		/// <summary>
		/// Synchronizes the GuidelineCodes collection
		/// </summary>
		public void SynchronizeGuidelineCodes()
		{
			GuidelineCodeCollection.SynchronizeChildCollection(this.guidelineCodes, true);
		}

		public GuidelineSourceSetCollection LookupOf_guidelineSourceSetID
		{
			get
			{
				return GuidelineSourceSetCollection.ActiveGuidelineSourceSets; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public string GuidelineSourceSetName
		{
			get { return GuidelineSourceSetCollection.ActiveGuidelineSourceSets.Lookup_NoteByGuidelineSourceSetID(this.guidelineSourceSetID); }
			
		}



		/// <summary>
		/// Child GuidelineTips mapped to related rows of table GuidelineTip where [GuidelineID] = [GuidelineID]
		/// </summary>
		[SPLoadChild("usp_LoadGuidelineGuidelineTip", "guidelineID")]
		public GuidelineTipCollection GuidelineTips
		{
			get { return this.guidelineTips; }
			set
			{
				this.guidelineTips = value;
				if (value != null)
					value.ParentGuideline = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the GuidelineTips collection
		/// </summary>
		public void LoadGuidelineTips(bool forceReload)
		{
			this.guidelineTips = (GuidelineTipCollection)GuidelineTipCollection.LoadChildCollection("GuidelineTips", this, typeof(GuidelineTipCollection), guidelineTips, forceReload, null);
		}

		/// <summary>
		/// Saves the GuidelineTips collection
		/// </summary>
		public void SaveGuidelineTips()
		{
			GuidelineTipCollection.SaveChildCollection(this.guidelineTips, true);
		}

		/// <summary>
		/// Synchronizes the GuidelineTips collection
		/// </summary>
		public void SynchronizeGuidelineTips()
		{
			GuidelineTipCollection.SynchronizeChildCollection(this.guidelineTips, true);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			this.SaveGuidelineTips();
			this.SaveGuidelineIndicators();
			this.SaveGuidelineCodes();
			// Save the child collections here.
		}
	}

	/// <summary>
	/// Strongly typed collection of Guideline objects
	/// </summary>
	[ElementType(typeof(Guideline))]
	public class GuidelineCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Parent GuidelineSourceSet that contains this collection
		/// </summary>
		public GuidelineSourceSet ParentGuidelineSourceSet
		{
			get { return this.ParentDataObject as GuidelineSourceSet; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GuidelineSourceSet */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelinesForSourceSet(int maxRecords, int guidelineSourceSetID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelinesForSourceSet", maxRecords, this, false, new object[] { guidelineSourceSetID });
		}

		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadLinkedGuidelinesForProduct(int maxRecords, int guidelineProductID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetLinkedGuidelinesForProduct", maxRecords, this, false, new object[] {guidelineProductID});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadLinkedGuidelinesForCategory(int maxRecords,int guidelineCategoryID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetLinkedGuidelinesForCategory", maxRecords, this, false,new object[] {guidelineCategoryID});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadLinkedGuidelinesForProductCategorySS(int maxRecords, int guidelineSourceSetID,int guidelineProductID, int guidelineCategoryID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetLinkedGuidelinesForProductCategorySS", maxRecords, this, false, new object[] {guidelineProductID,guidelineCategoryID,guidelineSourceSetID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllGuidelines(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadAllGuidelines", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadLinkedGuidelinesForProductCategory(int maxRecords,int guidelineProductID,int guidelineCategoryID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetLinkedGuidelinesForProductCategory", maxRecords, this, false, new object[]{guidelineProductID,guidelineCategoryID});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelinesForProductSourceSet(int maxRecords,int guidelineProductID, int guidelineSourceSetID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelinesForProductSourceSet", maxRecords, this, false, new object[] { guidelineProductID,guidelineSourceSetID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelinesForCategorySourceSet(int maxRecords,int guidelineCategoryID, int guidelineSourceSetID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelinesForCategorySourceSet", maxRecords, this, false, new object[] { guidelineCategoryID,guidelineSourceSetID });
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Guideline elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGuidelineCollection = this;
			else
				elem.ParentGuidelineCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Guideline elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Guideline this[int index]
		{
			get
			{
				return (Guideline)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Guideline)oldValue, false);
			SetParentOnElem((Guideline)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllGuidelinesForCode(int maxRecords, string codeType,string code,string diagOrPrc)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllGuidelinesForCode", maxRecords, this, false, new object[] {code,codeType,diagOrPrc});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveGuidelinesForProduct(int maxRecords, int guidelineProductID,bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveGuidelinesForProduct", maxRecords, this, false, new object[] {guidelineProductID, active });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveGuidelinesForCategory(int maxRecords, int guidelineCategoryID,bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveGuidelinesForCategory", maxRecords, this, false, new object[] {guidelineCategoryID, active });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveGuidelinesForProductCategory(int maxRecords,int guidelineProductID,int guidelineCategoryID, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveGuidelinesForProductCategory", maxRecords, this, false, new object[] {guidelineProductID,guidelineCategoryID, active });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveGuidelinesForProductCategorySS(int maxRecords,int guidelineProductID,int guidelineCategoryID, int guidelineSourceSetID, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveGuidelinesForProductCategorySS", maxRecords, this, false, new object[] { guidelineProductID,guidelineCategoryID,guidelineSourceSetID, active });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveGuidelinesForSS(int maxRecords, bool active, int guidelineSourceSetID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveGuidelinesForSS", maxRecords, this, false, new object[] { active, guidelineSourceSetID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveGuidelines(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveGuidelines", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveGuidelinesForProductSourceSet(int maxRecords,int guidelineProductID, int guidelineSourceSetID,bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveGuidelinesForProductSS", maxRecords, this, false, new object[] { guidelineProductID,guidelineSourceSetID,active });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveGuidelinesForCategorySourceSet(int maxRecords,int guidelineCategoryID, int guidelineSourceSetID,bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveGuidelinesForCategorySS", maxRecords, this, false, new object[] { guidelineCategoryID,guidelineSourceSetID,active });
		}
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveGuidelinesForCode(int maxRecords, string codeType,string code,string diagOrPrc,bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveGuidelinesForCode", maxRecords, this, false, new object[] {code,codeType,diagOrPrc,active});
		}
		}
}
