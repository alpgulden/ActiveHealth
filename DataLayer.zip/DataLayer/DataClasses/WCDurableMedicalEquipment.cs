using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [WCDurableMedicalEquipment]
	/// </summary>
	[SPAutoGen("usp_GetAllWCDurableMedicalEquipment","SelectAll.sptpl","")]
	[SPInsert("usp_InsertWCDurableMedicalEquipment")]
	[SPUpdate("usp_UpdateWCDurableMedicalEquipment")]
	[SPDelete("usp_DeleteWCDurableMedicalEquipment")]
	[SPLoad("usp_LoadWCDurableMedicalEquipment")]
	[TableMapping("WCDurableMedicalEquipment","durableMedicalEquipmentId")]
	public class WCDurableMedicalEquipment : BaseLookupWithNote
	{
		[NonSerialized]
		private WCDurableMedicalEquipmentCollection parentWCDurableMedicalEquipmentCollection;
		[ColumnMapping("DurableMedicalEquipmentId",(int)0)]
		private int durableMedicalEquipmentId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public WCDurableMedicalEquipment()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int DurableMedicalEquipmentId
		{
			get { return this.durableMedicalEquipmentId; }
			set { this.durableMedicalEquipmentId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent WCDurableMedicalEquipmentCollection that contains this element
		/// </summary>
		public WCDurableMedicalEquipmentCollection ParentWCDurableMedicalEquipmentCollection
		{
			get
			{
				return this.parentWCDurableMedicalEquipmentCollection;
			}
			set
			{
				this.parentWCDurableMedicalEquipmentCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int durableMedicalEquipmentId)
		{
			return base.Load(durableMedicalEquipmentId);
		}
	}

	/// <summary>
	/// Strongly typed collection of WCDurableMedicalEquipment objects
	/// </summary>
	[ElementType(typeof(WCDurableMedicalEquipment))]
	public class WCDurableMedicalEquipmentCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(WCDurableMedicalEquipment elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentWCDurableMedicalEquipmentCollection = this;
			else
				elem.ParentWCDurableMedicalEquipmentCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (WCDurableMedicalEquipment elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public WCDurableMedicalEquipment this[int index]
		{
			get
			{
				return (WCDurableMedicalEquipment)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((WCDurableMedicalEquipment)oldValue, false);
			SetParentOnElem((WCDurableMedicalEquipment)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllWCDurableMedicalEquipment", -1, this, false);
		}
	}
}
