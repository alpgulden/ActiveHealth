using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [UB92Source]
	/// </summary>
	[SPAutoGen("usp_GetUB92SourceByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllUB92Source","SelectAll.sptpl","")]
	[SPInsert("usp_InsertUB92Source")]
	[SPUpdate("usp_UpdateUB92Source")]
	[SPDelete("usp_DeleteUB92Source")]
	[SPLoad("usp_LoadUB92Source")]
	[TableMapping("UB92Source","uB92SourceID")]
	public class UB92Source : BaseLookupWithSubCode
	{
		[NonSerialized]
		private UB92SourceCollection parentUB92SourceCollection;
		[ColumnMapping("UB92SourceID",(int)0)]
		private int uB92SourceID;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("IsNewborn")]
		private bool isNewborn;
	
		public UB92Source()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int UB92SourceID
		{
			get { return this.uB92SourceID; }
			set { this.uB92SourceID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int uB92SourceID)
		{
			return base.Load(uB92SourceID);
		}

		/// <summary>
		/// Parent UB92SourceCollection that contains this element
		/// </summary>
		public UB92SourceCollection ParentUB92SourceCollection
		{
			get
			{
				return this.parentUB92SourceCollection;
			}
			set
			{
				this.parentUB92SourceCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IsNewborn
		{
			get { return this.isNewborn; }
			set { this.isNewborn = value; }
		}
		
		[FieldValuesMember("ValuesOf_IsNewborn")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@ISNEWBORN@")]
		public override int SubCodeID
		{
			get 
			{
				if(this.isNewborn)
					  return 1;
				  else
					  return 2;
			}
			set 
			{
				if(value==1)
					  this.isNewborn = true;
				  else
					  this.isNewborn = false; 
			}
		}

		public object[,] ValuesOf_IsNewborn
		{
			get
			{
				return new object[,] {{1,"Yes"},{2,"No"}};
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of UB92Source objects
	/// </summary>
	[ElementType(typeof(UB92Source))]
	public class UB92SourceCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(UB92Source elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentUB92SourceCollection = this;
			else
				elem.ParentUB92SourceCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (UB92Source elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public UB92Source this[int index]
		{
			get
			{
				return (UB92Source)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((UB92Source)oldValue, false);
			SetParentOnElem((UB92Source)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllUB92Source", -1, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadUB92SourceByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetUB92SourceByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared UB92SourceCollection which is cached in NSGlobal
		/// </summary>
		public static UB92SourceCollection ActiveUB92Sources
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				UB92SourceCollection col = (UB92SourceCollection)NSGlobal.EnsureCachedObject("ActiveUB92Sources", typeof(UB92SourceCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadUB92SourceByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
