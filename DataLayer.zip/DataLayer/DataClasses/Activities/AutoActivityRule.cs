using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [AutoActivityRule]
	/// </summary>
	[SPAutoGen("usp_GetAutoActivityRulesByRuleTypeId","SelectAllByGivenArgs.sptpl","ruleTypeId")]
	[SPAutoGen("usp_GetAllAutoActivityRules","SelectAll.sptpl","")]
	[SPInsert("usp_InsertAutoActivityRule")]
	[SPUpdate("usp_UpdateAutoActivityRule")]
	[SPDelete("usp_DeleteAutoActivityRule")]
	[SPLoad("usp_LoadAutoActivityRule")]
	[TableMapping("AutoActivityRule","ruleId")]
	public class AutoActivityRule : BaseAutoActivityRule
	{
		[NonSerialized]
		private AutoActivityRuleCollection parentAutoActivityRuleCollection;
		[ColumnMapping("RuleId",(int)0)]
		private int ruleId;
		[ColumnMapping("RuleTypeId",StereoType=DataStereoType.FK)]
		private int ruleTypeId;
		[ColumnMapping("NoteTypeId",StereoType=DataStereoType.FK)]
		private int noteTypeId;

		private int cboRuleTypeId;

		private AutoActivityRuleExceptionCollection autoActivityRuleExceptions;
		private AutoActivityInitializationValueCollection autoActivityInitializationValues;
	
		public AutoActivityRule()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public AutoActivityRule(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			this.Active=true;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int RuleId
		{
			get { return this.ruleId; }
			set { this.ruleId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Inserts Clone and create Values and Exceptions and Exceptions Values.
		/// </summary>
		public new void SaveClone()
		{
			try
			{
				this.Save();
				// save exceptions
				this.SaveAutoActivityRuleExceptions();
				this.LoadAutoActivityRuleExceptions(false);

				//save exception values
				foreach(AutoActivityRuleException item in this.AutoActivityRuleExceptions)
				{
					item.LoadAutoActivityInitializationValues(false);
					item.SaveAutoActivityInitializationValues();
				}

				// save rule values
				this.SaveAutoActivityInitializationValues();

			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}
	

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int ruleId)
		{
			return base.Load(ruleId);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Parent AutoActivityRuleCollection that contains this element
		/// </summary>
		public AutoActivityRuleCollection ParentAutoActivityRuleCollection
		{
			get
			{
				return this.parentAutoActivityRuleCollection;
			}
			set
			{
				this.parentAutoActivityRuleCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child AutoActivityRuleExceptions mapped to related rows of table AutoActivityRuleException where [RuleId] = [RuleId]
		/// </summary>
		[SPLoadChild("usp_LoadAutoActivityRuleAutoActivityRuleException", "ruleId")]
		public AutoActivityRuleExceptionCollection AutoActivityRuleExceptions
		{
			get { return this.autoActivityRuleExceptions; }
			set
			{
				this.autoActivityRuleExceptions = value;
				if (value != null)
					value.ParentAutoActivityRule = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AutoActivityRuleExceptions collection
		/// </summary>
		public void LoadAutoActivityRuleExceptions(bool forceReload)
		{
			this.autoActivityRuleExceptions = (AutoActivityRuleExceptionCollection)AutoActivityRuleExceptionCollection.LoadChildCollection("AutoActivityRuleExceptions", this, typeof(AutoActivityRuleExceptionCollection), autoActivityRuleExceptions, forceReload, null);
		}

		/// <summary>
		/// Saves the AutoActivityRuleExceptions collection
		/// </summary>
		public void SaveAutoActivityRuleExceptions()
		{
			AutoActivityRuleExceptionCollection.SaveChildCollection(this.autoActivityRuleExceptions, true);
		}

		/// <summary>
		/// Synchronizes the AutoActivityRuleExceptions collection
		/// </summary>
		public void SynchronizeAutoActivityRuleExceptions()
		{
			AutoActivityRuleExceptionCollection.SynchronizeChildCollection(this.autoActivityRuleExceptions, true);
		}

		/// <summary>
		/// Child AutoActivityInitializationValues mapped to related rows of table AutoActivityInitializationValues where [RuleId] = [RuleID]
		/// </summary>
		[SPLoadChild("usp_LoadAutoActivityRuleAutoActivityInitializationValues", "ruleID")]
		public override AutoActivityInitializationValueCollection AutoActivityInitializationValues
		{
			get { return this.autoActivityInitializationValues; }
			set
			{
				this.autoActivityInitializationValues = value;
				if (value != null)
					value.ParentAutoActivityRule = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AutoActivityInitializationValues collection
		/// </summary>
		public override void LoadAutoActivityInitializationValues(bool forceReload)
		{
			this.autoActivityInitializationValues = (AutoActivityInitializationValueCollection)AutoActivityInitializationValueCollection.LoadChildCollection("AutoActivityInitializationValues", this, typeof(AutoActivityInitializationValueCollection), autoActivityInitializationValues, forceReload, null);
		}

		/// <summary>
		/// Saves the AutoActivityInitializationValues collection
		/// </summary>
		public override void SaveAutoActivityInitializationValues()
		{
			AutoActivityInitializationValueCollection.SaveChildCollection(this.autoActivityInitializationValues, true);
		}

		[FieldValuesMember("LookupOf_RuleTypeId", "RuleTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CboRuleTypeId
		{
			get { return this.cboRuleTypeId; }
			set { this.cboRuleTypeId = value; }
		}

		[FieldValuesMember("LookupOf_RuleTypeId", "RuleTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int RuleTypeId
		{
			get { return this.ruleTypeId; }
			set { this.ruleTypeId = value; }
		}

		public AutoActivityRuleTypeCollection LookupOf_RuleTypeId
		{
			get
			{
				return AutoActivityRuleTypeCollection.ActiveAutoActivityRuleTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public string RuleTypeCode
		{
			get { return AutoActivityRuleTypeCollection.ActiveAutoActivityRuleTypes.Lookup_CodeByRuleTypeId(this.ruleTypeId); }
			set { this.ruleTypeId = AutoActivityRuleTypeCollection.ActiveAutoActivityRuleTypes.Lookup_RuleTypeIdByCode(value); }
		}

		public string RuleTypeCategory
		{
			get { return AutoActivityRuleTypeCollection.ActiveAutoActivityRuleTypes.Lookup_CategoryByRuleTypeId(this.ruleTypeId); }
		}

		public string GetRuleTypeCategory(int ruletypeid)
		{
			return AutoActivityRuleTypeCollection.ActiveAutoActivityRuleTypes.Lookup_CategoryByRuleTypeId(ruletypeid);
		}

		public AutoActivityRuleType RuleType
		{
			get { return AutoActivityRuleTypeCollection.ActiveAutoActivityRuleTypes.FindBy(this.ruleTypeId); }
		}

		[FieldValuesMember("LookupOf_NoteTypeId", "NoteTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int NoteTypeId
		{
			get { return this.noteTypeId; }
			set { this.noteTypeId = value; }
		}

		public NoteTypeCollection LookupOf_NoteTypeId
		{
			get
			{
				return NoteTypeCollection.ActiveNoteTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.StartNewLineInSection();
				writer.AddHeaderLabelandValueOnSameLine("Activity Rule", this.RuleId.ToString());
				writer.AddField(this,"Description");				
				writer.EndLineInSection();
			}
		}

		/// <summary>
		/// Create a copy of this rule.
		/// Copied subcomponents are:
		///		Exceptions, Values
		/// </summary>
		/// <returns></returns>
		public AutoActivityRule CreateCopyOfRule()
		{
			AutoActivityRule newAARule = new AutoActivityRule(true);
			this.CopyMappedMembersTo(newAARule, false, false, false);

			// copy rule exceptions
			// this function trigers another function in the exception to copy exception's values as well
			this.LoadAutoActivityRuleExceptions(false);
			newAARule.LoadAutoActivityRuleExceptions(false);
			this.AutoActivityRuleExceptions.CopyElementsTo(newAARule.AutoActivityRuleExceptions, false, true);		// deep copy, don't mark new

			// copy rule values
			this.LoadAutoActivityInitializationValues(false);
			newAARule.LoadAutoActivityInitializationValues(false);
			this.AutoActivityInitializationValues.CopyElementsTo(newAARule.AutoActivityInitializationValues, false, true);		// deep copy, don't mark new

			return newAARule;
		}
	}

	/// <summary>
	/// Strongly typed collection of AutoActivityRule objects
	/// </summary>
	[ElementType(typeof(AutoActivityRule))]
	public class AutoActivityRuleCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AutoActivityRule elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAutoActivityRuleCollection = this;
			else
				elem.ParentAutoActivityRuleCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AutoActivityRule elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AutoActivityRule this[int index]
		{
			get
			{
				return (AutoActivityRule)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AutoActivityRule)oldValue, false);
			SetParentOnElem((AutoActivityRule)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/*
		/// <summary>
		/// Load all matching rules for the current context.
		/// </summary>
		/// <param name="autoActivityManager"></param>
		/// <returns></returns>
		public int LoadRules(string ruleTypeCode, AutoActivityManager autoActivityManager)
		{
			this.Clear();
			autoActivityManager.PrepareRuleFilterVariables(ruleTypeCode);
			return SqlData.SPExecReadCol("usp_GetAutoActivityRulesByFilter", -1, this, 
				autoActivityManager, false);
			//return SqlData.SPExecReadCol("usp_GetAutoActivityRulesByFilter", maxRecords, this, false, new object[] { ruleTypeID, eventTypeID, referralTypeID, cmsTypeID, decisionTypeID, planID, planMgmtSvcTypeId, morgID, orgID, sorgID, lastName, zip, stateID, facilityFedTaxId, facilityNetworkStatusId, facilityLocationNetworkId, providerFedTaxId, providerNetworkStatusId, providerLocationNetworkId, referProviderFedTaxId, referProviderNetworkStatusId, referProviderLocationNetworkId, noteTypeId });
		}
		*/

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAutoActivityRulesByRuleTypeId(int maxRecords, int ruleTypeId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAutoActivityRulesByRuleTypeId", maxRecords, this, false, new object[] { ruleTypeId });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllAutoActivityRules(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllAutoActivityRules", maxRecords, this, false);
		}
	}
}

// 
// Auto Activities functionality allows the Active Advice system to create 
// and assign activities to teams or users automatically. For example, the 
// system may generate an activity each time an Event is created where the 
// patient last name begins with A to L, the Event Type is Hospitalization, 
// the Plan Management has Care Management as a purchased service, and the 
// User codes are within the ICD9 code range of 765.10 � 765.19 (pre term 
// baby codes). 
//
// The three main steps of the activity creation are:
// 
// *	Define the event that would trigger the process (Rule Type)
// *	Specify one or more rules and exceptions by providing values to predefined attributes 
// *	Define one or more activities and their attributes that will be generated
//
// Define the event that would trigger the process (Rule Type)