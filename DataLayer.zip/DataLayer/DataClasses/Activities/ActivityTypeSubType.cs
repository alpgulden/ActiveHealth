using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ActivityTypeSubType]
	/// </summary>
	[SPAutoGen("usp_GetActivityTypeSubTypeByActivitySubType","SelectAllByGivenArgs.sptpl","activitySubTypeId")]
	[SPAutoGen("usp_GetActivityTypeSubTypeByActivityType","SelectAllByGivenArgs.sptpl","activityTypeId")]
	[SPAutoGen("usp_GetAllActivityTypeSubType","SelectAll.sptpl","")]
	[SPInsert("usp_InsertActivityTypeSubType")]
	[SPUpdate("usp_UpdateActivityTypeSubType")]
	[SPDelete("usp_DeleteActivityTypeSubType")]
	[SPLoad("usp_LoadActivityTypeSubType")]
	[TableMapping("ActivityTypeSubType","activityTypeSubTypeId")]
	public class ActivityTypeSubType : BaseCodeBracket
	{
		[NonSerialized]
		private ActivityTypeSubTypeCollection parentActivityTypeSubTypeCollection;
		[ColumnMapping("ActivityTypeSubTypeId",(int)0)]
		private int activityTypeSubTypeId;
		[ColumnMapping("ActivityTypeId",StereoType=DataStereoType.FK)]
		private int activityTypeId;
		[ColumnMapping("ActivitySubTypeId",StereoType=DataStereoType.FK)]
		private int activitySubTypeId;

		private ActivityType	parentActivityType;
		private ActivitySubType parentActivitySubType;
	
		public ActivityTypeSubType()
		{		
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ActivityTypeSubTypeId
		{
			get { return this.activityTypeSubTypeId; }
			set { this.activityTypeSubTypeId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ActivityTypeId
		{
			get { return this.activityTypeId; }
			set { this.activityTypeId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ActivitySubTypeId
		{
			get { return this.activitySubTypeId; }
			set { this.activitySubTypeId = value; }
		}

		[FieldDescription("@ACTIVITYTYPEID@")]
		public override int CodeTypeID
		{
			get { return this.activityTypeId; }
			set { this.activityTypeId = value; }
		}

		[FieldDescription("@ACTIVITYSUBTYPEID@")]
		public override int LinkedCodeTypeID
		{
			get { return this.activitySubTypeId; }
			set { this.activitySubTypeId = value; }
		}

		[FieldDescription("@ACTIVITYTYPECODE@")]
		public override string Code1
		{
			get 
			{ 
				if(this.ParentActivityType!=null)
					return this.parentActivityType.Code;
				  else
					  return null;
			}
		}

		[FieldDescription("@ACTIVITYSUBTYPECODE@")]
		public override string Code2
		{
			get 
			{
				if(this.ParentActivitySubType!=null)
					  return this.parentActivitySubType.Code;
				else
					return null;
			}			
		}
		[FieldDescription("@ACTIVITYTYPEDESCRIPTION@")]
		public override string Description1
		{
			get 
			{
				if(this.ParentActivityType!=null)
					  return this.parentActivityType.Description;
				else
					return null;
			}			
		}

		[FieldDescription("@ACTIVITYSUBTYPEDESCRIPTION@")]
		public override string Description2
		{
			get 
			{
				if(this.ParentActivitySubType!=null)
					return this.parentActivitySubType.Description;
				else
					return null;
			}			
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}			
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int activityTypeSubTypeId)
		{
			return base.Load(activityTypeSubTypeId);
		}

		/// <summary>
		/// Parent ActivityTypeSubTypeCollection that contains this element
		/// </summary>
		public ActivityTypeSubTypeCollection ParentActivityTypeSubTypeCollection
		{
			get
			{
				return this.parentActivityTypeSubTypeCollection;
			}
			set
			{
				this.parentActivityTypeSubTypeCollection = value; // parent is set when added to a collection
			}
		}


		public ActivityType ParentActivityType
		{
			get 
			{ 
				if (this.parentActivityType == null)
					this.parentActivityType = GetActivityType();
				return this.parentActivityType;
			}
		}

		public ActivityType GetActivityType()
		{
			if (this.activityTypeId == 0)
				return null;
			else
			{
				ActivityType a = new ActivityType();
				if (a.Load(this.activityTypeId))
					return a;
				else
					return null;
			}
		}


		public ActivitySubType ParentActivitySubType
		{
			get 
			{ 
				if (this.parentActivitySubType == null)
					this.parentActivitySubType= GetActivitySubType();
				return this.parentActivitySubType;
			}
		}

		public ActivitySubType GetActivitySubType()
		{
			if (this.activitySubTypeId == 0)
				return null;
			else
			{
				ActivitySubType a = new ActivitySubType();
				if (a.Load(this.activitySubTypeId))
					return a;
				else
					return null;
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ActivityTypeSubType objects
	/// </summary>
	[ElementType(typeof(ActivityTypeSubType))]
	public class ActivityTypeSubTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ActivityTypeId_ActivitySubTypeId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ActivityTypeSubType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentActivityTypeSubTypeCollection = this;
			else
				elem.ParentActivityTypeSubTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ActivityTypeSubType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ActivityTypeSubType this[int index]
		{
			get
			{
				return (ActivityTypeSubType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ActivityTypeSubType)oldValue, false);
			SetParentOnElem((ActivityTypeSubType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllActivityTypeSubType(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllActivityTypeSubType", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActivityTypeSubTypeByActivityType(int maxRecords, int activityTypeId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActivityTypeSubTypeByActivityType", maxRecords, this, false, new object[] { activityTypeId });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActivityTypeSubTypeByActivitySubType(int maxRecords, int activitySubTypeId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActivityTypeSubTypeByActivitySubType", maxRecords, this, false, new object[] { activitySubTypeId });
		}

		/// <summary>
		/// Parent ActivityType that contains this collection
		/// </summary>
		public ActivityType ParentActivityType
		{
			get { return this.ParentDataObject as ActivityType; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ActivityType */ }
		}

		/// <summary>
		/// Parent ActivitySubType that contains this collection
		/// </summary>
		public ActivitySubType ParentActivitySubType
		{
			get { return this.ParentDataObject as ActivitySubType; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ActivitySubType */ }
		}

		/// <summary>
		/// Hashtable based index on activityTypeId, activitySubTypeId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ActivityTypeId_ActivitySubTypeId
		{
			get
			{
				if (this.indexBy_ActivityTypeId_ActivitySubTypeId == null)
					this.indexBy_ActivityTypeId_ActivitySubTypeId = new CollectionIndexer(this, new string[] { "activityTypeId", "activitySubTypeId" }, true);
				return this.indexBy_ActivityTypeId_ActivitySubTypeId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on activityTypeId, activitySubTypeId fields returns the object.  Uses the IndexBy_ActivityTypeId_ActivitySubTypeId indexer.
		/// </summary>
		public ActivityTypeSubType FindBy(int activityTypeId, int activitySubTypeId)
		{
			IndexBy_ActivityTypeId_ActivitySubTypeId.Rebuild();
			return (ActivityTypeSubType)this.IndexBy_ActivityTypeId_ActivitySubTypeId.GetObject(activityTypeId, activitySubTypeId);
		}

		public override bool FindBaseCodeType(int code1,int code2) 
		{
			if(null== this.FindBy(code1,code2))
				return false;
			else
				return true;
		}

		public void MyMarkDel(ActivityTypeSubType obj)
		{			
			obj.MarkDel();
			IndexBy_ActivityTypeId_ActivitySubTypeId.Rebuild();
		}
	
		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public override void Save()
		{
			this.SaveElements();		
		}

	}
}

