using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	public class AutoActivityRuleTypeCategory
	{
		public const string EVNT = "EVNT";		// Event
		public const string REF = "REF";		// Referral
		public const string CMS = "CMS";		// CMS
		public const string ACT = "ACT";		// Activity
		public const string NOTE = "NOTE";		// Note
		public const string LTR = "LTR";		// Letter
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [AutoActivityRuleType]
	/// </summary>
	[SPLoad("usp_LoadAutoActivityRuleType")]
	[SPAutoGen("usp_GetAutoActivityRuleTypeByActive","CodeTableLoader.sptpl","active")]
	[TableMapping("AutoActivityRuleType","ruleTypeId")]
	public class AutoActivityRuleType : BaseLookupWithNote
	{
		#region Auto Activity Rule Types used programmatically

		public const string ES1 = "ES1";		// Event Initial Save
		public const string RS1 = "RS1";		// Referral Initial Save
		public const string CM1 = "CM1";		// Clinical Management Service - Initial save
		public const string ER2 = "ER2";		// Physician Review for Event - Initial save
		public const string ER5 = "ER5";		// Physician Review for Referral - Initial save
		public const string ER3 = "ER3";		// Closing Event
		public const string ER4 = "ER4";		// Closing Event with Open Activities
		public const string ED1 = "ED1";		// Setting Event Decision Type
		public const string RD1 = "RD1";		// Setting Referral Decision Type
		public const string AC1 = "AC1";		// Completing Activity
		public const string AC2 = "AC2";		// Completing Activity for Event
		public const string AC3 = "AC3";		// Completing Activity for Referral
		public const string CD1 = "CD1";		// Coding Event Diagnosis
		public const string CP1 = "CP1";		// Coding Event Procedure
		public const string CD2 = "CD2";		// Coding Referral Diagnosis
		public const string CP2 = "CP2";		// Coding Referral Procedure
		public const string NT1 = "NT1";		// Note Initial Save
		public const string SL1 = "SL1";		// Scoring Load Run
		public const string IL1 = "IL1";		// Intro Letter 1 Generated
		public const string IL2 = "IL2";		// Intro Letter 2 Generated
		
		public const string PT1 = "PT1";		// Patient Initial Save
		public const string PR1 = "PR1";		// Problem Initial Save
		public const string BP1 = "BP1";		// Baby Initial Save
	
		#endregion

		[NonSerialized]
		private AutoActivityRuleTypeCollection parentAutoActivityRuleTypeCollection;
		[ColumnMapping("RuleTypeId",(int)0)]
		private int ruleTypeId;
		[ColumnMapping("Category")]
		private string category;
		[ColumnMapping("EndDateValid")]
		private bool endDateValid;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public AutoActivityRuleType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int RuleTypeId
		{
			get { return this.ruleTypeId; }
			set { this.ruleTypeId = value; }
		}

		/// <summary>
		/// Parent AutoActivityRuleTypeCollection that contains this element
		/// </summary>
		public AutoActivityRuleTypeCollection ParentAutoActivityRuleTypeCollection
		{
			get
			{
				return this.parentAutoActivityRuleTypeCollection;
			}
			set
			{
				this.parentAutoActivityRuleTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string Category
		{
			get { return this.category; }
			set { this.category = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool EndDateValid
		{
			get { return this.endDateValid; }
			set { this.endDateValid = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int ruleTypeId)
		{
			return base.Load(ruleTypeId);
		}

	}

	/// <summary>
	/// Strongly typed collection of AutoActivityRuleType objects
	/// </summary>
	[ElementType(typeof(AutoActivityRuleType))]
	public class AutoActivityRuleTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		[NonSerialized]
		private CollectionIndexer indexBy_RuleTypeId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AutoActivityRuleType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAutoActivityRuleTypeCollection = this;
			else
				elem.ParentAutoActivityRuleTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AutoActivityRuleType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AutoActivityRuleType this[int index]
		{
			get
			{
				return (AutoActivityRuleType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AutoActivityRuleType)oldValue, false);
			SetParentOnElem((AutoActivityRuleType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAutoActivityRuleTypeByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAutoActivityRuleTypeByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared AutoActivityRuleTypeCollection which is cached in NSGlobal
		/// </summary>
		public static AutoActivityRuleTypeCollection ActiveAutoActivityRuleTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				AutoActivityRuleTypeCollection col = (AutoActivityRuleTypeCollection)NSGlobal.EnsureCachedObject("ActiveAutoActivityRuleTypes", typeof(AutoActivityRuleTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAutoActivityRuleTypeByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on ruleTypeId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_RuleTypeId
		{
			get
			{
				if (this.indexBy_RuleTypeId == null)
					this.indexBy_RuleTypeId = new CollectionIndexer(this, new string[] { "ruleTypeId" }, true);
				return this.indexBy_RuleTypeId;
			}
			
		}

		/// <summary>
		/// Looks up by ruleTypeId and returns Code value.  Uses the IndexBy_RuleTypeId indexer.
		/// </summary>
		public string Lookup_CodeByRuleTypeId(int ruleTypeId)
		{
			return this.IndexBy_RuleTypeId.LookupStringMember("Code", ruleTypeId);
		}

		/// <summary>
		/// Looks up by ruleTypeId and returns Category value.  Uses the IndexBy_RuleTypeId indexer.
		/// </summary>
		public string Lookup_CategoryByRuleTypeId(int ruleTypeId)
		{
			return this.IndexBy_RuleTypeId.LookupStringMember("Category", ruleTypeId);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns RuleTypeId value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_RuleTypeIdByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("RuleTypeId", code);
		}

		/// <summary>
		/// Hashtable based search on ruleTypeId fields returns the object.  Uses the IndexBy_RuleTypeId indexer.
		/// </summary>
		public AutoActivityRuleType FindBy(int ruleTypeId)
		{
			return (AutoActivityRuleType)this.IndexBy_RuleTypeId.GetObject(ruleTypeId);
		}
	}
}
