using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [AutoActivityRuleException]
	/// </summary>
	[SPAutoGen("usp_GetAllAutoActivityRuleExceptions","SelectAll.sptpl","")]
	[SPInsert("usp_InsertAutoActivityRuleException")]
	[SPUpdate("usp_UpdateAutoActivityRuleException")]
	[SPDelete("usp_DeleteAutoActivityRuleException")]
	[SPLoad("usp_LoadAutoActivityRuleException")]
	[TableMapping("AutoActivityRuleException","exceptionId")]
	public class AutoActivityRuleException : BaseAutoActivityRule
	{
		[NonSerialized]
		private AutoActivityRuleExceptionCollection parentAutoActivityRuleExceptionCollection;
		[ColumnMapping("ExceptionId",(int)0)]
		private int exceptionId;
		[ColumnMapping("RuleId",StereoType=DataStereoType.FK)]
		private int ruleId;
		[ColumnMapping("GenerateActivity")]
		private bool generateActivity;
		
		private string ruleType;

		private AutoActivityInitializationValueCollection autoActivityInitializationValues;
	
		public AutoActivityRuleException()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public AutoActivityRuleException(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			this.Active=true;
		}

		[FieldDescription("@RULETYPE@")]
		public string RuleType
		{
			get{ return this.ruleType;}
			set{ this.ruleType =value;}
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ExceptionId
		{
			get { return this.exceptionId; }
			set { this.exceptionId = value; }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int exceptionId)
		{
			return base.Load(exceptionId);
		}

		/// <summary>
		/// Parent AutoActivityRuleExceptionCollection that contains this element
		/// </summary>
		public AutoActivityRuleExceptionCollection ParentAutoActivityRuleExceptionCollection
		{
			get
			{
				return this.parentAutoActivityRuleExceptionCollection;
			}
			set
			{
				this.parentAutoActivityRuleExceptionCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child AutoActivityInitializationValues mapped to related rows of table AutoActivityInitializationValues where [ExceptionId] = [ExceptionID]
		/// </summary>
		[SPLoadChild("usp_LoadAutoActivityRuleExceptionAutoActivityInitializationValues", "exceptionID")]
		public override AutoActivityInitializationValueCollection AutoActivityInitializationValues
		{
			get { return this.autoActivityInitializationValues; }
			set
			{
				this.autoActivityInitializationValues = value;
				if (value != null)
					value.ParentAutoActivityRuleException = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AutoActivityInitializationValues collection
		/// </summary>
		public override void LoadAutoActivityInitializationValues(bool forceReload)
		{
			this.autoActivityInitializationValues = (AutoActivityInitializationValueCollection)AutoActivityInitializationValueCollection.LoadChildCollection("AutoActivityInitializationValues", this, typeof(AutoActivityInitializationValueCollection), autoActivityInitializationValues, forceReload, null);
		}

		/// <summary>
		/// Saves the AutoActivityInitializationValues collection
		/// </summary>
		public override void SaveAutoActivityInitializationValues()
		{
			AutoActivityInitializationValueCollection.SaveChildCollection(this.autoActivityInitializationValues, true);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int RuleId
		{
			get { return this.ruleId; }
			set { this.ruleId = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool GenerateActivity
		{
			get { return this.generateActivity; }
			set { this.generateActivity = value; }
		}
		
		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.StartNewLineInSection();
				writer.AddHeaderLabelandValueOnSameLine("Exception", this.ExceptionId.ToString());
				writer.AddField(this,"Description");
				writer.EndLineInSection();
			}
		}

		public override BaseDataClass Clone(bool markNew)
		{
			AutoActivityRuleException newAARuleException = (AutoActivityRuleException)base.Clone(markNew);
			this.LoadAutoActivityInitializationValues(true);
			newAARuleException.LoadAutoActivityInitializationValues(true);
			this.AutoActivityInitializationValues.CopyElementsTo(newAARuleException.AutoActivityInitializationValues, false, true);		// deep copy, don't mark new
			return newAARuleException;
		}

	}

	/// <summary>
	/// Strongly typed collection of AutoActivityRuleException objects
	/// </summary>
	[ElementType(typeof(AutoActivityRuleException))]
	public class AutoActivityRuleExceptionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_RuleId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AutoActivityRuleException elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAutoActivityRuleExceptionCollection = this;
			else
				elem.ParentAutoActivityRuleExceptionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AutoActivityRuleException elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AutoActivityRuleException this[int index]
		{
			get
			{
				return (AutoActivityRuleException)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AutoActivityRuleException)oldValue, false);
			SetParentOnElem((AutoActivityRuleException)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Hashtable based index on ruleId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_RuleId
		{
			get
			{
				if (this.indexBy_RuleId == null)
					this.indexBy_RuleId = new CollectionIndexer(this, new string[] { "ruleId" }, true);
				return this.indexBy_RuleId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on ruleId fields returns the object.  Uses the IndexBy_RuleId indexer.
		/// </summary>
		public AutoActivityRuleException FindBy(int ruleId)
		{
			return (AutoActivityRuleException)this.IndexBy_RuleId.GetObject(ruleId);
		}

		/// <summary>
		/// Parent AutoActivityRule that contains this collection
		/// </summary>
		public AutoActivityRule ParentAutoActivityRule
		{
			get { return this.ParentDataObject as AutoActivityRule; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AutoActivityRule */ }
		}

		/*
		/// <summary>
		/// Load all matching exceptions of given rule for the current context.
		/// </summary>
		/// <param name="rule"></param>
		/// <param name="autoActivityManager"></param>
		/// <returns></returns>
		public int LoadExceptions(string ruleTypeCode, AutoActivityRule rule, AutoActivityManager autoActivityManager)
		{
			this.Clear();
			autoActivityManager.PrepareRuleFilterVariables(ruleTypeCode);
			return SqlData.SPExecReadCol("usp_GetAutoActivityRuleExceptionsByFilter", -1, this, 
				autoActivityManager, false,
				new string[] { "ruleID" },
				new object[] { rule.RuleId } );
			//return SqlData.SPExecReadCol("usp_GetAutoActivityRulesByFilter", maxRecords, this, false, new object[] { ruleTypeID, eventTypeID, referralTypeID, cmsTypeID, decisionTypeID, planID, planMgmtSvcTypeId, morgID, orgID, sorgID, lastName, zip, stateID, facilityFedTaxId, facilityNetworkStatusId, facilityLocationNetworkId, providerFedTaxId, providerNetworkStatusId, providerLocationNetworkId, referProviderFedTaxId, referProviderNetworkStatusId, referProviderLocationNetworkId, noteTypeId });
		}*/

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllAutoActivityRuleExceptions(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllAutoActivityRuleExceptions", maxRecords, this, false);
		}

	}
}
