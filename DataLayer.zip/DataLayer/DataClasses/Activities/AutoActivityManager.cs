using System;
using System.Data.SqlClient;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Collections;

namespace ActiveAdvice.DataLayer
{
	#region AutoActivityManager class

	/// <summary>
	/// Utility class that manages automatic creation of activities
	/// based on auto-activity rules.
	/// </summary>
	public class AutoActivityManager
	{
		public const int MaxAutoActivityRecursionDepth = 5;

		// The rule evaluation will be enabled but the autoactivity generation will be disabled for now.
		// These values are read from web.config.
		public static bool AutoActivityEvaluateEnabled = false;		// The global flag that enables/disables the auto-activity evaluation.
		public static bool AutoActivityGenerateEnabled = false;	// The global flag that enables/disables the auto-activity generation.
		public static bool AutoActivityLogDump = false;			// The global flag that enables/disables the auto-activity log dumping on the page.

		private SqlTransactionWithEvents transaction;
		private Patient patient;
		private PatientCoverage patientCoverage;
		private Problem problem;
		private BaseForEventCMSReferral erc;
		private Event eventObj;
		private Referral referral;
		private CMS cms;
		private Activity activity;
		private Note note;
		private DxPxSelect dxPx;
		private PRRequest pRRequest;

		private ArrayList messageLog = new ArrayList();				// track of allt the steps performed for debugging purposes.  displayed only in debug mode.
		private ArrayList userNotifications = new ArrayList();		// all user notifications that must be displayed always (even in release mode).

		/// <summary>
		/// This is set by AutoActivityManager to prevent recursive autoactivity rule evaluation
		///   0: not automatically created
		///   1: autoamatically created by a auto-activity rule of 1st level
		///   2: autoamatically created by a auto-activity rule of 2nd level
		///   ...
		/// </summary>
		public int AutoActivityCreationLevel
		{
			get 
			{ 
				if (this.activity == null)
					return 0;
				return this.activity.AutoActivityCreationLevel; 
			}
		}

		public AutoActivityManager()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public AutoActivityManager(Patient patient, PatientCoverage patientCoverage, Problem problem, BaseForEventCMSReferral erc)
		{
			this.patient = patient;
			this.patientCoverage = patientCoverage;
			this.problem = problem;
			this.erc = erc;
			this.eventObj = erc as Event;
			this.referral = erc as Referral;
			this.cms = erc as CMS;
		}

		public AutoActivityManager(Patient patient, PatientCoverage patientCoverage, Activity activity)
		{
			this.patient = patient;
			this.patientCoverage = patientCoverage;
			this.activity = activity;

			if (activity.EventID != 0)
				this.erc = activity.GetEvent();
			else if (activity.ReferralID != 0)
				this.erc = activity.GetReferral();
			else if (activity.CMSID != 0)
				this.erc = activity.GetCMS();

			this.eventObj = erc as Event;
			this.referral = erc as Referral;
			this.cms = erc as CMS;
		}

		public AutoActivityManager(Patient patient, PatientCoverage selectedPatientCoverage, Note note)
		{
			this.patient = patient;
			this.note = note;

			if (note.ProblemId != 0)
				this.problem = note.GetProblem();

			if (note.EventID != 0)
				this.erc = note.GetEvent();
			else if (note.ReferralId != 0)
				this.erc = note.GetReferral();
			else if (note.CMSId != 0)
				this.erc = note.GetCMS();

			this.eventObj = erc as Event;
			this.referral = erc as Referral;
			this.cms = erc as CMS;

			if (this.patientCoverage == null)
			{
				if (erc != null)
					this.patientCoverage = erc.PatientSubscriberLog.PatientCoverage;
				else if (problem != null)
					this.patientCoverage = this.problem.PatientSubscriberLog.PatientCoverage;
			}
			else
				this.patientCoverage = selectedPatientCoverage;		// in other context just use the given coverage
		}

		public AutoActivityManager(Patient patient, PatientCoverage patientCoverage)
		{
			this.patient = patient;
			this.patientCoverage = patientCoverage;
		}

		public SqlTransactionWithEvents Transaction
		{
			get { return this.transaction; }
			set { this.transaction = value; }
		}

		public ArrayList MessageLog
		{
			get { return this.messageLog; }
		}

		public void AppendMessageLog(ArrayList messageLog)
		{
			this.messageLog.AddRange(messageLog);
		}

		public ArrayList UserNotifications
		{
			get { return this.userNotifications; }
		}

		public void AddToMessageLog(string msg)
		{
			this.messageLog.Add(msg);
			Debug.WriteLine(msg);
		}

		public void AddUserNotification(string msg)
		{
			this.userNotifications.Add(msg);
			Debug.WriteLine("USER NOTIFICATION: " + msg);
		}

		public void AddToMessageLog(string msg, params object[] parameters)
		{
			AddToMessageLog(String.Format(msg, parameters));
		}

		public void AddUserNotification(string msg, params object[] parameters)
		{
			AddUserNotification(String.Format(msg, parameters));
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "}\r\n";

			for (int i = 0; i < this.messageLog.Count; i++)
			{
				s += this.messageLog[i].ToString() + "\r\n";
			}
			
			return s;
		}

		/// <summary>
		/// Find related rules for the current context and execute them.
		/// </summary>
		/// <param name="transaction"></param>
		public void Execute(string ruleTypeCode, SqlTransactionWithEvents transaction)
		{
			if (!AutoActivityEvaluateEnabled)
			{
				AddToMessageLog("AutoActivity evaluation disabled. Skipping rules for {0}", ruleTypeCode );
				return;
			}

			int ruleTypeID = AutoActivityRuleTypeCollection.ActiveAutoActivityRuleTypes.Lookup_RuleTypeIdByCode(ruleTypeCode);
			string ruleTypeCategory = AutoActivityRuleTypeCollection.ActiveAutoActivityRuleTypes.Lookup_CategoryByRuleTypeId(ruleTypeID);

			// BR01.2.19	If an auto activity rule has network status as a criteria but not 
			// network ID then the application shall check to see if any of the provider�s or 
			// facility�s networks are In Network to determine if the rule or exception is met.  NOT IMPL

			this.Transaction = transaction;

			AddToMessageLog("Evaluating AutoActivity rules for {0}", ruleTypeCode );

			MatchingRuleCollection rules = new MatchingRuleCollection();
			rules.SqlData.Transaction = transaction;
			// pass paramater values relevant to the context
			if (dxPx != null)			// dx/px coding context
			{
				if (eventObj != null)
					rules.LoadMatchingRules(ruleTypeCode, patient.PatientId, eventObj.PrimaryProblemID, eventObj.EventID, 0, 0, 0, 0, dxPx.CodeType, dxPx.CodeValue); 
				else if (referral != null)
					rules.LoadMatchingRules(ruleTypeCode, patient.PatientId, referral.PrimaryProblemID, 0, referral.ReferralID, 0, 0, 0, dxPx.CodeType, dxPx.CodeValue); 
			}
			else if (activity != null)	// activity context
				rules.LoadMatchingRules(ruleTypeCode, patient.PatientId, activity.ProblemId, activity.EventID, activity.ReferralID, activity.CMSID, 0, activity.ActivityID, null, null); 
			else if (note != null)		// note context
				rules.LoadMatchingRules(ruleTypeCode, patient.PatientId, note.ProblemId, note.EventID, note.ReferralId, note.CMSId, note.NoteID, 0, null, null);
			else	// other contexts
				rules.LoadMatchingRules(ruleTypeCode, patient, problem, eventObj, referral, cms, note, activity); 

			AddToMessageLog("usp_GetAutoActivityRulesByFilter returned {0} rules/exceptions", rules.Count );

			// Iterate on all the rules and exceptions and generate activity

			MatchingRule rule = null;
			MatchingRule previousRule = null;		// helps find the exceptions of a rule

			// BR01.2.29	When an action occurs that results in the evaluation of auto 
			// activity rules and a matching rule is found, the application must check for 
			// matching exceptions. If an exception is found then the activity defined for 
			// the rule will not be generated. A matching exception may or may not result 
			// in an activity being generated. If an exception is set up to generate an 
			// activity, the application must require activity default values.

			// If there's an exception for a rule, don't generate activity for the rule itself.
			for (int i = 0; i < rules.Count; i++)
			{
				rule = rules[i];	
				if (rule.IsException)		// if this is exception and the previous item was a rule, it was the parent rule.  don't generate activity for it.
					if (previousRule != null && previousRule.IsRule)
					{
						previousRule.GenerateActivity = false;
						AddToMessageLog("Matching exceptions found for {0}.  The rule will not generate activity. (BR01.2.10)", previousRule.DebugDescription);
					}
			}

			// Generate all the necessary activities.
			for (int i = 0; i < rules.Count; i++)
			{
				rule = rules[i];
				if (rule.GenerateActivity)
				{
					rule.SqlData.Transaction = transaction;
					CreateActivities(rule, ruleTypeCode, ruleTypeCategory);
				}
			}
		}

		/// <summary>
		/// Create activities using the related initialization values.
		/// </summary>
		/// <param name="brule"></param>
		private void CreateActivities(MatchingRule matchingRule, string ruleTypeCode, string ruleTypeCategory)
		{
			int lastDecisionTypeID = matchingRule.LastDecisionTypeID;
			DateTime lastDecisionEndDate = matchingRule.LastDecisionEndDate;
			BaseAutoActivityRule brule = matchingRule.GetRuleOrException();

			if (brule == null)
			{
				AddToMessageLog(String.Format( "AutoActivity rule/exception definition not found for {0}.", matchingRule.DebugDescription ));
				return;
			}

			if (!AutoActivityGenerateEnabled)
			{
				AddToMessageLog(String.Format( "AutoActivity generation disabled.  Activity for {0} was NOT created.", brule.DebugDescription ));
				return;
			}

			// BR01.2.11	The System shall not generate an Activity when a Coding 
			// Diagnosis or Coding Procedure rule is met if a CMS case is already open 
			// for the patient.
			if (ruleTypeCode == AutoActivityRuleType.CD1 || ruleTypeCode == AutoActivityRuleType.CP1 ||
				ruleTypeCode == AutoActivityRuleType.CD2 || ruleTypeCode == AutoActivityRuleType.CP2)
			{
				if (patient.HasPatientOpenCMSs(problem))		// if problem is given, check all the CMS cases matching primary problem ID
				{
					AddToMessageLog(String.Format("{0} found open CMSs for the patient.  BR01.2.11 prevents activity creation under this condition.", matchingRule.DebugDescription));
					return;
				}
			}

			AddToMessageLog(String.Format( "Creating activities for {0}", brule.DebugDescription ));

			brule.LoadAutoActivityInitializationValues(false);

			if (brule.AutoActivityInitializationValues.Count == 0)
				AddToMessageLog(String.Format("No autoactivity initialization values were found."));

			for (int i = 0; i < brule.AutoActivityInitializationValues.Count; i++)
			{
				AutoActivityInitializationValue init = brule.AutoActivityInitializationValues[i];
				if (!init.Active)
				{	// Initialization value is Inactive
					AddToMessageLog("Initialization value record {0} is inactive.  Activity not created.", init.AutoActivityInitializationID);
				}
				else
				{	// Initialization value is Active
					Activity act = new Activity(patient, patientCoverage, this.transaction);
					if (init.ActivityTypeID != 0)
						act.ActivityTypeID = init.ActivityTypeID;

					if (init.AssignedUserType != null)
					{
						// AssignedUser and team comes from given context entity
						act.AssignedUserID = AASecurityHelper.GetUserId;
						switch (init.AssignedUserType)
						{
							case AssignedUserTypeConstants.Event:
								if (this.eventObj != null)
								{
									act.AssignedUserID = this.eventObj.AssignedUserID;
									act.AssignedTeamID = this.eventObj.AssignedTeamID;
								}
								break;
							case AssignedUserTypeConstants.Referral:
								if (this.referral != null)
								{
									act.AssignedUserID = this.referral.AssignedToUser;
									act.AssignedTeamID = this.referral.AssignedToTeam;
								}
								break;
							case AssignedUserTypeConstants.CMS:
								if (this.cms != null)
								{
									act.AssignedUserID = this.cms.LatestCMSStatusHistory.AssignedUserId;
									act.AssignedTeamID = this.cms.LatestCMSStatusHistory.AssignedTeamId;
								}
								break;
							default:
								AddToMessageLog("Initialization value record {0} has an invalid AssignedUserType={1}. Assigning current user.", init.AutoActivityInitializationID, init.AssignedUserType);
								break;
						}
					}
					// FORK 1.0
					else if (init.AssignedUserID != 0 || init.AssignedTeamID != 0)
					{
						// Use the given userID and teamID directly
						act.AssignedUserID = init.AssignedUserID;
						act.AssignedTeamID = init.AssignedTeamID;
					}
					// END FORK 1.0
					else	// Use the userID from the currently logged-in user
						act.AssignedUserID = AASecurityHelper.GetUserId;		// BR01.2.28
						
					if (init.CompletionID != 0)
						act.ActivityCompletionID = init.CompletionID;
					DateTime dueDate = DateTime.Today;

					if (init.DateSource == AutoActivityInitDateSource.SERV)
					{
						if (erc != null)
							dueDate = erc.ERCServiceDate;
					}
					else if (init.DateSource == AutoActivityInitDateSource.END)
					{
						// BR01.2.16	If the due date type (in activity default values) 
						// is equal to End Date and there are multiple decisions, the application 
						// shall use the end date from the most recent decision. If the most 
						// recent decision does not have an end date, the application must use 
						// the current date for the activity due date.

						// BR01.2.14	When evaluating event rules and exceptions, 
						// the application must use the decision type from the event�s most 
						// recent clinical review decision. The most recent decision is the 
						// one that was added to the database last. Event rule types are 
						// ones with �Event� in the name.
						// BR01.2.15	When evaluating referral rules and exceptions, 
						// the application must use the decision type from the referral�s most 
						// recent decision. The most recent decision is the one that was added 
						// to the database last. Referral rule types are ones with �Referral� in the name.
						if (lastDecisionEndDate != DateTime.MinValue)	// only if there is an end-date
							dueDate = lastDecisionEndDate;		// last decision returned by the rule-evaluation
					}

					if (eventObj != null)
						act.EventID = eventObj.EventID;
					if (referral != null)
						act.ReferralID = referral.ReferralID;
					if (cms != null)
						act.CMSID = cms.CMSID;

					dueDate = dueDate.AddDays(init.DateOffset);
					act.DueDate = dueDate;
					if (init.Description != null)
						act.ActivityDescription = init.Description;
					if (init.PriorityID != 0)
						act.ActivityPriority = init.PriorityID;

					// BR01.2.12	The System shall notify the User when an Activity cannot 
					// be generated because the Management Service for the plan is not active 
					// on the due date.
					//	-- Which management service for the plan is this rule talking about???
					//	A plan may have multiple.  We now check all management service items 
					//  of the patientCoverage.Plan that match the service type.
					
					if (brule.PlanMgmtSvcTypeId != 0 && ruleTypeCategory != AutoActivityRuleTypeCategory.NOTE &&
						ruleTypeCategory != AutoActivityRuleTypeCategory.LTR)		// don't execute this rule in the Note and Letter contexts (deduced from maintenance UI).
					{
						Plan pl = new Plan();
						pl.PlanId = brule.PlanId;

						if (pl.PlanId == 0)	// if the rule was not attached to a plan, use the coverage in the current context
						{
							if (this.patientCoverage != null)
							{
								pl.PlanId = this.patientCoverage.PlanID;
								AddToMessageLog("Checking managements services of plan ID={0} for the patient coverage.", pl.PlanId);
							}
						}
						else
							AddToMessageLog("Checking managements services of plan ID={0} specified in the rule.", pl.PlanId);

						if (!pl.HasPlanActiveManagementServiceItems(brule.PlanMgmtSvcTypeId, dueDate))
						{
							// Create a dummy plan object with the plan id to query the active management service items on the due date.
							
							// No active management service items on the due date
							// Notify the user.
							this.AddUserNotification("Activity for {0} was not created because no active management service was found on the due date {1}.", brule.UserFriendlyDescription, dueDate);
							continue;	// skip activity generation in this case.
						}
					}

					act.SqlData.Transaction = this.transaction;
					// We're using the current patient coverage context to save the activity.  Not sure about this..
					act.AutoActivityCreationLevel = this.AutoActivityCreationLevel + 1;	// Pass the next autoactivity creation level.  If this is not already in a automatic activity creation context, this will be 1.
					act.Save(patientCoverage);
					AddToMessageLog("Activity {0} automatically created.", act.ActivityID);
					if (act.AutoActivityManager != null)
						this.AppendMessageLog(act.AutoActivityManager.MessageLog);	// accumulate message log
				}
			}
		}

		public ActiveAdvice.DataLayer.Patient Patient
		{
			get { return this.patient; }
			set { this.patient = value; }
		}

		public ActiveAdvice.DataLayer.PatientCoverage PatientCoverage
		{
			get { return this.patientCoverage; }
			set { this.patientCoverage = value; }
		}

		public ActiveAdvice.DataLayer.DxPxSelect DxPx
		{
			get { return this.dxPx; }
			set { this.dxPx = value; }
		}

		public ActiveAdvice.DataLayer.PRRequest PRRequest
		{
			get { return this.pRRequest; }
			set 
			{ 
				this.pRRequest = value;
				if (pRRequest.EventID != 0)
					this.erc = pRRequest.GetEvent();
				else if (activity.ReferralID != 0)
					this.erc = activity.GetReferral();
			}
		}


	}

	#endregion

	#region MatchingRule Class
	
	/// <summary>
	/// Non-table based class that contains records returned by usp_GetAutoActivityRulesByFilter.
	/// Both exception and rule may be returned by this query.
	/// If ExceptionID != 0, then the record is exception.
	/// If ExceptionID == 0, then the record is rule.
	/// </summary>
	[SPAutoGen("usp_GetAutoActivityRulesByFilter", null, ManuallyManaged=true)]
	[TableMapping(null, "exceptionID,ruleID")]
	public class MatchingRule : BaseData
	{
		[NonSerialized]
		private MatchingRuleCollection parentMatchingRuleCollection;
		[ColumnMapping("ExceptionID",(int)0)]
		private int exceptionID;
		[ColumnMapping("RuleID",(int)0)]
		private int ruleID;
		[ColumnMapping("GenerateActivity")]
		private bool generateActivity;
		[ColumnMapping("LastDecisionTypeID")]
		private int lastDecisionTypeID;
		[ColumnMapping("LastDecisionEndDate")]
		private DateTime lastDecisionEndDate;

		/// <summary>
		/// If there's no exception id, this is a rule.
		/// </summary>
		public bool IsRule
		{
			get { return this.exceptionID == 0; }
		}

		/// <summary>
		/// If there's an exception id, this is an exception.
		/// </summary>
		public bool IsException
		{
			get { return this.exceptionID != 0; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ExceptionID
		{
			get { return this.exceptionID; }
			set { this.exceptionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int RuleID
		{
			get { return this.ruleID; }
			set { this.ruleID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool GenerateActivity
		{
			get { return this.generateActivity; }
			set { this.generateActivity = value; }
		}

		public BaseAutoActivityRule GetRuleOrException()
		{
			if (this.IsRule)
			{
				AutoActivityRule rule = new AutoActivityRule();
				rule.SqlData.Transaction = this.SqlData.Transaction;
				if (rule.Load(this.ruleID))
					return rule;
				else
					return null;
			}
			else
			{
				AutoActivityRuleException excep = new AutoActivityRuleException();
				excep.SqlData.Transaction = this.SqlData.Transaction;
				if (excep.Load(this.exceptionID))
					return excep;
				else
					return null;
			}
		}

		/// <summary>
		/// Parent MatchingRuleCollection that contains this element
		/// </summary>
		public MatchingRuleCollection ParentMatchingRuleCollection
		{
			get
			{
				return this.parentMatchingRuleCollection;
			}
			set
			{
				this.parentMatchingRuleCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "	exceptionID= '" + ReflectionHelper.GetMemberValueAsString(this, "exceptionID") + "'\r\n";
			s += "	ruleID= '" + ReflectionHelper.GetMemberValueAsString(this, "ruleID") + "'\r\n";
			s += "	generateActivity= '" + ReflectionHelper.GetMemberValueAsString(this, "generateActivity") + "'\r\n";
			s += "}\r\n";
			return s;
		}

		public int LastDecisionTypeID
		{
			get { return this.lastDecisionTypeID; }
			set { this.lastDecisionTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime LastDecisionEndDate
		{
			get { return this.lastDecisionEndDate; }
			set { this.lastDecisionEndDate = value; }
		}

	}

	#endregion

	#region MatchingRuleCollection Class

	/// <summary>
	/// Strongly typed collection of MatchingRule objects
	/// </summary>
	[ElementType(typeof(MatchingRule))]
	public class MatchingRuleCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MatchingRule elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMatchingRuleCollection = this;
			else
				elem.ParentMatchingRuleCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MatchingRule elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MatchingRule this[int index]
		{
			get
			{
				return (MatchingRule)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MatchingRule)oldValue, false);
			SetParentOnElem((MatchingRule)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Evaluate all the activity-rule filters for the given rule-type and context
		/// and load the matching rules and exceptions.
		/// Some rule types may use multiple ids passed.
		/// </summary>
		public int LoadMatchingRules(string ruleType, int patientID, int problemID, int eventID, int referralID, int cmsID, int noteID, int activityID, string dxPxCodeType, string dxPxCode)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAutoActivityRulesByFilter", -1, this, false, 
				new object[] 
				{	ruleType,
					SQLDataDirect.MakeDBValue(patientID, 0), 
					SQLDataDirect.MakeDBValue(problemID, 0), 
					SQLDataDirect.MakeDBValue(eventID, 0), 
					SQLDataDirect.MakeDBValue(referralID, 0), 
					SQLDataDirect.MakeDBValue(cmsID, 0), 
					SQLDataDirect.MakeDBValue(noteID, 0), 
					SQLDataDirect.MakeDBValue(activityID, 0),
					SQLDataDirect.MakeDBValue(dxPxCodeType),
					SQLDataDirect.MakeDBValue(dxPxCode)
					});
		}

		/// <summary>
		/// Load the matching rules for the given rule type and context.
		/// </summary>
		/// <param name="ruleType"></param>
		/// <param name="patient"></param>
		/// <param name="problem"></param>
		/// <param name="eventObj"></param>
		/// <param name="referral"></param>
		/// <param name="cms"></param>
		/// <param name="note"></param>
		/// <param name="activity"></param>
		/// <returns></returns>
		public int LoadMatchingRules(string ruleType, Patient patient, Problem problem, Event eventObj, Referral referral, CMS cms, Note note, Activity activity)
		{
			int patientID = 0;
			int problemID = 0;
			int eventID = 0;
			int referralID = 0;
			int cmsID = 0;
			int noteID = 0;
			int activityID = 0;

			if (patient != null)
				patientID = patient.PatientId;

			if (problem != null)
				problemID = problem.ProblemID;

			if (eventObj != null)
				eventID = eventObj.EventID;

			if (referral != null)
				referralID = referral.ReferralID;

			if (cms != null)
				cmsID = cms.CMSID;

			if (note != null)
				noteID = note.NoteID;

			if (activity != null)
				activityID = activity.ActivityID;

			return LoadMatchingRules(ruleType, patientID, problemID, eventID, referralID, cmsID, noteID, activityID, null, null);
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(MatchingRule elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((MatchingRule)value, true);
			base.OnInsertComplete (index, value);		
		}

	}

	#endregion

}
