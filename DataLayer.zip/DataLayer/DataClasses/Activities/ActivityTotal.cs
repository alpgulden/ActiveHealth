using System;

using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Collections;


namespace ActiveAdvice.DataLayer
{

	/// <summary>
	/// Contains the activity totals calculation result
	/// returned by usp_CalculateActivityTotals
	/// </summary>
	[SPAutoGen("usp_CalculateActivityTotals", null, ManuallyManaged=true)]
	[TableMapping(null)]
	public class ActivityTotal : BaseData
	{
		[NonSerialized]
		private ActivityTotalCollection parentActivityTotalCollection;
	
		public ActivityTotal()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ColumnMapping("ManagementServiceTypeID", StereoType=DataStereoType.FK)]	// if 0/null, total of all managementServiceTypeIDs
		private int managementServiceTypeID;
		[ColumnMapping("Amount")]
		private decimal amount;
		[ColumnMapping("BaseUOMID", StereoType=DataStereoType.FK)]	// if 0/null, total of all BaseUOMIDs
		private int baseUOMID;
		[ColumnMapping("Cost")]
		private decimal cost;
		[ColumnMapping("IsBillable", ValueForNull=(int)-1)]		// if -1/null, total of all billables/not billables
		private int isBillable;

		[FieldValuesMember("LookupOf_ManagementServiceTypeID", "ManagementServiceTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ManagementServiceTypeID
		{
			get { return this.managementServiceTypeID; }
			set { this.managementServiceTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal Amount
		{
			get { return this.amount; }
			set { this.amount = value; }
		}

		[FieldValuesMember("LookupOf_BaseUOMID", "BaseUnitOfMeasureId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int BaseUOMID
		{
			get { return this.baseUOMID; }
			set { this.baseUOMID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		public decimal Cost
		{
			get { return this.cost; }
			set { this.cost = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int IsBillable
		{
			get { return this.isBillable; }
			set { this.isBillable = value; }
		}

		public ManagementServiceTypeCollection LookupOf_ManagementServiceTypeID
		{
			get
			{
				return ManagementServiceTypeCollection.ActiveManagementServiceTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Parent ActivityTotalCollection that contains this element
		/// </summary>
		public ActivityTotalCollection ParentActivityTotalCollection
		{
			get
			{
				return this.parentActivityTotalCollection;
			}
			set
			{
				this.parentActivityTotalCollection = value; // parent is set when added to a collection
			}
		}

		public string ManagementServiceTypeDesc
		{
			get { return ManagementServiceTypeCollection.ActiveManagementServiceTypes.Lookup_DescriptionByManagementServiceTypeId(this.managementServiceTypeID); }
		}

		public string BaseUOMDesc
		{
			get { return BaseUnitOfMeasureCollection.ActiveBaseUnitOfMeasures.Lookup_DescriptionByBaseUnitOfMeasureId(this.baseUOMID); }
		}

		public BaseUnitOfMeasureCollection LookupOf_BaseUOMID
		{
			get
			{
				return BaseUnitOfMeasureCollection.ActiveBaseUnitOfMeasures; // Acquire a shared instance from the static member of collection
			}
		}

		[FieldDescription("@ISBILLABLE@")]
		public string IsBillableStr
		{
			get { return this.isBillable < 0 ? null : Convert.ToBoolean( this.isBillable ).ToString(); }
		}


		public int GetSingleColumn(ArrayList arr, string columnName)
		{
			return this.SqlData.SPExecReadArrayList("usp_GetBatchNumbers", -1, arr, 
				new string[] { "BatchNumber" } );
		}

		public int GetAllColumns(ArrayList arr)
		{
			return this.SqlData.SPExecReadArrayList("usp_GetBatchNumbers", -1, arr, 
				null );
		}

	
	}

	/// <summary>
	/// Strongly typed collection of ActivityTotal objects
	/// </summary>
	[ElementType(typeof(ActivityTotal))]
	public class ActivityTotalCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ActivityTotal elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentActivityTotalCollection = this;
			else
				elem.ParentActivityTotalCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ActivityTotal elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ActivityTotal this[int index]
		{
			get
			{
				return (ActivityTotal)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ActivityTotal)oldValue, false);
			SetParentOnElem((ActivityTotal)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calculates Activity Totals
		///   Called in both Worklist and Activity contexts.
		///   In activity context, @patientID is specified given.
		///   In worklist context, @assignedTeamID, @assignedUserID, @fromDueDate, @toDueDate, @fromCompletionDate, @toCompletionDate are specified
		/// </summary>
		public int CalculateActivityTotals(ActivityTotalFilter activityTotalFilter)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_CalculateActivityTotals", -1, this, activityTotalFilter, false);
		}

	}

	/// <summary>
	/// The members of this class are passed to usp_CalculateActivityTotals parameters
	/// </summary>
	[TableMapping(null)]
	public class ActivityTotalFilter : BaseData
	{
		#region SubTotalBy constants

		public const string SUBTOTALBYSVCTYPE = "SUBTOTALBYSVCTYPE";	// Subtotal by Management Service Type
		public const string SUBTOTALBYUOM = "SUBTOTALBYUOM";			// Subtotal by Unit of Measure
		public const string SUBTOTALBYALL = "SUBTOTALBYALL";			// Subtotal by Unit of Measure

		#endregion

		[ColumnMapping(null, StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping(null, StereoType=DataStereoType.FK)]
		private int assignedTeamID;
		[ColumnMapping(null, StereoType=DataStereoType.FK)]
		private int assignedUserID;
		[ColumnMapping(null)]
		private DateTime fromDueDate;
		[ColumnMapping(null)]
		private DateTime toDueDate;
		[ColumnMapping(null)]
		private DateTime fromCompletionDate;
		[ColumnMapping(null)]
		private DateTime toCompletionDate;

		private string subTotalBy = ActivityTotalFilter.SUBTOTALBYUOM;

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedTeamID
		{
			get { return this.assignedTeamID; }
			set { this.assignedTeamID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedUserID
		{
			get { return this.assignedUserID; }
			set { this.assignedUserID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime FromDueDate
		{
			get { return this.fromDueDate; }
			set { this.fromDueDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ToDueDate
		{
			get { return this.toDueDate; }
			set { this.toDueDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime FromCompletionDate
		{
			get { return this.fromCompletionDate; }
			set { this.fromCompletionDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ToCompletionDate
		{
			get { return this.toCompletionDate; }
			set { this.toCompletionDate = value; }
		}

		public string AssignedTeamAndUserDisplay
		{
			get { return FormatTeamAndUserForDisplay( this.assignedTeamID, this.assignedUserID); }
		}

		[FieldValuesMember("ValuesOf_SubTotalBy")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, ControlType = EnumControlTypes.RadioButtonBox)]
		public string SubTotalBy
		{
			get { return this.subTotalBy; }
			set { this.subTotalBy = value; }
		}

		public string[,] ValuesOf_SubTotalBy
		{
			get
			{
				return new string[,] 
					{ 
						{ ActivityTotalFilter.SUBTOTALBYUOM, "@UOM@" },
						{ ActivityTotalFilter.SUBTOTALBYSVCTYPE, "@MANAGEMENTSERVICETYPE@" },
						{ ActivityTotalFilter.SUBTOTALBYALL, "@SUBTOTALBYALL@" }
					}; // return possible field values
			}
		}

	}

}
