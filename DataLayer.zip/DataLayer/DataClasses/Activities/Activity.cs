using System;
using System.Diagnostics;
using System.Collections;
using NetsoftUSA.DataLayer;



namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Activity]
	/// </summary>
	[SPAutoGen("usp_SearchActivities","-SearchAndSortByArgs.sptpl","patientId, cMSID, planId, problemId, eventID, referralID, reviewID, physicianReviewDetailID, physicianINDPhysicianReviewID, physicianReviewID, activityTypeID, activityPriority, activityCompletionID, isBillable", ManuallyManaged=true)]
	[SPInsert("usp_InsertActivity")]
	[SPUpdate("usp_UpdateActivity")]
	[SPDelete("usp_DeleteActivity")]
	[SPLoad("usp_LoadActivity")]
	[TableMapping("Activity","activityID")]
	public class Activity : BaseData
	{
		[NonSerialized]
		protected ActivityCollection parentActivityCollection;
		[ColumnMapping("ActivityID",StereoType=DataStereoType.FK)]
		protected int activityID;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		protected int patientId;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		protected int cMSID;
		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)]
		protected int planId;
		[ColumnMapping("ProblemId",StereoType=DataStereoType.FK)]
		protected int problemId;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		protected int eventID;
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		protected int referralID;
		[ColumnMapping("ReviewID",StereoType=DataStereoType.FK)]
		protected int reviewID;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("PRProviderDecisionID",StereoType=DataStereoType.FK)]
		private int pRProviderDecisionID;
		[ColumnMapping("ActivityDescription")]
		protected string activityDescription;
		[ColumnMapping("DueDate")]
		protected DateTime dueDate;
		[ColumnMapping("AssignedTeamID",StereoType=DataStereoType.FK)]
		protected int assignedTeamID;
		[ColumnMapping("AssignedUserID",StereoType=DataStereoType.FK)]
		protected int assignedUserID;
		[ColumnMapping("ActivityPriority",StereoType=DataStereoType.FK)]
		protected int activityPriority;
		[ColumnMapping("CompletionNote")]
		protected string completionNote;
		[ColumnMapping("CompletedByUserID",StereoType=DataStereoType.FK)]
		protected int completedByUserID;
		[ColumnMapping("CompletionDate")]
		protected DateTime completionDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ActivityAmount")]
		protected decimal activityAmount;
		[ColumnMapping("ManagementServiceRate")]
		protected decimal managementServiceRate;
		[ColumnMapping("IsBillable")]
		protected bool isBillable;
		[ColumnMapping("BaseAmount")]
		protected decimal baseAmount;
		[ColumnMapping("ExtendedAmount")]
		protected decimal extendedAmount;
		[ColumnMapping("BillableAmount")]
		protected decimal billableAmount;
		[ColumnMapping("BaseConvMult")]
		protected decimal baseConvMult;
		[ColumnMapping("BaseConvDiv")]
		protected decimal baseConvDiv;
		[ColumnMapping("InterventionID",StereoType=DataStereoType.FK)]
		protected int interventionID;
		[ColumnMapping("ActivityCompletionID",StereoType=DataStereoType.FK)]
		protected int activityCompletionID;
		[ColumnMapping("ActivityTypeID",StereoType=DataStereoType.FK)]
		protected int activityTypeID;
		[ColumnMapping("ManagementServiceItemID",StereoType=DataStereoType.FK)]
		protected int managementServiceItemID;
		[ColumnMapping("PRRequestID",StereoType=DataStereoType.FK)]
		private int pRRequestID;
		[ColumnMapping("ManagementServiceTypeId",StereoType=DataStereoType.FK)]
		protected int managementServiceTypeId;
		[ColumnMapping("ActivitySubtypeID",StereoType=DataStereoType.FK)]
		protected int activitySubtypeID;
		[ColumnMapping("ParentActivityID",StereoType=DataStereoType.FK)]
		protected int parentActivityID;
		[ColumnMapping("BaseUOMId",StereoType=DataStereoType.FK)]
		protected int baseUOMId;
		[ColumnMapping("ConversionUOMId",StereoType=DataStereoType.FK)]
		protected int conversionUOMId;
		[ColumnMapping("PatientSubscriberLogID",StereoType=DataStereoType.FK)]
		protected int patientSubscriberLogID;
		[ColumnMapping("PRReviewID",StereoType=DataStereoType.FK)]
		private int pRReviewID;			
	
		//[ColumnMapping("ActivityPrimaryTypeID", SQLGen=SQLGenerationFlags.NoInsert | SQLGenerationFlags.NoUpdate | SQLGenerationFlags.NoSelect)]
		protected int primaryType = 0;				// Not in table.  Used to filter activity type
		private string activityCompletionStatus;			// completion status for the selected activity type

		[ColumnMapping("PlanName", JoinColumn="Name", JoinRelation="Activity.PlanId = [Plan].PlanId", SQLGen=SQLGenerationFlags.NoSelect | SQLGenerationFlags.NoUpdate | SQLGenerationFlags.NoUpdate)]
		protected string planName;
		// The linked plan
		protected Plan plan;							// loaded and cached plan
		protected Patient patient;						// loaded and cached patient
		protected PatientSubscriberLog patSubLog;		// loaded and cached pat sub log

		private int activityCompletionIDwhenLoaded = 0;		// track changes to detect completion

		private int autoActivityCreationLevel = 0;			// this is set by AutoActivityManager to prevent recursive autoactivity rule evaluation
															// 0: not automatically created
															// 1: autoamatically created by a auto-activity rule of 1st level
															// 2: autoamatically created by a auto-activity rule of 2nd level

		public Activity()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Create an activity for patient.  Even if the activity exists in the database,
		/// you can create an Activity for a specific patient.  
		/// Once you pass the patient object, the in-memory relationship to activity will be established.
		/// </summary>
		/// <param name="patient"></param>
		public Activity(Patient patient, bool initNew)
		{
			if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You can create an activity only in the context of a patient");

			if (initNew)
				this.NewRecord();

			this.patient = patient;
			this.patientId = patient.PatientId;
		}

		/// <summary>
		/// Create a new activity for patient and the selected coverage
		/// </summary>
		/// <param name="patient"></param>
		public Activity(Patient patient, PatientCoverage patCov, SqlTransactionWithEvents transaction)
		{
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You can create an activity only in the context of a patient");

			if (patCov == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You can create a new activity only in the context of a patient-subscriber-coverage");

			this.NewRecord();
			this.patient = patient;
			this.patientId = patient.PatientId;

			this.SqlData.Transaction = transaction;
			
			SetCoverage(patient, patCov);
		}

		/// <summary>
		/// This is set by AutoActivityManager to prevent recursive autoactivity rule evaluation
		///   0: not automatically created
		///   1: autoamatically created by a auto-activity rule of 1st level
		///   2: autoamatically created by a auto-activity rule of 2nd level
		/// </summary>
		public int AutoActivityCreationLevel
		{
			get { return this.autoActivityCreationLevel; }
			set { this.autoActivityCreationLevel = value; }
		}

		protected override void InitializeToTrackChanges()
		{
			base.InitializeToTrackChanges ();

			this.activityCompletionIDwhenLoaded = this.activityCompletionID;
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ActivityID
		{
			get { return this.activityID; }
			set { this.activityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientId
		{
			get { return this.patientId; }
			set 
			{ 
				this.patientId = value; 
				this.patient = null;
			}
		}

		[FieldValuesMember("LookupOf_CMSID", "CMSID", "ERCDescription")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		[FieldValuesMember("LookupOf_ProblemId", "ProblemID", "ProblemDescriptionToDisplay")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ProblemId
		{
			get { return this.problemId; }
			set { this.problemId = value; }
		}

		[FieldValuesMember("LookupOf_EventID", "EventID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[FieldValuesMember("LookupOf_ReferralID", "ReferralID", "ERCDescription")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReviewID
		{
			get { return this.reviewID; }
			set { this.reviewID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		[FieldDescription("@DESCRIPTION@")]
		public string ActivityDescription
		{
			get { return this.activityDescription; }
			set { this.activityDescription = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime, IsRequired=true)]	// don't use date-time validation
		public System.DateTime DueDate
		{
			get { return this.dueDate; }
			set { this.dueDate = value; }
		}

		[FieldDescription("@DUEDATE@")]
		public string DueDateStr
		{
			get { return Formatting.FormatDateTime(this.dueDate); }
			set { this.dueDate = Formatting.ParseDateTime(value); }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedTeamID
		{
			get { return this.assignedTeamID; }
			set { this.assignedTeamID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedUserID
		{
			get { return this.assignedUserID; }
			set { this.assignedUserID = value; }
		}

		public string AssignedTeamAndUserDisplay
		{
			get { return FormatTeamAndUserForDisplay( this.assignedTeamID, this.assignedUserID); }
		}

		public string AssignedTeamName
		{
			get { return TeamCollection.AllTeams.Lookup_CodeByTeamId(this.assignedTeamID); }
		}

		public string AssignedUserName
		{
			get { return AAUserCollection.AllUsers.Lookup_LoginNameByUserId(this.assignedUserID); }
		}

		[FieldValuesMember("ValuesOf_ActivityPriority")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ClientValidators = EnumClientValidators.Integer, ValueForNull=(int)0)]
		public int ActivityPriority
		{
			get { return this.activityPriority; }
			set { this.activityPriority = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ClientValidators = EnumClientValidators.Integer, ValueForNull=(int)0)]
		public int ActivityPriorityFFRM
		{
			get { return this.activityPriority; }
			set { this.activityPriority = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		[FieldDescription("@COMMENT@")]
		public string CompletionNote
		{
			get { return this.completionNote; }
			set { this.completionNote = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime)]
		public System.DateTime CompletionDate
		{
			get { return this.completionDate; }
			set { this.completionDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal ActivityAmount
		{
			get { return this.activityAmount; }
			set { this.activityAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal ManagementServiceRate
		{
			get { return this.managementServiceRate; }
			set { this.managementServiceRate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool IsBillable
		{
			get { return this.isBillable; }
			set { this.isBillable = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal BaseAmount
		{
			get { return this.baseAmount; }
			set { this.baseAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal ExtendedAmount
		{
			get { return this.extendedAmount; }
			set { this.extendedAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		[FieldDescription("@TOTAL@")]
		public decimal BillableAmount
		{
			get { return this.billableAmount; }
			set { this.billableAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public decimal BaseConvMult
		{
			get { return this.baseConvMult; }
			set { this.baseConvMult = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public decimal BaseConvDiv
		{
			get { return this.baseConvDiv; }
			set { this.baseConvDiv = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int InterventionID
		{
			get { return this.interventionID; }
			set { this.interventionID = value; }
		}

		[FieldValuesMember("LookupOf_ActivityCompletionID", "ActivityCompletionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ActivityCompletionID
		{
			get { return this.activityCompletionID; }
			set { this.activityCompletionID = value; }
		}

		
		/// <summary>
		/// BR04.3 & BR04.8 are identical
		/// Determines if Activity can be Reassigned or Rescheduled
		/// </summary>
		public bool CanReassignReschedule
		{
			get {return !(this.ActivityCompletionCode == ActivityCompletion.PEND
				  || this.ActivityCompletionCode == ActivityCompletion.CANC
				  || this.ActivityCompletionCode == ActivityCompletion.COMP
				  || this.ActivityCompletionCode == ActivityCompletion.LATE
				  || this.ActivityCompletionCode == ActivityCompletion.RASS
				  || this.ActivityCompletionCode == ActivityCompletion.RSCH);}
		}

		[FieldValuesMember("LookupOf_ActivityTypeID", "ActivityTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int ActivityTypeID
		{
			get { return this.activityTypeID; }
			set { this.activityTypeID = value; }
		}

		/// <summary>
		/// Activity Type for the activity type id set.
		/// </summary>
		public ActivityType ActivityType
		{
			get
			{
				if (this.activityTypeID == 0)
					return null;
				else
					return ActivityTypeCollection.ActiveActivityTypes.FindBy(activityTypeID);
			}
		}

		[FieldValuesMember("LookupOf_ManagementServiceItemID", "ManagementServiceItemId", "ServiceTypeDescription")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ManagementServiceItemID
		{
			get { return this.managementServiceItemID; }
			set { this.managementServiceItemID = value; }
		}

		//[FieldValuesMember("LookupOf_ManagementServiceTypeId", "ManagementServiceTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ManagementServiceTypeId
		{
			get { return this.managementServiceTypeId; }
			set { this.managementServiceTypeId = value; }
		}

		[FieldValuesMember("LookupOf_ActivitySubtypeID", "ActivitySubtypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]		// in the ui, made required when completed
		public int ActivitySubtypeID
		{
			get { return this.activitySubtypeID; }
			set { this.activitySubtypeID = value; }
		}

		[FieldValuesMember("LookupOf_BaseUnitOfMeasureId", "BaseUnitOfMeasureId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@BASEUOM@")]
		public int BaseUOMId
		{
			get { return this.baseUOMId; }
			set { this.baseUOMId = value; }
		}

		[FieldDescription("@RATEUNITS@")]
		public string Fmt_BaseUOMID
		{
			get 
			{ 
				return BaseUnitOfMeasureCollection.ActiveBaseUnitOfMeasures.Lookup_DescriptionByBaseUnitOfMeasureId(this.baseUOMId); 
			}
		}

		public BaseUnitOfMeasureCollection LookupOf_BaseUnitOfMeasureId
		{
			get
			{
				return BaseUnitOfMeasureCollection.ActiveBaseUnitOfMeasures; // Acquire a shared instance from the static member of collection
			}
		}


		[FieldValuesMember("LookupOf_ConversionUnitOfMeasureId", "ConversionUnitOfMeasureId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@CONVERSIONUOM@")]
		public int ConversionUOMId
		{
			get { return this.conversionUOMId; }
			set { this.conversionUOMId = value; }
		}

		[FieldDescription("@UNITS@")]
		public string Fmt_ConversionUnitOfMeasureId
		{
			get 
			{ 
				return ConversionUnitOfMeasureCollection.ActiveConversionUnitOfMeasures.Lookup_DescriptionByConversionUnitOfMeasureId(this.conversionUOMId); 
			}
		}

		public ConversionUnitOfMeasureCollection LookupOf_ConversionUnitOfMeasureId
		{
			get
			{
				return ConversionUnitOfMeasureCollection.ActiveConversionUnitOfMeasures; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Parent ActivityCollection that contains this element
		/// </summary>
		public ActivityCollection ParentActivityCollection
		{
			get
			{
				return this.parentActivityCollection;
			}
			set
			{
				this.parentActivityCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Save method for an existing activity.
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			Save(true);		// Intervention always needs to be in sync
		}

		/// <summary>
		/// Save method for an existing activity.  CAn also be called to update Intervention.
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public void Save(bool updateIntervetion)
		{
			/* Commented out by Dmitriy on 10/28/05
			 * patient-subscriber-coverage may not be available.
			 * This occurs when activity is being reassigned to another user.
			 * In such case new (clone) Activity is being created
			if (this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "You must save a new activity only in the context of a patient-subscriber-coverage");
			*/

			if (this.Patient == null)
				throw new ActiveAdviceException(AAExceptionAction.None,
					"You must save an existing Activity only in the context of a patient");

			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				bool wasDirty = this.IsDirty;
				base.Save();

				// update intervention.
				if(updateIntervetion && wasDirty)
				{
					// update and save related Intervention
					LoadAndUpdateIntervention();
				}

				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Save method for a new Activity.
		/// A new Activity can be saved only in the context of a selected patient-subscriver-coverage
		/// </summary>
		public void Save(PatientCoverage patCov)
		{
			if (!this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "Activity.Save(patCov) can be called only for a new activity");

			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "A new activity can only be saved in the context of a patient");

			if (patCov == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "A new activity can only be saved in the context of a patient-coverage");

			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				// set the planId from the selected coverage
				SetCoverage(this.patient, patCov);

				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		protected void SetCoverage(Patient patient, PatientCoverage patCov)
		{
			this.plan = patCov.Plan;
			this.planId = patCov.PlanID;
			PatientSubscriberLog lastPatSubLog = PatientSubscriberLog.GetLastPatientSubscriberLogEntry(this.SqlData.Transaction, patient, patCov);
			if (lastPatSubLog == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI,
					"No patient-subscriber-log entry found for PatientID={0}, PatientCoverageID={1}", patient.PatientId, patCov.PatientCoverageID);
			this.patientSubscriberLogID = lastPatSubLog.PatientSubscriberLogId;
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int activityID)
		{
			return base.Load(activityID);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CompletedByUserID
		{
			get { return this.completedByUserID; }
			set { this.completedByUserID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ParentActivityID
		{
			get { return this.parentActivityID; }
			set { this.parentActivityID = value; }
		}

		public ActivityTypeCollection LookupOf_ActivityTypeID
		{
			get
			{
				// Load all the active activity types for the selected primary type
				if (this.primaryType == 0)	// ALL
					return ActivityTypeCollection.ActiveActivityTypes;
				else
					return ActivityTypeCollection.GetActiveActivityTypes(this.primaryType); // Acquire a shared instance from the static member of collection
			}
		}

		public ActivitySubTypeCollection LookupOf_ActivitySubtypeID
		{
			get
			{
				if (this.ActivityType == null)
					return ActivitySubTypeCollection.ActiveActivitySubTypes; // Return all subtypes
				else
					return this.ActivityType.GetActiveSubTypes();
			}
		}

		public int[] ValuesOf_ActivityPriority
		{
			get
			{
				return new int[] { 1, 2, 3, 4 }; // return possible field values
			}
		}

		[FieldValuesMember("LookupOf_PrimaryType", "ActivityPrimaryTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int PrimaryType
		{
			get { return this.primaryType; }
			set { this.primaryType = value; }
		}

		public ActivityPrimaryTypeCollection LookupOf_PrimaryType
		{
			get
			{
				return ActivityPrimaryTypeCollection.ActiveActivityPrimaryTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			SyncronizePrimaryTypeByActivityType();
		}

		public void SyncronizePrimaryTypeByActivityType()
		{
			// set correct primary type filter combo for current activity type
			if (this.activityTypeID != 0)
			{
				ActivityType atype = ActivityTypeCollection.ActiveActivityTypes.FindBy(this.activityTypeID);
				if (atype != null)
					this.primaryType = atype.ActivityPrimaryTypeID;
			}
		}

		/// <summary>
		/// Get the associated plan from db
		/// </summary>
		/// <returns></returns>
		public Plan GetPlan()
		{
			if (this.planId == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.planId))
				return plan;
			else
				return null;
		}

		/// <summary>
		/// Get the associated plan from db and cache it.
		/// </summary>
		public Plan Plan
		{
			get
			{
				if (this.plan == null)
					this.plan = this.GetPlan();
				return this.plan;
			}
		}

		// This is a joined column coming from Plans table.
		[ControlType(EnumControlTypes.TextBox)]
		public string PlanName
		{
			get 
			{ 
				if (this.planName == null)
				{
					// load from Plans
					Plan plan = this.Plan;
					if (plan != null)
						this.planName = plan.Name;
				}
				return this.planName; 
			}
		}

		public virtual ActivityCompletionCollection LookupOf_ActivityCompletionID
		{
			get
			{
				return ActivityCompletionCollection.ActiveActivityCompletions; // Acquire a shared instance from the static member of collection
			}
		}

		/*public ManagementServiceTypeCollection LookupOf_ManagementServiceTypeId
		{
			get
			{
				return ManagementServiceTypeCollection.ActiveManagementServiceTypes; // Acquire a shared instance from the static member of collection
			}
		}*/

		/// <summary>
		/// Return the linked problems for the parent patient.
		/// </summary>
		public ProblemCollection LookupOf_ProblemId
		{
			get
			{
				if (this.Patient == null)
					return null;
				return this.Patient.GetLinkedProblems();
			}
		}

		/// <summary>
		/// Return the linked events for the parent patient. 
		/// </summary>
		public EventCollection LookupOf_EventID
		{
			get
			{
				if (this.Patient == null)
					return null;
				return this.Patient.GetLinkedEvents();
			}
		}

		/// <summary>
		/// Return the linked CMS's for the parent patient.
		/// </summary>
		public CMSCollection LookupOf_CMSID
		{
			get
			{
				if (this.Patient == null)
					return null;
				return this.Patient.GetLinkedCMSs();
			}
		}

		/// <summary>
		/// Return the linked Referrals for the parent patient.
		/// </summary>
		public ReferralCollection LookupOf_ReferralID
		{
			get
			{
				if (this.Patient == null)
					return null;
				return this.Patient.GetLinkedReferrals();
			}
		}

		/// <summary>
		/// Return the management service items of the associated plan
		/// </summary>
		public ManagementServiceItemCollection LookupOf_ManagementServiceItemID
		{
			get
			{
				if (this.Plan == null)
					return null;

				this.Plan.ManagementService.LoadManagementServiceItems(false);		// ensure management service items loaded
				return this.Plan.ManagementService.ManagementServiceItems;
			}
		}

		
		/// <summary>
		/// Load the event related to this activity and return it.
		/// </summary>
		/// <returns></returns>
		public Event GetEvent()
		{
			if (this.eventID == 0)
				return null;

			Event eventObj = new Event();
			eventObj.SqlData.Transaction = this.SqlData.Transaction;
			if (eventObj.Load(this.Patient, eventID))
				return eventObj;
			else
				return null;

		}

		/// <summary>
		/// Load the referral related to this activity and return it.
		/// </summary>
		/// <returns></returns>
		public Referral GetReferral()
		{
			if (this.referralID == 0)
				return null;

			Referral referral = new Referral();
			referral.SqlData.Transaction = this.SqlData.Transaction;
			if (referral.Load(referralID))
				return referral;
			else
				return null;

		}

		/// <summary>
		/// Load the cms related to this activity and return it.
		/// </summary>
		/// <returns></returns>
		public CMS GetCMS()
		{
			if (this.cMSID == 0)
				return null;

			CMS cms = new CMS();
			cms.SqlData.Transaction = this.SqlData.Transaction;
			if (cms.Load(cMSID))
				return cms;
			else
				return null;

		}

		/// <summary>
		/// Load the problem related to this activity and return it.
		/// </summary>
		/// <returns></returns>
		public Problem GetProblem()
		{
			if (this.problemId == 0)
				return null;

			Problem problem= new Problem();
			problem.SqlData.Transaction = this.SqlData.Transaction;
			if (problem.Load(problemId))
				return problem;
			else
				return null;

		}

		/// <summary>
		/// Load the patient related to this activity and return it.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientId == 0)
				return null;

			Patient patient = new Patient();
			patient.SqlData.Transaction = this.SqlData.Transaction;
			if (patient.Load(patientId))
				return patient;
			else
				return null;

		}


		/// <summary>
		/// Load and cache the patient related to this activity.  If a patient was already
		/// passed during construction, it's returned.
		/// </summary>
		public Patient Patient
		{
			get 
			{ 
				if (this.patient == null)
					this.patient = GetPatient();
				return this.patient; 
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string ActivityCompletionCode
		{
			get { return ActivityCompletionCollection.ActiveActivityCompletions.Lookup_CodeByActivityCompletionID(this.activityCompletionID); }
			set { this.activityCompletionID = ActivityCompletionCollection.ActiveActivityCompletions.Lookup_ActivityCompletionIDByCode(value); }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string ActivityCompletionCodeWhenLoaded
		{
			get { return ActivityCompletionCollection.ActiveActivityCompletions.Lookup_CodeByActivityCompletionID(this.activityCompletionIDwhenLoaded); }
			set { this.activityCompletionIDwhenLoaded = ActivityCompletionCollection.ActiveActivityCompletions.Lookup_ActivityCompletionIDByCode(value); }
		}

		/// <summary>
		/// Call this whenever you want the CompletedByUserID and CompletionDate fields to be set from the current user context
		/// This is set by the UI
		/// </summary>
		public void SetCompletingUser()
		{
			// will set the inactivating user from the current user context
			//Debug.WriteLine("Activity set completing user for  " + this.PKString);
			
			this.completedByUserID = AASecurityHelper.GetUserId;
			this.completionDate = DateTime.Now;
		}

		public ManagementServiceItem PullManagementServiceItemFields()
		{
			ManagementServiceItemCollection serviceitems = this.LookupOf_ManagementServiceItemID;
			if (serviceitems == null)
				return null;
			serviceitems.IndexBy_ManagementServiceItemId.Rebuild();
			ManagementServiceItem serviceItem = serviceitems.FindBy(this.managementServiceItemID);

			if (serviceItem != null)
			{
				// copy fields
				this.managementServiceTypeId = serviceItem.ManagementServiceTypeId;
				this.managementServiceRate = serviceItem.Rate;
				this.baseUOMId = serviceItem.BaseUnitOfMeasureId;
				this.conversionUOMId = serviceItem.ConversionUnitOfMeasureId;
				this.isBillable = serviceItem.Billable;
				this.baseConvMult = (decimal)serviceItem.Multiplier;
				this.baseConvDiv = (decimal)serviceItem.Divider;
			}
			return serviceItem;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientSubscriberLogID
		{
			get { return this.patientSubscriberLogID; }
			set { this.patientSubscriberLogID = value; }
		}

		public void CalculateTotals()
		{
			PullManagementServiceItemFields();
			CalculateBaseAndExtendedAmount(this.activityAmount, this.managementServiceRate, (decimal)baseConvDiv, (decimal)baseConvMult, ref this.baseAmount, ref this.extendedAmount);
			if (this.isBillable)
				this.billableAmount = this.extendedAmount;
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "	activityID= '" + ReflectionHelper.GetMemberValueAsString(this, "activityID") + "'\r\n";
			s += "	activityDescription= '" + ReflectionHelper.GetMemberValueAsString(this, "activityDescription") + "'\r\n";
			s += "	patientId= '" + ReflectionHelper.GetMemberValueAsString(this, "patientId") + "'\r\n";
			s += "	planId= '" + ReflectionHelper.GetMemberValueAsString(this, "planId") + "'\r\n";
			s += "	problemId= '" + ReflectionHelper.GetMemberValueAsString(this, "problemId") + "'\r\n";
			s += "	eventID= '" + ReflectionHelper.GetMemberValueAsString(this, "eventID") + "'\r\n";
			s += "	referralID= '" + ReflectionHelper.GetMemberValueAsString(this, "referralID") + "'\r\n";
			s += "	reviewID= '" + ReflectionHelper.GetMemberValueAsString(this, "reviewID") + "'\r\n";
			s += "	cMSID= '" + ReflectionHelper.GetMemberValueAsString(this, "cMSID") + "'\r\n";
			s += "}\r\n";
			return s;

		}

		[FieldDescription("@STATUS@")]
		public string ActivityCompletionStatus
		{
			get 
			{ 
				if (this.activityCompletionStatus == null)
					this.activityCompletionStatus = ActivityCompletionCollection.ActiveActivityCompletions.Lookup_CodeStatusByActivityCompletionID(this.activityCompletionID);
				return this.activityCompletionStatus;
			}
			set { this.activityCompletionStatus = value; }
		}

		
		/// <summary>
		/// This property implements BR01.3.1
		/// </summary>
		[FieldDescription("@STATUS@")]
		public string ActivityCompletionStatusGrid
		{
			/*
			 * The status that displays on the worklist and activity grids is calculated as follows:
			 * If the completion code is Future and the due date is before the current date then the status is "Late".
			 * If the completion code is Future and the due date is after the current date then the status is "Future".
			 * If the completion code is Future and the due date equals the current date 
			 *			and the create date is the current date then the status is "New".
			 * If the completion code is Future and the due date equals the current date 
			 *			and the create date is not the current date then the status is "Today".
			 * */
			get
			{
				if(this.ActivityCompletionCode != ActivityCompletion.FUTU)
					return this.ActivityCompletionStatus;
				DateTime now = DateTime.Now.Date;

				if(this.dueDate.Date < now)
					return "Late";
				else if(this.dueDate.Date > now)
					return "Future";

				//here due date equals the current date
				if(this.createTime.Date == now.Date)
					return "New";
				else
					return "Today";
			}

		}

		/// <summary>
		/// Returns the loaded and cached patient subscriber log entry
		/// </summary>
		public PatientSubscriberLog PatientSubscriberLog
		{
			get
			{
				if (this.patSubLog == null)
					this.patSubLog = GetPatientSubscriberLog();
				return this.patSubLog;
			}
		}

		/// <summary>
		/// Loads and retuns the linked patient subscriber log entry
		/// </summary>
		/// <returns></returns>
		public PatientSubscriberLog GetPatientSubscriberLog()
		{
			if (this.patientSubscriberLogID == 0)
				return null;
			PatientSubscriberLog patSubLog = new PatientSubscriberLog();
			patSubLog.SqlData.Transaction = this.SqlData.Transaction;
			if (patSubLog.Load(this.patientSubscriberLogID))
				return patSubLog;
			else
				return null;
		}

		public void CopyTo(Activity activity)
		{
			this.CopyMappedMembersTo(activity, false, false, false);
		}

		/// <summary>
		/// Create a copy of this activity.
		/// </summary>
		/// <returns></returns>
		public Activity CreateCopy()
		{
			Activity newAct = new Activity(this.Patient, true);
			this.CopyTo(newAct);
			newAct.primaryType = this.primaryType;
			return newAct;
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.dueDate = DateTime.Today;
			this.assignedUserID = AASecurityHelper.GetUserId;
			this.PrimaryTypeCode = ActivityPrimaryType.ACTIVITY;
			this.activityPriority = 3;
			this.ActivityCompletionCode = ActivityCompletion.FUTU;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			bool isCompleting = false;
			if (this.activityCompletionIDwhenLoaded != this.activityCompletionID)
				if (this.ActivityCompletionCode == ActivityCompletion.COMP)
					isCompleting = true;	// completing just now

			base.InternalSave();
			// Save the child collections here.

			#region Trigger AutoActivities - AC1, AC2, AC3

			if (this.autoActivityCreationLevel >= AutoActivityManager.MaxAutoActivityRecursionDepth )
			{
				NSGlobal.WriteToEventLog( String.Format("AutoActivity creation rule has recursed to a depth of {0}.  Rule evaluation is cancelled for {1}.", this.autoActivityCreationLevel, this.DebugDescription), EventLogEntryType.Warning );
			}

			if (isCompleting && this.autoActivityCreationLevel <= AutoActivityManager.MaxAutoActivityRecursionDepth)	// Limit the recursion level to a depth of 5 max.
			{
				PatientCoverage patCov = null;
				if (this.PatientSubscriberLog != null)
					patCov = this.PatientSubscriberLog.PatientCoverage;

				autoActivityManager = new AutoActivityManager(patient, patCov, this);

				AutoActivity_CompletingActivity();	// AC1

				if (this.eventID != 0)
				{
					AutoActivity_CompletingActivityForEvent();	// AC2
				}

				if (this.referralID != 0)
				{
					AutoActivity_CompletingActivityForReferral();	// AC3
				}
			}

			#endregion
		}

		private void LoadAndUpdateIntervention()
		{
			if(this.interventionID < 1)
				return;
			POCIntervention intv = new POCIntervention();
			if(!intv.Load(this.interventionID))
				throw new Exception("Could not load and update Intervention with PK: " + this.interventionID.ToString());
			
				
			/* Fields to Update
			 * - Primary Type
			 * - Type
			 * - Description
			 * - Due Date
			 * - Assigned Team/User
			 * - Completion Code
			 * - SubType
			 * - UserID
			 * - Done Date/Time
			 * - Comment
			 * - Management Service Item
			 * - Amount
			 * - Units
			 * - Rate
			 * - Rate Units
			 * - Total
			 * - Billable
			 * */

			intv.ActivityPrimaryTypeID = this.primaryType;
			intv.InterventionTypeID = this.ActivityTypeID;
			intv.Description = this.ActivityDescription;
			intv.DueDate = this.dueDate;
			intv.AssignedTeamID = this.assignedTeamID;
			intv.AssignedUserID = this.assignedUserID;
			intv.CompletionID = this.activityCompletionID;
			intv.CompletionDate = this.completionDate;
			intv.ActivitySubTypeID = this.activitySubtypeID;
			intv.Comment = this.CompletionNote;
			intv.ManagementServiceItemID = this.managementServiceItemID;
			intv.InterventionAmount = Convert.ToInt32(this.activityAmount);
			intv.BaseUOMID = this.baseUOMId;
			intv.ManagementServiceRate = this.managementServiceRate;
			intv.IsBillable = this.isBillable;
			intv.BillableAmount = this.billableAmount;
			intv.ConversionUnitOfMeasureID= this.conversionUOMId;
			intv.BaseAmount = this.baseAmount;
			intv.ExtendedAmount = this.extendedAmount;
			intv.BaseConversionMultiplier = this.baseConvMult;
			intv.BaseConversionDivider = this.baseConvDiv;

			intv.SqlData.Transaction = this.sqlData.Transaction;
			intv.Save(false);  //Save Intervention ONLY, without saving Activity.
		}

		/// <summary>
		/// AC1	- Completing Activity
		/// This is triggered when the activity is being completed.
		/// </summary>
		protected void AutoActivity_CompletingActivity()
		{
			autoActivityManager.Execute(AutoActivityRuleType.AC1, this.SqlData.Transaction);
		}

		/// <summary>
		/// AC2	- Completing Activity for Event
		/// This is triggered when the activity is being completed for an Event.
		/// </summary>
		protected void AutoActivity_CompletingActivityForEvent()
		{
			autoActivityManager.Execute(AutoActivityRuleType.AC2, this.SqlData.Transaction);
		}

		/// <summary>
		/// AC3	- Completing Activity for Referral
		/// This is triggered when the activity is being completed for an Referral.
		/// </summary>
		protected void AutoActivity_CompletingActivityForReferral()
		{
			autoActivityManager.Execute(AutoActivityRuleType.AC3, this.SqlData.Transaction);
		}

		public string PrimaryTypeCode
		{
			get { return ActivityPrimaryTypeCollection.ActiveActivityPrimaryTypes.Lookup_CodeByActivityPrimaryTypeID(this.primaryType); }
			set { this.primaryType = ActivityPrimaryTypeCollection.ActiveActivityPrimaryTypes.Lookup_ActivityPrimaryTypeIDByCode(value); }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PRProviderDecisionID
		{
			get { return this.pRProviderDecisionID; }
			set { this.pRProviderDecisionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PRRequestID
		{
			get { return this.pRRequestID; }
			set { this.pRRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PRReviewID
		{
			get { return this.pRReviewID; }
			set { this.pRReviewID = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of Activity objects
	/// </summary>
	[ElementType(typeof(Activity))]
	public class ActivityCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Activity elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentActivityCollection = this;
			else
				elem.ParentActivityCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Activity elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Activity this[int index]
		{
			get
			{
				return (Activity)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Activity)oldValue, false);
			SetParentOnElem((Activity)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Activity elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Activity)value, true);
			base.OnInsertComplete (index, value);		
		}

	}

	/// <summary>
	/// Used in the Activity/Worklist Search page.
	/// </summary>
	[SPAutoGen("usp_SearchActivitiesReturnIDs",null, ManuallyManaged=true)]
	[SPAutoGen("usp_GetActivitiesByIDs",null, ManuallyManaged=true)]
	public class ActivitySummary : Activity
	{
		[ColumnMapping("PatientFirstName")]
		protected string patientFirstName;
		[ColumnMapping("PatientLastName")]
		protected string patientLastName;
		
		// FORK1.1
		[ColumnMapping("ProviderName")]
		protected string providerName;
		[ColumnMapping("ProviderPhone")]
		protected string providerPhone;

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientFirstName
		{
			get { return this.patientFirstName; }
			set { this.patientFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientLastName
		{
			get { return this.patientLastName; }
			set { this.patientLastName = value; }
		}

		// FORK1.1
		[ControlType(EnumControlTypes.TextBox)]
		public string ProviderName
		{
			get { return this.providerName; }
			set { this.providerName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string ProviderPhone
		{
			get { return this.providerPhone; }
			set { this.providerPhone = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ActivitySummary objects
	/// </summary>
	[ElementType(typeof(ActivitySummary))]
	public class ActivitySummaryCollection : ActivityCollection
	{
		private CollectionPager pager = null;

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ActivitySummary this[int index]
		{
			get
			{
				return (ActivitySummary)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		/// <summary>
		/// Search activities and load the collection.
		/// </summary>
		public int SearchActivities(int maxRecords, ActivitySearcher searcher)
		{
			if (searcher.SortField == null)
				searcher.SortField = searcher.PKFields[0];
			
			if (searcher.Context == EnumActivityContext.WorkList)
				searcher.CodeStatus = FunctionalStatus.OPEN;
			else
				searcher.CodeStatus = null;
			
			string[] extraParamNames = new string[] { "rowCount", "isBillable", "activityPrimaryTypeID", "userid"};
			object[] extraParamValues = new object[] { 
														 maxRecords < 0 ? 0 : maxRecords,
														 searcher.IsBillable ? (object)true : DBNull.Value,
														 SQLDataDirect.MakeDBValue(searcher.PrimaryType, 0),
														 SQLDataDirect.MakeDBValue(AASecurityHelper.GetUserId, (int)0)};

//			if (maxRecords == 0)
//			{
//				// calculate total
//				object total = SqlData.SPExecScalar("usp_SearchActivitiesWithDAFilter", searcher, false, 
//					extraParamNames, extraParamValues);
//				if (total is DBNull)
//					searcher.CalculatedTotalBillableAmount = 0;
//				else
//					searcher.CalculatedTotalBillableAmount = Convert.ToDecimal( total );
//				return 0;
//			}
//			else
//			{
//				this.Clear();
//				// search activities
//				return SqlData.SPExecReadCol("usp_SearchActivitiesWithDAFilter", maxRecords, this, searcher, false, 
//					extraParamNames, extraParamValues);
//			}

			// -o-

			// if isbillable = false, don't include this in search.

//			if (searcher.SortField == null)
//				searcher.SortField = searcher.PKFields[0];
//			
//			if (searcher.Context == EnumActivityContext.WorkList)
//				searcher.CodeStatus = FunctionalStatus.OPEN;
//			else
//				searcher.CodeStatus = null;
//			
//			string[] extraParamNames = new string[] { "rowCount", "isBillable", "activityPrimaryTypeID" };
//			object[] extraParamValues = new object[] { 
//														 calcTotal ? 0 : 1000,
//														 searcher.IsBillable ? (object)true : DBNull.Value,
//														 SQLDataDirect.MakeDBValue(searcher.PrimaryType, 0) };
//
			if (maxRecords==0)
			{
				// calculate total
				object total = SqlData.SPExecScalar("usp_SearchActivitiesWithDAFilter", searcher, false, 
					extraParamNames, extraParamValues);
				if (total is DBNull)
					searcher.CalculatedTotalBillableAmount = 0;
				else
					searcher.CalculatedTotalBillableAmount = Convert.ToDecimal( total );
				return 0;
			}
			else
			{
				// search and load IDs only into the activityIDs ArrayList
				this.Clear();
				this.pager = new CollectionPager(this, 20);
				// search activities
				int count = SqlData.SPExecReadArrayList("usp_SearchActivitiesWithDAFilter", -1, pager.RecordIDs, new string[] {"ActivityID"},
					searcher, false, 
					extraParamNames, extraParamValues);
				this.pager.Rebuild();
				return count;
			}

			// if isbillable = false, don't include this in search.
		}

		/// <summary>
		/// Load the activities int the given group of IDs
		/// </summary>
		public int LoadPagedGroup(int pageIndex)
		{
			this.Clear();
			string ids = this.pager.GetPageIDsAsString(pageIndex);
			if (ids == null)
				return 0;
			else
			{
				int count = SqlData.SPExecReadCol("usp_GetActivitiesByIDs2", -1, this, false, ids);
				this.pager.ReorderCollection(pageIndex, false);
				return count;
			}
		}

		public CollectionPager Pager
		{
			get { return this.pager; }
			set { this.pager = value; }
		}
		
	}

	public enum EnumActivityContext
	{
		Activity = 0,
		WorkList = 1
	}

	/// <summary>
	/// Derives from Activity and contains extra fields that are
	/// used only in the search.
	/// </summary>
	public class ActivitySearcher : Activity
	{
		private EnumActivityContext context = EnumActivityContext.Activity;

		[ColumnMapping(null)]
		private string sortField;
		[ColumnMapping(null)]
		private DateTime fromDueDate;
		[ColumnMapping(null)]
		private DateTime toDueDate;
		[ColumnMapping(null)]
		private DateTime fromCompletionDate;
		[ColumnMapping(null)]
		private DateTime toCompletionDate;
		[ColumnMapping(null)]
		private string codeStatus;

		private int userid;	// userid of the user doing the search, for Data access filtering

		private Decimal calculatedTotalBillableAmount;

		public ActivitySearcher()
		{
			this.SetMembersNull(true, true);
			sortField = "dueDate";		// the default sort is by dueDate
		}

		[FieldValuesMember("ValuesOf_SortField")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string SortField
		{
			get { return this.sortField; }
			set { this.sortField = value; }
		}

		public string[,] ValuesOf_SortField
		{
			get
			{
				return new string[,] 
				{
					//{ "patientId", "@PATIENT@" },
					{ "activityID", "@ACTIVITYID@" },
					{ "cMSID", "@CMS@" },
					//{ "planId", "@PLAN@" },
					{ "problemId", "@PROBLEM@" },
					{ "eventID", "@EVENT@" },
					{ "referralID", "@REFERRAL@" },
					{ "referralDetailID", "@REFERRALDETAIL@" },
					//{ "reviewID", "@REVIEW@" },
					{ "pRRequestID", "@PHYSICIANREVIEWREQUEST@" },
					{ "pRReviewID", "@PHYSICIANREVIEW@" },
					{ "pRProviderDecisionID", "@PHYSICIANREVIEWPROVIDERDECISION@" },
					{ /*"activityTypeDescription"*/ "aty.[Description]", "@ACTIVITYTYPE@" },
					{ "activityPriority", "@PRIORITY@" },
					{ /*"activityCompletionCode"*/"ac.[Description]", "@COMPLETIONCODE@" },
					{ /*"activityCompletionStatus"*/"ac.[CodeStatus]", "@STATUS@" },
					{ "isBillable", "@ISBILLABLE@" },
					{ /*"completedByUser"*/ "compu.[LoginName]", "@COMPLETEDBYUSERID@" },
					{ /*"assignedUser"*/ "asgu.[LoginName]", "@ASSIGNEDUSER@" },
					{ /*"assignedTeam"*/ "asgt.[Description]", "@ASSIGNEDTEAM@" },
					{ "completionDate", "@COMPLETIONDATE@" },
					{ "dueDate", "@DUEDATE@" },
					{ "interventionID", "@INTERVENTIONID@" }
				};
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime FromDueDate
		{
			get { return this.fromDueDate; }
			set { this.fromDueDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ToDueDate
		{
			get { return this.toDueDate; }
			set { this.toDueDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime FromCompletionDate
		{
			get { return this.fromCompletionDate; }
			set { this.fromCompletionDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ToCompletionDate
		{
			get { return this.toCompletionDate; }
			set { this.toCompletionDate = value; }
		}

		public ActiveAdvice.DataLayer.EnumActivityContext Context
		{
			get { return this.context; }
			set { this.context = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal CalculatedTotalBillableAmount
		{
			get { return this.calculatedTotalBillableAmount; }
			set { this.calculatedTotalBillableAmount = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string CodeStatus
		{
			get { return this.codeStatus; }
			set { this.codeStatus = value; }
		}

		public int UserID
		{
			get { return this.userid; }
			set { this.userid = value; }
		}

		public override ActivityCompletionCollection LookupOf_ActivityCompletionID
		{
			get
			{
				if  (this.context == EnumActivityContext.WorkList)	// only open codes should display in worklist mode
					return ActivityCompletionCollection.OpenActivityCompletions; // Acquire a filtered instance from the static member of collection
				else
					return ActivityCompletionCollection.ActiveActivityCompletions; // Acquire a shared instance from the static member of collection
			}
		}
	}


}
