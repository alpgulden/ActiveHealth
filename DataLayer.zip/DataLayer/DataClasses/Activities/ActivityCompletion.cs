using System;

using NetsoftUSA.DataLayer;
/*ss test*/

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Codes for Activity Completion status
	/// </summary>
	public class ActivityCompletionStatus
	{
		#region Programmatic codes for the Activity completion status codes.

		public const string OPEN = "OPEN";			// Open
		public const string CLOS = "CLOS";			// Closed
		public const string TERM = "TERM";			// Terminated

		#endregion
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [ActivityCompletion]
	/// </summary>
	[SPAutoGen("usp_GetActivityCompletionsByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllActivityCompletions","SelectAll.sptpl","")]
	[SPInsert("usp_InsertActivityCompletion")]
	[SPUpdate("usp_UpdateActivityCompletion")]
	[SPDelete("usp_DeleteActivityCompletion")]
	[SPLoad("usp_LoadActivityCompletion")]
	[TableMapping("ActivityCompletion","activityCompletionID")]
	public class ActivityCompletion : BaseLookupWithSubCodeSTR
	{
		#region Programmatic codes for the Activity completion codes.

		public const string COMP = "COMP";			// Complete
		public const string CANC = "CANC";			// Cancelled
		public const string FUTU = "FUTU";			// Future
		public const string LATE = "LATE";			// Late
		public const string NOVT = "NOVT";			// Not an event
		public const string PEND = "PEND";			// Pending
		public const string TERM = "TERM";			// Terminated
		public const string NOCP = "NOCP";			// Incomplete
		public const string RASS = "RASS";			// Reassigned
		public const string RSCH = "RSCH";			// Rescheduled

		#endregion

		[NonSerialized]
		private ActivityCompletionCollection parentActivityCompletionCollection;
		[ColumnMapping("ActivityCompletionID",StereoType=DataStereoType.FK)]
		private int activityCompletionID;
		[ColumnMapping("Notepad")]
		private string notepad;
		[ColumnMapping("CodeStatus")]
		private string codeStatus;
	
		public ActivityCompletion()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ActivityCompletionID
		{
			get { return this.activityCompletionID; }
			set { this.activityCompletionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldValuesMember("LookupOf_SubCodeStr", "Code", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		[FieldDescription("@CODESTATUS@")]
		public override string SubCodeStr
		{
			get { return this.codeStatus; }
			set { this.codeStatus = value; }
		}


		/// <summary>
		/// Parent ActivityCompletionCollection that contains this element
		/// </summary>
		public ActivityCompletionCollection ParentActivityCompletionCollection
		{
			get
			{
				return this.parentActivityCompletionCollection;
			}
			set
			{
				this.parentActivityCompletionCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string CodeStatus
		{
			get { return this.codeStatus; }
			set { this.codeStatus = value; }
		}

		public FunctionalStatusCollection LookupOf_SubCodeStr
		{
			get
			{
				return FunctionalStatusCollection.AllFunctionalStatusCodes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ActivityCompletion objects
	/// </summary>
	[ElementType(typeof(ActivityCompletion))]
	public class ActivityCompletionCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		[NonSerialized]
		private CollectionIndexer indexBy_ActivityCompletionID;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ActivityCompletion elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentActivityCompletionCollection = this;
			else
				elem.ParentActivityCompletionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ActivityCompletion elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ActivityCompletion this[int index]
		{
			get
			{
				return (ActivityCompletion)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ActivityCompletion)oldValue, false);
			SetParentOnElem((ActivityCompletion)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Load activity completion codes either active or inactive.
		/// </summary>
		public int LoadActivityCompletionsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActivityCompletionsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ActivityCompletionCollection which is cached in NSGlobal
		/// </summary>
		public static ActivityCompletionCollection ActiveActivityCompletions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ActivityCompletionCollection col = (ActivityCompletionCollection)NSGlobal.EnsureCachedObject("ActivityCompletions", typeof(ActivityCompletionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadActivityCompletionsByActive(-1, true);
				}
				return col;
			}
		}

		/// <summary>
		/// Return only the activity codes with status = 'OPEN'
		/// </summary>
		public static ActivityCompletionCollection OpenActivityCompletions
		{
			get
			{
				ActivityCompletionCollection col = ActivityCompletionCollection.ActiveActivityCompletions;
				ActivityCompletionCollection filtered = new ActivityCompletionCollection();
				foreach (ActivityCompletion ac in col)
				{
					if (ac.CodeStatus == FunctionalStatus.OPEN)
						filtered.Add(ac);
				}
				return filtered;
			}
		}

		/// <summary>
		/// Hashtable based index on activityCompletionID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ActivityCompletionID
		{
			get
			{
				if (this.indexBy_ActivityCompletionID == null)
					this.indexBy_ActivityCompletionID = new CollectionIndexer(this, new string[] { "activityCompletionID" }, true);
				return this.indexBy_ActivityCompletionID;
			}
			
		}

		/// <summary>
		/// Looks up by activityCompletionID and returns Code value.  Uses the IndexBy_ActivityCompletionID indexer.
		/// </summary>
		public string Lookup_CodeByActivityCompletionID(int activityCompletionID)
		{
			return this.IndexBy_ActivityCompletionID.LookupStringMember("Code", activityCompletionID);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns ActivityCompletionID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_ActivityCompletionIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("ActivityCompletionID", code);
		}

		/// <summary>
		/// Looks up by activityCompletionID and returns CodeStatus value.  Uses the IndexBy_ActivityCompletionID indexer.
		/// </summary>
		public string Lookup_CodeStatusByActivityCompletionID(int activityCompletionID)
		{
			return this.IndexBy_ActivityCompletionID.LookupStringMember("CodeStatus", activityCompletionID);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllActivityCompletions", -1, this, false);
		}

		/// <summary>
		/// Looks up by activityCompletionID and returns Description value.  Uses the IndexBy_ActivityCompletionID indexer.
		/// </summary>
		public string Lookup_DescriptionByActivityCompletionID(int activityCompletionID)
		{
			return this.IndexBy_ActivityCompletionID.LookupStringMember("Description", activityCompletionID);
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ActivityCompletion elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ActivityCompletion)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
