using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Holds code constants for AutoActivityInitializationValue.DateSource
	/// </summary>
	public class AutoActivityInitDateSource
	{
		public const string CURR = "CURR";				// Current system date
		public const string END = "END";				// End date
		public const string SERV = "SERV";				// Service date
	}

	public class AssignedUserTypeConstants
	{
		public const string Event = "1";
		public const string Referral = "2";
		public const string CMS = "3";
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [AutoActivityInitializationValues]
	/// </summary>
	[SPAutoGen("usp_GetAllActivityValuesByExceptId","SelectAllByGivenArgs.sptpl","exceptionID")]
	[SPAutoGen("usp_GetAllActivityValuesByRuleId","SelectAllByGivenArgs.sptpl","ruleID")]
	[SPInsert("usp_InsertAutoActivityInitializationValue")]
	[SPUpdate("usp_UpdateAutoActivityInitializationValue")]
	[SPDelete("usp_DeleteAutoActivityInitializationValue")]
	[SPLoad("usp_LoadAutoActivityInitializationValue")]
	[TableMapping("AutoActivityInitializationValues","autoActivityInitializationID")]
	public class AutoActivityInitializationValue : BaseData
	{
		[NonSerialized]
		private AutoActivityInitializationValueCollection parentAutoActivityInitializationValueCollection;
		[ColumnMapping("AutoActivityInitializationID",(int)0)]
		private int autoActivityInitializationID;
		[ColumnMapping("RuleID",StereoType=DataStereoType.FK)]
		private int ruleID;
		[ColumnMapping("ExceptionID",StereoType=DataStereoType.FK)]
		private int exceptionID;
		[ColumnMapping("DateSource")]
		private string dateSource;
		[ColumnMapping("DueTime")]
		private DateTime dueTime;
		[ColumnMapping("DateOffset")]
		private int dateOffset;
		[ColumnMapping("ActivityTypeID",StereoType=DataStereoType.FK)]
		private int activityTypeID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("AssignedUserID",StereoType=DataStereoType.FK)]
		private int assignedUserID;
		[ColumnMapping("AssignedTeamID",StereoType=DataStereoType.FK)]
		private int assignedTeamID;
		[ColumnMapping("AssignedUserType")]
		private string assignedUserType;
		[ColumnMapping("PriorityID",StereoType=DataStereoType.FK)]
		private int priorityID;
		[ColumnMapping("CompletionID",StereoType=DataStereoType.FK)]
		private int completionID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public AutoActivityInitializationValue()
		{
		}

		public AutoActivityInitializationValue(bool initNew)
		{
			if (initNew) // initialize record if requested
			{
				this.NewRecord();
				this.Active=true;
			}
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int AutoActivityInitializationID
		{
			get { return this.autoActivityInitializationID; }
			set { this.autoActivityInitializationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RuleID
		{
			get { return this.ruleID; }
			set { this.ruleID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ExceptionID
		{
			get { return this.exceptionID; }
			set { this.exceptionID = value; }
		}

		[FieldValuesMember("ValuesOf_DateSource")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string DateSource
		{
			get { return this.dateSource; }
			set { this.dateSource = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int DateOffset
		{
			get { return this.dateOffset; }
			set { this.dateOffset = value; }
		}

		[FieldValuesMember("LookupOf_ActivityTypeID", "ActivityTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int ActivityTypeID
		{
			get { return this.activityTypeID; }
			set { this.activityTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedUserID
		{
			get { return this.assignedUserID; }
			set { this.assignedUserID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedTeamID
		{
			get { return this.assignedTeamID; }
			set { this.assignedTeamID = value; }
		}

		[FieldValuesMember("ValuesOf_Priority")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int PriorityID
		{
			get { return this.priorityID; }
			set { this.priorityID = value; }
		}

		[FieldValuesMember("LookupOf_CompletionID", "ActivityCompletionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CompletionID
		{
			get { return this.completionID; }
			set { this.completionID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int autoActivityInitializationID)
		{
			return base.Load(autoActivityInitializationID);
		}

		/// <summary>
		/// Parent AutoActivityInitializationValueCollection that contains this element
		/// </summary>
		public AutoActivityInitializationValueCollection ParentAutoActivityInitializationValueCollection
		{
			get
			{
				return this.parentAutoActivityInitializationValueCollection;
			}
			set
			{
				this.parentAutoActivityInitializationValueCollection = value; // parent is set when added to a collection
			}
		}

		public string[,] ValuesOf_DateSource
		{
			get
			{
				return new string[,] 
					{
					  { AutoActivityInitDateSource.CURR, "CURRSYSTEMDATE" },
					  { AutoActivityInitDateSource.END, "ENDDATE" },
					  { AutoActivityInitDateSource.SERV, "SERVICEDATE" }
					}; // return possible field values
			}
		}

		public string[,] ValuesOf_AssignedUserType
		{
			get
			{
				return new string[,] 
					{
					  { "1", "Event" },
					  { "2", "Referral" },
					  { "3", "CMS" }
					}; // return possible field values
			}
		}

		public int[] ValuesOf_Priority
		{
			get
			{
				return new int[] { 1 , 2, 3};
			}
		}		

		public ActivityTypeCollection LookupOf_ActivityTypeID
		{
			get
			{
				return ActivityTypeCollection.ActiveActivityTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public ActivityCompletionCollection LookupOf_CompletionID
		{
			get
			{
				return ActivityCompletionCollection.ActiveActivityCompletions; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.assignedUserID = AASecurityHelper.GetUserId;
		}


		[FieldValuesMember("ValuesOf_AssignedUserType")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, MaxLength=1)]
		public string AssignedUserType
		{
			get { return this.assignedUserType; }
			set { this.assignedUserType = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Time12,MaxLength=8)]
		public DateTime DueTime
		{
			get { return this.dueTime; }
			set { this.dueTime = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of AutoActivityInitializationValue objects
	/// </summary>
	[ElementType(typeof(AutoActivityInitializationValue))]
	public class AutoActivityInitializationValueCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ExceptionID;
		[NonSerialized]
		private CollectionIndexer indexBy_RuleID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AutoActivityInitializationValue elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAutoActivityInitializationValueCollection = this;
			else
				elem.ParentAutoActivityInitializationValueCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AutoActivityInitializationValue elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AutoActivityInitializationValue this[int index]
		{
			get
			{
				return (AutoActivityInitializationValue)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AutoActivityInitializationValue)oldValue, false);
			SetParentOnElem((AutoActivityInitializationValue)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Hashtable based index on ruleID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_RuleID
		{
			get
			{
				if (this.indexBy_RuleID == null)
					this.indexBy_RuleID = new CollectionIndexer(this, new string[] { "ruleID" }, true);
				return this.indexBy_RuleID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on ruleID fields returns the object.  Uses the IndexBy_RuleID indexer.
		/// </summary>
		public AutoActivityInitializationValue FindBy(int ruleID)
		{
			return (AutoActivityInitializationValue)this.IndexBy_RuleID.GetObject(ruleID);
		}

		/// <summary>
		/// Parent AutoActivityRule that contains this collection
		/// </summary>
		public AutoActivityRule ParentAutoActivityRule
		{
			get { return this.ParentDataObject as AutoActivityRule; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AutoActivityRule */ }
		}

		/// <summary>
		/// Parent AutoActivityRuleException that contains this collection
		/// </summary>
		public AutoActivityRuleException ParentAutoActivityRuleException
		{
			get { return this.ParentDataObject as AutoActivityRuleException; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AutoActivityRuleException */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllActivityValuesByRuleId(int maxRecords, int ruleID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllActivityValuesByRuleId", maxRecords, this, false, new object[] { ruleID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllActivityValuesByExceptId(int maxRecords, int exceptionID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllActivityValuesByExceptId", maxRecords, this, false, new object[] { exceptionID });
		}
	}
}
