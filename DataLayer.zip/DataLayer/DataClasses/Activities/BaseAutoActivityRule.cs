using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Base class for AutoActivityRule and AutoActivityException classes
	/// </summary>
	//[TableMapping("AutoActivityRuleException","ruleId")]
	public abstract class BaseAutoActivityRule : BaseData
	{
		[ColumnMapping("Active")]
		protected bool active;
		[ColumnMapping("Description")]
		protected string description;
		[ColumnMapping("EventServiceCategoryId",StereoType=DataStereoType.FK)]
		protected int eventServiceCategoryId;
		[ColumnMapping("ReferralServiceCategoryId",StereoType=DataStereoType.FK)]
		protected int referralServiceCategoryId;
		[ColumnMapping("PrimaryDiagCodeType")]
		protected string primaryDiagCodeType;
		[ColumnMapping("PrimaryDiagStart")]
		protected string primaryDiagStart;
		[ColumnMapping("PrimaryDiagEnd")]
		protected string primaryDiagEnd;
		[ColumnMapping("PrimaryProcCodeType")]
		protected string primaryProcCodeType;
		[ColumnMapping("PrimaryProcStart")]
		protected string primaryProcStart;
		[ColumnMapping("PrimaryProcEnd")]
		protected string primaryProcEnd;
		[ColumnMapping("LastNameStart")]
		protected string lastNameStart;
		[ColumnMapping("LastNameEnd")]
		protected string lastNameEnd;
		[ColumnMapping("MORGId",StereoType=DataStereoType.FK)]
		protected int mORGId;
		[ColumnMapping("ORGId",StereoType=DataStereoType.FK)]
		protected int oRGId;
		[ColumnMapping("SORGId",StereoType=DataStereoType.FK)]
		protected int sORGId;
		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)]
		protected int planId;
		[ColumnMapping("CMSTypeId",StereoType=DataStereoType.FK)]
		protected int cMSTypeId;
		[ColumnMapping("DecisionTypeId",StereoType=DataStereoType.FK)]
		protected int decisionTypeId;
		[ColumnMapping("PlanMgmtSvcTypeId",StereoType=DataStereoType.FK)]
		protected int planMgmtSvcTypeId;
		[ColumnMapping("ActivityTypeId",StereoType=DataStereoType.FK)]
		protected int activityTypeId;
		[ColumnMapping("StateId",StereoType=DataStereoType.FK)]
		protected int stateId;
		[ColumnMapping("ZipStart")]
		protected string zipStart;
		[ColumnMapping("ZipEnd")]
		protected string zipEnd;
		[ColumnMapping("ProviderFedTaxId")]
		protected string providerFedTaxId;
		[ColumnMapping("ProviderNetworkStatusId",StereoType=DataStereoType.FK,ValueForNull=(int)-1)]
		protected int providerNetworkStatusId=-1;
		[ColumnMapping("ProviderNetworkId",StereoType=DataStereoType.FK)]
		protected int providerNetworkId;
		[ColumnMapping("FacilityFedTaxId")]
		protected string facilityFedTaxId;
		[ColumnMapping("FacilityNetworkStatusId",StereoType=DataStereoType.FK,ValueForNull=(int)-1)]
		protected int facilityNetworkStatusId=-1;
		[ColumnMapping("FacilityNetworkId",StereoType=DataStereoType.FK)]
		protected int facilityNetworkId;
		[ColumnMapping("ReferProviderFedTaxId")]
		protected string referProviderFedTaxId;
		[ColumnMapping("ReferProviderNetworkStatusId",StereoType=DataStereoType.FK,ValueForNull=(int)-1)]
		protected int referProviderNetworkStatusId=-1;
		[ColumnMapping("ReferProviderNetworkId",StereoType=DataStereoType.FK)]
		protected int referProviderNetworkId;

		private int organizationId;
		private string organizationPath;
		private string planName;

		[FieldDescription("@ORGANIZATIONID@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int OrganizationId
		{
			get { 
				int ret=0;
				if(this.mORGId!=0)
					ret=this.mORGId;
				if(this.oRGId!=0)
					ret=this.oRGId;
				if(this.sORGId!=0)
					ret=this.sORGId;
				return ret;
				}
			set 
			{ 
				this.organizationId = value; 
				//determine level of given Organization and set ID's accordingly
				Organization o = new Organization();
				// FORK 1.1 
				// mORGId, oRGId, sORGId assigned 0 if orgid empty.
				if ( this.organizationId < 1)
				{
					this.mORGId = 0;
					this.oRGId = 0;
					this.sORGId = 0;
				}
				//
				if (o.Load(this.organizationId))
				{
					switch (o.OrganizationLevel.Code)
					{
						case "MORG":
							this.mORGId = this.organizationId;
							this.oRGId = 0;
							this.sORGId = 0;
							break;
						case "ORG":
							this.mORGId = 0;
							this.oRGId = this.organizationId;
							this.sORGId = 0;
							break;
						case "SORG":
							this.mORGId = 0;
							this.oRGId = 0;
							this.sORGId = this.organizationId;
							break;
						default:
							return;
					}
				}
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string OrganizationPath
		{
			get { return this.organizationPath; }
			set { this.organizationPath = value; }
		}
		
		[ControlType(EnumControlTypes.TextBox)]
		public string PlanName
		{
			get { return this.planName; }
			set { this.planName = value; }
		}

		[FieldDescription("@PLAN@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}
		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string PrimaryDiagCodeType
		{
			get { return this.primaryDiagCodeType; }
			set { this.primaryDiagCodeType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string PrimaryDiagStart
		{
			get { return this.primaryDiagStart; }
			set { this.primaryDiagStart = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string PrimaryDiagEnd
		{
			get { return this.primaryDiagEnd; }
			set { this.primaryDiagEnd = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string PrimaryProcCodeType
		{
			get { return this.primaryProcCodeType; }
			set { this.primaryProcCodeType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string PrimaryProcStart
		{
			get { return this.primaryProcStart; }
			set { this.primaryProcStart = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string PrimaryProcEnd
		{
			get { return this.primaryProcEnd; }
			set { this.primaryProcEnd = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string LastNameStart
		{
			get { return this.lastNameStart; }
			set { this.lastNameStart = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string LastNameEnd
		{
			get { return this.lastNameEnd; }
			set { this.lastNameEnd = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int MORGId
		{
			get { return this.mORGId; }
			set { this.mORGId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ORGId
		{
			get { return this.oRGId; }
			set { this.oRGId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int SORGId
		{
			get { return this.sORGId; }
			set { this.sORGId = value; }
		}

		[FieldValuesMember("LookupOf_ActivityTypeId", "ActivityTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ActivityTypeId
		{
			get { return this.activityTypeId; }
			set { this.activityTypeId = value; }
		}

		[FieldDescription("@STATE@")]
		[FieldValuesMember("LookupOf_StateId", "StateID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]		
		public int StateId
		{
			get { return this.stateId; }
			set { this.stateId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=5)]
		public string ZipStart
		{
			get { return this.zipStart; }
			set { this.zipStart = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=5)]
		public string ZipEnd
		{
			get { return this.zipEnd; }
			set { this.zipEnd = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string ProviderFedTaxId
		{
			get { return this.providerFedTaxId; }
			set { this.providerFedTaxId = value; }
		}

		[FieldValuesMember("LookupOf_ReferProviderNetworkId", "NetworkID", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ProviderNetworkId
		{
			get { return this.providerNetworkId; }
			set { this.providerNetworkId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string FacilityFedTaxId
		{
			get { return this.facilityFedTaxId; }
			set { this.facilityFedTaxId = value; }
		}

		[FieldValuesMember("LookupOf_ReferProviderNetworkId", "NetworkID", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int FacilityNetworkId
		{
			get { return this.facilityNetworkId; }
			set { this.facilityNetworkId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string ReferProviderFedTaxId
		{
			get { return this.referProviderFedTaxId; }
			set { this.referProviderFedTaxId = value; }
		}

		[FieldValuesMember("LookupOf_ReferProviderNetworkId", "NetworkID", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ReferProviderNetworkId
		{
			get { return this.referProviderNetworkId; }
			set { this.referProviderNetworkId = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[FieldValuesMember("LookupOf_EventServiceCategoryId", "EventTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int EventServiceCategoryId
		{
			get { return this.eventServiceCategoryId; }
			set { this.eventServiceCategoryId = value; }
		}

		[FieldValuesMember("LookupOf_ReferralServiceCategoryId", "ReferralTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ReferralServiceCategoryId
		{
			get { return this.referralServiceCategoryId; }
			set { this.referralServiceCategoryId = value; }
		}

		[FieldValuesMember("LookupOf_CMSTypeId", "CMSTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CMSTypeId
		{
			get { return this.cMSTypeId; }
			set { this.cMSTypeId = value; }
		}

		[FieldValuesMember("LookupOf_DecisionTypeId", "ClinicalReviewDecisionTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]		
		public int DecisionTypeId
		{
			get { return this.decisionTypeId; }
			set { this.decisionTypeId = value; }
		}

		[FieldValuesMember("LookupOf_PlanMgmtSvcTypeId", "PlanTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int PlanMgmtSvcTypeId
		{
			get { return this.planMgmtSvcTypeId; }
			set { this.planMgmtSvcTypeId = value; }
		}

		[FieldValuesMember("ValuesOf_ProviderNetworkStatusId")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup,ValueForNull=(int)-1)]
		public int ProviderNetworkStatusId
		{
			get { return this.providerNetworkStatusId; }
			set { this.providerNetworkStatusId = value; }
		}

		[FieldValuesMember("ValuesOf_ProviderNetworkStatusId")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup,ValueForNull=(int)-1)]
		public int FacilityNetworkStatusId
		{
			get { return this.facilityNetworkStatusId; }
			set { this.facilityNetworkStatusId = value; }
		}

		[FieldValuesMember("ValuesOf_ProviderNetworkStatusId")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup,ValueForNull=(int)-1)]
		public int ReferProviderNetworkStatusId
		{
			get { return this.referProviderNetworkStatusId; }
			set { this.referProviderNetworkStatusId = value; }
		}

		public abstract AutoActivityInitializationValueCollection AutoActivityInitializationValues
		{
			get; set;
		}
		public abstract void LoadAutoActivityInitializationValues(bool forceReload);
		public abstract void SaveAutoActivityInitializationValues();

		public ActivityTypeCollection LookupOf_ActivityTypeId
		{
			get
			{
				return ActivityTypeCollection.ActiveActivityTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public EventTypeCollection LookupOf_EventServiceCategoryId
		{
			get
			{
				return EventTypeCollection.ActiveEventTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public ReferralTypeCollection LookupOf_ReferralServiceCategoryId
		{
			get
			{
				return ReferralTypeCollection.ActiveReferralTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public CMSTypeCollection LookupOf_CMSTypeId
		{
			get
			{
				return CMSTypeCollection.ActiveCMSTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public PlanTypeCollection LookupOf_PlanMgmtSvcTypeId
		{
			get
			{
				return PlanTypeCollection.ActivePlanTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public StateCollection LookupOf_StateId
		{
			get
			{
				return StateCollection.AllStates; // Acquire a shared instance from the static member of collection
			}
		}

		public NetworkCollection LookupOf_ReferProviderNetworkId
		{
			get
			{
				return NetworkCollection.Networks; // Acquire a shared instance from the static member of collection
			}
		}

		public object[,] ValuesOf_ProviderNetworkStatusId
		{
			get
			{
				return new object[,] { {(int)1, "@INNETWORK@" },{ (int)0, "@OUTNETWORK@" } }; // return possible field values
			}
		}

		public ClinicalReviewDecisionTypeCollection LookupOf_DecisionTypeId
		{
			get
			{
				return ClinicalReviewDecisionTypeCollection.ActiveClinicalReviewDecisionTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public string DebugDescription
		{
			get
			{
				string rtype = null;
				if (this is AutoActivityRule)
					rtype = "Rule";
				else
					rtype = "Exception";

				return String.Format("{0} {1} (ID={2})", rtype, this.description, this.PKString);
			}
		}

		public string UserFriendlyDescription
		{
			get
			{
				string rtype = null;
				if (this is AutoActivityRule)
					rtype = "Rule";
				else
					rtype = "Exception";

				return String.Format("{0} {1} (ID={2})", rtype, this.description, this.PKString);
			}
		}

	}
}

// 
// Auto Activities functionality allows the Active Advice system to create 
// and assign activities to teams or users automatically. For example, the 
// system may generate an activity each time an Event is created where the 
// patient last name begins with A to L, the Event Type is Hospitalization, 
// the Plan Management has Care Management as a purchased service, and the 
// User codes are within the ICD9 code range of 765.10 � 765.19 (pre term 
// baby codes). 
//
// The three main steps of the activity creation are:
// 
// *	Define the event that would trigger the process (Rule Type)
// *	Specify one or more rules and exceptions by providing values to predefined attributes 
// *	Define one or more activities and their attributes that will be generated
//
// Define the event that would trigger the process (Rule Type)