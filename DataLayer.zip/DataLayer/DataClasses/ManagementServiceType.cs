using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ManagementServiceTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllManagementServiceType","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetManagementServiceTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertManagementServiceType")]
	[SPUpdate("usp_UpdateManagementServiceType")]
	[SPDelete("usp_DeleteManagementServiceType")]
	[SPLoad("usp_LoadManagementServiceType")]
	[TableMapping("ManagementServiceType","managementServiceTypeId")]
	public class ManagementServiceType : BaseLookupWithNote
	{
		[NonSerialized]
		private ManagementServiceTypeCollection parentManagementServiceTypeCollection;
		[ColumnMapping("ManagementServiceTypeId",StereoType=DataStereoType.FK)]
		private int managementServiceTypeId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ManagementServiceType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ManagementServiceType(int managementServiceTypeId,  string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.managementServiceTypeId = managementServiceTypeId;
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ManagementServiceTypeId
		{
			get { return this.managementServiceTypeId; }
			set { this.managementServiceTypeId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int managementServiceTypeId)
		{
			return base.Load(managementServiceTypeId);
		}

		/// <summary>
		/// Parent ManagementServiceTypeCollection that contains this element
		/// </summary>
		public ManagementServiceTypeCollection ParentManagementServiceTypeCollection
		{
			get
			{
				return this.parentManagementServiceTypeCollection;
			}
			set
			{
				this.parentManagementServiceTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ManagementServiceType objects
	/// </summary>
	[ElementType(typeof(ManagementServiceType))]
	public class ManagementServiceTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ManagementServiceTypeId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ManagementServiceType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentManagementServiceTypeCollection = this;
			else
				elem.ParentManagementServiceTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ManagementServiceType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ManagementServiceType this[int index]
		{
			get
			{
				return (ManagementServiceType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ManagementServiceType)oldValue, false);
			SetParentOnElem((ManagementServiceType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Load this collection with the management service types either active or inactive
		/// </summary>
		public int LoadManagementServiceTypesByActive(int maxRecords, bool active)
		{
			return SqlData.SPExecReadCol("usp_GetManagementServiceTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ManagementServiceTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ManagementServiceTypeCollection ActiveManagementServiceTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ManagementServiceTypeCollection col = (ManagementServiceTypeCollection)NSGlobal.EnsureCachedObject("ActiveManagementServiceTypes", typeof(ManagementServiceTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadManagementServiceTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on managementServiceTypeId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ManagementServiceTypeId
		{
			get
			{
				if (this.indexBy_ManagementServiceTypeId == null)
					this.indexBy_ManagementServiceTypeId = new CollectionIndexer(this, new string[] { "managementServiceTypeId" }, true);
				return this.indexBy_ManagementServiceTypeId;
			}			
		}

		/// <summary>
		/// Looks up by managementServiceTypeId and returns Description value.  Uses the IndexBy_ManagementServiceTypeId indexer.
		/// </summary>
		public string Lookup_DescriptionByManagementServiceTypeId(int managementServiceTypeId)
		{
			return this.IndexBy_ManagementServiceTypeId.LookupStringMember("Description", managementServiceTypeId);
		}

		/// <summary>
		///  Searches for Management Service Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchManagementServiceTypes", -1, this, false, code, description, active);
		}

		public override void LoadAll()
		{			
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllManagementServiceType", -1, this, false);
		}
	}
}