using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LengthOfStayRegions]
	/// </summary>
	[SPAutoGen("usp_GetAllLengthOfStayRegions","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetLengthOfStayRegionsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertLengthOfStayRegion")]
	[SPUpdate("usp_UpdateLengthOfStayRegion")]
	[SPDelete("usp_DeleteLengthOfStayRegion")]
	[SPLoad("usp_LoadLengthOfStayRegion")]
	[TableMapping("LengthOfStayRegion","hciaRegionid")]
	public class LengthOfStayRegion : BaseLookupWithSubCodeSTR
	{
		[NonSerialized]
		private LengthOfStayRegionCollection parentLengthOfStayRegionCollection;
		[ColumnMapping("HCIA_RegionId",StereoType=DataStereoType.FK)]
		private int hciaRegionid;
		[ColumnMapping("HCIA_Region")]
		private string hciaRegion;
		[ColumnMapping("Note")]
		private string note;
	
		public LengthOfStayRegion()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int HciaRegionid
		{
			get { return this.hciaRegionid; }
			set { this.hciaRegionid = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string HciaRegion
		{
			get { return this.hciaRegion; }
			set { this.hciaRegion = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[FieldValuesMember("ValueOf_SubCodeStr")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		[FieldDescription("@HCIAREGION@")]
		public override string SubCodeStr
		{
			get { return this.hciaRegion;}
			set	{ this.hciaRegion = value; }
		}

		public object [,] ValueOf_SubCodeStr
		{
			get
			{
				return new object[,] {{"N","Not Applicable"},{"8","Geriatrics"},{"2","North Central"},{"3","North East"},{"7","Pediatrics"},{"5","Southern"},{"6","United States"},{"4","Western"}};
			}
		}
		/// <summary>
		/// Parent LengthOfStayRegionCollection that contains this element
		/// </summary>
		public LengthOfStayRegionCollection ParentLengthOfStayRegionCollection
		{
			get
			{
				return this.parentLengthOfStayRegionCollection;
			}
			set
			{
				this.parentLengthOfStayRegionCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of LengthOfStayRegion objects
	/// </summary>
	[ElementType(typeof(LengthOfStayRegion))]
	public class LengthOfStayRegionCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_HciaRegion;
		[NonSerialized]
		private CollectionIndexer indexBy_HciaRegionid;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LengthOfStayRegion elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLengthOfStayRegionCollection = this;
			else
				elem.ParentLengthOfStayRegionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LengthOfStayRegion elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LengthOfStayRegion this[int index]
		{
			get
			{
				return (LengthOfStayRegion)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LengthOfStayRegion)oldValue, false);
			SetParentOnElem((LengthOfStayRegion)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadLengthOfStayRegionsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetLengthOfStayRegionsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared LengthOfStayRegionCollection which is cached in NSGlobal
		/// </summary>
		public static LengthOfStayRegionCollection ActiveLengthOfStayRegions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LengthOfStayRegionCollection col = (LengthOfStayRegionCollection)NSGlobal.EnsureCachedObject("ActiveLengthOfStayRegions", typeof(LengthOfStayRegionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadLengthOfStayRegionsByActive(-1, true);
				}
				return col;
			}
		}

		/// <summary>
		/// Hashtable based index on hciaRegionid fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_HciaRegionid
		{
			get
			{
				if (this.indexBy_HciaRegionid == null)
					this.indexBy_HciaRegionid = new CollectionIndexer(this, new string[] { "hciaRegionid" }, true);
				return this.indexBy_HciaRegionid;
			}
			
		}

		/// <summary>
		/// Looks up by hciaRegionid and returns HciaRegion value.  Uses the IndexBy_HciaRegionid indexer.
		/// </summary>
		public string Lookup_HciaRegionByHciaRegionid(int hciaRegionid)
		{
			return this.IndexBy_HciaRegionid.LookupStringMember("HciaRegion", hciaRegionid);
		}

		/// <summary>
		/// Hashtable based index on hciaRegion fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_HciaRegion
		{
			get
			{
				if (this.indexBy_HciaRegion == null)
					this.indexBy_HciaRegion = new CollectionIndexer(this, new string[] { "hciaRegion" }, true);
				return this.indexBy_HciaRegion;
			}
			
		}

		/// <summary>
		/// Looks up by hciaRegion and returns HciaRegionid value.  Uses the IndexBy_HciaRegion indexer.
		/// </summary>
		public int Lookup_HciaRegionidByHciaRegion(string hciaRegion)
		{
			return this.IndexBy_HciaRegion.LookupIntMember("HciaRegionid", hciaRegion);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllLengthOfStayRegions", -1, this, false);
		}

		/// <summary>
		/// Looks up by hciaRegionid and returns Code value.  Uses the IndexBy_HciaRegionid indexer.
		/// </summary>
		public string Lookup_CodeByHciaRegionid(int hciaRegionid)
		{
			return this.IndexBy_HciaRegionid.LookupStringMember("Code", hciaRegionid);
		}		
	}
}