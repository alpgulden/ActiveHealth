using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ReportUnit]
	/// </summary>
	[SPAutoGen("usp_GetReportUnitsByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllReportUnits","SelectAll.sptpl","")]
	[SPInsert("usp_InsertReportUnit")]
	[SPUpdate("usp_UpdateReportUnit")]
	[SPDelete("usp_DeleteReportUnit")]
	[SPLoad("usp_LoadReportUnit")]
	[TableMapping("ReportUnit","codeID")]
	public class ReportUnit : BaseLookupWithNote
	{
		[NonSerialized]
		private ReportUnitCollection parentReportUnitCollection;
		[ColumnMapping("CodeID",(int)0)]
		private int codeID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ReportUnit()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CodeID
		{
			get { return this.codeID; }
			set { this.codeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent ReportUnitCollection that contains this element
		/// </summary>
		public ReportUnitCollection ParentReportUnitCollection
		{
			get
			{
				return this.parentReportUnitCollection;
			}
			set
			{
				this.parentReportUnitCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ReportUnit objects
	/// </summary>
	[ElementType(typeof(ReportUnit))]
	public class ReportUnitCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ReportUnit elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentReportUnitCollection = this;
			else
				elem.ParentReportUnitCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ReportUnit elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ReportUnit this[int index]
		{
			get
			{
				return (ReportUnit)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ReportUnit)oldValue, false);
			SetParentOnElem((ReportUnit)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllReportUnits", -1, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadReportUnitsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetReportUnitsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ReportUnitCollection which is cached in NSGlobal
		/// </summary>
		public static ReportUnitCollection ActiveReportUnits
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ReportUnitCollection col = (ReportUnitCollection)NSGlobal.EnsureCachedObject("ActiveReportUnits", typeof(ReportUnitCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadReportUnitsByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
