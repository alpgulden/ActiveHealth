using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NameSuffix]
	/// </summary>
	/*[SPAutoGen("usp_GetNameSuffixesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertNameSuffix")]
	[SPUpdate("usp_UpdateNameSuffix")]
	[SPDelete("usp_DeleteNameSuffix")]
	[SPLoad("usp_LoadNameSuffix")]
	[TableMapping("NameSuffix","nameSuffixId")]
	public class NameSuffix : BaseData
	{
		[NonSerialized]
		private NameSuffixCollection parentNameSuffixCollection;
		[ColumnMapping("NameSuffixId",StereoType=DataStereoType.FK)]
		private int nameSuffixId;
		[ColumnMapping("Suffix")]
		private string suffix;
		[ColumnMapping("Active")]
		private bool active = true;
	
		public NameSuffix()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NameSuffixId
		{
			get { return this.nameSuffixId; }
			set { this.nameSuffixId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=16)]
		public string Suffix
		{
			get { return this.suffix; }
			set { this.suffix = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Parent NameSuffixCollection that contains this element
		/// </summary>
		public NameSuffixCollection ParentNameSuffixCollection
		{
			get
			{
				return this.parentNameSuffixCollection;
			}
			set
			{
				this.parentNameSuffixCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of NameSuffix objects
	/// </summary>
	[ElementType(typeof(NameSuffix))]
	public class NameSuffixCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_nameSuffixId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(NameSuffix elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNameSuffixCollection = this;
			else
				elem.ParentNameSuffixCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (NameSuffix elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public NameSuffix this[int index]
		{
			get
			{
				return (NameSuffix)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((NameSuffix)oldValue, false);
			SetParentOnElem((NameSuffix)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetNameSuffixesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetNameSuffixesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared NameSuffixCollection which is cached in NSGlobal
		/// </summary>
		public static NameSuffixCollection ActiveNameSuffixes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				NameSuffixCollection col = (NameSuffixCollection)NSGlobal.EnsureCachedObject("ActiveNameSuffixes", typeof(NameSuffixCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetNameSuffixesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on nameSuffixId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_nameSuffixId
		{
			get
			{
				if (this.indexBy_nameSuffixId == null)
					this.indexBy_nameSuffixId = new CollectionIndexer(this, new string[] { "nameSuffixId" }, true);
				return this.indexBy_nameSuffixId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on nameSuffixId fields returns the object.  Uses the IndexBy_nameSuffixId indexer.
		/// </summary>
		public NameSuffix FindBy(int nameSuffixId)
		{
			return (NameSuffix)this.IndexBy_nameSuffixId.GetObject(nameSuffixId);
		}
	}*/
}
