using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SystemStatus]
	/// </summary>
	[SPAutoGen("usp_SearchSystemStatusesByCodeDescriptionActive","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_LoadSystemStatusesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_LoadAllSystemStatuses","SelectAll.sptpl","")]
	[SPInsert("usp_InsertSystemStatus")]
	[SPUpdate("usp_UpdateSystemStatus")]
	[SPDelete("usp_DeleteSystemStatus")]
	[SPLoad("usp_LoadSystemStatus")]
	[TableMapping("SystemStatus","statusId")]
	public class SystemStatus : BaseLookupWithSubCodeSTR
	{
		public const string CLOSED = "CLOS";
		public const string CANCELLED = "CANL";
		public const string DECLINED = "DECL";
		public const string OPEN = "OPEN";

		[NonSerialized]
		private SystemStatusCollection parentSystemStatusCollection;
		[ColumnMapping("StatusId",StereoType=DataStereoType.FK)]
		private int statusId;
		[ColumnMapping("DisplayCode")]
		private string displayCode;
		[ColumnMapping("CodeStatus")]
		private string codeStatus;
		[ColumnMapping("NotePad")]
		private string notePad;

		public SystemStatus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int StatusId
		{
			get { return this.statusId; }
			set { this.statusId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

	
		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Parent SystemStatusCollection that contains this element
		/// </summary>
		public SystemStatusCollection ParentSystemStatusCollection
		{
			get
			{
				return this.parentSystemStatusCollection;
			}
			set
			{
				this.parentSystemStatusCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string CodeStatus
		{
			get { return this.codeStatus; }
			set { this.codeStatus = value; }
		}

		[FieldValuesMember("LookupOf_SubCodeStr", "Code", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		[FieldDescription("@CODESTATUS@")]
		public override string SubCodeStr
		{
			get { return this.codeStatus; }
			set { this.codeStatus = value; }
		}

		public FunctionalStatusCollection LookupOf_SubCodeStr
		{
			get
			{
				return FunctionalStatusCollection.AllFunctionalStatusCodes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of SystemStatus objects
	/// </summary>
	[ElementType(typeof(SystemStatus))]
	public class SystemStatusCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		[NonSerialized]
		private CollectionIndexer indexBy_StatusId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SystemStatus elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSystemStatusCollection = this;
			else
				elem.ParentSystemStatusCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SystemStatus elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SystemStatus this[int index]
		{
			get
			{
				return (SystemStatus)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SystemStatus)oldValue, false);
			SetParentOnElem((SystemStatus)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadSystemStatusesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadSystemStatusesByActive", maxRecords, this, false, new object[] { active} );
		}

		/// <summary>
		/// Accessor to a shared SystemStatusCollection which is cached in NSGlobal
		/// </summary>
		public static SystemStatusCollection ActiveSystemStatuses
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				SystemStatusCollection col = (SystemStatusCollection)NSGlobal.EnsureCachedObject("ActiveSystemStatuses", typeof(SystemStatusCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadSystemStatusesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchSystemStatusesByCodeDescriptionActive(int maxRecords, string code, string description, bool active)
		{
			//this.Clear();
			return SqlData.SPExecReadCol("usp_SearchSystemStatusesByCodeDescriptionActive", maxRecords, this, false, new object[] { code == null ? DBNull.Value : (object)code , description == null ? DBNull.Value : (object)description , active ? (object)true : DBNull.Value });
		}

		

		/// <summary>
		/// Hashtable based index on statusId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_StatusId
		{
			get
			{
				if (this.indexBy_StatusId == null)
					this.indexBy_StatusId = new CollectionIndexer(this, new string[] { "statusId" }, true);
				return this.indexBy_StatusId;
			}
			
		}

		/// <summary>
		/// Looks up by statusId and returns Code value.  Uses the IndexBy_StatusId indexer.
		/// </summary>
		public string Lookup_CodeByStatusId(int statusId)
		{
			return this.IndexBy_StatusId.LookupStringMember("Code", statusId);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns StatusId value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_StatusIdByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("StatusId", code);
		}

		/// <summary>
		/// Looks up by statusId and returns Description value.  Uses the IndexBy_StatusId indexer.
		/// </summary>
		public string Lookup_DescriptionByStatusId(int statusId)
		{
			return this.IndexBy_StatusId.LookupStringMember("Description", statusId);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_LoadAllSystemStatuses", -1, this, false);
		}
	}
}
