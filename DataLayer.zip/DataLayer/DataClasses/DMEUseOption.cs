using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [DMEUseOption]
	/// </summary>
	[SPAutoGen("usp_GetAllDMEUseOption","SelectAll.sptpl","")]
	[SPDelete("usp_DeleteDMEUseOption")]
	[SPAutoGen("usp_GetAllDMEUseOptionBeActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertDMEUseOption")]
	[SPUpdate("usp_UpdateDMEUseOption")]
	[SPLoad("usp_LoadDMEUseOption")]
	[TableMapping("DMEUseOption","dMEUseOptionID")]
	public class DMEUseOption : BaseLookupWithNote
	{
		[NonSerialized]
		private DMEUseOptionCollection parentDMEUseOptionCollection;
		[ColumnMapping("DMEUseOptionID",(int)0)]
		private int dMEUseOptionID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public DMEUseOption()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int DMEUseOptionID
		{
			get { return this.dMEUseOptionID; }
			set { this.dMEUseOptionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent DMEUseOptionCollection that contains this element
		/// </summary>
		public DMEUseOptionCollection ParentDMEUseOptionCollection
		{
			get
			{
				return this.parentDMEUseOptionCollection;
			}
			set
			{
				this.parentDMEUseOptionCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of DMEUseOption objects
	/// </summary>
	[ElementType(typeof(DMEUseOption))]
	public class DMEUseOptionCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(DMEUseOption elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentDMEUseOptionCollection = this;
			else
				elem.ParentDMEUseOptionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (DMEUseOption elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public DMEUseOption this[int index]
		{
			get
			{
				return (DMEUseOption)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((DMEUseOption)oldValue, false);
			SetParentOnElem((DMEUseOption)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns DMEUseOptionID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_DMEUseOptionIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("DMEUseOptionID", code);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllDMEUseOptionBeActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllDMEUseOptionBeActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared DMEUseOptionCollection which is cached in NSGlobal
		/// </summary>
		public static DMEUseOptionCollection ActiveDMEUseOptions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				DMEUseOptionCollection col = (DMEUseOptionCollection)NSGlobal.EnsureCachedObject("ActiveDMEUseOptions", typeof(DMEUseOptionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllDMEUseOptionBeActive(-1, true);
				}
				return col;
			}			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllDMEUseOption", -1, this, false);
		}
	}
}
