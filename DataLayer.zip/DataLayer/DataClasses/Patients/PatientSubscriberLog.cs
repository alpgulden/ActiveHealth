using System;
using System.Data.SqlClient;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientSubscriberLog]
	/// Inserts log entries into the PatientSubscriberLog and also the PatientCoveragePCPLog table.
	/// No update, delete allowed.
	/// </summary>
	[SPAutoGen("usp_GetLastPatientSubscriberLogID","SelectTop1PK.sptpl","patientSubscriberLogId, DESC, patientId, patientCoverageID")]
	[SPAutoGen("usp_GetLastPatientSubscriberLogEntry","SelectTop1.sptpl","patientSubscriberLogId, DESC, patientId, patientCoverageID")]
	[SPInsert("usp_InsertPatientSubscriberLog")]
	[SPUpdate("usp_UpdatePatientSubscriberLog")]
	[SPDelete("usp_DeletePatientSubscriberLog")]
	[SPLoad("usp_LoadPatientSubscriberLog")]
	[TableMapping("PatientSubscriberLog","patientSubscriberLogId")]
	public class PatientSubscriberLog : BaseData
	{
		#region Log specific fields

		[ColumnMapping("PatientSubscriberLogId",StereoType=DataStereoType.FK)][Copiable(false)]
		private int patientSubscriberLogId;
		[ColumnMapping("CreationDate", InjectInsert="getDate()")][Copiable(false)]
		private DateTime creationDate;

		#endregion

		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		private int patientId;
		[ColumnMapping("PatientRelationshipId",StereoType=DataStereoType.FK)]
		private int patientRelationshipId;
		[ColumnMapping("AlternateGroupId")]
		private string alternateGroupId;
		[ColumnMapping("AlternateInsuranceId")]
		private string alternateInsuranceId;
		[ColumnMapping("PatientAlternateId")]
		private string patientAlternateId;
		[ColumnMapping("PatientFirstName")]
		private string patientFirstName;
		[ColumnMapping("PatientLastName")]
		private string patientLastName;
		[ColumnMapping("PatientMiddleInitial")]
		private string patientMiddleInitial;
		[ColumnMapping("PatientNamePrefixId",StereoType=DataStereoType.FK)]
		private int patientNamePrefixId;
		[ColumnMapping("PatientDOB")]
		private DateTime patientDOB;
		[ColumnMapping("PatientSSN")]
		private string patientSSN;
		[ColumnMapping("PatientGender")]
		private string patientGender;
		[ColumnMapping("PatientAddress1")]
		private string patientAddress1;
		[ColumnMapping("PatientAddress2")]
		private string patientAddress2;
		[ColumnMapping("PatientAddress3")]
		private string patientAddress3;
		[ColumnMapping("PatientCity")]
		private string patientCity;
		[ColumnMapping("PatientState")]
		private string patientState;
		[ColumnMapping("PatientZip")]
		private string patientZip;
		[ColumnMapping("PatientCounty")]
		private string patientCounty;
		[ColumnMapping("PatientCountry")]
		private string patientCountry;
		[ColumnMapping("PatientHomePhone")]
		private string patientHomePhone;
		[ColumnMapping("PatientWorkPhone")]
		private string patientWorkPhone;
		[ColumnMapping("PatientWorkExtension")]
		private string patientWorkExtension;
		[ColumnMapping("PatientFaxPhone")]
		private string patientFaxPhone;
		[ColumnMapping("PatientFaxExtension")]
		private string patientFaxExtension;
		[ColumnMapping("PatientEmail")]
		private string patientEmail;
		[ColumnMapping("PatientAssignedUserId",StereoType=DataStereoType.FK)]
		private int patientAssignedUserId;
		[ColumnMapping("PatientAssignedTeamId",StereoType=DataStereoType.FK)]
		private int patientAssignedTeamId;
		[ColumnMapping("PatientMedicaidId")]
		private string patientMedicaidId;
		[ColumnMapping("PatientMedicareId")]
		private string patientMedicareId;
		[ColumnMapping("PatientCreatedByUserId",StereoType=DataStereoType.FK)]
		private int patientCreatedByUserId;
		[ColumnMapping("PatientCreationDate")]
		private DateTime patientCreationDate;
		[ColumnMapping("PatientModifiedByUserId",StereoType=DataStereoType.FK)]
		private int patientModifiedByUserId;
		[ColumnMapping("PatientModificationDate")]
		private DateTime patientModificationDate;
		[ColumnMapping("PatientUDEF1")]
		private string patientUDEF1;
		[ColumnMapping("PatientUDEF2")]
		private string patientUDEF2;
		[ColumnMapping("PatientUDEF3")]
		private string patientUDEF3;
		[ColumnMapping("PatientUDEF4")]
		private string patientUDEF4;
		[ColumnMapping("PatientUDEF5")]
		private string patientUDEF5;
		[ColumnMapping("PatientUDEF6")]
		private string patientUDEF6;
		[ColumnMapping("PatientUDEF7")]
		private string patientUDEF7;
		[ColumnMapping("PatientUDEF8")]
		private string patientUDEF8;
		[ColumnMapping("PatientUDEF9")]
		private string patientUDEF9;
		[ColumnMapping("PatientUDEF10")]
		private string patientUDEF10;
		[ColumnMapping("PatientUDEF11")]
		private string patientUDEF11;
		[ColumnMapping("PatientUDEF12")]
		private string patientUDEF12;
		[ColumnMapping("PatientUDEF13")]
		private string patientUDEF13;
		[ColumnMapping("PatientUDEF14")]
		private string patientUDEF14;
		[ColumnMapping("SubscriberId",StereoType=DataStereoType.FK)]
		private int subscriberId;
		[ColumnMapping("AlternateSubscriberId")]
		private string alternateSubscriberId;
		[ColumnMapping("SubscriberLastName")]
		private string subscriberLastName;
		[ColumnMapping("SubscriberNamePrefixId",StereoType=DataStereoType.FK)]
		private int subscriberNamePrefixId;
		[ColumnMapping("SubscriberFirstName")]
		private string subscriberFirstName;
		[ColumnMapping("SubscriberMiddleInitial")]
		private string subscriberMiddleInitial;
		[ColumnMapping("SubscriberDOB")]
		private DateTime subscriberDOB;
		[ColumnMapping("SubscriberSSN")]
		private string subscriberSSN;
		[ColumnMapping("SubscriberGender")]
		private string subscriberGender;
		[ColumnMapping("SubscriberCreatedByUserId",StereoType=DataStereoType.FK)]
		private int subscriberCreatedByUserId;
		[ColumnMapping("SubscriberCreationDate")]
		private DateTime subscriberCreationDate;
		[ColumnMapping("SubscriberModifiedByUserId",StereoType=DataStereoType.FK)]
		private int subscriberModifiedByUserId;
		[ColumnMapping("SubscriberModificationDate")]
		private DateTime subscriberModificationDate;
		[ColumnMapping("SubscriberAssignedUserId",StereoType=DataStereoType.FK)]
		private int subscriberAssignedUserId;
		[ColumnMapping("SubscriberAssignedTeamId",StereoType=DataStereoType.FK)]
		private int subscriberAssignedTeamId;
		[ColumnMapping("SubscriberUDEF1")]
		private string subscriberUDEF1;
		[ColumnMapping("SubscriberUDEF2")]
		private string subscriberUDEF2;
		[ColumnMapping("SubscriberUDEF3")]
		private string subscriberUDEF3;
		[ColumnMapping("SubscriberUDEF4")]
		private string subscriberUDEF4;
		[ColumnMapping("SubscriberUDEF5")]
		private string subscriberUDEF5;
		[ColumnMapping("SubscriberUDEF6")]
		private string subscriberUDEF6;
		[ColumnMapping("SubscriberUDEF7")]
		private string subscriberUDEF7;
		[ColumnMapping("SubscriberUDEF8")]
		private string subscriberUDEF8;
		[ColumnMapping("SubscriberUDEF9")]
		private string subscriberUDEF9;
		[ColumnMapping("SubscriberUDEF10")]
		private string subscriberUDEF10;
		[ColumnMapping("SubscriberUDEF11")]
		private string subscriberUDEF11;
		[ColumnMapping("SubscriberUDEF12")]
		private string subscriberUDEF12;
		[ColumnMapping("SubscriberUDEF13")]
		private string subscriberUDEF13;
		[ColumnMapping("SubscriberUDEF14")]
		private string subscriberUDEF14;
		//[ColumnMapping("SubscriberAssignedUserId",StereoType=DataStereoType.FK)]
		//private int subscriberAssignedUserId;
		//[ColumnMapping("SubscriberAssignedTeamId",StereoType=DataStereoType.FK)]
		//private int subscriberAssignedTeamId;
		[ColumnMapping("SubscriberNotePad")]
		private string subscriberNotePad;
		[ColumnMapping("SubscriberAddress1")]
		private string subscriberAddress1;
		[ColumnMapping("SubscriberAddress2")]
		private string subscriberAddress2;
		[ColumnMapping("SubscriberAddress3")]
		private string subscriberAddress3;
		[ColumnMapping("SubscriberCity")]
		private string subscriberCity;
		[ColumnMapping("SubscriberState")]
		private string subscriberState;
		[ColumnMapping("SubscriberZip")]
		private string subscriberZip;
		[ColumnMapping("SubscriberCounty")]
		private string subscriberCounty;
		[ColumnMapping("SubscriberCountry")]
		private string subscriberCountry;
		[ColumnMapping("SubscriberHomePhone")]
		private string subscriberHomePhone;
		[ColumnMapping("SubscriberWorkPhone")]
		private string subscriberWorkPhone;
		[ColumnMapping("SubscriberWorkPhoneExtension")]
		private string subscriberWorkPhoneExtension;
		[ColumnMapping("SubscriberFaxPhone")]
		private string subscriberFaxPhone;
		[ColumnMapping("SubscriberFaxPhoneExtension")]
		private string subscriberFaxPhoneExtension;
		[ColumnMapping("SubscriberEmail")]
		private string subscriberEmail;
		[ColumnMapping("SubscriberNameSuffix")]
		private string subscriberNameSuffix;
		[ColumnMapping("PatientNameSuffix")]
		private string patientNameSuffix;
		[ColumnMapping("PatientRelatedProblemID",StereoType=DataStereoType.FK)]	// don't know the source!
		private int patientRelatedProblemID;
		[ColumnMapping("PatientRelatedEventID",StereoType=DataStereoType.FK)]		// don't know the source!
		private int patientRelatedEventID;
		[ColumnMapping("PatientAsOfDate")]
		private DateTime patientAsOfDate;
		//[ColumnMapping("AlternateMemberID")]
		//private string alternateMemberID;
		[ColumnMapping("PatientSubscriberRelationshipID",StereoType=DataStereoType.FK)]
		private int patientSubscriberRelationshipID;
		[ColumnMapping("OtherPlan")]
		private bool otherPlan;
		[ColumnMapping("SubscriberAsOfDate")]
		private DateTime subscriberAsOfDate;
		[ColumnMapping("SORGId")]
		private int sORGId;
		[ColumnMapping("PlanId")]
		private int planId;
		[ColumnMapping("SubscriberCoverageIsPrimary")]
		private bool subscriberCoverageIsPrimary;
		[ColumnMapping("SubscriberCoverageCreatedBy")]
		private int subscriberCoverageCreatedBy;
		[ColumnMapping("SubscriberCoverageCreateTime")]
		private DateTime subscriberCoverageCreateTime;
		[ColumnMapping("SubscriberCoverageModifyTime")]
		private DateTime subscriberCoverageModifyTime;
		[ColumnMapping("SubscriberCoverageModifiedBy")]
		private int subscriberCoverageModifiedBy;
		[ColumnMapping("PatientEligibilityID",StereoType=DataStereoType.FK)]
		private int patientEligibilityID;
		[ColumnMapping("SubscriberEligibilityID",StereoType=DataStereoType.FK)]
		private int subscriberEligibilityID;
		[ColumnMapping("PatientCoverageID",StereoType=DataStereoType.FK)]
		private int patientCoverageID;
		[ColumnMapping("PatientCoverageDataID",StereoType=DataStereoType.FK)]
		private int patientCoverageDataID;
		[ColumnMapping("EnrollmentID",StereoType=DataStereoType.FK)]
		private int enrollmentID;

		private Organization sorg;
		private PatientCoveragePCPLogCollection patientCoveragePCPLogEntries;		// loaded and cached sorg object
		private PatientCoverage patientCoverage;					// loaded and cached patient coverage
		private Plan plan;
	
		public PatientSubscriberLog()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Organization GetSORG()
		{
			if (this.sORGId == 0)
				return null;
			Organization sorg = new Organization();
			sorg.SqlData.Transaction = this.SqlData.Transaction;
			if (sorg.Load(this.sORGId))
				return sorg;
			else
				return null;
		}

		public Organization SORG
		{
			get
			{
				if (this.sorg == null)
					this.sorg = GetSORG();
				return this.sorg;
			}
		}

		public string PlanName
		{
			get 
			{
				if (this.Plan == null)
					return null;				// no plan.
				return this.Plan.Name; 
			}
		}

		/// <summary>
		/// Loads and returns the associated Plan.
		/// </summary>
		/// <returns></returns>
		public Plan GetPlan()
		{
			if (this.planId == 0)
				return null;
			Plan plan = new Plan();
			plan.SqlData.Transaction = this.SqlData.Transaction;
			if (plan.Load(this.planId))
				return plan;
			else
				return null;
		}

		/// <summary>
		/// Returns the linked plan object.  
		/// </summary>
		public Plan Plan
		{
			get
			{
				if (this.plan == null)
				{
					this.plan = GetPlan();
				}
				return this.plan;
			}
		}


		/// <summary>
		/// Creates a Patient Subscriber Log object for the given context.
		/// </summary>
		/// <param name="pat"></param>
		/// <param name="subs"></param>
		/// <param name="subsCov"></param>
		/// <param name="subsCov"></param>
		/// <param name="patCov"></param>
		public PatientSubscriberLog(Patient pat, Subscriber subs, PatientCoverageData patCovData, PatientCoverage patCov)
		{
			this.NewRecord();
			this.patientId = pat.PatientId;
			this.patientRelationshipId = patCov.RelationShipID;
			this.alternateGroupId = patCov.AlternateGroupID;
			this.alternateInsuranceId = patCov.AlternateInsuranceID;
			this.patientAlternateId = patCov.AlternatePatientID;
			this.enrollmentID = patCov.EnrollmentID;
			this.patientFirstName = pat.FirstName;
			this.patientLastName = pat.LastName;
			this.patientMiddleInitial = pat.MiddleInitial;
			this.patientNamePrefixId = pat.NamePrefixId;
			this.patientDOB = pat.DateOfBirth;
			this.patientSSN = pat.SocialSecurityNumber;
			this.patientGender = pat.Gender;
			this.patientAddress1 = pat.Address.Line1;
			this.patientAddress2 = pat.Address.Line2;
			this.patientAddress3 = pat.Address.Line3;
			this.patientCity = pat.Address.City;
			this.patientState = pat.Address.State;
			this.patientZip = pat.Address.Zip;
			this.patientCounty = pat.Address.County;
			this.patientCountry = pat.Address.Country;
			this.patientHomePhone = pat.Address.PhoneNumber1;
			this.patientWorkPhone = pat.Address.PhoneNumber2;
			this.patientWorkExtension = pat.Address.PhoneExt2;
			this.patientFaxPhone = pat.Address.FaxNumber;
			this.patientFaxExtension = pat.Address.FaxExtension;
			this.patientEmail = pat.Address.Email;
			this.patientAssignedUserId = pat.AssignedUserId;
			this.patientAssignedTeamId = pat.AssignedTeamId;
			this.patientMedicaidId = subs.MedicaidID;
			this.patientMedicareId = subs.MedicareID;
			this.patientCreatedByUserId = pat.CreatedBy;
			this.patientCreationDate = pat.CreateTime;
			this.patientModifiedByUserId = pat.ModifiedBy;
			this.patientModificationDate = pat.ModifyTime;
			this.subscriberId = subs.SubscriberId;
			this.alternateSubscriberId = patCov.AlternateSubscriberID;
			this.subscriberLastName = subs.LastName;
			this.subscriberNamePrefixId = subs.NamePrefixId;
			this.subscriberFirstName = subs.FirstName;
			this.subscriberMiddleInitial = subs.MiddleInitial;
			this.subscriberDOB = subs.DateOfBirth;
			this.subscriberSSN = subs.SocialSecurityNumber;
			this.subscriberGender = subs.Gender;
			this.subscriberCreatedByUserId = subs.CreatedBy;
			this.subscriberCreationDate = subs.CreateTime;
			this.subscriberModifiedByUserId = subs.ModifiedBy;
			this.subscriberModificationDate = subs.ModifyTime;
			//this.subscriberAssignedUserId = don't exist
			//this.subscriberAssignedTeamId = don't exist
			//this.subscriberNotePad = don't exist
			this.subscriberAddress1 = subs.Address.Line1;
			this.subscriberAddress2 = subs.Address.Line2;
			this.subscriberAddress3 = subs.Address.Line3;
			this.subscriberCity = subs.Address.City;
			this.subscriberState = subs.Address.State;
			this.subscriberZip = subs.Address.Zip;
			this.subscriberCounty = subs.Address.County;
			this.subscriberCountry = subs.Address.Country;
			this.subscriberHomePhone = subs.Address.PhoneNumber1;
			this.subscriberWorkPhone = subs.Address.PhoneNumber2;
			this.subscriberWorkPhoneExtension = subs.Address.PhoneExt2;
			this.subscriberFaxPhone = subs.Address.FaxNumber;
			this.subscriberFaxPhoneExtension = subs.Address.FaxExtension;
			this.subscriberEmail = subs.Address.Email;
			this.subscriberNameSuffix = subs.NameSuffix;
			this.patientNameSuffix = pat.NameSuffix;
			//this.patientRelatedProblemID = don't know source!
			//this.patientRelatedEventID = don't know source!
			this.patientAsOfDate = pat.AsOfDate;
			//this.alternateMemberID = don't know source!
			this.patientSubscriberRelationshipID = patCov.RelationShipID;	// the same as patientRelationshipId

			this.subscriberAsOfDate = subs.AsOfDate;
			this.patientCoverageID = patCov.PatientCoverageID;
			this.sORGId = patCov.SORGID;
			this.planId = patCov.PlanID;
			this.subscriberCoverageIsPrimary = patCov.IsPrimary;
			this.subscriberCoverageCreatedBy = patCov.CreatedBy;
			this.subscriberCoverageCreateTime = patCov.CreateTime;
			this.subscriberCoverageModifyTime = patCov.ModifyTime;
			this.subscriberCoverageModifiedBy = patCov.ModifiedBy;
			this.subscriberEligibilityID = patCov.SubscriberEligibilityID;
			this.patientEligibilityID = patCov.PatientEligibilityID;
			this.patientCoverageDataID = patCovData.PatientCoverageDataID;

			// User defineds
			this.patientUDEF1 = pat.UserDefined.UDEF1;
			this.patientUDEF2 = pat.UserDefined.UDEF2;
			this.patientUDEF3 = pat.UserDefined.UDEF3;
			this.patientUDEF4 = pat.UserDefined.UDEF4;
			this.patientUDEF5 = pat.UserDefined.UDEF5;
			this.patientUDEF6 = pat.UserDefined.UDEF6;
			this.patientUDEF7 = pat.UserDefined.UDEF7;
			this.patientUDEF8 = pat.UserDefined.UDEF8;
			this.patientUDEF9 = pat.UserDefined.UDEF9;
			this.patientUDEF10 = pat.UserDefined.UDEF10;
			this.patientUDEF11 = pat.UserDefined.UDEF11;
			this.patientUDEF12 = pat.UserDefined.UDEF12;
			this.patientUDEF13 = pat.UserDefined.UDEF13;
			this.patientUDEF14 = pat.UserDefined.UDEF14;

			this.subscriberUDEF1 = subs.UserDefined.UDEF1;
			this.subscriberUDEF2 = subs.UserDefined.UDEF2;
			this.subscriberUDEF3 = subs.UserDefined.UDEF3;
			this.subscriberUDEF4 = subs.UserDefined.UDEF4;
			this.subscriberUDEF5 = subs.UserDefined.UDEF5;
			this.subscriberUDEF6 = subs.UserDefined.UDEF6;
			this.subscriberUDEF7 = subs.UserDefined.UDEF7;
			this.subscriberUDEF8 = subs.UserDefined.UDEF8;
			this.subscriberUDEF9 = subs.UserDefined.UDEF9;
			this.subscriberUDEF10 = subs.UserDefined.UDEF10;
			this.subscriberUDEF11 = subs.UserDefined.UDEF11;
			this.subscriberUDEF12 = subs.UserDefined.UDEF12;
			this.subscriberUDEF13 = subs.UserDefined.UDEF13;
			this.subscriberUDEF14 = subs.UserDefined.UDEF14;

			// import PCP records
			patCov.LoadPatientCoveragePCPs(false);
			this.LoadPatientCoveragePCPLogEntries(false);
			
			for (int i = 0; i < patCov.PatientCoveragePCPs.Count; i++)
			{
				// import members of patient coverage pcp
				PatientCoveragePCP pcp = patCov.PatientCoveragePCPs[i];
				PatientCoveragePCPLog pcpLog = new PatientCoveragePCPLog(true);

				// set the members
				pcpLog.AsOfDate = pcp.AsOfDate;
				pcpLog.ProviderID = pcp.PCPID;
				pcpLog.LocationID = pcp.ProviderLocationID;
				//pcpLog.ProviderStatusID = pcp.Status;			// provider status is not a in the log
				if (pcp.Provider != null)
					pcpLog.AlternateProviderID = pcp.Provider.AlternateID;
				if (pcp.ProviderLocation != null)
					pcpLog.AlternateLocationID = pcp.ProviderLocation.AlternateID;
				pcpLog.EffectiveDate = pcp.EffectiveDate;
				pcpLog.TerminationDate = pcp.TerminationDate;
				pcpLog.SpecialtyID = pcp.ProviderSpecialtyTypeID;

				// add
				this.PatientCoveragePCPLogEntries.Add(pcpLog);
			}

		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientSubscriberLogId
		{
			get { return this.patientSubscriberLogId; }
			set { this.patientSubscriberLogId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreationDate
		{
			get { return this.creationDate; }
			set { this.creationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientRelationshipId
		{
			get { return this.patientRelationshipId; }
			set { this.patientRelationshipId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateGroupId
		{
			get { return this.alternateGroupId; }
			set { this.alternateGroupId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateInsuranceId
		{
			get { return this.alternateInsuranceId; }
			set { this.alternateInsuranceId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PatientAlternateId
		{
			get { return this.patientAlternateId; }
			set { this.patientAlternateId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=16)]
		public string PatientFirstName
		{
			get { return this.patientFirstName; }
			set { this.patientFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string PatientLastName
		{
			get { return this.patientLastName; }
			set { this.patientLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string PatientMiddleInitial
		{
			get { return this.patientMiddleInitial; }
			set { this.patientMiddleInitial = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientNamePrefixId
		{
			get { return this.patientNamePrefixId; }
			set { this.patientNamePrefixId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PatientDOB
		{
			get { return this.patientDOB; }
			set { this.patientDOB = value; }
		}

		public string PatientSSN
		{
			get { return this.patientSSN; }
			set { this.patientSSN = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string PatientGender
		{
			get { return this.patientGender; }
			set { this.patientGender = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientAddress1
		{
			get { return this.patientAddress1; }
			set { this.patientAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientAddress2
		{
			get { return this.patientAddress2; }
			set { this.patientAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientAddress3
		{
			get { return this.patientAddress3; }
			set { this.patientAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientCity
		{
			get { return this.patientCity; }
			set { this.patientCity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string PatientState
		{
			get { return this.patientState; }
			set { this.patientState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string PatientZip
		{
			get { return this.patientZip; }
			set { this.patientZip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PatientCounty
		{
			get { return this.patientCounty; }
			set { this.patientCounty = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PatientCountry
		{
			get { return this.patientCountry; }
			set { this.patientCountry = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string PatientHomePhone
		{
			get { return this.patientHomePhone; }
			set { this.patientHomePhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string PatientWorkPhone
		{
			get { return this.patientWorkPhone; }
			set { this.patientWorkPhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string PatientWorkExtension
		{
			get { return this.patientWorkExtension; }
			set { this.patientWorkExtension = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string PatientFaxPhone
		{
			get { return this.patientFaxPhone; }
			set { this.patientFaxPhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string PatientFaxExtension
		{
			get { return this.patientFaxExtension; }
			set { this.patientFaxExtension = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string PatientEmail
		{
			get { return this.patientEmail; }
			set { this.patientEmail = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientAssignedUserId
		{
			get { return this.patientAssignedUserId; }
			set { this.patientAssignedUserId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientAssignedTeamId
		{
			get { return this.patientAssignedTeamId; }
			set { this.patientAssignedTeamId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string PatientMedicaidId
		{
			get { return this.patientMedicaidId; }
			set { this.patientMedicaidId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string PatientMedicareId
		{
			get { return this.patientMedicareId; }
			set { this.patientMedicareId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientCreatedByUserId
		{
			get { return this.patientCreatedByUserId; }
			set { this.patientCreatedByUserId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime PatientCreationDate
		{
			get { return this.patientCreationDate; }
			set { this.patientCreationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientmodifiedByUserId
		{
			get { return this.patientModifiedByUserId; }
			set { this.patientModifiedByUserId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PatientModificationDate
		{
			get { return this.patientModificationDate; }
			set { this.patientModificationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberId
		{
			get { return this.subscriberId; }
			set { this.subscriberId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public string AlternateSubscriberId
		{
			get { return this.alternateSubscriberId; }
			set { this.alternateSubscriberId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string SubscriberLastName
		{
			get { return this.subscriberLastName; }
			set { this.subscriberLastName = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberNamePrefixId
		{
			get { return this.subscriberNamePrefixId; }
			set { this.subscriberNamePrefixId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=16)]
		public string SubscriberFirstName
		{
			get { return this.subscriberFirstName; }
			set { this.subscriberFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string SubscriberMiddleInitial
		{
			get { return this.subscriberMiddleInitial; }
			set { this.subscriberMiddleInitial = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime SubscriberDOB
		{
			get { return this.subscriberDOB; }
			set { this.subscriberDOB = value; }
		}

		public string SubscriberSSN
		{
			get { return this.subscriberSSN; }
			set { this.subscriberSSN = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string SubscriberGender
		{
			get { return this.subscriberGender; }
			set { this.subscriberGender = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberCreatedByUserId
		{
			get { return this.subscriberCreatedByUserId; }
			set { this.subscriberCreatedByUserId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime SubscriberCreationDate
		{
			get { return this.subscriberCreationDate; }
			set { this.subscriberCreationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberModifiedByUserId
		{
			get { return this.subscriberModifiedByUserId; }
			set { this.subscriberModifiedByUserId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime SubscriberModificationDate
		{
			get { return this.subscriberModificationDate; }
			set { this.subscriberModificationDate = value; }
		}

		/*[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberAssignedUserId
		{
			get { return this.subscriberAssignedUserId; }
			set { this.subscriberAssignedUserId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberAssignedTeamId
		{
			get { return this.subscriberAssignedTeamId; }
			set { this.subscriberAssignedTeamId = value; }
		}*/

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string SubscriberNotePad
		{
			get { return this.subscriberNotePad; }
			set { this.subscriberNotePad = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberAddress1
		{
			get { return this.subscriberAddress1; }
			set { this.subscriberAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberAddress2
		{
			get { return this.subscriberAddress2; }
			set { this.subscriberAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberAddress3
		{
			get { return this.subscriberAddress3; }
			set { this.subscriberAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberCity
		{
			get { return this.subscriberCity; }
			set { this.subscriberCity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string SubscriberState
		{
			get { return this.subscriberState; }
			set { this.subscriberState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string SubscriberZip
		{
			get { return this.subscriberZip; }
			set { this.subscriberZip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SubscriberCounty
		{
			get { return this.subscriberCounty; }
			set { this.subscriberCounty = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SubscriberCountry
		{
			get { return this.subscriberCountry; }
			set { this.subscriberCountry = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string SubscriberHomePhone
		{
			get { return this.subscriberHomePhone; }
			set { this.subscriberHomePhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string SubscriberWorkPhone
		{
			get { return this.subscriberWorkPhone; }
			set { this.subscriberWorkPhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string SubscriberWorkPhoneExtension
		{
			get { return this.subscriberWorkPhoneExtension; }
			set { this.subscriberWorkPhoneExtension = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string SubscriberFaxPhone
		{
			get { return this.subscriberFaxPhone; }
			set { this.subscriberFaxPhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string SubscriberFaxPhoneExtension
		{
			get { return this.subscriberFaxPhoneExtension; }
			set { this.subscriberFaxPhoneExtension = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string SubscriberEmail
		{
			get { return this.subscriberEmail; }
			set { this.subscriberEmail = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string SubscriberNameSuffix
		{
			get { return this.subscriberNameSuffix; }
			set { this.subscriberNameSuffix = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string PatientNameSuffix
		{
			get { return this.patientNameSuffix; }
			set { this.patientNameSuffix = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientRelatedProblemID
		{
			get { return this.patientRelatedProblemID; }
			set { this.patientRelatedProblemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientRelatedEventID
		{
			get { return this.patientRelatedEventID; }
			set { this.patientRelatedEventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PatientAsOfDate
		{
			get { return this.patientAsOfDate; }
			set { this.patientAsOfDate = value; }
		}

		/*[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateMemberID
		{
			get { return this.alternateMemberID; }
			set { this.alternateMemberID = value; }
		}*/

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientSubscriberRelationshipID
		{
			get { return this.patientSubscriberRelationshipID; }
			set { this.patientSubscriberRelationshipID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool OtherPlan
		{
			get { return this.otherPlan; }
			set { this.otherPlan = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime SubscriberAsOfDate
		{
			get { return this.subscriberAsOfDate; }
			set { this.subscriberAsOfDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGId
		{
			get { return this.sORGId; }
			set 
			{
				this.sORGId = value; 
				this.sorg = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool SubscriberCoverageIsPrimary
		{
			get { return this.subscriberCoverageIsPrimary; }
			set { this.subscriberCoverageIsPrimary = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberCoverageCreatedBy
		{
			get { return this.subscriberCoverageCreatedBy; }
			set { this.subscriberCoverageCreatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime SubscriberCoverageCreateTime
		{
			get { return this.subscriberCoverageCreateTime; }
			set { this.subscriberCoverageCreateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime SubscriberCoverageModifyTime
		{
			get { return this.subscriberCoverageModifyTime; }
			set { this.subscriberCoverageModifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberCoverageModifiedBy
		{
			get { return this.subscriberCoverageModifiedBy; }
			set { this.subscriberCoverageModifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox|EnumControlTypes.ComboBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@SUBSCRIBERNAME@")]
		public string Fmt_SubscriberFullName
		{
			get { return FormatFNameLName(this.subscriberLastName, this.subscriberFirstName); }
		}

		[ControlType(EnumControlTypes.TextBox|EnumControlTypes.ComboBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@PATIENTNAME@")]
		public string Fmt_PatientFullName
		{
			get { return FormatFNameLName(this.patientLastName, this.patientFirstName); }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			base.InternalSave();

			// Save the child collections here.

			SavePatientCoveragePCPLogEntries();		// save the PCP log entries along with the main patient-subscriber-log entry.
		}

		/// <summary>
		/// Do pre and post-delete operations of this object here.
		/// </summary>
		protected override void InternalDelete()
		{
			throw new Exception("PatientSubscriberLog can not be deleted!");
			// Do pre-delete operations here (set members before delete, insert/update/delete extra records etc).
			//base.InternalDelete(); // always call this to ensure record flags gets updated properly.
			// Do post-delete operations here (set members after delete, insert/update/delete extra records etc).
		}

		/// <summary>
		/// Do pre and post-update operations of the object here.
		/// </summary>
		protected override void InternalUpdate()
		{
			throw new Exception("PatientSubscriberLog can not be updated!");
			// Do pre-update operations here (set members before update, insert/update extra records etc).
			//base.InternalUpdate(); // always call this to ensure record flags gets updated properly.
			// Do post-insert operations here (set members after update, insert/update extra records etc).
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientSubscriberLogId)
		{
			return base.Load(patientSubscriberLogId);
		}

		/// <summary>
		/// Load the latest patient-subscriber-log entry for the given patient and the selected
		/// subscriber-covereage.
		/// </summary>
		public bool LoadLastPatientSubscriberLogEntry(int patientId, int patientCoverageId)
		{
			return SqlData.SPExecReadObj("usp_GetLastPatientSubscriberLogEntry", this, false, patientId, patientCoverageId);
		}

		public static PatientSubscriberLog GetLastPatientSubscriberLogEntry(SqlTransactionWithEvents transaction, int patientId, int patientCoverageId)
		{
			PatientSubscriberLog patSubLog = new PatientSubscriberLog();
			patSubLog.SqlData.Transaction = transaction;
			if (patSubLog.LoadLastPatientSubscriberLogEntry(patientId, patientCoverageId))
				return patSubLog;
			else
				return null;	// not found
		}

		public static PatientSubscriberLog GetLastPatientSubscriberLogEntry(SqlTransactionWithEvents transaction, Patient patient, PatientCoverage patientCoverage)
		{
			if (patient == null)
				throw new Exception("Null value passed to GetLastPatientSubscriberLogEntry for patient");

			if (patientCoverage == null)
				throw new Exception("Null value passed to GetLastPatientSubscriberLogEntry for patientCoverage");

			return GetLastPatientSubscriberLogEntry(transaction, patient.PatientId, patientCoverage.PatientCoverageID);
		}

		/// <summary>
		/// Get the last patient subscriber log id
		/// </summary>
		public int LoadLastPatientSubscriberLogID(int patientId, int patientCoverageID)
		{
			return Convert.ToInt32( SqlData.SPExecScalar("usp_GetLastPatientSubscriberLogID", new object[] { patientId, patientCoverageID }) );
		}

		/// <summary>
		/// Get the last patient subscriber log id
		/// </summary>
		public static int GetLastPatientSubscriberLogID(SqlTransactionWithEvents transaction, Patient patient, PatientCoverage patientCoverage)
		{
			if (patient == null)
				throw new Exception("Null value passed to GetLastPatientSubscriberLogID for patient");

			if (patientCoverage == null)
				throw new Exception("Null value passed to GetLastPatientSubscriberLogID for patientCoverage");

			PatientSubscriberLog patSubLog = new PatientSubscriberLog();
			patSubLog.SqlData.Transaction = transaction;
			return patSubLog.LoadLastPatientSubscriberLogID(patient.PatientId, patientCoverage.PatientCoverageID);
		}

		/// <summary>
		/// Get the last patient subscriber log id
		/// </summary>
		public static int GetLastPatientSubscriberLogID(SqlTransactionWithEvents transaction, int patientID, int patientCoverageID)
		{
			PatientSubscriberLog patSubLog = new PatientSubscriberLog();
			patSubLog.SqlData.Transaction = transaction;
			return patSubLog.LoadLastPatientSubscriberLogID(patientID, patientCoverageID);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberAssignedUserId
		{
			get { return this.subscriberAssignedUserId; }
			set { this.subscriberAssignedUserId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberAssignedTeamId
		{
			get { return this.subscriberAssignedTeamId; }
			set { this.subscriberAssignedTeamId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientCoverageID
		{
			get { return this.patientCoverageID; }
			set { this.patientCoverageID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientEligibilityID
		{
			get { return this.patientEligibilityID; }
			set { this.patientEligibilityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberEligibilityID
		{
			get { return this.subscriberEligibilityID; }
			set { this.subscriberEligibilityID = value; }
		}

		/// <summary>
		/// Child PatientCoveragePCPLogEntries mapped to related rows of table PatientCoveragePCPLog where [PatientSubscriberLogId] = [PatientSubscriberLogID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientCoveragePCPLogEntries", "patientSubscriberLogID")]
		public PatientCoveragePCPLogCollection PatientCoveragePCPLogEntries
		{
			get { return this.patientCoveragePCPLogEntries; }
			set
			{
				this.patientCoveragePCPLogEntries = value;
				if (value != null)
					value.ParentPatientSubscriberLog = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientCoveragePCPLogEntries collection
		/// </summary>
		public void LoadPatientCoveragePCPLogEntries(bool forceReload)
		{
			this.patientCoveragePCPLogEntries = (PatientCoveragePCPLogCollection)PatientCoveragePCPLogCollection.LoadChildCollection("PatientCoveragePCPLogEntries", this, typeof(PatientCoveragePCPLogCollection), patientCoveragePCPLogEntries, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientCoveragePCPLogEntries collection
		/// </summary>
		public void SavePatientCoveragePCPLogEntries()
		{
			PatientCoveragePCPLogCollection.SaveChildCollection(this.patientCoveragePCPLogEntries, true);
		}

		/// <summary>
		/// Synchronizes the PatientCoveragePCPLogEntries collection
		/// </summary>
		public void SynchronizePatientCoveragePCPLogEntries()
		{
			PatientCoveragePCPLogCollection.SynchronizeChildCollection(this.patientCoveragePCPLogEntries, true);
		}

		/// <summary>
		/// Returns the loaded and cached patient coverage
		/// </summary>
		public PatientCoverage PatientCoverage
		{
			get
			{
				if (this.patientCoverage == null)
					this.patientCoverage = GetPatientCoverage();
				return this.patientCoverage;
			}
		}

		/// <summary>
		/// Loads and retuns the linked patient coverage
		/// </summary>
		/// <returns></returns>
		public PatientCoverage GetPatientCoverage()
		{
			if (this.patientCoverageID == 0)
				return null;
			PatientCoverage patientCoverage = new PatientCoverage();
			patientCoverage.SqlData.Transaction = this.SqlData.Transaction;
			if (patientCoverage.Load(this.patientCoverageID))
				return patientCoverage;
			else
				return null;
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF1
		{
			get { return this.patientUDEF1; }
			set { this.patientUDEF1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF2
		{
			get { return this.patientUDEF2; }
			set { this.patientUDEF2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF3
		{
			get { return this.patientUDEF3; }
			set { this.patientUDEF3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF4
		{
			get { return this.patientUDEF4; }
			set { this.patientUDEF4 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF5
		{
			get { return this.patientUDEF5; }
			set { this.patientUDEF5 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF6
		{
			get { return this.patientUDEF6; }
			set { this.patientUDEF6 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF7
		{
			get { return this.patientUDEF7; }
			set { this.patientUDEF7 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF8
		{
			get { return this.patientUDEF8; }
			set { this.patientUDEF8 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF9
		{
			get { return this.patientUDEF9; }
			set { this.patientUDEF9 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF10
		{
			get { return this.patientUDEF10; }
			set { this.patientUDEF10 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF11
		{
			get { return this.patientUDEF11; }
			set { this.patientUDEF11 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF12
		{
			get { return this.patientUDEF12; }
			set { this.patientUDEF12 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF13
		{
			get { return this.patientUDEF13; }
			set { this.patientUDEF13 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientUDEF14
		{
			get { return this.patientUDEF14; }
			set { this.patientUDEF14 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF1
		{
			get { return this.subscriberUDEF1; }
			set { this.subscriberUDEF1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF2
		{
			get { return this.subscriberUDEF2; }
			set { this.subscriberUDEF2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF3
		{
			get { return this.subscriberUDEF3; }
			set { this.subscriberUDEF3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF4
		{
			get { return this.subscriberUDEF4; }
			set { this.subscriberUDEF4 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF5
		{
			get { return this.subscriberUDEF5; }
			set { this.subscriberUDEF5 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF6
		{
			get { return this.subscriberUDEF6; }
			set { this.subscriberUDEF6 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF7
		{
			get { return this.subscriberUDEF7; }
			set { this.subscriberUDEF7 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF8
		{
			get { return this.subscriberUDEF8; }
			set { this.subscriberUDEF8 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF9
		{
			get { return this.subscriberUDEF9; }
			set { this.subscriberUDEF9 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF10
		{
			get { return this.subscriberUDEF10; }
			set { this.subscriberUDEF10 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF11
		{
			get { return this.subscriberUDEF11; }
			set { this.subscriberUDEF11 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF12
		{
			get { return this.subscriberUDEF12; }
			set { this.subscriberUDEF12 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF13
		{
			get { return this.subscriberUDEF13; }
			set { this.subscriberUDEF13 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberUDEF14
		{
			get { return this.subscriberUDEF14; }
			set { this.subscriberUDEF14 = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EnrollmentID
		{
			get { return this.enrollmentID; }
			set { this.enrollmentID = value; }
		}
		

	}
}
