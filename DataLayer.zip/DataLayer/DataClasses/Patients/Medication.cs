using System;

using NetsoftUSA.DataLayer;
using System.Collections;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Medication]
	/// </summary>
	[SPAutoGen("usp_SearchMedications","SearchByArgs.sptpl","brandName, etcName, genericName, nDC, etcID", InjectPreOperation="SET ROWCOUNT @rowCount", InjectParameters="@rowCount int")]
	[SPAutoGen("usp_GetAllMedications","SelectAll.sptpl","")]
	[SPInsert("usp_InsertMedication")]
	[SPUpdate("usp_UpdateMedication")]
	[SPDelete("usp_DeleteMedication")]
	[SPLoad("usp_LoadMedication")]
	[TableMapping("Medication","medicationId")]
	public class Medication : BaseData
	{
		[NonSerialized]
		private MedicationCollection parentMedicationCollection;
		[ColumnMapping("MedicationId",StereoType=DataStereoType.FK)]
		private int medicationId;
		[ColumnMapping("NDC")]
		private string nDC;
		[ColumnMapping("BrandName")]
		private string brandName;
		[ColumnMapping("GenericName")]
		private string genericName;
		[ColumnMapping("EtcID")]
		private string etcID;
		[ColumnMapping("EtcName")]
		private string etcName;

		private int medicationNameType = 1;
	
		public Medication()
		{
		}

		#if DEBUG
		public static Medication GetDummyMedication(int medicationId)
		{
			Medication med = new Medication();
			med.medicationId = medicationId;
			med.brandName = med.genericName = med.etcName = med.nDC =
				string.Format("Medication {0} N/A in Debug mode (not a bug)", medicationId);
			return med;
		}
		#endif

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int MedicationId
		{
			get { return this.medicationId; }
			set { this.medicationId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=11)]
		[FieldDescription("@NDC@")]
		public string NDC
		{
			get { return this.nDC; }
			set { this.nDC = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		[FieldDescription("@BRANDNAME@")]
		public string BrandName
		{
			get { return this.brandName; }
			set { this.brandName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		[FieldDescription("@GENERICNAME@")]
		public string GenericName
		{
			get { return this.genericName; }
			set { this.genericName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=8)]
		public string EtcID
		{
			get { return this.etcID; }
			set { this.etcID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		[FieldDescription("@ETCNAME@")]
		public string EtcName
		{
			get { return this.etcName; }
			set { this.etcName = value; }
		}
		
		[ControlType(EnumControlTypes.TextBox, MaxLength=255, IsRequired=true)]
		[FieldDescription("@NAME@")]
		public string SearchName
		{
			get 
			{
				switch(SelectedMedicationNameTypeInt)
				{
					case (int)MedicationNameType.Brand:
						return this.brandName;
					case (int)MedicationNameType.Generic:
						return this.genericName;
					case (int)MedicationNameType.Etc:
						return this.etcName;
				}
				return "";
			}
			set
			{
				switch(SelectedMedicationNameTypeInt)
				{
					case (int)MedicationNameType.Brand:
						this.brandName = value;
						this.genericName = "";
						this.etcName = "";
						break;
					case (int)MedicationNameType.Generic:
						this.brandName = "";
						this.genericName = value;
						this.etcName = "";
						break;
					case (int)MedicationNameType.Etc:
						this.brandName = "";
						this.genericName = "";
						this.etcName = value;
						break;
				}
			}
		}
		
		[FieldValuesMember("ValuesOf_SelectedMedicationNameTypeInt")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@DATALEVELFILTER@")]
		public int SelectedMedicationNameTypeInt
		{
			get {return medicationNameType; }
			set { medicationNameType = value; }
		}
		
		public enum MedicationNameType
		{
			//Undefined = 0,
			Brand = 1,
			Generic = 2,
			Etc = 3,
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int medicationId)
		{
			return base.Load(medicationId);
		}

		/// <summary>
		/// Parent MedicationCollection that contains this element
		/// </summary>
		public MedicationCollection ParentMedicationCollection
		{
			get
			{
				return this.parentMedicationCollection;
			}
			set
			{
				this.parentMedicationCollection = value; // parent is set when added to a collection
			}
		}

		public object[,] ValuesOf_SelectedMedicationNameTypeInt
		{
			get
			{
				return new object[,] { { (int)MedicationNameType.Brand , "Brand Name"}, 
									   { (int)MedicationNameType.Generic , "Generic Name"},
									   { (int)MedicationNameType.Etc , "Etc Name"}
									 }; // return possible field values
			}
		}

		/// <summary>
		/// Parent PatientMedication that contains this object
		/// </summary>
		public PatientMedication ParentPatientMedication
		{
			get { return this.ParentDataObject as PatientMedication; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PatientMedication */ }
		}
	}

	/// <summary>
	/// Strongly typed collection of Medication objects
	/// </summary>
	[ElementType(typeof(Medication))]
	public class MedicationCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_MedicationId;
		public const int MAXRECORDS = 50;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Medication elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMedicationCollection = this;
			else
				elem.ParentMedicationCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Medication elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Medication this[int index]
		{
			get
			{
				return (Medication)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Medication)oldValue, false);
			SetParentOnElem((Medication)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public int SearchMedications(Medication searcher)
		{
			return SearchMedications(-1, MAXRECORDS, searcher);
		}
		
		/// <summary>
		/// Search for medications and fill the collection.
		/// </summary>
		public int SearchMedications(int maxRecords, int rowCount, Medication searcher)
		{
			this.Clear();
//			if(searcher.SelectedMedicationNameTypeInt == 0
//				&& searcher.SearchName == null)
//				return 0;
			return SqlData.SPExecReadCol("usp_SearchMedications", maxRecords, this, searcher, false,
				new string[] {"rowCount"},
				new object[] {rowCount});
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Medication elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Medication)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllMedications(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol(0, "usp_GetAllMedications", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared MedicationCollection which is cached in NSGlobal
		/// </summary>
		public static MedicationCollection AllMedications
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				MedicationCollection col = (MedicationCollection)NSGlobal.EnsureCachedObject("Medications", typeof(MedicationCollection), ref initialize);
				if (initialize)
				{
					// Loading thousands of medications after every recompilation takes a lot of time
#if DEBUG
					col.LoadAllMedications(1000);
					return col;
#endif					
					col.LoadAllMedications(-1);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on medicationId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_MedicationId
		{
			get
			{
				if (this.indexBy_MedicationId == null)
					this.indexBy_MedicationId = new CollectionIndexer(this, new string[] { "medicationId" }, true);
				return this.indexBy_MedicationId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on medicationId fields returns the object.  Uses the IndexBy_MedicationId indexer.
		/// </summary>
		public Medication FindBy(int medicationId)
		{
			return (Medication)this.IndexBy_MedicationId.GetObject(medicationId);
		}


		public string GetMedicationNamesCombined(ArrayList patientMedications)
		{
			string combinedMedicationNames = null;
			string[] medicationNames = GetMedicationNames(patientMedications);
			if (medicationNames == null) return null;

			foreach (string medicationName in medicationNames)
			{
				combinedMedicationNames += medicationName + "\n\r";
			}

			return combinedMedicationNames;
		}

		public string[] GetMedicationNames(ArrayList patientMedications)
		{
			// if there are no medications there is nothing to return
			if (patientMedications == null || patientMedications.Count == 0) return null;

			string[] medicationNames = new string[patientMedications.Count];
			Medication currentMedication = null;

			// Go thru the medication collection and try to get some kind of text for each medication
			for (int index = 0; index < patientMedications.Count; index++)
			{
				currentMedication = ((PatientMedication)patientMedications[index]).Medication;
				
				if (currentMedication.BrandName != null && currentMedication.BrandName != "")						
					medicationNames[index] = currentMedication.BrandName; 
				else
					medicationNames[index] = "Unknown Medication";
			}

			return medicationNames;
		}

	}
}
