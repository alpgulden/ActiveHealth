using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientSubscriberCoveragePCP]
	/// </summary>
	[SPInsert("usp_InsertPatientSubscriberCoveragePCP")]
	[SPUpdate("usp_UpdatePatientSubscriberCoveragePCP")]
	[SPDelete("usp_DeletePatientSubscriberCoveragePCP")]
	[SPLoad("usp_LoadPatientSubscriberCoveragePCP")]
	[TableMapping("PatientSubscriberCoveragePCP","patientSubscriberCoveragePCPID")]
	public class PatientSubscriberCoveragePCP : BaseData
	{
		[NonSerialized]
		private PatientSubscriberCoveragePCPCollection parentPatientSubscriberCoveragePCPCollection;
		[ColumnMapping("PatientSubscriberCoveragePCPID",StereoType=DataStereoType.FK)]
		private int patientSubscriberCoveragePCPID;
		[ColumnMapping("PatientSubscriberCoverageId",StereoType=DataStereoType.FK)]
		private int patientSubscriberCoverageId;
		[ColumnMapping("PCPLocationID",StereoType=DataStereoType.FK)]
		private int pCPLocationID;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public PatientSubscriberCoveragePCP()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientSubscriberCoveragePCPID
		{
			get { return this.patientSubscriberCoveragePCPID; }
			set { this.patientSubscriberCoveragePCPID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientSubscriberCoverageId
		{
			get { return this.patientSubscriberCoverageId; }
			set { this.patientSubscriberCoverageId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PCPLocationID
		{
			get { return this.pCPLocationID; }
			set { this.pCPLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientSubscriberCoveragePCPID)
		{
			return base.Load(patientSubscriberCoveragePCPID);
		}

		/// <summary>
		/// Parent PatientSubscriberCoveragePCPCollection that contains this element
		/// </summary>
		public PatientSubscriberCoveragePCPCollection ParentPatientSubscriberCoveragePCPCollection
		{
			get
			{
				return this.parentPatientSubscriberCoveragePCPCollection;
			}
			set
			{
				this.parentPatientSubscriberCoveragePCPCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PatientSubscriberCoveragePCP objects
	/// </summary>
	[ElementType(typeof(PatientSubscriberCoveragePCP))]
	public class PatientSubscriberCoveragePCPCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientSubscriberCoveragePCP elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientSubscriberCoveragePCPCollection = this;
			else
				elem.ParentPatientSubscriberCoveragePCPCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientSubscriberCoveragePCP elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientSubscriberCoveragePCP this[int index]
		{
			get
			{
				return (PatientSubscriberCoveragePCP)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientSubscriberCoveragePCP)oldValue, false);
			SetParentOnElem((PatientSubscriberCoveragePCP)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PatientSubscriberCoveragePCP elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PatientSubscriberCoveragePCP)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent PatientSubscriberCoverage that contains this collection
		/// </summary>
		public PatientSubscriberCoverage ParentPatientSubscriberCoverage
		{
			get { return this.ParentDataObject as PatientSubscriberCoverage; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PatientSubscriberCoverage */ }
		}
	}
}
