using System;
using System.Collections;
using NetsoftUSA.DataLayer;
using System.Diagnostics;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// The Intake Log module is the typical initial entry point for Patient information into the ActiveAdvice system. 
	/// All incoming calls or requests are handled by the Intake staff and are entered into the Intake Log. 
	/// Every entry into the Intake log must have a resolution, a resolution being an Event, Note or Activity.
	/// </summary>
	[SPInsert("usp_InsertIntakeLog")]
	[SPUpdate("usp_UpdateIntakeLog")]
	[SPLoad("usp_LoadIntakeLog")]
	[TableMapping("IntakeLog","intakeLogID")]
	public class IntakeLog : BaseData
	{
		[NonSerialized]
		private IntakeLogCollection parentIntakeLogCollection;
		[ColumnMapping("IntakeLogID",(int)0)]
		protected int intakeLogID;
		[ColumnMapping("ServiceDate")]
		protected DateTime serviceDate;
		[ColumnMapping("CallerFName")]
		protected string callerFName;
		[ColumnMapping("CallerLName")]
		protected string callerLName;
		[ColumnMapping("CallerPhone")]
		protected string callerPhone;
		[ColumnMapping("CallerPhoneExt")]
		protected string callerPhoneExt;
		[ColumnMapping("CallerOrganization")]
		protected string callerOrganization;
		[ColumnMapping("CallerRelation")]
		protected string callerRelation;
		[ColumnMapping("PatientSSN")]
		protected string patientSSN;
		[ColumnMapping("PatientMemberID")]
		protected string patientMemberID;
		[ColumnMapping("PatientFName")]
		protected string patientFName;
		[ColumnMapping("PatientLName")]
		protected string patientLName;
		[ColumnMapping("PatientMI")]
		protected string patientMI;
		[ColumnMapping("SubscriberSSN")]
		protected string subscriberSSN;
		[ColumnMapping("SubscriberFName")]
		protected string subscriberFName;
		[ColumnMapping("SubscriberLName")]
		protected string subscriberLName;
		[ColumnMapping("SubscriberMI")]
		protected string subscriberMI;
		[ColumnMapping("AuthID",StereoType=DataStereoType.FK)]
		protected int authID;
		[ColumnMapping("AuthType")]
		private string authType;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("Notepad")]
		protected string notepad;
		[ColumnMapping("PatientDOB")]
		protected DateTime patientDOB;
		[ColumnMapping("PatientGender",StereoType=DataStereoType.Gender)]
		protected string patientGender;
		[ColumnMapping("IntakeCallReasonID",StereoType=DataStereoType.FK)]
		protected int intakeCallReasonID;
		[ColumnMapping("IntakeCallSourceID",StereoType=DataStereoType.FK)]
		protected int intakeCallSourceID;
		[ColumnMapping("IntakeCallTypeID",StereoType=DataStereoType.FK)]
		protected int intakeCallTypeID;
		[ColumnMapping("IntakeResolutionID",StereoType=DataStereoType.FK)]
		protected int intakeResolutionID;
		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
		protected int planID;
		[ColumnMapping("SORGId",StereoType=DataStereoType.FK)]
		protected int sORGId;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		protected int patientId;
		[ColumnMapping("SubscriberId",StereoType=DataStereoType.FK)]
		protected int subscriberId;
		[ColumnMapping("EligibilityId",StereoType=DataStereoType.FK)]
		protected int eligibilityId;
		[ColumnMapping("SubscriberMemberID")]
		protected string subscriberMemberID;
	
		// Loaded and cached objects
		private Patient patient;		// patient linked to this intake log
		private Subscriber subscriber;	// subscriber linked to this intake log
		private Organization sorg;		// sorg linked to this intake log
		private Plan plan;				// plan linked to this intake log
		private PatientCoverage patientCoverage;	// the patient-coverage picked by subscriber search
		//private EligibilitySearchResult eligibilityResult;	// the eligibility search result picked from eligibility search

		protected int problemID;			// selected problem in the intake log.  not saved to db
		private Problem problem;		// selected problem is loaded whenever accessed.
		private ProblemCollection patientProblems;	// used for ProblemID combo items.

		private bool saveWithPatient = false;		// set to true, when the intake log's save is delayed until patient-subs-coverage is saved
		//private bool addProblemAndReturn = false;	// The problem page checks this.

		private int searchByInt = (int)EnumIntakeSearchBy.Patient;
		private bool eligible = false;

		private bool eligibilitySearched = false;
		private bool patientSearched = false;

		private ArrayList messageLog = new ArrayList();		// track of allt the steps performed

		public IntakeLog()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public IntakeLog(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public ArrayList MessageLog
		{
			get { return this.messageLog; }
		}

		public void AddToMessageLog(string msg)
		{
			this.messageLog.Add(msg);
			Debug.WriteLine(msg);
		}

		public void AddToMessageLog(string msg, params object[] parameters)
		{
			AddToMessageLog(String.Format(msg, parameters));
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "}\r\n";

			for (int i = 0; i < this.messageLog.Count; i++)
			{
				s += this.messageLog[i].ToString() + "\r\n";
			}
			
			return s;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int IntakeLogID
		{
			get { return this.intakeLogID; }
			set { this.intakeLogID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime ServiceDate
		{
			get { return this.serviceDate; }
			set { this.serviceDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string CallerFName
		{
			get { return this.callerFName; }
			set { this.callerFName = Formatting.CapitalizeFirstLetter(value); }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string CallerLName
		{
			get { return this.callerLName; }
			set { this.callerLName = Formatting.CapitalizeFirstLetter(value); }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=128)]
		public string CallerOrganization
		{
			get { return this.callerOrganization; }
			set { this.callerOrganization = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string CallerRelation
		{
			get { return this.callerRelation; }
			set { this.callerRelation = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string PatientFName
		{
			get { return this.patientFName; }
			set { this.patientFName =  Formatting.CapitalizeFirstLetter(value); }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string PatientLName
		{
			get { return this.patientLName; }
			set { this.patientLName =  Formatting.CapitalizeFirstLetter(value); }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string PatientMI
		{
			get { return this.patientMI; }
			set { this.patientMI = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string SubscriberFName
		{
			get { return this.subscriberFName; }
			set { this.subscriberFName =  Formatting.CapitalizeFirstLetter(value); }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string SubscriberLName
		{
			get { return this.subscriberLName; }
			set { this.subscriberLName =  Formatting.CapitalizeFirstLetter(value); }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string SubscriberMI
		{
			get { return this.subscriberMI; }
			set { this.subscriberMI = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AuthID
		{
			get { return this.authID; }
			set { this.authID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string AuthType
		{
			get { return this.authType; }
			set { this.authType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PatientDOB
		{
			get { return this.patientDOB; }
			set { this.patientDOB = value; }
		}

		[FieldValuesMember("ValuesOf_Gender")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, MaxLength=1)]
		public string PatientGender
		{
			get { return this.patientGender; }
			set { this.patientGender = value; }
		}

		[FieldValuesMember("LookupOf_IntakeCallReasonID", "IntakeCallReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int IntakeCallReasonID
		{
			get { return this.intakeCallReasonID; }
			set { this.intakeCallReasonID = value; }
		}

		[FieldValuesMember("LookupOf_IntakeCallSourceID", "IntakeCallSourceID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int IntakeCallSourceID
		{
			get { return this.intakeCallSourceID; }
			set { this.intakeCallSourceID = value; }
		}

		[FieldValuesMember("LookupOf_IntakeCallTypeID", "IntakeCallTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int IntakeCallTypeID
		{
			get { return this.intakeCallTypeID; }
			set { this.intakeCallTypeID = value; }
		}

		[FieldValuesMember("LookupOf_IntakeResolutionID", "IntakeResolutionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int IntakeResolutionID
		{
			get { return this.intakeResolutionID; }
			set { this.intakeResolutionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PlanID
		{
			get { return this.planID; }
			set 
			{ 
				this.planID = value; 
				this.plan = null;			// cause reload of plan
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int SORGId
		{
			get { return this.sORGId; }
			set 
			{ 
				this.sORGId = value; 
				this.sorg = null;			// cause reload of sorg
			}
		}

		// dummy for EDIReader
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ORGId
		{
			get { return 0; }
			set { }
		}

		// dummy for EDIReader
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MORGId
		{
			get { return 0; }
			set { }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientId
		{
			get { return this.patientId; }
			set 
			{ 
				this.patientId = value;
				this.patient = null;				// cause reload of patient
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberId
		{
			get { return this.subscriberId; }
			set 
			{ 
				this.subscriberId = value; 
				this.subscriber = null;				// cause reload of subscriber
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EligibilityId
		{
			get { return this.eligibilityId; }
			set { this.eligibilityId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=15)]
		public string CallerPhone
		{
			get { return this.callerPhone; }
			set { this.callerPhone = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, MaxLength=5)]
		[FieldDescription("@EXT@")]
		public string CallerPhoneExt
		{
			get { return this.callerPhoneExt; }
			set { this.callerPhoneExt = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USSSN)]
		public string PatientSSN
		{
			get { return this.patientSSN; }
			set 
			{ 
				this.patientSSN =  ParseSSN( value ); 
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.USSSN)]
		public string SubscriberSSN
		{
			get { return this.subscriberSSN; }
			set 
			{ 
				this.subscriberSSN =  ParseSSN( value );
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string PatientMemberID
		{
			get { return this.patientMemberID; }
			set { this.patientMemberID = value; }
		}

		[FieldDescription("@ALTIDFORSUBS@")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string SubscriberMemberID
		{
			get { return this.subscriberMemberID; }
			set { this.subscriberMemberID = value; }
		}

		/// <summary>
		/// Intake log is called only to insert a new intake log.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="subscriber"></param>
		/// <param name="patientCoverage"></param>
		public void Save(Patient patient, Subscriber subscriber, PatientCoverage patientCoverage)
		{
			//if (!this.IsNew)
			//	throw new ActiveAdviceException(AAExceptionAction.None, "Intake Log cannot be updated!");
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Patient is required to save intake log");
			if (subscriber == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Subscriber is required to save intake log");
			if (patientCoverage == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "PatientCoverage is required to save intake log");

			/*if (this.PatientLName == null || this.PatientLName == "")
				throw new ActiveAdviceException(AAExceptionAction.None, "Patient Last Name is required to save intake log");
			
			if (this.PatientFName == null || this.PatientFName == "")
				throw new ActiveAdviceException(AAExceptionAction.None, "Patient First Name is required to save intake log");

			if (this.PatientSSN == null || this.PatientSSN == "")
				throw new ActiveAdviceException(AAExceptionAction.None, "Patient SSN is required to save intake log");
			*/

			// establish both in memory and fk relationships.
			this.patientCoverage = patientCoverage;
			this.Patient = patient;
			this.Subscriber = subscriber;
			PullSORGAndPlanFromCoverage();
			//this.Plan = patientCoverage.Plan;
			//this.SORG = patientCoverage.SORG;

			base.Save();
		}

		/// <summary>
		/// Save a new intake log.
		/// This method assumes that the in-memory and fk relationships
		/// to patient, subscriber, sorg and the plan is already set.
		/// </summary>
		public new void Save()
		{
			//if (!this.IsNew)
			//	throw new ActiveAdviceException(AAExceptionAction.None, "Intake Log cannot be updated!");
			base.Save();
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int intakeLogID)
		{
			return base.Load(intakeLogID);
		}

		public IntakeCallTypeCollection LookupOf_IntakeCallTypeID
		{
			get
			{
				return IntakeCallTypeCollection.ActiveIntakeCallTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public IntakeResolutionCollection LookupOf_IntakeResolutionID
		{
			get
			{
				IntakeResolutionCollection resolutions = (IntakeResolutionCollection)IntakeResolutionCollection.ActiveIntakeResolutions.Clone(false, false);
				IntakeResolution resolution = null;
				// if there's not a selected proble, remove Add Event and Add Referral
				
				if (this.IsNew && (this.Patient == null || this.PatientCoverage == null)) // || this.Problem == null)
				{
					resolution = resolutions.FindBy(IntakeResolution.ADDE);
					if (resolution != null)
						resolution.MarkDel();
					resolution = resolutions.FindBy(IntakeResolution.ADDR);
					if (resolution != null)
						resolution.MarkDel();
				}

				return resolutions;
			}
		}

		public IntakeCallSourceCollection LookupOf_IntakeCallSourceID
		{
			get
			{
				return IntakeCallSourceCollection.IntakeCallSources; // Acquire a shared instance from the static member of collection
			}
		}

		public IntakeCallReasonCollection LookupOf_IntakeCallReasonID
		{
			get
			{
				return IntakeCallReasonCollection.ActiveIntakeCallReasons; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Loads and returns the associated patient.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientId == 0)
				return null;
			Patient patient = new Patient();
			if (patient.Load(this.patientId))
				return patient;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated subscriber.
		/// </summary>
		/// <returns></returns>
		public Subscriber GetSubscriber()
		{
			if (this.subscriberId == 0)
				return null;
			Subscriber subscriber = new Subscriber();
			if (subscriber.Load(this.subscriberId))
				return subscriber;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated SORG.
		/// </summary>
		/// <returns></returns>
		public Organization GetSORG()
		{
			if (this.sORGId == 0)
				return null;
			Organization sorg = new Organization();
			if (sorg.Load(this.sORGId))
				return sorg;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated Plan.
		/// </summary>
		/// <returns></returns>
		public Plan GetPlan()
		{
			if (this.planID == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.planID))
				return plan;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the problem set to ProblemID.
		/// </summary>
		/// <returns></returns>
		public Problem GetProblem()
		{
			if (this.problemID == 0)
				return null;
			Problem problem = new Problem();
			if (problem.Load(this.problemID))
				return problem;
			else
				return null;
		}

		public PatientCoverage GetPatientCoverage()
		{
			PatientCoverage patCov = new PatientCoverage();
			if (patCov.Load(this.patientId, this.subscriberId, this.sORGId, this.planID))
				return patCov;
			else
				return null;
		}

		public PatientCoverage PatientCoverage
		{
			get 
			{ 
				if (this.patientCoverage == null)
					this.patientCoverage = GetPatientCoverage();
				return this.patientCoverage;
			}
			set { this.patientCoverage = value; }
		}

		/// <summary>
		/// Loaded and cached patient.
		/// </summary>
		public Patient Patient
		{
			get
			{
				if (this.patient == null)
				{
					this.patient = GetPatient();
					//  a new patient, load patient problems.
					if (this.patient != null)
						patientProblems = this.patient.GetLinkedProblems();
					else
						patientProblems = null;
				}
				return this.patient;
			}
			set
			{
				this.patient = value;
				if (value == null)
				{
					this.patientId = 0;
				}
				else
				{
					this.patientId = patient.PatientId;
				}
				// a new patient was set, load its problems.
				if (this.patient != null)
					patientProblems = this.patient.GetLinkedProblems();
				else
					patientProblems = null;
			}
		}

		/// <summary>
		/// Loaded and cached subsriber.
		/// </summary>
		public Subscriber Subscriber
		{
			get
			{
				if (this.subscriber == null)
					this.subscriber = this.GetSubscriber();
				return this.subscriber;
			}
			set
			{
				this.subscriber = value;
				if (value == null)
					this.subscriberId = 0;
				else
					this.subscriberId = subscriber.SubscriberId;
			}
		}

		/// <summary>
		/// Loaded and cached SORG
		/// </summary>
		public Organization SORG
		{
			get
			{
				if (this.sorg == null)
					this.sorg = this.GetSORG();
				return this.sorg;
			}
			set
			{
				if (value != null && !value.IsSubOrganization)
					throw new ActiveAdviceException(AAExceptionAction.None, "Only a sub-organization can be linked to IntakeLog");
				this.sorg = value;
				if (value == null)
					this.sORGId = 0;
				else
					this.sORGId = sorg.OrganizationID;
			}
		}

		/// <summary>
		/// Loaded and cached Plan
		/// </summary>
		public Plan Plan
		{
			get
			{
				if (this.plan == null)
					this.plan = GetPlan();
				return this.plan;
			}
			set
			{
				this.plan = value;
				if (value == null)
					this.planID = 0;
				else
					this.planID = plan.PlanId;
			}
		}

		/// <summary>
		/// Loaded and cached problem selected.
		/// </summary>
		public Problem Problem
		{
			get
			{
				if (this.problem == null)
					this.problem = this.GetProblem();
				return this.problem;
			}
			set
			{
				this.problem = value;
				if (value == null)
					this.problemID = 0;
				else
					this.problemID = problem.ProblemID;
			}
		}

		public string SubscriberLastName
		{
			get { return this.Subscriber.LastName; }
		}

		public string SubscriberFirstName
		{
			get { return this.Subscriber.FirstName; }
		}

		[FieldDescription("@SUBSCRIBERNAME@")]
		public string SubscriberFullName
		{
			get { return this.Subscriber.Fmt_FullName; }
		}

		[FieldDescription("@PLAN@")]
		public string PlanName
		{
			get 
			{
				if (this.Plan == null)
					return null;				// no plan.
				return this.Plan.Name; 
			}
		}

		[FieldDescription("@SORG@")]
		public string SORGName
		{
			get 
			{
				if (this.SORG == null)
					return null;				// no SORG.
				return this.SORG.Name; 
			}
		}

		[FieldDescription("@PATIENTNAME@")]
		public string PatientFullName
		{
			get { return this.Patient.Fmt_FullName; }
		}

		[FieldDescription("@CALLER@")]
		public string Fmt_CallerFullName
		{
			get { return FormatFNameLName(this.callerLName, this.callerFName); }
		}

		[FieldDescription("@PATIENT@")]
		public string Fmt_PaitentFullName
		{
			get { return FormatFNameLName(this.patientLName, this.patientFName); }
		}

		[FieldDescription("@SUBSCRIBER@")]
		public string Fmt_SubscriberFullName
		{
			get { return FormatFNameLName(this.subscriberLName, this.subscriberFName); }
		}

		public void PullPatientInfo()
		{
			if (this.Patient == null)
				return;
			this.patientSSN = this.Patient.SocialSecurityNumber;
			this.patientFName = this.Patient.FirstName;
			this.patientLName = this.Patient.LastName;
			// FORK 1.0
			this.patientDOB = this.patient.DateOfBirth;
			this.patientGender = this.patient.Gender;
			// END FORK 1.0
		}

		public void PullSubsriberInfo()
		{
			if (this.Subscriber == null)
				return;
			this.subscriberSSN = this.Subscriber.SocialSecurityNumber;
			this.subscriberFName = this.Subscriber.FirstName;
			this.subscriberLName = this.Subscriber.LastName;
		}

		/// <summary>
		/// Pull the first matching coverage for the patient, subscriber SSN and subscriber last name
		/// </summary>
		public void PullFirstMatchingSubscriberInfo()
		{
			if (this.Patient == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Intake has no patient to look for coverages");
			// search for subscriber using patienid, subscriber ssn, and subscriber last name
			PatientCoverageCollection patCovs = new PatientCoverageCollection();
			patCovs.SearchCoveragesOfPatient(this.Patient, this.subscriberSSN, this.SubscriberLName);
			if (patCovs.Count > 0)
			{
				// Use the first coverage to get the subscriber.
				this.PatientCoverage = patCovs[0];
				this.Subscriber = this.patientCoverage.Subscriber;
				PullSORGAndPlanFromCoverage();			// using the coverage set, set SORG and Plan too
				this.PullSubsriberInfo();				// set the first name and last name
			}
			else
			{
				this.PatientCoverage = null;
				this.Subscriber = null;
				PullSORGAndPlanFromCoverage();			// using the coverage set, set SORG and Plan too
			}
		}

		public void Refresh(PatientCoverage patCoverage, Patient patient, Subscriber subscriber)
		{
			if(patCoverage == null)
				this.ClearSORGPlan();
			else
			{
				this.PatientCoverage = patCoverage;
				this.PullSORGAndPlanFromCoverage();
			}

			if(subscriber == null)
				this.ClearSubscriber();
			else
			{
				this.Subscriber = subscriber;
				this.PullSubsriberInfo();
			}
			RefreshPatientOnly(patient);
		}

		public void RefreshPatientOnly(Patient patient)
		{
			if(patient == null)
				this.ClearPatient();
			else
			{
				this.Patient = patient;
				this.PullPatientInfo();
			}
		}

		/// <summary>
		/// using the coverage set, set SORG and Plan too
		/// </summary>
		public void PullSORGAndPlanFromCoverage()
		{
			if (this.patientCoverage == null)
			{
				this.SORG = null;
				this.Plan = null;
			}
			else
			{
				this.SORG = this.patientCoverage.SORG;
				this.Plan = this.patientCoverage.Plan;
			}
		}

		public void Import(CoverageSelectionContext coverageSelectionContext)
		{
			if (coverageSelectionContext == null)
			{
				this.PatientCoverage = null;
				this.Subscriber = null;
			}
			else
			{
				this.PatientCoverage = coverageSelectionContext.PatientCoverage;
				this.Subscriber = coverageSelectionContext.PatientCoverage.Subscriber;
			}
			this.PullSubsriberInfo();
			this.PullSORGAndPlanFromCoverage();
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			//writer.AddLabelandValue("@INTAKELOG@", ControlTypeAttribute.GetMemberValueAsString(this, "IntakeLogID"));
			writer.AddFieldsSubstituted(this, "@Fmt_CallerFullName@", "@CALLERINFO@");
			writer.AddField(this, "ServiceDate");
			writer.StartNewLineInSection();
			if (this.Patient != null)
				writer.AddField(this, "PatientFullName");
			if (this.Subscriber != null)
				writer.AddField(this, "SubscriberFullName");
			writer.StartNewLineInSection();
		}

		/// <summary>
		/// Create a new patient using the same coverage and subscriber
		/// </summary>
		public void CreateNewPatientWithThisCoverage()
		{
			if (!this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "CreateNewPatientWithThisCoverage method is intended to be used with a new intake log");
			this.Patient = new Patient(true);
			this.Patient.SocialSecurityNumber = this.patientSSN;
			this.Patient.FirstName = this.PatientFName;
			this.Patient.LastName = this.PatientLName;
			if (this.PatientCoverage != null)
			{
				this.PatientCoverage = (PatientCoverage)this.PatientCoverage.Clone(true);	// copy the coverage
				this.PatientCoverage.Patient = this.Patient;
			}
			else
			{
				this.PatientCoverage = new PatientCoverage(true);
				this.PatientCoverage.Patient = this.Patient;
			}
			// also use the filled data
			this.PatientCoverage.SORG = this.SORG;
			this.PatientCoverage.Plan = this.Plan;

			// don't know whether a new subscriber should be created or not..

		}

		/// <summary>
		/// Check if intake is valid for save.
		/// </summary>
		public bool ValidateForSave()
		{
			if (!this.IsNew)
				return true;

			if (this.Patient != null) // || this.PatientId == 0)	// allow new
			{
				//return false;
				if (this.SORG == null || this.SORGId == 0)
					return false;
				if (this.Plan == null || this.PlanID == 0)
					return false;
				if (this.Subscriber == null)		// allow new
					return false;
			}
			return true;
		}

		[FieldValuesMember("LookupOf_ProblemID", "ProblemID", "ProblemDescriptionToDisplay")]
		[FieldDescription("@PROBLEM@")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ProblemID
		{
			get { return this.problemID; }
			set 
			{ 
				this.problemID = value; 
				this.problem = null;
			}
		}

		public ProblemCollection LookupOf_ProblemID
		{
			get
			{
				// the patient problems are loaded whenever the patient linked to this
				// intake-log is loaded or whenever a new patient is set.
				return patientProblems;
			}
		}

		/*public ActiveAdvice.DataLayer.EligibilitySearchResult EligibilityResult
		{
			get { return this.eligibilityResult; }
			set { this.eligibilityResult = value; }
		}*/

		/// <summary>
		/// Given an eligibility result, create Patient, Subscriber and PatientCoverage objects
		/// </summary>
		/// <param name="eligibilityResult"></param>
		public void CreatePatSubsCovFromEligibility(EligibilitySearchResult eligibilityResult, /* FORK 1.0 */ bool checkIfPatientExists)
		{
			// Create patient if not in the context
			if (this.Patient == null)
			{
				// Create patient object
				Eligibility patElig = eligibilityResult.PatientEligibility;
				if (patElig == null)
					throw new ActiveAdviceException(AAExceptionAction.None, "No patient in eligiblity");
				Patient patient = null;
				// Check if the eligibility record has an existing Patient in the system.
				
				// FORK 1.0
				int foundPatientID = 0;
				if (checkIfPatientExists)
					foundPatientID = patElig.ExistsPatientInTheSystem();
				// END FORK 1.0

				if (foundPatientID != 0)	// found and existing patient, use it
				{
					patient = new Patient();
					if (!patient.Load(foundPatientID))
						patient = null;
				}
				if (patient == null)		// If the patient is not found in the system.  Import it from eligibility.
				{
					patient = new Patient(true);
					patient.ImportFromEligibility(patElig);
				}
				this.Patient = patient;
				this.PullPatientInfo();
			}

			// Create subscriber if not in the context
			if (this.Subscriber == null)
			{
				// Create subscriber object
				Eligibility subsElig = eligibilityResult.SubscriberEligibility;
				if (subsElig == null)
					throw new ActiveAdviceException(AAExceptionAction.None, "No patient in eligibility");
				Subscriber subscriber = new Subscriber(true);
				subscriber.ImportFromEligibility(subsElig);
				this.Subscriber = subscriber;
				this.PullSubsriberInfo();
			}
			
			// Create patient coverage if not in the context
			if (this.PatientCoverage == null)
			{
				// Using the data from patient eligibility an plan, create Patient Coverage
				Plan plan = eligibilityResult.PatientPlan;
				if (plan == null)
					throw new ActiveAdviceException(AAExceptionAction.None, "No plan in eligibility");
				Organization sorg = eligibilityResult.PatientEligibility.SORG;
				if (sorg == null)
					throw new ActiveAdviceException(AAExceptionAction.None, "No SORG in eligibility");
				PatientCoverage patCov = new PatientCoverage(this.Patient, this.Subscriber, sorg, plan);

				// Create patientCoverage import from eligibility process works in the
				// context of a CoverageSelectionContext object.  We create a coverage selection context
				// for this intake log.  It's going to use the intakeLog.ServiceDate
				CoverageSelectionContext covSelContext = new CoverageSelectionContext(this);
				this.PatientCoverage = patCov;
				patCov.ImportFromEligibility(covSelContext, eligibilityResult.PatientEligibility, eligibilityResult.SubscriberEligibility, eligibilityResult.PatientEligibilityPlan);

				this.PullSORGAndPlanFromCoverage();		// using the coverage set, set SORG and Plan too
			}

		}

		/// <summary>
		/// Delay saving the intake log until patient, subscriber and coverage has been saved.
		/// </summary>
		public bool SaveWithPatient
		{
			get { return this.saveWithPatient; }
			set { this.saveWithPatient = value; }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.serviceDate = DateTime.Today;
		}

		[ControlType(EnumControlTypes.TextBox, IsRequired=true)]
		public string IntakeResolutionCode
		{
			get { return IntakeResolutionCollection.ActiveIntakeResolutions.Lookup_CodeByIntakeResolutionID(this.intakeResolutionID); }
			set { this.intakeResolutionID = IntakeResolutionCollection.ActiveIntakeResolutions.Lookup_IntakeResolutionIDByCode(value); }
		}



		/// <summary>
		/// Parent IntakeLogCollection that contains this element
		/// </summary>
		public IntakeLogCollection ParentIntakeLogCollection
		{
			get
			{
				return this.parentIntakeLogCollection;
			}
			set
			{
				this.parentIntakeLogCollection = value; // parent is set when added to a collection
			}
		}

		//[ControlType(EnumControlTypes.CheckBox)]
		//public bool AddProblemAndReturn
		//{
		//	get { return this.addProblemAndReturn; }
		//	set { this.addProblemAndReturn = value; }
		//}


		/// <summary>
		/// Clear caller related information
		/// </summary>
		public void ClearCaller()
		{
			this.CallerFName = null;
			this.CallerLName = null;
			this.CallerOrganization = null;
			this.CallerPhone = null;
			this.CallerPhoneExt = null;
			this.IntakeCallSourceID = 0;
			this.IntakeResolutionID = 0;
			this.IntakeCallReasonID = 0;
		}

		/// <summary>
		/// Clear patient related information and the objects
		/// </summary>
		public void ClearPatient()
		{
			this.Patient = null;
			this.PatientCoverage = null;
			this.Subscriber = null;

			this.PatientSSN = null;
			this.PatientFName = null;
			this.PatientLName = null;
			this.PatientDOB = DateTime.MinValue;
			this.PatientMemberID = null;
			this.Notepad = string.Empty;
			this.ProblemID = 0;

			this.eligibilitySearched = false;
			this.patientSearched = false;

			this.intakeResolutionID = 0;
		}

		/// <summary>
		/// Clear subscriber related information and the objects
		/// </summary>
		public void ClearSubscriber()
		{
			this.PatientCoverage = null;
			this.Subscriber = null;

			this.SubscriberSSN = null;
			this.SubscriberFName = null;
			this.SubscriberLName = null;

			this.intakeResolutionID = 0;
		}

		/// <summary>
		/// Clear SORG and Plan related information and the objects
		/// </summary>
		public void ClearSORGPlan()
		{
			this.PatientCoverage = null;
			this.Plan = null;
			this.SORG = null;

			this.intakeResolutionID = 0;
		}

		/*
		/// <summary>
		/// Clear member search fields.
		/// </summary>
		public void ClearMemberSearch()
		{
			this.PatientMemberID = null;
			this.ServiceDate = DateTime.Today;
		}*/

		public bool EligibilitySearched
		{
			get { return this.eligibilitySearched; }
			set { this.eligibilitySearched = value; }
		}

		public bool PatientSearched
		{
			get { return this.patientSearched; }
			set { this.patientSearched = value; }
		}

		

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Eligible
		{
			get { return this.eligible; }
			set { this.eligible = value; }
		}

		/// <summary>
		/// Do coverage check with the selected patient coverage and set Eligible flag.
		/// </summary>
		public void DoCoverageCheck()
		{
			this.eligible = false;
			if (this.Patient == null || this.PatientCoverage == null)
				return;
			if (this.Patient.IsNew || this.PatientCoverage.IsNew)
				this.eligible = this.PatientCoverage.CheckCoverageInMemory();
			else
				this.eligible = this.PatientCoverage.CheckCoverageInDB();
		}

		[FieldValuesMember("ValuesOf_SearchByInt")]
		[ControlType(EnumControlTypes.RadioButtonBox)]
		[FieldDescription("@INTAKESEARCHBY@")]
		public int SearchByInt
		{
			get { return this.searchByInt; }
			set { this.searchByInt = value; }
		}

		public EnumIntakeSearchBy SearchBy
		{
			get { return (EnumIntakeSearchBy)this.searchByInt; }
			set { this.searchByInt = (int)value; }
		}

		public object[,] ValuesOf_SearchByInt
		{
			get
			{
				return new object[,] 
					{ 
						{ (int)EnumIntakeSearchBy.Patient, "Patient" },
						{ (int)EnumIntakeSearchBy.MemberEligibility, "Member Eligibility" }
					}; // return possible field values
			}
		}

		/// <summary>
		/// Intake page redirects to a different page based on the action code of selected resolution.
		/// </summary>
		public string IntakeResolutionAction
		{
			get { return IntakeResolutionCollection.ActiveIntakeResolutions.Lookup_ResolutionActionByIntakeResolutionID(this.intakeResolutionID); }
		}

		
	}

	/// <summary>
	/// Strongly typed collection of IntakeLog objects
	/// </summary>
	[ElementType(typeof(IntakeLog))]
	public class IntakeLogCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		public const int MAXRECORDS = 100;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(IntakeLog elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentIntakeLogCollection = this;
			else
				elem.ParentIntakeLogCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (IntakeLog elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public IntakeLog this[int index]
		{
			get
			{
				return (IntakeLog)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((IntakeLog)oldValue, false);
			SetParentOnElem((IntakeLog)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Search in the intake log.
		/// </summary>
		public int Search(IntakeLogSearcher intakeLogSearcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchIntakeLog", -1, this, intakeLogSearcher, false,
				new string[] { "rowCount" },
				new object[] { MAXRECORDS });
		}
	}

	/// <summary>
	/// Searcher class that contains search fields to be passed to intakesearch
	/// </summary>
	public class IntakeLogSearcher : IntakeLog
	{
		[ColumnMapping(null)]
		private DateTime fromDate;
		[ColumnMapping(null)]
		private DateTime toDate;
		[ColumnMapping(null)]
		private DateTime creationDate;

		public IntakeLogSearcher()
		{
			this.SetMembersNull(true, true);
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime FromDate
		{
			get { return this.fromDate; }
			set { this.fromDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ToDate
		{
			get { return this.toDate; }
			set { this.toDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreationDate
		{
			get { return this.creationDate; }
			set { this.creationDate = value; }
		}

		

	}

}
