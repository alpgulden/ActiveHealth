using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
/*	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientSubscribers]
	/// PatientSubscriberCoverage is a linkage between Patient and Subscriber.
	/// Patient may have multiple PatientSubscriberCoverage's and
	/// Subscriber may have multiple PatientSubscriberCoverage's too.
	/// This class provides an easy method of accessing the linked objects.
	/// If have a Patient object, you can access Patient.PatientSubscriberCoverages
	/// collection.  And from any of the PatientSubscriberCoverage element of this collection
	/// you can ask for the Subscriber object.  But it is not contained by PatientSubscriberCoverage.
	/// For example :  Patient.PatientSubscriberCoverages[0].GetSubscriber()
	/// or :  Subscriber.PatientSubscriberCoverages[0].GetPatient()
	/// but not :  Patient.PatientSubscriberCoverages[0].Subscriber.
	/// This object is not responsible for containing and persisting Patient and Subscriber
	/// objects.
	/// </summary>
	
	[SPInsert("usp_InsertPatientSubscriberCoverage")]
	[SPUpdate("usp_UpdatePatientSubscriberCoverage")]
	[SPDelete("usp_DeletePatientSubscriberCoverage")]
	[SPLoad("usp_LoadPatientSubscriberCoverage")]
	[TableMapping("PatientSubscriber","patientSubscriberId")]
	public class PatientSubscriber : BaseData
	{
		[ColumnMapping("PatientSubscriberId")]
		private int patientSubscriberId;
		[ColumnMapping("PatientId")]
		private int patientId;
		[ColumnMapping("SubscriberId")]
		private int subscriberId;
		[ColumnMapping("RelationshipId")]
		private int relationshipId;
	
		public PatientSubscriber()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Use this constructor when you want to create a link between a specific patient 
		/// and a specific subscriberId
		/// </summary>
		/// <param name="patientId"></param>
		/// <param name="subscriberId"></param>
		public PatientSubscriber(int patientId, int subscriberId, int relationshipId)
		{
			this.NewRecord(); // initialize record state
			this.patientId = patientId;
			this.subscriberId = subscriberId;
			this.relationshipId = relationshipId;
		}

		public PatientSubscriber(bool initNew)
		{
			if (initNew)
				this.NewRecord();
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientCoverageId)
		{
			return base.Load(patientCoverageId);
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads and returns the associated subscriber.
		/// </summary>
		/// <returns></returns>
		public Subscriber GetSubscriber()
		{
			if (this.subscriberId == 0)
				return null;
			Subscriber subscriber = new Subscriber();
			if (subscriber.Load(this.subscriberId))
				return subscriber;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated patient.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientId == 0)
				return null;
			Patient patient = new Patient();
			if (patient.Load(this.patientId))
				return patient;
			else
				return null;
		}

		public RelationshipTypeCollection LookupOf_RelationshipId
		{
			get
			{
				return RelationshipTypeCollection.ActiveRelationshipTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public InsuranceTypeCollection LookupOf_OtherInsuranceTypeId
		{
			get
			{
				return InsuranceTypeCollection.ActiveInsuranceTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public InsuranceStatusCollection LookupOf_OtherInsuranceStatusId
		{
			get
			{
				return InsuranceStatusCollection.ActiveInsuranceStatuses; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientSubscriberId
		{
			get { return this.patientSubscriberId; }
			set { this.patientSubscriberId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberId
		{
			get { return this.subscriberId; }
			set { this.subscriberId = value; }
		}

		[FieldValuesMember("LookupOf_RelationshipId", "RelationshipId", "Relationship")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RelationshipId
		{
			get { return this.relationshipId; }
			set { this.relationshipId = value; }
		}

	}
*/
}
