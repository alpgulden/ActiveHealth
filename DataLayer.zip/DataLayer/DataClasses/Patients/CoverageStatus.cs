using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CoverageStatus]
	/// </summary>
	[SPAutoGen("usp_GetAllCoverageStatusCodes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetCoverageStatusCodesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertCoverageStatus")]
	[SPUpdate("usp_UpdateCoverageStatus")]
	[SPDelete("usp_DeleteCoverageStatus")]
	[SPLoad("usp_LoadCoverageStatus")]
	[TableMapping("CoverageStatus","coverageStatusID")]
	public class CoverageStatus : BaseLookupWithNote
	{
		[NonSerialized]
		private CoverageStatusCollection parentCoverageStatusCollection;
		[ColumnMapping("CoverageStatusID",(int)0)]
		private int coverageStatusID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public CoverageStatus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public CoverageStatus(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public CoverageStatus(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CoverageStatusID
		{
			get { return this.coverageStatusID; }
			set { this.coverageStatusID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int coverageStatusID)
		{
			return base.Load(coverageStatusID);
		}

		/// <summary>
		/// Parent CoverageStatusCollection that contains this element
		/// </summary>
		public CoverageStatusCollection ParentCoverageStatusCollection
		{
			get
			{
				return this.parentCoverageStatusCollection;
			}
			set
			{
				this.parentCoverageStatusCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of CoverageStatus objects
	/// </summary>
	[ElementType(typeof(CoverageStatus))]
	public class CoverageStatusCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CoverageStatus elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCoverageStatusCollection = this;
			else
				elem.ParentCoverageStatusCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CoverageStatus elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CoverageStatus this[int index]
		{
			get
			{
				return (CoverageStatus)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CoverageStatus)oldValue, false);
			SetParentOnElem((CoverageStatus)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Load the collection with status codes either active or inactive.
		/// </summary>
		public int LoadCoverageStatusCodesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetCoverageStatusCodesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared CoverageStatusCollection which is cached in NSGlobal.
		/// Returns all active coverage status codes.
		/// </summary>
		public static CoverageStatusCollection ActiveCoverageStatusCodes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				CoverageStatusCollection col = (CoverageStatusCollection)NSGlobal.EnsureCachedObject("CoverageStatuses", typeof(CoverageStatusCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadCoverageStatusCodesByActive(-1, true);
				}
				return col;
			}			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllCoverageStatusCodes", -1, this, false);
		}	
	}
}
