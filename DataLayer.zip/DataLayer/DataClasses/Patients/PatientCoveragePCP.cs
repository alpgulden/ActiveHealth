using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientCoveragePCP]
	/// </summary>
	[SPInsert("usp_InsertPatientCoveragePCP")]
	[SPUpdate("usp_UpdatePatientCoveragePCP")]
	[SPDelete("usp_DeletePatientCoveragePCP")]
	[SPLoad("usp_LoadPatientCoveragePCP")]
	[TableMapping("PatientCoveragePCP","patientCoveragePCPID")]
	public class PatientCoveragePCP : BaseData
	{
		[NonSerialized]
		private PatientCoveragePCPCollection parentPatientCoveragePCPCollection;
		[ColumnMapping("PatientCoveragePCPID",StereoType=DataStereoType.FK)]
		private int patientCoveragePCPID;
		[ColumnMapping("PatientCoverageID",StereoType=DataStereoType.FK)]
		private int patientCoverageID;
		[ColumnMapping("PCPID",StereoType=DataStereoType.FK)]
		private int pCPID;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("ProviderSpecialtyTypeID",StereoType=DataStereoType.FK)]
		private int providerSpecialtyTypeID;
		[ColumnMapping("Status")]
		private string status;				// this is not network status
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

		private Provider provider;						// loaded and cached provider object
		private ProviderLocation providerLocation;		// loaded and cached provider loacation object
	
		public PatientCoveragePCP()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PatientCoveragePCP(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientCoveragePCPID
		{
			get { return this.patientCoveragePCPID; }
			set { this.patientCoveragePCPID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientCoverageID
		{
			get { return this.patientCoverageID; }
			set { this.patientCoverageID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set 
			{
				this.providerLocationID = value;
				this.providerLocation = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientCoveragePCPID)
		{
			return base.Load(patientCoveragePCPID);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PCPID
		{
			get { return this.pCPID; }
			set 
			{
				this.pCPID = value; 
				this.provider = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ProviderSpecialtyTypeID
		{
			get { return this.providerSpecialtyTypeID; }
			set { this.providerSpecialtyTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string Status
		{
			get { return this.status; }
			set { this.status = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		/// <summary>
		/// Parent PatientCoveragePCPCollection that contains this element
		/// </summary>
		public PatientCoveragePCPCollection ParentPatientCoveragePCPCollection
		{
			get
			{
				return this.parentPatientCoveragePCPCollection;
			}
			set
			{
				this.parentPatientCoveragePCPCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Load and return the provider location record.
		/// </summary>
		/// <returns></returns>
		public ProviderLocation GetProviderLocation()
		{
			if (this.providerLocationID == 0)
				return null;
			ProviderLocation providerLocation = new ProviderLocation();
			if (providerLocation.Load(this.providerLocationID))
				return providerLocation;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached provider location object.
		/// </summary>
		public ProviderLocation ProviderLocation
		{
			get 
			{
				if (this.providerLocation == null)
					this.providerLocation = GetProviderLocation();
				return this.providerLocation;
			}
		}

		/// <summary>
		/// Load and return the provider record.
		/// </summary>
		/// <returns></returns>
		public Provider GetProvider()
		{
			if (this.pCPID == 0)
				return null;
			Provider provider = new Provider();
			if (provider.Load(this.pCPID))
				return provider;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached provider object.
		/// </summary>
		public Provider Provider
		{
			get 
			{
				if (this.provider == null)
					this.provider = GetProvider();
				return this.provider;
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.asOfDate = DateTime.Today;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		[FieldDescription("@PCPNAME@")]
		public string PCPFullName
		{
			get { return Provider.GetProviderFullNameWithPrefixByID(this.pCPID); }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		[FieldDescription("@LOCATION@")]
		public string PCPLocationAddress
		{
			get { return Location.GetLocationAddressDescriptionByID(this.providerLocationID); }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		[FieldDescription("@SPECIALTY@")]
		public string PCPSpecialty
		{
			get { return Specialty.GetSpecialtyByID(this.providerSpecialtyTypeID); }
		}
	}

	/// <summary>
	/// Strongly typed collection of PatientCoveragePCP objects
	/// </summary>
	[ElementType(typeof(PatientCoveragePCP))]
	public class PatientCoveragePCPCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientCoveragePCP elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientCoveragePCPCollection = this;
			else
				elem.ParentPatientCoveragePCPCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientCoveragePCP elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientCoveragePCP this[int index]
		{
			get
			{
				return (PatientCoveragePCP)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientCoveragePCP)oldValue, false);
			SetParentOnElem((PatientCoveragePCP)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PatientCoveragePCP elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PatientCoveragePCP)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent PatientCoverage that contains this collection
		/// </summary>
		public PatientCoverage ParentPatientCoverage
		{
			get { return this.ParentDataObject as PatientCoverage; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PatientCoverage */ }
		}
	}

}
