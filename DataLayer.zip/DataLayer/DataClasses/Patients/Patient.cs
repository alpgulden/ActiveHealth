using System;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Collections;


namespace ActiveAdvice.DataLayer
{
	public enum EnumIntakeSearchBy 
	{
		Patient = 0,
		MemberEligibility = 1
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [Patients]
	/// 
	/// A Patient is a person in need of the health services that AHM and its clients provide. 
	/// The information required to provide services to a patient comes from a variety of sources.
	/// Full or partial patient information may be provided by "external data feeds". Patient 
	/// information may also be collected by a manual process of "eliciting the information" 
	/// from the "patient" or their "care provider". Patient may also be provided by the 
	/// "Client" with the "eligibility information".
	/// To determine if a patient is eligible for services, eligibility information is required. 
	/// 
	/// The patient may be "eligible" through "subscription in a healthcare plan", or by 
	/// "relation to a subscriber". The Health Plan Provider may provide information indicating 
	/// that a subscriber is eligible for services. In cases where this information is not 
	/// provided, services may optionally be rendered to the patient without eligibility 
	/// verification.
	/// 
	/// The Patient record contains demographic information that is required to uniquely 
	/// identify a patient. In addition, Patient records contain additional information that 
	/// provides patient-specific health information such as Medications, Allergies and 
	/// Measurements (i.e. Blood Pressure, height/weight, etc.).
	///   
	/// </summary>
	[SPInsert("usp_InsertPatient")]
	[SPUpdate("usp_UpdatePatient")]
	[SPDelete("usp_DeletePatient")]
	[SPLoad("usp_LoadPatient")]
	[TableMapping("Patient","patientId")]
	public class Patient : BaseDataWithUserDefined, IContactOwner,IImageOwner
	{
		[NonSerialized]
		protected PatientCollection parentPatientCollection;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		protected int patientId;
		[ColumnMapping("LastName")]
		protected string lastName;
		[ColumnMapping("FirstName")]
		protected string firstName;
		[ColumnMapping("MiddleInitial")]
		protected string middleInitial;
		[ColumnMapping("NamePrefixId",StereoType=DataStereoType.FK)]
		protected int namePrefixId;
		[ColumnMapping("NameSuffix")]
		protected string nameSuffix;
		[ColumnMapping("Gender",StereoType=DataStereoType.Gender)]
		protected string gender;
		[ColumnMapping("DateOfBirth")]
		protected DateTime dateOfBirth;
		[ColumnMapping("SocialSecurityNumber",StereoType=DataStereoType.USSSN)]
		protected string socialSecurityNumber;
		//protected Byte[] socialSecurityNumber;
		[ColumnMapping("AddressID")]
		protected int addressID;
		[ColumnMapping("LanguageID",StereoType=DataStereoType.FK)]
		protected int languageID;
		[ColumnMapping("AssignedTeamId",StereoType=DataStereoType.FK)]
		protected int assignedTeamId;
		[ColumnMapping("AssignedUserId",StereoType=DataStereoType.FK)]
		protected int assignedUserId;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("PrimaryCOBId",StereoType=DataStereoType.FK)]
		protected int primaryCOBId;
		[ColumnMapping("AsOfDate")]
		protected DateTime asOfDate;
		[ColumnMapping("MedicareID")]
		protected string medicareID;
		[ColumnMapping("MedicaidID")]
		protected string medicaidID;
		[ColumnMapping("RelatedEventID",StereoType=DataStereoType.FK)]
		protected int relatedEventID;
		[ColumnMapping("RelatedProblemID",StereoType=DataStereoType.FK)]
		protected int relatedProblemID;

		//[ColumnMapping("AsOfDate", SQLGen=SQLGenerationFlags.NoInsert | SQLGenerationFlags.NoUpdate | SQLGenerationFlags.NoSelect, InjectSearch="{0} > @{1}")]
		//protected DateTime asOfDateStart;
		/*[ColumnMapping("AsOfDate", SQLGen=SQLGenerationFlags.NoInsert | SQLGenerationFlags.NoUpdate | SQLGenerationFlags.NoSelect, InjectSearch="{0} < @{1}")]
		protected DateTime asOfDateEnd;*/

		protected Address address;
		protected PatientContactCollection patientContacts;
		protected PatientFocusHistoryCollection patientFocusHistory;
		protected PatientCOBCollection patientCOBs;
		protected PatientProblemCollection patientProblems;
		protected PatientMedicationCollection patientMedications;
		protected PatientAllergyCollection patientAllergies;
		protected PatientMeasurementCollection patientMeasurements;
		protected PatientCoverageCollection patientCoverages;
		protected Event mostRecentEvent;
		protected ImageLinkCollection images;

		protected bool createdAsBaby;				// true when creating a baby.
		
		public bool displaySummaryForPLI = false;

		/*private int primaryPatientCoverageID = 0;		// Filled from coverage thru search..
		private int primarySubscriberID = 0;			// Filled from coverage thru search..
		private string primaryPatientAlternateID;		// Filled from coverage thru search..
		private DateTime effectiveDate;					// Filled from coverage thru search..
		private DateTime terminationDate;					// Filled from coverage thru search..
		*/

		//protected PatientProblem selectedPatientProblem;				// child items in the hiearchy may use this.

		//protected DateTime termDateWhenLoaded;
	
		public Patient()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Patient(string firstName, string lastName, string gender)
		{
			this.NewRecord(); // initialize record state
			this.firstName = firstName;
			this.lastName = lastName;
			this.gender = gender;
		}

		public Patient(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/*/// <summary>
		/// Used to keep the current problem context. Save of child items may use this.
		/// </summary>
		public PatientProblem SelectedPatientProblem
		{
			get { return this.selectedPatientProblem; }
			set { this.selectedPatientProblem = value; }
		}*/

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		[FieldDescription("@LASTNAME@")]
		public string LastName
		{
			get { return this.lastName; }
			set { this.lastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@FIRSTNAME@")]
		public string FirstName
		{
			get { return this.firstName; }
			set { this.firstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		[FieldDescription("@MIDDLEINITIAL@")]
		public string MiddleInitial
		{
			get { return this.middleInitial; }
			set { this.middleInitial = value; }
		}

		[FieldValuesMember("LookupOf_NamePrefixId", "NamePrefixId", "Prefix")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@NAMEPREFIX@")]
		public int NamePrefixId
		{
			get { return this.namePrefixId; }
			set { this.namePrefixId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		[FieldDescription("@NAMESUFFIX@")]
		public string NameSuffix
		{
			get { return this.nameSuffix; }
			set { this.nameSuffix = value; }
		}

		[FieldValuesMember("ValuesOf_Gender")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, MaxLength=1)]
		[FieldDescription("@GENDER@")]
		public string Gender
		{
			get { return this.gender; }
			set { this.gender = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DATEOFBIRTH@")]
		public System.DateTime DateOfBirth
		{
			get { return this.dateOfBirth; }
			set { this.dateOfBirth = value; }
		}

		[FieldValuesMember("LookupOf_LanguageID", "LanguageID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@LANGUAGE@")]
		public int LanguageID
		{
			get { return this.languageID; }
			set { this.languageID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldValuesMember("LookupOf_TeamID", "TeamId", "Code")]
		[FieldDescription("@ASSIGNEDTEAM@")]
		public int AssignedTeamId
		{
			get { return this.assignedTeamId; }
			set { this.assignedTeamId = value; }
		}

		[FieldDescription("@ASSIGNEDTEAM@")]
		public string AssignedTeamString
		{
			get { return FormatTeamForDisplay(this.AssignedTeamId); }
		}

		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldValuesMember("LookupOf_UserID", "UserId", "LoginName")]
		[FieldDescription("@ASSIGNEDUSER@")]
		public int AssignedUserId
		{
			get { return this.assignedUserId; }
			set { this.assignedUserId = value; }
		}

		[FieldDescription("@ASSIGNEDUSER@")]
		public string AssignedUserString
		{
			get { return FormatUserForDisplay(this.AssignedUserId); }
		}

		[ControlType(Macro=EnumControlTypeMacros.USSSN)]
		[FieldDescription("@SOCIALSECURITY@")]
		public string SocialSecurityNumber
		{
			get { return this.socialSecurityNumber; }
			set 
			{ 
				this.socialSecurityNumber = ParseSSN( value );
			}
			//get { return DecryptSSN(this.socialSecurityNumber); }
			//set { this.socialSecurityNumber = EncryptSSN(value); }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch(Exception ex)
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				Debug.WriteLine(ex);
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientId)
		{
			Debug.WriteLine( AASecurityHelper.AAUser.Name );

			return base.Load(patientId);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			//this.effectiveDate = DateTime.Today;
			this.addressID = 0;
			this.assignedUserId = AASecurityHelper.GetUserId;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		#region Address
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}

		/// <summary>
		/// Contained Address object
		/// </summary>
		[Contained]
		public Address Address
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.address = (Address)Address.EnsureContainedDataObject(this, typeof(Address), address, false, addressID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.address;
			}
			set
			{
				this.address = value;
				if (value != null) value.ParentPatient = this; // set this as a parent of the child data class
			}
		}

		[FieldDescription("@STREETADDR1@")]
		public string Line1
		{	get{ return this.Address.Line1;}}

		[FieldDescription("@STREETADDR2@")]
		public string Line2
		{	get{ return this.Address.Line2;}}

		[FieldDescription("@STREETADDR3@")]
		public string Line3
		{	get{ return this.Address.Line3;}}

		[FieldDescription("@CITY@")]
		public string City
		{	get{ return this.Address.City;}}

		[FieldDescription("@STATE@")]
		public string State
		{	get{ return this.Address.State;}}

		[FieldDescription("@ZIPCODE@")]
		public string Zip
		{	get{ return this.Address.Zip;}}

		[FieldDescription("@PHONE1@")]
		public string Phone1Full
		{	get { return this.Address.Phone1Full; } }

		[FieldDescription("@PHONE2@")]
		public string Phone2Full
		{	get { return this.Address.Phone2Full; } }

		[FieldDescription("@PHONE3@")]
		public string Phone3Full
		{	get { return this.Address.Phone3Full; } }

		[FieldDescription("@FAX@")]
		public string FaxFull
		{	get { return this.Address.FaxFull; } }

		#endregion

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			//termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to load child and other objects that must be loaded with this object.
		/// </summary>
		protected override bool InternalLoad(params object[] keys)
		{
			// Do pre-load operations here.
			bool result = base.InternalLoad(keys);
			// Do post-load operations here.
			return result;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.

			bool isNew = this.IsNew;
			this.Address.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			{
				base.InternalSave();	// in that case, delete the base first
				Address.MarkDel();	// then allow the deletion of the conatined object
			}
			Address.IsNew = this.IsNew;	// make sure the contained object is new if the containing object is new
			Address.Save();
			this.addressID = Address.AddressID; // set the fk if the contained object was newly created
			/*if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}*/

			base.InternalSave();
			// Save the child collections here.

			this.SavePatientFocusHistory();

			this.SavePatientCOBs();

			// If the primary COB was not selected so far, try to select the first
			if (this.primaryCOBId == 0)
			{
				if (this.PatientCOBs != null && this.PatientCOBs.Count > 0)
				{
					// Select the first COB as primary
					this.UpdatePrimaryCOBForPatient(this.PatientCOBs[0].PatientCOBID);
				}
				
			}

			// PT1 is triggered in Subscriber.Save() because we also need a coverage to create activities!
		}

		/// <summary>
		/// PT1	- Patient Initial Save
		/// BP1	- Baby Patient Initial Save
		/// This is triggered when the patient is saved with a coverage from subscriber.Save
		/// </summary>
		public void AutoActivity_PatientInitialSave(PatientCoverage patientCoverage)
		{
			autoActivityManager = new AutoActivityManager(this, patientCoverage, null, null);
			autoActivityManager.Execute(AutoActivityRuleType.PT1, this.SqlData.Transaction);		// PT1 - Patient Initial Save

			if (this.createdAsBaby)
				autoActivityManager.Execute(AutoActivityRuleType.BP1, this.SqlData.Transaction);	// BP1 - Baby Patient Initial Save
		}

		/// <summary>
		/// Indirect access to the LanguageID.  You can set/get a language code 
		/// instead of language id.
		/// </summary>
		/*[ControlType(Macro=EnumControlTypeMacros.StringLookup, IsRequired=true)]
		public string LanguageCode
		{
			get { return LanguageCollection.ActiveLanguages.Lookup_LanguageCode_By_LanguageID(this.languageID); }
			set { this.languageID = LanguageCollection.ActiveLanguages.Lookup_LanguageID_By_LanguageCode(value); }
		}*/

		public NamePrefixCollection LookupOf_NamePrefixId
		{
			get
			{
				return NamePrefixCollection.ActiveNamePrefixes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Parent PatientCollection that contains this element
		/// </summary>
		public PatientCollection ParentPatientCollection
		{
			get
			{
				return this.parentPatientCollection;
			}
			set
			{
				this.parentPatientCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, IsRequired=true)]
		public string LanguageCode
		{
			get { return LanguageCollection.ActiveLanguages.Lookup_LanguageCodeByLanguageID(this.languageID); }
			set { this.languageID = LanguageCollection.ActiveLanguages.Lookup_LanguageIDByLanguageCode(value); }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PrimaryCOBId
		{
			get { return this.primaryCOBId; }
			set { this.primaryCOBId = value; }
		}

		/// <summary>
		/// Child PatientContacts mapped to related rows of table PatientContact where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientContacts", "patientID")]
		public PatientContactCollection PatientContacts
		{
			get { return this.patientContacts; }
			set
			{
				this.patientContacts = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientContacts collection
		/// </summary>
		public void LoadPatientContacts(bool forceReload)
		{
			this.patientContacts = (PatientContactCollection)PatientContactCollection.LoadChildCollection("PatientContacts", this, typeof(PatientContactCollection), patientContacts, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientContacts collection
		/// </summary>
		public void SavePatientContacts()
		{
			PatientContactCollection.SaveChildCollection(this.patientContacts, true);
		}

		/// <summary>
		/// Synchronizes the PatientContacts collection
		/// </summary>
		public void SynchronizePatientContacts()
		{
			PatientContactCollection.SynchronizeChildCollection(this.patientContacts, true);
		}
		
		#region IContactOwner Members

		public BaseDataCollectionClass GetContacts()
		{
			if (PatientContacts == null) LoadPatientContacts(false);
			return PatientContacts;
		}

		public void LoadContacts(bool forceLoad)
		{
			this.LoadPatientContacts(forceLoad);
		}

		public void SaveContacts()
		{
			this.SavePatientContacts();
		}

		public ContactOwnerType ContactOwnerType
		{
			get
			{
				return ContactOwnerType.Patient;
			}
		}

		#endregion

		public LanguageCollection LookupOf_LanguageID
		{
			get
			{
				return LanguageCollection.ActiveLanguages; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(EnumControlTypes.TextBox|EnumControlTypes.ComboBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@NAME@")]
		public string Fmt_FullName
		{
			get { return FormatFNameLName(this.lastName, this.firstName); }
		}

		[FieldDescription("@AGE@")]
		public string AgeYearMonths
		{
			get
			{
				if (this.dateOfBirth == DateTime.MinValue)
					return "@UNKNOWN@";
				int years = 0, months = 0;
				CalculateYearsMonths(this.dateOfBirth, DateTime.Today, ref years, ref months);
				return String.Format("{0} @YEARS@ {1} @MOS@", years, months);
			}
		}

		[FieldDescription("@AGE@")]
		public int AgeYears
		{
			get
			{
				return CalculateYears(this.dateOfBirth, DateTime.Today);
			}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if(displaySummaryForPLI)
			{
				//Printed list must include: Patient name,  patient address, city, state, zip,
				writer.AddFieldsSubstituted(this, "@Fmt_FullName@", Messages.PatientMessages.MessageIDs.PATIENTSUMMARY);
				writer.AddFieldOnNewLine(this, "Line1");
				if(this.Address.Line2 != null)
					writer.AddFieldOnNewLine(this, "Line2");
				if(this.Address.Line3 != null)
					writer.AddFieldOnNewLine(this, "Line3");
				writer.AddFieldsOnNewLine(this, "City", "State", "Zip");
				displaySummaryForPLI = false;	// return to default state.
				return;
			}

			writer.AddFieldsSubstituted(this, "@PatientId@-@Fmt_FullName@", Messages.PatientMessages.MessageIDs.PATIENTSUMMARY);
			writer.AddFieldsOnNewLine(this, "SocialSecurityNumber", "Gender");
			writer.AddFieldsOnNewLine(this, "DateOfBirth", "AgeYearMonths");
		}

		/// <summary>
		/// Child PatientFocusHistory mapped to related rows of table PatientFocusHistory where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientFocusHistories", "patientID")]
		public PatientFocusHistoryCollection PatientFocusHistory
		{
			get { return this.patientFocusHistory; }
			set
			{
				this.patientFocusHistory = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientFocusHistory collection
		/// </summary>
		public void LoadPatientFocusHistory(bool forceReload)
		{
			this.patientFocusHistory = (PatientFocusHistoryCollection)PatientFocusHistoryCollection.LoadChildCollection("PatientFocusHistory", this, typeof(PatientFocusHistoryCollection), patientFocusHistory, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientFocusHistory collection
		/// </summary>
		public void SavePatientFocusHistory()
		{
			PatientFocusHistoryCollection.SaveChildCollection(this.patientFocusHistory, true);
		}

		/// <summary>
		/// Synchronizes the PatientFocusHistory collection
		/// </summary>
		public void SynchronizePatientFocusHistory()
		{
			PatientFocusHistoryCollection.SynchronizeChildCollection(this.patientFocusHistory, true);
		}

		/// <summary>
		/// Child PatientCOBs mapped to related rows of table PatientCOB where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientCOBs", "patientID")]
		public PatientCOBCollection PatientCOBs
		{
			get { return this.patientCOBs; }
			set
			{
				this.patientCOBs = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientCOBs collection
		/// </summary>
		public void LoadPatientCOBs(bool forceReload)
		{
			this.patientCOBs = (PatientCOBCollection)PatientCOBCollection.LoadChildCollection("PatientCOBs", this, typeof(PatientCOBCollection), patientCOBs, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientCOBs collection
		/// </summary>
		public void SavePatientCOBs()
		{
			PatientCOBCollection.SaveChildCollection(this.patientCOBs, true);
		}

		/// <summary>
		/// Synchronizes the PatientCOBs collection
		/// </summary>
		public void SynchronizePatientCOBs()
		{
			PatientCOBCollection.SynchronizeChildCollection(this.patientCOBs, true);
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		/// <summary>
		/// Child PatientProblems mapped to related rows of table PatientProblem where [PatientId] = [PatientId]
		/// </summary>
		[SPLoadChild("usp_LoadPatientProblems", "patientId")]
		public PatientProblemCollection PatientProblems
		{
			get { return this.patientProblems; }
			set
			{
				this.patientProblems = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientProblems collection
		/// </summary>
		public void LoadPatientProblems(bool forceReload)
		{
			this.patientProblems = (PatientProblemCollection)PatientProblemCollection.LoadChildCollection("PatientProblems", this, typeof(PatientProblemCollection), patientProblems, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientProblems collection
		/// </summary>
		public void SavePatientProblems()
		{
			PatientProblemCollection.SaveChildCollection(this.patientProblems, true);
		}

		/// <summary>
		/// Synchronizes the PatientProblems collection
		/// </summary>
		public void SynchronizePatientProblems()
		{
			PatientProblemCollection.SynchronizeChildCollection(this.patientProblems, true);
		}


		/// <summary>
		/// Returns the actual collection of problems linked to this patient.
		/// </summary>
		/// <returns></returns>
		public ProblemCollection GetLinkedProblems()
		{
			ProblemCollection problems = new ProblemCollection();
			problems.LoadLinkedPatientProblems(this);
			return problems;
		}
		
		/// <summary>
		/// Returns the actual collection of events linked to this patient.
		/// </summary>
		/// <returns></returns>
		public EventCollection GetLinkedEvents()
		{
			EventCollection events = new EventCollection();
			events.LoadLinkedPatientEvents(this);
			return events;
		}

		/// <summary>
		/// Returns the actual collection of CMS linked to this patient.
		/// </summary>
		/// <returns></returns>
		public CMSCollection GetLinkedCMSs()
		{
			CMSCollection cmss = new CMSCollection();
			cmss.LoadLinkedPatientCMSs(this);
			return cmss;
		}

		/// <summary>
		/// Returns the actual collection of Referrals linked to this patient.
		/// </summary>
		/// <returns></returns>
		public ReferralCollection GetLinkedReferrals()
		{
			ReferralCollection referrals = new ReferralCollection();
			referrals.LoadLinkedPatientReferrals(this);
			return referrals;
		}

		/// <summary>
		/// Gets a collection of an ERC (event/referrral/cms type data objects).
		/// </summary>
		/// <param name="ercType"></param>
		/// <returns></returns>
		public BaseCollectionForEventCMSReferral GetLinkedERCs(EnumERCType ercType)
		{
			switch (ercType)
			{
				/*case EnumERCType.All:
				{
					BaseCollectionForEventCMSReferral all = new BaseCollectionForEventCMSReferral();
					all.AppendToCollection(GetLinkedEvents());			// append events
					all.AppendToCollection(GetLinkedReferrals());		// append referrals
					all.AppendToCollection(GetLinkedCMSs());			// append CMSs.
					return all;
				}*/
				case EnumERCType.Event:
				{
					return GetLinkedEvents();
				}
				case EnumERCType.CMS:
				{
					return GetLinkedCMSs();
				}
				case EnumERCType.Referral:
				{
					return GetLinkedReferrals();
				}
			}
			throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Invalid ERC Type asked from Patient.GetLinkedERCs");
		}

		/// <summary>
		/// Child PatientMedications mapped to related rows of table PatientMedication where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_SearchPatientMedications", "patientID", ManuallyManaged=true /*Managed at PatientMedication.cs*/)]
		public PatientMedicationCollection PatientMedications
		{
			get { return this.patientMedications; }
			set
			{
				this.patientMedications = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientMedications collection
		/// </summary>
		public void LoadPatientMedications(bool forceReload)
		{
			this.patientMedications = (PatientMedicationCollection)PatientMedicationCollection.LoadChildCollection("PatientMedications", this, typeof(PatientMedicationCollection), patientMedications, forceReload, null,
				new object[]{ this.patientId, DBNull.Value, 1});
		}

		/// <summary>
		/// Saves the PatientMedications collection
		/// </summary>
		public void SavePatientMedications()
		{
			PatientMedicationCollection.SaveChildCollection(this.patientMedications, true);
		}

		/// <summary>
		/// Synchronizes the PatientMedications collection
		/// </summary>
		public void SynchronizePatientMedications()
		{
			PatientMedicationCollection.SynchronizeChildCollection(this.patientMedications, true);
		}

		/// <summary>
		/// Child PatientAllergies mapped to related rows of table PatientAllergy where [PatientId] = [PatientId]
		/// </summary>
		[SPLoadChild("usp_LoadPatientPatientAllergy", "patientId")]
		public PatientAllergyCollection PatientAllergies
		{
			get { return this.patientAllergies; }
			set
			{
				this.patientAllergies = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientAllergies collection
		/// </summary>
		public void LoadPatientAllergies(bool forceReload)
		{
			this.patientAllergies = (PatientAllergyCollection)PatientAllergyCollection.LoadChildCollection("PatientAllergies", this, typeof(PatientAllergyCollection), patientAllergies, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientAllergies collection
		/// </summary>
		public void SavePatientAllergies()
		{
			PatientAllergyCollection.SaveChildCollection(this.patientAllergies, true);
		}

		/// <summary>
		/// Synchronizes the PatientAllergies collection
		/// </summary>
		public void SynchronizePatientAllergies()
		{
			PatientAllergyCollection.SynchronizeChildCollection(this.patientAllergies, true);
		}

		/// <summary>
		/// Child PatientMeasurements mapped to related rows of table PatientMeasurement where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientPatientMeasurement", "patientID")]
		public PatientMeasurementCollection PatientMeasurements
		{
			get { return this.patientMeasurements; }
			set
			{
				this.patientMeasurements = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientMeasurements collection
		/// </summary>
		public void LoadPatientMeasurements(bool forceReload)
		{
			this.patientMeasurements = (PatientMeasurementCollection)PatientMeasurementCollection.LoadChildCollection("PatientMeasurements", this, typeof(PatientMeasurementCollection), patientMeasurements, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientMeasurements collection
		/// </summary>
		public void SavePatientMeasurements()
		{
			PatientMeasurementCollection.SaveChildCollection(this.patientMeasurements, true);
		}

		/// <summary>
		/// Synchronizes the PatientMeasurements collection
		/// </summary>
		public void SynchronizePatientMeasurements()
		{
			PatientMeasurementCollection.SynchronizeChildCollection(this.patientMeasurements, true);
		}

		/// <summary>
		/// Child PatientCoverages mapped to related rows of table PatientCoverage where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientCoverages", "patientID")]
		public PatientCoverageCollection PatientCoverages
		{
			get { return this.patientCoverages; }
			set
			{
				this.patientCoverages = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientCoverages collection
		/// </summary>
		public void LoadPatientCoverages(bool forceReload)
		{
			this.patientCoverages = (PatientCoverageCollection)PatientCoverageCollection.LoadChildCollection("PatientCoverages", this, typeof(PatientCoverageCollection), patientCoverages, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientCoverages collection
		/// </summary>
		public void SavePatientCoverages()
		{
			PatientCoverageCollection.SaveChildCollection(this.patientCoverages, true);
		}

		/// <summary>
		/// Synchronizes the PatientCoverages collection
		/// </summary>
		public void SynchronizePatientCoverages()
		{
			PatientCoverageCollection.SynchronizeChildCollection(this.patientCoverages, true);
		}

		/// <summary>
		/// Load and return a collection of patient coverages from the database.
		/// </summary>
		/// <returns></returns>
		public PatientCoverageCollection GetPatientCoverages()
		{
			PatientCoverageCollection patCovCol = new PatientCoverageCollection();
			patCovCol.LoadPatientCoverages(-1, this.patientId, 0);
			if (patCovCol.Count == 0)
				return null;
			else
				return patCovCol;
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MedicareID
		{
			get { return this.medicareID; }
			set { this.medicareID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MedicaidID
		{
			get { return this.medicaidID; }
			set { this.medicaidID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RelatedEventID
		{
			get { return this.relatedEventID; }
			set { this.relatedEventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RelatedProblemID
		{
			get { return this.relatedProblemID; }
			set { this.relatedProblemID = value; }
		}

		/// <summary>
		/// Get the most recent event of this patient
		/// </summary>
		/// <returns></returns>
		public Event GetMostRecentEvent()
		{
			if (this.IsNew)
				return null;
			Event mostRecentEvent = new Event();
			if (mostRecentEvent.LoadMostRecentEventForPatient(this))
				return mostRecentEvent;
			else
				return null;
		}

		/// <summary>
		/// Loaded and cached most recent event
		/// </summary>
		public Event MostRecentEvent
		{
			get
			{
				if (mostRecentEvent == null)
					mostRecentEvent = GetMostRecentEvent();
				return mostRecentEvent;
			}
		}

		/// <summary>
		/// Import patient properties form eligibility
		/// </summary>
		/// <param name="elig"></param>
		public void ImportFromEligibility(Eligibility elig)
		{
			//if (elig.IsSubscriber)
			//	throw new ActiveAdviceException(AAExceptionAction.None, "Can't import patient from eligibility record of a subscriber");
			this.AsOfDate = elig.AsOfDate;
			this.FirstName = elig.FirstName;
			this.LastName = elig.LastName;
			this.Address.ImportFromEligibility(elig);
			this.SocialSecurityNumber = elig.MemberSSN;
			this.DateOfBirth = elig.MemberDOB;
			this.Gender = elig.MemberGender;
			this.MiddleInitial = elig.MiddleInitial;
			this.NameSuffix = elig.NameSuffix;
			this.MedicareID = elig.MedicareId;
			this.MedicaidID = elig.MedicaidId;
			//this.LanguageID = LanguageCollection.ActiveLanguages.Lookup_LanguageIDByLanguageCode(elig.Race);
		}

		#region Images Overriden
		/// <summary>
		/// Child Outcomes mapped to related rows of table Outcome where [CMSID] = [CMSID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientImages", "patientID")]
		public ImageLinkCollection Images
		{
			get { return this.images; }
			set
			{
				this.images = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}
				
		/// <summary>
		/// Loads the Outcomes collection
		/// </summary>
		public void LoadImages(bool forceReload)
		{
			this.images = (ImageLinkCollection)ImageLinkCollection.LoadChildCollection("Images", this, typeof(ImageLinkCollection), images, forceReload, null);
		}

		/// <summary>
		/// Saves the Outcomes collection
		/// </summary>
		public void SaveImages()
		{
			ImageLinkCollection.SaveChildCollection(this.images, true);
		}

		/// <summary>
		/// Synchronizes the Outcomes collection
		/// </summary>
		public void SynchronizeImages()
		{
			ImageLinkCollection.SynchronizeChildCollection(this.images, true);
		}

		#endregion

		public bool CreatedAsBaby
		{
			get { return this.createdAsBaby; }
		}

		public static Patient CreateBaby()
		{
			Patient patient = new Patient(true);
			patient.createdAsBaby = true;
			return patient;
		}

		public static Patient CreateBaby(string firstName, string lastName, string gender)
		{
			Patient patient = new Patient(firstName, lastName, gender);
			patient.createdAsBaby = true;
			return patient;
		}

		public PRRequestCollection GetPatientPRRequests()
		{
			PRRequestCollection phyRevs = new PRRequestCollection();
			phyRevs.LoadPatientPRRequests(-1, this.patientId);
			return phyRevs;
		}

		/// <summary>
		/// Returns true if the patient has any open CMS cases.
		/// If the problemID is 0, all CMSs of the patient are checked.
		/// If the problemID is given, all CMSs of the patient matching the primary problem id of the CMS are checked.
		/// </summary>
		public bool HasPatientOpenCMSs(int problemID)
		{
			return Convert.ToBoolean( SqlData.SPExecScalar("usp_HasPatientOpenCMSs", 
				new object[] 
				{ 
					this.patientId, 
					SQLDataDirect.MakeDBValue(problemID, (int)0)
				}) );
		}

		/// <summary>
		/// Returns true if the patient has any open CMS cases.
		/// If the problem is null, all CMSs of the patient are checked.
		/// If the problem is given, all CMSs of the patient matching the primary problem id of the CMS are checked.
		/// </summary>
		public bool HasPatientOpenCMSs(Problem problem)
		{
			return HasPatientOpenCMSs(problem == null ? 0 : problem.ProblemID);
		}

		/// <summary>
		/// Returns true if the patient has any open CMS cases.
		/// </summary>
		public bool HasPatientOpenCMSs()
		{
			return HasPatientOpenCMSs(0);	// check all CMS cases of the patient
		}

		/// <summary>
		/// Updates the primary COB ID for the patient.
		/// </summary>
		public void UpdatePrimaryCOBForPatient(int primaryPatientCOBID)
		{
			SqlData.SPExecNonQuery("usp_UpdatePrimaryCOBForPatient", 
				new object[] { this.patientId, primaryPatientCOBID });
			this.primaryCOBId = primaryPatientCOBID;
		}

		public override SQLDataDirect SqlData
		{
			get
			{
				if (this.sqlData == null)
					this.sqlData = SQLDataDirect.CreateSqlDataForType(typeof(Patient));
				return this.sqlData;
			}
			set
			{
				this.sqlData = value;
			}
		}

		// FORK 1.1
		/// <summary>
		/// Will use to subsiture Load Paitent method when security function needed.
		/// </summary>
		public bool LoadPatientwithDASecurity(int patientId)
		{
			int iUserId = AASecurityHelper.GetUserId;
			return SqlData.SPExecReadObj("usp_LoadPatientwithDASecurity", this, false, new object[] { patientId, iUserId });
		}
		//
	}

	/// <summary>
	/// Strongly typed collection of Patient objects
	/// </summary>
	[ElementType(typeof(Patient))]
	public class PatientCollection : BaseDataCollectionClass//, ICollectionElementFilter
	{
		public const int MAXRECORDS = 20;		//  -1 = unlimited

		//private bool fillExtraFields = false;

		/*private string filterState = null;		// if this is set, the collection can be filtered by state
		public string FilterState
		{	
			get { return this.filterState; }
			set { this.filterState = value; }
		}*/

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Patient elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientCollection = this;
			else
				elem.ParentPatientCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Patient elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Patient this[int index]
		{
			get
			{
				return (Patient)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Patient)oldValue, false);
			SetParentOnElem((Patient)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/*protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);

			if (fillExtraFields)
			{
				((Patient)data).PrimaryPatientCoverageID = SQLDataDirect.GetFromDBValue( rdr["PrimaryPatientCoverageID"], (int)0 );
				((Patient)data).PrimarySubscriberID = SQLDataDirect.GetFromDBValue( rdr["PrimarySubscriberID"], (int)0 );
				((Patient)data).PrimaryPatientAlternateID = SQLDataDirect.GetFromDBValue( rdr["PrimaryPatientAlternateID"], (string)null );	// PatientAlternateID from the Primary Coverage.
			}
		}*/


		/*#region ICollectionElementFilter Members

		public bool FilterElement(int index)
		{
			return (filterState == null) || (this[index].Address.State == filterState);
		}

		#endregion*/
	}

	[SPAutoGen("usp_SearchPatientswithDAFilter", null, ManuallyManaged=true)]
	[SPAutoGen("usp_SearchPatientsByPatientAndSubscriberInfo", null, ManuallyManaged=true)]
	// FORK 1.0
	[SPAutoGen("usp_GetPatientsLinkedToEligibility", null, ManuallyManaged=true)]
	// END FORK 1.0
	[TableMapping("Patient","patientId")]
	public class PatientSearchResult : BaseData
	{
		[NonSerialized]
		protected PatientSearchResultCollection parentPatientSearchResultCollection;

		[ColumnMapping("PatientId",StereoType=DataStereoType.PK)]
		protected int patientId;
		[ColumnMapping("LastName")]
		protected string lastName;
		[ColumnMapping("FirstName")]
		protected string firstName;
		[ColumnMapping("MiddleInitial")]
		protected string middleInitial;
		[ColumnMapping("Gender",StereoType=DataStereoType.Gender)]
		protected string gender;
		[ColumnMapping("DateOfBirth")]
		protected DateTime dateOfBirth;
		[ColumnMapping("SocialSecurityNumber",StereoType=DataStereoType.USSSN)]
		protected string socialSecurityNumber;
		[ColumnMapping("AssignedTeamId",StereoType=DataStereoType.FK)]
		protected int assignedTeamId;
		[ColumnMapping("AssignedUserId",StereoType=DataStereoType.FK)]
		protected int assignedUserId;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;

		[ColumnMapping("PrimaryPatientCoverageID", StereoType=DataStereoType.FK)]
		private int primaryPatientCoverageID;
		[ColumnMapping("PrimarySubscriberID", StereoType=DataStereoType.FK)]
		private int primarySubscriberID;
		[ColumnMapping("PrimaryPatientAlternateID")]
		private string primaryPatientAlternateID;
		[ColumnMapping("PrimaryAlternateInsuranceID")]		// 1.1
		protected string primaryAlternateInsuranceID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("PrimaryPlanName")]		// 1.1			char(45)
		private string primaryPlanName;
		[ColumnMapping("PrimarySORGName")]		// 1.1			char(50)
		private string primarySORGName;

		// Address related fields, populated in the FillFromReader
		[ColumnMapping("Line1")]
		private string line1;
		[ColumnMapping("Line2")]
		private string line2;
		[ColumnMapping("Line3")]
		private string line3;
		[ColumnMapping("City")]
		private string city;
		[ColumnMapping("State")]
		private string state;
		[ColumnMapping("Zip")]
		private string zip;
		[ColumnMapping("PhoneNumber1")]
		private string phoneNumber1;
		[ColumnMapping("PhoneNumber2")]
		private string phoneNumber2;
		[ColumnMapping("PhoneNumber3")]
		private string phoneNumber3;
		[ColumnMapping("FaxNumber")]
		private string faxNumber;

		private bool isValidCoverage;	// filled from usp_SearchPatientsByPatientAndSubscriberInfo

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		[ControlType(EnumControlTypes.TextBox|EnumControlTypes.ComboBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@NAME@")]
		public string Fmt_FullName
		{
			get { return FormatFNameLName(this.lastName, this.firstName); }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		[FieldDescription("@LASTNAME@")]
		public string LastName
		{
			get { return this.lastName; }
			set { this.lastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@FIRSTNAME@")]
		public string FirstName
		{
			get { return this.firstName; }
			set { this.firstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		[FieldDescription("@MIDDLEINITIAL@")]
		public string MiddleInitial
		{
			get { return this.middleInitial; }
			set { this.middleInitial = value; }
		}

		[FieldValuesMember("ValuesOf_Gender")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, MaxLength=1)]
		[FieldDescription("@GENDER@")]
		public string Gender
		{
			get { return this.gender; }
			set { this.gender = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DATEOFBIRTH@")]
		public System.DateTime DateOfBirth
		{
			get { return this.dateOfBirth; }
			set { this.dateOfBirth = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldValuesMember("LookupOf_TeamID", "TeamId", "Code")]
		[FieldDescription("@ASSIGNEDTEAM@")]
		public int AssignedTeamId
		{
			get { return this.assignedTeamId; }
			set { this.assignedTeamId = value; }
		}

		[FieldDescription("@ASSIGNEDTEAM@")]
		public string AssignedTeamString
		{
			get { return FormatTeamForDisplay(this.AssignedTeamId); }
		}

		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldValuesMember("LookupOf_UserID", "UserId", "LoginName")]
		[FieldDescription("@ASSIGNEDUSER@")]
		public int AssignedUserId
		{
			get { return this.assignedUserId; }
			set { this.assignedUserId = value; }
		}

		[FieldDescription("@ASSIGNEDUSER@")]
		public string AssignedUserString
		{
			get { return FormatUserForDisplay(this.AssignedUserId); }
		}

		[ControlType(Macro=EnumControlTypeMacros.USSSN)]
		[FieldDescription("@SOCIALSECURITY@")]
		public string SocialSecurityNumber
		{
			get { return this.socialSecurityNumber; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PrimaryPatientCoverageID
		{
			get { return this.primaryPatientCoverageID; }
			set { this.primaryPatientCoverageID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PrimarySubscriberID
		{
			get { return this.primarySubscriberID; }
			set { this.primarySubscriberID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PrimaryPatientAlternateID
		{
			get { return this.primaryPatientAlternateID; }
			set { this.primaryPatientAlternateID = value; }
		}

		// 1.1
		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PrimaryAlternateInsuranceID
		{
			get { return this.primaryAlternateInsuranceID; }
			set { this.primaryAlternateInsuranceID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[FieldDescription("@STREETADDR1@")]
		public string Line1
		{	get{ return this.line1;}}

		[FieldDescription("@STREETADDR2@")]
		public string Line2
		{	get{ return this.line2;}}

		[FieldDescription("@STREETADDR3@")]
		public string Line3
		{	get{ return this.line3;}}

		[FieldDescription("@CITY@")]
		public string City
		{	get{ return this.city;}}

		[FieldDescription("@STATE@")]
		public string State
		{	get{ return this.state;}}

		[FieldDescription("@ZIPCODE@")]
		public string Zip
		{	get{ return this.zip;}}

		[FieldDescription("@PHONE1@")]
		public string Phone1Full
		{	get { return this.phoneNumber1; } }

		[FieldDescription("@PHONE2@")]
		public string Phone2Full
		{	get { return this.phoneNumber2; } }

		[FieldDescription("@PHONE3@")]
		public string Phone3Full
		{	get { return this.phoneNumber3; } }

		[FieldDescription("@FAX@")]
		public string FaxFull
		{	get { return this.faxNumber; } }


		/// <summary>
		/// Parent PatientSearchResultCollection that contains this element
		/// </summary>
		public PatientSearchResultCollection ParentPatientSearchResultCollection
		{
			get
			{
				return this.parentPatientSearchResultCollection;
			}
			set
			{
				this.parentPatientSearchResultCollection = value; // parent is set when added to a collection
			}
		}

		// 1.1
		[FieldDescription("@PLANNAME@")]
		[ControlType(EnumControlTypes.TextBox)]
		public string PrimaryPlanName
		{
			get { return this.primaryPlanName; }
		}

		// 1.1
		[FieldDescription("@SORGNAME@")]
		[ControlType(EnumControlTypes.TextBox)]
		public string PrimarySORGName
		{
			get { return this.primarySORGName; }
		}

		// 1.1
		[ControlType(EnumControlTypes.CheckBox)]
		public bool IsValidCoverage
		{
			get { return this.isValidCoverage; }
			set { this.isValidCoverage = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of Patient objects
	/// </summary>
	[ElementType(typeof(PatientSearchResult))]
	public class PatientSearchResultCollection : BaseDataCollectionClass
	{
		public const int MAXRECORDS = 20;		//  -1 = unlimited

		private bool fillExtraFields = false;

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientSearchResult this[int index]
		{
			get
			{
				return (PatientSearchResult)List[index];
			}
			set
			{
				List[index] = value;
			}
		}


		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientSearchResult elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientSearchResultCollection = this;
			else
				elem.ParentPatientSearchResultCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientSearchResult elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientSearchResult)oldValue, false);
			SetParentOnElem((PatientSearchResult)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Search for patients and load the collection.
		/// </summary>
		public int SearchPatients(int startPatientId, string startLastName, string startFirstName, PatientSearcher searcher)
		{
			this.Clear();

			int maxRecords = MAXRECORDS;
			
			//get UserId, returns > 0 if it is form authenticated
			int iUserId = AASecurityHelper.GetUserId;

			//if(iUserId > 0 )    The sp now includes this logic!
			//{
									
			//adding extraParamNames: "UserID" and extraParamValues: iUserId in usp_SearchPatientswithDAFilter
			//added rowCount and startPatientId parameters for paging. 
			//fillExtraFields = true;
			return SqlData.SPExecReadCol(60, "usp_SearchPatientswithDAFilter", -1, this, new object[] { searcher }, false, // true
				new string[] {"UserID",  "rowCount", "startPatientId", "startLastName", "startFirstName" },
				new object[] { iUserId,  maxRecords < 0 ? 0 : maxRecords, startPatientId, startLastName, startFirstName }  );
					
			//}
		}

		/// <summary>
		/// Search the patients by patient/subscriber's SSN, last name and first name.  Used by Intake when
		/// the user this Search button for Patient/Subscriber.
		/// </summary>
		public int SearchForPatientSubscriberInfo(int startPatientId, string startLastName, string startFirstName, PatientSearcher searcher)
		{
			this.Clear();
			fillExtraFields = true;


			// FORK 1.1 
			// userid added in to the parameters
			int iUserId = AASecurityHelper.GetUserId;

			try
			{
				return SqlData.SPExecReadCol(60, "usp_SearchPatientsByPatientAndSubscriberInfowithDAFilter", -1, this, 
					new object[] { searcher }, false,
					new string[] {"rowCount", "startPatientId", "startLastName", "startFirstName","UserID" },
					new object[] { MAXRECORDS, startPatientId, startLastName, startFirstName ,iUserId } );
				//
			}
			finally
			{
				fillExtraFields = false;
			}
		}

		// FORK 1.0

		public int LoadPatientsLinkedToEligibility(int eligibilityId)
		{
			return SqlData.SPExecReadCol("usp_GetPatientsLinkedToEligibility", -1, this, false, new object[] { eligibilityId });
		}

		// END FORK 1.0

		protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);

			if (fillExtraFields)
			{
				((PatientSearchResult)data).IsValidCoverage = Convert.ToBoolean( rdr["IsValidCoverage"] );
			}
		}
	}

	public class PatientSearcher : Patient
	{
		private ArrayList pageStartStack = new ArrayList();	// used to store page start values in paging.
		private object[] pageRecordIDs = null;	// keeps the PatientIDs for the current page

		[ColumnMapping("AlternatePatientID")]
		private string alternatePatientID;

		[ColumnMapping("AuthorizationID", StereoType=DataStereoType.FK)]
		private int authorizationID;		// The authorization ID to be searched in Event/Referral/CMS
		[ColumnMapping("AltAuthorizationID")]
		private string altAuthorizationID;		// The alt-authorization ID to be searched in Event/Referral/CMS

		// Used from intake.
		[ColumnMapping("PatientMemberID")]
		private string patientMemberID;
		[ColumnMapping("PatientSSN")]
		private string patientSSN;
		[ColumnMapping("PatientLName")]
		private string patientLName;
		[ColumnMapping("PatientFName")]
		private string patientFName;

		[ColumnMapping("SubscriberID", StereoType=DataStereoType.FK)]
		private int subscriberID;

		[ColumnMapping("SubscriberSSN")]
		private string subscriberSSN;
		[ColumnMapping("SubscriberLName")]
		private string subscriberLName;
		[ColumnMapping("SubscriberFName")]
		private string subscriberFName;
		[ColumnMapping("SORGId", StereoType=DataStereoType.FK)]
		private int sORGId;
		[ColumnMapping("PlanID", StereoType=DataStereoType.FK)]
		private int planID;

		[ColumnMapping("PatientDOB")]
		private DateTime patientDOB;

		public PatientSearcher()
		{
			this.NewRecord();
			this.SetMembersNull(true, true);
		}

		public PatientSearcher(IntakeLog intakeLog)
		{
			this.NewRecord();
			this.SetMembersNull(true, true);
			// these fields are used in two different search sps.
			this.alternatePatientID = this.patientMemberID = intakeLog.PatientMemberID;
			this.SocialSecurityNumber = this.PatientSSN = intakeLog.PatientSSN;
			this.lastName = this.patientLName = intakeLog.PatientLName;
			this.firstName = this.patientFName = intakeLog.PatientFName;
			this.dateOfBirth = this.patientDOB = intakeLog.PatientDOB;
			// these fields are used in patient-subsriber search
			this.subscriberSSN = intakeLog.SubscriberSSN;
			this.subscriberLName = intakeLog.SubscriberLName;
			this.subscriberFName = intakeLog.SubscriberFName;
			this.sORGId = intakeLog.SORGId;
			this.planID = intakeLog.PlanID;
			
		}

		public void SearchFieldsToIntakeSearchFields()
		{
			patientMemberID = this.alternatePatientID;
			patientSSN = this.socialSecurityNumber;
			patientLName = this.lastName;
			patientFName  = this.firstName;
			patientDOB = this.dateOfBirth;
		}

		[ControlType(EnumControlTypes.TextBox)]
		[FieldDescription("@PATIENTALTERNATEID@")]
		public string AlternatePatientID
		{
			get { return this.alternatePatientID; }
			set { this.alternatePatientID = value; }
		}

		public ArrayList PageStartStack
		{
			get { return this.pageStartStack; }
			set { this.pageStartStack = value;	}
		}
		
		public object[] PageRecordIDs
		{
			get { return this.pageRecordIDs; }
			set { this.pageRecordIDs = value;	}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int AuthorizationID
		{
			get { return this.authorizationID; }
			set { this.authorizationID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string AltAuthorizationID
		{
			get { return this.altAuthorizationID; }
			set { this.altAuthorizationID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientMemberID
		{
			get { return this.patientMemberID; }
			set { this.patientMemberID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientSSN
		{
			get { return this.patientSSN; }
			set { this.patientSSN = ParseSSN( value ); }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientLName
		{
			get { return this.patientLName; }
			set { this.patientLName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientFName
		{
			get { return this.patientFName; }
			set { this.patientFName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberSSN
		{
			get { return this.subscriberSSN; }
			set { this.subscriberSSN = ParseSSN( value ); }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberLName
		{
			get { return this.subscriberLName; }
			set { this.subscriberLName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberFName
		{
			get { return this.subscriberFName; }
			set { this.subscriberFName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int SORGId
		{
			get { return this.sORGId; }
			set { this.sORGId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PlanID
		{
			get { return this.planID; }
			set { this.planID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PatientDOB
		{
			get { return this.patientDOB; }
			set { this.patientDOB = value; }
		}
		

	}
}
