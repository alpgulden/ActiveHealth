using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientAuthorizer]
	/// </summary>
	[SPAutoGen("usp_SearchPatientAuthorizers","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetPatientAuthorizersByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllPatientAuthorizers","SelectAll.sptpl","")]
	[SPInsert("usp_InsertPatientAuthorizer")]
	[SPUpdate("usp_UpdatePatientAuthorizer")]
	[SPDelete("usp_DeletePatientAuthorizer")]
	[SPLoad("usp_LoadPatientAuthorizer")]
	[TableMapping("PatientAuthorizer","patientAuthorizerId")]
	public class PatientAuthorizer : BaseLookupWithNote
	{
		[NonSerialized]
		[ColumnMapping("PatientAuthorizerId")]
		private int patientAuthorizerId;
		[ColumnMapping("NotePad")]
		private string notePad;
		
		private PatientAuthorizerCollection parentPatientAuthorizerCollection;
		
		
			
		public PatientAuthorizer()
		{
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientAuthorizerId
		{
			get { return this.patientAuthorizerId; }
			set { this.patientAuthorizerId = value; }
		}

		/// <summary>
		/// Parent PatientAuthorizerCollection that contains this element
		/// </summary>
		public PatientAuthorizerCollection ParentPatientAuthorizerCollection
		{
			get
			{
				return this.parentPatientAuthorizerCollection;
			}
			set
			{
				this.parentPatientAuthorizerCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientAuthorizerId)
		{
			return base.Load(patientAuthorizerId);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of PatientAuthorizer objects
	/// </summary>
	[ElementType(typeof(PatientAuthorizer))]
	public class PatientAuthorizerCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientAuthorizer elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientAuthorizerCollection = this;
			else
				elem.ParentPatientAuthorizerCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientAuthorizer elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientAuthorizer this[int index]
		{
			get
			{
				return (PatientAuthorizer)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientAuthorizer)oldValue, false);
			SetParentOnElem((PatientAuthorizer)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetPatientAuthorizersByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientAuthorizersByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PatientAuthorizerCollection which is cached in NSGlobal
		/// </summary>
		public static PatientAuthorizerCollection ActivePatientAuthorizers
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PatientAuthorizerCollection col = (PatientAuthorizerCollection)NSGlobal.EnsureCachedObject("ActivePatientAuthorizers", typeof(PatientAuthorizerCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetPatientAuthorizersByActive(-1, true);
				}
				return col;
			}
			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllPatientAuthorizers", -1, this, false);
		}
	}
}
