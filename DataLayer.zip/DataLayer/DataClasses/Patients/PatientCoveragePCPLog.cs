using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientCoveragePCPLog]
	/// </summary>
	[SPInsert("usp_InsertPatientCoveragePCPLog")]
	[SPUpdate("usp_UpdatePatientCoveragePCPLog")]
	[SPDelete("usp_DeletePatientCoveragePCPLog")]
	[SPLoad("usp_LoadPatientCoveragePCPLog")]
	[TableMapping("PatientCoveragePCPLog","patientCoveragePCPLogID")]
	public class PatientCoveragePCPLog : BaseData
	{
		[NonSerialized]
		private PatientCoveragePCPLogCollection parentPatientCoveragePCPLogCollection;
		[ColumnMapping("PatientCoveragePCPLogID",(int)0)]
		private int patientCoveragePCPLogID;
		[ColumnMapping("PatientSubscriberLogID",StereoType=DataStereoType.FK)]
		private int patientSubscriberLogID;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]
		private int providerID;
		[ColumnMapping("LocationID",StereoType=DataStereoType.FK)]
		private int locationID;
		[ColumnMapping("SpecialtyID",StereoType=DataStereoType.FK)]
		private int specialtyID;
		//[ColumnMapping("ServiceTypeID",StereoType=DataStereoType.FK)]	// dropped
		//private int serviceTypeID;
		[ColumnMapping("AlternateProviderID")]
		private string alternateProviderID;
		[ColumnMapping("AlternateLocationID")]
		private string alternateLocationID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public PatientCoveragePCPLog()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PatientCoveragePCPLog(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientCoveragePCPLogID
		{
			get { return this.patientCoveragePCPLogID; }
			set { this.patientCoveragePCPLogID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientSubscriberLogID
		{
			get { return this.patientSubscriberLogID; }
			set { this.patientSubscriberLogID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LocationID
		{
			get { return this.locationID; }
			set { this.locationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SpecialtyID
		{
			get { return this.specialtyID; }
			set { this.specialtyID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateProviderID
		{
			get { return this.alternateProviderID; }
			set { this.alternateProviderID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateLocationID
		{
			get { return this.alternateLocationID; }
			set { this.alternateLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		/// <summary>
		/// Do pre and post-delete operations of this object here.
		/// </summary>
		protected override void InternalDelete()
		{
			throw new Exception("PatientCoveragePCPLog can not be deleted!");
			// Do pre-delete operations here (set members before delete, insert/update/delete extra records etc).
			//base.InternalDelete(); // always call this to ensure record flags gets updated properly.
			// Do post-delete operations here (set members after delete, insert/update/delete extra records etc).
		}

		/// <summary>
		/// Do pre and post-update operations of the object here.
		/// </summary>
		protected override void InternalUpdate()
		{
			throw new Exception("PatientCoveragePCPLog can not be updated!");
			// Do pre-update operations here (set members before update, insert/update extra records etc).
			//base.InternalUpdate(); // always call this to ensure record flags gets updated properly.
			// Do post-insert operations here (set members after update, insert/update extra records etc).
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientCoveragePCPLogID)
		{
			return base.Load(patientCoveragePCPLogID);
		}

		/// <summary>
		/// Parent PatientCoveragePCPLogCollection that contains this element
		/// </summary>
		public PatientCoveragePCPLogCollection ParentPatientCoveragePCPLogCollection
		{
			get
			{
				return this.parentPatientCoveragePCPLogCollection;
			}
			set
			{
				this.parentPatientCoveragePCPLogCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PatientCoveragePCPLog objects
	/// </summary>
	[ElementType(typeof(PatientCoveragePCPLog))]
	public class PatientCoveragePCPLogCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientCoveragePCPLog elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientCoveragePCPLogCollection = this;
			else
				elem.ParentPatientCoveragePCPLogCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientCoveragePCPLog elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientCoveragePCPLog this[int index]
		{
			get
			{
				return (PatientCoveragePCPLog)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientCoveragePCPLog)oldValue, false);
			SetParentOnElem((PatientCoveragePCPLog)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PatientCoveragePCPLog elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PatientCoveragePCPLog)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent PatientSubscriberLog that contains this collection
		/// </summary>
		public PatientSubscriberLog ParentPatientSubscriberLog
		{
			get { return this.ParentDataObject as PatientSubscriberLog; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PatientSubscriberLog */ }
		}
	}
}
