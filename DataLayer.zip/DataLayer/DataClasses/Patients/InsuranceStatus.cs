using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [InsuranceStatus]
	/// </summary>
	[SPAutoGen("usp_SearchInsuranceStatuses","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllInsuranceStatus","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetInsuranceStatusByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertInsuranceStatus")]
	[SPUpdate("usp_UpdateInsuranceStatus")]
	[SPDelete("usp_DeleteInsuranceStatus")]
	[SPLoad("usp_LoadInsuranceStatus")]
	[TableMapping("InsuranceStatus","insuranceStatusId")]
	public class InsuranceStatus : BaseLookupWithNote
	{
		[NonSerialized]
		private InsuranceStatusCollection parentInsuranceStatusCollection;
		[ColumnMapping("InsuranceStatusId",StereoType=DataStereoType.FK)]
		private int insuranceStatusId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public InsuranceStatus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int InsuranceStatusId
		{
			get { return this.insuranceStatusId; }
			set { this.insuranceStatusId = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent InsuranceStatusCollection that contains this element
		/// </summary>
		public InsuranceStatusCollection ParentInsuranceStatusCollection
		{
			get
			{
				return this.parentInsuranceStatusCollection;
			}
			set
			{
				this.parentInsuranceStatusCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}


	}

	/// <summary>
	/// Strongly typed collection of InsuranceStatus objects
	/// </summary>
	[ElementType(typeof(InsuranceStatus))]
	public class InsuranceStatusCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(InsuranceStatus elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentInsuranceStatusCollection = this;
			else
				elem.ParentInsuranceStatusCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (InsuranceStatus elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public InsuranceStatus this[int index]
		{
			get
			{
				return (InsuranceStatus)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((InsuranceStatus)oldValue, false);
			SetParentOnElem((InsuranceStatus)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetInsuranceStatusByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetInsuranceStatusByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared InsuranceStatusCollection which is cached in NSGlobal
		/// </summary>
		public static InsuranceStatusCollection ActiveInsuranceStatuses
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				InsuranceStatusCollection col = (InsuranceStatusCollection)NSGlobal.EnsureCachedObject("ActiveInsuranceStatuses", typeof(InsuranceStatusCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetInsuranceStatusByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Searches for Insurance Status matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchInsuranceStatuses", -1, this, false, code, description, active);
		}

		/// <summary>
		///  Loads all Insurance Status information into collection.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllInsuranceStatus", -1, this, false);
		}
	}
}
