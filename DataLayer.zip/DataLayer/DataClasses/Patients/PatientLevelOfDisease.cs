using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientLevelOfDisease]
	/// </summary>
	[SPAutoGen("usp_GetPatientLevelOfDiseasesByAssessmentGUID","SelectAllByGivenArgs.sptpl","assessmentGUID")]
	[SPInsert("usp_InsertPatientLevelOfDisease")]
	[SPUpdate("usp_UpdatePatientLevelOfDisease")]
	[SPDelete("usp_DeletePatientLevelOfDisease")]
	[SPLoad("usp_LoadPatientLevelOfDisease")]
	[TableMapping("PatientLevelOfDisease","patientLevelOfDiseaseID")]
	public class PatientLevelOfDisease : BaseData
	{
		[NonSerialized]
		private PatientLevelOfDiseaseCollection parentPatientLevelOfDiseaseCollection;
		[ColumnMapping("PatientLevelOfDiseaseID",StereoType=DataStereoType.FK)]
		private int patientLevelOfDiseaseID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("AssessmentGUID")]
		private string assessmentGUID;
		[ColumnMapping("AssessmentLevelOfDiseaseID",StereoType=DataStereoType.FK)]
		private int assessmentLevelOfDiseaseID;
		[ColumnMapping("AssessmentMeasurementID",StereoType=DataStereoType.FK)]
		private int assessmentMeasurementID;
		[ColumnMapping("MeasurementLevelOfDiseaseID",StereoType=DataStereoType.FK)]
		private int measurementLevelOfDiseaseID;
		[ColumnMapping("LevelOfDiseaseTypeID",StereoType=DataStereoType.FK)]
		private int levelOfDiseaseTypeID;
		[ColumnMapping("LevelOfDiseaseDate",StereoType=DataStereoType.FK)]
		private DateTime levelOfDiseaseDate;
		[ColumnMapping("LevelOfDiseaseDescription")]
		private string levelOfDiseaseDescription;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;


		//[ColumnMapping("LogicID", JoinColumn="LogicID", JoinRelation="PatientLevelOfDisease.AssessmentLevelOfDiseaseID = [AssessmentLevelOfDisease].AssessmentLevelOfDiseaseID", SQLGen=SQLGenerationFlags.NoSelect | SQLGenerationFlags.NoUpdate | SQLGenerationFlags.NoInsert)]
		//private string logicID;
	
		public PatientLevelOfDisease() : base()
		{
		}

		public PatientLevelOfDisease(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public PatientLevelOfDisease(int patientLevelOfDiseaseID)
		{
			this.NewRecord(); // initialize record state
			this.patientLevelOfDiseaseID = patientLevelOfDiseaseID;
		}
			

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientLevelOfDiseaseID
		{
			get { return this.patientLevelOfDiseaseID; }
			set { this.patientLevelOfDiseaseID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssessmentLevelOfDiseaseID
		{
			get { return this.assessmentLevelOfDiseaseID; }
			set { this.assessmentLevelOfDiseaseID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LevelOfDiseaseTypeID
		{
			get { return this.levelOfDiseaseTypeID; }
			set { this.levelOfDiseaseTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime LevelOfDiseaseDate
		{
			get { return this.levelOfDiseaseDate; }
			set { this.levelOfDiseaseDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=400)]
		public string LevelOfDiseaseDescription
		{
			get { return this.levelOfDiseaseDescription; }
			set { this.levelOfDiseaseDescription = value; }
		}



		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent PatientLevelOfDiseaseCollection that contains this element
		/// </summary>
		public PatientLevelOfDiseaseCollection ParentPatientLevelOfDiseaseCollection
		{
			get
			{
				return this.parentPatientLevelOfDiseaseCollection;
			}
			set
			{
				this.parentPatientLevelOfDiseaseCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MeasurementLevelOfDiseaseID
		{
			get { return this.measurementLevelOfDiseaseID; }
			set { this.measurementLevelOfDiseaseID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssessmentMeasurementID
		{
			get { return this.assessmentMeasurementID; }
			set { this.assessmentMeasurementID = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of PatientLevelOfDisease objects
	/// </summary>
	[ElementType(typeof(PatientLevelOfDisease))]
	public class PatientLevelOfDiseaseCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_MeasurementLevelOfDiseaseID;
		[NonSerialized]
		private CollectionIndexer indexBy_AssessmentLevelOfDiseaseID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientLevelOfDisease elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientLevelOfDiseaseCollection = this;
			else
				elem.ParentPatientLevelOfDiseaseCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientLevelOfDisease elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientLevelOfDisease this[int index]
		{
			get
			{
				return (PatientLevelOfDisease)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientLevelOfDisease)oldValue, false);
			SetParentOnElem((PatientLevelOfDisease)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}


		public void ResetIndexers()
		{
			indexBy_AssessmentLevelOfDiseaseID = null;
			indexBy_MeasurementLevelOfDiseaseID = null;
		}

		public override int AddRecord(BaseDataClass data)
		{
			int ret = base.AddRecord (data);
            //ResetIndexers();
			return ret;
		}


		/// <summary>
		/// Hashtable based index on assessmentLevelOfDiseaseID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_AssessmentLevelOfDiseaseID
		{
			get
			{
				if (this.indexBy_AssessmentLevelOfDiseaseID == null)
					this.indexBy_AssessmentLevelOfDiseaseID = new CollectionIndexer(this, new string[] { "assessmentLevelOfDiseaseID" }, true);
				return this.indexBy_AssessmentLevelOfDiseaseID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on assessmentLevelOfDiseaseID fields returns the object.  Uses the IndexBy_AssessmentLevelOfDiseaseID indexer.
		/// </summary>
		public PatientLevelOfDisease FindByAssessment(int assessmentLevelOfDiseaseID)
		{
			return (PatientLevelOfDisease)this.IndexBy_AssessmentLevelOfDiseaseID.GetObject(assessmentLevelOfDiseaseID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPatientLevelOfDiseases(string assessmentGUID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientLevelOfDiseasesByAssessmentGUID", -1, this, false, assessmentGUID);
		}

		/// <summary>
		/// Hashtable based index on measurementLevelOfDiseaseID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_MeasurementLevelOfDiseaseID
		{
			get
			{
				if (this.indexBy_MeasurementLevelOfDiseaseID == null)
					this.indexBy_MeasurementLevelOfDiseaseID = new CollectionIndexer(this, new string[] { "measurementLevelOfDiseaseID" }, true);
				return this.indexBy_MeasurementLevelOfDiseaseID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on measurementLevelOfDiseaseID fields returns the object.  Uses the IndexBy_MeasurementLevelOfDiseaseID indexer.
		/// </summary>
		public PatientLevelOfDisease FindByMeasurement(int measurementLevelOfDiseaseID)
		{
			return (PatientLevelOfDisease)this.IndexBy_MeasurementLevelOfDiseaseID.GetObject(measurementLevelOfDiseaseID);
		}





	}
}
