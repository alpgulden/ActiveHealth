using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientContacts]
	/// </summary>
	[SPInsert("usp_InsertPatientContact")]
	[SPLoad("usp_LoadPatientContact")]
	[TableMapping("PatientContact","patientID,contactID",true)]
	[TableLinkageAttribute(typeof(Patient), "patientID", typeof(Contact), "contactID")]
	public class PatientContact : BaseLinkageClass
	{
		[NonSerialized]
		private PatientContactCollection parentPatientContactCollection;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("ContactID",StereoType=DataStereoType.FK)]
		private int contactID;
	
		public PatientContact()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ContactID
		{
			get { return this.contactID; }
			set { this.contactID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent PatientContactCollection that contains this element
		/// </summary>
		public PatientContactCollection ParentPatientContactCollection
		{
			get
			{
				return this.parentPatientContactCollection;
			}
			set
			{
				this.parentPatientContactCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of PatientContact objects
	/// </summary>
	[ElementType(typeof(PatientContact))]
	public class PatientContactCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientContact elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientContactCollection = this;
			else
				elem.ParentPatientContactCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientContact elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientContact this[int index]
		{
			get
			{
				return (PatientContact)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientContact)oldValue, false);
			SetParentOnElem((PatientContact)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Patient that contains this collection
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.ParentDataObject as Patient; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}
	}




}
