using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientCoverages]
	/// PatientCoverage is a linkage between [Patient], [Subscriber], [Plan] and SORG
	/// Patient may have multiple PatientCoverage's and
	/// Subscriber may have multiple PatientCoverage's too.
	/// This class provides an easy method of accessing the linked objects.
	/// If have a Patient object, you can access Patient.PatientCoverages
	/// collection.  And from any of the PatientCoverage element of this collection
	/// you can ask for the Subscriber object.  But it is not contained by PatientCoverage.
	/// For example :  Patient.PatientCoverages[0].GetSubscriberCoverage()
	/// or :  Subscriber.PatientCoverages[0].GetPatient()
	/// but not :  Patient.PatientCoverages[0].Subscriber.
	/// This object is not responsible for containing and persisting Patient, Subscriber, Plan or SORG
	/// objects.
	/// </summary>
	[SPAutoGen("usp_SetPrimaryCoverage", null, ManuallyManaged=true)]
	[SPAutoGen("usp_SearchCoveragesOfPatient", null, ManuallyManaged=true)]
	[SPAutoGen("usp_GetPatientCoveragesByAlternateID","SelectAllByGivenArgs.sptpl","alternatePatientID")]
	[SPAutoGen("usp_GetPatientCoveragesByPatientEligibilityID","SelectAllByGivenArgs.sptpl","patientEligibilityID")]
	[SPInsert("usp_InsertPatientCoverage")]
	[SPUpdate("usp_UpdatePatientCoverage")]
	[SPDelete("usp_DeletePatientCoverage")]
	[SPLoad("usp_LoadPatientCoverage")]
	[SPAutoGen("usp_GetPatientCoverageByIDs","SelectAllByGivenArgs.sptpl","patientID, subscriberID, sORGID, planID")]
	[SPAutoGen("usp_GetPatientCoveragesByPatientIDSubscriberID","SearchByArgs.sptpl","patientID, subscriberID", InjectOrderBy="ORDER BY [PatientCoverage].[PatientCoverageID] DESC")]
	[TableMapping("PatientCoverage","patientCoverageID")]
	public class PatientCoverage : BaseData
	{
		[NonSerialized]
		private PatientCoverageCollection parentPatientCoverageCollection;
		[ColumnMapping("PatientCoverageID",StereoType=DataStereoType.FK)]
		private int patientCoverageID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("SubscriberID",StereoType=DataStereoType.FK)]
		private int subscriberID;
		[ColumnMapping("SORGID",StereoType=DataStereoType.FK)]
		private int sORGID;
		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
		private int planID;
		[ColumnMapping("RelationShipID",StereoType=DataStereoType.FK)]
		private int relationShipID;
		[ColumnMapping("IsPrimary")]
		private bool isPrimary;
		[ColumnMapping("AlternatePatientID")]
		private string alternatePatientID;
		[ColumnMapping("AlternateGroupID")]
		private string alternateGroupID;
		[ColumnMapping("AlternateInsuranceID")]
		private string alternateInsuranceID;
		[ColumnMapping("AlternateSubscriberID")]
		private string alternateSubscriberID;
		[ColumnMapping("PatientEligibilityID",StereoType=DataStereoType.FK)]
		private int patientEligibilityID;
		[ColumnMapping("SubscriberEligibilityID",StereoType=DataStereoType.FK)]
		private int subscriberEligibilityID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("EnrollmentID",StereoType=DataStereoType.FK)]
		private int enrollmentID;

		// The Patient-SubscriberCoverage relationship never gets updated
		// So we can keep object references
		private Patient patient;		// the parent patient
		private Subscriber subscriber;	// subscriber linked to the subscriber-coverage
		private Organization sorg;		// sorg linked to the subscriber-coverage
		private Plan plan;
		private PlanSORG planSorg;		// the plan-sorg link

		private PatientCoverageData latestCoverageData;
		private PatientCoveragePCPCollection patientCoveragePCPs;

		private bool isCreatedFromEligibility;		// this is set to true if the coverage is created from eligibility.  we check this when EligibilityAddAnyway is false
	
		public PatientCoverage()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Use this constructor when you want to create a link between a specific [Patient],
		/// [Subscriber], SORG and [Plan]
		/// </summary>
		public PatientCoverage(Patient patient, Subscriber subscriber, Organization sORG, Plan plan)
		{
			this.NewRecord(); // initialize record state
			SetRelationship(patient, subscriber, sORG, plan);
		}

		/// <summary>
		/// Use this constructor when you want to create a link between a specific [Patient] and
		/// [Subscriber]
		/// </summary>
		public PatientCoverage(Patient patient, Subscriber subscriber)
		{
			this.NewRecord(); // initialize record state
			SetRelationship(patient, subscriber);
		}

		/// <summary>
		/// Use this constructor when you want to create the Plan and SORG
		/// linkage at first.  The rest of the linkage must be completed later.
		/// </summary>
		public PatientCoverage(Organization sORG, Plan plan)
		{
			this.NewRecord(); // initialize record state
			SetRelationship(sORG, plan);
		}

		public PatientCoverage(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}


		/// <summary>
		///  Retrieves the NetworkID of the Network to which current 
		///  patient's plan is linked.
		/// </summary>
		/// <returns>NetworkID</returns>
		public int GetPlanRelatedNetworkID()
		{
			int netID = 0;
			if (this.planID != 0) // if the current object has a planID set.
			{
				object objResult = SqlData.ExecuteProcedureScalar("usp_SelectPatientPlanNetwork",new string[] {"PlanID"},new object[] { this.planID });
				if (objResult != null) // if the stored proc returns anything but null convert it to int and assign to netID
					netID = (int)objResult;
			}
			return netID;
		}

		/// <summary>
		/// The relationship can only be established in using objects.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="subscriber"></param>
		/// <param name="sORG"></param>
		/// <param name="plan"></param>
		public void SetRelationship(Patient patient, Subscriber subscriber, Organization sORG, Plan plan)
		{
			SetRelationship(patient, subscriber);

			if (sORG == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "SORG not specified for PatientCoverage");
			if (plan == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Plan not specified for PatientCoverage");

			// Create a link
			this.sORGID = sORG.OrganizationID;
			this.sorg = sORG;

			this.planID = plan.PlanId;
			this.plan = plan;
		}

		/// <summary>
		/// The relationship can only be established in using objects.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="subscriber"></param>
		public void SetRelationship(Patient patient, Subscriber subscriber)
		{
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Patient not specified for PatientCoverage");
			if (subscriber == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Subscriber not specified for PatientCoverage");

			// Create a link
			this.patientID = patient.PatientId;
			this.patient = patient;

			this.subscriberID = subscriber.SubscriberId;
			this.subscriber = subscriber;
		}

		/// <summary>
		/// The relationship can only be established in using objects.
		/// </summary>
		/// <param name="plan"></param>
		/// <param name="sORG"></param>
		public void SetRelationship(Organization sORG, Plan plan)
		{
			if (plan == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Plan not specified for PatientCoverage");
			if (sORG == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "SORG not specified for PatientCoverage");

			// Create a link
			this.planID = plan.PlanId;
			this.plan = plan;

			this.sORGID = sORG.OrganizationID;
			this.sorg = sORG;
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientCoverageId)
		{
			return base.Load(patientCoverageId);
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads and returns the associated patient.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientID == 0)
				return null;
			Patient patient = new Patient();
			if (patient.Load(this.patientID))
				return patient;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated subscriber.
		/// </summary>
		/// <returns></returns>
		public Subscriber GetSubscriber()
		{
			if (this.subscriberID == 0)
				return null;
			Subscriber subscriber = new Subscriber();
			if (subscriber.Load(this.subscriberID))
				return subscriber;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated SORG.
		/// </summary>
		/// <returns></returns>
		public Organization GetSORG()
		{
			if (this.sORGID == 0)
				return null;
			Organization sorg = new Organization();
			if (sorg.Load(this.sORGID))
				return sorg;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated Plan.
		/// </summary>
		/// <returns></returns>
		public Plan GetPlan()
		{
			if (this.planID == 0)
				return null;
			Plan plan = new Plan();
			plan.SqlData.Transaction = this.SqlData.Transaction;
			if (plan.Load(this.planID))
				return plan;
			else
				return null;
		}

		/// <summary>
		/// Returns the linked patient object.  This was either passed
		/// in the constructor, or it's loaded from the Patient table.
		/// </summary>
		public Patient Patient
		{
			get
			{
				if (this.patient == null)
				{
					if (this.parentPatientCoverageCollection != null)
						this.patient = this.parentPatientCoverageCollection.ParentPatient;
					if (this.patient == null)
						this.patient = GetPatient();
				}
				return this.patient;
			}
			set
			{
				this.patient = value;
				if (this.patient != null)
					this.patientID = this.patient.PatientId;
				else
					this.patientID = 0;
			}
		}

		/// <summary>
		/// Subscriber object indirectly linked to SubscriberCoverage
		/// </summary>
		public Subscriber Subscriber
		{
			get
			{
				if (this.subscriber == null)
					this.subscriber = this.GetSubscriber();
				return this.subscriber;
			}
		}

		/// <summary>
		/// SORG object indirectly linked to SubscriberCoverage
		/// </summary>
		public Organization SORG
		{
			get
			{
				if (this.sorg == null)
					this.sorg = this.GetSORG();
				return this.sorg;
			}
			set
			{
				if (value != null && !value.IsSubOrganization)
					throw new ActiveAdviceException(AAExceptionAction.None, "Only a sub-organization can be linked to PatientCoverage");
				this.sorg = value;
				if (value == null)
					this.sORGID = 0;
				else
					this.sORGID = sorg.OrganizationID;
			}
		}

		/// <summary>
		/// Returns the linked plan object.  This was either passed
		/// in the constructor, or it's loaded from the plan table.
		/// </summary>
		public Plan Plan
		{
			get
			{
				if (this.plan == null)
				{
					this.plan = GetPlan();
				}
				return this.plan;
			}
			set
			{
				this.plan = value;
				if (value == null)
					this.planID = 0;
				else
					this.planID = plan.PlanId;
			}
		}

		/// <summary>
		/// Loads and returns the associated PlanSORG link.
		/// </summary>
		/// <returns></returns>
		public PlanSORG GetPlanSORG()
		{
			if (this.planID == 0 || this.sORGID == 0)
				return null;
			PlanSORG planSORG = new PlanSORG();
			planSORG.SqlData.Transaction = this.SqlData.Transaction;
			if (planSORG.LoadPlanSORGByIDs(this.sORGID, this.planID))
				return planSORG;
			else
				return null;
		}

		public PlanSORG PlanSORG
		{
			get
			{
				if (this.planSorg == null)
				{
					this.planSorg = GetPlanSORG();
				}
				return this.planSorg;
			}
		}

		/*/// <summary>
		/// Returns plan's id linked thru SubscriberCoverage
		/// </summary>
		public int PlanId
		{
			get
			{
				if (this.Plan == null)
					return 0;
				else
					return this.Plan.PlanId;
			}
		}

		/// <summary>
		/// Returns the linked SubscriberCoverage's SORGId.
		/// The SORG that the coverage is linked to.
		/// </summary>
		public int SORGId
		{
			get
			{
				if (this.SORG == null)
					return 0;
				else
					return this.SORG.OrganizationID;
			}
		}*/

		

		[FieldValuesMember("LookupOf_RelationShipID", "RelationshipId", "RelationshipName")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int RelationShipID
		{
			get { return this.relationShipID; }
			set { this.relationShipID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientEligibilityID
		{
			get { return this.patientEligibilityID; }
			set { this.patientEligibilityID = value; }
		}

		public RelationshipTypeCollection LookupOf_RelationShipID
		{
			get
			{
				return RelationshipTypeCollection.ActiveRelationshipTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public string Description
		{
			get { return this.SubscriberFullName; }
		}
		
		[FieldDescription("@LASTNAME@")]
		public string SubscriberLastName
		{
			get { return this.Subscriber.LastName; }
		}

		[FieldDescription("@FIRSTNAME@")]
		public string SubscriberFirstName
		{
			get { return this.Subscriber.FirstName; }
		}

		[FieldDescription("@SUBSCRIBERNAME@")]
		public string SubscriberFullName
		{
			get { return this.Subscriber.Fmt_FullName; }
		}

		public string PlanName
		{
			get 
			{
				if (this.Plan == null)
					return null;				// no plan.
				return this.Plan.Name; 
			}
		}

		[FieldDescription("@PATIENTNAME@")]
		public string PatientFullName
		{
			get { return this.Patient.Fmt_FullName; }
		}

		/// <summary>
		/// Load this object from db by the given patient id and subscriber coverage id
		/// </summary>
		public bool Load(int patientId, int subscriberId, int sORGID, int planID)
		{
			return SqlData.SPExecReadObj("usp_GetPatientCoverageByIDs", this, false, 
				patientId, subscriberId, sORGID, planID);
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			writer.AddFieldsSubstituted(this, "@SubscriberID@-@SubscriberFullName@", Messages.PatientMessages.MessageIDs.SUBSCRIBERNAME);
			writer.AddFieldsSubstituted(this, "@PlanID@-@PlanName@", Messages.PatientMessages.MessageIDs.PLANNAME);
			writer.AddField(this, "AlternatePatientID");
		}

		/* 
		[FieldDescription("@ALTERNATEPATIENTID@")]
		public string AlternatePatientIDSummaryView
		{
			get { return this.alternatePatientID == null ? "@NOTSPECIFIED@" : this.alternatePatientID.ToString(); }
		}*/

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			//set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberID
		{
			get { return this.subscriberID; }
			//set { this.subscriberID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0, IsRequired=true)]
		public int SORGID
		{
			get { return this.sORGID; }
			set 
			{ 
				this.sORGID = value; 
				this.sorg = null;
				// FORK 1.0
				this.planSorg = null;
				// END FORK 1.0
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0, IsRequired=true)]
		public int PlanID
		{
			get { return this.planID; }
			set 
			{ 
				this.planID = value; 
				this.plan = null;
				// FORK 1.0
				this.planSorg = null;
				// END FORK 1.0
			}
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IsPrimary
		{
			get { return this.isPrimary; }
			set { this.isPrimary = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternatePatientID
		{
			get { return this.alternatePatientID; }
			set { this.alternatePatientID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateGroupID
		{
			get { return this.alternateGroupID; }
			set { this.alternateGroupID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateInsuranceID
		{
			get { return this.alternateInsuranceID; }
			set { this.alternateInsuranceID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateSubscriberID
		{
			get { return this.alternateSubscriberID; }
			set { this.alternateSubscriberID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberEligibilityID
		{
			get { return this.subscriberEligibilityID; }
			set { this.subscriberEligibilityID = value; }
		}

		/// <summary>
		/// Parent PatientCoverageCollection that contains this element
		/// </summary>
		public PatientCoverageCollection ParentPatientCoverageCollection
		{
			get
			{
				return this.parentPatientCoverageCollection;
			}
			set
			{
				this.parentPatientCoverageCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientCoverageID
		{
			get { return this.patientCoverageID; }
			set { this.patientCoverageID = value; }
		}

		/// <summary>
		/// Returns the latest coverage in history (PatientCoverageData).
		/// If this record is new, a new one is automatically created.
		/// </summary>
		public PatientCoverageData LatestCoverageData
		{
			get
			{
				if (this.latestCoverageData == null)
				{
					if (this.IsNew || this.IsNewlyInsertedInDB)
						this.latestCoverageData = null;
					else
						this.latestCoverageData = GetLatestCoverageData();

					// if nothing was found, just create new history entry
					if (this.latestCoverageData == null)
						this.latestCoverageData = new PatientCoverageData(this);
				}

				return this.latestCoverageData;
			}
		}

		/// <summary>
		/// Use an existing coverage for a new patient.
		/// </summary>
		/// <param name="patient"></param>
		/// <returns></returns>
		public PatientCoverage CreateForNewPatient(Patient patient)
		{
			PatientCoverage patCov = (PatientCoverage)this.Clone(true);
			patCov.Patient = patient;
			if (patient.IsNew)
				patCov.IsPrimary = true;
			else
				patCov.IsPrimary = false;	// using somebody else's coverage, and this patient is not new.  don't make the coverage primary.
			patCov.AlternateGroupID = null;
			patCov.AlternatePatientID = null;
			patCov.RelationShipID = 0;
			patCov.PatientEligibilityID = 0;
			return patCov;
		}

		/// <summary>
		/// Load the latest PatientCoverageData record for this PatientCoverage
		/// and return it.
		/// </summary>
		/// <returns></returns>
		public PatientCoverageData GetLatestCoverageData()
		{
			PatientCoverageData lasestCovData = new PatientCoverageData();
			lasestCovData.SqlData.Transaction = this.SqlData.Transaction;
			if (lasestCovData.LoadLatest(this.patientCoverageID))
				return lasestCovData;
			else
				return null;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			if (!this.IsMarkedForDeletion)
			{
				if (this.patientID == 0)
					throw new ActiveAdviceException(AAExceptionAction.None, "Can't save the PatientCoverage without a patient id");

				if (this.subscriberID == 0)
					throw new ActiveAdviceException(AAExceptionAction.None, "Can't save the PatientCoverage without a subscriber id");

				if (this.planID == 0)
					throw new ActiveAdviceException(AAExceptionAction.None, "Can't save the PatientCoverage without a plan id");
				
				if (this.SORG == null)
					throw new ActiveAdviceException(AAExceptionAction.None, "Can't save the PatientCoverage without a SORG");
				if (!this.SORG.IsSubOrganization)
					throw new ActiveAdviceException(AAExceptionAction.None, "Organization {0} is not a SORG", this.SORG.OrganizationID);

				if (this.relationShipID == 0)
					throw new ActiveAdviceException(AAExceptionAction.None, "RelationshipID was not specified for this PatientCoverage");

				// check PlanSORG.EligibilityAddAnyway
				if (this.IsNew)
					if (this.PlanSORG != null)
					{
						if (!this.PlanSORG.EligibilityAddAnyway)
						{
							if (!this.isCreatedFromEligibility)
								throw new ActiveAdviceException(AAExceptionAction.None, "You cannot add coverage for this Plan and SORG on the fly.");
						}
					}
			}

			base.InternalSave();
			this.SetAsPrimaryCoverage();		// Set this coverage as the

			// Save the child collections here.
			SavePatientCoveragePCPs();		// save the patient coverage PCPs.

			KeepCoverageHistoryData();
		}

		/// <summary>
		/// This will check if a new record is needed into the subscriber coverage history
		/// and will create a history entry if necessary.
		/// </summary>
		private void KeepCoverageHistoryData()
		{
			PatientCoverageData history = this.LatestCoverageData;
			if (history.IsNew)
			{
				history.SqlData.Transaction = this.SqlData.Transaction;
				history.PatientCoverageID = this.patientCoverageID;
				history.Save();
			}
			else
			{
				// updating
				// save only if the history was changed
				PatientCoverageData latestInDB = this.GetLatestCoverageData();
				if (latestInDB == null || !latestInDB.EqualsMappedMembers(history, false))
				{
					// there's a change, or there was no log entry in the db so far.
					history = (PatientCoverageData)history.Clone();
					history.SqlData.Transaction = this.SqlData.Transaction;
					history.Save();
				}
			}
		}

		/// <summary>
		/// Child PatientCoveragePCPs mapped to related rows of table PatientCoveragePCP where [PatientCoverageID] = [PatientCoverageID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientCoveragePCPs", "patientCoverageID")]
		public PatientCoveragePCPCollection PatientCoveragePCPs
		{
			get { return this.patientCoveragePCPs; }
			set
			{
				this.patientCoveragePCPs = value;
				if (value != null)
					value.ParentPatientCoverage = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientCoveragePCPs collection
		/// </summary>
		public void LoadPatientCoveragePCPs(bool forceReload)
		{
			this.patientCoveragePCPs = (PatientCoveragePCPCollection)PatientCoveragePCPCollection.LoadChildCollection("PatientCoveragePCPs", this, typeof(PatientCoveragePCPCollection), patientCoveragePCPs, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientCoveragePCPs collection
		/// </summary>
		public void SavePatientCoveragePCPs()
		{
			PatientCoveragePCPCollection.SaveChildCollection(this.patientCoveragePCPs, true);
		}

		/// <summary>
		/// Synchronizes the PatientCoveragePCPs collection
		/// </summary>
		public void SynchronizePatientCoveragePCPs()
		{
			PatientCoveragePCPCollection.SynchronizeChildCollection(this.patientCoveragePCPs, true);
		}

		/// <summary>
		/// Imports the Eligibility PCPs into PatientCoveragePCPs.
		/// Called from AvailableCoverage.EnsurePatientCoverageFromEligibility.
		/// 
		/// USE CASE ID: UC3.7
		/// TITLE: UPDATE COVERAGE PROVIDER DATA
		/// REQUIREMENT ID: 1.8.4.5
		/// Step 1.b.ii
		/// 
		/// </summary>
		/// <param name="eligibility"></param>
		public void ImportPatientCoveragePCPsFromEligibility(CoverageSelectionContext coverageSelectionContext, Eligibility eligibility)
		{
			EligibilityPCPCollection eligPCPCol = eligibility.GetAllEligibilityPCPs(coverageSelectionContext.GetDateOfService(), this.planID);
			if (eligPCPCol == null)
			{
				if (coverageSelectionContext != null)
					coverageSelectionContext.AddToMessageLog("There's no EligibilityPCP record for EligibilityID:{0}, PlanID:{1}", eligibility.EligibilityId, this.planID);
				return;		// Nothing to import
			}

			this.LoadPatientCoveragePCPs(false);

			if (coverageSelectionContext != null)
				coverageSelectionContext.AddToMessageLog("Importing EligibilityPCP records for EligibilityID:{0}, PlanID:{1}", eligibility.EligibilityId, this.planID);
			for (int i = 0; i < eligPCPCol.Count; i++)
			{
				EligibilityPCP eligPCP = eligPCPCol[i];
				PatientCoveragePCP patCovPCP = new PatientCoveragePCP(true);

				// copy members from eligibility PCP
				patCovPCP.EffectiveDate = eligPCP.EffectiveDate;
				patCovPCP.TerminationDate = eligPCP.TerminationDate;
				patCovPCP.AsOfDate = eligPCP.AsOfDate;
				//if (eligPCP.ProviderLocation != null)
				//	patCovPCP.ProviderLocationID = eligPCP.ProviderLocation.LocationID;// ProviderLocationID;
				patCovPCP.ProviderSpecialtyTypeID = eligPCP.PCPSpecialtyID;
				patCovPCP.Status = eligPCP.Status;		// not network status

				patCovPCP.PCPID = eligPCP.PCPId;
				patCovPCP.ProviderLocationID = eligPCP.PCPLocationID;

				this.PatientCoveragePCPs.Add(patCovPCP);
			}
		}

		public void ImportFromEligibility(CoverageSelectionContext coverageSelectionContext, Eligibility patientElig, Eligibility subscriberElig, EligibilityPlan plan)
		{
			if (coverageSelectionContext != null)
				coverageSelectionContext.AddToMessageLog("Importing coverage data from eligibility");
			this.AlternatePatientID = patientElig.MembershipId;
			this.AlternateSubscriberID = subscriberElig.MembershipId;
			this.AlternateGroupID = plan.AlternateGroupID;
			this.enrollmentID = Enrollment.LookupEnrollmentIDByAlternateID( plan.AlternateEnrollmentID );
			this.AlternateInsuranceID = patientElig.AlternateInsuranceID;			

			this.PatientEligibilityID = patientElig.EligibilityId;
			this.SubscriberEligibilityID = subscriberElig.EligibilityId;

			this.RelationShipID = patientElig.RelationshipID;
				
			this.LatestCoverageData.EffectiveDate = plan.EffectiveDate;
			this.LatestCoverageData.TerminationDate = plan.TerminationDate;		// this implies setting the current user and time too.
			this.LatestCoverageData.AsOfDate = patientElig.AsOfDate;
			this.LatestCoverageData.Active = true;

			


			if (this.IsNew)	// normally always new
			{
				this.isCreatedFromEligibility = true;			// mark this coverage as 'created from eligibility', so that EligibilityAddAnyway check will recognize it when this patientcoverage is saved
				this.ImportPatientCoveragePCPsFromEligibility(coverageSelectionContext, patientElig);
			}
		}

		/// <summary>
		/// If this coverage is created from Eligibility, this flag is set to true.
		/// </summary>
		public bool IsCreatedFromEligibility
		{
			get { return this.isCreatedFromEligibility; }
		}

		[FieldValuesMember("LookupOf_EnrollmentID", "EnrollmentID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int EnrollmentID
		{
			get { return this.enrollmentID; }
			set { this.enrollmentID = value; }
		}

		/// <summary>
		/// Loads and returns the linked enrolments of the sorg.
		/// </summary>
		/// <returns></returns>
		public EnrollmentCollection GetLinkedOrganizationEnrollments()
		{
			if (this.sORGID == 0)
				return null;
			EnrollmentCollection enrollments = new EnrollmentCollection();
			enrollments.LoadAllEnrollmentsByValidDateRangeAndOrganization(this.sORGID);
			return enrollments;
		}

		public EnrollmentCollection LookupOf_EnrollmentID
		{
			get
			{
				return GetLinkedOrganizationEnrollments();
			}
		}

		/// <summary>
		/// Set the primary coverage for the patient.
		/// </summary>
		public void SetAsPrimaryCoverage()
		{
			this.IsPrimary = Convert.ToBoolean( SqlData.SPExecNonQuery("usp_SetPrimaryCoverage", 
				new object[] { this.patientID, this.patientCoverageID, this.IsPrimary }) );
		}

		/// <summary>
		/// In memory coverage check.
		/// This can check for the coverage without using an sp.  So it doesn't depend on the records
		/// in db, and can check new records that were not saved yet.
		/// </summary>
		/// <returns></returns>
		public bool CheckCoverageInMemory()
		{
			DateTime now = DateTime.Today;

			// Check PatientCoverage
			if (!BaseData.IsActiveBetween(this.LatestCoverageData.EffectiveDate, this.LatestCoverageData.TerminationDate, now))
				return false;

			// Check Plan
			if (!BaseData.IsActiveBetween(this.Plan.EffectiveDate, this.Plan.TerminationDate, now))
				return false;

			// Check MORG, ORG, SORG
			if (!this.SORG.CheckCoverageInMemory())
				return false;

			// Check plan sorg
			if (!BaseData.IsActiveBetween(this.PlanSORG.EffectiveDate, this.PlanSORG.TerminationDate, now))
				return false;
			
			return true;
		}

		/// <summary>
		/// Check the coverage using the ValidateCoverageSP
		/// </summary>
		/// <returns></returns>
		public bool CheckCoverageInDB()
		{
			DateTime now = DateTime.Today;
			int patSubLogID = PatientSubscriberLog.GetLastPatientSubscriberLogID(null, this.patientID, this.patientCoverageID);
			AvailableCoverageCollection avaCovCol = new AvailableCoverageCollection();
			int validPatSubLogID = avaCovCol.ValidateCoverage(patSubLogID, now);
			return validPatSubLogID != 0;
		}

	}

	/// <summary>
	/// Strongly typed collection of PatientCoverage objects
	/// </summary>
	[ElementType(typeof(PatientCoverage))]
	public class PatientCoverageCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientCoverage elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientCoverageCollection = this;
			else
				elem.ParentPatientCoverageCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientCoverage elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientCoverage this[int index]
		{
			get
			{
				return (PatientCoverage)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientCoverage)oldValue, false);
			SetParentOnElem((PatientCoverage)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Patient that contains this collection
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.ParentDataObject as Patient; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}

		/// <summary>
		/// Load patient coverages for the given patient and subscriber
		/// </summary>
		public int LoadPatientCoverages(int maxRecords, int patientID, int subscriberID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientCoveragesByPatientIDSubscriberIDWithDAFilter", maxRecords, this, false,
				SQLDataDirect.MakeDBValue(patientID, (int)0),
				SQLDataDirect.MakeDBValue(subscriberID, (int)0) ,
				SQLDataDirect.MakeDBValue(AASecurityHelper.GetUserId, (int)0));
		}

		/// <summary>
		/// Load patient coverages for the given patient and subscriber
		/// </summary>
		public int LoadPatientCoverages(int maxRecords, Patient patient, Subscriber subscriber)
		{
			return LoadPatientCoverages(maxRecords, patient.PatientId, subscriber.SubscriberId);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPatientCoveragesByPatientEligibilityID(int maxRecords, int patientEligibilityID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientCoveragesByPatientEligibilityID", maxRecords, this, false, new object[] { patientEligibilityID });
		}

		/// <summary>
		/// Load patient coverages by the given alternate ID
		/// </summary>
		public int LoadPatientCoveragesByAlternateID(int maxRecords, string alternatePatientID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientCoveragesByAlternateID", maxRecords, this, false, new object[] { alternatePatientID });
		}

		/// <summary>
		/// Search the coverage of a patient by SSN and last name.  Used by Intake.
		/// </summary>
		public int SearchCoveragesOfPatient(Patient patient, string subscriberSSN, string subscriberLName)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchCoveragesOfPatient", -1, this, false, 
				new object[] 
					{	patient.PatientId,
						SQLDataDirect.MakeDBValue(subscriberSSN),
						SQLDataDirect.MakeDBValue(subscriberLName)
					});
		}

		// FORK 1.0

		/// <summary>
		/// Find the primary coverage and return its index
		/// </summary>
		/// <returns></returns>
		public int GetPrimaryCoverageIndex()
		{
			for (int i = 0; i < this.Count; i++)
				if (this[i].IsPrimary)
					return i;
			return -1;	// not found
		}

		// END FORK 1.0

	}

}
