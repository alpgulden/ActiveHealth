using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientSubscriberCoverages]
	/// PatientSubscriberCoverage is a linkage between [Patient] and [SubscriberCoverage].
	/// Patient may have multiple PatientSubscriberCoverage's and
	/// Subscriber may have multiple PatientSubscriberCoverage's too.
	/// This class provides an easy method of accessing the linked objects.
	/// If have a Patient object, you can access Patient.PatientSubscriberCoverages
	/// collection.  And from any of the PatientSubscriberCoverage element of this collection
	/// you can ask for the Subscriber object.  But it is not contained by PatientSubscriberCoverage.
	/// For example :  Patient.PatientSubscriberCoverages[0].GetSubscriberCoverage()
	/// or :  Subscriber.PatientSubscriberCoverages[0].GetPatient()
	/// but not :  Patient.PatientSubscriberCoverages[0].Subscriber.
	/// This object is not responsible for containing and persisting Patient and Subscriber
	/// objects.
	/// </summary>
	[SPAutoGen("usp_GetPatSubsCovByPatIdAndSubsCovId","SelectAllByGivenArgs.sptpl","patientId, subscriberCoverageId")]
	[SPInsert("usp_InsertPatientSubscriberCoverage")]
	[SPUpdate("usp_UpdatePatientSubscriberCoverage")]
	[SPDelete("usp_DeletePatientSubscriberCoverage")]
	[SPLoad("usp_LoadPatientSubscriberCoverage")]
	[TableMapping("PatientSubscriberCoverage","patientSubscriberCoverageId")]
	public class PatientSubscriberCoverage : BaseData
	{
		[NonSerialized]
		private PatientSubscriberCoverageCollection parentPatientSubscriberCoverageCollection;
		[ColumnMapping("PatientSubscriberCoverageId",StereoType=DataStereoType.FK)]
		private int patientSubscriberCoverageId;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		private int patientId;
		[ColumnMapping("SubscriberCoverageId",StereoType=DataStereoType.FK)]
		private int subscriberCoverageId;
		[ColumnMapping("RelationShipID",StereoType=DataStereoType.FK)]
		private int relationShipID;
		[ColumnMapping("AlternatePatientId")]
		private string alternatePatientId;
		[ColumnMapping("PatientEligibilityID",StereoType=DataStereoType.FK)]
		private int patientEligibilityID;

		// The Patient-SubscriberCoverage relationship never gets updated
		// So we can keep object references
		private Patient patient;		// the parent patient
		private SubscriberCoverage subscriberCoverage;
		// indirectly linked objects
		private Subscriber subscriber;	// subscriber linked to the subscriber-coverage
		private Organization sorg;		// sorg linked to the subscriber-coverage
		private Plan plan;
		private PatientSubscriberCoveragePCPCollection pCPs;				// plan linked to the subscriber-coverage
	
		public PatientSubscriberCoverage()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Use this constructor when you want to create a link between a specific [Patient]
		/// and a specific [SubscriberCoverage]
		/// </summary>
		/// <param name="patientId"></param>
		/// <param name="subscriberId"></param>
		public PatientSubscriberCoverage(Patient patient, SubscriberCoverage subscriberCoverage)
		{
			this.NewRecord(); // initialize record state
			SetRelationship(patient, subscriberCoverage);
		}

		public PatientSubscriberCoverage(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public void SetRelationship(Patient patient, SubscriberCoverage subscriberCoverage)
		{
			// Create a link
			this.patientId = patient.PatientId;
			this.patient = patient;
			this.subscriberCoverageId = subscriberCoverage.SubscriberCoverageId;
			this.subscriberCoverage = subscriberCoverage;
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientSubscriberCoverageId)
		{
			return base.Load(patientSubscriberCoverageId);
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/*/// <summary>
		/// Loads and returns the associated subscriber.
		/// </summary>
		/// <returns></returns>
		public Subscriber GetSubscriber()
		{
			if (this.subscriberId == 0)
				return null;
			Subscriber subscriber = new Subscriber();
			if (subscriber.Load(this.subscriberId))
				return subscriber;
			else
				return null;
		}*/

		/// <summary>
		/// Loads and returns the associated patient.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientId == 0)
				return null;
			Patient patient = new Patient();
			if (patient.Load(this.patientId))
				return patient;
			else
				return null;
		}

		/// <summary>
		/// Returns the linked patient object.  This was either passed
		/// in the constructor, or it's loaded from the Patient table.
		/// </summary>
		public Patient Patient
		{
			get
			{
				if (this.patient == null)
				{
					if (this.parentPatientSubscriberCoverageCollection != null)
						this.patient = this.parentPatientSubscriberCoverageCollection.ParentPatient;
					if (this.patient == null)
						this.patient = GetPatient();
				}
				return this.patient;
			}
		}

		/// <summary>
		/// Loads and returns the associated subscriber coverage.
		/// </summary>
		/// <returns></returns>
		public SubscriberCoverage GetSubscriberCoverage()
		{
			if (this.subscriberCoverageId == 0)
				return null;
			SubscriberCoverage subscriberCoverage = new SubscriberCoverage();
			if (subscriberCoverage.Load(this.subscriberCoverageId))
				return subscriberCoverage;
			else
				return null;
		}

		/// <summary>
		/// Returns the linked subscriber coverage object.  This was either passed
		/// in the constructor, or it's loaded from the SubscriberCoverage table.
		/// </summary>
		public SubscriberCoverage SubscriberCoverage
		{
			get
			{
				if (this.subscriberCoverage == null)
				{
					//if (this.parentPatientSubscriberCoverageCollection != null)
					//	this.subscriberCoverage = this.parentPatientSubscriberCoverageCollection.pare;
					//if (this.subscriberCoverage == null)
					this.subscriberCoverage = GetSubscriberCoverage();
				}
				return this.subscriberCoverage;
			}
		}

		/// <summary>
		/// Subscriber object indirectly linked to SubscriberCoverage
		/// </summary>
		public Subscriber Subscriber
		{
			get
			{
				if (this.subscriber == null)
					this.subscriber = this.SubscriberCoverage.Subscriber;
				return this.subscriber;
			}
		}

		/// <summary>
		/// SORG object indirectly linked to SubscriberCoverage
		/// </summary>
		public Organization SORG
		{
			get
			{
				if (this.sorg == null)
					this.sorg = this.SubscriberCoverage.SORG;
				return this.sorg;
			}
		}

		/// <summary>
		/// Plan object indirectly linked to SubscriberCoverage
		/// </summary>
		public Plan Plan
		{
			get
			{
				if (this.plan == null)
					this.plan = this.SubscriberCoverage.Plan;
				return this.plan;
			}
		}

		/// <summary>
		/// Returns plan's id linked thru SubscriberCoverage
		/// </summary>
		public int PlanId
		{
			get
			{
				if (this.Plan == null)
					return 0;
				else
					return this.Plan.PlanId;
			}
		}

		/// <summary>
		/// Returns the linked SubscriberCoverage's SORGId.
		/// The SORG that the coverage is linked to.
		/// </summary>
		public int SORGId
		{
			get
			{
				if (this.SORG == null)
					return 0;
				else
					return this.SORG.OrganizationID;
			}
		}

		/// <summary>
		/// The pk for this PatientSubscriberCoverage
		/// </summary>
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientSubscriberCoverageId
		{
			get { return this.patientSubscriberCoverageId; }
			set { this.patientSubscriberCoverageId = value; }
		}

		//[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientId
		{
			get { return this.patientId; }
			//set { this.patientId = value; }
		}

		//[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberCoverageId
		{
			get { return this.subscriberCoverageId; }
			//set { this.subscriberCoverageId = value; }
		}

		[FieldValuesMember("LookupOf_RelationShipID", "RelationshipId", "RelationshipName")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int RelationShipID
		{
			get { return this.relationShipID; }
			set { this.relationShipID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternatePatientId
		{
			get { return this.alternatePatientId; }
			set { this.alternatePatientId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientEligibilityID
		{
			get { return this.patientEligibilityID; }
			set { this.patientEligibilityID = value; }
		}

		/// <summary>
		/// Parent PatientSubscriberCoverageCollection that contains this element
		/// </summary>
		public PatientSubscriberCoverageCollection ParentPatientSubscriberCoverageCollection
		{
			get
			{
				return this.parentPatientSubscriberCoverageCollection;
			}
			set
			{
				this.parentPatientSubscriberCoverageCollection = value; // parent is set when added to a collection
			}
		}

		public RelationshipTypeCollection LookupOf_RelationShipID
		{
			get
			{
				return RelationshipTypeCollection.ActiveRelationshipTypes; // Acquire a shared instance from the static member of collection
			}
		}
		
		[FieldDescription("@LASTNAME@")]
		public string SubscriberLastName
		{
			get { return this.Subscriber.LastName; }
		}

		[FieldDescription("@FIRSTNAME@")]
		public string SubscriberFirstName
		{
			get { return this.Subscriber.FirstName; }
		}

		[FieldDescription("@SUBSCRIBERNAME@")]
		public string SubscriberFullName
		{
			get { return this.SubscriberFirstName + ", " + this.SubscriberFirstName; }
		}

		public string PlanName
		{
			get { return this.Plan.Name; }
		}

		/// <summary>
		/// Load this object from db by the given patient id and subscriber coverage id
		/// </summary>
		public bool LoadPatSubsCovByPatIdAndSubsCovId(int patientId, int subscriberCoverageId)
		{
			return SqlData.SPExecReadObj("usp_GetPatSubsCovByPatIdAndSubsCovId", this, false, 
				patientId, subscriberCoverageId);
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "	patientSubscriberCoverageId= '" + ReflectionHelper.GetMemberValueAsString(this, "patientSubscriberCoverageId") + "'\r\n";
			s += "	patientId= '" + ReflectionHelper.GetMemberValueAsString(this, "patientId") + "'\r\n";
			s += "	subscriberCoverageId= '" + ReflectionHelper.GetMemberValueAsString(this, "subscriberCoverageId") + "'\r\n";
			s += "	relationShipID= '" + ReflectionHelper.GetMemberValueAsString(this, "relationShipID") + "'\r\n";
			s += "}\r\n";
			return s;
		}

		/// <summary>
		/// Child PCPs mapped to related rows of table PatientSubscriberCoveragePCP where [PatientSubscriberCoverageId] = [PatientSubscriberCoverageId]
		/// </summary>
		[SPLoadChild("usp_LoadPatientSubscriberCoveragePCPs", "patientSubscriberCoverageId")]
		public PatientSubscriberCoveragePCPCollection PCPs
		{
			get { return this.pCPs; }
			set
			{
				this.pCPs = value;
				if (value != null)
					value.ParentPatientSubscriberCoverage = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PCPs collection
		/// </summary>
		public void LoadPCPs(bool forceReload)
		{
			this.pCPs = (PatientSubscriberCoveragePCPCollection)PatientSubscriberCoveragePCPCollection.LoadChildCollection("PCPs", this, typeof(PatientSubscriberCoveragePCPCollection), pCPs, forceReload, null);
		}

		/// <summary>
		/// Saves the PCPs collection
		/// </summary>
		public void SavePCPs()
		{
			PatientSubscriberCoveragePCPCollection.SaveChildCollection(this.pCPs, true);
		}

		/// <summary>
		/// Synchronizes the PCPs collection
		/// </summary>
		public void SynchronizePCPs()
		{
			PatientSubscriberCoveragePCPCollection.SynchronizeChildCollection(this.pCPs, true);
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			writer.AddField(this, "SubscriberFullName", Messages.PatientMessages.MessageIDs.SUBSCRIBERCOVERAGE );
			writer.AddField(this, "PlanName", Messages.PatientMessages.MessageIDs.PLANNAME );
		}

	}

	/// <summary>
	/// Strongly typed collection of PatientSubscriberCoverage objects
	/// </summary>
	[ElementType(typeof(PatientSubscriberCoverage))]
	public class PatientSubscriberCoverageCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientSubscriberCoverage elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientSubscriberCoverageCollection = this;
			else
				elem.ParentPatientSubscriberCoverageCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientSubscriberCoverage elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientSubscriberCoverage this[int index]
		{
			get
			{
				return (PatientSubscriberCoverage)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientSubscriberCoverage)oldValue, false);
			SetParentOnElem((PatientSubscriberCoverage)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Patient that contains this collection
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.ParentDataObject as Patient; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}

	}
}
