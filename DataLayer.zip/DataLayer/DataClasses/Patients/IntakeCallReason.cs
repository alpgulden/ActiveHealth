using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [IntakeCallReason]
	/// </summary>
	[SPAutoGen("usp_GetAllIntakeCallReasons","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetIntakeCallReasonsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertIntakeCallReason")]
	[SPUpdate("usp_UpdateIntakeCallReason")]
	[SPDelete("usp_DeleteIntakeCallReason")]
	[SPLoad("usp_LoadIntakeCallReason")]
	[TableMapping("IntakeCallReason","intakeCallReasonID")]
	public class IntakeCallReason : BaseLookupWithNote
	{
		[NonSerialized]
		private IntakeCallReasonCollection parentIntakeCallReasonCollection;
		[ColumnMapping("IntakeCallReasonID",(int)0)]
		private int intakeCallReasonID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public IntakeCallReason()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public IntakeCallReason(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		public IntakeCallReason(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int IntakeCallReasonID
		{
			get { return this.intakeCallReasonID; }
			set { this.intakeCallReasonID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int intakeCallReasonID)
		{
			return base.Load(intakeCallReasonID);
		}

		/// <summary>
		/// Parent IntakeCallReasonCollection that contains this element
		/// </summary>
		public IntakeCallReasonCollection ParentIntakeCallReasonCollection
		{
			get
			{
				return this.parentIntakeCallReasonCollection;
			}
			set
			{
				this.parentIntakeCallReasonCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of IntakeCallReason objects
	/// </summary>
	[ElementType(typeof(IntakeCallReason))]
	public class IntakeCallReasonCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(IntakeCallReason elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentIntakeCallReasonCollection = this;
			else
				elem.ParentIntakeCallReasonCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (IntakeCallReason elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public IntakeCallReason this[int index]
		{
			get
			{
				return (IntakeCallReason)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((IntakeCallReason)oldValue, false);
			SetParentOnElem((IntakeCallReason)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadIntakeCallReasonsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetIntakeCallReasonsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared IntakeCallReasonCollection which is cached in NSGlobal
		/// </summary>
		public static IntakeCallReasonCollection ActiveIntakeCallReasons
		{
			get{
				bool initialize = false;
				// Get a cached instance of the collection
				IntakeCallReasonCollection col = (IntakeCallReasonCollection)NSGlobal.EnsureCachedObject("ActiveIntakeCallReasons", typeof(IntakeCallReasonCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadIntakeCallReasonsByActive(-1, true);
				}
				return col;
			}
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllIntakeCallReasons", -1, this, false);
		}
	}
}
