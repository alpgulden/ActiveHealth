using System;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Collections;


namespace ActiveAdvice.DataLayer
{
	/*[TableMapping(null)]
	public class AuthorizationExport : BaseDataClass
	{
		public void ReadAuthorizations()
		{
			SqlData.SPExecNonQuery("usp_Staging_ExportEventsPatientSubscriber", new object[] { 1, 2});
		}
	}*/

	/// <summary>
	/// 
	/// The available coverage information returned from 
	/// usp_GenerateCoverageList.
	/// 
	/// This is not a database entity that we can save or load.
	/// </summary>
	[SPAutoGen("usp_ValidateCoverage", null, ManuallyManaged=true)]
	[SPAutoGen("usp_GenerateCoverageList", null, ManuallyManaged=true)]
	[SPAutoGen("usp_GenerateValidCoverageList", null, ManuallyManaged=true)]
	[TableMapping("PatientCoverage", "patientCoverageID")]
	public class AvailableCoverage : BaseData
	{
		[NonSerialized]
		private AvailableCoverageCollection parentAvailableCoverageCollection;
		[ColumnMapping("PatientCoverageID",StereoType=DataStereoType.FK)]
		private int patientCoverageID;
		//[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		//private int patientID;
		[ColumnMapping("SORGID",StereoType=DataStereoType.FK)]
		private int sORGID;
		[ColumnMapping("SubscriberID",StereoType=DataStereoType.FK)]
		private int subscriberID;
		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
		private int planID;
		[ColumnMapping("PatientEligibilityID",StereoType=DataStereoType.FK)]
		private int patientEligibilityID;
		[ColumnMapping("SubscriberEligibilityID",StereoType=DataStereoType.FK)]
		private int subscriberEligibilityID;
		[ColumnMapping("EligibilityPlanID",StereoType=DataStereoType.FK)]
		private int eligibilityPlanID;
		
		[ColumnMapping("SubscriberSSN")]
		private string subscriberSSN;
		[ColumnMapping("SubscriberFirstName")]
		private string subscriberFirstName;
		[ColumnMapping("SubscriberLastName")]
		private string subscriberLastName;
		[ColumnMapping("SORGName")]
		private string sorgName;
		[ColumnMapping("PlanName")]
		private string planName;
		
		[ColumnMapping("ValidCoverage")]
		private bool validCoverage;

		[ColumnMapping("PlanTypeId",StereoType=DataStereoType.FK)]
		private int planTypeId;
		[ColumnMapping("PlanEffectiveDate")]
		private DateTime planEffectiveDate;
		[ColumnMapping("PlanTerminationDate")]
		private DateTime planTerminationDate;

		// loaded and cached objects
		private Eligibility patientEligibility;		// loaded and cached patient eligibility object
		private Eligibility subscriberEligibility;	// loaded and cached subscriber eligibility object
		private Plan eligibilityPlan;				// loaded and cached plan object
		private Subscriber subscriber;				// loaded and cached subscriber object
		private PatientCoverage patientCoverage;	// loaded and cached patient coverage object
		private Organization sORG;					// loaded and cached sorg object
		private EligibilityPlan patientEligibilityPlan;

		/*[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}*/

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberID
		{
			get { return this.subscriberID; }
			set 
			{
				this.subscriberID = value;
				this.subscriber = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SORGID
		{
			get { return this.sORGID; }
			set 
			{
				this.sORGID = value;
				this.sORG = null;
			}
		}

		[FieldValuesMember("LookupOf_PlanTypeId", "PlanTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@TYPE@")]
		public int PlanTypeId
		{
			get { return this.planTypeId; }
			set { this.planTypeId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientCoverageID
		{
			get { return this.patientCoverageID; }
			set 
			{ 
				this.patientCoverageID = value; 
				this.patientCoverage = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientEligibilityID
		{
			get { return this.patientEligibilityID; }
			set 
			{ 
				this.patientEligibilityID = value; 
				this.patientEligibility = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberEligibilityID
		{
			get { return this.subscriberEligibilityID; }
			set 
			{ 
				this.subscriberEligibilityID = value;
				this.subscriberEligibility = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PlanID
		{
			get { return this.planID; }
			set 
			{ 
				this.planID = value;
				this.eligibilityPlan = null;
			}
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool ValidCoverage
		{
			get { return this.validCoverage; }
			set { this.validCoverage = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberSSN
		{
			get { return this.subscriberSSN; }
			set { this.subscriberSSN = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberFirstName
		{
			get { return this.subscriberFirstName; }
			set { this.subscriberFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SubscriberLastName
		{
			get { return this.subscriberLastName; }
			set { this.subscriberLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string SORGName
		{
			get { return this.sorgName; }
			set { this.sorgName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PlanName
		{
			get { return this.planName; }
			set { this.planName = value; }
		}

		/// <summary>
		/// Load and return the sorg record.
		/// </summary>
		/// <returns></returns>
		public Organization GetSORG()
		{
			if (this.sORGID == 0)
				return null;
			Organization sorg = new Organization();
			if (sorg.Load(this.sORGID))
				return sorg;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached sorg object.
		/// </summary>
		public Organization SORG
		{
			get 
			{
				if (this.sORG == null)
					this.sORG = GetSORG();
				return this.sORG;
			}
		}

		/// <summary>
		/// Load and return the patient eligibility record.
		/// </summary>
		/// <returns></returns>
		public Eligibility GetPatientEligibility()
		{
			if (this.patientEligibilityID == 0)
				return null;
			Eligibility eligibility = new Eligibility();
			if (eligibility.Load(this.patientEligibilityID))
				return eligibility;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached patient eligibility object.
		/// </summary>
		public Eligibility PatientEligibility
		{
			get 
			{
				if (this.patientEligibility == null)
					this.patientEligibility = GetPatientEligibility();
				return this.patientEligibility;
			}
		}

		/// <summary>
		/// Load and return the subscriber eligibility record.
		/// </summary>
		/// <returns></returns>
		public Eligibility GetSubscriberEligibility()
		{
			if (this.subscriberEligibilityID == 0)
				return null;
			Eligibility eligibility = new Eligibility();
			if (eligibility.Load(this.subscriberEligibilityID))
				return eligibility;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached subscriber eligibility object.
		/// </summary>
		public Eligibility SubscriberEligibility
		{
			get 
			{
				if (this.subscriberEligibility == null)
					this.subscriberEligibility = GetSubscriberEligibility();
				return this.subscriberEligibility;
			}
		}


		/// <summary>
		/// Load and return the plan record.
		/// </summary>
		/// <returns></returns>
		public Plan GetPatientPlan()
		{
			if (this.planID == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.planID))
				return plan;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached plan object.
		/// </summary>
		public Plan PatientPlan
		{
			get 
			{
				if (this.eligibilityPlan == null)
					this.eligibilityPlan = GetPatientPlan();
				return this.eligibilityPlan;
			}
		}

		/// <summary>
		/// Load and return the eligibility plan record for the patient
		/// </summary>
		/// <returns></returns>
		public EligibilityPlan GetPatientEligibilityPlan()
		{
			if (this.planID == 0)
				return null;
			EligibilityPlan eligPlan = new EligibilityPlan();
			if (eligPlan.Load(this.eligibilityPlanID))
				return eligPlan;
			else
				return null;
		}

		/// <summary>
		/// Loaded and cached Eligibility Plan selected for the patient
		/// </summary>
		public ActiveAdvice.DataLayer.EligibilityPlan PatientEligibilityPlan
		{
			get 
			{ 
				if (this.patientEligibilityPlan == null)
					this.patientEligibilityPlan = GetPatientEligibilityPlan();
				return this.patientEligibilityPlan;
			}
		}

		/// <summary>
		/// Load and return the subscriber record.
		/// </summary>
		/// <returns></returns>
		public Subscriber GetSubscriber()
		{
			if (this.subscriberID == 0)
				return null;
			Subscriber subscriber = new Subscriber();
			if (subscriber.Load(this.subscriberID))
				return subscriber;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached subscriber object.
		/// </summary>
		public Subscriber Subscriber
		{
			get 
			{
				if (this.subscriber == null)
					this.subscriber = GetSubscriber();
				return this.subscriber;
			}
		}

		/// <summary>
		/// Load and return the patient coverage record.
		/// </summary>
		/// <returns></returns>
		public PatientCoverage GetPatientCoverage()
		{
			if (this.patientCoverageID == 0)
				return null;
			PatientCoverage patientCoverage = new PatientCoverage();
			if (patientCoverage.Load(this.patientCoverageID))
				return patientCoverage;
			else
				return null;
		}

		/// <summary>
		/// Return the loaded and cached patient coverage object.
		/// </summary>
		public PatientCoverage PatientCoverage
		{
			get 
			{
				if (this.patientCoverage == null)
					this.patientCoverage = GetPatientCoverage();
				return this.patientCoverage;
			}
		}

		/// <summary>
		/// Returns true if this record is from eligibility rather than an existing coverage.
		/// </summary>
		public bool IsFromEligibility
		{
			get
			{
				// if there's no patient coverage, then it must be from eligibility
				return this.patientCoverageID == 0;
			}
		}

		/// <summary>
		/// Parent AvailableCoverageCollection that contains this element
		/// </summary>
		public AvailableCoverageCollection ParentAvailableCoverageCollection
		{
			get
			{
				return this.parentAvailableCoverageCollection;
			}
			set
			{
				this.parentAvailableCoverageCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Ensure that the coverage this coverage is in the system and set
		/// the current coverage selection cotext.
		/// </summary>
		/// <param name="coverageSelectionContext"></param>
		public void EnsurePatientCoverage(CoverageSelectionContext coverageSelectionContext)
		{
			if (this.IsFromEligibility)
			{
				coverageSelectionContext.AddToMessageLog("The patient coverage requires import from eligibility.");
				EnsurePatientCoverageFromEligibility(coverageSelectionContext);
			}
			else
			{
				coverageSelectionContext.AddToMessageLog("The patient coverage id {0} is already in the system.  Using it.", this.PatientCoverageID);
				// Not from eligibility.  An existing coverage in the system.
				// Just return it.
				if (this.patientCoverageID == 0)
				{
					// Unexpected
					throw new ActiveAdviceException(AAExceptionAction.None, "CoverageSelectionContext(): No patient coverage id!");
				}
				// the patient coverage was already found.
				// set it to the coverageSelectionContext.
				coverageSelectionContext.PatientCoverage = this.PatientCoverage;
			}
		}


		/// <summary>
		/// 
		/// USE CASE ID: UC3.5
		/// TITLE: CREATE PATIENT COVERAGE
		/// REQUIREMENT ID: 1.8.4.6,1.8.4.7, 1.8.4.8
		/// 
		/// This method will ensure that all the records related to the
		/// coverage are created from the eligibility.
		/// Make the PatientCoverage available on coverageSelectionContext.
		/// 
		/// </summary>
		public void EnsurePatientCoverageFromEligibility(CoverageSelectionContext coverageSelectionContext)
		{
			coverageSelectionContext.AddToMessageLog("Checking that coverage exists in the system.");

			//if (!this.IsFromEligibility)
			//	throw new ActiveAdviceException(AAExceptionAction.None, "EnsurePatientCoverageFromEligibility(): Only coverage from eligibility can be created by this method");

			if (this.patientCoverageID != 0)
			{
				// the patient coverage was already found.
				// set it to the coverageSelectionContext.
				coverageSelectionContext.PatientCoverage = this.PatientCoverage;
				coverageSelectionContext.AddToMessageLog("The patient coverage id {0} is already in the system.", this.PatientCoverageID);
				return;
			}

			/*if (this.patientID == 0)
			{
				// The patient was not found.
				// This scenario was not implemented.
				throw new ActiveAdviceException(AAExceptionAction.None, "EnsurePatientCoverageFromEligibility(): Creation of Patient from eligibility not implemented");
			}*/

			if (this.sORGID == 0)
			{
				// The SORG was not found.
				// This is not expected!
				throw new ActiveAdviceException(AAExceptionAction.None, "EnsurePatientCoverageFromEligibility(): Cannot create SORG from eligibility!");
			}

			if (this.planID == 0)
			{
				// The planID was not found.
				// This is not expected!
				throw new ActiveAdviceException(AAExceptionAction.None, "EnsurePatientCoverageFromEligibility(): Cannot create Plan from eligibility!");
			}

			// Create the patient-coverage record
			/// USE CASE ID: UC3.5
			/// TITLE: CREATE PATIENT COVERAGE
			/// REQUIREMENT ID: 1.8.4.6,1.8.4.7, 1.8.4.8
			/// Step 4.b.i-ii
			PatientCoverage patCov = new PatientCoverage(this.SORG, this.PatientPlan);
			if (coverageSelectionContext.Patient.IsNew)
			{
				patCov.IsPrimary = true;		// if the patient is new, set this coverages as the primary coverage.
			}

			Subscriber subscriber = null;

			if (this.subscriberID == 0)
			{
				// The SubscriberID was not found.
				// Create a subscriber.

				if (this.subscriberEligibilityID == 0)
				{
					// This is not expected.  If the subscriberID was not found, subscriberEligibilityID must have been found.
					throw new ActiveAdviceException(AAExceptionAction.None, "EnsurePatientCoverageFromEligibility(): Coverage has neither subscriber ID nor subscriber eligiblity ID!");
				}

				Debug.WriteLine("EnsurePatientCoverageFromEligibility(): Creating and importing a new subscriber from eligibility");
				subscriber = new Subscriber(true);
				/// USE CASE ID: UC3.5
				/// TITLE: CREATE PATIENT COVERAGE
				/// REQUIREMENT ID: 1.8.4.6,1.8.4.7, 1.8.4.8
				/// Step 4.b
				subscriber.ImportFromEligibility(this.SubscriberEligibility);
				// continue with creating the patient-coverage record.

				coverageSelectionContext.AddToMessageLog("New subscriber imported SubscriberEligibilityID: {0}", this.subscriberEligibilityID);
			}	
			else
			{
				// else A subscriber was already found.
				coverageSelectionContext.AddToMessageLog("Using an existing subscriber.  SubscriberID: {0}", this.subscriberID);
				subscriber = this.Subscriber;	// use the found subscriber
				// just create the patient-coverage record.
			}

			/// USE CASE ID: UC3.5
			/// TITLE: CREATE PATIENT COVERAGE
			/// REQUIREMENT ID: 1.8.4.6,1.8.4.7, 1.8.4.8
			/// Step 4.c
			patCov.ImportFromEligibility(coverageSelectionContext, this.PatientEligibility, this.SubscriberEligibility, this.PatientEligibilityPlan);
			// Actually create subscriber and the patient-coverage records
			
			if (coverageSelectionContext.SaveIfNewlyCreated)
			{
				coverageSelectionContext.AddToMessageLog("Saving subscriber and patient-coverage");
				subscriber.Save(coverageSelectionContext.Patient, patCov);
			}

			coverageSelectionContext.AddToMessageLog("Subscriber and patient-coverage has been saved (SubscriberID:{0}, PatientCoverageID:{1})", subscriber.SubscriberId, patCov.PatientCoverageID);
			
			// Make the new patient coverage available in the coverage-selection-context
			coverageSelectionContext.PatientCoverage = patCov;
		}

		public PlanTypeCollection LookupOf_PlanTypeId
		{
			get
			{
				return PlanTypeCollection.ActivePlanTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "	patientCoverageID= '" + ReflectionHelper.GetMemberValueAsString(this, "patientCoverageID") + "'\r\n";
			s += "	sORGID= '" + ReflectionHelper.GetMemberValueAsString(this, "sORGID") + "'\r\n";
			s += "	subscriberID= '" + ReflectionHelper.GetMemberValueAsString(this, "subscriberID") + "'\r\n";
			s += "	planID= '" + ReflectionHelper.GetMemberValueAsString(this, "planID") + "'\r\n";
			s += "	patientEligibilityID= '" + ReflectionHelper.GetMemberValueAsString(this, "patientEligibilityID") + "'\r\n";
			s += "	subscriberEligibilityID= '" + ReflectionHelper.GetMemberValueAsString(this, "subscriberEligibilityID") + "'\r\n";
			s += "}\r\n";
			return s;

		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PlanEffectiveDate
		{
			get { return this.planEffectiveDate; }
			set { this.planEffectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PlanTerminationDate
		{
			get { return this.planTerminationDate; }
			set { this.planTerminationDate = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of AvailableCoverage objects
	/// </summary>
	[ElementType(typeof(AvailableCoverage))]
	public class AvailableCoverageCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass, ICollectionElementFilter
	{
		private bool filterValidCovarages = true;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AvailableCoverage elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAvailableCoverageCollection = this;
			else
				elem.ParentAvailableCoverageCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AvailableCoverage elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AvailableCoverage this[int index]
		{
			get
			{
				return (AvailableCoverage)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AvailableCoverage)oldValue, false);
			SetParentOnElem((AvailableCoverage)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Generate the available coverages from eligibility and the PatientCoverage table.
		/// </summary>
		public int GenerateCoverageList(int maxRecords, int patientID, DateTime dateOfService)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GenerateCoverageListWithDAFilter", maxRecords, this, false, 
				new object[] { patientID, SQLDataDirect.MakeDBValue(dateOfService), SQLDataDirect.MakeDBValue(AASecurityHelper.GetUserId, (int)0) });
		}

		/// <summary>
		/// Generate the available coverages from eligibility and the PatientCoverage table.
		/// </summary>
		public int GenerateEligibilityCoverageList(int maxRecords, int patienteligibilityID, DateTime dateOfService)
		{
			this.Clear();
			return SqlData.SPExecReadCol(60, "usp_GenerateValidCoverageList", maxRecords, this, false, 
				new object[] { patienteligibilityID, SQLDataDirect.MakeDBValue(dateOfService) });
		}

		/// <summary>
		/// Validate coverage for the given patient subscriber log id
		/// and the date of service.
		/// Returns the patientsubscriberlogid int � if non-zero, the patientsubscriberlogid that should 
		/// be referenced, perhaps updated.
		/// </summary>
		public int ValidateCoverage(int patientSubscriberLogID, DateTime dateOfService)
		{
			//return 0;	// invalid coverage. temporary code.
			return Convert.ToInt32( SqlData.SPExecScalar("usp_ValidateCoverage", new object[] { patientSubscriberLogID, SQLDataDirect.MakeDBValue( dateOfService ) }) );
		}

		/// <summary>
		/// Returns -2 if there's no valid coverages.
		/// Returns -1 if there are more than one valid coverages.
		/// Returns N if a single valid coverage was found.
		/// </summary>
		/// <returns></returns>
		public int GetIndexOfValidCoverageIfSingle()
		{
			int lastValidIndex = -2;	// -2:   no valid covareges
			for (int i = 0; i < this.Count; i++)
			{
				AvailableCoverage avaCov = this[i];
				if (avaCov.ValidCoverage)
				{
					if (lastValidIndex >= 0)
						return -1;		// there are more than 1 valid coverages
					lastValidIndex = i;
				}
			}
			return lastValidIndex;		// return the last found valid coverage. Either there's no valid coverage or a single one.
		}

		/// <summary>
		/// Returns the first valid coverage that's from eligibility
		/// </summary>
		/// <returns></returns>
		public int GetIndexOfFirstValidCoverageFromEligibility()
		{
			for (int i = 0; i < this.Count; i++)
			{
				AvailableCoverage avaCov = this[i];
				if (avaCov.ValidCoverage && avaCov.IsFromEligibility)
					return i;
			}
			return -1;
		}

		public bool FilterValidCovarages
		{
			get { return this.filterValidCovarages; }
			set { this.filterValidCovarages = value; }
		}

		#region ICollectionElementFilter Members

		/// <summary>
		/// If FilterValidCoverages = true, only the valid coverages are to be 
		/// displayed on the grid.
		/// </summary>
		/// <param name="index"></param>
		/// <returns></returns>
		public bool FilterElement(int index)
		{
			if (!this.filterValidCovarages)
				return true;

			AvailableCoverage avaCov = this[index];
			return avaCov.ValidCoverage;
		}

		#endregion
	}

	public class CoverageSelectionContext 
	{
		public static bool CoverageLogDump = false;		// If true, the coverage selection steps are dumped on the page.  Read from web.config.

		private bool saveIfNewlyCreated = true;	// save the newly imported coverages if necessary.
		private bool isSaving;					// is in save phase or view phase
		private DateTime explicitDateOfService;		// if a specific date of service is to be used
		//private bool coverageSelected = false;	// true if the user selected a coverage
		private AvailableCoverageCollection availableCoverages;
		private Patient patient;
		private PatientCoverage patientCoverage;
		private Problem problem;
		private BaseForEventCMSReferral erc;
		private string coverageSelectionPrompt;			// The message that's displayed in the coverage selection page.
		private ArrayList messageLog = new ArrayList();		// track of allt the steps performed
		private IntakeLog intakeLog;

		public CoverageSelectionContext(bool isSaving, Patient patient, PatientCoverage patientCoverage, Problem problem, BaseForEventCMSReferral erc)
		{
			this.isSaving = isSaving;
			this.patient = patient;
			this.patientCoverage = patientCoverage;
			this.problem = problem;
			this.erc = erc;
			if (this.patientCoverage == null)
			{
				// if not passed directly
				if (this.problem != null)
					if (!this.problem.IsNew)	// if event, CMS or referral is not new, use the coverage it's linked to
						this.patientCoverage = problem.PatientSubscriberLog.PatientCoverage;
				if (this.erc != null)
					if (!this.erc.IsNew)	// if event, CMS or referral is not new, use the coverage it's linked to
						this.patientCoverage = erc.PatientSubscriberLog.PatientCoverage;
			}
		}

		/// <summary>
		/// This constructor is used when available coverage selection is to be called
		/// from IntakeLog.
		/// </summary>
		/// <param name="intakeLog"></param>
		public CoverageSelectionContext(IntakeLog intakeLog)
			: this(false, intakeLog.Patient, intakeLog.PatientCoverage, null, null)
		{
			this.intakeLog = intakeLog;
			this.saveIfNewlyCreated = false; // do not automatically create the new coverage and subscriber in db.
			this.explicitDateOfService = intakeLog.ServiceDate;
		}

		public ArrayList MessageLog
		{
			get { return this.messageLog; }
		}

		public void AddToMessageLog(string msg)
		{
			this.messageLog.Add(msg);
			Debug.WriteLine(msg);
		}

		public void AddToMessageLog(string msg, params object[] parameters)
		{
			AddToMessageLog(String.Format(msg, parameters));
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "}\r\n";

			for (int i = 0; i < this.messageLog.Count; i++)
			{
				s += this.messageLog[i].ToString() + "\r\n";
			}
			
			return s;
		}

		public ActiveAdvice.DataLayer.AvailableCoverageCollection AvailableCoverages
		{
			get 
			{ 
				if (this.availableCoverages == null)
					this.availableCoverages = this.GetAvailableCoverages();
				return this.availableCoverages;
			}
			set { this.availableCoverages = value; }
		}

		public ActiveAdvice.DataLayer.Patient Patient
		{
			get { return this.patient; }
			set { this.patient = value; }
		}

		public ActiveAdvice.DataLayer.PatientCoverage PatientCoverage
		{
			get { return this.patientCoverage; }
			set { this.patientCoverage = value; }
		}

		public ActiveAdvice.DataLayer.Problem Problem
		{
			get { return this.problem; }
			set { this.problem = value; }
		}

		public ActiveAdvice.DataLayer.BaseForEventCMSReferral ERC
		{
			get { return this.erc; }
			set { this.erc = value; }
		}

		public DateTime GetDateOfService()
		{
			if (explicitDateOfService != DateTime.MinValue)
				return explicitDateOfService;
			if (this.erc != null)
				return this.erc.ERCStartDate;
			else if (this.problem != null)
				return this.problem.StartDate;
			else
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "No date of service can be found!");
		}

		/// <summary>
		/// PatientSubscriberLogID for the event or problem in the context.
		/// If the ERC or problem is new, then we find the last PatientSubscriberLogID for 
		/// the Patient and PatientCoverage in the current context.
		/// </summary>
		public int PatientSubscriberLogID
		{
			get
			{
				if (this.erc != null)
				{
					if (this.erc.IsNew)
					{
						// uses no transaction
						return GetPatientSubscriberLogID(null);		// if new find the last pat sub log id
					}
					return this.erc.PatientSubscriberLogID;
				}
				else if (this.problem != null)
				{
					if (this.problem.IsNew)	// uses no transaction
						return GetPatientSubscriberLogID(null);		// if new find the last pat sub log id
					return this.problem.PatientSubscriberLogID;
				}
				else
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "No ERC or Problem to get the PatientSubscriberLogID!");
			}
			set
			{
				// sets back the patient subscriber log id.
				// called after validateCoverage to set the newly returned log id.
				if (this.erc != null)
					this.erc.PatientSubscriberLogID = value;
				else if (this.problem != null)
					this.problem.PatientSubscriberLogID = value;
				else
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "No ERC or Problem to set the PatientSubscriberLogID!");
			}
		}

		/// <summary>
		/// Get the available coverages for the coverage context.
		/// </summary>
		/// <returns></returns>
		public AvailableCoverageCollection GetAvailableCoverages()
		{
			this.AddToMessageLog("Generating coverage list for {0}", this.GetDateOfService());
			int patientID = this.patient.PatientId;
			DateTime dateOfService = this.GetDateOfService();
			AvailableCoverageCollection availableCoverages = new AvailableCoverageCollection();
			availableCoverages.GenerateCoverageList(-1, patientID, dateOfService );
			return availableCoverages;
		}

		/// <summary>
		/// Find the latest patient subscriber log id for this patient and coverage.
		/// Called when the problem or ERC is new and has no linked PatientSubscriberLogID on it.
		/// </summary>
		/// <returns></returns>
		public int GetPatientSubscriberLogID(SqlTransactionWithEvents transaction)
		{
			return PatientSubscriberLog.GetLastPatientSubscriberLogID(transaction, this.patient, this.patientCoverage);
		}

		/// <summary>
		/// Validate the covereage for the dateof service and the patientsubscriberlog id.
		/// If the coverage is valid, the returned PatientSubscriberLogID is set to ERC or Problem in the context.
		/// If the coverage is not valid, false is returned.
		/// </summary>
		/// <returns></returns>
		public bool ValidateCoverage()
		{
			int patSubLogID = this.PatientSubscriberLogID;
			this.AddToMessageLog("Validating Coverage for PatientSubscriberLogID:{0}", patSubLogID);
			AvailableCoverageCollection avaCovCol = new AvailableCoverageCollection();
			int validPatSubLogID = avaCovCol.ValidateCoverage(patSubLogID, this.GetDateOfService());
			if (this.erc != null)
			{
				this.erc.ERCLastValidationDate = DateTime.Today;	// set the last validation date
				
				if (!this.erc.IsNew)		// if not new, update the last validation date in the db directly
				{
					this.erc.UpdateLastValidationDate();
					this.AddToMessageLog("Last validation date updated for ERC-ID:", erc.ID);
				}
				else
				{
					// not new just put a message log
					this.AddToMessageLog("Last validation date set for new ERC");
				}
			}
			if (validPatSubLogID == 0)
			{
				this.AddToMessageLog("Coverage Invalid!");
				return false;
			}

			if (patSubLogID != validPatSubLogID)
			{
				// Different log id returned.
				this.AddToMessageLog("A different valid log entry found.  New PatientSubscriberLogID={0} with valid coverage.  Relinking with this.", validPatSubLogID);
				this.PatientSubscriberLogID = validPatSubLogID;		// set to ERC or Problem in the context.
			}
			else
			{
				this.AddToMessageLog("Coverage valid.");
			}

			return true;
		}

		/// <summary>
		/// Save the problem in the selected patient coverage context.
		/// </summary>
		/// <returns></returns>
		public void SaveProblem()
		{
			if (this.patientCoverage == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "A valid patient coverage must be selected before saving the problem!");

			this.problem.Save(this.patientCoverage);
		}

		/// <summary>
		/// Save the problem in the selected patient coverage context.
		/// </summary>
		/// <returns></returns>
		public void SaveERC()
		{
			if (this.patientCoverage == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "A valid patient coverage must be selected before saving the event-referral-CMS!");

			if (!erc.IsNew)
			{
				// Change coverage if necessary.
				erc.ChangeCoverage(this.patientCoverage);	// make sure the ERC is linked to the new patient subscriber log entry.
			}

			Event eventObj = erc as Event;
			if (eventObj != null)
			{
				if (eventObj.IsNew)
					eventObj.Save(this.patientCoverage, this.problem);
				else
					eventObj.Save();
				return;
			}
			Referral referralObj = erc as Referral;
			if (referralObj != null)
			{
				if (referralObj.IsNew)
				{
					//throw new ActiveAdviceException(AAExceptionAction.None, "Referral must implement Save(PatientCoverage, Problem) method to be saved in this context");
					referralObj.Save(this.patientCoverage, this.problem);		// must be fixed
				}
				else
					referralObj.Save();
				return;
			}
			CMS cmsObj = erc as CMS;
			if (cmsObj != null)
			{
				if (cmsObj.IsNew)
					cmsObj.Save(this.patientCoverage, this.problem);
				else
					cmsObj.Save();
				return;
			}

			throw new ActiveAdviceException(AAExceptionAction.None, "No Event/Referral/CMS is in the coverage selection context");
		}

		public bool IsSaving
		{
			get { return this.isSaving; }
			set { this.isSaving = value; }
		}

		public bool SaveIfNewlyCreated
		{
			get { return this.saveIfNewlyCreated; }
			set { this.saveIfNewlyCreated = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string CoverageSelectionPrompt
		{
			get { return this.coverageSelectionPrompt; }
			set { this.coverageSelectionPrompt = value; }
		}

		public ActiveAdvice.DataLayer.IntakeLog IntakeLog
		{
			get { return this.intakeLog; }
			set { this.intakeLog = value; }
		}

		/*/// <summary>
		/// Coverage selected by user or not.
		/// </summary>
		public bool CoverageSelected
		{
			get { return this.coverageSelected; }
			set { this.coverageSelected = value; }
		}*/

	}

}
