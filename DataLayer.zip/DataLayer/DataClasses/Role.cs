using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	
	/// <summary>
	/// Summary description for SelectableRole.
	/// </summary>
	public class SelectableRole : Role
	{
		private bool selected;

		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [Roles]
	/// </summary>
	
	[SPAutoGen("usp_GetAllRoles","SelectAll.sptpl","")]
	[SPDelete("usp_DeleteRole")]
	[SPAutoGen("usp_GetRolesByContactOwnerTypeID","SelectAllByGivenArgs.sptpl","contactOwnerTypeID, active")]
	[SPInsert("usp_InsertRole")]
	[SPUpdate("usp_UpdateRole")]
	[SPLoad("usp_LoadRole")]
	[TableMapping("Role","roleID")]
	public class Role : BaseLookupWithNote
	{
		[NonSerialized]
		protected RoleCollection parentRoleCollection;
		[ColumnMapping("RoleID",StereoType=DataStereoType.FK)]
		protected int roleID;
		[ColumnMapping("Notepad")]
		private string notepad;

		[ColumnMapping("ContactOwnerTypeID")]
		protected int contactOwnerTypeID;
	
		public Role()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public int RoleID
		{
			get { return this.roleID; }
			set { this.roleID = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int roleID)
		{
			return base.Load(roleID);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Parent RoleCollection that contains this element
		/// </summary>
		public RoleCollection ParentRoleCollection
		{
			get
			{
				return this.parentRoleCollection;
			}
			set
			{
				this.parentRoleCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ContactOwnerTypeID
		{
			get { return this.contactOwnerTypeID; }
			set { this.contactOwnerTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of Role objects
	/// </summary>
	[ElementType(typeof(Role))]
	public class RoleCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_RoleID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Role elem, bool setUnset)
		{ 
			if (setUnset)
				elem.ParentRoleCollection = this;
			else
				elem.ParentRoleCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Role elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Role this[int index]
		{
			get
			{
				return (Role)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Role)oldValue, false);
			SetParentOnElem((Role)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}


		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetRolesByContactOwnerType(int maxRecords, ContactOwnerType contactOwnerType, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetRolesByContactOwnerTypeID", maxRecords, this, false, new object[] { (int)contactOwnerType, active});
		}

		public int LoadByContactOwnerTypeForSelection(int maxRecords, ContactOwnerType contactOwnerType, bool active)
		{
			this.Clear();
			this.ElementType = typeof(SelectableRole);
			return SqlData.SPExecReadCol("usp_GetRolesByContactOwnerTypeID", maxRecords, this, false, new object[] { (int)contactOwnerType, active});
		}


		public static RoleCollection GetRolesByContactOwnerTypeForSelection(ContactOwnerType contactOwnerType)
		{
			RoleCollection col = new RoleCollection();
			// initialize the content of the collection
			col.LoadByContactOwnerTypeForSelection(-1, contactOwnerType, true);
			return col;
		}

		public void SetSelectedRolesFromCollection(ContactRoleCollection selectedRoles)
		{
			foreach (Role role in this)
			{
				if (selectedRoles.FindBy(role.RoleID) != null)
					((SelectableRole)role).Selected = true;
			}
		}


		/// <summary>
		/// Hashtable based index on roleID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_RoleID
		{
			get
			{
				if (this.indexBy_RoleID == null)
					this.indexBy_RoleID = new CollectionIndexer(this, new string[] { "roleID" }, true);
				return this.indexBy_RoleID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on roleID fields returns the object.  Uses the IndexBy_RoleID indexer.
		/// </summary>
		public Role FindBy(int roleID)
		{
			return (Role)this.IndexBy_RoleID.GetObject(roleID);
		}

		/// <summary>
		/// Accessor to a shared RoleCollection which is cached in NSGlobal
		/// </summary>
		public static RoleCollection ProviderLocationRoles
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				RoleCollection col = (RoleCollection)NSGlobal.EnsureCachedObject("ProviderLocationRoles", typeof(RoleCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetRolesByContactOwnerType(-1, ContactOwnerType.ProviderLocation, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllRoles(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllRoles", -1, this, false);
		}		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllRoles", -1, this, false);
		}	
		
	}
}
