using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Urgency]
	/// </summary>	
	
	[SPAutoGen("usp_GetUrgencyByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllUrgency","SelectAll.sptpl","")]
	[SPInsert("usp_InsertUrgency")]
	[SPUpdate("usp_UpdateUrgency")]
	[SPDelete("usp_DeleteUrgency")]
	[SPLoad("usp_LoadUrgency")]
	[TableMapping("Urgency","urgencyId")]
	public class Urgency11 : BaseLookupWithCode
	{
		[NonSerialized]
		private UrgencyCollection parentUrgencyCollection;
		[ColumnMapping("UrgencyId",StereoType=DataStereoType.FK)]
		private int urgencyId;
	
		public Urgency11()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int UrgencyId
		{
			get { return this.urgencyId; }
			set { this.urgencyId = value; }
		}

		/// <summary>
		/// Parent UrgencyCollection that contains this element
		/// </summary>
		public UrgencyCollection ParentUrgencyCollection
		{
			get
			{
				return this.parentUrgencyCollection;
			}
			set
			{
				this.parentUrgencyCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of Urgency objects
	/// </summary>
	[ElementType(typeof(Urgency11))]
	public class UrgencyCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Urgency11 elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentUrgencyCollection = this;
			else
				elem.ParentUrgencyCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Urgency11 elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Urgency11 this[int index]
		{
			get
			{
				return (Urgency11)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Urgency11)oldValue, false);
			SetParentOnElem((Urgency11)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadUrgencyByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetUrgencyByActive", maxRecords, this, false, new object [] { active });
		}

		/// <summary>
		/// Accessor to a shared ReferralTypeCollection which is cached in NSGlobal
		/// </summary>
		public static UrgencyCollection ActiveUrgency
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				UrgencyCollection col = (UrgencyCollection)NSGlobal.EnsureCachedObject("ActiveUrgency", typeof(UrgencyCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					//col.GetFacilityFocusTypesByActive(-1, true);
					col.LoadUrgencyByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
