using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Locations]
	/// </summary>
	[SPInsert("usp_InsertLocation")]
	[SPUpdate("usp_UpdateLocation")]
	[SPDelete("usp_DeleteLocation")]
	[SPLoad("usp_LoadLocation")]
	[TableMapping("Location","locationID")]
	public class Location : BaseData
	{
		[ColumnMapping("LocationID",StereoType=DataStereoType.FK)]
		private int locationID;
		[ColumnMapping("MailingAddressID",StereoType=DataStereoType.FK)]
		private int mailingAddressID;
		[ColumnMapping("BillingAddressID",StereoType=DataStereoType.FK)]
		private int billingAddressID;
		[ColumnMapping("ServiceAddressID",StereoType=DataStereoType.FK)]
		private int serviceAddressID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime",StereoType=DataStereoType.DateTime)]
		private DateTime createTime;
		[ColumnMapping("ModifyTime",StereoType=DataStereoType.DateTime)]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("UPIN")]
		private string uPIN;
		[ColumnMapping("FederalTaxID")]
		private string federalTaxID;
		[ColumnMapping("MedicareID")]
		private string medicareID;

		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("Notepad")]
		private string notepad;
		[ColumnMapping("StatusChangedBy",StereoType=DataStereoType.FK)]
		private int statusChangedBy;
		[ColumnMapping("StatusChangeDate")]
		private DateTime statusChangeDate;
		[ColumnMapping("AlternateID")]
		private string alternateID;
		private Address mailingAddress;
		private Address billingAddress;
		private Address serviceAddress;

		/*[ColumnMapping("CreatedByName", JoinColumn="LoginName", JoinRelation="Location.CreatedBy = [AAUser].UserId")]
		private string createdByStr;
		[ColumnMapping("ModifiedByName", JoinColumn="LoginName", JoinRelation="Location.ModifiedBy = [AAUser].UserId")]
		private string modifiedByStr;*/
		[ColumnMapping("StatusChangedByName", JoinColumn="LoginName", JoinRelation="Location.StatusChangedBy = [AAUser].UserId")]
		private string statusChangedByStr;

		public string StatusChangedByStr
		{
			get { return this.statusChangedByStr; }
		}
		/*public string CreatedByStr
		{
			get { return this.createdByStr; }
		}

		public string ModifiedByStr
		{
			get { return this.modifiedByStr; }
		}*/
	
		public Location()
		{
			
		}
		
		
		public Location(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox)]
		public int LocationID
		{
			get { return this.locationID; }
			set { this.locationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MailingAddressID
		{
			get { return this.mailingAddressID; }
			set { this.mailingAddressID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int BillingAddressID
		{
			get { return this.billingAddressID; }
			set { this.billingAddressID = value;}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ServiceAddressID
		{
			get { return this.serviceAddressID; }
			set { this.serviceAddressID = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{

			base.Save();		
			
		}

		
		

		/// <summary>
		/// Updates/Inserts/Deletes/Loads a record depending on its status flags.
		/// </summary>
		public new void Synchronize()
		{
			base.Synchronize();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int locationID)
		{
			return base.Load(locationID);
		}

	

		/// <summary>
		/// Contained MailingAddress object
		/// </summary>
		public Address MailingAddress
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.mailingAddress = (Address)Address.EnsureContainedDataObject(this, typeof(Address), mailingAddress, false, mailingAddressID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.mailingAddress;
			}
			set 
			{
				this.mailingAddress = value;
				if (this.mailingAddress != null)
					this.mailingAddressID = this.mailingAddress.AddressID;
			}
		}

		/// <summary>
		/// Contained BillingAddress object
		/// </summary>
		public Address BillingAddress
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.billingAddress = (Address)Address.EnsureContainedDataObject(this, typeof(Address), billingAddress, false, billingAddressID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.billingAddress;
			}
			set
			{
				this.billingAddress = value;
				if (this.billingAddress != null)
					this.billingAddressID = this.billingAddress.AddressID;
			}
			
		}

		/// <summary>
		/// Contained ServiceAddress object
		/// </summary>
		[Contained]
		public Address ServiceAddress
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.serviceAddress = (Address)Address.EnsureContainedDataObject(this, typeof(ServiceAddress), serviceAddress, false, this.serviceAddressID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.serviceAddress;
			}
			set
			{
				
				this.serviceAddress = value;
				if (this.serviceAddress != null)
					this.serviceAddressID = this.serviceAddress.AddressID;
			}
		}

		

		protected  override void InternalSave()
		{	
			/*
			 * How do we use transactions here to save
			 * all contained objects and parent information
			 * in one transaction ?
			 */


			// Save Address Information
			if (this.mailingAddress != null)
			{
				// Must pass transaction to the contained object
				this.mailingAddress.SqlData.Transaction = this.SqlData.Transaction;
				this.mailingAddress.Save();				// create transaction here and then pass it to Save() method?
				this.MailingAddressID		= this.MailingAddress.AddressID;
			}
			

			if (this.serviceAddress != null)
			{
				// Must pass transaction to the contained object
				this.serviceAddress.SqlData.Transaction = this.SqlData.Transaction;
				this.serviceAddress.Save();
				
				this.ServiceAddressID		= this.ServiceAddress.AddressID;
			}
		
		

			if (this.billingAddress != null)
			{
				// Must pass transaction to the contained object
				this.billingAddress.SqlData.Transaction = this.SqlData.Transaction;
				this.billingAddress.Save();
				this.BillingAddressID		= this.BillingAddress.AddressID;
			}
		

			// save current record
			base.InternalSave();

			
			
		}

		protected override bool InternalLoad(params object[] keys)
		{	
			return base.InternalLoad (keys);
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state\
			
			// set contained objects to NULL;
			this.mailingAddress = null;
			this.serviceAddress = null;
			this.billingAddress = null;

		}

		/// <summary>
		/// Parent ProviderLocation that contains this object
		/// </summary>
		public ProviderLocation ParentProviderLocation
		{
			get { return this.ParentDataObject as ProviderLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ProviderLocation */ }
		}
		
		/// <summary>
		/// Parent ProviderLocation that contains this object
		/// </summary>
		public FacilityLocation ParentFacilityLocation
		{
			get { return this.ParentDataObject as FacilityLocation ; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ProviderLocation */ }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.serviceAddressID = 0;
			this.mailingAddressID = 0;
			this.billingAddressID = 0;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Parent BaseLocation that contains this object
		/// </summary>
		public BaseLocation ParentBaseLocation
		{
			get { return this.ParentDataObject as BaseLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a BaseLocation */ }
		}

		/*
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}*/

		[ControlType(EnumControlTypes.TextBox, MaxLength=12)]
		public string UPIN
		{
			get { return this.uPIN; }
			set { this.uPIN = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string FederalTaxID
		{
			get { return this.federalTaxID; }
			set { this.federalTaxID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string MedicareID
		{
			get { return this.medicareID; }
			set { this.medicareID = value; }
		}



		[ControlType(EnumControlTypes.CheckBox,ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StatusChangeDate
		{
			get { return this.statusChangeDate; }
			set { this.statusChangeDate = value; }
		}

		[FieldDescription("@ADDRESS@")]
		public string FullAddress
		{
			get 
			{
				if (this.ServiceAddress != null)
				{
					
					return this.ServiceAddress.Line1 + " " + this.ServiceAddress.City + ", " + this.ServiceAddress.State + ", " + this.ServiceAddress.Zip;
				}
				else
					return "@UNKNOWN@";
			}

		}

		/// <summary>
		/// Returns the location for the given location ID.
		/// </summary>
		/// <param name="providerID"></param>
		/// <returns></returns>
		public static string GetLocationAddressDescriptionByID(int locationID)
		{
			if (locationID == 0)
				return null;
			Location location = new Location();
			if (location.Load(locationID))
				return location.FullAddress;
			else
				return null;
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}

	}
	
	public class ServiceAddress : Address
	{
		[ControlType(EnumControlTypes.TextBox, MaxLength=255,IsRequired=true)]
		public string Line1
		{
			get { return this.line1 ; }
			set { this.line1 = value; }
		}
	}

}


