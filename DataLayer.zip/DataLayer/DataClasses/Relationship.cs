using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Relationship]
	/// </summary>
	[SPAutoGen("usp_GetAllRelationships","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetRelationshipsByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertRelationship")]
	[SPUpdate("usp_UpdateRelationship")]
	[SPDelete("usp_DeleteRelationship")]
	[SPLoad("usp_LoadRelationship")]
	[TableMapping("Relationship","relationshipId")]
	public class RelationshipType : BaseLookupWithNoteWithOutCode
	{
		[NonSerialized]
		private RelationshipTypeCollection parentRelationshipTypeCollection;
		[ColumnMapping("RelationshipId",StereoType=DataStereoType.FK)]
		private int relationshipId;
		[ColumnMapping("RelationshipName")]
		private string relationshipName;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public RelationshipType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int RelationshipId
		{
			get { return this.relationshipId; }
			set { this.relationshipId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string RelationshipName
		{
			get { return this.relationshipName; }
			set { this.relationshipName = value; }
		}
		
		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		} 

		[FieldDescription("@RELATIONSHIPNAME@")]
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public override string Text
		{
			get { return this.relationshipName; }
			set { this.relationshipName = value; }
		} 

		/// <summary>
		/// Parent RelationshipCollection that contains this element
		/// </summary>
		public RelationshipTypeCollection ParentRelationshipTypeCollection
		{
			get
			{
				return this.parentRelationshipTypeCollection;
			}
			set
			{
				this.parentRelationshipTypeCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of Relationship objects
	/// </summary>
	[ElementType(typeof(RelationshipType))]
	public class RelationshipTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_relationshipId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(RelationshipType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentRelationshipTypeCollection = this;
			else
				elem.ParentRelationshipTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (RelationshipType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public RelationshipType this[int index]
		{
			get
			{
				return (RelationshipType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((RelationshipType)oldValue, false);
			SetParentOnElem((RelationshipType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetRelationshipsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetRelationshipsByActive", maxRecords, this, false, new object[] { active } );
		}

		/// <summary>
		/// Accessor to a shared RelationshipCollection which is cached in NSGlobal
		/// </summary>
		public static RelationshipTypeCollection ActiveRelationshipTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				RelationshipTypeCollection col = (RelationshipTypeCollection)NSGlobal.EnsureCachedObject("ActiveRelationshipTypes", typeof(RelationshipTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetRelationshipsByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on relationshipId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_relationshipId
		{
			get
			{
				if (this.indexBy_relationshipId == null)
					this.indexBy_relationshipId = new CollectionIndexer(this, new string[] { "relationshipId" }, true);
				return this.indexBy_relationshipId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on relationshipId fields returns the object.  Uses the IndexBy_relationshipId indexer.
		/// </summary>
		public RelationshipType FindBy(int relationshipId)
		{
			return (RelationshipType)this.IndexBy_relationshipId.GetObject(relationshipId);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllRelationships", -1, this, false);
		}
	}
}
