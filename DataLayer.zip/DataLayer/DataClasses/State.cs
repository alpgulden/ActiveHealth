using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [State]
	/// </summary>
	[SPDelete("usp_DeleteState")]
	[SPAutoGen("usp_GetAllStates","SelectAll.sptpl","")]
	[SPInsert("usp_InsertState")]
	[SPUpdate("usp_UpdateState")]
	[SPLoad("usp_LoadState")]
	[TableMapping("State","stateID")]
	public class State : BaseLookupWithNoteWithOutCode
	{
		[NonSerialized]
		private StateCollection parentStateCollection;
		[ColumnMapping("StateID",(int)0)]
		private int stateID;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public State()
		{
		}
 
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int StateID
		{
			get { return this.stateID; }
			set { this.stateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=2)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		} 

		[FieldDescription("@CODE@")]
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=2)]
		public override string Text
		{
			get { return this.code; }
			set { this.code = value; }
		} 

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent StateCollection that contains this element
		/// </summary>
		public StateCollection ParentStateCollection
		{
			get
			{
				return this.parentStateCollection;
			}
			set
			{
				this.parentStateCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of State objects
	/// </summary>
	[ElementType(typeof(State))]
	public class StateCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		[NonSerialized]
		private CollectionIndexer indexBy_StateID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(State elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentStateCollection = this;
			else
				elem.ParentStateCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (State elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public State this[int index]
		{
			get
			{
				return (State)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((State)oldValue, false);
			SetParentOnElem((State)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllStates(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllStates", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared StateCollection which is cached in NSGlobal
		/// </summary>
		public static StateCollection AllStates
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				StateCollection col = (StateCollection)NSGlobal.EnsureCachedObject("AllStates", typeof(StateCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllStates(-1);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on stateID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_StateID
		{
			get
			{
				if (this.indexBy_StateID == null)
					this.indexBy_StateID = new CollectionIndexer(this, new string[] { "stateID" }, true);
				return this.indexBy_StateID;
			}
			
		}

		/// <summary>
		/// Looks up by stateID and returns Code value.  Uses the IndexBy_StateID indexer.
		/// </summary>
		public string Lookup_CodeByStateID(int stateID)
		{
			return this.IndexBy_StateID.LookupStringMember("Code", stateID);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns StateID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_StateIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("StateID", code);
		}

		
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllStates", -1, this, false);
		}
	}
}
