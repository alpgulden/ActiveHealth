using System;
using System.Diagnostics;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SpecialProcedures]
	/// The Plan Special Procedures provides a method by which special action can be 
	/// taken for a defined list of diagnostic and/or procedure codes. These procedure 
	/// lists are associated with Plans and initiate Review and/or Referral processes 
	/// for specific medical diagnostics and/or procedures.
	/// 
	/// BR01.39.2.8	System shall allow the User to copy an existing Special Procedure List.
	/// </summary>
	[SPAutoGen("usp_SearchSpecialProcedures","SearchEffectiveRecordsForDate.sptpl","name, listId, effectiveDate")]
	[SPAutoGen("usp_GetEffectiveSpecialProceduresForDate","SelectActiveRecordsForDate.sptpl","effectiveDate, terminationDate")]
	[SPInsert("usp_InsertSpecialProcedure")]
	[SPUpdate("usp_UpdateSpecialProcedure")]
	[SPDelete("usp_DeleteSpecialProcedure")]
	[SPLoad("usp_LoadSpecialProcedure")]
	[TableMapping("SpecialProcedure","specialProcedureId")]
	public class SpecialProcedure : BaseData
	{
		[NonSerialized]
		private SpecialProcedureCollection parentSpecialProcedureCollection;
		[ColumnMapping("SpecialProcedureId",StereoType=DataStereoType.FK)]
		private int specialProcedureId;
		[ColumnMapping("Name")]
		private string name;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("ListId")]
		private string listId;

		private DateTime termDateWhenLoaded;
		private SpecialProcedureItemCollection specialProcedureItems;
	
		public SpecialProcedure()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public SpecialProcedure(int specialProcedureId, string name, string listId)
		{
			this.NewRecord(); // initialize record state
			this.specialProcedureId = specialProcedureId;
			this.name = name;
			this.listId = listId;
		}

		public SpecialProcedure(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int SpecialProcedureId
		{
			get { return this.specialProcedureId; }
			set { this.specialProcedureId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=128)]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]		// defined in the base
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=15)]
		public string ListId
		{
			get { return this.listId; }
			set { this.listId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SaveSpecialProcedureItems(); // save the items in a seperate transaction
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int specialProcedureId)
		{
			return base.Load(specialProcedureId);
		}

		/// <summary>
		/// Use this function to test CRUD operations on this class
		/// </summary>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void TestCRUDOperations()
		{
			for (int i = 0; i < 10; i++)
			{
				SpecialProcedure obj = new SpecialProcedure();  // Use appropriate constructor
				obj.NewRecord();
				// Do other initializations on the object;
				obj.Save();
				Debug.Assert(obj.Load(), "Load failed for SpecialProcedure PK="+obj.PKString);
				// do some change in the properties
				obj.Save();
				obj.MarkDel();  // Mark for deletion
				obj.Save();  // Delete it
			}
		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			
			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}

			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Child SpecialProcedureItems mapped to related rows of table SpecialProcedureItems where [SpecialProcedureId] = [SpecialProcedureId]
		/// </summary>
		[SPLoadChild("usp_LoadSpecialProcedureItems", "specialProcedureId")]
		public SpecialProcedureItemCollection SpecialProcedureItems
		{
			get { return this.specialProcedureItems; }
			set
			{
				this.specialProcedureItems = value;
				if (value != null)
					value.ParentSpecialProcedure = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the SpecialProcedureItems collection
		/// </summary>
		public void LoadSpecialProcedureItems(bool forceReload)
		{
			this.specialProcedureItems = (SpecialProcedureItemCollection)SpecialProcedureItemCollection.LoadChildCollection("SpecialProcedureItems", this, typeof(SpecialProcedureItemCollection), specialProcedureItems, forceReload, null);
		}

		/// <summary>
		/// Saves the SpecialProcedureItems collection
		/// </summary>
		public void SaveSpecialProcedureItems()
		{
			SpecialProcedureItemCollection.SaveChildCollection(this.specialProcedureItems, true);
		}

		/// <summary>
		/// Synchronizes the SpecialProcedureItems collection
		/// </summary>
		public void SynchronizeSpecialProcedureItems()
		{
			SpecialProcedureItemCollection.SynchronizeChildCollection(this.specialProcedureItems, true);
		}

		/// <summary>
		/// Parent SpecialProcedureCollection that contains this element
		/// </summary>
		public SpecialProcedureCollection ParentSpecialProcedureCollection
		{
			get
			{
				return this.parentSpecialProcedureCollection;
			}
			set
			{
				this.parentSpecialProcedureCollection = value; // parent is set when added to a collection
			}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFields(this, "Name");
			}
		}

		/// <summary>
		/// Create a copy of this special procedure.
		/// All items are also copied.
		/// </summary>
		/// <returns></returns>
		public SpecialProcedure CreateCopyOfSpecialProcedure()
		{
			SpecialProcedure specproc = new SpecialProcedure(true);
			this.CopyMappedMembersTo(specproc, false, false, false);

			// copy items
			this.LoadSpecialProcedureItems(false);
			specproc.LoadSpecialProcedureItems(false);
			this.SpecialProcedureItems.CopyElementsTo(specproc.SpecialProcedureItems, false, true);		// deep copy, don't mark new

			return specproc;
		}
		
	}

	/// <summary>
	/// Strongly typed collection of SpecialProcedure objects
	/// </summary>
	[ElementType(typeof(SpecialProcedure))]
	public class SpecialProcedureCollection : BaseDataCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_SpecialProcedureId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SpecialProcedure elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSpecialProcedureCollection = this;
			else
				elem.ParentSpecialProcedureCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SpecialProcedure elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SpecialProcedure this[int index]
		{
			get
			{
				return (SpecialProcedure)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SpecialProcedure)oldValue, false);
			SetParentOnElem((SpecialProcedure)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Load all active special procedures for the given date
		/// </summary>
		public int LoadEffectiveSpecialProceduresForDate(int maxRecords, DateTime currentDate)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetEffectiveSpecialProceduresForDate", maxRecords, this, false, currentDate);
		}

		/// <summary>
		/// Accessor to a shared SpecialProcedureCollection which is cached in NSGlobal
		/// </summary>
		public static SpecialProcedureCollection EffectiveSpecialProcedures
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				SpecialProcedureCollection col = (SpecialProcedureCollection)NSGlobal.EnsureCachedObject("EffectiveSpecialProcedures", typeof(SpecialProcedureCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadEffectiveSpecialProceduresForDate(-1, DateTime.Today);
				}
				return col;
			}
		}

		public static void ClearFromCache()
		{
			NSGlobal.ClearCache(typeof(SpecialProcedureCollection), false);
		}

		/// <summary>
		/// Search special procedures by the given object's members.
		/// </summary>
		public int Search(int maxRecords, SpecialProcedure searcher, bool effectiveOnly)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchSpecialProcedures", maxRecords, this, searcher, false,
				new string[] { "effectiveOnly" }, new object[] { effectiveOnly } );
		}

		/// <summary>
		/// Hashtable based index on specialProcedureId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_SpecialProcedureId
		{
			get
			{
				if (this.indexBy_SpecialProcedureId == null)
					this.indexBy_SpecialProcedureId = new CollectionIndexer(this, new string[] { "specialProcedureId" }, true);
				return this.indexBy_SpecialProcedureId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on specialProcedureId fields returns the object.  Uses the IndexBy_SpecialProcedureId indexer.
		/// </summary>
		public SpecialProcedure FindBy(int specialProcedureId)
		{
			return (SpecialProcedure)this.IndexBy_SpecialProcedureId.GetObject(specialProcedureId);
		}
	}
}
