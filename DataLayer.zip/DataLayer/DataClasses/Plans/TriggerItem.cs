using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [TriggerItems]
	/// </summary>
	[SPAutoGen("usp_GetTriggerItemsInCodeRange","SelectByArgsAndRange.sptpl","code:codeStart, codeStart, codeEnd, triggerListId, diagOrProc, codeType", InjectWhere="AND @currentDate >= EffectiveDate AND @currentDate <= TerminationDate", InjectParameters="@currentDate DateTime")]
	[SPAutoGen("usp_SearchTriggerItems","SearchByArgs.sptpl","triggerListId, diagOrProc, codeType, description")]
	[SPInsert("usp_InsertTriggerItem")]
	[SPUpdate("usp_UpdateTriggerItem")]
	[SPDelete("usp_DeleteTriggerItem")]
	[SPLoad("usp_LoadTriggerItem")]
	[TableMapping("TriggerItem","triggerItemId")]
	public class TriggerItem : BaseDataWithUserDefined
	{
		[NonSerialized]
		private TriggerItemCollection parentTriggerItemCollection;
		[ColumnMapping("TriggerItemId",StereoType=DataStereoType.FK)]
		private int triggerItemId;
		[ColumnMapping("TriggerListId")]
		private int triggerListId;
		[ColumnMapping("DiagOrProc")]
		private string diagOrProc;
		[ColumnMapping("CodeType")]
		private string codeType;
		[ColumnMapping("CodeStart")]
		private string codeStart;
		[ColumnMapping("CodeEnd")]
		private string codeEnd;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("CareManagement")]				// if this is true, set the dx or px flag CMTrigger when added
		private bool careManagement;
		[ColumnMapping("DiseaseManagement")]			// if this is true, set the dx or px flag DMTrigger when added
		private bool diseaseManagement;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
	
		public TriggerItem()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public TriggerItem(string diagOrProc, string codeType, string codeStart, string codeEnd, string description)
		{
			this.NewRecord(); // initialize record state
			this.diagOrProc = diagOrProc;
			this.codeType = codeType;
			this.codeStart = codeStart;
			this.codeEnd = codeEnd;
			this.description = description;
		}

		public TriggerItem(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int TriggerItemId
		{
			get { return this.triggerItemId; }
			set { this.triggerItemId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TriggerListId
		{
			get { return this.triggerListId; }
			set { this.triggerListId = value; }
		}

		[FieldValuesMember("ValuesOf_DiagOrProc")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, IsRequired=true)]
		public string DiagOrProc
		{
			get { return this.diagOrProc; }
			set { this.diagOrProc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=16)]
		public string CodeStart
		{
			get { return this.codeStart; }
			set { this.codeStart = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=16)]
		public string CodeEnd
		{
			get { return this.codeEnd; }
			set { this.codeEnd = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool CareManagement
		{
			get { return this.careManagement; }
			set { this.careManagement = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool DiseaseManagement
		{
			get { return this.diseaseManagement; }
			set { this.diseaseManagement = value; }
		}

		[FieldValuesMember("ValuesOf_CodeType")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, IsRequired=true)]
		public string CodeType
		{
			get { return this.codeType; }
			set { this.codeType = value; }
		}

		/// <summary>
		/// Parent TriggerItemCollection that contains this element
		/// </summary>
		public TriggerItemCollection ParentTriggerItemCollection
		{
			get
			{
				return this.parentTriggerItemCollection;
			}
			set
			{
				this.parentTriggerItemCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int triggerItemId)
		{
			return base.Load(triggerItemId);
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFields(this, "Description");
			}
		}

		/// <summary>
		/// Create a copy of the trigger item.
		/// </summary>
		/// <returns></returns>
		public TriggerItem CreateCopyOfTriggerItem()
		{
			return (TriggerItem)this.Clone(true);
		}
	}

	/// <summary>
	/// Strongly typed collection of TriggerItem objects
	/// </summary>
	[ElementType(typeof(TriggerItem))]
	public class TriggerItemCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(TriggerItem elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentTriggerItemCollection = this;
			else
				elem.ParentTriggerItemCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (TriggerItem elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public TriggerItem this[int index]
		{
			get
			{
				return (TriggerItem)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((TriggerItem)oldValue, false);
			SetParentOnElem((TriggerItem)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(TriggerItem elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((TriggerItem)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent TriggerList that contains this collection
		/// </summary>
		public TriggerList ParentTriggerList
		{
			get { return this.ParentDataObject as TriggerList; }
			set { this.ParentDataObject = value; /* parent is set when contained by a TriggerList */ }
		}

		/// <summary>
		/// Search for trigger items and load the collection.
		/// </summary>
		public int Search(int maxRecords, TriggerItem searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchTriggerItems", maxRecords, this, searcher, false);
		}

		/// <summary>
		/// Load the trigger items that has the given code
		/// </summary>
		public int LoadTriggerItemsInCodeRange(string diagOrProc, string codeType, string code, DateTime currentDate, int triggerListId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetTriggerItemsInCodeRange", -1, this, false, 
				new object[] 
					{ 
						code, 
						currentDate, 
						triggerListId, 
						diagOrProc,
						codeType
					}
				);
		}
	}
}
