using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{/*
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PlanPayorTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllPlanPayorTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetPlanPayorTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertPlanPayorType")]
	[SPUpdate("usp_UpdatePlanPayorType")]
	[SPDelete("usp_DeletePlanPayorType")]
	[SPLoad("usp_LoadPlanPayorType")]
	[TableMapping("PlanPayorType","payorTypeId")]
	public class PlanPayorType : BaseLookup
	{
		[NonSerialized]
		private PlanPayorTypeCollection parentPlanPayorTypeCollection;
		[ColumnMapping("PayorTypeId",StereoType=DataStereoType.FK)]
		private int payorTypeId;

	
		public PlanPayorType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PlanPayorType(int payorTypeId, string description)
		{
			this.NewRecord(); // initialize record state
			this.payorTypeId = payorTypeId;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PayorTypeId
		{
			get { return this.payorTypeId; }
			set { this.payorTypeId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Parent PlanPayorTypeCollection that contains this element
		/// </summary>
		public PlanPayorTypeCollection ParentPlanPayorTypeCollection
		{
			get
			{
				return this.parentPlanPayorTypeCollection;
			}
			set
			{
				this.parentPlanPayorTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int payorTypeId)
		{
			return base.Load(payorTypeId);
		}
	}

	/// <summary>
	/// Strongly typed collection of PlanPayorType objects
	/// </summary>
	[ElementType(typeof(PlanPayorType))]
	public class PlanPayorTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PlanPayorType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPlanPayorTypeCollection = this;
			else
				elem.ParentPlanPayorTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PlanPayorType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PlanPayorType this[int index]
		{
			get
			{
				return (PlanPayorType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PlanPayorType)oldValue, false);
			SetParentOnElem((PlanPayorType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads the collection with active or inactive plan payor types
		/// </summary>
		public int LoadPlanPayorTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPlanPayorTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PlanPayorTypeCollection which is cached in NSGlobal
		/// </summary>
		public static PlanPayorTypeCollection ActivePlanPayorTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PlanPayorTypeCollection col = (PlanPayorTypeCollection)NSGlobal.EnsureCachedObject("ActivePlanPayorTypes", typeof(PlanPayorTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPlanPayorTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Loads all Plan Payor Types into collection.
		/// </summary>
		public override void LoadAll()
		{
			SqlData.SPExecReadCol("usp_GetAllPlanPayorTypes", -1, this, false);
		}

		/// <summary>
		///	 Searches for Plan Payor Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchPlanPayorTypes", -1, this, false, description, active);
		}
	}*/
}
