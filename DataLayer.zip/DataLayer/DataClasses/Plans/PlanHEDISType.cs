using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PlanHEDISTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllPlanHEDISTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetPlanHEDISTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertPlanHEDISType")]
	[SPUpdate("usp_UpdatePlanHEDISType")]
	[SPDelete("usp_DeletePlanHEDISType")]
	[SPLoad("usp_LoadPlanHEDISType")]
	[TableMapping("PlanHEDISType","hEDISTypeId")]
	public class PlanHEDISType : BaseLookupWithNote
	{
		[NonSerialized]
		private PlanHEDISTypeCollection parentPlanHEDISTypeCollection;

		[ColumnMapping("HEDISTypeId",StereoType=DataStereoType.FK)]
		private int hEDISTypeId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public PlanHEDISType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PlanHEDISType(int hEDISTypeId, string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.hEDISTypeId = hEDISTypeId;
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int HEDISTypeId
		{
			get { return this.hEDISTypeId; }
			set { this.hEDISTypeId = value; }
		}

		/// <summary>
		/// Parent PlanHEDISTypeCollection that contains this element
		/// </summary>
		public PlanHEDISTypeCollection ParentPlanHEDISTypeCollection
		{
			get
			{
				return this.parentPlanHEDISTypeCollection;
			}
			set
			{
				this.parentPlanHEDISTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int hEDISTypeId)
		{
			return base.Load(hEDISTypeId);
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of PlanHEDISType objects
	/// </summary>
	[ElementType(typeof(PlanHEDISType))]
	public class PlanHEDISTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_code;
		[NonSerialized]
		private CollectionIndexer indexBy_hEDISTypeId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PlanHEDISType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPlanHEDISTypeCollection = this;
			else
				elem.ParentPlanHEDISTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PlanHEDISType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PlanHEDISType this[int index]
		{
			get
			{
				return (PlanHEDISType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PlanHEDISType)oldValue, false);
			SetParentOnElem((PlanHEDISType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Load plan HEDIS types either active or inactive
		/// </summary>
		public int LoadPlanHEDISTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPlanHEDISTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PlanHEDISTypeCollection which is cached in NSGlobal
		/// </summary>
		public static PlanHEDISTypeCollection ActivePlanHEDISTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PlanHEDISTypeCollection col = (PlanHEDISTypeCollection)NSGlobal.EnsureCachedObject("ActivePlanHEDISTypes", typeof(PlanHEDISTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPlanHEDISTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on hEDISTypeId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_hEDISTypeId
		{
			get
			{
				if (this.indexBy_hEDISTypeId == null)
					this.indexBy_hEDISTypeId = new CollectionIndexer(this, new string[] { "hEDISTypeId" }, true);
				return this.indexBy_hEDISTypeId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on hEDISTypeId fields returns the object.  Uses the IndexBy_hEDISTypeId indexer.
		/// </summary>
		public PlanHEDISType FindBy(int hEDISTypeId)
		{
			return (PlanHEDISType)this.IndexBy_hEDISTypeId.GetObject(hEDISTypeId);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_code
		{
			get
			{
				if (this.indexBy_code == null)
					this.indexBy_code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_code;
			}
			
		}

		/// <summary>
		/// Hashtable based search on code fields returns the object.  Uses the IndexBy_code indexer.
		/// </summary>
		public PlanHEDISType FindBy(string code)
		{
			return (PlanHEDISType)this.IndexBy_code.GetObject(code);
		}

		/// <summary>
		///  Loads all Plan HEDIS Types into collection.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllPlanHEDISTypes", -1, this, false);
		}

		/// <summary>
		/// Searches for Plan HEDIS Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchPlanHEDISTypes", -1, this, false, code, description, active);
		}
		
	}
}
