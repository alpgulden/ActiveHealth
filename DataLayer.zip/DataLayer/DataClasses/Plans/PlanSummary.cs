using System;
using System.Diagnostics;
using System.Collections;
using NetsoftUSA.DataLayer;
using ActiveAdvice.Messages;

namespace ActiveAdvice.DataLayer
{
	[SPAutoGen("usp_GetPlans","SelectAll.sptpl","")]
	[TableMapping("Plan","planId")]
	public class PlanSummary : BaseData
	{
		[NonSerialized]
		private PlanSummaryCollection parentPlanSummaryCollection;
		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)]
		private int planId;
		[ColumnMapping("Name")]
		private string name;

		private bool selected;

		public PlanSummary()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45, IsRequired=true)]
		[FieldDescription("@NAME@")]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		[FieldDescription("@ASSIGNED@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool Selected
		{
			get { return this.selected;}
			set { this.selected = value;}
		}


		/// <summary>
		/// Parent PlanSummaryCollection that contains this element
		/// </summary>
		public PlanSummaryCollection ParentPlanSummaryCollection
		{
			get
			{
				return this.parentPlanSummaryCollection;
			}
			set
			{
				this.parentPlanSummaryCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Parent SecurityGroupPlanLevel that contains this object
		/// </summary>
		public SecurityGroupPlanLevel ParentSecurityGroupPlanLevel
		{
			get { return this.ParentDataObject as SecurityGroupPlanLevel; }
			set { this.ParentDataObject = value; /* parent is set when contained by a SecurityGroupPlanLevel */ }
		}
	}

	/// <summary>
	/// Strongly typed collection of PlanSummary objects
	/// </summary>
	[ElementType(typeof(PlanSummary))]
	public class PlanSummaryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PlanID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PlanSummary elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPlanSummaryCollection = this;
			else
				elem.ParentPlanSummaryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PlanSummary elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PlanSummary this[int index]
		{
			get
			{
				return (PlanSummary)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PlanSummary)oldValue, false);
			SetParentOnElem((PlanSummary)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}


		public void SetSelectedPlansFromCollection(SecurityGroupPlanLevelCollection plans)
		{
			if(plans.Count>0)
			{
				foreach (PlanSummary planSummary in this)
				{
					if (plans.FindBy(planSummary.PlanId) != null)
						planSummary.Selected= true;
				}
			}
		}

		/// <summary>
		/// Hashtable based index on PlanID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PlanID
		{
			get
			{
				if (this.indexBy_PlanID == null)
					this.indexBy_PlanID = new CollectionIndexer(this, new string[] { "PlanId" }, true);
				return this.indexBy_PlanID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on PlanID fields returns the object.  Uses the IndexBy_PlanID indexer.
		/// </summary>
		public PlanSummary FindBy(int PlanID)
		{
			return (PlanSummary)this.IndexBy_PlanID.GetObject(PlanID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetPlans(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPlans", maxRecords, this, false);
		}

	}
}