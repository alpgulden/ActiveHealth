using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ManagementServices]
	/// A Plan will have Management Services. A Management Service identifies the type 
	/// of services provided for the Plan. For example Utilization Review, Care Management, 
	/// Disease Management, Outpatient Procedure Review etc. 
	/// </summary>
	//[SPAutoGen("usp_GetEffectiveManagementServicesForDate","SelectActiveRecordsForDate.sptpl","effectiveDate, terminationDate")]
	[SPInsert("usp_InsertManagementService")]
	[SPUpdate("usp_UpdateManagementService")]
	[SPDelete("usp_DeleteManagementService")]
	[SPLoad("usp_LoadManagementService")]
	[TableMapping("ManagementService","managementServiceId")]
	public class ManagementService : BaseData
	{
		[NonSerialized]
		private ManagementServiceCollection parentManagementServiceCollection;
		[ColumnMapping("ManagementServiceId",StereoType=DataStereoType.FK)]
		private int managementServiceId;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

		private DateTime termDateWhenLoaded;
		private ManagementServiceItemCollection managementServiceItems;
	
		public ManagementService()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ManagementService(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ManagementServiceId
		{
			get { return this.managementServiceId; }
			set { this.managementServiceId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]		// defined in the base
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			//this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SaveManagementServiceItems(); // save the items in a seperate transaction
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int managementServiceId)
		{
			return base.Load(managementServiceId);
		}

		/// <summary>
		/// Parent ManagementServiceCollection that contains this element
		/// </summary>
		public ManagementServiceCollection ParentManagementServiceCollection
		{
			get
			{
				return this.parentManagementServiceCollection;
			}
			set
			{
				this.parentManagementServiceCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			
			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}

			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Child ManagementServiceItems mapped to related rows of table ManagementServiceItems where [ManagementServiceId] = [ManagementServiceId]
		/// </summary>
		[SPLoadChild("usp_LoadManagementServiceItems", "managementServiceId")]
		public ManagementServiceItemCollection ManagementServiceItems
		{
			get { return this.managementServiceItems; }
			set
			{
				this.managementServiceItems = value;
				value.ParentManagementService = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ManagementServiceItems collection
		/// </summary>
		public void LoadManagementServiceItems(bool forceReload)
		{
			this.managementServiceItems = (ManagementServiceItemCollection)ManagementServiceItemCollection.LoadChildCollection("ManagementServiceItems", this, typeof(ManagementServiceItemCollection), managementServiceItems, forceReload, null);
		}

		/// <summary>
		/// Saves the ManagementServiceItems collection
		/// </summary>
		public void SaveManagementServiceItems()
		{
			ManagementServiceItemCollection.SaveChildCollection(this.managementServiceItems, true);
		}

		/// <summary>
		/// Synchronizes the ManagementServiceItems collection
		/// </summary>
		public void SynchronizeManagementServiceItems()
		{
			ManagementServiceItemCollection.SynchronizeChildCollection(this.managementServiceItems, true);
		}

		/// <summary>
		/// Parent Plan that contains this object
		/// </summary>
		public Plan ParentPlan
		{
			get { return this.ParentDataObject as Plan; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Plan */ }
		}

	}

	/// <summary>
	/// Strongly typed collection of ManagementService objects
	/// </summary>
	[ElementType(typeof(ManagementService))]
	public class ManagementServiceCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ManagementService elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentManagementServiceCollection = this;
			else
				elem.ParentManagementServiceCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ManagementService elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ManagementService this[int index]
		{
			get
			{
				return (ManagementService)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ManagementService)oldValue, false);
			SetParentOnElem((ManagementService)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/*/// <summary>
		/// Accessor to a shared ManagementServiceCollection which is cached in NSGlobal
		/// </summary>
		public static ManagementServiceCollection EffectiveManagementServices
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ManagementServiceCollection col = (ManagementServiceCollection)NSGlobal.EnsureCachedObject("EffectiveManagementServices", typeof(ManagementServiceCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadEffectiveManagementServicesForDate(-1, DateTime.Today);
				}
				return col;
			}
			
		}*/

	}
}
