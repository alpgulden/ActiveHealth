using System;
using System.Diagnostics;
using System.Collections;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Plans]
	/// </summary>
	[SPAutoGen("usp_SearchPlans","SearchEffectiveRecordsForDate.sptpl","planId, name, alternatePlanId, planTypeId, hedisPlanTypeID", ManuallyManaged=true)]
	[SPInsert("usp_InsertPlan")]
	[SPUpdate("usp_UpdatePlan")]
	[SPDelete("usp_DeletePlan")]
	[SPLoad("usp_LoadPlan")]
	[TableMapping("Plan","planId")]
	public class Plan : BaseDataWithUserDefined, IContactOwner
	{
		[NonSerialized]
		protected PlanCollection parentPlanCollection;
		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)]
		protected int planId;
		[ColumnMapping("EffectiveDate")]
		protected DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		protected DateTime terminationDate;
		[ColumnMapping("AlternatePlanId")]
		protected string alternatePlanId;
		[ColumnMapping("PlanTypeId",StereoType=DataStereoType.FK)]
		protected int planTypeId;
		[ColumnMapping("Name")]
		protected string name;
		//[ColumnMapping("SearchTerm")]
		//protected string searchTerm;
		[ColumnMapping("ContractEffectiveDate")]
		protected DateTime contractEffectiveDate;
		[ColumnMapping("HedisPlanTypeID",StereoType=DataStereoType.FK)]
		protected int hedisPlanTypeID;
		//[ColumnMapping("PayorTypeId",StereoType=DataStereoType.FK)]
		//protected int payorTypeId;
		[ColumnMapping("TriggerListId",StereoType=DataStereoType.FK)]
		protected int triggerListId;
		[ColumnMapping("SpecialProcedureId",StereoType=DataStereoType.FK)]
		protected int specialProcedureId;
		[ColumnMapping("BenefitServiceId",StereoType=DataStereoType.FK)]
		protected int benefitServiceId;
		[ColumnMapping("ManagementServiceId",StereoType=DataStereoType.FK)]
		protected int managementServiceId;
		[ColumnMapping("LengthOfStayTrigger",StereoType=DataStereoType.FK)]
		protected int lengthOfStayTrigger;
		[ColumnMapping("OutlierTrigger",StereoType=DataStereoType.FK)]
		protected int outlierTrigger;
		[ColumnMapping("ReferralGoodFor")]
		protected int referralGoodFor;
		[ColumnMapping("ReviewPercent")]
		protected int reviewPercent;	// # days for which a referral is good.
		[ColumnMapping("URWhenOtherInsIsPrimary")]
		protected bool uRWhenOtherInsIsPrimary;
		[ColumnMapping("CMWhenOtherInsIsPrimary")]
		protected bool cMWhenOtherInsIsPrimary;
		[ColumnMapping("URWhenMedicareIsPrimary")]
		protected bool uRWhenMedicareIsPrimary;
		[ColumnMapping("CMWhenMedicareIsPrimary")]
		protected bool cMWhenMedicareIsPrimary;
		[ColumnMapping("EAPreferral")]
		protected bool eAPReferral;
		[ColumnMapping("NormalDeny")]
		protected bool normalDeny;
		[ColumnMapping("CallBeforeDeny")]
		protected bool callBeforeDeny;
		[ColumnMapping("CallBeforeLetter")]
		protected bool callBeforeLetter;
		[ColumnMapping("CallForLatePreCert")]
		protected bool callForLatePreCert;
		[ColumnMapping("PlanDenyNote")]
		protected string planDenyNote;
		[ColumnMapping("PreCertNotificationServicesRequired")]
		protected int preCertNotificationServicesRequired;
		[ColumnMapping("PreCertNotificationServicesRequiredUOM",StereoType=DataStereoType.FK)]
		protected int preCertNotificationServicesRequiredUOM;
		[ColumnMapping("PreCertPenalty")]
		protected string preCertPenalty;
		[ColumnMapping("MaternichekBeginDate")]
		protected DateTime maternichekBeginDate;
		[ColumnMapping("MaternichekRegistrationWeeks")]
		protected int maternichekRegistrationWeeks;
		[ColumnMapping("MaternichekIncentiveId",StereoType=DataStereoType.FK)]
		protected int maternichekIncentiveId;
		[ColumnMapping("MaternichekNote")]
		protected string maternichekNote;
		[ColumnMapping("InsurancePayorId",StereoType=DataStereoType.FK)]
		protected int insurancePayorId;
		[ColumnMapping("AddressID")]
		protected int addressID;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("TerminateTime")]
		protected DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		protected int terminatedBy;
		[ColumnMapping("HEDISPayorTypeID",StereoType=DataStereoType.FK)]
		protected int hEDISPayorTypeID;
		[ColumnMapping("AsOfDate")]
		protected DateTime asOfDate;
		
		protected DateTime termDateWhenLoaded;
		protected PlanNoteCollection planNotes;
		protected Address address;
		protected ManagementService managementService;
		protected PlanContactCollection planContacts;
		
		public Plan()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Plan(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public Plan(string name, int planTypeId, int hedisPlanTypeID, int hEDISPayorTypeID, int specialProcedureId, int benefitServiceId)
		{
			this.NewRecord(); // initialize record state
			this.name = name;
			this.planTypeId = planTypeId;
			this.hedisPlanTypeID = hedisPlanTypeID;
			//this.payorTypeId = payorTypeId;
			this.hEDISPayorTypeID = hEDISPayorTypeID;
			this.specialProcedureId = specialProcedureId;
			this.benefitServiceId = benefitServiceId;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@TERMDATE@")]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		[FieldDescription("@ALTERNATEID@")]
		public string AlternatePlanId
		{
			get { return this.alternatePlanId; }
			set { this.alternatePlanId = value; }
		}

		[FieldValuesMember("LookupOf_PlanTypeId", "PlanTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@TYPE@")]
		public int PlanTypeId
		{
			get { return this.planTypeId; }
			set { this.planTypeId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45, IsRequired=true)]
		[FieldDescription("@NAME@")]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		/*[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SearchTerm
		{
			get { return this.searchTerm; }
			set { this.searchTerm = value; }
		}*/

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@CONTRACTEFFDATE@")]
		public System.DateTime ContractEffectiveDate
		{
			get { return this.contractEffectiveDate; }
			set { this.contractEffectiveDate = value; }
		}

		/*[FieldValuesMember("LookupOf_PayorTypeId", "PayorTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int PayorTypeId
		{
			get { return this.payorTypeId; }
			set { this.payorTypeId = value; }
		}*/

		[FieldValuesMember("LookupOf_HedisPlanTypeID", "HEDISTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int HedisPlanTypeID
		{
			get { return this.hedisPlanTypeID; }
			set { this.hedisPlanTypeID = value; }
		}

		[FieldValuesMember("LookupOf_TriggerListId", "TriggerListId", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int TriggerListId
		{
			get { return this.triggerListId; }
			set { this.triggerListId = value; }
		}

		[FieldValuesMember("LookupOf_SpecialProcedureId", "SpecialProcedureId", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int SpecialProcedureId
		{
			get { return this.specialProcedureId; }
			set { this.specialProcedureId = value; }
		}

		[FieldValuesMember("LookupOf_BenefitServiceId", "BenefitServiceId", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int BenefitServiceId
		{
			get { return this.benefitServiceId; }
			set { this.benefitServiceId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ManagementServiceId
		{
			get { return this.managementServiceId; }
			set { this.managementServiceId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LengthOfStayTrigger
		{
			get { return this.lengthOfStayTrigger; }
			set { this.lengthOfStayTrigger = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int OutlierTrigger
		{
			get { return this.outlierTrigger; }
			set { this.outlierTrigger = value; }
		}

		/// <summary>
		/// # days for which a referral is good.
		/// </summary>
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralGoodFor
		{
			get { return this.referralGoodFor; }
			set { this.referralGoodFor = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool URWhenOtherInsIsPrimary
		{
			get { return this.uRWhenOtherInsIsPrimary; }
			set { this.uRWhenOtherInsIsPrimary = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool CMWhenOtherInsIsPrimary
		{
			get { return this.cMWhenOtherInsIsPrimary; }
			set { this.cMWhenOtherInsIsPrimary = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool URWhenMedicareIsPrimary
		{
			get { return this.uRWhenMedicareIsPrimary; }
			set { this.uRWhenMedicareIsPrimary = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool CMWhenMedicareIsPrimary
		{
			get { return this.cMWhenMedicareIsPrimary; }
			set { this.cMWhenMedicareIsPrimary = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool EAPReferral
		{
			get { return this.eAPReferral; }
			set { this.eAPReferral = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool NormalDeny
		{
			get { return this.normalDeny; }
			set { this.normalDeny = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool CallBeforeDeny
		{
			get { return this.callBeforeDeny; }
			set { this.callBeforeDeny = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool CallBeforeLetter
		{
			get { return this.callBeforeLetter; }
			set { this.callBeforeLetter = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool CallForLatePreCert
		{
			get { return this.callForLatePreCert; }
			set { this.callForLatePreCert = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		[FieldDescription("@NOTE@")]
		public string PlanDenyNote
		{
			get { return this.planDenyNote; }
			set { this.planDenyNote = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@NOTIFICATIONSVCSREQUIRED@")]
		public int PreCertNotificationServicesRequired
		{
			get { return this.preCertNotificationServicesRequired; }
			set { this.preCertNotificationServicesRequired = value; }
		}

		[FieldValuesMember("LookupOf_PreCertNotificationServicesRequiredUOM", "UnitOfMeasureId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int PreCertNotificationServicesRequiredUOM
		{
			get { return this.preCertNotificationServicesRequiredUOM; }
			set { this.preCertNotificationServicesRequiredUOM = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string PreCertPenalty
		{
			get { return this.preCertPenalty; }
			set { this.preCertPenalty = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@BEGIN@")]
		public System.DateTime MaternichekBeginDate
		{
			get { return this.maternichekBeginDate; }
			set { this.maternichekBeginDate = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@REGISTRATIONWEEKS@")]
		public int MaternichekRegistrationWeeks
		{
			get { return this.maternichekRegistrationWeeks; }
			set { this.maternichekRegistrationWeeks = value; }
		}

		[FieldValuesMember("LookupOf_MaternichekIncentiveId", "IncentiveId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescriptionAttribute("@INCENTIVE@")]
		public int MaternichekIncentiveId
		{
			get { return this.maternichekIncentiveId; }
			set { this.maternichekIncentiveId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=90)]
		[FieldDescription("@NOTE@")]
		public string MaternichekNote
		{
			get { return this.maternichekNote; }
			set { this.maternichekNote = value; }
		}

		[FieldValuesMember("LookupOf_InsurancePayorId", "InsurancePayorId", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int InsurancePayorId
		{
			get { return this.insurancePayorId; }
			set { this.insurancePayorId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch(Exception ex)
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				Debug.WriteLine(ex);
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int planId)
		{
			return base.Load(planId);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			this.contractEffectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.addressID = 0;
			this.managementServiceId = 0;
		}

		/// <summary>
		/// Parent PlanCollection that contains this element
		/// </summary>
		public PlanCollection ParentPlanCollection
		{
			get
			{
				return this.parentPlanCollection;
			}
			set
			{
				this.parentPlanCollection = value; // parent is set when added to a collection
			}
		}

		/*public PlanPayorTypeCollection LookupOf_PayorTypeId
		{
			get
			{
				return PlanPayorTypeCollection.ActivePlanPayorTypes; // Acquire a shared instance from the static member of collection
			}
		}*/

		public InsurancePayorCollection LookupOf_InsurancePayorId
		{
			get
			{
				return InsurancePayorCollection.EffectiveInsurancePayors; // Acquire a shared instance from the static member of collection
			}
		}

		public PlanMaternichekIncentiveCollection LookupOf_MaternichekIncentiveId
		{
			get
			{
				return PlanMaternichekIncentiveCollection.ActivePlanMaternichekIncentives; // Acquire a shared instance from the static member of collection
			}
		}

		public PlanTypeCollection LookupOf_PlanTypeId
		{
			get
			{
				return PlanTypeCollection.ActivePlanTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public PlanHEDISTypeCollection LookupOf_HedisPlanTypeID
		{
			get
			{
				return PlanHEDISTypeCollection.ActivePlanHEDISTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public PlanUnitOfMeasureCollection LookupOf_PreCertNotificationServicesRequiredUOM
		{
			get
			{
				return PlanUnitOfMeasureCollection.ActivePlanUnitOfMeasures; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to load child and other objects that must be loaded with this object.
		/// </summary>
		protected override bool InternalLoad(params object[] keys)
		{
			// Do pre-load operations here.
			bool result = base.InternalLoad(keys);
			// Do post-load operations here.
			return result;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			this.Address.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			this.ManagementService.SqlData.Transaction = this.SqlData.Transaction;
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			{
				base.InternalSave();	// in that case, delete the base first
				Address.MarkDel();	// then allow the deletion of the conatined object
				ManagementService.MarkDel();
			}

			Address.IsNew = this.IsNew;		// make sure the address is new if the containing object is new
			Address.Save();
			this.addressID = Address.AddressID; // set the fk if the contained object was newly created			
			//ManagementService.IsNew = this.IsNew;
			ManagementService.Save();
			this.managementServiceId = ManagementService.ManagementServiceId;

			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}

			base.InternalSave();
			// Save the child collections here.

			KeepPlanSorgLog();
		}

		/// <summary>
		/// Parent SecurityGroupOrganizationLevel that contains this object
		/// </summary>
		public SecurityGroupPlanLevel ParentSecurityGroupPlanLevel
		{
			get { return this.ParentDataObject as SecurityGroupPlanLevel; }
			set { this.ParentDataObject = value; /* parent is set when contained by a SecurityGroupPlanLevel */ }
		}

		/// <summary>
		/// This will check if a new record is needed into the Plan-Sorg-Log
		/// and will create a log entry if necessary.
		/// </summary>
		private void KeepPlanSorgLog()
		{
			/*PlanSORGLog planSorgLog = this.
			if (history.IsNew)
			{
				history.SqlData.Transaction = this.SqlData.Transaction;
				history.SubscriberCoverageID = this.subscriberCoverageId;
				history.Save();
			}
			else
			{
				// updating
				// save only if the history was changed
				SubscriberCoverageHistory latestInDB = this.GetLatestCoverageInHistory();
				if (latestInDB == null || !latestInDB.EqualsMappedMembers(history, false))
				{
					// there's a change, or there was no log entry in the db so far.
					history = (SubscriberCoverageHistory)history.Clone();
					history.SqlData.Transaction = this.SqlData.Transaction;
					history.Save();
				}
			}*/
		}

		/*/// <summary>
		/// Returns the latest PlanSorgLog entry.
		/// If this record is new, a new one is automatically created.
		/// </summary>
		public SubscriberCoverageHistory LatestCoverageInHistory
		{
			get
			{
				if (this.latestCoverageInHistory == null)
				{
					if (this.IsNew || this.IsNewlyInsertedInDB)
						this.latestCoverageInHistory = null;
					else
						this.latestCoverageInHistory = GetLatestCoverageInHistory();

					// if nothing was found, just create new history entry
					if (this.latestCoverageInHistory == null)
						this.latestCoverageInHistory = new SubscriberCoverageHistory(this);
				}

				return this.latestCoverageInHistory;
			}
		}

		/// <summary>
		/// Load the latest SubscriberCoverageHistory record for this SubscriberCoverage
		/// and return it.
		/// </summary>
		/// <returns></returns>
		public SubscriberCoverageHistory GetLatestCoverageInHistory()
		{
			SubscriberCoverageHistory latestCovInHis = new SubscriberCoverageHistory();
			if (latestCovInHis.LoadLatest(this.subscriberCoverageId))
				return latestCovInHis;
			else
				return null;
		}*/

		public SpecialProcedureCollection LookupOf_SpecialProcedureId
		{
			get
			{
				return SpecialProcedureCollection.EffectiveSpecialProcedures; // Acquire a shared instance from the static member of collection
			}
		}

		public BenefitServiceCollection LookupOf_BenefitServiceId
		{
			get
			{
				return BenefitServiceCollection.EffectiveBenefitServices; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Child PlanNotes mapped to related rows of table PlanNotes where [PlanId] = [PlanId]
		/// </summary>
		[SPLoadChild("usp_LoadPlanNotes", "planId")]
		public PlanNoteCollection PlanNotes
		{
			get { return this.planNotes; }
			set
			{
				this.planNotes = value;
				if (value != null)
					value.ParentPlan = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PlanNotes collection
		/// </summary>
		public void LoadPlanNotes(bool forceReload)
		{
			this.planNotes = (PlanNoteCollection)PlanNoteCollection.LoadChildCollection("PlanNotes", this, typeof(PlanNoteCollection), planNotes, forceReload, null);
		}

		/// <summary>
		/// Saves the PlanNotes collection
		/// </summary>
		public void SavePlanNotes()
		{
			PlanNoteCollection.SaveChildCollection(this.planNotes, true);
		}

		/// <summary>
		/// Synchronizes the PlanNotes collection
		/// </summary>
		public void SynchronizePlanNotes()
		{
			PlanNoteCollection.SynchronizeChildCollection(this.planNotes, true);
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}

		/// <summary>
		/// Contained Address object
		/// </summary>
		[Contained]
		public Address Address
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.address = (Address)Address.EnsureContainedDataObject(this, typeof(Address), address, false, addressID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.address;
			}
			set
			{
				this.address = value;
				if (value != null) value.ParentPlan = this; // set this as a parent of the child data class
			}
		}

		public TriggerListCollection LookupOf_TriggerListId
		{
			get
			{
				return TriggerListCollection.EffectiveTriggerLists; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Contained ManagementService object
		/// </summary>
		[Contained]
		public ManagementService ManagementService
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.managementService = (ManagementService)ManagementService.EnsureContainedDataObject(this, typeof(ManagementService), managementService, false, managementServiceId );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.managementService;
			}
			set
			{
				this.managementService = value;
				if (value != null) value.ParentPlan = this; // set this as a parent of the child data class
			}
		}

		/// <summary>
		/// Loads and returns the linked special procedure object from the database.
		/// This is not a contained object, but rather a reference to a linked object.
		/// Hence it's not saved along with the object.
		/// </summary>
		/// <returns></returns>
		public SpecialProcedure GetSpecialProcedure()
		{
			return this.LookupOf_SpecialProcedureId.FindBy(this.specialProcedureId);
			
			/*if (this.specialProcedureId == 0)
				return null;
			else
			{
				SpecialProcedure specialProcedure = new SpecialProcedure();
				if (specialProcedure.Load(this.specialProcedureId))
					return specialProcedure;
				else
					return null;
			}*/
		}

		/// <summary>
		/// Loads and returns the trigger list object from the database.
		/// This is not a contained object, but rather a reference to a linked object.
		/// Hence it's not saved along with the object.
		/// </summary>
		/// <returns></returns>
		public TriggerList GetTriggerList()
		{
			return this.LookupOf_TriggerListId.FindBy(this.triggerListId);
			/*if (this.triggerListId == 0)
				return null;
			else
			{
				TriggerList triggerList = new TriggerList();
				if (triggerList.Load(this.triggerListId))
					return triggerList;
				else
					return null;
			}*/
		}

		/// <summary>
		/// Loads and returns the linked benefit service object from the database.
		/// This is not a contained object, but rather a reference to a linked object.
		/// Hence it's not saved along with the object.
		/// </summary>
		/// <returns></returns>
		public BenefitService GetBenefitService()
		{
			return this.LookupOf_BenefitServiceId.FindBy(this.benefitServiceId);
			/*if (this.benefitServiceId == 0)
				return null;
			else
			{
				BenefitService benefitService = new BenefitService();
				if (benefitService.Load(this.benefitServiceId))
					return benefitService;
				else
					return null;
			}*/
		}

		/// <summary>
		/// Loads and returns the linked insurance payor object from the database.
		/// This is not a contained object, but rather a reference to a linked object.
		/// Hence it's not saved along with the object.
		/// </summary>
		/// <returns></returns>
		public InsurancePayor GetInsurancePayor()
		{
			return this.LookupOf_InsurancePayorId.FindBy(this.insurancePayorId);
			/*
			if (this.insurancePayorId == 0)
				return null;
			else
			{
				BenefitService benefitService = new BenefitService();
				if (benefitService.Load(this.benefitServiceId))
					return benefitService;
				else
					return null;
			}*/
		}

		/// <summary>
		/// Percentile after which concurrent review should occur.
		/// </summary>
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReviewPercent
		{
			get { return this.reviewPercent; }
			set { this.reviewPercent = value; }
		}

		[FieldValuesMember("LookupOf_HEDISPayorTypeID", "HEDISTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int HEDISPayorTypeID
		{
			get { return this.hEDISPayorTypeID; }
			set { this.hEDISPayorTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		public PlanPayorHEDISTypeCollection LookupOf_HEDISPayorTypeID
		{
			get
			{
				return PlanPayorHEDISTypeCollection.ActivePlanPayorHEDISTypes; // Acquire a shared instance from the static member of collection
			}
		}

		#region IContactOwner Members

		public BaseDataCollectionClass GetContacts()
		{
			if (PlanContacts == null) LoadPlanContacts(false);
			return PlanContacts;
		}

		public void LoadContacts(bool forceLoad)
		{
			this.LoadPlanContacts(forceLoad);
		}

		public void SaveContacts()
		{
			this.SavePlanContacts();
		}

		public ContactOwnerType ContactOwnerType
		{
			get
			{
				return ContactOwnerType.Plan;
			}
		}

		#endregion

		/// <summary>
		/// Child PlanContacts mapped to related rows of table PlanContacts where [PlanId] = [ContactID]
		/// </summary>
		[SPLoadChild("usp_LoadPlanContacts", "planID")]
		public PlanContactCollection PlanContacts
		{
			get { return this.planContacts; }
			set
			{
				this.planContacts = value;
				if (value != null)
					value.ParentPlan = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PlanContacts collection
		/// </summary>
		public void LoadPlanContacts(bool forceReload)
		{
			this.planContacts = (PlanContactCollection)PlanContactCollection.LoadChildCollection("PlanContacts", this, typeof(PlanContactCollection), planContacts, forceReload, null);
		}

		/// <summary>
		/// Saves the PlanContacts collection
		/// </summary>
		public void SavePlanContacts()
		{
			PlanContactCollection.SaveChildCollection(this.planContacts, true);
		}

		/// <summary>
		/// Synchronizes the PlanContacts collection
		/// </summary>
		public void SynchronizePlanContacts()
		{
			PlanContactCollection.SynchronizeChildCollection(this.planContacts, true);
		}


		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddHeaderLabelandValue("Plan", Name);
				//writer.AddFieldsOnNewLine(this, "EffectiveDate", "TerminationDate");
			}
		}


		/// <summary>
		/// Create a copy of this plan.
		/// Copied subcomponents are:
		///		Address, PlanNotes
		/// </summary>
		/// <returns></returns>
		public Plan CreateCopyOfPlan()
		{
			Plan plan = new Plan(true);
			this.CopyMappedMembersTo(plan, false, false, false);
			this.Address.CopyMappedMembersTo(plan.Address, false, false, false);

			// copy plan notes
			this.LoadPlanNotes(false);
			plan.LoadPlanNotes(false);
			this.PlanNotes.CopyElementsTo(plan.PlanNotes, false, true);		// deep copy, don't mark new

			// copy management service record 
			this.ManagementService.CopyMappedMembersTo(plan.ManagementService, false, false, false);

			// copy management service items
			this.ManagementService.LoadManagementServiceItems(false);
			plan.ManagementService.LoadManagementServiceItems(false);
			this.ManagementService.ManagementServiceItems.CopyElementsTo(plan.ManagementService.ManagementServiceItems, false, true);

			return plan;
		}

		/// <summary>
		/// Returns true if the plan has any management service items for the given service type
		/// on the given date.
		/// If the managementServiceTypeID is 0, all management service items of the plan are checked.
		/// </summary>
		public bool HasPlanActiveManagementServiceItems(int managementServiceTypeID, DateTime date)
		{
			return Convert.ToBoolean( SqlData.SPExecScalar("usp_HasPlanActiveManagementServiceItems", 
				new object[] 
				{ 
					planId, 
					SQLDataDirect.MakeDBValue( managementServiceTypeID, (int)0),
					date
				}));
		}

		public NetworkCollection GetLinkedNetworks()
		{
			NetworkCollection networks = new NetworkCollection();
			if (this.PlanId != 0)
			{
				networks.LoadAllNetworksByPlanID(this.PlanId);
			}
			return networks;
		}

	}

	/// <summary>
	/// Strongly typed collection of Plan objects
	/// </summary>
	[ElementType(typeof(Plan))]
	public class PlanCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		public const int MAXRECORDS = 20;		//  -1 = unlimited

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Plan elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPlanCollection = this;
			else
				elem.ParentPlanCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Plan elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Plan this[int index]
		{
			get
			{
				return (Plan)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Plan)oldValue, false);
			SetParentOnElem((Plan)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Search for plans starting from the given planID
		/// </summary>
		public int SearchPlans(int startPlanID, PlanSearcher planSearcher)
		{
			int maxRecords = MAXRECORDS;
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchPlans", -1, this, planSearcher, false,
				new string[] { "rowCount", "startPlanID" }, 
				new object[] { maxRecords, startPlanID } );
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(Plan elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((Plan)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Plan elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Plan)value, true);
			base.OnInsertComplete (index, value);		
		}
	
	}

	/// <summary>
	/// Searcher object used by search pages.
	/// </summary>
	public class PlanSearcher : Plan
	{
		protected bool effectiveOnly = false;
		protected ArrayList pageStartStack = new ArrayList();	// used to store page start values in paging.

		public PlanSearcher()
		{
			this.NewRecord();
			this.SetMembersNull(true, true);
		}

		public ArrayList PageStartStack
		{
			get { return this.pageStartStack; }
			set { this.pageStartStack = value;	}
		}

		public bool EffectiveOnly
		{
			get { return this.effectiveOnly; }
			set { this.effectiveOnly = value; }
		}
	}

}
