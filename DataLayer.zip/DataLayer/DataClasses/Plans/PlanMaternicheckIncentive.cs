using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PlanMaternichekIncentives]
	/// </summary>
	[SPAutoGen("usp_SearchPlanIncentives","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllPlanIncentives","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetPlanMaternichekIncentivesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertPlanMaternichekIncentive")]
	[SPUpdate("usp_UpdatePlanMaternichekIncentive")]
	[SPDelete("usp_DeletePlanMaternichekIncentive")]
	[SPLoad("usp_LoadPlanMaternichekIncentive")]
	[TableMapping("PlanMaternichekIncentive","incentiveId")]
	public class PlanMaternichekIncentive :	BaseLookupWithNote
	{
		[NonSerialized]
		private PlanMaternichekIncentiveCollection parentPlanMaternichekIncentiveCollection;
		[ColumnMapping("IncentiveId",StereoType=DataStereoType.FK)]
		private int incentiveId;
		[ColumnMapping("Notepad")]
		private string notepad;

		public PlanMaternichekIncentive()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PlanMaternichekIncentive(int incentiveId, string description)
		{
			this.NewRecord(); // initialize record state
			this.incentiveId = incentiveId;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int IncentiveId
		{
			get { return this.incentiveId; }
			set { this.incentiveId = value; }
		}

		/// <summary>
		/// Parent PlanMaternichekIncentiveCollection that contains this element
		/// </summary>
		public PlanMaternichekIncentiveCollection ParentPlanMaternichekIncentiveCollection
		{
			get
			{
				return this.parentPlanMaternichekIncentiveCollection;
			}
			set
			{
				this.parentPlanMaternichekIncentiveCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int incentiveId)
		{
			return base.Load(incentiveId);
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of PlanMaternichekIncentive objects
	/// </summary>
	[ElementType(typeof(PlanMaternichekIncentive))]
	public class PlanMaternichekIncentiveCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PlanMaternichekIncentive elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPlanMaternichekIncentiveCollection = this;
			else
				elem.ParentPlanMaternichekIncentiveCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PlanMaternichekIncentive elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PlanMaternichekIncentive this[int index]
		{
			get
			{
				return (PlanMaternichekIncentive)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PlanMaternichekIncentive)oldValue, false);
			SetParentOnElem((PlanMaternichekIncentive)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Searches for Plan Incentives matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchPlanIncentives", -1, this, false,code, description, active);
		}

		/// <summary>
		/// Loads the collection with the plan incentives either active or inactive
		/// </summary>
		public int LoadPlanMaternichekIncentivesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPlanMaternichekIncentivesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		///  Loads all Plan Incentives into collection.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllPlanIncentives", -1, this, false);
		}

		/// <summary>
		/// Accessor to a shared PlanMaternichekIncentiveCollection which is cached in NSGlobal
		/// </summary>
		public static PlanMaternichekIncentiveCollection ActivePlanMaternichekIncentives
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PlanMaternichekIncentiveCollection col = (PlanMaternichekIncentiveCollection)NSGlobal.EnsureCachedObject("ActivePlanMaternichekIncentives", typeof(PlanMaternichekIncentiveCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPlanMaternichekIncentivesByActive(-1, true);
				}
				return col;
			}
			
		}

	}
}
