using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [SpecialProcedureItems]
	/// </summary>
	[SPAutoGen("usp_GetSpecialProcedurItemsInCodeRange","SelectByArgsAndRange.sptpl","code:codeStart, codeStart, codeEnd, specialProcedureId, diagOrProc, codeType", InjectWhere="AND @currentDate >= EffectiveDate AND @currentDate <= TerminationDate", InjectParameters="@currentDate DateTime")]
	[SPInsert("usp_InsertSpecialProcedureItem")]
	[SPUpdate("usp_UpdateSpecialProcedureItem")]
	[SPDelete("usp_DeleteSpecialProcedureItem")]
	[SPLoad("usp_LoadSpecialProcedureItem")]
	[TableMapping("SpecialProcedureItem","specialProcedureItemId")]
	public class SpecialProcedureItem : BaseDataWithUserDefined
	{
		[NonSerialized]
		private SpecialProcedureItemCollection parentSpecialProcedureItemCollection;
		[ColumnMapping("SpecialProcedureItemId",StereoType=DataStereoType.FK)]
		private int specialProcedureItemId;
		[ColumnMapping("DiagOrProc")]
		private string diagOrProc;
		[ColumnMapping("CodeType")]
		private string codeType;
		[ColumnMapping("CodeStart")]
		private string codeStart;
		[ColumnMapping("CodeEnd")]
		private string codeEnd;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("SpecialProcedureId",StereoType=DataStereoType.FK)]
		private int specialProcedureId;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("InPatientReview")]
		private bool inPatientReview;
		[ColumnMapping("InPatientReviewOther")]
		private bool inPatientReviewOther;
		[ColumnMapping("OutPatientReview")]
		private bool outPatientReview;
		[ColumnMapping("OutPatientReviewOther")]
		private bool outPatientReviewOther;
		[ColumnMapping("Referral")]
		private bool referral;
	
		public SpecialProcedureItem()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public SpecialProcedureItem(string diagOrProc, string codeType, string codeStart, string codeEnd, string description)
		{
			this.NewRecord(); // initialize record state
			this.diagOrProc = diagOrProc;
			this.codeType = codeType;
			this.codeStart = codeStart;
			this.codeEnd = codeEnd;
			this.description = description;
		}

		public SpecialProcedureItem(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int SpecialProcedureItemId
		{
			get { return this.specialProcedureItemId; }
			set { this.specialProcedureItemId = value; }
		}

		[FieldValuesMember("ValuesOf_DiagOrProc")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, IsRequired=true)]
		public string DiagOrProc
		{
			get { return this.diagOrProc; }
			set { this.diagOrProc = value; }
		}

		[FieldValuesMember("ValuesOf_CodeType")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, IsRequired=true)]
		public string CodeType
		{
			get { return this.codeType; }
			set { this.codeType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=16, IsRequired=true)]
		public string CodeStart
		{
			get { return this.codeStart; }
			set { this.codeStart = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=16, IsRequired=true)]
		public string CodeEnd
		{
			get { return this.codeEnd; }
			set { this.codeEnd = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@ID@")]
		public int SpecialProcedureId
		{
			get { return this.specialProcedureId; }
			set { this.specialProcedureId = value; }
		}

		/// <summary>
		/// Parent SpecialProcedureItemCollection that contains this element
		/// </summary>
		public SpecialProcedureItemCollection ParentSpecialProcedureItemCollection
		{
			get
			{
				return this.parentSpecialProcedureItemCollection;
			}
			set
			{
				this.parentSpecialProcedureItemCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int specialProcedureItemId)
		{
			return base.Load(specialProcedureItemId);
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool InPatientReview
		{
			get { return this.inPatientReview; }
			set { this.inPatientReview = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool InPatientReviewOther
		{
			get { return this.inPatientReviewOther; }
			set { this.inPatientReviewOther = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool OutPatientReview
		{
			get { return this.outPatientReview; }
			set { this.outPatientReview = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool OutPatientReviewOther
		{
			get { return this.outPatientReviewOther; }
			set { this.outPatientReviewOther = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Referral
		{
			get { return this.referral; }
			set { this.referral = value; }
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFields(this, "Description");
			}
		}

		/// <summary>
		/// Create a copy of the special procedure item.
		/// </summary>
		/// <returns></returns>
		public SpecialProcedureItem CreateCopyOfSpecialProcedureItem()
		{
			return (SpecialProcedureItem)this.Clone(true);
		}
	}

	/// <summary>
	/// Strongly typed collection of SpecialProcedureItem objects
	/// </summary>
	[ElementType(typeof(SpecialProcedureItem))]
	public class SpecialProcedureItemCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(SpecialProcedureItem elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentSpecialProcedureItemCollection = this;
			else
				elem.ParentSpecialProcedureItemCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (SpecialProcedureItem elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public SpecialProcedureItem this[int index]
		{
			get
			{
				return (SpecialProcedureItem)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((SpecialProcedureItem)oldValue, false);
			SetParentOnElem((SpecialProcedureItem)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(SpecialProcedureItem elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((SpecialProcedureItem)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent SpecialProcedure that contains this collection
		/// </summary>
		public SpecialProcedure ParentSpecialProcedure
		{
			get { return this.ParentDataObject as SpecialProcedure; }
			set { this.ParentDataObject = value; /* parent is set when contained by a SpecialProcedure */ }
		}

		/// <summary>
		/// Load the special procedure items that has the given code
		/// </summary>
		public int LoadSpecialProcedurItemsInCodeRange(string diagOrProc, string codeType, string code, DateTime currentDate, int specialProcedureId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetSpecialProcedurItemsInCodeRange", -1, this, false, 
				new object[] 
					{ 
						code, 
						currentDate, 
						specialProcedureId, 
						diagOrProc, 
						codeType }
					);
		}
	}
}
