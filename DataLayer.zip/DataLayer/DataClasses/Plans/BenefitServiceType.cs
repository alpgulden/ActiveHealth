using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [BenefitServiceTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllBenefitServiceTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetBenefitServicesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertBenefitServiceType")]
	[SPUpdate("usp_UpdateBenefitServiceType")]
	[SPDelete("usp_DeleteBenefitServiceType")]
	[SPLoad("usp_LoadBenefitServiceType")]
	[TableMapping("BenefitServiceType","benefitServiceTypeId")]
	public class BenefitServiceType : BaseLookupWithNote
	{
		[NonSerialized]
		private BenefitServiceTypeCollection parentBenefitServiceTypeCollection;
		[ColumnMapping("BenefitServiceTypeId",StereoType=DataStereoType.FK)]
		private int benefitServiceTypeId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public BenefitServiceType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public BenefitServiceType(int benefitServiceTypeId, string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.benefitServiceTypeId = benefitServiceTypeId;
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int BenefitServiceTypeId
		{
			get { return this.benefitServiceTypeId; }
			set { this.benefitServiceTypeId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int benefitServiceTypeId)
		{
			return base.Load(benefitServiceTypeId);
		}

		/// <summary>
		/// Parent BenefitServiceTypeCollection that contains this element
		/// </summary>
		public BenefitServiceTypeCollection ParentBenefitServiceTypeCollection
		{
			get
			{
				return this.parentBenefitServiceTypeCollection;
			}
			set
			{
				this.parentBenefitServiceTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of BenefitServiceType objects
	/// </summary>
	[ElementType(typeof(BenefitServiceType))]
	public class BenefitServiceTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(BenefitServiceType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentBenefitServiceTypeCollection = this;
			else
				elem.ParentBenefitServiceTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (BenefitServiceType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public BenefitServiceType this[int index]
		{
			get
			{
				return (BenefitServiceType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((BenefitServiceType)oldValue, false);
			SetParentOnElem((BenefitServiceType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Load the collection with benefit service either active or inactive.
		/// </summary>
		public int LoadBenefitServicesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetBenefitServicesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared BenefitServiceTypeCollection which is cached in NSGlobal
		/// </summary>
		public static BenefitServiceTypeCollection ActiveBenefitServiceTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				BenefitServiceTypeCollection col = (BenefitServiceTypeCollection)NSGlobal.EnsureCachedObject("ActiveBenefitServiceTypes", typeof(BenefitServiceTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadBenefitServicesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Loads all Benefit Service Types into collection.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllBenefitServiceTypes", -1, this, false);
		}

		/// <summary>
		/// Searches for Benefit Service Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchBenefitServiceTypes", -1, this, false, code, description, active);
		}
	}
}
