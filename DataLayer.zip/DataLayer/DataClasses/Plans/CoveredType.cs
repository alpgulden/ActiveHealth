using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CoveredTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllCoveredTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetCoveredTypesByActive","CodeTableLoader.sptpl","active")]
	[SPInsert("usp_InsertCoveredType")]
	[SPUpdate("usp_UpdateCoveredType")]
	[SPDelete("usp_DeleteCoveredType")]
	[SPLoad("usp_LoadCoveredType")]
	[TableMapping("CoveredType","coveredTypeID")]
	public class CoveredType : BaseLookupWithNote
	{
		[NonSerialized]
		private CoveredTypeCollection parentCoveredTypeCollection;
		[ColumnMapping("CoveredTypeID",StereoType=DataStereoType.FK)]
		private int coveredTypeID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public CoveredType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public CoveredType(int coveredTypeID, string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.coveredTypeID = coveredTypeID;
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CoveredTypeID
		{
			get { return this.coveredTypeID; }
			set { this.coveredTypeID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int coveredTypeID)
		{
			return base.Load(coveredTypeID);
		}

		/// <summary>
		/// Parent CoveredTypeCollection that contains this element
		/// </summary>
		public CoveredTypeCollection ParentCoveredTypeCollection
		{
			get
			{
				return this.parentCoveredTypeCollection;
			}
			set
			{
				this.parentCoveredTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of CoveredType objects
	/// </summary>
	[ElementType(typeof(CoveredType))]
	public class CoveredTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CoveredType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCoveredTypeCollection = this;
			else
				elem.ParentCoveredTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CoveredType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CoveredType this[int index]
		{
			get
			{
				return (CoveredType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CoveredType)oldValue, false);
			SetParentOnElem((CoveredType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadCoveredTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetCoveredTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared CoveredTypeCollection which is cached in NSGlobal
		/// </summary>
		public static CoveredTypeCollection ActiveCoveredTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				CoveredTypeCollection col = (CoveredTypeCollection)NSGlobal.EnsureCachedObject("ActiveCoveredTypes", typeof(CoveredTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadCoveredTypesByActive(-1, true);
				}
				return col;
			}
		}

		/// <summary>
		///  Loads all CoveredTypes into collection.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllCoveredTypes", -1, this, false);
		}

		/// <summary>
		/// Searches for Covered Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchCoveredTypes", -1, this, false, code, description, active);
		}
	}
}
