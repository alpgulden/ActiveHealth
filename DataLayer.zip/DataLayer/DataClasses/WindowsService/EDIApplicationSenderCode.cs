using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EDIApplicationSenderCode]
	/// </summary>
	[SPAutoGen("usp_SelectAllEDIApplicationSenderCodesByActive","CodeTableLoader.sptpl","active")]
	[TableMapping("EDIApplicationSenderCode","eDIApplicationSenderCodeID")]
	public class EDIApplicationSenderCode : BaseDataClass
	{
		[NonSerialized]
		private EDIApplicationSenderCodeCollection parentEDIApplicationSenderCodeCollection;
		[ColumnMapping("EDIApplicationSenderCodeID",(int)0)]
		private int eDIApplicationSenderCodeID;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
	
		public EDIApplicationSenderCode()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EDIApplicationSenderCodeID
		{
			get { return this.eDIApplicationSenderCodeID; }
			set { this.eDIApplicationSenderCodeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Parent EDIApplicationSenderCodeCollection that contains this element
		/// </summary>
		public EDIApplicationSenderCodeCollection ParentEDIApplicationSenderCodeCollection
		{
			get
			{
				return this.parentEDIApplicationSenderCodeCollection;
			}
			set
			{
				this.parentEDIApplicationSenderCodeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of EDIApplicationSenderCode objects
	/// </summary>
	[ElementType(typeof(EDIApplicationSenderCode))]
	public class EDIApplicationSenderCodeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EDIApplicationSenderCode elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEDIApplicationSenderCodeCollection = this;
			else
				elem.ParentEDIApplicationSenderCodeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EDIApplicationSenderCode elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EDIApplicationSenderCode this[int index]
		{
			get
			{
				return (EDIApplicationSenderCode)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EDIApplicationSenderCode)oldValue, false);
			SetParentOnElem((EDIApplicationSenderCode)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SelectAllEDIApplicationSenderCodesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllEDIApplicationSenderCodesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Hashtable based search on code fields returns the object.  Uses the IndexBy_Code indexer.
		/// </summary>
		public EDIApplicationSenderCode FindBy(string code)
		{
			return (EDIApplicationSenderCode)this.IndexBy_Code.GetObject(code);
		}
	}
}
