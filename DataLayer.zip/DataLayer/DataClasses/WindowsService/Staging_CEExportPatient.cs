using System;
using System.Data.SqlClient;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Staging_CEExportPatient]
	/// </summary>
	[SPAutoGen("usp_SelectAllCCExportPatientByBatchNumber","SelectAllByGivenArgs.sptpl","batchNumber")]
	[TableMapping("Staging_CEExportPatient","cEExportPatientID")]
	public class Staging_CEExportPatient : BaseDataClass
	{
		#region column mappings
		[NonSerialized]
		private Staging_CEExportPatientCollection parentStaging_CEExportPatientCollection;
		[ColumnMapping("CEExportPatientID",(int)0)]
		private int cEExportPatientID;
		[ColumnMapping("BatchNumber")]
		private Guid batchNumber;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("alt_org_id")]
		private string altOrgId;
		[ColumnMapping("alt_pt_id")]
		private string altPtId;
		[ColumnMapping("cms_id",StereoType=DataStereoType.FK)]
		private int cmsId;
		[ColumnMapping("cms_status")]
		private string cmsStatus;
		[ColumnMapping("asmt_id",StereoType=DataStereoType.FK)]
		private int asmtId;
		[ColumnMapping("asmt_date")]
		private DateTime asmtDate;
		[ColumnMapping("question_id",StereoType=DataStereoType.FK)]
		private int questionId;
		[ColumnMapping("answer_id",StereoType=DataStereoType.FK)]
		private int answerId;
		[ColumnMapping("response_text")]
		private string responseText;
		[ColumnMapping("cc_ans_id")]
		private int ccAnsId;
		[ColumnMapping("cc_source")]
		private int ccSource;
		#endregion
	
		#region properties
		public Staging_CEExportPatient()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CEExportPatientID
		{
			get { return this.cEExportPatientID; }
			set { this.cEExportPatientID = value; }
		}

		public System.Guid BatchNumber
		{
			get { return this.batchNumber; }
			set { this.batchNumber = value; }
		}

		[ImportExportFieldPos(Start=61, End=70)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ImportExportFieldPos(Start=1, End=30)]
		public string AltOrgId
		{
			get { return this.altOrgId; }
			set { this.altOrgId = value; }
		}

		[ImportExportFieldPos(Start=31, End=60)]
		public string AltPtId
		{
			get { return this.altPtId; }
			set { this.altPtId = value; }
		}

		[ImportExportFieldPos(Start=61, End=82)]
		public int CmsId
		{
			get { return this.cmsId; }
			set { this.cmsId = value; }
		}

		[ImportExportFieldPos(Start=83, End=86)]
		public string CmsStatus
		{
			get { return this.cmsStatus; }
			set { this.cmsStatus = value; }
		}

		[ImportExportFieldPos(Start=87, End=108)]
		public int AsmtId
		{
			get { return this.asmtId; }
			set { this.asmtId = value; }
		}

		[ImportExportFieldPos(Start=109, End=118)]
		public System.DateTime AsmtDate
		{
			get { return this.asmtDate; }
			set { this.asmtDate = value; }
		}

		[ImportExportFieldPos(Start=119, End=140)]
		public int QuestionId
		{
			get { return this.questionId; }
			set { this.questionId = value; }
		}

		[ImportExportFieldPos(Start=141, End=162)]
		public int AnswerId
		{
			get { return this.answerId; }
			set { this.answerId = value; }
		}

		[ImportExportFieldPos(Start=163, End=363)]
		public string ResponseText
		{
			get { return this.responseText; }
			set { this.responseText = value; }
		}

		[ImportExportFieldPos(Start=364, End=366)]
		public int CcAnsId
		{
			get { return this.ccAnsId; }
			set { this.ccAnsId = value; }
		}

		[ImportExportFieldPos(Start=367, End=370)]
		public int CcSource
		{
			get { return this.ccSource; }
			set { this.ccSource = value; }
		}
		#endregion

		public Staging_CEExportPatient(ref SqlDataReader r)
		{
			// fill in the object from a DataReader
			this.AltOrgId		= (r["alt_org_id"]    == DBNull.Value ? null : Convert.ToString(r["alt_org_id"]) );
			this.AltPtId		= (r["alt_pt_id"]     == DBNull.Value ? null : Convert.ToString(r["alt_pt_id"]) );
			this.AnswerId		= (r["answer_id"]     == DBNull.Value ? 0    : Convert.ToInt32(r["answer_id"]) );
			this.AsmtDate		= (r["asmt_date"]     == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(r["asmt_date"]) );
			this.CcAnsId		= (r["cc_ans_id"]     == DBNull.Value ? 0    : Convert.ToInt32(r["cc_ans_id"]) );
			this.CcSource		= (r["cc_source"]     == DBNull.Value ? 0    : Convert.ToInt32(r["cc_source"]) );
			this.CmsId			= (r["cms_id"]        == DBNull.Value ? 0    : Convert.ToInt32(r["cms_id"]) );
			this.CmsStatus		= (r["cms_status"]    == DBNull.Value ? null : Convert.ToString(r["cms_status"]) );
			this.PatientID		= (r["PatientID"]     == DBNull.Value ? 0    : Convert.ToInt32(r["PatientID"]) );
			this.ResponseText	= (r["response_text"] == DBNull.Value ? null : Convert.ToString(r["response_text"]) );
			this.QuestionId		= (r["question_id"]   == DBNull.Value ? 0    : Convert.ToInt32(r["question_id"]) );
			this.AsmtId			= (r["asmt_id"]       == DBNull.Value ? 0    : Convert.ToInt32(r["asmt_id"]) );
		}

		/// <summary>
		/// Parent Staging_CEExportPatientCollection that contains this element
		/// </summary>
		public Staging_CEExportPatientCollection ParentStaging_CEExportPatientCollection
		{
			get
			{
				return this.parentStaging_CEExportPatientCollection;
			}
			set
			{
				this.parentStaging_CEExportPatientCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of Staging_CEExportPatient objects
	/// </summary>
	[ElementType(typeof(Staging_CEExportPatient))]
	public class Staging_CEExportPatientCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SelectAllCCExportPatientByBatchNumber(int maxRecords, System.Guid batchNumber)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllCCExportPatientByBatchNumber", maxRecords, this, false, new object[] { batchNumber });
		}

		/// <summary>
		/// SelectAllCCExportPatientByBatchNumberPatientID()
		/// This method will return all the patient information
		/// for the specified patient.
		/// </summary>
		/// <param name="maxRecords"></param>
		/// <param name="batchNumber"></param>
		/// <param name="patientID"></param>
		/// <returns></returns>
		public int SelectAllCCExportPatientByBatchNumberPatientID(int maxRecords, System.Guid batchNumber, int patientID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllCCExportPatientByBatchNumberPatientID", maxRecords, this, false, new object[] { batchNumber, patientID });
		}
	}
}
