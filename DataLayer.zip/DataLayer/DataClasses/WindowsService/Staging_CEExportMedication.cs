using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Staging_CEExportMedication]
	/// </summary>
	[SPAutoGen("usp_SelectAllCEExportMedicationByBatchNumber","SelectAllByGivenArgs.sptpl","batchNumber")]
	[TableMapping("Staging_CEExportMedication","cEExportMedicationID")]
	public class Staging_CEExportMedication : BaseDataClass
	{
		[NonSerialized]
		private Staging_CEExportMedicationCollection parentStaging_CEExportMedicationCollection;
		[ColumnMapping("CEExportMedicationID",(int)0)]
		private int cEExportMedicationID;
		[ColumnMapping("BatchNumber")]
		private Guid batchNumber;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("medicationid",StereoType=DataStereoType.FK)]
		private int medicationid;
		[ColumnMapping("ndc")]
		private string ndc;
		[ColumnMapping("status")]
		private string status;
		[ColumnMapping("status_reason")]
		private string statusReason;
		[ColumnMapping("noncompliant")]
		private bool noncompliant;
		[ColumnMapping("noncompreason")]
		private string noncompreason;
		[ColumnMapping("termed")]
		private bool termed;
	
		public Staging_CEExportMedication()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CEExportMedicationID
		{
			get { return this.cEExportMedicationID; }
			set { this.cEExportMedicationID = value; }
		}

		public System.Guid BatchNumber
		{
			get { return this.batchNumber; }
			set { this.batchNumber = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int Medicationid
		{
			get { return this.medicationid; }
			set { this.medicationid = value; }
		}

		[ImportExportFieldPos(Start=363, End=373)]
		[ControlType(EnumControlTypes.TextBox, MaxLength=11)]
		public string Ndc
		{
			get { return this.ndc; }
			set { this.ndc = value; }
		}

		[ImportExportFieldPos(Start=374, End=443)]
		[ControlType(EnumControlTypes.TextBox, MaxLength=70)]
		public string Status
		{
			get { return this.status; }
			set { this.status = value; }
		}

		[ImportExportFieldPos(Start=444, End=447)]
		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string StatusReason
		{
			get { return this.statusReason; }
			set { this.statusReason = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Noncompliant
		{
			get { return this.noncompliant; }
			set { this.noncompliant = value; }
		}

		[ImportExportFieldPos(Start=448, End=448)]
		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string IsNoncompliant
		{
			get { return (this.noncompliant ? "T" : "F"); }
		}

		[ImportExportFieldPos(Start=449, End=452)]
		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string Noncompreason
		{
			get { return this.noncompreason; }
			set { this.noncompreason = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Termed
		{
			get { return this.termed; }
			set { this.termed = value; }
		}

		[ImportExportFieldPos(Start=453, End=453)]
		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string IsTermed
		{
			get { return (this.termed ? "T" : "F"); }
		}

		/// <summary>
		/// Parent Staging_CEExportMedicationCollection that contains this element
		/// </summary>
		public Staging_CEExportMedicationCollection ParentStaging_CEExportMedicationCollection
		{
			get
			{
				return this.parentStaging_CEExportMedicationCollection;
			}
			set
			{
				this.parentStaging_CEExportMedicationCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of Staging_CEExportMedication objects
	/// </summary>
	[ElementType(typeof(Staging_CEExportMedication))]
	public class Staging_CEExportMedicationCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PatientID;

		/// <summary>
		/// Hashtable based index on patientID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PatientID
		{
			get
			{
				if (this.indexBy_PatientID == null)
					this.indexBy_PatientID = new CollectionIndexer(this, new string[] { "patientID" }, true);
				return this.indexBy_PatientID;
			}
			
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SelectAllCEExportMedicationByBatchNumber(int maxRecords, System.Guid batchNumber)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllCEExportMedicationByBatchNumber", maxRecords, this, false, new object[] { batchNumber });
		}

		/// <summary>
		/// SelectAllCEExportMedicationByBatchNumberPatientID()
		/// This method will return the medications for the specified
		/// patient.
		/// </summary>
		/// <param name="maxRecords"></param>
		/// <param name="batchNumber"></param>
		/// <param name="patientID"></param>
		/// <returns></returns>
		public int SelectAllCEExportMedicationByBatchNumberPatientID(int maxRecords, System.Guid batchNumber, int patientID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllCEExportMedicationByBatchNumberPatientID", maxRecords, this, false, new object[] { batchNumber, patientID });
		}
	}
}
