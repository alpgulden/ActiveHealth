using System;

using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ScheduleStatus]
	/// </summary>
	[SPAutoGen("usp_GetScheduleStatusByActive","CodeTableLoader.sptpl","active")]
	[SPLoad("usp_LoadScheduleStatus")]
	[TableMapping("ScheduleStatus","scheduleStatusID")]
	public class ScheduleStatus : BaseDataClass
	{
		[NonSerialized]
		private ScheduleStatusCollection parentScheduleStatusCollection;
		[ColumnMapping("ScheduleStatusID",(int)0)]
		private int scheduleStatusID;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("ReadOnly")]
		private bool readOnly;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public ScheduleStatus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ScheduleStatusID
		{
			get { return this.scheduleStatusID; }
			set { this.scheduleStatusID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReadOnly
		{
			get { return this.readOnly; }
			set { this.readOnly = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		/// <summary>
		/// Parent ScheduleStatusCollection that contains this element
		/// </summary>
		public ScheduleStatusCollection ParentScheduleStatusCollection
		{
			get
			{
				return this.parentScheduleStatusCollection;
			}
			set
			{
				this.parentScheduleStatusCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ScheduleStatus objects
	/// </summary>
	[ElementType(typeof(ScheduleStatus))]
	public class ScheduleStatusCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ScheduleStatus elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentScheduleStatusCollection = this;
			else
				elem.ParentScheduleStatusCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ScheduleStatus elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ScheduleStatus this[int index]
		{
			get
			{
				return (ScheduleStatus)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ScheduleStatus)oldValue, false);
			SetParentOnElem((ScheduleStatus)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadScheduleStatusByActive(int maxRecords, bool active)
		{
			return SqlData.SPExecReadCol("usp_GetScheduleStatusByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Hashtable based search on code fields returns the object.  Uses the IndexBy_Code indexer.
		/// </summary>
		/// <param name="code">input string of the "code" value I'm looking for</param>
		public ScheduleStatus FindBy(string code)
		{
			return (ScheduleStatus)this.IndexBy_Code.GetObject(code);
		}
	}
}
