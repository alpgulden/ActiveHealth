using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EDILogDetail]
	/// </summary>
//	[SPAutoGen("usp_GetAllWithCompletedAuthorizations","SelectAll.sptpl","")]
	[SPInsert("usp_InsertEDILogDetail")]
	[SPUpdate("usp_UpdateEDILogDetail")]
	[SPLoad("usp_LoadEDILogDetail")]
	[TableMapping("EDILogDetail","eDILogDetailID")]
	public class EDILogDetail : BaseDataClass
	{
		[NonSerialized]
		private EDILogDetailCollection parentEDILogDetailCollection;
		[ColumnMapping("EDILogDetailID",(int)0)]
		private int eDILogDetailID;
		[ColumnMapping("EDILogID",StereoType=DataStereoType.FK)]
		private int eDILogID;
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		private int referralID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("RequestISAIDType")]
		private string requestISAIDType;
		[ColumnMapping("RequestISAID")]
		private string requestISAID;
		[ColumnMapping("RequestGSCode")]
		private string requestGSCode;
		[ColumnMapping("RequestEntityIDCode")]
		private string requestEntityIDCode;
		[ColumnMapping("RequestEntityType")]
		private string requestEntityType;
		[ColumnMapping("RequestLastName")]
		private string requestLastName;
		[ColumnMapping("RequestFirstName")]
		private string requestFirstName;
		[ColumnMapping("RequestMiddleInitial")]
		private string requestMiddleInitial;
		[ColumnMapping("RequestSuffix")]
		private string requestSuffix;
		[ColumnMapping("Request_NM1_IDType")]
		private string requestNm1Idtype;
		[ColumnMapping("Request_NM1_ID")]
		private string requestNm1Id;
		[ColumnMapping("Request_ReferenceID")]
		private string requestReferenceid;
		[ColumnMapping("Request_ReferenceIDType")]
		private string requestReferenceidtype;
		[ColumnMapping("Request_ProviderCode")]
		private string requestProvidercode;
		[ColumnMapping("Request_ProviderSpecialty")]
		private string requestProviderspecialty;
		[ColumnMapping("BHT_TransactionID")]
		private string bhtTransactionid;
		[ColumnMapping("AcceptanceDate")]
		private DateTime acceptanceDate;
		[ColumnMapping("LastMenstrualDate")]
		private DateTime lastMenstrualDate;
		[ColumnMapping("EstimatedDOBdate")]
		private DateTime estimatedDOBdate;
		[ColumnMapping("OnSetDate")]
		private DateTime onSetDate;
		[ColumnMapping("SubscriberAccount")]
		private string subscriberAccount;
		[ColumnMapping("PatientAccount")]
		private string patientAccount;
		[ColumnMapping("ProviderContactName")]
		private string providerContactName;
		[ColumnMapping("ProviderContactType_1")]
		private string providercontacttype1;
		[ColumnMapping("ProviderContactPhone_1")]
		private string providercontactphone1;
		[ColumnMapping("ProviderContactType_2")]
		private string providercontacttype2;
		[ColumnMapping("ProviderContactPhone_2")]
		private string providercontactphone2;
		[ColumnMapping("ProviderContactType_3")]
		private string providercontacttype3;
		[ColumnMapping("ProviderContactPhone_3")]
		private string providercontactphone3;
		[ColumnMapping("ProviderRole")]
		private string providerRole;
		[ColumnMapping("Transaction1_Number")]
		private string transaction1Number;
		[ColumnMapping("Transaction1_ID")]
		private string transaction1Id;
		[ColumnMapping("Transaction1_AdditionalID")]
		private string transaction1Additionalid;
		[ColumnMapping("Transaction2_Number")]
		private string transaction2Number;
		[ColumnMapping("Transaction2_ID")]
		private string transaction2Id;
		[ColumnMapping("Transaction2_AdditionalID")]
		private string transaction2Additionalid;
		[ColumnMapping("RequestCertNumber",StereoType=DataStereoType.FK)]
		private int requestCertNumber;
		[ColumnMapping("EDIControlID",StereoType=DataStereoType.FK)]
		private int eDIControlID;
	
		public EDILogDetail()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EDILogDetailID
		{
			get { return this.eDILogDetailID; }
			set { this.eDILogDetailID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EDILogID
		{
			get { return this.eDILogID; }
			set { this.eDILogID = value; }
		}

		[FieldDescription("Referral that was generated from this MA EDI")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[FieldDescription("Event that was generated from this MA EDI")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string RequestISAIDType
		{
			get { return this.requestISAIDType; }
			set { this.requestISAIDType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string RequestISAID
		{
			get { return this.requestISAID; }
			set { this.requestISAID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string RequestGSCode
		{
			get { return this.requestGSCode; }
			set { this.requestGSCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string RequestEntityIDCode
		{
			get { return this.requestEntityIDCode; }
			set { this.requestEntityIDCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string RequestEntityType
		{
			get { return this.requestEntityType; }
			set { this.requestEntityType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string RequestLastName
		{
			get { return this.requestLastName; }
			set { this.requestLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string RequestFirstName
		{
			get { return this.requestFirstName; }
			set { this.requestFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string RequestMiddleInitial
		{
			get { return this.requestMiddleInitial; }
			set { this.requestMiddleInitial = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string RequestSuffix
		{
			get { return this.requestSuffix; }
			set { this.requestSuffix = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string RequestNm1Idtype
		{
			get { return this.requestNm1Idtype; }
			set { this.requestNm1Idtype = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string RequestNm1Id
		{
			get { return this.requestNm1Id; }
			set { this.requestNm1Id = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string RequestReferenceid
		{
			get { return this.requestReferenceid; }
			set { this.requestReferenceid = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string RequestReferenceidtype
		{
			get { return this.requestReferenceidtype; }
			set { this.requestReferenceidtype = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string RequestProvidercode
		{
			get { return this.requestProvidercode; }
			set { this.requestProvidercode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=8)]
		public string RequestProviderspecialty
		{
			get { return this.requestProviderspecialty; }
			set { this.requestProviderspecialty = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string BhtTransactionid
		{
			get { return this.bhtTransactionid; }
			set { this.bhtTransactionid = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AcceptanceDate
		{
			get { return this.acceptanceDate; }
			set { this.acceptanceDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime LastMenstrualDate
		{
			get { return this.lastMenstrualDate; }
			set { this.lastMenstrualDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EstimatedDOBdate
		{
			get { return this.estimatedDOBdate; }
			set { this.estimatedDOBdate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime OnSetDate
		{
			get { return this.onSetDate; }
			set { this.onSetDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string SubscriberAccount
		{
			get { return this.subscriberAccount; }
			set { this.subscriberAccount = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string PatientAccount
		{
			get { return this.patientAccount; }
			set { this.patientAccount = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string ProviderContactName
		{
			get { return this.providerContactName; }
			set { this.providerContactName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string Providercontacttype1
		{
			get { return this.providercontacttype1; }
			set { this.providercontacttype1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Providercontactphone1
		{
			get { return this.providercontactphone1; }
			set { this.providercontactphone1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string Providercontacttype2
		{
			get { return this.providercontacttype2; }
			set { this.providercontacttype2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Providercontactphone2
		{
			get { return this.providercontactphone2; }
			set { this.providercontactphone2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string Providercontacttype3
		{
			get { return this.providercontacttype3; }
			set { this.providercontacttype3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Providercontactphone3
		{
			get { return this.providercontactphone3; }
			set { this.providercontactphone3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string ProviderRole
		{
			get { return this.providerRole; }
			set { this.providerRole = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Transaction1Number
		{
			get { return this.transaction1Number; }
			set { this.transaction1Number = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Transaction1Id
		{
			get { return this.transaction1Id; }
			set { this.transaction1Id = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Transaction1Additionalid
		{
			get { return this.transaction1Additionalid; }
			set { this.transaction1Additionalid = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Transaction2Number
		{
			get { return this.transaction2Number; }
			set { this.transaction2Number = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Transaction2Id
		{
			get { return this.transaction2Id; }
			set { this.transaction2Id = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Transaction2Additionalid
		{
			get { return this.transaction2Additionalid; }
			set { this.transaction2Additionalid = value; }
		}

		/// <summary>
		/// Parent EDILogDetailCollection that contains this element
		/// </summary>
		public EDILogDetailCollection ParentEDILogDetailCollection
		{
			get
			{
				return this.parentEDILogDetailCollection;
			}
			set
			{
				this.parentEDILogDetailCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RequestCertNumber
		{
			get { return this.requestCertNumber; }
			set { this.requestCertNumber = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EDIControlID
		{
			get { return this.eDIControlID; }
			set { this.eDIControlID = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of EDILogDetail objects
	/// </summary>
	[ElementType(typeof(EDILogDetail))]
	public class EDILogDetailCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EDILogDetail elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEDILogDetailCollection = this;
			else
				elem.ParentEDILogDetailCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EDILogDetail elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EDILogDetail this[int index]
		{
			get
			{
				return (EDILogDetail)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EDILogDetail)oldValue, false);
			SetParentOnElem((EDILogDetail)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllWithCompletedAuthorizations(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllWithCompletedAuthorizations", maxRecords, this, false);
		}
	}
}
