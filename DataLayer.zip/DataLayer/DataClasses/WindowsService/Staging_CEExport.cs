using System;
using System.Data.SqlClient;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Staging_CEExport]
	/// </summary>
	[SPLoad("usp_LoadStaging_CEExport")]
	[SPAutoGen("usp_LoadCareEngineExportByBatchNumber","SelectAllByGivenArgs.sptpl","batchNumber")]
	[TableMapping("Staging_CEExport","cEExportID")]
	public class Staging_CEExport : BaseDataClass
	{
		[NonSerialized]
		private Staging_CEExportCollection parentStaging_CEExportCollection;

		#region column mapping
		[ColumnMapping("CEExportID",(int)0)]
		private int cEExportID;
		[ColumnMapping("BatchNumber")]
		private Guid batchNumber;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("alt_org_id")]
		private string altOrgId;
		[ColumnMapping("alt_pt_id")]
		private string altPtId;
		[ColumnMapping("cms_id",StereoType=DataStereoType.FK)]
		private int cmsId;
		[ColumnMapping("cms_status")]
		private string cmsStatus;
		[ColumnMapping("asmt_id",StereoType=DataStereoType.FK)]
		private int asmtId;
		[ColumnMapping("asmt_date")]
		private DateTime asmtDate;
		[ColumnMapping("question_id",StereoType=DataStereoType.FK)]
		private int questionId;
		[ColumnMapping("answer_id",StereoType=DataStereoType.FK)]
		private int answerId;
		[ColumnMapping("response_text")]
		private string responseText;
		[ColumnMapping("cc_ans_id")]
		private int ccAnsId;
		[ColumnMapping("cc_source")]
		private int ccSource;
		#endregion

		public Staging_CEExport()
		{
		}

		public Staging_CEExport(ref SqlDataReader r)
		{
			this.BatchNumber	= new Guid(Convert.ToString(r["batchnumber"]) );
			this.cEExportID		= Convert.ToInt32(r["CEExportID"]);
			this.patientID		= Convert.ToInt32(r["PatientID"]);
			this.AltOrgId		= (r["alt_org_id"]    == DBNull.Value ? null : Convert.ToString(r["alt_org_id"]) );
			this.AltPtId		= (r["alt_pt_id"]     == DBNull.Value ? null : Convert.ToString(r["alt_pt_id"])  );
			this.CmsId			= (r["cms_id"]        == DBNull.Value ? 0    : Convert.ToInt32(r["cms_id"]) );
			this.CmsStatus		= (r["cms_status"]    == DBNull.Value ? null : Convert.ToString(r["cms_status"]) );
			this.AsmtId			= (r["asmt_id"]       == DBNull.Value ? 0    : Convert.ToInt32(r["asmt_id"]) );
			this.AsmtDate		= (r["asmt_date"]     == DBNull.Value ? DateTime.MinValue    : Convert.ToDateTime(r["asmt_date"]) );
			this.questionId		= (r["question_id"]   == DBNull.Value ? 0    : Convert.ToInt32(r["question_id"]) );
			this.answerId		= (r["answer_id"]     == DBNull.Value ? 0    : Convert.ToInt32(r["answer_id"]) );
			this.ResponseText	= (r["response_text"] == DBNull.Value ? null : Convert.ToString(r["response_text"]) );
			this.ccAnsId		= (r["cc_ans_id"]     == DBNull.Value ? 0    : Convert.ToInt32(r["cc_ans_id"]) );
			this.ccSource		= (r["cc_source"]     == DBNull.Value ? 0    : Convert.ToInt32(r["cc_source"]));
		}

		#region properties
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CEExportID
		{
			get { return this.cEExportID; }
			set { this.cEExportID = value; }
		}

		public System.Guid BatchNumber
		{
			get { return this.batchNumber; }
			set { this.batchNumber = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ImportExportFieldPos(Start=1, End=30)]
		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AltOrgId
		{
			get { return this.altOrgId; }
			set { this.altOrgId = value; }
		}

		[ImportExportFieldPos(Start=31, End=60)]
		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AltPtId
		{
			get { return this.altPtId; }
			set { this.altPtId = value; }
		}

		[ImportExportFieldPos(Start=61, End=82)]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CmsId
		{
			get { return this.cmsId; }
			set { this.cmsId = value; }
		}

		[ImportExportFieldPos(Start=83, End=86)]
		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string CmsStatus
		{
			get { return this.cmsStatus; }
			set { this.cmsStatus = value; }
		}

		[ImportExportFieldPos(Start=87, End=108)]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AsmtId
		{
			get { return this.asmtId; }
			set { this.asmtId = value; }
		}

		[ImportExportFieldPos(Start=109, End=118)]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsmtDate
		{
			get { return this.asmtDate; }
			set { this.asmtDate = value; }
		}

		[ImportExportFieldPos(Start=119, End=140)]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int QuestionId
		{
			get { return this.questionId; }
			set { this.questionId = value; }
		}

		[ImportExportFieldPos(Start=141, End=162)]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AnswerId
		{
			get { return this.answerId; }
			set { this.answerId = value; }
		}

		[ImportExportFieldPos(Start=163, End=362)]
		[ControlType(EnumControlTypes.TextBox, MaxLength=200)]
		public string ResponseText
		{
			get { return this.responseText; }
			set { this.responseText = value; }
		}

		[ImportExportFieldPos(Start=363, End=365)]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CcAnsId
		{
			get { return this.ccAnsId; }
			set { this.ccAnsId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CcSource
		{
			get { return this.ccSource; }
			set { this.ccSource = value; }
		}

		[ImportExportFieldPos(Start=366, End=369)]
		public string ccSourceId
		{
			get
			{
				switch (this.ccSource)
				{
					case 1:
						return "D";
					case 2:
						return "N";
					case 3:
						return "P";
					default:
						return "";
				}
			}
		}

		#endregion

		/// <summary>
		/// Parent Staging_CEExportCollection that contains this element
		/// </summary>
		public Staging_CEExportCollection ParentStaging_CEExportCollection
		{
			get
			{
				return this.parentStaging_CEExportCollection;
			}
			set
			{
				this.parentStaging_CEExportCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of Staging_CEExport objects
	/// </summary>
	[ElementType(typeof(Staging_CEExport))]
	public class Staging_CEExportCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PatientID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Staging_CEExport elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentStaging_CEExportCollection = this;
			else
				elem.ParentStaging_CEExportCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Staging_CEExport elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Staging_CEExport this[int index]
		{
			get
			{
				return (Staging_CEExport)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Staging_CEExport)oldValue, false);
			SetParentOnElem((Staging_CEExport)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadCareEngineExportByBatchNumber(int maxRecords, System.Guid batchNumber)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadCareEngineExportByBatchNumber", maxRecords, this, false, new object[] { batchNumber });
		}

		/// <summary>
		/// Hashtable based index on patientID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PatientID
		{
			get
			{
				if (this.indexBy_PatientID == null)
					this.indexBy_PatientID = new CollectionIndexer(this, new string[] { "patientID" }, true);
				return this.indexBy_PatientID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on patientID fields returns the object.  Uses the IndexBy_PatientID indexer.
		/// </summary>
		public Staging_CEExport FindBy(int patientID)
		{
			return (Staging_CEExport)this.IndexBy_PatientID.GetObject(patientID);
		}
	}// end of class
	
	[TableMapping(null)]
	public class CEExportArgs : CEExportArguments
	{
		public CEExportArgs()
		{
		}

		public CEExportArgs(string sTask, string errorpath)
		{
			this.task			= sTask;
			this.ParseTask();
			this.errorlogpath	= errorpath;
		}

		#region variables
		private int morglevelid = 0;
		private int orglevelid = 0;
		private int sorglevelid = 0;
		private string organizationPath = null;
		#endregion

		#region properties
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int OrganizationID
		{
			get {return organizationid; }
			set 
			{
				organizationid = value;
			}
		}
		[ControlType(EnumControlTypes.TextBox)]
		public string OrganizationPath
		{
			get { return this.organizationPath; }
			set { this.organizationPath = value; }
		}
		
		public int MORGLevelID
		{
			get { return morglevelid; }
			set { morglevelid = value; }
		}

		public int ORGLevelID
		{
			get { return orglevelid; }
			set { orglevelid = value; }
		}
		public int SORGLevelID
		{
			get { return sorglevelid; }
			set { sorglevelid = value; }
		}
		#endregion

	}// end of class

	/// <summary>
	/// ImportExportImportExportFieldPos
	/// a custom attribute class so we can attach
	/// the start/end field positions to our properties
	/// to simplify the building of the output strings
	/// </summary>
	[AttributeUsage(AttributeTargets.Property)]
	public class ImportExportFieldPos : Attribute
	{
		public int Start;
		public int End;
		public string NullString; // value that is null
	}

}
