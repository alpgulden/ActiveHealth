using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Staging_AuthorizationNote]
	/// </summary>
	[SPAutoGen("usp_LoadAuthorizationNoteByBatchNumber","SelectAllByGivenArgs.sptpl","batchNumber")]
	[TableMapping("Staging_AuthorizationNote", "NoteID")]
	public class Staging_AuthorizationNote : BaseDataClass
	{
		[NonSerialized]
		private Staging_AuthorizationNoteCollection parentStaging_AuthorizationNoteCollection;
	
		
		#region column mapping
		[ColumnMapping("BatchNumber")]
		private Guid batchNumber;
		[ColumnMapping("AuthorizationID",StereoType=DataStereoType.FK)]
		private int authorizationID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		private int referralID;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("AppendDate")]
		private DateTime appendDate;
		[ColumnMapping("MedicalNoteBrief")]
		private string medicalNoteBrief;
		[ColumnMapping("NoteID",StereoType=DataStereoType.FK)]
		private int noteID;
		#endregion

		public Staging_AuthorizationNote()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region properties
		public System.Guid BatchNumber
		{
			get { return this.batchNumber; }
			set { this.batchNumber = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AuthorizationID
		{
			get { return this.authorizationID; }
			set { this.authorizationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AppendDate
		{
			get { return this.appendDate; }
			set { this.appendDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=128)]
		public string MedicalNoteBrief
		{
			get { return this.medicalNoteBrief; }
			set { this.medicalNoteBrief = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int NoteID
		{
			get { return this.noteID; }
			set { this.noteID = value; }
		}
		#endregion

		public string GenerateFormattedOutput(ref int count)
		{
			string x12 = "";
			Note note = new Note();
			note.Load(this.NoteID);
			try
			{
				string message = null;
				if (note.NotePage.IsRTF)
				{
					System.Windows.Forms.RichTextBox rtb = new System.Windows.Forms.RichTextBox();
					rtb.Rtf = note.NotePage.NoteText;
					message = rtb.Text;
				}
				else
					message = note.NotePage.NoteText;

				x12 += ExportAuthorization.FormatRecord("MSG*{0}{1}", new object[] {createTime, medicalNoteBrief}, ref count);
				x12 += ExportAuthorization.FormatRecord("MSG*{0}{1}", new object[] {createTime, message.Substring(0,256)}, ref count);
				if (message.Length > 256)
					x12 += ExportAuthorization.FormatRecord("MSG*{0}{1}", new object[] {createTime, message.Substring(256,256)}, ref count);
				return x12;
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				return null;
			}
		}

		/// <summary>
		/// Parent Staging_AuthorizationNoteCollection that contains this element
		/// </summary>
		public Staging_AuthorizationNoteCollection ParentStaging_AuthorizationNoteCollection
		{
			get
			{
				return this.parentStaging_AuthorizationNoteCollection;
			}
			set
			{
				this.parentStaging_AuthorizationNoteCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of Staging_AuthorizationNote objects
	/// </summary>
	[ElementType(typeof(Staging_AuthorizationNote))]
	public class Staging_AuthorizationNoteCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Staging_AuthorizationNote elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentStaging_AuthorizationNoteCollection = this;
			else
				elem.ParentStaging_AuthorizationNoteCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Staging_AuthorizationNote elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Staging_AuthorizationNote this[int index]
		{
			get
			{
				return (Staging_AuthorizationNote)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Staging_AuthorizationNote)oldValue, false);
			SetParentOnElem((Staging_AuthorizationNote)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAuthorizationNoteByBatchNumber(int maxRecords, System.Guid batchNumber)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadAuthorizationNoteByBatchNumber", maxRecords, this, false, new object[] { batchNumber });
		}
	}// end of clas
}
