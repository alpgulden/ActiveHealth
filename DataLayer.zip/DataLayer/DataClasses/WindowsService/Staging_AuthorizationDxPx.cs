using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Staging_AuthorizationDxPx]
	/// </summary>
	[SPAutoGen("usp_LoadAuthorizationCodesByBatchNumber","SelectAllByGivenArgs.sptpl","batchNumber")]
	[TableMapping("Staging_AuthorizationDxPx","authorizationDxPxID")]
	public class Staging_AuthorizationDxPx : BaseDataClass
	{
		[NonSerialized]
		private Staging_AuthorizationDxPxCollection parentStaging_AuthorizationDxPxCollection;
		[ColumnMapping("BatchNumber")]
		private Guid batchNumber;

		#region column mapping
		[ColumnMapping("AuthorizationDxPxID",(int)0)]
		private int authorizationDxPxID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		private int referralID;
		[ColumnMapping("IsDiagnostic")]
		private bool isDiagnostic;
		[ColumnMapping("SequenceID",StereoType=DataStereoType.FK)]
		private int sequenceID;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("CreateDate")]
		private DateTime createDate;
		[ColumnMapping("Type")]
		private string type;
		[ColumnMapping("ScheduledDate")]
		private DateTime scheduledDate;
		[ColumnMapping("Modifier1")]
		private string modifier1;
		[ColumnMapping("Modifier2")]
		private string modifier2;
		[ColumnMapping("Modifier3")]
		private string modifier3;
		[ColumnMapping("LinkedPxType")]
		private string linkedPxType;
		[ColumnMapping("LinkedPxCode")]
		private string linkedPxCode;
		[ColumnMapping("DSM4axis",StereoType=DataStereoType.FK)]
		private int dSM4axis;
		#endregion
	
		public Staging_AuthorizationDxPx()
		{
		}

		#region properties
		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string Description
		{
			get { return (description == null ? null : this.description.TrimEnd(' ') ); }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ScheduledDate
		{
			get { return this.scheduledDate; }
			set { this.scheduledDate = value; }
		}
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int AuthorizationDxPxID
		{
			get { return this.authorizationDxPxID; }
			set { this.authorizationDxPxID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IsDiagnostic
		{
			get { return this.isDiagnostic; }
			set { this.isDiagnostic = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SequenceID
		{
			get { return this.sequenceID; }
			set { this.sequenceID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=7)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateDate
		{
			get { return this.createDate; }
			set { this.createDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string Type
		{
			get { return this.type; }
			set { this.type = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string Modifier1
		{
			get { return this.modifier1; }
			set { this.modifier1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string Modifier2
		{
			get { return this.modifier2; }
			set { this.modifier2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string Modifier3
		{
			get { return this.modifier3; }
			set { this.modifier3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string LinkedPxType
		{
			get { return this.linkedPxType; }
			set { this.linkedPxType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string LinkedPxCode
		{
			get { return this.linkedPxCode; }
			set { this.linkedPxCode = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DSM4axis
		{
			get { return this.dSM4axis; }
			set { this.dSM4axis = value; }
		}

		#endregion

		public string GenerateFormattedOutput(ref int count)
		{
			string x12out = "";
			if (IsDiagnostic)
				x12out += X12diagnosis(ref count);
			else
				x12out += X12procedure(ref count);

			return x12out;
		}

//		protected string ExportAuthorization.FormatRecord(string format, object[] args)
//		{
//			string[] newargs = new string[args.Length];
//			bool isnull = true;
//			for(int i = 0; i < args.Length; i++)
//			{
//				if (args[i] == null)
//					newargs[i] = "";
//				else
//				{
//					Type t = args[i].GetType();
//					if (t == typeof(System.Boolean))
//					{
//						bool x = Convert.ToBoolean(args[i]);
//						newargs[i] = (x ? "Y" : "N");
//					}
//					else if (t == typeof(System.Int32) )
//					{
//						int x = Convert.ToInt32(args[i]);
//						if (x == 0)
//							newargs[i] = "";
//						else
//						{
//							newargs[i] = x.ToString();
//							isnull = false;
//						}
//					}
//					else if (t == typeof(System.DateTime) )
//					{
//						DateTime x = Convert.ToDateTime(args[i]);
//						if (x.Year == 1)
//							newargs[i] = "";
//						else
//						{
//							newargs[i] = x.ToString("yyyyddMM");
//							isnull = false;
//						}
//					}
//					else if (t == typeof(System.String) )
//					{
//						newargs[i] = args[i].ToString();
//						if (newargs[i] != "")
//							isnull = false;
//					}
//				}
//			}// end of for
//
//			if (isnull)
//				return null; // empty string
//
//			string x12 = string.Format(format, newargs) + "\r\n";
//
//			return x12;
//		}// end of method

		protected string X12diagnosis(ref int count)
		{
			string x12out = "";
			switch(SequenceID)
			{
				case 1:
					x12out += ExportAuthorization.FormatRecord("HI*DD>{0}>D8>{1}>>>{2}*{3}", new object[] {Code, CreateDate, Description, Type}, ref count);
					break;
				case 2:
					x12out += ExportAuthorization.FormatRecord("HI*SD>{0}>D8>{1}>>>{2}*{3}", new object[] {Code, CreateDate, Description, Type}, ref count);
					break;
				case 3:
					x12out += ExportAuthorization.FormatRecord("HI*TD>{0}>D8>{1}>>>{2}*{3}", new object[] {Code, CreateDate, Description, Type}, ref count);
					break;
				default:
					x12out += ExportAuthorization.FormatRecord("HI*BF>{0}>D8>{1}>>>{2}*{3}", new object[] {Code, CreateDate, Description, Type}, ref count);
					break;
			}
			if (Type == "ICD9")
				x12out += ExportAuthorization.FormatRecord("HI*BQ*{0}>D8>{1}>>{2}",       new object[] {Code, ScheduledDate, Description}, ref count);
			else if (Type == "HCPCS")
				x12out += ExportAuthorization.FormatRecord("HI*BO*{0}>D8>{1}>>{2}",       new object[] {Code, ScheduledDate, Description}, ref count);
			else if (Type == "DSM4")
				x12out += ExportAuthorization.FormatRecord("HI*E*{0}>D8>{1}>>{2}",        new object[] {Code, ScheduledDate, Description}, ref count);
			else if (Type == "CPT")
				x12out += ExportAuthorization.FormatRecord("HI*BS*{0}>D8>{1}>>{2}",       new object[] {Code, ScheduledDate, Description}, ref count);

			x12out += ExportAuthorization.FormatRecord("SV1*{0}>{1}>{2}>{3}>{4}",  new object[] {Type, LinkedPxType, Description, Modifier1, Modifier2, Modifier3}, ref count);
			x12out += ExportAuthorization.FormatRecord("SV2**{0}>{1}>{2}>{3}>{4}", new object[] {LinkedPxType, Description, Modifier1, Modifier2, Modifier3}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*ORG*D8*{0}",           new object[] {this.CreateDate}, ref count);
			return x12out;
		}

		protected string X12procedure(ref int count)
		{
			string x12out = "";

			switch(SequenceID)
			{
				case 1:
					x12out += ExportAuthorization.FormatRecord("HI*DD>{0}>D8>{1}>>>{2}*{3}", new object[] {Code, CreateDate, Description, Type}, ref count);
					break;
				case 2:
					x12out += ExportAuthorization.FormatRecord("HI*SD>{0}>D8>{1}>>>{2}*{3}", new object[] {Code, CreateDate, Description, Type}, ref count);
					break;
				case 3:
					x12out += ExportAuthorization.FormatRecord("HI*TD>{0}>D8>{1}>>>{2}*{3}", new object[] {Code, CreateDate, Description, Type}, ref count);
					break;
				default:
					x12out += ExportAuthorization.FormatRecord("HI*BF>{0}>D8>{1}>>>{2}*{3}", new object[] {Code, CreateDate, Description, Type}, ref count);
					break;
			}
			if (Type == "ICD9")
				x12out += ExportAuthorization.FormatRecord("HI*BQ*{0}>D8>{1}>>{2}",       new object[] {Code, ScheduledDate, Description}, ref count);
			else if (Type == "HCPCS")
				x12out += ExportAuthorization.FormatRecord("HI*BO*{0}>D8>{1}>>{2}",       new object[] {Code, ScheduledDate, Description}, ref count);
			else if (Type == "DSM4")
				x12out += ExportAuthorization.FormatRecord("HI*E*{0}>D8>{1}>>{2}",        new object[] {Code, ScheduledDate, Description}, ref count);
			else if (Type == "CPT")
				x12out += ExportAuthorization.FormatRecord("HI*BS*{0}>D8>{1}>>{2}",       new object[] {Code, ScheduledDate, Description}, ref count);

			x12out += ExportAuthorization.FormatRecord("SV1*{0}>{1}>{2}>{3}>{4}",     new object[] {Type, LinkedPxType, Description, Modifier1, Modifier2, Modifier3}, ref count);
			x12out += ExportAuthorization.FormatRecord("SV2**{0}>{1}>{2}>{3}>{4}",    new object[] {LinkedPxType, Description, Modifier1, Modifier2, Modifier3}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*ORG*D8*{0}",              new object[] {CreateDate}, ref count);

			return x12out;
		}

		public System.Guid BatchNumber
		{
			get { return this.batchNumber; }
			set { this.batchNumber = value; }
		}

		/// <summary>
		/// Parent Staging_AuthorizationDxPxCollection that contains this element
		/// </summary>
		public Staging_AuthorizationDxPxCollection ParentStaging_AuthorizationDxPxCollection
		{
			get
			{
				return this.parentStaging_AuthorizationDxPxCollection;
			}
			set
			{
				this.parentStaging_AuthorizationDxPxCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}


	}

	/// <summary>
	/// Strongly typed collection of Staging_AuthorizationDxPx objects
	/// </summary>
	[ElementType(typeof(Staging_AuthorizationDxPx))]
	public class Staging_AuthorizationDxPxCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAuthorizationCodesByBatchNumber(int maxRecords, System.Guid batchNumber)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadAuthorizationCodesByBatchNumber", maxRecords, this, false, new object[] { batchNumber });
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Staging_AuthorizationDxPx elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentStaging_AuthorizationDxPxCollection = this;
			else
				elem.ParentStaging_AuthorizationDxPxCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Staging_AuthorizationDxPx elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Staging_AuthorizationDxPx this[int index]
		{
			get
			{
				return (Staging_AuthorizationDxPx)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Staging_AuthorizationDxPx)oldValue, false);
			SetParentOnElem((Staging_AuthorizationDxPx)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}// end of class
}// end of namespace
