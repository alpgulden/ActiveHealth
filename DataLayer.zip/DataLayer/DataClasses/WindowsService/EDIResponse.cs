using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EDIResponse]
	/// </summary>
	[SPInsert("usp_InsertEDIResponse")]
	[SPUpdate("usp_UpdateEDIResponse")]
	[SPAutoGen("usp_SelectAllEDIResponsesByEDILogDetail","SelectAllByGivenArgs.sptpl","eDILogDetailID")]
	[SPLoad("usp_LoadEDIResponse")]
	[TableMapping("EDIResponse","eDIResponseID")]
	public class EDIResponse : BaseDataClass
	{
		[ColumnMapping("EDIResponseID",(int)0)]
		private int eDIResponseID;
		[ColumnMapping("EDILogDetailID",StereoType=DataStereoType.FK)]
		private int eDILogDetailID;
		[ColumnMapping("ResponseDate")]
		private DateTime responseDate;
		[ColumnMapping("ResponseData")]
		private string responseData;
	
		public EDIResponse()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EDIResponseID
		{
			get { return this.eDIResponseID; }
			set { this.eDIResponseID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EDILogDetailID
		{
			get { return this.eDILogDetailID; }
			set { this.eDILogDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ResponseDate
		{
			get { return this.responseDate; }
			set { this.responseDate = value; }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool SelectAllEDIResponsesByEDILogDetail(int eDILogDetailID)
		{
			return SqlData.SPExecReadObj("usp_SelectAllEDIResponsesByEDILogDetail", this, false, new object[] { eDILogDetailID });
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2147483647)]
		public string ResponseData
		{
			get { return this.responseData; }
			set { this.responseData = value; }
		}

	}
}
