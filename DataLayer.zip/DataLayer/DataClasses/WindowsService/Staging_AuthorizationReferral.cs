using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Staging_AuthorizationReferral]
	/// </summary>
	[SPAutoGen("usp_LoadAuthorizationReferralsByBatch","SelectAllByGivenArgs.sptpl","batchNumber")]
	[TableMapping("Staging_AuthorizationReferral", "AuthorizationID")]
	public class Staging_AuthorizationReferral : BaseDataClass
	{
		[NonSerialized]
		private Staging_AuthorizationReferralCollection parentStaging_AuthorizationReferralCollection;
		#region column mappings
		[ColumnMapping("unit_qty",StereoType=DataStereoType.FK)]
		private int unitQty;
		[ColumnMapping("ref_auth_decision")]
		private string refAuthDecision;
		[ColumnMapping("ref_auth_decision_description")]
		private string refAuthDecisionDescription;
		[ColumnMapping("BatchNumber")]
		private Guid batchNumber;
		[ColumnMapping("AuthorizationID",StereoType=DataStereoType.FK)]
		private int authorizationID;
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		private int referralID;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("admitting_dx_code")]
		private string admittingDxCode;
		[ColumnMapping("admitting_dx_type")]
		private string admittingDxType;
		[ColumnMapping("ref_create_id",StereoType=DataStereoType.FK)]
		private int refCreateId;
		[ColumnMapping("ref_mod_id",StereoType=DataStereoType.FK)]
		private int refModId;
		[ColumnMapping("ref_unit")]
		private string refUnit;
		[ColumnMapping("ref_unit_desc")]
		private string refUnitDesc;
		[ColumnMapping("ref_type")]
		private string refType;
		[ColumnMapping("ref_type_desc")]
		private string refTypeDesc;
		[ColumnMapping("ref_urgency")]
		private string refUrgency;
		[ColumnMapping("ref_urgency_desc")]
		private string refUrgencyDesc;
		[ColumnMapping("ref_status")]
		private string refStatus;
		[ColumnMapping("ref_status_desc")]
		private string refStatusDesc;
		[ColumnMapping("ref_status_code")]
		private string refStatusCode;
		[ColumnMapping("status_id",StereoType=DataStereoType.FK)]
		private int statusId;
		[ColumnMapping("unit_unlimited")]
		private bool unitUnlimited;
		[ColumnMapping("ref_cust_1")]
		private string refCust1;
		[ColumnMapping("ref_cust_2")]
		private string refCust2;
		[ColumnMapping("ref_cust_3")]
		private string refCust3;
		[ColumnMapping("ref_cust_4")]
		private string refCust4;
		[ColumnMapping("ref_cust_5")]
		private string refCust5;
		[ColumnMapping("ref_cust_6")]
		private string refCust6;
		[ColumnMapping("ref_cust_7")]
		private string refCust7;
		[ColumnMapping("ref_cust_8")]
		private string refCust8;
		[ColumnMapping("ref_cust_9")]
		private string refCust9;
		[ColumnMapping("ref_cust_10")]
		private string refCust10;
		[ColumnMapping("ref_cust_11")]
		private string refCust11;
		[ColumnMapping("ref_cust_12")]
		private string refCust12;
		[ColumnMapping("ref_cust_13")]
		private string refCust13;
		[ColumnMapping("ref_cust_14")]
		private string refCust14;
		[ColumnMapping("ot_plan_desc")]
		private string otPlanDesc;
		[ColumnMapping("related_event",StereoType=DataStereoType.FK)]
		private int relatedEvent;
		[ColumnMapping("related_pt",StereoType=DataStereoType.FK)]
		private int relatedPt;
		[ColumnMapping("related_problem",StereoType=DataStereoType.FK)]
		private int relatedProblem;
		[ColumnMapping("elig_id",StereoType=DataStereoType.FK)]
		private int eligId;
		[ColumnMapping("elig_status")]
		private bool eligStatus;
		[ColumnMapping("ref_detail_mod_id",StereoType=DataStereoType.FK)]
		private int refDetailModId;
		[ColumnMapping("physician_review",StereoType=DataStereoType.FK)]
		private int physicianReview;
		[ColumnMapping("primary_problem_id",StereoType=DataStereoType.FK)]
		private int primaryProblemId;
		[ColumnMapping("alt_referral_id")]
		private string altReferralId;
		[ColumnMapping("valid_from")]
		private DateTime validFrom;
		[ColumnMapping("valid_to")]
		private DateTime validTo;
		[ColumnMapping("status_date")]
		private DateTime statusDate;
		[ColumnMapping("elig_eff_date")]
		private DateTime eligEffDate;
		[ColumnMapping("ref_detail_date")]
		private DateTime refDetailDate;
		[ColumnMapping("ref_detail_mod_date")]
		private DateTime refDetailModDate;
		[ColumnMapping("report_date_received")]
		private DateTime reportDateReceived;
		[ColumnMapping("ref_create_date")]
		private DateTime refCreateDate;
		[ColumnMapping("ref_mod_date")]
		private DateTime refModDate;
		#endregion

		#region properties
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int UnitQty
		{
			get { return this.unitQty; }
			set { this.unitQty = value; }
		}
		public Staging_AuthorizationReferral()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public System.Guid BatchNumber
		{
			get { return this.batchNumber; }
			set { this.batchNumber = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AuthorizationID
		{
			get { return this.authorizationID; }
			set { this.authorizationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string AdmittingDxCode
		{
			get { return this.admittingDxCode; }
			set { this.admittingDxCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string AdmittingDxType
		{
			get { return this.admittingDxType; }
			set { this.admittingDxType = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RefCreateId
		{
			get { return this.refCreateId; }
			set { this.refCreateId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RefModId
		{
			get { return this.refModId; }
			set { this.refModId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string RefUnit
		{
			get { return this.refUnit; }
			set { this.refUnit = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefUnitDesc
		{
			get { return this.refUnitDesc; }
			set { this.refUnitDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string RefType
		{
			get { return this.refType; }
			set { this.refType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefTypeDesc
		{
			get { return this.refTypeDesc; }
			set { this.refTypeDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string RefUrgency
		{
			get { return this.refUrgency; }
			set { this.refUrgency = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefUrgencyDesc
		{
			get { return this.refUrgencyDesc; }
			set { this.refUrgencyDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string RefStatus
		{
			get { return this.refStatus; }
			set { this.refStatus = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefStatusDesc
		{
			get { return this.refStatusDesc; }
			set { this.refStatusDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string RefStatusCode
		{
			get { return this.refStatusCode; }
			set { this.refStatusCode = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int StatusId
		{
			get { return this.statusId; }
			set { this.statusId = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool UnitUnlimited
		{
			get { return this.unitUnlimited; }
			set { this.unitUnlimited = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust1
		{
			get { return this.refCust1; }
			set { this.refCust1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust2
		{
			get { return this.refCust2; }
			set { this.refCust2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust3
		{
			get { return this.refCust3; }
			set { this.refCust3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust4
		{
			get { return this.refCust4; }
			set { this.refCust4 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust5
		{
			get { return this.refCust5; }
			set { this.refCust5 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust6
		{
			get { return this.refCust6; }
			set { this.refCust6 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust7
		{
			get { return this.refCust7; }
			set { this.refCust7 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust8
		{
			get { return this.refCust8; }
			set { this.refCust8 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust9
		{
			get { return this.refCust9; }
			set { this.refCust9 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust10
		{
			get { return this.refCust10; }
			set { this.refCust10 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust11
		{
			get { return this.refCust11; }
			set { this.refCust11 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust12
		{
			get { return this.refCust12; }
			set { this.refCust12 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust13
		{
			get { return this.refCust13; }
			set { this.refCust13 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefCust14
		{
			get { return this.refCust14; }
			set { this.refCust14 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string OtPlanDesc
		{
			get { return this.otPlanDesc; }
			set { this.otPlanDesc = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RelatedEvent
		{
			get { return this.relatedEvent; }
			set { this.relatedEvent = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RelatedPt
		{
			get { return this.relatedPt; }
			set { this.relatedPt = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RelatedProblem
		{
			get { return this.relatedProblem; }
			set { this.relatedProblem = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EligId
		{
			get { return this.eligId; }
			set { this.eligId = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool EligStatus
		{
			get { return this.eligStatus; }
			set { this.eligStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RefDetailModId
		{
			get { return this.refDetailModId; }
			set { this.refDetailModId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PhysicianReview
		{
			get { return this.physicianReview; }
			set { this.physicianReview = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PrimaryProblemId
		{
			get { return this.primaryProblemId; }
			set { this.primaryProblemId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AltReferralId
		{
			get { return this.altReferralId; }
			set { this.altReferralId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ValidFrom
		{
			get { return this.validFrom; }
			set { this.validFrom = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ValidTo
		{
			get { return this.validTo; }
			set { this.validTo = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StatusDate
		{
			get { return this.statusDate; }
			set { this.statusDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EligEffDate
		{
			get { return this.eligEffDate; }
			set { this.eligEffDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime RefDetailDate
		{
			get { return this.refDetailDate; }
			set { this.refDetailDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime RefDetailModDate
		{
			get { return this.refDetailModDate; }
			set { this.refDetailModDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ReportDateReceived
		{
			get { return this.reportDateReceived; }
			set { this.reportDateReceived = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime RefCreateDate
		{
			get { return this.refCreateDate; }
			set { this.refCreateDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime RefModDate
		{
			get { return this.refModDate; }
			set { this.refModDate = value; }
		}
		#endregion

		public string GenerateFormattedOutput(ref int count, int heirarchialID, int parentheirarchialID)
		{
			string x12 = "";
			x12 += this.x12services(ref count, heirarchialID, parentheirarchialID);
			return x12;
		}

		public string x12Units(ref int count)
		{
			string x12out = null;
			x12out = ExportAuthorization.FormatRecord("AMT*NT*{0}", new object[] {unitQty}, ref count);
			return x12out;
		}
		/// <summary>
		/// GenerateHeader()
		/// method creates the Event Header the comes before the information
		/// common to events & referrals
		/// </summary>
		/// <returns></returns>
		public string GenerateHeader(ref int count, ref int heirarchialID, ref int parentheirarchialID)
		{
			string x12out;
			x12out = this.X12header(ref count, heirarchialID, parentheirarchialID);
			heirarchialID++; parentheirarchialID++;
			return x12out;
		}
		protected string X12header(ref int count, int heirarchialID, int parentheirarchialID)
		{
			string x12out = "";
			x12out += ExportAuthorization.FormatRecord("HL*{0}*{1}*{2}*1", new object[] {heirarchialID, parentheirarchialID,22}, ref count);
			x12out += ExportAuthorization.FormatRecord("TRN*1*{0}**{1}", new object[] {ReferralID, AltReferralId}, ref count);
			return x12out;
		}

		protected string x12services(ref int count, int heirarchialID, int parentheirarchialID)
		{
			string x12 = "";

			x12 += ExportAuthorization.FormatRecord("HL*{0}*{1}*{2}*{0}",  new object[] {heirarchialID, parentheirarchialID, "SS", 1}, ref count);
			x12 += ExportAuthorization.FormatRecord("TRN*2*{0}**{1}", new object[] {refCreateId, refModId}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QQ*{0}*{1}", new object[] {refUnit, refUnitDesc}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*XY*{0}*{1}", new object[] {refType, refTypeDesc}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*E1*{0}*{1}", new object[] {refUrgency, refUrgencyDesc}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*K0*{0}*{1}", new object[] {refAuthDecision, refAuthDecisionDescription}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*1P*{0}*{1}", new object[] {refStatus, refStatusDesc}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*94*{0}*{1}", new object[] {refStatusCode, statusId}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*YH*{0}",     new object[] {unitUnlimited}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R1*{0}",  new object[] {refCust1}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R2*{0}",  new object[] {refCust2}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R3*{0}",  new object[] {refCust3}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R4*{0}",  new object[] {refCust4}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R5*{0}",  new object[] {refCust5}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R6*{0}",  new object[] {refCust6}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R7*{0}",  new object[] {refCust7}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R8*{0}",  new object[] {refCust8}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R9*{0}",  new object[] {refCust9}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R10*{0}", new object[] {refCust10}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R11*{0}", new object[] {refCust11}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R12*{0}", new object[] {refCust12}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R13*{0}", new object[] {refCust13}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*QY*R14*{0}", new object[] {refCust14}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*NC*{0}",     new object[] {otPlanDesc}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*REC*{0}",    new object[] {relatedEvent}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*7U*{0}*{1}", new object[] {relatedPt, relatedProblem}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*A9*{0}*{1}", new object[] {eligId, eligStatus}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*JD*{0}",     new object[] {refDetailModId}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*JC*{0}",     new object[] {physicianReview}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*5H*{0}",     new object[] {primaryProblemId}, ref count);
			x12 += ExportAuthorization.FormatRecord("REF*72*{0}",     new object[] {altReferralId}, ref count);
			x12 += ExportAuthorization.FormatRecord("DTP*RFO*D8*{0}", new object[] {validFrom}, ref count);
			x12 += ExportAuthorization.FormatRecord("DTP*RTO*D8*{0}", new object[] {validTo}, ref count);
			x12 += ExportAuthorization.FormatRecord("DTP*771*D8*{0}", new object[] {statusDate}, ref count);
			x12 += ExportAuthorization.FormatRecord("DTP*307*D8*{0}", new object[] {eligEffDate}, ref count);
			x12 += ExportAuthorization.FormatRecord("DTP*330*D8*{0}", new object[] {refDetailDate}, ref count);
			x12 += ExportAuthorization.FormatRecord("DTP*152*D8*{0}", new object[] {refDetailModDate}, ref count);
			x12 += ExportAuthorization.FormatRecord("DTP*524*D8*{0}", new object[] {reportDateReceived}, ref count);
			x12 += ExportAuthorization.FormatRecord("DTP*196*D8*{0}", new object[] {refCreateDate}, ref count);
			x12 += ExportAuthorization.FormatRecord("DTP*328*D8*{0}", new object[] {refModDate}, ref count);

			return x12;
		}

		/// <summary>
		/// Parent Staging_AuthorizationReferralCollection that contains this element
		/// </summary>
		public Staging_AuthorizationReferralCollection ParentStaging_AuthorizationReferralCollection
		{
			get
			{
				return this.parentStaging_AuthorizationReferralCollection;
			}
			set
			{
				this.parentStaging_AuthorizationReferralCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Reads multiple objects of this type from source data reader into the given collection
		/// </summary>
		public int ReadCollection(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords, System.Collections.IList collection)
		{
			return SqlData.ReadCollection(sourceReader, maxRecords, collection, typeof(Staging_AuthorizationReferral), true, false);
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string RefAuthDecision
		{
			get { return this.refAuthDecision; }
			set { this.refAuthDecision = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefAuthDecisionDescription
		{
			get { return this.refAuthDecisionDescription; }
			set { this.refAuthDecisionDescription = value; }
		}


	}

	/// <summary>
	/// Strongly typed collection of Staging_AuthorizationReferral objects
	/// </summary>
	[ElementType(typeof(Staging_AuthorizationReferral))]
	public class Staging_AuthorizationReferralCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAuthorizationReferralsByBatch(int maxRecords, System.Guid batchNumber)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadAuthorizationReferralsByBatch", maxRecords, this, false, new object[] { batchNumber });
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Staging_AuthorizationReferral elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentStaging_AuthorizationReferralCollection = this;
			else
				elem.ParentStaging_AuthorizationReferralCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Staging_AuthorizationReferral elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Staging_AuthorizationReferral this[int index]
		{
			get
			{
				return (Staging_AuthorizationReferral)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Staging_AuthorizationReferral)oldValue, false);
			SetParentOnElem((Staging_AuthorizationReferral)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}// end of class
}
