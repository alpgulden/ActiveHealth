using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Staging_AuthorizationEvent]
	/// </summary>
	[SPAutoGen("usp_LoadAuthorizationEventsByBatchNumber","SelectAllByGivenArgs.sptpl","batchNumber")]
	[TableMapping("Staging_AuthorizationEvent","AuthorizationID")]
	public class Staging_AuthorizationEvent : BaseDataClass
	{

		#region column mappings
		[NonSerialized]
		private Staging_AuthorizationEventCollection parentStaging_AuthorizationEventCollection;
		[ColumnMapping("BatchNumber")]
		private Guid batchNumber;
		[ColumnMapping("AuthorizationID",StereoType=DataStereoType.FK)]
		private int authorizationID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		private int referralID;
		[ColumnMapping("EventType")]
		private string eventType;
		[ColumnMapping("EventTypeDesc")]
		private string eventTypeDesc;
		[ColumnMapping("EventStatus")]
		private string eventStatus;
		[ColumnMapping("EventAlternateID")]
		private string eventAlternateID;
		[ColumnMapping("HEDISReportType")]
		private string hEDISReportType;
		[ColumnMapping("LateCallIn")]
		private bool lateCallIn;
		[ColumnMapping("EventUDEF1")]
		private string eventUDEF1;
		[ColumnMapping("EventUDEF2")]
		private string eventUDEF2;
		[ColumnMapping("EventUDEF3")]
		private string eventUDEF3;
		[ColumnMapping("EventUDEF4")]
		private string eventUDEF4;
		[ColumnMapping("EventUDEF5")]
		private string eventUDEF5;
		[ColumnMapping("EventUDEF6")]
		private string eventUDEF6;
		[ColumnMapping("EventUDEF7")]
		private string eventUDEF7;
		[ColumnMapping("EventUDEF8")]
		private string eventUDEF8;
		[ColumnMapping("EventUDEF9")]
		private string eventUDEF9;
		[ColumnMapping("EventUDEF10")]
		private string eventUDEF10;
		[ColumnMapping("EventUDEF11")]
		private string eventUDEF11;
		[ColumnMapping("EventUDEF12")]
		private string eventUDEF12;
		[ColumnMapping("EventUDEF13")]
		private string eventUDEF13;
		[ColumnMapping("EventUDEF14")]
		private string eventUDEF14;
		[ColumnMapping("EventDRGCode")]
		private string eventDRGCode;
		[ColumnMapping("EventOtherPlanDesc")]
		private string eventOtherPlanDesc;
		[ColumnMapping("EventCreateDate")]
		private DateTime eventCreateDate;
		[ColumnMapping("EventStartDate")]
		private DateTime eventStartDate;
		[ColumnMapping("EventEndDate")]
		private DateTime eventEndDate;
		[ColumnMapping("EventModDate")]
		private DateTime eventModDate;
		[ColumnMapping("UB92Source")]
		private string uB92Source;
		[ColumnMapping("AdmittingDxCode")]
		private string admittingDxCode;
		[ColumnMapping("AdmittingDxType")]
		private string admittingDxType;
		[ColumnMapping("req_amount",StereoType=DataStereoType.FK)]
		private int reqAmount;
		[ColumnMapping("req_uofm_rpt_units")]
		private string reqUofmRptUnits;
		[ColumnMapping("req_uofm_desc")]
		private string reqUofmDesc;
		[ColumnMapping("req_duration_amount",StereoType=DataStereoType.FK)]
		private int reqDurationAmount;
		[ColumnMapping("req_duration_uofm")]
		private string reqDurationUofm;
		[ColumnMapping("req_duration_uofm_desc")]
		private string reqDurationUofmDesc;
		[ColumnMapping("dec_uofm")]
		private string decUofm;
		[ColumnMapping("dec_uofm_desc")]
		private string decUofmDesc;
		[ColumnMapping("dec_amount",StereoType=DataStereoType.FK)]
		private int decAmount;
		[ColumnMapping("dec_freq_amount",StereoType=DataStereoType.FK)]
		private int decFreqAmount;
		[ColumnMapping("dec_freq_uofm")]
		private string decFreqUofm;
		[ColumnMapping("dec_freq_uofm_desc")]
		private string decFreqUofmDesc;
		[ColumnMapping("req_freq_amount",StereoType=DataStereoType.FK)]
		private int reqFreqAmount;
		[ColumnMapping("req_freq_uofm")]
		private string reqFreqUofm;
		[ColumnMapping("req_freq_uofm_desc")]
		private string reqFreqUofmDesc;
		[ColumnMapping("req_description_desc")]
		private string reqDescriptionDesc;
		[ColumnMapping("dec_duration_amount",StereoType=DataStereoType.FK)]
		private int decDurationAmount;
		[ColumnMapping("dec_duration_uofm")]
		private string decDurationUofm;
		[ColumnMapping("dec_duration_uofm_desc")]
		private string decDurationUofmDesc;
		[ColumnMapping("req_mod_date")]
		private DateTime reqModDate;
		[ColumnMapping("req_create_date")]
		private DateTime reqCreateDate;
		[ColumnMapping("dec_procedure_type")]
		private string decProcedureType;
		[ColumnMapping("dec_procedure_code")]
		private string decProcedureCode;
		[ColumnMapping("dec_mod_date")]
		private DateTime decModDate;
		[ColumnMapping("dec_create_date")]
		private DateTime decCreateDate;
		[ColumnMapping("dec_start_date")]
		private DateTime decStartDate;
		[ColumnMapping("dec_end_date")]
		private DateTime decEndDate;
		[ColumnMapping("dec_actual_end_date")]
		private DateTime decActualEndDate;
		[ColumnMapping("dec_type")]
		private string decType;
		[ColumnMapping("dec_decision_code")]
		private string decDecisionCode;
		[ColumnMapping("decision_type_desc")]
		private string decisionTypeDesc;
		[ColumnMapping("dec_reason")]
		private string decReason;
		[ColumnMapping("dec_reason_desc")]
		private string decReasonDesc;
		[ColumnMapping("dec_description_desc")]
		private string decDescriptionDesc;
		[ColumnMapping("rev_request_id",StereoType=DataStereoType.FK)]
		private int revRequestId;
		[ColumnMapping("dec_unit_cost",StereoType=DataStereoType.FK)]
		private int decUnitCost;
		[ColumnMapping("dec_discount",StereoType=DataStereoType.FK)]
		private int decDiscount;
		[ColumnMapping("req_unit_cost",StereoType=DataStereoType.FK)]
		private int reqUnitCost;
		[ColumnMapping("dec_actual_amount",StereoType=DataStereoType.FK)]
		private int decActualAmount;
		[ColumnMapping("dec_comment")]
		private string decComment;
		[ColumnMapping("dec_cust_1")]
		private string decCust1;
		[ColumnMapping("dec_cust_2")]
		private string decCust2;
		[ColumnMapping("dec_cust_3")]
		private string decCust3;
		[ColumnMapping("dec_cust_4")]
		private string decCust4;
		[ColumnMapping("dec_cust_5")]
		private string decCust5;
		[ColumnMapping("dec_cust_6")]
		private string decCust6;
		[ColumnMapping("UB92DispositionID",StereoType=DataStereoType.FK)]
		private int uB92DispositionID;
		#endregion

		public Staging_AuthorizationEvent()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region properties
		UB92DispositionCollection ub92list = null;
		public string UB92Disposition
		{
			get
			{
				if (null == ub92list)
				{
					ub92list = new UB92DispositionCollection();
					ub92list.LoadActiveUB92DispositionByActive(-1, true);
				}

				// Okay we have our UB92Disposition code table, lookup our ID
				foreach(ActiveAdvice.DataLayer.UB92Disposition ub92 in ub92list)
				{
					if (ub92.UB92DispositionID == this.UB92DispositionID)
						return ub92.Code;
				}
				return "UNKN";
			}
		}

		public System.Guid BatchNumber
		{
			get { return this.batchNumber; }
			set { this.batchNumber = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string EventType
		{
			get { return this.eventType; }
			set { this.eventType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string EventTypeDesc
		{
			get { return this.eventTypeDesc; }
			set { this.eventTypeDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string EventAlternateID
		{
			get { return this.eventAlternateID; }
			set { this.eventAlternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string HEDISReportType
		{
			get { return this.hEDISReportType; }
			set { this.hEDISReportType = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool LateCallIn
		{
			get { return this.lateCallIn; }
			set { this.lateCallIn = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF1
		{
			get { return this.eventUDEF1; }
			set { this.eventUDEF1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF2
		{
			get { return this.eventUDEF2; }
			set { this.eventUDEF2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF3
		{
			get { return this.eventUDEF3; }
			set { this.eventUDEF3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF4
		{
			get { return this.eventUDEF4; }
			set { this.eventUDEF4 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF5
		{
			get { return this.eventUDEF5; }
			set { this.eventUDEF5 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF6
		{
			get { return this.eventUDEF6; }
			set { this.eventUDEF6 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF7
		{
			get { return this.eventUDEF7; }
			set { this.eventUDEF7 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF8
		{
			get { return this.eventUDEF8; }
			set { this.eventUDEF8 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF9
		{
			get { return this.eventUDEF9; }
			set { this.eventUDEF9 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF10
		{
			get { return this.eventUDEF10; }
			set { this.eventUDEF10 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF11
		{
			get { return this.eventUDEF11; }
			set { this.eventUDEF11 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF12
		{
			get { return this.eventUDEF12; }
			set { this.eventUDEF12 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF13
		{
			get { return this.eventUDEF13; }
			set { this.eventUDEF13 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventUDEF14
		{
			get { return this.eventUDEF14; }
			set { this.eventUDEF14 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string EventDRGCode
		{
			get { return this.eventDRGCode; }
			set { this.eventDRGCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string EventOtherPlanDesc
		{
			get { return this.eventOtherPlanDesc; }
			set { this.eventOtherPlanDesc = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EventCreateDate
		{
			get { return this.eventCreateDate; }
			set { this.eventCreateDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EventStartDate
		{
			get { return this.eventStartDate; }
			set { this.eventStartDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EventEndDate
		{
			get { return this.eventEndDate; }
			set { this.eventEndDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EventModDate
		{
			get { return this.eventModDate; }
			set { this.eventModDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string UB92Source
		{
			get { return this.uB92Source; }
			set { this.uB92Source = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string AdmittingDxCode
		{
			get { return this.admittingDxCode; }
			set { this.admittingDxCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string AdmittingDxType
		{
			get { return this.admittingDxType; }
			set { this.admittingDxType = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReqAmount
		{
			get { return this.reqAmount; }
			set { this.reqAmount = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string ReqUofmRptUnits
		{
			get { return this.reqUofmRptUnits; }
			set { this.reqUofmRptUnits = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string ReqUofmDesc
		{
			get { return this.reqUofmDesc; }
			set { this.reqUofmDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string ReqDurationUofm
		{
			get { return this.reqDurationUofm; }
			set { this.reqDurationUofm = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string ReqDurationUofmDesc
		{
			get { return this.reqDurationUofmDesc; }
			set { this.reqDurationUofmDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DecUofm
		{
			get { return this.decUofm; }
			set { this.decUofm = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DecAmount
		{
			get { return this.decAmount; }
			set { this.decAmount = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DecFreqUofm
		{
			get { return this.decFreqUofm; }
			set { this.decFreqUofm = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DecFreqUofmDesc
		{
			get { return this.decFreqUofmDesc; }
			set { this.decFreqUofmDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string ReqFreqUofm
		{
			get { return this.reqFreqUofm; }
			set { this.reqFreqUofm = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string ReqFreqUofmDesc
		{
			get { return this.reqFreqUofmDesc; }
			set { this.reqFreqUofmDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DecDurationUofm
		{
			get { return this.decDurationUofm; }
			set { this.decDurationUofm = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DecDurationUofmDesc
		{
			get { return this.decDurationUofmDesc; }
			set { this.decDurationUofmDesc = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ReqModDate
		{
			get { return this.reqModDate; }
			set { this.reqModDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ReqCreateDate
		{
			get { return this.reqCreateDate; }
			set { this.reqCreateDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DecModDate
		{
			get { return this.decModDate; }
			set { this.decModDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DecCreateDate
		{
			get { return this.decCreateDate; }
			set { this.decCreateDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DecStartDate
		{
			get { return this.decStartDate; }
			set { this.decStartDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DecEndDate
		{
			get { return this.decEndDate; }
			set { this.decEndDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DecType
		{
			get { return this.decType; }
			set { this.decType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DecDecisionCode
		{
			get { return this.decDecisionCode; }
			set { this.decDecisionCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DecisionTypeDesc
		{
			get { return this.decisionTypeDesc; }
			set { this.decisionTypeDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DecReason
		{
			get { return this.decReason; }
			set { this.decReason = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DecReasonDesc
		{
			get { return this.decReasonDesc; }
			set { this.decReasonDesc = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RevRequestId
		{
			get { return this.revRequestId; }
			set { this.revRequestId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DecCust1
		{
			get { return this.decCust1; }
			set { this.decCust1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DecCust2
		{
			get { return this.decCust2; }
			set { this.decCust2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DecCust3
		{
			get { return this.decCust3; }
			set { this.decCust3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DecCust4
		{
			get { return this.decCust4; }
			set { this.decCust4 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DecCust5
		{
			get { return this.decCust5; }
			set { this.decCust5 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DecCust6
		{
			get { return this.decCust6; }
			set { this.decCust6 = value; }
		}
		#endregion

		/// <summary>
		/// GenerateHeader()
		/// method creates the Event Header the comes before the information
		/// common to events & referrals
		/// </summary>
		/// <returns></returns>
		public string GenerateHeader(ref int count, ref int heirarchialID, ref int parentheirarchialID)
		{
			string x12out;
			x12out = this.X12header(ref count, heirarchialID, parentheirarchialID);
			heirarchialID++; parentheirarchialID++;
			return x12out;
		}
		/// <summary>
		/// GenerateFormattedOutput()
		/// Generates the x12 event-specific formatted
		/// output. 
		/// </summary>
		/// <returns>string x12out, x12 output that is ready to write to file</returns>
		public string GenerateFormattedOutput(ref int count, int heirarchialID, int parentheirarchialID)
		{
			string x12out;
			x12out  = X12services(ref count, heirarchialID, parentheirarchialID);
			x12out += X12decision(ref count, heirarchialID, parentheirarchialID);
			x12out += X12admittingcode(ref count); // probably needs to be last so it abutts the dx/px data
			return x12out;
		}

		public string GenerateMessageLoop(ref int count, Staging_AuthorizationNote note)
		{
			return this.X12messageloop(ref count, note);
		}

		/// <summary>
		/// Parent Staging_AuthorizationEventCollection that contains this element
		/// </summary>
		public Staging_AuthorizationEventCollection ParentStaging_AuthorizationEventCollection
		{
			get
			{
				return this.parentStaging_AuthorizationEventCollection;
			}
			set
			{
				this.parentStaging_AuthorizationEventCollection = value; // parent is set when added to a collection
			}
		}

		protected string X12header(ref int count, int heirarchialID, int parentheirarchialID)
		{
			string x12out = "";
			x12out += ExportAuthorization.FormatRecord("HL*{0}*{1}*{2}*1", new object[] {heirarchialID, parentheirarchialID, 22}, ref count);
			x12out += ExportAuthorization.FormatRecord("TRN*1*{0}*{1}*{2}", new object[] {this.EventID, this.EventType, this.EventTypeDesc}, ref count);
			return x12out;
		}

		protected string X12decision(ref int count, int heirarchialID, int parentheirarchialID)
		{
			string x12out;
			int start_count = count;
			x12out  = ExportAuthorization.FormatRecord("HL*{0}*{1}*{2}*1",  new object[] {heirarchialID, parentheirarchialID, "RB"}, ref count);
			x12out += ExportAuthorization.FormatRecord("HCR*11*{0}",     new object[] {this.DecReasonDesc}, ref count);
			x12out += ExportAuthorization.FormatRecord("HCR*18*{0}",     new object[] {this.DecDescriptionDesc}, ref count);
			x12out += ExportAuthorization.FormatRecord("HCR*16*{0}",     new object[] {this.ReqDescriptionDesc}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*T8*{0}",     new object[] {this.DecDescriptionDesc}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*W4*{0}",     new object[] {this.RevRequestId}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*K0*{0}*{1}*>{2}>>{3}", new object[]{this.DecType, DecDecisionCode, DecisionTypeDesc, this.DecReason}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*OD*{0}*{1}", new object[] {this.DecUofm, this.DecAmount}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*KR*{0}*{1}", new object[] {this.DecFreqUofm, this.DecFreqUofmDesc}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*Q1*{0}*{1}", new object[] {this.DecDurationUofm, this.DecDurationUofmDesc}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*K9*{0}*{1}", new object[] {this.ReqUofmRptUnits, this.ReqAmount}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*KT*{0}*{1}", new object[] {this.ReqFreqUofm, this.ReqFreqUofmDesc}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*MZ*{0}*{1}", new object[] {ReqDurationUofm, ReqDurationUofmDesc}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*BLT*{0}*{1}", new object[] {DecAmount, DecUofm}, ref count);

			x12out += ExportAuthorization.FormatRecord("REF*CI*1*{0}",   new object[] {DecCust1}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*CI*2*{0}",   new object[] {DecCust2}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*CI*3*{0}",   new object[] {DecCust3}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*CI*4*{0}",   new object[] {DecCust4}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*CI*5*{0}",   new object[] {DecCust5}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*CI*6*{0}",   new object[] {DecCust6}, ref count);

			x12out += ExportAuthorization.FormatRecord("DTP*ORG*D8*{0}", new object[] {DecCreateDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*089*D8*{0}", new object[] {ReqCreateDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*328*D8*{0}", new object[] {this.ReqModDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*150*D8*{0}", new object[] {DecStartDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*151*D8*{0}", new object[] {DecEndDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*243*D8*{0}", new object[] {DecActualEndDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*155*D8*{0}", new object[] {DecEndDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("HI*{0}>{1}",     new object[] {DecProcedureType, DecProcedureCode}, ref count);
			x12out += ExportAuthorization.FormatRecord("HSD*1A*{0}*{1}**{2}", new object[] {this.DecFreqAmount, this.DecFreqUofm, this.DecDurationUofm, this.DecDurationAmount}, ref count);
			x12out += ExportAuthorization.FormatRecord("HSD*1B*{0}",     new object[] {this.DecAmount, this.DecUofm}, ref count);
			x12out += ExportAuthorization.FormatRecord("HSD*B3*{0}*{1}*{2}*{3}", new object[] {this.ReqFreqAmount, this.ReqFreqUofm, this.reqDurationUofm, this.ReqDurationAmount}, ref count);
			x12out += ExportAuthorization.FormatRecord("HSD*B5*{0}*{1}", new object[] {reqAmount, ReqUofmRptUnits}, ref count);
			x12out += ExportAuthorization.FormatRecord("AMT*LI*{0}",     new object[] {this.DecUnitCost}, ref count);
			x12out += ExportAuthorization.FormatRecord("AMT*D8*{0}",     new object[] {this.DecDiscount}, ref count);
			x12out += ExportAuthorization.FormatRecord("AMT*YV*{0}",     new object[] {this.ReqUnitCost}, ref count);
			x12out += ExportAuthorization.FormatRecord("AMT*AU*{0}",     new object[] {this.DecActualAmount}, ref count);
			x12out += ExportAuthorization.FormatRecord("MSG*{0}",        new object[] {this.DecComment}, ref count);

			// If nothing but the header was generated, then don't output anything
			if (count == (start_count + 1) )
			{
				count = start_count;
				return null;
			}
			return x12out;
		}// end of X12decision

		protected string X12services(ref int count, int heirarchialID, int parentheirarchialID)
		{
			string x12out = "";
			x12out += ExportAuthorization.FormatRecord("HL*{0}*{1}*{2}*1",   new object[] {heirarchialID, parentheirarchialID, "SS"}, ref count);
			x12out += ExportAuthorization.FormatRecord("TRN*2*{0}",       new object[] {this.EventAlternateID}, ref count);
			x12out += ExportAuthorization.FormatRecord("UM*HS**{0}",     new object[] {HEDISReportType}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*SU*{0}",     new object[] {this.EventStatus}, ref count); // Is this the "Code_status" field???
			x12out += ExportAuthorization.FormatRecord("REF*ZZ*{0}",     new object[] {LateCallIn}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*S2*{0}",     new object[] {this.UB92Source}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*K0*{0}",     new object[] {this.UB92Disposition}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*1*{1}",   new object[] {EventUDEF1}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*2*{1}",   new object[] {EventUDEF2}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*3*{1}",   new object[] {EventUDEF3}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*4*{1}",   new object[] {EventUDEF4}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*5*{1}",   new object[] {EventUDEF5}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*6*{1}",   new object[] {EventUDEF6}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*7*{1}",   new object[] {EventUDEF7}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*8*{1}",   new object[] {EventUDEF8}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*9*{1}",   new object[] {EventUDEF9}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*10*{1}",  new object[] {EventUDEF10}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*11*{1}",  new object[] {EventUDEF11}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*12*{1}",  new object[] {EventUDEF12}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*13*{1}",  new object[] {EventUDEF13}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*QY*14*{1}",  new object[] {EventUDEF14}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*G2*{0}",     new object[] {EventUDEF2}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*1N*{0}",     new object[] {EventDRGCode}, ref count);
			x12out += ExportAuthorization.FormatRecord("REF*NC*{0}",     new object[] {EventOtherPlanDesc}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*ORG*D8*{0}", new object[] {EventCreateDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*152*D8*",    new object[] {EventModDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*242*D8*{0}", new object[] {EventStartDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*243*D8*{0}", new object[] {EventEndDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*244*D8*{0}", new object[] {EventStartDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*245*D8*{0}", new object[] {EventEndDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*196*D8*{0}", new object[] {EventStartDate}, ref count);
			x12out += ExportAuthorization.FormatRecord("DTP*197*D8*{0}", new object[] {EventEndDate}, ref count);

			return x12out;
		}

		protected string X12admittingcode(ref int count)
		{
			string x12out;
			x12out = ExportAuthorization.FormatRecord("HI*BJ>{0}>>>>{1}", new object[] {this.AdmittingDxCode, this.AdmittingDxType}, ref count);
			return x12out;
		}

		protected string X12messageloop(ref int count, Staging_AuthorizationNote note)
		{
			string x12out;
			Note n = new Note();
			n.Load(note.NoteID);
			if (n.NotePage == null)
				return null;
			try
			{
				string message = null;
				if (n.NotePage.IsRTF)
				{
					System.Windows.Forms.RichTextBox rtb = new System.Windows.Forms.RichTextBox();
					rtb.Rtf = n.NotePage.NoteText;
					message = rtb.Text;
				}
				else
					message = n.NotePage.NoteText;

				x12out  = ExportAuthorization.FormatRecord("LS*{0}", new object[] {1000}, ref count);
				x12out += ExportAuthorization.FormatRecord("DTP*920*D8*{0}", new object[] {note.CreateTime}, ref count);
				x12out += ExportAuthorization.FormatRecord("REF*{0}*{1}", new object[] {"LI", note.NoteID}, ref count);
				x12out += ExportAuthorization.FormatRecord("MSG*{0}", new object[] {message.Substring(0, (message.Length > 256 ? 256 : message.Length-1) ) }, ref count);
				x12out += ExportAuthorization.FormatRecord("LE*{0}", new object[] {1000}, ref count);
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				// probably an empty notepage, how could this happen?
				return null; // just return an empty note message loop
			}
			return x12out;
		}

		#region properties
		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DecUofmDesc
		{
			get { return this.decUofmDesc; }
			set { this.decUofmDesc = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DecFreqAmount
		{
			get { return this.decFreqAmount; }
			set { this.decFreqAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReqFreqAmount
		{
			get { return this.reqFreqAmount; }
			set { this.reqFreqAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DecDurationAmount
		{
			get { return this.decDurationAmount; }
			set { this.decDurationAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DecUnitCost
		{
			get { return this.decUnitCost; }
			set { this.decUnitCost = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DecDiscount
		{
			get { return this.decDiscount; }
			set { this.decDiscount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReqUnitCost
		{
			get { return this.reqUnitCost; }
			set { this.reqUnitCost = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DecActualAmount
		{
			get { return this.decActualAmount; }
			set { this.decActualAmount = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string DecComment
		{
			get { return this.decComment; }
			set { this.decComment = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DecProcedureType
		{
			get { return this.decProcedureType; }
			set { this.decProcedureType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DecProcedureCode
		{
			get { return this.decProcedureCode; }
			set { this.decProcedureCode = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DecActualEndDate
		{
			get { return this.decActualEndDate; }
			set { this.decActualEndDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReqDurationAmount
		{
			get { return this.reqDurationAmount; }
			set { this.reqDurationAmount = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string ReqDescriptionDesc
		{
			get { return this.reqDescriptionDesc; }
			set { this.reqDescriptionDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string DecDescriptionDesc
		{
			get { return this.decDescriptionDesc; }
			set { this.decDescriptionDesc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string EventStatus
		{
			get { return this.eventStatus; }
			set { this.eventStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AuthorizationID
		{
			get { return this.authorizationID; }
			set { this.authorizationID = value; }
		}
		#endregion

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int UB92DispositionID
		{
			get { return this.uB92DispositionID; }
			set { this.uB92DispositionID = value; }
		}

	}// end of class

	/// <summary>
	/// Strongly typed collection of Staging_AuthorizationEvent objects
	/// </summary>
	[ElementType(typeof(Staging_AuthorizationEvent))]
	public class Staging_AuthorizationEventCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAuthorizationEventsByBatchNumber(int maxRecords, System.Guid batchNumber)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadAuthorizationEventsByBatchNumber", maxRecords, this, false, new object[] { batchNumber });
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Staging_AuthorizationEvent elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentStaging_AuthorizationEventCollection = this;
			else
				elem.ParentStaging_AuthorizationEventCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Staging_AuthorizationEvent elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Staging_AuthorizationEvent this[int index]
		{
			get
			{
				return (Staging_AuthorizationEvent)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Staging_AuthorizationEvent)oldValue, false);
			SetParentOnElem((Staging_AuthorizationEvent)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}
}
