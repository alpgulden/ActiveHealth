using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ScheduleType]
	/// </summary>
	[SPAutoGen("usp_GetScheduleTypeByActive","CodeTableLoader.sptpl","active")]
	[TableMapping("ScheduleType","scheduleTypeID")]
	public class ScheduleType : BaseDataClass
	{
		[NonSerialized]
		private ScheduleTypeCollection parentScheduleTypeCollection;
		[ColumnMapping("ScheduleTypeID",(int)0)]
		private int scheduleTypeID;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("ReadOnly")]
		private bool readOnly;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public ScheduleType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ScheduleTypeID
		{
			get { return this.scheduleTypeID; }
			set { this.scheduleTypeID = value; }
		}

		/// <summary>
		/// Parent ScheduleTypeCollection that contains this element
		/// </summary>
		public ScheduleTypeCollection ParentScheduleTypeCollection
		{
			get
			{
				return this.parentScheduleTypeCollection;
			}
			set
			{
				this.parentScheduleTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReadOnly
		{
			get { return this.readOnly; }
			set { this.readOnly = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of ScheduleType objects
	/// </summary>
	[ElementType(typeof(ScheduleType))]
	public class ScheduleTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ScheduleTypeID;
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadScheduleTypeByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetScheduleTypeByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ScheduleType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentScheduleTypeCollection = this;
			else
				elem.ParentScheduleTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ScheduleType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ScheduleType this[int index]
		{
			get
			{
				return (ScheduleType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ScheduleType)oldValue, false);
			SetParentOnElem((ScheduleType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Hashtable based search on code fields returns the object.  Uses the IndexBy_Code indexer.
		/// </summary>
		public ScheduleType FindBy(string code)
		{
			return (ScheduleType)this.IndexBy_Code.GetObject(code);
		}

		/// <summary>
		/// Hashtable based index on scheduleTypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ScheduleTypeID
		{
			get
			{
				if (this.indexBy_ScheduleTypeID == null)
					this.indexBy_ScheduleTypeID = new CollectionIndexer(this, new string[] { "scheduleTypeID" }, true);
				return this.indexBy_ScheduleTypeID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on scheduleTypeID fields returns the object.  Uses the IndexBy_ScheduleTypeID indexer.
		/// </summary>
		public ScheduleType FindBy(int scheduleTypeID)
		{
			return (ScheduleType)this.IndexBy_ScheduleTypeID.GetObject(scheduleTypeID);
		}
	}
}
