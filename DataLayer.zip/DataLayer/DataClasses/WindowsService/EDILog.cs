using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EDILog]
	/// </summary>
	[SPInsert("usp_InsertEDILog")]
	[SPUpdate("usp_UpdateEDILog")]
	[SPLoad("usp_LoadEDILog")]
	[TableMapping("EDILog","eDILogID")]
	public class EDILog : BaseDataClass
	{
		[ColumnMapping("EDILogID",(int)0)]
		private int eDILogID;
		[ColumnMapping("ReceiverIDType")]
		private string receiverIDType;
		[ColumnMapping("ReceiverID")]
		private string receiverID;
		[ColumnMapping("ReceiveDate")]
		private DateTime receiveDate;
		[ColumnMapping("FileName")]
		private string fileName;
		[ColumnMapping("ESEP")]
		private string eSEP;
		[ColumnMapping("SubESEP")]
		private string subESEP;
		[ColumnMapping("Status")]
		private string status;
		[ColumnMapping("LineCount",StereoType=DataStereoType.FK)]
		private int lineCount;
		[ColumnMapping("DataFile")]
		private string dataFile;
		[ColumnMapping("Acknowledge")]
		private string acknowledge;
	
		public EDILog()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EDILogID
		{
			get { return this.eDILogID; }
			set { this.eDILogID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string ReceiverIDType
		{
			get { return this.receiverIDType; }
			set { this.receiverIDType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string ReceiverID
		{
			get { return this.receiverID; }
			set { this.receiverID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime ReceiveDate
		{
			get { return this.receiveDate; }
			set { this.receiveDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string FileName
		{
			get { return this.fileName; }
			set { this.fileName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string ESEP
		{
			get { return this.eSEP; }
			set { this.eSEP = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string SubESEP
		{
			get { return this.subESEP; }
			set { this.subESEP = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string Status
		{
			get { return this.status; }
			set { this.status = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LineCount
		{
			get { return this.lineCount; }
			set { this.lineCount = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eDILogID)
		{
			return base.Load(eDILogID);
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2147483647)]
		public string DataFile
		{
			get { return this.dataFile; }
			set { this.dataFile = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2147483647)]
		public string Acknowledge
		{
			get { return this.acknowledge; }
			set { this.acknowledge = value; }
		}
	}
}
