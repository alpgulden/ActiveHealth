using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EDIRequestorDetail]
	/// </summary>
	[TableMapping("EDIRequestorDetail","eDIRequestorDetailID")]
	public class EDIRequestorDetail : BaseDataClass
	{
		[ColumnMapping("EDIRequestorDetailID",(int)0)]
		private int eDIRequestorDetailID;
		[ColumnMapping("IDQualifier")]
		private string iDQualifier;
		[ColumnMapping("IDCode")]
		private string iDCode;
		[ColumnMapping("RequesterName")]
		private string requesterName;
		[ColumnMapping("OutboxPath")]
		private string outboxPath;
		[ColumnMapping("MAProviderID",StereoType=DataStereoType.FK)]
		private int mAProviderID;
		[ColumnMapping("ContactName")]
		private string contactName;
		[ColumnMapping("ContactType_1")]
		private string contacttype1;
		[ColumnMapping("ContactPhone_1")]
		private string contactphone1;
		[ColumnMapping("ContactType_2")]
		private string contacttype2;
		[ColumnMapping("ContactPhone_2")]
		private string contactphone2;
		[ColumnMapping("ContactType_3")]
		private string contacttype3;
		[ColumnMapping("ContactPhone_3")]
		private string contactphone3;
	
		public EDIRequestorDetail()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EDIRequestorDetailID
		{
			get { return this.eDIRequestorDetailID; }
			set { this.eDIRequestorDetailID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=2)]
		public string IDQualifier
		{
			get { return this.iDQualifier; }
			set { this.iDQualifier = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=80)]
		public string IDCode
		{
			get { return this.iDCode; }
			set { this.iDCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string RequesterName
		{
			get { return this.requesterName; }
			set { this.requesterName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=200)]
		public string OutboxPath
		{
			get { return this.outboxPath; }
			set { this.outboxPath = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int MAProviderID
		{
			get { return this.mAProviderID; }
			set { this.mAProviderID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string ContactName
		{
			get { return this.contactName; }
			set { this.contactName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string Contacttype1
		{
			get { return this.contacttype1; }
			set { this.contacttype1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Contactphone1
		{
			get { return this.contactphone1; }
			set { this.contactphone1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string Contacttype2
		{
			get { return this.contacttype2; }
			set { this.contacttype2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Contactphone2
		{
			get { return this.contactphone2; }
			set { this.contactphone2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string Contacttype3
		{
			get { return this.contacttype3; }
			set { this.contacttype3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Contactphone3
		{
			get { return this.contactphone3; }
			set { this.contactphone3 = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}
	}
}
