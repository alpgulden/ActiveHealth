using System;
using System.IO;		// Path class
using NetsoftUSA.DataLayer;
using System.Globalization;	// DateTimeInfo for ParseExact

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ScheduleTask]
	/// </summary>
	[SPLoad("usp_LoadScheduleTask")]
	[SPInsert("usp_InsertScheduleTask")]
	[SPAutoGen("usp_GetScheduleTasksByTypeANDStatus","SelectAllByGivenArgs.sptpl","scheduleTypeID, scheduleStatusID")]
	[SPAutoGen("usp_GetScheduleTasksByType","SelectAllByGivenArgs.sptpl","scheduleTypeID")]
	[SPAutoGen("usp_GetScheduleTasks","SelectAll.sptpl","")]
	[SPUpdate("usp_UpdateScheduleTask")]
	[SPAutoGen("usp_GetScheduleTasksByStatus","SelectAllByGivenArgs.sptpl","scheduleStatusID")]
	[TableMapping("ScheduleTask","jobID")]
	public class ScheduleTask : BaseData
	{
		[NonSerialized]
		private ScheduleTaskCollection parentScheduleTaskCollection;
		[ColumnMapping("JobID",(int)0)]
		private int jobID;
		[ColumnMapping("ScheduleTypeID")]
		private int scheduleTypeID;
		[ColumnMapping("ScheduleStatusID")]
		private int scheduleStatusID;
		[ColumnMapping("ScheduledTime")]
		private DateTime scheduledTime;
		[ColumnMapping("Task")]
		private string task;
		[ColumnMapping("Label")]
		private string label;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("StartTime")]
		private DateTime startTime;
		[ColumnMapping("EndTime")]
		private DateTime endTime;
	
		public ScheduleTask()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int JobID
		{
			get { return this.jobID; }
			set { this.jobID = value; }
		}

		[FieldValuesMember("LookupOf_ScheduleTypeID", "ScheduleTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int ScheduleTypeID
		{
			get { return this.scheduleTypeID; }
			set { this.scheduleTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public string ScheduleType
		{
			get { return MapScheduleType(this.scheduleTypeID); }
		}

		[FieldValuesMember("LookupOf_ScheduleStatusID", "ScheduleStatusID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int ScheduleStatusID
		{
			get { return this.scheduleStatusID; }
			set { this.scheduleStatusID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public string ScheduleStatus
		{
			get { return MapScheduleStatus(this.scheduleStatusID, this.JobID); }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime ScheduledTime
		{
			get { return this.scheduledTime; }
			set { this.scheduledTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Task
		{
			get { return this.task; }
			set { this.task = value; }
		}

		public ScheduleStatusCollection LookupOf_ScheduleStatusID
		{
			get
			{
				ScheduleStatusCollection scheduleStatuses	= (ScheduleStatusCollection)ScheduleTask.ActiveScheduleStatuses.Clone(false, false);
				ScheduleStatus scheduleStatus = new ScheduleStatus();
				scheduleStatus.Description = "ALL";
				scheduleStatus.ScheduleStatusID = -1;
				scheduleStatuses.InsertRecord(0, scheduleStatus);
				return scheduleStatuses;
			}
		}
		/// <summary>
		/// Parent ScheduleTaskCollection that contains this element
		/// </summary>
		public ScheduleTaskCollection ParentScheduleTaskCollection
		{
			get
			{
				return this.parentScheduleTaskCollection;
			}
			set
			{
				this.parentScheduleTaskCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		#region properties
		[ControlType(EnumControlTypes.TextBox, MaxLength=500)]
		public string Label
		{
			get { return this.label; }
			set { this.label = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StartTime
		{
			get { return this.startTime; }
			set { this.startTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndTime
		{
			get { return this.endTime; }
			set { this.endTime = value; }
		}
		#endregion

		static ScheduleTypeCollection scheduleTypes       = null;
		static ScheduleStatusCollection scheduleStatuses  = null;
		/// <summary>
		/// InitializeCodeTables()
		/// </summary>
		protected static void InitializeCodeTables()
		{
			try
			{
				if (scheduleTypes == null)
				{
					scheduleTypes		= new ScheduleTypeCollection();
					scheduleTypes.LoadScheduleTypeByActive(-1, true);
				}
				if (scheduleStatuses == null)
				{
					scheduleStatuses	= new ScheduleStatusCollection();
					scheduleStatuses.LoadScheduleStatusByActive(-1, true);
				}
			}
			catch(Exception e)
			{
				string message = e.Message;
			}
		}// end of method

		/// <summary>
		/// MapScheduleType()
		/// This static method maintains an instance of the ScheduleTypeCollection
		/// so it can map the ScheduleTypeID of the scheduletask to a string
		/// </summary>
		/// <param name="ScheduleTypeID"></param>
		/// <returns></returns>
		protected static string MapScheduleType(int ScheduleTypeID)
		{
			if (null == scheduleTypes)
				InitializeCodeTables();
			for(int i = 0; i < scheduleTypes.Count; i++)
			{
				if (scheduleTypes[i].ScheduleTypeID == ScheduleTypeID)
					return scheduleTypes[i].Code;
			}

			return null;
		}

		protected static string MapScheduleStatus(int ScheduleStatusID, int jobid)
		{
			if (null == scheduleStatuses)
				InitializeCodeTables();
			for(int i = 0; i < scheduleStatuses.Count; i++)
			{
				if (scheduleStatuses[i].ScheduleStatusID == ScheduleStatusID)
				{
					string targeturl = "importexportjobstatus.aspx?WindowMode=ModalDialog&jobid=" + jobid.ToString();
					string size      = String.Format("'width={0},height={1},resizable=0'", 600,300);
					string html =  "<a href=\"#\" onclick=\"window.open('" + targeturl + "', 'tskstatus',"+ size +" ); return false;\" target=\"tskstatus\">" + scheduleStatuses[i].Code + "</a>";
					return html;
				}
			}

			return null;
		}
		/// <summary>
		/// Accessor to a shared ScheduleTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ScheduleTypeCollection ActiveScheduleTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ScheduleTypeCollection col = (ScheduleTypeCollection)NSGlobal.EnsureCachedObject("ActiveScheduleTypes", typeof(ScheduleTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadScheduleTypeByActive(-1, true);
				}
				return col;
			}
			
		}
		/// <summary>
		/// Accessor to a shared ScheduleStatusCollection which is cached in NSGlobal
		/// </summary>
		public static ScheduleStatusCollection ActiveScheduleStatuses
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ScheduleStatusCollection col = (ScheduleStatusCollection)NSGlobal.EnsureCachedObject("ActiveScheduleStatuses", typeof(ScheduleStatusCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadScheduleStatusByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// LookupOf_ScheduleTypeID
		/// returns a collection of schedule types, the first record
		/// being "ALL".
		/// </summary>
		public ScheduleTypeCollection LookupOf_ScheduleTypeID
		{
			get
			{
				ScheduleTypeCollection scheduleTypes		= (ScheduleTypeCollection)ScheduleTask.ActiveScheduleTypes.Clone(false,false);
				ScheduleType st = new ScheduleType();
				st.Description = "ALL";
				st.ScheduleTypeID = -1;
				scheduleTypes.InsertRecord(0, st);
				return scheduleTypes;
			}
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int jobID)
		{
			return base.Load(jobID);
		}

		public string StartDate
		{
			get 
			{
				if (StartTime == DateTime.MinValue)
					return "not run yet";

				return this.StartTime.ToString("MM/dd/yyyy @h:mm tt"); 
			}
		}

		public string ElapsedTime
		{
			get
			{
				TimeSpan ts = EndTime - StartTime;
				if (ts.Hours == 0)
					return String.Format("{0} minutes and {1} seconds", ts.Minutes, ts.Seconds);
				else
					return String.Format("{0} hours, {1} minutes and {2} seconds", ts.Hours, ts.Minutes, ts.Seconds);
			}
		}

		public string FileName
		{
			get
			{
				TaskArguments ta = new TaskArguments(this.Task, null);
				return ta.FileName;
			}
		}

		protected string urlformat;
		public string URLformat
		{
			get { return urlformat;}
			set { urlformat = value; }
		}
		public string ErrorLogFileName
		{
			get
			{
				TaskArguments ta = new TaskArguments(this.Task, null);
				string filename = Path.GetFileName(ta.ErrorLogFileName);
				string size     = "??";
				try
				{
					FileInfo fi	= new FileInfo(ta.ErrorLogFileName);
					size		= fi.Length.ToString();
				}
				catch(Exception e)
				{
					string msg = e.Message;
				}
				string str;
				try
				{
					str = String.Format(URLformat, filename, filename, size);
				}
				catch(Exception ex)
				{
					string msg = ex.Message;
					return "no errorlog";
				}
				return str;
			}
		}
		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			writer.AddFieldsSubstituted(this,"@JobID@", "JobID");
			writer.AddFieldsOnNewLine(this, "FileName");
			writer.AddFieldsOnNewLine(this, "Label");
			writer.AddFieldsOnNewLine(this, "StartDate");
			if (EndTime != DateTime.MinValue)
				writer.AddFieldsOnNewLine(this, "ElapsedTime");
			TaskArguments ta = new TaskArguments();
			ta.Task	= this.Task;
			if (ta.ErrorLogFileName != null)
			{
				writer.AddFieldsOnNewLine(this, "ErrorLogFileName");
//				writer.AddCustomInfo("ErrorLog=" + ta.ErrorLogFileName);
			}
		}

	}// end of class

	/// <summary>
	/// Strongly typed collection of ScheduleTask objects
	/// </summary>
	[ElementType(typeof(ScheduleTask))]
	public class ScheduleTaskCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadScheduleTasksByStatus(int maxRecords, int scheduleStatusID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetScheduleTasksByStatus", maxRecords, this, false, new object[] { scheduleStatusID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadScheduleTasks(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetScheduleTasks", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadScheduleTasksByType(int maxRecords, int scheduleTypeID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetScheduleTasksByType", maxRecords, this, false, new object[] { scheduleTypeID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadScheduleTasksByTypeANDStatus(int maxRecords, int scheduleTypeID, int scheduleStatusID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetScheduleTasksByTypeANDStatus", maxRecords, this, false, new object[] { scheduleTypeID, scheduleStatusID });
		}

	}

	/// <summary>
	/// [TaskArguments]
	/// this class will parse the task list for arguments
	/// used by the Import/Export engines.
	/// </summary>
	[TableMapping(null)]
	public class TaskArguments : BaseDataClass
	{
		#region variables
		[NonSerialized]
		[ColumnMapping("FileName")]
		protected string filename;	// file we are to process

		protected string task;		// the task string, contains our encoded arguments
		protected string errorlog;	// filename for the errolog, derived from input filename
		protected string errorlogpath;
		#endregion

		public TaskArguments()
		{
		}
		public TaskArguments(string sTask, string errorpath)
		{
			this.task			= sTask;
			this.ParseTask();
			this.errorlogpath	= errorpath;
		}

		public string ErrorLogPath
		{
			get { return errorlogpath; }
			set { errorlogpath = value; }
		}

		public string ErrorLogFileName
		{
			get
			{
				if (null == errorlog)
					this.GenerateErrorLogFileName();
				return this.errorlog;
			}
			set
			{
				errorlog = (value == "" ? null : value);
			}
		}// end of property

		protected void GenerateErrorLogFileName()
		{
			if (errorlogpath == null) return;

			// Okay the filename is in the format:
			//   c:\data\input\foobar.txt
			//
			// We will create an error log file with the extension:
			//   c:\errorlogs\foobar_mmddyyyy_hhmm.log
			//

			string filename_noextension = Path.GetFileNameWithoutExtension(filename);
			DateTime dt = DateTime.Now;
			this.errorlog = errorlogpath + filename_noextension + "_" + dt.ToString("mmddyyyy_hhmm") + ".log";
		}// end of generating the error log filename

		[ControlType(EnumControlTypes.TextBox, MaxLength=500, IsRequired=true)]
		public virtual string FileName
		{
			get { return filename; }
			set { filename = value; }
		}

		private string label;
		[ControlType(EnumControlTypes.TextBox, MaxLength=500, IsRequired=true)]
		public string Label
		{
			get { return label; }
			set { label = value; }
		}

		public string Task
		{
			set
			{
				task = value;
				this.ParseTask();
			}
			get
			{
				this.MakeTask();
				return task;  
			}
		}

		/// <summary>
		/// MakeTask()
		/// this method will create our task string from the properties
		/// of the class.
		/// </summary>
		protected virtual void MakeTask()
		{
			task = "Filename=" + this.filename + "," + "ErrorPath=" + this.ErrorLogPath + "," + "ErrorLogFileName=" + this.ErrorLogFileName;
		}

		/// <summary>
		/// ParseTask()
		/// this method will populate the properties of the class
		/// from the task string.
		/// </summary>
		protected virtual void ParseTask()
		{
			if (task == null) return;
			const int maxparts = 15;
			char []comma			= {','};	// empty splitter
			char []equal            = {'='};
			string[] parts = task.Split(comma, maxparts);
			for(int i = 0; i < parts.Length; i++)
			{
				parts[i] = parts[i].ToUpper();
				string[] subparts = parts[i].Split(equal, 2);
				if (parts[i].StartsWith("FILENAME"))
					FileName = subparts[1];
				else if (parts[i].StartsWith("ERRORPATH") )
					ErrorLogPath = subparts[1];
				else if (parts[i].StartsWith("ERRORLOGFILENAME") )
					ErrorLogFileName = subparts[1];
			}
		}// end of method ParseTask()

	}// end of class TaskArguments


	/// <summary>
	/// MembershipLogArguments
	/// This is where we get/set the arguments for the membership log.
	/// Values of 0 for the MORG/ORG/SORG are interpreted as "ALL",
	/// so if the task string has "MORGID=ALL,...", then the morgid 
	/// value is set to 0.
	/// </summary>
	[TableMapping(null)]
	public class MembershipLogArguments : TaskArguments
	{
		#region variables
		protected string filetype;
		protected DateTime startdate;
		protected DateTime enddate;
		#endregion

		#region properties

		public override string FileName
		{
			get { return base.FileName; }
			set { base.FileName = value; }
		}
		public string FileType
		{
			get { return filetype; }
			set { filetype = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public DateTime StartDate
		{
			get { return startdate; }
			set { startdate = value; }
		}
		#endregion

		#region methods
		/// <summary>
		/// ParseTask()
		/// this method will parse the task string and extract the
		/// arguments specific to this kind of task.
		/// </summary>
		protected override void ParseTask()
		{
			base.ParseTask();
			if (task == null) return;
			const int maxparts = 15;
			char []comma			= {','};	// empty splitter
			char []equal            = {'='};
			string[] parts = task.Split(comma, maxparts);
			for(int i = 0; i < parts.Length; i++)
			{
				parts[i] = parts[i].ToUpper();
				string[] subparts = parts[i].Split(equal, 2);
				if (parts[i].StartsWith("STARTDATE") )
					this.startdate = DateTime.ParseExact(subparts[1], "MMddyyyy", DateTimeFormatInfo.InvariantInfo);
				else if (parts[i].StartsWith("FILETYPE") )
					this.filetype = subparts[1];
			}

		} // end of method ParseTask()

		/// <summary>
		/// MakeTask()
		/// this method performs the inverse of "ParseTask()"
		/// and creates a task string from the member properties.
		/// </summary>
		protected override void MakeTask()
		{
			base.MakeTask();
			Task = this.task + "," + "StartDate=" + StartDate.ToString("MMddyyyy") + "," + 
                   "FileType=" + FileType;
		}// end of method MakeTask()

		#endregion

		public MembershipLogArguments()
		{
		}

		public MembershipLogArguments(string sTask, string errorpath)
		{
			this.task			= sTask;
			this.ParseTask();
			this.errorlogpath	= errorpath;
		}

	}// end of class AAMembershipLogArguments


	/// <summary>
	/// AuthorizationArguments
	/// This class will process the arguments for the Authorization
	/// output file format. We need the following:
	/// 
	/// filename .......... name of file to process (for Authorizations it's EVT.X12 and/or REF.X12)
	/// start date ........ starting date range
	/// end date .......... ending date range (or null if all)
	/// events ............ =true, then generate event authorizations
	/// referrals ......... =true, then generate referral authorizations
	/// morgid ............ The MORG we are interested in (only a single more for authorizations)
	/// </summary>
	[TableMapping(null)]
	public class AuthorizationArguments : TaskArguments
	{
		#region  variables
		string   filetype;
		int		 morgid;
		DateTime startdate;
		DateTime enddate;
		bool     process_events;
		bool     process_referrals;
		#endregion

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Events
		{
			get {return process_events; }
			set {process_events = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Referrals
		{
			get {return process_referrals; }
			set {process_referrals = value; }
		}

		public string FileType
		{
			get { return filetype; }
			set { filetype = value; }
		}

		public int MORGID
		{
			get {return morgid; }
			set {morgid = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public DateTime StartDate
		{
			set { startdate = value; }
			get { return startdate; }
		}
		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public DateTime EndDate
		{
			set {enddate = value; }
			get {return enddate; }
		}

		/// <summary>
		/// AuthorizationArguments
		/// This method will process the arguments for an authorization output
		/// file.
		/// </summary>
		/// <param name="sTask"></param>
		/// <param name="errorpath"></param>
		public AuthorizationArguments(string sTask, string errorpath)
		{
			Initialize();
			this.task			= sTask;
			this.ParseTask();
			this.errorlogpath	= errorpath;
		}
		public AuthorizationArguments()
		{
			Initialize();
		}
		protected void Initialize()
		{
			Events			= false;
			Referrals		= false;
			FileName		= null;
			Task			= null;
			ErrorLogPath	= null;
			StartDate		= DateTime.Parse("1/1/0001");
			EndDate			= DateTime.Parse("1/1/0001");
		}
		/// <summary>
		/// ParseTask()
		/// this method will populate the properties of the class
		/// from the task string.
		/// </summary>
		protected override void ParseTask()
		{
			if (task == null) return;
			base.ParseTask();

			const int maxparts = 15;
			char []comma			= {','};	// empty splitter
			char []equal            = {'='};
			string[] parts = task.Split(comma, maxparts);
			for(int i = 0; i < parts.Length; i++)
			{
				parts[i] = parts[i].ToUpper();
				string[] subparts = parts[i].Split(equal, 2);
				if (parts[i].StartsWith("STARTDATE") )
					this.startdate = DateTime.ParseExact(subparts[1], "MMddyyyy", DateTimeFormatInfo.InvariantInfo);
				else if (parts[i].StartsWith("ENDDATE") )
					this.enddate = DateTime.ParseExact(subparts[1], "MMddyyyy", DateTimeFormatInfo.InvariantInfo);
				else if (parts[i].StartsWith("FILETYPE") )
					this.filetype = subparts[1];
				else if (parts[i].StartsWith("ALTMORGID") )
					this.morgid = Convert.ToInt32(subparts[1]);
				else if (parts[i].StartsWith("EVENTS") )
					this.process_events	= subparts[1] == "TRUE";
				else if (parts[i].StartsWith("REFERRALS") )
					this.process_referrals = subparts[1] == "TRUE";
			}
		}// end of method ParseTask()
		/// <summary>
		/// MakeTask()
		/// this method will create our task string from the properties
		/// of the class.
		/// </summary>
		protected override void MakeTask()
		{
			base.MakeTask();
			this.Task = this.task    + "," +
				"StartDate="         + this.startdate.ToString("MMddyyyy")   + "," +
				"EndDate="           + this.enddate.ToString("MMddyyyy")     + "," +
				"FileType="          + this.filetype    + "," +
				"AltMORGID="         + this.morgid.ToString() + "," +
				"Events="            + (this.process_events ? "true" : "false") + "," +
				"Referrals="         + (this.process_referrals ? "true" : "false");

		}// method MakeTask()

	}// end of class AuthorizationArguments


	[TableMapping(null)]
	public class CEExportArguments : TaskArguments
	{
		public CEExportArguments()
		{
		}
		public CEExportArguments(string sTask, string errorpath)
		{
			this.task			= sTask;
			this.ParseTask();
			this.errorlogpath	= errorpath;
		}
		protected int organizationid  = 0; // non specified, equivalent to 'all'
		protected DateTime startdate = DateTime.MinValue;
		protected DateTime enddate   = DateTime.MinValue;

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public DateTime StartDate
		{
			get {return startdate; }
			set {startdate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public DateTime EndDate
		{
			get {return enddate; }
			set {enddate = value; }
		}

		/// <summary>
		/// MakeTask()
		/// this method will create our task string from the properties
		/// of the class.
		/// </summary>
		protected override void MakeTask()
		{
			base.MakeTask();
			this.Task = this.task +  "," +
				   "ORGANIZATION="      + this.organizationid    + "," +
				   "STARTDATE=" + (StartDate == DateTime.MinValue ? "0" : StartDate.ToString("MMddyyyy") ) + "," + 
				   "ENDDATE="   + (StartDate == DateTime.MinValue ? "0" : EndDate.ToString("MMddyyyy") );
		}// method MakeTask()

		/// <summary>
		/// ParseTask()
		/// this method will populate the properties of the class
		/// from the task string.
		/// </summary>
		protected override void ParseTask()
		{
			if (task == null) return;
			const int maxparts = 15;
			char []comma			= {','};	// empty splitter
			char []equal            = {'='};
			string ucTask	= task.ToUpper();
			string[] parts = ucTask.Split(comma, maxparts);
			for(int i = 0; i < parts.Length; i++)
			{
				parts[i] = parts[i].ToUpper();
				string[] subparts = parts[i].Split(equal, 2);
				if (parts[i].StartsWith("FILENAME"))
					this.filename = subparts[1];
				else if (parts[i].StartsWith("ORGANIZATION") )
					this.organizationid	= Convert.ToInt32(subparts[1]);
				else if (parts[i].StartsWith("STARTDATE") )
				{
					if (subparts[1] == "0") // no date specified
						StartDate = DateTime.MinValue;
					else
						StartDate = DateTime.ParseExact(subparts[1], "MMddyyyy", DateTimeFormatInfo.InvariantInfo);
				}
				else if (parts[i].StartsWith("ENDDATE") )
				{
					if (subparts[1] == "0")
						EndDate = DateTime.MinValue;
					else
						EndDate  = DateTime.ParseExact(subparts[1], "MMddyyyy", DateTimeFormatInfo.InvariantInfo);
				}
			}
		}// end of method ParseTask()
	}// end of class CEExportArguments

	/// <summary>
	/// ScoringLoadArguments
	/// parses the task string into the arguments we need
	/// for a scoring load
	/// 
	/// "Filename=c:\\datafiles\icmload_3.txt,MORG=ALL,ORG=Anthem FEP,GenerateEnvelopes=NO,GenerateEnvelopesOnly=NO"
	/// </summary>
	public class ScoringLoadArguments : TaskArguments
	{
		#region variables
		protected string morg;
		protected string org;
		protected bool   generate_envelopes;
		protected bool   generate_envelopesonly;
		protected bool   scoringloadonly;
		#endregion

		public ScoringLoadArguments()
		{
		}

		public ScoringLoadArguments(string sTask, string errorpath)
		{
			this.task			= sTask;
			this.ParseTask();
			this.errorlogpath	= errorpath;
		}

		public string MORG
		{
			get { return morg; }
		}
		public string ORG
		{
			get { return org; }
		}

		[ControlType(EnumControlTypes.RadioButtonBox)]
		public bool GenerateEnvelopes
		{
			get { return generate_envelopes; }
			set { this.generate_envelopes = value; }
		}
		[ControlType(EnumControlTypes.RadioButtonBox)]
		public bool GenerateEnvelopesOnly
		{
			get {return this.generate_envelopesonly; }
			set {this.generate_envelopesonly = value; }
		}

		[ControlType(EnumControlTypes.RadioButtonBox)]
		public bool ScoringLoadOnly
		{
			get {return this.scoringloadonly; }
			set {this.scoringloadonly = value; }
		}

		/// <summary>
		/// MakeTask()
		/// this method will create our task string from the properties
		/// of the class.
		/// </summary>
		protected override void MakeTask()
		{
			base.MakeTask();
			this.task += "," + "GenerateEnvelopes="       + (this.generate_envelopes     ? "YES" : "NO") + "," +
				               "GenerateEnvelopesOnly="   + (this.generate_envelopesonly ? "YES" : "NO") + "," +
				               "ScoringLoadOnly="         + (this.scoringloadonly        ? "YES" : "NO") + "," +
				               "MORG="                    + this.morg                                    + "," +
				               "ORG="                     + this.org;
		}// method MakeTask()

		/// <summary>
		/// ParseTask()
		/// this method will populate the properties of the class
		/// from the task string.
		/// </summary>
		protected override void ParseTask()
		{
			if (task == null) return;
			base.ParseTask();
			const int maxparts = 15;
			char []comma			= {','};	// empty splitter
			char []equal            = {'='};
			string ucTask = task.ToUpper();
			string[] parts = ucTask.Split(comma, maxparts);
			for(int i = 0; i < parts.Length; i++)
			{
				parts[i] = parts[i].ToUpper();
				string[] subparts = parts[i].Split(equal, 2);
				if (parts[i].StartsWith("GENERATEENVELOPES=") )
					this.generate_envelopes	= (subparts[1] == "YES");
				else if (parts[i].StartsWith("GENERATEENVELOPESONLY") )
					this.generate_envelopesonly	= (subparts[1] == "YES");
				else if (parts[i].StartsWith("SCORINGLOADONLY") )
					this.scoringloadonly	= (subparts[1] == "YES");
				else if (parts[i].StartsWith("MORG") )
					this.morg  = subparts[1];
				else if (parts[i].StartsWith("ORG") )
					this.org	= subparts[1];
			}

		}// end of method ParseTask()
	}// end of class ScoringLoadArguments
	[TableMapping(null)]
	public class OrgName : BaseDataClass
	{

		public OrgName(int level, string desc)
		{
			OrgLevelID = level;
			Description = desc;
		}

		int orglevelid;
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OrgLevelID
		{
			get { return this.orglevelid; }
			set { this.orglevelid = value; }
		}
		private string description;
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get {return this.description; }
			set { this.description = value; }
		}

	}// end of class

	[ElementType(typeof(OrgName))]
	public class OrgNameCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		public OrgNameCollection()
		{
		}
	}

	[TableMapping(null)]
	public class MFLExportArguments : TaskArguments
	{
		public MFLExportArguments()
		{
		}
		public MFLExportArguments(string sTask, string errorpath)
		{
			this.task			= sTask;
			this.ParseTask();
			this.errorlogpath	= errorpath;
		}
		private DateTime startdate    = DateTime.MinValue;
		private DateTime enddate      = DateTime.MinValue;
		private int      letternumber = 0;

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LetterNumber
		{
			get {return letternumber;  }
			set {letternumber = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public DateTime StartDate
		{
			get {return startdate; }
			set {startdate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public DateTime EndDate
		{
			get {return enddate; }
			set {enddate = value; }
		}

		/// <summary>
		/// MakeTask()
		/// this method will create our task string from the properties
		/// of the class.
		/// </summary>
		protected override void MakeTask()
		{
			base.MakeTask();
			this.Task = this.task +  "," + 
                "LETTER="    + this.LetterNumber.ToString() + "," + 
				"STARTDATE=" + (StartDate == DateTime.MinValue ? "0" : StartDate.ToString("MMddyyyy") ) + "," + 
				"ENDDATE="   + (StartDate == DateTime.MinValue ? "0" : EndDate.ToString("MMddyyyy") );
		}// method MakeTask()

		/// <summary>
		/// ParseTask()
		/// this method will populate the properties of the class
		/// from the task string.
		/// </summary>
		protected override void ParseTask()
		{
			if (task == null) return;
			const int maxparts = 15;
			char []comma			= {','};	// empty splitter
			char []equal            = {'='};
			string[] parts = task.Split(comma, maxparts);
			for(int i = 0; i < parts.Length; i++)
			{
				parts[i] = parts[i].ToUpper();
				string[] subparts = parts[i].Split(equal, 2);
				if (parts[i].StartsWith("FILENAME"))
					this.filename = subparts[1];
				else if (parts[i].StartsWith("STARTDATE") )
				{
					if (subparts[1] == "0") // no date specified
						StartDate = DateTime.MinValue;
					else
						StartDate = DateTime.ParseExact(subparts[1], "MMddyyyy", DateTimeFormatInfo.InvariantInfo);
				}
				else if (parts[i].StartsWith("ENDDATE") )
				{
					if (subparts[1] == "0")
						EndDate = DateTime.MinValue;
					else
						EndDate  = DateTime.ParseExact(subparts[1], "MMddyyyy", DateTimeFormatInfo.InvariantInfo);
				}
				else if (parts[i].StartsWith("LETTER") )
				{
					this.LetterNumber = Convert.ToInt32(subparts[1]);
				}
			}
		}// end of method ParseTask()
	}// end of class MemberFileListArguments

}
