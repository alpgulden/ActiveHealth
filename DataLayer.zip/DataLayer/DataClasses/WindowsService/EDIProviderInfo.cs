using System;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Collections;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for EDIProviderInfo.
	/// </summary>
	[TableMapping("Provider", "providerID")]
	public class EDIProviderInfo : BaseData
	{
		[ColumnMapping("providerid",StereoType=DataStereoType.FK)]
		private int providerID;
		[ColumnMapping("locationid",StereoType=DataStereoType.FK)]
		private int locationID;
		[ColumnMapping("networkid",StereoType=DataStereoType.FK)]
		private int networkID;
		[ColumnMapping("networkstatus", ValueForNull=(int)-1)]
		private int networkstatus = -1;
		[ColumnMapping("specialtyid",StereoType=DataStereoType.FK)]
		private int specialtyID;

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ProviderID
		{
			get { return this.providerID; }
			set 
			{
				this.providerID = value;
			}
		}
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NetworkID
		{
			get { return this.networkID; }
			set 
			{
				this.networkID = value;
			}
		}
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LocationID
		{
			get { return this.locationID; }
			set 
			{
				this.locationID = value;
			}
		}
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1)]
		public int NetworkStatus
		{
			get { return this.networkstatus; }
			set 
			{
				this.networkstatus = value;
			}
		}
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SpecialtyID
		{
			get { return this.specialtyID; }
			set 
			{
				this.specialtyID = value;
			}
		}


		public EDIProviderInfo()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public bool LoadProviderInfo(int providerID, DateTime dateOfService, string providerType)
		{
//			this.Clear();
			return SqlData.SPExecReadObj("usp_GetDefaultProviderInfo", this, false, 
				new object[] { providerID, SQLDataDirect.MakeDBValue(dateOfService), providerType});
		}

	}// end of class

	[TableMapping(null)]
	public class X12Authorization : BaseDataClass
	{
		public X12Authorization()
		{
		}

		/// <summary>
		/// GenerateAutoActivites()
		/// This method will execute the specified stored procedure
		/// to create activities related to the rule 'X12A', which is the
		/// "X12 Authorization Request" rule type.
		/// 
		/// </summary>
		/// <param name="patientid"></param>
		/// <param name="patienteligibilityid"></param>
		/// <param name="patientsubscriberlogid"></param>
		/// <param name="eventid"></param>
		/// <param name="reviewid"></param>
		/// <param name="referralid"></param>
		/// <param name="referraldetailid"></param>
		/// <returns></returns>
		public int GenerateAutoActivites(int patientid, int patienteligibilityid, int patientsubscriberlogid, int eventid, int reviewid, int referralid, int referraldetailid)
		{
			return Convert.ToInt32( SqlData.SPExecScalar("usp_CreateX12AutoActivities", new object[] { patientid, patienteligibilityid, patientsubscriberlogid, 
																										 SQLDataDirect.MakeDBValue(eventid,0), 
																										 SQLDataDirect.MakeDBValue(reviewid,0), 
																										 SQLDataDirect.MakeDBValue(referralid,0), 
																										 SQLDataDirect.MakeDBValue(referraldetailid,0)
																									 } ) );
		}

	}// end of class
}
