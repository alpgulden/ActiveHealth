using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Team]
	/// </summary>
	[SPAutoGen("usp_GetAllTeams","SelectAll.sptpl","", InjectOrderBy="ORDER BY code")]
	[SPInsert("usp_InsertTeam")]
	[SPUpdate("usp_UpdateTeam")]
	[SPDelete("usp_DeleteTeam")]
	[SPLoad("usp_LoadTeam")]
	[TableMapping("Team","teamId")]
	public class Team : BaseData
	{
		[NonSerialized]
		private TeamCollection parentTeamCollection;
		[ColumnMapping("TeamId",(int)0)]
		private int teamId;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",(int)0)]
		private int modifiedBy;
		[ColumnMapping("Active")]
		private bool active = true;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("ReadOnly")]
		private bool readOnly;
		private TeamUserCollection teamUsers;
	
		public Team()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Team(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int TeamId
		{
			get { return this.teamId; }
			set { this.teamId = value; }
		}

		[FieldDescription("@CODEID@")]
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=8)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[FieldDescription("@CODEDESCRIPTION@")]
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[FieldDescription("@INACTIVECODE@")]	
		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool InActive
		{
			get { return !this.active; }
			set { this.active = !value; }
		}

		[FieldDescription("@NOTE@")]	
		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReadOnly
		{
			get { return this.readOnly; }
			set { this.readOnly = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent TeamCollection that contains this element
		/// </summary>
		public TeamCollection ParentTeamCollection
		{
			get
			{
				return this.parentTeamCollection;
			}
			set
			{
				this.parentTeamCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Child TeamUsers mapped to related rows of table TeamUser where [TeamId] = [TeamId]
		/// </summary>
		[SPLoadChild("usp_LoadTeamTeamUser", "teamId")]
		public TeamUserCollection TeamUsers
		{
			get { return this.teamUsers; }
			set
			{
				this.teamUsers = value;
				if (value != null)
					value.ParentTeam = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the TeamUsers collection
		/// </summary>
		public void LoadTeamUsers(bool forceReload)
		{
			this.teamUsers = (TeamUserCollection)TeamUserCollection.LoadChildCollection("TeamUsers", this, typeof(TeamUserCollection), teamUsers, forceReload, null);
		}

		/// <summary>
		/// Saves the TeamUsers collection
		/// </summary>
		public void SaveTeamUsers()
		{
			TeamUserCollection.SaveChildCollection(this.teamUsers, true);
		}

		/// <summary>
		/// Synchronizes the TeamUsers collection
		/// </summary>
		public void SynchronizeTeamUsers()
		{
			TeamUserCollection.SynchronizeChildCollection(this.teamUsers, true);
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{
				writer.AddHeaderLabelandValue("Team",this.code);
				writer.AddFieldsOnNewLine(this,"Description");
				//writer.AddFieldOnNewLine(this,"NotePad");
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int teamId)
		{
			return base.Load(teamId);
		}



	}

	/// <summary>
	/// Strongly typed collection of Team objects
	/// </summary>
	[ElementType(typeof(Team))]
	public class TeamCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_TeamId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Team elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentTeamCollection = this;
			else
				elem.ParentTeamCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Team elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Team this[int index]
		{
			get
			{
				return (Team)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Team)oldValue, false);
			SetParentOnElem((Team)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllTeams(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllTeams", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared TeamCollection which is cached in NSGlobal
		/// </summary>
		public static TeamCollection AllTeams
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				TeamCollection col = (TeamCollection)NSGlobal.EnsureCachedObject("AllTeams", typeof(TeamCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllTeams(-1);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on teamId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_TeamId
		{
			get
			{
				if (this.indexBy_TeamId == null)
					this.indexBy_TeamId = new CollectionIndexer(this, new string[] { "teamId" }, true);
				return this.indexBy_TeamId;
			}
			
		}

		/// <summary>
		/// Looks up by teamId and returns Code value.  Uses the IndexBy_TeamId indexer.
		/// </summary>
		public string Lookup_CodeByTeamId(int teamId)
		{
			return this.IndexBy_TeamId.LookupStringMember("Code", teamId);
		}
	}
}
