using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [TeamUser]
	/// </summary>
	[SPInsert("usp_InsertTeamUser")]
	[SPUpdate("usp_UpdateTeamUser")]
	[SPDelete("usp_DeleteTeamUser")]
	[SPLoad("usp_LoadTeamUser")]
	[TableMapping("TeamUser","teamId,userId",true)]
	public class TeamUser : BaseData
	{
		[NonSerialized]
		private TeamUserCollection parentTeamUserCollection;
		[ColumnMapping("TeamId",(int)0)]
		private int teamId;
		[ColumnMapping("UserId")]
		private int userId;
		[ColumnMapping("EffectiveDate",ValuesForNull.NullDateTime)]
		private DateTime effectiveDate;
		[ColumnMapping("TerminateTime",ValuesForNull.NullDateTime)]
		private DateTime terminateTime;
		[ColumnMapping("TerminationDate",ValuesForNull.NullDateTime)]
		private DateTime terminationDate;
		[ColumnMapping("TerminatedBy",(int)0)]
		private int terminatedBy;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",(int)0)]
		private int modifiedBy;

		private string loginName;
		private string name;
		private AAUser aAUser;
		private string code;
		private Team team;

		public TeamUser()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public TeamUser(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public TeamUser(int userId)
		{
			this.NewRecord();
			this.userId = userId;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int TeamId
		{
			get { return this.teamId; }
			set { this.teamId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int UserId
		{
			get { return this.userId; }
			set { this.userId = value; }
		}

		[FieldDescription("@EFFDATE@")]		
		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[FieldDescription("@TERMDATE@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate,IsRequired=true)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		public string LoginName
		{
			get
			{
				if (this.loginName == null)
					if(this.AAUser!=null)
						this.loginName = this.AAUser.LoginName;
					else
						this.loginName = "";
				return this.loginName; 
			}
			set{this.loginName = value;}
		}

		public string Name
		{
			get
			{
				if (this.name == null)
					if(this.AAUser!=null)
						this.name = this.AAUser.Name;
					else
						this.name = "";
				return this.name; 
			}
			set{this.name = value;}
		}

		public string Code
		{
			get
			{
				if (this.code == null)
					if(this.Team!=null)
						this.code = this.Team.Code;
					else
						this.code = "";
				return this.code; 
			}
			set{this.code = value;}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int teamId)
		{
			return base.Load(teamId);
		}

		/// <summary>
		/// Parent TeamUserCollection that contains this element
		/// </summary>
		public TeamUserCollection ParentTeamUserCollection
		{
			get
			{
				return this.parentTeamUserCollection;
			}
			set
			{
				this.parentTeamUserCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Loads and returns the associated problem.
		/// </summary>
		/// <returns></returns>
		public AAUser GetAAUser()
		{
			if (this.userId == 0)
				return null;
			AAUser aAUser = new AAUser();
			if (aAUser.Load(this.userId))
				return aAUser;
			else
				return null;
		}

		/// <summary>
		/// Returns the linked problem object.  This was either passed
		/// in the constructor, or it's loaded from the Problem table.
		/// </summary>
		public AAUser AAUser
		{
			get
			{
				if (this.aAUser == null)
				{
					// try to get the problem from the parent patientProblemCollection
					if (this.parentTeamUserCollection != null)
						this.aAUser = this.parentTeamUserCollection.ParentAAUser;
					// try to get the problem from the db
					if (this.aAUser == null)
						this.aAUser = GetAAUser();
				}
				return this.aAUser;
			}
		}

		/// <summary>
		/// Loads and returns the associated problem.
		/// </summary>
		/// <returns></returns>
		public Team GetTeam()
		{
			if (this.TeamId == 0)
				return null;
			Team team = new Team();
			if (team.Load(this.teamId))
				return team;
			else
				return null;
		}

		/// <summary>
		/// Returns the linked problem object.  This was either passed
		/// in the constructor, or it's loaded from the Problem table.
		/// </summary>
		public Team Team
		{
			get
			{
				if (this.team == null)
				{
					// try to get the problem from the parent patientProblemCollection
					if (this.parentTeamUserCollection != null)
						this.team = this.parentTeamUserCollection.ParentTeam;
					// try to get the problem from the db
					if (this.team == null)
						this.team = GetTeam();
				}
				return this.team;
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of TeamUser objects
	/// </summary>
	[ElementType(typeof(TeamUser))]
	public class TeamUserCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_TeamId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(TeamUser elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentTeamUserCollection = this;
			else
				elem.ParentTeamUserCollection = null;		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		protected override void OnClear()
		{
			foreach (TeamUser elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public TeamUser this[int index]
		{
			get
			{
				return (TeamUser)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((TeamUser)oldValue, false);
			SetParentOnElem((TeamUser)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Hashtable based index on teamId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_TeamId
		{
			get
			{
				if (this.indexBy_TeamId == null)
					this.indexBy_TeamId = new CollectionIndexer(this, new string[] { "teamId" }, true);
				return this.indexBy_TeamId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on teamId fields returns the object.  Uses the IndexBy_TeamId indexer.
		/// </summary>
		public TeamUser FindBy(int teamId)
		{
			return (TeamUser)this.IndexBy_TeamId.GetObject(teamId);
		}

		/// <summary>
		/// Parent Team that contains this collection
		/// </summary>
		public Team ParentTeam
		{
			get { return this.ParentDataObject as Team; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Team */ }
		}

		/// <summary>
		/// Parent AAUser that contains this collection
		/// </summary>
		public AAUser ParentAAUser
		{
			get { return this.ParentDataObject as AAUser; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AAUser */ }
		}
	}
}
