using System;
using System.Diagnostics;
using System.Collections;
using NetsoftUSA.DataLayer;
using ActiveAdvice.Messages;

namespace ActiveAdvice.DataLayer
{
	[SPLoad("usp_LoadOrganizationSummary")]
	[SPAutoGen("usp_GetOrganizationsByLevel","SelectAllByGivenArgs.sptpl","organizationLevelID")]
	[TableMapping("Organization","organizationID")]
	public class OrganizationSummary : BaseData
	{
		[NonSerialized]
		private OrganizationSummaryCollection parentOrganizationSummaryCollection;
		[ColumnMapping("OrganizationID",(int)0)]
		protected int organizationID;
		[ColumnMapping("OrganizationLevelID")]
		protected int organizationLevelID;
		[ColumnMapping("Name")]
		protected string name;
		[ColumnMapping("AlternateID")]
		private string alternateID;
		[ColumnMapping("ICMID")]
		private string iCMID;
		[ColumnMapping("ParentOrganizationID")]
		private int parentOrganizationID;

		private bool selected;

		public OrganizationSummary()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		public int ParentOrganizationID
		{
			get {return this.parentOrganizationID; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int OrganizationID
		{
			get { return this.organizationID; }
			set { this.organizationID = value; }	
		}

		public int OrganizationLevelID
		{
			get { return this.organizationLevelID; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		[FieldDescription("@ORGNAME@")]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		[FieldDescription("@ASSIGNED@")]
		[ControlType(EnumControlTypes.CheckBox)]
		public bool Selected
		{
			get { return this.selected;}
			set { this.selected = value;}
		}


		/// <summary>
		/// Parent OrganizationSummaryCollection that contains this element
		/// </summary>
		public OrganizationSummaryCollection ParentOrganizationSummaryCollection
		{
			get
			{
				return this.parentOrganizationSummaryCollection;
			}
			set
			{
				this.parentOrganizationSummaryCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Parent SecurityGroupOrganizationLevel that contains this object
		/// </summary>
		public SecurityGroupOrganizationLevel ParentSecurityGroupOrganizationLevel
		{
			get { return this.ParentDataObject as SecurityGroupOrganizationLevel; }
			set { this.ParentDataObject = value; /* parent is set when contained by a SecurityGroupOrganizationLevel */ }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string ICMID
		{
			get { return this.iCMID; }
			set { this.iCMID = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of OrganizationSummary objects
	/// </summary>
	[ElementType(typeof(OrganizationSummary))]
	public class OrganizationSummaryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_OrganizationID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OrganizationSummary elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOrganizationSummaryCollection = this;
			else
				elem.ParentOrganizationSummaryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OrganizationSummary elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OrganizationSummary this[int index]
		{
			get
			{
				return (OrganizationSummary)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OrganizationSummary)oldValue, false);
			SetParentOnElem((OrganizationSummary)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// GetOrganizationsByLevelICMflag
		/// Get the organizations by the level (i.e. 1=MORG, 2=ORG, 3=SORG) and
		/// only the organizations that have the "ICMID" field set to a non-null
		/// value. These are fields that are to be processed by our Scoring Load.
		/// </summary>
		/// <param name="maxRecords">=-1, then get all records</param>
		/// <param name="organizationLevelID">1=MORG, 2=ORG, 3=SORG</param>
		/// <returns></returns>
		public int GetOrganizationsByLevelICMflag(int maxRecords, int organizationLevelID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOrganizationsByLevelICMflag", maxRecords, this, false, organizationLevelID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetOrganizationsByLevel(int maxRecords, int organizationLevelID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOrganizationsByLevel", maxRecords, this, false, organizationLevelID);
		}

		public int GetValidOrganizationsByLevel(int maxRecords, int organizationLevelID, DateTime dtNow)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetValidOrganizationsByLevel", maxRecords, this, false, new object [] {organizationLevelID, dtNow} );
		}

		public int GetOrganizationsByLevelAndFilter(int maxRecords, int organizationLevelID,string filter)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOrganizationsByLevelAndFilter", maxRecords, this, false, organizationLevelID,filter);
		}

		public void SetSelectedOrganizationsFromCollection(SecurityGroupOrganizationLevelCollection orgLevels)
		{
			if(orgLevels.Count>0)
			{
				foreach (OrganizationSummary organizationSummary in this)
				{
					if (orgLevels.FindBy(organizationSummary.OrganizationID) != null)
						organizationSummary.Selected= true;
				}
			}
		}

		public override int AddRecord(BaseDataClass data)
		{
			int ret = base.AddRecord (data);
			ResetIndexers();
			return ret;
		}

		private void ResetIndexers()
		{
			indexBy_OrganizationID = null;
		}

		/// <summary>
		/// Hashtable based index on organizationID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_OrganizationID
		{
			get
			{
				if (this.indexBy_OrganizationID == null)
					this.indexBy_OrganizationID = new CollectionIndexer(this, new string[] { "organizationID" }, true);
				return this.indexBy_OrganizationID;
			}			
		}

		/// <summary>
		/// Hashtable based search on organizationID fields returns the object.  Uses the IndexBy_OrganizationID indexer.
		/// </summary>
		public OrganizationSummary FindBy(int organizationID)
		{
			ResetIndexers();
			return (OrganizationSummary)this.IndexBy_OrganizationID.GetObject(organizationID);
		}

	}
}