using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OrganizationFocuses]
	/// </summary>
	[SPInsert("usp_InsertOrganizationFocus")]
	[SPUpdate("usp_UpdateOrganizationFocus")]
	[SPDelete("usp_DeleteOrganizationFocus")]
	[SPLoad("usp_LoadOrganizationFocus")]
	[TableMapping("OrganizationFocus","organizationID,orgFocusCodeID",true)]
	public class OrganizationFocus : BaseData
	{
		[NonSerialized]
		private OrganizationFocusCollection parentOrganizationFocusCollection;
		[ColumnMapping("OrganizationID",StereoType=DataStereoType.FK)]
		private int organizationID = 0;
		[ColumnMapping("OrgFocusCodeID",StereoType=DataStereoType.FK)]
		private int orgFocusCodeID = 0;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
	
		public OrganizationFocus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public OrganizationFocus(int orgFocusCodeID)
		{
			this.NewRecord(); // initialize record state
			this.orgFocusCodeID = orgFocusCodeID;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OrganizationID
		{
			get { return this.organizationID; }
			set { this.organizationID = value; }
		}

		[FieldValuesMember("LookupOf_OrgFocusCodeID", "OrgFocusCodeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@ORGFOCUSCODE@")]
		public int OrgFocusCodeID
		{
			get { return this.orgFocusCodeID; }
			set { this.orgFocusCodeID = value; }
		}

		[FieldDescription("@DESCRIPTION@")]
		public string Description
		{
			get
			{
				OrgFocusCode focusCode = this.LookupOf_OrgFocusCodeID.FindBy(this.orgFocusCodeID);
				if (focusCode == null)
					return null;
				else
					return focusCode.Description;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int organizationID, int orgFocusCodeID)
		{
			return base.Load(organizationID, orgFocusCodeID);
		}

		/// <summary>
		/// Parent OrganizationFocusCollection that contains this element
		/// </summary>
		public OrganizationFocusCollection ParentOrganizationFocusCollection
		{
			get
			{
				return this.parentOrganizationFocusCollection;
			}
			set
			{
				this.parentOrganizationFocusCollection = value; // parent is set when added to a collection
			}
		}

		public OrgFocusCodeCollection LookupOf_OrgFocusCodeID
		{
			get
			{
				return OrgFocusCodeCollection.ActiveOrgFocusCodes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFields(this, "Description");
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of OrganizationFocus objects
	/// </summary>
	[ElementType(typeof(OrganizationFocus))]
	public class OrganizationFocusCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OrganizationFocus elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOrganizationFocusCollection = this;
			else
				elem.ParentOrganizationFocusCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OrganizationFocus elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OrganizationFocus this[int index]
		{
			get
			{
				return (OrganizationFocus)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OrganizationFocus)oldValue, false);
			SetParentOnElem((OrganizationFocus)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(OrganizationFocus elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((OrganizationFocus)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent Organization that contains this collection
		/// </summary>
		public Organization ParentOrganization
		{
			get { return this.ParentDataObject as Organization; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Organization */ }
		}
	}
}