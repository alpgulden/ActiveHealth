using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OrganizationContacts]
	/// </summary>
	[SPInsert("usp_InsertOrganizationContact")]
	[SPLoad("usp_LoadOrganizationContact")]
	[TableMapping("OrganizationContact","organizationID,contactID",true)]
	[TableLinkageAttribute(typeof(Organization), "organizationID", typeof(Contact), "contactID")]
	public class OrganizationContact : BaseLinkageClass
	{
		[NonSerialized]
		private OrganizationContactCollection parentOrganizationContactCollection;
		[ColumnMapping("OrganizationID",StereoType=DataStereoType.FK)]
		private int organizationID;
		[ColumnMapping("ContactID",StereoType=DataStereoType.FK)]
		private int contactID;
	
		public OrganizationContact()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OrganizationID
		{
			get { return this.organizationID; }
			set { this.organizationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ContactID
		{
			get { return this.contactID; }
			set { this.contactID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent OrganizationContactCollection that contains this element
		/// </summary>
		public OrganizationContactCollection ParentOrganizationContactCollection
		{
			get
			{
				return this.parentOrganizationContactCollection;
			}
			set
			{
				this.parentOrganizationContactCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of OrganizationContact objects
	/// </summary>
	[ElementType(typeof(OrganizationContact))]
	public class OrganizationContactCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OrganizationContact elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOrganizationContactCollection = this;
			else
				elem.ParentOrganizationContactCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OrganizationContact elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OrganizationContact this[int index]
		{
			get
			{
				return (OrganizationContact)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OrganizationContact)oldValue, false);
			SetParentOnElem((OrganizationContact)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Organization that contains this collection
		/// </summary>
		public Organization ParentOrganization
		{
			get { return this.ParentDataObject as Organization; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Organization */ }
		}
	}
}
