using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OrganizationLevels]
	/// The Organization Levels are defined once for the current database, and assumed unchanging.
	/// </summary>
	[SPInsert("usp_InsertOrganizationLevel")]
	[SPUpdate("usp_UpdateOrganizationLevel")]
	[SPDelete("usp_DeleteOrganizationLevel")]
	[SPAutoGen("usp_GetOrganizationLevels","SelectAll.sptpl","")]
	[SPLoad("usp_LoadOrganizationLevel")]
	[TableMapping("OrganizationLevel","organizationLevelID",true)]
	public class OrganizationLevel : BaseLookupWithNote
	{
		[NonSerialized]
		private OrganizationLevelCollection parentOrganizationLevelCollection;
		[ColumnMapping("OrganizationLevelID",StereoType=DataStereoType.FK)]
		private int organizationLevelID;

		[ColumnMapping("Notepad")]
		private string notepad;
		[ColumnMapping("CodePlural")]
		private string codePlural;
		[ColumnMapping("DescriptionPlural")]
		private string descriptionPlural;
	
		public OrganizationLevel()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OrganizationLevelID
		{
			get { return this.organizationLevelID; }
			set { this.organizationLevelID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int organizationLevelID)
		{
			return base.Load(organizationLevelID);
		}

		/// <summary>
		/// Parent OrganizationLevelCollection that contains this element
		/// </summary>
		public OrganizationLevelCollection ParentOrganizationLevelCollection
		{
			get
			{
				return this.parentOrganizationLevelCollection;
			}
			set
			{
				this.parentOrganizationLevelCollection = value; // parent is set when added to a collection
			}
		}

		public static int NumberOfLevels
		{
			get { return OrganizationLevelCollection.OrganizationLevels.Count; }
		}

		public static int MaxLevel
		{
			get { return OrganizationLevelCollection.OrganizationLevels[NumberOfLevels - 1].OrganizationLevelID; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=10)]
		public string CodePlural
		{
			get { return this.codePlural; }
			set { this.codePlural = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string DescriptionPlural
		{
			get { return this.descriptionPlural; }
			set { this.descriptionPlural = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of OrganizationLevel objects
	/// </summary>
	[ElementType(typeof(OrganizationLevel))]
	public class OrganizationLevelCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		[NonSerialized]
		private CollectionIndexer indexBy_OrganizationLevelID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OrganizationLevel elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOrganizationLevelCollection = this;
			else
				elem.ParentOrganizationLevelCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OrganizationLevel elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OrganizationLevel this[int index]
		{
			get
			{
				return (OrganizationLevel)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OrganizationLevel)oldValue, false);
			SetParentOnElem((OrganizationLevel)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadOrganizationLevels(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOrganizationLevels", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared OrganizationLevelCollection which is cached in NSGlobal
		/// </summary>
		public static OrganizationLevelCollection OrganizationLevels
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				OrganizationLevelCollection col = (OrganizationLevelCollection)NSGlobal.EnsureCachedObject("OrganizationLevels", typeof(OrganizationLevelCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadOrganizationLevels(-1);
				}
				return col;
			}			
		}

		/// <summary>
		/// Hashtable based index on organizationLevelID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_OrganizationLevelID
		{
			get
			{
				if (this.indexBy_OrganizationLevelID == null)
					this.indexBy_OrganizationLevelID = new CollectionIndexer(this, new string[] { "organizationLevelID" }, true);
				return this.indexBy_OrganizationLevelID;
			}
			
		}

		/// <summary>
		/// Looks up by organizationLevelID and returns Description value.  Uses the IndexBy_OrganizationLevelID indexer.
		/// </summary>
		public string Lookup_DescriptionByOrganizationLevelID(int organizationLevelID)
		{
			return this.IndexBy_OrganizationLevelID.LookupStringMember("Description", organizationLevelID);
		}

		/// <summary>
		/// Looks up by organizationLevelID and returns Code value.  Uses the IndexBy_OrganizationLevelID indexer.
		/// </summary>
		public string Lookup_CodeByOrganizationLevelID(int organizationLevelID)
		{
			return this.IndexBy_OrganizationLevelID.LookupStringMember("Code", organizationLevelID);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns OrganizationLevelID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_OrganizationLevelIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("OrganizationLevelID", code);
		}

		/// <summary>
		/// Hashtable based search on organizationLevelID fields returns the object.  Uses the IndexBy_OrganizationLevelID indexer.
		/// </summary>
		public OrganizationLevel FindBy(int organizationLevelID)
		{
			return (OrganizationLevel)this.IndexBy_OrganizationLevelID.GetObject(organizationLevelID);
		}
	}
}
