using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OrgFocusCodes]
	/// </summary>
	[SPAutoGen("usp_GetAllOrgFocusCodes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetOrgFocusCodesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetOrgFocusCodes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertOrgFocusCode")]
	[SPUpdate("usp_UpdateOrgFocusCode")]
	[SPDelete("usp_DeleteOrgFocusCode")]
	[SPLoad("usp_LoadOrgFocusCode")]
	[TableMapping("OrgFocusCode","orgFocusCodeID")]
	public class OrgFocusCode : BaseLookupWithNote
	{
		[NonSerialized]
		private OrgFocusCodeCollection parentOrgFocusCodeCollection;
		[ColumnMapping("OrgFocusCodeID",StereoType=DataStereoType.FK)]
		private int orgFocusCodeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public OrgFocusCode()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OrgFocusCodeID
		{
			get { return this.orgFocusCodeID; }
			set { this.orgFocusCodeID = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Parent OrgFocusCodeCollection that contains this element
		/// </summary>~
		public OrgFocusCodeCollection ParentOrgFocusCodeCollection
		{
			get
			{
				return this.parentOrgFocusCodeCollection;
			}
			set
			{
				this.parentOrgFocusCodeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of OrgFocusCode objects
	/// </summary>
	[ElementType(typeof(OrgFocusCode))]
	public class OrgFocusCodeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_orgFocusCodeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OrgFocusCode elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOrgFocusCodeCollection = this;
			else
				elem.ParentOrgFocusCodeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OrgFocusCode elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OrgFocusCode this[int index]
		{
			get
			{
				return (OrgFocusCode)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OrgFocusCode)oldValue, false);
			SetParentOnElem((OrgFocusCode)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Load all Organization Focus Codes
		/// </summary>
		public int LoadOrgFocusCodes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOrgFocusCodes", maxRecords, this, false);
		}

		/// <summary>
		/// Load all Organization Focus Codes that are active
		/// </summary>
		public int LoadActiveOrgFocusCodes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOrgFocusCodesByActive", maxRecords, this, false, new object[] { true });
		}

		/// <summary>
		/// Accessor to a shared OrgFocusCodeCollection which is cached in NSGlobal
		/// </summary>
		public static OrgFocusCodeCollection ActiveOrgFocusCodes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				OrgFocusCodeCollection col = (OrgFocusCodeCollection)NSGlobal.EnsureCachedObject("OrgFocusCodes", typeof(OrgFocusCodeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadActiveOrgFocusCodes(-1);
				}
				return col;
			}
		}

		/// <summary>
		/// Hashtable based index on orgFocusCodeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_orgFocusCodeID
		{
			get
			{
				if (this.indexBy_orgFocusCodeID == null)
					this.indexBy_orgFocusCodeID = new CollectionIndexer(this, new string[] { "orgFocusCodeID" }, true);
				return this.indexBy_orgFocusCodeID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on orgFocusCodeID fields returns the object.  Uses the IndexBy_orgFocusCodeID indexer.
		/// </summary>
		public OrgFocusCode FindBy(int orgFocusCodeID)
		{
			return (OrgFocusCode)this.IndexBy_orgFocusCodeID.GetObject(orgFocusCodeID);
		}

		/// <summary>
		///  Loads all Organization Focus Codes into collection.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllOrgFocusCodes", -1, this, false);
		}

		/// <summary>
		/// Searches for Organization Focus Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchOrgFocusCodes", -1, this, false, code, description, active);
		}
	}
}
