using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [MemberLives]
	/// </summary>
	[SPAutoGen("usp_SearchBySorgPlan","SearchByArgs.sptpl","sorgID, planID")]
	[SPAutoGen("usp_SearchMemberLive","SearchByArgs.sptpl","morgID, orgID, sorgID, planID")]
	[SPDelete("usp_DeleteMemberLive")]
	[SPUpdate("usp_UpdateMemberLive")]
	[SPInsert("usp_InsertMemberLive")]
	[SPLoad("usp_LoadMemberLive")]
	[TableMapping("MemberLives","memberLivesID")]
	public class MemberLive : BaseLetterMOSP
	{
		[NonSerialized]
		private MemberLiveCollection parentMemberLiveCollection;
		[ColumnMapping("MemberLivesID",StereoType=DataStereoType.FK)]
		private int memberLivesID;
		[ColumnMapping("NumberOfInsured",StereoType=DataStereoType.FK)]
		private int numberOfInsured;
		[ColumnMapping("DependentsRatio")]
		private double dependentsRatio;
		[ColumnMapping("TotalMembers",StereoType=DataStereoType.FK)]
		private int totalMembers;
		[ColumnMapping("MemberLivesSourceID",StereoType=DataStereoType.FK)]
		private int memberLivesSourceID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public MemberLive()
		{
			this.dependentsRatio = 2.3d;
			//this.numberOfInsured = 249;
		}

		public MemberLive(bool initNew) : this()
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int MemberLivesID
		{
			get { return this.memberLivesID; }
			set { this.memberLivesID = value; }
		}

		[FieldDescription("@INSUREDS@")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NumberOfInsured
		{
			get { return this.numberOfInsured; }
			set { this.numberOfInsured = value; }
		}

		[FieldDescription("@RATIO@")]
		[ControlType(Macro=EnumControlTypeMacros.Double, IsRequired=true)]
		public double DependentsRatio
		{
			get { return this.dependentsRatio; }
			set { this.dependentsRatio = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TotalMembers
		{
			get { return this.totalMembers; }
			set { this.totalMembers = value; }
		}

		[FieldDescription("@CASESOURCEID@")]
		[FieldValuesMember("LookupOf_MemberLivesSourceID", "MemberLivesSourceID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int MemberLivesSourceID
		{
			get { return this.memberLivesSourceID; }
			set { this.memberLivesSourceID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[FieldDescription("@MONTH@")]
		public String EffectiveDateForGridDisplay
		{
			get
			{
				return this.effectiveDate.ToString("MMM yyy");
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent MemberLiveCollection that contains this element
		/// </summary>
		public MemberLiveCollection ParentMemberLiveCollection
		{
			get
			{
				return this.parentMemberLiveCollection;
			}
			set
			{
				this.parentMemberLiveCollection = value; // parent is set when added to a collection
			}
		}

		public MemberLivesSourceCollection LookupOf_MemberLivesSourceID
		{
			get
			{
				return MemberLivesSourceCollection.ActiveMemberLivesSources; // Acquire a shared instance from the static member of collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of MemberLive objects
	/// </summary>
	[ElementType(typeof(MemberLive))]
	public class MemberLiveCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MemberLive elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMemberLiveCollection = this;
			else
				elem.ParentMemberLiveCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MemberLive elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MemberLive this[int index]
		{
			get
			{
				return (MemberLive)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MemberLive)oldValue, false);
			SetParentOnElem((MemberLive)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(MemberLive elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((MemberLive)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchMemberLive(int maxRecords, MemberLive searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchMemberLive", maxRecords, this, searcher, true);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchBySorgPlan(int maxRecords, int sorgID, int planID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchBySorgPlan", maxRecords, this, false, new object[] { sorgID, planID });
		}

		/// <summary>
		/// Verifies if Month of EffectiveDate of passed object is already present in collection.
		/// If not - adds object to collection
		/// </summary>
		/// <param name="dt"></param>
		/// <returns></returns>
		public bool IsEffectiveDateExist(MemberLive obj)
		{
			bool result = false;
			foreach(MemberLive ml in this)
			{
				if(!ml.IsMarkedForDeletion && ml.EffectiveDate.Month == obj.EffectiveDate.Month && ml != obj)
				{
					result = true;
					break;
				}
			}
			return result;
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}	
	}

	[TableMapping(null)]
	public class MemberLivesResultDateRange : BaseData
	{
		private DateTime dtStart;
		private DateTime dtEnd;

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		[FieldDescription("@FROM@")]
		public System.DateTime DtStart
		{
			get { return this.dtStart; }
			set { this.dtStart = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		[FieldDescription("@TO@")]
		public System.DateTime DtEnd
		{
			get { return this.dtEnd; }
			set { this.dtEnd = value; }
		}
	}

	[SPAutoGen("usp_CalculateMemberLivesBetweenDates", null, ManuallyManaged=true)]
	[SPAutoGen("usp_GetMemberLivesByYearMonth", null, ManuallyManaged=true)]
	[TableMapping(null,"year,month")]
	public class MemberLivesResult : BaseData
	{
		[NonSerialized]
		private MemberLivesResultCollection parentMemberLivesResultCollection;
		[ColumnMapping("Year",ValueForNull=(int)0)]
		private int year;
		[ColumnMapping("Month",ValueForNull=(int)0)]
		private int month;
		[ColumnMapping("Insureds",ValueForNull=(int)0)]
		private int insureds;
		[ColumnMapping("Members",ValueForNull=(int)0)]
		private int members;
		[ColumnMapping("Ratio")]
		private decimal ratio;

		[ControlType(Macro=EnumControlTypeMacros.Int)]//, ValueForNull=(int)0)]
		public int Year
		{
			get { return this.year; }
			set { this.year = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]//, ValueForNull=(int)0)]
		public int Month
		{
			get { return this.month; }
			set { this.month = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]//, ValueForNull=(int)0)]
		public int Insureds
		{
			get { return this.insureds; }
			set { this.insureds = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]//, ValueForNull=(int)0)]
		public int Members
		{
			get { return this.members; }
			set { this.members = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal Ratio
		{
			get { return this.ratio; }
			set { this.ratio = value; }
		}

		/// <summary>
		/// Parent MemberLivesResultCollection that contains this element
		/// </summary>
		public MemberLivesResultCollection ParentMemberLivesResultCollection
		{
			get
			{
				return this.parentMemberLivesResultCollection;
			}
			set
			{
				this.parentMemberLivesResultCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// For the given morg, org or sorg and date range, calculate member lives averages.
		/// </summary>
		public bool CalculateMemberLivesBetweenDates(int morgID, int orgID, int sorgID, DateTime dtStart, DateTime dtEnd)
		{
			return SqlData.SPExecReadObj("usp_CalculateMemberLivesBetweenDates", this, true, new object[] 
				{	SQLDataDirect.MakeDBValue(morgID, (int)0),
					SQLDataDirect.MakeDBValue(orgID, (int)0),
					SQLDataDirect.MakeDBValue(sorgID, (int)0),
					SQLDataDirect.MakeDBValue(dtStart),
					SQLDataDirect.MakeDBValue(dtEnd) });
		}

	
	}

	/// <summary>
	/// Strongly typed collection of MemberLivesResult objects
	/// </summary>
	[ElementType(typeof(MemberLivesResult))]
	public class MemberLivesResultCollection : BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MemberLivesResult elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMemberLivesResultCollection = this;
			else
				elem.ParentMemberLivesResultCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MemberLivesResult elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MemberLivesResult this[int index]
		{
			get
			{
				return (MemberLivesResult)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MemberLivesResult)oldValue, false);
			SetParentOnElem((MemberLivesResult)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// For the given morg, org or sorg, calcualte member lives averages grouped by year and month.
		/// </summary>
		public int GetMemberLivesByYearMonth(int morgID, int orgID, int sorgID)
		{
			return SqlData.SPExecReadCol("usp_GetMemberLivesByYearMonth", -1, this, true, new object[] 
				{
					SQLDataDirect.MakeDBValue(morgID, (int)0), 
					SQLDataDirect.MakeDBValue(orgID, (int)0), 
					SQLDataDirect.MakeDBValue(sorgID, (int)0) });
		}
	}

}
