using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PlanSORGs]
	/// Multiple plans can be linked to an organization.  This data class
	/// is the linkage information between an organization and a plan.  Organization
	/// holds a collection of PlanSORG instances loaded from its child table
	/// PlanSORGs.
	/// </summary>
	[SPAutoGen("usp_GetPlanSORGByIDs","SelectAllByGivenArgs.sptpl","sORGID, planId")]
	[SPInsert("usp_InsertPlanSORG")]
	[SPUpdate("usp_UpdatePlanSORG")]
	[SPDelete("usp_DeletePlanSORG")]
	[SPLoad("usp_LoadPlanSORG")]
	[TableMapping("PlanSORG","planSORGID")]
	public class PlanSORG : BaseData
	{
		[NonSerialized]
		private PlanSORGCollection parentPlanSORGCollection;
		[ColumnMapping("PlanSORGID",StereoType=DataStereoType.FK)]
		private int planSORGID;
		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)]
		private int planId;
		[ColumnMapping("SORGID",StereoType=DataStereoType.FK)]
		private int sORGID;
		[ColumnMapping("AltGroupID")]
		private string altGroupID;
		[ColumnMapping("AltPlanID")]
		private string altPlanID;
		[ColumnMapping("AltPlanName")]
		private string altPlanName;
		//[ColumnMapping("DefaultPlan")]
		//private bool defaultPlan;
		[ColumnMapping("CheckEligibility")]
		private bool checkEligibility;
		[ColumnMapping("EligibilityAddAnyway")]
		private bool eligibilityAddAnyway;
		[ColumnMapping("DRGType",StereoType=DataStereoType.FK)]
		private int dRGType;
		[ColumnMapping("DRGVersion")]
		private string dRGVersion;
		//[ColumnMapping("RegionID",StereoType=DataStereoType.FK)]
		//private int regionID;
		[ColumnMapping("PayorGroupID",StereoType=DataStereoType.FK)]
		private int payorGroupID;
		[ColumnMapping("GuidelineSourceSet",StereoType=DataStereoType.FK)]
		private int guidelineSourceSet;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("NumberOfInsured")]
		private int numberOfInsured;
		[ColumnMapping("DependentsRatio")]
		private Decimal dependentsRatio;
		[ColumnMapping("TotalMembers")]
		private int totalMembers;
		[ColumnMapping("Source")]
		private int source;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("LOSRegion",StereoType=DataStereoType.FK)]
		private int lOSRegion;
		[ColumnMapping("LOSYear")]
		private string lOSYear;
		
		[ColumnMapping("PlanName", JoinColumn="Name", JoinRelation="PlanSORG.PlanId = [Plan].PlanId", SQLGen=SQLGenerationFlags.NoInsert|SQLGenerationFlags.NoUpdate|SQLGenerationFlags.NoSelect)]
		private string planName;

		// The linked plan
		private Plan plan;
		private Organization sorg;

		private DateTime termDateWhenLoaded;
	
		public PlanSORG()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PlanSORG(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public PlanSORG(Organization sorg, Plan plan)
		{
			this.NewRecord(); // initialize record state
			if (sorg == null)
				throw new Exception("A sub-organization must be passed to PlanSORG");
			if (plan == null)
				throw new Exception("A plan must be passed to PlanSORG");
			if (!sorg.IsSubOrganization)
				throw new Exception("The organization passed PlanSORG is not a sub-organization");
			this.sorg = sorg;
			this.sORGID = sorg.OrganizationID;
			this.plan = plan;
			this.planId = plan.PlanId;
		}

		public PlanSORG(Organization sorg, int planID)
		{
			this.NewRecord();
			if (sorg == null)
				throw new Exception("A sub-organization must be passed to PlanSORG");
			if (!sorg.IsSubOrganization)
				throw new Exception("The organization passed PlanSORG is not a sub-organization");
			this.sorg = sorg;
			this.sORGID = sorg.OrganizationID;
			this.planId = planID;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int PlanSORGID
		{
			get { return this.planSORGID; }
			set { this.planSORGID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PlanId
		{
			get { return this.planId; }
			set 
			{ 
				this.planId = value; 
				this.plan = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SORGID
		{
			get { return this.sORGID; }
			set 
			{ 
				this.sORGID = value; 
				this.sorg = null;
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AltGroupID
		{
			get { return this.altGroupID; }
			set { this.altGroupID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AltPlanID
		{
			get { return this.altPlanID; }
			set { this.altPlanID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string AltPlanName
		{
			get 
			{ return this.altPlanName; }
			set { this.altPlanName = value; }
		}

		//[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		//public bool DefaultPlan
		//{
		//	get { return this.defaultPlan; }
		//	set { this.defaultPlan = value; }
		//}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool CheckEligibility
		{
			get { return this.checkEligibility; }
			set { this.checkEligibility = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool EligibilityAddAnyway
		{
			get { return this.eligibilityAddAnyway; }
			set { this.eligibilityAddAnyway = value; }
		}

		[FieldValuesMember("LookupOf_DRGType", "CodeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int DRGType
		{
			get { return this.dRGType; }
			set { this.dRGType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string DRGVersion
		{
			get { return this.dRGVersion; }
			set { this.dRGVersion = value; }
		}

		//[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		//public int RegionID
		//{
		//	get { return this.regionID; }
		//	set { this.regionID = value; }
		//}

		[FieldValuesMember("LookupOf_PayorGroupID", "LengthOfStayPayorGroupID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int PayorGroupID
		{
			get { return this.payorGroupID; }
			set { this.payorGroupID = value; }
		}

		[FieldValuesMember("LookupOf_GuidelineSourceSet", "GuidelineSourceSetID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int GuidelineSourceSet
		{
			get { return this.guidelineSourceSet; }
			set { this.guidelineSourceSet = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NumberOfInsured
		{
			get { return this.numberOfInsured; }
			set { this.numberOfInsured = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal DependentsRatio
		{
			get { return this.dependentsRatio; }
			set { this.dependentsRatio = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TotalMembers
		{
			get { return this.totalMembers; }
			set { this.totalMembers = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Source
		{
			get { return this.source; }
			set { this.source = value; }
		}

		[FieldValuesMember("LookupOf_LOSRegion", "HciaRegionid", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int LOSRegion
		{
			get { return this.lOSRegion; }
			set { this.lOSRegion = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string LOSYear
		{
			get { return this.lOSYear; }
			set { this.lOSYear = value; }
		}

		/// <summary>
		/// Parent PlanSORGCollection that contains this element
		/// </summary>
		public PlanSORGCollection ParentPlanSORGCollection
		{
			get
			{
				return this.parentPlanSORGCollection;
			}
			set
			{
				this.parentPlanSORGCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Get the linked plan directly from db
		/// </summary>
		/// <returns></returns>
		public Plan GetLinkedPlan()
		{
			if (planId == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.planId))
				return plan;
			else
				return null;
		}

		public Organization GetSORG()
		{
			if (sORGID == 0)
				return null;
			Organization sorg = new Organization();
			if (sorg.Load(this.sORGID))
				return sorg;
			else
				return null;
		}

		/// <summary>
		/// Get the linked plan and cache it.
		/// </summary>
		public Plan Plan
		{
			get
			{
				if (this.plan == null)
					this.plan = this.GetLinkedPlan();
				return this.plan;
			}
		}

		public Organization SORG
		{
			get
			{
				if (this.sorg == null)
				{
					// try to get the sorg from the parent collection
					if (this.parentPlanSORGCollection != null)
						this.sorg = this.parentPlanSORGCollection.ParentOrganization;
					
					// try to get the sorg from the db
					if (this.sorg == null)
						this.sorg = this.GetSORG();
				}
				return this.sorg;
			}
		}

		// This is a joined column coming from Plans table.
		[ControlType(EnumControlTypes.TextBox)]
		public string PlanName
		{
			get 
			{ 
				if (this.planName == null)
				{
					// load from Plans
					Plan plan = this.Plan;
					if (plan != null)
						this.planName = plan.Name;
				}
				return this.planName; 
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			this.sorg = null;
			this.plan = null;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		public DRGTypeCollection LookupOf_DRGType
		{
			get
			{
				return DRGTypeCollection.ActiveDRGTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public LengthOfStayRegionCollection LookupOf_LOSRegion
		{
			get
			{
				return LengthOfStayRegionCollection.ActiveLengthOfStayRegions; // Acquire a shared instance from the static member of collection
			}
		}

		public LengthOfStayPayorGroupCollection LookupOf_PayorGroupID
		{
			get
			{
				return LengthOfStayPayorGroupCollection.ActiveLengthOfStayPayorGroups; // Acquire a shared instance from the static member of collection
			}
		}

		public GuidelineSourceSetCollection LookupOf_GuidelineSourceSet
		{
			get
			{
				return GuidelineSourceSetCollection.ActiveGuidelineSourceSets; // Acquire a shared instance from the static member of collection
			}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFields(this, "PlanName");
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}

			base.InternalSave();
			
			// add a plan SORG log
			// check for change

			KeepPlanSORGLog();

			// Save the child collections here.
		}

		public PlanSORGLog CreateLogObject()
		{
			return new PlanSORGLog(this.Plan, this);
		}

		public void KeepPlanSORGLog()
		{
			bool logEntryRequired = false;
			
			PlanSORGLog log = this.CreateLogObject();
			PlanSORGLog lastLog = PlanSORGLog.GetLastPlanSORGLogEntry(this.SqlData.Transaction, this.planId, this.sORGID);

			if (lastLog == null)		// no log entry found.
				logEntryRequired = true;
			else
			{
				// a log entry was found.
				// Check if anything changed.

				string[] excludedMembers = CollectionUtil.JoinArrays(log.PKFields, new string[] { "creationDate", "sORGCreateTime", "sORGModifyTime" } );
				if (!log.EqualsMappedMembers(lastLog, false, excludedMembers ))
					logEntryRequired = true;	// the log entry to be created has changed.
			}

			if (logEntryRequired)
			{
				// a log entry must be created
				log.SqlData.Transaction = this.SqlData.Transaction;
				log.Save();
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadPlanSORGByIDs(int sORGID, int planId)
		{
			return SqlData.SPExecReadObj("usp_GetPlanSORGByIDs", this, false, new object[] { sORGID, planId });
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		// FORK 1.1
		public string HCIA_LOSRegion
		{
			get { return LengthOfStayRegionCollection.ActiveLengthOfStayRegions.Lookup_HciaRegionByHciaRegionid(this.lOSRegion ); }
			set { this.lOSRegion = LengthOfStayRegionCollection.ActiveLengthOfStayRegions.Lookup_HciaRegionidByHciaRegion(value); }
		}

		public string HCIA_PayorGroup
		{
			get { return LengthOfStayPayorGroupCollection.ActiveLengthOfStayPayorGroups.Lookup_HCIAGroupByLengthOfStayPayorGroupID(this.payorGroupID ); }
			set { this.payorGroupID = LengthOfStayPayorGroupCollection.ActiveLengthOfStayPayorGroups.Lookup_LengthOfStayPayorGroupIDByHCIAGroup(value); }
		}

		public string HCIA_PayorGroupWithCode
		{
			get 
			{ 
				return LengthOfStayPayorGroupCollection.ActiveLengthOfStayPayorGroups.Lookup_HCIAGroupByLengthOfStayPayorGroupID(this.payorGroupID) 
					+ "-"+ LengthOfStayPayorGroupCollection.ActiveLengthOfStayPayorGroups.Lookup_CodeByLengthOfStayPayorGroupID(this.payorGroupID);
			}
		}

		public string HCIA_LOSRegionWithCode
		{
			get 
			{ 
				return LengthOfStayRegionCollection.ActiveLengthOfStayRegions.Lookup_HciaRegionByHciaRegionid(this.lOSRegion)
					+ "-" + LengthOfStayRegionCollection.ActiveLengthOfStayRegions.Lookup_CodeByHciaRegionid(this.lOSRegion);
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int planSORGID)
		{
			return base.Load(planSORGID);
		}
		// END FORK 1.1
	}

	/// <summary>
	/// Strongly typed collection of PlanSORG objects
	/// </summary>
	[ElementType(typeof(PlanSORG))]
	public class PlanSORGCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PlanSORGID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PlanSORG elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPlanSORGCollection = this;
			else
				elem.ParentPlanSORGCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PlanSORG elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PlanSORG this[int index]
		{
			get
			{
				return (PlanSORG)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PlanSORG)oldValue, false);
			SetParentOnElem((PlanSORG)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PlanSORG elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PlanSORG)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Hashtable based index on planSORGID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PlanSORGID
		{
			get
			{
				if (this.indexBy_PlanSORGID == null)
					this.indexBy_PlanSORGID = new CollectionIndexer(this, new string[] { "planSORGID" }, true);
				return this.indexBy_PlanSORGID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on planSORGID fields returns the object.  Uses the IndexBy_PlanSORGID indexer.
		/// </summary>
		public PlanSORG FindBy(int planSORGID)
		{
			return (PlanSORG)this.IndexBy_PlanSORGID.GetObject(planSORGID);
		}

		/// <summary>
		/// Parent Organization that contains this collection
		/// </summary>
		public Organization ParentOrganization
		{
			get { return this.ParentDataObject as Organization; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Organization */ }
		}
	}
}
