using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Implements utility functions like:
	///   Update MemberLives from Eligibility
	///	  MemberLives Rollover.
	///	The properties can be bound to utility from data entry fields.
	/// </summary>
	[TableMapping("MemberLives",null)]
	public class MemberLivesUtility : BaseData
	{
		private DateTime fromDate;
		private DateTime toDate;

		private DateTime rolloverSrcDate;
		private DateTime rolloverDstDate;


		// We ask the user the month and year

		public MemberLivesUtility()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Update the member lives table from the eligibility.
		/// The given date range is used to filter plans in eligibility.
		/// </summary>
		public int UpdateMemberLivesFromEligibility(DateTime fromDate, DateTime toDate)
		{
			// Set 1st day for fromDate, and last day for the toDate
			fromDate = NSGlobal.GetBeginningOfMonth(fromDate);
			toDate = NSGlobal.GetBeginOfNextMonth(toDate);
			
			return SqlData.SPExecNonQuery("usp_UpdateMemberLivesFromEligibility", 
				AASecurityHelper.GetUserId, fromDate, toDate);
		}

		public int UpdateMemberLivesFromEligibility()
		{
			return this.UpdateMemberLivesFromEligibility(this.fromDate, this.toDate);
		}

		/// <summary>
		/// Copy all the member lives records with EffectiveDate = srcDate to dstDate.
		/// The dates are matched by day granularity (hours/mins/secs not included).
		/// Returns the number of effected records.
		/// </summary>
		public int RolloverMemberLives(DateTime srcDate, DateTime dstDate)
		{
			// Set 1st day for fromDate, and last day for the toDate
			srcDate = NSGlobal.GetBeginningOfMonth(srcDate);
			dstDate = NSGlobal.GetBeginningOfMonth(dstDate);

			return SqlData.SPExecNonQuery("usp_RolloverMemberLives", 
				AASecurityHelper.GetUserId, srcDate, dstDate);
		}

		public int RolloverMemberLives()
		{
			return this.RolloverMemberLives(this.rolloverSrcDate, this.rolloverDstDate);
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, ClientValidators=EnumClientValidators.Required)]
		public System.DateTime FromDate
		{
			get { return this.fromDate; }
			set { this.fromDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, ClientValidators=EnumClientValidators.Required)]
		public System.DateTime ToDate
		{
			get { return this.toDate; }
			set { this.toDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, ClientValidators=EnumClientValidators.Required)]
		public System.DateTime RolloverSrcDate
		{
			get { return this.rolloverSrcDate; }
			set { this.rolloverSrcDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, ClientValidators=EnumClientValidators.Required)]
		public System.DateTime RolloverDstDate
		{
			get { return this.rolloverDstDate; }
			set { this.rolloverDstDate = value; }
		}
	}
}
