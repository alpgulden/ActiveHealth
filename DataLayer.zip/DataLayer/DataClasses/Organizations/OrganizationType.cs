using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OrganizationTypes]
	/// </summary>
	/// 
	[SPAutoGen("usp_GetOrganizationTypesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetAllOrganizationTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertOrganizationType")]
	[SPUpdate("usp_UpdateOrganizationType")]
	[SPDelete("usp_DeleteOrganizationType")]
	[SPLoad("usp_LoadOrganizationType")]
	[TableMapping("OrganizationType","organizationTypeID")]
	public class OrganizationType : BaseLookupWithNote
	{
		[NonSerialized]
		private OrganizationTypeCollection parentOrganizationTypeCollection;
		[ColumnMapping("OrganizationTypeID",StereoType=DataStereoType.FK)]
		private int organizationTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public OrganizationType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OrganizationTypeID
		{
			get { return this.organizationTypeID; }
			set { this.organizationTypeID = value; }
		}

		/// <summary>
		/// Parent OrganizationTypeCollection that contains this element
		/// </summary>
		public OrganizationTypeCollection ParentOrganizationTypeCollection
		{
			get
			{
				return this.parentOrganizationTypeCollection;
			}
			set
			{
				this.parentOrganizationTypeCollection = value; // parent is set when added to a collection
			}
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of OrganizationType objects
	/// </summary>
	[ElementType(typeof(OrganizationType))]
	public class OrganizationTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_OrganizationTypeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OrganizationType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOrganizationTypeCollection = this;
			else
				elem.ParentOrganizationTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OrganizationType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OrganizationType this[int index]
		{
			get
			{
				return (OrganizationType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OrganizationType)oldValue, false);
			SetParentOnElem((OrganizationType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		///  Loads all Organization Types into collection.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllOrganizationTypes", -1, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveOrganizationTypes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOrganizationTypesByActive", maxRecords, this, false, new object[] { true });
		}

		/// <summary>
		/// Accessor to a shared OrganizationTypeCollection which is cached in NSGlobal
		/// </summary>
		public static OrganizationTypeCollection ActiveOrganizationTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				OrganizationTypeCollection col = (OrganizationTypeCollection)NSGlobal.EnsureCachedObject("ActiveOrganizationTypes", typeof(OrganizationTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadActiveOrganizationTypes(-1);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Searches for Organization Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchOrganizationTypes", -1, this, false, code, description, active);
		}

		/// <summary>
		/// Hashtable based index on organizationTypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_OrganizationTypeID
		{
			get
			{
				if (this.indexBy_OrganizationTypeID == null)
					this.indexBy_OrganizationTypeID = new CollectionIndexer(this, new string[] { "organizationTypeID" }, true);
				return this.indexBy_OrganizationTypeID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on organizationTypeID fields returns the object.  Uses the IndexBy_OrganizationTypeID indexer.
		/// </summary>
		public OrganizationType FindBy(int organizationTypeID)
		{
			return (OrganizationType)this.IndexBy_OrganizationTypeID.GetObject(organizationTypeID);
		}
	}
}
