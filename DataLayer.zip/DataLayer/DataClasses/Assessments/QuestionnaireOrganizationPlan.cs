using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [QuestionnaireOrganizationPlan]
	/// </summary>
	[SPAutoGen("usp_SearchQuestionnaireOrganizationPlans","SelectAllByGivenArgs.sptpl","contentOwnerID, sORGID, planID")]
	[SPInsert("usp_InsertQuestionnaireOrganizationPlan")]
	[SPUpdate("usp_UpdateQuestionnaireOrganizationPlan")]
	[SPDelete("usp_DeleteQuestionnaireOrganizationPlan")]
	[SPLoad("usp_LoadQuestionnaireOrganizationPlan")]
	[TableMapping("QuestionnaireOrganizationPlan","questionnaireOrganizationPlanID")]
	public class QuestionnaireOrganizationPlan : BaseData
	{
		[NonSerialized]
		private QuestionnaireOrganizationPlanCollection parentQuestionnaireOrganizationPlanCollection;
		[ColumnMapping("QuestionnaireOrganizationPlanID",StereoType=DataStereoType.FK)]
		private int questionnaireOrganizationPlanID;
		[ColumnMapping("QuestionnaireID",StereoType=DataStereoType.FK)]
		private int questionnaireID;
		[ColumnMapping("SORGID",StereoType=DataStereoType.FK)]
		private int sORGID;
		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
		private int planID;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		private int contentOwnerID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public QuestionnaireOrganizationPlan()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public QuestionnaireOrganizationPlan(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int QuestionnaireOrganizationPlanID
		{
			get { return this.questionnaireOrganizationPlanID; }
			set { this.questionnaireOrganizationPlanID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		[FieldDescription("@QUESTIONNAIRE@")]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@SUBORGANIZATION@")]
		public int SORGID
		{
			get { return this.sORGID; }
			set { this.sORGID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@PLAN@")]
		public int PlanID
		{
			get { return this.planID; }
			set { this.planID = value; }
		}

		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent QuestionnaireOrganizationPlanCollection that contains this element
		/// </summary>
		public QuestionnaireOrganizationPlanCollection ParentQuestionnaireOrganizationPlanCollection
		{
			get
			{
				return this.parentQuestionnaireOrganizationPlanCollection;
			}
			set
			{
				this.parentQuestionnaireOrganizationPlanCollection = value; // parent is set when added to a collection
			}
		}

		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of QuestionnaireOrganizationPlan objects
	/// </summary>
	[ElementType(typeof(QuestionnaireOrganizationPlan))]
	public class QuestionnaireOrganizationPlanCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_QuestionnaireID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(QuestionnaireOrganizationPlan elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentQuestionnaireOrganizationPlanCollection = this;
			else
				elem.ParentQuestionnaireOrganizationPlanCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (QuestionnaireOrganizationPlan elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public QuestionnaireOrganizationPlan this[int index]
		{
			get
			{
				return (QuestionnaireOrganizationPlan)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((QuestionnaireOrganizationPlan)oldValue, false);
			SetParentOnElem((QuestionnaireOrganizationPlan)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetQuestionnaireOrganizationPlans(int maxRecords, QuestionnaireOrganizationPlan searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchQuestionnaireOrganizationPlans", maxRecords, this, searcher, false);
		}

		/// <summary>
		/// Hashtable based index on questionnaireID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionnaireID
		{
			get
			{
				if (this.indexBy_QuestionnaireID == null)
					this.indexBy_QuestionnaireID = new CollectionIndexer(this, new string[] { "questionnaireID" }, true);
				return this.indexBy_QuestionnaireID;
			}
			
		}

		public void SynchronizeQuestionnairesFromSelectableCollection(int questionnaireID, QuestionnaireCollection questionnaires, int sORGID, int planID)
		{
			QuestionnaireOrganizationPlan  existingQuestionnaireOrganizationPlan = null;

			foreach (Questionnaire questionnaire in questionnaires)
			{
				if (((SelectableQuestionnaire)questionnaire).Selected)
				{
					existingQuestionnaireOrganizationPlan = this.FindBy(questionnaire.QuestionnaireID);
					if (existingQuestionnaireOrganizationPlan == null)
					{
						QuestionnaireOrganizationPlan questionnaireOrganizationPlan = null;
						questionnaireOrganizationPlan = new QuestionnaireOrganizationPlan(true);
						questionnaireOrganizationPlan.QuestionnaireID = questionnaireID;
						questionnaireOrganizationPlan.SORGID = sORGID;
						questionnaireOrganizationPlan.PlanID = planID;
						questionnaireOrganizationPlan.ContentOwnerID = questionnaire.ContentOwnerID;
						this.AddRecord(questionnaireOrganizationPlan);
					}
					else if (existingQuestionnaireOrganizationPlan.IsMarkedForDeletion)
					{
						existingQuestionnaireOrganizationPlan.IsMarkedForDeletion = false;
					}
				}
			}

			foreach (QuestionnaireOrganizationPlan questionnaireOrganizationPlan in this)
			{
				Questionnaire questionnaire = null;
				questionnaire = questionnaires.FindBy(questionnaireOrganizationPlan.QuestionnaireID);
				if (!((SelectableQuestionnaire)questionnaire).Selected)
				{
					questionnaireOrganizationPlan.MarkDel();
				}
			}
		}

		public override int AddRecord(BaseDataClass data)
		{
			int ret = base.AddRecord (data);
			// Rebuild indexers
			// TODO: Remove this when the library automatically supports this feature
			indexBy_QuestionnaireID.Rebuild();
			return ret;
		}

		/// <summary>
		/// Hashtable based search on questionnaireID fields returns the object.  Uses the IndexBy_QuestionnaireID indexer.
		/// </summary>
		public QuestionnaireOrganizationPlan FindBy(int questionnaireID)
		{
			return (QuestionnaireOrganizationPlan)this.IndexBy_QuestionnaireID.GetObject(questionnaireID);
		}
	}
}
