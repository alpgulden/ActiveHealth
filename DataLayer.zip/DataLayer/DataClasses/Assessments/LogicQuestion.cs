using System;
using System.Collections;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [AssessmentQuestionnaireOrder]
	/// </summary>
	[SPInsert("usp_InsertLogicQuestion")]
	[SPDelete("usp_DeleteLogicQuestion")]
	[SPLoad("usp_LoadLogicQuestion")]
	[TableMapping("LogicQuestion","logicID,questionID",true)]
	public class LogicQuestion : BaseData
	{
		[NonSerialized]
		private LogicQuestionCollection parentLogicQuestionCollection;
		[ColumnMapping("LogicID",StereoType=DataStereoType.FK)]
		private int logicID;
		[ColumnMapping("QuestionID",StereoType=DataStereoType.FK)]
		private int questionID;
	
		public LogicQuestion() : base()
		{
		}

		public LogicQuestion(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LogicID
		{
			get { return this.logicID; }
			set { this.logicID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionID
		{
			get { return this.questionID; }
			set { this.questionID = value; }
		}

		/// <summary>
		/// Parent LogicQuestionCollection that contains this element
		/// </summary>
		public LogicQuestionCollection ParentLogicQuestionCollection
		{
			get
			{
				return this.parentLogicQuestionCollection;
			}
			set
			{
				this.parentLogicQuestionCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}


	}

	/// <summary>
	/// Strongly typed collection of LogicQuestion objects
	/// </summary>
	[ElementType(typeof(LogicQuestion))]
	public class LogicQuestionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_QuestionID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LogicQuestion elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLogicQuestionCollection = this;
			else
				elem.ParentLogicQuestionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LogicQuestion elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LogicQuestion this[int index]
		{
			get
			{
				return (LogicQuestion)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LogicQuestion)oldValue, false);
			SetParentOnElem((LogicQuestion)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Hashtable based index on questionID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionID
		{
			get
			{
				if (this.indexBy_QuestionID == null)
					this.indexBy_QuestionID = new CollectionIndexer(this, new string[] { "questionID" }, true);
				return this.indexBy_QuestionID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on questionID fields returns the object.  Uses the IndexBy_QuestionID indexer.
		/// </summary>
		public LogicQuestion FindBy(int questionID)
		{
			return (LogicQuestion)this.IndexBy_QuestionID.GetObject(questionID);
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Parent Logic that contains this collection
		/// </summary>
		public Logic ParentLogic
		{
			get { return this.ParentDataObject as Logic; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Logic */ }
		}
	}
}
