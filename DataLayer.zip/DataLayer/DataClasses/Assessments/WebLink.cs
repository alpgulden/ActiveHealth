using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	public class SelectableWebLink : WebLink
	{
		private bool selected;

		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}
	} 
	
	
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_GetAllWebLinkssByInterventionTemplateID","SelectRelatedFromLinkedTable.sptpl","InterventionTemplateWebLink, webLinkID, InterventionTemplateID", InjectOrderBy="ORDER BY [InterventionTemplateWebLink].[SortOrder] ASC")]
	[SPAutoGen("usp_GetAllWebLinkssByDefictGoalIntervention","","")]
	[SPAutoGen("usp_SearchWebLinks","SearchByArgs.sptpl","activeWithAll:active, code, address, contentOwnerID", ManuallyManaged=true)]
	[SPAutoGen("usp_SearchWebLinksByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPDelete("usp_DeleteWebLink")]
	[SPInsert("usp_InsertWebLink")]
	[SPUpdate("usp_UpdateWebLink")]
	[SPLoad("usp_LoadWebLink")]
	[TableMapping("WebLink","webLinkID")]
	public class WebLink : BaseAssessment
	{
		[NonSerialized]
		protected WebLinkCollection parentWebLinkCollection;
		[ColumnMapping("WebLinkID",StereoType=DataStereoType.FK)]
		protected int webLinkID;
		[ColumnMapping("Code")]
		protected string code;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		protected int contentOwnerID;
		[ColumnMapping("Address")]
		protected string address;
		[ColumnMapping("Description")]
		protected string description;
		[ColumnMapping("Active")]
		protected bool active = true;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("NotePad")]
		protected string notePad;
		[ColumnMapping("ReadOnly")]
		protected bool readOnly;
	
		public WebLink(): base()
		{
		}

		public WebLink(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}
		
		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int webLinkID)
		{
			return base.Load(webLinkID);
		}

		[FieldDescription("@ID@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int WebLinkID
		{
			get { return this.webLinkID; }
			set { this.webLinkID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=8)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.URL, IsRequired=true, MaxLength=256)]
		public string Address
		{
			get { return this.address; }
			set { this.address = value; }
		}
		
		[FieldDescription("@CONTENTOWNER@")]
		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=256)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[FieldDescription("@ACTIVE@")]
		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@READONLYCOL@")]
		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReadOnly
		{
			get { return this.readOnly; }
			set { this.readOnly = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent WebLinkCollection that contains this element
		/// </summary>
		public WebLinkCollection ParentWebLinkCollection
		{
			get
			{
				return this.parentWebLinkCollection;
			}
			set
			{
				this.parentWebLinkCollection = value; // parent is set when added to a collection
			}
		}

		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.Active = true;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		
	}

	/// <summary>
	/// Strongly typed collection of WebLink objects
	/// </summary>
	[ElementType(typeof(WebLink))]
	public class WebLinkCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_WebLinkID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(WebLink elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentWebLinkCollection = this;
			else
				elem.ParentWebLinkCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (WebLink elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public WebLink this[int index]
		{
			get
			{
				return (WebLink)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((WebLink)oldValue, false);
			SetParentOnElem((WebLink)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetWebLinksByActive(int maxRecords, bool active)
		{
			this.Clear();
			this.ElementType = typeof(SelectableWebLink);
			return SqlData.SPExecReadCol("usp_SearchWebLinksByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared WebLinkCollection which is cached in NSGlobal
		/// </summary>
		public static WebLinkCollection ActiveWebLinks
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				WebLinkCollection col = (WebLinkCollection)NSGlobal.EnsureCachedObject("ActiveWebLinks", typeof(WebLinkCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetWebLinksByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(WebLink elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((WebLink)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchWebLinks(int maxRecords, WebLink searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchWebLinks", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}

		public static WebLinkCollection GetWebLinksFromSearch(WebLink searcher)
		{
			WebLinkCollection col = new WebLinkCollection();
			col.SearchWebLinks(-1, searcher);
			return col;
		}

		/// <summary>
		/// Hashtable based index on webLinkID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_WebLinkID
		{
			get
			{
				if (this.indexBy_WebLinkID == null)
					this.indexBy_WebLinkID = new CollectionIndexer(this, new string[] { "webLinkID" }, true);
				return this.indexBy_WebLinkID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on webLinkID fields returns the object.  Uses the IndexBy_WebLinkID indexer.
		/// </summary>
		public WebLink FindBy(int webLinkID)
		{
			return (WebLink)this.IndexBy_WebLinkID.GetObject(webLinkID);
		}

		/// <summary>
		/// Sets Selected property for each item based on passed collection
		/// When passed collection is empty reset Selected property to false
		/// </summary>
		/// <param name="selectedWebLinks"></param>
		public void SetSelectedWebLinksFromCollection(WebLinkCollection selectedWebLinks)
		{
			if(selectedWebLinks.Count < 1)
			{
				foreach (WebLink weblink in this)
					((SelectableWebLink)weblink).Selected = false;
				return;
			}

			WebLink existingWL = null;
			foreach (WebLink weblink in this)
			{
				existingWL = selectedWebLinks.FindBy(weblink.WebLinkID);
				if (existingWL != null && !existingWL.IsMarkedForDeletion)
					((SelectableWebLink)weblink).Selected = true;
				else
					((SelectableWebLink)weblink).Selected = false;
			}
		}

		/// <summary>
		/// Parent InterventionTemplate that contains this collection
		/// </summary>
		public InterventionTemplate ParentInterventionTemplate
		{
			get { return this.ParentDataObject as InterventionTemplate; }
			set { this.ParentDataObject = value; /* parent is set when contained by a InterventionTemplate */ }
		}
		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadAllWebLinkssByDefictGoalIntervention(int maxRecords, int pOCDeficitTypeID, int pOCGoalTypeID, int interventionTypeID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllWebLinkssByDefictGoalIntervention", maxRecords, this, false, new object[] { pOCDeficitTypeID, pOCGoalTypeID, interventionTypeID });
		}

		/// <summary>
		/// Returns WebLinkCollection for matching input.
		/// </summary>
		/// <param name="pOCDeficitTypeID"></param>
		/// <param name="pOCGoalTypeID"></param>
		/// <param name="interventionTypeID"></param>
		/// <returns>WebLinkCollection</returns>
		public static WebLinkCollection LoadAllWebLinkssByDefictGoalIntervention(int pOCDeficitTypeID, int pOCGoalTypeID, int interventionTypeID)
		{
			WebLinkCollection col = new WebLinkCollection();
			if(pOCDeficitTypeID < 1 || pOCGoalTypeID < 1 || interventionTypeID < 1)
				return col;
			col.LoadAllWebLinkssByDefictGoalIntervention(-1, pOCDeficitTypeID, pOCGoalTypeID, interventionTypeID);
			return col;
		}
		
	}
}
