using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [InterventionTemplateWebLink]
	/// </summary>
	[SPInsert("usp_InsertInterventionTemplateWebLink")]
	[SPUpdate("usp_UpdateInterventionTemplateWebLink")]
	[SPDelete("usp_DeleteInterventionTemplateWebLink")]
	[SPLoad("usp_LoadInterventionTemplateWebLink")]
	[TableMapping("InterventionTemplateWebLink", "interventionTemplateID,webLinkID",true)]
	public class InterventionTemplateWebLink : BaseData
	{
		[NonSerialized]
		private InterventionTemplateWebLinkCollection parentInterventionTemplateWebLinkCollection;
		[ColumnMapping("InterventionTemplateID",StereoType=DataStereoType.FK)]
		private int interventionTemplateID;
		[ColumnMapping("WebLinkID",StereoType=DataStereoType.FK)]
		private int webLinkID;
		[ColumnMapping("SortOrder",StereoType=DataStereoType.FK)]
		private int sortOrder = 0;
	
		public InterventionTemplateWebLink()
		{
		}

		public InterventionTemplateWebLink(bool initNew, int interventionTemplateID, int webLinkID)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			this.webLinkID = webLinkID;
			this.interventionTemplateID = interventionTemplateID;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int InterventionTemplateID
		{
			get { return this.interventionTemplateID; }
			set { this.interventionTemplateID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int WebLinkID
		{
			get { return this.webLinkID; }
			set { this.webLinkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent InterventionTemplateWebLinkCollection that contains this element
		/// </summary>
		public InterventionTemplateWebLinkCollection ParentInterventionTemplateWebLinkCollection
		{
			get
			{
				return this.parentInterventionTemplateWebLinkCollection;
			}
			set
			{
				this.parentInterventionTemplateWebLinkCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of InterventionTemplateWebLink objects
	/// </summary>
	[ElementType(typeof(InterventionTemplateWebLink))]
	public class InterventionTemplateWebLinkCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_WebLinkID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(InterventionTemplateWebLink elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentInterventionTemplateWebLinkCollection = this;
			else
				elem.ParentInterventionTemplateWebLinkCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (InterventionTemplateWebLink elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public InterventionTemplateWebLink this[int index]
		{
			get
			{
				return (InterventionTemplateWebLink)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((InterventionTemplateWebLink)oldValue, false);
			SetParentOnElem((InterventionTemplateWebLink)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(InterventionTemplateWebLink elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((InterventionTemplateWebLink)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Hashtable based index on webLinkID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_WebLinkID
		{
			get
			{
				if (this.indexBy_WebLinkID == null)
					this.indexBy_WebLinkID = new CollectionIndexer(this, new string[] { "webLinkID" }, true);
				return this.indexBy_WebLinkID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on webLinkID fields returns the object.  Uses the IndexBy_WebLinkID indexer.
		/// </summary>
		public InterventionTemplateWebLink FindBy(int webLinkID)
		{
			return (InterventionTemplateWebLink)this.IndexBy_WebLinkID.GetObject(webLinkID);
		}

		/// <summary>
		/// Manipulates (add/remove items) InterventionTemplateWebLinkCollection
		/// based on passed WebLinkCollection.
		/// </summary>
		/// <param name="webLinks"></param>
		/// <param name="interventionTemplateID"></param>
		public void SynchronizeWebLinksFromSelectableCollection(WebLinkCollection webLinks, int interventionTemplateID)
		{
			this.IndexBy_WebLinkID.Rebuild();
			InterventionTemplateWebLink existing = null;

			foreach(WebLink weblink in webLinks)
			{
				existing = this.FindBy(weblink.WebLinkID);
				if (((SelectableWebLink)weblink).Selected)
				{
					if (existing == null)
					{ //Selected WebLink is not linked - Adding
						InterventionTemplateWebLink toAdd = new InterventionTemplateWebLink(true, interventionTemplateID, weblink.WebLinkID);
						this.Add(toAdd);
					}
					else if (existing.IsMarkedForDeletion)
						existing.IsMarkedForDeletion = false;
				}
				else if (!((SelectableWebLink)weblink).Selected)
				{
					if(existing != null)
						// Selected WebLink is linked to this - Removing
						existing.MarkDel();
				}
			}// end of foreach
		}

		/// <summary>
		/// Parent InterventionTemplate that contains this collection
		/// </summary>
		public InterventionTemplate ParentInterventionTemplate
		{
			get { return this.ParentDataObject as InterventionTemplate; }
			set { this.ParentDataObject = value; /* parent is set when contained by a InterventionTemplate */ }
		}
	}
}
