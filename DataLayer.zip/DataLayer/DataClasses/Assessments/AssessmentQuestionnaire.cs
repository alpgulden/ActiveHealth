using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [AssessmentQuestionnaire]
	/// </summary>
	[TableMapping("AssessmentQuestionnaire","assessmentGUID,questionnaireID")]
	public class AssessmentQuestionnaire : BaseData
	{
		public AssessmentQuestionnaire() :  base()
		{
		}

	}
}
