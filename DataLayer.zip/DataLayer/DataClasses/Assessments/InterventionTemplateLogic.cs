using System;

using NetsoftUSA.DataLayer;
using System.Collections;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [InterventionTemplateLogic]
	/// </summary>
	[SPInsert("usp_InsertInterventionTemplateLogic")]
	[SPDelete("usp_DeleteInterventionTemplateLogic")]
	[SPLoad("usp_LoadInterventionTemplateLogic")]
	[TableMapping("InterventionTemplateLogic", "interventionTemplateID,logicID",true)]
	public class InterventionTemplateLogic : BaseData
	{
		[NonSerialized]
		private InterventionTemplateLogicCollection parentInterventionTemplateLogicCollection;
		[ColumnMapping("InterventionTemplateID",StereoType=DataStereoType.FK)]
		private int interventionTemplateID;
		[ColumnMapping("LogicID",StereoType=DataStereoType.FK)]
		private int logicID;

		protected int questionID;
	
		public InterventionTemplateLogic()
		{
		}

		public InterventionTemplateLogic(bool initNew, int logicID, int interventionTemplateID)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			this.logicID = logicID;
			this.interventionTemplateID = interventionTemplateID;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int InterventionTemplateID
		{
			get { return this.interventionTemplateID; }
			set { this.interventionTemplateID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LogicID
		{
			get { return this.logicID; }
			set { this.logicID = value; }
		}

		public int QuestionID
		{
			get { return questionID; }
			set { questionID = value; }
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int interventionTemplateID, int logicID)
		{
			base.Delete(interventionTemplateID,logicID);		
		}

		/// <summary>
		/// Parent InterventionTemplateLogicCollection that contains this element
		/// </summary>
		public InterventionTemplateLogicCollection ParentInterventionTemplateLogicCollection
		{
			get
			{
				return this.parentInterventionTemplateLogicCollection;
			}
			set
			{
				this.parentInterventionTemplateLogicCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}
	}

	/// <summary>
	/// Strongly typed collection of InterventionTemplateLogic objects
	/// </summary>
	[ElementType(typeof(InterventionTemplateLogic))]
	public class InterventionTemplateLogicCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_InterventionTemplateID_LogicID;

		private bool fillExtraFields = false;

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(InterventionTemplateLogic elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentInterventionTemplateLogicCollection = this;
			else
				elem.ParentInterventionTemplateLogicCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (InterventionTemplateLogic elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public InterventionTemplateLogic this[int index]
		{
			get
			{
				return (InterventionTemplateLogic)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((InterventionTemplateLogic)oldValue, false);
			SetParentOnElem((InterventionTemplateLogic)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(InterventionTemplateLogic elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((InterventionTemplateLogic)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent InterventionTemplate that contains this collection
		/// </summary>
		public InterventionTemplate ParentInterventionTemplate
		{
			get { return this.ParentDataObject as InterventionTemplate; }
			set { this.ParentDataObject = value; /* parent is set when contained by a InterventionTemplate */ }
		}

		public void SynchronizeLogicsFromLogicCollection(LogicCollection selectedLogics, int interventionTemplateID)
		{
			this.IndexBy_InterventionTemplateID_LogicID.Rebuild();
			InterventionTemplateLogic existing = null;
			foreach(Logic logic in selectedLogics)
			{
				existing = this.FindBy(interventionTemplateID, logic.LogicID);
				if (existing == null & !logic.IsMarkedForDeletion)
				{	// Not found - adding
					InterventionTemplateLogic toAdd = new InterventionTemplateLogic(true, logic.LogicID, interventionTemplateID);
					this.Add(toAdd);
				}
				else if (existing != null)
					existing.IsMarkedForDeletion = logic.IsMarkedForDeletion;
			}// end of foreach
		}


		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAssessmentInterventionTemplateLogics(string assessmentGUID)
		{
			this.Clear();
			fillExtraFields = true;
			int result = SqlData.SPExecReadCol("usp_GetAssessmentInterventionTemplateLogics", -1, this, false, new object[] {assessmentGUID});
			fillExtraFields = false;
			return result;
		}

		protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);
			// Fill the extra members on question object with the data from reader
			if (fillExtraFields)
			{
				((InterventionTemplateLogic)data).QuestionID = int.Parse((rdr["QuestionID"].ToString()));
			}
		}

		/// <summary>
		/// Hashtable based index on interventionTemplateID, logicID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_InterventionTemplateID_LogicID
		{
			get
			{
				if (this.indexBy_InterventionTemplateID_LogicID == null)
					this.indexBy_InterventionTemplateID_LogicID = new CollectionIndexer(this, new string[] { "interventionTemplateID", "logicID" }, true);
				return this.indexBy_InterventionTemplateID_LogicID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on interventionTemplateID, logicID fields returns the object.  Uses the IndexBy_InterventionTemplateID_LogicID indexer.
		/// </summary>
		public InterventionTemplateLogic FindBy(int interventionTemplateID, int logicID)
		{
			return (InterventionTemplateLogic)this.IndexBy_InterventionTemplateID_LogicID.GetObject(interventionTemplateID, logicID);
		}


		/// <summary>
		/// Returns InterventionTemplateLogics filtered by InterventionTemplateID
		/// </summary>
		/// <param name="questionID"></param>
		/// <returns></returns>
		public ArrayList FilterBy(int interventionTemplateID)
		{
			ArrayList its = new ArrayList(5);
			for (int i = 0; i < this.Count; i++)
			{
				if (this[i].InterventionTemplateID == interventionTemplateID)
					its.Add(this[i]);
			}
			if (its.Count > 0)
				return its;
			else
				return null;
		}


	}
}
