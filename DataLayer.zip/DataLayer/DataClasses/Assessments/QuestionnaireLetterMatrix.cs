using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [QuestionnaireLetterMatrix]
	/// </summary>
	[SPInsert("usp_InsertQuestionnaireLetterMatrix")]
	[SPUpdate("usp_UpdateQuestionnaireLetterMatrix")]
	[SPDelete("usp_DeleteQuestionnaireLetterMatrix")]
	[SPLoad("usp_LoadQuestionnaireLetterMatrix")]
	[TableMapping("QuestionnaireLetterMatrix","questionnaireID,matrixID,contentOwnerID", true)]
	public class QuestionnaireLetterMatrix : BaseData
	{
		[NonSerialized]
		private QuestionnaireLetterMatrixCollection parentQuestionnaireLetterMatrixCollection;
		[ColumnMapping("QuestionnaireID",(int)0)]
		private int questionnaireID;
		[ColumnMapping("MatrixID",StereoType=DataStereoType.FK)]
		private int matrixID;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		private int contentOwnerID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public QuestionnaireLetterMatrix()
		{
		}

		public QuestionnaireLetterMatrix(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public QuestionnaireLetterMatrix(bool initNew, Questionnaire q, int matrixdId)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			this.questionnaireID = q.QuestionnaireID;
			this.contentOwnerID = q.ContentOwnerID;
			this.matrixID = matrixdId;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value; }
		}

		[FieldDescription("@ID@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int MatrixID
		{
			get { return this.matrixID; }
			set { this.matrixID = value; }
		}

		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent QuestionnaireLetterMatrixCollection that contains this element
		/// </summary>
		public QuestionnaireLetterMatrixCollection ParentQuestionnaireLetterMatrixCollection
		{
			get
			{
				return this.parentQuestionnaireLetterMatrixCollection;
			}
			set
			{
				this.parentQuestionnaireLetterMatrixCollection = value; // parent is set when added to a collection
			}
		}

		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of QuestionnaireLetterMatrix objects
	/// </summary>
	[ElementType(typeof(QuestionnaireLetterMatrix))]
	public class QuestionnaireLetterMatrixCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_MatrixID;
		[NonSerialized]
		private CollectionIndexer indexBy_QuestionnaireID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(QuestionnaireLetterMatrix elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentQuestionnaireLetterMatrixCollection = this;
			else
				elem.ParentQuestionnaireLetterMatrixCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (QuestionnaireLetterMatrix elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public QuestionnaireLetterMatrix this[int index]
		{
			get
			{
				return (QuestionnaireLetterMatrix)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((QuestionnaireLetterMatrix)oldValue, false);
			SetParentOnElem((QuestionnaireLetterMatrix)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(QuestionnaireLetterMatrix elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((QuestionnaireLetterMatrix)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent Questionnaire that contains this collection
		/// </summary>
		public Questionnaire ParentQuestionnaire
		{
			get { return this.ParentDataObject as Questionnaire; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Questionnaire */ }
		}

		/// <summary>
		/// Hashtable based index on questionnaireID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionnaireID
		{
			get
			{
				if (this.indexBy_QuestionnaireID == null)
					this.indexBy_QuestionnaireID = new CollectionIndexer(this, new string[] { "questionnaireID" }, true);
				return this.indexBy_QuestionnaireID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on questionnaireID fields returns the object.  Uses the IndexBy_QuestionnaireID indexer.
		/// </summary>
		public QuestionnaireLetterMatrix FindByQuestionnaireID(int questionnaireID)
		{
			return (QuestionnaireLetterMatrix)this.IndexBy_QuestionnaireID.GetObject(questionnaireID);
		}

		public void SynchronizeFromCollection(LetterMatrixCollection col, Questionnaire q)
		{
			this.IndexBy_MatrixID.Rebuild();
			QuestionnaireLetterMatrix existing = null;
			foreach(LetterMatrix lm in col)
			{
				existing = this.FindByMatrixID(lm.MatrixID);
				if(existing == null && !lm.IsMarkedForDeletion && ((SelectableLetterMatrix)lm).Selected )
				{ // doesn't exist - adding
					QuestionnaireLetterMatrix qlm = new QuestionnaireLetterMatrix(true, q, lm.MatrixID);
					this.Add(qlm);
				}
				else if(existing != null && !lm.IsMarkedForDeletion && !((SelectableLetterMatrix)lm).Selected )
					existing.MarkDel();
			}
		}

		/// <summary>
		/// Hashtable based index on matrixID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_MatrixID
		{
			get
			{
				if (this.indexBy_MatrixID == null)
					this.indexBy_MatrixID = new CollectionIndexer(this, new string[] { "matrixID" }, true);
				return this.indexBy_MatrixID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on matrixID fields returns the object.  Uses the IndexBy_MatrixID indexer.
		/// </summary>
		public QuestionnaireLetterMatrix FindByMatrixID(int matrixID)
		{
			return (QuestionnaireLetterMatrix)this.IndexBy_MatrixID.GetObject(matrixID);
		}
	}
}
