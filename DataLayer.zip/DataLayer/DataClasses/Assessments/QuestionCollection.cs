using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Strongly typed collection of Question objects
	/// </summary>
	[ElementType(typeof(Question))]
	public class QuestionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass//, ICollectionElementFilter
	{
		[NonSerialized]
		private CollectionIndexer indexBy_QuestionIndexID_ComponentIndexID;
		[NonSerialized]
		private AssessmentContext assessmentContext;

		private bool fillExtraFields = false;
		public const int MAXRECORDS = 50;

		public AssessmentContext AssessmentContext
		{
			get { return assessmentContext; }
			set { assessmentContext = value; }
		}

		[NonSerialized]
		private CollectionIndexer indexBy_QuestionID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Question elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentQuestionCollection = this;
			else
				elem.ParentQuestionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Question elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Question this[int index]
		{
			get
			{
				return (Question)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Question)oldValue, false);
			SetParentOnElem((Question)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		
		public int SearchQuestions(Question searcher)
		{
			return SearchQuestions(-1, MAXRECORDS, searcher);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchQuestions(int maxRecords, int rowCount, Question searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchQuestions", maxRecords, this, searcher, false, 
				new string[] {"rowCount", "activeWithAll"}, 
				new object[] {rowCount, activeWithAll});
		}


		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadByContentOwnerForSelection(int maxRecords, int contentOwnerID)
		{
			this.Clear();
			this.ElementType = typeof(SelectableQuestion);
			return SqlData.SPExecReadCol("usp_GetQuestionsByContentOwnerIDComponentIndexID", maxRecords, this, false, contentOwnerID, 0 /* No component questions */);
			// usp_GetQuestionsByContentOwnerIDComponentIndexID 1, 0 returns 13K records
		}


		public static QuestionCollection GetQuestionsByContentOwnerForSelection(int contentOwnerID)
		{
			// Get a cached instance of the collection
			QuestionCollection col = new QuestionCollection();
			// initialize the content of the collection
			#if RELEASE
			col.LoadByContentOwnerForSelection(-1, contentOwnerID);
			#endif
			#if DEBUG
			col.LoadByContentOwnerForSelection(100, contentOwnerID);
			#endif
			return col;
		}

		public void SetSelectedQuestionsFromCollection(PresentationGroupQuestionCollection selectedQuestions)
		{
			PresentationGroupQuestion existingPresentationGroupQuestion = null;
			foreach (Question question in this)
			{
				existingPresentationGroupQuestion = selectedQuestions.FindBy(question.QuestionID);
				if (existingPresentationGroupQuestion != null && !existingPresentationGroupQuestion.IsMarkedForDeletion)
					((SelectableQuestion)question).Selected = true;
			}
		}

		/// <summary>
		/// Hashtable based index on questionID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionID
		{
			get
			{
				if (this.indexBy_QuestionID == null)
					this.indexBy_QuestionID = new CollectionIndexer(this, new string[] { "questionID" }, true);
				return this.indexBy_QuestionID;
			}
			
		}

		/// <summary>
		/// Parent Question that contains this collection
		/// </summary>
		public Question ParentQuestion
		{
			get { return this.ParentDataObject as Question; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Question */ }
		}

		/// <summary>
		/// Hashtable based search on questionID fields returns the object.  Uses the IndexBy_QuestionID indexer.
		/// </summary>
		public Question FindBy(int questionID)
		{
			return (Question)this.IndexBy_QuestionID.GetObject(questionID);
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
			ResetIndexers();
		}

		private void ResetIndexers()
		{
			// Rebuild indexers
			// TODO: Remove this when the library automatically supports this feature
			indexBy_QuestionID = null;
			indexBy_QuestionIndexID_ComponentIndexID = null;
		}

		public override int AddRecord(BaseDataClass data)
		{
			int ret = base.AddRecord(data);
			//ResetIndexers();
			return ret;
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadByAssessmentGUID(string assessmentGUID, int contentOwnerID)
		{
			this.Clear();
			// Set this so in OnFillElemFromReader the extra fields are filled
			fillExtraFields = true;
			int result = SqlData.SPExecReadCol("usp_GetAssessmentQuestionsByAssessmentGUID", -1, this, false, new object[] {assessmentGUID, contentOwnerID});
			fillExtraFields = false;
			return result;
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadByContentOwnerID(int contentOwnerID)
		{
			this.Clear();
			int result = SqlData.SPExecReadCol("usp_GetQuestionsByContentOwnerID", -1, this, false, new object[] {contentOwnerID});
			return result;
		}

		protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);
			// Fill the extra members on question object with the data from reader
			if (fillExtraFields)
			{
				((Question)data).PostBackRequired = Convert.ToBoolean(int.Parse((rdr["PostBackRequired"].ToString())));
			}
		}

		/// <summary>
		/// Hashtable based index on questionIndexID, componentIndexID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionIndexID_ComponentIndexID
		{
			get
			{
				if (this.indexBy_QuestionIndexID_ComponentIndexID == null)
					this.indexBy_QuestionIndexID_ComponentIndexID = new CollectionIndexer(this, new string[] { "questionIndexID", "componentIndexID" }, true);
				return this.indexBy_QuestionIndexID_ComponentIndexID;
			}
			
		}

		public Question FindByIndexID(int questionIndexID, int componentIndexID)
		{
			return (Question)this.IndexBy_QuestionIndexID_ComponentIndexID.GetObject(questionIndexID, componentIndexID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadQuestionsByContentOwnerIDAssessmentGUID(int maxRecords, int contentOwnerID, string AssessmentGuid)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetQuestionsByContentOwnerIDAssessmentGUID", maxRecords, this, false, new object[] { contentOwnerID, SQLDataDirect.MakeDBValue(AssessmentGuid)  });
		}

		static QuestionCollection GetLoadQuestionsByContentOwnerIDAssessmentGUID(int maxRecords, int contentOwnerID, string AssessmentGuid)
		{
			QuestionCollection col = new QuestionCollection();
			col.LoadQuestionsByContentOwnerIDAssessmentGUID(maxRecords, contentOwnerID, AssessmentGuid);
			return col;
		}


	}
}
