using System;
using System.Collections;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	public class SelectableQuestion : Question
	{
		private bool selected;

		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}
	} 

	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// 
	/// !!!Manually Managed Stored Procedures:
	/// usp_GetAssessmentQuestionsByAssessmentGUID
	/// GetAssessmentQuestions (User Defined Function)
	/// </summary>
	
	[SPAutoGen("usp_SearchQuestions","SearchByArgs.sptpl","activeWithAll:active, questionText, contentOwnerID, componentIndexID", InjectPreOperation="SET ROWCOUNT @rowCount", InjectParameters="@rowCount int")]
	[SPAutoGen("usp_GetQuestionsByContentOwnerID","SelectAllByGivenArgs.sptpl","contentOwnerID")]
	[SPAutoGen("usp_GetQuestionsByContentOwnerIDComponentIndexID","SelectAllByGivenArgs.sptpl","contentOwnerID, componentIndexID")]
	[SPAutoGen("usp_GetQuestionsByContentOwnerIDAssessmentGUID",null ,ManuallyManaged=true)]
	[SPInsert("usp_InsertQuestion")]
	[SPUpdate("usp_UpdateQuestion")]
	[SPDelete("usp_DeleteQuestion")]
	[SPLoad("usp_LoadQuestion")]
	[TableMapping("Question","QuestionID")]
	public class Question : BaseAssessment
	{
		[NonSerialized]
		protected QuestionCollection parentQuestionCollection;
		[ColumnMapping("QuestionID",StereoType=DataStereoType.FK)]
		protected int questionID;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		protected int contentOwnerID;
		[ColumnMapping("QuestionIndexID", (int)-1)]
		protected int questionIndexID = -1;
		[ColumnMapping("ComponentIndexID", (int)-1)]
		private int componentIndexID = 0;
		[ColumnMapping("QuestionText")]
		protected string questionText;
		[ColumnMapping("InstructionText")]
		protected string instructionText;
		[ColumnMapping("QuestionControlTypeID",StereoType=DataStereoType.FK)]
		protected int questionControlTypeID = (int)QuestionControlTypeEnum.Custom;
		[ColumnMapping("MasterQuestionID",StereoType=DataStereoType.FK)]
		private int masterQuestionID;
		[ColumnMapping("ComponentType")]
		private string componentType;
		[ColumnMapping("Active")]
		protected bool active = true;
		[ColumnMapping("Mandatory")]
		protected bool mandatory = false;
		[ColumnMapping("LogicID",StereoType=DataStereoType.FK)]
		protected int logicID;
		[ColumnMapping("WebLinkID",StereoType=DataStereoType.FK)]
		private int webLinkID;
		[ColumnMapping("Note")]
		protected string note;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		protected AnswerCollection answers;
		protected QuestionCollection subQuestions;
		protected Logic logic;			// loaded and cached logic
		protected Question parentQuestion;

		protected QuestionControlTypeEnum oldQuestionControlType = QuestionControlTypeEnum.Custom;
		protected bool needsRebuild = false;

		protected bool postBackRequired = false;

		public Question(): base()
		{
		}

		public Question(int questionID)
		{
			this.NewRecord(); // initialize record state
			this.questionID = questionID;
		}

		public Question(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public Question(int componentIndexID, string questionText, QuestionControlTypeEnum questionControlType, string componentType)
		{
			this.NewRecord(); // initialize record state
			this.questionIndexID = questionIndexID;
			this.componentIndexID = componentIndexID;
			this.questionText = questionText;
			this.QuestionControlType = questionControlType;
			this.componentType = componentType;
		}

		public void LoadFullTree(bool forceReload)
		{
			this.LoadAnswers(forceReload);
			foreach (Answer answer in this.answers)
			{
				answer.LoadFullTree(forceReload);
			}
			
			this.LoadSubQuestions(forceReload);
			foreach (Question subQuestion in this.subQuestions)
			{
				subQuestion.LoadFullTree(forceReload);
			}
		}


		// Set this whenever answers and subquestions collections need to be rebuilt because of a change in the QuestionControlType
		public bool NeedsRebuild
		{
			get { return this.needsRebuild; }
			set { this.needsRebuild = value; }
		}

		
		/// <summary>
		/// Rebuilds the question structure after a QuestionControlTypeChange
		/// </summary>
		public void RebuildQuestionStructure()
		{
			// If the control type is not changed there is nothing to do
			if (oldQuestionControlType == this.QuestionControlType) return;

			// CCDropDownList, DropDownList, CheckList and RadioList are interchangable
			if ((oldQuestionControlType == QuestionControlTypeEnum.CCDropDown || oldQuestionControlType == QuestionControlTypeEnum.DropDownList || oldQuestionControlType == QuestionControlTypeEnum.CheckList || oldQuestionControlType == QuestionControlTypeEnum.RadioList) && 
				(this.QuestionControlType == QuestionControlTypeEnum.CCDropDown || this.QuestionControlType == QuestionControlTypeEnum.DropDownList || this.QuestionControlType == QuestionControlTypeEnum.CheckList || this.QuestionControlType == QuestionControlTypeEnum.RadioList))
				return;

			// If we're here that means we're switching between two incompatible control types.
			// We have to delete and rebuild the structure

			// First delete everything
			if (this.IsNew)
			{
				this.LoadAnswers(true);
				this.LoadSubQuestions(true);
			}
			else
			{
				this.Answers.MarkAllDel();
				this.SaveAnswers();

				this.SubQuestions.MarkAllDel();
				this.SaveSubQuestions();
			}

			// If this is a complex question we need to rebuild
			if (this.IsComplex)
				BuildSubQuestionsAndAnswers();

			oldQuestionControlType = this.QuestionControlType;
		}



		/// <summary>
		/// Builds the whole SubQuestion and Answers structure for the complex questions
		/// </summary>
		public void BuildSubQuestionsAndAnswers()
		{
			Question subQuestion = null;

			switch (this.QuestionControlType)
			{
				/* Asthma Level Of Disease
				 * Exactly four hard-coded answer records � one of which will be chosen automatically during the assessment based on the selections of four component dropdown questions.
				 * Frequency of symptoms:	Exactly four hard-coded answer records � one of which will be selected during the assessment.
				 * Severity of symptoms:	Exactly three hard-coded answer records � one of which will be selected during the assessment.
				 * Frequency of attacks:	Exactly four hard-coded answer records � one of which will be selected during the assessment.
				 * Frequency of night symptoms:	Exactly four hard-coded answer records � one of which will be selected during the assessment.
				*/

				case QuestionControlTypeEnum.AsthmaLOD:
		
					// Set the main question's control type
					//this.QuestionControlType = QuestionControlTypeEnum.AsthmaLOD;
					//this.questionText = "Level Of Disease";

					// Add answers to the main question
					this.Answers.AddRecord(new Answer(1, "Mild and Intermittent", AnswerControlTypeEnum.Auto, 1));
					this.Answers.AddRecord(new Answer(2, "Mild and Persistent", AnswerControlTypeEnum.Auto, 2));
					this.Answers.AddRecord(new Answer(3, "Moderate and Persistent", AnswerControlTypeEnum.Auto, 3));
					this.Answers.AddRecord(new Answer(4, "Severe and Persistent", AnswerControlTypeEnum.Auto, 4));
			
					// Create SubQuestions and their answers
			
					// Q1
					subQuestion = new Question(1, "How often do you have asthma symptoms?", QuestionControlTypeEnum.DropDownList, "ASTHMAQ1");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "<2 times a week", AnswerControlTypeEnum.Auto, 1));
					subQuestion.Answers.AddRecord(new Answer(2, ">2 times a week but less than once a day", AnswerControlTypeEnum.Auto, 2));
					subQuestion.Answers.AddRecord(new Answer(3, "Every Day", AnswerControlTypeEnum.Auto, 3));
					subQuestion.Answers.AddRecord(new Answer(4, "Continually", AnswerControlTypeEnum.Auto, 4));

					// Q2
					subQuestion = new Question(2, "Do your asthma sysmptoms ever affect your activity?", QuestionControlTypeEnum.DropDownList, "ASTHMAQ2");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "Never", AnswerControlTypeEnum.Auto, 1));
					subQuestion.Answers.AddRecord(new Answer(2, "Sometimes", AnswerControlTypeEnum.Auto, 2));
					subQuestion.Answers.AddRecord(new Answer(3, "Always", AnswerControlTypeEnum.Auto, 3));
			
					// Q3
					subQuestion = new Question(3, "How often do you have asthma attacks?", QuestionControlTypeEnum.DropDownList, "ASTHMAQ3");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "<2 times a week", AnswerControlTypeEnum.Auto, 1));
					subQuestion.Answers.AddRecord(new Answer(2, ">2 times a week but less than once a day", AnswerControlTypeEnum.Auto, 2));
					subQuestion.Answers.AddRecord(new Answer(3, ">2 times a week, may last several days", AnswerControlTypeEnum.Auto, 3));
					subQuestion.Answers.AddRecord(new Answer(4, "Continually", AnswerControlTypeEnum.Auto, 4));

					// Q4
					subQuestion = new Question(4, "How often do you have asthma symptoms at night?", QuestionControlTypeEnum.DropDownList, "ASTHMAQ4");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "<2 times a month", AnswerControlTypeEnum.Auto, 1));
					subQuestion.Answers.AddRecord(new Answer(2, "3 times a month", AnswerControlTypeEnum.Auto, 2));
					subQuestion.Answers.AddRecord(new Answer(3, "4 times a month or more", AnswerControlTypeEnum.Auto, 3));
					subQuestion.Answers.AddRecord(new Answer(4, "Very frequently, almost every night", AnswerControlTypeEnum.Auto, 4));

					break;

				/* Body Mass Index
				 * A single answer record that will store the calculated Body Mass Index based on the input of two component questions.
				 * Height:	A single answer record that will accept numeric input during the assessment in the form of a masked edit field.
				 * Weight:	A single answer record that will accept numeric input during the assessment in the form of a masked edit field.
				*/ 
					case QuestionControlTypeEnum.BMI:
			
					// Set the main question's control type
					//this.QuestionControlType = QuestionControlTypeEnum.BMI;
					//this.questionText = "BMI";

					// Add answers to the main question
					this.Answers.AddRecord(new Answer(1, "BMI:", AnswerControlTypeEnum.Numeric, 1));
			
					// Create SubQuestions and their answers
			
					// Q1
					subQuestion = new Question(1, "Height:", QuestionControlTypeEnum.Custom, "BMIQ1");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "Height:", AnswerControlTypeEnum.Numeric, 1));

					// Q2
					subQuestion = new Question(2, "Weight:", QuestionControlTypeEnum.Custom, "BMIQ2");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "Weight:", AnswerControlTypeEnum.Numeric, 1));

					break;

				/* Blood Pressure
				 * Exactly three hard-coded answer records � one of which will be chosen automatically during the assessment based on the input of two component questions.
				 * Systolic:	A single answer record that will accept numeric input during the assessment in the form of a masked edit field.
				 * Diastolic:	A single answer record that will accept numeric input during the assessment in the form of a masked edit field.
				*/ 

				case QuestionControlTypeEnum.BP:

					// Set the main question's control type
					//this.QuestionControlType = QuestionControlTypeEnum.BP;
					//this.questionText = "Blood Pressure";

					// Add answers to the main question
					this.Answers.AddRecord(new Answer(1, "BP:", AnswerControlTypeEnum.Text, 1));

					// Create SubQuestions and their answers
			
					// Q1
					subQuestion = new Question(1, "Systolic Pressure:", QuestionControlTypeEnum.Custom, "BPQ1");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "Systolic", AnswerControlTypeEnum.Numeric, 1));

					// Q2
					subQuestion = new Question(2, "Diastolic Pressure:", QuestionControlTypeEnum.Custom, "BPQ2");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "Diastolic", AnswerControlTypeEnum.Numeric, 1));
					
					// Q3
					subQuestion = new Question(3, "Stage:", QuestionControlTypeEnum.DropDownList, "BPQ3");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "Stage 1", AnswerControlTypeEnum.Auto, 1));
					subQuestion.Answers.AddRecord(new Answer(2, "Stage 2", AnswerControlTypeEnum.Auto, 2));
					subQuestion.Answers.AddRecord(new Answer(3, "stage 3", AnswerControlTypeEnum.Auto, 3));


					break;

				/* Delivery Age
				 * A single answer record that will store the calculated delivery age (in years) based on the input of two component questions that ask for the EDC and LMP dates.
				 * EDC Date:	A single answer record that will accept date input during the assessment.
				 * LMP Date:	A single answer record that will accept date input during the assessment.
				*/

				case QuestionControlTypeEnum.DeliveryAge:

					// Set the main question's control type
					//this.QuestionControlType = QuestionControlTypeEnum.DeliveryAge;
					//this.questionText = "Delivery Age";

					// Add answers to the main question
					this.Answers.AddRecord(new Answer(1, "Delivery Age", AnswerControlTypeEnum.Numeric, 1));
			
					// Create SubQuestions and their answers
			
					// Q1
					subQuestion = new Question(1, "EDC Date:", QuestionControlTypeEnum.Custom, "DAQ1");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "EDC Date:", AnswerControlTypeEnum.Date, 1));

					// Q2
					subQuestion = new Question(2, "LMP Date:", QuestionControlTypeEnum.Custom, "DAQ2");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "LMP Date:", AnswerControlTypeEnum.Date, 1));

					break;

				/* Gestational Age
				 * A single answer record that will store the calculated gestational age (in weeks) based on the input of two component questions that ask for the EDC and last visit dates.
				 * EDC Date:	A single answer record that will accept date input during the assessment.
				 * Last Visit Date:	A single answer record that will accept date input during the assessment.
				*/

				case QuestionControlTypeEnum.GestationalAge:

					// Set the main question's control type
					//this.QuestionControlType = QuestionControlTypeEnum.GestationalAge;
					//this.questionText = "Gestational Age";

					// Add answers to the main question
					this.Answers.AddRecord(new Answer(1, "Gestational Age", AnswerControlTypeEnum.Numeric, 1));
			
					// Create SubQuestions and their answers
			
					// Q1
					subQuestion = new Question(1, "EDC Date:", QuestionControlTypeEnum.Custom, "GAQ1");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "EDC Date:", AnswerControlTypeEnum.Date, 1));

					// Q2
					subQuestion = new Question(2, "Last Visit Date:", QuestionControlTypeEnum.Custom, "GAQ2");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "Last Visit Date:", AnswerControlTypeEnum.Date, 1));

					break;

				/* Grams To Pounds
				 * A single answer record that will store the calculated weight in pounds based on the input of component questions that asks for the weight in grams.
				 * Wt. in Grams:	A single answer record that will accept numeric input during the assessment in the form of a masked edit field.
				*/ 

				case QuestionControlTypeEnum.GramsToPounds:

					// Set the main question's control type
					//this.QuestionControlType = QuestionControlTypeEnum.GramstoPounds;
					//this.questionText = "Grams To Pounds";

					// Add answers to the main question
					this.Answers.AddRecord(new Answer(1, "Pounds", AnswerControlTypeEnum.Numeric, 1));
			
					// Create SubQuestions and their answers
			
					// Q1
					subQuestion = new Question(1, "Grams:", QuestionControlTypeEnum.Custom, "G2PQ1");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "Grams:", AnswerControlTypeEnum.Numeric, 1));

					break;

				/* Pounds To Grams
				 * A single answer record that will store the calculated weight in grams based on the input of component questions that asks for the weight in pounds.
				 * Pounds:	A single answer record that will accept numeric input during the assessment in the form of a masked edit field.
				 * Ounces:	A single answer record that will accept numeric input during the assessment in the form of a masked edit field.
				*/ 

				case QuestionControlTypeEnum.PoundsToGrams:

					// Set the main question's control type
					//this.QuestionControlType = QuestionControlTypeEnum.PoundstoGrams;
					//this.questionText = "Pounds To Grams";

					// Add answers to the main question
					this.Answers.AddRecord(new Answer(1, "Grams", AnswerControlTypeEnum.Numeric, 1));
			
					// Create SubQuestions and their answers
			
					// Q1
					subQuestion = new Question(1, "Pounds:", QuestionControlTypeEnum.Custom, "P2GQ1");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "Pounds:", AnswerControlTypeEnum.Numeric, 1));

					// Q2
					subQuestion = new Question(2, "Ounces:", QuestionControlTypeEnum.Custom, "P2GQ2");
					this.SubQuestions.AddRecord(subQuestion);
					subQuestion.Answers.AddRecord(new Answer(1, "Ounces:", AnswerControlTypeEnum.Numeric, 1));

					break;

			}
		}




		public string GetResponseTextsCombined(ArrayList responses)
		{
			string combinedResponse = null;
			string[] responseTexts = GetResponseTexts(responses);
			if (responseTexts == null) return null;

			foreach (string responseText in responseTexts)
			{
				combinedResponse += responseText + "\n\r";
			}

			return combinedResponse;
		}

		public string[] GetResponseTexts(ArrayList responses)
		{
			// if there are no response there is nothing to return
			if (responses == null || responses.Count == 0) return null;

			string[] responseTexts = new string[responses.Count];
			Response currentResponse = null;
			Answer answer = null;
			MedicationCollection medications = MedicationCollection.AllMedications;
			Medication medication = null;

			// Go thru the response collection and try to get some kind of text for each response
			for (int index = 0; index < responses.Count; index++)
			{
				currentResponse = (Response)responses[index];

				// If the currentResponse is an ID
				if (currentResponse.DataType == AnswerDataType.ID)
				{
					// If its an ID for a medication
					if (currentResponse.AnswerType == AnswerTypeEnum.Medication)
					{
						// Find the corresponding medication
						medication = medications.FindBy(int.Parse(currentResponse.AnswerText));
						if (medication != null)
							responseTexts[index] = medication.BrandName; 
						else
							responseTexts[index] = "Unknown Medication";
					}
					else
					{
//						// If its an ID for a regular answer just get the AnswerText
//						answer = this.Answers.FindBy(currentResponse.AnswerID);
//						if (answer != null)
//							responseTexts[index] = answer.AnswerText;
//						else
//							responseTexts[index] = "Unknown Answer";

						responseTexts[index] = currentResponse.AnswerText;
					}
				}
				else // Otherwise its just plain text
					responseTexts[index] = currentResponse.AnswerText;
			}

			return responseTexts;
		}



		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int questionID)
		{
			return base.Load(questionID);
		}

		public QuestionControlTypeEnum QuestionControlType
		{
			get { return (QuestionControlTypeEnum)this.questionControlTypeID;}
			set { this.questionControlTypeID = (int)value;}
		}

		
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@QUESTIONID@")]
		public int QuestionID
		{
			get { return this.questionID; }
			set { this.questionID = value; }
		}
		
		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1, IsRequired=true)]
		[FieldDescription("@QUESTIONINDEXID@")]
		public int QuestionIndexID
		{
			get { return this.questionIndexID; }
			set { this.questionIndexID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ComponentIndexID
		{
			get { return this.componentIndexID; }
			set { this.componentIndexID = value; }
		}


		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@ACTIVE@")]
		public bool Active
		{
			get 
			{ 
				if (this.IsSubQuestion)
				{
					Question parentQuestion = parentQuestionCollection.ParentQuestion;
					if (parentQuestion != null)
					{
						return parentQuestion.Active;
					}
				}
                
				return this.active; 
			
			}
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@MANDATORY@")]
		public bool Mandatory
		{
			get { return this.mandatory; }
			set { this.mandatory = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@LOGIC@")]
		public int LogicID
		{
			get { return this.logicID; }
			set 
			{ 
				this.logicID = value; 
				this.logic = null;
			}
		}

		/// <summary>
		/// Return the loaded and cached logic object.
		/// </summary>
		public Logic Logic
		{
			get
			{
				if (this.logic == null)
					this.logic = GetLogic();
				return this.logic;
			}
		}

		/// <summary>
		/// Load and cache the linked logic.
		/// </summary>
		/// <returns></returns>
		public Logic GetLogic()
		{
			if (this.logicID == 0)
				return null;
			Logic logic = new Logic();
			if (logic.Load(this.logicID))
				return logic;
			else
				return null;
		}

		/// <summary>
		/// The description of the linked logic.
		/// </summary>
		public string LogicDescription
		{
			get 
			{ 
				Logic logic = this.Logic;
				if (logic == null)
					return null;
				return logic.Description;
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=500)]
		[FieldDescription("@NOTE@")]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}


		[FieldValuesMember("LookupOf_WebLinkID", "WebLinkID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@WEBLINK@")]
		public int WebLinkID
		{
			get { return this.webLinkID; }
			set { this.webLinkID = value; }
		}


		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4000)]
		[FieldDescription("@QUESTIONTEXT@")]
		public string QuestionText
		{
			get { return this.questionText; }
			set { this.questionText = value; }
		}

		[FieldValuesMember("LookupOf_QuestionControlTypeID", "QuestionControlTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@QUESTIONCONTROLTYPE@")]
		public int QuestionControlTypeID
		{
			get { return this.questionControlTypeID; }
			set { this.questionControlTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		[FieldDescription("@INSTRUCTIONTEXT@")]
		public string InstructionText
		{
			get { return this.instructionText; }
			set { this.instructionText = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MasterQuestionID
		{
			get { return this.masterQuestionID; }
			set { this.masterQuestionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=5)]
		public string ComponentType
		{
			get { return this.componentType; }
			set { this.componentType = value; }
		}

		public bool PostBackRequired
		{
			get { return postBackRequired; }
			set { this.postBackRequired = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				if (this.needsRebuild)
				{
					RebuildQuestionStructure();
					this.needsRebuild = false;
				}
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch(Exception ex)
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			Question parentQuestion = null;
			
			if (parentQuestionCollection != null)
			{
				parentQuestion = parentQuestionCollection.ParentQuestion;

				/*    Removed:  Master question was added to sub-questions for display purpose.
				 
				// In the maintenance page the question itself is added to its own SubQuestions collection for UI reasons.
				// DO NOT save the main question as a SubQuestion again, just leave
				if (this.QuestionID == parentQuestion.QuestionID)
					return;*/

				// This MUST be SubQuestion in a Complex Question
				// NOTE: ParentQuestion here does not have anything to do with the ParentQuestions of follow up questions
				if (this.isNew && this.IsSubQuestion) 
				{
					this.contentOwnerID = parentQuestion.contentOwnerID;
					//this.masterQuestionID = parentQuestion.QuestionID;
					this.questionIndexID = parentQuestion.questionIndexID;
				}
			}

			base.InternalSave();
          
			// Save the child collections here.
			this.SaveAnswers();

			// Save the subquestions if not a subquestion
			if (!this.IsSubQuestion)
				this.SaveSubQuestions();
		}

		/// <summary>
		/// The logical evaluation that will return whether this is a subquestion or not.
		/// </summary>
		public bool IsSubQuestion
		{
			get 
			{
				if (parentQuestionCollection == null)
					return this.masterQuestionID != 0 && this.componentType != null; 

				Question parentQuestion = parentQuestionCollection.ParentQuestion;
				return parentQuestion != null && this.componentType != null; 
			}
		}

		/// <summary>
		/// The logical evaluation that will return whether this question is complex or simple.
		/// </summary>
		public bool IsComplex
		{
			get { return ActiveAdvice.DataLayer.QuestionControlType.IsComplex(this.QuestionControlType); }
		}


		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}


		/// <summary>
		/// Child SubQuestions mapped to related rows of table Question where [QuestionID] = [MasterQuestionID]
		/// </summary>
		[SPLoadChild("usp_LoadSubQuestions", "masterQuestionID")]
		public QuestionCollection SubQuestions
		{
			get 
			{ 
				LoadSubQuestions(false);
				return this.subQuestions; 
			}
			set
			{
				this.subQuestions = value;
				if (value != null)
					value.ParentQuestion = this; // set this as a parent of the child collection
			}
		}


		/// <summary>
		/// Loads the SubQuestion collection
		/// </summary>
		public void LoadSubQuestions(bool forceReload)
		{
			this.subQuestions = (QuestionCollection)QuestionCollection.LoadChildCollection("SubQuestions", this, typeof(QuestionCollection), subQuestions, forceReload, null);
		}

		/// <summary>
		/// Saves the Answer collection
		/// </summary>
		public void SaveSubQuestions()
		{
			QuestionCollection.SaveChildCollection(this.subQuestions, true);
		}

		/// <summary>
		/// Synchronizes the Answer collection
		/// </summary>
		public void SynchronizeSubQuestions()
		{
			QuestionCollection.SynchronizeChildCollection(this.subQuestions, true);
		}



		/// <summary>
		/// Child Answers mapped to related rows of table Answer where [QuestionID] = [QuestionID]
		/// </summary>
		[SPLoadChild("usp_LoadQuestionAnswersInOrder", "questionID", ManuallyManaged = true)]
		public AnswerCollection Answers
		{
			get 
			{ 
				LoadAnswers(false);
				return this.answers; 
			}
			set
			{
				this.answers = value;
				if (value != null)
					value.ParentQuestion = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Answer collection
		/// </summary>
		public void LoadAnswers(bool forceReload)
		{
			this.answers = (AnswerCollection)AnswerCollection.LoadChildCollection("Answers", this, typeof(AnswerCollection), answers, forceReload, null);
		}

		/// <summary>
		/// Saves the Answer collection
		/// </summary>
		public void SaveAnswers()
		{
			AnswerCollection.SaveChildCollection(this.answers, true);
		}

		/// <summary>
		/// Synchronizes the Answer collection
		/// </summary>
		public void SynchronizeAnswers()
		{
			AnswerCollection.SynchronizeChildCollection(this.answers, true);
		}

		/// <summary>
		/// Parent QuestionCollection that contains this element
		/// </summary>
		public QuestionCollection ParentQuestionCollection
		{
			get
			{
				return this.parentQuestionCollection;
			}
			set
			{
				this.parentQuestionCollection = value; // parent is set when added to a collection
			}
		}

		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public WebLinkCollection LookupOf_WebLinkID
		{
			get
			{
				return WebLinkCollection.ActiveWebLinks; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public QuestionControlTypeCollection LookupOf_QuestionControlTypeID
		{
			get
			{
				QuestionControlTypeCollection col = QuestionControlTypeCollection.QuestionControlTypes;
				if (this.IsNew)
					return col; // Acquire a shared instance from the static member of collection

				QuestionControlTypeCollection filteredCol = new QuestionControlTypeCollection();
				foreach(QuestionControlType questionControlType in col)
				{
					// TODO: Add some filtering code
					filteredCol.AddRecord(questionControlType);
				}

				return filteredCol;
			}
		}

		/// <summary>
		/// Parent PresentationGroupQuestionOrder that contains this object
		/// </summary>
		public PresentationGroupQuestionOrder ParentPresentationGroupQuestionOrder
		{
			get { return this.ParentDataObject as PresentationGroupQuestionOrder; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PresentationGroupQuestionOrder */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public void GetNextQuestionIndexID()
		{
			this.questionIndexID = (int)SqlData.SPExecScalar("usp_GetNextQuestionIndexID", new object[] { this.contentOwnerID });
		}



		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddHeaderLabelandValue("@QUESTION@", questionText);
			}
		}
        
		
	}

}
