using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[TableMapping("QuestionnaireAssessment","questionnaireAssessmentID")]
	public class QuestionnaireAssessment : BaseData
	{
		public QuestionnaireAssessment()
		{
			//
			// TODO: Add constructor logic here
			//
		}

	}
}
