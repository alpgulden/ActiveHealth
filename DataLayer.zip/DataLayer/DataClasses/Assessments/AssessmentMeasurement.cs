using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPInsert("usp_InsertAssessmentMeasurement")]
	[SPUpdate("usp_UpdateAssessmentMeasurement")]
	[SPDelete("usp_DeleteAssessmentMeasurement")]
	[SPLoad("usp_LoadAssessmentMeasurement")]
	[TableMapping("AssessmentMeasurement","assessmentMeasurementID")]
	public class AssessmentMeasurement : BaseData
	{
		[NonSerialized]
		private AssessmentMeasurementCollection parentAssessmentMeasurementCollection;
		[ColumnMapping("AssessmentMeasurementID",StereoType=DataStereoType.FK)]
		private int assessmentMeasurementID;
		[ColumnMapping("MeasurementTypeID",StereoType=DataStereoType.FK)]
		private int measurementTypeID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("AnswerID",StereoType=DataStereoType.FK)]
		private int answerID;
		[ColumnMapping("AnswerRangeID",StereoType=DataStereoType.FK)]
		private int answerRangeID;
		[ColumnMapping("LogicID",StereoType=DataStereoType.FK)]
		private int logicID;
		private Logic logic;
	
		public AssessmentMeasurement() : base()
		{
		}

		public AssessmentMeasurement(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AssessmentMeasurementID
		{
			get { return this.assessmentMeasurementID; }
			set { this.assessmentMeasurementID = value; }
		}

		[FieldValuesMember("LookupOf_MeasurementTypeID", "CodeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int MeasurementTypeID
		{
			get { return this.measurementTypeID; }
			set { this.measurementTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AnswerID
		{
			get { return this.answerID; }
			set { this.answerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AnswerRangeID
		{
			get { return this.answerRangeID; }
			set { this.answerRangeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LogicID
		{
			get { return this.logicID; }
			set { this.logicID = value; }
		}

		/// <summary>
		/// Parent AssessmentMeasurementCollection that contains this element
		/// </summary>
		public AssessmentMeasurementCollection ParentAssessmentMeasurementCollection
		{
			get
			{
				return this.parentAssessmentMeasurementCollection;
			}
			set
			{
				this.parentAssessmentMeasurementCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			this.Logic.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			{
				base.InternalSave();	// in that case, delete the base first
				Logic.MarkDel();	// then allow the deletion of the contained object
				Logic.Save();
				return;
			}
			Logic.IsNew = this.IsNew;	// make sure the contained object is new if the containing object is new

			if (this.parentAssessmentMeasurementCollection.ParentAnswer != null)
			{
				Logic.CreateLogicFromObjects(this.parentAssessmentMeasurementCollection.ParentAnswer);
			}
			else if (this.parentAssessmentMeasurementCollection.ParentAnswerRange != null)
			{
				Logic.CreateLogicFromObjects(this.parentAssessmentMeasurementCollection.ParentAnswerRange);
			}

			Logic.Save();
			this.logicID = Logic.LogicID; // set the fk if the contained object was newly created

			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Contained Logic object
		/// </summary>
		[Contained]
		public Logic Logic
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.logic = (Logic)Logic.EnsureContainedDataObject(this, typeof(Logic), logic, false, logicID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.logic;
			}
			set
			{
				this.logic = value;
				if (value != null) value.ParentAssessmentMeasurement = this; // set this as a parent of the child data class
			}
		}

		public MeasurementTypeCollection LookupOf_MeasurementTypeID
		{
			get
			{
				return MeasurementTypeCollection.ActiveMeasurementTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of AssessmentMeasurement objects
	/// </summary>
	[ElementType(typeof(AssessmentMeasurement))]
	public class AssessmentMeasurementCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AssessmentMeasurement elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAssessmentMeasurementCollection = this;
			else
				elem.ParentAssessmentMeasurementCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AssessmentMeasurement elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AssessmentMeasurement this[int index]
		{
			get
			{
				return (AssessmentMeasurement)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AssessmentMeasurement)oldValue, false);
			SetParentOnElem((AssessmentMeasurement)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Answer that contains this collection
		/// </summary>
		public Answer ParentAnswer
		{
			get { return this.ParentDataObject as Answer; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Answer */ }
		}

		/// <summary>
		/// Parent AnswerRange that contains this collection
		/// </summary>
		public AnswerRange ParentAnswerRange
		{
			get { return this.ParentDataObject as AnswerRange; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AnswerRange */ }
		}
	}
}
