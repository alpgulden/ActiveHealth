using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_GetAllQuestionnairePresentationGroupByQuestionnaireID","SelectAllByGivenArgs.sptpl","questionnaireID", InjectOrderBy="ORDER BY [QuestionnairePresentationGroup].[SortOrder]")]
	[SPDelete("usp_DeleteQuestionnairePresentationGroup")]
	[SPLoad("usp_LoadQuestionnairePresentationGroup")]
	[SPInsert("usp_InsertQuestionnairePresentationGroup")]
	[SPUpdate("usp_UpdateQuestionnairePresentationGroup")]
	[TableMapping("QuestionnairePresentationGroup","questionnairePresentationGroupID")]
	public class QuestionnairePresentationGroup : BaseData
	{
		[ColumnMapping("QuestionnairePresentationGroupID",StereoType=DataStereoType.FK)]
		private int questionnairePresentationGroupID;
		[NonSerialized]
		private QuestionnairePresentationGroupCollection parentQuestionnairePresentationGroupCollection;
		[ColumnMapping("QuestionnaireID",StereoType=DataStereoType.FK)]
		private int questionnaireID;
		[ColumnMapping("PresentationGroupID",StereoType=DataStereoType.FK)]
		private int presentationGroupID;
		[ColumnMapping("SortOrder")]
		private int sortOrder = 0;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		private int contentOwnerID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;

		[ColumnMapping("PresentationGroupDescription", JoinColumn="Description", JoinRelation="QuestionnairePresentationGroup.PresentationGroupID = [PresentationGroup].PresentationGroupID", SQLGen=SQLGenerationFlags.NoSelect | SQLGenerationFlags.NoUpdate | SQLGenerationFlags.NoUpdate)]
		private string presentationGroupDescription;
	
		public QuestionnairePresentationGroup() : base()
		{
		}

		public QuestionnairePresentationGroup(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@QUESTIONNAIREID@")]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@PRESENTATIONGROUPID@")]
		public int PresentationGroupID
		{
			get { return this.presentationGroupID; }
			set { this.presentationGroupID = value; }
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		[FieldDescription("@SORTORDER@")]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[FieldDescription("@PRGROUPDESCRIPTION@")]
		public string PresentationGroupDescription
		{
			get {return presentationGroupDescription;}
			set { this.presentationGroupDescription = value; }
		}

		/// <summary>
		/// Parent QuestionnairePresentationGroupCollection that contains this element
		/// </summary>
		public QuestionnairePresentationGroupCollection ParentQuestionnairePresentationGroupCollection
		{
			get
			{
				return this.parentQuestionnairePresentationGroupCollection;
			}
			set
			{
				this.parentQuestionnairePresentationGroupCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionnairePresentationGroupID
		{
			get { return this.questionnairePresentationGroupID; }
			set { this.questionnairePresentationGroupID = value; }
		}

		


	}

	/// <summary>
	/// Strongly typed collection of QuestionnairePresentationGroup objects
	/// </summary>
	[ElementType(typeof(QuestionnairePresentationGroup))]
	public class QuestionnairePresentationGroupCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PresentationGroupID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(QuestionnairePresentationGroup elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentQuestionnairePresentationGroupCollection = this;
			else
				elem.ParentQuestionnairePresentationGroupCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (QuestionnairePresentationGroup elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public QuestionnairePresentationGroup this[int index]
		{
			get
			{
				return (QuestionnairePresentationGroup)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((QuestionnairePresentationGroup)oldValue, false);
			SetParentOnElem((QuestionnairePresentationGroup)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}


		public void SynchronizePresentationGroupsFromSelectableCollection(int questionnaireID, PresentationGroupCollection presentationGroups)
		{
			QuestionnairePresentationGroup  existingQuestionnairePresentationGroup = null;

			this.IndexBy_PresentationGroupID.Rebuild();

			foreach (PresentationGroup presentationGroup in presentationGroups)
			{
				if (((SelectablePresentationGroup)presentationGroup).Selected)
				{
					existingQuestionnairePresentationGroup = this.FindBy(presentationGroup.PresentationGroupID);
					if (existingQuestionnairePresentationGroup == null)
					{
						QuestionnairePresentationGroup questionnairePresentationGroup = null;
						questionnairePresentationGroup = new QuestionnairePresentationGroup(true);
						questionnairePresentationGroup.QuestionnaireID = questionnaireID;
						questionnairePresentationGroup.PresentationGroupID = presentationGroup.PresentationGroupID;
						questionnairePresentationGroup.PresentationGroupDescription = presentationGroup.Description;
						questionnairePresentationGroup.ContentOwnerID = presentationGroup.ContentOwnerID;
						this.AddRecord(questionnairePresentationGroup);
					}
					else if (existingQuestionnairePresentationGroup.IsMarkedForDeletion)
					{
						existingQuestionnairePresentationGroup.IsMarkedForDeletion = false;
					}
				}
			}

			foreach (QuestionnairePresentationGroup questionnairePresentationGroup in this)
			{
				PresentationGroup presentationGroup = null;
				presentationGroup = presentationGroups.FindBy(questionnairePresentationGroup.PresentationGroupID);
				if (!((SelectablePresentationGroup)presentationGroup).Selected)
				{
					questionnairePresentationGroup.MarkDel();
				}
			}
		}

		public override int AddRecord(BaseDataClass data)
		{
			int ret = base.AddRecord (data);
			// Rebuild indexers
			// TODO: Remove this when the library automatically supports this feature
			indexBy_PresentationGroupID = null;
			return ret;
        }



		/// <summary>
		/// Hashtable based index on presentationGroupID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PresentationGroupID
		{
			get
			{
				if (this.indexBy_PresentationGroupID == null)
					this.indexBy_PresentationGroupID = new CollectionIndexer(this, new string[] { "presentationGroupID" }, true);
				return this.indexBy_PresentationGroupID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on presentationGroupID fields returns the object.  Uses the IndexBy_PresentationGroupID indexer.
		/// </summary>
		public QuestionnairePresentationGroup FindBy(int presentationGroupID)
		{
			return (QuestionnairePresentationGroup)this.IndexBy_PresentationGroupID.GetObject(presentationGroupID);
		}

		/// <summary>
		/// Parent Questionnaire that contains this collection
		/// </summary>
		public Questionnaire ParentQuestionnaire
		{
			get { return this.ParentDataObject as Questionnaire; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Questionnaire */ }
		}

		/// <summary>
		/// Sorts the collection by the sortOrder members.
		/// </summary>
		public void SortBySortOrder(bool ascending)
		{
			CollectionUtil.SortBy(this, ascending, false, new string[] { "sortOrder" });		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllQuestionnairePresentationGroupByQuestionnaireID(int questionnaireID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllQuestionnairePresentationGroupByQuestionnaireID", -1, this, false, new object[] { questionnaireID });
		}

	}
}
