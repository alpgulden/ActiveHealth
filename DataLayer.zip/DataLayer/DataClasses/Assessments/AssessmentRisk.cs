using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_GetAssessmentRisksByAnswerID","SelectAllByGivenArgs.sptpl","answerID")]  
	[SPInsert("usp_InsertAssessmentRisk")]
	[SPUpdate("usp_UpdateAssessmentRisk")]
	[SPDelete("usp_DeleteAssessmentRisk")]
	[SPLoad("usp_LoadAssessmentRisk")]
	[TableMapping("AssessmentRisk","assessmentRiskID")]
	public class AssessmentRisk : BaseData
	{
		[NonSerialized]
		private AssessmentRiskCollection parentAssessmentRiskCollection;
		[ColumnMapping("AssessmentRiskID")]
		private int assessmentRiskID;
		[ColumnMapping("RiskTypeID",StereoType=DataStereoType.FK)]
		private int riskTypeID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("AnswerID",StereoType=DataStereoType.FK)]
		private int answerID;
		[ColumnMapping("AnswerRangeID",StereoType=DataStereoType.FK)]
		private int answerRangeID;
		[ColumnMapping("LogicID",StereoType=DataStereoType.FK)]
		private int logicID;
		private Logic logic;
	
		public AssessmentRisk() :  base()
		{
		}

		public AssessmentRisk(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AssessmentRiskID
		{
			get { return this.assessmentRiskID; }
			set { this.assessmentRiskID = value; }
		}

		[FieldValuesMember("LookupOf_RiskTypeID", "CMSRiskId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int RiskTypeID
		{
			get { return this.riskTypeID; }
			set { this.riskTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AnswerID
		{
			get { return this.answerID; }
			set { this.answerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AnswerRangeID
		{
			get { return this.answerRangeID; }
			set { this.answerRangeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LogicID
		{
			get { return this.logicID; }
			set { this.logicID = value; }
		}

		public CMSRiskCollection LookupOf_RiskTypeID
		{
			get
			{
				return CMSRiskCollection.ActiveCMSRisks; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent AssessmentRiskCollection that contains this element
		/// </summary>
		public AssessmentRiskCollection ParentAssessmentRiskCollection
		{
			get
			{
				return this.parentAssessmentRiskCollection;
			}
			set
			{
				this.parentAssessmentRiskCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			this.Logic.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			{
				base.InternalSave();	// in that case, delete the base first
				Logic.MarkDel();	// then allow the deletion of the contained object
				Logic.Save();
				return;
			}
			Logic.IsNew = this.IsNew;	// make sure the contained object is new if the containing object is new

			if (this.parentAssessmentRiskCollection.ParentAnswer != null)
			{
				Logic.CreateLogicFromObjects(this.parentAssessmentRiskCollection.ParentAnswer);
			}
			else if (this.parentAssessmentRiskCollection.ParentAnswerRange != null)
			{
				Logic.CreateLogicFromObjects(this.parentAssessmentRiskCollection.ParentAnswerRange);
			}

			Logic.Save();
			this.logicID = Logic.LogicID; // set the fk if the contained object was newly created

			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Contained Logic object
		/// </summary>
		[Contained]
		public Logic Logic
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.logic = (Logic)Logic.EnsureContainedDataObject(this, typeof(Logic), logic, false, logicID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.logic;
			}
			set
			{
				this.logic = value;
				if (value != null) value.ParentAssessmentRisk = this; // set this as a parent of the child data class
			}
		}



	}

	/// <summary>
	/// Strongly typed collection of AssessmentRisk objects
	/// </summary>
	[ElementType(typeof(AssessmentRisk))]
	public class AssessmentRiskCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AssessmentRisk elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAssessmentRiskCollection = this;
			else
				elem.ParentAssessmentRiskCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AssessmentRisk elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AssessmentRisk this[int index]
		{
			get
			{
				return (AssessmentRisk)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AssessmentRisk)oldValue, false);
			SetParentOnElem((AssessmentRisk)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAssessmentLevelOfDiseasesByAnswerID(int maxRecords, int answerID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAssessmentRisksByAnswerID", maxRecords, this, new object[] {answerID}, false);
		}

		/// <summary>
		/// Parent Answer that contains this collection
		/// </summary>
		public Answer ParentAnswer
		{
			get { return this.ParentDataObject as Answer; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Answer */ }
		}

		/// <summary>
		/// Parent AnswerRange that contains this collection
		/// </summary>
		public AnswerRange ParentAnswerRange
		{
			get { return this.ParentDataObject as AnswerRange; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AnswerRange */ }
		}
	}
}