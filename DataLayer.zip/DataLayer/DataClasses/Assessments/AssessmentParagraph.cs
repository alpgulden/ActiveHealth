using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	public enum AssessmentParagraphPosition
	{
		First = 1,
		Normal = 2,
		Last = 3
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [AssessmentParagraph]
	/// </summary>
	[SPAutoGen("usp_LoadAssessmentParagraphByCategory","SelectAllByGivenArgsOrderBy.sptpl","sortOrder, ASC, assessmentCategoryID, active")]
	[SPAutoGen("usp_SearchAssessmentParagraph","SearchByArgs.sptpl","activeWithAll:active, logicID")]
	[SPInsert("usp_InsertAssessmentParagraph")]
	[SPUpdate("usp_UpdateAssessmentParagraph")]
	[SPDelete("usp_DeleteAssessmentParagraph")]
	[SPLoad("usp_LoadAssessmentParagraph")]
	[TableMapping("AssessmentParagraph","assessmentParagraphID")]
	public class AssessmentParagraph : BaseAssessment
	{
		[NonSerialized]
		private AssessmentParagraphCollection parentAssessmentParagraphCollection;
		private AssessmentCategory parentAssessmentCategory;
		[ColumnMapping("AssessmentParagraphID",(int)0)]
		private int assessmentParagraphID;
		[ColumnMapping("AssessmentCategoryID",StereoType=DataStereoType.FK)]
		private int assessmentCategoryID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active = true;
		[ColumnMapping("LogicID",StereoType=DataStereoType.FK)]
		private int logicID;
		[ColumnMapping("AssessmentParagraphBodyID",StereoType=DataStereoType.FK)]
		private int assessmentParagraphBodyID;
		[ColumnMapping("AssessmentParagraphBrief")]
		private string assessmentParagraphBrief;
		[ColumnMapping("SortOrder",StereoType=DataStereoType.FK)]
		private int sortOrder;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		private AssessmentParagraphBody assessmentParagraphBody;

		[ColumnMapping("LogicDescription", JoinColumn="Description", JoinRelation="AssessmentParagraph.logicID = [logic].logicID", SQLGen=SQLGenerationFlags.NoInsertUpdate)]
		private string logicDescription;

		//private int sortOrderWhenLoaded;
		//private bool activeWhenLoaded;
	
		public AssessmentParagraph()
		{
		}

		public AssessmentParagraph(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[FieldDescription("@ID@")]
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int AssessmentParagraphID
		{
			get { return this.assessmentParagraphID; }
			set { this.assessmentParagraphID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AssessmentCategoryID
		{
			get { return this.assessmentCategoryID; }
			set { this.assessmentCategoryID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[FieldDescription("@POSITION@")]
		[FieldValuesMember("ValuesOf_SortOrder")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		[FieldDescription("@LOGIC@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int LogicID
		{
			get { return this.logicID; }
			set { this.logicID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssessmentParagraphBodyID
		{
			get { return this.assessmentParagraphBodyID; }
			set { this.assessmentParagraphBodyID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LogicDescription
		{
			get { return this.logicDescription; }
			set { this.logicDescription = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		public AssessmentCategory ParentAssessmentCategory
		{
			get { return this.parentAssessmentCategory; }
			set 
			{ 
				this.parentAssessmentCategory = value;
				if(value == null)
					this.assessmentCategoryID = 0;
				else
					this.assessmentCategoryID = value.AssessmentCategoryID;
			}
		}

		/// <summary>
		/// Parent AssessmentParagraphCollection that contains this element
		/// </summary>
		public AssessmentParagraphCollection ParentAssessmentParagraphCollection
		{
			get
			{
				return this.parentAssessmentParagraphCollection;
			}
			set
			{
				this.parentAssessmentParagraphCollection = value; // parent is set when added to a collection
			}
		}

		

		/// <summary>
		/// Contained AssessmentParagraphBody object
		/// </summary>
		[Contained]
		public AssessmentParagraphBody AssessmentParagraphBody
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.assessmentParagraphBody = (AssessmentParagraphBody)AssessmentParagraphBody.EnsureContainedDataObject(this, typeof(AssessmentParagraphBody), assessmentParagraphBody, false, assessmentParagraphBodyID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.assessmentParagraphBody;
			}
			set
			{
				this.assessmentParagraphBody = value;
				if (value != null) value.ParentAssessmentParagraph = this; // set this as a parent of the child data class
			}
		}

		public object[,] ValuesOf_SortOrder
		{
			get
			{	
				if (this.ParentAssessmentCategory != null)
					return (this.ParentAssessmentCategory).ValuesOf_ParagraphPosition(this.assessmentParagraphID);
				else
				{
					return new object[,] 
					{
						{(int)1, AssessmentParagraphPosition.First.ToString()},
						{(int)2, AssessmentParagraphPosition.Normal.ToString()},
						{(int)3, AssessmentParagraphPosition.Last.ToString()},
					}; // return possible field values
				}
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			this.assessmentParagraphBody.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			{
				base.InternalSave();	// in that case, delete the base first
				assessmentParagraphBody.MarkDel();	// then allow the deletion of the conatined object
			}
			assessmentParagraphBody.Save();
			this.assessmentParagraphBodyID = assessmentParagraphBody.AssessmentParagraphBodyID; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.
			UpdateSortOder();
		}

		public void UpdateSortOder()
		{
			if(this.ParentAssessmentCategory == null)
				return;

			if(this.sortOrder == 1 /*First Paragraph*/)
				this.ParentAssessmentCategory.SetFirstPositionOwner(this);	
			else if(this.sortOrder == 3 /*Last Paragraph*/)
				this.ParentAssessmentCategory.SetLastPositionOwner(this);
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=128)]
		public string AssessmentParagraphBrief
		{
			get { return this.assessmentParagraphBrief; }
			set { this.assessmentParagraphBrief = value; }
		}

		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);
			//this.sortOrderWhenLoaded = this.sortOrder;
			//this.activeWhenLoaded = this.active;
			this.UpdateSortOder();
		}

	}

	/// <summary>
	/// Strongly typed collection of AssessmentParagraph objects
	/// </summary>
	[ElementType(typeof(AssessmentParagraph))]
	public class AssessmentParagraphCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass, ICollectionElementFilter
	{
		protected int activeWithAll = -1;

		public int FilterByActiveWithAll
		{
			get { return this.activeWithAll; }
			set { this.activeWithAll = value; }
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AssessmentParagraph elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAssessmentParagraphCollection = this;
			else
				elem.ParentAssessmentParagraphCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AssessmentParagraph elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AssessmentParagraph this[int index]
		{
			get
			{
				return (AssessmentParagraph)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AssessmentParagraph)oldValue, false);
			SetParentOnElem((AssessmentParagraph)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(AssessmentParagraph elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((AssessmentParagraph)value, true);

			base.OnInsertComplete (index, value);
			this[index].ParentAssessmentCategory = this.ParentDataObject as AssessmentCategory;
		}


		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchAssessmentParagraph(int maxRecords, AssessmentParagraph searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchAssessmentParagraph", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}

		public static AssessmentParagraphCollection GetFromSearch(AssessmentParagraph searcher)
		{
			AssessmentParagraphCollection col = new AssessmentParagraphCollection();
			col.SearchAssessmentParagraph(-1, searcher);
			return col;
		}

		/// <summary>
		/// Parent AssessmentCategory that contains this collection
		/// </summary>
		public AssessmentCategory ParentAssessmentCategory
		{
			get { return this.ParentDataObject as AssessmentCategory; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AssessmentCategory */ }
		}

		#region ICollectionElementFilter Members

		public bool FilterElement(int index)
		{
			if(this.activeWithAll == -1)
				return true;
			bool visible = (this.activeWithAll == 0 ? false : true);
			return ((this[index].Active == visible) ? true : false);
		}

		#endregion

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAssessmentParagraphByCategory(int maxRecords, int assessmentCategoryID, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadAssessmentParagraphByCategory", maxRecords, this, false, new object[] { assessmentCategoryID, active });
		}

		public int GetPreQualifiedAssessmentParagraphsByCategory(string assessmentGUID, int assessmentCategoryID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAssessmentParagraphsByCategory", -1, this, false, new object[] { assessmentGUID, assessmentCategoryID});
		}

		public int GetICMLetterParagraphsByCategory(int maxRecords, int cMSID, int categoryID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetICMLetterParagraphsByCategory", maxRecords, this, false, new object[] { cMSID, categoryID});
		}

	}
}
