using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_GetAssessmentPOCDeficitsByAnswerID","SelectAllByGivenArgs.sptpl","answerID")] 
	[SPInsert("usp_InsertAssessmentPOCDeficit")]
	[SPUpdate("usp_UpdateAssessmentPOCDeficit")]
	[SPDelete("usp_DeleteAssessmentPOCDeficit")]
	[SPLoad("usp_LoadAssessmentPOCDeficit")]
	[TableMapping("AssessmentPOCDeficit","assessmentPOCDeficitID")]
	public class AssessmentPOCDeficit : BaseData
	{
		[NonSerialized]
		private AssessmentPOCDeficitCollection parentAssessmentPOCDeficitCollection;
		[ColumnMapping("AssessmentPOCDeficitID",StereoType=DataStereoType.FK)]
		private int assessmentPOCDeficitID;
		[ColumnMapping("POCDeficitTypeID",StereoType=DataStereoType.FK)]
		private int pOCDeficitTypeID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("AnswerID",StereoType=DataStereoType.FK)]
		private int answerID;
		[ColumnMapping("AnswerRangeID",StereoType=DataStereoType.FK)]
		private int answerRangeID;
		[ColumnMapping("LogicID",StereoType=DataStereoType.FK)]
		private int logicID;
	
		public AssessmentPOCDeficit() : base()
		{
		}

		public AssessmentPOCDeficit(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AssessmentPOCDeficitID
		{
			get { return this.assessmentPOCDeficitID; }
			set { this.assessmentPOCDeficitID = value; }
		}

		[FieldValuesMember("LookupOf_POCDeficitTypeID", "POCDeficitTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int POCDeficitTypeID
		{
			get { return this.pOCDeficitTypeID; }
			set { this.pOCDeficitTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AnswerID
		{
			get { return this.answerID; }
			set { this.answerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AnswerRangeID
		{
			get { return this.answerRangeID; }
			set { this.answerRangeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LogicID
		{
			get { return this.logicID; }
			set { this.logicID = value; }
		}



		public POCDeficitTypeCollection LookupOf_POCDeficitTypeID
		{
			get
			{
				return POCDeficitTypeCollection.ActivePOCDeficitTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent AssessmentPOCDeficitCollection that contains this element
		/// </summary>
		public AssessmentPOCDeficitCollection ParentAssessmentPOCDeficitCollection
		{
			get
			{
				return this.parentAssessmentPOCDeficitCollection;
			}
			set
			{
				this.parentAssessmentPOCDeficitCollection = value; // parent is set when added to a collection
			}
		}


	}

	/// <summary>
	/// Strongly typed collection of AssessmentPOCDeficit objects
	/// </summary>
	[ElementType(typeof(AssessmentPOCDeficit))]
	public class AssessmentPOCDeficitCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AssessmentPOCDeficit elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAssessmentPOCDeficitCollection = this;
			else
				elem.ParentAssessmentPOCDeficitCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AssessmentPOCDeficit elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AssessmentPOCDeficit this[int index]
		{
			get
			{
				return (AssessmentPOCDeficit)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AssessmentPOCDeficit)oldValue, false);
			SetParentOnElem((AssessmentPOCDeficit)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAssessmentLevelOfDiseasesByAnswerID(int maxRecords, int answerID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAssessmentPOCDeficitsByAnswerID", maxRecords, this, new object[] {answerID}, false);
		}

		/// <summary>
		/// Parent Answer that contains this collection
		/// </summary>
		public Answer ParentAnswer
		{
			get { return this.ParentDataObject as Answer; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Answer */ }
		}

		/// <summary>
		/// Parent AnswerRange that contains this collection
		/// </summary>
		public AnswerRange ParentAnswerRange
		{
			get { return this.ParentDataObject as AnswerRange; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AnswerRange */ }
		}

	}
}