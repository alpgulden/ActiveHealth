using System;
using NetsoftUSA.DataLayer;
using System.Collections;
using System.Collections.Specialized;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Strongly typed collection of Response objects
	/// </summary>
	[ElementType(typeof(Response))]
	public class ResponseCollection : BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_AnswerID;
		[NonSerialized]
		private CollectionIndexer indexBy_ResponseID;
		private AssessmentContext assessmentContext;

		public AssessmentContext AssessmentContext
		{
			get { return assessmentContext; }
			set { assessmentContext = value; }
		}

		public Answer GetAnswerByAnswerIndexID(int questionIndexID, int componentIndexID, int answerIndexID)
		{
			// Lookup for the question and answer
			Question question = assessmentContext.Questions.FindByIndexID(questionIndexID, componentIndexID);
			return question.Answers.FindByAnswerIndexID(answerIndexID);
		}

		public Answer GetAnswerByAnswerID(int questionID, int answerID)
		{
			// Lookup for the question and answer
			Question question = assessmentContext.Questions.FindBy(questionID);
			return question.Answers.FindBy(answerID);
		}

		/// <summary>
		/// Overload for SetResponse
		/// </summary>
		/// <param name="questionIndexID">QuestionIndex ID</param>
		/// <param name="answerIndexID">AnswerIndex ID</param>
		/// <param name="response">Numeric response</param>
		/// <returns>A boolean value representing whether the operation was successful</returns>
		public bool SetResponse(int questionIndexID, int componentIndexID, int answerIndexID, int response, AnswerDataType dataType, bool deleteOldResponses)
		{
			return SetResponse(questionIndexID, componentIndexID, answerIndexID, response.ToString(), dataType, deleteOldResponses);
		}

		/// <summary>
		/// Sets the response for the given question and answer pair
		/// </summary>
		/// <param name="questionIndexID">QuestionIndex ID</param>
		/// <param name="answerIndexID">AnswerIndex ID</param>
		/// <param name="response">Response</param>
		/// <returns>A boolean value representing whether the operation was successful</returns>
		public bool SetResponse(int questionIndexID, int componentIndexID, int answerIndexID, string responseText, AnswerDataType dataType, bool deleteOldResponses)
		{
			this.IndexBy_AnswerID.Rebuild();

			Answer answer = GetAnswerByAnswerIndexID(questionIndexID, componentIndexID, answerIndexID);

			if (deleteOldResponses)
			{
				// Delete all the responses for this question
				DeleteResponses(questionIndexID, componentIndexID, true, false);
			}

			// Try to find the response
			Response response = this.FindByAnswerID(answer.AnswerID);
			if (response == null)
			{
				// Create new if necessary
				response = new Response(true);

				// This response is new so add it to the collection
				this.AddRecord(response);
			}				
				// If the response exists but marked for deletion remove the mark and make the changes
			else if (response.IsMarkedForDeletion)
			{
				response.IsMarkedForDeletion = false;
				response.IsDirty = true;
			}
				
			// Finally set the actual response
			//response.AnswerText = responseText;

			if (responseText == null)
				response.AnswerText = answer.AnswerText;
			else
				response.AnswerText = responseText;
			
			response.AnswerID = answer.AnswerID;
			response.AnswerTypeID = answer.AnswerTypeID;
			response.AssessmentGUID = assessmentContext.AssessmentGUID;
			response.DataType = dataType;
			response.QuestionID = answer.QuestionID;
			
			// If this is a response for a CC DropDown Question
			response.CCAnswerID = answer.CCAnswerID;
			response.CCSourceID = answer.CCSourceID;

			response.IsDirty = true;

			ResetIndexers();

			assessmentContext.Cache();

			return true;
		}


		/// <summary>
		/// Finds all responses for a given questions and deletes them
		/// </summary>
		/// <param name="questionIndexID">QuestionIndex ID</param>
		/// <param name="deleteMedications">Should the Medication responses be deleted?</param>
		public void DeleteResponses(int questionIndexID, int componentIndexID, bool deleteMedications, bool deleteSubQuestionResponses)
		{
			Question question = assessmentContext.Questions.FindByIndexID(questionIndexID, componentIndexID);

			DeleteResponses(question, deleteMedications, deleteSubQuestionResponses);
		}


		public void DeleteResponses(int questionID, bool deleteMedications, bool deleteSubQuestionResponses)
		{
			Question question = assessmentContext.Questions.FindBy(questionID);

			DeleteResponses(question, deleteMedications, deleteSubQuestionResponses);	
		}

		public void DeleteResponses(Question question, bool deleteMedications, bool deleteSubQuestionResponses)
		{
			// Delete main question's responses
			DeleteResponses(question.QuestionID, deleteMedications);

			if (deleteSubQuestionResponses)
			{
				// Delete sub questions' responses
				foreach (Question subQuestion in question.SubQuestions)
				{
					DeleteResponses(subQuestion.QuestionID, deleteMedications);
				}
			}
		}

	
		public void DeleteResponses(int questionID, bool deleteMedications)
		{
			Response response = null;
			// Find all the responses for this specific question
			ArrayList responses = this.FilterBy(questionID);
			if (responses != null)
			{
				for (int  i = 0; i < responses.Count; i++)
				{
					response = (Response)responses[i];
					// If the response is a medication response we may not be supposed to delete them
					if (!(response.AnswerType == AnswerTypeEnum.Medication && !deleteMedications))
						response.MarkDel();
				}
			}

			assessmentContext.Cache();
		}



		/// <summary>
		/// Finds a specific response for a given questions and deletes it
		/// </summary>
		/// <param name="questionIndexID">QuestionIndex ID</param>
		/// <param name="answerIndexID">AnswerIndex ID</param>
		public void DeleteResponse(int questionIndexID, int componentIndexID, int answerIndexID)
		{
			Answer answer = GetAnswerByAnswerIndexID(questionIndexID, componentIndexID, answerIndexID);

			// Try to find the response
			Response response = this.FindByAnswerID(answer.AnswerID);
			response.MarkDel();

			assessmentContext.Cache();
		}



		/// <summary>
		/// Returns the response for a given answer
		/// </summary>
		/// <param name="answerID">Answer ID</param>
		/// <returns>Response</returns>
		public string GetResponse(int answerID)
		{
			Response response = this.FindByAnswerID(answerID);
			if (response != null && !response.IsMarkedForDeletion)
				return response.AnswerText;
			else
				return null;
		}


		/// <summary>
		/// Returns the response for a given answer
		/// </summary>
		/// <param name="answerID">Answer ID</param>
		/// <returns>Response</returns>
		public string GetResponse(int questionIndexID, int componentIndexID, int answerIndexID)
		{
			Answer answer = GetAnswerByAnswerIndexID(questionIndexID, componentIndexID, answerIndexID);

			return GetResponse(answer.AnswerID);
		}


		public bool CheckResponse(int questionIndexID, int componentIndexID, int answerIndexID/*, string response*/)
		{
			Answer answer = GetAnswerByAnswerIndexID(questionIndexID, componentIndexID, answerIndexID);

			return CheckResponse(answer.AnswerID/*, response*/);
		}

		public bool CheckAnswerActive(int questionIndexID, int componentIndexID, int answerIndexID)
		{
			Answer answer = GetAnswerByAnswerIndexID(questionIndexID, componentIndexID, answerIndexID);
			return answer.Active;
		}

	

		/// <summary>
		/// Given Question ID, Answer ID and a response, 
		/// checks if the given response matches with the actual response
		/// </summary>
		/// <param name="questionID">Question ID</param>
		/// <param name="answerID">Answer ID</param>
		/*/// <param name="response">Response</param>*/
		/// <returns>Boolean value showing whether responses match or not</returns>
		public bool CheckResponse(int answerID/*, string responseText*/)
		{
			Response response = this.FindByAnswerID(answerID);
			if (response != null && !response.IsMarkedForDeletion) 
				return true; /*(response.AnswerText != null && response.AnswerText.Equals(responseText));*/
			return false;
		}


		/// <summary>
		/// Checks and returns a boolean indicating whether the question has any responses
		/// </summary>
		/// <param name="questionIndexID">QuestionIndex ID</param>
		/// <returns>A boolean value indication whether the question has any responses</returns>
		public bool HasResponses(int questionIndexID, int componentIndexID)
		{
			Question question = assessmentContext.Questions.FindByIndexID(questionIndexID, componentIndexID);
			return HasResponses(question.QuestionID);
		}

		public bool HasResponses(int questionID)
		{
			ArrayList responses = this.FilterBy(questionID);
			if (responses != null)
			{
				for (int i = 0; i < responses.Count; i++)
				{
					if (!((Response)responses[i]).IsMarkedForDeletion) return true;
				}
			}
			return false;
		}
			


		/// <summary>
		/// Clears responses that belong to a question which no longer has at least one visible instance
		/// </summary>
		/// <param name="questionVisibilities"></param>
		public bool ClearResponsesForInVisibleQuestions(ref Hashtable questionVisibilities)
		{
			Response response;
			bool atLeastOneDeleted = false;	
			// Go over the responses to find the ones that belong to a question which no longer has at least one visible instance
			for (int i = 0; i < this.Count; i++)
			{
				response = this[i];
				// If the response is already marked for deletion don't bother looking at it
				if (!response.IsMarkedForDeletion)
				{
					// If the question is not marked as visible that means there's no instance of this question
					// that's visible
					if (questionVisibilities[response.QuestionID] == null || !((bool)questionVisibilities[response.QuestionID]))
					{
						// Delete the response for this question, including its sub questions
						this.DeleteResponses(response.QuestionID, false, true);
						atLeastOneDeleted = true;
					}
				}
			}

			return atLeastOneDeleted;
		}





		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Response elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentResponseCollection = this;
			else
				elem.ParentResponseCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Response elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Response this[int index]
		{
			get
			{
				return (Response)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Response)oldValue, false);
			SetParentOnElem((Response)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		protected override void InternalSaveElements()
		{
			base.InternalSaveElements ();

			ResetIndexers();

			//UpdatePatientLevelOfDiseases();
			//UpdatePatientRisks();
		
			assessmentContext.Cache();
		}

		/// <summary>
		/// This method goes thru the responses and ensures the necessary LevelOfDiseases tied to answers and answerranges are created
		/// </summary>
		public void UpdatePatientLevelOfDiseases()
		{
			// Get the collection of PatientLevelOfDiseases from DB
			PatientLevelOfDiseaseCollection patientLevelOfDiseases = new PatientLevelOfDiseaseCollection();
			patientLevelOfDiseases.LoadPatientLevelOfDiseases(assessmentContext.AssessmentGUID);

			Answer answer = null;
			// Go thru each response record and create/update appropriate PatientLevelOfDisease record
			foreach (Response response in this)
			{
				// Find the answer object for this response and check if the LevelOfDisease tied to it needs to be created
				answer = GetAnswerByAnswerID(response.QuestionID, response.AnswerID);
				if (answer != null)
				{
					EnsurePatientLevelOfDisease(patientLevelOfDiseases, answer.AssessmentLevelOfDisease);

					// Go thru each answerrange for this answer and check if the LevelOfDisease tied to it needs to be created
					foreach (AnswerRange answerRange in answer.AnswerRanges)						
					{
						EnsurePatientLevelOfDisease(patientLevelOfDiseases, answerRange.AssessmentLevelOfDisease);
					}
				}
			}


			// We need to call UpdateMeasurements at this point because some measurements may include LevelOfDiseases
			UpdatePatientMeasurements(patientLevelOfDiseases);
            			


			// Go thru the existing PatientLevelOfDisease records and find the ones that are not newly created or updated by the code above.
			// Because if the code above did not touch a specific record that means it's not valid anymore and it should be deleted. 
			foreach (PatientLevelOfDisease patientLevelOfDisease in patientLevelOfDiseases)
			{
				if (!patientLevelOfDisease.IsDirty) patientLevelOfDisease.MarkDel();
			}

			// Save the collection to update the DB 
			patientLevelOfDiseases.Save();
			
			patientLevelOfDiseases.ResetIndexers();
		}

		/// <summary>
		/// Checks if a PatientLevelOfDisease record needs to be created and if so creates it
		/// </summary>
		/// <param name="patientLevelOfDiseases">Collection of current PatientLevlOfDiseases</param>
		/// <param name="assessmentLevelOfDisease">The current assessmentLevelOfDisease</param>
		private void EnsurePatientLevelOfDisease(PatientLevelOfDiseaseCollection patientLevelOfDiseases, AssessmentLevelOfDisease assessmentLevelOfDisease)
		{
			// If there is no AssessmentLEvelOfDisease record or its logic does not evalute to true leave the method
			if (assessmentLevelOfDisease == null || assessmentLevelOfDisease.AssessmentLevelOfDiseaseID == 0 || !assessmentContext.LogicEvaluator.EvaluateExpression(assessmentLevelOfDisease.LogicID))
				return;

			patientLevelOfDiseases.IndexBy_AssessmentLevelOfDiseaseID.Rebuild();

			// See if the LevelOfDisease already exits
			PatientLevelOfDisease patientLevelOfDisease = patientLevelOfDiseases.FindByAssessment(assessmentLevelOfDisease.AssessmentLevelOfDiseaseID);
			if (patientLevelOfDisease == null)
			{
				// Create a new one
				patientLevelOfDisease = new PatientLevelOfDisease(true);
				// Add it to the collection
				patientLevelOfDiseases.AddRecord(patientLevelOfDisease);
			}

			// Set all the necessary properties
			patientLevelOfDisease.AssessmentLevelOfDiseaseID = assessmentLevelOfDisease.AssessmentLevelOfDiseaseID;
			patientLevelOfDisease.AssessmentGUID = assessmentContext.AssessmentGUID;
			patientLevelOfDisease.CMSID = assessmentContext.CMS.CMSID;
			patientLevelOfDisease.LevelOfDiseaseDate = DateTime.Now;
			patientLevelOfDisease.LevelOfDiseaseDescription = assessmentLevelOfDisease.Description;
			patientLevelOfDisease.LevelOfDiseaseTypeID = assessmentLevelOfDisease.LevelOfDiseaseTypeID;
			patientLevelOfDisease.PatientID = assessmentContext.CMS.PatientId;
			// Set the dirty so if the record is an existing one it'll be updated in the DB
			patientLevelOfDisease.IsDirty = true;
		}

		/// <summary>
		/// Checks if a PatientLevelOfDisease record needs to be created and if so creates it
		/// This method is called from UpdatePatientMeasurements
		/// </summary>
		/// <param name="patientLevelOfDiseases">Collection of current PatientLevlOfDiseases</param>
		/// <param name="assessmentLevelOfDisease">The current assessmentLevelOfDisease</param>
		private void EnsurePatientLevelOfDisease(PatientLevelOfDiseaseCollection patientLevelOfDiseases, MeasurementLevelOfDisease measurementLevelOfDisease, int assessmentMeasurementID)
		{
			// If there is no AssessmentLEvelOfDisease record or its logic does not evalute to true leave the method
			if (measurementLevelOfDisease == null || measurementLevelOfDisease.MeasurementLevelOfDiseaseID == 0)
				return;

			patientLevelOfDiseases.IndexBy_MeasurementLevelOfDiseaseID.Rebuild();

			// See if the LevelOfDisease already exits
			PatientLevelOfDisease patientLevelOfDisease = patientLevelOfDiseases.FindByMeasurement(measurementLevelOfDisease.MeasurementLevelOfDiseaseID);
			if (patientLevelOfDisease == null)
			{
				// Create a new one
				patientLevelOfDisease = new PatientLevelOfDisease(true);
				// Add it to the collection
				patientLevelOfDiseases.AddRecord(patientLevelOfDisease);
			}

			// Set all the necessary properties
			patientLevelOfDisease.MeasurementLevelOfDiseaseID = measurementLevelOfDisease.MeasurementLevelOfDiseaseID;
			patientLevelOfDisease.AssessmentMeasurementID = assessmentMeasurementID;
			patientLevelOfDisease.AssessmentGUID = assessmentContext.AssessmentGUID;
			patientLevelOfDisease.CMSID = assessmentContext.CMS.CMSID;
			patientLevelOfDisease.LevelOfDiseaseDate = DateTime.Now;
			//patientLevelOfDisease.LevelOfDiseaseDescription = assessmentLevelOfDisease.Description;
			patientLevelOfDisease.LevelOfDiseaseTypeID = measurementLevelOfDisease.LevelOfDiseaseTypeID;
			patientLevelOfDisease.PatientID = assessmentContext.CMS.PatientId;
			// Set the dirty so if the record is an existing one it'll be updated in the DB
			patientLevelOfDisease.IsDirty = true;
		}



		/// <summary>
		/// This method goes thru the responses and ensures the necessary Risks tied to answers and answerranges are created
		/// </summary>
		public void UpdatePatientRisks()
		{
			// Get the collection of PatientRisks from DB
			PatientRiskCollection patientRisks = new PatientRiskCollection();
			patientRisks.LoadPatientRisks(assessmentContext.AssessmentGUID);

			Answer answer = null;
			// Go thru each response record and create/update appropriate PatientRisk record
			foreach (Response response in this)
			{
				// Find the answer object for this response and check if the Risk tied to it needs to be created
				answer = GetAnswerByAnswerID(response.QuestionID, response.AnswerID);
				if (answer != null)
				{
					EnsurePatientRisk(patientRisks, answer.AssessmentRisk);

					// Go thru each answerrange for this answer and check if the Risk tied to it needs to be created
					foreach (AnswerRange answerRange in answer.AnswerRanges)						
					{
						EnsurePatientRisk(patientRisks, answerRange.AssessmentRisk);
					}
				}
			}

			// Clear the overall risk
			this.assessmentContext.OverallRiskID = 0; 
			this.assessmentContext.OverallRiskSeverityOrder = int.MaxValue;

			CMSRiskCollection activeCMSRisks = CMSRiskCollection.ActiveCMSRisks;
			CMSRisk risk = null;

			// Go thru the existing PatientRisk records and find the ones that are not newly created or updated by the code above.
			// Because if the code above did not touch a specific record that means it's not valid anymore and it should be deleted. 
			foreach (PatientRisk patientRisk in patientRisks)
			{
				if (!patientRisk.IsDirty) 
					patientRisk.MarkDel();
				else
				{
					risk = activeCMSRisks.FindBy(patientRisk.CMSRiskID);
					if (risk != null)
					{
						// If the risk has higher severity than the current overall risk, set it as the current overall risk
						if (this.assessmentContext.OverallRiskID == 0 ||  risk.SeverityOrder < this.assessmentContext.OverallRiskSeverityOrder)
						{
							this.assessmentContext.OverallRiskID = risk.CMSRiskId;
							this.assessmentContext.OverallRiskSeverityOrder = risk.SeverityOrder;
						}
					}
				}
			}

			// Save the collection to update the DB 
			patientRisks.Save();     		
	
			patientRisks.ResetIndexers();

			CMS cMS = assessmentContext.CMS;
			CMSRisk latestRisk = null;

			bool updateCMSStatusRisk = true;

			// Check if we have a real CMSStatusHistory
			// Need to check for the IsNew flag because the public property always returns and object, even if it has to create a new one
			if (cMS.LatestCMSStatusHistory != null && !cMS.LatestCMSStatusHistory.IsNew) 
			{
				latestRisk = activeCMSRisks.FindBy(cMS.LatestCMSStatusHistory.CMSRiskId);
				if (latestRisk != null && latestRisk.SeverityOrder < this.assessmentContext.OverallRiskSeverityOrder)
					updateCMSStatusRisk = false;
			}

			if (updateCMSStatusRisk)
			{
				// Update the CMS and add a history record
				// Mark the record as new so that we save a copy
				cMS.LatestCMSStatusHistory.New();
				cMS.LatestCMSStatusHistory.CMSRiskId = assessmentContext.OverallRiskID;
				cMS.SaveCMSStatusHistories();
			}
		}

		/// <summary>
		/// Checks if a PatientRisk record needs to be created and if so creates it
		/// </summary>
		/// <param name="patientRisks">Collection of current PatientLevlOfDiseases</param>
		/// <param name="assessmentRisk">The current assessmentRisk</param>
		private void EnsurePatientRisk(PatientRiskCollection patientRisks, AssessmentRisk assessmentRisk)
		{
			// If there is no AssessmentRisk record or its logic does not evalute to true leave the method
			if (assessmentRisk == null || assessmentRisk.AssessmentRiskID == 0 || !assessmentContext.LogicEvaluator.EvaluateExpression(assessmentRisk.LogicID))
				return;

			patientRisks.IndexBy_AssessmentRiskID.Rebuild();

			// See if the Risk already exits
			PatientRisk patientRisk = patientRisks.FindBy(assessmentRisk.AssessmentRiskID);
			if (patientRisk == null)
			{
				// Create a new one
				patientRisk = new PatientRisk(true);
				// Add it to the collection
				patientRisks.AddRecord(patientRisk);
			}
						
			// Set all the necessary properties
			patientRisk.AssessmentGUID = assessmentContext.AssessmentGUID;
			patientRisk.AssessmentRiskID = assessmentRisk.AssessmentRiskID;
			patientRisk.CMSID = assessmentContext.CMS.CMSID;
			patientRisk.RiskDate = DateTime.Now;
			patientRisk.RiskDescription = assessmentRisk.Description;
			patientRisk.CMSRiskID = assessmentRisk.RiskTypeID;
			patientRisk.PatientID = assessmentContext.CMS.PatientId;
			// Set the dirty so if the record is an existing one it'll be updated in the DB
			patientRisk.IsDirty = true;
		}

		

				
		
		/// <summary>
		/// This method goes thru the responses and ensures the necessary Measurements tied to answers and answerranges are created
		/// It also creates LevelOfDisease records if they are tied to measurement type
		/// </summary>
		public void UpdatePatientMeasurements(PatientLevelOfDiseaseCollection patientLevelOfDiseases)
		{
			// Get the collection of PatientMeasurements from DB
			PatientMeasurementCollection patientMeasurements = new PatientMeasurementCollection();
			patientMeasurements.LoadPatientMeasurements(assessmentContext.AssessmentGUID);

			Answer answer = null;
			// Go thru each response record and create/update appropriate PatientMeasurement record
			foreach (Response response in this)
			{
				// Find the answer object for this response and check if the Measurement tied to it needs to be created
				answer = GetAnswerByAnswerID(response.QuestionID, response.AnswerID);
				if (answer != null)
				{
					EnsurePatientMeasurement(patientMeasurements, answer.AssessmentMeasurement, patientLevelOfDiseases, response);

					// Go thru each answerrange for this answer and check if the Measurement tied to it needs to be created
					foreach (AnswerRange answerRange in answer.AnswerRanges)						
					{
						EnsurePatientMeasurement(patientMeasurements, answerRange.AssessmentMeasurement, patientLevelOfDiseases, response);
					}
				}
			}

			// Go thru the existing PatientMeasurement records and find the ones that are not newly created or updated by the code above.
			// Because if the code above did not touch a specific record that means it's not valid anymore and it should be deleted. 
			foreach (PatientMeasurement patientMeasurement in patientMeasurements)
			{
				if (!patientMeasurement.IsDirty) patientMeasurement.MarkDel();
			}

			// Save the collection to update the DB 
			patientMeasurements.Save();     
			
			patientMeasurements.ResetIndexers();
		}

		/// <summary>
		/// Checks if a PatientMeasurement record needs to be created and if so creates it
		/// </summary>
		/// <param name="patientMeasurements">Collection of current PatientLevlOfDiseases</param>
		/// <param name="assessmentMeasurement">The current assessmentMeasurement</param>
		private void EnsurePatientMeasurement(PatientMeasurementCollection patientMeasurements, AssessmentMeasurement assessmentMeasurement, PatientLevelOfDiseaseCollection patientLevelOfDiseases, Response response)
		{
			// If there is no AssessmentMeasurement record or its logic does not evalute to true leave the method
			if (assessmentMeasurement == null || assessmentMeasurement.AssessmentMeasurementID == 0 || !assessmentContext.LogicEvaluator.EvaluateExpression(assessmentMeasurement.LogicID))
				return;

			patientMeasurements.IndexBy_AssessmentMeasurementID.Rebuild();

			// See if the Measurement already exits
			PatientMeasurement patientMeasurement = patientMeasurements.FindBy(assessmentMeasurement.AssessmentMeasurementID);
			if (patientMeasurement == null)
			{
				// Create a new one
				patientMeasurement = new PatientMeasurement(true);
				// Add it to the collection
				patientMeasurements.AddRecord(patientMeasurement);
			}
						
			// Set all the necessary properties
			patientMeasurement.AssessmentGUID = assessmentContext.AssessmentGUID;
			patientMeasurement.AssessmentMeasurementID = assessmentMeasurement.AssessmentMeasurementID;
			//patientMeasurement.CMSID = assessmentContext.CMS.CMSID;
			patientMeasurement.MeasurementDate = DateTime.Now;
			//patientMeasurement.MeasurementDescription = assessmentMeasurement.Description;
			patientMeasurement.MeasurementTypeID = assessmentMeasurement.MeasurementTypeID;
			patientMeasurement.PatientID = assessmentContext.CMS.PatientId;
			patientMeasurement.MeasurementValue = response.AnswerText;
			// Set the dirty so if the record is an existing one it'll be updated in the DB
			patientMeasurement.IsDirty = true;

            
			// Get MeasurementType and see if it's tied to any LevelOfDiseases
			MeasurementType measurementType = new MeasurementType(assessmentMeasurement.MeasurementTypeID);
			measurementType.LoadMeasurementLevelOfDiseases(true);
			// For each LevelofDisease call Ensure method to create/remove the LevelOfDisease from PatientLevelOfDisease
			try
			{
				int measurementValue = int.Parse(response.AnswerText);

				foreach (MeasurementLevelOfDisease mLevelOfDisease in measurementType.MeasurementLevelOfDiseases)
				{
					if (mLevelOfDisease.ThreshholdLow <= measurementValue && mLevelOfDisease.ThreshholdHigh >= measurementValue)
						EnsurePatientLevelOfDisease(patientLevelOfDiseases, mLevelOfDisease, assessmentMeasurement.AssessmentMeasurementID);
				}
			}
			catch
			{
				
			}
		}

		
		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadByAssessmentGUID(string assessmentGUID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetResponsesByAssessmentGUID", -1, this, false, new object[] {assessmentGUID});
		}

		/// <summary>
		/// Hashtable based index on responseID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ResponseID
		{
			get
			{
				if (this.indexBy_ResponseID == null)
					this.indexBy_ResponseID = new CollectionIndexer(this, new string[] { "responseID" }, true);
				return this.indexBy_ResponseID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on responseID fields returns the collection index.  Uses the IndexBy_ResponseID indexer.
		/// </summary>
		public int IndexOfByResponseID(int responseID)
		{
			return this.IndexBy_ResponseID.IndexOf(responseID);
		}


		/// <summary>
		/// Hashtable based index on answerID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_AnswerID
		{
			get
			{
				if (this.indexBy_AnswerID == null)
					this.indexBy_AnswerID = new CollectionIndexer(this, new string[] { "answerID" }, true);
				return this.indexBy_AnswerID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on answerID fields returns the collection index.  Uses the IndexBy_AnswerID indexer.
		/// </summary>
		public int IndexOfByAnswerID(int answerID)
		{
			return this.IndexBy_AnswerID.IndexOf(answerID);
		}

		/// <summary>
		/// Hashtable based search on responseID fields returns the object.  Uses the IndexBy_ResponseID indexer.
		/// </summary>
		public Response FindByReponseID(int responseID)
		{
			return (Response)this.IndexBy_ResponseID.GetObject(responseID);
		}

		public Response FindByAnswerID(int answerID)
		{
			return (Response)this.IndexBy_AnswerID.GetObject(answerID);
		}


		public override int AddRecord(BaseDataClass data)
		{
			int ret = base.AddRecord (data);
			//ResetIndexers();
			return ret;
		}

		private void ResetIndexers()
		{
			// Rebuild indexers
			// TODO: Remove this when the library automatically supports this feature
			indexBy_AnswerID = null;
			indexBy_ResponseID = null;
		}

		/// <summary>
		/// Returns respones filtered by question id
		/// </summary>
		/// <param name="questionID"></param>
		/// <returns></returns>
		public ArrayList FilterBy(int questionID)
		{
			ArrayList responses = new ArrayList(5);
			for (int i = 0; i < this.Count; i++)
			{
				if (this[i].QuestionID == questionID)
					responses.Add(this[i]);
			}
			if (responses.Count > 0)
				return responses;
			else
				return null;
		}

		/// <summary>
		/// Parent Assessment that contains this collection
		/// </summary>
		public Assessment ParentAssessment
		{
			get { return this.ParentDataObject as Assessment; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Assessment */ }
		}
		

	}

}
