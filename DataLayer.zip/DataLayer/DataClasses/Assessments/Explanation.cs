using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[TableMapping("Explanation","explanationID")]
	public class Explanation : BaseData
	{
		public Explanation()
		{
			//
			// TODO: Add constructor logic here
			//
		}

	}
}
