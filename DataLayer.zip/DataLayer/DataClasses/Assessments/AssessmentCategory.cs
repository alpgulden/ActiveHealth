using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [AssessmentCategory]
	/// </summary>
	[SPAutoGen("usp_GetActiveAssessmentCategoriesByActive","CodeTableLoader.sptpl","active")]
	[SPAutoGen("usp_GetActiveAssessmentCategoriesByCMSTypeID","SelectAllByGivenArgs.sptpl","active, cMSTypeID")]
	[SPAutoGen("usp_SearchAssessmentCategories","SearchByArgs.sptpl","activeWithAll:active, cMSTypeID, headerText, description")]
	[SPInsert("usp_InsertAssessmentCategory")]
	[SPUpdate("usp_UpdateAssessmentCategory")]
	[SPDelete("usp_DeleteAssessmentCategory")]
	[SPLoad("usp_LoadAssessmentCategory")]
	[TableMapping("AssessmentCategory","assessmentCategoryID")]
	public class AssessmentCategory : BaseAssessment
	{
		[NonSerialized]
		private AssessmentCategoryCollection parentAssessmentCategoryCollection;
		[ColumnMapping("AssessmentCategoryID",(int)0)]
		private int assessmentCategoryID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("HeaderText")]
		private string headerText;
		[ColumnMapping("CMSTypeID",StereoType=DataStereoType.FK)]
		private int cMSTypeID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		private AssessmentParagraphCollection assessmentParagraphs;

		private int firstPositionParagraphID;	// ID of Assessment Paragraph that occupies First Position
		private int lastPositionParagraphID;	// ID of Assessment Paragraph that occupies Last Position
	
		public AssessmentCategory()
		{
			this.firstPositionParagraphID = this.lastPositionParagraphID = 0;
		}

		public AssessmentCategory(bool initNew) : this()
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public AssessmentCategory(int assessmentCategoryID) : this()
		{
			if (assessmentCategoryID > 0)
				this.Load(assessmentCategoryID);
		}

		
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int AssessmentCategoryID
		{
			get { return this.assessmentCategoryID; }
			set { this.assessmentCategoryID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255, IsRequired=true)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string HeaderText
		{
			get { return this.headerText; }
			set { this.headerText = value; }
		}

		[FieldValuesMember("LookupOf_CMSTypeID", "CMSTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@CMSTYPE@")]
		public int CMSTypeIDSearch
		{
			get { return this.cMSTypeID; }
			set { this.cMSTypeID = value; }
		}

		[FieldValuesMember("LookupOf_CMSTypeID", "CMSTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CMSTYPE@")]
		public int CMSTypeID
		{
			get { return this.cMSTypeID; }
			set { this.cMSTypeID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		#region AssessmentParagraphs
		/// <summary>
		/// Child AssessmentParagraphs mapped to related rows of table AssessmentParagraph where [AssessmentCategoryID] = [AssessmentCategoryID]
		/// </summary>
		[SPLoadChild("usp_LoadAssessmentCategoryAssessmentParagraph", "assessmentCategoryID")]
		public AssessmentParagraphCollection AssessmentParagraphs
		{
			get { return this.assessmentParagraphs; }
			set
			{
				this.assessmentParagraphs = value;
				if (value != null)
					value.ParentAssessmentCategory = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AssessmentParagraphs collection
		/// </summary>
		public void LoadAssessmentParagraphs(bool forceReload)
		{
			this.assessmentParagraphs = (AssessmentParagraphCollection)AssessmentParagraphCollection.LoadChildCollection("AssessmentParagraphs", this, typeof(AssessmentParagraphCollection), assessmentParagraphs, forceReload, null);
		}

		/// <summary>
		/// Saves the AssessmentParagraphs collection
		/// </summary>
		public void SaveAssessmentParagraphs()
		{
			AssessmentParagraphCollection.SaveChildCollection(this.assessmentParagraphs, true);
		}

		/// <summary>
		/// Synchronizes the AssessmentParagraphs collection
		/// </summary>
		public void SynchronizeAssessmentParagraphs()
		{
			AssessmentParagraphCollection.SynchronizeChildCollection(this.assessmentParagraphs, true);
		}
		#endregion

		public CMSTypeCollection LookupOf_CMSTypeID
		{
			get
			{
				return CMSTypeCollection.ActiveCMSTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Parent AssessmentCategoryCollection that contains this element
		/// </summary>
		public AssessmentCategoryCollection ParentAssessmentCategoryCollection
		{
			get
			{
				return this.parentAssessmentCategoryCollection;
			}
			set
			{
				this.parentAssessmentCategoryCollection = value; // parent is set when added to a collection
			}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddHeaderLabelandValue("@ASSESSMENTCATEGORY@", description);
				writer.AddFields(this, "AssessmentCategoryID", "HeaderText");
			}
		}
		
		#region Paragraph Positions
		public object[,] ValuesOf_ParagraphPosition(int assessmentParagraphID)
		{

			object[,]val = new object[3,2];
			
			if(this.firstPositionParagraphID == assessmentParagraphID || IsFirstPositionAllowed)
			{
				val[0,0] = 1;
				val[0,1] = AssessmentParagraphPosition.First.ToString();
			}
			val[1,0] = 2;
			val[1,1] = AssessmentParagraphPosition.Normal.ToString();

			if(this.lastPositionParagraphID == assessmentParagraphID || IsLastPositionAllowed)
			{
				val[2,0] = 3;
				val[2,1] = AssessmentParagraphPosition.Last.ToString();
			}
			return val;
		}

		public bool IsFirstPositionAllowed
		{
			get { return this.firstPositionParagraphID == 0; }
		}
		
		public void SetFirstPositionOwner(AssessmentParagraph paragraph)
		{
			this.firstPositionParagraphID = paragraph.Active == true ? paragraph.AssessmentParagraphID : 0;
		}

		public bool IsLastPositionAllowed
		{
			get { return this.lastPositionParagraphID == 0; }
		}

		public void SetLastPositionOwner(AssessmentParagraph paragraph)
		{
			this.lastPositionParagraphID = paragraph.Active == true ? paragraph.AssessmentParagraphID : 0;
		}
		#endregion

	}

	/// <summary>
	/// Strongly typed collection of AssessmentCategory objects
	/// </summary>
	[ElementType(typeof(AssessmentCategory))]
	public class AssessmentCategoryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AssessmentCategory elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAssessmentCategoryCollection = this;
			else
				elem.ParentAssessmentCategoryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AssessmentCategory elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AssessmentCategory this[int index]
		{
			get
			{
				return (AssessmentCategory)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AssessmentCategory)oldValue, false);
			SetParentOnElem((AssessmentCategory)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(AssessmentCategory elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((AssessmentCategory)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchAssessmentCategories(int maxRecords, AssessmentCategory searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchAssessmentCategories", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}

		public static AssessmentCategoryCollection GetFromSearch(AssessmentCategory searcher)
		{
			AssessmentCategoryCollection col = new AssessmentCategoryCollection();
			col.SearchAssessmentCategories(-1, searcher);
			return col;
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveAssessmentCategoriesByCMSTypeID(int cMSTypeID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveAssessmentCategoriesByCMSTypeID", -1, this, false, new object[] { true, cMSTypeID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadActiveAssessmentCategoriesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetActiveAssessmentCategoriesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared AssessmentCategoryCollection which is cached in NSGlobal
		/// </summary>
		public static AssessmentCategoryCollection ActiveAssessmentCategories
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				AssessmentCategoryCollection col = (AssessmentCategoryCollection)NSGlobal.EnsureCachedObject("ActiveAssessmentCategories", typeof(AssessmentCategoryCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadActiveAssessmentCategoriesByActive(-1, true);
				}
				return col;
			}
		}
	}
}
