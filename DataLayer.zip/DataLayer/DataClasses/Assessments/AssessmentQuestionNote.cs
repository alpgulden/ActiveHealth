using System;
using System.Collections.Specialized;
using System.Collections;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [AssessmentQuestionNote]
	/// </summary>
	[SPAutoGen("usp_GetAssessmentQuestionNotesByCMSID","SelectAllByGivenArgs.sptpl","cMSID", InjectPostOperation="ORDER BY AssessmentGUID, QuestionID, CreateTime DESC")]
	[SPInsert("usp_InsertAssessmentQuestionNote")]
	[SPUpdate("usp_UpdateAssessmentQuestionNote")]
	[SPLoad("usp_LoadAssessmentQuestionNote")]
	[TableMapping("AssessmentQuestionNote","assessmentQuestionNoteID")]
	public class AssessmentQuestionNote : BaseData
	{
		[NonSerialized]
		private AssessmentQuestionNoteCollection parentAssessmentQuestionNoteCollection;
		[ColumnMapping("AssessmentQuestionNoteID",StereoType=DataStereoType.FK)]
		private int assessmentQuestionNoteID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("AssessmentGUID")]
		private string assessmentGUID;
		[ColumnMapping("QuestionID",StereoType=DataStereoType.FK)]
		private int questionID;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public AssessmentQuestionNote() : base()
		{
		}

		public AssessmentQuestionNote(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}



		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AssessmentQuestionNoteID
		{
			get { return this.assessmentQuestionNoteID; }
			set { this.assessmentQuestionNoteID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionID
		{
			get { return this.questionID; }
			set { this.questionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=500)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		public string ShortNote
		{
			get 
			{ 
				if (note != null && note.Length > 30)
					return this.note.Substring(0, 30) + "...";
				else
					return note;
			}
		}

		/// <summary>
		/// Parent AssessmentQuestionNoteCollection that contains this element
		/// </summary>
		public AssessmentQuestionNoteCollection ParentAssessmentQuestionNoteCollection
		{
			get
			{
				return this.parentAssessmentQuestionNoteCollection;
			}
			set
			{
				this.parentAssessmentQuestionNoteCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}
	}

	/// <summary>
	/// Strongly typed collection of AssessmentQuestionNote objects
	/// </summary>
	[ElementType(typeof(AssessmentQuestionNote))]
	public class AssessmentQuestionNoteCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass, ICollectionElementFilter
	{
		[NonSerialized]
		private CollectionIndexer indexBy_AssessmentGUID_QuestionID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AssessmentQuestionNote elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAssessmentQuestionNoteCollection = this;
			else
				elem.ParentAssessmentQuestionNoteCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AssessmentQuestionNote elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		public override int AddRecord(BaseDataClass data)
		{
			int ret = base.AddRecord (data);
			ResetIndexers();
			return ret;
		}

		private void ResetIndexers()
		{
			indexBy_AssessmentGUID_QuestionID = null;
		}


		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AssessmentQuestionNote this[int index]
		{
			get
			{
				return (AssessmentQuestionNote)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		private int filterQuestionID = -1;        // if this is set, the collection can be filtered by questionID
		private string filterAssessmentGUID = null;

		public int FilterQuestionID
		{     
			get { return this.filterQuestionID; }
			set { this.filterQuestionID = value; }
		}

		/// <summary>
		/// This filters out items with a specific assessmentGUID from the collection
		/// </summary>
		public string FilterAssessmentGUID
		{
			get { return this.filterAssessmentGUID; }
			set { this.filterAssessmentGUID = value; }
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AssessmentQuestionNote)oldValue, false);
			SetParentOnElem((AssessmentQuestionNote)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadByCMSID(int cMSID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAssessmentQuestionNotesByCMSID", -1, this, false, new object[] {cMSID});
		}

		/// <summary>
		/// Hashtable based index on assessmentGUID, questionID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_AssessmentGUID_QuestionID
		{
			get
			{
				if (this.indexBy_AssessmentGUID_QuestionID == null)
					this.indexBy_AssessmentGUID_QuestionID = new CollectionIndexer(this, new string[] { "assessmentGUID", "questionID" }, true);
				return this.indexBy_AssessmentGUID_QuestionID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on assessmentGUID, questionID fields returns the object.  Uses the IndexBy_AssessmentGUID_QuestionID indexer.
		/// </summary>
		public AssessmentQuestionNote FindBy(string assessmentGUID, int questionID)
		{
			return (AssessmentQuestionNote)this.IndexBy_AssessmentGUID_QuestionID.GetObject(assessmentGUID, questionID);
		}

	

		public bool FilterElement(int index)
		{
			return (filterQuestionID == -1 || this[index].QuestionID == filterQuestionID)
					&& (filterAssessmentGUID == null || this[index].AssessmentGUID != filterAssessmentGUID);
		}


		public bool NoteHistoryExists(string assessmentGUID, int questionID)
		{
			bool exists = false;
			this.filterAssessmentGUID = assessmentGUID;
			this.filterQuestionID = questionID;

			for (int i = 0; i < this.Count; i++)
			{
				if (FilterElement(i)) {exists = true; break;};
			}
				
			return exists;
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}	



	}
}
