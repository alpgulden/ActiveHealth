using System;
using System.Collections;
using NetsoftUSA.DataLayer;



namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [InterventionTemplate]
	/// 
	/// !!!Manually Managed Stored Procedures:
	/// usp_GetAssessmentInterventionTemplates
	/// </summary>
	[SPAutoGen("usp_SearchInterventionTemplates","SearchByArgs.sptpl","activeWithAll:active, pOCDeficitTypeID, pOCGoalTypeID, interventionTypeID")]
	[SPInsert("usp_InsertInterventionTemplate")]
	[SPUpdate("usp_UpdateInterventionTemplate")]
	[SPLoad("usp_LoadInterventionTemplate")]
	[TableMapping("InterventionTemplate","interventionTemplateID")]
	public class InterventionTemplate : BaseAssessment
	{
		[NonSerialized]
		protected InterventionTemplateCollection parentInterventionTemplateCollection;
		[ColumnMapping("InterventionTemplateID",StereoType=DataStereoType.FK)]
		protected int interventionTemplateID;
		[ColumnMapping("POCDeficitTypeID",StereoType=DataStereoType.FK)]
		protected int pOCDeficitTypeID;
		[ColumnMapping("POCGoalTypeID",StereoType=DataStereoType.FK)]
		protected int pOCGoalTypeID;
		[ColumnMapping("InterventionTypeID",StereoType=DataStereoType.FK)]
		protected int interventionTypeID;
		[ColumnMapping("Active")]
		protected bool active = true;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;

		protected int logicID;
		protected string logicExpression = null;
		protected int questionID;

		protected int doNowLater = 0;
		protected bool visibleInList = false;

		[FieldValuesMember("ValuesOf_DoNowLater")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int DoNowLater
		{
			get { return this.doNowLater; }
			set { this.doNowLater = value; }
		}

		public bool VisibleInList
		{
			get { return this.visibleInList; }
			set { this.visibleInList = value; }
		}

		public int LogicID
		{
			get { return logicID; }
			set { logicID = value; }
		}

		public string LogicExpression
		{
			get { return logicExpression; }
			set { logicExpression = value; }
		}

		public int QuestionID
		{
			get { return questionID; }
			set { questionID = value; }
		}
		


		protected InterventionTemplateLogicCollection interventionTemplateLogics;
		private LogicCollection logics;
		private InterventionTemplateWebLinkCollection interventionTemplateWebLinks;
		private WebLinkCollection webLinks;
	
		public InterventionTemplate() : base()
		{
		}

		public InterventionTemplate(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int interventionTemplateID)
		{
			return base.Load(interventionTemplateID);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		[FieldDescription("@ID@")]
		public int InterventionTemplateID
		{
			get { return this.interventionTemplateID; }
			set { this.interventionTemplateID = value; }
		}

		[FieldValuesMember("LookupOf_POCDeficitTypeID", "POCDeficitTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@DEFICITTYPEID@")]
		public int POCDeficitTypeID
		{
			get { return this.pOCDeficitTypeID; }
			set { this.pOCDeficitTypeID = value; }
		}

		[FieldDescription("@DEFICITTYPEID@")]
		public string POCDeficitTypeID_Description
		{
			get { return LookupOf_POCDeficitTypeID.Lookup_DescriptionByPOCDeficitTypeID(this.pOCDeficitTypeID);	}
		}

		[FieldValuesMember("LookupOf_POCGoalTypeID", "GoalTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@GOALTYPEID@")]
		public int POCGoalTypeID
		{
			get { return this.pOCGoalTypeID; }
			set { this.pOCGoalTypeID = value; }
		}

		[FieldDescription("@GOALTYPEID@")]
		public string POCGoalTypeID_Description
		{
			get { return LookupOf_POCGoalTypeID.Lookup_DescriptionByGoalTypeId(this.pOCGoalTypeID); }
		}

		[FieldValuesMember("LookupOf_InterventionTypeID", "ActivityTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@INTERVENTION@")]
		public int InterventionTypeID
		{
			get { return this.interventionTypeID; }
			set { this.interventionTypeID = value; }
		}

		[FieldDescription("@INTERVENTION@")]
		public string InterventionTypeID_Description
		{
			get { return LookupOf_InterventionTypeID.Lookup_DescriptionByActivityTypeID(this.interventionTypeID); }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Parent InterventionTemplateCollection that contains this element
		/// </summary>
		public InterventionTemplateCollection ParentInterventionTemplateCollection
		{
			get
			{
				return this.parentInterventionTemplateCollection;
			}
			set
			{
				this.parentInterventionTemplateCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			writer.AddFieldsOnNewLine(this, "InterventionTemplateID", "POCDeficitTypeID_Description"); 
			writer.AddFieldsOnNewLine(this, "POCGoalTypeID_Description", "InterventionTypeID_Description");
		}
		
		#region InterventionTemplateLogicCollection
		/// <summary>
		/// Child InterventionTemplateLogics mapped to related rows of table InterventionTemplateLogic where [InterventionTemplateID] = [InterventionTemplateID]
		/// </summary>
		[SPLoadChild("usp_LoadInterventionTemplateInterventionTemplateLogic", "interventionTemplateID")]
		private InterventionTemplateLogicCollection InterventionTemplateLogics
		{
			get { return this.interventionTemplateLogics; }
			set
			{
				this.interventionTemplateLogics = value;
				if (value != null)
					value.ParentInterventionTemplate = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the InterventionTemplateLogics collection
		/// </summary>
		private void LoadInterventionTemplateLogics(bool forceReload)
		{
			this.interventionTemplateLogics = (InterventionTemplateLogicCollection)InterventionTemplateLogicCollection.LoadChildCollection("InterventionTemplateLogics", this, typeof(InterventionTemplateLogicCollection), interventionTemplateLogics, forceReload, null);
		}

		/// <summary>
		/// Saves the InterventionTemplateLogics collection
		/// </summary>
		private void SaveInterventionTemplateLogics()
		{
			InterventionTemplateLogicCollection.SaveChildCollection(this.interventionTemplateLogics, true);
		}

		/// <summary>
		/// Synchronizes the InterventionTemplateLogics collection
		/// </summary>
		private void SynchronizeInterventionTemplateLogics()
		{
			InterventionTemplateLogicCollection.SynchronizeChildCollection(this.interventionTemplateLogics, true);
		}
		#endregion

		#region LogicCollection
		/// <summary>
		/// Child Logics mapped to related rows of table Logic where [InterventionTemplateID] = [LogicID]
		/// Use this collection for display only. 
		/// When changes are done save them into InterventionTemplateLogicCollection (linkage table)
		/// </summary>
		public LogicCollection Logics
		{
			get { return this.logics; }
			set
			{
				this.logics = value;
				if (value != null)
					value.ParentInterventionTemplate = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Logics collection
		/// </summary>
		public void LoadLogics()
		{
			this.logics = LogicCollection.GetLogicCollectionFromInterventionTemplate(this.interventionTemplateID); // ueses usp_GetAllLogicsByInterventionTemplateID
		}

		/// <summary>
		/// Saves the InterventionTemplateLogics collection
		/// Appears to client as though he is saving Logics Collection
		/// where as we're saving InterventionTemplateLogics - linkage table
		/// </summary>
		/// <param name="selectedLogics"></param>
		public void SaveLogics(LogicCollection selectedLogics)
		{
			this.LoadInterventionTemplateLogics(false);
			this.InterventionTemplateLogics.SynchronizeLogicsFromLogicCollection(selectedLogics, this.interventionTemplateID);
			this.SaveInterventionTemplateLogics();
		}
		#endregion

		#region InterventionTemplateWebLinkCollection
		/// <summary>
		/// Child InterventionTemplateWebLinks mapped to related rows of table InterventionTemplateWebLink where [InterventionTemplateID] = [InterventionTemplateID]
		/// </summary>
		[SPLoadChild("usp_LoadInterventionTemplateInterventionTemplateWebLink", "interventionTemplateID")]
		private InterventionTemplateWebLinkCollection InterventionTemplateWebLinks
		{
			get { return this.interventionTemplateWebLinks; }
			set
			{
				this.interventionTemplateWebLinks = value;
				if (value != null)
					value.ParentInterventionTemplate = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the InterventionTemplateWebLinks collection
		/// </summary>
		private void LoadInterventionTemplateWebLinks(bool forceReload)
		{
			this.interventionTemplateWebLinks = (InterventionTemplateWebLinkCollection)InterventionTemplateWebLinkCollection.LoadChildCollection("InterventionTemplateWebLinks", this, typeof(InterventionTemplateWebLinkCollection), interventionTemplateWebLinks, forceReload, null);
		}

		/// <summary>
		/// Saves the InterventionTemplateWebLinks collection
		/// </summary>
		private void SaveInterventionTemplateWebLinks()
		{
			InterventionTemplateWebLinkCollection.SaveChildCollection(this.interventionTemplateWebLinks, true);
		}
		#endregion

		#region WebLinks
		/// <summary>
		/// Child WebLinks mapped to related rows of table WebLink where [InterventionTemplateID] = [WebLinkID]
		/// </summary>
		[SPLoadChild("usp_GetAllWebLinkssByInterventionTemplateID", "webLinkID")]
		public WebLinkCollection WebLinks
		{
			get { return this.webLinks; }
			set
			{
				this.webLinks = value;
				if (value != null)
					value.ParentInterventionTemplate = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the WebLinks collection
		/// </summary>
		public void LoadWebLinks(bool forceReload)
		{
			this.webLinks = (WebLinkCollection)WebLinkCollection.LoadChildCollection("WebLinks", this, typeof(WebLinkCollection), webLinks, forceReload, null);
		}

		/// <summary>
		/// Saves the InterventionTemplateWebLinks collection
		/// Appears to client as though he is saving WebLinks Collection
		/// where as we're saving InterventionTemplateWebLinks - linkage table
		/// </summary>
		/// <param name="selectedWebLinks"></param>
		public void SaveWebLinks(WebLinkCollection selectedWebLinks)
		{	
			this.LoadInterventionTemplateWebLinks(false);
			this.InterventionTemplateWebLinks.SynchronizeWebLinksFromSelectableCollection(selectedWebLinks, this.interventionTemplateID);
			this.SaveInterventionTemplateWebLinks();
		}
		#endregion

		#region Lookups
		public POCGoalTypeCollection LookupOf_POCGoalTypeID
		{
			get
			{
				return POCGoalTypeCollection.ActivePOCGoalTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public POCDeficitTypeCollection LookupOf_POCDeficitTypeID
		{
			get
			{
				return POCDeficitTypeCollection.ActivePOCDeficitTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ActivityTypeCollection LookupOf_InterventionTypeID
		{
			get
			{
				return ActivityTypeCollection.ActiveActivityTypes; // Acquire a shared instance from the static member of collection
			}
		}
		#endregion
	}

	/// <summary>
	/// Strongly typed collection of InterventionTemplate objects
	/// </summary>
	[ElementType(typeof(InterventionTemplate))]
	public class InterventionTemplateCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass, ICollectionElementFilter
	{
		private bool fillExtraFields = false;
		private int filterQuestionID = 0;        // if this is set, the collection can be filtered by questionID

		public int FilterQuestionID
		{     
			get { return this.filterQuestionID; }
			set { this.filterQuestionID = value; }
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(InterventionTemplate elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentInterventionTemplateCollection = this;
			else
				elem.ParentInterventionTemplateCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (InterventionTemplate elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public InterventionTemplate this[int index]
		{
			get
			{
				return (InterventionTemplate)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((InterventionTemplate)oldValue, false);
			SetParentOnElem((InterventionTemplate)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchInterventionTemplates(int maxRecords, InterventionTemplate searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchInterventionTemplates", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}

		public static InterventionTemplateCollection GetInterventionTemplatesFromSearch(InterventionTemplate searcher)
		{
			InterventionTemplateCollection col = new InterventionTemplateCollection();
			col.SearchInterventionTemplates(-1, searcher);
			return col;
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAssessmentInterventionTemplates(string assessmentGUID)
		{
			this.Clear();
			// Set this so in OnFillElemFromReader the extra fields are filled
			fillExtraFields = true;
			int result = SqlData.SPExecReadCol("usp_GetAssessmentInterventionTemplates", -1, this, false, new object[] {assessmentGUID});
			fillExtraFields = false;
			return result;

		}

		protected override void OnFillElemFromReader(int rowNumber, System.Data.SqlClient.SqlDataReader rdr, object data)
		{
			base.OnFillElemFromReader (rowNumber, rdr, data);
			// Fill the extra members on question object with the data from reader
			if (fillExtraFields)
			{
//				((InterventionTemplate)data).LogicID = int.Parse((rdr["LogicID"].ToString()));
//				((InterventionTemplate)data).LogicExpression = rdr["Expression"].ToString();
				((InterventionTemplate)data).QuestionID = int.Parse((rdr["QuestionID"].ToString()));
			}
		}

		/// <summary>
		/// Returns InterventionTemplates filtered by QuestionID
		/// </summary>
		/// <param name="questionID"></param>
		/// <returns></returns>
		public ArrayList FilterBy(int questionID)
		{
			ArrayList its = new ArrayList(5);
			for (int i = 0; i < this.Count; i++)
			{
				if (this[i].QuestionID == questionID)
					its.Add(this[i]);
			}
			if (its.Count > 0)
				return its;
			else
				return null;
		}


		#region ICollectionElementFilter Members

		public bool FilterElement(int index)
		{
			return (this[index].VisibleInList && (filterQuestionID == 0 || filterQuestionID == this[index].QuestionID));
		}

		#endregion
	}
}
