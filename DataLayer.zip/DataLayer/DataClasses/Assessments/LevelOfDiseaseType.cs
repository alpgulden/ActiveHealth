using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	
	[SPAutoGen("usp_GetAllLevelOfDiseaseTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetAllLevelOfDiseaseTypesByActive","CodeTableLoader.sptpl","active")]
	[SPDelete("usp_DeleteLevelOfDiseaseType")]
	[SPInsert("usp_InsertLevelOfDiseaseType")]
	[SPUpdate("usp_UpdateLevelOfDiseaseType")]
	[SPLoad("usp_LoadLevelOfDiseaseType")]
	[TableMapping("LevelOfDiseaseType","levelOfDiseaseTypeID")]
	public class LevelOfDiseaseType : BaseLookupWithNote
	{
		[NonSerialized]
		private LevelOfDiseaseTypeCollection parentLevelOfDiseaseTypeCollection;
		[ColumnMapping("LevelOfDiseaseTypeID",StereoType=DataStereoType.FK)]
		private int levelOfDiseaseTypeID;
		[ColumnMapping("Note")]
		private string note;
	
		public LevelOfDiseaseType() : base()
		{
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LevelOfDiseaseTypeID
		{
			get { return this.levelOfDiseaseTypeID; }
			set { this.levelOfDiseaseTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=500)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.note; }
			set { this.note = value; }
		} 

		/// <summary>
		/// Parent LevelOfDiseaseTypeCollection that contains this element
		/// </summary>
		public LevelOfDiseaseTypeCollection ParentLevelOfDiseaseTypeCollection
		{
			get
			{
				return this.parentLevelOfDiseaseTypeCollection;
			}
			set
			{
				this.parentLevelOfDiseaseTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=8)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}


	}

	/// <summary>
	/// Strongly typed collection of LevelOfDiseaseType objects
	/// </summary>
	[ElementType(typeof(LevelOfDiseaseType))]
	public class LevelOfDiseaseTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LevelOfDiseaseType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLevelOfDiseaseTypeCollection = this;
			else
				elem.ParentLevelOfDiseaseTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LevelOfDiseaseType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LevelOfDiseaseType this[int index]
		{
			get
			{
				return (LevelOfDiseaseType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LevelOfDiseaseType)oldValue, false);
			SetParentOnElem((LevelOfDiseaseType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllLevelOfDiseaseTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLevelOfDiseaseTypesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared LevelOfDiseaseTypeCollection which is cached in NSGlobal
		/// </summary>
		public static LevelOfDiseaseTypeCollection ActiveLevelOfDiseaseTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LevelOfDiseaseTypeCollection col = (LevelOfDiseaseTypeCollection)NSGlobal.EnsureCachedObject("ActiveLevelOfDiseaseTypes", typeof(LevelOfDiseaseTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllLevelOfDiseaseTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllLevelOfDiseaseTypes", -1, this, false);
		}
	}
}

