using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	public enum AnswerDataType
	{
		ID = 1,
		Value = 2
	}

	/// <summary>
	/// Assumptions: 
	/// AnswerIndexID fields for the answers of a specific question must be consecutive numbers starting with 1
	/// </summary>
	[SPInsert("usp_InsertAnswer")]
	[SPUpdate("usp_UpdateAnswer")]
	[SPDelete("usp_DeleteAnswer")]
	[SPLoad("usp_LoadAnswer")]
	[TableMapping("Answer","answerID")]
	public class Answer : BaseData
	{
		[NonSerialized]
		private AnswerCollection parentAnswerCollection;
		[ColumnMapping("AnswerID",StereoType=DataStereoType.FK)]
		private int answerID;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		private int contentOwnerID;
		[ColumnMapping("QuestionID",StereoType=DataStereoType.FK)]
		private int questionID;
		[ColumnMapping("AnswerIndexID", (int)-1)]
		private int answerIndexID = -1;
		[ColumnMapping("AnswerTypeID",StereoType=DataStereoType.FK)]
		private int answerTypeID = (int)AnswerTypeEnum.Regular;
		[ColumnMapping("AnswerControlTypeID",StereoType=DataStereoType.FK)]
		private int answerControlTypeID;
		[ColumnMapping("AnswerText")]
		private string answerText;
		[ColumnMapping("MinValue")]
		private double minValue = double.NaN;
		[ColumnMapping("MaxValue")]
		private double maxValue = double.NaN;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("Active")]
		private bool active = true;
		[ColumnMapping("DataTypeID",StereoType=DataStereoType.FK)]
		private int dataTypeID = (int)AnswerDataType.ID;
		[ColumnMapping("SortOrder")]
		private int sortOrder = 0;
		[ColumnMapping("CCAnswerID", (int)-1)]
		private int cCAnswerID;
		[ColumnMapping("CCSourceID", (int)-1)]
		private int cCSourceID;
		private AnswerRangeCollection answerRanges;
		
		private AssessmentLevelOfDiseaseCollection assessmentLevelOfDiseases;
		// Feature removed
		// private AssessmentPOCDeficitCollection assessmentPOCDeficits;
		private AssessmentRiskCollection assessmentRisks;
		private AssessmentMeasurementCollection assessmentMeasurements;
	
		public Answer() :  base()
		{
		}

		public Answer(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public Answer(int answerIndexID, string answerText, AnswerControlTypeEnum answerControlType, int sortOrder)
		{
			this.NewRecord(); // initialize record state
			this.answerIndexID = answerIndexID;
			this.AnswerControlType = answerControlType;
			this.answerText = answerText;
			this.sortOrder = sortOrder;
		}


		public void LoadFullTree(bool forceReload)
		{
			this.LoadAnswerRanges(forceReload);
			foreach (AnswerRange answerRange in this.answerRanges)
			{
				answerRange.LoadFullTree(forceReload);
			}
			this.LoadAssessmentLevelOfDiseases(forceReload);
			this.LoadAssessmentMeasurements(forceReload);
			// Feature removed
			// this.LoadAssessmentPOCDeficits(forceReload);
			this.LoadAssessmentRisks(forceReload);
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int AnswerID
		{
			get { return this.answerID; }
			set { this.answerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionID
		{
			get { return this.questionID; }
			set { this.questionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)-1,  IsRequired=true)]
		public int AnswerIndexID
		{
			get { return this.answerIndexID; }
			set { this.answerIndexID = value; }
		}

		[FieldValuesMember("LookupOf_AnswerType", "AnswerTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int AnswerTypeID
		{
			get { return this.answerTypeID; }
			set { this.answerTypeID = value; }
		}

		public AnswerTypeEnum AnswerType
		{
			get { return (AnswerTypeEnum)this.answerTypeID; }
			set { this.answerTypeID = (int)value; }
		}

		[FieldValuesMember("LookupOf_AnswerControlTypeID", "AnswerControlTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@ANSWERCONTROLTYPE@")]
		public int AnswerControlTypeID
		{
			get { return this.answerControlTypeID; }
			set { this.answerControlTypeID = value; }
		}

		public AnswerControlTypeEnum AnswerControlType
		{
			get { return (AnswerControlTypeEnum)this.answerControlTypeID;}
			set { this.answerControlTypeID = (int)value;}
		}
		
		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string AnswerText
		{
			get { return this.answerText; }
			set { this.answerText = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DataTypeID
		{
			get { return this.dataTypeID; }
			set { this.dataTypeID = value; }
		}

		public AnswerDataType DataType
		{
			get { return (AnswerDataType)this.dataTypeID; }
			set { this.dataTypeID = (int)value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public double MinValue
		{
			get { return this.minValue; }
			set { this.minValue = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public double MaxValue
		{
			get { return this.maxValue; }
			set { this.maxValue = value; }
		}



		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get 
			{ 
//				if (this.parentAnswerCollection != null && this.parentAnswerCollection.ParentQuestion != null)
//				{
//					return this.parentAnswerCollection.ParentQuestion.Active && this.active;
//				}
//
				return this.active; 
			}
			set { this.active = value; }
		}

		[FieldValuesMember("ValuesOf_CCAnswer")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CCAnswerID
		{
			get { return this.cCAnswerID; }
			set { this.cCAnswerID = value; }
		}

		[FieldValuesMember("ValuesOf_CCSource")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CCSourceID
		{
			get { return this.cCSourceID; }
			set { this.cCSourceID = value; }
		}


		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int answerID)
		{
			base.Delete(answerID);		
		}

		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}

		/// <summary>
		/// Parent AnswerCollection that contains this element
		/// </summary>
		public AnswerCollection ParentAnswerCollection
		{
			get
			{
				return this.parentAnswerCollection;
			}
			set
			{
				this.parentAnswerCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child AnswerRanges mapped to related rows of table AnswerRange where [AnswerID] = [AnswerID]
		/// </summary>
		[SPLoadChild("usp_LoadAnswerRanges", "answerID")]
		public AnswerRangeCollection AnswerRanges
		{
			get 
			{
				this.LoadAnswerRanges(false);
				return this.answerRanges; 
			}
			set
			{
				this.answerRanges = value;
				if (value != null)
					value.ParentAnswer = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AnswerRanges collection
		/// </summary>
		public void LoadAnswerRanges(bool forceReload)
		{
			this.answerRanges = (AnswerRangeCollection)AnswerRangeCollection.LoadChildCollection("AnswerRanges", this, typeof(AnswerRangeCollection), answerRanges, forceReload, null);
		}

		/// <summary>
		/// Saves the AnswerRanges collection
		/// </summary>
		public void SaveAnswerRanges()
		{
			AnswerRangeCollection.SaveChildCollection(this.answerRanges, true);
		}

		/// <summary>
		/// Synchronizes the AnswerRanges collection
		/// </summary>
		public void SynchronizeAnswerRanges()
		{
			AnswerRangeCollection.SynchronizeChildCollection(this.answerRanges, true);
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}


		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Fill some of the properties from the parent question	
			Question parentQuestion = this.ParentAnswerCollection.ParentQuestion;
			this.contentOwnerID = parentQuestion.ContentOwnerID;
			//this.questionID = parentQuestion.QuestionID;

			if (this.isMarkedForDeletion)
			{
				if (!this.isNew)
				{
					this.LoadAssessmentLevelOfDiseases(false);
					this.assessmentLevelOfDiseases.MarkAllDel();
					this.SaveAssessmentLevelOfDiseases();

					this.LoadAssessmentRisks(false);
					this.assessmentRisks.MarkAllDel();
					this.SaveAssessmentRisks();

					this.LoadAssessmentMeasurements(false);
					this.assessmentMeasurements.MarkAllDel();
					this.SaveAssessmentMeasurements();

					this.LoadAnswerRanges(false);
					this.answerRanges.MarkAllDel();
					this.SaveAnswerRanges();
				}

				base.InternalSave();
			}
			else
			{
				base.InternalSave();

				// Save the child collections here.
				if (this.AssessmentLevelOfDisease.LevelOfDiseaseTypeID == 0)
				{
					if (!this.isNew)
					{
						this.AssessmentLevelOfDisease.MarkDel();
						this.SaveAssessmentLevelOfDiseases();
					}
				}
				else
					this.SaveAssessmentLevelOfDiseases();

				// Feature removed
				// this.SaveAssessmentPOCDeficits();

				if (this.AssessmentRisk.RiskTypeID == 0)
				{
					if (!this.isNew)
					{
						this.AssessmentRisk.MarkDel();
						this.SaveAssessmentRisks();
					}
				}
				else
					this.SaveAssessmentRisks();


				if (this.AssessmentMeasurement.MeasurementTypeID == 0)
				{
					if (!this.isNew)
					{
						this.AssessmentMeasurement.MarkDel();
						this.SaveAssessmentMeasurements();
					}
				}
				else
					this.SaveAssessmentMeasurements();


				// Save ranges
				this.SaveAnswerRanges();
			}
		}

		public AssessmentLevelOfDisease AssessmentLevelOfDisease
		{
			get 
			{
				LoadAssessmentLevelOfDiseases(false);
				if (this.AssessmentLevelOfDiseases.Count > 0)
				{
					if (this.AssessmentLevelOfDiseases.Count > 1)
						throw new Exception(String.Format("An answer can be directly linked to only one LOD, AnswerID = {0}", this.answerID));
					return this.assessmentLevelOfDiseases[0];
				}
				else
				{
					// create a new one
					AssessmentLevelOfDisease lod = new AssessmentLevelOfDisease(true);
					this.AssessmentLevelOfDiseases.AddRecord(lod);
					return lod;
				}

				return null;
			}
		}

		/// <summary>
		/// Child AssessmentLevelOfDiseases mapped to related rows of table AssessmentLevelOfDisease where [AnswerID] = [AnswerID]
		/// </summary>
		[SPLoadChild("usp_LoadAnswerAssessmentLevelOfDisease", "answerID")]
		public AssessmentLevelOfDiseaseCollection AssessmentLevelOfDiseases
		{
			get 
			{ 
				LoadAssessmentLevelOfDiseases(false);
				return this.assessmentLevelOfDiseases; 
			}
			set
			{
				this.assessmentLevelOfDiseases = value;
				if (value != null)
					value.ParentAnswer = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AssessmentLevelOfDiseases collection
		/// </summary>
		public void LoadAssessmentLevelOfDiseases(bool forceReload)
		{
			this.assessmentLevelOfDiseases = (AssessmentLevelOfDiseaseCollection)AssessmentLevelOfDiseaseCollection.LoadChildCollection("AssessmentLevelOfDiseases", this, typeof(AssessmentLevelOfDiseaseCollection), assessmentLevelOfDiseases, forceReload, null);
		}

		/// <summary>
		/// Saves the AssessmentLevelOfDiseases collection
		/// </summary>
		public void SaveAssessmentLevelOfDiseases()
		{
			AssessmentLevelOfDiseaseCollection.SaveChildCollection(this.assessmentLevelOfDiseases, true);
		}

		/// <summary>
		/// Synchronizes the AssessmentLevelOfDiseases collection
		/// </summary>
		public void SynchronizeAssessmentLevelOfDiseases()
		{
			AssessmentLevelOfDiseaseCollection.SynchronizeChildCollection(this.assessmentLevelOfDiseases, true);
		}

		/* Feature removed

		public AssessmentPOCDeficit AssessmentPOCDeficit
		{
			get 
			{
				LoadAssessmentPOCDeficits(false);
				if (this.assessmentPOCDeficits.Count > 0)
				{
					if (this.assessmentPOCDeficits.Count > 1)
						throw new Exception(String.Format("An answer can be directly linked to only one Deficit, AnswerID = {0}", this.answerID));
					return this.assessmentPOCDeficits[0];
				}

				return null;
			}
		}

		/// <summary>
		/// Child AssessmentPOCDeficits mapped to related rows of table AssessmentPOCDeficit where [AnswerID] = [AnswerID]
		/// </summary>
		[SPLoadChild("usp_LoadAnswerAssessmentPOCDeficit", "answerID")]
		public AssessmentPOCDeficitCollection AssessmentPOCDeficits
		{
			get { return this.assessmentPOCDeficits; }
			set
			{
				this.assessmentPOCDeficits = value;
				if (value != null)
					value.ParentAnswer = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AssessmentPOCDeficits collection
		/// </summary>
		public void LoadAssessmentPOCDeficits(bool forceReload)
		{
			this.assessmentPOCDeficits = (AssessmentPOCDeficitCollection)AssessmentPOCDeficitCollection.LoadChildCollection("AssessmentPOCDeficits", this, typeof(AssessmentPOCDeficitCollection), assessmentPOCDeficits, forceReload, null);
		}

		/// <summary>
		/// Saves the AssessmentPOCDeficits collection
		/// </summary>
		public void SaveAssessmentPOCDeficits()
		{
			AssessmentPOCDeficitCollection.SaveChildCollection(this.assessmentPOCDeficits, true);
		}

		/// <summary>
		/// Synchronizes the AssessmentPOCDeficits collection
		/// </summary>
		public void SynchronizeAssessmentPOCDeficits()
		{
			AssessmentPOCDeficitCollection.SynchronizeChildCollection(this.assessmentPOCDeficits, true);
		}


		*/
		
		public AssessmentRisk AssessmentRisk
		{
			get 
			{
				LoadAssessmentRisks(false);
				if (this.assessmentRisks.Count > 0)
				{
					if (this.assessmentRisks.Count > 1)
						throw new Exception(String.Format("An answer can be directly linked to only one Risk, AnswerID = {0}", this.answerID));
					return this.assessmentRisks[0];
				}
				else
				{
					// create a new one
					AssessmentRisk risk = new AssessmentRisk(true);
					this.AssessmentRisks.AddRecord(risk);
					return risk;
				}

				return null;
			}
		}


		/// <summary>
		/// Child AssessmentRisks mapped to related rows of table AssessmentRisk where [AnswerID] = [AnswerID]
		/// </summary>
		[SPLoadChild("usp_LoadAnswerAssessmentRisk", "answerID")]
		public AssessmentRiskCollection AssessmentRisks
		{
			get 
			{ 
				LoadAssessmentRisks(false);
				return this.assessmentRisks; 
			}
			set
			{
				this.assessmentRisks = value;
				if (value != null)
					value.ParentAnswer = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AssessmentRisks collection
		/// </summary>
		public void LoadAssessmentRisks(bool forceReload)
		{
			this.assessmentRisks = (AssessmentRiskCollection)AssessmentRiskCollection.LoadChildCollection("AssessmentRisks", this, typeof(AssessmentRiskCollection), assessmentRisks, forceReload, null);
		}

		/// <summary>
		/// Saves the AssessmentRisks collection
		/// </summary>
		public void SaveAssessmentRisks()
		{
			AssessmentRiskCollection.SaveChildCollection(this.assessmentRisks, true);
		}

		/// <summary>
		/// Synchronizes the AssessmentRisks collection
		/// </summary>
		public void SynchronizeAssessmentRisks()
		{
			AssessmentRiskCollection.SynchronizeChildCollection(this.assessmentRisks, true);
		}



		public AnswerControlTypeCollection LookupOf_AnswerControlTypeID
		{
			get
			{
				return AnswerControlTypeCollection.AnswerControlTypes;
			}
		}

		public AssessmentMeasurement AssessmentMeasurement
		{
			get 
			{
				LoadAssessmentMeasurements(false);
				if (this.assessmentMeasurements.Count > 0)
				{
					if (this.assessmentMeasurements.Count > 1)
						throw new Exception(String.Format("An answer can be directly linked to only one Measurement, AnswerRangeID = {0}", this.answerID));
					return this.assessmentMeasurements[0];
				}
				else
				{
					// create a new one
					AssessmentMeasurement mes = new AssessmentMeasurement(true);
					this.AssessmentMeasurements.AddRecord(mes);
					return mes;
				}

				return null;
			}
		}

		/// <summary>
		/// Child AssessmentMeasurements mapped to related rows of table AssessmentMeasurement where [AnswerID] = [AnswerID]
		/// </summary>
		[SPLoadChild("usp_LoadAnswerAssessmentMeasurement", "answerID")]
		public AssessmentMeasurementCollection AssessmentMeasurements
		{
			get 
			{ 
				LoadAssessmentMeasurements(false);
				return this.assessmentMeasurements; 
			}
			set
			{
				this.assessmentMeasurements = value;
				if (value != null)
					value.ParentAnswer = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AssessmentMeasurements collection
		/// </summary>
		public void LoadAssessmentMeasurements(bool forceReload)
		{
			this.assessmentMeasurements = (AssessmentMeasurementCollection)AssessmentMeasurementCollection.LoadChildCollection("AssessmentMeasurements", this, typeof(AssessmentMeasurementCollection), assessmentMeasurements, forceReload, null);
		}

		/// <summary>
		/// Saves the AssessmentMeasurements collection
		/// </summary>
		public void SaveAssessmentMeasurements()
		{
			AssessmentMeasurementCollection.SaveChildCollection(this.assessmentMeasurements, true);
		}

		/// <summary>
		/// Synchronizes the AssessmentMeasurements collection
		/// </summary>
		public void SynchronizeAssessmentMeasurements()
		{
			AssessmentMeasurementCollection.SynchronizeChildCollection(this.assessmentMeasurements, true);
		}

		public AnswerTypeCollection LookupOf_AnswerType
		{
			get
			{
				return AnswerTypeCollection.AllAnswerTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

	

	}

	/// <summary>
	/// Strongly typed collection of Answer objects
	/// </summary>
	[ElementType(typeof(Answer))]
	public class AnswerCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_AnswerID;
		[NonSerialized]
		private CollectionIndexer indexBy_QuestionID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Answer elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAnswerCollection = this;
			else
				elem.ParentAnswerCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Answer elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Answer this[int index]
		{
			get
			{
				return (Answer)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Answer)oldValue, false);
			SetParentOnElem((Answer)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Hashtable based index on questionID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionID
		{
			get
			{
				if (this.indexBy_QuestionID == null)
					this.indexBy_QuestionID = new CollectionIndexer(this, new string[] { "questionID" }, true);
				return this.indexBy_QuestionID;
			}
			
		}

		/// <summary>
		/// Looks up by questionID and returns AnswerID value.  Uses the IndexBy_QuestionID indexer.
		/// </summary>
		public int Lookup_AnswerIDByQuestionID(int questionID)
		{
			return this.IndexBy_QuestionID.LookupIntMember("AnswerID", questionID);
		}

		/// <summary>
		/// Parent Question that contains this collection
		/// </summary>
		public Question ParentQuestion
		{
			get { return this.ParentDataObject as Question; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Question */ }
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Hashtable based index on answerID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_AnswerID
		{
			get
			{
				if (this.indexBy_AnswerID == null)
					this.indexBy_AnswerID = new CollectionIndexer(this, new string[] { "answerID" }, true);
				return this.indexBy_AnswerID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on answerID fields returns the object.  Uses the IndexBy_AnswerID indexer.
		/// </summary>
		public Answer FindBy(int answerID)
		{
			return (Answer)this.IndexBy_AnswerID.GetObject(answerID);
		}

		/// <summary>
		/// Returns response with a specific index ID
		/// </summary>
		/// <param name="questionID"></param>
		/// <returns></returns>
		public Answer FindByAnswerIndexID(int answerIndexID)
		{
			for (int i = 0; i < this.Count; i++)
			{
				if (this[i].AnswerIndexID == answerIndexID)
					return this[i];
			}
			return null;
		}


		public int GetNextIndexID()
		{
			int answerIndexID = 0;
			for (int i = 0; i < this.Count; i++)
			{
				if (this[i].AnswerIndexID > answerIndexID)
					answerIndexID = this[i].AnswerIndexID;
			}

			answerIndexID++;
			return answerIndexID;
		}
		
		
	}
}
