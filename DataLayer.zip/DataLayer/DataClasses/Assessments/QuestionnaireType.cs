using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPDelete("usp_DeleteQuestionnaireType")]
	[SPAutoGen("usp_GetAllSearchQuestionnaireTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_SearchQuestionnaireTypesByActive","usp_GetAllQuestionnairesByActive","active")] 
	[SPInsert("usp_InsertQuestionnaireType")]
	[SPUpdate("usp_UpdateQuestionnaireType")]
	[SPLoad("usp_LoadQuestionnaireType")]
	[TableMapping("QuestionnaireType","questionnaireTypeID")]
	public class QuestionnaireType : BaseLookupWithNote
	{
		[NonSerialized]
		private QuestionnaireTypeCollection parentQuestionnaireTypeCollection;
		[ColumnMapping("QuestionnaireTypeID",StereoType=DataStereoType.FK)]
		private int questionnaireTypeID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public QuestionnaireType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public QuestionnaireType(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionnaireTypeID
		{
			get { return this.questionnaireTypeID; }
			set { this.questionnaireTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[FieldDescription("@NOTE@")]
		public override string NoteGeneric
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}


		/// <summary>
		/// Parent QuestionnaireTypeCollection that contains this element
		/// </summary>
		public QuestionnaireTypeCollection ParentQuestionnaireTypeCollection
		{
			get
			{
				return this.parentQuestionnaireTypeCollection;
			}
			set
			{
				this.parentQuestionnaireTypeCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of QuestionnaireType objects
	/// </summary>
	[ElementType(typeof(QuestionnaireType))]
	public class QuestionnaireTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(QuestionnaireType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentQuestionnaireTypeCollection = this;
			else
				elem.ParentQuestionnaireTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (QuestionnaireType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public QuestionnaireType this[int index]
		{
			get
			{
				return (QuestionnaireType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((QuestionnaireType)oldValue, false);
			SetParentOnElem((QuestionnaireType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetQuestionnaireTypes(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchQuestionnaireTypesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared QuestionnaireTypeCollection which is cached in NSGlobal
		/// </summary>
		public static QuestionnaireTypeCollection ActiveQuestionnaireTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				QuestionnaireTypeCollection col = (QuestionnaireTypeCollection)NSGlobal.EnsureCachedObject("ActiveQuestionnaireTypes", typeof(QuestionnaireTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetQuestionnaireTypes(-1, true);
				}
				return col;
			}			
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllSearchQuestionnaireTypes", -1, this, false);
		}
	}
}
