using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Response]
	/// </summary>
	[SPAutoGen("usp_GetResponsesByCMS","SelectAssessmentResponsesByCMS.sptpl","cMSID")]
	[SPAutoGen("usp_GetResponsesByAssessmentGUID","SelectAllByGivenArgsOrderBy.sptpl","questionID, assessmentGUID")]
	[SPInsert("usp_InsertResponse")]
	[SPUpdate("usp_UpdateResponse")]
	[SPDelete("usp_DeleteResponse")]
	[SPLoad("usp_LoadResponse")]
	[TableMapping("Response","responseID")]
	public class Response : BaseData
	{
		[NonSerialized]
		private ResponseCollection parentResponseCollection;
		[ColumnMapping("ResponseID",StereoType=DataStereoType.FK)]
		private int responseID;
		[ColumnMapping("QuestionID",StereoType=DataStereoType.FK)]
		private int questionID;
		[ColumnMapping("AnswerID",StereoType=DataStereoType.FK)]
		private int answerID;
		[ColumnMapping("AssessmentGUID")]
		private string assessmentGUID;
		[ColumnMapping("AnswerText")]
		private string answerText;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("DataTypeID",StereoType=DataStereoType.FK)]
		private int dataTypeID;
		[ColumnMapping("AnswerTypeID",StereoType=DataStereoType.FK)]
		private int answerTypeID;
		[ColumnMapping("CCAnswerID")]
		private int cCAnswerID;
		[ColumnMapping("CCSourceID")]
		private int cCSourceID;
	
		public Response() :  base()
		{
		}

		public Response(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ResponseID
		{
			get { return this.responseID; }
			set { this.responseID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionID
		{
			get { return this.questionID; }
			set { this.questionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AnswerID
		{
			get { return this.answerID; }
			set { this.answerID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4000)]
		public string AnswerText
		{
			get { return this.answerText; }
			set { this.answerText = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=500)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DataTypeID
		{
			get { return this.dataTypeID; }
			set { this.dataTypeID = value; }
		}

		public AnswerDataType DataType
		{
			get { return (AnswerDataType)this.dataTypeID; }
			set { this.dataTypeID = (int)value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AnswerTypeID
		{
			get { return this.answerTypeID; }
			set { this.answerTypeID = value; }
		}

		public AnswerTypeEnum AnswerType
		{
			get { return (AnswerTypeEnum)this.answerTypeID; }
			set { this.answerTypeID = (int)value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CCAnswerID
		{
			get { return this.cCAnswerID; }
			set { this.cCAnswerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CCSourceID
		{
			get { return this.cCSourceID; }
			set { this.cCSourceID = value; }
		}

		/// <summary>
		/// Parent ResponseCollection that contains this element
		/// </summary>
		public ResponseCollection ParentResponseCollection
		{
			get
			{
				return this.parentResponseCollection;
			}
			set
			{
				this.parentResponseCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}


	}
}
