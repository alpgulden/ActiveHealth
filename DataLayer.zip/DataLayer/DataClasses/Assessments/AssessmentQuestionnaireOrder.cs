using System;
using System.Collections;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [AssessmentQuestionnaireOrder]
	/// </summary>
	[SPAutoGen("usp_GetAssessmentQuestionnaireOrdersByAssessmentGUID","SelectAllByGivenArgs.sptpl","assessmentGUID", InjectOrderBy="ORDER BY [AssessmentQuestionnaireOrder].[SortOrder]")]
	[SPInsert("usp_InsertAssessmentQuestionnaireOrder")]
	[SPUpdate("usp_UpdateAssessmentQuestionnaireOrder")]
	[SPDelete("usp_DeleteAssessmentQuestionnaireOrder")] 
	[SPLoad("usp_LoadAssessmentQuestionnaireOrder")]
	[TableMapping("AssessmentQuestionnaireOrder","assessmentQuestionnaireOrderID")]
	public class AssessmentQuestionnaireOrder : BaseData
	{
		[NonSerialized]
		private AssessmentQuestionnaireOrderCollection parentAssessmentQuestionnaireOrderCollection;
		[ColumnMapping("AssessmentQuestionnaireOrderID",StereoType=DataStereoType.FK)]
		private int assessmentQuestionnaireOrderID;
		[ColumnMapping("AssessmentGUID")]
		private string assessmentGUID;
		[ColumnMapping("QuestionnaireID")]
		private int questionnaireID;
		[ColumnMapping("SortOrder")]
		private int sortOrder= 0;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		private QuestionnairePresentationGroupOrderCollection questionnairePresentationGroupOrders;
		private Questionnaire questionnaire;
		private string description;  // for display only

		private bool isVisible;

		public bool IsVisible
		{
			get { return isVisible; }
			set { isVisible = value; }
		}

	
		public AssessmentQuestionnaireOrder() :  base()
		{
		}

		public AssessmentQuestionnaireOrder(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public AssessmentQuestionnaireOrder(bool initNew, int questionnaireID, string description/*, string assessmentGUID*/)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();

			this.QuestionnaireID = questionnaireID;
			//aqoToAdd.SortOrder = q.SortOrder;
			this.Description = description;
			//this.AssessmentGUID = assessmentGUID;
							
			// Populating QuestionnairePresentationGroupOrder Collection 
			this.LoadQuestionnairePresentationGroupOrders(false);
			
			if (this.QuestionnairePresentationGroupOrders.Count == 0)
				this.QuestionnairePresentationGroupOrders.CreateFromQuestionnairePresentationGroup();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AssessmentQuestionnaireOrderID
		{
			get { return this.assessmentQuestionnaireOrderID; }
			set { this.assessmentQuestionnaireOrderID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value; }
		}

		[FieldDescription("@SORTORDER@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		public string Description
		{
			get
			{
				if (this.description == null)
				{
					if(this.Questionnaire != null)
						return this.questionnaire.Description;
					else
						return " this.questionnaire is NULL";
				}
				else
					return this.description;
			}
			set { this.description = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent AssessmentQuestionnaireOrderCollection that contains this element
		/// </summary>
		public AssessmentQuestionnaireOrderCollection ParentAssessmentQuestionnaireOrderCollection
		{
			get
			{
				return this.parentAssessmentQuestionnaireOrderCollection;
			}
			set
			{
				this.parentAssessmentQuestionnaireOrderCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child QuestionnairePresentationGroupOrders mapped to related rows of table QuestionnairePresentationGroupOrder where [AssessmentQuestionnaireOrderID] = [AssessmentQuestionnaireOrderID]
		/// </summary>
		[SPLoadChild("usp_LoadQuestionnairePresentationGroupOrders", "assessmentQuestionnaireOrderID", ManuallyManaged = true)] //Manuall Managed: usp_LoadQuestionnairePresentationGroupOrders
		public QuestionnairePresentationGroupOrderCollection QuestionnairePresentationGroupOrders
		{
			get 
			{ 
				this.LoadQuestionnairePresentationGroupOrders(false);
				return this.questionnairePresentationGroupOrders; 
			}
			set
			{
				this.questionnairePresentationGroupOrders = value;
				if (value != null)
					value.ParentAssessmentQuestionnaireOrder = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the QuestionnairePresentationGroupOrders collection
		/// </summary>
		public void LoadQuestionnairePresentationGroupOrders(bool forceReload)
		{
			this.questionnairePresentationGroupOrders = (QuestionnairePresentationGroupOrderCollection)QuestionnairePresentationGroupOrderCollection.LoadChildCollection("QuestionnairePresentationGroupOrders", this, typeof(QuestionnairePresentationGroupOrderCollection), questionnairePresentationGroupOrders, forceReload, null);
		}

		/// <summary>
		/// Saves the QuestionnairePresentationGroupOrders collection
		/// </summary>
		public void SaveQuestionnairePresentationGroupOrders()
		{
			QuestionnairePresentationGroupOrderCollection.SaveChildCollection(this.questionnairePresentationGroupOrders, true);
		}

		/// <summary>
		/// Synchronizes the QuestionnairePresentationGroupOrders collection
		/// </summary>
		public void SynchronizeQuestionnairePresentationGroupOrders()
		{
			QuestionnairePresentationGroupOrderCollection.SynchronizeChildCollection(this.questionnairePresentationGroupOrders, true);
		}

		/// <summary>
		/// Contained Questionnaire object
		/// </summary>
		[Contained]
		public Questionnaire Questionnaire
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.questionnaire = (Questionnaire)Questionnaire.EnsureContainedDataObject(this, typeof(Questionnaire), questionnaire, false, questionnaireID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.questionnaire;
			}
			set
			{
				this.questionnaire = value;
				if (value != null) value.ParentAssessmentQuestionnaireOrder = this; // set this as a parent of the child data class
			}
		}

		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			if (this.assessmentGUID == null)
			{
				if (this.parentAssessmentQuestionnaireOrderCollection != null && this.parentAssessmentQuestionnaireOrderCollection.ParentAssessment != null && this.parentAssessmentQuestionnaireOrderCollection.ParentAssessment.AssessmentGUID != null)
					this.assessmentGUID = this.parentAssessmentQuestionnaireOrderCollection.ParentAssessment.AssessmentGUID;
				else
					throw new ActiveAdviceException("AssessmentQuestionnaire record cannot be saved without AssessmentGUID");
			}

			base.InternalSave();
			// Save the child collections here.

			if (QuestionnairePresentationGroupOrders != null)
			{
				QuestionnairePresentationGroupOrders.SqlData.Transaction = this.sqlData.Transaction;
				SaveQuestionnairePresentationGroupOrders();
			}
		}

		/// <summary>
		/// Do pre and post-delete operations of this object here.
		/// </summary>
		protected override void InternalDelete()
		{
			// Do pre-delete operations here (set members before delete, insert/update/delete extra records etc).
			if (QuestionnairePresentationGroupOrders != null)
			{
				foreach(QuestionnairePresentationGroupOrder qpgOrder in QuestionnairePresentationGroupOrders)
					qpgOrder.Delete();
				QuestionnairePresentationGroupOrders = null;
			}

			base.InternalDelete(); // always call this to ensure record flags gets updated properly.
			// Do post-delete operations here (set members after delete, insert/update/delete extra records etc).
		}
	}

	/// <summary>
	/// Strongly typed collection of AssessmentQuestionnaireOrder objects
	/// </summary>
	[ElementType(typeof(AssessmentQuestionnaireOrder))]
	public class AssessmentQuestionnaireOrderCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]

		private CollectionIndexer indexBy_QuestionnaireID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AssessmentQuestionnaireOrder elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAssessmentQuestionnaireOrderCollection = this;
			else
				elem.ParentAssessmentQuestionnaireOrderCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AssessmentQuestionnaireOrder elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AssessmentQuestionnaireOrder this[int index]
		{
			get
			{
				return (AssessmentQuestionnaireOrder)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AssessmentQuestionnaireOrder)oldValue, false);
			SetParentOnElem((AssessmentQuestionnaireOrder)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAssessmentQuestionnaireOrders(string assessmentGUID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAssessmentQuestionnaireOrdersByAssessmentGUID", -1, this, false, new object[] {assessmentGUID});
		}

		/// <summary>
		/// Hashtable based index on questionnaireID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionnaireID
		{
			get
			{
				if (this.indexBy_QuestionnaireID == null)
					this.indexBy_QuestionnaireID = new CollectionIndexer(this, new string[] { "questionnaireID" }, true);
				return this.indexBy_QuestionnaireID;
			}
		}

		/// <summary>
		/// Hashtable based search on questionnaireID fields returns the object.  Uses the IndexBy_QuestionnaireID indexer.
		/// </summary>
		public AssessmentQuestionnaireOrder FindBy(int questionnaireID)
		{
			return (AssessmentQuestionnaireOrder)this.IndexBy_QuestionnaireID.GetObject(questionnaireID);
		}


		/// <summary>
		/// Manipulates (adds or removes items) in AssessmentQuestionnaireOrderCollection [this] based on param.
		/// Returns true if no errors were thrown and false otherwise
		/// </summary>
		/// <param name="questionnaires"></param>
		public bool SynchronizeFromSelectableCollection(QuestionnaireCollection questionnaires, ArrayList errorMessages, CMS cms)
		{
			AssessmentQuestionnaireOrder existingAQO = null;
			this.IndexBy_QuestionnaireID.Rebuild();

			// NOTE: This is no more a synchronization routine, it just adds
			
			foreach (Questionnaire q in questionnaires)
			{
				if (((SelectableQuestionnaire)q).Selected)
				{
					existingAQO = this.FindBy(q.QuestionnaireID);
					if (existingAQO == null)
					{	// Selected Questionnaire is not linked to this - Adding
						AssessmentQuestionnaireOrder aqoToAdd = new 
							AssessmentQuestionnaireOrder(true, q.QuestionnaireID, q.Description);
						this.AddRecord(aqoToAdd);
					}
					else if (existingAQO.IsMarkedForDeletion)
					{
						existingAQO.IsMarkedForDeletion = false;
					}
					else
					{
						errorMessages.Add("Questionnaire '" + q.Description + "' (ID: " + q.QuestionnaireID + ") is already selected.");
					}

					((SelectableQuestionnaire)q).Selected = false;
				}
//				if(!((SelectableQuestionnaire)q).Selected)
//				{	// Selected Questionnare is linked to this - Removing
//					if (existingAQO != null)
//					{
//						try
//						{ 
//							existingAQO.Delete();		// delete from DB	
//							this.Remove(existingAQO);   // remove from Memory
//							this.IndexBy_QuestionnaireID.Rebuild();
//						}
//						catch
//						{
//							errorMessages.Add("AssessmentQuestionnaireOrder with ID " + existingAQO.AssessmentQuestionnaireOrderID
//								+ " cannot be removed.");
//							((SelectableQuestionnaire)q).Selected = true; // modify param collection 
//						}
//					}
//				}
				existingAQO = null;
			} // end of foreach
			return errorMessages.Count > 0 ? false : true;
		}

		
		/*
		/// <summary>
		/// Will Add a questionnare to AssessmentQuestionnare Collection
		/// IF an item from cMS.CMSDiagnosticProcedures is within range of 
		/// given QuestionnaireTrigger from passed questionnaires collection.
		/// </summary>
		/// <param name="cMS"></param>
		/// <param name="questionnaires"></param>
		/// <param name="assessmentGUID"></param>
		/// <returns></returns>
		public void SelectByDxPx(CMS cMS, bool rebuildIndex)
		{
			if (cMS == null)
				return;
			cMS.LoadCMSDiagnosticProcedures(false); // Load CMS's DxPx
			QuestionnaireTriggerFilterCollection qtfCol = new QuestionnaireTriggerFilterCollection();
			qtfCol.LoadQuestionnairesWithTrigger();
			foreach(Questionnaire q in questionnaires)
			{
				
				if (qtfCol.QuestionnaireExists(q.QuestionnaireID))
				{
					q.LoadTriggers(false); // Load Questionnaire Triggers
				
					foreach(QuestionnaireTrigger qt in q.Triggers)
					{
						foreach(CMSDiagnosticProcedure cMSDxPx in cMS.CMSDiagnosticProcedures)
						{
							if (String.Compare(qt.CodeStart.Trim(), cMSDxPx.DxPxCode.Trim()) <= 0 &
								String.Compare(qt.CodeEnd.Trim(), cMSDxPx.DxPxCode.Trim()) >= 0)
							{
								// In range - adding 
								AssessmentQuestionnaireOrder aqoToAdd = new 
									AssessmentQuestionnaireOrder(true, q.QuestionnaireID, q.Description);
								this.AddRecord(aqoToAdd);
								break; //Particular Questionnaire needs to be added ONLY once
							}						
						}
					}// end of Triggers
				}
			}// end of questionnaires

			if (rebuildIndex)
				this.IndexBy_QuestionnaireID.Rebuild();
		}
		*/

		
		/// <summary>
		/// Load only the triggered questionaires for scoring load
		/// and add them to this collection.
		/// </summary>
		/// <param name="contentOwnerID"></param>
		/// <param name="cMS"></param>
		public void LoadQuestionnaireOrdersTriggeredForDxPxAndScoringLoad(int contentOwnerID, CMS cMS)
		{
			QuestionnaireCollection triggeredQuest = new QuestionnaireCollection();
			// Load only triggered questionnaries
			triggeredQuest.LoadAllQuestionnariesTriggeredForScoringLoad(contentOwnerID, cMS.CMSID, false);	// load this
			this.AddTriggeredQuestionaires(triggeredQuest);
			this.IndexBy_QuestionnaireID.Rebuild();		// build index so that the next AddTriggeredQuestionaires can check existing
			triggeredQuest.LoadAllQuestionnariesTriggeredForCMSDxPx(contentOwnerID, cMS.CMSID, false);		// load and append this
			this.AddTriggeredQuestionaires(triggeredQuest);
			this.IndexBy_QuestionnaireID.Rebuild();
		}

		/// <summary>
		/// Load only the triggered questionaires for scoring load
		/// and add them to this collection.
		/// </summary>
		/// <param name="contentOwnerID"></param>
		/// <param name="cMS"></param>
		public void AddTriggeredQuestionaires(QuestionnaireCollection triggeredQuest)
		{
			// The questionnaire id's may be repeated in the triggeredQuest collection
			// so we first check before adding.

			foreach (Questionnaire q in triggeredQuest)
			{
				if (this.FindBy(q.QuestionnaireID) == null)	// if not already added
				{
					AssessmentQuestionnaireOrder aqoToAdd = new 
						AssessmentQuestionnaireOrder(true, q.QuestionnaireID, q.Description);
					this.AddRecord(aqoToAdd);
				}
			}
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(AssessmentQuestionnaireOrder elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((AssessmentQuestionnaireOrder)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Parent Assessment that contains this collection
		/// </summary>
		public Assessment ParentAssessment
		{
			get { return this.ParentDataObject as Assessment; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Assessment */ }
		}

		/// <summary>
		/// Looks up by questionnaireID and returns AssessmentQuestionnaireOrderID value.  Uses the IndexBy_QuestionnaireID indexer.
		/// </summary>
		public int Lookup_AssessmentQuestionnaireOrderIDByQuestionnaireID(int questionnaireID)
		{
			return this.IndexBy_QuestionnaireID.LookupIntMember("AssessmentQuestionnaireOrderID", questionnaireID);
		}

		/// <summary>
		/// Sorts the collection by the sortOrder members.
		/// </summary>
		public void SortBy_SortOrder(bool ascending, bool ignoreCase)
		{
			CollectionUtil.SortBy(this, ascending, ignoreCase, new string[] { "sortOrder" });		
		}


	}
}
