using System;
using System.Collections;
using Tx4oleLib;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;
using Microsoft.ApplicationBlocks.Data;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for AssessmentContext.
	/// </summary>
	public class AssessmentContext
	{
		private Assessment assessment;
		private CMS cMS;
		private QuestionCollection questions;
				
		private LogicEvaluator logicEvaluator; 

		private InterventionTemplateCollection iTemplates;
		private InterventionTemplateLogicCollection iTemplateLogics;

		private int overallRiskID;
		private int overallRiskSeverityOrder = int.MaxValue;

		private int currentQuestionnaireIndex = -1;
		private int vPos;
		private int hPos;

		private bool materniChekCreated = false;

		private AssessmentQuestionNoteCollection questionNotes;

		private bool isReadOnly = true;

		private bool isDirty = true;
		private bool isNew = false;

		public bool IsDirty
		{
			get { return isDirty; }
			set { isDirty = value; }
		}

		public bool IsNew
		{
			get { return isNew; }
			set { isNew = value; }
		}

		public bool IsReadOnly
		{
			get { return isReadOnly; }
			set { isReadOnly = value; }
		}

		public int CurrentQuestionnaireIndex
		{
			get { return currentQuestionnaireIndex; }
			set { currentQuestionnaireIndex = value; }
		}

		public int VPos
		{
			get { return vPos; }
			set { vPos = value; }
		}

		public int HPos
		{
			get { return hPos; }
			set { hPos = value; }
		}
		
		public Assessment Assessment
		{
			get { return this.assessment; }
		}

		public CMS CMS
		{
			get { return cMS; }
			set { this.cMS = value; }
		}

		public bool MaterniChekCreated
		{
			get { return this.materniChekCreated; }
			set { this.materniChekCreated = value; }
		}

		public AssessmentQuestionnaireOrderCollection QuestionnaireOrders
		{
			get 
			{ 
				if (this.assessment.AssessmentQuestionnaireOrders == null)
					ReloadQuestionnaireOrders();
				return this.assessment.AssessmentQuestionnaireOrders; 
			}
		}

		public QuestionCollection Questions
		{
			get 
			{ 
				if (this.questions == null)
					ReloadQuestions();
				return this.questions; 
			}
			set { questions = value; }
		}

		public ResponseCollection Responses
		{
			get 
			{ 
				if (this.assessment.Responses == null)
					ReloadResponses();
				return this.assessment.Responses; 
			}
			set { this.assessment.Responses = value; }
		}

		public LogicEvaluator LogicEvaluator
		{
			get 
			{ 
				if (this.logicEvaluator == null)
					ReloadLogicEvaluator();
				return this.logicEvaluator; 
			}
			set { this.logicEvaluator = null; }
		}

		public string AssessmentGUID
		{
			get { return this.assessment.AssessmentGUID; }
		}

		public AssessmentQuestionNoteCollection QuestionNotes
		{
			get 
			{ 
				if (this.questionNotes == null)
					ReloadQuestionNotes();
				return this.questionNotes; 
			}
			set { this.questionNotes = null; }
		}

		public InterventionTemplateCollection ITemplates
		{
			get 
			{ 
				if (this.iTemplates == null)
					ReloadInterventionTemplates();
				return this.iTemplates; 
			}
			set { this.iTemplates = value; }
		}

		public InterventionTemplateLogicCollection ITemplateLogics
		{
			get 
			{ 
				if (this.iTemplateLogics == null)
					ReloadInterventionTemplateLogics();
				return this.iTemplateLogics; 
			}
			set { this.iTemplateLogics = value; }
		}


		public int OverallRiskID
		{
			get { return this.overallRiskID; }
			set { this.overallRiskID = value; }
		}

		public int OverallRiskSeverityOrder
		{
			get { return this.overallRiskSeverityOrder; }
			set { this.overallRiskSeverityOrder = value; }
		}

		public AssessmentContext(CMS cMS, string assessmentGUID)
		{
			this.cMS = cMS;
			this.assessment = new Assessment();
			this.assessment.Load(assessmentGUID);
		}

		public AssessmentContext(CMS cMS, Assessment assessment)
		{
			this.cMS = cMS;
			this.assessment = assessment;

			ResetContext();
		}


		/// <summary>
		/// Sets the dirty flag so the parent page cache
		/// </summary>
		public void Cache()
		{
			isDirty = true;	
		}
        
		
		public void Cancel()
		{
			if (this.IsNew)
			{
				bool atLeastOneResponse = false;
				foreach (Response response in this.Responses)
				{
					if (!response.IsNew) atLeastOneResponse = true;
					break;
				}

				// If there is no response in the DB we can remove the Assessment record
				if (!atLeastOneResponse)
				{
					this.Assessment.Delete();
					this.CMS.LoadAssessments(true);
				}
			}
			// Reload the patient related data so that the newly added items are gone
			this.CMS.Patient.LoadPatientMedications(true);
			this.CMS.Patient.LoadPatientMeasurements(true);
			this.CMS.Patient.LoadPatientAllergies(true);
			this.CMS.LoadPOCDeficits(true);
			this.CMS.LoadPOCInterventions(true);
			this.CMS.LoadCMSStatusHistories(true);
			this.CMS.LoadAssessments(true);

			this.CMS.RemoveMaternichek();
			this.ReloadQuestionnaireOrders();
		}


		private void ResetContext()
		{
			// Fix: Because we're referencing the assessment on CMS object 
			// and when the user is working on an assessment we go thru the old assessments for response history and stuff,
			// We load these collection on the assessment objects but we don't tie them to the assessmentcontext
			this.assessment.AssessmentQuestionnaireOrders = null;
			this.assessment.Responses = null;
		}

		private void Reload()
		{
			ReloadQuestions();
			ReloadQuestionnaireOrders();
		}

		private void ReloadInterventionTemplates()
		{
			iTemplates = new InterventionTemplateCollection();
			iTemplates.LoadAssessmentInterventionTemplates(this.AssessmentGUID);
		}

		private void ReloadInterventionTemplateLogics()
		{
			iTemplateLogics = new InterventionTemplateLogicCollection();
			iTemplateLogics.LoadAssessmentInterventionTemplateLogics(this.AssessmentGUID);
		}

		private void ReloadResponses()
		{
			this.assessment.LoadResponses(true);
			this.assessment.Responses.AssessmentContext = this;
		}

		// Created by Burag on 8/24 
		private void ReloadQuestions()
		{
			questions = new QuestionCollection();
			questions.AssessmentContext = this;
			//this.assessment.LoadAssessmentQuestionnaireOrders(true);
			//this.assessment.RefreshPresentationGroupQuestionOrdersFromDB();
			questions.LoadQuestionsByContentOwnerIDAssessmentGUID(-1, this.assessment.ContentOwnerID, this.assessment.AssessmentGUID);
		}


		private void ReloadLogicEvaluator()
		{
			logicEvaluator = new LogicEvaluator();
			logicEvaluator.AssessmentContext = this;
			logicEvaluator.Questions = this.Questions;
			logicEvaluator.UseCache = true;
		}

		// Changed by Burag on 8/24 to avoid loading all questions in the constructor.
		private void ReloadQuestions(bool loadAllQuestions)
		{
			questions = new QuestionCollection();
			questions.AssessmentContext = this;
			questions.LoadByContentOwnerID(assessment.ContentOwnerID);
		}

		private void ReloadQuestionNotes()
		{
			questionNotes = new AssessmentQuestionNoteCollection();
			questionNotes.LoadByCMSID(cMS.CMSID);
		}

		private void ReloadQuestionnaireOrders()
		{
			this.assessment.LoadAssessmentQuestionnaireOrders(true);
		}




		/// <summary>
		/// Returns the responses to a specific question in all the assessments 
		/// for this CMS. It may exclude the current assessment depending on the value of the argument passed
		/// </summary>
		/// <param name="questionID">Question ID</param>
		/// <param name="excludeCurrentAssessment">If this is true the current assessment responses are disregarded</param>
		/// <returns></returns>
		public ArrayList GetLatestReponses(int questionID, bool checkCurrentAssessment, bool checkOldAssessments, int howMany)
		{
			ArrayList latestResponses = new ArrayList();
			ArrayList tempResponses;
			ArrayList tempResponses2;

			if (howMany == 0) return latestResponses;

			// If current assessment is not excluded from the search, first look in there
			if (checkCurrentAssessment)
			{
				// Let's see if there is any answer for this question in this assessment
				tempResponses = this.Responses.FilterBy(questionID);	
				tempResponses2 = new ArrayList();
				if (tempResponses != null)
				{
					for (int index = 0 ; index < tempResponses.Count; index++)
					{
						if (!((Response)tempResponses[index]).IsMarkedForDeletion) tempResponses2.Add(tempResponses[index]);
					}
				}
				if (tempResponses2.Count > 0)
					latestResponses.Add(tempResponses2);
			}

			if (howMany != - 1 && latestResponses.Count >= howMany) return latestResponses;

			if (checkOldAssessments)
			{
				cMS.LoadAssessments(false);
				// The Assessments collection of CMS MUST BE ordered by date
				foreach (Assessment assessment in cMS.Assessments)
				{
					if (assessment.AssessmentGUID != AssessmentGUID)
					{
						assessment.LoadResponses(false);
						// Let's see if there is any answer for this question in this assessment
						tempResponses = assessment.Responses.FilterBy(questionID);	
						tempResponses2 = new ArrayList();
						if (tempResponses != null)
						{
							for (int index = 0 ; index < tempResponses.Count; index++)
							{
								if (!((Response)tempResponses[index]).IsMarkedForDeletion) tempResponses2.Add(tempResponses[index]);
							}
						}

						if (tempResponses2.Count > 0)
							latestResponses.Add(tempResponses2);
					}

					if (howMany != - 1 && latestResponses.Count >= howMany) return latestResponses;
				}


				if (latestResponses.Count > 0)
					return latestResponses;	
			}

			return null;
		}


		public ArrayList GetLatestMedicationReponses(int questionID, bool checkCurrentAssessment, bool checkOldAssessments, int howMany)
		{
			ArrayList latestResponses = new ArrayList();
			ArrayList tempResponses;
			ArrayList tempResponses2;

			if (howMany == 0) return latestResponses;

			this.cMS.ParentPatient.LoadPatientMedications(false);

			// If current assessment is not excluded from the search, first look in there
			if (checkCurrentAssessment)
			{
				// Let's see if there is any medication response for this question in this assessment

				tempResponses = this.cMS.ParentPatient.PatientMedications.FilterBy(this.AssessmentGUID, questionID);
				tempResponses2 = new ArrayList();
				if (tempResponses != null)
				{
					for (int index = 0 ; index < tempResponses.Count; index++)
					{
						if (!((PatientMedication)tempResponses[index]).IsMarkedForDeletion) tempResponses2.Add(tempResponses[index]);
					}
				}
				if (tempResponses2.Count > 0)
					latestResponses.Add(tempResponses2);
			}

			if (howMany != - 1 && latestResponses.Count >= howMany) return latestResponses;

			if (checkOldAssessments)
			{
				cMS.LoadAssessments(false);
				// The Assessments collection of CMS MUST BE ordered by date
				foreach (Assessment assessment in cMS.Assessments)
				{
					if (assessment.AssessmentGUID != AssessmentGUID)
					{
						assessment.LoadResponses(false);
						// Let's see if there is any answer for this question in this assessment
						tempResponses = this.cMS.ParentPatient.PatientMedications.FilterBy(assessment.AssessmentGUID, questionID);
						tempResponses2 = new ArrayList();
						if (tempResponses != null)
						{
							for (int index = 0 ; index < tempResponses.Count; index++)
							{
								if (!((PatientMedication)tempResponses[index]).IsMarkedForDeletion) tempResponses2.Add(tempResponses[index]);
							}
						}

						if (tempResponses2.Count > 0)
							latestResponses.Add(tempResponses2);
					}

					if (howMany != - 1 && latestResponses.Count >= howMany) return latestResponses;
				}


				if (latestResponses.Count > 0)
					return latestResponses;	
			}

			return null;

		}

	

		public bool EvaluateQuestionVisibility(ref Hashtable questionVisibilities)
		{
			bool atLeastOneQRVisible = false;
			bool atLeastOnePRVisible = false;
			bool atLeastOneQVisible = false;
			
			// Go over the QuestionnaireOrders
			for (int i = 0; i < this.assessment.AssessmentQuestionnaireOrders.Count; i++)
			{
				AssessmentQuestionnaireOrder assessmentQuestionnaireOrder = this.assessment.AssessmentQuestionnaireOrders[i];
			
				atLeastOnePRVisible = false;
				for (int j = 0; j < assessmentQuestionnaireOrder.QuestionnairePresentationGroupOrders.Count; j++)	
				{

					QuestionnairePresentationGroupOrder questionnairePresentationGroupOrder = assessmentQuestionnaireOrder.QuestionnairePresentationGroupOrders[j];
				
					atLeastOneQVisible = false;
					for (int k = 0; k < questionnairePresentationGroupOrder.PresentationGroupQuestionOrders.Count; k++)	
					{

						PresentationGroupQuestionOrder presentationGroupQuestionOrder = questionnairePresentationGroupOrder.PresentationGroupQuestionOrders[k];
						PresentationGroupQuestionOrder parentPresentationGroupQuestionOrder = null;

						Question question = this.Questions.FindBy(presentationGroupQuestionOrder.QuestionID);


						// Find parent question, if any
						for (int n = k; n > 0; n--)
						{
							if (questionnairePresentationGroupOrder.PresentationGroupQuestionOrders[n - 1].PresentationGroupQuestionOrderID == presentationGroupQuestionOrder.ParentPresentationGroupQuestionOrderID)
							{
								// We have a parent
								parentPresentationGroupQuestionOrder = questionnairePresentationGroupOrder.PresentationGroupQuestionOrders[n - 1];
								break;
							}
						}

						// Initially do not display it
						bool isVisible = false;

						// If we're in Readonly mode, just use the visibility values that come from db
						if (this.isReadOnly)
						{
							isVisible = presentationGroupQuestionOrder.IsVisible;
						}
						else
						{

							// If the question is not active then do not display it
							if (!question.Active)
							{
								isVisible  = false;
							}
							else
							{
								// If there is a parent and it's not visible don't display the child question
								if (parentPresentationGroupQuestionOrder == null || (parentPresentationGroupQuestionOrder.IsVisible && this.Responses.HasResponses(parentPresentationGroupQuestionOrder.QuestionID)))
								{
									// If it's a follow-up, only evaulate follow-up logic
									if (parentPresentationGroupQuestionOrder != null)
										isVisible = this.LogicEvaluator.EvaluateExpression(presentationGroupQuestionOrder.LogicID); 
									else // not a follow-up evaluate presentation logic
										isVisible = this.LogicEvaluator.EvaluateExpression(question.LogicID);
								}
							}
 
							presentationGroupQuestionOrder.IsVisible = isVisible;
							presentationGroupQuestionOrder.IsDirty = true;
						}

						if (isVisible) 	// We have at least one question in this presentation group visible
							atLeastOneQVisible = true;

						presentationGroupQuestionOrder.IndentLevel = 0;

						// Set the indentation by adding one to parent's indentation
						if (parentPresentationGroupQuestionOrder != null)
							presentationGroupQuestionOrder.IndentLevel = parentPresentationGroupQuestionOrder.IndentLevel + 1;

						// Set the flag in hashtable because at least one instance of this question is visible
						// FIX: If the flag is already set to true do not touch it
						if (questionVisibilities[question.QuestionID] == null || ((bool)questionVisibilities[question.QuestionID]) == false)
						{
							questionVisibilities[question.QuestionID] = isVisible;

							if (question.IsComplex)
							{
								foreach (Question sub in question.SubQuestions)
									questionVisibilities[sub.QuestionID] = isVisible;
							}

						}
					}
				
					// Make this presentation group visible
					questionnairePresentationGroupOrder.IsVisible = atLeastOneQVisible;
					questionnairePresentationGroupOrder.IsDirty = true;
					if (atLeastOneQVisible) atLeastOnePRVisible = true;
				}
				
				// Make this questionnaire visible
				assessmentQuestionnaireOrder.IsVisible = atLeastOnePRVisible;
				assessmentQuestionnaireOrder.IsDirty = true;
				if (atLeastOnePRVisible) atLeastOneQRVisible = true;
			}

			// We do this in the Save method
			// Do not change it here because otherwise it triggers isdirty
			// assessment.IsDirty = true;

			// Return whether there's anything at all to display in this assessment
			return atLeastOneQRVisible;
		}

	}
}
