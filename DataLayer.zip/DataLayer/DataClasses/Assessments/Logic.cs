using System;
using System.Collections;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_SearchLogics","SearchByArgs.sptpl","description, logicTypeID, contentOwnerID, expression", InjectPreOperation="SET ROWCOUNT @rowCount", InjectParameters="@rowCount int")]
	[SPAutoGen("usp_GetAllLogicsByInterventionTemplateID","SelectRelatedFromLinkedTable.sptpl","InterventionTemplateLogic, logicID, interventionTemplateID")]
	[SPDelete("usp_DeleteLogic")]
	[SPInsert("usp_InsertLogic")]
	[SPUpdate("usp_UpdateLogic")]
	[SPLoad("usp_LoadLogic")]
	[TableMapping("Logic","logicID")]
	public class Logic : BaseData
	{
		[NonSerialized]
		private LogicCollection parentLogicCollection;
		[ColumnMapping("LogicID",StereoType=DataStereoType.FK)]
		private int logicID;
		[ColumnMapping("LogicTypeID",StereoType=DataStereoType.FK)]
		private int logicTypeID = (int)LogicTypeEnum.Presentation;
		[ColumnMapping("Expression")]
		private string expression;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		private int contentOwnerID;
		private LogicQuestionCollection logicQuestions;
	
		public Logic(): base()
		{
		}

		public Logic(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public Logic(int logicID)
		{
			base.Load(logicID);
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int logicID)
		{
			return base.Load(logicID);
		}

		public static Logic NewFromExisting(int logicID)
		{
			Logic l = new Logic(logicID);
			l.isNew = true;
			return l;
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		//[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0, IsRequired=true)]
		[FieldDescription("@LOGICID@")]
		public int LogicID
		{
			get { return this.logicID; }
			set { this.logicID = value; }
		}

		[FieldValuesMember("LookupOf_LogicTypeID", "LogicTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@LOGICTYPE@")]
		public int LogicTypeID
		{
			get { return this.logicTypeID; }
			set { this.logicTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4000)]
		public string Expression
		{
			get { return this.expression; }
			set { this.expression = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255, IsRequired=true)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent LogicCollection that contains this element
		/// </summary>
		public LogicCollection ParentLogicCollection
		{
			get
			{
				return this.parentLogicCollection;
			}
			set
			{
				this.parentLogicCollection = value; // parent is set when added to a collection
			}
		}

		public LogicTypeCollection LookupOf_LogicTypeID
		{
			get
			{
				return LogicTypeCollection.AllLogicTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		/// <summary>
		/// Parent InterventionTemplate that contains this object
		/// </summary>
		public InterventionTemplate ParentInterventionTemplate
		{
			get { return this.ParentDataObject as InterventionTemplate; }
			set { this.ParentDataObject = value; /* parent is set when contained by a InterventionTemplate */ }
		}

		/// <summary>
		/// Parent AssessmentLevelOfDisease that contains this object
		/// </summary>
		public AssessmentLevelOfDisease ParentAssessmentLevelOfDisease
		{
			get { return this.ParentDataObject as AssessmentLevelOfDisease; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AssessmentLevelOfDisease */ }
		}

		/// <summary>
		/// Parent AssessmentMeasurement that contains this object
		/// </summary>
		public AssessmentMeasurement ParentAssessmentMeasurement
		{
			get { return this.ParentDataObject as AssessmentMeasurement; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AssessmentMeasurement */ }
		}

		/// <summary>
		/// Parent AssessmentRisk that contains this object
		/// </summary>
		public AssessmentRisk ParentAssessmentRisk
		{
			get { return this.ParentDataObject as AssessmentRisk; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AssessmentRisk */ }
		}


		/// <summary>
		/// This method creates a logic expression based on an answer
		/// </summary>
		/// <param name="answer"></param>
		public void CreateLogicFromObjects(Answer answer)
		{
			if (answer == null) return;

			int questionIndexID = answer.ParentAnswerCollection.ParentQuestion.QuestionIndexID;
			int componentIndexID = answer.ParentAnswerCollection.ParentQuestion.ComponentIndexID;
			int answerIndexID = answer.AnswerIndexID;

			// Set the ContentOwner
			this.ContentOwnerID = answer.ContentOwnerID;
			this.LogicTypeID = (int)LogicTypeEnum.Internal;
			this.Description = "Selected Answer";

            this.expression = String.Format("S(Q{0}, C{1}, A{2})", questionIndexID, componentIndexID, answerIndexID) ;

		}

		/// <summary>
		/// This method creates a logic expression based on an answerRange
		/// </summary>
		/// <param name="answerRange"></param>
		public void CreateLogicFromObjects(AnswerRange answerRange)
		{
			if (answerRange == null) return;

			int questionIndexID = answerRange.ParentAnswerRangeCollection.ParentAnswer.ParentAnswerCollection.ParentQuestion.QuestionIndexID;
			int componentIndexID = answerRange.ParentAnswerRangeCollection.ParentAnswer.ParentAnswerCollection.ParentQuestion.ComponentIndexID;
			int answerIndexID = answerRange.ParentAnswerRangeCollection.ParentAnswer.AnswerIndexID;

			// Set the ContentOwner
			this.ContentOwnerID = answerRange.ContentOwnerID;
			this.LogicTypeID = (int)LogicTypeEnum.Internal;
			this.Description = "In AnswerRange";

			string lowExpression = "";
			string highExpression = "";
			
			if (answerRange.LowOp != null && answerRange.LowValue != double.NaN)
				lowExpression = String.Format("(Q{0}, C{1}, A{2}) {3} {4}", questionIndexID, componentIndexID, answerIndexID, answerRange.LowOp, answerRange.LowValue);
			if (answerRange.HighOp != null && answerRange.HighValue != double.NaN)
				highExpression = String.Format("(Q{0}, C{1}, A{2}) {3} {4}", questionIndexID, componentIndexID, answerIndexID, answerRange.HighOp, answerRange.HighValue);

			if (lowExpression != "" && highExpression != "")
				this.expression = String.Format("(({0}) AND ({1}))", lowExpression, highExpression);
			else if (lowExpression != "")
				this.expression = lowExpression;
			else if (highExpression != "")
				this.expression = highExpression;
			else
				throw new ActiveAdviceException("Answer Range needs at least one of the high and low values.");
		}


		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			if (this.IsMarkedForDeletion)
			{
				if (!this.isNew)
				{
					this.LoadLogicQuestions(false);
					this.LogicQuestions.MarkAllDel();
					this.SaveLogicQuestions();
				}
				base.InternalSave();
				return;
			}

			QuestionCollection questions = new QuestionCollection();
			questions.SqlData.Transaction = this.sqlData.Transaction;

			questions.LoadByContentOwnerID(this.contentOwnerID);

			// In test mode logicEvaluator does not need an assessment context
			// So we can just create a new one
			LogicEvaluator logicEvaluator = new LogicEvaluator();
			logicEvaluator.Questions = questions;

			// Go into the test mode so the expression is evaluated 
			// and also the "questions invloved" list is generated
			logicEvaluator.BeginTestMode();
				
			// Evaluate the expression
			// The return value is irrelevant, as long as this method returns a boolean 
			// without throwing an exception that means we have a valid expression
			logicEvaluator.EvaluateExpression(this.expression);

			// If the logic passed evaluation we can save it
			base.InternalSave();

			// Get the list of questions involved in this logic
			ArrayList questionsInvolved = logicEvaluator.GetQuestionsInvolved();

			// Clear the old list from db 
			this.LoadLogicQuestions(true);
			if (!this.IsNew)
			{
				this.LogicQuestions.MarkAllDel();
				this.SaveLogicQuestions();
			}
                
			LogicQuestion logicQ = null;
			// for each question involved add a record to the breaker table
			for (int index = 0 ; index < questionsInvolved.Count; index++)
			{
				logicQ = new LogicQuestion(true);
				logicQ.LogicID = this.logicID;
				logicQ.QuestionID = ((Question)questionsInvolved[index]).QuestionID;
				this.logicQuestions.AddRecord(logicQ);
			}
			this.SaveLogicQuestions();

			// End the test mode
			logicEvaluator.EndTestMode();
		}

		/// <summary>
		/// Child LogicQuestions mapped to related rows of table LogicQuestion where [LogicID] = [LogicID]
		/// </summary>
		[SPLoadChild("usp_LoadLogicQuestions", "logicID")]
		public LogicQuestionCollection LogicQuestions
		{
			get { return this.logicQuestions; }
			set
			{
				this.logicQuestions = value;
				if (value != null)
					value.ParentLogic = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the LogicQuestions collection
		/// </summary>
		public void LoadLogicQuestions(bool forceReload)
		{
			this.logicQuestions = (LogicQuestionCollection)LogicQuestionCollection.LoadChildCollection("LogicQuestions", this, typeof(LogicQuestionCollection), logicQuestions, forceReload, null);
		}

		/// <summary>
		/// Saves the LogicQuestions collection
		/// </summary>
		public void SaveLogicQuestions()
		{
			LogicQuestionCollection.SaveChildCollection(this.logicQuestions, true);
		}

		/// <summary>
		/// Synchronizes the LogicQuestions collection
		/// </summary>
		public void SynchronizeLogicQuestions()
		{
			LogicQuestionCollection.SynchronizeChildCollection(this.logicQuestions, true);
		}



	}

	/// <summary>
	/// Strongly typed collection of Logic objects
	/// </summary>
	[ElementType(typeof(Logic))]
	public class LogicCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		public const int MAXRECORDS = 50;		//  -1 = unlimited

		private CollectionIndexer indexBy_LogicID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Logic elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLogicCollection = this;
			else
				elem.ParentLogicCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Logic elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Logic this[int index]
		{
			get
			{
				return (Logic)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Logic)oldValue, false);
			SetParentOnElem((Logic)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		public int SearchLogics(Logic searcher)
		{
			return SearchLogics(-1, MAXRECORDS, searcher);
		}
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchLogics(int maxRecords, int rowCount, Logic searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchLogics", maxRecords, this, searcher, false,
				new string[] {"rowCount"},
				new object[] {rowCount});
		}

		/// <summary>
		/// Parent InterventionTemplate that contains this collection
		/// </summary>
		public InterventionTemplate ParentInterventionTemplate
		{
			get { return this.ParentDataObject as InterventionTemplate; }
			set { this.ParentDataObject = value; /* parent is set when contained by a InterventionTemplate */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Logic elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Logic)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Hashtable based index on logicID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_LogicID
		{
			get
			{
				if (this.indexBy_LogicID == null)
					this.indexBy_LogicID = new CollectionIndexer(this, new string[] { "logicID" }, true);
				return this.indexBy_LogicID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on logicID fields returns the object.  Uses the IndexBy_LogicID indexer.
		/// </summary>
		public Logic FindBy(int logicID)
		{
			return (Logic)this.IndexBy_LogicID.GetObject(logicID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadAllLogicsByInterventionTemplateID(int maxRecords, int interventionTemplateID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLogicsByInterventionTemplateID", maxRecords, this, false, new object[] { interventionTemplateID });
		}

		public static LogicCollection GetLogicCollectionFromInterventionTemplate(int interventionTemplateID)
		{
			LogicCollection col = new LogicCollection();
			col.LoadAllLogicsByInterventionTemplateID(-1, interventionTemplateID);
			return col;
		}
	}
}
