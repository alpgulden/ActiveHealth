using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	public enum AnswerControlTypeEnum
	{
		Auto = 1,
		Numeric = 2,
		Text = 3,
		Memo = 4,
		Date = 5,
		RadioButton = 6,
		CheckBox = 7
	}
		


	/// <summary>
	/// Data class that wraps the entity access functionality to table [AnswerControlType]
	/// </summary>
	[SPAutoGen("usp_GetAllAnswerControlTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertAnswerControlType")]
	[SPUpdate("usp_UpdateAnswerControlType")]
	[SPLoad("usp_LoadAnswerControlType")]
	[TableMapping("AnswerControlType","answerControlTypeID")]
	public class AnswerControlType : BaseData
	{
		[NonSerialized]
		private AnswerControlTypeCollection parentAnswerControlTypeCollection;
		[ColumnMapping("AnswerControlTypeID",StereoType=DataStereoType.FK)]
		private int answerControlTypeID;
		[ColumnMapping("Description")]
		private string description;
	
		public AnswerControlType()
		{
		}

		public AnswerControlType(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AnswerControlTypeID
		{
			get { return this.answerControlTypeID; }
			set { this.answerControlTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=100)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent AnswerControlTypeCollection that contains this element
		/// </summary>
		public AnswerControlTypeCollection ParentAnswerControlTypeCollection
		{
			get
			{
				return this.parentAnswerControlTypeCollection;
			}
			set
			{
				this.parentAnswerControlTypeCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of AnswerControlType objects
	/// </summary>
	[ElementType(typeof(AnswerControlType))]
	public class AnswerControlTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AnswerControlType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAnswerControlTypeCollection = this;
			else
				elem.ParentAnswerControlTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AnswerControlType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AnswerControlType this[int index]
		{
			get
			{
				return (AnswerControlType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AnswerControlType)oldValue, false);
			SetParentOnElem((AnswerControlType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllAnswerControlTypes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllAnswerControlTypes", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared AnswerControlTypeCollection which is cached in NSGlobal
		/// </summary>
		public static AnswerControlTypeCollection AnswerControlTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				AnswerControlTypeCollection col = (AnswerControlTypeCollection)NSGlobal.EnsureCachedObject("AnswerControlTypes", typeof(AnswerControlTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllAnswerControlTypes(-1);
				}
				return col;
			}
			
		}
	}
}
