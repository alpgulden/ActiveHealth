using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PresentationGroupQuestionOrder]
	/// </summary>
	[SPAutoGen("usp_GetPresentationGroupQuestionOrdersByQuestionnairePresentationGroupOrderID","SelectAllByGivenArgs.sptpl","questionnairePresentationGroupOrderID", InjectOrderBy="ORDER BY [PresentationGroupQuestionOrder].[SortOrder]", ManuallyManaged=true)]
	[SPInsert("usp_InsertPresentationGroupQuestionOrder")]
	[SPUpdate("usp_UpdatePresentationGroupQuestionOrder")]
	// Delete uses a custom SP
	[SPDelete("usp_DeletePresentationGroupQuestionOrderWithCheck", ManuallyManaged = true)]
	[SPLoad("usp_LoadPresentationGroupQuestionOrder")]
	[TableMapping("PresentationGroupQuestionOrder","presentationGroupQuestionOrderID")]
	public class PresentationGroupQuestionOrder : BaseData
	{
		[NonSerialized]
		private PresentationGroupQuestionOrderCollection parentPresentationGroupQuestionOrderCollection;
		[ColumnMapping("PresentationGroupQuestionOrderID",StereoType=DataStereoType.FK)]
		private int presentationGroupQuestionOrderID;
		[ColumnMapping("QuestionnairePresentationGroupOrderID",StereoType=DataStereoType.FK)]
		private int questionnairePresentationGroupOrderID;
		[ColumnMapping("ParentPresentationGroupQuestionOrderID",StereoType=DataStereoType.FK)]
		private int parentPresentationGroupQuestionOrderID;
		[ColumnMapping("PresentationGroupID",StereoType=DataStereoType.FK)]
		private int presentationGroupID;
		[ColumnMapping("QuestionID",StereoType=DataStereoType.FK)]
		private int questionID;
		[ColumnMapping("SortOrder")]
		private string sortOrder;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("IsDisplayed")]
		private bool isDisplayed = false;
		private Question question;

		[ColumnMapping("LogicID", SQLGen = SQLGenerationFlags.NoInsertUpdate)]
		private int logicID;

		public int LogicID
		{
			get { return logicID; }
			set { logicID = value; }
		}

		private int indentLevel;

		public int IndentLevel
		{
			get { return indentLevel; }
			set { indentLevel = value; }
		}

		public PresentationGroupQuestionOrder() :  base()
		{
		}

		public PresentationGroupQuestionOrder(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PresentationGroupQuestionOrderID
		{
			get { return this.presentationGroupQuestionOrderID; }
			set { this.presentationGroupQuestionOrderID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionnairePresentationGroupOrderID
		{
			get { return this.questionnairePresentationGroupOrderID; }
			set { this.questionnairePresentationGroupOrderID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PresentationGroupID
		{
			get { return this.presentationGroupID; }
			set { this.presentationGroupID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionID
		{
			get { return this.questionID; }
			set { this.questionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4, IsRequired=true)]
		public string SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent PresentationGroupQuestionOrderCollection that contains this element
		/// </summary>
		public PresentationGroupQuestionOrderCollection ParentPresentationGroupQuestionOrderCollection
		{
			get
			{
				return this.parentPresentationGroupQuestionOrderCollection;
			}
			set
			{
				this.parentPresentationGroupQuestionOrderCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Contained Question object
		/// </summary>
		[Contained]
		public Question Question
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.question = (Question)Question.EnsureContainedDataObject(this, typeof(Question), question, false, questionID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.question;
			}
			set
			{
				this.question = value;
				if (value != null) value.ParentPresentationGroupQuestionOrder = this; // set this as a parent of the child data class
			}
		}

		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ParentPresentationGroupQuestionOrderID
		{
			get { return this.parentPresentationGroupQuestionOrderID; }
			set { this.parentPresentationGroupQuestionOrderID = value; }
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.
		}

		public bool IsDisplayed
		{
			get { return this.isDisplayed; }
			set { this.isDisplayed = value; }
		}

		public bool IsVisible
		{
			get { return this.isDisplayed; }
			set { this.isDisplayed = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of PresentationGroupQuestionOrder objects
	/// </summary>
	[ElementType(typeof(PresentationGroupQuestionOrder))]
	public class PresentationGroupQuestionOrderCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PresentationGroupQuestionOrder elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPresentationGroupQuestionOrderCollection = this;
			else
				elem.ParentPresentationGroupQuestionOrderCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PresentationGroupQuestionOrder elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PresentationGroupQuestionOrder this[int index]
		{
			get
			{
				return (PresentationGroupQuestionOrder)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PresentationGroupQuestionOrder)oldValue, false);
			SetParentOnElem((PresentationGroupQuestionOrder)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetPresentationGroupQuestionOrders(int maxRecords, int questionnairePresentationGroupOrderID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPresentationGroupQuestionOrdersByQuestionnairePresentationGroupOrderID", maxRecords, this, false, new object[] {questionnairePresentationGroupOrderID});
		}

		/// <summary>
		/// Parent QuestionnairePresentationGroupOrder that contains this collection
		/// </summary>
		public QuestionnairePresentationGroupOrder ParentQuestionnairePresentationGroupOrder
		{
			get { return this.ParentDataObject as QuestionnairePresentationGroupOrder; }
			set { this.ParentDataObject = value; /* parent is set when contained by a QuestionnairePresentationGroupOrder */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PresentationGroupQuestionOrder elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PresentationGroupQuestionOrder)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Add objects to this collection from PresentationGroupQuestionCollection
		/// loaded by presentationGroupID
		/// </summary>
		public void CreateFromPresentationGroupQuestion()
		{
			if (this == null)
				throw new Exception("PresentationGroupQuestionOrderCollection is NULL.");

			PresentationGroupQuestionCollection col = new PresentationGroupQuestionCollection();
			// Load by presentationGroupID
			col.LoadAllPresentationGroupQuestionsByPresentationGroupID(this.ParentQuestionnairePresentationGroupOrder.PresentationGroupID);
			foreach(PresentationGroupQuestion pgq in col)
			{
				PresentationGroupQuestionOrder pgqOrder = new PresentationGroupQuestionOrder(true);
					pgqOrder.QuestionID = pgq.QuestionID;
					pgqOrder.PresentationGroupID = pgq.PresentationGroupID;
					pgqOrder.QuestionnairePresentationGroupOrderID = this.ParentQuestionnairePresentationGroupOrder.QuestionnairePresentationGroupOrderID;
					pgqOrder.SortOrder = pgq.SortOrder;
				this.Add(pgqOrder);
			}
		}
	}
}
