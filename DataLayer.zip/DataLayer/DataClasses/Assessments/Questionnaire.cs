using System;
using System.Collections;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	public class SelectableQuestionnaire : Questionnaire
	{
		private bool selected;

		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}
	} 

	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_SearchQuestionnaires","SearchByArgs.sptpl","activeWithAll:active, description, contentOwnerID, questionnaireTypeID, cMSTypeID", InjectPreOperation="SET ROWCOUNT @rowCount", InjectOrderBy="ORDER BY  [Questionnaire].[QuestionnaireID] ASC", InjectParameters="@rowCount int")]
	[SPAutoGen("usp_GetAllQuestionnairesBySorgOrgMorg", null, ManuallyManaged=true)]
	[SPAutoGen("usp_GetAllQuestionnairesByActive","SelectAllByGivenArgsOrderBy.sptpl","sortOrder, ASC, active", InjectOrderBy="ORDER BY [Questionnaire].[SortOrder]")]
	[SPAutoGen("usp_GetUsableQuestionnairesBySorgOrgMorg", null, ManuallyManaged=true)]
	[SPAutoGen("usp_GetAllQuestionnariesTriggeredForScoringLoad", null, ManuallyManaged=true)]
	[SPAutoGen("usp_GetAllQuestionnariesTriggeredForCMSDxPx", null, ManuallyManaged=true)]
	[SPAutoGen("usp_SearchUsableQuestionnairesInOrder", null, ManuallyManaged=true)]
	[SPInsert("usp_InsertQuestionnaire")]
	[SPUpdate("usp_UpdateQuestionnaire")]
	[SPLoad("usp_LoadQuestionnaire")]
	[TableMapping("Questionnaire","questionnaireID")]
	public class Questionnaire : BaseAssessment
	{
		private ArrayList pageStartStack = new ArrayList();	// used to store page start values in paging.

		[NonSerialized]
		protected QuestionnaireCollection parentQuestionnaireCollection;
		[ColumnMapping("QuestionnaireID",StereoType=DataStereoType.FK)]
		protected int questionnaireID;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		protected int contentOwnerID;
		[ColumnMapping("Description")]
		protected string description;
		[ColumnMapping("QuestionnaireTypeID",StereoType=DataStereoType.FK)]
		protected int questionnaireTypeID;
		[ColumnMapping("CMSTypeID",StereoType=DataStereoType.FK)]
		protected int cMSTypeID;
		[ColumnMapping("Active")]
		protected bool active = true;
		[ColumnMapping("SortOrder")]
		protected int sortOrder = 0;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		protected QuestionnaireTriggerCollection triggers;
		protected QuestionnairePresentationGroupCollection presentationGroups;
		private QuestionnaireLetterMatrixCollection questionnaireLetterMatrixs;
	
		public Questionnaire(): base()
		{
		}

		public Questionnaire(int questionnaireID)
		{
			this.NewRecord(); // initialize record state
			this.questionnaireID = questionnaireID;
		}

		public Questionnaire(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int questionnaireID)
		{
			return base.Load(questionnaireID);
		}

		public ArrayList PageStartStack
		{
			get { return this.pageStartStack; }
			set { this.pageStartStack = value;	}
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		//[FieldDescription("@QUESTIONNAIREID@")]
		[FieldDescription("@ID@")]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value; }
		}

		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255, IsRequired=true)]
		[FieldDescription("@DESCRIPTION@")]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[FieldValuesMember("LookupOf_QuestionnaireTypeID", "QuestionnaireTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@QUESTIONNAIRETYPE@")]
		public int QuestionnaireTypeID
		{
			get { return this.questionnaireTypeID; }
			set { this.questionnaireTypeID = value; }
		}

		[FieldValuesMember("LookupOf_CMSTypeID", "CMSTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CMSTYPE@")]
		public int CMSTypeID
		{
			get { return this.cMSTypeID; }
			set { this.cMSTypeID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@ACTIVE@")]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
//				writer.AddSummaryTitle("@QUESTIONNAIRE@");
				writer.AddFields(this, "QuestionnaireID","Description");
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent QuestionnaireCollection that contains this element
		/// </summary>
		public QuestionnaireCollection ParentQuestionnaireCollection
		{
			get
			{
				return this.parentQuestionnaireCollection;
			}
			set
			{
				this.parentQuestionnaireCollection = value; // parent is set when added to a collection
			}
		}

		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
		}

		public QuestionnaireTypeCollection LookupOf_QuestionnaireTypeID
		{
			get
			{
				if (this.PrototypeInstance)
				{
					QuestionnaireTypeCollection col = new QuestionnaireTypeCollection();
					col.LoadAll();
					QuestionnaireType questionnaireType  = new QuestionnaireType();
						questionnaireType.QuestionnaireTypeID = 0;
						questionnaireType.Description = "All";
					col.InsertRecord(0, questionnaireType);
					return col;
				}
				else
					return QuestionnaireTypeCollection.ActiveQuestionnaireTypes;
			}
			
		}

		public CMSTypeCollection LookupOf_CMSTypeID
		{
			get
			{
				return CMSTypeCollection.ActiveCMSTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Child Triggers mapped to related rows of table QuestionnaireTrigger where [QuestionnaireID] = [QuestionnaireID]
		/// </summary>
		[SPLoadChild("usp_LoadQuestionnaireTriggers", "questionnaireID")]
		public QuestionnaireTriggerCollection Triggers
		{
			get { return this.triggers; }
			set
			{
				this.triggers = value;
				if (value != null)
					value.ParentQuestionnaire = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the QuestionnaireTriggers collection
		/// </summary>
		public void LoadTriggers(bool forceReload)
		{
			this.triggers = (QuestionnaireTriggerCollection)QuestionnaireTriggerCollection.LoadChildCollection("Triggers", this, typeof(QuestionnaireTriggerCollection), triggers, forceReload, null);
		}

		/// <summary>
		/// Saves the QuestionnaireTriggers collection
		/// </summary>
		public void SaveTriggers()
		{
			QuestionnaireTriggerCollection.SaveChildCollection(this.triggers, true);
		}

		/// <summary>
		/// Synchronizes the QuestionnaireTriggers collection
		/// </summary>
		public void SynchronizeTriggers()
		{
			QuestionnaireTriggerCollection.SynchronizeChildCollection(this.triggers, true);
		}

		/// <summary>
		/// Child QuestionnairePresentationGroups mapped to related rows of table QuestionnairePresentationGroup where [QuestionnaireID] = [QuestionnaireID]
		/// </summary>
		[SPLoadChild("usp_LoadQuestionnairePresentationGroups", "questionnaireID")]
		public QuestionnairePresentationGroupCollection PresentationGroups
		{
			get { return this.presentationGroups; }
			set
			{
				this.presentationGroups = value;
				if (value != null)
					value.ParentQuestionnaire = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the QuestionnairePresentationGroups collection
		/// </summary>
		public void LoadPresentationGroups(bool forceReload)
		{
			this.presentationGroups = (QuestionnairePresentationGroupCollection)QuestionnairePresentationGroupCollection.LoadChildCollection("PresentationGroups", this, typeof(QuestionnairePresentationGroupCollection), presentationGroups, forceReload, null);
		}

		/// <summary>
		/// Saves the QuestionnairePresentationGroups collection
		/// </summary>
		public void SavePresentationGroups()
		{
			QuestionnairePresentationGroupCollection.SaveChildCollection(this.presentationGroups, true);
		}

		/// <summary>
		/// Synchronizes the QuestionnairePresentationGroups collection
		/// </summary>
		public void SynchronizePresentationGroups()
		{
			QuestionnairePresentationGroupCollection.SynchronizeChildCollection(this.presentationGroups, true);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		/// <summary>
		/// Parent AssessmentQuestionnaireOrder that contains this object
		/// </summary>
		public AssessmentQuestionnaireOrder ParentAssessmentQuestionnaireOrder
		{
			get { return this.ParentDataObject as AssessmentQuestionnaireOrder; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AssessmentQuestionnaireOrder */ }
		}

		#region QuestionnaireLetterMatrixCollection
		/// <summary>
		/// Child QuestionnaireLetterMatrixs mapped to related rows of table QuestionnaireLetterMatrix where [QuestionnaireID] = [QuestionnaireID]
		/// </summary>
		[SPLoadChild("usp_LoadQuestionnaireQuestionnaireLetterMatrix", "questionnaireID")]
		public QuestionnaireLetterMatrixCollection QuestionnaireLetterMatrixs
		{
			get { return this.questionnaireLetterMatrixs; }
			set
			{
				this.questionnaireLetterMatrixs = value;
				if (value != null)
					value.ParentQuestionnaire = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the QuestionnaireLetterMatrixs collection
		/// </summary>
		public void LoadQuestionnaireLetterMatrixs(bool forceReload)
		{
			this.questionnaireLetterMatrixs = (QuestionnaireLetterMatrixCollection)QuestionnaireLetterMatrixCollection.LoadChildCollection("QuestionnaireLetterMatrixs", this, typeof(QuestionnaireLetterMatrixCollection), questionnaireLetterMatrixs, forceReload, null);
		}

		/// <summary>
		/// Saves the QuestionnaireLetterMatrixs collection
		/// </summary>
		public void SaveQuestionnaireLetterMatrixs()
		{
			QuestionnaireLetterMatrixCollection.SaveChildCollection(this.questionnaireLetterMatrixs, true);
		}

		/// <summary>
		/// Synchronizes the QuestionnaireLetterMatrixs collection
		/// </summary>
		public void SynchronizeQuestionnaireLetterMatrixs()
		{
			QuestionnaireLetterMatrixCollection.SynchronizeChildCollection(this.questionnaireLetterMatrixs, true);
		}
		#endregion

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.

			this.SavePresentationGroups();
			this.SaveTriggers();
			this.SaveQuestionnaireLetterMatrixs();
		}

	}

	/// <summary>
	/// Strongly typed collection of Questionnaire objects
	/// </summary>
	[ElementType(typeof(Questionnaire))]
	public class QuestionnaireCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_QuestionnaireID;
		public const int MAXRECORDS = 50;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Questionnaire elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentQuestionnaireCollection = this;
			else
				elem.ParentQuestionnaireCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Questionnaire elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Questionnaire this[int index]
		{
			get
			{
				return (Questionnaire)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Questionnaire)oldValue, false);
			SetParentOnElem((Questionnaire)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public int SearchQuestionnaires(Questionnaire searcher)
		{
			return SearchQuestionnaires(-1, MAXRECORDS, searcher);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchQuestionnaires(int maxRecords, int rowCount, Questionnaire searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			searcher.QuestionnaireTypeID = (searcher.QuestionnaireTypeID == -1 ? 0 : searcher.QuestionnaireTypeID);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchQuestionnaires", maxRecords, this, searcher, false, 
				new string[] {"rowCount", "activeWithAll"}, 
				new object[] {rowCount, activeWithAll});
		}


		public int SearchQuestionnairesInOrder(int maxRecords, int rowCount, Questionnaire searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			searcher.QuestionnaireTypeID = (searcher.QuestionnaireTypeID == -1 ? 0 : searcher.QuestionnaireTypeID);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchQuestionnairesInOrder", maxRecords, this, searcher, false, 
				new string[] {"rowCount", "activeWithAll"}, 
				new object[] {rowCount, activeWithAll});
		}
		
		public static QuestionnaireCollection GetQuestionnairesForSelectionInOrder(Questionnaire searcher)
		{
			QuestionnaireCollection col = new QuestionnaireCollection();
			// initialize the content of the collection
			col.ElementType = typeof(SelectableQuestionnaire);
			col.SearchQuestionnairesInOrder(-1, MAXRECORDS, searcher);
			return col;
		}

		public static QuestionnaireCollection GetQuestionnairesForSelection(Questionnaire searcher)
		{
			QuestionnaireCollection col = new QuestionnaireCollection();
			// initialize the content of the collection
			col.ElementType = typeof(SelectableQuestionnaire);
			col.SearchQuestionnaires(-1, MAXRECORDS, searcher);
			return col;
		}

		/// <summary>
		/// Search the usable questionaries under given cmsID.
		/// </summary>
		/// <param name="maxRecords"></param>
		/// <param name="rowCount"></param>
		/// <param name="searcher"></param>
		/// <param name="cmsID"></param>
		/// <returns></returns>
		public int SearchUsableQuestionnairesInOrder(int startQuestionnaireID, int startSortOrder, int maxRecords, int rowCount, Questionnaire searcher, int cmsID)
		{
			searcher.QuestionnaireTypeID = (searcher.QuestionnaireTypeID == -1 ? 0 : searcher.QuestionnaireTypeID);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchUsableQuestionnairesInOrder", maxRecords, this, searcher, false, 
				new string[] { "rowCount", "startQuestionnaireID", "startSortOrder", "cmsID" }, 
				new object[] { rowCount, startQuestionnaireID, startSortOrder, cmsID });
		}
		
		public static QuestionnaireCollection GetUsableQuestionnairesForSelectionInOrder(int startQuestionnaireID, int startSortOrder, Questionnaire searcher, int cmsID)
		{
			QuestionnaireCollection col = new QuestionnaireCollection();
			// initialize the content of the collection
			col.ElementType = typeof(SelectableQuestionnaire);
			col.SearchUsableQuestionnairesInOrder(startQuestionnaireID, startSortOrder, -1, MAXRECORDS, searcher, cmsID);
			return col;
		}
 

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchQuestionnairesByOrganization(int maxRecords, int rowCount, QuestionnaireOrganizationSearcher searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			this.ElementType = typeof(SelectableQuestionnaire);
			return SqlData.SPExecReadCol("usp_GetAllQuestionnairesBySorgOrgMorg", maxRecords, this, searcher, false, 
				new string[] {"rowCount", "activeWithAll"}, 
				new object[] {rowCount, activeWithAll});
		}

		public static QuestionnaireCollection GetQuestionnairesByOrganization(int maxRecords, QuestionnaireOrganizationSearcher searcher)
		{
			QuestionnaireCollection col = new QuestionnaireCollection();
			col.SearchQuestionnairesByOrganization(-1, MAXRECORDS, searcher);
			return col;
		}

		public static QuestionnaireCollection GetQuestionnairesByOrganization(QuestionnaireOrganizationSearcher searcher)
		{
			return GetQuestionnairesByOrganization(-1, searcher);
		}



		private int SearchUsableQuestionnairesByOrganization(int maxRecords, int rowCount, QuestionnaireOrganizationSearcher searcher)
		{
			this.Clear();
			this.ElementType = typeof(SelectableQuestionnaire);
			return SqlData.SPExecReadCol("usp_GetUsableQuestionnairesBySorgOrgMorg", maxRecords, this, searcher, false, 
				new string[] {"rowCount"}, 
				new object[] {rowCount});;
		}

		public static QuestionnaireCollection GetUsableQuestionnairesByOrganization(int maxRecords, QuestionnaireOrganizationSearcher searcher)
		{
			QuestionnaireCollection col = new QuestionnaireCollection();
			col.SearchUsableQuestionnairesByOrganization(-1, MAXRECORDS, searcher);
			return col;
		}

		public static QuestionnaireCollection GetUsableQuestionnairesByOrganization(QuestionnaireOrganizationSearcher searcher)
		{
			return GetUsableQuestionnairesByOrganization(-1, searcher);
		}

		public void SetSelectedQuestionnairesFromCollection(QuestionnaireOrganizationCollection selectedQuestionnaires)
		{
			QuestionnaireOrganization existingQuestionnaireOrganization = null;
			foreach (Questionnaire questionnaire in this)
			{
				existingQuestionnaireOrganization = selectedQuestionnaires.FindBy(questionnaire.QuestionnaireID);
				if (existingQuestionnaireOrganization != null && !existingQuestionnaireOrganization.IsMarkedForDeletion)
					((SelectableQuestionnaire)questionnaire).Selected = true;
				else
					((SelectableQuestionnaire)questionnaire).Selected = false;
			}
		}

		public void SetSelectedQuestionnairesFromCollection(AssessmentQuestionnaireOrderCollection selectedQuestionnaires)
		{
            selectedQuestionnaires.IndexBy_QuestionnaireID.Rebuild();
			
			AssessmentQuestionnaireOrder existingAssessmentQuestionnaireOrder = null;
			foreach (Questionnaire questionnaire in this)
			{
				existingAssessmentQuestionnaireOrder = selectedQuestionnaires.FindBy(questionnaire.QuestionnaireID);
				if (existingAssessmentQuestionnaireOrder != null && !existingAssessmentQuestionnaireOrder.IsMarkedForDeletion)
					((SelectableQuestionnaire)questionnaire).Selected = true;
				else
					((SelectableQuestionnaire)questionnaire).Selected = false;
			}
		}

//		public void SetSelectedQuestionnairesFromCollection(AssessmentScoringQuestionnaireTriggerCollection selectedQuestionnaires)
//		{
//			AssessmentScoringQuestionnaireTrigger existing = null;
//			foreach(Questionnaire questionnaire in this)
//			{
//				existing = selectedQuestionnaires.FindBy(questionnaire.QuestionnaireID);
//				if(existing != null && !existing.IsMarkedForDeletion)
//					((SelectableQuestionnaire)questionnaire).Selected = true;
//				else
//					((SelectableQuestionnaire)questionnaire).Selected = false;
//			}
//		}

		/// <summary>
		/// Hashtable based index on questionnaireID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionnaireID
		{
			get
			{
				if (this.indexBy_QuestionnaireID == null)
					this.indexBy_QuestionnaireID = new CollectionIndexer(this, new string[] { "questionnaireID" }, true);
				return this.indexBy_QuestionnaireID;
			}
		}

		/// <summary>
		/// Hashtable based search on questionnaireID fields returns the object.  Uses the IndexBy_QuestionnaireID indexer.
		/// </summary>
		public Questionnaire FindBy(int questionnaireID)
		{
			return (Questionnaire)this.IndexBy_QuestionnaireID.GetObject(questionnaireID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllQuestionnairesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllQuestionnairesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared QuestionnaireCollection which is cached in NSGlobal
		/// </summary>
		public static QuestionnaireCollection ActiveQuestionnaires
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				QuestionnaireCollection col = (QuestionnaireCollection)NSGlobal.EnsureCachedObject("ActiveQuestionnaires", typeof(QuestionnaireCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllQuestionnairesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Load all questionnaires triggered for CMS DxPx.
		/// </summary>
		public int LoadAllQuestionnariesTriggeredForCMSDxPx(int contentOwnerID, int cmsID, bool append)
		{
			if (!append)
				this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllQuestionnariesTriggeredForCMSDxPx", -1, this, false, 
				new object[] { cmsID, contentOwnerID });
		}

		/// <summary>
		/// Load all questionnaires triggered for scoring load.
		/// </summary>
		public int LoadAllQuestionnariesTriggeredForScoringLoad(int contentOwnerID, int cmsID, bool append)
		{
			if (!append)
				this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllQuestionnariesTriggeredForScoringLoad", -1, this, false, 
				new object[] { cmsID, contentOwnerID });
		}

		
		
	}
}
