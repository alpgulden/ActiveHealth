using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using Microsoft.JScript;
using Microsoft.JScript.Vsa;
using Microsoft.Vsa;
using System.Text.RegularExpressions;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.ApplicationBlocks.Data;
using NetsoftUSA.DataLayer;
using System.Text;
using System.Collections.Specialized;


namespace ActiveAdvice.DataLayer
{

	#region Exception classes
	public class LogicException : ActiveAdviceException
	{
		public LogicException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		public LogicException(string message)
			: base(message)
		{
		}
	}
	#endregion

	/// <summary>
	/// This class encapsulates all the logic necessary to evaluate given logical expressions.
	/// After creating an object of type LogicEvaluator, the caller must call EvaluateExpression method,
	/// which returns a boolean value depending on the validity of the expression.
	/// </summary>
	public class LogicEvaluator
	{

		private AssessmentContext assessmentContext;

		public AssessmentContext AssessmentContext
		{
			get { return assessmentContext; }
			set { assessmentContext = value; }
		}

		private QuestionCollection questions;

		public QuestionCollection Questions
		{
			get { return questions; }
			set { questions = value; }
		}

		
		private bool testMode = false;
		private ArrayList questionsInvolved = null;

		private bool useCache = false;
		private Hashtable cachedLogics = null;
		
		public void BeginTestMode()
		{
			this.testMode = true;
			questionsInvolved = new ArrayList(5);
		}

		public void EndTestMode()
		{
			this.testMode = false;
			questionsInvolved = null;
		}

		public ArrayList GetQuestionsInvolved()
		{
			if (this.testMode)
				return questionsInvolved;
			else
				throw new Exception("The method GetQuestionsInvolved can be used only in test mode");
		}

		public bool UseCache
		{
			get { return this.useCache; }
			set { this.useCache = value; }
		}

		public void ResetCache()
		{
			cachedLogics = new Hashtable(50);
		}

		
		public LogicEvaluator()
		{
			ResetCache();
		}


		/// <summary>
		/// Evaluates and returns the result for a logic expression given its ID
		/// </summary>
		/// <param name="logicID">ID for logic expression</param>
		/// <returns>TRUE if the expression is valid, otherwise FALSE</returns>
		public bool EvaluateExpression(int logicID)
		{
			// If there's nothing to evaluate the result is by default true
			if (logicID == 0) return true;

			Logic logic = null;
			string expression = null;

			try
			{
				// Look for the expression in the cache
				if (cachedLogics.ContainsKey(logicID))
					expression = (string)cachedLogics[logicID];
				else
				{
					// It's not there so load it from db
					logic = new Logic(logicID);
					expression = logic.Expression;
					// Cache the expression
					cachedLogics.Add(logicID, expression);
				}

				return EvaluateExpression(expression);
			}
			catch
			{
				throw new LogicException(String.Format("Logic ID ({0}) cannot be found", logicID));
			}
		}



		/// <summary>
		/// This method deals with evaluating the whole expression by splitting it into logical subexpressions.
		/// The process is done as follows:
		/// - The expression is splitted into logical subexpressions like: (Q123,A1) = 1  
		/// - QuestionID, AnswerIndexID, Operator, Response is extracted for each subexpression.
		/// - The above values are passed to CheckResponse method, which returns either true or false 
		/// depending on the validity of that subexpression.
		/// - In the expression, the subexpression is replaced by the return value of CheckResponse.
		/// - After processing each subexpression and replacing posible matches for predefined operators 
		/// like "AND, OR", the expression turns into a simple logical expression which can be evaluated 
		/// using JScript's Evaluation method. (ex. "(true && false) || true")
		///  
		/// Following regular expression pattern is designed to match all possible variations of a 
		/// subexpression.
		/// 
		/// (<QuestionIndexID>, <AnswerIndexID>) <Operator> (<NumericResponse>, <AlphaNumericResponse>, <DateResponse>)	
		/// ******Outdated	
		/// Pattern: "\\(\\s*Q(?<QuestionIndexID>[0-9]+)\\s*(,\\s*C(?<ComponentIndexID>((\\*)|([0-9]*)))\\s*)*(,\\s*A(?<AnswerIndexID>((\\*)|([0-9]*))))*\\s*\\)\\s*(?<Operator>(((=)|(>)|(<)|(!=)|(>=)|(<=)){1})) \\s* ( (?<AlphaNumericResponse>((\\\"\\\")|(\\\".*?([^\\\\]\\\")))) | (?<NumericResponse>[0-9\\.]+) | (?<DateResponse>(\\'[0-9]{2}\\.[0-9]{2}\\.[0-9]{4}(\\s[0-9]{2}:[0-9]{2}(:[0-9]{2})?(\\s[AP]M)?)?')))";
		/// 
		/// 
		/// Notes:
		/// - BackSlash and Quote characters are escaped.
		/// - A cheatsheet for the special characters used in regular expression patterns can be found at
		///		http://regexlib.com/CheatSheet.htm
		/// - When a match is found it is its components are extracted: QuestionID, ComponentIndexID, AnswerIndexID, Operator, AlphaNumericResponse, NumericResponse, DateResponse
		///	- QuestionIndexID can be any numeric value. No spaces allowed between the letter 'Q' and QuestionIndexID.
		///	- ComponentIndexID can be any numeric value. No spaces allowed between the letter 'C' and ComponentIndexID.
		///	- AnswerIndexID can be either a numeric value or '*' character, which means all the answers for a specific question.
		///		No spaces allowed between the letter 'A' and AnswerIndexID or '*' character.
		///	- Operator can be one of the following: =, >=, <=, <, <, != 
		///	- The righthand side of the subexpresion can be either numeric, alphanumeric or date. 
		///	  Alphanumeric values must be surrounded by double-quotes (ex. "abc").
		///	  If a double-quote must be used inside of an alphanumeric expression, Back-slash (\) character can be used to 
		///	  as an escape character. ex. "abc\"cde" 
		///	  Numeric values must be expressed without quotes and cannot include anything other than
		///	  digits and dot character for decimal values.
		///	- Date values must be surrended by single quotes. The format of the date is mm.dd.yyyy (hh:mm AM/PM)
		///	  
		/// </summary>
		/// <param name="expression">The string expression to be evaluated.</param>
		/// <returns>TRUE if the expression is valid, otherwise FALSE</returns>
		public bool EvaluateExpression(string expression)
		{
			try
			{
				// If there's nothing to evaluate the result is by default true
				if (expression == null) return true;

				// Declare local variables
				Regex regex;
				string temporaryExpression = expression;
		
				// This pattern is used to find all the posibble matches
				// Modified to accept date values
				string regPattern = "(?<Selected>[sS])?\\(\\s*[qQ](?<QuestionIndexID>[0-9]+)\\s*(,\\s*[cC](?<ComponentIndexID>((\\*)|([0-9]*))))?\\s*(,\\s*[aA](?<AnswerIndexID>((\\*)|([0-9]*))))?\\s*(,\\s*[rR](?<AnswerRangeIndexID>((\\*)|([0-9]*))))?\\s*\\)(\\s*(?<Operator>(((=)|(>)|(<)|(!=)|(>=)|(<=)){1})) \\s* ( (?<AlphaNumericResponse>((\\\"\\\")|(\\\".*?([^\\\\]\\\")))) | (?<NumericResponse>[0-9\\\\.]+) | (?<DateResponse>(\\'[0-9]{2}\\/[0-9]{2}\\/[0-9]{4}(\\s[0-9]{2}:[0-9]{2}(:[0-9]{2})?(\\s[AP]M)?)?'))))?";

				// RegEx object is created with following options:			
				// - RegexOptions.IgnoreCase: Finding a match is case-insensitive
				// - RegexOptions.Compiled: The pattern get compiled on the first run and consecutive operations run faster.
				// - RegexOptions.IgnorePatternWhitespace: White spaces in pattern expression are ignored.
				regex = new Regex( regPattern
					, RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			
				// Call the Replace method
				// This call is going to look for matching patterns in the expression 
				// and for each match it's going call the GetReplacementValue method
				temporaryExpression = regex.Replace(expression, new MatchEvaluator(GetReplacementValue));

				// Active Advice currently does not have any functions
				//temporaryExpression = AnalyzeFunctions(temporaryExpression);

				// Replace human readible logical operators with their JScript versions.
				// Fixed to support all cases of OR and AND
				//temporaryExpression = temporaryExpression.Replace("OR", " || ");
				//temporaryExpression = temporaryExpression.Replace("AND", " && ");
				
				temporaryExpression = Regex.Replace(temporaryExpression, "[oO][rR]", " || ");
				temporaryExpression = Regex.Replace(temporaryExpression, "[aA][nN][dD]", " && ");
				
				// New
				temporaryExpression = Regex.Replace(temporaryExpression, "[nN][oO][tT]", " ! ");

				// Pass the simplified logical expression into JSCriptEvaluate method and return the result to the caller.
				return JScriptEvaluate(expression, temporaryExpression);


			}
			catch(Exception ex)
			{
					if (this.testMode) 
						throw;
					else
						return false;
			}
		}


		/// <summary>
		/// This method takes the "match" and evaluates if it should be true or false
		/// </summary>
		/// <param name="match"></param>
		/// <returns></returns>
		private string GetReplacementValue(Match match)
		{
			bool selected = false;
			int questionIndexID = -1;
			int componentIndexID = -1;
			int answerIndexID = -1;
			int answerRangeIndexID = -1;

			// Set Numeric Response to -1, which means no Numeric Response has been provided.
			double numericResponse = -1;
			// Set AlphaNumeric response to null, which means no AlphaNumeric response has been provided.
			string alphaNumericResponse = null;

			string expressionOperator = null;
			// Set Date response to min date, which means no Date response has been provided.
			DateTime dateResponse = DateTime.MinValue;
			bool valid;

			try
			{

				// Check if "S" is there
				selected = match.Groups["Selected"].Success;

				// Extract the QuestionIndexID from match
				if (match.Groups["QuestionIndexID"].Success)
				{
					try
					{
						questionIndexID = int.Parse(match.Groups["QuestionIndexID"].ToString());
					}
					catch
					{
						throw new LogicException(String.Format("Error occured while parsing QuestionIndexID: {0}", match.Value));
					}
				}

				// Extract the ComponentIndexID from match.
				if (match.Groups["ComponentIndexID"].Success)
				{
					try
					{
						componentIndexID = int.Parse(match.Groups["ComponentIndexID"].ToString());
					}
					catch
					{
						throw new LogicException(String.Format("Error occured while parsing ComponentIndexID: {0}", match.Value));
					}
				}
				else
					componentIndexID = 0; // By default we use the main question.


				// Extract the AnswerIndexID from match.
				if (match.Groups["AnswerIndexID"].Success)
				{	
					if (match.Groups["AnswerIndexID"].ToString() == "*") // All answers
						answerIndexID = int.MinValue;
					else
					{
						try
						{
							answerIndexID = int.Parse(match.Groups["AnswerIndexID"].ToString());
						}
				
						catch
						{
							throw new LogicException(String.Format("Error occured while parsing AnswerIndexID: {0}", match.Value));
						}
					}
				}

				// Extract the AnswerRangeIndexID from match.
				if (match.Groups["AnswerRangeIndexID"].Success)
				{
					if (match.Groups["AnswerRangeIndexID"].ToString() == "*") // All answerRanges
						answerRangeIndexID  = int.MinValue;
					else
					{
						try
						{
							answerRangeIndexID = int.Parse(match.Groups["AnswerRangeIndexID"].ToString());
						}
						catch
						{
							throw new LogicException(String.Format("Error occured while parsing AnswerRangeIndexID: {0}", match.Value));
						}
					}
				}

				if (match.Groups["Operator"].Success)
				{
					// Extract the Operator from match
					expressionOperator = match.Groups["Operator"].ToString();
				}
				
				// If a Date Response exists
				if (match.Groups["DateResponse"].Success)
				{
					try
					{
						// Extract Date Response from match and parse it into DateTime.
						dateResponse = DateTime.Parse(match.Groups["DateResponse"].ToString());
					}
					catch
					{
						throw new LogicException(String.Format("Error occured while parsing date value, please make sure it's in correct format: {0}", match.Value));
					}
				}
					// If a Numeric response exists
				else if (match.Groups["NumericResponse"].Success)
				{
					try
					{
						// Extract Numeric Response from match and parse it into Double.
						numericResponse = Double.Parse(match.Groups["NumericResponse"].ToString());
					}
					catch
					{
						throw new LogicException(String.Format("Error occured while parsing numeric value, please make sure it's in correct format: {0}", match.Value));
					}
				}
					// If an AlphaNumeric Response exists
				else if (match.Groups["AlphaNumericResponse"].Success)
				{
					// Extract the AlphaNumeric response from match.
					alphaNumericResponse = match.Groups["AlphaNumericResponse"].ToString();
					if (alphaNumericResponse.StartsWith("\"")) alphaNumericResponse = alphaNumericResponse.Substring(1);
					if (alphaNumericResponse.EndsWith("\"")) alphaNumericResponse = alphaNumericResponse.Substring(0, alphaNumericResponse.Length - 1);

					// Replace escaped double-quotes with unescaped quotes.
					alphaNumericResponse = alphaNumericResponse.Replace("\\\"", "\"");
				}
			
				bool isNumeric = numericResponse != -1;
				bool isAlpha = alphaNumericResponse != null;
				bool isDate = dateResponse != DateTime.MinValue;

				if (questionIndexID == -1) // Question is always required
					throw new LogicException(String.Format("Expression does not have a QuestionIndexID: {0}", match.Value));
				if (selected && answerIndexID == -1) // If Selected AnswerIndexID is required (It can be A*)
					throw new LogicException(String.Format("When selected ('S') function is used AnswerIndexID must be present: {0}", match.Value));
				if (!selected && answerRangeIndexID != -1) // If not Selected AnswerRangeIndexID cannot be specified
					throw new LogicException(String.Format("Answer Ranges can only be used together with selected ('S') function: {0}", match.Value));
				if (answerRangeIndexID != -1 && answerIndexID < 0) // If AnswerRangeIndexID is specified AnswerIndexID must be specified and It CANNOT be A*
					throw new LogicException(String.Format("When Answer Range is specified, AnswerIndexID must be specified explicitly (A* cannot be used): {0}", match.Value));
				if (selected && expressionOperator != null)
					throw new LogicException(String.Format("Selected ('S') and Operator ({0}) cannot be used to together: {0}", match.Value));
				if (expressionOperator != null && !(isNumeric || isAlpha || isDate))
					throw new LogicException(String.Format("Expression contains an operator but no right-hand side value. Make sure you have a value in the correct format after the operator.", match.Value));
			
				// When "selected" shortcut is used and AnswerIndexID is explicitly specified, 
				// the expression itself cannot contain operator (restricted by line above) or value on the right-hand side but we need the operator to behave as equals (=) and we need to use the answerindexid value
				// If answerRangeIndexID is set we don't need this here since its being handled elsewhere
				//			if (selected && answerIndexID >= 0 && answerRangeIndexID < 0)
				//			{
				//				expressionOperator = "=";
				//				numericResponse = answerIndexID;
				//			}
			
			
				// Pass extracted values to CheckResponse method and get the boolean result.
				valid = CheckResponse(match, selected, questionIndexID, componentIndexID, answerIndexID, answerRangeIndexID, expressionOperator, alphaNumericResponse, numericResponse, dateResponse);

			}
			catch (Exception ex)
			{
				// Fix: If we're not in the test mode return false for only this piece of the expression
				if (this.testMode) 
					throw;
				else
					return "  false ";
			}

			if (valid) return " true "; else return "  false ";
		}



		/// <summary>
		/// This method takes a logic expression as its only parameter. It creates an instance of JScript engine,
		/// passes given expression to the JScriptEvaluate method of Eval class and returns the result returned by 
		/// that method to its caller. In case of an error in evaluation process it returns false.
		/// </summary>
		/// <param name="expression">Logical expression to be evaluated by the JScript engine</param>
		/// <returns></returns>
		private bool JScriptEvaluate(string originalExpression, string expression)
		{
			VsaEngine jsEngine = null;

			try
			{
				// Create an instance of VsaEngine 
				jsEngine = VsaEngine.CreateEngine();
				
				// Pass the expression and engine to Evaluator method.
				object result = Microsoft.JScript.Eval.JScriptEvaluate(expression, jsEngine);
				
				// If the result is something other than null return it
				if (result != null)
				{
					return (bool)result;
				}
				else
				{	
					// If result is null return false;
					return false;
				}

			}
			catch(Exception ex)
			{	
				// If an error occures return false;
				throw new LogicException(String.Format("The expression cannot be evaluated: {0} : {1}", originalExpression, expression), ex);
			}
		}


		private object JScriptCalculate(string expression)
		{
			VsaEngine jsEngine = null;

			try
			{
				// Create an instance of VsaEngine 
				jsEngine = VsaEngine.CreateEngine();
				
				// Pass the expression and engine to Evaluator method.
				object result = Microsoft.JScript.Eval.JScriptEvaluate(expression, jsEngine);
				
				return result;

			}
			catch
			{	
				// If an error occures return null;
				return null;
			}
		}



		/// <summary>
		/// This method queries the response table with the parameters passed to it, 
		/// in order to find out if the user has matching reponse(s).
		/// </summary>
		/// <param name="selected">If this is a "Selected" type of expression</param>
		/// <param name="questionIndexID">The QuestionIndex ID</param>
		/// <param name="componentIndexID">The ComponentIndex ID</param>
		/// <param name="answerIndexID">The AnswerIndexID. Note: -1 means no specific AnswerID is provided (A*) </param>
		/// <param name="expressionOperator">The Operator used in the expression</param>
		/// <param name="alphaNumericResponse">If Answer type is freetext this is provided. If this is null then numericResponse is used.</param>
		/// <param name="numericResponse">Numeric Response</param>
		/// <returns></returns>
		private bool CheckResponse(Match match, bool selected, int questionIndexID, int componentIndexID, int answerIndexID, int answerRangeIndexID, string expressionOperator, string alphaNumericResponse, double numericResponse, DateTime dateResponse)
		{
			bool isNumeric = numericResponse != -1;
			bool isAlpha = alphaNumericResponse != null;
			bool isDate = dateResponse != DateTime.MinValue;

			try
			{
				ArrayList allResponses = null;
				ArrayList responses = null;
				Question question = questions.FindByIndexID(questionIndexID, componentIndexID);

				if (question == null)
					throw new LogicException(String.Format("QuestionIndexID {0} cannot be found: {1}", questionIndexID, match.Value));

				question.SqlData.Transaction = questions.SqlData.Transaction;

				if (!this.testMode)
				{
					allResponses = assessmentContext.GetLatestReponses(question.QuestionID, true, false, 1);
					if (allResponses != null && allResponses.Count > 0)
						responses = (ArrayList)allResponses[0];
				}

				Answer answer = null;
				AnswerRange answerRange = null;

				Response responseToCheck = null;
				ArrayList responsesToCheck = new ArrayList(5);
				if (answerIndexID >= 0)
				{
					answer = question.Answers.FindByAnswerIndexID(answerIndexID);

					if (answer == null)
						throw new LogicException(String.Format("Question (QuestionIndexID = {0}) does not have an answer with AnswerIndexID {1}: {2}", questionIndexID, answerIndexID, match.Value));

					answer.SqlData.Transaction = question.SqlData.Transaction;

					if (!this.testMode)
					{
						if (responses != null)
						{
							for (int index = 0; index < responses.Count; index++)
							{
								if (((Response)responses[index]).AnswerID == answer.AnswerID)
									responseToCheck = (Response)responses[index];
							}
						}
						if (responseToCheck != null)
							responsesToCheck.Add(responseToCheck);
					}

					if (answerRangeIndexID >= 0)
					{
						answerRange = answer.AnswerRanges.FindBy(answerRangeIndexID);

						if (answerRange == null)
							throw new LogicException(String.Format("Question (QuestionIndexID = {0}) Answer (AnswerIndexID = {1}) does not have an answer range with AnswerRangeIndexID {2}: {3}", questionIndexID, answerIndexID, answerRangeIndexID, match.Value));

						answerRange.SqlData.Transaction = answer.SqlData.Transaction;
					}
				}
				else
				{
					if (!this.testMode)
					{
						responsesToCheck = responses;
					}
				}


			
				// At this point we know the question and answer and answer range are valid
				if (this.testMode)
				{
					bool foundQ = false;
					if (questionsInvolved != null)
					{
						for (int index = 0; index < questionsInvolved.Count; index++ )
						{
							if (((Question)questionsInvolved[index]).QuestionID == question.QuestionID)
							{
								foundQ = true;
								break;
							}
						}
					}
					if (!foundQ)
						questionsInvolved.Add(question);	
					
					return true;
				}
			
				if (responsesToCheck != null && responsesToCheck.Count > 0)
				{
					// If we we're looking for "selected" answerindex (not a answerange)
					// If we come up to this point we already know we have a matching response
					if (selected && answerRange == null) return true;

					Response currentResponse = null;
					bool found = false;
					for (int index = 0; index < responsesToCheck.Count; index++)
					{
						currentResponse = responsesToCheck[index] as Response;
						if (currentResponse != null)
						{
							if (answerRange != null || answerRangeIndexID == int.MinValue)
							{
								if(answerRange != null)
								{
									// We have an answer range
									if ((answerRange.LowOp == null || answerRange.LowValue == double.NaN || CompareValues(match, currentResponse, true /*isNumeric*/, false, false, answerRange.LowOp, null, answerRange.LowValue /*numericResponse*/, DateTime.MinValue)) &&
										(answerRange.HighOp == null || answerRange.HighValue == double.NaN || CompareValues(match, currentResponse, true /*isNumeric*/, false, false, answerRange.HighOp, null, answerRange.HighValue /*numericResponse*/, DateTime.MinValue)))
									{
										found = true;
										break;
									}
								}
								else if (answerRangeIndexID == int.MinValue) // Go over all ranges
								{
									foreach (AnswerRange range in answer.AnswerRanges)
									{	
										if ((range.LowOp == null || range.LowValue == double.NaN || CompareValues(match, currentResponse, true /*isNumeric*/, false, false, range.LowOp, null, range.LowValue /*numericResponse*/, DateTime.MinValue)) &&
											(range.HighOp == null || range.HighValue == double.NaN || CompareValues(match, currentResponse, true /*isNumeric*/, false, false, range.HighOp, null, range.HighValue /*numericResponse*/, DateTime.MinValue)))
										{
											found = true;
											break;
										}
									}
									if (found) break;
								}
							}
							else
							{
								// No range involved
								if (CompareValues(match, currentResponse, isNumeric, isAlpha, isDate, expressionOperator, alphaNumericResponse, numericResponse, dateResponse))
								{
									found = true;
									break;
								}
							}
						}
					}
			
					return found;
				}
			}
			catch(Exception ex)
			{
				throw new LogicException(String.Format("Error occured while evaluating the logic expression: {0}, Error Detail: {1}", match.Value, ex.Message), ex);
			}


			return false;
		}


		/// <summary>
		/// This method compares the user's response with the value in the logic expression
		/// </summary>
		/// <param name="currentResponse"></param>
		/// <param name="isNumeric"></param>
		/// <param name="isAlpha"></param>
		/// <param name="isDate"></param>
		/// <param name="expressionOperator"></param>
		/// <param name="alphaNumericResponse"></param>
		/// <param name="numericResponse"></param>
		/// <param name="dateResponse"></param>
		/// <returns></returns>
		private bool CompareValues(Match match, Response currentResponse, bool isNumeric, bool isAlpha, bool isDate, string expressionOperator, string alphaNumericResponse, double numericResponse, DateTime dateResponse)
		{
			if (expressionOperator == null) return false;
			expressionOperator = expressionOperator.Trim();

			switch (expressionOperator)
			{
				case "<":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) < numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) < dateResponse))
						return true;
					else if (isAlpha) 
						throw new LogicException(String.Format("Operator < cannot be used together with an alphanumeric value: {0}", match.Value));
					;
					break;
				case ">":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) > numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) > dateResponse))
						return true;
					else if (isAlpha) 
						throw new LogicException(String.Format("Operator > cannot be used together with an alphanumeric value: {0}", match.Value));
					break;
				case "=":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) == numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) == dateResponse) ||
						(isAlpha && currentResponse.AnswerText == alphaNumericResponse))
						return true;
					break;
				case "!=":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) != numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) != dateResponse) ||
						(isAlpha && currentResponse.AnswerText != alphaNumericResponse))
						return true;
					break;
				case ">=":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) >= numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) >= dateResponse))
						return true;
					else if (isAlpha)
						throw new LogicException(String.Format("Operator >= cannot be used together with an alphanumeric value: {0}", match.Value));
					break;
				case "<=":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) <= numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) <= dateResponse))
						return true;
					else if (isAlpha)
						throw new LogicException(String.Format("Operator <= cannot be used together with an alphanumeric value: {0}", match.Value));
					break;

			}

			return false;
		}


	}
}
