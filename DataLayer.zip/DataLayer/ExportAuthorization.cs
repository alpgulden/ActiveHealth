using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Staging_Authorization]
	/// </summary>
	[SPAutoGen("usp_LoadAuthorizationByBatchNumber","SelectAllByGivenArgs.sptpl","batchNumber")]
	[TableMapping("Staging_Authorization","eventReferralID")]
	public class ExportAuthorization : BaseDataClass
	{

		#region column mappings
		[ColumnMapping("BatchNumber")]
		private Guid batchNumber;
		[NonSerialized]
		private ExportAuthorizationCollection parentExportAuthorizationCollection;
		[ColumnMapping("EventReferralID",(int)0)]
		private int eventReferralID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("PatientFirstName")]
		private string patientFirstName;
		[ColumnMapping("PatientLastName")]
		private string patientLastName;
		[ColumnMapping("PatientMiddleInitial")]
		private string patientMiddleInitial;
		[ColumnMapping("PatientAddress1")]
		private string patientAddress1;
		[ColumnMapping("PatientAddress2")]
		private string patientAddress2;
		[ColumnMapping("PatientAddress3")]
		private string patientAddress3;
		[ColumnMapping("PatientCity")]
		private string patientCity;
		[ColumnMapping("PatientState")]
		private string patientState;
		[ColumnMapping("PatientZip")]
		private string patientZip;
		[ColumnMapping("PatientAlternateID")]
		private string patientAlternateID;
		[ColumnMapping("PatientMedicareID")]
		private string patientMedicareID;
		[ColumnMapping("PatientMedicaidID")]
		private string patientMedicaidID;
		[ColumnMapping("PatientAltPlanID")]
		private string patientAltPlanID;
		[ColumnMapping("PatientAltGroupID")]
		private string patientAltGroupID;
		[ColumnMapping("PatientAltMORGID")]
		private string patientAltMORGID;
		[ColumnMapping("PatientAltORGID")]
		private string patientAltORGID;
		[ColumnMapping("PatientAltSORGID")]
		private string patientAltSORGID;
		[ColumnMapping("PatientSSN")]
		private string patientSSN;
		[ColumnMapping("PatientDOB")]
		private DateTime patientDOB;
		[ColumnMapping("PatientGender")]
		private string patientGender;
		[ColumnMapping("SubscriberID",StereoType=DataStereoType.FK)]
		private int subscriberID;
		[ColumnMapping("SubscriberFirstName")]
		private string subscriberFirstName;
		[ColumnMapping("SubscriberLastName")]
		private string subscriberLastName;
		[ColumnMapping("SubscriberMiddleInitial")]
		private string subscriberMiddleInitial;
		[ColumnMapping("SubscriberAddress1")]
		private string subscriberAddress1;
		[ColumnMapping("SubscriberAddress2")]
		private string subscriberAddress2;
		[ColumnMapping("SubscriberAddress3")]
		private string subscriberAddress3;
		[ColumnMapping("SubscriberCity")]
		private string subscriberCity;
		[ColumnMapping("SubscriberState")]
		private string subscriberState;
		[ColumnMapping("SubscriberZip")]
		private string subscriberZip;
		[ColumnMapping("SubscriberAlternateID")]
		private string subscriberAlternateID;
		[ColumnMapping("SubscriberMedicareID")]
		private string subscriberMedicareID;
		[ColumnMapping("SubscriberMedicaidID")]
		private string subscriberMedicaidID;
		[ColumnMapping("SubscriberAltPlanID")]
		private string subscriberAltPlanID;
		[ColumnMapping("SubscriberAltGroupID")]
		private string subscriberAltGroupID;
		[ColumnMapping("SubscriberAltMORGID")]
		private string subscriberAltMORGID;
		[ColumnMapping("SubscriberAltORGID")]
		private string subscriberAltORGID;
		[ColumnMapping("SubscriberAltSORGID")]
		private string subscriberAltSORGID;
		[ColumnMapping("SubscriberSSN")]
		private string subscriberSSN;
		[ColumnMapping("SubscriberDOB")]
		private DateTime subscriberDOB;
		[ColumnMapping("SubscriberGender")]
		private string subscriberGender;
		[ColumnMapping("PCPFirstName")]
		private string pCPFirstName;
		[ColumnMapping("PCPLastName")]
		private string pCPLastName;
		[ColumnMapping("PCPMiddleInitial")]
		private string pCPMiddleInitial;
		[ColumnMapping("PCPSuffix")]
		private string pCPSuffix;
		[ColumnMapping("PCPAlternateID")]
		private string pCPAlternateID;
		[ColumnMapping("PCPTaxID")]
		private string pCPTaxID;
		[ColumnMapping("PCPMedicareID")]
		private string pCPMedicareID;
		[ColumnMapping("PCPNetworkAlternateID")]
		private string pCPNetworkAlternateID;
		[ColumnMapping("PCPLocationTaxID")]
		private string pCPLocationTaxID;
		[ColumnMapping("PCPAltLocationID")]
		private string pCPAltLocationID;
		[ColumnMapping("PCPAddress1")]
		private string pCPAddress1;
		[ColumnMapping("PCPAddress2")]
		private string pCPAddress2;
		[ColumnMapping("PCPAddress3")]
		private string pCPAddress3;
		[ColumnMapping("PCPCity")]
		private string pCPCity;
		[ColumnMapping("PCPState")]
		private string pCPState;
		[ColumnMapping("PCPZip")]
		private string pCPZip;
		[ColumnMapping("PCPPhone")]
		private string pCPPhone;
		[ColumnMapping("PCPupin")]
		private string pCPupin;
		[ColumnMapping("PCPspecialty")]
		private string pCPspecialty;
		[ColumnMapping("ProviderLastName")]
		private string providerLastName;
		[ColumnMapping("ProviderFirstName")]
		private string providerFirstName;
		[ColumnMapping("ProviderMiddleInitial")]
		private string providerMiddleInitial;
		[ColumnMapping("ProviderSuffix")]
		private string providerSuffix;
		[ColumnMapping("ProviderAlternateID")]
		private string providerAlternateID;
		[ColumnMapping("ProviderTaxID")]
		private string providerTaxID;
		[ColumnMapping("ProviderMedicareID")]
		private string providerMedicareID;
		[ColumnMapping("ProviderNetworkAlternateID")]
		private string providerNetworkAlternateID;
		[ColumnMapping("ProviderLocationTaxID")]
		private string providerLocationTaxID;
		[ColumnMapping("ProviderAltLocationID")]
		private string providerAltLocationID;
		[ColumnMapping("ProviderAddress1")]
		private string providerAddress1;
		[ColumnMapping("ProviderAddress2")]
		private string providerAddress2;
		[ColumnMapping("ProviderAddress3")]
		private string providerAddress3;
		[ColumnMapping("ProviderCity")]
		private string providerCity;
		[ColumnMapping("ProviderState")]
		private string providerState;
		[ColumnMapping("ProviderZip")]
		private string providerZip;
		[ColumnMapping("ProviderPhone")]
		private string providerPhone;
		[ColumnMapping("ProviderUPIN")]
		private string providerUPIN;
		[ColumnMapping("ProviderSpecialty")]
		private string providerSpecialty;
		[ColumnMapping("RefProviderLastName")]
		private string refProviderLastName;
		[ColumnMapping("RefProviderFirstName")]
		private string refProviderFirstName;
		[ColumnMapping("RefProviderMiddleInitial")]
		private string refProviderMiddleInitial;
		[ColumnMapping("RefProviderSuffix")]
		private string refProviderSuffix;
		[ColumnMapping("RefProviderAlternateID")]
		private string refProviderAlternateID;
		[ColumnMapping("RefProviderTaxID")]
		private string refProviderTaxID;
		[ColumnMapping("RefProviderMedicareID")]
		private string refProviderMedicareID;
		[ColumnMapping("RefProviderNetworkAlternateID")]
		private string refProviderNetworkAlternateID;
		[ColumnMapping("RefProviderLocationTaxID")]
		private string refProviderLocationTaxID;
		[ColumnMapping("RefProviderAltLocationID")]
		private string refProviderAltLocationID;
		[ColumnMapping("RefProviderAddress1")]
		private string refProviderAddress1;
		[ColumnMapping("RefProviderAddress2")]
		private string refProviderAddress2;
		[ColumnMapping("RefProviderAddress3")]
		private string refProviderAddress3;
		[ColumnMapping("RefProviderCity")]
		private string refProviderCity;
		[ColumnMapping("RefProviderState")]
		private string refProviderState;
		[ColumnMapping("RefProviderZip")]
		private string refProviderZip;
		[ColumnMapping("RefProviderPhone")]
		private string refProviderPhone;
		[ColumnMapping("RefProviderUPIN")]
		private string refProviderUPIN;
		[ColumnMapping("RefProviderSpecialty")]
		private string refProviderSpecialty;
		[ColumnMapping("FacilityName")]
		private string facilityName;
		[ColumnMapping("FacilityAlternateID")]
		private string facilityAlternateID;
		[ColumnMapping("FacilityTaxID")]
		private string facilityTaxID;
		[ColumnMapping("FacilityAlternateNetworkID")]
		private string facilityAlternateNetworkID;
		[ColumnMapping("FacilityLocationTaxID")]
		private string facilityLocationTaxID;
		[ColumnMapping("FacilityAlternateLocationID")]
		private string facilityAlternateLocationID;
		[ColumnMapping("FacilityType")]
		private string facilityType;
		[ColumnMapping("FacilityAddress1")]
		private string facilityAddress1;
		[ColumnMapping("FacilityAddress2")]
		private string facilityAddress2;
		[ColumnMapping("FacilityAddress3")]
		private string facilityAddress3;
		[ColumnMapping("FacilityCity")]
		private string facilityCity;
		[ColumnMapping("FacilityState")]
		private string facilityState;
		[ColumnMapping("FacilityZip")]
		private string facilityZip;
		[ColumnMapping("FacilityPhone")]
		private string facilityPhone;
		[ColumnMapping("GroupPracticeName")]
		private string groupPracticeName;
		[ColumnMapping("GroupPracticeAlternateID")]
		private string groupPracticeAlternateID;
		[ColumnMapping("GroupPracticeTaxID")]
		private string groupPracticeTaxID;
		[ColumnMapping("GroupPracticeAlternateNetworkID")]
		private string groupPracticeAlternateNetworkID;
		[ColumnMapping("GroupPracticeLocationTaxID")]
		private string groupPracticeLocationTaxID;
		[ColumnMapping("GroupPracticeAlternateLocationID")]
		private string groupPracticeAlternateLocationID;
		[ColumnMapping("GroupPracticeType")]
		private string groupPracticeType;
		[ColumnMapping("GroupPracticeAddress1")]
		private string groupPracticeAddress1;
		[ColumnMapping("GroupPracticeAddress2")]
		private string groupPracticeAddress2;
		[ColumnMapping("GroupPracticeAddress3")]
		private string groupPracticeAddress3;
		[ColumnMapping("GroupPracticeCity")]
		private string groupPracticeCity;
		[ColumnMapping("GroupPracticeState")]
		private string groupPracticeState;
		[ColumnMapping("GroupPracticeZip")]
		private string groupPracticeZip;
		[ColumnMapping("GroupPracticePhone")]
		private string groupPracticePhone;
		[ColumnMapping("PatientSubscriberLogID",StereoType=DataStereoType.FK)]
		private int patientSubscriberLogID;
		#endregion
	
		public ExportAuthorization()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Parent ExportAuthorizationCollection that contains this element
		/// </summary>
		public ExportAuthorizationCollection ParentExportAuthorizationCollection
		{
			get
			{
				return this.parentExportAuthorizationCollection;
			}
			set
			{
				this.parentExportAuthorizationCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// GenerateFormattedOutput()
		/// This method will create the x12 formatted
		/// output for the contents of this 
		/// authorization record
		/// </summary>
		/// <returns>string x12out, the formatted x12 output string, ready to write to a file</returns>
		public string GenerateFormattedOutput()
		{
			string x12out;
			x12out  = X12subscriber();
			x12out += X12patient();
			x12out += X12pcp();
			x12out += X12provider();
			x12out += X12refprovider();
			x12out += X12facility();
			x12out += X12grouppractice();
			return x12out;
		}

		#region properties
		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string PatientMiddleInitial
		{
			get { return this.patientMiddleInitial; }
			set { this.patientMiddleInitial = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string SubscriberMiddleInitial
		{
			get { return this.subscriberMiddleInitial; }
			set { this.subscriberMiddleInitial = value; }
		}
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EventReferralID
		{
			get { return this.eventReferralID; }
			set { this.eventReferralID = value; }
		}

		public System.Guid BatchNumber
		{
			get { return this.batchNumber; }
			set { this.batchNumber = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string PatientFirstName
		{
			get { return this.patientFirstName; }
			set { this.patientFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string PatientLastName
		{
			get { return this.patientLastName; }
			set { this.patientLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string PatientAddress1
		{
			get { return this.patientAddress1; }
			set { this.patientAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string PatientAddress2
		{
			get { return this.patientAddress2; }
			set { this.patientAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string PatientAddress3
		{
			get { return this.patientAddress3; }
			set { this.patientAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PatientCity
		{
			get { return this.patientCity; }
			set { this.patientCity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string PatientState
		{
			get { return this.patientState; }
			set { this.patientState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string PatientZip
		{
			get { return this.patientZip; }
			set { this.patientZip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PatientAlternateID
		{
			get { return this.patientAlternateID; }
			set { this.patientAlternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PatientMedicareID
		{
			get { return this.patientMedicareID; }
			set { this.patientMedicareID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PatientMedicaidID
		{
			get { return this.patientMedicaidID; }
			set { this.patientMedicaidID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PatientAltPlanID
		{
			get { return this.patientAltPlanID; }
			set { this.patientAltPlanID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PatientAltGroupID
		{
			get { return this.patientAltGroupID; }
			set { this.patientAltGroupID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PatientAltMORGID
		{
			get { return this.patientAltMORGID; }
			set { this.patientAltMORGID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PatientAltORGID
		{
			get { return this.patientAltORGID; }
			set { this.patientAltORGID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PatientAltSORGID
		{
			get { return this.patientAltSORGID; }
			set { this.patientAltSORGID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string PatientSSN
		{
			get { return this.patientSSN; }
			set { this.patientSSN = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PatientDOB
		{
			get { return this.patientDOB; }
			set { this.patientDOB = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string PatientGender
		{
			get { return this.patientGender; }
			set { this.patientGender = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberID
		{
			get { return this.subscriberID; }
			set { this.subscriberID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string SubscriberFirstName
		{
			get { return this.subscriberFirstName; }
			set { this.subscriberFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string SubscriberLastName
		{
			get { return this.subscriberLastName; }
			set { this.subscriberLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string SubscriberAddress1
		{
			get { return this.subscriberAddress1; }
			set { this.subscriberAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string SubscriberAddress2
		{
			get { return this.subscriberAddress2; }
			set { this.subscriberAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string SubscriberAddress3
		{
			get { return this.subscriberAddress3; }
			set { this.subscriberAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SubscriberCity
		{
			get { return this.subscriberCity; }
			set { this.subscriberCity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string SubscriberState
		{
			get { return this.subscriberState; }
			set { this.subscriberState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string SubscriberZip
		{
			get { return this.subscriberZip; }
			set { this.subscriberZip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SubscriberAlternateID
		{
			get { return this.subscriberAlternateID; }
			set { this.subscriberAlternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SubscriberMedicareID
		{
			get { return this.subscriberMedicareID; }
			set { this.subscriberMedicareID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SubscriberMedicaidID
		{
			get { return this.subscriberMedicaidID; }
			set { this.subscriberMedicaidID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SubscriberAltPlanID
		{
			get { return this.subscriberAltPlanID; }
			set { this.subscriberAltPlanID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SubscriberAltGroupID
		{
			get { return this.subscriberAltGroupID; }
			set { this.subscriberAltGroupID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SubscriberAltMORGID
		{
			get { return this.subscriberAltMORGID; }
			set { this.subscriberAltMORGID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SubscriberAltORGID
		{
			get { return this.subscriberAltORGID; }
			set { this.subscriberAltORGID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SubscriberAltSORGID
		{
			get { return this.subscriberAltSORGID; }
			set { this.subscriberAltSORGID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string SubscriberSSN
		{
			get { return this.subscriberSSN; }
			set { this.subscriberSSN = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime SubscriberDOB
		{
			get { return this.subscriberDOB; }
			set { this.subscriberDOB = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string SubscriberGender
		{
			get { return this.subscriberGender; }
			set { this.subscriberGender = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string PCPFirstName
		{
			get { return this.pCPFirstName; }
			set { this.pCPFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string PCPLastName
		{
			get { return this.pCPLastName; }
			set { this.pCPLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string PCPMiddleInitial
		{
			get { return this.pCPMiddleInitial; }
			set { this.pCPMiddleInitial = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string PCPSuffix
		{
			get { return this.pCPSuffix; }
			set { this.pCPSuffix = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PCPAlternateID
		{
			get { return this.pCPAlternateID; }
			set { this.pCPAlternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string PCPTaxID
		{
			get { return this.pCPTaxID; }
			set { this.pCPTaxID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string PCPMedicareID
		{
			get { return this.pCPMedicareID; }
			set { this.pCPMedicareID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PCPNetworkAlternateID
		{
			get { return this.pCPNetworkAlternateID; }
			set { this.pCPNetworkAlternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string PCPLocationTaxID
		{
			get { return this.pCPLocationTaxID; }
			set { this.pCPLocationTaxID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PCPAltLocationID
		{
			get { return this.pCPAltLocationID; }
			set { this.pCPAltLocationID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string PCPAddress1
		{
			get { return this.pCPAddress1; }
			set { this.pCPAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string PCPAddress2
		{
			get { return this.pCPAddress2; }
			set { this.pCPAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string PCPAddress3
		{
			get { return this.pCPAddress3; }
			set { this.pCPAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PCPCity
		{
			get { return this.pCPCity; }
			set { this.pCPCity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string PCPState
		{
			get { return this.pCPState; }
			set { this.pCPState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string PCPZip
		{
			get { return this.pCPZip; }
			set { this.pCPZip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string PCPPhone
		{
			get { return this.pCPPhone; }
			set { this.pCPPhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string PCPupin
		{
			get { return this.pCPupin; }
			set { this.pCPupin = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string PCPspecialty
		{
			get { return this.pCPspecialty; }
			set { this.pCPspecialty = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string ProviderLastName
		{
			get { return this.providerLastName; }
			set { this.providerLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string ProviderFirstName
		{
			get { return this.providerFirstName; }
			set { this.providerFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string ProviderMiddleInitial
		{
			get { return this.providerMiddleInitial; }
			set { this.providerMiddleInitial = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string ProviderSuffix
		{
			get { return this.providerSuffix; }
			set { this.providerSuffix = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string ProviderAlternateID
		{
			get { return this.providerAlternateID; }
			set { this.providerAlternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string ProviderTaxID
		{
			get { return this.providerTaxID; }
			set { this.providerTaxID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string ProviderMedicareID
		{
			get { return this.providerMedicareID; }
			set { this.providerMedicareID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string ProviderNetworkAlternateID
		{
			get { return this.providerNetworkAlternateID; }
			set { this.providerNetworkAlternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string ProviderLocationTaxID
		{
			get { return this.providerLocationTaxID; }
			set { this.providerLocationTaxID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string ProviderAltLocationID
		{
			get { return this.providerAltLocationID; }
			set { this.providerAltLocationID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string ProviderAddress1
		{
			get { return this.providerAddress1; }
			set { this.providerAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string ProviderAddress2
		{
			get { return this.providerAddress2; }
			set { this.providerAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string ProviderAddress3
		{
			get { return this.providerAddress3; }
			set { this.providerAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string ProviderCity
		{
			get { return this.providerCity; }
			set { this.providerCity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string ProviderState
		{
			get { return this.providerState; }
			set { this.providerState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string ProviderZip
		{
			get { return this.providerZip; }
			set { this.providerZip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string ProviderPhone
		{
			get { return this.providerPhone; }
			set { this.providerPhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string ProviderUPIN
		{
			get { return this.providerUPIN; }
			set { this.providerUPIN = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string ProviderSpecialty
		{
			get { return this.providerSpecialty; }
			set { this.providerSpecialty = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RefProviderLastName
		{
			get { return this.refProviderLastName; }
			set { this.refProviderLastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string RefProviderFirstName
		{
			get { return this.refProviderFirstName; }
			set { this.refProviderFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string RefProviderMiddleInitial
		{
			get { return this.refProviderMiddleInitial; }
			set { this.refProviderMiddleInitial = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string RefProviderSuffix
		{
			get { return this.refProviderSuffix; }
			set { this.refProviderSuffix = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string RefProviderAlternateID
		{
			get { return this.refProviderAlternateID; }
			set { this.refProviderAlternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string RefProviderTaxID
		{
			get { return this.refProviderTaxID; }
			set { this.refProviderTaxID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string RefProviderMedicareID
		{
			get { return this.refProviderMedicareID; }
			set { this.refProviderMedicareID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string RefProviderNetworkAlternateID
		{
			get { return this.refProviderNetworkAlternateID; }
			set { this.refProviderNetworkAlternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string RefProviderLocationTaxID
		{
			get { return this.refProviderLocationTaxID; }
			set { this.refProviderLocationTaxID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string RefProviderAltLocationID
		{
			get { return this.refProviderAltLocationID; }
			set { this.refProviderAltLocationID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string RefProviderAddress1
		{
			get { return this.refProviderAddress1; }
			set { this.refProviderAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string RefProviderAddress2
		{
			get { return this.refProviderAddress2; }
			set { this.refProviderAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string RefProviderAddress3
		{
			get { return this.refProviderAddress3; }
			set { this.refProviderAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string RefProviderCity
		{
			get { return this.refProviderCity; }
			set { this.refProviderCity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string RefProviderState
		{
			get { return this.refProviderState; }
			set { this.refProviderState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string RefProviderZip
		{
			get { return this.refProviderZip; }
			set { this.refProviderZip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string RefProviderPhone
		{
			get { return this.refProviderPhone; }
			set { this.refProviderPhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string RefProviderUPIN
		{
			get { return this.refProviderUPIN; }
			set { this.refProviderUPIN = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string RefProviderSpecialty
		{
			get { return this.refProviderSpecialty; }
			set { this.refProviderSpecialty = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string FacilityName
		{
			get { return this.facilityName; }
			set { this.facilityName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string FacilityAlternateID
		{
			get { return this.facilityAlternateID; }
			set { this.facilityAlternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string FacilityTaxID
		{
			get { return this.facilityTaxID; }
			set { this.facilityTaxID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string FacilityAlternateNetworkID
		{
			get { return this.facilityAlternateNetworkID; }
			set { this.facilityAlternateNetworkID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string FacilityLocationTaxID
		{
			get { return this.facilityLocationTaxID; }
			set { this.facilityLocationTaxID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string FacilityAlternateLocationID
		{
			get { return this.facilityAlternateLocationID; }
			set { this.facilityAlternateLocationID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string FacilityType
		{
			get { return this.facilityType; }
			set { this.facilityType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string FacilityAddress1
		{
			get { return this.facilityAddress1; }
			set { this.facilityAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string FacilityAddress2
		{
			get { return this.facilityAddress2; }
			set { this.facilityAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string FacilityAddress3
		{
			get { return this.facilityAddress3; }
			set { this.facilityAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string FacilityCity
		{
			get { return this.facilityCity; }
			set { this.facilityCity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string FacilityState
		{
			get { return this.facilityState; }
			set { this.facilityState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string FacilityZip
		{
			get { return this.facilityZip; }
			set { this.facilityZip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string FacilityPhone
		{
			get { return this.facilityPhone; }
			set { this.facilityPhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string GroupPracticeName
		{
			get { return this.groupPracticeName; }
			set { this.groupPracticeName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string GroupPracticeAlternateID
		{
			get { return this.groupPracticeAlternateID; }
			set { this.groupPracticeAlternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string GroupPracticeTaxID
		{
			get { return this.groupPracticeTaxID; }
			set { this.groupPracticeTaxID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string GroupPracticeAlternateNetworkID
		{
			get { return this.groupPracticeAlternateNetworkID; }
			set { this.groupPracticeAlternateNetworkID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string GroupPracticeLocationTaxID
		{
			get { return this.groupPracticeLocationTaxID; }
			set { this.groupPracticeLocationTaxID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string GroupPracticeAlternateLocationID
		{
			get { return this.groupPracticeAlternateLocationID; }
			set { this.groupPracticeAlternateLocationID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string GroupPracticeType
		{
			get { return this.groupPracticeType; }
			set { this.groupPracticeType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string GroupPracticeAddress1
		{
			get { return this.groupPracticeAddress1; }
			set { this.groupPracticeAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string GroupPracticeAddress2
		{
			get { return this.groupPracticeAddress2; }
			set { this.groupPracticeAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string GroupPracticeAddress3
		{
			get { return this.groupPracticeAddress3; }
			set { this.groupPracticeAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string GroupPracticeCity
		{
			get { return this.groupPracticeCity; }
			set { this.groupPracticeCity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string GroupPracticeState
		{
			get { return this.groupPracticeState; }
			set { this.groupPracticeState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string GroupPracticeZip
		{
			get { return this.groupPracticeZip; }
			set { this.groupPracticeZip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string GroupPracticePhone
		{
			get { return this.groupPracticePhone; }
			set { this.groupPracticePhone = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientSubscriberLogID
		{
			get { return this.patientSubscriberLogID; }
			set { this.patientSubscriberLogID = value; }
		}
		#endregion

		protected string FormatRecord(string format, object[] args)
		{
			string[] newargs = new string[args.Length];
			bool isnull = true;
			for(int i = 0; i < args.Length; i++)
			{
				Type t = args[i].GetType();
				if (t == typeof(System.Boolean))
				{
					bool x = Convert.ToBoolean(args[i]);
					newargs[i] = (x ? "Y" : "N");
				}
				else if (t == typeof(System.Int32) )
				{
					int x = Convert.ToInt32(args[i]);
					if (x == 0)
						newargs[i] = "";
					else
					{
						newargs[i] = x.ToString();
						isnull = false;
					}
				}
				else if (t == typeof(System.DateTime) )
				{
					DateTime x = Convert.ToDateTime(args[i]);
					if (x.Year == 1)
						newargs[i] = "";
					else
					{
						newargs[i] = x.ToString("yyyyddMM");
						isnull = false;
					}
				}
				else if (t == typeof(System.String) )
				{
					newargs[i] = args[i].ToString();
					if (newargs[i] != "")
						isnull = false;
				}
				else
					return null;
			}// end of for

			if (!isnull)
				return null; // empty string

			string x12 = string.Format(format, newargs) + "\r\n";

			return x12;
		}// end of method

		protected string X12refprovider()
		{
			string x12out;
			x12out  = FormatRecord("NM1*DN*1*{0}*{1}*{2}**{3}*{4}", new object[] {RefProviderLastName, RefProviderFirstName, RefProviderMiddleInitial, RefProviderSuffix, RefProviderAlternateID});
			x12out += FormatRecord("REF*TJ*{0}", new object[] {RefProviderTaxID});
			x12out += FormatRecord("REF*1C*{0}", new object[] {RefProviderMedicareID});
			x12out += FormatRecord("REF*N5*{0}", new object[] {RefProviderNetworkAlternateID});
			x12out += FormatRecord("REF*4L*{0}", new object[] {RefProviderAltLocationID});
			x12out += FormatRecord("REF*ZZ*{0}", new object[] {RefProviderAltLocationID});
			x12out += FormatRecord("N3*{0}*{1}", new object[] {RefProviderAddress1, RefProviderAddress2});
			x12out += FormatRecord("N3*{0}", new object[] {RefProviderAddress3});
			x12out += FormatRecord("N4*{0}*{1}*{2}**94*{3}", new object[] {RefProviderCity, RefProviderState, RefProviderZip, RefProviderAltLocationID});
			x12out += FormatRecord("PER*1F*TE*{0}", new object[] {RefProviderPhone});
			x12out += FormatRecord("PRV*RF*1G*{0}**{1}", new object[] {RefProviderUPIN, RefProviderSpecialty});
			return x12out;
		}
		protected string X12provider()
		{
			string x12out;
			x12out  = FormatRecord("NM1*82*1*{0}*{1}*{2}**{3}*{4}", new object[] {ProviderLastName, ProviderFirstName, ProviderMiddleInitial, ProviderSuffix, ProviderAlternateID});
			x12out += FormatRecord("REF*TJ*{0}", new object[] {ProviderTaxID});
			x12out += FormatRecord("REF*1C*{0}", new object[] {ProviderMedicareID});
			x12out += FormatRecord("REF*N5*{0}", new object[] {ProviderNetworkAlternateID});
			x12out += FormatRecord("REF*4L*{0}", new object[] {ProviderAltLocationID});
			x12out += FormatRecord("REF*ZZ*{0}", new object[] {ProviderAltLocationID});
			x12out += FormatRecord("N3*{0}*{1}", new object[] {ProviderAddress1, ProviderAddress2});
			x12out += FormatRecord("N3*{0}", new object[] {ProviderAddress3});
			x12out += FormatRecord("N4*{0}*{1}*{2}**94*{3}", new object[] {ProviderCity, ProviderState, ProviderZip, ProviderAltLocationID});
			x12out += FormatRecord("PER*1F*TE*{0}", new object[] {ProviderPhone});
			x12out += FormatRecord("PRV*PE*1G*{0}**{1}", new object[] {ProviderUPIN, ProviderSpecialty});
			return x12out;
		}
		protected string X12pcp()
		{
			string x12out;
			x12out  = FormatRecord("NM1*P3*1*{0}*{1}*{2}**{3}*{4}", new object[] {PCPLastName, PCPFirstName, PCPMiddleInitial, PCPSuffix, PCPAlternateID});
			x12out += FormatRecord("REF*TJ*{0}", new object[] {PCPTaxID});
			x12out += FormatRecord("REF*1C*{0}", new object[] {PCPMedicareID});
			x12out += FormatRecord("REF*N5*{0}", new object[] {PCPNetworkAlternateID});
			x12out += FormatRecord("REF*4L*{0}", new object[] {PCPAltLocationID});
			x12out += FormatRecord("REF*ZZ*{0}", new object[] {PCPAltLocationID});
			x12out += FormatRecord("N3*{0}*{1}", new object[] {PCPAddress1, PCPAddress2});
			x12out += FormatRecord("N3*{0}", new object[] {PCPAddress3});
			x12out += FormatRecord("N4*{0}*{1}*{2}**94*{3}", new object[] {PCPCity, PCPState, PCPZip, PCPAltLocationID});
			x12out += FormatRecord("PER*1F*TE*{0}", new object[] {PCPPhone});
			x12out += FormatRecord("PRV*PC*1G*{0}**{1}", new object[] {PCPupin, PCPspecialty});
			return x12out;
		}
		protected string X12patient()
		{
			string x12out;
			x12out  = FormatRecord("NM1*QC*{0}*{1}*{2}***{3}", new object[] {PatientLastName, PatientFirstName, PatientMiddleInitial, PatientAlternateID});
			x12out += FormatRecord("REF*EJ*{0}",     new object[] {SubscriberID});
			x12out += FormatRecord("REF*1W*{0}",     new object[] {PatientAlternateID});
			x12out += FormatRecord("REF*14*{0}",     new object[] {PatientAltMORGID});
			x12out += FormatRecord("REF*N8*{0}",     new object[] {PatientAltORGID});
			x12out += FormatRecord("REF*AV*{0}",     new object[] {PatientAltSORGID});
			x12out += FormatRecord("N3*{0}*{1}",     new object[] {PatientAddress1, PatientAddress2});
			x12out += FormatRecord("N3*{0}",         new object[] {PatientAddress3});
			x12out += FormatRecord("N4*{0}*{1}*{2}", new object[] {PatientCity, PatientState, PatientZip});
			x12out += FormatRecord("DMG*D8*{0}*{1}", new object[] {PatientDOB, PatientGender});
			x12out += FormatRecord("REF*F5*{0}",     new object[] {PatientMedicareID});
			x12out += FormatRecord("REF*NQ*{0}",     new object[] {PatientMedicaidID});
			x12out += FormatRecord("REF*1L*{0}",     new object[] {PatientAltGroupID});
			x12out += FormatRecord("REF*18*{0}",     new object[] {PatientAltPlanID});
			x12out += FormatRecord("REF*SY*{0}",     new object[] {PatientSSN});
			x12out += FormatRecord("INS*{0}",        new object[] {PatientAlternateID == SubscriberAlternateID} );
			return x12out;
		}
		protected string X12subscriber()
		{
			string x12out;
			x12out  = FormatRecord("NM1*IL*{0}*{1}*{2}***{3}", new object[] {SubscriberLastName, SubscriberFirstName, SubscriberMiddleInitial, SubscriberAlternateID});
			x12out += FormatRecord("REF*0F*{0}",     new object[] {SubscriberID});
			x12out += FormatRecord("REF*1W*{0}",     new object[] {SubscriberAlternateID});
			x12out += FormatRecord("REF*14*{0}",     new object[] {SubscriberAltMORGID});
			x12out += FormatRecord("REF*N8*{0}",     new object[] {SubscriberAltORGID});
			x12out += FormatRecord("REF*AV*{0}",     new object[] {SubscriberAltSORGID});
			x12out += FormatRecord("N3*{0}*{1}",     new object[] {SubscriberAddress1, SubscriberAddress2});
			x12out += FormatRecord("N3*{0}",         new object[] {SubscriberAddress3});
			x12out += FormatRecord("N4*{0}*{1}*{2}", new object[] {SubscriberCity, SubscriberState, SubscriberZip});
			x12out += FormatRecord("DMG*D8*{0}*{1}", new object[] {SubscriberDOB, SubscriberGender});
			x12out += FormatRecord("REF*F5*{0}",     new object[] {SubscriberMedicareID});
			x12out += FormatRecord("REF*NQ*{0}",     new object[] {SubscriberMedicaidID});
			x12out += FormatRecord("REF*1L*{0}",     new object[] {SubscriberAltGroupID});
			x12out += FormatRecord("REF*18*{0}",     new object[] {SubscriberAltPlanID});
			x12out += FormatRecord("REF*SY*{0}",     new object[] {SubscriberSSN});
			x12out += FormatRecord("INS*{0}",        new object[] {true} );
			return x12out;
		}

		protected string X12facility()
		{
			string x12out = null;
			x12out  = FormatRecord("NM1*2D*2*{0}*****{1}", new object[] {FacilityName, FacilityAlternateID});
			x12out += FormatRecord("REF*TJ*{0}", new object[] {FacilityTaxID});
			x12out += FormatRecord("REF*N5*{0}", new object[] {FacilityAlternateNetworkID});
			x12out += FormatRecord("REF*ZZ*{0}", new object[] {FacilityLocationTaxID});
			x12out += FormatRecord("REF*4L*{0}", new object[] {FacilityAlternateLocationID});
			x12out += FormatRecord("N3*{0}*{1}", new object[] {FacilityAddress1, FacilityAddress2});
			x12out += FormatRecord("N3*{0}", new object[] {FacilityAddress3});
			x12out += FormatRecord("N4*{0}*{1}*{2}**94*{3}", new object[] {FacilityCity, FacilityState, FacilityZip, FacilityAlternateLocationID});
			x12out += FormatRecord("PER*1F**TE*{0}", new object[] {FacilityPhone});
			return x12out;
		}

		protected string X12grouppractice()
		{
			string x12out = null;
			x12out  = FormatRecord("NM1*1T*2*{0}*****{1}", new object[] {GroupPracticeName, GroupPracticeAlternateID});
			x12out += FormatRecord("REF*TJ*{0}", new object[] {GroupPracticeTaxID});
			x12out += FormatRecord("REF*N5*{0}", new object[] {GroupPracticeAlternateNetworkID});
			x12out += FormatRecord("REF*ZZ*{0}", new object[] {GroupPracticeLocationTaxID});
			x12out += FormatRecord("REF*4L*{0}", new object[] {GroupPracticeAlternateLocationID});
			x12out += FormatRecord("N3*{0}*{1}", new object[] {GroupPracticeAddress1, GroupPracticeAddress2});
			x12out += FormatRecord("N3*{0}", new object[] {GroupPracticeAddress3});
			x12out += FormatRecord("N4*{0}*{1}*{2}**94*{3}", new object[] {GroupPracticeCity, GroupPracticeState, GroupPracticeZip, GroupPracticeAlternateLocationID});
			x12out += FormatRecord("PER*1F**TE*{0}", new object[] {GroupPracticePhone});
			return x12out;
		}


	}// end of class

	/// <summary>
	/// Strongly typed collection of ExportAuthorization objects
	/// </summary>
	[ElementType(typeof(ExportAuthorization))]
	public class ExportAuthorizationCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAuthorizationByBatchNumber(int maxRecords, System.Guid batchNumber)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadAuthorizationByBatchNumber", maxRecords, this, false, new object[] { batchNumber });
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ExportAuthorization elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentExportAuthorizationCollection = this;
			else
				elem.ParentExportAuthorizationCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ExportAuthorization elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ExportAuthorization this[int index]
		{
			get
			{
				return (ExportAuthorization)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ExportAuthorization)oldValue, false);
			SetParentOnElem((ExportAuthorization)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}
}
