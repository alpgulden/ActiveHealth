using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Language class that contains app specific messages
	/// </summary>
	[LanguageTable("Messages", "MsgID", "LangID", "Text")]
	public class BaseFocusTypeMessages : Language
	{
		
		public BaseFocusTypeMessages(string langID): base(langID)
		{
			LoadFromTable();
		}
	}
}
