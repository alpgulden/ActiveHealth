using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [InterfaceORGList]
	/// </summary>
	[SPInsert("usp_InsertInterfaceORGList")]
	[SPAutoGen("usp_GetAllInterfaceOrganizationsByJobID","SelectAllByGivenArgs.sptpl","jobID")]
	[TableMapping("InterfaceORGList","interfaceORGListID")]
	public class InterfaceORGList : BaseDataClass
	{
		[NonSerialized]
		private InterfaceORGListCollection parentInterfaceORGListCollection;
		[ColumnMapping("InterfaceORGListID",(int)0)]
		private int interfaceORGListID;
		[ColumnMapping("JobID",StereoType=DataStereoType.FK)]
		private int jobID;
		[ColumnMapping("OrganizationID",StereoType=DataStereoType.FK)]
		private int organizationID;
		[ColumnMapping("OrganizationLevelID",StereoType=DataStereoType.FK)]
		private int organizationLevelID;
	
		public InterfaceORGList()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public InterfaceORGList(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int InterfaceORGListID
		{
			get { return this.interfaceORGListID; }
			set { this.interfaceORGListID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int JobID
		{
			get { return this.jobID; }
			set { this.jobID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OrganizationID
		{
			get { return this.organizationID; }
			set { this.organizationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OrganizationLevelID
		{
			get { return this.organizationLevelID; }
			set { this.organizationLevelID = value; }
		}

		/// <summary>
		/// Parent InterfaceORGListCollection that contains this element
		/// </summary>
		public InterfaceORGListCollection ParentInterfaceORGListCollection
		{
			get
			{
				return this.parentInterfaceORGListCollection;
			}
			set
			{
				this.parentInterfaceORGListCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of InterfaceORGList objects
	/// </summary>
	[ElementType(typeof(InterfaceORGList))]
	public class InterfaceORGListCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(InterfaceORGList elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentInterfaceORGListCollection = this;
			else
				elem.ParentInterfaceORGListCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (InterfaceORGList elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public InterfaceORGList this[int index]
		{
			get
			{
				return (InterfaceORGList)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((InterfaceORGList)oldValue, false);
			SetParentOnElem((InterfaceORGList)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(InterfaceORGList elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((InterfaceORGList)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllInterfaceOrganizationsByJobID(int maxRecords, int jobID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllInterfaceOrganizationsByJobID", maxRecords, this, false, new object[] { jobID });
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
	}
}
