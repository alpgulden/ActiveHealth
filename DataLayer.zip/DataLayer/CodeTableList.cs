using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CodeTableList]
	/// </summary>
	[TableMapping("CodeTableList","codeTableListID")]
	public class CodeTableList : BaseDataClass
	{
		[NonSerialized]
		private CodeTableListCollection parentCodeTableListCollection;
		[ColumnMapping("CodeTableListID",(int)0)]
		private int codeTableListID;
		[ColumnMapping("CodeTableName")]
		private string codeTableName;
	
		public CodeTableList()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CodeTableListID
		{
			get { return this.codeTableListID; }
			set { this.codeTableListID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		public string CodeTableName
		{
			get { return this.codeTableName; }
			set { this.codeTableName = value; }
		}

		/// <summary>
		/// Parent CodeTableListCollection that contains this element
		/// </summary>
		public CodeTableListCollection ParentCodeTableListCollection
		{
			get
			{
				return this.parentCodeTableListCollection;
			}
			set
			{
				this.parentCodeTableListCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of CodeTableList objects
	/// </summary>
	[ElementType(typeof(CodeTableList))]
	public class CodeTableListCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CodeTableList elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCodeTableListCollection = this;
			else
				elem.ParentCodeTableListCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CodeTableList elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CodeTableList this[int index]
		{
			get
			{
				return (CodeTableList)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CodeTableList)oldValue, false);
			SetParentOnElem((CodeTableList)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int LoadAll()
		{
			this.Clear();
			return this.SqlData.SPExecReadCol("usp_GetCodeTableList", -1, this, false);
		}
	}
}
