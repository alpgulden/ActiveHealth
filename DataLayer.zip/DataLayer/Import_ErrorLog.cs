using System;
using System.IO;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Import_ErrorLog]
	/// </summary>
	[SPAutoGen("usp_SelectAllErrorLogsByBatchNumber","SelectAllByGivenArgs.sptpl","batchNumber")]
	[TableMapping("Import_ErrorLog", "ImportErrorLogID")]
	public class Import_ErrorLog : BaseDataClass
	{
		[NonSerialized]
		private Import_ErrorLogCollection parentImport_ErrorLogCollection;
		[ColumnMapping("ImportErrorLogID",StereoType=DataStereoType.FK)]
		private int importErrorLogID;
		[ColumnMapping("BatchNumber")]
		private Guid batchNumber;
		[ColumnMapping("Message")]
		private string message;
		[ColumnMapping("LineNumber",StereoType=DataStereoType.FK)]
		private int lineNumber;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
	
		public Import_ErrorLog()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ImportErrorLogID
		{
			get { return this.importErrorLogID; }
			set { this.importErrorLogID = value; }
		}

		public System.Guid BatchNumber
		{
			get { return this.batchNumber; }
			set { this.batchNumber = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=500)]
		public string Message
		{
			get { return this.message; }
			set { this.message = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LineNumber
		{
			get { return this.lineNumber; }
			set { this.lineNumber = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		/// <summary>
		/// Parent Import_ErrorLogCollection that contains this element
		/// </summary>
		public Import_ErrorLogCollection ParentImport_ErrorLogCollection
		{
			get
			{
				return this.parentImport_ErrorLogCollection;
			}
			set
			{
				this.parentImport_ErrorLogCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of Import_ErrorLog objects
	/// </summary>
	[ElementType(typeof(Import_ErrorLog))]
	public class Import_ErrorLogCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Import_ErrorLog elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentImport_ErrorLogCollection = this;
			else
				elem.ParentImport_ErrorLogCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Import_ErrorLog elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Import_ErrorLog this[int index]
		{
			get
			{
				return (Import_ErrorLog)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Import_ErrorLog)oldValue, false);
			SetParentOnElem((Import_ErrorLog)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SelectAllErrorLogsByBatchNumber(int maxRecords, System.Guid batchNumber)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllErrorLogsByBatchNumber", maxRecords, this, false, new object[] { batchNumber });
		}

		/// <summary>
		/// WriteErrorLog
		/// This method will read the Import_ErrorLog table into the collection
		/// and write out the error statements to the specified file. 
		/// </summary>
		/// <param name="filename">file (on server) to write to</param>
		/// <param name="batchNumber">error log entries to process</param>
		/// <param name="errors">any additional errors not logged on DB</param>
		/// <returns></returns>
		
		public int WriteErrorLog(string filename, System.Guid batchNumber)
		{
			return WriteErrorLog(filename, batchNumber, null);
		}
		public int WriteErrorLog(string filename, System.Guid batchNumber, Import_ErrorLogCollection errors)
		{
			const int number_records = 100;
			const string errFormat = "Line#{0}, {1}";
			StreamWriter sw = new StreamWriter(filename, true, System.Text.Encoding.ASCII); // append
			if (null == sw) return -1;


			// write out any errors not logged to db
			if (errors != null)
			{
				for (int j = 0; j < errors.Count; j++)
				{
					string msg = String.Format(errFormat, errors[j].LineNumber, errors[j].Message);
					sw.WriteLine(msg);
				}
				sw.Flush();
			}

			System.Data.SqlClient.SqlDataReader rdr = this.SqlData.SPExecRead("usp_SelectAllErrorLogsByBatchNumber", new object[] { batchNumber });
 			try
			{
				while (this.Read(rdr, number_records, false) != 0)
				{
					// collection has 10 elements to process
					for (int i = 0; i < this.Count; i++)
					{
						string msg = String.Format(errFormat, this[i].LineNumber, this[i].Message);
						sw.WriteLine(msg);
					}
					sw.Flush();
					// get next set
					this.Clear();
				}
			}
			catch
			{
			}
			finally
			{
				sw.Close();
				this.SqlData.CloseConnection();
			}

			return 0;
		}// end of method ReadandProcess()
	}
}
