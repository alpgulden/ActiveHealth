using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LengthOfStayRegions]
	/// </summary>
	[SPAutoGen("usp_GetAllLengthOfStayRegions","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetLengthOfStayRegionsByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertLengthOfStayRegion")]
	[SPUpdate("usp_UpdateLengthOfStayRegion")]
	[SPDelete("usp_DeleteLengthOfStayRegion")]
	[SPLoad("usp_LoadLengthOfStayRegion")]
	[TableMapping("LengthOfStayRegions","hciaRegionid")]
	public class LengthOfStayRegion : BaseCode
	{
		[ColumnMapping("HCIA_RegionId",(int)0)]
		private int hciaRegionid;
		[ColumnMapping("HCIA_Region")]
		private string hciaRegion;
		[ColumnMapping("Note")]
		private string note;
	
		public LengthOfStayRegion()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int HciaRegionid
		{
			get { return this.hciaRegionid; }
			set { this.hciaRegionid = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string HciaRegion
		{
			get { return this.hciaRegion; }
			set { this.hciaRegion = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}
	}
}
