using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [DuplicateCheckCriteria]
	/// </summary>

	[TableMapping("DuplicateCheckCriteria","duplicateCheckCriteriaID")]
	public class BaseDuplicateCheckCriteria : BaseDataClass
	{
		[ColumnMapping("DuplicateCheckCriteriaID",StereoType=DataStereoType.FK)]
		protected int duplicateCheckCriteriaID;
		[ColumnMapping("ExactMatch")]
		protected bool exactMatch;
		[ColumnMapping("Days",(int)0)]
		protected int days;
		[ColumnMapping("ServiceType")]
		protected bool serviceType;
		[ColumnMapping("TreatingProvFacGroup")]
		protected bool treatingProvFacGroup;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
	
		public BaseDuplicateCheckCriteria()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DuplicateCheckCriteriaID
		{
			get { return this.duplicateCheckCriteriaID; }
			set { this.duplicateCheckCriteriaID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool ExactMatch
		{
			get { return this.exactMatch; }
			set { this.exactMatch = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Days
		{
			get { return this.days; }
			set { this.days = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool ServiceType
		{
			get { return this.serviceType; }
			set { this.serviceType = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool TreatingProvFacGroup
		{
			get { return this.treatingProvFacGroup; }
			set { this.treatingProvFacGroup = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int duplicateCheckCriteriaID)
		{
			return base.Load(duplicateCheckCriteriaID);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			if(!this.exactMatch && this.days==0)
				this.Days=0;
			base.InternalSave();
			// Save the child collections here.
		}

	}

	

	[SPUpdate("usp_UpdateEventDuplicateCheckCriteria")]
	[SPLoad("usp_LoadEventDuplicateCheckCriteria")]
	[TableMapping("DuplicateCheckCriteria","duplicateCheckCriteriaID")]
	public class EventDuplicateCheckCriteria: BaseDuplicateCheckCriteria
	{
		[ColumnMapping("Type",StereoType=DataStereoType.FK)]
		private int type;

		[FieldDescription("1 - Event / 2 - Referral")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int Type
		{
			get { return 1; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int aduplicateCheckCriteriaID)
		{
			return base.Load(aduplicateCheckCriteriaID);
			// set type = 1 for Event.
			this.type = 1;
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadCriteria()
		{
			return SqlData.SPExecReadObj("usp_GetEventDuplicateCheckCriteria", this, false);
		}
	}

	
	[SPUpdate("usp_UpdateReferralDuplicateCheckCriteria")]
	[SPLoad("usp_LoadReferralDuplicateCheckCriteria")]
	[SPInsert("usp_InsertReferralDuplicateCheckCriteria")]
	[TableMapping("DuplicateCheckCriteria","duplicateCheckCriteriaID")]
	public class ReferralDuplicateCheckCriteria: BaseDuplicateCheckCriteria
	{
		[ColumnMapping("Type",StereoType=DataStereoType.FK)]
		private int type;
		[ColumnMapping("ReferringProvider")]
		private bool referringProvider;

		[ControlType(EnumControlTypes.CheckBox)]
		public bool ReferringProvider
		{
			get { return this.referringProvider; }
			set { this.referringProvider = value; }
		}

		

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int duplicateCheckCriteriaID)
		{
			return base.Load(duplicateCheckCriteriaID);
			this.type = 2;
		}

		[FieldDescription("1 - Event / 2 - Referral")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int Type
		{
			get { return 2; }
			
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadCriteria()
		{
			return SqlData.SPExecReadObj("usp_GetReferralDuplicateCheckCriteria", this, false);
		}
	}
}
