using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EDIRequestorDetail]
	/// </summary>
	[SPAutoGen("usp_SelectAllEDIRequesterDetailsByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetActiveEDIRequestorDetailByID","SelectAllByGivenArgs.sptpl","iDQualifierID, iDCode, active")]
	[SPLoad("usp_LoadEDIRequestorDetail")]
	[SPInsert("usp_InsertEDIRequestorDetail")]
	[SPUpdate("usp_UpdateEDIRequestorDetail")]
	[TableMapping("EDIRequestorDetail","eDIRequestorDetailID")]
	public class EDIRequestorDetail : BaseDataClass
	{
		[NonSerialized]
		private EDIRequestorDetailCollection parentEDIRequestorDetailCollection;
		[ColumnMapping("EDIRequestorDetailID",(int)0)]
		private int eDIRequestorDetailID;
		[ColumnMapping("IDQualifierID",StereoType=DataStereoType.FK)]
		private int iDQualifierID;
		[ColumnMapping("IDCode")]
		private string iDCode;
		[ColumnMapping("RequesterName")]
		private string requesterName;
		[ColumnMapping("OutboxPath")]
		private string outboxPath;
		[ColumnMapping("MAProviderID",StereoType=DataStereoType.FK)]
		private int mAProviderID;
		[ColumnMapping("ContactName")]
		private string contactName;
		[ColumnMapping("ContactType1ID",StereoType=DataStereoType.FK)]
		private int contactType1ID;
		[ColumnMapping("ContactPhone_1")]
		private string contactphone1;
		[ColumnMapping("ContactType2ID",StereoType=DataStereoType.FK)]
		private int contactType2ID;
		[ColumnMapping("ContactPhone_2")]
		private string contactphone2;
		[ColumnMapping("ContactType3ID",StereoType=DataStereoType.FK)]
		private int contactType3ID;
		[ColumnMapping("ContactPhone_3")]
		private string contactphone3;
		[ColumnMapping("Active")]
		private bool active;
	
		public EDIRequestorDetail()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EDIRequestorDetailID
		{
			get { return this.eDIRequestorDetailID; }
			set { this.eDIRequestorDetailID = value; }
		}

		//		[FieldDescription("specifies the type of value being used as an identifier")]
		[FieldValuesMember("LookupOf_UMOIdentificationQualifierID", "UMOIdentificationQualifierID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int IDQualifierID
		{
			get { return this.iDQualifierID; }
			set { this.iDQualifierID = value; }
		}

		//		[FieldDescription("value entered by user, i.e. UPIN or FederalTaxID")]
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=80)]
		public string IDCode
		{
			get { return this.iDCode; }
			set { this.iDCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string RequesterName
		{
			get { return this.requesterName; }
			set { this.requesterName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=200)]
		public string OutboxPath
		{
			get { return this.outboxPath; }
			set { this.outboxPath = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int MAProviderID
		{
			get { return this.mAProviderID; }
			set { this.mAProviderID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=40)]
		public string ContactName
		{
			get { return this.contactName; }
			set { this.contactName = value; }
		}

		[FieldValuesMember("LookupOf_UMOContactNumberQualifierID", "UMOContactNumberQualifierID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int ContactType1ID
		{
			get { return this.contactType1ID; }
			set { this.contactType1ID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Contactphone1
		{
			get { return this.contactphone1; }
			set { this.contactphone1 = value; }
		}

		[FieldValuesMember("LookupOf_UMOContactNumberQualifierID", "UMOContactNumberQualifierID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int ContactType2ID
		{
			get { return this.contactType2ID; }
			set { this.contactType2ID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Contactphone2
		{
			get { return this.contactphone2; }
			set { this.contactphone2 = value; }
		}

		[FieldValuesMember("LookupOf_UMOContactNumberQualifierID", "UMOContactNumberQualifierID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int ContactType3ID
		{
			get { return this.contactType3ID; }
			set { this.contactType3ID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Contactphone3
		{
			get { return this.contactphone3; }
			set { this.contactphone3 = value; }
		}

		/// <summary>
		/// Parent EDIRequestorDetailCollection that contains this element
		/// </summary>
		public EDIRequestorDetailCollection ParentEDIRequestorDetailCollection
		{
			get
			{
				return this.parentEDIRequestorDetailCollection;
			}
			set
			{
				this.parentEDIRequestorDetailCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		protected UMOContactNumberQualifierCollection umocnqc = null;
		public UMOContactNumberQualifierCollection LookupOf_UMOContactNumberQualifierID
		{
			get
			{
				if (null == umocnqc)
				{
					umocnqc = new UMOContactNumberQualifierCollection();
					umocnqc.SelectAllUMOContactNumberQualifiersByActive(-1, true);
				}
				return umocnqc;
			}
		}

		protected UMOIdentificationQualifierCollection umoc = null;
		public UMOIdentificationQualifierCollection LookupOf_UMOIdentificationQualifierID
		{
			get 
			{
				if (null == umoc)
				{
					umoc = new UMOIdentificationQualifierCollection();
					umoc.SelectAllUMOIdentificationQualifiersByActive(-1, true);
				}
				return umoc;
			}
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eDIRequestorDetailID)
		{
			return base.Load(eDIRequestorDetailID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadActiveEDIRequestorDetailByID(int iDQualifierID, string iDCode, bool active)
		{
			return SqlData.SPExecReadObj("usp_GetActiveEDIRequestorDetailByID", this, false, new object[] { iDQualifierID, iDCode, active });
		}
	}

	/// <summary>
	/// Strongly typed collection of EDIRequestorDetail objects
	/// </summary>
	[ElementType(typeof(EDIRequestorDetail))]
	public class EDIRequestorDetailCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_EDIRequestorDetailID;
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SelectAllEDIRequesterDetailsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllEDIRequesterDetailsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Hashtable based index on eDIRequestorDetailID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_EDIRequestorDetailID
		{
			get
			{
				if (this.indexBy_EDIRequestorDetailID == null)
					this.indexBy_EDIRequestorDetailID = new CollectionIndexer(this, new string[] { "eDIRequestorDetailID" }, true);
				return this.indexBy_EDIRequestorDetailID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on eDIRequestorDetailID fields returns the object.  Uses the IndexBy_EDIRequestorDetailID indexer.
		/// </summary>
		public EDIRequestorDetail FindBy(int eDIRequestorDetailID)
		{
			return (EDIRequestorDetail)this.IndexBy_EDIRequestorDetailID.GetObject(eDIRequestorDetailID);
		}
	}
}
