using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Derive all code-table based collections from this.
	/// Collections derived from this class will display only Active codes in the drop down combos.
	/// </summary>
	public class BaseTypeCollection: BaseDataCollection, ICollectionElementFilter
	{
		public BaseTypeCollection()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private bool displayOnlyActive = true;

		#region ICollectionElementFilter Members

		public virtual bool FilterElement(int index)
		{
			if (!displayOnlyActive)		// if filter is not set, just display all.
				return true;

			BaseLookup lookup = this.GetAt(index) as BaseLookup;
			if (lookup == null)
				return true;

			return lookup.Active;		// display only actives
		}

		#endregion

		[ControlType(EnumControlTypes.CheckBox)]
		public bool DisplayOnlyActive
		{
			get { return this.displayOnlyActive; }
			set { this.displayOnlyActive = value; }
		}

		public virtual void LoadAll() { }

		public virtual void SynchronizeCollection(BaseTypeCollection col) { }

		public virtual void SearchCodeTypes(string code, string description, bool active) { }

		public virtual bool FindBaseCodeType(int code1,int code2) {return false; }

		public virtual void Save(){}

	}
}
