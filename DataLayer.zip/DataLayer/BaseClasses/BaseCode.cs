using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// This is the base class for all code classes. 
	/// </summary>
	public class BaseLookup : BaseData
	{
		[ColumnMapping("Description")]
		protected string description;
		[ColumnMapping("Active")]
		protected bool active=true;
		[ColumnMapping("ReadOnly")]
		protected bool readOnly;		
		
		//protected BaseTypeCollection parentBaseTypeCollection;

		public bool ReadOnly
		{
			get { return this.readOnly; }
		}

		/// <summary>
		/// Generic property to access pk of the code.
		/// </summary>
		public int ID
		{
			get
			{
				return (int)this.PK[0];
			}
			set
			{
				this.PK[0] = value;
			}
		}

	
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		public void New()
		{
			base.NewRecord ();
		}

		public void Delete(int ID)
		{
			base.Delete(ID);
		}

		public new void Save()
		{			
			base.Save();
		}

		public virtual BaseDataCollectionClass BracketCodeTableChilderen
		{get{ return null; } set{}}

		public virtual void LoadBracketCodeTableChilderen(bool forceReload)
		{}

		public virtual void SaveBracketCodeTableChilderen()
		{}

		public virtual void SynchronizeBracketCodeTableChilderen()
		{}

		public virtual BaseTypeCollection ParentBaseTypeCollection
		{get{return null;}	set{}}

		/// <summary>
		/// The full text to be displayed in the combo.
		/// </summary>
		public virtual string ComboDisplayText
		{
			get { return this.description; }
		}

	}

	public class BaseLookupWithCode: BaseLookup
	{
		[ColumnMapping("Code")]
		protected string code;

		[ControlType(EnumControlTypes.TextBox,ClientValidators=EnumClientValidators.Required,ClientFormatter="FormatAllUpperCase(this.value)",MaxLength=4)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		/// <summary>
		/// Refers to functional code status values.
		/// Valid only for the codes that have this column in table.
		/// </summary>
		[FieldValuesMember("LookupOf_CodeStatus", "Code", "Description")]
		public string CodeStatus
		{
			get
			{
				return (string)this.Get("codeStatus", false);
			}
			set
			{
				this.Set("codeStatus", value, false);
			}
		}

		public FunctionalStatusCollection LookupOf_CodeStatus
		{
			get
			{
				return FunctionalStatusCollection.AllFunctionalStatusCodes; // Acquire a shared instance from the static member of collection
			}
		}

		public bool IsStatusApplicable
		{
			get
			{
				return this.CodeStatus != null;
			}
		}

		public bool IsStatusNotApplicable
		{
			get
			{
				return this.CodeStatus == null;
			}
		}

		public bool IsStatusOpen
		{
			get
			{
				return this.CodeStatus == FunctionalStatus.OPEN;
			}
		}

		public bool IsStatusClosed
		{
			get
			{
				return this.CodeStatus == FunctionalStatus.CLOS;
			}
		}

		public bool IsStatusTerminated
		{
			get
			{
				return this.CodeStatus == FunctionalStatus.TERM;
			}
		}

	}

	public abstract class BaseLookupWithSubCode: BaseLookupWithNote
	{
		public abstract int SubCodeID { get; set; }		
	}

	public abstract class BaseLookupWithTwoSubCode: BaseLookupWithSubCode
	{
		public abstract int SubCodeExtID { get; set; }
	}	

	public abstract class BaseLookupWithSubCodeSTR: BaseLookupWithNote
	{
		public abstract string SubCodeStr { get; set; }
	}

	public abstract class BaseLookupWithSubCodeTwoSTR: BaseLookupWithSubCodeSTR
	{
		public abstract string SubCodeExtStr { get; set; }
	}

	public abstract class BaseLookupWithExtCode: BaseLookupWithNote
	{
		public abstract string ExtCode { get; set; }
	}

	public abstract class BaseLookupWithTwoExtCode: BaseLookupWithExtCode
	{
		public abstract string ExtExtCode { get; set; }
	}

	public abstract class BaseLookupWithNote: BaseLookupStandard
	{
		public abstract string NoteGeneric { get; set; }
	}
	
	public abstract class BaseLookupWithNoteWithOutCode: BaseLookupStdWithOutCode
	{
		public abstract string NoteGeneric { get; set; }
		public abstract string Text { get; set; }
	}

	public abstract class BaseCodeBracket : BaseData
	{
		public abstract int CodeTypeID { get; set; }
		public abstract int LinkedCodeTypeID { get; set; }

		public virtual string Code1{get{ return null; } set{}}
		public virtual string Code2{get{ return null; } set{}}
		public virtual string Description1{get{ return null; } set{}}
		public virtual string Description2{get{ return null; } set{}}
	}

	public class BaseLookupStdWithOutCode : BaseLookup
	{
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}		
	}

	public class BaseLookupStandard : BaseLookupWithCode
	{
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}		
	}

	/// <summary>
	/// Many classes derive from BaseCode.  This ensures, they won't break.
	/// Remove these after changing all
	/// </summary>
	public class BaseCode: BaseLookupStandard
	{
		
	}

	public class BaseCodeWithNote: BaseCode
	{
		public new void Delete(int ID)
		{
			base.Delete(ID);
		}
	}

//	public class BaseLookupCollection : BaseDataCollection
//	{
//	}

	[ElementType(typeof(BaseLookupWithNote))]
	public class BaseLookupWithNoteCollection : BaseDataCollection
	{
		
		[NonSerialized]
		protected CollectionIndexer indexBy_ID;

		/// <summary>
		/// Hashtable based index on ID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ID
		{
			get
			{
				if (this.indexBy_ID == null)
					this.indexBy_ID = new CollectionIndexer(this, new string[] { "ID" }, true);
				return this.indexBy_ID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on ID fields returns the collection index.  Uses the IndexBy_ID indexer.
		/// </summary>
		public int IndexOfID(int ID)
		{
			return this.IndexBy_ID.IndexOf(ID);
		}

		/// <summary>
		/// Hashtable based search on ID fields returns the object.  Uses the IndexBy_ID indexer.
		/// </summary>
		public BaseLookupWithNote FindByID(int ID)
		{
			return (BaseLookupWithNote)this.IndexBy_ID.GetObject(ID);
		}

		/// <summary>
		/// Looks up by ID and returns Code value.  Uses the IndexBy_ID indexer.
		/// </summary>
		public string Lookup_CodeByID(int ID)
		{
			return this.IndexBy_ID.LookupStringMember("Code", ID);
		}
	}

//	[ElementType(typeof(BaseLookupWithSubCode))]
//	public class BaseLookupWithSubCodeCollection : BaseLookupWithNoteCollection
//	{
//
//		/// <summary>
//		/// Hashtable based search on ID fields returns the object.  Uses the IndexBy_ID indexer.
//		/// </summary>
//		public BaseLookupWithSubCode FindByID(int ID)
//		{
//			return (BaseLookupWithSubCode)this.IndexBy_ID.GetObject(ID);
//		}
//		
//	}

}
