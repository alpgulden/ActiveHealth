using System;
using System.Diagnostics;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	

	/// <summary>
	/// Extends the NetsoftUSA.BaseDataClass features and provides
	/// a centralized management point for all of the application data classes.
	/// </summary>
	public class BaseData : BaseDataClass
	{
		public const string CreateTimeMember = "createTime";
		public const string CreatedByMember = "createdBy";
		public const string ModifyTimeMember = "modifyTime";
		public const string ModifiedByMember = "modifiedBy";
		public const string InactivateTimeMember = "inactivateTime";
		public const string InactivatedByMember = "inactivatedBy";
		public const string TerminateTimeMember = "terminateTime";
		public const string TerminatedByMember = "terminatedBy";
		public const string AddTimeMember = "addTime";
		public const string AddedByMember = "addedBy";
		public const string ActiveMember = "Active";
		public const string StatusChangedByMember = "statusChangedBy";
		public const string StatusChangeTimeMember = "statusChangeTime";

		// only for obtimization
		protected bool saveChildrenOnly = false;

		protected AutoActivityManager autoActivityManager;		// last used autoactivity context

		public BaseData()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Returns the last used autoactivity context.
		/// All classes are responsible for creating the auto activity context
		/// and executing them.
		/// </summary>
		public ActiveAdvice.DataLayer.AutoActivityManager AutoActivityManager
		{
			get { return this.autoActivityManager; }
			set { this.autoActivityManager = value; }
		}

		protected override void NewRecord()
		{
			base.NewRecord ();
			this.autoActivityManager = null;
		}

		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			base.FillFromReader (sourceRdr, ignoreAssignmentError);
			this.autoActivityManager = null;
		}


		protected override void InternalUpdate()
		{
			//this.SqlData.Principal   // get from principal and set user info
			this.Set(ModifyTimeMember, DateTime.Now, false);
			//#if DEBUG

			this.Set(ModifiedByMember, AASecurityHelper.GetUserId, false);
			//#endif

			base.InternalUpdate ();
		}

		protected override object InternalInsert()
		{
			this.Set(CreateTimeMember, DateTime.Now, false);
			//#if DEBUG
			this.Set(CreatedByMember, AASecurityHelper.GetUserId, false);
			//#endif
			
			return base.InternalInsert ();
		}

		/// <summary>
		/// Call this whenever you want the InactivateTime and InactivatedBy fields to be set from the current user context
		/// </summary>
		protected void SetInactivatingUser()
		{
			this.Set(InactivateTimeMember, DateTime.Now, false);
			//#if DEBUG
			this.Set(InactivatedByMember, AASecurityHelper.GetUserId, false);
			//#endif
			// will set the inactivating user from the current user context
			Debug.WriteLine("Inactivating user set for " + this.GetType() + " " + this.PKString);
		}

		/// <summary>
		/// Call this whenever you want the TerminateTime and TerminatedBy fields to be set from the current user context
		/// </summary>
		protected void SetTerminatingUser()
		{
			this.Set(TerminateTimeMember, DateTime.Now, false);
			//#if DEBUG
			this.Set(TerminatedByMember, AASecurityHelper.GetUserId, false);
			//#endif
			// will set the inactivating user from the current user context
			Debug.WriteLine("Terminating user set for " + this.GetType() + " " + this.PKString);
		}

		/// <summary>
		/// Call this whenever you want the StatusChangedBy and StatusChangedBy fields to be set from the current user context
		/// </summary>
		protected void SetStatusChangingUser()
		{
			// will set the inactivating user from the current user context
			Debug.WriteLine("Status changing user set for " + this.GetType() + " " + this.PKString);
			
			this.Set(StatusChangeTimeMember, DateTime.Now, false);
			this.Set(StatusChangedByMember, AASecurityHelper.GetUserId, false);
		}

		/*/// <summary>
		/// Encrypt SSN number.
		/// For simplicity, we just change to byte[] for now.
		/// </summary>
		/// <param name="SSN"></param>
		/// <returns></returns>
		protected byte[] EncryptSSN(string SSN)
		{
			if (SSN == null)
				return null;
			byte[] buf = new byte[SSN.Length + 1];
			buf[0] = (byte)SSN.Length;		// save the length in the first byte
			for (int i = 0; i < SSN.Length; i++)
			{
				buf[i + 1] = (byte)SSN[i];
			}
			return buf;
		}

		/// <summary>
		/// Decrypt given encrypted SSN.
		/// For simplicity, we just return it as a string.
		/// </summary>
		/// <param name="buf"></param>
		/// <returns></returns>
		protected string DecryptSSN(byte[] buf)
		{
			if (buf == null)
				return null;
			string s = null;
			int length = (int)buf[0];
			for (int i = 1; i <= length; i++)
			{
				s += (char)buf[i];
			}
			return s;
		}*/

		//     [-----
		//     [ -- ]
		// x1    x2   x3
		//
		public static bool IsActiveBetween(DateTime startDate, DateTime endDate, DateTime now)
		{
			if (endDate == DateTime.MinValue)
				return now >= startDate;

			return now >= startDate && now <= endDate;
		}

		// General validator props
		[GenericScript("Vld_TerminationDate", "@TerminationDate@ != null && @TerminationDate@ >= @EffectiveDate@;")]
		protected string Vld_TerminationDate
		{
			get
			{
				return "@ERRTERMDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
				/*DateTime terminationDate = (DateTime)this.Get("terminationDate");
				DateTime effectiveDate = (DateTime)this.Get("effectiveDate");
				if (terminationDate != DateTime.MinValue && !(terminationDate >= effectiveDate))
					throw new ValidationException("TerminationDate", Vld_TerminationDate);  // throw validation exception if failed (don't set the member) 
					*/

				// Can't validate on the server, because the depended 2 members are not filled yet.
			}
		}

		// General validator props
		[GenericScript("Vld_EndDate", "@EndDate@ != null && @EndDate@ >= @StartDate@;")]
		protected string Vld_EndDate
		{
			get
			{
				return "@ERRENDDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
				/*DateTime terminationDate = (DateTime)this.Get("terminationDate");
				DateTime effectiveDate = (DateTime)this.Get("effectiveDate");
				if (terminationDate != DateTime.MinValue && !(terminationDate >= effectiveDate))
					throw new ValidationException("TerminationDate", Vld_TerminationDate);  // throw validation exception if failed (don't set the member) 
					*/

				// Can't validate on the server, because the depended 2 members are not filled yet.
			}
		}

		[GenericScript("Vld_DXPXCodes", "@CodeStart@ == null || @CodeEnd@ == null || @CodeEnd@ >= @CodeStart@;")]
		protected string Vld_DXPXCodes
		{
			get
			{
				return "@CODEENDGTCODESTART@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
				// Can't validate on the server, because the depended 2 members are not filled yet.
			}
		}


		// General valuesof functions
		public string[,] ValuesOf_DiagOrProc
		{
			get
			{
				return new string[,] { { "D", "Diagnostics" }, { "P", "Procedure" }  }; // return possible field values
			}
		}

		public string[,] ValuesOf_Gender
		{
			get
			{
				return new string[,] { { "M", "Male" }, { "F", "Female" }  }; // return possible field values
			}
		}

		public string[,] ValuesOf_CodeType
		{
			get
			{
				string diagProc = (string)this.Get("DiagOrProc");
				return BaseDxPx.GetValuesOfCodeType(diagProc);
			}
		}

		public object[,] ValuesOf_ActiveWithAll
		{
			get
			{
				return new object[,] { { (int)-1, "All"}, { (int)1, "Active"},  { (int)0, "Inactive"}};
			}
		}

		public object[,] ValuesOf_ActiveWithTerminatedAndAll
		{
			get
			{
				return new object[,] { { (int)-1, "All"}, { (int)1, "Active"},  { (int)0, "Terminated"}};
			}
		}

		public object[,] ValuesOf_DoNowLater
		{
			get 
			{
				return new object[,] { {(int)0, " "}, { (int)1, "Do Now"}, {(int)2, "Do Later"}};
			}
		}

		public string[] ValuesOf_HighOp
		{
			get
			{
				return new string[] {"<", "<=", "="};
			}
		}

		public string[] ValuesOf_LowOp
		{
			get
			{
				return new string[] {">", ">=", "="};
			}
		}

		public int[] ValuesOf_CCAnswer
		{
			get 
			{
				int[] values = new int[99];
				for (int index = 0; index < 99; index++)
					values[index] = index + 1;
				return values;
			}
		}

		public object[,] ValuesOf_CCSource
		{
			get 
			{
				return new object[,] { {(int)1, "Doctor"}, { (int)2, "Nurse"}, {(int)3, "Patient"}};
			}
		}

		public object[,] ValuesOf_MergeFieldType
		{
			get
			{
				return new object[,] {{(int)1, "Merge Fields"}, {(int)2, "Pictures"}};
			}
		}

		public object[,] ValuesOf_MergeFieldTypeWithTable
		{
			get
			{
				return new object[,] {{(int)1, "Merge Fields"}, {(int)2, "Pictures"}, {(int)3, "Tables"}};
			}
		}

		public object[,] ValuesOf_MergeFieldTypeWithCategory
		{
			get
			{
				return new object[,] {{(int)1, "Merge Fields"}, {(int)2, "Pictures"}, {(int)4, "Categories"}};
			}
		}

		public object[,] ValuesOf_MergeFieldTypeWithTableCategory
		{
			get
			{
				return new object[,] {{(int)1, "Merge Fields"}, {(int)2, "Pictures"}, {(int)3, "Tables"}, {(int)4, "Categories"}};
			}
		}

		public object[,] ValuesOf_MergeFieldTypeForParagraphs
		{
			get
			{
				return new object[,] {{(int)1, "Merge Fields"}, {(int)5, "Measurements"}};
			}
		}

		public object[,] ValuesOf_NetworkStatuses
		{
			get
			{
				return new object[,] {/*{(int)-1, "---"}, */{(int)1, "In"}, {(int)0, "Out"}};
			}
		}


		public object[,] ValuesOf_OpenClose
		{
			get
			{
				return new object[,] { /*{ (int)-1, "All"},*/ { (int)1, "Open"},  { (int)0, "Closed"}};
			}
		}
 
		public object[,] ValuesOf_DeliveryMethod
		{
			get
			{
				return new object[,] { {(bool)true, "Print"}, {(bool)false, "Fax"} };
			}
		}

		public string[,] ValuesOf_PRActionType
		{
			get
			{
				return new string[,] { { "NOACTION", "No Action"}, { "NEWPRREVIEW", "New PRReview" }, { "NEWPRDECISION", "New PRDecision" }  }; // return possible field values
			}
		}

		public virtual void FillSummaryText(SummaryWriter writer)
		{
			// data classes override this
		}

		public static string MakeCompositeDiagnosticIdentifier(string dxType, int diagId, int dsm4Axis)
		{
			return String.Format("{0}-{1}-{2}", dxType, diagId, dsm4Axis);
		}

		public static void ParseCompositeDiagnosticIdentifier(string composite, ref string dxType, ref int diagId, ref int dsm4Axis)
		{
			dxType = null;
			diagId = 0;
			dsm4Axis = 0;
			if (composite == null)
				return;

			string[] terms = composite.Split('-');
			dxType = terms[0];
			if (terms.Length > 1)
			{
				diagId = Convert.ToInt32( terms[1] );
				if (terms.Length > 2)
				{
					dsm4Axis = Convert.ToInt32( terms[2] );
				}
			}
		}

		public static string FormatDxPxCodeForDisplay(string dxType, string diagCode)
		{
			if (dxType == null && diagCode == null)
				return "";
			else
				return String.Format("{0}-{1}", dxType, diagCode);
		}

		public static string FormatTeamAndUserForDisplay(int teamID, int userID)
		{
			if (teamID == 0 && userID == 0)
				return "";
			else
				return String.Format("{0} - {1}", FormatTeamForDisplay(teamID), FormatUserForDisplay(userID) );
		}

		public static string FormatUserForDisplay(int userID)
		{
			return FormatUserForDisplay(userID, false);
		}

		public static string FormatUserForDisplay(int userID, bool withID)
		{
			if (userID == 0)
				return "";
			return (withID ? userID.ToString() : null) + AAUserCollection.AllUsers.Lookup_LoginNameByUserId(userID);
		}

		public static string FormatTeamForDisplay(int teamID)
		{
			return FormatTeamForDisplay(teamID, false);
		}

		public static string FormatTeamForDisplay(int teamID, bool withID)
		{
			if (teamID == 0)
				return "";
			return (withID ? teamID.ToString() : null) + TeamCollection.AllTeams.Lookup_CodeByTeamId(teamID);
		}

		/// <summary>
		/// Format the status change date and the changing user
		/// </summary>
		public static string FormatStatusChangeForDisplay(DateTime statusChangedDate, int statusChangedBy)
		{
			if (statusChangedDate == DateTime.MinValue)
				return "";

			return String.Format("{0} by {1}", 
				Formatting.FormatShortDate(statusChangedDate),
				FormatUserForDisplay(statusChangedBy) );
		}

		public static string ParseSSN(string ssn)
		{
			if (ssn != null)
			{
				ssn = Formatting.RemoveChars(ssn, ' ', '-');
				if (ssn == "")
					ssn = null;
			}
			return ssn;
		}

		public static string ParseZip(string zip)
		{
			if (zip != null)
			{
				zip = Formatting.RemoveChars(zip, ' ', '-');
				if (zip == "")
					zip = null;
			}
			return zip;
		}

		public static bool CalculateYearsMonths(DateTime dateStart, DateTime dateEnd, ref int years, ref int months)
		{
			int days = 0;
			return CalculateYearsMonthsDays(dateStart, dateEnd, ref years, ref months, ref days);
		}

		public static int CalculateMonths(DateTime dateStart, DateTime dateEnd)
		{
			int years = 0, months = 0;
			CalculateYearsMonths(dateStart, dateEnd, ref years, ref months);
			return years * 12 + months;
		}

		public static int CalculateDays(DateTime dateStart, DateTime dateEnd)
		{
			TimeSpan dateDif = dateEnd - dateStart;
			return dateDif.Days;
		}

		public static int CalculateYears(DateTime dateStart, DateTime dateEnd)
		{
			int iYearStart = dateStart.Year, iMonthStart = dateStart.Month, iDayStart = dateStart.Day;
			int iYearEnd = dateEnd.Year, iMonthEnd = dateEnd.Month, iDayEnd = dateEnd.Day;
			
			if (iDayEnd < iDayStart)
				iMonthEnd --;
			if (iMonthEnd < iMonthStart)
				iYearEnd --;
			return iYearEnd - iYearStart;

			/*
			 *  Original Pascal code sent by TR.
			 * 
				{ Calculate age in years from date of birth and service date }
				procedure TCustomGrouper.CalculateAgeInYears(dDOB, dService: TDateTime);
				var
				iYearDOB, iMonthDOB, iDayDOB: Word;
				iYearServ, iMonthServ, iDayServ: Word;
				begin
				DecodeDate(dDOB, iYearDOB, iMonthDOB, iDayDOB);
				DecodeDate(dService, iYearServ, iMonthServ, iDayServ);
				if iDayServ < iDayDOB then
					Dec(iMonthServ);
				if iMonthServ < iMonthDOB then
					Dec(iYearServ);
				AgeInYears := iYearServ - iYearDOB;
				end;
			*/

			/*
			int years = 0, months = 0;
			CalculateYearsMonths(dateStart, dateEnd, ref years, ref months);
			if (months >= 6)
				years ++;
			return years;*/
		}

		/// <summary>
		/// Years, months and days between two given dates.
		/// Based on the calendar calculation sent by David Henrickson.
		/// The days are calculated in more detail based on age calculation in LOSCoder.pas.
		/// </summary>
		/// <param name="dateStart"></param>
		/// <param name="dateEnd"></param>
		/// <param name="years"></param>
		/// <param name="months"></param>
		/// <param name="days"></param>
		/// <returns></returns>
		public static bool CalculateYearsMonthsDays(DateTime dateStart, DateTime dateEnd, ref int years, ref int months, ref int days)
		{
			int[] iDaysInMonths = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

			// if start or end date was not given, date difference can't be calculated.
			if (dateStart == DateTime.MinValue || dateEnd == DateTime.MinValue)
				return false;

			// { Calculate difference in years, months, days }
			years = dateEnd.Year - dateStart.Year;
			months = dateEnd.Month - dateStart.Month;
			days = dateEnd.Day - dateStart.Day;

			if (days < 0)
			{
				days += iDaysInMonths[(dateEnd.Month - 1) % 12];  //  DateTime.DaysInMonth() ;  
				months --;
			}
	

			if (months < 0)
			{
				months += 12;
				years --;
			}

			return true;
		}

		public static bool CalculateYearsDays(DateTime dateStart, DateTime dateEnd, ref int years, ref int days)
		{
			int[] iDaysInMonths = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

			int months = 0;
			if (!CalculateYearsMonthsDays(dateStart, dateEnd, ref years, ref months, ref days))
				return false;
			if (months > 0)
			{
				// add the days of the months
				int month = dateEnd.Month;
				for (int i = months; i > 0; i--)
				{
					days += iDaysInMonths[(month - 1) % 12];
					month--;
					if (month <= 0)
						month = month = 12;
				}
			}

			return true;
		}

		/// <summary>
		/// Gestational age calculation sent by David Henrickson.
		/// </summary>
		/// <param name="FVisit"></param>
		/// <param name="FLMP"></param>
		/// <returns></returns>
		public static int CalculateGestationalAge(int FVisit, int FLMP)
		{
			// For gestational age we calculate the number of weeks, rounding up after four days as follows:
			int iWeek = (FVisit - FLMP) / 7;
			int iMod = (FVisit - FLMP) % 7;
			if (iMod > 4)
				iWeek ++;
			return iWeek;
		}


		/// <summary>
		/// Calculates the base amount and extended amount for the given rate, amount, and conversion contstants.
		/// Returns false if there's a calculation error.
		/// </summary>
		/// <param name="amount"></param>
		/// <param name="rate"></param>
		/// <param name="baseConversionDivider"></param>
		/// <param name="baseConversionMultiplier"></param>
		/// <param name="baseAmount"></param>
		/// <param name="extendedAmount"></param>
		/// <returns></returns>
		public bool CalculateBaseAndExtendedAmount(decimal amount, decimal rate, decimal baseConversionDivider, decimal baseConversionMultiplier, ref decimal baseAmount, ref decimal extendedAmount)
		{
			baseAmount = 0;
			extendedAmount = 0;
			// check for 0 denominator
			if (baseConversionDivider == 0)
				return false;
			// check for NULLs
			if (baseConversionDivider == decimal.MinValue ||
				baseConversionMultiplier == decimal.MinValue ||
				rate == decimal.MinValue ||
				amount == decimal.MinValue)
				return false;
			baseAmount =  baseConversionMultiplier * amount / baseConversionDivider;
			extendedAmount = baseAmount * rate;
			return true;
		}

		public static string FormatFNameLName(string lastName, string firstName)
		{
			String str = "";
			if (firstName != null)
				str += firstName;
			if (lastName != null)
			{
				str += " ";
				str += lastName;
			}

			return str.ToString();
		}

		/// <summary>
		/// Return true if the given code is in the specified range.
		/// </summary>
		/// <param name="code"></param>
		/// <param name="fromCode"></param>
		/// <param name="toCode"></param>
		/// <returns></returns>
		public static bool IsCodeInRange(string code, string fromCode, string toCode)
		{
			if (String.Compare(code, fromCode) >= 0 &&
				String.Compare(code, toCode) <= 0)
				return true;
			else
				return false;
		}


		[FieldValuesMember("LookupOf_UserID", "UserId", "LoginName")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CreatedBy
		{
			get { return Convert.ToInt32(this.Get(CreatedByMember, false)); }
			set { this.Set(CreatedByMember, value, false); }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime)]
		public DateTime CreateTime
		{
			get { return Convert.ToDateTime(this.Get(CreateTimeMember, false)); }
			set { this.Set(CreateTimeMember, value, false); }
		}

		[FieldDescription("@CREATEDBY@")]
		public string CreatedByString
		{
			get { return FormatUserForDisplay(this.CreatedBy); }
		}

		[FieldValuesMember("LookupOf_UserID", "UserId", "LoginName")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ModifiedBy
		{
			get { return Convert.ToInt32(this.Get(ModifiedByMember, false)); }
			set { this.Set(ModifiedByMember, value, false); }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime)]
		public DateTime ModifyTime
		{
			get { return Convert.ToDateTime(this.Get(ModifyTimeMember, false)); }
			set { this.Set(ModifyTimeMember, value, false); }
		}

		[FieldDescription("@MODIFIEDBY@")]
		public string ModifiedByString
		{
			get { return FormatUserForDisplay(this.ModifiedBy); }
		}

		public AAUserCollection LookupOf_UserID
		{
			get
			{
				return AAUserCollection.AllUsers; // Acquire a shared instance from the static member of collection
			}
		}

		public TeamCollection LookupOf_TeamID
		{
			get
			{
				return TeamCollection.AllTeams; // Acquire a shared instance from the static member of collection
			}
		}
	}

	/// <summary>
	/// Extends the NetsoftUSA.BaseDataClass features and provides
	/// a centralized management point for all of the application data collection classes.
	/// </summary>
	public class BaseDataCollection : BaseDataCollectionClass
	{
		public BaseDataCollection()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}

}
