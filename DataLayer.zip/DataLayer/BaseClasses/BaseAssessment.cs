using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for BaseAssessment.
	/// </summary>
	public class BaseAssessment : BaseData
	{
		protected int activeWithAll = -1;

		[FieldValuesMember("LookupOf_activeWithAll")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true, ValueForNull=(int)-1)]
		[FieldDescription("@ACTIVE@")]
		public int ActiveWithAll
		{
			get { return this.activeWithAll; }
			set { this.activeWithAll = value; }
		}


		public object[,] LookupOf_activeWithAll
		{
			get
			{
				return base.ValuesOf_ActiveWithAll; // Acquire a shared instance from the static member of collection
			}
		}

	}
}
