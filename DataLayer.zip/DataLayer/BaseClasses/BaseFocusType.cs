using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for BaseFocusType.
	/// </summary>
	// Pseudo table mapping for BaseFocusType, attributes will be overwritten by derived classes.
	[TableMapping("ProviderFocusTypes","ProviderFocusTypeID")]
	public  class BaseFocusType: NetsoftUSA.DataLayer.BaseDataClass
	{

		[ColumnMapping("FocusCode",ValuesForNull.NullObject)]
		protected string focusCode;
		[ColumnMapping("Focus",ValuesForNull.NullObject)]
		protected string focus;
		[ColumnMapping("Active")]
		protected bool active;
		[ColumnMapping("Note",ValuesForNull.NullObject)]
		protected string note;

		protected EntityType parentEntity;
		public  EntityType Entity
		{
			get { return this.parentEntity; }
			set { this.parentEntity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=10)]
		public string FocusCode
		{
			get { return this.focusCode; }
			set { this.focusCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=100)]
		[FieldDescription("@FOCUSDESC@")]
		public string Focus
		{
			get { return this.focus; }
			set { this.focus = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get 
			{ return this.active;
			}
			set { 
				this.active = value;
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		public BaseFocusType()
		{
			
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		public new void Save()
		{
			base.Save();
		}
	}
}
