using System;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Derive all ActiveAdvice application exceptions
	/// from this class.
	/// </summary>
	
	[Flags]
	public enum AAExceptionAction
	{
		None = 0,
		DisableUI = 1,
		NoLogging = 2
	}

	public enum EnumExceptionResolution
	{
		General = 0,
		DxPxLoadError = 1
	}

	public class ActiveAdviceException : NetsoftUSA.DataLayer.ExceptionWithParameters
	{
		AAExceptionAction exceptionAction = AAExceptionAction.None;
		EnumExceptionResolution exceptionResolution = EnumExceptionResolution.General;

		public ActiveAdviceException(AAExceptionAction exceptionAction, string msg, Exception innerException) : base(msg, innerException)
		{
			this.exceptionAction = exceptionAction;
		}

		public ActiveAdviceException(AAExceptionAction exceptionAction, string msg) : base(msg)
		{
			this.exceptionAction = exceptionAction;
		}

		public ActiveAdviceException(AAExceptionAction exceptionAction, string msg, Exception innerException, params object[] parameters) : base(msg, innerException, parameters)
		{
			this.exceptionAction = exceptionAction;
		}

		public ActiveAdviceException(AAExceptionAction exceptionAction, string msg, params object[] parameters) : base(msg, parameters)
		{
			this.exceptionAction = exceptionAction;
		}

		//
		public ActiveAdviceException(EnumExceptionResolution exceptionResolution, string msg, Exception innerException) : base(msg, innerException)
		{
			this.ExceptionResolution = exceptionResolution;
		}

		public ActiveAdviceException(EnumExceptionResolution exceptionResolution, string msg) : base(msg)
		{
			this.ExceptionResolution = exceptionResolution;
		}

		public ActiveAdviceException(EnumExceptionResolution exceptionResolution, string msg, Exception innerException, params object[] parameters) : base(msg, innerException, parameters)
		{
			this.ExceptionResolution = exceptionResolution;
		}

		public ActiveAdviceException(EnumExceptionResolution exceptionResolution, string msg, params object[] parameters) : base(msg, parameters)
		{
			this.ExceptionResolution = exceptionResolution;
		}

		// 

		public ActiveAdviceException(string msg, Exception innerException) : this(AAExceptionAction.None, msg, innerException)
		{
		}

		public ActiveAdviceException(string msg) : this(AAExceptionAction.None, msg)
		{
		}

		public ActiveAdviceException(string msg, Exception innerException, params object[] parameters) : this(AAExceptionAction.None, msg, innerException, parameters)
		{
		}

		public ActiveAdviceException(string msg, params object[] parameters) : this(AAExceptionAction.None, msg, parameters)
		{
		}

		public ActiveAdvice.DataLayer.AAExceptionAction ExceptionAction
		{
			get { return this.exceptionAction; }
			set { this.exceptionAction = value; }
		}

		public ActiveAdvice.DataLayer.EnumExceptionResolution ExceptionResolution
		{
			get { return this.exceptionResolution; }
			set 
			{ 
				this.exceptionResolution = value; 
				// put here the code that sets exceptionaction based on exception resolution
				switch (this.exceptionResolution)
				{
					//example:
					//case EnumExceptionResolution.xxx1:
					//case EnumExceptionResolution.xxx2:
					//	this.exceptionAction = AAExceptionAction.DisableUI;
					//	break;
				}
			}
		}

		public override bool NoLogging
		{
			get 
			{
				return (exceptionAction & AAExceptionAction.NoLogging) != 0;
			}
		}

	}
}
