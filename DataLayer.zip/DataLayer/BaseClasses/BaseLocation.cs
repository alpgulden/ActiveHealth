using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for BaseLocation.
	/// </summary>
	/// 
	[TableMapping("ProviderLocation","providerLocationID")]
	public class BaseLocation: BaseDataWithUserDefined
	{
		
		[NonSerialized]
		private BaseLocationCollection parentBaseLocationCollection;
		[ColumnMapping("LocationID",StereoType=DataStereoType.FK)]
		protected int locationID;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("Notepad")]
		protected string notepad;
		[ColumnMapping("EffectiveDate")]
		protected DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		protected DateTime terminationDate;
		[ColumnMapping("TerminateTime")]
		protected DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		protected int terminatedBy;
		[ColumnMapping("AlternateID")]
		protected string alternateID;
		protected Location location;
	

		[FieldDescription("@LOCATIONID@")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LocationID
		{
			get { return this.locationID; }
			set { this.locationID = value; }
		}

		
		[FieldDescription("@CREATETIME@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}


		[FieldDescription("@CREATEDBY@")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[FieldDescription("@MODIFYTIME@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[FieldDescription("@MODIFYBY@")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		

		[FieldDescription("@EFFDATE@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[FieldDescription("@TERMDATE@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[FieldDescription("@TERMINATEDBY@")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}



		[FieldDescription("@ADDRESS@")]
		public string ServiceAddress
		{
			get { return this.Location.ServiceAddress.Line1 + " " + this.Location.ServiceAddress.Line2; }
		}

		[FieldDescription("@CITY@")]
		public string ServiceAddressCity
		{
			get { return this.Location.ServiceAddress.City; }
		}

		[FieldDescription("@STATE@")]
		public string ServiceAddressState
		{
			get { return this.Location.ServiceAddress.State; }
		}

		[FieldDescription("@ZIP@")]
		public string ServiceAddressZip
		{
			get { return this.Location.ServiceAddress.Zip; }
		}

		[FieldDescription("@COUNTY@")]
		public string ServiceAddressCounty
		{
			get { return this.Location.ServiceAddress.County; }
		}



		public BaseLocation()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Contained Location object
		/// </summary>
		[Contained]
		public Location Location
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.location = (Location)Location.EnsureContainedDataObject(this, typeof(Location), location, false, LocationID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.location;
			}
			set
			{
				this.location = value;
				if (value != null) 
				{
					value.ParentBaseLocation = this; // set this as a parent of the child data class
					this.LocationID = this.location.LocationID;	
				}

			}
		}

		/// <summary>
		/// Parent BaseLocationCollection that contains this element
		/// </summary>
		public BaseLocationCollection ParentBaseLocationCollection
		{
			get
			{
				return this.parentBaseLocationCollection;
			}
			set
			{
				this.parentBaseLocationCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}
	}

	[ElementType(typeof(BaseLocation))]
	public class BaseLocationCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		

	}
	

}
