using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// WE are using this interface to add physician review function in to the erc class.
	/// </summary>
	public interface IImageOwner
	{
		ImageLinkCollection Images { get; set;}
		void LoadImages(bool foreReload);
		void SaveImages();
	}
}
