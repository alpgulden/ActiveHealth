using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [MemberLogORGList]
	/// </summary>
	[SPAutoGen("usp_GetOrgsByJobID","SelectAllByGivenArgs.sptpl","jobID")]
	[TableMapping("MemberLogORGList","memberLogORGListID")]
	public class MemberLogORGList : BaseDataClass
	{
		[ColumnMapping("MemberLogORGListID",(int)0)]
		private int memberLogORGListID;
		[ColumnMapping("JobID",StereoType=DataStereoType.FK)]
		private int jobID;
		[ColumnMapping("OrganizationID",StereoType=DataStereoType.FK)]
		private int organizationID;
		[ColumnMapping("OrganizationLevelID",StereoType=DataStereoType.FK)]
		private int organizationLevelID;
	
		public MemberLogORGList()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int MemberLogORGListID
		{
			get { return this.memberLogORGListID; }
			set { this.memberLogORGListID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int JobID
		{
			get { return this.jobID; }
			set { this.jobID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OrganizationID
		{
			get { return this.organizationID; }
			set { this.organizationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OrganizationLevelID
		{
			get { return this.organizationLevelID; }
			set { this.organizationLevelID = value; }
		}
	}
}
