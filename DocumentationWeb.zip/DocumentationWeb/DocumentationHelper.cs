using System;
using System.Web;
using System.IO;
using System.Reflection;
using System.Diagnostics;
using System.Text;
using System.Collections;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Web.Caching;
using System.Configuration;

namespace DocumentationWeb
{
	/// <summary>
	/// Summary description for DocumentationHelper.
	/// </summary>
	public class DocumentationHelper
	{

		public enum EntityType: int
		{	unknown = 0,
			page = 1,
			dataclass = 2,
			datacollection = 3,
			usercontrol = 4
		}

		public enum MemberType: int
		{
			unknown = 0,
			field = 1,
			property = 2,
			method = 3
		}

		public enum ExplainPageTable:int
		{
			DOC_ENTITY = 0,
			UDF_DOC_PAGE_ENTITIES =1,
			UDF_DOC_DC_MEMBER_ATTRIBUTES_BY_PAGE=2,
			UDF_DOC_USERCONTROL_MEMBERS=3,
			USP_DOC_EXPLAIN_ENTITY_ATTRIBUTES=4,
			USP_DOC_EXPLAIN_ENTITY_MEMBER_ATTRIBUTES = 5
		}

		
		public enum DOCTableFields:int
		{			
			EntityId = 0,
			PageName ,
			Name,
			FullName,
			BaseNameSpaces,
			Type,
			MemberId,
			AttributeId,
			AllValues
		}			

		public DocumentationHelper()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static int F_A_COUNT = 0;
		public static int P_A_COUNT = 0;
		public static int E_A_COUNT = 0;
		public static int E_COUNT = 0;

		public static int gParentEntityId = 0;

		#region Store DS as static ht
		
		private Hashtable instanceCache = new Hashtable();
		
		public DataSet GetCachedDataSet(string cachingKey)
		{
			if (cachingKey == null)
				return null;	// always unchached
			
			return instanceCache[cachingKey] as DataSet;
		}

		public void SetCachedDataSet(string cachingKey, DataSet ds)
		{
			if (cachingKey == null)
				return;			// always unchached
			
			
			instanceCache[cachingKey] = ds;
		}

		#endregion DS as static ht

		#region Consts

		public static string BIN_PATH = "";

		// !!!!!!!!!!THIS IS AA SPECIFIC !!!!!!!!!!!!!!!!
		public static string DLL_AAWEB = ConfigurationSettings.AppSettings["DLL_AAWEB"];							//"ActiveAdviceWeb";
		public static string DLL_AA_DATALAYER = ConfigurationSettings.AppSettings["DLL_AA_DATALAYER"];				//"DataLayer";
		public static string AAWEB_NAMESPACE = ConfigurationSettings.AppSettings["AAWEB_NAMESPACE"];				//"ActiveAdvice.Web.";
		public static string AADATALAYER_NAMESPACE = ConfigurationSettings.AppSettings["AADATALAYER_NAMESPACE"];	//"ActiveAdvice.DataLayer."

//		public const string DLL_AAWEB = "ActiveAdviceWeb";
//		public const string DLL_AA_DATALAYER = "DataLayer";
//		public const string AAWEB_NAMESPACE = "ActiveAdvice.Web.";
//		public const string AADATALAYER_NAMESPACE = "ActiveAdvice.DataLayer.";
		// !!!!!!!!!!THIS IS AA SPECIFIC !!!!!!!!!!!!!!!!


		public const string NS_DATALAYER_NAMESPACE = "NetsoftUSA.DataLayer";
		public const string NS_WEBFORMS_NAMESPACE = "NetsoftUSA.WebForms";
		public const string NS_WEBCONTROLS_NAMESPACE = "NetsoftUSA.WebControls";
		public const string NS_INFRAWEB_NAMESPACE = "NetsoftUSA.InfragisticsWeb";
		public const string NS_SECURITY_NAMESPACE = "NetsoftUSA.Security";
		
		public const string UNDERSCORE = "_";

		public const string ATTR_OWNER = "Attribute Owner";
		public const string ATTR_TYPE = "Attribute Type";
		public const string ATTR_PIPE_DEL = "|";		
		public const string ATTR_EQUAL = "=";



		//type constants WEB_USERCONTROL, WEB_PANEL, SYS_COLLECTIONBASE, NS_BASEDATACLASS
		public const string WEB_PAGE = "System.Web.UI.Page"; 
		public const string WEB_USERCONTROL = "System.Web.UI.UserControl";
		public const string WEB_PANEL = "System.Web.UI.WebControls.Panel";
		
		public const string SYS_COLLECTIONBASE = "System.Collections.CollectionBase";

		//public static string AA_
		//NetsoftUSA.DataLayer.BaseDataClass
		public const string NS_BASEDATACLASS = "NetsoftUSA.DataLayer.BaseDataClass";

		//DB values const for Entity/Member Types
		public const string ENTITY_PAGE = "PG";
		public const string ENTITY_DATACLASS = "DC";
		public const string ENTITY_DATACOLLECTION = "DCC";
		public const string ENTITY_USERCONTROL = "UC";

		public const string MEMBER_PROPERTY = "P";
		public const string MEMBER_FIELD = "F";
		public const string MEMBER_METHOD = "M";
		
		//DB tables
		public const string DOC_ENTITY = "DOC_ENTITY"; 
		public const string DOC_MEMBER = "DOC_MEMBER";
		public const string DOC_ATTRIBUTE = "DOC_ATTRIBUTE";

		//DB columns
		public const string NAME ="Name", FULLNAME = "FullName";
		public const string BASENAMESPACES = "BaseNameSpaces",  TYPE = "Type";
		public const string ASSEMBLY = "Assembly";
		public const string ENTITYID = "EntityId";

		public const string MEMBERID = "MemberId";

		//DOC_ATTRIBUTE
		public const string ATTRIBUTEID = "AttributeId";
		public const string ALLVALUES = "AllValues";
		public const string ONLYATTR = "OnlyAttr";		//SP parm


		//Explain Page fields
		public const string PAGENAME = "PageName";
		public const string PAGEENTITYID = "PageEntityId";

		//text consts
		public const string NEW_LINE = "<BR>";

		//test 
		public const string DEFAULT_PAGE = "PatientForm";

		//<add key="ConnectionString" value="server=localhost;database=pubs;Integrated Security=SSPI" /> 
		private const string CONN_STRING = "ConnectionString";
		private static string connString = ConfigurationSettings.AppSettings[CONN_STRING];
		
		public static string ConnectionString
		{
			get{return connString;}
		}

		#endregion Consts

		#region Cached DOC Data

		public static string RemoveTableFromCache
		{
			set
			{
				if(!IsDocTable(value))
					return;

				//remove data from cache
				HttpContext.Current.Cache.Remove(value);
			}
		}
		
		public static DataSet CacheDataSet(string strTable )
		{		
			//only for 3 DOC tables
			if(!IsDocTable(strTable))
			{				
				return null;
			}

			DataSet dsSource = (DataSet)HttpContext.Current.Cache.Get(strTable);

			if (dsSource == null || RowCount(dsSource) == 0)
			{	
				dsSource = GetDbRecords(strTable);

				if(dsSource != null)
				{
					//DateTime.Now.AddMinutes(2), TimeSpan.Zero
					//DateTime.MaxValue, new TimeSpan(0,30,0) //h, m, s

					//remove from cache in 30 mins if no action made in Documentation
					HttpContext.Current.Cache.Insert(strTable, dsSource,
						null,
						DateTime.Now.AddMinutes(30), 
						TimeSpan.Zero,
						CacheItemPriority.Normal, 
						null);
				}
				else
				{
					string msg = String.Format("Load data to DB table {0}", strTable);
					CodeHelper.WriteEventLog(msg);
				}
			}

			return dsSource;	
		}

		public static DataView PageDV
		{
			get
			{
				DataView dv = new DataView();
				DataSet ds = CacheDataSet(DOC_ENTITY);
				string filter = String.Format("{0}='{1}'", TYPE, ENTITY_PAGE);
				string sort = NAME;

				if(RowCount(ds) > 0)
				{
					dv = ds.Tables[0].DefaultView;
					dv.RowFilter = filter;
					dv.Sort = sort;
				}
				return dv;
			}
		}

		public static DataView DataClassDV
		{
			get
			{
				DataView dv = new DataView();
				DataSet ds = CacheDataSet(DOC_ENTITY);
				string filter = String.Format("{0}='{1}'", TYPE, ENTITY_DATACLASS);
				string sort = NAME;

				if(RowCount(ds) > 0)
				{
					dv = ds.Tables[0].DefaultView;
					dv.RowFilter = filter;
					dv.Sort = sort;
				}
				return dv;
			}
		}

		public static DataView UserControlDV
		{
			get
			{
				DataView dv = new DataView();
				DataSet ds = CacheDataSet(DOC_ENTITY);
				string filter = String.Format("{0}='{1}'", TYPE, DocumentationHelper.ENTITY_USERCONTROL);
				string sort = NAME;

				if(RowCount(ds) > 0)
				{
					dv = ds.Tables[0].DefaultView;
					dv.RowFilter = filter;
					dv.Sort = sort;
				}
				return dv;
			}
		}

		public static DataView DataCollectionDV
		{
			get
			{
				DataView dv = new DataView();
				DataSet ds = CacheDataSet(DOC_ENTITY);
				string filter = String.Format("{0}='{1}'", TYPE, DocumentationHelper.ENTITY_DATACOLLECTION);
				string sort = NAME;

				if(RowCount(ds) > 0)
				{
					dv = ds.Tables[0].DefaultView;
					dv.RowFilter = filter;
					dv.Sort = sort;
				}
				return dv;
			}
		}

		#endregion Cached Data

		#region Entities

		public static EntityType GetEntityTypeEmFromId(int EntityId)
		{			
			DataRow dataRow = GetEntityById(EntityId);
			if(dataRow == null)
				return EntityType.unknown;
		
			string EntityName = dataRow[NAME].ToString();
			string strEntityTypeCode = dataRow[TYPE].ToString();
					
			switch(strEntityTypeCode)
			{
				case ENTITY_DATACLASS:
					return EntityType.dataclass;
				
				case DocumentationHelper.ENTITY_DATACOLLECTION:
					return EntityType.datacollection;	

				case DocumentationHelper.ENTITY_USERCONTROL:
					return EntityType.usercontrol;	

				case DocumentationHelper.ENTITY_PAGE:
					return EntityType.page;						
			}

			return EntityType.unknown;		
		}

		public static EntityType GetEntityTypeEmFromFullName(string strFullName)
		{
			Type type = GetTypeFromFullName( strFullName);
			
			if(IsDataClass(type))
				return EntityType.dataclass;

			if(IsPage(type))
				return EntityType.page;

			if(IsDataCollection(type))
				return EntityType.datacollection; 

			if(IsUserControl(type))
				return EntityType.usercontrol;
			
			return EntityType.unknown;
		}


		public static DataSet EntitiesDS
		{
			get	{return CacheDataSet(DocumentationHelper.DOC_ENTITY);}
		}

		public static DataRow GetEntityByFullName(string EntityFullName)
		{
			DataRow row = null;			
			DataSet ds = EntitiesDS;

			string filter = string.Format("{0}='{1}'",DocumentationHelper.FULLNAME,EntityFullName);

			if(RowCount(ds) > 0)
			{
				DataRow[] drArr = ds.Tables[0].Select(filter);

				if(drArr.Length == 1)
					return drArr[0];
			}

			return row;
		}

		public static DataRow GetEntityById(int EntityId)
		{
			DataRow row = null;			
			DataSet ds = EntitiesDS;

			string filter = string.Format("{0}={1}",DocumentationHelper.ENTITYID,EntityId);

			if(RowCount(ds) > 0)
			{
				DataRow[] drArr = ds.Tables[0].Select(filter);

				if(drArr.Length == 1)
					return drArr[0];
			}

			return row;
		}

		public static string UpdatedEntitiesCount
		{
			get
			{
				string msg = String.Format("Updated entities: {0}, with Attributes {1}.",E_COUNT, E_A_COUNT);
				E_A_COUNT = 0;
				E_COUNT = 0;
				return msg;
			}

		}
	
		public static bool LoadAllEntitiesToDB()
		{
			string file = "";
			string strEntityBaseNS = "";
			string strOut = "";
			int rc = 0;
			bool bLoadIsOK = true;
			//reset static counters
			E_A_COUNT = 0;
			E_COUNT = 0;

			try
			{
				//Pages
				file = DocumentationHelper.AAWEB_NAMESPACE;
				strEntityBaseNS = DocumentationHelper.WEB_PAGE;
				bLoadIsOK = LoadEntityToDBFromAssembly(file, strEntityBaseNS, out strOut);

				//DataClass
				if(!bLoadIsOK) 
					return bLoadIsOK;

				file = DocumentationHelper.AADATALAYER_NAMESPACE;
				strEntityBaseNS = DocumentationHelper.NS_BASEDATACLASS;
				bLoadIsOK = LoadEntityToDBFromAssembly(file, strEntityBaseNS, out strOut);

				//DataCollection
				if(!bLoadIsOK) 
					return bLoadIsOK;

				file = DocumentationHelper.AADATALAYER_NAMESPACE;
				strEntityBaseNS = DocumentationHelper.SYS_COLLECTIONBASE;
				bLoadIsOK = LoadEntityToDBFromAssembly(file, strEntityBaseNS, out strOut);

				//UserControl
				if(!bLoadIsOK) 
					return bLoadIsOK; 

				file = DocumentationHelper.AAWEB_NAMESPACE;
				strEntityBaseNS = DocumentationHelper.WEB_USERCONTROL;
				bLoadIsOK = LoadEntityToDBFromAssembly(file, strEntityBaseNS, out strOut);

			}
			catch(Exception ex)
			{
				string msg = String.Format("Error while loading {0}, Entity updated {1}, with attributes {2}", strEntityBaseNS, E_COUNT,E_A_COUNT );
				CodeHelper.WriteEventLog(msg);
				E_A_COUNT = 0;
				E_COUNT = 0;
				throw new Exception(msg + " Error Details: " + ex.Message);
				//return false;
			}
			
			return bLoadIsOK;

		}

		public static bool LoadEntityToDBFromAssembly(string file, string strOnlyFullName, out string temp)
		{
			temp = "";
			string strList = "";
			Hashtable ht = new Hashtable();
			string strFile = file;
			string strEntityType = GetEntityTypeConstFromBaseFullName(strOnlyFullName);
			string strDllFile = GetDllFromNamespace(file);
			int currEntityId = 0;
			Type currType = null;

			try
			{
				if(!File.Exists(file))
				{
					file = GetAssemblyFile(file);
				}

				if(!File.Exists(file))
				{
					temp = String.Format("Error: {0} not exists", file);
					throw new Exception(temp);
					//return false;
				}

				Assembly a = Assembly.LoadFrom(file);

				temp += String.Format("Error for Assembly: {0}: <BR>", file);
				
				if(strEntityType.Length == 0)
				{
					throw new Exception(temp);
					//return false;
				}

				foreach (Type type in a.GetTypes())
				{
					currType = type;

					// temp VS
					if(type.ToString().IndexOf("ActiveAdvice.Web.PatientForm") == 0)
					{
						string stop = type.Name;
						
					}

					if(strOnlyFullName != null && strOnlyFullName.Length > 0 && !IsType(type,strOnlyFullName))
						continue;

					strList = GetAllTypes(type, ",");
					temp += String.Format("<B>{0}</B>: {1}<BR> ",
						type.Name, strList);

					ht.Add(type.Name, type);	
			
					//get Entity Attrs VS
					object[] attArr = type.GetCustomAttributes(true);

					Hashtable hta = ExplainAttributesForDb(attArr);
				
					currEntityId = Update_DOC_ENTITY_GetId(type.Name, type.ToString(), strList, strEntityType, strDllFile);
					E_COUNT ++;
						
					if(currEntityId > 0 && hta.Count > 0)
					{
						E_A_COUNT ++;
						
						foreach(object attr in hta.Keys)
						{
							string strName = attr.GetType().Name;
							string FullName = attr.GetType().ToString();
							string strAllValues = hta[attr].ToString();

							DocumentationHelper.Update_DOC_ATTRIBUTE(strName,FullName, currEntityId, 0, strAllValues);
							
						}
							
					}	// if hta.Count > 0

				}	//foreach GetTypes
			}
			catch(Exception ex)
			{
				string msg = String.Format("On LoadEntityToDBFromAssembly() Curr Type: {0}, last EntitryId={1}, err: {2}",currType.ToString(), currEntityId, ex.Message);
				throw new Exception(temp);
				//return false;
			}

			return true;

		}

		#endregion Entities

		#region Members

		public static string LoadAllMembersToDB(bool bNotSystemType)
		{	
			bool bLoadIsOK = true;
			//loop thru all entities
			DataSet ds = EntitiesDS;
			DataRow row = null;
			 //bNotSystemType = true;
			int rc = 0;
			int errRow = 0;

			//refresh counter
			F_A_COUNT = 0;
			P_A_COUNT = 0;

			try
			{
				rc = RowCount(ds);
				if(rc > 0)
				{
					for(int i=0;i<rc; i++)
					{
						errRow = i;
						row = ds.Tables[0].Rows[i];
						bLoadIsOK = LoadMembersToDbFromEntityRow(row, bNotSystemType);
						if(!bLoadIsOK)
							break;
					}
				}
			}
			catch(Exception ex)
			{
				string msg = String.Format("On LoadAllMembersToDB(): row={0}, err: {1}",errRow, ex.Message);
				CodeHelper.WriteEventLog(msg);
				return msg;

			}

			string msgOK = String.Format("On OK LoadAllMembersToDB(): F count={0}, P count: {1}",F_A_COUNT, P_A_COUNT);
			CodeHelper.WriteEventLog(msgOK);
			F_A_COUNT = 0;
			P_A_COUNT = 0;
			return msgOK;
		}

		public static DataSet MembersDS
		{
			get	{return CacheDataSet(DocumentationHelper.DOC_MEMBER);}
		}

		public static DataRow GetMemberByEntityIdName(int EntityID, string MemberName)
		{
			DataRow row = null;			
			DataSet ds = MembersDS;

			string filter = string.Format("{0}={1} and {2}='{3}'",
				DocumentationHelper.ENTITYID, EntityID, DocumentationHelper.FULLNAME , MemberName);

			if(RowCount(ds) > 0)
			{
				DataRow[] drArr = ds.Tables[0].Select(filter);

				if(drArr.Length == 1)
					return drArr[0];
			}

			return row;
		}

		public static bool LoadMembersToDbFromEntityRow(DataRow row, bool bNotSystemType)
		{
			Type type = null;
			int EntityId = 0;
			string strEntityFullName = "";
			EntityType emEntityType = EntityType.unknown;
			bool bLoadIsOk = true;
 
			if(row != null)
			{
				strEntityFullName = row[FULLNAME].ToString();
				type = GetTypeFromFullName(strEntityFullName);
				emEntityType = GetEntityTypeEmFromFullName(strEntityFullName);
				EntityId = (int)row[ENTITYID];

				//load fields
				//bLoadIsOk =  LoadFieldsToDbFromEntity( type,  EntityId,  emEntityType ,  bNotSystemType);
				bLoadIsOk =  LoadFieldsAttrToDbFromEntity( type,  EntityId,  emEntityType ,  bNotSystemType);				

				if(!bLoadIsOk)
					return bLoadIsOk;

				//load properties
				//bLoadIsOk =  LoadPropertiesToDbFromEntity( type,  EntityId,  emEntityType ,  bNotSystemType);
				bLoadIsOk =  LoadPropertiesAttrToDbFromEntity( type,  EntityId,  emEntityType ,  bNotSystemType);

				if(!bLoadIsOk)
					return bLoadIsOk;

				//load methods
				bLoadIsOk =  LoadMembersToDbFromEntity( type,  EntityId,  emEntityType ,  bNotSystemType);
			}

			return bLoadIsOk;
		}

		//Fields
			
		/// <summary>
		/// type - Entity type (page, DC, DCC, UserControl)
		/// </summary>
		/// <param name="type"></param>
		/// <param name="EntityId"></param>
		/// <param name="EntityType"></param>
		/// <param name="bNotSystemType"></param>
		/// <returns></returns>
		public static bool LoadFieldsToDbFromEntity(Type type, int EntityId, EntityType em, bool bNotSystemType)
		{
			string temp = "";
			
			Hashtable ht = new Hashtable();
			string strList = "";

//			try
//			{
				if(type == null) 
					return false;
				// 
				FieldInfo [] fiArr = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

				foreach(FieldInfo fi in fiArr)
				{
					if(bNotSystemType && fi.FieldType.FullName.IndexOf("System.") ==0)
						continue;

					temp += String.Format("F: {0} - {1} <br>", fi.FieldType.ToString(),  fi.Name);				
					try
					{
						ht.Add(fi.Name, fi.FieldType);
					}
					catch(Exception ex)
					{
						string msg = String.Format("EntityId {0} F {1} error: {2}", EntityId, fi.Name, ex.Message);
						//CodeHelper.WriteEventLog(msg);
						continue;
					}

					strList = GetAllTypes(fi.FieldType, ",");

					DocumentationHelper.Update_DOC_MEMBER(fi.Name, fi.FieldType.ToString(), strList, MEMBER_FIELD, EntityId);
				}
//			}
//			catch(Exception ex)
//			{
//				temp += ex.Message + "<br>";
//				return false;
//			}

			return true;//(ht.Count > 0);
		}


		public static bool LoadFieldsAttrToDbFromEntity(Type type, int EntityId, EntityType em, bool bNotSystemType)
		{
			string temp = "";
			
			Hashtable ht = new Hashtable();
			string strList = "";
			int currMemberId = 0;
			try
			{

				if(type == null) 
					return false;
			
				FieldInfo [] fiArr = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

				foreach(FieldInfo fi in fiArr)
				{
					if(bNotSystemType && fi.FieldType.FullName.IndexOf("System.") ==0)
						continue;

					temp += String.Format("F: {0} - {1} <br>", fi.FieldType.ToString(),  fi.Name);				
					try
					{
						ht.Add(fi.Name, fi.FieldType);
					}
					catch(Exception ex)
					{
						string msg = String.Format("EntityId {0} F {1} error: {2}", EntityId, fi.Name, ex.Message);
						//CodeHelper.WriteEventLog(msg);
						continue;
					}

					strList = GetAllTypes(fi.FieldType, ",");

					//VS05
					if(fi.FieldType is NetsoftUSA.WebForms.IDataBoundControl)
					{
						NetsoftUSA.WebForms.IDataBoundControl boundControl = (NetsoftUSA.WebForms.IDataBoundControl)fi;
						string dm = boundControl.GetDataMember();
						//string ds = boundControl.GetDataSource(); 
						string ds = boundControl.GetDataSource().GetType().Name;
						DataRowView drv =  boundControl.GetCurrentDataRowView();


					}

				
					//get Field Attrs VS
					object[] attArr = fi.GetCustomAttributes(true);

					Hashtable hta = ExplainAttributesForDb(attArr);
			
					currMemberId = Update_DOC_MEMBER_GetId(fi.Name, fi.FieldType.ToString(), strList, MEMBER_FIELD, EntityId);
					if(hta.Count > 0)
					{											
						if(currMemberId > 0 )
						{
							foreach(object attr in hta.Keys)
							{
								string strName = attr.GetType().Name;
								string FullName = attr.GetType().ToString();
								string strAllValues = hta[attr].ToString();

								DocumentationHelper.Update_DOC_ATTRIBUTE(strName,FullName, 0, currMemberId, strAllValues);
								F_A_COUNT++;
							}
						
						}	// if hta.Count > 0
					}					
				}
			}
			catch(Exception ex)
			{
				//VSF
				string msg = String.Format("On LoadFieldsAttrToDBFromEntity() Curr Member Type: {0}, last MemberId={1}, err: {2}",type.ToString(), currMemberId, ex.Message);
				CodeHelper.WriteEventLog(msg);
				return false;
			}
			
			return true;//(ht.Count > 0);
		}


	
		//Properties		
		public static bool LoadPropertiesToDbFromEntity(Type type, int EntityId, EntityType em, bool bNotSystemType)
		{
			string temp = "";
			
			Hashtable ht = new Hashtable();
			string strList = "";

				if(type == null) 
					return false;
				// 
				PropertyInfo [] piArr = type.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

				foreach(PropertyInfo pi in piArr)
				{
					if(bNotSystemType && pi.PropertyType.FullName.IndexOf("System.") ==0)
						continue;

					temp += String.Format("P: {0} - {1} <br>", pi.PropertyType.ToString(),  pi.Name);				
					
					try
					{
						ht.Add(pi.Name, pi.PropertyType);
					}
					catch(Exception ex)
					{
						string msg = String.Format("EntityId {0} P {1} error: {2}", EntityId, pi.Name, ex.Message);
						CodeHelper.WriteEventLog(msg);
						continue;
					}

					strList = GetAllTypes(pi.PropertyType, ",");

					DocumentationHelper.Update_DOC_MEMBER(pi.Name, pi.PropertyType.ToString(), strList, MEMBER_PROPERTY, EntityId);
				}


			return true;//(ht.Count > 0);
		}
	
		public static bool LoadPropertiesAttrToDbFromEntity(Type type, int EntityId, EntityType em, bool bNotSystemType)
		{
			string temp = "";
			
			Hashtable ht = new Hashtable();
			string strList = "";
			int currMemberId = 0;

			if(type == null) 
				return false;

			try
			{				
			// 
			PropertyInfo [] piArr = type.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

				foreach(PropertyInfo pi in piArr)
				{
					if(bNotSystemType && pi.PropertyType.FullName.IndexOf("System.") ==0)
						continue;

					temp += String.Format("F: {0} - {1} <br>", pi.PropertyType.ToString(),  pi.Name);				
					
					try
					{
						ht.Add(pi.Name, pi.PropertyType);
					}
					catch(Exception ex)
					{
						string msg = String.Format("EntityId {0} P {1} error: {2}", EntityId, pi.Name, ex.Message);
						CodeHelper.WriteEventLog(msg);
						continue;
					}

					strList = GetAllTypes(pi.PropertyType, ",");

					//get Prop Attr VS
					object[] attArr = pi.GetCustomAttributes(true);

					Hashtable hta = ExplainAttributesForDb(attArr);
					
					currMemberId = Update_DOC_MEMBER_GetId(pi.Name, pi.PropertyType.ToString(), strList, MEMBER_PROPERTY, EntityId);

					if(hta.Count > 0)
					{
						
					
						//VSPP
						if(currMemberId > 0  )
						{
							foreach(object attr in hta.Keys)
							{
								string strName = attr.GetType().Name;
								string FullName = attr.GetType().ToString();
								string strAllValues = hta[attr].ToString();

								DocumentationHelper.Update_DOC_ATTRIBUTE(strName,FullName, 0, currMemberId, strAllValues);
								P_A_COUNT++;
							}
						
						}	// if hta.Count > 0
					}

					//currMemberId = DocumentationHelper.Update_DOC_MEMBER_GetId(pi.Name, pi.PropertyType.ToString(), strList, MEMBER_PROPERTY, EntityId);
				}			
			}
			catch(Exception ex)
			{
				//VSF
				string msg = String.Format("On LoadPropertiesAttrToDbFromEntity() Curr Member Type: {0}, last MemberId={1}, err: {2}",type.ToString(), currMemberId, ex.Message);
				CodeHelper.WriteEventLog(msg);
				return false;
			}


			return true;//(ht.Count > 0);
		}

		
		
		
		//LoadMembersToDbFromEntity
		public static bool LoadMembersToDbFromEntity(Type type, int EntityId, EntityType em, bool bNotSystemType)
		{

			return true;
		}

		#endregion Members

		#region DB


		public static void LoadAllRecordsToDB()
		{
			// load all Entities with attrs
			if(LoadAllEntitiesToDB())
			{
				//load all Members with attrs
				DocumentationHelper.LoadAllMembersToDB(false);
			}

		}

		public static DataSet GetDbRecords(string strTable)
		{			
			DataSet ds = null;			

			if(!IsDocTable(strTable)) return ds;

			switch(strTable)
			{
				case DocumentationHelper.DOC_ATTRIBUTE:
					ds = DocumentationHelper.GetAttributes(0, 0);
					break;

				case DocumentationHelper.DOC_MEMBER:

					ds = DocumentationHelper.GetMembers(0);
					break;

				case DocumentationHelper.DOC_ENTITY:
					ds = DocumentationHelper.GetEntities();
					break;		
			}

			return ds;

		}

		public static void DeleteAllRecordsFromSystem()
		{

			DeleteRecordsFromSystem(DOC_ENTITY);
		}

		public static void DeleteRecordsFromSystem(string strTable)
		{
			try
			{
				switch(strTable)
				{
					case DocumentationHelper.DOC_ATTRIBUTE:
						break;

					case DocumentationHelper.DOC_MEMBER:
						DeleteRecordsFromSystem(DOC_ATTRIBUTE);
						break;

					case DocumentationHelper.DOC_ENTITY:
						DeleteRecordsFromSystem(DOC_MEMBER);
						break;

					default:

						return;
				}

				//remove from cache
				RemoveTableFromCache = strTable;
			
				string strSql = "DELETE FROM " + strTable;

				SqlHelper.ExecuteNonQuery(ConnectionString, CommandType.Text, strSql);
			}
			catch(Exception ex)
			{
				CodeHelper.WriteEventLog(ex.Message);
				string msg = String.Format("On delete {0}: {1}",strTable, ex.Message);
				throw new Exception(msg);

			}
		}

		public static DataSet GetEntities()
		{
			DataSet ds = null;
			string strTestSql = "";			 

			try
			{

				string strSP = "USP_DOC_ENTITY_GET";	
		
				strTestSql = strSP + " " + 
					CodeHelper.FormatParm("", true)  ;

				ds = SqlHelper.ExecuteDataset(ConnectionString, strSP,
					new SqlParameter("@" + FULLNAME, DBNull.Value)
					);
			}
			catch(Exception ex)
			{
				string strErr = "Db Error on " + strTestSql + ": " + ex.Message;
				throw new Exception(strErr);
			}

			return ds;
			
		}

		/// <summary>
		/// @Name varchar(100),
		/// @FullName varchar(100),
		/// @BaseNameSpaces varchar(500),
		/// @Type varchar(5),
		/// @Assembly varchar(50)
		/// </summary>	
		public static void Update_DOC_ENTITY(string Name, string FullName, string BaseNameSpaces,  string EntityType, string Assembly)
		{			
			string strTestSql = "";
			string strSP = "USP_DOC_ENTITY_SET";

			//debug
			strTestSql = strSP + " " + 
				CodeHelper.FormatParm(Name, true) + "," +
				CodeHelper.FormatParm(FullName, true) + "," +
				CodeHelper.FormatParm(BaseNameSpaces, true) + "," + 
				CodeHelper.FormatParm(EntityType, true) + "," +
				CodeHelper.FormatParm(Assembly, true) ;
			
			SqlHelper.ExecuteNonQuery(ConnectionString, strSP,
				new SqlParameter("@" + NAME, Name),
				new SqlParameter("@" + FULLNAME, FullName),
				new SqlParameter("@" + BASENAMESPACES, BaseNameSpaces),
				new SqlParameter("@" + TYPE, EntityType),
				new SqlParameter("@" + ASSEMBLY, Assembly)
				);
		
//			}
//			catch(Exception ex)
//			{
//				CodeHelper.WriteEventLog(ex.Message);
//			}				
		}

		
		public static int Update_DOC_ENTITY_GetId(string Name, string FullName, string BaseNameSpaces,  string EntityType, string Assembly)
		{			
			string strTestSql = "";
			string strSP = "USP_DOC_ENTITY_SET";

			//debug
			strTestSql = strSP + " " + 
				CodeHelper.FormatParm(Name, true) + "," +
				CodeHelper.FormatParm(FullName, true) + "," +
				CodeHelper.FormatParm(BaseNameSpaces, true) + "," + 
				CodeHelper.FormatParm(EntityType, true) + "," +
				CodeHelper.FormatParm(Assembly, true) ;
			
			int newRowId = Convert.ToInt32(SqlHelper.ExecuteScalar(ConnectionString, strSP,
				new SqlParameter("@" + NAME, Name),
				new SqlParameter("@" + FULLNAME, FullName),
				new SqlParameter("@" + BASENAMESPACES, BaseNameSpaces),
				new SqlParameter("@" + TYPE, EntityType),
				new SqlParameter("@" + ASSEMBLY, Assembly)
				)
				);
		
			return 	newRowId;		
		}

		

		public static DataSet GetMembers(int EntityId)
		{
			DataSet ds = null;
			string strTestSql = "";			 

			try
			{

				string strSP = "USP_DOC_MEMBER_GET";	
		
				strTestSql = strSP + " " + 
					CodeHelper.FormatParm(EntityId.ToString(), false)  ;

				ds = SqlHelper.ExecuteDataset(ConnectionString, strSP,
					new SqlParameter("@" + ENTITYID, EntityId)
					);
			}
			catch(Exception ex)
			{
				string strErr = "Db Error on " + strTestSql + ": " + ex.Message;
				throw new Exception(strErr);
			}

			return ds;
			
		}

		/// <summary>
		/// USP_DOC_MEMBER_SET
		/// @Name varchar(100),
		/// @Type varchar(3),
		/// @FullName varchar(100),
		/// @BaseNameSpaces varchar(500),
		/// @EntityId int
		/// </summary>
		public static void Update_DOC_MEMBER(string Name, string FullName, string BaseNameSpaces,  string MemberType, int EntityId)
		{
			string strTestSql = "";
			string strSP = "USP_DOC_MEMBER_SET";

			//debug
			strTestSql = strSP + " " + 
				CodeHelper.FormatParm(Name, true) + "," +
				CodeHelper.FormatParm(MemberType, true) + "," +
				CodeHelper.FormatParm(FullName, true) + "," +
				CodeHelper.FormatParm(BaseNameSpaces, true) + "," + 				
				CodeHelper.FormatParm(EntityId.ToString(), false) ;
		
			SqlHelper.ExecuteNonQuery(ConnectionString, strSP,
				new SqlParameter("@" + NAME, Name),
				new SqlParameter("@" + TYPE, MemberType),
				new SqlParameter("@" + FULLNAME, FullName),
				new SqlParameter("@" + BASENAMESPACES, BaseNameSpaces),				
				new SqlParameter("@" + ENTITYID, EntityId)
				);
			
		}

		
		public static int Update_DOC_MEMBER_GetId(string Name, string FullName, string BaseNameSpaces,  string MemberType, int EntityId)
		{
			string strTestSql = "";
			string strSP = "USP_DOC_MEMBER_SET";

			//debug
			strTestSql = strSP + " " + 
				CodeHelper.FormatParm(Name, true) + "," +
				CodeHelper.FormatParm(MemberType, true) + "," +
				CodeHelper.FormatParm(FullName, true) + "," +
				CodeHelper.FormatParm(BaseNameSpaces, true) + "," + 				
				CodeHelper.FormatParm(EntityId.ToString(), false) ;
		
			int newRowId = Convert.ToInt32(SqlHelper.ExecuteScalar(ConnectionString, strSP,
				new SqlParameter("@" + NAME, Name),
				new SqlParameter("@" + TYPE, MemberType),
				new SqlParameter("@" + FULLNAME, FullName),
				new SqlParameter("@" + BASENAMESPACES, BaseNameSpaces),				
				new SqlParameter("@" + ENTITYID, EntityId)
				)
				);
	
				return 	newRowId;		
		}

		
		
		public static DataSet GetAttributes(int EntityId, int MemberId)
		{
			DataSet ds = null;
			string strTestSql = "";			 

			try
			{
				string strSP = "USP_DOC_ATTRIBUTE_GET";	
		
				strTestSql = strSP + " " + 
					CodeHelper.FormatParm(EntityId.ToString(), false)  ;

				ds = SqlHelper.ExecuteDataset(ConnectionString, strSP,
					new SqlParameter("@" + ENTITYID, EntityId),
					new SqlParameter("@" + MEMBERID, MemberId)
					);
			}
			catch(Exception ex)
			{
				string strErr = "Db Error on " + strTestSql + ": " + ex.Message;
				throw new Exception(strErr);
			}

			return ds;
			
		}

		/// <summary>
		/// USP_DOC_ATTRIBUTE_SET
		/// @Name varchar(50),
		/// @FullName varchar(100),
		/// @EntityId int,
		/// @MemberId int,
		/// @UniqueValue varchar(100),
		/// @AllValues varchar(1000)
		/// </summary>
		/// <param name="Name"></param>
		/// <param name="FullName"></param>
		/// <param name="BaseNameSpaces"></param>
		/// <param name="MemberType"></param>
		/// <param name="EntityId"></param>
		public static void Update_DOC_ATTRIBUTE(string Name, string FullName, int EntityId,  int MemberId,  string AllValues)
		{
			//validation : only one Id must valid
			if((EntityId > 0 && !(MemberId > 0)) || (MemberId > 0 && !(EntityId > 0)))
			{
				
					string strTestSql = "";
					string strSP = "USP_DOC_ATTRIBUTE_SET";

					//debug
					strTestSql = strSP + " " + 
						CodeHelper.FormatParm(Name, true) + "," +					
						CodeHelper.FormatParm(FullName, true) + "," +
						CodeHelper.FormatParm(EntityId.ToString(), false) + "," + 				
						CodeHelper.FormatParm(MemberId.ToString(), false) + "," +					
						CodeHelper.FormatParm(AllValues, true) ;
			
					SqlHelper.ExecuteNonQuery(ConnectionString, strSP,
						new SqlParameter("@" + NAME, Name),
						new SqlParameter("@" + FULLNAME, FullName),									
						new SqlParameter("@" + ENTITYID, EntityId),
						new SqlParameter("@" + MEMBERID, MemberId),							
						new SqlParameter("@" + ALLVALUES, AllValues)
						);
		
					
			}
			else
			{
				string msg = String.Format("Update_DOC_ATTRIBUTE(): Attribute {0} has wrong Ids: EntityId={1}, MemberId={2}",
				FullName, EntityId, MemberId);
//				CodeHelper.WriteEventLog(msg);
				throw new Exception(msg);
			}
		}

		#endregion DB

		#region Explain Page Data

		//USP_DOC_EXPLAIN_ENTITY_ATTRIBUTES
		public static DataView GetExplainEntityAttributes(int EntityId)
		{
			DataView dv = new DataView();
			DataSet ds = null;
			string strTestSql = "";			 

			try
			{

				string strSP = "USP_DOC_EXPLAIN_ENTITY_ATTRIBUTES";	
		
				strTestSql = strSP + " " + 
					CodeHelper.FormatParm(EntityId.ToString(), false)  ;

				ds = SqlHelper.ExecuteDataset(ConnectionString, strSP,
					new SqlParameter("@" + ENTITYID, EntityId)
					);
			}
			catch(Exception ex)
			{
				string strErr = "Db Error on " + strTestSql + ": " + ex.Message;
				throw new Exception(strErr);
			}

			if(ds != null && ds.Tables.Count > 0)
				dv = ds.Tables[0].DefaultView;

			return dv;
			
		}

		
		//USP_DOC_EXPLAIN_ENTITY_ATTRIBUTES
		public static DataView GetExplainEntityMemberAttributes(int EntityId, bool bOnlyAttr)
		{
			DataView dv = new DataView();
			DataSet ds = null;
			string strTestSql = "";	
			
			try
			{
				string strSP = "USP_DOC_EXPLAIN_ENTITY_MEMBER_ATTRIBUTES";	
		
				strTestSql = strSP + " " + 
					CodeHelper.FormatParm(EntityId.ToString(), false)  ;

				ds = SqlHelper.ExecuteDataset(ConnectionString, strSP,
					new SqlParameter("@" + ENTITYID, EntityId),
					new SqlParameter("@" + ONLYATTR, bOnlyAttr)
					);
			}
			catch(Exception ex)
			{
				string strErr = "Db Error on " + strTestSql + ": " + ex.Message;
				throw new Exception(strErr);
			}

			if(ds != null && ds.Tables.Count > 0)
				dv = ds.Tables[0].DefaultView;

			return dv;
			
		}

		

		/// <summary>
		/// Get DataSet with page info
		/// </summary>
		/// <param name="strNameSpace"></param>
		/// <returns></returns>
		public static DataSet GetExplainPageDS(int EntityId)
		{
			DataSet ds = null;
			string strTestSql = "";			 

			try
			{

				string strSP = "USP_DOC_EXPLAIN_PAGE";	
		
				strTestSql = strSP + " " + 
					CodeHelper.FormatParm(EntityId.ToString(), false)  ;

				ds = SqlHelper.ExecuteDataset(ConnectionString, strSP,
					new SqlParameter("@" + ENTITYID, EntityId)
					);
			}
			catch(Exception ex)
			{
				string strErr = "Db Error on " + strTestSql + ": " + ex.Message;
				throw new Exception(strErr);
			}

			return ds;
			
		}

		public static DataView GetExplainPageDV(int EntityId, ExplainPageTable em )
		{
			DataView dv = new DataView();
			DataSet ds = GetExplainPageDS(EntityId);
			int iTable = (int)em;

			if(ds != null && ds.Tables[iTable] !=null)
				dv = ds.Tables[iTable].DefaultView;

			return dv;

		}

		public static string ExplainPageOutput(int EntityId)
		{
			
			string text = "";
			ExplainPageTable em = ExplainPageTable.DOC_ENTITY;

			text += ExplainPageOutput(EntityId, em) + NEW_LINE;
			
			text += ExplainPageOutput(EntityId, ExplainPageTable.UDF_DOC_PAGE_ENTITIES) + NEW_LINE;

			//text += ExplainPageOutput(EntityId, ExplainPageTable.UDF_DOC_DC_MEMBER_ATTRIBUTES_BY_PAGE) + NEW_LINE;

			return text;

		}

		public static string ExplainPageOutput(int EntityId, ExplainPageTable em )
		{
			DataView dv = null;
			string errMsg = String.Format("Error in ExplainPageOutput({0}) for result set {1}", EntityId, em.ToString());
			DataRowView row = null;
			string text = "";
			string temp = "";
			string col = "";
			string val = "";
			string filter = "";
			int currEntityId = 0;

			switch(em)
			{
				case ExplainPageTable.DOC_ENTITY:
					dv = GetExplainPageDV(EntityId, em);
					//
					if(dv==null || dv.Count == 0)
						return text += errMsg;

					row = dv[0];
					col = DOCTableFields.Name.ToString();
					string PageName = row[col].ToString();
					 
					text += String.Format("<B>Page</B>: {0}", PageName ) + DocumentationHelper.NEW_LINE;
					
					col = BASENAMESPACES;	
					
					val = row[col].ToString();
					val = val.Replace(",", " - ");
					
					text += String.Format("Page NameSpaces: {0}", val ) + NEW_LINE;
				
					break;

				case ExplainPageTable.UDF_DOC_PAGE_ENTITIES:
					dv = GetExplainPageDV(EntityId, em);
					//
					if(dv==null )
						return text += errMsg;

					if(dv.Count == 0)
						return text;

					string col_FN = DOCTableFields.FullName.ToString();

					// Pring DataClasses
					filter = String.Format("{0}='{1}'","EntityType",ENTITY_DATACLASS);
					dv.RowFilter = filter; 

					if(dv.Count > 0)
					{
						text += String.Format("<B>Page DataClasses</B>: ---") + DocumentationHelper.NEW_LINE;
						for(int i =0;i<dv.Count;i++)
						{
							row = dv[i];
		
							text += String.Format("*** DataClass = <B>{0}</B> , FullName = {1}", 
								row["MemberName"].ToString(), row[col_FN].ToString())
								+ DocumentationHelper.NEW_LINE;

							gParentEntityId = EntityId;
							//print attr for dataclass
							currEntityId = Convert.ToInt32(row[ENTITYID]);
							text += ExplainPageOutput(currEntityId, ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_ATTRIBUTES) + NEW_LINE;

							//print list all Page members (Prop or field) 
							//that have same name as DC member having a custom attr
							text += ExplainPageOutput(currEntityId, ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_MEMBER_ATTRIBUTES) + NEW_LINE;

							gParentEntityId = 0;	//reset global Parent EntityId
						}
					}

					// Pring DataCollections
					filter = String.Format("{0}='{1}'","EntityType",DocumentationHelper.ENTITY_DATACOLLECTION);
					dv.RowFilter = filter; 

					if(dv.Count > 0)
					{
						text += String.Format("<B>Page DataCollections</B>: ---") + DocumentationHelper.NEW_LINE;
						
						for(int i =0;i<dv.Count;i++)
						{
							row = dv[i];
							text += String.Format("*** DataCollection = <B>{0}</B> , FullName = {1}", 
								row["MemberName"].ToString(), row[col_FN].ToString())
								+ DocumentationHelper.NEW_LINE;

							//print attr for datacollection
							currEntityId = Convert.ToInt32(row[ENTITYID]);
							text += ExplainPageOutput(currEntityId, ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_ATTRIBUTES) + NEW_LINE;

						}
					}

					// Pring UserControls
					filter = String.Format("{0}='{1}'","EntityType",DocumentationHelper.ENTITY_USERCONTROL);
					dv.RowFilter = filter; 

					if(dv.Count > 0)
					{
						text += String.Format("<B>Page UserControls</B>: ---") + DocumentationHelper.NEW_LINE;
						for(int i =0;i<dv.Count;i++)
						{
							row = dv[i];
							text += String.Format("*** UserControl = <B>{0}</B> , FullName = {1}", 
								row["MemberName"].ToString(), row[col_FN].ToString())
								+ DocumentationHelper.NEW_LINE;

							//print attr for usercontrol
							currEntityId = Convert.ToInt32(row[ENTITYID]);
							text += ExplainPageOutput(currEntityId, ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_ATTRIBUTES) + NEW_LINE;

						}
					}

					break;

				case ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_ATTRIBUTES:
					dv = GetExplainEntityAttributes(EntityId);
					//
					if(dv==null )
						return text += errMsg;

					//string col_MN = "MemberName";
					string col_AN = "AttrName";
					//string col_AV = DocumentationHelper.ALLVALUES;

					//print all attributes for Page entity
					if(dv.Count > 0)
					{						
						for(int i =0;i<dv.Count;i++)
						{
							row = dv[i];
		
							text += String.Format("------ AttributeName = {0} ", 
								 row[col_AN].ToString())
								+ DocumentationHelper.NEW_LINE;
							//all attr values
							val = row[ALLVALUES].ToString();
							val = val.Replace(ATTR_PIPE_DEL, " ");
							text += String.Format("--------- {0} ",val) + NEW_LINE; 

						}
					}

					break;

				case ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_MEMBER_ATTRIBUTES:					

					dv = GetExplainEntityMemberAttributes(EntityId, true);
					//return only members sorted by name and member type desc (Prop then Field)
					//prop and field with same name are considered as one member

					if(dv==null )
						return text += errMsg;					

					string colMN = "MemberName";
					string colMT = "MemberType";
					string colEN = "EntityName";
					//string colAV = ALLVALUES;
					string valMN = "";
					bool bMemberNameChanged = true;

					string sort = String.Format("{0},{1},{2} DESC",colEN,colMN, colMT);
					dv.Sort = sort;

					//print all attributes for Entity Member 
					if(dv.Count > 0)
					{				
						if(gParentEntityId == 0)
							return text += errMsg + " Error detail: no page EntityId";

						for(int i =0;i<dv.Count;i++)
						{
							row = dv[i];

							bMemberNameChanged = !(valMN.ToUpper() == row[colMN].ToString().ToUpper());
							valMN = row[colMN].ToString();

							//check if page has member with same name else not print
							bool bBound = IsParentHasBoundMember(gParentEntityId, EntityId, valMN);	
							if(!bBound)
								continue;



							if(bMemberNameChanged)
							{								
								text += String.Format("<BR>------ MemberName = <B>{0}</B> ", 
									 valMN)
									+ DocumentationHelper.NEW_LINE;
								text += String.Format("--------- ");
							}

							//all attr values
							val = row[ALLVALUES].ToString();
							val = val.Replace(ATTR_PIPE_DEL, " ");

							//not print IsRequired=False
							//val = val.Replace("IsRequired=False", "");

							text += String.Format(" {0} ",val); 
						}
						text += NEW_LINE;
					}

					break;

				default:
					text += errMsg + NEW_LINE;
					break;

			}

			return text;


		}

		public static bool IsParentHasBoundMember(int parentEntityId, int EntityId, string MemberName)
		{
			DataRow row = null;			
			DataSet ds = MembersDS;

			string filter = string.Format("{0}={1}",
				DocumentationHelper.ENTITYID, parentEntityId);

			if(RowCount(ds) > 0)
			{
				DataRow[] drArr = ds.Tables[0].Select(filter);

				for(int i = 0; i<drArr.Length;i++)
				{
					string test = drArr[i][NAME].ToString();
					if(drArr[i][NAME].ToString().ToUpper() == MemberName.ToUpper())
						return true;
				}
				
			}
			
			return false;
		}


		//Entity 

		//public string VS05

		public static string ExplainEntityOutput(int EntityId)
		{
			string text = "";			

			text += ExplainEntityOutput(EntityId, ExplainPageTable.DOC_ENTITY) + NEW_LINE;

			text += ExplainEntityOutput(EntityId, ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_ATTRIBUTES) + NEW_LINE;
			
			text += ExplainEntityOutput(EntityId, ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_MEMBER_ATTRIBUTES) + NEW_LINE;

			return text;

		}

		/// <summary>
		/// For 3 entity types: DataClass(DC), UserControl(UC), DataCollection(DCC)
		/// </summary>
		/// <param name="EntityId"></param>
		/// <param name="em"></param>
		/// <returns></returns>
		public static string ExplainEntityOutput(int EntityId, ExplainPageTable em )
		{
			DataView dv = null;
			string errMsg = String.Format("Error in ExplainEntityOutput({0}) for result set {1}", EntityId, em.ToString());
			DataRowView row = null;
			string text = "";
			string temp = "";
			string col = "";
			string val = "";
			string filter = "";
			int currEntityId = 0;

			switch(em)
			{
				case ExplainPageTable.DOC_ENTITY:
					//type general entity info: name, base namespaces
					
					DataRow dataRow = GetEntityById(EntityId);
					if(dataRow == null)
						return text += errMsg;

					
					string EntityName = dataRow[NAME].ToString();
					string strEntityTypeCode = dataRow[TYPE].ToString();
					string strEntityType = "";
					
					switch(strEntityTypeCode)
					{
						case ENTITY_DATACLASS:
							strEntityType = "DataClass";
							break;

						case DocumentationHelper.ENTITY_DATACOLLECTION:
							strEntityType = "DataCollection";
							break;

						case DocumentationHelper.ENTITY_USERCONTROL:
							strEntityType = "UserControl";
							break;

						default:
							return text += errMsg + "; wrong entity type " + strEntityTypeCode;
					}
					 
					text += String.Format("<B>{0}</B>: {1}",strEntityType, EntityName ) + NEW_LINE;
					
					col = BASENAMESPACES;	
					
					val = dataRow[col].ToString();
					val = val.Replace(",", " - ");
					
					text += String.Format("{0} NameSpaces: {1}", strEntityType, val ) + NEW_LINE;
				
					break;

				
				case ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_ATTRIBUTES:
					//type attributes belong to entity (if there are)
					dv = GetExplainEntityAttributes(EntityId);
					
					if(dv==null )
						return text += errMsg;

					
					string col_AN = "AttrName";
					
					//print all attributes belong to entity
					if(dv.Count > 0)
					{						
						for(int i =0;i<dv.Count;i++)
						{
							row = dv[i];
		
							text += String.Format("------ AttributeName = {0} ", 
								row[col_AN].ToString())
								+ DocumentationHelper.NEW_LINE;
							//all attr values
							val = row[ALLVALUES].ToString();
							val = val.Replace(ATTR_PIPE_DEL, " ");
							text += String.Format("--------- {0} ",val) + NEW_LINE; 

						}
					}

					break;
					
				case ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_MEMBER_ATTRIBUTES:
					//type all members of the entity with type
					//also any attached info (attr)
					Hashtable ht = new Hashtable();
					bool bUserControl = false;

					//check entity type, if UC then do different
					bUserControl=(DocumentationHelper.GetEntityTypeEmFromId(EntityId) == EntityType.usercontrol);
					
					//false - show all mermbers 
					// true - only members with attr
					dv = GetExplainEntityMemberAttributes(EntityId, false);
					// VS05					
					/*
					EntityId int, 
					EntityName varchar(100),
					EntityType varchar(5),
					MemberId int,
					MemberName varchar(100),
					FullName varchar(100),
					BaseNameSpaces varchar(1000),
					MemberType varchar(5),
					AttrName varchar(50),
					AllValues varchar(1000)
					 */
					if(dv==null )
						return text += errMsg;					

					string colMN = "MemberName";
					string colMT = "MemberType";
					string colEN = "EntityName";

					string colMFN = "FullName"; 
					string valMFN = "";
					string colMBNS = "BaseNameSpaces";

					string valMN = "";
					bool bMemberNameChanged = true;

					string sort = String.Format("{0},{1},{2} DESC",colEN,colMN, colMT);
					dv.Sort = sort;
					
					if(bUserControl)
					{						
						for(int i=0;i<dv.Count;i++)
						{	
							valMN = dv[i][colMN].ToString();
							valMFN = dv[i][FULLNAME].ToString(); 
							
							if(GetEntityTypeEmFromFullName(valMFN) == EntityType.dataclass)
							{

								// to prevent duplicate dataclass output - store name in hashtable
								if(ht.Contains(valMFN))
									continue;
								else
									ht.Add(valMFN, valMN);
 
								currEntityId = GetEntityIdFromNameType( valMN, EntityType.dataclass);

								if(currEntityId > 0)
								{
									gParentEntityId = EntityId;

									text += String.Format("***DataClass = <B>{0}</B>, FullName = {1}" , valMN, valMFN) + NEW_LINE;

									//print attr for dataclass
									text += ExplainPageOutput(currEntityId, ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_ATTRIBUTES) + NEW_LINE;

									//print list all Page members (Prop or field) 
									//that have same name as DC member having a custom attr
									text += ExplainPageOutput(currEntityId, ExplainPageTable.USP_DOC_EXPLAIN_ENTITY_MEMBER_ATTRIBUTES) + NEW_LINE;

									gParentEntityId = 0;	//reset global Parent EntityId

								}
									
							}
							
						}

					}
					
					// this section will print all members: name, FullName and cust attributes (if exist)
					//excluding printed dataclasses (checking ht)
					
					//return members sorted by name and member type desc (Prop then Field)
					//prop and field with same name are considered as one member
					//print Entity Members with attr or without 

					text += "*** All Members:" + NEW_LINE;

					if(dv.Count > 0 )
					{						
						for(int i =0;i<dv.Count;i++)
						{
							row = dv[i];

							bMemberNameChanged = !(valMN.ToUpper() == row[colMN].ToString().ToUpper());
							valMN = row[colMN].ToString();	//Member Name
							valMFN = row[colMFN].ToString();	// Member FullName

							//do not print dataclasses that are in ht
							if(ht.Contains(valMFN))
								continue;

							if(bMemberNameChanged)
							{
								valMFN = 
								text += String.Format("<BR>------ MemberName = <B>{0}</B> Type={1}", 
									valMN, valMFN)
									+ DocumentationHelper.NEW_LINE;								
							}

							//all attr values
							val = row[ALLVALUES].ToString();

							if(val.Length > 0)
							{
								if(bMemberNameChanged)
									text += String.Format("--------- ");

								val = val.Replace(ATTR_PIPE_DEL, " ");
								text += String.Format(" {0} ",val); 
							}

						}	//for

						text += NEW_LINE;
					}

					break;

				default:
					text += errMsg + NEW_LINE;
					break;

			}

			return text;
		}
		
		#endregion Explain Page Data

		#region IO

		/// <summary>
		/// This is AA specific !!!!!!!
		/// </summary>
		/// <param name="strNameSpace"></param>
		/// <returns></returns>
		public static string GetDllFromNamespace(string strNameSpace)
		{
			string file = "";

			if(strNameSpace.IndexOf(AAWEB_NAMESPACE) == 0)
			{
				file = "ActiveAdviceWeb";
			}

			if(strNameSpace.IndexOf(AADATALAYER_NAMESPACE) == 0)
			{
				file = "DataLayer";	
			}

			//NetsoftUSA.InfragisticsWeb
			if(strNameSpace.IndexOf(NS_INFRAWEB_NAMESPACE) == 0)
			{
				file = NS_INFRAWEB_NAMESPACE;	
			}

			//NetsoftUSA.WebForms
			if(strNameSpace.IndexOf(NS_WEBFORMS_NAMESPACE) == 0)
			{
				file = NS_WEBFORMS_NAMESPACE;	
			}

			//NetsoftUSA.WebControls
			if(strNameSpace.IndexOf(NS_WEBCONTROLS_NAMESPACE) == 0)
			{
				file = NS_WEBCONTROLS_NAMESPACE;	
			}
			
			if(strNameSpace.IndexOf(NS_SECURITY_NAMESPACE) == 0)
			{
				file = NS_SECURITY_NAMESPACE;	
			}
			
			file = file + ".dll";
									
			return file;
		}


		public static string GetAssemblyFile(string strNameSpace)
		{
			string file = "";

			file = GetDllFromNamespace(strNameSpace);
			
			file = GetMapPath(".") + @"\bin\" + file;
			if(File.Exists(file))
				return file;
						
			return "";
		}

		public static string GetMapPath(string strPath)
		{
			string temp = "";
			try
			{
				temp = HttpContext.Current.Server.MapPath(strPath);
			}
			catch(Exception ex)
			{
				temp = ex.Message;
			}
			return temp;
			
		}

		#endregion IO

		#region DataSet Methods
		
		public static int RowCount(DataSet ds)
		{
			int rc = 0;
			if(ds != null && ds.Tables.Count > 0 )
			{
				rc = ds.Tables[0].Rows.Count;
				return rc;
			}

			return rc ;
		}

		#endregion DataSet Methods

		#region Common

		public static bool IsDocTable(string strTable)
		{
			switch(strTable)
			{
				case DocumentationHelper.DOC_ATTRIBUTE:
					return true;
					break;

				case DocumentationHelper.DOC_ENTITY:
					return true;
					break;

				case DocumentationHelper.DOC_MEMBER:
					return true;
					break;
			}
			string msg = String.Format("{0} is not DOC Table.", strTable);
			CodeHelper.WriteEventLog(msg);
			return false;

		}



		public static string GetEntityTypeConstFromBaseFullName(string strOnlyType)
		{
			switch(strOnlyType)
			{
				case DocumentationHelper.WEB_PAGE:
					return DocumentationHelper.ENTITY_PAGE;
					break;
				case DocumentationHelper.SYS_COLLECTIONBASE:
					return DocumentationHelper.ENTITY_DATACOLLECTION;
					break;
				case DocumentationHelper.NS_BASEDATACLASS:
					return DocumentationHelper.ENTITY_DATACLASS;
					break;
				case DocumentationHelper.WEB_USERCONTROL:
					return DocumentationHelper.ENTITY_USERCONTROL;
					break;

				default:
					return "";

			}
		}

		public static bool IsPage(Type type)
		{
			Type t = GetSystemBaseType(type);

			//"System.Web.UI.Page"
			if(t != null && t.FullName == WEB_PAGE )
				return true;

			return false;
		}

		public static bool IsDataCollection(Type type)
		{
			Type t = GetSystemBaseType(type);
			
			//"System.Collections.CollectionBase"
			if(t != null && t.FullName == SYS_COLLECTIONBASE)
				return true;

			return false;
		}

		public static bool IsUserControl(Type type)
		{
			Type t = GetSystemBaseType(type);
			
			//"System.Web.UI.UserControl"
			if(t != null && t.FullName == WEB_USERCONTROL)
				return true; 

			return false;
		}

		public static bool IsDataClass(Type type)
		{
			if(IsType(type, NS_BASEDATACLASS))
				return true;

			return false;
		}

		public static bool IsFullNameType(Type type, string strType)
		{
			try
			{
				if(type == null) 
					return false;

				if(type.FullName == strType.Trim())
					return true;			
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
			}

			return false;
		}

		
		public static bool IsType(Type type, string strFullType)
		{	
			Type t = type;
			try
			{
				//check full name only
				if(strFullType.IndexOf(".") == -1)
					return false;

				if(type == null) 
					return false;

				if(type.FullName == strFullType)
					return true;

				if(type.FullName.IndexOf("System") == 0)
					return false;

				int count = 0;

				while(true || count < 10)
				{
					t = t.BaseType;

					if(t == null)
						return false;

					if(t.FullName == strFullType)
						return true;
			
					if(t.FullName.IndexOf("System") == 0)
						return false;

					count++;	//to be on save side

				}
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
			}
			return false;

		}

		public static Type GetTypeFromFullName(string strFullName)
		{
			Type type = null;
			
			if(strFullName.Trim().Length == 0 || strFullName.IndexOf(".") == -1)
				return null;

			string file = GetAssemblyFile(strFullName);

			if(File.Exists(file))
			{
				Assembly a = Assembly.LoadFrom(file);

				if(a != null)
					type = a.GetType(strFullName);	
			}

			return type;
		}

		public static Type GetSystemBaseType(Type type)
		{
			try
			{
				if(type == null) 
					return null;

				if(type.FullName.IndexOf("System") == 0)
					return type;

				Type t = type.BaseType;

				if(t == null)
					return t;
			
				if(t.FullName.IndexOf("System") == 0)
					return t;

				return GetSystemBaseType(t);
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
			}
			return null;

		}


		
		public static string GetAllTypes(Type type, string del)
		{
			string temp = "";
			Type t = type;

			try
			{
				if(type == null) 
					return "";

				temp = type.FullName;

				if(type.FullName.IndexOf("System") == 0)
					return temp;

				int count = 0;

				while(true || count < 10)
				{
					t = t.BaseType;
					if(t == null)
						return temp;
			
					temp += del + t.FullName;

					if(t.FullName.IndexOf("System") == 0)
					{
						return temp ;
					}
					
					count++;
				}				
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
			}

			return temp;
		}

		public static string GetEntityFullName(string EntityName, EntityType em)
		{
			string FullName = "";
			
			switch(em)
			{	
				case EntityType.page:
					FullName = AAWEB_NAMESPACE + EntityName;
					break;

				case EntityType.dataclass:
					FullName = AADATALAYER_NAMESPACE + EntityName;
					break;

				case EntityType.datacollection:
					FullName = AADATALAYER_NAMESPACE + EntityName;
					break;

				case EntityType.usercontrol:
					FullName = AAWEB_NAMESPACE + EntityName;
					break;

			}
			return FullName;
		}

		public static int GetEntityIdFromNameType(string EntityName, EntityType em)
		{
			int id = 0;			
			string FullName = GetEntityFullName(EntityName,em) ;
			string filter = String.Format("{0}='{1}'", FULLNAME, FullName) ;			

			DataSet ds = EntitiesDS;
			if(RowCount(EntitiesDS) > 0)
			{
				DataView dv = EntitiesDS.Tables[0].DefaultView;
				dv.RowFilter = filter;

				if(dv.Count ==1)
				{
					id = Int32.Parse(dv[0][ENTITYID].ToString());
				}
			}
			
			return id;
		}

		#endregion Common

		#region Explain Type

		
		public static Hashtable ExplainFields(Type type, bool bNotSystemType)
		{
			string temp = "";
			
			Hashtable ht = new Hashtable();

			try
			{
				if(type == null) return null;
				// 
				FieldInfo [] fiArr = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

				foreach(FieldInfo fi in fiArr)
				{
					if(bNotSystemType && fi.FieldType.FullName.IndexOf("System.") ==0)
						continue;

					temp += String.Format("F: {0} - {1} <br>", fi.FieldType.ToString(),  fi.Name);				
					
					ht.Add(fi.Name, fi.FieldType);
				}
			}
			catch(Exception ex)
			{
				temp += ex.Message + "<br>";
			}

			return ht;
		}


		public static Hashtable ExplainFields_Attr(Type type, bool bNotSystemType)
		{
			string temp = "";
			
			Hashtable ht = new Hashtable();

			try
			{
				if(type == null) return null;
				// 
				FieldInfo [] fiArr = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

				int cc=0;
				foreach(FieldInfo fi in fiArr)
				{
					cc++;
					string strAttr = "";
					if(bNotSystemType && fi.FieldType.FullName.IndexOf("System.") ==0)
						continue;

					//if(ht.Contains(fi.Name))
					ht.Add(cc.ToString()+ "_"+ fi.Name, fi.FieldType);
					//ht.Add(fi.Name, fi.FieldType);

					object[] attArr = fi.GetCustomAttributes(true);

					for(int i=0;i<attArr.Length;i++)
					{
						strAttr += attArr[i].GetType().ToString()+"-";
						string tem = "";

						Hashtable hta = ExplainAttrubute(fi.GetType(),attArr[i]);
						
						if(hta.Count > 0)
						{							
							foreach(string key in hta.Keys)
							{	
								if(key == DocumentationHelper.ATTR_OWNER || key == DocumentationHelper.ATTR_TYPE)
									continue;

								string val = "";
								if(hta[key] == null)
									val = "";
								else
									val = hta[key].ToString();

								tem += String.Format("*** {0} = {1} <br>", key, val);	

							}	
							ht.Add(cc.ToString()+ "_"+ fi.Name + "_" + attArr[i].GetType().Name, tem);

						}
					}	//end for

				}
			}
			catch(Exception ex)
			{
				temp += ex.Message + "<br>";
			}

			return ht;
		}



		public static Hashtable ExplainProperties(Type type, bool bNotSystemType)
		{
			string temp = "";
			Hashtable ht = new Hashtable();

			try
			{
				if(type == null) return ht;
				// 				
				PropertyInfo [] piArr = type.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

				foreach(PropertyInfo pi in piArr)
				{
					if(bNotSystemType && pi.PropertyType.FullName.IndexOf("System.") ==0)
						continue;

					temp += String.Format("P : {0} - {1} <br>", pi.PropertyType.ToString(), pi.Name);
					ht.Add(pi.Name, pi.PropertyType);
				
				}
			}
			catch(Exception ex)
			{
				temp += ex.Message + "<br>";
			}

			return ht;
		}


		
		public static Hashtable ExplainProperties_Attr(Type type, bool bNotSystemType)
		{
			string temp = "";
			Hashtable ht = new Hashtable();

			try
			{
				if(type == null) return ht;
				// 				
				PropertyInfo [] piArr = type.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

				int cc = 0;
				foreach(PropertyInfo pi in piArr)
				{
					cc++;
					if(bNotSystemType && pi.PropertyType.FullName.IndexOf("System.") ==0)
						continue;

					temp += String.Format("P : {0} - {1} <br>", pi.PropertyType.ToString(), pi.Name);
					ht.Add(cc.ToString() +"_"+ pi.Name, pi.PropertyType);

					object[] attArr = pi.GetCustomAttributes(true);

					for(int i=0;i<attArr.Length;i++)
					{
						//strAttr += attArr[i].GetType().ToString()+"-";
						string tem = "";

						Hashtable hta = ExplainAttrubute(pi.GetType(),attArr[i]);
						
						if(hta.Count > 0)
						{							
							foreach(string key in hta.Keys)
							{	
								if(key == DocumentationHelper.ATTR_OWNER || key == DocumentationHelper.ATTR_TYPE)
									continue;

								string val = "";
								if(hta[key] == null)
									val = "";
								else
									val = hta[key].ToString();

								tem += String.Format("*** {0} = {1} <br>", key, val);	

							}	
							ht.Add(cc.ToString()+ "_"+ pi.Name + "_" + attArr[i].GetType().Name, tem);

						}
					}

				}
			}
			catch(Exception ex)
			{
				temp += ex.Message + "<br>";
			}

			return ht;
		}



	
		public static ArrayList ExplainCustomAttributes(Type type, bool bNotSystemType)
		{
			string text = "";

			ArrayList al = new ArrayList();

			if(type == null)
				return al;

			MemberInfo mi = type;
			object[] objs = mi.GetCustomAttributes(true);

			text += String.Format("{0} All Cust Attributes for: {1} <BR> ",
				objs.Length, type.ToString());

			foreach(object o in objs) 
			{
				string attrType = o.GetType().ToString();
				if(bNotSystemType && attrType.IndexOf("System.") ==0)
					continue;
					
				text += String.Format("Attr Type: {0} <br>",  attrType);
				al.Add(o.GetType());
			}
					
			return al;		
		}

		/// <summary>
		/// return list of ht for every custom attr
		/// where ht - coll attr properties
		/// </summary>
		/// <param name="o"></param>
		/// <param name="bNotSystem"></param>
		/// <returns></returns>
		public static ArrayList GetTypeCustomAttrubutes(Type ownerType, bool bNotSystemType)
		{  

			string text = "";

			ArrayList al = new ArrayList();

			if(ownerType == null)
				return al;

			MemberInfo mi = ownerType;
			object[] objs = mi.GetCustomAttributes(true);

			text += String.Format("{0} All Cust Attributes for: {1} <BR> ",
				objs.Length, ownerType.ToString());

			foreach(object o in objs) 
			{
				string attrType = o.GetType().ToString();
				if(bNotSystemType && attrType.IndexOf("System.") ==0)
					continue;
					
				text += String.Format("Attr Type: {0} <br>",  attrType);
				Hashtable ht = ExplainAttrubute(ownerType, o);
				if(ht.Count > 0)
					al.Add(ht);
			}
					
			return al;	
		}

		public static Hashtable ExplainAttrubute(object attr)
		{
			Hashtable ht = new Hashtable();
			

			//Page Attr-------------
			//NetsoftUSA.DataLayer.MainDataClassAttribute attr
			//ht.Add(attrType+"PPP", MainDataClass.PPP);
			if(attr is MainDataClassAttribute)
			{
				MainDataClassAttribute MainDataClass = attr as MainDataClassAttribute;
				ht.Add("ClassName", MainDataClass.ClassName);				
			}

			//NetsoftUSA.DataLayer.SelectedMainMenuItemAttribute attr
			if(attr is SelectedMainMenuItemAttribute)
			{
				SelectedMainMenuItemAttribute SelectedMainMenuItem = attr as SelectedMainMenuItemAttribute;
				
				ht.Add("MenuItem", SelectedMainMenuItem.MenuItem);				
			}

			//NetsoftUSA.DataLayer.SelectedMenuItemAttribute attr
			if(attr is SelectedMenuItemAttribute)
			{
				SelectedMenuItemAttribute SelectedMenuItem = attr as SelectedMenuItemAttribute;
				
				ht.Add("MenuItem", SelectedMenuItem.MenuItem);				
			}

			//NetsoftUSA.DataLayer.MainLanguageClassAttribute attr
			if(attr is MainLanguageClassAttribute)
			{
				MainLanguageClassAttribute MainLanguageClassAttribute = attr as MainLanguageClassAttribute;
				
				ht.Add("ClassName", MainLanguageClassAttribute.ClassName);				
			}

			//NetsoftUSA.DataLayer.PickPageAttribute attr
			if(attr is PickPageAttribute)
			{
				PickPageAttribute PickPageAttribute = attr as PickPageAttribute;
				
				ht.Add("Page", PickPageAttribute.Page);				
			}

			//NetsoftUSA.DataLayer.PageTitleAttribute attr
			if(attr is PageTitleAttribute)
			{
				PageTitleAttribute PageTitleAttribute = attr as PageTitleAttribute;
				
				ht.Add("Title", PageTitleAttribute.Title);				
			}

			//NetsoftUSA.DataLayer.BackPageAttribute attr
			if(attr is BackPageAttribute)
			{
				BackPageAttribute BackPageAttribute = attr as BackPageAttribute;
				
				ht.Add("backPage", BackPageAttribute.backPage);				
			}

			//DataClass Attr --------------------
			//NetsoftUSA.DataLayer.SPAutoGen attr
			if(attr is SPAutoGen)
			{
				SPAutoGen SPAutoGen = attr as SPAutoGen;
				
				ht.Add("spName", SPAutoGen.spName);
				ht.Add("spTemplate", SPAutoGen.spTemplate);
				if(SPAutoGen.ManuallyManaged)
					ht.Add("ManuallyManaged", SPAutoGen.ManuallyManaged);
				ht.Add("InjectPostOperation", SPAutoGen.InjectPostOperation);
				ht.Add("teplateArgs", SPAutoGen.teplateArgs);
				ht.Add("InjectParameters", SPAutoGen.InjectParameters);	
				ht.Add("InjectPreOperation", SPAutoGen.InjectPreOperation);
				ht.Add("InjectWhere", SPAutoGen.InjectWhere);
			}

			//NetsoftUSA.DataLayer.TableMappingAttribute attr
			if(attr is TableMappingAttribute)
			{
				TableMappingAttribute TableMappingAttribute = attr as TableMappingAttribute;
				
				ht.Add("TableName", TableMappingAttribute.TableName);
				if(TableMappingAttribute.InsertPK)
					ht.Add("InsertPK", TableMappingAttribute.InsertPK);
				ht.Add("PKMemberName", TableMappingAttribute.PKMemberName);
				if(TableMappingAttribute.UseJoinColumns)
					ht.Add("UseJoinColumns", TableMappingAttribute.UseJoinColumns);
			}

			//NetsoftUSA.DataLayer.SPLoadAttribute attr
			if(attr is SPLoadAttribute)
			{
				SPLoadAttribute SPLoadAttribute = attr as SPLoadAttribute;
				
				ht.Add("spName", SPLoadAttribute.spName);
				if(SPLoadAttribute.ManuallyManaged)
					ht.Add("ManuallyManaged", SPLoadAttribute.ManuallyManaged);
			}

			//NetsoftUSA.DataLayer.SPUpdateAttribute attr
			if(attr is SPUpdateAttribute)
			{
				SPUpdateAttribute SPUpdateAttribute = attr as SPUpdateAttribute;
				
				ht.Add("spName", SPUpdateAttribute.spName);
				if(SPUpdateAttribute.ManuallyManaged)
					ht.Add("ManuallyManaged", SPUpdateAttribute.ManuallyManaged);
			}

			//NetsoftUSA.DataLayer.SPInsertAttribute attr
			if(attr is SPInsertAttribute)
			{
				SPInsertAttribute SPInsertAttribute = attr as SPInsertAttribute;
				
				ht.Add("spName", SPInsertAttribute.spName);
				if(SPInsertAttribute.ManuallyManaged)
					ht.Add("ManuallyManaged", SPInsertAttribute.ManuallyManaged);
			}

			//NetsoftUSA.DataLayer.SPDeleteAttribute attr
			if(attr is SPDeleteAttribute)
			{
				SPDeleteAttribute SPDeleteAttribute = attr as SPDeleteAttribute;
				
				ht.Add("spName", SPDeleteAttribute.spName);
				if(SPDeleteAttribute.ManuallyManaged)
					ht.Add("ManuallyManaged", SPDeleteAttribute.ManuallyManaged);
			}

			//DataCollection Attr --------------------
			//NetsoftUSA.DataLayer.ElementTypeAttribute attr
			if(attr is ElementTypeAttribute)
			{
				ElementTypeAttribute ElementTypeAttribute = attr as ElementTypeAttribute;
				
				ht.Add("ElemType", ElementTypeAttribute.ElemType);
			}

			//Field/Prop Attr
			if(attr is ColumnMappingAttribute)
			{
				ColumnMappingAttribute ColumnMappingAttribute = attr as ColumnMappingAttribute;
				
				ht.Add("ColumnName", ColumnMappingAttribute.ColumnName);
				if(ColumnMappingAttribute.StereoType != DataStereoType.None)
					ht.Add("StereoType", ColumnMappingAttribute.StereoType);
			}

			if(attr is FieldDescriptionAttribute)
			{
				FieldDescriptionAttribute FieldDescriptionAttribute = attr as FieldDescriptionAttribute;
				
				ht.Add("Description", FieldDescriptionAttribute.Description);				
			}

			if(attr is ControlTypeAttribute)
			{
				ControlTypeAttribute ControlTypeAttribute = attr as ControlTypeAttribute;
				if(ControlTypeAttribute.IsRequired)
					ht.Add("IsRequired", ControlTypeAttribute.IsRequired);
	
				ht.Add("MaxLength", ControlTypeAttribute.MaxLength);
			}

			if(attr is FieldValuesMemberAttribute)
			{
				FieldValuesMemberAttribute FieldValuesMemberAttribute = attr as FieldValuesMemberAttribute;
				
				ht.Add("lookupCollectionMember", FieldValuesMemberAttribute.lookupCollectionMember);					
			}

			//--------------
			return ht;

		}

		/// <summary>
		/// attr is object from owner.GetCustomAttributes(true)
		/// </summary>
		/// <param name="ownerType"></param>
		/// <param name="attr"></param>
		/// <returns></returns>
		public static Hashtable ExplainAttrubute(Type ownerType, object attr)
		{
			Hashtable ht = ExplainAttrubute(attr);
			
			ht.Add(ATTR_OWNER, ownerType.ToString());
			string attrType = attr.GetType().Name ;	
			//the first item has attr type 
			ht.Add(ATTR_TYPE, attrType);
			
			return ht;

		}

		//--- VS 
		public static Hashtable ExplainAttributesForDb(object[] attArr) 
		{	
			Hashtable hta = new Hashtable();
			int attrCount = 0;

			if(attArr != null)
				attrCount = attArr.Length;
			
			for(int i=0;i<attrCount;i++)
			{	
				string strValues = "";
				string strAttrName = attArr[i].GetType().Name;
				bool bDuplAttr = (hta.Contains(attArr[i]));
				Hashtable htai = ExplainAttrubute(attArr[i]);

				if(htai.Count > 0 && bDuplAttr)
				{
					//strValues +=  ATTR_PIPE_DEL + hta[attArr[i]].ToString() ;
					continue;
				}

				foreach(string key in htai.Keys)
				{
					if(htai[key] != null && htai[key].ToString().Trim().Length > 0)
					{
						if(strValues.Length > 0)
							strValues += ATTR_PIPE_DEL;

						strValues += key + ATTR_EQUAL + htai[key].ToString();

					}
				}	//foreach	

				if(strValues.Length > 0 && !bDuplAttr)
				{							
					hta.Add(attArr[i], strValues);
				}
			}			//for attr array

			return hta; 
		}

					// ---  VS 


		#endregion Explain


		#region Assembly Info
	
		public static Hashtable GetTypesFromAssembly(string file, string strOnlyFullName)
		{
			string temp = "";
			return GetTypesFromAssembly(file, strOnlyFullName, out temp);
		}
		
		/// <summary>
		/// strOnlyFullName should be set as one from class constants (e.x. WEB_PAGE)
		/// or returns all types if strOnlyFullName is not specified
		/// (but should not be call with no strOnlyFullName)
		/// </summary>
		/// <param name="file"></param>
		/// <param name="strOnlyFullName"></param>
		/// <param name="temp"></param>
		/// <returns></returns>
		public static Hashtable GetTypesFromAssembly(string file, string strOnlyFullName, out string temp)
		{
			temp = "";
			string strList = "";
			Hashtable ht = new Hashtable();

			if(!File.Exists(file))
			{
				file = GetAssemblyFile(file);
			}

			if(!File.Exists(file))
			{
				temp = String.Format("Error: {0} not exists", file);
				return ht;
			}

			Assembly a = Assembly.LoadFrom(file);

			temp += String.Format("Assembly: {0}: <BR>", file);
			//string strEntityType = GetEntityTypeConstFromBaseFullName(strOnlyFullName);
//			if(strEntityType.Length == 0)
//				return ht;

			foreach (Type type in a.GetTypes())
			{
				if(strOnlyFullName != null && strOnlyFullName.Length > 0 && !IsType(type,strOnlyFullName))
					continue;

				strList = GetAllTypes(type, ",");
				temp += String.Format("<B>{0}</B>: {1}<BR> ",
					type.Name, strList);

				ht.Add(type.Name, type);	
			}

			return ht;

		}

		public static Hashtable GetPagesFromAssembly(string file)
		{
			string temp = "";
			return GetPagesFromAssembly(file, out temp);
		}

		public static Hashtable GetPagesFromAssembly(string file, out string temp)
		{
			return GetTypesFromAssembly(file, WEB_PAGE, out temp);
		}

		public static Hashtable GetDataClassesFromAssembly(string file)
		{
			string temp = "";
			return GetDataClassesFromAssembly(file, out temp);
		}
		public static Hashtable GetDataClassesFromAssembly(string file, out string temp)
		{
			return GetTypesFromAssembly(file, NS_BASEDATACLASS, out temp);
		}

		public static Hashtable GetDataCollectionsFromAssembly(string file)
		{
			string temp = "";
			return GetDataCollectionsFromAssembly(file, out temp);
		}
		
		public static Hashtable GetDataCollectionsFromAssembly(string file, out string temp)
		{
			return GetTypesFromAssembly(file, SYS_COLLECTIONBASE, out temp);
		}

		public static Hashtable GetUserControlsFromAssembly(string file)
		{
			string temp = "";
			return GetUserControlsFromAssembly(file, out temp);
		}
		 
		public static Hashtable GetUserControlsFromAssembly(string file, out string temp)
		{
			return GetTypesFromAssembly(file, WEB_USERCONTROL, out temp);
		}

		public static Hashtable GetPanelsFromAssembly(string file)
		{
			string temp = "";
			return GetPanelsFromAssembly(file, out temp);
		}
		
		public static Hashtable GetPanelsFromAssembly(string file, out string temp)
		{
			return GetTypesFromAssembly(file, WEB_PANEL, out temp);
		}

		#endregion Assembly

	}
}
