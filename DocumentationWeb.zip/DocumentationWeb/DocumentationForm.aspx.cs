using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DocumentationWeb
{
	/// <summary>
	/// Summary description for DocumentationForm.
	/// </summary>
	public class DocumentationForm : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button btnDropAllDataFromDb;
		protected System.Web.UI.WebControls.Button btnLoadAllDataToDb;
		protected System.Web.UI.WebControls.Button btnExplainPage;
		protected System.Web.UI.WebControls.DropDownList ddlPages;
		protected System.Web.UI.WebControls.DropDownList ddlDataClasses;
		protected System.Web.UI.WebControls.DropDownList ddlUserControls;
		protected System.Web.UI.WebControls.Button btnExplainUserControl;
		protected System.Web.UI.WebControls.Button btnExplainDataClass;
		protected System.Web.UI.WebControls.Label lblPgRc;
		protected System.Web.UI.WebControls.Label lblUcRc;
		protected System.Web.UI.WebControls.Label lblDccRc;
		protected System.Web.UI.WebControls.DropDownList ddlDataCollections;
		protected System.Web.UI.WebControls.Button btnExplainDataCollection;
		protected System.Web.UI.WebControls.Label lblDcRc;
		protected System.Web.UI.WebControls.Button btnRefresh;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			
			if(!IsPostBack)
			{
				LoadDropDowns();
			}

		}

		public void ShowMsg(string msg)
		{
			Response.Write(msg);
			Response.Flush();
			Response.End();
		}

		public string ExecTime(DateTime start, DateTime finish)
		{
			TimeSpan ts = finish - start;
			string execTime = String.Format("Time taken to execute: {0} mins {1} secs", ts.Minutes, ts.Seconds );
			
			return execTime;
		}

		public void ShowAlert(string msg)
		{
			msg = msg.Replace(DocumentationHelper.NEW_LINE , "  ");
			//msg = msg.Replace("=" , " -  ");
			
			string jsMsg = String.Format("<script language='javascript'>alert('{0}');</script>", msg);
			Response.Write(jsMsg);
		}

		public void LoadDropDowns()
		{
			int rc = 0;
			rc = LoadPages();
			rc = LoadDataClasses();
			rc = LoadDataCollections();
			rc = LoadUserControls();
		}

		public int LoadPages()
		{
			int rc = DocumentationHelper.PageDV.Count;
			ddlPages.DataSource = DocumentationHelper.PageDV;
			ddlPages.DataTextField = DocumentationHelper.NAME;
			ddlPages.DataValueField = DocumentationHelper.ENTITYID;

			ddlPages.DataBind();

			this.lblPgRc.Text = rc.ToString() + " Pages:";

			return rc;
		}

		public int LoadUserControls()
		{
			int rc = DocumentationHelper.UserControlDV.Count;
			this.ddlUserControls.DataSource = DocumentationHelper.UserControlDV;
			ddlUserControls.DataTextField = DocumentationHelper.NAME;
			ddlUserControls.DataValueField = DocumentationHelper.ENTITYID;

			ddlUserControls.DataBind();

			this.lblUcRc.Text = rc.ToString() + " User Controls:";

			return rc;
		}


		public int LoadDataClasses()
		{
			int rc = DocumentationHelper.DataClassDV.Count;
			this.ddlDataClasses.DataSource = DocumentationHelper.DataClassDV;
			ddlDataClasses.DataTextField = DocumentationHelper.NAME;
			ddlDataClasses.DataValueField = DocumentationHelper.ENTITYID;

			ddlDataClasses.DataBind();

			this.lblDcRc.Text = rc.ToString() + " DataClasses:";

			return rc;
		}

		public int LoadDataCollections()
		{
			int rc = DocumentationHelper.DataCollectionDV.Count;
			this.ddlDataCollections.DataSource = DocumentationHelper.DataCollectionDV;
			ddlDataCollections.DataTextField = DocumentationHelper.NAME;
			ddlDataCollections.DataValueField = DocumentationHelper.ENTITYID;

			ddlDataCollections.DataBind();

			this.lblDccRc.Text = rc.ToString() + " DataCollections:";

			return rc;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnExplainPage.Click += new System.EventHandler(this.btnExplainPage_Click);
			this.btnExplainDataClass.Click += new System.EventHandler(this.btnExplainDataClass_Click);
			this.btnExplainUserControl.Click += new System.EventHandler(this.btnExplainUserControl_Click);
			this.btnExplainDataCollection.Click += new System.EventHandler(this.btnExplainDataCollection_Click);
			this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
			this.btnLoadAllDataToDb.Click += new System.EventHandler(this.btnLoadAllDataToDb_Click);
			this.btnDropAllDataFromDb.Click += new System.EventHandler(this.btnDropAllDataFromDb_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnExplainPage_Click(object sender, System.EventArgs e)
		{
			string msg = "";
			int id = 131;	//default PatientForm

			string strId = this.ddlPages.SelectedValue;

			//strId should be numeric but can be entityName
			try
			{
				if(strId.Length > 0 )
					id = Int32.Parse(strId);

			}
			catch(Exception ex)
			{
				//try get id from name
				id = DocumentationHelper.GetEntityIdFromNameType(strId, DocumentationHelper.EntityType.page);
			}		
				
			if(id > 0)
			{
				msg = DocumentationHelper.ExplainPageOutput(id);
				ShowMsg(msg);
			}
			else
			{
				ShowAlert("Error getting EntityId");
			}
		}

		private void btnLoadAllEntity_Click(object sender, System.EventArgs e)
		{
			DateTime start = DateTime.Now;
			string msg = "Load Entities is OK";
			if(!DocumentationHelper.LoadAllEntitiesToDB())
				msg = "Load entities failed<BR>" + DocumentationHelper.UpdatedEntitiesCount;
			else
				msg = msg + "<br>" + DocumentationHelper.UpdatedEntitiesCount;

			DateTime finish = DateTime.Now;
			
			string execTime = ExecTime(start, finish);
			msg = msg + DocumentationHelper.NEW_LINE + execTime;

			this.LoadDropDowns();

			ShowAlert(msg);
		}

		private void btnLoadAllMembers_Click(object sender, System.EventArgs e)
		{
			//LoadAllMembersToDB
			DateTime start = DateTime.Now;
			string msg = "";
			msg = DocumentationHelper.LoadAllMembersToDB(false);
				
			DateTime finish = DateTime.Now;

			string execTime = ExecTime(start, finish);
			
			msg = msg + DocumentationHelper.NEW_LINE + execTime;

			ShowAlert(msg);
		}

		private void btnDropAllDataFromDb_Click(object sender, System.EventArgs e)
		{
			string msg = "Delete All Records. " + DocumentationHelper.NEW_LINE;
		
			try
			{
				DateTime start = DateTime.Now;

				DocumentationHelper.DeleteAllRecordsFromSystem();

				DateTime finish = DateTime.Now;

				string execTime = ExecTime(start, finish);

				msg += execTime + DocumentationHelper.NEW_LINE;

			}
			catch(Exception ex)
			{
				msg +=  ex.Message;
			}

			this.LoadDropDowns();

			ShowAlert(msg);
				
		}

		private void btnLoadAllDataToDb_Click(object sender, System.EventArgs e)
		{
			string msg = "Load All Records. " + DocumentationHelper.NEW_LINE;
		
			try
			{
				DateTime start = DateTime.Now;

				DocumentationHelper.LoadAllRecordsToDB();

				DateTime finish = DateTime.Now;

				string execTime = ExecTime(start, finish);
				
				msg += execTime + DocumentationHelper.NEW_LINE;			
			}
			catch(Exception ex)
			{
				msg +=  ex.Message;
			}

			this.LoadDropDowns();

			ShowAlert(msg);
		}

		private void btnRefresh_Click(object sender, System.EventArgs e)
		{
			this.LoadDropDowns();
		}

		

		private void btnTest_Click(object sender, System.EventArgs e)
		{
			
		}

		private void ExplainEntity(string strId)
		{
			string msg = "";
			int id = 0;	

			//strId should be numeric but can be entityName
			try
			{
				if(strId.Length > 0 )
					id = Int32.Parse(strId);

			}
			catch(Exception ex)
			{
				//try get id from name
				id = DocumentationHelper.GetEntityIdFromNameType(strId, DocumentationHelper.EntityType.dataclass);
			}

			if(id > 0)
			{
				msg = DocumentationHelper.ExplainEntityOutput(id);
				ShowMsg(msg);
			}
			else
			{
				ShowAlert("Error getting EntityId");
			}
		}

		private void btnExplainDataClass_Click(object sender, System.EventArgs e)
		{			
			string strId = this.ddlDataClasses.SelectedValue;
			ExplainEntity(strId);	
		}

		private void btnExplainUserControl_Click(object sender, System.EventArgs e)
		{
			string strId = this.ddlUserControls.SelectedValue;
			ExplainEntity(strId);
		}

		private void btnExplainDataCollection_Click(object sender, System.EventArgs e)
		{
			string strId = this.ddlDataCollections.SelectedValue;
			ExplainEntity(strId);
		}

		
	}
}
