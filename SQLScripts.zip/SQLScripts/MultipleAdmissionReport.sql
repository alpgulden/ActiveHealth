if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Report_MultipleAdmission]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Report_MultipleAdmission]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO






CREATE  PROCEDURE [dbo].[usp_Report_MultipleAdmission] (
@FirstDate datetime, @LastDate datetime, @Dates int )
AS

--WITH CURSOR 
--USED IN MULTIPLE ADMISSION REPORTS

DECLARE @PrevId int, @CurrId int, @PrevEventId int, @CurrEventId int
DECLARE @PrevDate datetime , @CurrDate datetime
DECLARE @Multi bit
DECLARE @TempMult TABLE ( EventId int)
--DECLARE @test TABLE (PatientId int, SelectDate datetime, EventId int)

--init
select @Multi = 0

DECLARE myCursor CURSOR FAST_FORWARD FOR
SELECT  PatientId , SelectDate, EventId  
from Report_MultipleAdmission
where   (SelectDate  between @FirstDate AND @LastDate)
ORDER BY PatientId , SelectDate
	
OPEN myCursor
FETCH NEXT FROM  myCursor INTO @PrevId, @PrevDate, @PrevEventId
--INSERT INTO @test(PatientId, SelectDate, EventId) VALUES (@PrevId, @PrevDate, @PrevEventId)

WHILE @@fetch_status = 0
BEGIN  	
FETCH NEXT FROM  myCursor INTO @CurrId, @CurrDate, @CurrEventId

if @@fetch_status = 0
Begin
	--INSERT INTO @test(PatientId, SelectDate, EventId) VALUES (@CurrId, @CurrDate, @CurrEventId)

	if (@PrevId = @CurrId and DATEDIFF(DAY, @PrevDate, @CurrDate) <= @Dates)
	begin
		--
		INSERT INTO @TempMult(EventId) 
		VALUES (@PrevEventId)

		select @Multi = 1
		
	end
	else
	begin
		if (@Multi = 1)
		begin
			INSERT INTO @TempMult(EventId) 
			VALUES (@PrevEventId)
		end
			
		select @Multi = 0
	end

	select @PrevId = @CurrId , @PrevDate = @CurrDate, @PrevEventId = @CurrEventId
End
else
if( @Multi = 1)
begin
	INSERT INTO @TempMult(EventId) 
	VALUES (@PrevEventId)	
end
	
END
CLOSE myCursor
DEALLOCATE myCursor

-- test only
--select * from @test
--select * from @TempMult


-- return resut set
select R.* from Report_MultipleAdmission R , @TempMult T
where R.EventId = T.EventId 
order by R.PatientId, R.SelectDate









GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

