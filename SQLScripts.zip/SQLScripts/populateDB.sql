--
-- InitializationScript
-- ====================
--

-- First things first, make sure we have a user that we can create accounts with
if not exists(select * from aauser where loginname = 'INTERFACE_USER')
	insert into AAUser (Name, LoginName, Password, CreatedBy, Status, FailedLogins) VALUES('interfaceUser', 'INTERFACE_USER', 'interface', 1,1,0)
go

-- Create our code table entries
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('CMD',  'NT Shell script command',       1, 1, @interfaceUser, getdate())  
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('ICM',  'ICM Scoring Load',              1, 1, @interfaceUser, getdate())  
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('ELIG', 'Eligibility import',            1, 1, @interfaceUser, getdate())  
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('PROV', 'Provider import',               1, 1, @interfaceUser, getdate())
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('AUTH', 'Authorization export',          1, 1, @interfaceUser, getdate())
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('MLOG', 'Active Advice Membership Log',  1, 1, @interfaceUser, getdate())
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('CENG', 'Care Engine export',            1, 1, @interfaceUser, getdate())
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('MEMB', 'Membership file export',        1, 1, @interfaceUser, getdate())
go

-- Create our code table entries
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('CANC', 'Canceled',   1, 1, @interfaceUser, getdate())  -- canceled by the User
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('PEND', 'Pending',    1, 1, @interfaceUser, getdate())  -- ready to run
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('RUN',  'Running',    1, 1, @interfaceUser, getdate())  -- running
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('DONE', 'Completed',  1, 1, @interfaceUser, getdate())  -- completed, check error log for issues
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('FAIL', 'Failed',     1, 1, @interfaceUser, getdate())  -- failed, bad arguments, db error, etc.
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('INVL', 'Invalid',    1, 1, @interfaceUser, getdate())  -- updating arguments, not ready to run
go

declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
INSERT INTO EDIApplicationSenderCode (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('24', 'Employer Identifier', 1, 1, @interfaceuser, getdate() )
INSERT INTO EDIApplicationSenderCode (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('34', 'Social Security Number', 1, 1, @interfaceuser, getdate() )
INSERT INTO EDIApplicationSenderCode (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('46', 'ETIN - Electronic Transmitter Identification Number', 1, 1, @interfaceuser, getdate() )
INSERT INTO EDIApplicationSenderCode (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('PI', 'Payor Identification', 1, 1, @interfaceuser, getdate() )
INSERT INTO EDIApplicationSenderCode (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('XV', 'Health Care Financing Administration National PlanID', 1, 1, @interfaceuser, getdate() )
INSERT INTO EDIApplicationSenderCode (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('ZZ', 'User defined identifier', 1, 1, @interfaceuser, getdate() )
go

 
--UMOContactNumberQualifier 
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
INSERT INTO UMOContactNumberQualifier (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('EM', 'Email',     1, 1, @interfaceuser, getdate() )
INSERT INTO UMOContactNumberQualifier (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('FX', 'Facsimile', 1, 1, @interfaceuser, getdate() )
INSERT INTO UMOContactNumberQualifier (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('TE', 'Telephone', 1, 1, @interfaceuser, getdate() )
go

--UMOIdentificationQualifier 
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
INSERT INTO UMOIdentificationQualifier (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('24', 'Employer Identifier', 1, 1, @interfaceuser, getdate() )
INSERT INTO UMOIdentificationQualifier (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('34', 'Social Security Number', 1, 1, @interfaceuser, getdate() )
INSERT INTO UMOIdentificationQualifier (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('46', 'ETIN - Electronic Transmitter Identification Number', 1, 1, @interfaceuser, getdate() )
INSERT INTO UMOIdentificationQualifier (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('PI', 'Payor Identification', 1, 1, @interfaceuser, getdate() )
INSERT INTO UMOIdentificationQualifier (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('XV', 'Health Care Financing Administration National PlanID', 1, 1, @interfaceuser, getdate() )
INSERT INTO UMOIdentificationQualifier (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('ZZ', 'User defined identifier', 1, 1, @interfaceuser, getdate() )
go

--HEDISReportType
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
INSERT HEDISReportType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('NA',    'Not applicable',       1, 1, @interfaceUser, getdate())  
INSERT HEDISReportType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('AMB',   'Ambulatory Surgery',   1, 1, @interfaceUser, getdate())  
INSERT HEDISReportType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('ER',    'EmergencyRoom',        1, 1, @interfaceUser, getdate())  
INSERT HEDISReportType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('IP',    'Inpatient',            1, 1, @interfaceUser, getdate())
INSERT HEDISReportType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('OBSV',  'Observation',          1, 1, @interfaceUser, getdate())
INSERT HEDISReportType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('OP',    'Outpatient Visit',     1, 1, @interfaceUser, getdate())
go

--HEDISAcuityType
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
INSERT HEDISAcuityType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('ACT',    'Acute',       1, 1, @interfaceUser, getdate())  
INSERT HEDISAcuityType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('NACT',   'Non-acute',   1, 1, @interfaceUser, getdate())  
go

--ReferralRole
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
INSERT ReferralRole (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('OTHR',    'Other',       1, 1, @interfaceUser, getdate())  
INSERT ReferralRole (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('PCP',    'Preferred Care Provider',       1, 1, @interfaceUser, getdate())  
INSERT ReferralRole (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('REFR',    'Referring Physician',       1, 1, @interfaceUser, getdate())  
go

-- MedicationStatus
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
INSERT MedicationStatus (Code, [Description], Active, ReadOnly, CreatedBy, CreateTime) VALUES ('PREC', 'Prescription',                1, 1, @interfaceUser, getdate())
INSERT MedicationStatus (Code, [Description], Active, ReadOnly, CreatedBy, CreateTime) VALUES ('NPRE', 'Non-Prescription (OTC)',      1, 1, @interfaceUser, getdate())
INSERT MedicationStatus (Code, [Description], Active, ReadOnly, CreatedBy, CreateTime) VALUES ('ALGY', 'Allergy',                     1, 1, @interfaceUser, getdate())
INSERT MedicationStatus (Code, [Description], Active, ReadOnly, CreatedBy, CreateTime) VALUES ('MDST', 'MD told pt to stop med',      1, 1, @interfaceUser, getdate())
INSERT MedicationStatus (Code, [Description], Active, ReadOnly, CreatedBy, CreateTime) VALUES ('PTST', 'Pt stop med on own',          1, 1, @interfaceUser, getdate())
INSERT MedicationStatus (Code, [Description], Active, ReadOnly, CreatedBy, CreateTime) VALUES ('NOT',  'Pt not making as prescribed', 1, 1, @interfaceUser, getdate())
go


--
-- InitializeSecurity.SQL
-- ======================
--

-- First things first, make sure we have a user that we can create accounts with
if not exists(select * from aauser where loginname = 'INTERFACE_USER')
	insert into AAUser (Name, LoginName, Password, CreatedBy, Status, FailedLogins) VALUES('interfaceUser', 'INTERFACE_USER', 'interface', 1,1,0)
go

-- #1. Create the Functional Access Levels
-- =======================================
if not exists(select * from SecurityFALevel where FALevelName = 'File Maintenance')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('File Maintenance', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Code Tables')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Code Tables', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Intake')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Intake', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Patient summary')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Patient summary', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Patient information')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Patient information', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Problems')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Problems', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Events')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Events', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Reviews')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Reviews', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Diagnostics & Procedures')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Diagnostics & Procedures', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Referrals')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Referrals', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Clinical Management service')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Clinical Management service', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Care Management')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Care Management', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Maternichek')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Maternichek', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Workers compensation')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Workers compensation', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Guidelines')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Guidelines', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Reports')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Reports', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Contacts')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Contacts', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Worklists')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Worklists', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Activities')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Activities', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Notes')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Notes', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'System Administration & Utilities')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('System Administration & Utilities', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Plan')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Plan', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Provider')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Provider', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Letter Setup')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Letter Setup', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Letter generate batch')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Letter generate batch', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Letter send')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Letter send', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Administrator')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Administrator', 'Builtin Administrators FA Level', 1)
if not exists(select * from SecurityFALevel where FALevelName = 'FULL')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('FULL', 'Builtin FULL Access FA Level', 1)
if not exists(select * from SecurityFALevel where FALevelName = 'Medications')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Medications', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Measurements')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Measurements', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Allergies')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Allergies', NULL, 0)
if not exists(select * from SecurityFALevel where FALevelName = 'Letter Draft Queue')
    insert SecurityFALevel (FALevelName, FALevelDescription, BuiltIn) VALUES('Letter Draft Queue', NULL, 0)
go

-- #2. Create the 3 default groups
-- ===============================
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
if not exists(select * from securitygroup where groupname = 'Managers')
    insert SecurityGroup (GroupName, [Description], CreatedBy, CreateTime) VALUES('Managers', 'xxxxxx', @interfaceUser, getdate() )
if not exists(select * from securitygroup where groupname = 'System Admins')
    insert SecurityGroup (GroupName, [Description], CreatedBy, CreateTime) VALUES('System Admins', 'new', @interfaceUser, getdate() )
if not exists(select * from securitygroup where groupname = 'Users')
    insert SecurityGroup (GroupName, [Description], CreatedBy, CreateTime) VALUES('Users', NULL, @interfaceUser, getdate() )
go

-- #3. Create the default User accounts (all passwords are 'dev')
-- ==============================================================
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
if not exists(select * from aauser where loginname = 'admin')
    insert AAUser (Name, LoginName, Password, CreatedBy, CreateTime, Status, Active, Salt) VALUES('admin', 'admin', '2A51A1376E3F67337178FBDFEFBE920856EFB04B' , @interfaceUser, getdate(), 1,1, 'Dhy1NtE=')
if not exists(select * from aauser where loginname = 'dev')
    insert AAUser (Name, LoginName, Password, CreatedBy, CreateTime, Status, Active, Salt) VALUES('Developer', 'dev', '2A51A1376E3F67337178FBDFEFBE920856EFB04B' , @interfaceUser, getdate(), 1,1, '7JlxDbE=')
go

-- #4. Now add the Dev & admin users to the System Admins group
--

declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
declare @groupid int
select @groupid = GroupID from securityGroup where GroupName = 'System Admins'

declare @devuserid int
select @devuserid = userid from aauser where loginname = 'dev'
if not exists(select * from SecurityGroupUser where GroupID = @groupid and UserId = @devuserid)
    INSERT SecurityGroupUser (GroupID, UserID, CreatedBy, CreateTime) VALUES(@groupid, @devuserid, @interfaceUser, getdate())

declare @adminuserid int
select @adminuserid = userid from aauser where loginname = 'admin'
if not exists(select * from SecurityGroupUser where GroupID = @groupid and UserId = @adminuserid)
    INSERT SecurityGroupUser (GroupID, UserID, CreatedBy, CreateTime) VALUES(@groupid, @adminuserid, @interfaceUser, getdate())
go

--
-- Now give our admin user(s) Functional access
-- ============================================
declare @admingroupid int
select @admingroupid = groupid from SecurityGroup where GroupName = 'System Admins'
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser

-- don't insert things twice (we filter to avoid the error)
insert SecurityGroupFALevel (GroupID, FALevelID, CreatedBy, CreateTime, Permission)
select @admingroupid,
       FALevelID,
       @interfaceUser,
       getdate(),
       0 -- full access permission (=1 is ReadOnly)
from SecurityFALevel
where FALevelID not in (select FALevelID from SecurityGroupFALevel where GroupID = @admingroupid)

