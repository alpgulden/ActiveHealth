using System;
using System.IO;
using System.Data;
using System.Reflection;
using System.Security.Permissions;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Diagnostics;
using ActiveAdvice.DataLayer;

namespace ActiveAdviceService
{
	public class MemberLogWriter
	{

		#region properties & variables
		protected string connectionstring;
		public string ConnectionString
		{
			get { return connectionstring; }
			set { connectionstring = value; }
		}

		protected int jobid;
		public int JobID
		{
			get { return jobid; }
			set { jobid = value;}
		}
		protected string errorlogfilename;
		public string ErrorLogFileName
		{
			get { return errorlogfilename; }
			set { errorlogfilename = value;}
		}
		#endregion

		/// <summary>
		/// ParseFile()
		/// The MemberLogReader::ParseFile() method will read
		/// the member log from the datastore and produce
		/// formatted output to the specified file name
		/// </summary>
		/// <param name="FileName">string, where output is to be written. NOT appended, overwritten</param>
		/// <param name="strConnection">string, the connecting string to the database</param>
		/// <param name="errorlogfilename">string, name of error log file we can write errors to</param>
		/// <param name="jobid">int, the job-id of the task to execute</param>
		public int ParseFile(System.String in_filename, System.String in_connectionstring, String in_errorlogfilename, int in_jobid)
		{
			StreamWriter sw = null;
			try
			{
				//				errorlogfilename	            = in_errorlogfilename;
				//				fileiopermission permerrorlog   = new fileiopermission(fileiopermissionaccess.write, errorlogfilename);
				//				permerrorlog.assert();
				//
				//				fileiopermission permoutputfile = new fileiopermission(fileiopermissionaccess.write, in_filename);
				//				permoutputfile.assert();

				this.ConnectionString	= in_connectionstring;
				this.JobID				= in_jobid;
				sw						= new StreamWriter(in_filename);
				// We are setup to write stuff, now read in the necessary data
				int num_records = WriteMemberLog(sw);
				sw.Close();
				return num_records;
			}
			catch(Exception ex)
			{
				if (sw != null)
				{
					sw.Close();
					sw = null;
				}

				string message = ex.Message;
				if (!EventLog.SourceExists("EligibilityInterface") )
					EventLog.CreateEventSource("EligibilityInterface", "ActiveAdvice");
				EventLog.WriteEntry("EligibilityInterface", ex.Message, EventLogEntryType.Error);
				throw(ex);
			}

		}// end of method ParseFile()

		/// <summary>
		/// WriteMemberLog()
		/// This procedure will execute the stored proc and
		/// read the memberlog information
		/// </summary>
		/// <param name="sw">StreamWriter, the stream to write the output file to</param>
		/// <returns>int, # of records if > 0, otherwise error</returns>
		protected int WriteMemberLog(StreamWriter sw)
		{
			MemberLogFormatter mlf = new MemberLogFormatter();
			int num_records = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_GenerateMemberLog", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@jobid", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.JobID;

				try
				{
					connection.Open();
					SqlDataReader r = cmd.ExecuteReader();
					while(r.Read() )
					{
						num_records++;
						mlf.Initialize();
						mlf.AlternatePatientID  = r["AlternatePatientID"].ToString();
						mlf.AlternateORGID      = r["AlternateORGID"].ToString();
						if (!r.IsDBNull(r.GetOrdinal("CMSID")) )
							mlf.CMSID               = Convert.ToInt32(r["CMSID"]);
						else
							mlf.CMSID = 0;
						if (!r.IsDBNull(r.GetOrdinal("CMSStatus") ) )
							mlf.CMSStatus           = r["CMSStatus"].ToString();
						else
							mlf.CMSStatus = "";

						if (!r.IsDBNull(r.GetOrdinal("EligibilityAsOfDate") ) )
							mlf.EligibilityAsOfDate = Convert.ToDateTime(r["EligibilityAsOfDate"]);
						if (!r.IsDBNull(r.GetOrdinal("EffectiveDate") ) )
							mlf.MemberEffectiveDate	= Convert.ToDateTime(r["EffectiveDate"]);
						if (!r.IsDBNull(r.GetOrdinal("TerminationDate") ) )
							mlf.MemberTermDate		= Convert.ToDateTime(r["TerminationDate"]);

						string out_str = CEExportFormatter.FormatOutput(mlf);
						sw.WriteLine(out_str);
					}// end of reading loop
				}
				catch(SqlException se)
				{
					this.SQLexceptionHandler(cmd, se);
					return -1;
				}
				return num_records;
			}
		}// end of method readmemberlog

		/// <summary>
		/// SQLexceptionHandler()
		/// This method will process SQL exceptions and print out the
		/// parameters associated with the command object.
		/// </summary>
		/// <param name="cmd">SqlCommand, the command that had the error</param>
		/// <param name="se">SqlException, the exception that was caught</param>
		public void SQLexceptionHandler(SqlCommand cmd, SqlException se)
		{
			string msg = cmd.CommandText + " failure\nParameters:\n";
			for (int i = 0; i < cmd.Parameters.Count; i++)
			{
				try
				{
					msg += "    " + cmd.Parameters[i].ParameterName + "=" + (cmd.Parameters[i].Value == null ? "<null>" : cmd.Parameters[i].Value.ToString()) + "\n";
				}
				catch(Exception ex)
				{
					string messg = ex.Message;
				}
			}
			msg += "\n{Inner Exception}\n" + se.Message;
			Exception e = new Exception(msg, se);
			throw e;
		}// end of method SQLexceptionhandler
	}// end of class MemberLogWriter
		
	/// <summary>
	/// Summary description for MemberLogFormatter.
	/// </summary>
	public class MemberLogFormatter
	{
		/// <summary>
		/// MemberLogFormatter()
		/// This class will create the output strings
		/// per the format specification for "Extended Membership logs"
		/// </summary>
		public MemberLogFormatter()
		{
			Initialize();
		}

		/// <summary>
		/// Initialize()
		/// reset the state of the object so we can 
		/// re-use it.
		/// </summary>
		public void Initialize()
		{
			this.reasonid            = 0;
			this.eligibilityasofdate = DateTime.Parse("1/1/0001");
			this.cmstermdate		 = DateTime.Parse("1/1/0001");
			this.cmsstatus			 = "";
			this.cmsid				 = 0;
			this.assessmentdate		 = DateTime.Parse("1/1/0001");
			this.alternatepatientid	 = "";
			this.alternateorgid		 = "";
		}

		#region properties & variables
		protected string alternatepatientid;
		[ImportExportFieldPos(Start=1, End=30)]
		public string AlternatePatientID
		{
			set { alternatepatientid = value; }
			get { return alternatepatientid; }
		}
		protected string alternateorgid;
		[ImportExportFieldPos(Start=31, End=60)]
		public string AlternateORGID
		{
			get {return alternateorgid; }
			set {alternateorgid = value; }
		}
		protected DateTime eligibilityasofdate;
		[ImportExportFieldPos(Start=61, End=70)]
		public DateTime EligibilityAsOfDate
		{
			get { return eligibilityasofdate; }
			set { eligibilityasofdate = value; }
		}
		protected char eligibilitystatus;
		[ImportExportFieldPos(Start=71, End=71)]
		public char EligibilityStatus
		{
			get { return this.eligibilitystatus; }
			set {this.eligibilitystatus = value; }
		}
		protected DateTime membereffectivedate;
		[ImportExportFieldPos(Start=72, End=81)]
		public DateTime MemberEffectiveDate
		{
			get {return membereffectivedate;}
			set {membereffectivedate = value; }
		}
		protected DateTime membertermdate;
		[ImportExportFieldPos(Start=82, End=91)]
		public DateTime MemberTermDate
		{
			get {return membertermdate;}
			set {membertermdate = value; }
		}
		protected char enrollstatus;
		[ImportExportFieldPos(Start=92,End=92)]
		public char EnrollStatus
		{
			set {enrollstatus = value; }
			get {return enrollstatus; }
		}
		protected string cmsstatus;
		[ImportExportFieldPos(Start=93, End=96)]
		public string CMSStatus
		{
			get {return cmsstatus; }
			set {cmsstatus = value; }
		}
		protected DateTime assessmentdate;
		[ImportExportFieldPos(Start=97, End=106)]
		public DateTime AssessmentDate
		{
			get {return assessmentdate; }
			set {assessmentdate = value; }
		}
		protected DateTime cmstermdate;
		[ImportExportFieldPos(Start=107, End=116)]
		public DateTime CMSTermDate
		{
			get {return cmstermdate; }
			set {cmstermdate = value; }
		}
		protected int reasonid;
		[ImportExportFieldPos(Start=117, End=120)]
		public int ReasonID
		{
			get { return reasonid; }
			set { reasonid = value; }
		}
		protected int cmsid;
		[ImportExportFieldPos(Start=121, End=143)]
		public int CMSID
		{
			get {return cmsid; }
			set {cmsid = value; }
		}
#endregion

	}// end of class
}
