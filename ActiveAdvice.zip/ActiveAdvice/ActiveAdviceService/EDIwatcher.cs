using System;
using System.IO;
using System.Diagnostics;
using InterfaceReader;		// the EDI x12 parser

namespace ActiveAdviceService
{
	/// <summary>
	/// EDIwatcher
	/// Derived from the file watcher component, this class will respond to
	/// the Changed/Created/Deleted events.
	/// </summary>
	public class EDIwatcher : System.IO.FileSystemWatcher
	{
		protected string connectionString;
		protected string processing_dir = "processing";
		protected string processed_dir  = "done";
		public EDIwatcher(string path, string connectionstring)
		{
			try
			{
				this.IncludeSubdirectories	= false; // don't look at sub-dirs, we'll process files there
				this.Path					= path;
				this.Filter					= "";	// all files, we'll filter on read
				this.connectionString       = connectionstring;

				// If our directory to watch doesn't exist, create it!
				DirectoryInfo di            = new DirectoryInfo(Path);
				if (!di.Exists)
					di.Create();

				// We need two sub directories, one for "processing" files and
				// another when the file is "done". Create these if they don't exist.
				DirectoryInfo []entries = di.GetDirectories(processing_dir);
				if (entries.Length < 1)
				{
					di.CreateSubdirectory(processing_dir);
				}
				entries = di.GetDirectories(processed_dir);
				if (entries.Length < 1)
				{
					di.CreateSubdirectory(processed_dir);
				}
			}
			catch(System.ArgumentException se)
			{
				string msg = se.Message;
				Debugger.Break();
				throw se;
			}
			catch(Exception e)
			{
				string msg = e.Message;
				Debugger.Break();
				throw e;
			}

			try
			{
				this.EnableRaisingEvents = true;
//				this.Deleted += new System.IO.FileSystemEventHandler(this.EDIfilewatcher_Deleted);
//				this.Changed += new System.IO.FileSystemEventHandler(this.EDIfilewatcher_Changed);
				this.Created += new System.IO.FileSystemEventHandler(this.EDIfilewatcher_Created);
			}
			catch(System.ArgumentException se)
			{
				string msg = se.Message;
				Debugger.Break();
				return;
//				throw se;
			}
			catch(Exception e)
			{
				string msg = e.Message;
				Debugger.Break();
				throw e;
			}
		}

		private void EDIfilewatcher_Created(object sender, System.IO.FileSystemEventArgs e)
		{
			ProcessNewFile(e);
		}

//		private void EDIfilewatcher_Changed(object sender, System.IO.FileSystemEventArgs e)
//		{
//		
//		}
//
//		private void EDIfilewatcher_Deleted(object sender, System.IO.FileSystemEventArgs e)
//		{
//		
//		}

		/// <summary>
		/// ProcessNewFile()
		/// called on the thread that saw the change, this can invoke multiple
		/// x12 parsing operations through different x12 parsing objects.
		/// 
		/// We move files we have "seen" into a sub-directory called "processing"
		/// </summary>
		/// <param name="e"></param>
		private void ProcessNewFile(System.IO.FileSystemEventArgs e)
		{
			string Fullpath = e.FullPath;
			System.Guid uuid = System.Guid.NewGuid();
			string processing_name     = this.Path + "\\" + processing_dir + "\\" + e.Name + "." + uuid.ToString();
			File.Move(e.FullPath, processing_name);

			EDIreader parser = new EDIreader();
			parser.ParseFile(e.Name, processing_name, this.connectionString, null); // no error log right now

			// We're back, move the file to the "done" directory
			try
			{
				string processed_name = this.Path + "\\" + processed_dir + "\\" + e.Name;
				File.Move(processing_name, processed_name);
			}
			catch(IOException ie)
			{
				string msg = ie.Message; // file already exists! make it unique
				string processed_name = this.Path + "\\" + processed_dir + "\\" + e.Name + "." + System.Guid.NewGuid().ToString();
				File.Move(processing_name, processed_name);
			}
		}
	}// end of class
}// end of namespace
