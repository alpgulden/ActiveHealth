using System;
using System.IO;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Security.Permissions;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using X12Parsing;

namespace InterfaceReader
{
	/// <summary>
	/// Summary description for X12Reader.
	/// </summary>
	///

	public class EligibilityPlanStaging
	{
		public EligibilityPlanStaging(Guid batch, DateTime asofdate, string membershipid, string sorgid)
		{
			batch_guid		= batch;
			AsOfDate		= asofdate;
			AlternateID		= membershipid;
			AlternateSORGID	= sorgid;
			Initialize();
		}
		public void Initialize()
		{
			PlanID = null; PlanType = null; GroupID = null; EffectiveDate = new DateTime(1,1,1);
			TerminationDate = new DateTime(1,1,1); Status = null; ChangeDate = new DateTime(1,1,1);
		}// end of method Initialize()
		#region variables
		protected Guid		batch_guid;				// UUID for our batching
		public DateTime AsOfDate;
		string	PlanType;
		public string	PlanID;
		string	GroupID;
		DateTime EffectiveDate;
		DateTime TerminationDate;
		string	Status;
		DateTime ChangeDate;
		public string   AlternateID;
		public string   AlternateSORGID;
		public string   AlternateEnrollmentID;
		public string   AlternateInsuranceID;
		#endregion variables
		public void SetDependentDate(DependentDate dd)
		{
			switch (dd.DateTimeQualifier)
			{
				case "346":		// effective date
					this.EffectiveDate		= dd.DateTimePeriod;	break;
				case "347":		// termination date
					this.TerminationDate	= dd.DateTimePeriod;	break;
				default:	break;
			}// end of switch dd.DateTimeQualifier
		}
		public void SetDependentAdditionalIdentification(DependentAdditionalIdentification dai)
		{
			switch(dai.ReferenceIdentificationQualifier)
			{
				case "18":			// 18  = Plan ID
					this.PlanID					= dai.ReferenceIdentification;	break;
				case "LU":			// LU  = Enrollment ID
					this.AlternateEnrollmentID	= dai.ReferenceIdentification;	break;
				case "A9":          // A9  = Alternate Insurance ID (i.e. Policy #)
					this.AlternateInsuranceID	= dai.ReferenceIdentification;	break;
				default:
					break;
			}// end of switch ReferenceIdentificationQualifier

		}// end of method SetDependentAdditionalIdentification
		public void SetDependentBenefitInformation(DependentBenefitInformation dbi)
		{
			switch(dbi.BenefitInformationDescription)
			{
				case "1":
					Status = "A";	break;
				case "6":
				case "T":
				default:
					Status = "I";	break;
			}
		}// end of method SetDependentBenefitInformation()

		public void WriteToStaging(string ConnectionString)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Staging_WriteEligibilityPlan", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@alternateid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateID;

				inparm				= cmd.Parameters.Add("@alternatesorgid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateSORGID;

				inparm				= cmd.Parameters.Add("@asofdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (AsOfDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = AsOfDate;

				inparm				= cmd.Parameters.Add("@plantype", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.PlanType;

				inparm				= cmd.Parameters.Add("@plan", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.PlanID;

				inparm				= cmd.Parameters.Add("@groupid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.GroupID;

				inparm				= cmd.Parameters.Add("@effectivedate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (EffectiveDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = EffectiveDate;

				inparm				= cmd.Parameters.Add("@terminationdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (TerminationDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = TerminationDate;

				inparm				= cmd.Parameters.Add("@status", SqlDbType.Char,1);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Status;

				inparm				= cmd.Parameters.Add("@changedate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (ChangeDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = ChangeDate;

				inparm				= cmd.Parameters.Add("@enrollmentid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateEnrollmentID;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}
		}
	}// end of class EligibilityPlanStaging

	public class EligibilityPCPStaging
	{
		public EligibilityPCPStaging(Guid batch, DateTime asofdate, string membershipid, string sorgid, string planid)
		{
			batch_guid		= batch;
			AsOfDate		= asofdate;
			AlternateID		= membershipid;
			AlternateSORGID	= sorgid;
			PlanID			= planid;
			Initialize();
		}
		public void Initialize()
		{
			PCP = null; PCPType = null; EffectiveDate = new DateTime(1,1,1); TerminationDate = new DateTime(1,1,1);
			Status = null; ChangeDate = new DateTime(1,1,1); PCPSpecialty = null; PCPLocation = null;
			FirstName = null; LastName = null; NameSuffix = null; MiddleName = null;
			Address1 = null; Address2 = null; City = null; State = null; Country = null; PostalCode = null;
		}
		#region variables
		protected Guid		batch_guid;				// UUID for our batching
		protected string    PlanID;                 // alternate planid
		protected string    AlternateID;            // member's identifier
		protected string    AlternateSORGID;
		protected DateTime  AsOfDate;
		protected string	PCP;
		protected string	PCPType;
		protected DateTime	EffectiveDate;
		protected DateTime	TerminationDate;
		protected string	Status;
		protected DateTime	ChangeDate;
		protected string	PCPSpecialty;
		protected string	PCPLocation;
		protected string	FirstName;
		protected string	LastName;
		protected string	MiddleName;
		protected string	NameSuffix;
		protected string	Address1;
		protected string	Address2;
		protected string	City;
		protected string	State;
		protected string	PostalCode;
		protected string	Country;
		#endregion variables
		public void SetDependentName(DependentName nm) // "NM1"
		{
			this.FirstName	= nm.FirstName;
			this.LastName	= nm.LastName;
			this.MiddleName	= nm.MiddleName;
			this.NameSuffix	= nm.NameSuffix;
			switch(nm.IdentificationCodeQualifier)
			{
				case "SV":		// alternate provider id
					this.PCP	= nm.IdentificationCode;	break;
				case "MI":		// member id
				case "34":		// SSN
				default:
					break;
			}// end of handling identificationcodequalifier
		}// end method SetDependentName
		public void SetDependentDate(DependentDate dd)
		{
			switch (dd.DateTimeQualifier)
			{
				case "346":		// effective date
					this.EffectiveDate		= dd.DateTimePeriod;	break;
				case "347":		// termination date
					this.TerminationDate	= dd.DateTimePeriod;	break;
				default:	break;
			}// end of switch dd.DateTimeQualifier
		}
		public void SetDependentBenefitRelatedProvider(DependentBenefitRelatedProvider dbrp)
		{
			if (dbrp.ProviderCode == "PC")
			{
				this.PCPSpecialty	= dbrp.SpecialtyCode;
				if (dbrp.ReferenceIdentificationQualifier	== "LU")		// should always be LU
					this.PCPLocation	= dbrp.ReferenceIdentification;	// this is the AlternateLocationID
			}
		}
		public void SetDependentAddress(DependentAddress da)
		{
			this.Address1	= da.AddressLine1;
			this.Address2	= da.AddressLine1;
		}// end of method SetDependentAddress

		public void SetDependentCityStateZip(DependentCityStateZip dcsz)
		{
			this.City		= dcsz.CityName;
			this.State		= dcsz.StateProvince;
			this.PostalCode	= dcsz.PostalCode;
			this.Country	= dcsz.CountryCode;

		}// end of SetDependentCityStateZip
		public void WriteToStaging(string ConnectionString)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Staging_WriteEligibilityPCP", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@planid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.PlanID;

				inparm				= cmd.Parameters.Add("@alternateid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateID;

				inparm				= cmd.Parameters.Add("@alternatesorgid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateSORGID;

				inparm				= cmd.Parameters.Add("@asofdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (AsOfDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = AsOfDate;

				inparm				= cmd.Parameters.Add("@pcp", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.PCP;

				inparm				= cmd.Parameters.Add("@pcptype", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.PCPType;

				inparm				= cmd.Parameters.Add("@effectivedate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (EffectiveDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = EffectiveDate;

				inparm				= cmd.Parameters.Add("@terminationdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (TerminationDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = TerminationDate;

				inparm				= cmd.Parameters.Add("@status", SqlDbType.Char,1);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Status;

				inparm				= cmd.Parameters.Add("@changedate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (ChangeDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = ChangeDate;

				inparm				= cmd.Parameters.Add("@pcplocation", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.PCPLocation;

				inparm				= cmd.Parameters.Add("@pcpspecialty", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.PCPSpecialty;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}
		}// end of method WriteToStaging()

	}// end of class EligibilityPCPStaging

	public class EligibilityStaging
	{
		public EligibilityStaging(Guid batch, DateTime asofdate)
		{
			batch_guid	= batch;
			AsOfDate	= asofdate;
			Initialize();
		}
		public void Initialize()
		{
			FirstName = null;
			MiddleName = null;
			LastName = null;
			NameSuffix = null;
			MembershipId = null;
			MemberAddress1 = null;
			MemberAddress2 = null;
			MemberAddress3 = null;
			MemberCity = null;
			MemberState = null;
			MemberCountry = null;
			MemberPostalCode = null;
			MemberDOB = new DateTime(1,1,1);
			MemberGender = null;
			MemberSSN = null;
			MemberSORGId = null;		// filling in with Alternate SORG Id
			MemberEffectiveDate = new DateTime(1,1,1);
			IsSubscriber = false;
			RelationshipCode = null;	// NOT in DB! relationship to subscriber
			MedicaidId = null;
			MedicareId = null;
			MemberMORGId = null;		// filling in with Alternate MORG Id
			MemberORGId = null;		// filling in with Alternate ORG Id
			MemberGroupID = null;		// NOT in DB!
			HomePhoneNumber = null;
			WorkPhoneNumber = null;
			WorkPhoneExtension = null;
			Fax = null;
			FaxExtension = null;
			Email = null;
			County = null;
			Race = null;
			EligibilityTerminationDate = new DateTime(1,1,1);
			PlanTerminationDate = new DateTime(1,1,1);
		}// end of method Initialize()
		public string AlternateSubscriberID
		{
			get 
			{
				if (IsSubscriber) 
					  return this.MembershipId; 
				  else 
					  return SubscriberAlternateID; }
			set { SubscriberAlternateID = value; }
		}
		#region variables
		protected Guid		batch_guid;			// UUID for our batching
		protected DateTime	AsOfDate;
		protected string	FirstName;
		protected string	MiddleName;			// NOT in DB!
		protected string	LastName;
		protected string    NameSuffix;			// NOT in DB!
		public	  string	MembershipId;
		protected string	MemberAddress1;
		protected string	MemberAddress2;
		protected string	MemberAddress3;
		protected string	MemberCity;
		protected string	MemberState;
		protected string	MemberCountry;
		protected string	MemberPostalCode;
		protected DateTime	MemberDOB;
		protected string	MemberGender;
		protected string	MemberSSN;
		public string		MemberSORGId;		// filling in with Alternate SORG Id
		protected DateTime	MemberEffectiveDate;
		public	  bool		IsSubscriber	= false;
		protected string	RelationshipCode;	// NOT in DB! relationship to subscriber
		protected string	MedicaidId;
		protected string	MedicareId;
		protected string	MemberMORGId;		// filling in with Alternate MORG Id
		protected string	MemberORGId;		// filling in with Alternate ORG Id
		protected string	MemberGroupID;		// NOT in DB!
		protected string	HomePhoneNumber;
		protected string	WorkPhoneNumber;
		protected string	WorkPhoneExtension;
		protected string	Fax;
		protected string	FaxExtension;
		protected string	Email;
		protected string	County;
		protected string	Race;
		protected DateTime	EligibilityTerminationDate;
		protected DateTime	PlanTerminationDate;
		protected string	SubscriberAlternateID;
		#endregion variables

		public void WriteToStaging(string ConnectionString)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Staging_WriteEligibility", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@asofdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (AsOfDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = AsOfDate;

				inparm				= cmd.Parameters.Add("@firstname", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FirstName;

				inparm				= cmd.Parameters.Add("@lastname", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.LastName;

				inparm				= cmd.Parameters.Add("@membershipid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MembershipId;

				inparm				= cmd.Parameters.Add("@memberaddress1", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MemberAddress1;

				inparm				= cmd.Parameters.Add("@memberaddress2", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MemberAddress2;

				inparm				= cmd.Parameters.Add("@memberaddress3", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				if (null == MemberAddress3) inparm.Value = DBNull.Value; else inparm.Value = MemberAddress3;

				inparm				= cmd.Parameters.Add("@membercity", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MemberCity;

				inparm				= cmd.Parameters.Add("@memberstate", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MemberState;

				inparm				= cmd.Parameters.Add("@membercountry", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MemberCountry;

				inparm				= cmd.Parameters.Add("@memberpostalcode", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MemberPostalCode;

				inparm				= cmd.Parameters.Add("@memberdob", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (MemberDOB.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = MemberDOB;

				inparm				= cmd.Parameters.Add("@membergender", SqlDbType.Char,1);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MemberGender;

				inparm				= cmd.Parameters.Add("@memberssn", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MemberSSN;

				inparm				= cmd.Parameters.Add("@membersorgid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MemberSORGId;

				inparm				= cmd.Parameters.Add("@membereffectivedate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (MemberEffectiveDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = MemberEffectiveDate;

				inparm				= cmd.Parameters.Add("@issubscriber", SqlDbType.Bit,1);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= (IsSubscriber ? 1 : 0);

				inparm				= cmd.Parameters.Add("@medicaidid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MedicaidId;

				inparm				= cmd.Parameters.Add("@medicareid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MedicareId;

				inparm				= cmd.Parameters.Add("@membermorgid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MemberMORGId;

				inparm				= cmd.Parameters.Add("@memberorgid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MemberORGId;

				inparm				= cmd.Parameters.Add("@homephonenumber", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.HomePhoneNumber;

				inparm				= cmd.Parameters.Add("@workphonenumber", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.WorkPhoneNumber;

				inparm				= cmd.Parameters.Add("@workphoneextension", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.WorkPhoneExtension;

				inparm				= cmd.Parameters.Add("@fax", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Fax;

				inparm				= cmd.Parameters.Add("@faxextension", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FaxExtension;

				inparm				= cmd.Parameters.Add("@email", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Email;

				inparm				= cmd.Parameters.Add("@county", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.County;

				inparm				= cmd.Parameters.Add("@race", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Race;

				inparm				= cmd.Parameters.Add("@eligibilityterminationdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (EligibilityTerminationDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = EligibilityTerminationDate;

				inparm				= cmd.Parameters.Add("@planterminationdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (PlanTerminationDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = PlanTerminationDate;

				inparm				= cmd.Parameters.Add("@middlename", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MiddleName;

				inparm				= cmd.Parameters.Add("@namesuffix", SqlDbType.VarChar, 10);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.NameSuffix;

				inparm				= cmd.Parameters.Add("@relationshipcode", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.RelationshipCode;

				inparm				= cmd.Parameters.Add("@alternatesubscriberid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateSubscriberID;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}
		}// end of method WriteToStaging

		public void SetDependentRelationship(DependentRelationship dr)
		{
			this.IsSubscriber	= (dr.YesNoResponseCode != "N");
			switch(dr.IndividualRelationshipCode)
			{
				case "18": // self
					this.RelationshipCode	= "self";
					this.IsSubscriber		= true;
					break;
				case "01":	// spouse
					this.RelationshipCode	= "spouse";		break;
				case "02":
				case "09":
				case "19":
				case "22":
					this.RelationshipCode	= "dependent";	break;
				case "03":
				case "24":
					this.RelationshipCode	= "other";		break;
				default:
					this.RelationshipCode	= "unknown";	break;
			}// end of switch IndividualRelationshipCode
		}// end of method SetDependentRelationship

		public void SetDemographicInfo(DependentDemographicInformation ddi)
		{
			if (ddi.DateTimeFormatQualifier == "D8")
				this.MemberDOB	= ddi.DateTimePeriod;

			this.MemberGender	= ddi.GenderCode;
		}// end of method SetDemographicInfo()

		public void SetDependentName(DependentName nm)
		{
			this.FirstName	= nm.FirstName;
			this.LastName	= nm.LastName;
			this.MiddleName	= nm.MiddleName;
			this.NameSuffix	= nm.NameSuffix;
			switch(nm.IdentificationCodeQualifier)
			{
				case "MI":		// member id
					this.MembershipId	= nm.IdentificationCode;	break;
				case "34":		// SSN
					this.MemberSSN		= nm.IdentificationCode;	break;
				default:
					break;
			}// end of handling identificationcodequalifier
		}// end method SetDependentName

		public void SetDependentAdditionalIdentification(DependentAdditionalIdentification dai)
		{
			switch(dai.ReferenceIdentificationQualifier)
			{
				case "NQ":		// NQ  = Medicare ID
					this.MedicareId		= dai.ReferenceIdentification;	break;
				case "6P":		// 6P = Group ID
					this.MemberGroupID	= dai.ReferenceIdentification;	break;
				case "22":		// 22 or 1M = Alt Sub Organization ID
				case "1M":
					this.MemberSORGId	= dai.ReferenceIdentification;	break;
				case "SY":		// SY = Social Security Number
					this.MemberSSN		= dai.ReferenceIdentification;	break;
				case "23":		// 23 = Alt Master Organization ID
					this.MemberMORGId	= dai.ReferenceIdentification;	break;
				case "75":		// 75 = Alt Organization ID
					this.MemberORGId	= dai.ReferenceIdentification;	break;
				case "1W":		//	1W = Alt Member ID (MEM_PT_ID)
					this.MembershipId	= dai.ReferenceIdentification;	break;
				default:
					break;
			}// end of switch ReferenceIdentificationQualifier

		}// end of method SetDependentAdditionalIdentification
		public void SetDependentAddress(DependentAddress da)
		{
			this.MemberAddress1	= da.AddressLine1;
			this.MemberAddress2	= da.AddressLine2;
		}// end of method SetDependentAddress

		public void SetDependentCityStateZip(DependentCityStateZip dcsz)
		{
			this.MemberCity			= dcsz.CityName;
			this.MemberState		= dcsz.StateProvince;
			this.MemberPostalCode	= dcsz.PostalCode;
			this.MemberCountry		= dcsz.CountryCode;

		}// end of SetDependentCityStateZip

		public void SetDependentDate(DependentDate dd)
		{
			switch (dd.DateTimeQualifier)
			{
				case "356":		// effective date
					this.MemberEffectiveDate		= dd.DateTimePeriod;	break;
				case "357":		// termination date
					this.EligibilityTerminationDate	= dd.DateTimePeriod;	break;
				default:	break;
			}// end of switch dd.DateTimeQualifier
		}
		public void SetDependentContactInformation(DependentContactInformation dci)
		{
			if (dci.ContactFunctionCode != "IC") // not an information contact, get out
				return;

			for (int i = 0; i < 3; i++)
			{
				switch(dci.CommunicationNumberQualifier[i])
				{
					case "HP":	// home phone
						this.HomePhoneNumber	= dci.CommunicationNumber[i];	break;
					case "WP":	// work phone
						this.WorkPhoneNumber	= dci.CommunicationNumber[i];	break;
					default:	break;
				}// end of switch dci.CommunicationNumberQualifier[i]
			}
		}// end of method SetDependentContactInformation()
	}// end of class EligibilityStaging

	
	public class ParseEligibility
	{
		#region parsing array
		IBenefitInquiry []Parser = {new TransactionSetHeader(),					// ST
									   new InterchangeControlHeader(),				// ISA
									   new InterchangeControlTrailer(),			// ISE
									   new GroupHeader(),							// GS
									   new GroupTrailer(),							// GE
									   new DependentLevel(),						// HL
									   new BeginningHierarchicalTransfer(),		// BHT
									   new DependentName(),						// NM1
									   new DependentAdditionalIdentification(),	// REF
									   new DependentAddress(),						// N3
									   new DependentContactInformation(),			// PER
									   new DependentDemographicInformation(),		// DMG
									   new DependentRelationship(),				// INS
									   new DependentDate(),						// DTP
									   new DependentBenefitInformation(),			// EB
									   new DependentBenefitRelatedProvider(),		// PRV
									   new DependentEligibilityInformation(),		// LS

									   new LoopTrailer()							// LE
								   };
		#endregion parsing array
		#region variables
		protected string loopidentifier = "";
		EligibilityStaging pES			= null;
		EligibilityPCPStaging pEPCPS	= null;
		EligibilityPlanStaging pEPS		= null;
		Guid batch_guid					= Guid.NewGuid();
		String ConnectionString			= "";
		string errorLogFileName         = "";
		StreamWriter sw_errorlog		= null;
		bool cancel						= false;
		#endregion variables
		public ParseEligibility()
		{
		}

		~ParseEligibility()
		{
			if (this.sw_errorlog != null)
			{
				sw_errorlog.Flush();
				sw_errorlog.Close();
			}
		}

		/// <summary>
		/// Cancel
		/// Set this property to inform the object that it is being 
		/// canceled from another thread. Note that the variable is
		/// lock'd to avoid thread problems...
		/// </summary>
		public bool Cancel
		{
			set
			{ 
				lock(this)
				{
					cancel = value; 
				}
			}
		}

		/// <summary>
		/// IsCanceled
		/// Returns 'true' to acknowledge that the Cancel
		/// has been received and the object is cleaning up
		/// and canceling.
		/// </summary>
		public bool IsCanceled
		{
			get 
			{
				bool c;
				lock(this)
				{
					c = cancel;
				}
				return c; 
			}
		}

		/// <summary>
		/// WriteErrorLog()
		/// Write a string to the error log. If the file hasn't been
		/// openend, it will be opened. Keeps a member variable to
		/// track the stream.
		/// </summary>
		/// <param name="logmsg">string, error message to display in the log</param>
		int write_error_log_count = 0;
		protected void WriteErrorLog(string logmsg, EventLogEntryType type)
		{
			try
			{
				if (!EventLog.SourceExists("EligibilityInterface") )
					EventLog.CreateEventSource("EligibilityInterface", "ActiveAdvice");
				EventLog.WriteEntry("EligibilityInterface", logmsg, type);

				if (null == sw_errorlog)
				{
					// Let's open an error log
					sw_errorlog = new StreamWriter(this.errorLogFileName, true, System.Text.Encoding.ASCII);
					if (null == sw_errorlog) return;
					sw_errorlog.AutoFlush = true;	// write stuff out immediately so we don't lose it
				}
				sw_errorlog.Write(DateTime.Now.ToString("[mm.dd.yyyy@hh:mm:ss]"));
				sw_errorlog.WriteLine(logmsg);
			}
			catch(Exception ex)
			{
				write_error_log_count++;

				if (write_error_log_count < 15)
				{
					if (!EventLog.SourceExists("EligibilityInterface") )
						EventLog.CreateEventSource("EligibilityInterface", "ActiveAdvice");
					EventLog.WriteEntry("EligibilityInterface", ex.Message, EventLogEntryType.Error);
				}
			}
		}

		//
		// ParseFile():
		// This routine will open up the file and begin parsing the data
		public int ParseFile(System.String FileName, String connection, string errorlogfilename)
		{
			try
			{
				this.errorLogFileName	  = errorlogfilename;
				FileIOPermission filePerm = new FileIOPermission(FileIOPermissionAccess.Read, FileName);
				filePerm.Assert();

				this.ConnectionString	= connection;
				StreamReader sr = new StreamReader(FileName); // File.OpenText(FileName);

				// Now parse the file contents
				ParseX12(sr);

			}
			catch(Exception ex)
			{
				string message = ex.Message;
				if (!EventLog.SourceExists("EligibilityInterface") )
					EventLog.CreateEventSource("EligibilityInterface", "ActiveAdvice");
				EventLog.WriteEntry("EligibilityInterface", ex.Message, EventLogEntryType.Error);
				throw(ex);
			}

			return 0;
		}

		public int ParseX12(StreamReader sr)
		{
			const int max_parts		= 50;
			int line_number			= 0;
			char []splitter			= {'\0', '\0'};	// empty splitter
			DateTime AsOfDate		= DateTime.Now;

			string input_line		= sr.ReadLine();
			if (input_line.Substring(0, 3) == "ISA")
			{
				splitter[0] = input_line[input_line.Length - 2]; // get our delimiter "ISA*.......*P*>"
				//                                 ^--- our delimiter after the 'P'
				splitter[1] = input_line[input_line.Length - 1]; // get our sub-delimiter
			}
			// If the ISA is not the first record, then we don't have a delimiter and can't proceed, throw error
			if (splitter[0] == '\0')
			{
				Exception e = new Exception("ISA not first element, cannot proceed without delimiter! (line #" + line_number.ToString()+")");
				throw e;
			}

			// set the sub-element delimiter into the parsing objects
			if (splitter[1] != '\0')
			{
				for (int i = 0; i < Parser.Length; i++)
					Parser[i].Delimiter = splitter[1];
			}

			// Now walk the rest of the lines in the file...
			do
			{
				// If someone cancels us, then we are done for
				if (IsCanceled)
					return 0; // we are forced to exit...

				line_number++;
				string []parts = input_line.Split(splitter, max_parts);

				string TransactionSetID = parts[0]; // first is the parse code
				IBenefitInquiry po = null;
				for (int i = 0; i < Parser.Length; i++)
				{
					if (Parser[i].TransactionSetID == TransactionSetID)
					{
						Parser[i].ParseHeader(parts, sr);
						po			= Parser[i];
						break; // process the next line...
					}
				}
				if (po == null)
					continue;

				// Validate what we read
				if (!po.ValidateData())
				{
					string msg = "Element invalid, line #" + line_number.ToString() + ", TransactionSetID = " + po.TransactionSetID;
					msg += "\r\nLine = \'" + input_line + "\'";
					this.WriteErrorLog(msg, EventLogEntryType.Warning);
				}

				try
				{
					ProcessElement(po, AsOfDate);
				}
				catch(Exception e)
				{
					string msg = "Element invalid, line #" + line_number.ToString() + ", TransactionSetID = " + po.TransactionSetID;
					msg += "\r\n" + e.Message;
					this.WriteErrorLog(msg, EventLogEntryType.Error);
					if (e.Message == "NOT executing Process step for manual debugging")
						throw e;
				}
			}
			while ( (input_line = sr.ReadLine() ) != null);

			return 0;
		}// end of method ParseX12

		enum LoopType {noLoop = 0, 
			           infosourceLoop     =  20, 
			           inforeceiverLoop   =  21, 
			           subscriberLoop     =  22,
			           subscriberLoop_PCP = 122, // in subscriber loop, fetching PCP information
			           dependentLoop      =  23,
		               dependentLoop_PCP  = 123  // in dependent loop, fetching PCP information
						};
		LoopType loopType				= LoopType.noLoop;
		bool ignoreLoop					= false;
		bool ignoreSubscriber			= false;	// ignore all subscriber related data
		bool eligibilityBenefits		= false;
		string AlternateSubscriberID	= null;
		string AlternatePlanID			= null;
		void ProcessElement(IBenefitInquiry pe, DateTime AsOfDate)
		{
			// Okay we need to do some work on this element
			// Okay we know what we are dealing with
			switch(pe.TransactionSetID)
			{
				case "LS":	// this signals the start of sub-loop data for the Subscriber/Dependent. Typically provider info
					if (loopType == LoopType.dependentLoop)
						loopType = LoopType.dependentLoop_PCP;
					if (loopType == LoopType.subscriberLoop)
						loopType = LoopType.subscriberLoop_PCP;

					loopidentifier		= ((DependentEligibilityInformation)pe).LoopIdentifierCode;
					eligibilityBenefits	= false;
					if (pEPCPS != null)
						pEPCPS.WriteToStaging(ConnectionString);
					if (pEPS != null)
					{
						pEPS.WriteToStaging(ConnectionString);
						AlternatePlanID	= pEPS.PlanID;
						pEPS			= null;
					}
					pEPCPS = new EligibilityPCPStaging(batch_guid, AsOfDate, pES.MembershipId, pES.MemberSORGId, AlternatePlanID);
					break;
				case "LE":
					string ending_loopidentifier = ((LoopTrailer)pe).LoopIdentifierCode;
					if (ending_loopidentifier != loopidentifier)
					{
						// This is a problem, we are ending a different loop, error with the data
						return;
					}
					loopidentifier = null; // restart the loop
					// Flush out data accumulated during the loop
					if (!ignoreLoop && !ignoreSubscriber)
					{
						if (pES != null)
						{
							pES.WriteToStaging(ConnectionString);
							pES		= null;
						}
						if (pEPCPS != null) 
						{
							pEPCPS.WriteToStaging(ConnectionString);
							pEPCPS	= null;
						}
						if (pEPS != null)
						{
							pEPS.WriteToStaging(ConnectionString);
							pEPS	= null;
						}
					}
					break;
				case "HL":
					// Flush out data accumulated during the loop
					eligibilityBenefits	= false;
					if (!ignoreLoop && !ignoreSubscriber)
					{
						if (pES != null)
							pES.WriteToStaging(ConnectionString);
						if (pEPCPS != null)
							pEPCPS.WriteToStaging(ConnectionString);
						if (pEPS != null)
							pEPS.WriteToStaging(ConnectionString);
					}

					// Get ready for new element
					ignoreLoop  = false;
					pES			= new EligibilityStaging(batch_guid, AsOfDate);
					pEPCPS		= null;
					pEPS		= null;
					int levelcode = Convert.ToInt32(( (DependentLevel)pe).HierarchicalLevelCode);
					switch(levelcode)
					{
						case 20:	// info source receiver
							loopType = LoopType.infosourceLoop;
							ignoreLoop = true;
							break;
						case 21:	// info receiver
							loopType = LoopType.inforeceiverLoop;
							ignoreLoop = true;
							break;
						case 22:	// subscriber
							loopType					= LoopType.subscriberLoop;
							ignoreLoop					= false;
							ignoreSubscriber			= false;
							AlternateSubscriberID		= null;
							break;
						case 23:	// dependent
							loopType					= LoopType.dependentLoop;
							ignoreLoop					= false;
							pES.AlternateSubscriberID	= AlternateSubscriberID;
							break;
						default:
							ignoreLoop = true;	// if we don't know what it is - ignore it!
							break;
					}
					break;
				case "DMG":
						pES.SetDemographicInfo((DependentDemographicInformation)pe);			break;
				case "NM1":
					switch(loopType)
					{
						case LoopType.subscriberLoop:
						case LoopType.dependentLoop:
							pES.SetDependentName((DependentName)pe);
							break;
						case LoopType.subscriberLoop_PCP:
						case LoopType.dependentLoop_PCP:
							this.pEPCPS.SetDependentName((DependentName)pe);
							break;
						default:
							break;
					}
					break;
				case "N3":
					switch(loopType)
					{
						case LoopType.subscriberLoop:
						case LoopType.dependentLoop:
							pES.SetDependentAddress((DependentAddress)pe);
							break;
						case LoopType.subscriberLoop_PCP:
						case LoopType.dependentLoop_PCP:
							pEPCPS.SetDependentAddress((DependentAddress)pe);
							break;
						default:
							break;
					}
					break;
				case "N4":
					switch(loopType)
					{
						case LoopType.subscriberLoop:
						case LoopType.dependentLoop:
							pES.SetDependentCityStateZip((DependentCityStateZip)pe);
							break;
						case LoopType.subscriberLoop_PCP:
						case LoopType.dependentLoop_PCP:
							pEPCPS.SetDependentCityStateZip((DependentCityStateZip)pe);
							break;
						default:
							break;
					}
					break;
				case "DTP":
					switch(loopType)
					{
						case LoopType.subscriberLoop:
						case LoopType.dependentLoop:
							if (eligibilityBenefits)
								pEPS.SetDependentDate((DependentDate)pe);
							else
								pES.SetDependentDate((DependentDate)pe);
							break;
						case LoopType.subscriberLoop_PCP:
						case LoopType.dependentLoop_PCP:
							pEPCPS.SetDependentDate( (DependentDate)pe);
							break;
						default:
							break;
					}
					break;
				case "PER":
						pES.SetDependentContactInformation( (DependentContactInformation)pe);	break;
				case "INS":
					pES.SetDependentRelationship( (DependentRelationship)pe);
					if (pES.IsSubscriber)
						AlternateSubscriberID = pES.AlternateSubscriberID;
					break;
				case "EB":
					eligibilityBenefits	= true;
					pEPS = new EligibilityPlanStaging(batch_guid, AsOfDate, pES.MembershipId, pES.MemberSORGId);
					pEPS.SetDependentBenefitInformation( (DependentBenefitInformation)pe);
					break;
				case "REF":
					if (eligibilityBenefits)
					{
						pEPS.SetDependentAdditionalIdentification( (DependentAdditionalIdentification)pe);
						AlternatePlanID = pEPS.PlanID;
					}
					else
						pES.SetDependentAdditionalIdentification( (DependentAdditionalIdentification)pe);
					break;
				case "PRV":
					pEPCPS.SetDependentBenefitRelatedProvider( (DependentBenefitRelatedProvider)pe);
					break;
				case "IEA":		// Interchange Control Trailer - end of file
					EligibilityDB edb = new EligibilityDB();
					Exception e = new Exception("NOT executing Process step for manual debugging");
					throw e;
//					edb.ProcessStaging(ConnectionString, batch_guid, AsOfDate);
//					break;
				default:
					break;
			}// end of switch TransactionSetID


		}// end of method ProcessElement()

		/// <summary>
		/// SQLexceptionHandler()
		/// This method will process SQL exceptions and print out the
		/// parameters associated with the command object.
		/// </summary>
		/// <param name="cmd">SqlCommand, the command that had the error</param>
		/// <param name="se">SqlException, the exception that was caught</param>
		public static void SQLexceptionHandler(SqlCommand cmd, SqlException se)
		{
			string msg = cmd.CommandText + " failure\nParameters:\n";
			for (int i = 0; i < cmd.Parameters.Count; i++)
			{
				try
				{
					msg += "    " + cmd.Parameters[i].ParameterName + "=" + (cmd.Parameters[i].Value == null ? "<null>" : cmd.Parameters[i].Value.ToString()) + "\n";
				}
				catch(Exception ex)
				{
					string messg = ex.Message;
				}
			}
			msg += "\n{Inner Exception}\n" + se.Message;
			Exception e = new Exception(msg, se);
			throw e;
		}// end of method SQLexceptionhandler

	}// end of class ParseEligibility

	class EligibilityDB
	{
		public int ProcessStaging(string ConnectionString, Guid batch, DateTime AsOfDate)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd		= new SqlCommand("usp_Staging_ProcessEligibility", connection);
				cmd.CommandTimeout	= 300; // 5 minutes
				cmd.CommandType		= CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= batch;

				inparm				= cmd.Parameters.Add("@asofdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (AsOfDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = AsOfDate;

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}

			return rowsAffected;
		}// end of method WriteProvider()
	}// end of class EligibilityDB

}// end of namespace

