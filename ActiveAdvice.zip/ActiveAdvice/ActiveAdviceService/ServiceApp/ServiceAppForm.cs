using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using ActiveAdviceService; // so we can startup like a service

namespace ServiceApp
{
	/// <summary>
	/// Summary description for ServiceAppForm.
	/// </summary>
	public class ServiceAppForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.ListBox lstbxMessages;
		private System.Windows.Forms.Button btnStartInterface;
		private System.Windows.Forms.Button btnExit;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ServiceAppForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnCancel = new System.Windows.Forms.Button();
			this.lstbxMessages = new System.Windows.Forms.ListBox();
			this.btnStartInterface = new System.Windows.Forms.Button();
			this.btnExit = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(160, 280);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.TabIndex = 0;
			this.btnCancel.Text = "&Cancel";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// lstbxMessages
			// 
			this.lstbxMessages.Location = new System.Drawing.Point(16, 32);
			this.lstbxMessages.Name = "lstbxMessages";
			this.lstbxMessages.Size = new System.Drawing.Size(376, 212);
			this.lstbxMessages.TabIndex = 1;
			// 
			// btnStartInterface
			// 
			this.btnStartInterface.Location = new System.Drawing.Point(16, 280);
			this.btnStartInterface.Name = "btnStartInterface";
			this.btnStartInterface.TabIndex = 2;
			this.btnStartInterface.Text = "&Interface";
			this.btnStartInterface.Click += new System.EventHandler(this.btnStartInterface_Click);
			// 
			// btnExit
			// 
			this.btnExit.Location = new System.Drawing.Point(312, 280);
			this.btnExit.Name = "btnExit";
			this.btnExit.TabIndex = 3;
			this.btnExit.Text = "E&xit";
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// ServiceAppForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(416, 318);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.btnStartInterface);
			this.Controls.Add(this.lstbxMessages);
			this.Controls.Add(this.btnCancel);
			this.Name = "ServiceAppForm";
			this.Text = "Service Application";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new ServiceAppForm());
		}

		ServiceMain sm = null;
		private void btnStartInterface_Click(object sender, System.EventArgs e)
		{
			if (null == sm)
			{
				sm = new ServiceMain();
				sm.Start();

				this.lstbxMessages.Items.Add("service threads started");
			}
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			if (null != sm)
			{
				sm.Stop();
				sm = null;
				this.lstbxMessages.Items.Add("service threads stopped");
			}
		}

		private void btnExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}
	}
}
