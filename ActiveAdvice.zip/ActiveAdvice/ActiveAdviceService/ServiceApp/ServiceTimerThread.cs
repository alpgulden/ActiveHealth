using System;
using System.IO;		// Path class
using System.Threading;
using System.Diagnostics;
using InterfaceReader;	// classes to process interface data
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;

namespace ActiveAdviceService
{
	/// <summary>
	/// ServiceTimerThread
	/// This class serves as the "body" for the thread
	/// spawned from the Service startup. 
	/// </summary>
	public class ServiceTimerThread
	{
		protected string connectionstring; // access to database
		public string ConnectionString
		{
			set {connectionstring = value;}
			get {return connectionstring; }
		}

		protected string authorizationpath;
		public string AuthorizationPath
		{
			set {authorizationpath = value; }
			get {return authorizationpath; }
		}
		protected string errorlogpath;
		public string ErrorLogPath
		{
			set {errorlogpath = value;}
			get {return errorlogpath;}
		}

		protected string eventlogsource;
		protected string eventlogname;
		protected string eventlogmachine;
		public string EventLogSource
		{
			get { return eventlogsource; }
			set { eventlogsource = value; }
		}
		public string EventLogName
		{
			get { return eventlogname;}
			set {eventlogname = value; }
		}
		public string EventLogMachine
		{
			get {return eventlogmachine; }
			set {eventlogmachine = value; }
		}
		public ServiceTimerThread()
		{
		}

		#region Cancel Logic
		protected bool canceled = false;
		/// <summary>
		/// Cancel
		/// Set this property to inform the object that it is being 
		/// canceled from another thread. Note that the variable is
		/// lock'd to avoid thread problems...
		/// </summary>
		public bool Cancel
		{
			set
			{
				lock(this)
				{
					canceled = value;
				}
			}
			get
			{
				bool c;
				lock(this)
				{
					c = canceled;
				}
				return c;
			}
		}

		protected bool iscanceled = false;
		/// <summary>
		/// IsCanceled
		/// Returns 'true' to acknowledge that the Cancel
		/// has been received and the object is cleaning up
		/// and canceling.
		/// </summary>
		public bool IsCanceled
		{
			get
			{
				bool c;
				lock(this)
				{
					c = iscanceled;
				}

				return c; 
			}
			set
			{
				lock(this)
				{
					iscanceled = value;
				}
			}
		}
		#endregion

		/// <summary>
		/// ThreadStart()
		/// Here is where we actually run the thread. This thread
		/// is sleeping for 30 seconds and then looking for work. It's
		/// "single threaded" in that it'll only process one task at 
		/// a time.
		/// </summary>
		EventLog srvApplicationEvent = null;
		public void ThreadStart()
		{
			bool pause = false;
			while(pause)
			{
				Thread.Sleep(500);
			}

			// Initialize the event log
			srvApplicationEvent = new EventLog(EventLogName, EventLogMachine, EventLogSource);

			this.InitializeCodeTables();	// load up the code table values
			// This is where the thread work is done, so just wake up periodically
			IsCanceled = false;
			TimeSpan ts = new TimeSpan(0,0,1); // 1 second
			while(true)
			{
				// wait 30 seconds, but check for cancel every
				// second to reduce latency...
				for (int i = 0; i < 30 && !Cancel; i++)
					Thread.Sleep(ts); // sleep for 1 second

				if (Cancel)	break;

				ScheduleTask st = this.GetPendingScheduleTask();
				if (null == st)	continue; // nothing to do, go back to sleep

				// We have some work to perform
				PerformTask(st, this.ErrorLogPath);
			}

			IsCanceled = true;
		}// end of threading method

		ScheduleTypeCollection scheduleTypes		= null;
		ScheduleStatusCollection scheduleStatuses	= null;
		/// <summary>
		/// InitializeCodeTables()
		/// at the start of the thread we need to load up our
		/// code table values. This only has to be done once.
		/// </summary>
		protected void InitializeCodeTables()
		{
			try
			{
				scheduleTypes		= new ScheduleTypeCollection();
				scheduleTypes.LoadScheduleTypeByActive(-1, true);
				scheduleStatuses	= new ScheduleStatusCollection();
				scheduleStatuses.LoadScheduleStatusByActive(-1, true);
			}
			catch(Exception e)
			{
				String msg = String.Format("Error initializing code tables! {0}", e.Message);
				this.srvApplicationEvent.WriteEntry(msg, EventLogEntryType.Error);
			}
		}// end of method

		/// <summary>
		/// PerformTask()
		/// This method will determine what type of task
		/// is at hand and dispatch the appropriate worker
		/// class
		/// </summary>
		/// <param name="st">ScheduleTask object that needs to be worked on</param>
		/// <param name="errorpath">NTFS file path where error log should be placed</param>
		protected void PerformTask(ScheduleTask st, string errorpath)
		{
			// Figure out what type of task work we need to perform...
			string TaskType = "Undefined";
			try
			{
				TaskType = MapType(st.ScheduleTypeID);
				UpdateTaskStatus(st, "RUN");
				switch(TaskType)
				{
					// Inputs
					case "ICM":  // read in a scoring load
						this.ProcessScoringLoad(new ScoringLoadArguments(st.Task, errorpath));			break;
					case "ELIG": // import eligibility data
						this.ProcessEligibility(new TaskArguments(st.Task, errorpath));					break;
					case "PROV": // read Provider/Facility/Group Practice/Network data
						this.ProcessProvider(new TaskArguments(st.Task, errorpath));					break;

					// Outputs
					case "AUTH": // write Authorization file
						this.ProcessAuthorization(new AuthorizationArguments(st.Task, errorpath));		break;
					case "CENG": // write out Care Engine data
						this.ProcessCareEngine(new CEExportArguments(st.Task, errorpath));				break;
					case "MEMB": // write out membership data
						this.ProcessMembershipFile(new TaskArguments(st.Task, errorpath), st.JobID);	break;
					default:
						UpdateTaskStatus(st, "FAIL");													return;
				}// end of switch(tasktype)
			}
			catch(Exception e)
			{
				UpdateTaskStatus(st, "FAIL");
				String msg = String.Format("Error with import/export of {0} data operation! {1}", TaskType, e.Message);
				try
				{
					this.srvApplicationEvent.WriteEntry(msg, EventLogEntryType.Error);
				}
				catch(Exception ex)
				{
					string message = ex.Message;
				}
				return;
			}

			// No exceptions, then everything is alright...
			UpdateTaskStatus(st, "DONE");
		}// end of method

		/// <summary>
		/// UpdateTaskStatus()
		/// This method will write out the new, updated status to the
		/// specified task.
		/// </summary>
		/// <param name="st">ScheduleTask, instance to update</param>
		/// <param name="newStatus">string, new status (need to look up code-table id)</param>
		protected void UpdateTaskStatus(ScheduleTask st, string newStatus)
		{
			for (int i = 0; i < scheduleStatuses.Count; i++)
			{
				if (scheduleStatuses[i].Code == newStatus)
				{
					// have a status
					st.ScheduleStatusID = scheduleStatuses[i].ScheduleStatusID;
					if (newStatus == "RUN")
						st.StartTime = DateTime.Now;
					if ( (newStatus == "DONE") || (newStatus == "FAIL") )
						st.EndTime   = DateTime.Now;
					st.Update(); // write to the db
					return;
				}
			}
		}// end of method UpdateTaskStatus()


		protected void ProcessAuthorization(AuthorizationArguments aa)
		{
			AuthorizationExport ae = new AuthorizationExport(aa, this.AuthorizationPath);
		}
		protected void ProcessCareEngine(CEExportArguments args)
		{
			CEExportFormatter cef = new CEExportFormatter(args);
		}

		/// <summary>
		/// ProcessMembershipFile()
		/// this method will process the task that 
		/// will generate a "membership file" output
		/// file. These files can be quite large
		/// </summary>
		/// <param name="ta">TaskArguments, arguments for this task</param>
		/// <param name="jobid">int, the jobid of the task to execute</param>
		protected void ProcessMembershipFile(TaskArguments ta, int jobid)
		{
			MemberLogWriter mlw = new MemberLogWriter();
			mlw.ParseFile(ta.FileName, this.ConnectionString, ta.ErrorLogFileName, jobid);
		}

		/// <summary>
		/// ProcessScoringLoad()
		/// this method will perform the parsing and inputing
		/// of the scoring load data.
		/// </summary>
		/// <param name="sla">contains the arguments for scoring load</param>
		protected void ProcessScoringLoad(ScoringLoadArguments sla)
		{
			this.errorlogpath	= sla.ErrorLogPath;
			ScoringLoadReader slr = new ScoringLoadReader();
			slr.ParseFile(sla.FileName, this.ConnectionString, sla.ErrorLogFileName);
		}// end of method

		/// <summary>
		/// ProcessProvider()
		/// performs the parsing and inputing of the
		/// Provider/Group Practice/Facility/Network interface
		/// data.
		/// </summary>
		/// <param name="ta">contains the arguments for this task (filename)</param>
		protected void ProcessProvider(TaskArguments ta)
		{
			// First see if we are dealing with a single file
			if (File.Exists(ta.FileName))
			{
				ProviderParser pp = new ProviderParser();
				int status = pp.ParseFile(ta.FileName, this.ConnectionString, ta.ErrorLogFileName);
				return;
			}

			// Okay, see if this is a directory and has at least 1 file in it
			// See if this is a directory....
			DirectoryInfo di = new DirectoryInfo(ta.FileName);	
			if (!di.Exists)
				return;	// invalid file/directory name

			// Are there any files in this directory???
			FileInfo[] files = di.GetFiles();
			if (files.Length < 1)
				return;		// no files, write it out

			// Okay, process all the files in the directory...
			for (int i = 0; i < files.Length; i++)
			{
				ProviderParser pp = new ProviderParser();
				int status = pp.ParseFile(files[i].FullName, this.ConnectionString, ta.ErrorLogFileName);
			}

		}// end of method

		/// <summary>
		/// ProcessEligibility()
		/// performs the parsing and inputing of the
		/// Eligibility interface data.
		/// </summary>
		/// <param name="ta">contains the arguments for this task (filename)</param>
		protected void ProcessEligibility(TaskArguments ta)
		{
			ParseEligibility pe = new ParseEligibility();
			int status = pe.ParseFile(ta.FileName, this.ConnectionString, ta.ErrorLogFileName);
		}// end of method

		/// <summary>
		/// MapType()
		/// return the "type" code value for this 
		/// foreign key
		/// </summary>
		/// <param name="ScheduleTypeID">integer foreign key into ScheduleType table</param>
		/// <returns></returns>
		protected string MapType(int ScheduleTypeID)
		{
			for (int i = 0; i < scheduleTypes.Count; i++)
			{
				if (scheduleTypes[i].ScheduleTypeID == ScheduleTypeID)
					return scheduleTypes[i].Code;
			}
			return null;
		}

		/// <summary>
		/// GetPendingScheduleTask()
		/// This method will return the first, pending schedule task
		/// from the schedule list.
		/// </summary>
		/// <returns>ScheduleTask, instance of a ScheduleTask that is pending</returns>
		protected ScheduleTask GetPendingScheduleTask()
		{
			try
			{
				for (int i = 0; i < scheduleStatuses.Count; i++)
				{
					ScheduleStatus status = scheduleStatuses[i];
					if (status.Code == "PEND")
					{
						ScheduleTaskCollection scheduleTasks	= new ScheduleTaskCollection();
						scheduleTasks.LoadScheduleTasksByStatus(-1, status.ScheduleStatusID);
						if (scheduleTasks.Count > 0)
							return (ScheduleTask)scheduleTasks.GetAt(0);
					}
				}// end of searching
			}
			catch(Exception e)
			{
				String msg = String.Format("Error initializing code tables! {0}", e.Message);
				this.srvApplicationEvent.WriteEntry(msg, EventLogEntryType.Error);
			}

			return null;
		}
	}// end of ServiceTimerThread


}// end of namespace
