using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Threading;			// Thread() class
using NetsoftUSA.Security;		// for the "confighelper" class to get connecting string from registry
using NetsoftUSA.DataLayer;

namespace ActiveAdviceService
{
	public class ServiceMain : System.ServiceProcess.ServiceBase
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ServiceMain()
		{
			// This call is required by the Windows.Forms Component Designer.
			InitializeComponent();
		}

		// The main entry point for the process
#if WINAPP
#else
static void Main()
		{
			System.ServiceProcess.ServiceBase[] ServicesToRun;
	
			// More than one user Service may run within the same process. To add
			// another service to this process, change the following line to
			// create a second service object. For example,
			//
			//   ServicesToRun = new System.ServiceProcess.ServiceBase[] {new Service1(), new MySecondUserService()};
			//
			ServicesToRun = new System.ServiceProcess.ServiceBase[] { new ServiceMain() };

			System.ServiceProcess.ServiceBase.Run(ServicesToRun);
		}
#endif
		EDIwatcher watcher = null;
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// ServiceMain
			// 
			this.ServiceName = "AAservice";
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
#if WINAPP
		public void Start()
		{
			string[] args = null;
			OnStart(args);
		}

		public void Stop()
		{
			OnStop();
		}
#endif
		/// <summary>
		/// Set things in motion so your service can do its work.
		/// </summary>
		/// 
		Thread workerThread		= null;
		ServiceTimerThread st	= null;
		protected override void OnStart(string[] args)
		{
			try
			{
				if (GetConfiguration())
				{
					ConfigureWatcher();
					// First try to get the connection string, if we don't get it,
					// then we are done...
					st						= new ServiceTimerThread();
					st.ConnectionString		= this.ConnectionString;
					st.ErrorLogPath			= this.ErrorLogPath;
					st.AuthorizationPath	= this.AuthorizationPath;	// where our authorization output files go (including error logs)
					st.EventLogSource		= this.EventLogSource;
					st.EventLogName			= this.EventLogName;
					st.EventLogMachine		= this.EventLogMachine;
					this.workerThread		= new Thread(new ThreadStart(st.ThreadStart));
					workerThread.Name		= "AA Service Timer Thread";
					workerThread.Start();
				}
				else
				{
					Exception ex = new Exception("could not retrieve configuration information", null);
					throw ex;
				}
			}
			catch(Exception e)
			{
				if (!EventLog.SourceExists("TimerService") )
					EventLog.CreateEventSource("TimerService", "ActiveAdvice");
				EventLog.WriteEntry("TimerService", "Failed to start service\r\n" + e.Message, EventLogEntryType.Error);
				return;
			}

			if (!EventLog.SourceExists("TimerService") )
				EventLog.CreateEventSource("TimerService", "ActiveAdvice");
			EventLog.WriteEntry("TimerService", "Service successfully started", EventLogEntryType.Information);
		}

		protected bool ConfigureWatcher()
		{
			bool pause =  false;
			while(pause)
			{
				Thread.Sleep(500);
			}
			// 
			// EDIwatcher
			// Initialize the filewatcher
			// 
			watcher = new EDIwatcher(this.EDIPath, this.ConnectionString);
			((System.ComponentModel.ISupportInitialize)(this.watcher)).BeginInit();

			((System.ComponentModel.ISupportInitialize)(this.watcher)).EndInit();

			return true;
		}

		/// <summary>
		/// Stop this service.
		/// </summary>
		protected override void OnStop()
		{
			if (st != null)
			{
				st.Cancel = true;
				int i = 0;
				while(!st.IsCanceled && i < 12) // give it 1 minute
				{
					Thread.Sleep(new TimeSpan(0,0,5) ); // wait 5 seconds
					i++;
				}

				if (!st.IsCanceled)
				{
					// Make a note that we are exiting the thread
					// forcefully
					if (!EventLog.SourceExists("TimerService") )
						EventLog.CreateEventSource("TimerService", "ActiveAdvice");
					EventLog.WriteEntry("TimerService", "Timer thread forcefully exited", EventLogEntryType.Error);
				}
			}// end of stopping the Timer thread
			
			base.OnStop();
		}

		protected string EventLogSource;		// the event log source
		protected string EventLogName;			// the event log name
		protected string EventLogMachine;		// what machine to write event log info to
		protected string ConnectionString;		// connection string to the database
		protected string ErrorLogPath;			// where error logs should be
		protected string AuthorizationPath;		// where authorization files (EVT.X12 & REF.X12) are written
		protected string EDIPath;               // path where we watch for EDI authorization requests (MA EDI)

		/// <summary>
		/// GetConfiguration()
		/// Attempts to retrieve the necessary configuration information for
		/// the service to run. Must get the encrypted connection string
		/// or return failure, this will stop the service startup.
		/// </summary>
		/// <returns></returns>
		protected bool GetConfiguration()
		{
			EventLogSource	= ConfigHelper.GetConfigValue("ApplicationName");
			EventLogName	= ConfigHelper.GetConfigValue("EventLogName");
			EventLogMachine = ConfigHelper.GetConfigValue("EventLogMachine");
			string encryptedConnectionString = null;
			try
			{
				string ConnectionStringRegistryPath		 = ConfigHelper.GetConfigValue("ConnectionStringRegistryPath");
				string ConnectionStringRegistryKey		= ConfigHelper.GetConfigValue("ConnectionStringRegistryKey");
				encryptedConnectionString				= ConfigHelper.GetRegistryValue(ConnectionStringRegistryPath, ConnectionStringRegistryKey);
				string ErrorLogPathRegistryPath			= ConfigHelper.GetConfigValue("ErrorLogPathRegistryPath");
				string ErrorLogPathRegistryKey			= ConfigHelper.GetConfigValue("ErrorLogPathRegistryKey");
				ErrorLogPath							= ConfigHelper.GetRegistryValue(ErrorLogPathRegistryPath, ErrorLogPathRegistryKey); 
				string AuthorizationPathRegistryPath	= ConfigHelper.GetConfigValue("AuthorizationPathRegistryPath");
				string AuthorizationPathRegistryKey		= ConfigHelper.GetConfigValue("AuthorizationPathRegistryKey");
				AuthorizationPath						= ConfigHelper.GetRegistryValue(AuthorizationPathRegistryPath, AuthorizationPathRegistryKey); 
				string EDIPathRegistryPath	            = ConfigHelper.GetConfigValue("EDIPathRegistryPath");
				string EDIPathRegistryKey		        = ConfigHelper.GetConfigValue("EDIPathRegistryKey");
				EDIPath                                 = ConfigHelper.GetRegistryValue(EDIPathRegistryPath, EDIPathRegistryKey); 
			}
			catch(Exception ex)
			{
				EventLog.WriteEntry("An error occurred while reading the connection string from registry. Error Details: " + ex.Message, EventLogEntryType.Error);
				throw new Exception(String.Format("An error occurred while reading the connection string from registry. Error Details: {0}", ex.Message), ex);
			}

			try
			{
				ConnectionString = CryptoHelper.Decrypt(encryptedConnectionString);
				NSGlobal.ConnectionString	= ConnectionString;

			}
			catch (Exception ex)
			{
				EventLog.WriteEntry("An error occurred while decrypting the connection string. Error Message:" + ex.Message, EventLogEntryType.Error);
				return false;
			}
			
			return true;
		}

	}// end of class ServiceMain
}// end of namespace
