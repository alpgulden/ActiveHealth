using System;
using System.IO;
using System.Diagnostics;
using System.Globalization; // for DateTime.ParseExact()

namespace X12Parsing
{

	public interface IBenefitInquiry
	{
		string	TransactionSetID{ get;}
		void	ParseHeader(string []parts, StreamReader sr);	// parse the data from the file
		bool	ValidateData();									// Verify the integrity of the data
		char    Delimiter { set; }
	}// end of interface IBenefitInquiry

	public class ParsingFunctions
	{
		public static string[] Splitter(string line, char[] separator, int count)
		{
			string [] parts = line.Split(separator, count);
			for (int i = 0; i < parts.Length; i++)
			{
				if (parts[i] == "")
					parts[i] = null;
			}

			return parts;
		}

		public static DateTime DateTimeParse(string date, string time)
		{
			if ( (date == null) || (date.Length < 6) )
				return DateTime.MinValue;

			int year = 0, month = 0, day = 0, hour = 0, second = 0, minute = 0, millisecond = 0;

			if (date.Length > 6)
			{
				year = Convert.ToInt32(date.Substring(0,4));
				month = Convert.ToInt32(date.Substring(4,2) );
				day   = Convert.ToInt32(date.Substring(6,2) );
			}
			else
			{
				year = Convert.ToInt32(date.Substring(0,2) );
				year += (year < 50 ? 2000 : 1900);
				month = Convert.ToInt32(date.Substring(2,2) );
				day   = Convert.ToInt32(date.Substring(4,2) );
			}

			if (time != null)
			{
				hour = Convert.ToInt32(time.Substring(0,2));
				minute = Convert.ToInt32(time.Substring(2,2) );
				if (time.Length > 4)
					second = Convert.ToInt32(time.Substring(4,2) );
				if (time.Length > 6)
					millisecond = Convert.ToInt32(time.Substring(6,2) );
			}

			return new DateTime(year, month, day, hour, minute, second, millisecond);
		}
	}

	public class TransactionSetHeader : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }

		public string TransactionSetID { get {return "ST";} }
		public bool ValidateData()
		{
			if ( (this.TransactionSetControlNumber == null) || (this.TransactionSetControlNumber == "") )
				return false;
			if ( (this.TransactionSetIdentifierCode == null) || (this.TransactionSetIdentifierCode == "") )
				return false;
			return true;
		}// end of method ValidateData
		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.TransactionSetIdentifierCode	= parts[1];
			this.TransactionSetControlNumber	= parts[2];
		}

		public string TransactionSetIdentifierCode;		// ST01
		public string TransactionSetControlNumber;		// ST02
	}// end of class TransactionSetHeader

	public class InterchangeControlHeader : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }

		public bool ValidateData() { return true; }
		public string TransactionSetID { get {return "ISA";} }

		public void ParseHeader(string []parts, StreamReader sr)
		{
			AuthorizationInformationQualifier = (parts[1] == "03");
			if (AuthorizationInformationQualifier)
				AuthorizationInformation = parts[2];
			SecurityInformationQualifier = (parts[3] == "01"); // password
			if (SecurityInformationQualifier)
				SecurityInformation = parts[4];
			InterchangeIDQualifier = parts[5];
			InterchangeSenderID    = parts[6];
			InterchangeIDQualifierReceiver = parts[7];
			InterchangeReceiverID  = parts[8];
			// combine the Interchange Date & Time into one variable...
			InterchangeDateTime = ParsingFunctions.DateTimeParse(parts[9], parts[10]);
			InterchangeControlStandardsIdentifier = parts[11];
			InterchangeControlVersionNumber       = parts[12];
			InterchangeControlNumber              = parts[13];
			AcknowledgementRequested              = (parts[14] == "1");
			UsageIndicator                        = parts[15];
			ComponentElementSeparator             = parts[16];
		}

		public bool AuthorizationInformationQualifier; // ISA01: =true, additional id information present
		public string AuthorizationInformation;        // ISA02:login id
		public bool SecurityInformationQualifier;       // ISA03
		public string SecurityInformation;             // ISA04:password
		public string InterchangeIDQualifier;          // ISA05
		public string InterchangeSenderID;             // ISA06
		public string InterchangeIDQualifierReceiver;  // ISA07
		public string InterchangeReceiverID;           // ISA08
		public DateTime InterchangeDateTime;           // ISA09: YYMMDD, ISA10: HHMM
		public string InterchangeControlStandardsIdentifier; // ISA11
		public string InterchangeControlVersionNumber; // ISA12
		public string InterchangeControlNumber;        // ISA13
		public bool AcknowledgementRequested;          // ISA14
		public string UsageIndicator;                  // ISA15: "Production"/"Test"
		public string ComponentElementSeparator;       // ISA16: delimiter character not in data
	}// end of class InterchangeControlHeader

	public class InterchangeControlTrailer : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }

		public bool ValidateData()
		{
			return true;
		}
		public string TransactionSetID{	get {return "IEA";}}

		public void ParseHeader(string []parts, StreamReader sr)
		{
			NumberIncludedFunctionalGroups	= (parts.Length > 1 ? Convert.ToInt32(parts[1]) : -1);
			InterchangeControlNumber		= (parts.Length > 2 ? parts[2] : null);
		}
		public int NumberIncludedFunctionalGroups;		// IEA01
		public string InterchangeControlNumber;		    // IEA02
	}// end of class InterchangeControlTrailer

	public class GroupHeader : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }

		public bool ValidateData()
		{
			if (this.FunctionalIdentifierCode == "") //  != "HB") // HB is only for eligibility, parsing being shared
				return false;
			if (this.GroupControlNumber == "")
				return false;

			return true;
		}
		public string TransactionSetID{	get{ return "GS";}}

		public void ParseHeader(string []parts, StreamReader sr)
		{
			FunctionalIdentifierCode = parts[1];
			ApplicationSendersCode   = parts[2];
			ApplicationReceiversCode = parts[3];

			// combine the Date & Time into one variable...
			HeaderDateTime = ParsingFunctions.DateTimeParse(parts[4], parts[5]);
			GroupControlNumber				= parts[6];
			ResponsibleAgencyCode			= parts[7];
			VersionReleaseIndustryIDCode	= parts[8];
		}

		public string FunctionalIdentifierCode;				// GS01
		public string ApplicationSendersCode;				// GS02
		public string ApplicationReceiversCode;				// GS03
		public DateTime HeaderDateTime;						// GS04:CCYYMMDD, GS05:HHMM
		public string	GroupControlNumber;					// GS06, must match GE02
		public string	ResponsibleAgencyCode;				// GS07, = 'X', accredited ANSI standards committee X12
		public string	VersionReleaseIndustryIDCode;		// GS08

	}// end of class GroupHeader

	public class GroupTrailer : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }

		public bool ValidateData()
		{
			return true;
		}
		public string TransactionSetID{	get{return "GE";}}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			NumberTransactionSets	= Convert.ToInt32(parts[1]);
			GroupControlNumber		= parts[2];
		}

		public int NumberTransactionSets;				// GE01, count of ST/SE transactions
		public string GroupControlNumber;				// GE02
	}// end of class GroupTrailer

	public class BeginningHierarchicalTransfer : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }

		public bool ValidateData()
		{
			if ( (this.HierarchicalStructureCode == null) || (this.HierarchicalStructureCode == "") )
				return false;
//			if ( (this.TransactionSetPurposeCode == null) || (this.TransactionSetPurposeCode == "") )
//				return false;

			return true;
		}
		public string TransactionSetID{	get{return "BHT";}}

		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.HierarchicalStructureCode	= parts[1];
			this.TransactionSetPurposeCode	= parts[2];
			this.ReferenceIdentification	= parts[3];
			this.HierarchicalDate			= ParsingFunctions.DateTimeParse(parts[4], parts[5]);
		}

		// combine the Date & Time into one variable...
		public string HierarchicalStructureCode;		// BHT01
		public string TransactionSetPurposeCode;		// BHT02
		public string ReferenceIdentification;			// BHT03 <optional>
		public DateTime HierarchicalDate;				// BHT04:CCYYMMDD /BHT05:HHMMSSDD date & time

	}// end of class BeginningHierarchicalTransfer

	public class DependentLevel : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }

		public bool ValidateData()
		{
			return (HierarchicalID != 0) && (HierarchicalLevelCode.Length > 1);
		}
		public string TransactionSetID{get{ return "HL";}}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.HierarchicalID				= (parts[1] == "" ? 0 : Convert.ToInt32(parts[1]));
			this.ParentHierarchicalParentID	= (parts[2] == "" ? 0 : Convert.ToInt32(parts[2]));
			this.HierarchicalLevelCode		= parts[3];	// 20=Information source, 21=Information Receiver, 22=Subscriber, 23=Dependent
			this.HierarchicalChildCode		= parts[4];
		}

		int HierarchicalID;						// HL01
		int ParentHierarchicalParentID;			// HL02
		public string HierarchicalLevelCode;	// HL03
		public string HierarchicalChildCode;	// HL04

	}// end of class dependent level

	public class DependentTraceNumber : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return true;
		}
		public string TransactionSetID{	get{return "TRN";}}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.TraceTypeCode				= (parts.Length > 1 ? parts[1] : null);
			this.ReferenceIdentification	= (parts.Length > 2 ? parts[2] : null);
			this.OriginatingCompanyID		= (parts.Length > 3 ? parts[3] : null);
		}

		string TraceTypeCode;				// TRN01
		string	ReferenceIdentification;	// TRN02
		string OriginatingCompanyID;		// TRN03
		//		string ReferenceID;					// TRN04
	}// end of class DependentTraceNumber

	public class DependentName : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			if ( (EntityIdentifierCode == "") || (EntityIdentifierCode == "") )	// required fields
				return false;

			return true;
		}
		public string TransactionSetID {	get{return "NM1";}}

		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.EntityIdentifierCode			= (parts.Length > 1 ? parts[1] : null);
			this.EntityTypeQualifier			= (parts.Length > 2 ? parts[2] : null);
			this.LastName						= (parts.Length > 3 ? parts[3] : null);
			this.FirstName						= (parts.Length > 4 ? parts[4] : null);
			this.MiddleName						= (parts.Length > 5 ? parts[5] : null);
			this.NamePrefix						= (parts.Length > 6 ? parts[6] : null);
			this.NameSuffix						= (parts.Length > 7 ? parts[7] : null);
			this.IdentificationCodeQualifier	= (parts.Length > 8 ? parts[8] : null);
			this.IdentificationCode				= (parts.Length > 9 ? parts[9] : null);
		}
		
		public string EntityIdentifierCode;			// NM101 (03 = dependent; PR=payor; 1P=Provider; 80=Hospital; FA=Facility; IL=Insured/Subscriber; P3=PCP; 2B=3rd party administraotr; 36=Employer; GP=Gateway Provider; P5=Plan Sponsor)
		public string EntityTypeQualifier;			// NM102 (1  = Person; 2= Non-Person entity)
		public string LastName;						// NM103
		public string FirstName;					// NM104
		public string MiddleName;					// NM105
		public string NamePrefix;					// NM106
		public string NameSuffix;					// NM107
		public string IdentificationCodeQualifier;	// NM108 (MI = Member ID #, ZZ - mutually defined)
		public string IdentificationCode;			// NM109
	}// end of class DependentName

	public class DependentAdditionalIdentification : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return true;
		}
		public string TransactionSetID { get{return "REF";} }
		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.ReferenceIdentificationQualifier	= (parts.Length > 1 ? parts[1] : null);
			this.ReferenceIdentification			= (parts.Length > 2 ? parts[2] : null);
			this.Description						= (parts.Length > 3 ? parts[3] : null);
		}

		public string ReferenceIdentificationQualifier;		// RF01
		public string ReferenceIdentification;				// RF02
		public string Description;							// RF03
	}// end of class DependentAdditionalIdentification

	public class DependentAddress : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return (AddressLine1 != null);
		}
		public string TransactionSetID { get{return "N3";}}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.AddressLine1		= (parts.Length > 1 ? parts[1] : null);
			this.AddressLine2		= (parts.Length > 2 ? parts[2] : null);
		}

		public string AddressLine1;		// N301
		public string AddressLine2;		// N302
	}// end of class DependentAddress

	public class DependentCityStateZip : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			if ( (CityName == "") ||
				(StateProvince == "") ||
				(PostalCode == "") )
				return false;	// missing required fields

			return true;
		}
		public string TransactionSetID { get{return "N4";}}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			CityName		= (parts.Length > 1 ? parts[1] : null);
			StateProvince	= (parts.Length > 2 ? parts[2] : null);
			PostalCode		= (parts.Length > 3 ? parts[3] : null);
			CountryCode		= (parts.Length > 4 ? parts[4] : null);
		}

		public string CityName;				// N401
		public string StateProvince;		// N402
		public string PostalCode;			// N403
		public string CountryCode;			// N404
	}// end of class DependentCityStateZip

	public class DependentContactInformation : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return true;
		}
		public string TransactionSetID { get{ return "PER";} }
		public void ParseHeader(string []parts, StreamReader sr)
		{
			ContactFunctionCode				= (parts.Length > 1 ? parts[1] : null);
			Name							= (parts.Length > 2 ? parts[2] : null);
			for (int i = 0; i < 3; i++)
			{
				if (parts.Length < (4+(i*2))+1)
					break;
				CommunicationNumberQualifier[i]	= parts[3+(i*2)];
				CommunicationNumber[i]			= parts[4+(i*2)];
			}
		}

		public string []CommunicationNumberQualifier	= new string[3];
		public string []CommunicationNumber				= new string[3];
		public string ContactFunctionCode;				// PER01: "IC" = information contact
		public string Name;								// PER02
	}// end of class DependentContactInformation

	public class DependentDemographicInformation : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }

		public bool ValidateData()
		{
			return true;
		}
		public string TransactionSetID { get{ return "DMG"; }}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			try
			{
				this.DateTimeFormatQualifier		= (parts.Length > 1 ? parts[1] : null); // D8=date of birth
				this.DateTimePeriod					= (parts.Length > 2 ? ParsingFunctions.DateTimeParse(parts[2], null) : DateTime.MinValue);
				this.GenderCode						= (parts.Length > 3 ? parts[3] : "U");
			}
			catch(Exception ex)
			{
				string message = ex.Message;
				throw ex;
			}
		}

		public string DateTimeFormatQualifier;			// DMG01: D8=CCYYMMDD
		public DateTime DateTimePeriod;					// DMG02
		public string GenderCode;						// DMG03 (M/F/U)
	}// end of class DependentDemographicInformation

	public class DependentRelationship : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			if ( (IndividualRelationshipCode == null) || (IndividualRelationshipCode == "") )
				return false;
			if ( (YesNoResponseCode == null) || (YesNoResponseCode == "") )
				return false;

			return true;
		}
		public string TransactionSetID { get{return "INS"; }}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.YesNoResponseCode			= (parts.Length > 1 ? parts[1] : null); // N=No, is not subscriber, 
			this.IndividualRelationshipCode	= (parts.Length > 2 ? parts[2] : null); // 18=self; 01=spouse; 02,09,19,22=Dependent; 03,24=Other
		}

		public string YesNoResponseCode;				// INS01
		public string IndividualRelationshipCode;		// INS02
		public string MaintenanceTypeCode;				// INS03
		public string MaintenanceReasonCode;			// INS04
		public string StudentStatusCode;				// INS09
		public string YesNoResponseCode2;				// INS10
		public int Number;								// INS17
	}// end of DependentRelationship

	public class DependentDate : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			if ( (DateTimeQualifier == null) || (DateTimeQualifier == "") )
				return false;
			if ( (DateTimePeriodQualifier == null) || (DateTimePeriodQualifier == "") )
				return false;
			if ( (DateTimePeriodQualifier == "D8") && (DateTimePeriod.Year == 1) )
				return false;

			return true;
		}
		public string TransactionSetID { get{return "DTP";} }

		public void ParseHeader(string [] parts, StreamReader sr)
		{
			DateTimeQualifier		= parts[1];
			DateTimePeriodQualifier	= parts[2];
			if (DateTimePeriodQualifier == "D8") // single date
				DateTimePeriod	= ParsingFunctions.DateTimeParse(parts[3], null);
			else if (DateTimePeriodQualifier == "RD8") // range of dates
			{
				string[] dateparts  = parts[3].Split(new char[] {'-'}, 2);
				DateTimeRangeStart	= ParsingFunctions.DateTimeParse(dateparts[0], null);
				DateTimePeriod      = DateTimeRangeStart;
				DateTimeRangeEnd	= ParsingFunctions.DateTimeParse(dateparts[1], null);
			}
		}

		public string DateTimeQualifier;							// DTP01
		public string DateTimePeriodQualifier;						// DTP02
		public DateTime DateTimePeriod		= DateTime.MinValue;	// DTP03
		public DateTime DateTimeRangeStart  = DateTime.MinValue;	// DTP03 ?
		public DateTime DateTimeRangeEnd    = DateTime.MinValue;	// DTP04 ?
	}// end of class DependentDate

	public class DependentBenefitInformation : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return true;
		}
		public string TransactionSetID { get{return "EB";} }
		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.BenefitInformationDescription		= parts[1];		// =1, active plan, =6, inactive, =T, reported lost or stolen
			this.CoverageLevelCode					= parts[2];		// always "IND" (Individual)
			this.ServiceTypeCode					= parts[3];
			this.InsuranceTypeCode					= parts[4];		// always "MD"
			this.PlanCoverageDescription			= (parts.Length > 5  ? parts[5]  : "");
			this.TimePeriodQualifier				= (parts.Length > 6  ? parts[6]  : "");
			this.MonetaryAmount						= (parts.Length > 7  ? parts[7]  : "");
			this.Percent							= (parts.Length > 8  ? parts[8]  : "");
			this.QuantityQualifier					= (parts.Length > 9  ? parts[9]  : "");		// VS, DY, QA
			this.Quantity							= (parts.Length > 10 ? parts[10] : "");
			this.YesNoResponseCode					= (parts.Length > 11 ? parts[11] : "");
			this.InPlanNetworkIndicator				= (parts.Length > 12 ? parts[12] : "");		// 'Y' or 'N'
		}

		public string BenefitInformationDescription;	// EB01
		public string CoverageLevelCode;				// EB02
		public string ServiceTypeCode;					// EB03
		public string InsuranceTypeCode;				// EB04
		public string PlanCoverageDescription;			// EB05
		public string TimePeriodQualifier;				// EB06
		public string MonetaryAmount;					// EB07
		public string Percent;							// EB08
		public string QuantityQualifier;				// EB09
		public string Quantity;							// EB10
		public string YesNoResponseCode;				// EB11
		public string InPlanNetworkIndicator;			// EB12

	}// end of class DependentBenefitInformation

	public class DependentBenefitRelatedProvider : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return true;
		}
		public string TransactionSetID { get{return "PRV";} }
		public void ParseHeader(string []parts, StreamReader sr)
		{
			ProviderCode						= parts[1];
			ReferenceIdentificationQualifier	= parts[2];
			ReferenceIdentification				= parts[3];
			SpecialtyCode						= (parts.Length > 5 ? parts[5] : "");
		}
		
		public string ProviderCode;							// PRV01
		public string ReferenceIdentificationQualifier;		// PRV02
		public string ReferenceIdentification;				// PRV03
		public string SpecialtyCode;						// PRV05
	}// end of class DependentBenefitRelatedProvider

	public class DependentEligibilityInformation : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return (LoopIdentifierCode != "");
		}
		public string TransactionSetID { get{return "LS"; }}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.LoopIdentifierCode	= parts[1];
		}

		public string LoopIdentifierCode;					// LS01

	}// end of class DependentEligibilityInformation

	public class LoopTrailer : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return (LoopIdentifierCode != "");
		}
		public int WriteToStaging(string ConnectionString)
		{
			return 0;
		}
		public string TransactionSetID { get{return "LE";}}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.LoopIdentifierCode	= parts[1];
		}

		public string LoopIdentifierCode;					// LE01

	}// end of class LoopTrailer

	public class x12UM  : IBenefitInquiry
	{
		#region variables
		protected string requestCategoryCode;
		protected string certificationTypeCode;
		protected string serviceTypeCode;
		protected string healthcareServiceLocation;
		protected string facilityCodeValue;			// UM04-1
		protected string facilityCodeQualifier;		// UM04-2
		protected string relatedCausesCode;			// UM05-1
		protected string relatedCausesCode2;		// UM05-2
		protected string relatedCausesCode3;		// UM05-3
		protected string relatedCausesState;		// UM05-4
		protected string relatedCausesCountry;		// UM05-5
		protected string levelofServiceCode;
		protected string currentHealthConditionCode;
		protected string prognosisCode;
		protected string releaseofInformationCode;
		protected string delayReasonCode;
		#endregion

		#region properties
		public string TransactionSetID           { get { return "UM";                       } }
		public string RequestCategoryCode		 { get { return requestCategoryCode;        } }
		public string CertificationTypeCode		 { get { return certificationTypeCode;      } }
		public string ServiceTypeCode            { get { return serviceTypeCode;            } }
		public string HealthcareServiceLocation  { get { return healthcareServiceLocation;  } }
		public string RelatedCausesCode          { get { return relatedCausesCode;          } }
		public string LevelOfServiceCode         { get { return levelofServiceCode;         } }
		public string CurrentHealthConditionCode { get { return currentHealthConditionCode; } }
		public string PrognosisCode              { get { return prognosisCode;              } }
		public string DelayReasonCode            { get { return delayReasonCode;            } }
		public string ReleaseOfInformationCode   { get { return releaseofInformationCode;   } }
		public string FacilityTypeCode           { get { return facilityCodeValue;          } }
		#endregion


		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return ( (requestCategoryCode != null) && (certificationTypeCode != null) );
		}

		public void ParseHeader(string []parts, StreamReader sr)
		{
			// UM*<requestCategoryCode>*<certificationTypeCode>*<serviceTypeCode>*<healthcareServiceLocation>*<relatedCausesCode>*<levelofServiceCode>
			try
			{
				requestCategoryCode        = parts[1];
				certificationTypeCode      = parts[2];
				serviceTypeCode            = parts[3];

				if (parts[4] != null)
				{
					string []facility  = parts[4].Split(delimiter, 3);
					if (facility.Length > 0)
					{
						facilityCodeValue     = facility[0];
						facilityCodeQualifier = (facility.Length > 1 ? facility[1] : null);
					}
				}
				if (parts[5] != null)
				{
					string []relatedcauses = parts[5].Split(delimiter, 5);
					if (relatedcauses.Length > 0)
					{
						relatedCausesCode    = relatedcauses[0];
						relatedCausesCode2   = (relatedcauses.Length > 1 ? relatedcauses[1] : null);
						relatedCausesCode3   = (relatedcauses.Length > 2 ? relatedcauses[2] : null);
						relatedCausesState   = (relatedcauses.Length > 3 ? relatedcauses[3] : null);
						relatedCausesCountry = (relatedcauses.Length > 4 ? relatedcauses[4] : null);
					}
				}
				levelofServiceCode         = parts[6];
				currentHealthConditionCode = parts[7];
				prognosisCode              = parts[8];
				releaseofInformationCode   = parts[9];
				delayReasonCode            = parts[10];
			}
			catch(Exception e)
			{
				string msg = e.Message;
				return;
			}
		}
	}

	public class x12HSD : IBenefitInquiry
	{
		#region variables
		protected string quantityQualifier      = null;
		protected int quantity                  = -1;
		protected string unitMeasurementCode    = null;
		protected string sampleSelectionModulus = null;
		protected string timePeriodQualifier    = null;
		protected int    numberofPeriods        = -1;
		#endregion

		#region properties
		public string TransactionSetID           { get { return "HSD";                      } }
		public string QuantityQualifier          { get { return quantityQualifier;          } }
		public int    Quantity                   { get { return quantity;                   } }
		public string UnitMeasurementCode        { get { return unitMeasurementCode;        } }
		public string SampleSelectionModulus     { get { return sampleSelectionModulus;     } }
		public string TimePeriodQualifier        { get { return timePeriodQualifier;        } }
		public int    NumberOfPeriods            { get { return numberofPeriods;            } }
		#endregion

		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return (quantityQualifier != null) && (quantity > 0);
		}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			// HSD*<quantityQualifier>*<quantity>*<unitMeasurementCode>*<sampleSelectionModulus>*<timePeriodQualifier>*<numberofPeriods>
			try
			{
				quantityQualifier      = parts[1];
				quantity               = (parts[2] == null ? -1 : Convert.ToInt32(parts[2]) );
				unitMeasurementCode    = parts[3];
				sampleSelectionModulus = parts[4];
				timePeriodQualifier    = parts[5];
				numberofPeriods        = (parts[6] == null ? -1 : Convert.ToInt32(parts[6]));
			}
			catch(Exception e)
			{
				string msg = e.Message;
				return;
			}
		}
	}

	public class x12CR6 : IBenefitInquiry
	{
		#region variables
		protected string prognosisCode;
		protected DateTime date = DateTime.MinValue;
		protected string responseCode1;
		protected string responseCode2;
		protected string certificationTypeCode;
		protected DateTime surgeryDate = DateTime.MinValue;
		protected string productserviceIDqualifier;
		protected string medicalCodeValue;
		#endregion

		#region properties
		public string TransactionSetID           { get { return "CR6";                      } }
		public string PrognosisCode              { get { return prognosisCode;              } }
		public DateTime Date                     { get { return date;                       } }
		public string ResponseCode1              { get { return responseCode1;              } }
		public string ResponseCode2              { get { return responseCode2;              } }
		public string CertificationTypeCode      { get { return certificationTypeCode;      } }
		public DateTime SurgeryDate              { get { return surgeryDate;                } }
		public string ProductServiceIDQualifier  { get { return productserviceIDqualifier;  } }
		public string MedicalCodeValue           { get { return medicalCodeValue;           } }
		#endregion

		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return (PrognosisCode != null && ResponseCode1 != null && ResponseCode2 != null && CertificationTypeCode != null);
		}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			// CR6*<prognosisCode>*<date>*<responseCode1>*<responseCode2>*<certificationTypeCode>
			try
			{
				prognosisCode             = parts[1];
				date                      = ParsingFunctions.DateTimeParse(parts[2], null);
				responseCode1             = parts[6];
				responseCode2             = parts[7];
				certificationTypeCode     = parts[8];
				surgeryDate               = ParsingFunctions.DateTimeParse(parts[9], null);
				productserviceIDqualifier = parts[10];
				medicalCodeValue          = parts[11];
			}
			catch(Exception e)
			{
				string msg = e.Message;
				return;
			}
		}// end of method
	}
	public class x12SE : IBenefitInquiry
	{
		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }

		public string TransactionSetID { get {return "SE";} }
		public bool ValidateData()
		{
			if ( (this.TransactionSetControlNumber == null) || (this.TransactionSetControlNumber == "") )
				return false;
			if (this.NumberOfIncludedSegments == 0)
				return false;
			return true;
		}// end of method ValidateData
		public void ParseHeader(string []parts, StreamReader sr)
		{
			this.NumberOfIncludedSegments		= Convert.ToInt32(parts[1]);
			this.TransactionSetControlNumber	= parts[2];
		}

		public int    NumberOfIncludedSegments; 		// SE01
		public string TransactionSetControlNumber;		// SE02
	}// end of class TransactionSetHeader

	public class x12HI : IBenefitInquiry
	{
		#region variables
		protected string healthcareCodeInfo;
		protected string codeListQualifier;
		protected string industryCode;
		protected DateTime procedureDateStart;
		protected DateTime procedureDateEnd;
		#endregion

		#region properties
		public string   TransactionSetID           { get { return "HI";                       } }
		public string   HealthCareCodeInfo         { get { return healthcareCodeInfo;         } }
		public string   CodeListQualifier          { get { return codeListQualifier;          } }
		public string   IndustryCode               { get { return industryCode;               } }
		public DateTime ProcedureDateStart         { get { return procedureDateStart;         } }
		public DateTime ProcedureDateEnd           { get { return procedureDateEnd;           } }
		public DateTime ProcedureDate              { get { return procedureDateStart;         } }
		public bool     IsProcedureDateRange       { get { return procedureDateEnd != DateTime.MinValue; } }
		#endregion

		protected char []delimiter = new char[1];
		public char Delimiter { set {delimiter[0] = value; } }
		public bool ValidateData()
		{
			return (healthcareCodeInfo != null);
		}
		public void ParseHeader(string []parts, StreamReader sr)
		{
			// HI*<healthcareCodeInfo>
			procedureDateStart = DateTime.MinValue;
			procedureDateEnd   = DateTime.MinValue;
			healthcareCodeInfo = null;
			codeListQualifier  = null;
			industryCode       = null;
			try
			{
				healthcareCodeInfo = parts[1];
				string []subparts = parts[2].Split(delimiter, 5);
				codeListQualifier = subparts[0];
				industryCode      = subparts[1];
				if (subparts.Length > 2)
				{
					if (subparts[2] == "D8")
					{
						char []d = {'-'};
						string []dateparts = subparts[3].Split(d, 2);
						procedureDateStart = ParsingFunctions.DateTimeParse(dateparts[0], null);
						procedureDateEnd   = ParsingFunctions.DateTimeParse(dateparts[1], null);
					}
					else
						procedureDateStart = ParsingFunctions.DateTimeParse(subparts[3], null);
				}

			}
			catch(Exception e)
			{
				string msg = e.Message;
				return;
			}		
		}// end of method

	}// end of class

}// end of namespace