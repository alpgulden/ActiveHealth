using System;
using System.IO;
using System.Security.Permissions;
using System.Diagnostics;
using System.Globalization;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Data;

namespace InterfaceReader
{
	/// <summary>
	/// Summary description for ScoringLoadReader.
	/// </summary>
	public class ScoringLoadReader
	{
		protected string ConnectionString;
		protected string ErrorLogFileName;
		public void ParseFile(System.String FileName, System.String strConnection, String errorlogfilename)
		{
			ErrorLogFileName = errorlogfilename;

			try
			{
				FileIOPermission filePerm = new FileIOPermission(FileIOPermissionAccess.Read, FileName);
				filePerm.Assert();
				StreamReader sr = new StreamReader(FileName);
				ConnectionString = strConnection;
				this.ParseLine(sr);
			}
			catch(Exception ex)
			{
				string message = ex.Message;

				if (!EventLog.SourceExists("ScoringLoadInterface") )
					EventLog.CreateEventSource("ScoringLoadInterface", "ActiveAdvice");
				EventLog.WriteEntry("ScoringLoadInterface", "at line #" + linecnt.ToString() + "\n" + ex.Message + (ex.InnerException != null ? "\n\n" + ex.InnerException.Message : ""), EventLogEntryType.Error);
				throw ex;
			}
		}// end of constructor ScoringLoadReader()

		string Substring(string s, int start, int length)
		{
			// How much string is there?
			if (s.Length > (start + length) )
				return s.Substring(start, length).Trim();

			string ret = null;
			length = s.Length - start;
			if (length > 0)
			{
				ret = s.Substring(start, length).Trim();
				if (ret == "")
					ret = null;
			}
			return (ret == null ? null : ret.Trim()) ;
		}
		int linecnt			= 0;
		void ParseLine(StreamReader sr)
		{
			int h_recordcnt		= 0;
			string input_line	= null;
			System.Guid batch	= Guid.NewGuid();

			ScoringLoadWriter slw = new ScoringLoadWriter(batch, this.ConnectionString);
			while ( (input_line = sr.ReadLine() ) != null)
			{
				linecnt++;
				switch(Substring(input_line,0,1) )
				{
					case "H":
						// next is a datestring of the format:
						//   MM/DD/YYYYHH:MM<recordcount>
						//
						string date		= Substring(input_line,1, 10);
						string time		= Substring(input_line,11, 5);
						h_recordcnt		= Convert.ToInt32(Substring(input_line,16, input_line.Length - 16));
						DateTimeFormatInfo dti	= new DateTimeFormatInfo();
						dti.FullDateTimePattern = "dd/mm/yyyy HH:mm";
						DateTime dtRec	= DateTime.Parse(date + " " + time,dti);
						slw.WriteHeader(System.DateTime.Now, dtRec, h_recordcnt);
						break;
					case "T":
						int t_recordcnt	= Convert.ToInt32(Substring(input_line,1, input_line.Length -1));
						int recordcnt	= linecnt - 2; // subtract out header/trailer to get data record count
						if (t_recordcnt != recordcnt)
						{
							// there's a problem!!!
							if (!EventLog.SourceExists("ScoringLoadInterface") )
								EventLog.CreateEventSource("ScoringLoadInterface", "ActiveAdvice");
							EventLog.WriteEntry("ScoringLoadInterface", "mismatch on record count", EventLogEntryType.Warning);
						}
						slw.WriteTrailer(t_recordcnt);

						// Okay, now process the data we put into the staging tables...
						slw.ProcessScoringLoad();
						break;
					case "D":
						string clientid		= Substring(input_line,1,4).Trim();
						string patientid	= Substring(input_line,5,20).Trim();
						string component	= Substring(input_line,25,10).Trim();
						string source		= Substring(input_line,35,10).Trim();
						string attribute	= Substring(input_line,45,25).Trim(); // CMS attribute...
						string rvalue		= null;
						if (component == "TOTL")
							rvalue = Substring(input_line,70,10).Trim();
						string ProviderName	= Substring(input_line,90,30);
						string eventDate	= Substring(input_line,80,10);
						DateTime EventDate	= new DateTime(1,1,1);
						if ( (eventDate != null) && (eventDate != "") )
						{
							try
							{
								DateTimeFormatInfo dtfi	= new DateTimeFormatInfo();
								dtfi.FullDateTimePattern = "dd/mm/yyyy";
								EventDate = DateTime.Parse(eventDate, dtfi);
							}
							catch(Exception ex)
							{
								throw ex;
							}
						}
						string Note			= Substring(input_line,120,80);
						slw.WriteDetail(clientid, patientid, component, source, attribute, rvalue, EventDate, ProviderName, Note);
						break;
					default:
						break;
				}// end of switch
			}
		}// end of method ParseLine()

	}// end of class ScoringLoadReader()

	public class ScoringLoadWriter
	{
		protected string ConnectionString = null;
		System.Guid	batch_guid;
		public ScoringLoadWriter(Guid batch, string connectionstring)
		{
			batch_guid		 = batch;
			ConnectionString = connectionstring;
		}
		public void SQLexceptionHandler(SqlCommand cmd, SqlException se)
		{
			string msg = cmd.CommandText + " failure\nParameters:\n";
			for (int i = 0; i < cmd.Parameters.Count; i++)
			{
				try
				{
					msg += "    " + cmd.Parameters[i].ParameterName + "=" + (cmd.Parameters[i].Value == null ? "<null>" : cmd.Parameters[i].Value.ToString()) + "\n";
				}
				catch(Exception ex)
				{
					string messg = ex.Message;
				}
			}
			msg += "\n{Inner Exception}\n" + se.Message;
			Exception e = new Exception(msg, se);
			throw e;
		}// end of method SQLexceptionhandler

		public void WriteDetail(string clientid, string patientid, string component, string source, string attribute, string rvalue, DateTime eventdate, string providername, string note)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Write_Staging_ScoringLoadDetail", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@clientid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= clientid;

				inparm				= cmd.Parameters.Add("@patientid", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= patientid;

				inparm				= cmd.Parameters.Add("@component", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= component;

				inparm				= cmd.Parameters.Add("@source", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= source;

				inparm				= cmd.Parameters.Add("@attribute", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= attribute;

				inparm				= cmd.Parameters.Add("@value", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= rvalue;

				inparm				= cmd.Parameters.Add("@eventdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (eventdate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = eventdate;

				inparm				= cmd.Parameters.Add("@providername", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= providername;

				inparm				= cmd.Parameters.Add("@note", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= note;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					SQLexceptionHandler(cmd, se);
				}
			}
		}// end of method WriteDetail()

		public void WriteHeader(DateTime rundate, DateTime headertime, int recordcount)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Write_Staging_ScoringLoadHeader", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@rundate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (rundate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = rundate;

				inparm				= cmd.Parameters.Add("@headertime", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (headertime.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = headertime;

				inparm				= cmd.Parameters.Add("@recordcount", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= recordcount;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					SQLexceptionHandler(cmd, se);
				}
			}
		}// end of method WriteHeader()
		public void WriteTrailer(int recordcount)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Write_Staging_ScoringLoadTrailer", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@recordcount", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= recordcount;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					SQLexceptionHandler(cmd, se);
				}
			}
		}// end of method WriteTrailer()

		public void ProcessScoringLoad()
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Staging_ProcessScoringLoad", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					SQLexceptionHandler(cmd, se);
				}
			}
		}// end of method ProcessScoringLoad()

	}// end of class ScoringLoadWriter()

}// end of namespace
