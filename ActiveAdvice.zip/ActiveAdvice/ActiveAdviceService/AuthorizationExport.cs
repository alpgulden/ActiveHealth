using System;
using System.IO;		// Path class
using NetsoftUSA.DataLayer;
using System.Globalization;	// DateTimeInfo for ParseExact
using ActiveAdvice.DataLayer;

namespace ActiveAdviceService
{
	/// <summary>
	/// Summary description for AuthorizationExport.
	/// </summary>
	[TableMapping(null)]
	public class AuthorizationExport : BaseDataClass
	{
		const string EventFileName		= "\\EVT.X12";
		const string ReferralFileName	= "\\REF.X12";
		const string EventErrorLog		= "\\EvtError.txt";
		const string ReferralErrorLog	= "\\RefError.txt";
		
		protected string authorizationFolder = null;
		public AuthorizationExport(AuthorizationArguments aa, string authorizationfolder)
		{
			authorizationFolder = authorizationfolder;
			if (aa.Events)
				ReadEventAuthorizations(aa);
			if (aa.Referrals)
				ReadReferralsAuthorizations(aa);
		}

		protected void ReadReferralsAuthorizations(AuthorizationArguments aa)
		{
			// First open up an output stream
			StreamWriter sw_referrals = new StreamWriter(authorizationFolder + ReferralFileName, false, System.Text.Encoding.ASCII);
			if (null == sw_referrals)
				return;

			// Okay we have a stream, so let's do some work
			ExportAuthorizationCollection authorizations		= null;
			Staging_AuthorizationReferralCollection referrals	= null;
			Staging_AuthorizationDxPxCollection codes			= null;
			Staging_AuthorizationNoteCollection notes           = null;
			try
			{
				System.Guid batch = System.Guid.NewGuid();
				SqlData.SPExecNonQuery("usp_Staging_ExportReferralsPatientSubscriber", new object[] { batch, SQLDataDirect.MakeDBValue(aa.MORGID, 0), SQLDataDirect.MakeDBValue(aa.StartDate), SQLDataDirect.MakeDBValue(aa.EndDate)});

				authorizations = new ExportAuthorizationCollection();
				authorizations.LoadAuthorizationByBatchNumber(-1, batch);

				referrals = new Staging_AuthorizationReferralCollection();
				referrals.LoadAuthorizationReferralsByBatch(-1, batch);

				codes = new Staging_AuthorizationDxPxCollection();
				codes.LoadAuthorizationCodesByBatchNumber(-1, batch);

				notes = new Staging_AuthorizationNoteCollection();
				notes.LoadAuthorizationNoteByBatchNumber(-1, batch);

			}
			catch(Exception e)
			{
				sw_referrals.Close();
				string msg = e.Message;
				throw e;
			}

			// Now generate our x12 output
			try
			{
				ProcessReferralAuthorizations(authorizations, referrals, codes, sw_referrals, notes);
			}
			catch(Exception ex)
			{
				sw_referrals.Close();
				string msg = ex.Message;
				throw ex;
			}

			sw_referrals.Close();
		}

		protected void ProcessReferralAuthorizations(ExportAuthorizationCollection auths, Staging_AuthorizationReferralCollection referrals, Staging_AuthorizationDxPxCollection codes, StreamWriter sw_referrals, Staging_AuthorizationNoteCollection notes)
		{
			int controlnumber = 16000;
			int segmentcount  = 0;
			string x12 = "";

			// First create & write out our control header...
			x12 += this.x12ControlSection();
			x12 += this.x12HeaderSection(controlnumber, ref segmentcount);
			for (int i = 0; i < auths.Count; i++)
			{
				controlnumber++;
				x12 += this.x12InformationSourceSection(ref segmentcount);
				x12 += this.x12InformationReceiverSection(ref segmentcount);
				sw_referrals.Write(x12); x12 = null;

				bool firstReferral = true;
				for (int r = 0; r < referrals.Count; r++)
				{
					if (firstReferral) // only write out header info for the first referral (is that true???)
					{
						string x12header	= referrals[r].GenerateHeader(ref segmentcount);
						string x12auth		= auths[i].GenerateFormattedOutput(ref segmentcount);
						sw_referrals.Write(x12header);
						sw_referrals.Write(x12auth);
						firstReferral = false;
					}

					if (referrals[r].AuthorizationID != auths[i].AuthorizationID)
						continue;

					string x12referral	= referrals[i].GenerateFormattedOutput(ref segmentcount);
					sw_referrals.Write(x12referral);

					// Okay we have a referral detail
					for(int j = 0; j < codes.Count; j++)
					{
						if (codes[j].ReferralID != auths[i].ReferralID)
							continue;
						string x12code = codes[j].GenerateFormattedOutput(ref segmentcount);
						sw_referrals.Write(x12code);
					}// end of processing dx/px codes

					for(int n = 0; n < notes.Count; n++)
					{
						if (notes[n].ReferralDetailID != referrals[r].ReferralDetailID)
							continue;

						string x12note = notes[n].GenerateFormattedOutput(ref segmentcount);
						sw_referrals.Write(x12note);
					}

					string x12units = referrals[r].x12Units(ref segmentcount);
					if (null != x12units)
						sw_referrals.Write(x12units);
				}

				// generate the closing footer.
				x12 = x12Footer(segmentcount, controlnumber);
				sw_referrals.Write(x12);
			}// end of processing authorization referrals

			x12 = x12Trailer();
			sw_referrals.Write(x12);
		}// end of method

		protected void ReadEventAuthorizations(AuthorizationArguments aa)
		{
			// First open up an output stream
			StreamWriter sw_events = new StreamWriter(authorizationFolder + EventFileName, false, System.Text.Encoding.ASCII);
			if (null == sw_events)
				return;

			// Okay we have a stream, so let's do some work
			ExportAuthorizationCollection authorizations	= null;
			Staging_AuthorizationEventCollection events		= null;
			Staging_AuthorizationDxPxCollection codes		= null;
			try
			{
				System.Guid batch = System.Guid.NewGuid();
				SqlData.SPExecNonQuery("usp_Staging_ExportEventsPatientSubscriber", new object[] { batch, SQLDataDirect.MakeDBValue(aa.MORGID, 0), SQLDataDirect.MakeDBValue(aa.StartDate), SQLDataDirect.MakeDBValue(aa.EndDate)});

				authorizations = new ExportAuthorizationCollection();
				authorizations.LoadAuthorizationByBatchNumber(-1, batch);

				events = new Staging_AuthorizationEventCollection();
				events.LoadAuthorizationEventsByBatchNumber(-1, batch);

				codes = new Staging_AuthorizationDxPxCollection();
				codes.LoadAuthorizationCodesByBatchNumber(-1, batch);
			}
			catch(Exception e)
			{
				sw_events.Close();
				string msg = e.Message;
				throw e;
			}

			// Now generate our x12 output
			try
			{
				ProcessEventAuthorizations(authorizations, events, codes, sw_events);
			}
			catch(Exception ex)
			{
				sw_events.Close();
				string msg = ex.Message;
				throw ex;
			}

			sw_events.Close();
		}

		protected void ProcessEventAuthorizations(ExportAuthorizationCollection auths, Staging_AuthorizationEventCollection events, Staging_AuthorizationDxPxCollection codes, StreamWriter sw_events)
		{
			int segmentcount	= 0;
			int controlnumber	= 16001; // unique if we have multiple control loops
			string x12 = "";

			// First create & write out our control header...
			x12 += x12ControlSection();
			x12 += x12HeaderSection(controlnumber, ref segmentcount);
			x12 += x12InformationSourceSection(ref segmentcount);
			x12 += x12InformationReceiverSection(ref segmentcount);
			sw_events.Write(x12); x12 = null;

			for (int i = 0; i < auths.Count; i++)
			{
				string x12header    = events[i].GenerateHeader(ref segmentcount);
				string x12auth		= auths[i].GenerateFormattedOutput(ref segmentcount);
				string x12event		= events[i].GenerateFormattedOutput(ref segmentcount);

				sw_events.Write(x12header);
				sw_events.Write(x12auth);
				sw_events.Write(x12event);

				for(int j = 0; j < codes.Count; j++)
				{
					if (codes[j].EventID == auths[i].EventID)
					{
						string x12code = codes[j].GenerateFormattedOutput(ref segmentcount);
						sw_events.Write(x12code);
					}
				}// end of processing dx/px codes

				string x12msgloop = events[i].GenerateMessageLoop(ref segmentcount);
				if (null != x12msgloop)
					sw_events.Write(x12msgloop);

				// generate the closing footer.
				x12 = x12Footer(segmentcount, controlnumber);
				sw_events.Write(x12);
			}// end of processing authorization events

			// generate the trailer.
			x12 = x12Trailer();
			sw_events.Write(x12);
		}// end of method

		protected string x12Trailer()
		{
			int count = 0;
			string x12 = "";
			x12 += ExportAuthorization.FormatRecord("GE*1*{0}", new object[] {16}, ref count);
			x12 += ExportAuthorization.FormatRecord("IEA*1*{0}", new object[] {"000000016"}, ref count);
			return x12;
		}
		protected string x12Footer(int segmentcount, int controlnumber)
		{
			int count = 0;
			string x12  = ExportAuthorization.FormatRecord("SE*{0}*{1}", new object[] {segmentcount, controlnumber}, ref count);
			return x12;
		}

		const string interchangeSenderID = "195723648";
		protected string x12ControlSection()
		{
			string x12			= null;
			DateTime dt			= DateTime.Now;
			int count           = 0; // dummy count
			string TestFlag		= "T"; // = "P"; // production
			string gs_address	= null;
			x12  = ExportAuthorization.FormatRecord("ISA*00**00**01*{0}*01*{1}*{2}*{3}*U*00200*000000016*0*{4}", new object[] {interchangeSenderID, "iSA ADDRESS", dt, dt.ToString("hhmm"), TestFlag}, ref count);
			x12 += ExportAuthorization.FormatRecord("GS*HI*{0}*{1}*{2}*{3}*16*X*003070", new object[] {interchangeSenderID, gs_address, dt, dt.ToString("hhmm") }, ref count);
			return x12;
		}
		protected string x12HeaderSection(int controlnumber, ref int count)
		{
			string x12 = null;
			DateTime dt = DateTime.Now;
			x12  = ExportAuthorization.FormatRecord("ST*{0}*{1}", new object[] {278, controlnumber}, ref count);
			x12 += ExportAuthorization.FormatRecord("BHT*00010*00*00000016*{0}*{1}*PW", new object[] {dt, dt.ToString("hhmm")}, ref count);
			return x12;
		}
		protected string x12InformationSourceSection(ref int count)
		{
			string x12 = null;
			x12  = ExportAuthorization.FormatRecord("HL*{0}*{1}*20*1", new object[] {1, null}, ref count);
			x12 += ExportAuthorization.FormatRecord("NM1*X3*{0}*{1}",  new object[] {2, "HCC Limited"}, ref count);
			return x12;
		}
		const string interchangeReceiverID = "iSA ADDRESS";
		protected string x12InformationReceiverSection(ref int count)
		{
			string x12 = null;
			x12  = ExportAuthorization.FormatRecord("HL*{0}*{1}*21*1",        new object[] {1, null}, ref count);
			x12 += ExportAuthorization.FormatRecord("NM1*CX*{0}******01*{1}", new object[] {2, interchangeReceiverID}, ref count);
			return x12;
		}
	}// end of class

}// end of namespace
