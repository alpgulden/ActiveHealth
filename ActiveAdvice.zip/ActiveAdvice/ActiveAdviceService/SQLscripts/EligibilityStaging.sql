--
--
-- EligibilityStaging.SQL
-- ======================
--
-- Revision History:
-- 
--   02-10-2005 HjC
--      o add the PlanID to the Staging_EligibityPCP & EligibilityPCP
--        this allows us to maintain the relationship between the PCP
--        and the Plan (i.e. "coverage")
--
--use ActiveAdvice
--go

-- Fix up the Eligibility table...
if exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'County')
    ALTER TABLE Eligibility DROP COLUMN County
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'MemberCounty')
    ALTER TABLE Eligibility ADD MemberCounty varchar(30) NULL
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'AlternateInsuranceID')
    ALTER TABLE Eligibility ADD AlternateInsuranceID varchar(30) NULL

-- Add MORG & ORG ID fields
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'MORGID')
begin
    ALTER TABLE Eligibility ADD MORGID int NULL CONSTRAINT DF_Eligibility_MORGID default(1)
    ALTER TABLE Eligibility DROP CONSTRAINT DF_Eligibility_MORGID
    ALTER TABLE Eligibility ADD CONSTRAINT FK_Organization_Eligibility_MORGID FOREIGN KEY (MORGID) REFERENCES Organization(OrganizationID)
end
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'ORGID')
begin
    ALTER TABLE Eligibility ADD ORGID int NULL CONSTRAINT DF_Eligibility_ORGID default(1)
    ALTER TABLE Eligibility DROP CONSTRAINT DF_Eligibility_ORGID
    ALTER TABLE Eligibility ADD CONSTRAINT FK_Organization_Eligibility_ORGID FOREIGN KEY (ORGID) REFERENCES Organization(OrganizationID)
end

-- Put the plan id into the EligibilityPCP, that way we can keep PCPs with their plans
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'EligibilityPCP' AND SC.name = 'PlanID')
begin
    ALTER TABLE EligibilityPCP ADD PlanID int NOT NULL CONSTRAINT DF_EligibilityPCP_PlanID DEFAULT(1)
    ALTER TABLE EligibilityPCP DROP CONSTRAINT DF_EligibilityPCP_PlanID
    ALTER TABLE EligibilityPCP ADD CONSTRAINT FK_Plan_EligibilityPCP FOREIGN KEY (PlanID) REFERENCES [dbo].[Plan](PlanID)
end

-- Store the SORGID (not just the MemberSORGID which is the "alternate sorgid"), save subsequent searching on alternate sorg id
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'SORGID')
begin
    ALTER TABLE Eligibility ADD SORGID int NOT NULL CONSTRAINT DF_Eligibility_SORGID default(1)
    ALTER TABLE Eligibility DROP CONSTRAINT DF_Eligibility_SORGID
    ALTER TABLE Eligibility ADD CONSTRAINT FK_Organization_Eligibility_SORGID FOREIGN KEY (SORGID) REFERENCES Organization(OrganizationID)
end
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'MiddleInitial')
    ALTER TABLE Eligibility ADD MiddleInitial char(1) NULL

if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'NameSuffix')
    ALTER TABLE Eligibility ADD NameSuffix varchar(20) NULL
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'RelationshipID')
    ALTER TABLE Eligibility ADD RelationshipID int NULL CONSTRAINT FK_Relationship_Eligibility FOREIGN KEY (RelationshipID) REFERENCES Relationship(RelationshipID)

if exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'Country')
    ALTER TABLE Eligibility DROP COLUMN Country

if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'MemberCountry')
    ALTER TABLE Eligibility ADD MemberCountry varchar(30) NULL

if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'HomePhoneExtension')
    ALTER TABLE Eligibility ADD HomePhoneExtension varchar(6) NULL

if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Eligibility' AND SC.name = 'AlternateSubscriberID')
begin
    ALTER TABLE Eligibility ADD AlternateSubscriberID varchar(30) NOT NULL CONSTRAINT DF_Eligibility_AlternateSubscriberID DEFAULT ('unknown')
    ALTER TABLE Eligibility DROP CONSTRAINT DF_Eligibility_AlternateSubscriberID
end

ALTER TABLE Eligibility ALTER COLUMN MemberSSN varchar(64) NULL

-- Put the plan id into the EligibilityPCP, that way we can keep PCPs with their plans
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Enrollment' AND SC.name = 'AlternateEnrollmentID')
begin
    ALTER TABLE Enrollment ADD AlternateEnrollmentID varchar(30) NOT NULL CONSTRAINT DF_Enrollment_AlternateEnrollmentID default('')
    ALTER TABLE Enrollment DROP CONSTRAINT DF_Enrollment_AlternateEnrollmentID
end
if not exists(select * from sysobjects where name = 'FK_AAUser_Enrollment_CreatedBy' and type = 'F')
    ALTER TABLE Enrollment ADD CONSTRAINT FK_AAUser_Enrollment_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES AAUser(UserID)
if not exists(select * from sysobjects where name = 'FK_AAUser_Enrollment_ModifiedBy' and type = 'F')
    ALTER TABLE Enrollment ADD CONSTRAINT FK_AAUser_Enrollment_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES AAUser(UserID)
if not exists(select * from sysobjects where name = 'FK_AAUser_Enrollment_TerminatedBy' and type = 'F')
    ALTER TABLE Enrollment ADD CONSTRAINT FK_AAUser_Enrollment_TerminatedBy FOREIGN KEY (TerminatedBy) REFERENCES AAUser(UserID)
if not exists(select * from sysobjects where name = 'PK_OrganizationEnrollment_OrganizationID_EnrollmentID' AND type = 'K')
    ALTER TABLE OrganizationEnrollment ADD CONSTRAINT PK_OrganizationEnrollment_OrganizationID_EnrollmentID PRIMARY KEY (OrganizationID, EnrollmentID)

if not exists (select * from sysobjects where name = 'FK_Enrollment_OrganizationEnrollment' and type = 'F')
    ALTER TABLE OrganizationEnrollment ADD CONSTRAINT FK_Enrollment_OrganizationEnrollment FOREIGN KEY (EnrollmentID) REFERENCES Enrollment(EnrollmentID)
if not exists (select * from sysobjects where name = 'FK_Organization_OrganizationEnrollment' and type = 'F')
    ALTER TABLE OrganizationEnrollment ADD CONSTRAINT FK_Organization_OrganizationEnrollment FOREIGN KEY (OrganizationID) REFERENCES Organization(OrganizationID)

-- Need our enrollment data in the EligibilityPlan table...
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'EligibilityPlan' AND SC.name = 'EnrollmentID')
    ALTER TABLE EligibilityPlan ADD EnrollmentID int NULL CONSTRAINT FK_EligibilityPlan_Enrollment FOREIGN KEY (EnrollmentID) REFERENCES Enrollment(EnrollmentID)
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'EligibilityPlan' AND SC.name = 'AlternateEnrollmentID')
    ALTER TABLE EligibilityPlan ADD AlternateEnrollmentID varchar(30) null


-- Add the UUID field to the subscriber. This makes it soooo easy for interface operations to "find" records
-- they create with result sets, making interface operations a lot faster...
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'Subscriber' AND SC.name = 'uuid')
    ALTER TABLE Subscriber ADD uuid uniqueidentifier null
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'PatientSubscriberLog' AND SC.name = 'uuid')
    ALTER TABLE PatientSubscriberLog ADD uuid uniqueidentifier null

-- Create new Patient Coverage table

if exists(select * from sysobjects where name = 'FK_PatientCoverage_PatientCoverageData' AND type = 'F')
    ALTER TABLE PatientCoverageData DROP CONSTRAINT FK_PatientCoverage_PatientCoverageData
if exists(select * from sysobjects where name = 'FK_PatientCoverage_PatientCoveragePCP' AND type = 'F')
    ALTER TABLE PatientCoveragePCP DROP CONSTRAINT FK_PatientCoverage_PatientCoveragePCP
go
if exists(select * from sysobjects where name = 'FK_PatientCoverage_PatientCoverageData' and type = 'F')
    ALTER TABLE PatientCoverageData DROP CONSTRAINT FK_PatientCoverage_PatientCoverageData
go
--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PatientCoverage]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
--   drop table PatientCoverage
--go
--CREATE TABLE PatientCoverage(
--    PatientCoverageID int IDENTITY(1,1) PRIMARY KEY,
    
--    PatientID      int NOT NULL CONSTRAINT FK_Patient_PatientCoverage      FOREIGN KEY (PatientID)      REFERENCES Patient(PatientID),
--    SubscriberID   int NOT NULL CONSTRAINT FK_Subscriber_PatientCoverage   FOREIGN KEY (SubscriberID)   REFERENCES Subscriber(SubscriberID),
--    SORGID         int NOT NULL CONSTRAINT FK_Organization_PatientCoverage FOREIGN KEY (SORGID)         REFERENCES Organization(OrganizationID),
--    PlanID         int NOT NULL CONSTRAINT FK_Plan_PatientCoverage         FOREIGN KEY (PlanID)         REFERENCES [Plan](PlanID),
    
--    RelationShipID int NOT NULL CONSTRAINT FK_Relationship_PatientCoverage FOREIGN KEY (RelationshipID) REFERENCES Relationship(RelationshipID),
--    IsPrimary      bit NOT NULL,

--    AlternatePatientID    varchar(30) NULL,
--    AlternateGroupID      varchar(30) NULL,
--    AlternateInsuranceID  varchar(30) NULL,
--    AlternateSubscriberID varchar(30) NULL,
    
--    AsOfDate                datetime, -- date/time when eligibility updated this record
--    PatientEligibilityID    int NULL CONSTRAINT FK_Eligibility_PatientCoverage_PatientEligibilityID    FOREIGN KEY (PatientEligibilityID)    REFERENCES Eligibility(EligibilityID),
--    SubscriberEligibilityID int NULL CONSTRAINT FK_Eligibility_PatientCoverage_SubscriberEligibilityID FOREIGN KEY (SubscriberEligibilityID) REFERENCES Eligibility(EligibilityID),
    
--    CreatedBy int NOT NULL CONSTRAINT FK_AAUser_PatientCoverage_CreatedBy  FOREIGN KEY (CreatedBy)  REFERENCES AAUser(UserID),
--    CreateTime datetime NOT NULL default(getdate()),
--    ModifiedBy int    NULL CONSTRAINT FK_AAUser_PatientCoverage_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES AAUser(UserID),
--    ModifyTime datetime NULL
--)
--go

if not exists(select * from sysindexes where name = 'IX_PatientCoverage_PatientID')
    CREATE INDEX IX_PatientCoverage_PatientID               ON PatientCoverage(PatientID)
if not exists(select * from sysindexes where name = 'IX_PatientCoverage_SubscriberID')
    CREATE INDEX IX_PatientCoverage_SubscriberID            ON PatientCoverage(SubscriberID)
if not exists(select * from sysindexes where name = 'IX_PatientCoverage_SORGID')
    CREATE INDEX IX_PatientCoverage_SORGID                  ON PatientCoverage(SORGID)
if not exists(select * from sysindexes where name = 'IX_PatientCoverage_PlanID')
    CREATE INDEX IX_PatientCoverage_PlanID                  ON PatientCoverage(PlanID)
if not exists(select * from sysindexes where name = 'IX_PatientCoverage_PatientEligibilityID')
    CREATE INDEX IX_PatientCoverage_PatientEligibilityID    ON PatientCoverage(PatientEligibilityID)
if not exists(select * from sysindexes where name = 'IX_PatientCoverage_SubscriberEligibilityID')
    CREATE INDEX IX_PatientCoverage_SubscriberEligibilityID ON PatientCoverage(SubscriberEligibilityID)
if not exists(select * from sysindexes where name = 'IX_PatientCoverage_AlternatePatientID')
    CREATE INDEX IX_PatientCoverage_AlternatePatientID      ON PatientCoverage(AlternatePatientID)
if not exists(select * from sysindexes where name = 'IX_PatientCoverage_AlternateSubscriberID')
    CREATE INDEX IX_PatientCoverage_AlternateSubscriberID   ON PatientCoverage(AlternateSubscriberID)
-- Create an index to ensure that only a single record exists for the combination of Patient/Subscriber/SORG/Plan
if not exists(select * from sysindexes where name = 'UX_PatientCoverage_PatientID_SubscriberID_SORGID_PlanID')
     CREATE UNIQUE INDEX UX_PatientCoverage_PatientID_SubscriberID_SORGID_PlanID ON PatientCoverage(PatientID, SubscriberID, SORGID, PlanID)

-- Update the PatientSubscriberLog
--    o add FKs for EligiblityIDs
--    o add new colum "PatientCoverageDataID" and it's FK
--
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'PatientSubscriberLog' AND SC.name = 'PatientEligibilityID')
    ALTER TABLE PatientSubscriberLog ADD PatientEligibilityID int NULL
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'PatientSubscriberLog' AND SC.name = 'SubscriberEligibilityID')
    ALTER TABLE PatientSubscriberLog ADD SubscriberEligibilityID int NULL
if not exists(select * from sysobjects where name = 'FK_Eligibility_PatientSubscriberLog_SubscriberEligibilityID' AND type = 'F')
    ALTER TABLE PatientSubscriberLog ADD CONSTRAINT  FK_Eligibility_PatientSubscriberLog_SubscriberEligibilityID FOREIGN KEY (SubscriberEligibilityID) REFERENCES Eligibility(EligibilityID)
if not exists(select * from sysobjects where name = 'FK_Eligibility_PatientSubscriberLog_PatientEligibilityID' AND type = 'F')
    ALTER TABLE PatientSubscriberLog ADD CONSTRAINT  FK_Eligibility_PatientSubscriberLog_PatientEligibilityID    FOREIGN KEY (PatientEligibilityID) REFERENCES Eligibility(EligibilityID)
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'PatientSubscriberLog' AND SC.name = 'PatientCoverageDataID')
begin
    ALTER TABLE PatientSubscriberLog ADD PatientCoverageDataID int NOT NULL CONSTRAINT DF_PatientSubscriberLog_PatientCoverageDataID DEFAULT(1)
    ALTER TABLE PatientSubscriberLog DROP CONSTRAINT DF_PatientSubscriberLog_PatientCoverageDataID
end
if not exists(select * from sysobjects where name = 'FK_PatientCoverageData_PatientSubscriberLog' AND type = 'F')
    ALTER TABLE PatientSubscriberLog ADD CONSTRAINT FK_PatientCoverageData_PatientSubscriberLog  FOREIGN KEY (PatientCoverageDataID) REFERENCES PatientCoverageData(PatientCoverageDataID)
if not exists(select * from syscolumns SC, sysobjects SO where SO.id = SC.id AND SO.name = 'PatientSubscriberLog' AND SC.name = 'PatientEligibilityID')
    ALTER TABLE PatientSubscriberLog ADD PatientEligibilityID int NULL
go
--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PatientCoverageData]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    drop table PatientCoverageData
--go
--CREATE TABLE PatientCoverageData(
--    PatientCoverageDataID int IDENTITY(1,1) PRIMARY KEY,
    
--    PatientCoverageID int NOT NULL CONSTRAINT FK_PatientCoverage_PatientCoverageData FOREIGN KEY (PatientCoverageID) REFERENCES PatientCoverage(PatientCoverageID),
--    Active            bit NOT NULL default(1),
--    AsOfDate          datetime NOT NULL,
    
--    EffectiveDate   datetime NOT NULL,
--    TerminationDate datetime NULL,
--    TerminatedBy    int NULL CONSTRAINT FK_AAUser_PatientCoverageData FOREIGN KEY (TerminatedBy) REFERENCES AAUser(UserID),
--    TerminateTime   datetime NULL
--)
--go

if not exists(select * from sysindexes where name = 'IX_PatientCoverageData_PatientCoverageID')
    CREATE INDEX IX_PatientCoverageData_PatientCoverageID ON PatientCoverageData(PatientCoverageID)

--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PatientCoveragePCP]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    drop table PatientCoveragePCP
--go
--CREATE TABLE PatientCoveragePCP(
--    PatientCoveragePCPID int IDENTITY(1,1) PRIMARY KEY,
    
--    PatientCoverageID int NOT NULL CONSTRAINT FK_PatientCoverage_PatientCoveragePCP FOREIGN KEY (PatientCoverageID) REFERENCES PatientCoverage(PatientCoverageID),
    
--    PCPID int NOT NULL CONSTRAINT FK_Provider_PatientCoveragePCP FOREIGN KEY (PCPID) REFERENCES Provider(ProviderID),
--    ProviderLocationID int NOT NULL CONSTRAINT FK_ProviderLocation_PatientCoveragePCP FOREIGN KEY (ProviderLocationID) REFERENCES ProviderLocation(ProviderLocationID),
--    ProviderServiceTypeID     int NOT NULL CONSTRAINT FK_ProviderType_PatientCoveragePCP FOREIGN KEY (ProviderServiceTypeID) REFERENCES ProviderServiceType(ProviderServiceTypeID),
--    Status             char(1) NOT NULL,
--    AsOfDate datetime NOT NULL,

--    EffectiveDate datetime   NOT NULL,
--    TerminationDate datetime NULL,    

--    CreatedBy int NOT NULL CONSTRAINT FK_AAUser_PatientCoveragePCP_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES AAUser(UserID),
--   CreateTime datetime NOT NULL default(getdate()),
--    ModifiedBy int NULL CONSTRAINT FK_AAUser_PatientCoveragePCP_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES AAUser(UserID),
--    ModifyTime datetime NULL
--)
--go

if not exists(select * from sysindexes where name = 'IX_PatientCoveragePCP_PatientCoverageID')
    CREATE INDEX IX_PatientCoveragePCP_PatientCoverageID ON PatientCoveragePCP(PatientCoverageID)
if not exists(select * from sysindexes where name = 'IX_PatientCoveragePCP_PCPID')
    CREATE INDEX IX_PatientCoveragePCP_PCPID ON PatientCoveragePCP(PCPID)
go

-- This is where we keep our PatientSubscriberLog PCP information
--if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PatientCoveragePCPLog]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
--    drop table PatientCoveragePCPLog
--go
--CREATE TABLE PatientCoveragePCPLog(
--    PatientCoveragePCPLogID int IDENTITY(1,1) PRIMARY KEY,

--    PatientSubscriberLogID  int NOT NULL CONSTRAINT FK_PatientSubscriberLogID_PatientCoveragePCPLog FOREIGN KEY (PatientSubscriberLogID) REFERENCES PatientSubscriberLog(PatientSubscriberLogID),
    
--    AsOfDate            datetime NOT NULL,
--    ProviderID          int NOT NULL CONSTRAINT FK_Provider_PatientCoveragePCPLog    FOREIGN KEY (ProviderID)    REFERENCES Provider(ProviderID),
--    LocationID          int     NULL CONSTRAINT FK_Location_PatientCoveragePCPLog    FOREIGN KEY (LocationID)    REFERENCES Location(LocationID),
--    SpecialtyID         int     NULL CONSTRAINT FK_Specialty_PatientCoveragePCPLog   FOREIGN KEY (SpecialtyID)   REFERENCES Specialty(SpecialtyID),
--    ServiceTypeID       int     NULL CONSTRAINT FK_ServiceType_PatientCoveragePCPLog FOREIGN KEY (ServiceTypeID) REFERENCES ProviderServiceType(ProviderServiceTypeID),
--    AlternateProviderID varchar(30) null,
--    AlternateLocationID varchar(30) null,
    
--    EffectiveDate       datetime NOT NULL,
--    TerminationDate     datetime NOT NULL,
    
--    CreatedBy           int NOT NULL CONSTRAINT FK_AAUser_PatientCoveragePCPLog_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES AAUser(UserID),
--    CreateTime          datetime NOT NULL default(getdate()),
--    ModifiedBy          int NULL CONSTRAINT FK_AAUser_PatientCoveragePCPLog_ModifiedBy FOREIGN KEY (ModifiedBy) REFERENCES AAUser(UserID),
--    ModifyTime          datetime NULL
--)
--go

if not exists(select * from sysindexes where name = 'IX_PatientCoveragePCPLog_PatientSubscriberLogID')
    CREATE INDEX IX_PatientCoveragePCPLog_PatientSubscriberLogID ON PatientCoveragePCPLog(PatientSubscriberLogID)
go

--
-- usp_Staging_GetInterfaceUser
-- ============================
--
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Staging_GetInterfaceUser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure usp_Staging_GetInterfaceUser
GO
CREATE PROCEDURE usp_Staging_GetInterfaceUser
AS
BEGIN
    -- Step #3. Get the "INTERFACE_USER"
    if not exists(select * from AAUser where LoginName = 'INTERFACE_USER')
        insert into AAUser (LoginName, Password, CreatedBy, Status, FailedLogins) VALUES('INTERFACE_USER', 'interface', 1,1,0)

    declare @interfaceUser int
    select @interfaceUser = UserId from AAUser where LoginName = 'INTERFACE_USER'

    return @interfaceUser
END
go
--
-- Now add in some Relationship codes that we'll need
--
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser

declare @relationshipid int
select @relationshipid = max(RelationshipID)+1 from Relationship
if not exists(select * from Relationship where Relationship = 'Self')
begin
    insert into Relationship (Relationship, Active, ReadOnly, CreatedBy, RelationshipID) VALUES('Self',      1, 1, @interfaceUser, @relationshipid)
    select @relationshipid = @relationshipid + 1
end
if not exists(select * from Relationship where Relationship = 'Spouse')
begin
    insert into Relationship (Relationship, Active, ReadOnly, CreatedBy, RelationshipID) VALUES('Spouse',    1, 1, @interfaceUser, @relationshipid)
    select @relationshipid = @relationshipid + 1
end
if not exists(select * from Relationship where Relationship = 'Dependent')
begin
    insert into Relationship (Relationship, Active, ReadOnly, CreatedBy, RelationshipID) VALUES('Dependent', 1, 1, @interfaceUser, @relationshipid )
    select @relationshipid = @relationshipid + 1
end
if not exists(select * from Relationship where Relationship = 'Other')
begin
    insert into Relationship (Relationship, Active, ReadOnly, CreatedBy, RelationshipID) VALUES('Other',     1, 1, @interfaceUser, @relationshipid)
    select @relationshipid = @relationshipid + 1
end
go

if exists (select * from dbo.sysobjects where ID = object_ID(N'Staging_Eligibility') and OBJECTPROPERTY(ID, N'IsUserTable') = 1)
    DROP TABLE Staging_Eligibility
GO

CREATE TABLE Staging_Eligibility (
    EligibilityID         int IDENTITY (1, 1) PRIMARY KEY,
    
    BatchNumber           uniqueidentifier NOT NULL,
    AsOfDate              datetime         NOT NULL,

    FirstName             varchar(30)          NULL,
    LastName              varchar(30)          NULL,
    MembershipID          varchar(30)          NULL,
    MemberAddress1        varchar(45)          NULL,
    MemberAddress2        varchar(45)          NULL,
    MemberAddress3        varchar(45)          NULL,
    MemberCity            varchar(45)          NULL,
    MemberState           varchar(15)          NULL,
    MemberCountry         varchar(30)          NULL,
    MemberPostalCode      varchar(10)          NULL,
    MemberDOB             datetime             NULL,
    MemberGender          char(1)              NULL,
    MemberSSN             varchar(64)          NULL,	-- this will be encrypted, binHEX encoded
    MemberSORGID          varchar(15)          NULL,
    MemberEffectiveDate   datetime         NOT NULL,
    IsSubscriber          bit NOT              NULL,
    MedicaidID            varchar(30)          NULL,
    MedicareID            varchar(30)          NULL,
    MemberMORGID          varchar(15)          NULL,
    MemberORGID           varchar(15)          NULL,
    HomePhoneNumber       varchar(20)          NULL,
    HomePhoneExtension    varchar(6)           NULL,
    WorkPhoneNumber       varchar(20)          NULL,
    WorkPhoneExtension    varchar(6)           NULL,
    Fax                   varchar(20)          NULL,
    FaxExtension          varchar(6)           NULL,
    Email                 varchar(60)          NULL,
    MemberCounty          varchar(30)          NULL,
    Race                  varchar(4)           NULL,
    EligibilityTerminationDate datetime        NULL,
    PlanTerminationDate   datetime             NULL,
    MiddleInitial         char(1)              NULL,        -- Not in Eligibility table
    NameSuffix            varchar(10)          NULL,        -- Not in Eligibility table
    RelationshipCode      varchar(20)          NULL,        -- Not in Eligibility table
    AlternateSubscriberID varchar(30)      NOT NULL,        -- Subscriber's MembershipID
    AlternateInsuranceID  varchar(30)          NULL,        -- typically a Policy #
        
    CreateTime            datetime default(getdate()) NULL,
    DeleteRecord          bit              NOT NULL DEFAULT(0), -- If set, then record will be deleted
    
    MORGID               int                   NULL,
    ORGID                int                   NULL,
    SORGID               int                   NULL,
    RelationshipID       int                   NULL
)
go


if exists (select * from dbo.sysobjects where ID = object_ID(N'dbo.usp_Staging_WriteEligibility') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
    drop procedure usp_Staging_WriteEligibility
GO
CREATE PROCEDURE usp_Staging_WriteEligibility (@batch                 uniqueidentifier,
                                               @asofdate              datetime,
                                               @firstname             varchar(30)   = null,
                                               @lastname              varchar(30)   = null,
                                               @membershipid          varchar(30)   = null,
                                               @memberaddress1        varchar(45)   = null,
                                               @memberaddress2        varchar(45)   = null,
                                               @memberaddress3        varchar(45)   = null,
                                               @membercity            varchar(45)   = null,
                                               @memberstate           varchar(15)   = null,
                                               @membercountry         varchar(30)   = null,
                                               @memberpostalcode      varchar(10)   = null,
                                               @memberdob             datetime      = null,
                                               @membergender          char(1)       = null,
                                               @memberssn             varchar(64)   = null,
                                               @membersorgid          varchar(15)   = null,
                                               @membereffectivedate   datetime      = null,
                                               @issubscriber          char(1)       = null,
                                               @medicaidid            varchar(30)   = null,
                                               @medicareid            varchar(30)   = null,
                                               @membermorgid          varchar(15)   = null,
                                               @memberorgid           varchar(15)   = null,
                                               @homephonenumber       varchar(20)   = null,
                                               @workphonenumber       varchar(20)   = null,
                                               @workphoneextension    varchar(6)    = null,
                                               @fax                   varchar(20)   = null,
                                               @faxextension          varchar(6)    = null,
                                               @email                 varchar(60)   = null,
                                               @county                varchar(30)   = null,
                                               @country               varchar(30)   = null,
                                               @race                  varchar(4)    = null,
                                               @eligibilityterminationdate datetime = null,
                                               @planterminationdate   datetime      = null,
                                               @middlename            varchar(30)   = null,
                                               @namesuffix            varchar(10)   = null,
                                               @relationshipcode      varchar(20)   = null,
                                               @alternatesubscriberid varchar(30),
                                               @alternateinsuranceid  varchar(30)   = null)
AS
BEGIN
    declare @relationshipid int
    select  @relationshipid = RelationshipID from Relationship where Relationship = @relationshipcode

    insert into Staging_Eligibility (BatchNumber, AsOfDate, FirstName, LastName, MembershipID, MemberAddress1, MemberAddress2,
            MemberAddress3, MemberCity, MemberState, MemberCountry, MemberPostalCode, MemberDOB,
            MemberGender, MemberSSN, MemberSORGID, MemberEffectiveDate, IsSubscriber, MedicaidID,
            Medicareid, MemberMORGid, MemberORGid, Homephonenumber, Workphonenumber, Workphoneextension,
            Fax, FaxExtension, Email, MemberCounty, Race, EligibilityTerminationDate, PlanTerminationDate,
            MiddleInitial, NameSuffix, RelationshipCode, AlternateSubscriberID, AlternateInsuranceID, RelationshipID)
    VALUES(@batch, @asofdate, @firstname, @lastname, @membershipid, @memberaddress1, @memberaddress2,
            @memberaddress3, @membercity, @memberstate, @membercountry, @memberpostalcode, @memberdob,
            @membergender, @memberssn, @membersorgid, @membereffectivedate, @issubscriber, @medicaidid,
            @medicareid, @membermorgid, @memberorgid, @homephonenumber, @workphonenumber, @workphoneextension,
            @fax, @faxextension, @email, @county, @race, @eligibilityterminationdate, @planterminationdate,
            CONVERT(char(1), SUBSTRING(@middlename,1,1) ),@namesuffix, @relationshipcode, @alternatesubscriberid, @alternateinsuranceid, @relationshipid)

    return @@ERROR
END
go

if exists (select * from dbo.sysobjects where id = object_id(N'Staging_EligibilityPCP') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    DROP TABLE Staging_EligibilityPCP
GO

CREATE TABLE Staging_EligibilityPCP (
    BatchNumber        uniqueidentifier NOT NULL,
    AlternatePlanID    varchar(30) NOT NULL,    -- alternate id of Plan PCP is through
    AlternateID        varchar(30) NOT NULL,    -- who this coverage belongs too
    AlternateSORGID    varchar(15)     NULL,    -- needed to match records
    AsOfDate           datetime    NOT NULL,
    PCP                varchar(30) NOT NULL,
    PCPType            varchar(20)     NULL,
    EffectiveDate      datetime    NOT NULL,
    TerminationDate    datetime        NULL,
    Status             varchar(1)      NULL,
    ChangeDate         datetime        NULL,
    PCPSpecialty       varchar(30)     NULL,
    PCPLocation        varchar(30)     NULL,
    
    DeleteRecord       bit         NOT NULL DEFAULT(0), -- If set, then record will be deleted
    
    ProviderID         int             NULL,
    SORGID             int             NULL,
    PlanID             int             NULL
)
GO

if exists (select * from dbo.sysobjects where ID = object_ID(N'dbo.usp_Staging_WriteEligibilityPCP') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
    drop procedure usp_Staging_WriteEligibilityPCP
GO
CREATE PROCEDURE usp_Staging_WriteEligibilityPCP (@batch uniqueIDentifier,
                                                  @planid          varchar(30),
                                                  @alternateid     varchar(30),
                                                  @alternatesorgid varchar(15),
                                                  @asofdate        datetime,
                                                  @pcp             varchar(30),
                                                  @pcptype         varchar(20)  = null,
                                                  @effectivedate   datetime,
                                                  @terminationdate datetime     = null,
                                                  @status          char(1)      = null,
                                                  @changedate      datetime     = null,
                                                  @pcpspecialty    varchar(30)  = null,
                                                  @pcplocation     varchar(30)  = null )
AS
BEGIN
    insert into Staging_EligibilityPCP (BatchNumber, AlternatePlanID, AlternateID, AlternateSORGID, AsOfDate, PCP, PCPType, EffectiveDate, TerminationDate, Status, ChangeDate, PCPSpecialty, PCPLocation)
    VALUES (@batch, @planid, @alternateid, @alternatesorgid, @asofdate, @pcp, @pcptype, @effectivedate, @terminationdate, @status, @changedate, @pcpspecialty, @pcplocation)
    return @@ERROR
END
go


if exists (select * from dbo.sysobjects where id = object_id(N'Staging_EligibilityPlan') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    DROP TABLE Staging_EligibilityPlan
GO

CREATE TABLE Staging_EligibilityPlan (
	EligibilityPlanID int IDENTITY(1,1) NOT NULL,
	
    BatchNumber           uniqueidentifier NOT NULL,
    AlternateID		      varchar(30)      NOT NULL,      -- who this coverage belongs too
    AlternateSORGID       varchar(15)          NULL,      -- needed to match records
    AsOfDate              datetime         NOT NULL,
    PlanType              varchar(30)          NULL,
    AlternatePlanID       varchar(30)      NOT NULL,
    GroupID               varchar(30)          NULL,
    EffectiveDate         datetime         NOT NULL,
    TerminationDate       datetime             NULL,
    Status                char(1)          NOT NULL,
    ChangeDate            datetime             NULL,
    AlternateEnrollmentID varchar(30)          NULL,      -- as per requirement, 1 per Member, so 1 per Plan

    SORGID                int                  NULL,
    PlanID                int                  NULL,
    DeleteRecord          bit              NOT NULL DEFAULT(0) -- If set, then record will be deleted
)
go


if exists (select * from dbo.sysobjects where ID = object_ID(N'dbo.usp_Staging_WriteEligibilityPlan') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
    drop procedure usp_Staging_WriteEligibilityPlan
GO
CREATE PROCEDURE usp_Staging_WriteEligibilityPlan (@batch           uniqueidentifier,
                                                   @alternateid     varchar(30),
                                                   @alternatesorgid varchar(15),
                                                   @asofdate        datetime,
                                                   @plantype        varchar(30) = null,
                                                   @plan            varchar(30),
                                                   @groupid         varchar(30) = null,
                                                   @effectivedate   datetime,
                                                   @terminationdate datetime    = null,
                                                   @status          char(1),
                                                   @changedate      datetime    = null,
                                                   @enrollmentid    varchar(30) = null)
AS
BEGIN
        insert into Staging_EligibilityPlan (BatchNumber, AlternateID, AlternateSORGID, AsOfDate, PlanType, AlternatePlanID, GroupID, EffectiveDate, TerminationDate, Status, ChangeDate, AlternateEnrollmentID)
        VALUES(@batch, @alternateid, @alternatesorgid, @asofdate, @plantype, @plan, @groupid, @effectivedate, @terminationdate, @status, @changedate, @enrollmentid)
        return @@ERROR
END
go

--
-- Create the Staging_EligibilityLog. We'll write our "bad" records
--
if exists (select * from dbo.sysobjects where id = object_id(N'Staging_EligibilityLog') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    DROP TABLE Staging_EligibilityLog
go
CREATE TABLE Staging_EligibilityLog(
    AsOfDate        datetime         NOT NULL,
    BatchNumber     uniqueidentifier NOT NULL,
    AlternateID     varchar(30)      NOT NULL,
    AlternateSORGID varchar(30)      NOT NULL,  
    Log             varchar(2000)    NOT NULL
)
go

--
-- usp_Staging_RemoveUnchangedEligibility
-- ======================================
-- Per BR01.8.4.23, if the information in an Eligibility record is not different
-- then don't update anything
if exists (select * from dbo.sysobjects where ID = object_ID(N'dbo.usp_Staging_RemoveUnchangedEligibility') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
    drop procedure usp_Staging_RemoveUnchangedEligibility
GO
CREATE PROCEDURE usp_Staging_RemoveUnchangedEligibility(@batch uniqueidentifier, @asofdate datetime)
AS
BEGIN
    -- Now update OrganizationIDs to the Primary Key of the Organization table    
exec usp_Staging_PerfmonStart @batch, 'EligSORGIDupdate', ' Eligibility SORGIds updated'
    UPDATE Staging_Eligibility
    SET SORGID = SORG.OrganizationID
    FROM Staging_Eligibility SE
    INNER JOIN Organization SORG ON SORG.AlternateID = SE.MemberSORGID
    WHERE BatchNumber = @batch
exec usp_Staging_PerfmonEnd @batch, 'EligSORGIDupdate', @@ROWCOUNT

exec usp_Staging_PerfmonStart @batch, 'EligMORGIDupdate', ' Eligibility MORGIds updated'
    UPDATE Staging_Eligibility
    SET MORGID = MORG.OrganizationID
    FROM Staging_Eligibility SE
    INNER JOIN Organization MORG ON MORG.AlternateID = SE.MemberMORGID
    WHERE BatchNumber = @batch AND SE.MemberMORGID is not null
exec usp_Staging_PerfmonEnd @batch, 'EligMORGIDupdate', @@ROWCOUNT
    
exec usp_Staging_PerfmonStart @batch, 'EligORGIDupdate', ' Eligibility ORGIds updated'
    UPDATE Staging_Eligibility
    SET ORGID = ORG.OrganizationID
    FROM Staging_Eligibility SE
    INNER JOIN Organization ORG ON ORG.AlternateID = SE.MemberORGID
    WHERE BatchNumber = @batch AND SE.MemberORGID is not null
exec usp_Staging_PerfmonEnd @batch, 'EligORGIDupdate', @@ROWCOUNT
    
exec usp_Staging_PerfmonStart @batch, 'Eligibility Plan OrganizationID update', ' Eligibility Plan records unchanged'
    UPDATE Staging_EligibilityPlan
    SET SORGID = SORG.OrganizationID,
        PlanID = PLN.PlanID
    FROM Staging_EligibilityPlan SEP
    INNER JOIN Organization SORG ON SORG.AlternateID     = SEP.AlternateSORGID
    INNER JOIN [Plan]        PLN ON PLN.AlternatePlanID  = SEP.AlternatePlanID
    WHERE BatchNumber = @batch
exec usp_Staging_PerfmonEnd @batch, 'Eligibility Plan OrganizationID update', @@ROWCOUNT
        
exec usp_Staging_PerfmonStart @batch, 'Eligibility PCP OrganizationID update', ' Eligibility PCP records unchanged'
    UPDATE Staging_EligibilityPCP
    SET SORGID = SORG.OrganizationID,
        PlanID = PLN.PlanID
    FROM Staging_EligibilityPCP PCP
    INNER JOIN Organization SORG ON SORG.AlternateID     = PCP.AlternateSORGID
    INNER JOIN [Plan]        PLN ON PLN.AlternatePlanID  = PCP.AlternatePlanID
    INNER JOIN Provider      PRV ON PRV.AlternateID      = PCP.AlternateID
    WHERE BatchNumber = @batch
exec usp_Staging_PerfmonEnd @batch, 'Eligibility PCP OrganizationID update', @@ROWCOUNT

    -- If nothing has changed in the Eligibility information, then 
    -- don't bother processing the record
exec usp_Staging_PerfmonStart @batch, 'Unchanged Eligibility', ' Eligibility records unchanged'
     UPDATE Staging_Eligibility
     SET DeleteRecord = 1
     FROM  Staging_Eligibility SE
     INNER JOIN Eligibility     E ON    E.MembershipID   = SE.MembershipID AND E.SORGID = SE.SORGID
LEFT OUTER JOIN Organization MORG ON MORG.OrganizationID = E.MORGID
LEFT OUTER JOIN Organization  ORG ON  ORG.OrganizationID = E.ORGID
     INNER JOIN Organization SORG ON SORG.OrganizationID = E.SORGID
     WHERE SE.BatchNumber               = @batch                        AND
          ( (E.FirstName                  = SE.FirstName)                 OR (E.FirstName is null AND SE.FirstName is null)) AND
          ( (E.LastName                   = SE.LastName)                  OR (E.LastName  is null AND SE.LastName  is null)) AND
          ( (E.MiddleInitial              = SE.MiddleInitial)             OR (E.MiddleInitial is null AND SE.MiddleInitial is null)) AND
          ( (E.MemberAddress1             = SE.MemberAddress1)            OR (E.MemberAddress1 is null AND SE.MemberAddress1 is null)) AND
          ( (E.MemberAddress2             = SE.MemberAddress2)            OR (E.MemberAddress2 is null AND SE.MemberAddress2 is null)) AND
          ( (E.MemberAddress3             = SE.MemberAddress3)            OR (E.MemberAddress3 is null AND SE.MemberAddress3 is null)) AND
          ( (E.MemberCity                 = SE.MemberCity)                OR (E.MemberCity is null AND SE.MemberCity is null)) AND
          ( (E.MemberPostalCode           = SE.MemberPostalCode)          OR (E.MemberPostalCode is null AND SE.MemberPostalCode is null)) AND
          ( (E.MemberCounty               = SE.MemberCounty)              OR (E.MemberCounty is null AND SE.MemberCounty is null)) AND
          ( (E.MemberCountry              = SE.MemberCountry)             OR (E.MemberCountry is null AND SE.MemberCountry is null)) AND
          ( (E.MemberDOB                  = SE.MemberDOB)                 OR (E.MemberDOB is null AND SE.MemberDOB is null)) AND
          ( (E.MemberGender               = SE.MemberGender)              OR (E.MemberGender is null AND SE.MemberGender is null)) AND
          SORG.AlternateID             = SE.MemberSORGID                  AND
          ( (ORG.AlternateID              = SE.MemberORGID)               OR (E.MemberORGID is null AND SE.MemberORGID is null)) AND
          ( (MORG.AlternateID             = SE.MemberMORGID)              OR (E.MemberMORGID is null AND SE.MemberMORGID is null)) AND
          E.AlternateSubscriberID      = SE.AlternateSubscriberID      AND
          ( (E.EligibilityTerminationDate = SE.EligibilityTerminationDate)OR (E.EligibilityTerminationDate is null AND SE.EligibilityTerminationDate is null)) AND
          ( (E.HomePhoneNumber            = SE.HomePhoneNumber)           OR (E.HomePhoneNumber is null AND SE.HomePhoneNumber is null)) AND
          ( (E.HomePhoneExtension         = SE.HomePhoneExtension)        OR (E.HomePhoneExtension is null AND SE.HomePhoneExtension is null)) AND
          ( (E.WorkPhoneNumber            = SE.WorkPhoneNumber)           OR (E.WorkPhoneNumber is null AND SE.WorkPhoneNumber is null)) AND
          ( (E.WorkPhoneExtension         = SE.WorkPhoneExtension)        OR (E.WorkPhoneExtension is null AND SE.WorkPhoneExtension is null)) AND
          ( (E.Fax                        = SE.Fax)                       OR (E.Fax is null AND SE.Fax is null)) AND
          ( (E.FaxExtension               = SE.FaxExtension)              OR (E.FaxExtension is null AND SE.FaxExtension is null)) AND
          E.MemberEffectiveDate        = SE.MemberEffectiveDate           AND
          ( (E.Email                      = SE.Email)                     OR (E.Email is null AND SE.Email is null)) AND
          ( (E.NameSuffix                 = SE.NameSuffix)                OR (E.NameSuffix is null AND SE.NameSuffix is null)) AND
          ( (E.RelationshipID             = SE.RelationshipID)            OR (E.RelationshipID is null AND SE.RelationshipID is null)) AND
          ( (E.AlternateInsuranceID       = SE.AlternateInsuranceID)      OR (E.AlternateInsuranceID is null AND SE.AlternateInsuranceID is null) )
exec usp_Staging_PerfmonEnd @batch, 'Unchanged Eligibility', @@ROWCOUNT
    
exec usp_Staging_PerfmonStart @batch, 'Unchanged Eligibility Plan', ' Eligibility Plan records unchanged'
    UPDATE Staging_EligibilityPlan
    SET DeleteRecord = 1
    FROM Staging_EligibilityPlan SEP
    INNER JOIN EligibilityPlan EP ON EP.PlanID = SEP.PlanID
    WHERE SEP.BatchNumber    = @batch              AND
          EP.EffectiveDate   = SEP.EffectiveDate   AND
          ( (EP.TerminationDate = SEP.TerminationDate) OR (EP.TerminationDate is null AND SEP.TerminationDate is null) )
exec usp_Staging_PerfmonEnd @batch, 'Unchanged Eligibility Plan', @@ROWCOUNT

exec usp_Staging_PerfmonStart @batch, 'Unchanged Eligibility PCP', ' Eligibility PCP records unchanged'
    UPDATE Staging_EligibilityPCP
    SET DeleteRecord = 1
    FROM Staging_EligibilityPCP SPCP
    INNER JOIN EligibilityPCP PCP ON PCP.PlanID = SPCP.PlanID AND PCP.PCPID = SPCP.ProviderID
    WHERE SPCP.BatchNumber     = @batch              AND
          SPCP.EffectiveDate   = PCP.EffectiveDate   AND
          ( (SPCP.TerminationDate = PCP.TerminationDate) OR (SPCP.TerminationDate is null AND PCP.TerminationDate is null) )
exec usp_Staging_PerfmonEnd @batch, 'Unchanged Eligibility PCP', @@ROWCOUNT
                
    -- Get rid of records we have flagged as not changing
exec usp_Staging_PerfmonStart @batch, 'Deleted Eligibility', ' Eligibility records deleted'
    DELETE FROM Staging_Eligibility     WHERE DeleteRecord = 1
exec usp_Staging_PerfmonEnd @batch, 'Deleted Eligibility', @@ROWCOUNT

exec usp_Staging_PerfmonStart @batch, 'Deleted Eligibility Plan', ' Eligibility Plan records deleted'
    DELETE FROM Staging_EligibilityPlan WHERE DeleteRecord = 1
exec usp_Staging_PerfmonEnd @batch, 'Deleted Eligibility Plan', @@ROWCOUNT

exec usp_Staging_PerfmonStart @batch, 'Deleted Eligibility PCP', ' Eligibility PCP records deleted'
    DELETE FROM Staging_EligibilityPCP  WHERE DeleteRecord = 1
exec usp_Staging_PerfmonEnd @batch, 'Deleted Eligibility PCP', @@ROWCOUNT

END
go

if exists (select * from dbo.sysobjects where ID = object_ID(N'dbo.usp_Staging_ProcessCoverage') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
    drop procedure usp_Staging_ProcessCoverage
GO
CREATE PROCEDURE usp_Staging_ProcessCoverage (@batch uniqueidentifier, @asofdate datetime)
AS
BEGIN
--
-- usp_Staging_ProcessCoverage
-- ===========================
-- This procedure is run after the processing of the eligibility staging tables. The purpose
-- of this procedure is to update coverage & demographic information in the Patient/Subscriber & 
-- Coverage tables per Use Cases 3.0 - 3.4
--
    declare @interfaceUser int
    exec @interfaceUser = usp_Staging_GetInterfaceUser
    
    -- Update the Patient demographic information via the EligibilityID
    
exec usp_Staging_PerfmonStart @batch, 'UpdatePatients', ' Patient records updated'
    UPDATE Patient
    SET LastName      = E.LastName,
        FirstName     = E.FirstName,
        MiddleInitial = E.MiddleInitial,
        Gender        = E.MemberGender,
        DateOfBirth   = E.MemberDOB,
        ModifiedBy    = @interfaceUser,
        ModifyTime    = getdate()
    FROM Eligibility E
    INNER JOIN PatientCoverage PC ON PC.PatientEligibilityID = E.EligibilityID
    INNER JOIN Patient          P ON P.PatientID             = PC.PatientID
    WHERE E.AsOfDate = @asofdate
exec usp_Staging_PerfmonEnd @batch, 'UpdatePatients', @@ROWCOUNT

    -- Update the rest of the demographic data (Address)
exec usp_Staging_PerfmonStart @batch, 'UpdatePatientAddresses', ' Patient Address records updated'
    UPDATE Address
    SET Line1         = E.MemberAddress1,
        Line2         = E.MemberAddress2,
        Line3         = E.MemberAddress3,
        City          = E.MemberCity,
        State         = E.MemberState,
        Zip           = E.MemberPostalCode,
        County        = E.MemberCounty,
        Country       = E.MemberCountry,
        Email         = E.Email,
        PhoneNumber1  = E.HomePhoneNumber,
        PhoneExt1     = E.HomePhoneExtension,
        PhoneNumber2  = E.WorkPhoneNumber,
        PhoneExt2     = E.WorkPhoneExtension,
        FaxNumber     = E.Fax,
        FaxExtension  = E.FaxExtension
    FROM Eligibility E
    INNER JOIN PatientCoverage PC ON PC.PatientEligibilityID = E.EligibilityID
    INNER JOIN Patient          P ON P.PatientID             = PC.PatientID
    INNER JOIN Address          A ON A.AddressID             = P.AddressID
    WHERE E.AsOfDate = @asofdate
exec usp_Staging_PerfmonEnd @batch, 'UpdatePatientAddresses', @@ROWCOUNT

exec usp_Staging_PerfmonStart @batch, 'UpdateSubscribers', ' Subscriber records updated'
    UPDATE Subscriber
    SET LastName      = E.LastName,
        FirstName     = E.FirstName,
        MiddleInitial = E.MiddleInitial,
        Gender        = E.MemberGender,
        DateOfBirth   = E.MemberDOB,
        ModifiedBy    = @interfaceUser,
        ModifyTime    = getdate()
    FROM Eligibility E
    INNER JOIN PatientCoverage PC ON PC.SubscriberEligibilityID = E.EligibilityID
    INNER JOIN Subscriber       S ON S.SubscriberID             = PC.SubscriberID
    WHERE E.AsOfDate = @asofdate
exec usp_Staging_PerfmonEnd @batch, 'UpdateSubscribers', @@ROWCOUNT

exec usp_Staging_PerfmonStart @batch, 'UpdateSubscriberAddresses', ' Subscriber Address records updated'
    UPDATE Address
    SET Line1         = E.MemberAddress1,
        Line2         = E.MemberAddress2,
        Line3         = E.MemberAddress3,
        City          = E.MemberCity,
        State         = E.MemberState,
        Zip           = E.MemberPostalCode,
        County        = E.MemberCounty,
        Country       = E.MemberCountry,
        Email         = E.Email,
        PhoneNumber1  = E.HomePhoneNumber,
        PhoneExt1     = E.HomePhoneExtension,
        PhoneNumber2  = E.WorkPhoneNumber,
        PhoneExt2     = E.WorkPhoneExtension,
        FaxNumber     = E.Fax,
        FaxExtension  = E.FaxExtension
    FROM Eligibility E
    INNER JOIN PatientCoverage PC ON PC.SubscriberEligibilityID = E.EligibilityID
    INNER JOIN Subscriber       S ON S.SubscriberID = PC.SubscriberID
    INNER JOIN Address          A ON A.AddressID       = S.AddressID
    WHERE E.AsOfDate = @asofdate
exec usp_Staging_PerfmonEnd @batch, 'UpdateSubscriberAddresses', @@ROWCOUNT

    -- Determine if our new EligibilityPlan date will in-activate any existing
    -- PatientCoverageData records (per Use Case 3.4 "Update Patient Coverage")
exec usp_Staging_PerfmonStart @batch, 'UpdatePatientCoverageData', ' PatientCoverageData records updated'
    UPDATE PatientCoverageData SET Active = 0
    FROM PatientCoverageData PCD
    INNER JOIN PatientCoverage PC ON PC.PatientCoverageID = PCD.PatientCoverageID
    INNER JOIN EligibilityPlan EP ON EP.EligibilityID     = PC.PatientEligibilityID
    WHERE ( (PCD.TerminationDate > EP.EffectiveDate   OR PCD.TerminationDate is null) AND
            (PCD.EffectiveDate   < EP.TerminationDate OR EP.TerminationDate  is null) )
                                  OR
          ( (PCD.EffectiveDate = EP.EffectiveDate AND
            (PCD.EffectiveDate = EP.TerminationDate OR EP.EffectiveDate = EP.TerminationDate) ) )
exec usp_Staging_PerfmonEnd @batch, 'UpdatePatientCoverageData', @@ROWCOUNT

    -- Since the only EligibilityPlan records with a new AsOfDate are
    -- changed, we need to create PatientCoverageData for all of them.
exec usp_Staging_PerfmonStart @batch, 'InsertPatientCoverageData', ' PatientCoverageData records inserted'
    INSERT PatientCoverageData (PatientCoverageID, AsOfDate, EffectiveDate, 
                                TerminationDate, TerminateTime, TerminatedBy, Active)
    SELECT PC.PatientCoverageID,
            E.AsOfDate,
            EP.EffectiveDate,
            EP.TerminationDate,
            CASE WHEN EP.TerminationDate <> PCD.TerminationDate THEN getdate()  ELSE null END,
            CASE WHEN EP.TerminationDate is not null THEN @interfaceUser ELSE null END,
            CASE WHEN EP.EffectiveDate = EP.TerminationDate THEN 0 ELSE 1 END -- when eff is same as term, then ignore the record...
    FROM EligibilityPlan EP
    INNER JOIN Eligibility              E ON E.EligibilityID           = EP.EligibilityID
    INNER JOIN PatientCoverage         PC ON PC.PatientEligibilityID   = EP.EligibilityID
    INNER JOIN PatientCoverageData    PCD ON PCD.PatientCoverageDataID = (select max(PatientCoverageDataID) from PatientCoverageData where PatientCoverageID = PC.PatientCoverageID)
    WHERE EP.AsOfDate = @asofdate
exec usp_Staging_PerfmonEnd @batch, 'InsertPatientCoverageData', @@ROWCOUNT
    
    -- create a temp table so we can easily track the PatientSubscriberLog we just created by
    -- association with a uuid. This allows us to "find" it when we are creating the PatientCoveragePCPLog entry  
    CREATE TABLE #LogUpdate(
        PatientCoverageID int NOT NULL CONSTRAINT FK_PatientCoverage_LogUpdate FOREIGN KEY (PatientCoverageID) REFERENCES PatientCoverage(PatientCoverageID),
        uuid uniqueidentifier default(NEWID() ) NOT NULL,
    )

    -- Create the list of coverage updates we just performed. We're
    -- going to ignore any records where the eff & term dates are the same since
    -- they are "inactive".
    INSERT #LogUpdate
    SELECT PC.PatientCoverageID, NEWID()
    FROM PatientCoverage PC
    INNER JOIN Eligibility           E ON E.EligibilityID       = PC.PatientEligibilityID
    INNER JOIN PatientCoverageData PCD ON PCD.PatientCoverageID = PC.PatientCoverageID AND PCD.AsOfDate = @asofdate AND PCD.Active = 1
    WHERE PC.PatientEligibilityID is not null AND E.AsOfDate = @asofdate
    
    -- We need to update the PatientSubscriberLog for any
    -- coverage records that we have changed.
exec usp_Staging_PerfmonStart @batch, 'InsertPatSubLog', ' PatientSubscriberLog records updated'
    INSERT PatientSubscriberLog
           (CreationDate, PatientID, PatientRelationshipID, AlternateGroupID, AlternateInsuranceID,
            PatientAlternateID, PatientFirstName, PatientLastName, PatientMiddleInitial, PatientNamePrefixID,
            PatientDOB, PatientSSN, PatientGender,PatientAddress1, PatientAddress2, PatientAddress3, PatientCity,
            PatientState, PatientZip, PatientCounty, PatientCountry, PatientHomePhone, PatientWorkPhone,
            PatientWorkExtension, PatientFaxPhone, PatientFaxExtension, PatientEmail, PatientAssignedUserID,
            PatientAssignedTeamID, PatientMedicaidID, PatientMedicareID, PatientCreatedByUserID, PatientCreationDate,
            PatientModifiedByUserID, PatientModificationDate, PatientUDEF1, PatientUDEF2, PatientUDEF3, PatientUDEF4,
            PatientUDEF5, PatientUDEF6, PatientUDEF7, PatientUDEF8, PatientUDEF9, PatientUDEF10, PatientUDEF11,
            PatientUDEF12, PatientUDEF13, PatientUDEF14,
            SubscriberID, AlternateSubscriberID, SubscriberLastName, SubscriberNamePrefixID,SubscriberFirstName, SubscriberMiddleInitial,
            SubscriberDOB, SubscriberSSN, SubscriberGender, SubscriberCreatedByUserID, SubscriberCreationDate,
            SubscriberModifiedByUserID, SubscriberModificationDate, SubscriberAssignedUserID, SubscriberAssignedTeamID,
            SubscriberUDEF1, SubscriberUDEF2, SubscriberUDEF3, SubscriberUDEF4, SubscriberUDEF5, SubscriberUDEF6,
            SubscriberUDEF7, SubscriberUDEF8, SubscriberUDEF9, SubscriberUDEF10, SubscriberUDEF11, SubscriberUDEF12,
            SubscriberUDEF13, SubscriberUDEF14, SubscriberNotePad, SubscriberAddress1, SubscriberAddress2, SubscriberAddress3,
            SubscriberCity, SubscriberState, SubscriberZip, SubscriberCounty, SubscriberCountry, SubscriberHomePhone,
            SubscriberWorkPhone, SubscriberWorkPhoneExtension, SubscriberFaxPhone, SubscriberFaxPhoneExtension, SubscriberEmail,
            SubscriberNameSuffix, PatientNameSuffix, PatientRelatedProblemID, PatientRelatedEventID, PatientAsOfDate,
            AlternateMemberID, PatientSubscriberRelationshipID, OtherPlan,
            SubscriberAsOfDate, SORGID, PlanID, SubscriberCoverageIsPrimary,
            SubscriberCoverageCreatedBy, SubscriberCoverageCreateTime, SubscriberCoverageModifyTime,
            SubscriberCoverageModifiedBy, SubscriberEligibilityID,
            uuid, PatientEligibilityID, PatientCoverageDataID)
    SELECT    getdate()                    AS CreationDate,
              PC.PatientID                 AS PatientID,
              PC.RelationshipID            AS PatientRelationshipID,
              PC.AlternateGroupID          AS AlternateGroupID,
              PC.AlternateInsuranceID      AS AlternateInsuranceID,
              PC.AlternatePatientID        AS PatientAlternateID,
              P.FirstName                  AS PatientFirstName,
              P.LastName                   AS PatientLastName,
              P.MiddleInitial              AS PatientMiddleInitial,
              P.NamePrefixID               AS PatientNamePrefixID,
              P.DateOfBirth                AS PatientDOB,
              P.SocialSecurityNumber       AS PatientSSN,
              P.Gender                     AS PatientGender,
              PA.Line1                     AS PatientAddress1,
              PA.Line2                     AS PatientAddress2,
              PA.Line3                     AS PatientAddress3,
              PA.City                      AS PatientCity,
              PA.State                     AS PatientState,
              PA.Zip                       AS PatientZip,
              PA.County                    AS PatientCounty,
              PA.Country                   AS PatientCountry,
              PA.PhoneNumber1              AS PatientHomePhone,
              PA.PhoneNumber2              AS PatientWorkPhone,
              PA.PhoneExt2                 AS PatientWorkPhoneExtension,
              PA.FaxNumber                 AS PatientFaxPhone,
              PA.FaxExtension              AS PatientFaxExtension,
              PA.Email                     AS PatientEmail,
              P.AssignedUserID             AS PatientAssignedUserID,
              P.AssignedTeamID             AS PatientAssignedTeamID,
              null                         AS PatientMedicaidID,
              null                         AS PatientMedicareID,
              P.CreatedBy                  AS PatientCreatedByUserID,
              P.CreateTime                 AS PatientCreationDate,
              P.ModifiedBy                 AS PatientModifiedByUserID,
              P.ModifyTime                 AS PatientModificationDate,
              PU.UDEF1                     AS PatientUDEF1,
              PU.UDEF2                     AS PatientUDEF2,
              PU.UDEF3                     AS PatientUDEF3,
              PU.UDEF4                     AS PatientUDEF4,
              PU.UDEF5                     AS PatientUDEF5,
              PU.UDEF6                     AS PatientUDEF6,
              PU.UDEF7                     AS PatientUDEF7,
              PU.UDEF8                     AS PatientUDEF8,
              PU.UDEF9                     AS PatientUDEF9,
              PU.UDEF10                    AS PatientUDEF10,
              PU.UDEF11                    AS PatientUDEF11,
              PU.UDEF12                    AS PatientUDEF12,
              PU.UDEF13                    AS PatientUDEF13,
              PU.UDEF14                    AS PatientUDEF14,
              S.SubscriberID               AS SubscriberID,
              PC.AlternateSubscriberID     AS AlternateSubscriberID,
              S.LastName                   AS SubscriberLastName,
              S.NamePrefixID               AS SubscriberNamePrefixID,
              S.FirstName                  AS SubscriberFirstName,
              S.MiddleInitial              AS SubscriberMiddleInitial,
              S.DateOfBirth                AS SubscriberDOB,
              S.SocialSecurityNumber       AS SubscriberSSN,
              S.Gender                     AS SubscriberGender,
              S.CreatedBy                  AS SubscriberCreatedByUserID,
              S.CreateTime                 AS SubscriberCreationDate,
              S.ModifiedBy                 AS SubscriberModifiedByUserID,
              S.ModifyTime                 AS SubscriberModificationDate,
              null                         AS SubscriberAssignedUserID,
              null                         AS SubscriberAssignedTeamID,
              SU.UDEF1                     AS SubscriberUDEF1,
              SU.UDEF2                     AS SubscriberUDEF2,
              SU.UDEF3                     AS SubscriberUDEF3,
              SU.UDEF4                     AS SubscriberUDEF4,
              SU.UDEF5                     AS SubscriberUDEF5,
              SU.UDEF6                     AS SubscriberUDEF6,
              SU.UDEF7                     AS SubscriberUDEF7,
              SU.UDEF8                     AS SubscriberUDEF8,
              SU.UDEF9                     AS SubscriberUDEF9,
              SU.UDEF10                    AS SubscriberUDEF10,
              SU.UDEF11                    AS SubscriberUDEF11,
              SU.UDEF12                    AS SubscriberUDEF12,
              SU.UDEF13                    AS SubscriberUDEF13,
              SU.UDEF14                    AS SubscriberUDEF14,
              null                         AS SubscriberNotePad,
              SA.Line1                     AS SubscriberAddress1,
              SA.Line2                     AS SubscriberAddress2,
              SA.Line3                     AS SubscriberAddress3,
              SA.City                      AS SubscriberCity,
              SA.State                     AS SubscriberState,
              SA.Zip                       AS SubscriberZip,
              SA.County                    AS SubscriberCounty,
              SA.Country                   AS SubscriberCountry,
              SA.PhoneNumber1              AS SubscriberHomePhone,
              SA.PhoneNumber2              AS SubscriberWorkPhone,
              SA.PhoneExt2                 AS SubscriberWorkPhoneExtension,
              SA.FaxNumber                 AS SubscriberFaxPhone,
              SA.FaxExtension              AS SubscriberFaxExtension,
              SA.Email                     AS SubscriberEmail,
              S.NameSuffix                 AS SubscriberNameSuffix,
              P.NameSuffix                 AS PatientNameSuffix,
              null                         AS PatientRelatedProblemID,
              null                         AS PatientRelatedEventID,
              P.AsOfDate                   AS PatientAsOfDate,
              PC.AlternatePatientID        AS AlternateMemberID,
              PC.RelationshipID            AS PatientSubscriberRelationshipID,
              null                         AS OtherPlan,
              S.AsOfDate                   AS SubscriberAsOfDate,
              PC.SORGID                    AS SORGID,
              PC.PlanID                    AS PlanID,
              PC.IsPrimary                 AS SubscriberCoverageIsPrimary,
              PC.CreatedBy                 AS SubscriberCoverageCreatedBy,
              PC.CreateTime                AS SubscriberCoverageCreateTime,
              PC.ModifyTime                AS SubscriberCoverageModifyTime,
              PC.ModifiedBy                AS SubscriberCoverageModifiedBy,
              PC.SubscriberEligibilityID   AS SubscriberEligibilityID,
              E.EligibilityID              AS PatientEligibilityID,
              PCD.PatientCoverageDataID    AS PatientCoverageDataID,
              LU.uuid                      AS uuid
    FROM PatientCoverage PC
          INNER JOIN #LogUpdate                 LU ON  LU.PatientCoverageID    = PC.PatientCoverageID
          INNER JOIN Eligibility                 E ON   E.EligibilityID        = PC.PatientEligibilityID
          INNER JOIN Patient                     P ON   P.PatientID            = PC.PatientID
          INNER JOIN Address                    PA ON  PA.AddressID            = P.AddressID
    LEFT  OUTER JOIN UserDefined                PU ON  PU.UserDefinedID        = P.UserDefinedID
          INNER JOIN Subscriber                  S ON   S.SubscriberID         = PC.SubscriberID
          INNER JOIN Address                    SA ON  SA.AddressID            = S.AddressID
    LEFT  OUTER JOIN UserDefined                SU ON  SU.UserDefinedID        = S.UserDefinedID
          INNER JOIN PatientCoverageData    PCD ON PCD.PatientCoverageID    = PC.PatientCoverageID AND PCD.PatientCoverageDataID = (select max(PatientCoverageDataID) from PatientCoverageData where PatientCoverageID = PC.PatientCoverageID)
    WHERE PC.PatientEligibilityID is not null AND 
          (E.AsOfDate = @asofdate OR PC.AsOfDate = @asofdate)
exec usp_Staging_PerfmonEnd @batch, 'InsertPatSubLog', @@ROWCOUNT
    
    -- Now create the PCP entries associated with the PatientSubscriberLog
exec usp_Staging_PerfmonStart @batch, 'InsertPatientCoveragePCPLog', ' PatientCoveragePCPLog records created'
    INSERT PatientCoveragePCPLog (PatientSubscriberLogID, LocationID, SpecialtyID, ServiceTypeID, EffectiveDate, TerminationDate, AlternateProviderID, AlternateLocationID)
    SELECT 
           PSL.PatientSubscriberLogID,
           L.LocationID,
           S.SpecialtyID,
           PST.ProviderServiceTypeID,
           PCP.EffectiveDate,
           PCP.TerminationDate,
           P.AlternateID,
           L.AlternateID
    FROM PatientCoverage PC
    INNER JOIN #LogUpdate               LU ON  LU.PatientCoverageID     = PC.PatientCoverageID
    INNER JOIN PatientSubscriberLog    PSL ON PSL.uuid                  = LU.uuid
    INNER JOIN PatientCoveragePCP      PCP ON PCP.PatientCoverageID     = PC.PatientCoverageID
    INNER JOIN ProviderLocation         PL ON  PL.ProviderLocationID    = PCP.ProviderLocationID
    INNER JOIN Location                  L ON   L.LocationID            = PL.LocationID
    INNER JOIN Provider                  P ON   P.ProviderID            = PL.ProviderID
    INNER JOIN ProviderSpecialty        PS ON  PS.ProviderID            = P.ProviderID AND PS.[Primary] = 1
    INNER JOIN Specialty                 S ON   S.SpecialtyID           = PS.SpecialtyID
    INNER JOIN ProviderLocationService PLS ON PLS.ProviderLocationID    = PCP.ProviderLocationID
    INNER JOIN ProviderServiceType     PST ON PST.ProviderServiceTypeID = PLS.ProviderServiceTypeID
    WHERE PC.PatientEligibilityID is not null
exec usp_Staging_PerfmonEnd @batch, 'InsertPatientCoveragePCPLog', @@ROWCOUNT
    
    return @@ERROR
END
go

if exists (select * from dbo.sysobjects where ID = object_ID(N'dbo.usp_Staging_ProcessEligibility') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
    drop procedure usp_Staging_ProcessEligibility
GO
CREATE PROCEDURE usp_Staging_ProcessEligibility (@batch uniqueidentifier, @asofdate datetime)
AS
BEGIN
--
-- usp_Staging_ProcessEligibility
-- ==============================
-- This procedure will take the imported eligibility data from the staging files
-- and move it to the product tables (Eligibility, EligibilityPlan & EligibilityPCP)
-- The appropriate tables are updated, inserts are made and coverage is updated & created

    -- First remove all records that are the same as existing Eligibility
    -- records.
	exec usp_Staging_RemoveUnchangedEligibility @batch, @asofdate
	
    -- Now update Eligibility table records
    -- The PK of this table is:
    --
    --     EligibilityID
    --
    -- Records can also be uniquely identified by the following:
    --
    --      MembershipID | MemberSORGID
    --
    -- [Note: Can the AlternateSORGID change, if so we'll miss record??]

exec usp_Staging_PerfmonStart @batch, 'EligUpdate', ' Eligibility records updated'
    UPDATE Eligibility SET FirstName                  = ES.FirstName,
                           LastName                   = ES.LastName,
                           MemberAddress1             = ES.MemberAddress1,
                           MemberAddress2             = ES.MemberAddress2,
                           MemberAddress3             = ES.MemberAddress3,
                           MemberCity                 = ES.MemberCity,
                           MemberState                = ES.MemberState,
                           MemberCountry              = ES.MemberCountry,
                           MemberPostalCode           = ES.MemberPostalCode,
                           MemberDOB                  = ES.MemberDOB,
                           MemberGender               = ES.MemberGender,
                           MemberSSN                  = ES.MemberSSN,             -- this must be encrypted in C#
                           MemberEffectiveDate        = ES.MemberEffectiveDate,   -- Where is this value from ??
                           IsSubscriber               = ES.IsSubscriber,
                           MedicaidID                 = ES.MedicaidID,
                           MedicareID                 = ES.MedicareID,
                           MemberMORGID               = ES.MemberMORGID,
                           MemberORGID                = ES.MemberORGID,
                           HomePhoneNumber            = ES.HomePhoneNumber,
                           WorkPhoneNumber            = ES.WorkPhoneNumber,
                           WorkPhoneExtension         = ES.WorkPhoneExtension,
                           Fax                        = ES.Fax,
                           FaxExtension               = ES.FaxExtension,
                           Email                      = ES.Email,
                           MemberCounty               = ES.MemberCounty,
                           Race                       = ES.Race,
                           EligibilityTerminationDate = ES.EligibilityTerminationDate,
                           PlanTerminationDate        = ES.PlanTerminationDate,    -- where is this value from ??
                           MiddleInitial              = ES.MiddleInitial,
                           NameSuffix                 = ES.NameSuffix,
                           RelationshipID             = ES.RelationshipID,
                           AlternateSubscriberID      = ES.AlternateSubscriberID,
                           AlternateInsuranceID       = ES.AlternateInsuranceID,
                           AsOfDate                   = ES.AsOfDate
    FROM Staging_Eligibility ES
    INNER JOIN Eligibility E ON E.MembershipID = ES.MembershipID AND E.MemberSORGID = ES.MemberSORGID
    WHERE ES.BatchNumber = @batch
exec usp_Staging_PerfmonEnd @batch, 'EligUpdate', @@ROWCOUNT

exec usp_Staging_PerfmonStart @batch, 'EligInsert', ' Eligibility records inserted'
    INSERT Eligibility (AsOfDate, FirstName, LastName, MembershipID, MemberAddress1, MemberAddress2, MemberAddress3,
                        MemberCity, MemberState, MemberCountry, MemberPostalCode, MemberDOB, MemberGender, MemberSSN,
                        MemberSORGID, MemberEffectiveDate, IsSubscriber, MedicaidID, MedicareID, MemberMORGID, MemberORGID,
                        HomePhoneNumber, WorkPhoneNumber, WorkPhoneExtension, Fax, FaxExtension, Email, Race, EligibilityTerminationDate,
                        PlanTerminationDate, MemberCounty, MiddleInitial, NameSuffix, RelationshipID, HomePhoneExtension, AlternateSubscriberID, SORGID)
        SELECT AsOfDate,
               FirstName,
               LastName,
               MembershipID,
               MemberAddress1,
               MemberAddress2,
               MemberAddress3,
               MemberCity,
               MemberState,
               MemberCountry,
               MemberPostalCode,
               MemberDOB,
               MemberGender,
               MemberSSN,
               MemberSORGID,
               MemberEffectiveDate,
               IsSubscriber,
               MedicaidID,
               MedicareID,
               MemberMORGID,
               MemberORGID,
               HomePhoneNumber,
               WorkPhoneNumber,
               WorkPhoneExtension,
               Fax,
               FaxExtension,
               Email,
               Race,
               EligibilityTerminationDate,
               PlanTerminationDate,
               MemberCounty,
               MiddleInitial,
               NameSuffix,
               RelationshipID,
               HomePhoneExtension,
               AlternateSubscriberID,
               SORGID
    FROM Staging_Eligibility SE
    WHERE BatchNumber = @batch AND
    -- Only create records for MembershipID/SORGID combinations that don't already exist!! 
    not exists(select * from Eligibility E where E.MembershipID = SE.MembershipID AND E.MemberSORGID = SE.MemberSORGID)
exec usp_Staging_PerfmonEnd @batch, 'EligInsert', @@ROWCOUNT

    -- If the PlanType is NULL, the set to 'UNKNOWN' (avoid problems with FK constraint)
    UPDATE Staging_EligibilityPlan SET PlanType = 'UNKNOWN' WHERE PlanType is null
    
    -- Now update the EligibilityPlan information
    -- The PK into this table is:
    --
    --    EligibilityID | PlanID
    --
exec usp_Staging_PerfmonStart @batch, 'EligPlanUpdate', ' EligibilityPlan records updated'
    UPDATE EligibilityPlan SET AsOfDate        = SEP.AsOfDate,
                               PlanTypeID      = PT.PlanTypeID,
                               GroupID         = SEP.GroupID,
                               EffectiveDate   = SEP.EffectiveDate,
                               TerminationDate = SEP.TerminationDate,
                               Status          = SEP.Status,
                               ChangeDate      = SEP.ChangeDate,
                               Active          = 1,
                               EnrollmentID    = SEP.AlternateEnrollmentID -- Is this correct, or should be part of the match criteria?
    FROM EligibilityPlan EP
    INNER JOIN Staging_EligibilityPlan SEP ON SEP.BatchNumber   = @batch
    INNER JOIN Staging_Eligibility      SE ON SE.MembershipID   = SEP.AlternateID     AND SE.MemberSORGID = SEP.AlternateSORGID
    INNER JOIN Eligibility               E ON E.MembershipID    = SEP.AlternateID     AND  E.MemberSORGID = SEP.AlternateSORGID
    INNER JOIN PlanType                 PT ON PT.Description    = SEP.PlanType
    WHERE EP.EligibilityID = E.EligibilityID AND EP.PlanID = SEP.PlanID
       
exec usp_Staging_PerfmonEnd @batch, 'EligPlanUpdate', @@ROWCOUNT

     -- Insert new Plan information
exec usp_Staging_PerfmonStart @batch, 'EligPlanInsert', ' EligibilityPlan records inserted'
     INSERT EligibilityPlan 
     SELECT E.EligibilityID,
           SEP.AsOfDate,
           PT.PlanTypeID,
           SEP.PlanID,
           SEP.GroupID,
           SEP.EffectiveDate,
           SEP.TerminationDate,
           SEP.Status,
           SEP.ChangeDate,
           1 as Active,
           ENRL.EnrollmentID AS EnrollmentID,
           SEP.AlternateEnrollmentID
     FROM Staging_EligibilityPlan SEP
     INNER JOIN Eligibility    E ON E.MembershipID             = SEP.AlternateID AND E.MemberSORGID = SEP.AlternateSORGID -- find corresponding Eligiblity record
     INNER JOIN PlanType      PT ON PT.Description             = SEP.PlanType
LEFT OUTER JOIN Enrollment  ENRL ON ENRL.AlternateEnrollmentID = SEP.AlternateEnrollmentID
     WHERE SEP.BatchNumber = @batch AND
           -- ensure that this Plan for this Member does not already exist
           not exists(select * from EligibilityPlan where EligibilityID = E.EligibilityID AND PlanID = SEP.PlanID)
exec usp_Staging_PerfmonEnd @batch, 'EligPlanInsert', @@ROWCOUNT

    -- 
    -- Update the EligibilityPCP information
    -- The PK into this table is:
    --
    --   EligibilityID | PlanID | PCPID
    --
exec usp_Staging_PerfmonStart @batch, 'EligPCPUpdate', ' EligibilityPCP records updated'
     UPDATE EligibilityPCP SET AsOfDate        = SEPCP.AsOfDate,
                               PCPID           = P.ProviderID,
                               PCPTypeID       = PST.ProviderServiceTypeID,
                               EffectiveDate   = SEPCP.EffectiveDate,
                               TerminationDate = SEPCP.TerminationDate,
                               Status          = (CASE WHEN SEPCP.Status is null THEN 'A' ELSE SEPCP.Status END),
                               ChangeDate      = SEPCP.ChangeDate,
                               PCPSpecialtyID  = SP.SpecialtyID,
                               PCPLocationID   = L.LocationID,
                               PlanID          = PL.PlanID
     FROM EligibilityPCP EPCP, Staging_EligibilityPCP SEPCP
     INNER JOIN Staging_Eligibility  SE ON SE.MembershipID    = SEPCP.AlternateID     AND SE.MemberSORGID = SEPCP.AlternateSORGID
     INNER JOIN Eligibility           E ON E.MembershipID     = SEPCP.AlternateSORGID AND E.MemberSORGID  = SEPCP.AlternateSORGID
     INNER JOIN Provider              P ON P.AlternateID      = SEPCP.PCP
     INNER JOIN [dbo].[Plan]         PL ON PL.AlternatePlanID = SEPCP.AlternatePlanID AND SEPCP.AlternatePlanID is not null
LEFT OUTER JOIN ProviderServiceType PST ON PST.Code           = SEPCP.PCPType
LEFT OUTER JOIN Specialty            SP ON  SP.Code           = SEPCP.PCPSpecialty
LEFT OUTER JOIN Location              L ON   L.AlternateID    = SEPCP.PCPLocation
     WHERE EPCP.EligibilityID = E.EligibilityID AND SEPCP.BatchNumber = @batch
exec usp_Staging_PerfmonEnd @batch, 'EligPCPUpdate', @@ROWCOUNT

    -- Now insert the new PCP records
    -- Insert new Plan information
exec usp_Staging_PerfmonStart @batch, 'EligPCPInsert', ' EligibilityPCP records inserted'
     INSERT EligibilityPCP 
     SELECT E.EligibilityID,
           SEPCP.AsOfDate,
           P.ProviderID,
           PST.ProviderServiceTypeID,
           SEPCP.EffectiveDate,
           SEPCP.TerminationDate,
           (CASE WHEN SEPCP.Status is null THEN 'A' ELSE SEPCP.Status END),
           SEPCP.ChangeDate,
           SP.SpecialtyID,
           L.LocationID,
           PL.PlanID as PlanID
     FROM Staging_EligibilityPCP SEPCP
     INNER JOIN Eligibility           E ON E.MembershipID     = SEPCP.AlternateID AND E.MemberSORGID = SEPCP.AlternateSORGID -- find corresponding Eligiblity record
     INNER JOIN Provider              P ON P.AlternateID      = SEPCP.PCP                                                    -- match up to the Provider.ProviderID
     INNER JOIN [dbo].[Plan]         PL ON PL.AlternatePlanID = SEPCP.AlternatePlanID AND SEPCP.AlternatePlanID is not null
LEFT OUTER JOIN ProviderServiceType PST ON PST.Code           = SEPCP.PCPType
LEFT OUTER JOIN Specialty            SP ON  SP.Code           = SEPCP.PCPSpecialty
LEFT OUTER JOIN Location              L ON   L.AlternateID    = SEPCP.PCPLocation
     WHERE SEPCP.BatchNumber = @batch AND
               -- ensure that this PCP for this Member does not already exist
               not exists(select PCPID from EligibilityPCP where PCPID = P.ProviderID AND EligibilityID = E.EligibilityID AND PlanID = PL.PlanID)
exec usp_Staging_PerfmonEnd @batch, 'EligPCPInsert', @@ROWCOUNT

    -- We are done moving data into our system tables. Now we need to
    -- update coverage information in the system (i.e. PatientCoverage, PatientCoverageData, PatientSubscriberLog)
    -- that references eligibility information.
    
    -- =====================================================================
    -- Now update Patient/Subscriber demographic and coverage information...
    -- =====================================================================
    exec usp_Staging_ProcessCoverage @batch, @asofdate
END
go

--
-- Need to create some records
--
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser

declare @plantypeid int
if not exists(select * from PlanType where Description = 'UNKNOWN')
begin
    select @plantypeid = max(plantypeid) from Plantype
    if @plantypeid is null
        select @plantypeid = 1
    else
        select @plantypeid = @plantypeid + 1
    insert into PlanType (PlanTypeID, Description, Active, CreatedBy, CreateTime, ReadOnly) VALUES(@plantypeid, 'UNKNOWN', 1, @interfaceUser, getdate(), 1)
end

select @plantypeid = PlanTypeID from PlanType where Description = 'UNKNOWN'

declare @addressid int

if not exists(select * from [dbo].[Plan] where AlternatePlanID = 'PLANA')
begin
insert into Address (Line1, City, State, Zip) VALUES('74 Baltusrol Road', 'Far Hills', 'NJ', '07941')
select @addressid = @@IDENTITY

insert into [dbo].[Plan] (AlternatePlanID, 
                  EffectiveDate, 
                  TerminationDate, 
                  URWhenOtherInsIsPrimary,
                  CMWhenOtherInsIsPrimary,
                  URWhenMedicareIsPrimary,
                  CMWhenMedicareIsPrimary,
                  EAPreferral,
                  NormalDeny,
                  CallBeforeDeny,
                  CallBeforeLetter,
                  CallForLatePreCert,
                  CreatedBy,
                  CreateTime,
                  AddressID,
                  PlanTypeID,
                  HEDISPayorTypeID)
VALUES('PLANA', '11/1/2003', null, 1,1,1,1,1,1,1,1,1, @interfaceUser, getdate(), @addressid, @plantypeid, null)
END

if not exists(select * from [dbo].[Plan] where ALternatePlanID = 'PLANB')
BEGIN
insert into Address (Line1, City, State, Zip) VALUES('45	Kingman Road', 'South Orange', 'NJ', '07079')
select @addressid = @@IDENTITY

insert into [dbo].[Plan] (AlternatePlanID, 
                  EffectiveDate, 
                  TerminationDate, 
                  URWhenOtherInsIsPrimary,
                  CMWhenOtherInsIsPrimary,
                  URWhenMedicareIsPrimary,
                  CMWhenMedicareIsPrimary,
                  EAPreferral,
                  NormalDeny,
                  CallBeforeDeny,
                  CallBeforeLetter,
                  CallForLatePreCert,
                  CreatedBy,
                  CreateTime,
                  AddressID, PlanTypeID, HEDISPayorTypeID)
VALUES('PLANB', '11/1/2003', null, 1,1,1,1,1,1,1,1,1, @interfaceUser, getdate(), @addressid, @plantypeid, null)
END

if not exists(select * from [dbo].[Plan] where ALternatePlanID = 'FEP PPO')
BEGIN
insert into Address (Line1, City, State, Zip) VALUES('14120 Newbrook Avenue', 'Chantilly', 'VA', '07079')
select @addressid = @@IDENTITY

insert into [dbo].[Plan] (AlternatePlanID, 
                  EffectiveDate, 
                  TerminationDate, 
                  URWhenOtherInsIsPrimary,
                  CMWhenOtherInsIsPrimary,
                  URWhenMedicareIsPrimary,
                  CMWhenMedicareIsPrimary,
                  EAPreferral,
                  NormalDeny,
                  CallBeforeDeny,
                  CallBeforeLetter,
                  CallForLatePreCert,
                  CreatedBy,
                  CreateTime,
                  AddressID, PlanTypeID, HEDISPayorTypeID)
VALUES('FEP PPO', '11/1/2003', null, 1,1,1,1,1,1,1,1,1, @interfaceUser, getdate(), @addressid, @plantypeid, null)
END

--
-- We need to seed the provider table
--
if not exists(select * from Specialty where Code = 'FP')
    insert into Specialty (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('FP', 'Family Practice', 1, 1, @interfaceUser, getdate())
if not exists(select * from Specialty where Code = 'IM')
    insert into Specialty (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('IM', 'Internal Medicine', 1, 1, @interfaceUser, getdate())
if not exists(select * from Specialty where Code = 'OBG')
    insert into Specialty (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('OBG', 'Obstetrican/ Gynecological', 1, 1, @interfaceUser, getdate())
if not exists(select * from Specialty where Code = 'PED')
    insert into Specialty (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('PED', 'Pediatrician', 1, 1, @interfaceUser, getdate())

--
-- Create necessary Provider's
--
if not exists(select * from Provider where alternateid = 'CE1002')
    insert into Provider (AlternateID, Firstname, Lastname) VALUES('CE1002', 'Sample Firstname', 'Sample Lastname')
if not exists(select * from Provider where alternateid = 'KD4001')
    insert into Provider (AlternateID, Firstname, Lastname) VALUES('KD4001', 'Sample Firstname', 'Sample Lastname')
if not exists(select * from Provider where alternateid = 'KD4002')
    insert into Provider (AlternateID, Firstname, Lastname) VALUES('KD4002', 'Sample Firstname', 'Sample Lastname')
if not exists(select * from Provider where alternateid = 'KD4003')
    insert into Provider (AlternateID, Firstname, Lastname) VALUES('KD4003', 'Sample Firstname', 'Sample Lastname')
if not exists(select * from Provider where alternateid = 'KD4005')
    insert into Provider (AlternateID, Firstname, Lastname) VALUES('KD4005', 'Sample Firstname', 'Sample Lastname')
if not exists(select * from Provider where alternateid = 'SW1001')
    insert into Provider (AlternateID, Firstname, Lastname) VALUES('SW1001', 'Sample Firstname', 'Sample Lastname')
if not exists(select * from Provider where alternateid = 'SW1002')
    insert into Provider (AlternateID, Firstname, Lastname) VALUES('SW1002', 'Sample Firstname', 'Sample Lastname')
if not exists(select * from Provider where alternateid = 'SW4004')
    insert into Provider (AlternateID, Firstname, Lastname) VALUES('SW4004', 'Sample Firstname', 'Sample Lastname')

-- Create organizations we need for some eligibility import
if not exists(select * from Organization where AlternateID = 'ANTHEM FEP')
begin
    declare @MORGlevelid int
    select @MORGlevelid = OrganizationLevelID from OrganizationLevel where Code = 'MORG'
    declare @morgaddressid int
    insert into Address (Line1, City, State) VALUES('14120 Newbrook Drive', 'Chantilly', 'VA')
    select @morgaddressid = @@IDENTITY
    insert into Organization (OrganizationLevelID, Name, AlternateID, EffectiveDate, OrganizationTypeID, AddressID, ParentOrganizationID)
        VALUES(@MORGlevelid, 'Anthem FEP', 'ANTHEM FEP', '1/1/2000', 1, @morgaddressid, null)
end

if not exists(select * from Organization where AlternateID = 'ANTHEM-FEP SOUT')
begin
    declare @MORGid int
    select @MORGid = OrganizationID from Organization where AlternateID = 'ANTHEM FEP'
    declare @ORGlevelid int
    select @ORGlevelid = OrganizationLevelID from OrganizationLevel where Code = 'ORG'
    declare @orgaddressid int
    insert into Address (Line1, City, State) VALUES('14120 Newbrook Drive', 'Chantilly', 'VA')
    select @orgaddressid = @@IDENTITY
    insert into Organization (OrganizationLevelID, Name, AlternateID, EffectiveDate, OrganizationTypeID, AddressID, ParentOrganizationID)
        VALUES(@ORGlevelid, 'Anthem FEP South', 'ANTHEM-FEP SOUT', '1/1/2000', 1, @orgaddressid, @MORGid)
end

if not exists(select * from Organization where AlternateID = 'ANTHEM-FEP VA')
begin
    declare @orgid int
    select @orgid = OrganizationID from Organization where AlternateID = 'ANTHEM-FEP SOUT'
    declare @sorgaddressid int
    insert into Address (Line1, City, State) VALUES('14120 Newbrook Drive', 'Chantilly', 'VA')
    select @sorgaddressid = @@IDENTITY
    insert into Organization (OrganizationLevelID, Name, AlternateID, EffectiveDate, OrganizationTypeID, AddressID, ParentOrganizationID)
        VALUES(3, 'Anthem FEP South', 'ANTHEM-FEP VA', '1/1/2000', 1, @sorgaddressid, @orgid)
end
go

-- ===================================================================
-- We need to make sure we have some information seeded in the system.
-- ===================================================================

-- Create SORG for Elig_Sample.EDI file
-- First the Master Organization
if not exists(select * from Organization where AlternateID = 'BIKE-VA-MORG')
begin
    declare @morgaddressid int
    insert into Address (Line1, City, State) VALUES('14120 Bicycle Lane', 'Chantilly', 'VA')
    select @morgaddressid = @@IDENTITY
    insert into Organization (OrganizationLevelID, Name, AlternateID, EffectiveDate, OrganizationTypeID, AddressID, ParentOrganizationID)
        VALUES(1, 'Virginia Bikes', 'BIKE-VA-MORG', '1/1/2000', 1, @morgaddressid, null)
end
go

-- Now the organization
if not exists(select * from Organization where AlternateID = 'BIKE-VA-ORG')
begin
    declare @morgid int
    select @morgid = organizationid from Organization where AlternateID = 'BIKE-VA-MORG'
    declare @orgaddressid int
    insert into Address (Line1, City, State) VALUES('14120 Bicycle Lane', 'Chantilly', 'VA')
    select @orgaddressid = @@IDENTITY
    insert into Organization (OrganizationLevelID, Name, AlternateID, EffectiveDate, OrganizationTypeID, AddressID, ParentOrganizationID)
        VALUES(2, 'Virginia Bikes', 'BIKE-VA-ORG', '1/1/2000', 1, @orgaddressid, @morgid)
end
go

if not exists(select * from Organization where AlternateID = 'BIKE-VA')
begin
    declare @orgid int
    select @orgid = OrganizationID from Organization where AlternateID = 'BIKE-VA-ORG'
    declare @sorgaddressid int
    insert into Address (Line1, City, State) VALUES('14120 Bicycle Lane', 'Chantilly', 'VA')
    select @sorgaddressid = @@IDENTITY
    insert into Organization (OrganizationLevelID, Name, AlternateID, EffectiveDate, OrganizationTypeID, AddressID, ParentOrganizationID)
        VALUES(3, 'Virginia Bikes', 'BIKE-VA', '1/1/2000', 1, @sorgaddressid, @orgid)
end
go
--
-- Create some indices to speed things up
--

CREATE INDEX IX_Staging_Eligibility_MembershipID ON Staging_Eligibility(MembershipID)
CREATE INDEX IX_Staging_Eligibility_MemberSORGID ON Staging_Eligibility(MemberSORGID)

CREATE INDEX IX_Staging_EligibilityPlan_AlternateSORGID ON Staging_EligibilityPlan(AlternateSORGID)
CREATE INDEX IX_Staging_EligibilityPlan_AlternateID     ON Staging_EligibilityPlan(AlternateID)

CREATE INDEX IX_Staging_EligibilityPCP_AlternateSORGID ON Staging_EligibilityPCP(AlternateSORGID)
CREATE INDEX IX_Staging_EligibilityPCP_AlternateID     ON Staging_EligibilityPCP(AlternateID)
CREATE INDEX IX_Staging_EligibilityPCP_PCP             ON Staging_EligibilityPCP(PCP)
CREATE INDEX IX_Staging_EligibilityPCP_PCPType         ON Staging_EligibilityPCP(PCPType)

if not exists(select * from sysindexes where name = 'IX_Provider_AlternateID')
    CREATE INDEX IX_Provider_AlternateID               ON Provider(AlternateID)
if not exists(select * from sysindexes where name = 'IX_Plan_AlternatePlanID')
    CREATE INDEX IX_Plan_AlternatePlanID               ON [dbo].[Plan](AlternatePlanID)
if not exists(select * from sysindexes where name = 'IX_Plan_PlanTypeID')
    CREATE INDEX IX_Plan_PlanTypeID                    ON [dbo].[Plan](PlanTypeID)
if not exists(select * from sysindexes where name = 'IX_Specialty_Code')
    CREATE INDEX IX_Specialty_Code                     ON Specialty(Code)

-- some indices for the eligibility tables...
if not exists(select * from sysindexes where name = 'IX_EligibilityPCP_EligibilityID')
    CREATE INDEX IX_EligibilityPCP_EligibilityID      ON EligibilityPCP(EligibilityID)
if not exists(select * from sysindexes where name = 'IX_EligibilityPlan_EligibilityID')
    CREATE INDEX IX_EligibilityPlan_EligibilityID     ON EligibilityPlan(EligibilityID)
if not exists(select * from sysindexes where name = 'IX_Eligibility_MembershipID')
    CREATE INDEX IX_Eligibility_MembershipID          ON Eligibility(MembershipID)
if not exists(select * from sysindexes where name = 'IX_Eligibility_AlternateSubscriberID')
    CREATE INDEX IX_Eligibility_AlternateSubscriberID ON Eligibility(AlternateSubscriberID)
if not exists(select * from sysindexes where name = 'IX_Eligibility_MemberSORGID')
    CREATE INDEX IX_Eligibility_MemberSORGID          ON Eligibility(MemberSORGID)
