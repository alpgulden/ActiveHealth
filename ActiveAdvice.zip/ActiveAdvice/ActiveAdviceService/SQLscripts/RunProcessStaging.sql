use activeadvice
go
declare @batch uniqueidentifier
select distinct @batch = batchnumber from fileheader_staging where filetype = 'PRV'
print '@batch = ' + convert(varchar(48), @batch)

exec usp_Staging_ProcessStaging @batch
