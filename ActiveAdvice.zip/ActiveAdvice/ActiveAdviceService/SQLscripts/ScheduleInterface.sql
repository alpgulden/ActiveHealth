--
-- ScheduleInterface.SQL
-- =====================
--
use ActiveAdvice
go

--
-- usp_Staging_GetInterfaceUser
-- ============================
--
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Staging_GetInterfaceUser]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure usp_Staging_GetInterfaceUser
GO
CREATE PROCEDURE usp_Staging_GetInterfaceUser
AS
BEGIN
    -- Step #3. Get the "INTERFACE_USER"
    if not exists(select * from AAUser where LoginName = 'INTERFACE_USER')
        insert into AAUser (LoginName, Password, CreatedBy, Status, FailedLogins) VALUES('INTERFACE_USER', 'interface', 1,1,0)

    declare @interfaceUser int
    select @interfaceUser = UserId from AAUser where LoginName = 'INTERFACE_USER'

    return @interfaceUser
END
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ScheduleType]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    drop table ScheduleType
CREATE TABLE ScheduleType(
    ScheduleTypeID int IDENTITY(1,1) PRIMARY KEY,
    
    Code        varchar(4)     NOT NULL,
    Description varchar(64)    NOT NULL,
    Active      bit default(1) NOT NULL,
    ReadOnly    bit default(0) NOT NULL,
    
    CreatedBy   int NOT NULL CONSTRAINT FK_AAUser_ScheduleType_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES AAUser(UserID),
    CreateTime  datetime default(getdate()) NOT NULL,
    ModifiedBy  int NULL CONSTRAINT FK_AAUser_ScheduleType_ModifiedBy FOREIGN KEY (CreatedBy) REFERENCES AAUser(UserID),
    ModifyTime  datetime NULL
)
go

-- Create our code table entries
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('CMD',  'NT Shell script command',       1, 1, @interfaceUser, getdate())  
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('ICM',  'ICM Scoring Load',              1, 1, @interfaceUser, getdate())  
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('ELIG', 'Eligibility import',            1, 1, @interfaceUser, getdate())  
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('PROV', 'Provider import',               1, 1, @interfaceUser, getdate())
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('AUTH', 'Authorization export',          1, 1, @interfaceUser, getdate())
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('MLOG', 'Active Advice Membership Log',  1, 1, @interfaceUser, getdate())
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('CENG', 'Care Engine export',            1, 1, @interfaceUser, getdate())
INSERT ScheduleType (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('MEMB', 'Membership file export',        1, 1, @interfaceUser, getdate())
go

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ScheduleStatus]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    drop table ScheduleStatus
CREATE TABLE ScheduleStatus(
    ScheduleStatusID int IDENTITY(1,1) PRIMARY KEY,
    
    Code        varchar(4)     NOT NULL,
    Description varchar(64)    NOT NULL,
    Active      bit default(1) NOT NULL,
    ReadOnly    bit default(0) NOT NULL,
    
    CreatedBy   int NOT NULL CONSTRAINT FK_AAUser_ScheduleStatus_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES AAUser(UserID),
    CreateTime  datetime default(getdate()) NOT NULL,
    ModifiedBy  int NULL CONSTRAINT FK_AAUser_ScheduleStatus_ModifiedBy FOREIGN KEY (CreatedBy) REFERENCES AAUser(UserID),
    ModifyTime  datetime NULL
)
go
-- Create our code table entries
declare @interfaceUser int
exec @interfaceUser = usp_Staging_GetInterfaceUser
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('CANC', 'Canceled',   1, 1, @interfaceUser, getdate())  -- canceled by the User
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('PEND', 'Pending',    1, 1, @interfaceUser, getdate())  -- ready to run
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('RUN',  'Running',    1, 1, @interfaceUser, getdate())  -- running
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('DONE', 'Completed',  1, 1, @interfaceUser, getdate())  -- completed, check error log for issues
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('FAIL', 'Failed',     1, 1, @interfaceUser, getdate())  -- failed, bad arguments, db error, etc.
INSERT ScheduleStatus (Code, Description, Active, ReadOnly, CreatedBy, CreateTime) VALUES('INVL', 'Invalid',    1, 1, @interfaceUser, getdate())  -- updating arguments, not ready to run
go

--
-- ScheduleTask
-- ============
-- This table contains the tasks that we are pending/running/complete.
--  ScheduleTypeID ..... What we are running, NT command script, ICM load, etc.
--  ScheduleStatusID ... Status of the current task, Pending/Running/Completed/Cancelled
--  Task ............... contains data necessary to execute the task.
--          ScheduleTypeID          Task
--          ==============          ==================================================
--          CMD                     NT command script to execute
--          ICM                     ICM scoring load arguments
--          PROV                    Provider/Group Practice/Network filename to import
--          ELIG                    Eligibility filename to import
--
--
-- The ICM scoring load must encode several variables, then are encoded in the following manner:
--
--      "Filename=c:\\datafiles\icmload_3.txt,MORG=ALL,ORG=Anthem FEP,GenerateEnvelopes=NO,GenerateEmployeeLetters=NO,GenerateLettersOnly=NO,EmployeeLetterID=8235"
--
-- Any arguments not specified are "false". All keywords are case insensitive.
--
-- Developer's Note: The import/export process must periodically check this database table
--                   to determine if the operation has been canceled.
--
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ScheduleTask]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    drop table ScheduleTask
go
CREATE TABLE ScheduleTask(
    JobID            int IDENTITY(1,1) PRIMARY KEY,

    ScheduleTypeID   int NOT NULL CONSTRAINT FK_ScheduleType_ScheduleTask   FOREIGN KEY (ScheduleTypeID)   REFERENCES ScheduleType(ScheduleTypeID),
    ScheduleStatusID int NOT NULL CONSTRAINT FK_ScheduleStatus_ScheduleTask FOREIGN KEY (ScheduleStatusID) REFERENCES ScheduleStatus(ScheduleStatusID),

    ScheduledTime datetime NOT NULL, -- when the schedule should run

    Task          varchar(2000),     -- our task is encoded, see comments...
    Label         varchar(500),      -- descriptive label describing the task
    StartTime     datetime NULL,     -- when the task was started
    EndTime       datetime NULL,     -- when the task ended (success or failure)
    
    -- User information
    CreatedBy     int NOT NULL CONSTRAINT FK_AAUser_ScheduleTask_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES AAUser(UserID), -- who created this schedule
    CreateTime    datetime default(getdate()) NOT NULL,
    TerminatedBy  int NULL CONSTRAINT FK_AAUser_ScheduleTask_TerminatedBy FOREIGN KEY (TerminatedBy) REFERENCES AAUser(UserID), -- who canceled this schedule (if canceled)
    TerminateTime datetime NULL,
)
go

if not exists(select * from sysindexes where name = 'IX_ScheduleTask_ScheduleStatusID')
    CREATE INDEX IX_ScheduleTask_ScheduleStatusID ON ScheduleTask(ScheduleStatusID)
if not exists(select * from sysindexes where name = 'IX_ScheduleTask_ScheduleTypeID')
    CREATE INDEX IX_ScheduleTask_ScheduleTypeID ON ScheduleTask(ScheduleTypeID)
go

-- Here are the types of interfaces we have to process
-- and their input arguments
--
-- ELIGIBILITY [INPUT]
-- ===================
--     1. input file name
--
-- PROVIDER/NETWORK/GROUP PRACTICE [INPUT]
-- =======================================
--     1. input file name
--
-- ICM Scoring Load [INPUT]
-- ========================
--     1. input file name
--     2. Morg & Org selection
--     3. Generate Envelopes (TRUE/FALSE)
--     4. Generate Employee Letters (TRUE/FALSE)
--     5. Generate Letters Only (TRUE/FALSE)
--     6. Employee Letter ID (VALUE)
--
-- Membership file [OUTPUT]
-- ========================
--     1. output file name
--     2. Morg, Org & Sorg
--     3. Start Date
--
-- Care Engine Data [OUTPUT]
-- =========================
--     1. output file name
--     2. start/end date
--     3. Morg, Org & Sorg
--
-- Authorizations [OUTPUT]
-- =======================
--     1. output file name
--     2. Events (TRUE/FALSE) -----|
--     3. Referrals (TRUE/FALSE) --+-- both can be enabled at the same time.
--
