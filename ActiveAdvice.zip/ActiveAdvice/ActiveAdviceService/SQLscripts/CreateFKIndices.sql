--
-- Create Foreign Key Indices
--
-- Used following script to create this file:
--
--  >select 'if not exists(select * from sysindexes where name = ''IX_' + d.name + '_' + fc.name + ''')' + CHAR(13) +
--  >'    CREATE INDEX IX_' + d.name + '_' + fc.name + ' ON ' + d.name + '(' + fc.name + ')' + CHAR(13)
--  >--select d.name, fc.name, c.name 
--  >from sysreferences a 
--  >inner join sysobjects b on a.rkeyid = b.id
--  >inner join sysobjects c on c.id = a.constid
--  >inner join sysobjects d on d.id = a.fkeyid
--  >inner join syscolumns fc on fc.id = a.fkeyid and fc.colid = a.fkey1  -- get the FK table
--  >--inner join sysobjects e on e.id = a.
--  >where OBJECTPROPERTY(b.id, N'IsUserTable') = 1


use ActiveAdvice
go

if not exists(select * from sysindexes where name = 'IX_InsurancePayorContact_InsurancePayorID')
    CREATE INDEX IX_InsurancePayorContact_InsurancePayorID ON InsurancePayorContact(InsurancePayorID)

if not exists(select * from sysindexes where name = 'IX_ProviderServiceType_ModifiedBy')
    CREATE INDEX IX_ProviderServiceType_ModifiedBy ON ProviderServiceType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationNetwork_ModifiedBy')
    CREATE INDEX IX_FacilityLocationNetwork_ModifiedBy ON FacilityLocationNetwork(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_PatientId')
    CREATE INDEX IX_Referral_PatientId ON Referral(PatientId)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_IntakeCallSourceID')
    CREATE INDEX IX_IntakeLog_IntakeCallSourceID ON IntakeLog(IntakeCallSourceID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDescription_CreatedBy')
    CREATE INDEX IX_ClinicalReviewDescription_CreatedBy ON ClinicalReviewDescription(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_SorgID')
    CREATE INDEX IX_LetterPrintedQueue_SorgID ON LetterPrintedQueue(SorgID)

if not exists(select * from sysindexes where name = 'IX_Activity_ActivityTypeID')
    CREATE INDEX IX_Activity_ActivityTypeID ON Activity(ActivityTypeID)

if not exists(select * from sysindexes where name = 'IX_CMSStatusHistory_AssignedUserId')
    CREATE INDEX IX_CMSStatusHistory_AssignedUserId ON CMSStatusHistory(AssignedUserId)

if not exists(select * from sysindexes where name = 'IX_POCGoal_GoalReasonId')
    CREATE INDEX IX_POCGoal_GoalReasonId ON POCGoal(GoalReasonId)

if not exists(select * from sysindexes where name = 'IX_ProblemDescription_ModifiedBy')
    CREATE INDEX IX_ProblemDescription_ModifiedBy ON ProblemDescription(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCBodySubSystem_CreatedBy')
    CREATE INDEX IX_WCBodySubSystem_CreatedBy ON WCBodySubSystem(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianRequest_PhysicianReviewDecisionID')
    CREATE INDEX IX_PhysicianRequest_PhysicianReviewDecisionID ON PhysicianRequest(PhysicianReviewDecisionID)

if not exists(select * from sysindexes where name = 'IX_ActivityBaseUnitOfMeasure_ModifiedBy')
    CREATE INDEX IX_ActivityBaseUnitOfMeasure_ModifiedBy ON ActivityBaseUnitOfMeasure(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_IntakeCallTypeID')
    CREATE INDEX IX_IntakeLog_IntakeCallTypeID ON IntakeLog(IntakeCallTypeID)

if not exists(select * from sysindexes where name = 'IX_Network_TerminatedBy')
    CREATE INDEX IX_Network_TerminatedBy ON Network(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_MorgID')
    CREATE INDEX IX_LetterDraftQueue_MorgID ON LetterDraftQueue(MorgID)

if not exists(select * from sysindexes where name = 'IX_Activity_ActivitySubtypeID')
    CREATE INDEX IX_Activity_ActivitySubtypeID ON Activity(ActivitySubtypeID)

if not exists(select * from sysindexes where name = 'IX_GuidelineProduct_GuidelineSourceSetID')
    CREATE INDEX IX_GuidelineProduct_GuidelineSourceSetID ON GuidelineProduct(GuidelineSourceSetID)

if not exists(select * from sysindexes where name = 'IX_CMSStatusHistory_CreatedBy')
    CREATE INDEX IX_CMSStatusHistory_CreatedBy ON CMSStatusHistory(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PlanContact_ContactID')
    CREATE INDEX IX_PlanContact_ContactID ON PlanContact(ContactID)

if not exists(select * from sysindexes where name = 'IX_Relationship_CreatedBy')
    CREATE INDEX IX_Relationship_CreatedBy ON Relationship(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_WCBodySubSystem_ModifiedBy')
    CREATE INDEX IX_WCBodySubSystem_ModifiedBy ON WCBodySubSystem(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_PhysicianReviewDecisionID')
    CREATE INDEX IX_PhysicianReview_PhysicianReviewDecisionID ON PhysicianReview(PhysicianReviewDecisionID)

if not exists(select * from sysindexes where name = 'IX_ActivityBaseUnitOfMeasure_CreatedBy')
    CREATE INDEX IX_ActivityBaseUnitOfMeasure_CreatedBy ON ActivityBaseUnitOfMeasure(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_IntakeResolutionID')
    CREATE INDEX IX_IntakeLog_IntakeResolutionID ON IntakeLog(IntakeResolutionID)

if not exists(select * from sysindexes where name = 'IX_OrganizationContact_ContactID')
    CREATE INDEX IX_OrganizationContact_ContactID ON OrganizationContact(ContactID)

if not exists(select * from sysindexes where name = 'IX_Network_CreatedBy')
    CREATE INDEX IX_Network_CreatedBy ON Network(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_OrgID')
    CREATE INDEX IX_LetterDraftQueue_OrgID ON LetterDraftQueue(OrgID)

if not exists(select * from sysindexes where name = 'IX_Activity_BaseUOMId')
    CREATE INDEX IX_Activity_BaseUOMId ON Activity(BaseUOMId)

if not exists(select * from sysindexes where name = 'IX_Entity_Staging_PrefixID')
    CREATE INDEX IX_Entity_Staging_PrefixID ON Entity_Staging(PrefixID)

if not exists(select * from sysindexes where name = 'IX_Team_CreatedBy')
    CREATE INDEX IX_Team_CreatedBy ON Team(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Relationship_ModifiedBy')
    CREATE INDEX IX_Relationship_ModifiedBy ON Relationship(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PatientNamePrefixId')
    CREATE INDEX IX_PatientSubscriberLog_PatientNamePrefixId ON PatientSubscriberLog(PatientNamePrefixId)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecisionReason_ModifiedBy')
    CREATE INDEX IX_ClinicalReviewDecisionReason_ModifiedBy ON ClinicalReviewDecisionReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrixField_LetterMatrixTypeID')
    CREATE INDEX IX_LetterMatrixField_LetterMatrixTypeID ON LetterMatrixField(LetterMatrixTypeID)

if not exists(select * from sysindexes where name = 'IX_NetworkPlan_CreatedBy')
    CREATE INDEX IX_NetworkPlan_CreatedBy ON NetworkPlan(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_DRGCode_DRGType')
    CREATE INDEX IX_DRGCode_DRGType ON DRGCode(DRGType)

if not exists(select * from sysindexes where name = 'IX_NetworkContact_ContactID')
    CREATE INDEX IX_NetworkContact_ContactID ON NetworkContact(ContactID)

if not exists(select * from sysindexes where name = 'IX_Network_ModifiedBy')
    CREATE INDEX IX_Network_ModifiedBy ON Network(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_SorgID')
    CREATE INDEX IX_LetterDraftQueue_SorgID ON LetterDraftQueue(SorgID)

if not exists(select * from sysindexes where name = 'IX_Activity_ConversionUOMId')
    CREATE INDEX IX_Activity_ConversionUOMId ON Activity(ConversionUOMId)

if not exists(select * from sysindexes where name = 'IX_Team_CreatedBy')
    CREATE INDEX IX_Team_CreatedBy ON Team(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientMeasurement_CreatedBy')
    CREATE INDEX IX_PatientMeasurement_CreatedBy ON PatientMeasurement(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecisionReason_CreatedBy')
    CREATE INDEX IX_ClinicalReviewDecisionReason_CreatedBy ON ClinicalReviewDecisionReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_NetworkPlan_ModifiedBy')
    CREATE INDEX IX_NetworkPlan_ModifiedBy ON NetworkPlan(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_DRG_Type')
    CREATE INDEX IX_Referral_DRG_Type ON Referral(DRG_Type)

if not exists(select * from sysindexes where name = 'IX_Questionnaire_CreatedBy')
    CREATE INDEX IX_Questionnaire_CreatedBy ON Questionnaire(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Activity_ActivityCompletionID')
    CREATE INDEX IX_Activity_ActivityCompletionID ON Activity(ActivityCompletionID)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecision_ProviderNetworkID')
    CREATE INDEX IX_PhysicianDecision_ProviderNetworkID ON PhysicianDecision(ProviderNetworkID)

if not exists(select * from sysindexes where name = 'IX_Team_ModifiedBy')
    CREATE INDEX IX_Team_ModifiedBy ON Team(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientMeasurement_ModifiedBy')
    CREATE INDEX IX_PatientMeasurement_ModifiedBy ON PatientMeasurement(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_SubscriberNamePrefixId')
    CREATE INDEX IX_PatientSubscriberLog_SubscriberNamePrefixId ON PatientSubscriberLog(SubscriberNamePrefixId)

if not exists(select * from sysindexes where name = 'IX_SystemStatus_CreatedBy')
    CREATE INDEX IX_SystemStatus_CreatedBy ON SystemStatus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PatientCreatedByUserId')
    CREATE INDEX IX_PatientSubscriberLog_PatientCreatedByUserId ON PatientSubscriberLog(PatientCreatedByUserId)

if not exists(select * from sysindexes where name = 'IX_Event_DrgType')
    CREATE INDEX IX_Event_DrgType ON Event(DrgType)

if not exists(select * from sysindexes where name = 'IX_ProviderLocation_ProviderID')
    CREATE INDEX IX_ProviderLocation_ProviderID ON ProviderLocation(ProviderID)

if not exists(select * from sysindexes where name = 'IX_Questionnaire_ModifiedBy')
    CREATE INDEX IX_Questionnaire_ModifiedBy ON Questionnaire(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_DSM4Keyword_DSM4Code')
    CREATE INDEX IX_DSM4Keyword_DSM4Code ON DSM4Keyword(DSM4Code)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationServiceType_ModifiedBy')
    CREATE INDEX IX_FacilityLocationServiceType_ModifiedBy ON FacilityLocationServiceType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionnairePresentationGroupOrder_CreatedBy')
    CREATE INDEX IX_QuestionnairePresentationGroupOrder_CreatedBy ON QuestionnairePresentationGroupOrder(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_SystemStatus_ModifiedBy')
    CREATE INDEX IX_SystemStatus_ModifiedBy ON SystemStatus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_SubscriberCreatedByUserId')
    CREATE INDEX IX_PatientSubscriberLog_SubscriberCreatedByUserId ON PatientSubscriberLog(SubscriberCreatedByUserId)

if not exists(select * from sysindexes where name = 'IX_DRGCode_MDC')
    CREATE INDEX IX_DRGCode_MDC ON DRGCode(MDC)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationService_ProviderLocationID')
    CREATE INDEX IX_ProviderLocationService_ProviderLocationID ON ProviderLocationService(ProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_Activity_ModifiedBy')
    CREATE INDEX IX_Activity_ModifiedBy ON Activity(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_PatientID')
    CREATE INDEX IX_LetterNonPrintedQueue_PatientID ON LetterNonPrintedQueue(PatientID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecisionType_ClinicalReviewDecisionTypeCodeID')
    CREATE INDEX IX_ClinicalReviewDecisionType_ClinicalReviewDecisionTypeCodeID ON ClinicalReviewDecisionType(ClinicalReviewDecisionTypeCodeID)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecision_PhysicianRequestID')
    CREATE INDEX IX_PhysicianDecision_PhysicianRequestID ON PhysicianDecision(PhysicianRequestID)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationServiceType_CreatedBy')
    CREATE INDEX IX_FacilityLocationServiceType_CreatedBy ON FacilityLocationServiceType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocation_TerminatedBy')
    CREATE INDEX IX_GroupPracticeLocation_TerminatedBy ON GroupPracticeLocation(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_PatientId')
    CREATE INDEX IX_Event_PatientId ON Event(PatientId)

if not exists(select * from sysindexes where name = 'IX_Maternichek_CreatedBy')
    CREATE INDEX IX_Maternichek_CreatedBy ON Maternichek(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_MeasurementLevelOfDisease_LevelOfDiseaseTypeID')
    CREATE INDEX IX_MeasurementLevelOfDisease_LevelOfDiseaseTypeID ON MeasurementLevelOfDisease(LevelOfDiseaseTypeID)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PatientModifiedByUserId')
    CREATE INDEX IX_PatientSubscriberLog_PatientModifiedByUserId ON PatientSubscriberLog(PatientModifiedByUserId)

if not exists(select * from sysindexes where name = 'IX_Event_ProviderGroupID')
    CREATE INDEX IX_Event_ProviderGroupID ON Event(ProviderGroupID)

if not exists(select * from sysindexes where name = 'IX_DRGCode_DRGserviceclass')
    CREATE INDEX IX_DRGCode_DRGserviceclass ON DRGCode(DRGserviceclass)

if not exists(select * from sysindexes where name = 'IX_Activity_CreatedBy')
    CREATE INDEX IX_Activity_CreatedBy ON Activity(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_PatientID')
    CREATE INDEX IX_LetterPrintedQueue_PatientID ON LetterPrintedQueue(PatientID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_ClinicalReviewDecisionTypeID')
    CREATE INDEX IX_ClinicalReviewDecision_ClinicalReviewDecisionTypeID ON ClinicalReviewDecision(ClinicalReviewDecisionTypeID)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecision_ProviderLocationID')
    CREATE INDEX IX_PhysicianDecision_ProviderLocationID ON PhysicianDecision(ProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_Facility_CreatedBy')
    CREATE INDEX IX_Facility_CreatedBy ON Facility(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocation_CreatedBy')
    CREATE INDEX IX_GroupPracticeLocation_CreatedBy ON GroupPracticeLocation(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Maternichek_ModifiedBy')
    CREATE INDEX IX_Maternichek_ModifiedBy ON Maternichek(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_SubscriberModifiedByUserId')
    CREATE INDEX IX_PatientSubscriberLog_SubscriberModifiedByUserId ON PatientSubscriberLog(SubscriberModifiedByUserId)

if not exists(select * from sysindexes where name = 'IX_Event_ProviderGroupTypeID')
    CREATE INDEX IX_Event_ProviderGroupTypeID ON Event(ProviderGroupTypeID)

if not exists(select * from sysindexes where name = 'IX_PlanSORG_DRGType')
    CREATE INDEX IX_PlanSORG_DRGType ON PlanSORG(DRGType)

if not exists(select * from sysindexes where name = 'IX_Activity_CompletedByUserID')
    CREATE INDEX IX_Activity_CompletedByUserID ON Activity(CompletedByUserID)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_PatientID')
    CREATE INDEX IX_LetterDraftQueue_PatientID ON LetterDraftQueue(PatientID)

if not exists(select * from sysindexes where name = 'IX_ActivityTypeSubType_ActivityTypeId')
    CREATE INDEX IX_ActivityTypeSubType_ActivityTypeId ON ActivityTypeSubType(ActivityTypeId)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_ClinicalReviewDecisionTypeID')
    CREATE INDEX IX_LetterMatrix_ClinicalReviewDecisionTypeID ON LetterMatrix(ClinicalReviewDecisionTypeID)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecision_ProviderID')
    CREATE INDEX IX_PhysicianDecision_ProviderID ON PhysicianDecision(ProviderID)

if not exists(select * from sysindexes where name = 'IX_Facility_ModifiedBy')
    CREATE INDEX IX_Facility_ModifiedBy ON Facility(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocation_ModifiedBy')
    CREATE INDEX IX_GroupPracticeLocation_ModifiedBy ON GroupPracticeLocation(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Location_StatusChangedBy')
    CREATE INDEX IX_Location_StatusChangedBy ON Location(StatusChangedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PatientAssignedUserId')
    CREATE INDEX IX_PatientSubscriberLog_PatientAssignedUserId ON PatientSubscriberLog(PatientAssignedUserId)

if not exists(select * from sysindexes where name = 'IX_Event_ProviderGroupLocationID')
    CREATE INDEX IX_Event_ProviderGroupLocationID ON Event(ProviderGroupLocationID)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationContact_ProviderLocationID')
    CREATE INDEX IX_ProviderLocationContact_ProviderLocationID ON ProviderLocationContact(ProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_Activity_AssignedtoUser')
    CREATE INDEX IX_Activity_AssignedtoUser ON Activity(AssignedtoUser)

if not exists(select * from sysindexes where name = 'IX_ActivityTypeSubType_ActivitySubTypeId')
    CREATE INDEX IX_ActivityTypeSubType_ActivitySubTypeId ON ActivityTypeSubType(ActivitySubTypeId)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_ClinicalReviewDecisionID')
    CREATE INDEX IX_PhysicianReview_ClinicalReviewDecisionID ON PhysicianReview(ClinicalReviewDecisionID)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecision_ProviderSpecialtyID')
    CREATE INDEX IX_PhysicianDecision_ProviderSpecialtyID ON PhysicianDecision(ProviderSpecialtyID)

if not exists(select * from sysindexes where name = 'IX_Facility_StatusChangedBy')
    CREATE INDEX IX_Facility_StatusChangedBy ON Facility(StatusChangedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceItem_BaseUnitOfMeasureId')
    CREATE INDEX IX_ManagementServiceItem_BaseUnitOfMeasureId ON ManagementServiceItem(BaseUnitOfMeasureId)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecisionRole_CreatedBy')
    CREATE INDEX IX_PhysicianDecisionRole_CreatedBy ON PhysicianDecisionRole(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Location_CreatedBy')
    CREATE INDEX IX_Location_CreatedBy ON Location(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_SubscriberAssignedUserId')
    CREATE INDEX IX_PatientSubscriberLog_SubscriberAssignedUserId ON PatientSubscriberLog(SubscriberAssignedUserId)

if not exists(select * from sysindexes where name = 'IX_Event_ProviderGroupNetworkID')
    CREATE INDEX IX_Event_ProviderGroupNetworkID ON Event(ProviderGroupNetworkID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewUnit_ModifiedBy')
    CREATE INDEX IX_ClinicalReviewUnit_ModifiedBy ON ClinicalReviewUnit(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_EventSource_UB92Source')
    CREATE INDEX IX_EventSource_UB92Source ON EventSource(UB92Source)

if not exists(select * from sysindexes where name = 'IX_Outcome_Type')
    CREATE INDEX IX_Outcome_Type ON Outcome(Type)

if not exists(select * from sysindexes where name = 'IX_Logic_CreatedBy')
    CREATE INDEX IX_Logic_CreatedBy ON Logic(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecisionRole_ModifiedBy')
    CREATE INDEX IX_PhysicianDecisionRole_ModifiedBy ON PhysicianDecisionRole(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Location_ModifiedBy')
    CREATE INDEX IX_Location_ModifiedBy ON Location(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeCallReason_CreatedBy')
    CREATE INDEX IX_IntakeCallReason_CreatedBy ON IntakeCallReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_PCPLocationID')
    CREATE INDEX IX_Event_PCPLocationID ON Event(PCPLocationID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewUnit_CreatedBy')
    CREATE INDEX IX_ClinicalReviewUnit_CreatedBy ON ClinicalReviewUnit(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Logic_ModifiedBy')
    CREATE INDEX IX_Logic_ModifiedBy ON Logic(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCInjuryData_CreatedBy')
    CREATE INDEX IX_WCInjuryData_CreatedBy ON WCInjuryData(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_State_ModifiedBy')
    CREATE INDEX IX_State_ModifiedBy ON State(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeCallReason_ModifiedBy')
    CREATE INDEX IX_IntakeCallReason_ModifiedBy ON IntakeCallReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Event_RefProviderID')
    CREATE INDEX IX_Event_RefProviderID ON Event(RefProviderID)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireTrigger_ContentOwnerID')
    CREATE INDEX IX_QuestionnaireTrigger_ContentOwnerID ON QuestionnaireTrigger(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupProcedureLevel_CreatedBy')
    CREATE INDEX IX_SecurityGroupProcedureLevel_CreatedBy ON SecurityGroupProcedureLevel(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeProvider_GroupPracticeID')
    CREATE INDEX IX_GroupPracticeProvider_GroupPracticeID ON GroupPracticeProvider(GroupPracticeID)

if not exists(select * from sysindexes where name = 'IX_GuidelineSourceSet_CreatedBy')
    CREATE INDEX IX_GuidelineSourceSet_CreatedBy ON GuidelineSourceSet(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_WCInjuryData_ModifiedBy')
    CREATE INDEX IX_WCInjuryData_ModifiedBy ON WCInjuryData(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PatientAssignedTeamId')
    CREATE INDEX IX_PatientSubscriberLog_PatientAssignedTeamId ON PatientSubscriberLog(PatientAssignedTeamId)

if not exists(select * from sysindexes where name = 'IX_State_CreatedBy')
    CREATE INDEX IX_State_CreatedBy ON State(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_MedicationStatus_CreatedBy')
    CREATE INDEX IX_MedicationStatus_CreatedBy ON MedicationStatus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_RefProviderNetworkID')
    CREATE INDEX IX_Event_RefProviderNetworkID ON Event(RefProviderNetworkID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupProcedureLevel_ModifiedBy')
    CREATE INDEX IX_SecurityGroupProcedureLevel_ModifiedBy ON SecurityGroupProcedureLevel(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_GuidelineSourceSet_ModifiedBy')
    CREATE INDEX IX_GuidelineSourceSet_ModifiedBy ON GuidelineSourceSet(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_BenefitServiceItem_BenefitServiceTypeId')
    CREATE INDEX IX_BenefitServiceItem_BenefitServiceTypeId ON BenefitServiceItem(BenefitServiceTypeId)

if not exists(select * from sysindexes where name = 'IX_POCInterventionStatus_CreatedBy')
    CREATE INDEX IX_POCInterventionStatus_CreatedBy ON POCInterventionStatus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_UserDefinedID')
    CREATE INDEX IX_CMS_UserDefinedID ON CMS(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_SubscriberAssignedTeamId')
    CREATE INDEX IX_PatientSubscriberLog_SubscriberAssignedTeamId ON PatientSubscriberLog(SubscriberAssignedTeamId)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewRequest_CreatedBy')
    CREATE INDEX IX_ClinicalReviewRequest_CreatedBy ON ClinicalReviewRequest(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_MedicationStatus_ModifiedBy')
    CREATE INDEX IX_MedicationStatus_ModifiedBy ON MedicationStatus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Event_RefProviderGroupID')
    CREATE INDEX IX_Event_RefProviderGroupID ON Event(RefProviderGroupID)

if not exists(select * from sysindexes where name = 'IX_WebLink_CreatedBy')
    CREATE INDEX IX_WebLink_CreatedBy ON WebLink(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GuidelineSourceSet_CreatedBy')
    CREATE INDEX IX_GuidelineSourceSet_CreatedBy ON GuidelineSourceSet(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_POCInterventionStatus_ModifiedBy')
    CREATE INDEX IX_POCInterventionStatus_ModifiedBy ON POCInterventionStatus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceItem_ManagementServiceId')
    CREATE INDEX IX_ManagementServiceItem_ManagementServiceId ON ManagementServiceItem(ManagementServiceId)

if not exists(select * from sysindexes where name = 'IX_CMS_CaseSourceID')
    CREATE INDEX IX_CMS_CaseSourceID ON CMS(CaseSourceID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewRequest_ModifiedBy')
    CREATE INDEX IX_ClinicalReviewRequest_ModifiedBy ON ClinicalReviewRequest(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AssessmentQuestionnaire_AssessmentGUID')
    CREATE INDEX IX_AssessmentQuestionnaire_AssessmentGUID ON AssessmentQuestionnaire(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_WCInjuryType_ModifiedBy')
    CREATE INDEX IX_WCInjuryType_ModifiedBy ON WCInjuryType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Event_RefProviderGroupLocationID')
    CREATE INDEX IX_Event_RefProviderGroupLocationID ON Event(RefProviderGroupLocationID)

if not exists(select * from sysindexes where name = 'IX_WebLink_ModifiedBy')
    CREATE INDEX IX_WebLink_ModifiedBy ON WebLink(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityFocusType_ModifiedBy')
    CREATE INDEX IX_FacilityFocusType_ModifiedBy ON FacilityFocusType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Response_AssessmentGUID')
    CREATE INDEX IX_Response_AssessmentGUID ON Response(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_UserDefinedFieldPresentationType_CreatedBy')
    CREATE INDEX IX_UserDefinedFieldPresentationType_CreatedBy ON UserDefinedFieldPresentationType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PatientId')
    CREATE INDEX IX_CMS_PatientId ON CMS(PatientId)

if not exists(select * from sysindexes where name = 'IX_Specialty_ModifiedBy')
    CREATE INDEX IX_Specialty_ModifiedBy ON Specialty(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCInjuryType_CreatedBy')
    CREATE INDEX IX_WCInjuryType_CreatedBy ON WCInjuryType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_RefProviderGroupNetworkID')
    CREATE INDEX IX_Event_RefProviderGroupNetworkID ON Event(RefProviderGroupNetworkID)

if not exists(select * from sysindexes where name = 'IX_Activity_EventID')
    CREATE INDEX IX_Activity_EventID ON Activity(EventID)

if not exists(select * from sysindexes where name = 'IX_WebLink_CreatedBy')
    CREATE INDEX IX_WebLink_CreatedBy ON WebLink(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRule_RuleTypeId')
    CREATE INDEX IX_AutoActivityRule_RuleTypeId ON AutoActivityRule(RuleTypeId)

if not exists(select * from sysindexes where name = 'IX_FacilityFocusType_CreatedBy')
    CREATE INDEX IX_FacilityFocusType_CreatedBy ON FacilityFocusType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_InterventionTemplate_POCDeficitTypeID')
    CREATE INDEX IX_InterventionTemplate_POCDeficitTypeID ON InterventionTemplate(POCDeficitTypeID)

if not exists(select * from sysindexes where name = 'IX_UserDefinedFieldPresentationType_ModifiedBy')
    CREATE INDEX IX_UserDefinedFieldPresentationType_ModifiedBy ON UserDefinedFieldPresentationType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Specialty_CreatedBy')
    CREATE INDEX IX_Specialty_CreatedBy ON Specialty(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_POCDeficit_CreatedBy')
    CREATE INDEX IX_POCDeficit_CreatedBy ON POCDeficit(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_ParentEventID')
    CREATE INDEX IX_Event_ParentEventID ON Event(ParentEventID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecisionTypeCode_ModifiedBy')
    CREATE INDEX IX_ClinicalReviewDecisionTypeCode_ModifiedBy ON ClinicalReviewDecisionTypeCode(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianReviewRequestDetailType_CreatedBy')
    CREATE INDEX IX_PhysicianReviewRequestDetailType_CreatedBy ON PhysicianReviewRequestDetailType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_BenefitServiceItem_InNetCoveredId')
    CREATE INDEX IX_BenefitServiceItem_InNetCoveredId ON BenefitServiceItem(InNetCoveredId)

if not exists(select * from sysindexes where name = 'IX_LetterCustomText_CreatedBy')
    CREATE INDEX IX_LetterCustomText_CreatedBy ON LetterCustomText(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PrimaryProviderSpecialtyID')
    CREATE INDEX IX_CMS_PrimaryProviderSpecialtyID ON CMS(PrimaryProviderSpecialtyID)

if not exists(select * from sysindexes where name = 'IX_EventReferralDiagnose_CreatedBy')
    CREATE INDEX IX_EventReferralDiagnose_CreatedBy ON EventReferralDiagnose(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_POCDeficit_ModifiedBy')
    CREATE INDEX IX_POCDeficit_ModifiedBy ON POCDeficit(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecisionTypeCode_CreatedBy')
    CREATE INDEX IX_ClinicalReviewDecisionTypeCode_CreatedBy ON ClinicalReviewDecisionTypeCode(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_RequestID')
    CREATE INDEX IX_LetterNonPrintedQueue_RequestID ON LetterNonPrintedQueue(RequestID)

if not exists(select * from sysindexes where name = 'IX_Outcome_OutcomeIndicatorID')
    CREATE INDEX IX_Outcome_OutcomeIndicatorID ON Outcome(OutcomeIndicatorID)

if not exists(select * from sysindexes where name = 'IX_PhysicianReviewRequestDetailType_ModifiedBy')
    CREATE INDEX IX_PhysicianReviewRequestDetailType_ModifiedBy ON PhysicianReviewRequestDetailType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_BenefitServiceItem_OutNetCoveredId')
    CREATE INDEX IX_BenefitServiceItem_OutNetCoveredId ON BenefitServiceItem(OutNetCoveredId)

if not exists(select * from sysindexes where name = 'IX_LetterCustomText_ModifiedBy')
    CREATE INDEX IX_LetterCustomText_ModifiedBy ON LetterCustomText(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PrimaryProviderLocationID')
    CREATE INDEX IX_CMS_PrimaryProviderLocationID ON CMS(PrimaryProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_EventReferralDiagnose_ModifiedBy')
    CREATE INDEX IX_EventReferralDiagnose_ModifiedBy ON EventReferralDiagnose(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_EDIRequestorDetail_MAProviderID')
    CREATE INDEX IX_EDIRequestorDetail_MAProviderID ON EDIRequestorDetail(MAProviderID)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_StatusChangedBy')
    CREATE INDEX IX_PhysicianReview_StatusChangedBy ON PhysicianReview(StatusChangedBy)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_RequestID')
    CREATE INDEX IX_LetterPrintedQueue_RequestID ON LetterPrintedQueue(RequestID)

if not exists(select * from sysindexes where name = 'IX_OutcomeIndicatorSubIndicator_OutcomeIndicatorId')
    CREATE INDEX IX_OutcomeIndicatorSubIndicator_OutcomeIndicatorId ON OutcomeIndicatorSubIndicator(OutcomeIndicatorId)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_EventID')
    CREATE INDEX IX_PhysicianReview_EventID ON PhysicianReview(EventID)

if not exists(select * from sysindexes where name = 'IX_DxType_ModifiedBy')
    CREATE INDEX IX_DxType_ModifiedBy ON DxType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Assessment_CreatedBy')
    CREATE INDEX IX_Assessment_CreatedBy ON Assessment(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PrimaryProviderLocationNetworkID')
    CREATE INDEX IX_CMS_PrimaryProviderLocationNetworkID ON CMS(PrimaryProviderLocationNetworkID)

if not exists(select * from sysindexes where name = 'IX_MomBabyCode_CreatedBy')
    CREATE INDEX IX_MomBabyCode_CreatedBy ON MomBabyCode(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_CreatedBy')
    CREATE INDEX IX_PhysicianReview_CreatedBy ON PhysicianReview(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_RequestID')
    CREATE INDEX IX_LetterDraftQueue_RequestID ON LetterDraftQueue(RequestID)

if not exists(select * from sysindexes where name = 'IX_GuidelineProductCategoryLink_GuidelineCategoryID')
    CREATE INDEX IX_GuidelineProductCategoryLink_GuidelineCategoryID ON GuidelineProductCategoryLink(GuidelineCategoryID)

if not exists(select * from sysindexes where name = 'IX_DxType_CreatedBy')
    CREATE INDEX IX_DxType_CreatedBy ON DxType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_PlanHEDISPayorTypeID')
    CREATE INDEX IX_PlanSorgLog_PlanHEDISPayorTypeID ON PlanSorgLog(PlanHEDISPayorTypeID)

if not exists(select * from sysindexes where name = 'IX_Assessment_ModifiedBy')
    CREATE INDEX IX_Assessment_ModifiedBy ON Assessment(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PrimaryFacilityTypeID')
    CREATE INDEX IX_CMS_PrimaryFacilityTypeID ON CMS(PrimaryFacilityTypeID)

if not exists(select * from sysindexes where name = 'IX_MomBabyCode_ModifiedBy')
    CREATE INDEX IX_MomBabyCode_ModifiedBy ON MomBabyCode(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_ModifiedBy')
    CREATE INDEX IX_PhysicianReview_ModifiedBy ON PhysicianReview(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterComplexData_MatrixTypeID')
    CREATE INDEX IX_LetterComplexData_MatrixTypeID ON LetterComplexData(MatrixTypeID)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRule_ActivityTypeId')
    CREATE INDEX IX_AutoActivityRule_ActivityTypeId ON AutoActivityRule(ActivityTypeId)

if not exists(select * from sysindexes where name = 'IX_GuidelineProductCategoryLink_GuidelineID')
    CREATE INDEX IX_GuidelineProductCategoryLink_GuidelineID ON GuidelineProductCategoryLink(GuidelineID)

if not exists(select * from sysindexes where name = 'IX_DRGType_ModifiedBy')
    CREATE INDEX IX_DRGType_ModifiedBy ON DRGType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AssessmentQuestionnaireOrder_CreatedBy')
    CREATE INDEX IX_AssessmentQuestionnaireOrder_CreatedBy ON AssessmentQuestionnaireOrder(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PrimaryFacilityLocationID')
    CREATE INDEX IX_CMS_PrimaryFacilityLocationID ON CMS(PrimaryFacilityLocationID)

if not exists(select * from sysindexes where name = 'IX_MomBabyCode_TerminatedBy')
    CREATE INDEX IX_MomBabyCode_TerminatedBy ON MomBabyCode(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_PCPGroupID')
    CREATE INDEX IX_Event_PCPGroupID ON Event(PCPGroupID)

if not exists(select * from sysindexes where name = 'IX_Questionnaire_ContentOwnerID')
    CREATE INDEX IX_Questionnaire_ContentOwnerID ON Questionnaire(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_GuidelineCode_CreatedBy')
    CREATE INDEX IX_GuidelineCode_CreatedBy ON GuidelineCode(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GuidelineProductCategoryLink_GuidelineProductID')
    CREATE INDEX IX_GuidelineProductCategoryLink_GuidelineProductID ON GuidelineProductCategoryLink(GuidelineProductID)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireLetterMatrix_MatrixID')
    CREATE INDEX IX_QuestionnaireLetterMatrix_MatrixID ON QuestionnaireLetterMatrix(MatrixID)

if not exists(select * from sysindexes where name = 'IX_DRGType_CreatedBy')
    CREATE INDEX IX_DRGType_CreatedBy ON DRGType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceItem_ManagementServicesRateTypeId')
    CREATE INDEX IX_ManagementServiceItem_ManagementServicesRateTypeId ON ManagementServiceItem(ManagementServicesRateTypeId)

if not exists(select * from sysindexes where name = 'IX_WCAssessment_CreatedBy')
    CREATE INDEX IX_WCAssessment_CreatedBy ON WCAssessment(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ContactRole_ContactID')
    CREATE INDEX IX_ContactRole_ContactID ON ContactRole(ContactID)

if not exists(select * from sysindexes where name = 'IX_CMS_PrimaryFacilityLocationNetworkID')
    CREATE INDEX IX_CMS_PrimaryFacilityLocationNetworkID ON CMS(PrimaryFacilityLocationNetworkID)

if not exists(select * from sysindexes where name = 'IX_Image_CreatedBy')
    CREATE INDEX IX_Image_CreatedBy ON Image(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_PCPSpecialtyID')
    CREATE INDEX IX_Event_PCPSpecialtyID ON Event(PCPSpecialtyID)

if not exists(select * from sysindexes where name = 'IX_Questionnaire_CMSTypeID')
    CREATE INDEX IX_Questionnaire_CMSTypeID ON Questionnaire(CMSTypeID)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationNetwork_ProviderLocationID')
    CREATE INDEX IX_ProviderLocationNetwork_ProviderLocationID ON ProviderLocationNetwork(ProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_GuidelineCode_ModifiedBy')
    CREATE INDEX IX_GuidelineCode_ModifiedBy ON GuidelineCode(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRule_ProviderLocationNetworkId')
    CREATE INDEX IX_AutoActivityRule_ProviderLocationNetworkId ON AutoActivityRule(ProviderLocationNetworkId)

if not exists(select * from sysindexes where name = 'IX_GuidelineTip_GuidelineID')
    CREATE INDEX IX_GuidelineTip_GuidelineID ON GuidelineTip(GuidelineID)

if not exists(select * from sysindexes where name = 'IX_Subscriber_CreatedBy')
    CREATE INDEX IX_Subscriber_CreatedBy ON Subscriber(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_WCTreatmentPlan_FrequencyUnitId')
    CREATE INDEX IX_WCTreatmentPlan_FrequencyUnitId ON WCTreatmentPlan(FrequencyUnitId)

if not exists(select * from sysindexes where name = 'IX_WCAssessment_ModifiedBy')
    CREATE INDEX IX_WCAssessment_ModifiedBy ON WCAssessment(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PrimaryProviderID')
    CREATE INDEX IX_CMS_PrimaryProviderID ON CMS(PrimaryProviderID)

if not exists(select * from sysindexes where name = 'IX_Role_ModifiedBy')
    CREATE INDEX IX_Role_ModifiedBy ON Role(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Event_PCPGroupTypeID')
    CREATE INDEX IX_Event_PCPGroupTypeID ON Event(PCPGroupTypeID)

if not exists(select * from sysindexes where name = 'IX_EDILogDetail_EDILogID')
    CREATE INDEX IX_EDILogDetail_EDILogID ON EDILogDetail(EDILogID)

if not exists(select * from sysindexes where name = 'IX_Questionnaire_QuestionnaireTypeID')
    CREATE INDEX IX_Questionnaire_QuestionnaireTypeID ON Questionnaire(QuestionnaireTypeID)

if not exists(select * from sysindexes where name = 'IX_GuidelineCode_CreatedBy')
    CREATE INDEX IX_GuidelineCode_CreatedBy ON GuidelineCode(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRule_FacilityLocationNetworkId')
    CREATE INDEX IX_AutoActivityRule_FacilityLocationNetworkId ON AutoActivityRule(FacilityLocationNetworkId)

if not exists(select * from sysindexes where name = 'IX_GuidelineTip_GuidelineSourceSetID')
    CREATE INDEX IX_GuidelineTip_GuidelineSourceSetID ON GuidelineTip(GuidelineSourceSetID)

if not exists(select * from sysindexes where name = 'IX_Subscriber_ModifiedBy')
    CREATE INDEX IX_Subscriber_ModifiedBy ON Subscriber(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCTreatmentPlan_DurationUnitId')
    CREATE INDEX IX_WCTreatmentPlan_DurationUnitId ON WCTreatmentPlan(DurationUnitId)

if not exists(select * from sysindexes where name = 'IX_FacilityLocation_CreatedBy')
    CREATE INDEX IX_FacilityLocation_CreatedBy ON FacilityLocation(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PrimaryFacilityID')
    CREATE INDEX IX_CMS_PrimaryFacilityID ON CMS(PrimaryFacilityID)

if not exists(select * from sysindexes where name = 'IX_Role_CreatedBy')
    CREATE INDEX IX_Role_CreatedBy ON Role(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianRequest_AppealRequestedByTypeID')
    CREATE INDEX IX_PhysicianRequest_AppealRequestedByTypeID ON PhysicianRequest(AppealRequestedByTypeID)

if not exists(select * from sysindexes where name = 'IX_Event_PCPGroupNetworkID')
    CREATE INDEX IX_Event_PCPGroupNetworkID ON Event(PCPGroupNetworkID)

if not exists(select * from sysindexes where name = 'IX_EDILogDetail_EDIRequestorDetailID')
    CREATE INDEX IX_EDILogDetail_EDIRequestorDetailID ON EDILogDetail(EDIRequestorDetailID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecisionType_ModifiedBy')
    CREATE INDEX IX_ClinicalReviewDecisionType_ModifiedBy ON ClinicalReviewDecisionType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRule_ReferProviderLocationNetworkId')
    CREATE INDEX IX_AutoActivityRule_ReferProviderLocationNetworkId ON AutoActivityRule(ReferProviderLocationNetworkId)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_PatientID')
    CREATE INDEX IX_PhysicianReview_PatientID ON PhysicianReview(PatientID)

if not exists(select * from sysindexes where name = 'IX_PhysicianReviewDecision_CreatedBy')
    CREATE INDEX IX_PhysicianReviewDecision_CreatedBy ON PhysicianReviewDecision(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AssessmentParagraph_AssessmentCategoryID')
    CREATE INDEX IX_AssessmentParagraph_AssessmentCategoryID ON AssessmentParagraph(AssessmentCategoryID)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_SORGID')
    CREATE INDEX IX_PlanSorgLog_SORGID ON PlanSorgLog(SORGID)

if not exists(select * from sysindexes where name = 'IX_FacilityLocation_ModifiedBy')
    CREATE INDEX IX_FacilityLocation_ModifiedBy ON FacilityLocation(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_CMSTypeID')
    CREATE INDEX IX_CMS_CMSTypeID ON CMS(CMSTypeID)

if not exists(select * from sysindexes where name = 'IX_ReportUnit_ModifiedBy')
    CREATE INDEX IX_ReportUnit_ModifiedBy ON ReportUnit(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Event_RefProviderSpecialtyID')
    CREATE INDEX IX_Event_RefProviderSpecialtyID ON Event(RefProviderSpecialtyID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecisionType_CreatedBy')
    CREATE INDEX IX_ClinicalReviewDecisionType_CreatedBy ON ClinicalReviewDecisionType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianReviewDecision_ModifiedBy')
    CREATE INDEX IX_PhysicianReviewDecision_ModifiedBy ON PhysicianReviewDecision(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Question_WebLinkID')
    CREATE INDEX IX_Question_WebLinkID ON Question(WebLinkID)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_SORGLOSRegion')
    CREATE INDEX IX_PlanSorgLog_SORGLOSRegion ON PlanSorgLog(SORGLOSRegion)

if not exists(select * from sysindexes where name = 'IX_FacilityLocation_TerminatedBy')
    CREATE INDEX IX_FacilityLocation_TerminatedBy ON FacilityLocation(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PrimaryProblemID')
    CREATE INDEX IX_CMS_PrimaryProblemID ON CMS(PrimaryProblemID)

if not exists(select * from sysindexes where name = 'IX_ReportUnit_CreatedBy')
    CREATE INDEX IX_ReportUnit_CreatedBy ON ReportUnit(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_RefProviderGroupTypeID')
    CREATE INDEX IX_Event_RefProviderGroupTypeID ON Event(RefProviderGroupTypeID)

if not exists(select * from sysindexes where name = 'IX_QuestionnairePresentationGroupOrder_QuestionnaireID')
    CREATE INDEX IX_QuestionnairePresentationGroupOrder_QuestionnaireID ON QuestionnairePresentationGroupOrder(QuestionnaireID)

if not exists(select * from sysindexes where name = 'IX_AssessmentCategory_CreatedBy')
    CREATE INDEX IX_AssessmentCategory_CreatedBy ON AssessmentCategory(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_OutcomeCode_CreatedBy')
    CREATE INDEX IX_OutcomeCode_CreatedBy ON OutcomeCode(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Question_ContentOwnerID')
    CREATE INDEX IX_Question_ContentOwnerID ON Question(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_EventConsultingProvider_CreatedBy')
    CREATE INDEX IX_EventConsultingProvider_CreatedBy ON EventConsultingProvider(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PatientSubscriberLogID')
    CREATE INDEX IX_CMS_PatientSubscriberLogID ON CMS(PatientSubscriberLogID)

if not exists(select * from sysindexes where name = 'IX_ActivityPrimaryType_CreatedBy')
    CREATE INDEX IX_ActivityPrimaryType_CreatedBy ON ActivityPrimaryType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_LetterTemplateID')
    CREATE INDEX IX_LetterDraftQueue_LetterTemplateID ON LetterDraftQueue(LetterTemplateID)

if not exists(select * from sysindexes where name = 'IX_Contact_NamePrefixID')
    CREATE INDEX IX_Contact_NamePrefixID ON Contact(NamePrefixID)

if not exists(select * from sysindexes where name = 'IX_AssessmentQuestionnaireOrder_QuestionnaireID')
    CREATE INDEX IX_AssessmentQuestionnaireOrder_QuestionnaireID ON AssessmentQuestionnaireOrder(QuestionnaireID)

if not exists(select * from sysindexes where name = 'IX_AssessmentCategory_ModifiedBy')
    CREATE INDEX IX_AssessmentCategory_ModifiedBy ON AssessmentCategory(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Outcome_Subindicator')
    CREATE INDEX IX_Outcome_Subindicator ON Outcome(Subindicator)

if not exists(select * from sysindexes where name = 'IX_LetterValue_FieldID')
    CREATE INDEX IX_LetterValue_FieldID ON LetterValue(FieldID)

if not exists(select * from sysindexes where name = 'IX_OutcomeCode_ModifiedBy')
    CREATE INDEX IX_OutcomeCode_ModifiedBy ON OutcomeCode(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Question_LogicID')
    CREATE INDEX IX_Question_LogicID ON Question(LogicID)

if not exists(select * from sysindexes where name = 'IX_EventConsultingProvider_ModifiedBy')
    CREATE INDEX IX_EventConsultingProvider_ModifiedBy ON EventConsultingProvider(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PlanSorgLogID')
    CREATE INDEX IX_CMS_PlanSorgLogID ON CMS(PlanSorgLogID)

if not exists(select * from sysindexes where name = 'IX_ActivityPrimaryType_ModifiedBy')
    CREATE INDEX IX_ActivityPrimaryType_ModifiedBy ON ActivityPrimaryType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Plan_AddressID')
    CREATE INDEX IX_Plan_AddressID ON [dbo].[Plan](AddressID)

if not exists(select * from sysindexes where name = 'IX_EDIResponse_EDILogDetailID')
    CREATE INDEX IX_EDIResponse_EDILogDetailID ON EDIResponse(EDILogDetailID)

if not exists(select * from sysindexes where name = 'IX_Activity_AssignedtoTeam')
    CREATE INDEX IX_Activity_AssignedtoTeam ON Activity(AssignedtoTeam)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireLetterMatrix_QuestionnaireID')
    CREATE INDEX IX_QuestionnaireLetterMatrix_QuestionnaireID ON QuestionnaireLetterMatrix(QuestionnaireID)

if not exists(select * from sysindexes where name = 'IX_IntakeResolution_CreatedBy')
    CREATE INDEX IX_IntakeResolution_CreatedBy ON IntakeResolution(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_RuleId')
    CREATE INDEX IX_AutoActivityRuleException_RuleId ON AutoActivityRuleException(RuleId)

if not exists(select * from sysindexes where name = 'IX_OutcomeIndicatorSubIndicator_OutcomeSubIndicatorId')
    CREATE INDEX IX_OutcomeIndicatorSubIndicator_OutcomeSubIndicatorId ON OutcomeIndicatorSubIndicator(OutcomeSubIndicatorId)

if not exists(select * from sysindexes where name = 'IX_LetterTemplateMatrixField_FieldID')
    CREATE INDEX IX_LetterTemplateMatrixField_FieldID ON LetterTemplateMatrixField(FieldID)

if not exists(select * from sysindexes where name = 'IX_DRGServiceClass_ModifiedBy')
    CREATE INDEX IX_DRGServiceClass_ModifiedBy ON DRGServiceClass(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Question_QuestionControlTypeID')
    CREATE INDEX IX_Question_QuestionControlTypeID ON Question(QuestionControlTypeID)

if not exists(select * from sysindexes where name = 'IX_LetterComplexField_CreatedBy')
    CREATE INDEX IX_LetterComplexField_CreatedBy ON LetterComplexField(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_CaseClosedReasonID')
    CREATE INDEX IX_CMS_CaseClosedReasonID ON CMS(CaseClosedReasonID)

if not exists(select * from sysindexes where name = 'IX_BenefitService_CreatedBy')
    CREATE INDEX IX_BenefitService_CreatedBy ON BenefitService(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionnairePresentationGroup_QuestionnaireID')
    CREATE INDEX IX_QuestionnairePresentationGroup_QuestionnaireID ON QuestionnairePresentationGroup(QuestionnaireID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationContact_ContactID')
    CREATE INDEX IX_GroupPracticeLocationContact_ContactID ON GroupPracticeLocationContact(ContactID)

if not exists(select * from sysindexes where name = 'IX_IntakeResolution_ModifiedBy')
    CREATE INDEX IX_IntakeResolution_ModifiedBy ON IntakeResolution(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_CMSEvent_EventID')
    CREATE INDEX IX_CMSEvent_EventID ON CMSEvent(EventID)

if not exists(select * from sysindexes where name = 'IX_LetterTemplateMatrixField_LetterTemplateID')
    CREATE INDEX IX_LetterTemplateMatrixField_LetterTemplateID ON LetterTemplateMatrixField(LetterTemplateID)

if not exists(select * from sysindexes where name = 'IX_DRGServiceClass_CreatedBy')
    CREATE INDEX IX_DRGServiceClass_CreatedBy ON DRGServiceClass(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_PlanNotificationServicesREquiredUOMId')
    CREATE INDEX IX_PlanSorgLog_PlanNotificationServicesREquiredUOMId ON PlanSorgLog(PlanNotificationServicesREquiredUOMId)

if not exists(select * from sysindexes where name = 'IX_LetterComplexField_ModifiedBy')
    CREATE INDEX IX_LetterComplexField_ModifiedBy ON LetterComplexField(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ContactRole_RoleID')
    CREATE INDEX IX_ContactRole_RoleID ON ContactRole(RoleID)

if not exists(select * from sysindexes where name = 'IX_CMS_CaseContinuedReasonID')
    CREATE INDEX IX_CMS_CaseContinuedReasonID ON CMS(CaseContinuedReasonID)

if not exists(select * from sysindexes where name = 'IX_BenefitService_ModifiedBy')
    CREATE INDEX IX_BenefitService_ModifiedBy ON BenefitService(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_SubscriberCoverage_SORGId')
    CREATE INDEX IX_SubscriberCoverage_SORGId ON SubscriberCoverage(SORGId)

if not exists(select * from sysindexes where name = 'IX_Note_NoteTerminationReasonID')
    CREATE INDEX IX_Note_NoteTerminationReasonID ON Note(NoteTerminationReasonID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationContact_GroupPracticeLocationID')
    CREATE INDEX IX_GroupPracticeLocationContact_GroupPracticeLocationID ON GroupPracticeLocationContact(GroupPracticeLocationID)

if not exists(select * from sysindexes where name = 'IX_ClientAuthorizer_ModifiedBy')
    CREATE INDEX IX_ClientAuthorizer_ModifiedBy ON ClientAuthorizer(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Activity_PhysicianReviewID')
    CREATE INDEX IX_Activity_PhysicianReviewID ON Activity(PhysicianReviewID)

if not exists(select * from sysindexes where name = 'IX_PlanSORG_CreatedBy')
    CREATE INDEX IX_PlanSORG_CreatedBy ON PlanSORG(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Question_ParentQuestionID')
    CREATE INDEX IX_Question_ParentQuestionID ON Question(ParentQuestionID)

if not exists(select * from sysindexes where name = 'IX_SystemInfo_CreatedBy')
    CREATE INDEX IX_SystemInfo_CreatedBy ON SystemInfo(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_CaseOpenReasonID')
    CREATE INDEX IX_CMS_CaseOpenReasonID ON CMS(CaseOpenReasonID)

if not exists(select * from sysindexes where name = 'IX_ReportCriteriaType_CreatedBy')
    CREATE INDEX IX_ReportCriteriaType_CreatedBy ON ReportCriteriaType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientMedication_AssessmentGUID')
    CREATE INDEX IX_PatientMedication_AssessmentGUID ON PatientMedication(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_Note_NoteTypeID')
    CREATE INDEX IX_Note_NoteTypeID ON Note(NoteTypeID)

if not exists(select * from sysindexes where name = 'IX_AssessmentQuestionnaire_QuestionnaireID')
    CREATE INDEX IX_AssessmentQuestionnaire_QuestionnaireID ON AssessmentQuestionnaire(QuestionnaireID)

if not exists(select * from sysindexes where name = 'IX_ClientAuthorizer_CreatedBy')
    CREATE INDEX IX_ClientAuthorizer_CreatedBy ON ClientAuthorizer(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PlanNote_PlanNoteTypeId')
    CREATE INDEX IX_PlanNote_PlanNoteTypeId ON PlanNote(PlanNoteTypeId)

if not exists(select * from sysindexes where name = 'IX_Note_PhysicianReviewID')
    CREATE INDEX IX_Note_PhysicianReviewID ON Note(PhysicianReviewID)

if not exists(select * from sysindexes where name = 'IX_ComplexDataValue_ComplexDataID')
    CREATE INDEX IX_ComplexDataValue_ComplexDataID ON ComplexDataValue(ComplexDataID)

if not exists(select * from sysindexes where name = 'IX_Plan_HedisPlanTypeID')
    CREATE INDEX IX_Plan_HedisPlanTypeID ON [dbo].[Plan](HedisPlanTypeID)

if not exists(select * from sysindexes where name = 'IX_PlanSORG_ModifiedBy')
    CREATE INDEX IX_PlanSORG_ModifiedBy ON PlanSORG(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCSubDeficit_DeficitId')
    CREATE INDEX IX_WCSubDeficit_DeficitId ON WCSubDeficit(DeficitId)

if not exists(select * from sysindexes where name = 'IX_SystemInfo_ModifiedBy')
    CREATE INDEX IX_SystemInfo_ModifiedBy ON SystemInfo(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_ClientAuthorizerID')
    CREATE INDEX IX_CMS_ClientAuthorizerID ON CMS(ClientAuthorizerID)

if not exists(select * from sysindexes where name = 'IX_ReportCriteriaType_ModifiedBy')
    CREATE INDEX IX_ReportCriteriaType_ModifiedBy ON ReportCriteriaType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientFocusHistory_PatientFocusID')
    CREATE INDEX IX_PatientFocusHistory_PatientFocusID ON PatientFocusHistory(PatientFocusID)

if not exists(select * from sysindexes where name = 'IX_PatientMedication_MedicationID')
    CREATE INDEX IX_PatientMedication_MedicationID ON PatientMedication(MedicationID)

if not exists(select * from sysindexes where name = 'IX_PatientCOB_Status')
    CREATE INDEX IX_PatientCOB_Status ON PatientCOB(Status)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireTrigger_QuestionnaireID')
    CREATE INDEX IX_QuestionnaireTrigger_QuestionnaireID ON QuestionnaireTrigger(QuestionnaireID)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationService_TerminatedBy')
    CREATE INDEX IX_ProviderLocationService_TerminatedBy ON ProviderLocationService(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianRequest_PhysicianReviewID')
    CREATE INDEX IX_PhysicianRequest_PhysicianReviewID ON PhysicianRequest(PhysicianReviewID)

if not exists(select * from sysindexes where name = 'IX_LetterComplexField_ComplexDataID')
    CREATE INDEX IX_LetterComplexField_ComplexDataID ON LetterComplexField(ComplexDataID)

if not exists(select * from sysindexes where name = 'IX_Plan_TriggerListId')
    CREATE INDEX IX_Plan_TriggerListId ON [dbo].[Plan](TriggerListId)

if not exists(select * from sysindexes where name = 'IX_Guideline_CreatedBy')
    CREATE INDEX IX_Guideline_CreatedBy ON Guideline(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PresentationGroupQuestion_QuestionID')
    CREATE INDEX IX_PresentationGroupQuestion_QuestionID ON PresentationGroupQuestion(QuestionID)

if not exists(select * from sysindexes where name = 'IX_WCSubSubDeficit_SubDeficitId')
    CREATE INDEX IX_WCSubSubDeficit_SubDeficitId ON WCSubSubDeficit(SubDeficitId)

if not exists(select * from sysindexes where name = 'IX_POCGoalTerm_CreatedBy')
    CREATE INDEX IX_POCGoalTerm_CreatedBy ON POCGoalTerm(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMS_PatientAuthorizerID')
    CREATE INDEX IX_CMS_PatientAuthorizerID ON CMS(PatientAuthorizerID)

if not exists(select * from sysindexes where name = 'IX_EmailTextResource_CreatedBy')
    CREATE INDEX IX_EmailTextResource_CreatedBy ON EmailTextResource(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientFocusHistory_PatientID')
    CREATE INDEX IX_PatientFocusHistory_PatientID ON PatientFocusHistory(PatientID)

if not exists(select * from sysindexes where name = 'IX_Note_EventID')
    CREATE INDEX IX_Note_EventID ON Note(EventID)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationService_ModifiedBy')
    CREATE INDEX IX_ProviderLocationService_ModifiedBy ON ProviderLocationService(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_ActivityTypeId')
    CREATE INDEX IX_AutoActivityRuleException_ActivityTypeId ON AutoActivityRuleException(ActivityTypeId)

if not exists(select * from sysindexes where name = 'IX_Plan_PlanTypeId')
    CREATE INDEX IX_Plan_PlanTypeId ON [dbo].[Plan](PlanTypeId)

if not exists(select * from sysindexes where name = 'IX_Guideline_ModifiedBy')
    CREATE INDEX IX_Guideline_ModifiedBy ON Guideline(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionExplanation_QuestionID')
    CREATE INDEX IX_QuestionExplanation_QuestionID ON QuestionExplanation(QuestionID)

if not exists(select * from sysindexes where name = 'IX_Assessment_ContentOwnerID')
    CREATE INDEX IX_Assessment_ContentOwnerID ON Assessment(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_POCGoalTerm_ModifiedBy')
    CREATE INDEX IX_POCGoalTerm_ModifiedBy ON POCGoalTerm(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Provider_PrefixId')
    CREATE INDEX IX_Provider_PrefixId ON Provider(PrefixId)

if not exists(select * from sysindexes where name = 'IX_EmailTextResource_ModifiedBy')
    CREATE INDEX IX_EmailTextResource_ModifiedBy ON EmailTextResource(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationService_CreatedBy')
    CREATE INDEX IX_ProviderLocationService_CreatedBy ON ProviderLocationService(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PlanNote_PlanId')
    CREATE INDEX IX_PlanNote_PlanId ON PlanNote(PlanId)

if not exists(select * from sysindexes where name = 'IX_OutcomeReason_OutcomeIndicator')
    CREATE INDEX IX_OutcomeReason_OutcomeIndicator ON OutcomeReason(OutcomeIndicator)

if not exists(select * from sysindexes where name = 'IX_DRGMDC_ModifiedBy')
    CREATE INDEX IX_DRGMDC_ModifiedBy ON DRGMDC(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceItem_ConversionUnitOfMeasureId')
    CREATE INDEX IX_ManagementServiceItem_ConversionUnitOfMeasureId ON ManagementServiceItem(ConversionUnitOfMeasureId)

if not exists(select * from sysindexes where name = 'IX_ReportCriteriaResponse_QuestionID')
    CREATE INDEX IX_ReportCriteriaResponse_QuestionID ON ReportCriteriaResponse(QuestionID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationService_GroupPracticeServiceTypeID')
    CREATE INDEX IX_GroupPracticeLocationService_GroupPracticeServiceTypeID ON GroupPracticeLocationService(GroupPracticeServiceTypeID)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationNetwork_TerminatedBy')
    CREATE INDEX IX_ProviderLocationNetwork_TerminatedBy ON ProviderLocationNetwork(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemSent_CMSId')
    CREATE INDEX IX_PackingListItemSent_CMSId ON PackingListItemSent(CMSId)

if not exists(select * from sysindexes where name = 'IX_POCDeficitType_CreatedBy')
    CREATE INDEX IX_POCDeficitType_CreatedBy ON POCDeficitType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupPlanLevel_CreatedBy')
    CREATE INDEX IX_SecurityGroupPlanLevel_CreatedBy ON SecurityGroupPlanLevel(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_ProviderLocationNetworkId')
    CREATE INDEX IX_AutoActivityRuleException_ProviderLocationNetworkId ON AutoActivityRuleException(ProviderLocationNetworkId)

if not exists(select * from sysindexes where name = 'IX_DRGMDC_CreatedBy')
    CREATE INDEX IX_DRGMDC_CreatedBy ON DRGMDC(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PresentationGroupQuestionOrder_QuestionID')
    CREATE INDEX IX_PresentationGroupQuestionOrder_QuestionID ON PresentationGroupQuestionOrder(QuestionID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationService_GroupPracticeLocationID')
    CREATE INDEX IX_GroupPracticeLocationService_GroupPracticeLocationID ON GroupPracticeLocationService(GroupPracticeLocationID)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationNetwork_CreatedBy')
    CREATE INDEX IX_ProviderLocationNetwork_CreatedBy ON ProviderLocationNetwork(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireLetterMatrix_ContentOwnerID')
    CREATE INDEX IX_QuestionnaireLetterMatrix_ContentOwnerID ON QuestionnaireLetterMatrix(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_Outcome_CMSID')
    CREATE INDEX IX_Outcome_CMSID ON Outcome(CMSID)

if not exists(select * from sysindexes where name = 'IX_POCDeficitType_ModifiedBy')
    CREATE INDEX IX_POCDeficitType_ModifiedBy ON POCDeficitType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Note_ReferralDetailID')
    CREATE INDEX IX_Note_ReferralDetailID ON Note(ReferralDetailID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupPlanLevel_ModifiedBy')
    CREATE INDEX IX_SecurityGroupPlanLevel_ModifiedBy ON SecurityGroupPlanLevel(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_FacilityLocationNetworkId')
    CREATE INDEX IX_AutoActivityRuleException_FacilityLocationNetworkId ON AutoActivityRuleException(FacilityLocationNetworkId)

if not exists(select * from sysindexes where name = 'IX_PhysicianReviewAppealRequestByType_CreatedBy')
    CREATE INDEX IX_PhysicianReviewAppealRequestByType_CreatedBy ON PhysicianReviewAppealRequestByType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationNetwork_ModifiedBy')
    CREATE INDEX IX_ProviderLocationNetwork_ModifiedBy ON ProviderLocationNetwork(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WorkersComp_CMSId')
    CREATE INDEX IX_WorkersComp_CMSId ON WorkersComp(CMSId)

if not exists(select * from sysindexes where name = 'IX_Patient_AssignedUserId')
    CREATE INDEX IX_Patient_AssignedUserId ON Patient(AssignedUserId)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_StateId')
    CREATE INDEX IX_AutoActivityRuleException_StateId ON AutoActivityRuleException(StateId)

if not exists(select * from sysindexes where name = 'IX_OrgFocusCode_CreatedBy')
    CREATE INDEX IX_OrgFocusCode_CreatedBy ON OrgFocusCode(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_ReferProviderLocationNetworkId')
    CREATE INDEX IX_AutoActivityRuleException_ReferProviderLocationNetworkId ON AutoActivityRuleException(ReferProviderLocationNetworkId)

if not exists(select * from sysindexes where name = 'IX_Outcome_OutcomeReasonID')
    CREATE INDEX IX_Outcome_OutcomeReasonID ON Outcome(OutcomeReasonID)

if not exists(select * from sysindexes where name = 'IX_PhysicianReviewAppealRequestByType_ModifiedBy')
    CREATE INDEX IX_PhysicianReviewAppealRequestByType_ModifiedBy ON PhysicianReviewAppealRequestByType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_VitalNumberResponse_CreatedBy')
    CREATE INDEX IX_VitalNumberResponse_CreatedBy ON VitalNumberResponse(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMSStatusHistory_CMSId')
    CREATE INDEX IX_CMSStatusHistory_CMSId ON CMSStatusHistory(CMSId)

if not exists(select * from sysindexes where name = 'IX_WCBodySubSystem_BodySystemId')
    CREATE INDEX IX_WCBodySubSystem_BodySystemId ON WCBodySubSystem(BodySystemId)

if not exists(select * from sysindexes where name = 'IX_Patient_CreatedBy')
    CREATE INDEX IX_Patient_CreatedBy ON Patient(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationContact_ContactID')
    CREATE INDEX IX_FacilityLocationContact_ContactID ON FacilityLocationContact(ContactID)

if not exists(select * from sysindexes where name = 'IX_OrgFocusCode_ModifiedBy')
    CREATE INDEX IX_OrgFocusCode_ModifiedBy ON OrgFocusCode(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Plan_HEDISPayorTypeID')
    CREATE INDEX IX_Plan_HEDISPayorTypeID ON [dbo].[Plan](HEDISPayorTypeID)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_ReferralStatusChangedBy')
    CREATE INDEX IX_ReferralDetail_ReferralStatusChangedBy ON ReferralDetail(ReferralStatusChangedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceItem_ManagementServiceTypeId')
    CREATE INDEX IX_ManagementServiceItem_ManagementServiceTypeId ON ManagementServiceItem(ManagementServiceTypeId)

if not exists(select * from sysindexes where name = 'IX_PresentationGroupQuestion_ContentOwnerID')
    CREATE INDEX IX_PresentationGroupQuestion_ContentOwnerID ON PresentationGroupQuestion(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_VitalNumberResponse_ModifiedBy')
    CREATE INDEX IX_VitalNumberResponse_ModifiedBy ON VitalNumberResponse(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientLevelOfDisease_CMSID')
    CREATE INDEX IX_PatientLevelOfDisease_CMSID ON PatientLevelOfDisease(CMSID)

if not exists(select * from sysindexes where name = 'IX_WCInjuryData_InjuryTypeId')
    CREATE INDEX IX_WCInjuryData_InjuryTypeId ON WCInjuryData(InjuryTypeId)

if not exists(select * from sysindexes where name = 'IX_Patient_ModifiedBy')
    CREATE INDEX IX_Patient_ModifiedBy ON Patient(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationContact_FacilityLocationID')
    CREATE INDEX IX_FacilityLocationContact_FacilityLocationID ON FacilityLocationContact(FacilityLocationID)

if not exists(select * from sysindexes where name = 'IX_AAUserStatus_CreatedBy')
    CREATE INDEX IX_AAUserStatus_CreatedBy ON AAUserStatus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Plan_ManagementServiceId')
    CREATE INDEX IX_Plan_ManagementServiceId ON [dbo].[Plan](ManagementServiceId)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_ReferralStatusChangedBy')
    CREATE INDEX IX_ReferralDetail_ReferralStatusChangedBy ON ReferralDetail(ReferralStatusChangedBy)

if not exists(select * from sysindexes where name = 'IX_Activity_ManagementServiceTypeId')
    CREATE INDEX IX_Activity_ManagementServiceTypeId ON Activity(ManagementServiceTypeId)

if not exists(select * from sysindexes where name = 'IX_Event_CreatedBy')
    CREATE INDEX IX_Event_CreatedBy ON Event(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_CMSID')
    CREATE INDEX IX_LetterNonPrintedQueue_CMSID ON LetterNonPrintedQueue(CMSID)

if not exists(select * from sysindexes where name = 'IX_WCInjuryData_InjuryBodyPartId')
    CREATE INDEX IX_WCInjuryData_InjuryBodyPartId ON WCInjuryData(InjuryBodyPartId)

if not exists(select * from sysindexes where name = 'IX_ReferralUrgency_CreatedBy')
    CREATE INDEX IX_ReferralUrgency_CreatedBy ON ReferralUrgency(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeProviderHistory_GroupPracticeProviderID')
    CREATE INDEX IX_GroupPracticeProviderHistory_GroupPracticeProviderID ON GroupPracticeProviderHistory(GroupPracticeProviderID)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_PlanHEDISTypeId')
    CREATE INDEX IX_PlanSorgLog_PlanHEDISTypeId ON PlanSorgLog(PlanHEDISTypeId)

if not exists(select * from sysindexes where name = 'IX_AAUserStatus_ModifiedBy')
    CREATE INDEX IX_AAUserStatus_ModifiedBy ON AAUserStatus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Plan_PreCertNotificationServicesRequiredUOM')
    CREATE INDEX IX_Plan_PreCertNotificationServicesRequiredUOM ON [dbo].[Plan](PreCertNotificationServicesRequiredUOM)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_CreatedBy')
    CREATE INDEX IX_ReferralDetail_CreatedBy ON ReferralDetail(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_ModifiedBy')
    CREATE INDEX IX_Event_ModifiedBy ON Event(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeProvider_ProviderID')
    CREATE INDEX IX_GroupPracticeProvider_ProviderID ON GroupPracticeProvider(ProviderID)

if not exists(select * from sysindexes where name = 'IX_Problem_AssignedTeamID')
    CREATE INDEX IX_Problem_AssignedTeamID ON Problem(AssignedTeamID)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_CMSID')
    CREATE INDEX IX_LetterDraftQueue_CMSID ON LetterDraftQueue(CMSID)

if not exists(select * from sysindexes where name = 'IX_WCInjuryData_WorkersCompId')
    CREATE INDEX IX_WCInjuryData_WorkersCompId ON WCInjuryData(WorkersCompId)

if not exists(select * from sysindexes where name = 'IX_AssessmentCategory_CMSTypeID')
    CREATE INDEX IX_AssessmentCategory_CMSTypeID ON AssessmentCategory(CMSTypeID)

if not exists(select * from sysindexes where name = 'IX_ReferralUrgency_ModifiedBy')
    CREATE INDEX IX_ReferralUrgency_ModifiedBy ON ReferralUrgency(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_NotePage_NoteID')
    CREATE INDEX IX_NotePage_NoteID ON NotePage(NoteID)

if not exists(select * from sysindexes where name = 'IX_CaseOpenReason_ModifiedBy')
    CREATE INDEX IX_CaseOpenReason_ModifiedBy ON CaseOpenReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_ModifiedBy')
    CREATE INDEX IX_ReferralDetail_ModifiedBy ON ReferralDetail(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Event_AssignedUserID')
    CREATE INDEX IX_Event_AssignedUserID ON Event(AssignedUserID)

if not exists(select * from sysindexes where name = 'IX_Event_ProviderID')
    CREATE INDEX IX_Event_ProviderID ON Event(ProviderID)

if not exists(select * from sysindexes where name = 'IX_Problem_ProblemStatusID')
    CREATE INDEX IX_Problem_ProblemStatusID ON Problem(ProblemStatusID)

if not exists(select * from sysindexes where name = 'IX_CMSProblem_CMSId')
    CREATE INDEX IX_CMSProblem_CMSId ON CMSProblem(CMSId)

if not exists(select * from sysindexes where name = 'IX_MedicalEquipment_WorkersCompId')
    CREATE INDEX IX_MedicalEquipment_WorkersCompId ON MedicalEquipment(WorkersCompId)

if not exists(select * from sysindexes where name = 'IX_LetterValue_CreatedBy')
    CREATE INDEX IX_LetterValue_CreatedBy ON LetterValue(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CaseOpenReason_CreatedBy')
    CREATE INDEX IX_CaseOpenReason_CreatedBy ON CaseOpenReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_DecisionReason_ModifiedBy')
    CREATE INDEX IX_DecisionReason_ModifiedBy ON DecisionReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_EligibilityId')
    CREATE INDEX IX_IntakeLog_EligibilityId ON IntakeLog(EligibilityId)

if not exists(select * from sysindexes where name = 'IX_Event_PCPID')
    CREATE INDEX IX_Event_PCPID ON Event(PCPID)

if not exists(select * from sysindexes where name = 'IX_Problem_DxType')
    CREATE INDEX IX_Problem_DxType ON Problem(DxType)

if not exists(select * from sysindexes where name = 'IX_CMSEvent_CMSID')
    CREATE INDEX IX_CMSEvent_CMSID ON CMSEvent(CMSID)

if not exists(select * from sysindexes where name = 'IX_MedicalEquipment_DurableMedicalEquipmentId')
    CREATE INDEX IX_MedicalEquipment_DurableMedicalEquipmentId ON MedicalEquipment(DurableMedicalEquipmentId)

if not exists(select * from sysindexes where name = 'IX_LetterValue_ModifiedBy')
    CREATE INDEX IX_LetterValue_ModifiedBy ON LetterValue(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_CMSStatusHistory_StatusId')
    CREATE INDEX IX_CMSStatusHistory_StatusId ON CMSStatusHistory(StatusId)

if not exists(select * from sysindexes where name = 'IX_GuidelineCategory_CreatedBy')
    CREATE INDEX IX_GuidelineCategory_CreatedBy ON GuidelineCategory(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_PCPSpecialtyID')
    CREATE INDEX IX_Referral_PCPSpecialtyID ON Referral(PCPSpecialtyID)

if not exists(select * from sysindexes where name = 'IX_ReferralAuthorizationDecision_ClinicalReviewDecisionTypeCodeID')
    CREATE INDEX IX_ReferralAuthorizationDecision_ClinicalReviewDecisionTypeCodeID ON ReferralAuthorizationDecision(ClinicalReviewDecisionTypeCodeID)

if not exists(select * from sysindexes where name = 'IX_DecisionReason_CreatedBy')
    CREATE INDEX IX_DecisionReason_CreatedBy ON DecisionReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterComplexData_CreatedBy')
    CREATE INDEX IX_LetterComplexData_CreatedBy ON LetterComplexData(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderFocus_ProviderID')
    CREATE INDEX IX_ProviderFocus_ProviderID ON ProviderFocus(ProviderID)

if not exists(select * from sysindexes where name = 'IX_Assessment_CMSID')
    CREATE INDEX IX_Assessment_CMSID ON Assessment(CMSID)

if not exists(select * from sysindexes where name = 'IX_WCTreatmentPlan_WorkersCompId')
    CREATE INDEX IX_WCTreatmentPlan_WorkersCompId ON WCTreatmentPlan(WorkersCompId)

if not exists(select * from sysindexes where name = 'IX_SecurityGroup_CreatedBy')
    CREATE INDEX IX_SecurityGroup_CreatedBy ON SecurityGroup(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Logic_ContentOwnerID')
    CREATE INDEX IX_Logic_ContentOwnerID ON Logic(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_GuidelineCategory_ModifiedBy')
    CREATE INDEX IX_GuidelineCategory_ModifiedBy ON GuidelineCategory(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_PCPLocationID')
    CREATE INDEX IX_Referral_PCPLocationID ON Referral(PCPLocationID)

if not exists(select * from sysindexes where name = 'IX_SubscriberCoverage_PlanId')
    CREATE INDEX IX_SubscriberCoverage_PlanId ON SubscriberCoverage(PlanId)

if not exists(select * from sysindexes where name = 'IX_Problem_AssignedUserID')
    CREATE INDEX IX_Problem_AssignedUserID ON Problem(AssignedUserID)

if not exists(select * from sysindexes where name = 'IX_EligibilityPCP_EligibilityId')
    CREATE INDEX IX_EligibilityPCP_EligibilityId ON EligibilityPCP(EligibilityId)

if not exists(select * from sysindexes where name = 'IX_LetterComplexData_ModifiedBy')
    CREATE INDEX IX_LetterComplexData_ModifiedBy ON LetterComplexData(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Event_CMSID')
    CREATE INDEX IX_Event_CMSID ON Event(CMSID)

if not exists(select * from sysindexes where name = 'IX_WCTreatmentPlan_ProviderId')
    CREATE INDEX IX_WCTreatmentPlan_ProviderId ON WCTreatmentPlan(ProviderId)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_CMSType')
    CREATE INDEX IX_AutoActivityRuleException_CMSType ON AutoActivityRuleException(CMSType)

if not exists(select * from sysindexes where name = 'IX_SecurityGroup_ModifiedBy')
    CREATE INDEX IX_SecurityGroup_ModifiedBy ON SecurityGroup(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_CMSStatusHistory_AcuityId')
    CREATE INDEX IX_CMSStatusHistory_AcuityId ON CMSStatusHistory(AcuityId)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_PlanTypeId')
    CREATE INDEX IX_PlanSorgLog_PlanTypeId ON PlanSorgLog(PlanTypeId)

if not exists(select * from sysindexes where name = 'IX_Logic_LogicTypeID')
    CREATE INDEX IX_Logic_LogicTypeID ON Logic(LogicTypeID)

if not exists(select * from sysindexes where name = 'IX_CaseContinuedReason_ModifiedBy')
    CREATE INDEX IX_CaseContinuedReason_ModifiedBy ON CaseContinuedReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_ReferredFromProviderSpecialtyID')
    CREATE INDEX IX_Referral_ReferredFromProviderSpecialtyID ON Referral(ReferredFromProviderSpecialtyID)

if not exists(select * from sysindexes where name = 'IX_Outcome_OutcomeCodeID')
    CREATE INDEX IX_Outcome_OutcomeCodeID ON Outcome(OutcomeCodeID)

if not exists(select * from sysindexes where name = 'IX_Outcome_EventID')
    CREATE INDEX IX_Outcome_EventID ON Outcome(EventID)

if not exists(select * from sysindexes where name = 'IX_EligibilityPlan_PlanId')
    CREATE INDEX IX_EligibilityPlan_PlanId ON EligibilityPlan(PlanId)

if not exists(select * from sysindexes where name = 'IX_Problem_CreatedBy')
    CREATE INDEX IX_Problem_CreatedBy ON Problem(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PatientRelationshipId')
    CREATE INDEX IX_PatientSubscriberLog_PatientRelationshipId ON PatientSubscriberLog(PatientRelationshipId)

if not exists(select * from sysindexes where name = 'IX_EligibilityPCP_PCPId')
    CREATE INDEX IX_EligibilityPCP_PCPId ON EligibilityPCP(PCPId)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireOrganizationPlan_CreatedBy')
    CREATE INDEX IX_QuestionnaireOrganizationPlan_CreatedBy ON QuestionnaireOrganizationPlan(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_AutoGenCMSID')
    CREATE INDEX IX_Event_AutoGenCMSID ON Event(AutoGenCMSID)

if not exists(select * from sysindexes where name = 'IX_WCTreatmentPlan_SettingId')
    CREATE INDEX IX_WCTreatmentPlan_SettingId ON WCTreatmentPlan(SettingId)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeFocus_TerminatedBy')
    CREATE INDEX IX_GroupPracticeFocus_TerminatedBy ON GroupPracticeFocus(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_CMSStatusHistory_PhaseId')
    CREATE INDEX IX_CMSStatusHistory_PhaseId ON CMSStatusHistory(PhaseId)

if not exists(select * from sysindexes where name = 'IX_CaseContinuedReason_CreatedBy')
    CREATE INDEX IX_CaseContinuedReason_CreatedBy ON CaseContinuedReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_ReferredFromProviderLocationID')
    CREATE INDEX IX_Referral_ReferredFromProviderLocationID ON Referral(ReferredFromProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_PlanId')
    CREATE INDEX IX_AutoActivityRuleException_PlanId ON AutoActivityRuleException(PlanId)

if not exists(select * from sysindexes where name = 'IX_Problem_ModifiedBy')
    CREATE INDEX IX_Problem_ModifiedBy ON Problem(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_EligibilityPCP_PCPTypeId')
    CREATE INDEX IX_EligibilityPCP_PCPTypeId ON EligibilityPCP(PCPTypeId)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireOrganizationPlan_ModifiedBy')
    CREATE INDEX IX_QuestionnaireOrganizationPlan_ModifiedBy ON QuestionnaireOrganizationPlan(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_EventReferralDiagnose_CMSId')
    CREATE INDEX IX_EventReferralDiagnose_CMSId ON EventReferralDiagnose(CMSId)

if not exists(select * from sysindexes where name = 'IX_PatientLevelOfDisease_PatientID')
    CREATE INDEX IX_PatientLevelOfDisease_PatientID ON PatientLevelOfDisease(PatientID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeFocus_CreatedBy')
    CREATE INDEX IX_GroupPracticeFocus_CreatedBy ON GroupPracticeFocus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMSStatusHistory_IntensityId')
    CREATE INDEX IX_CMSStatusHistory_IntensityId ON CMSStatusHistory(IntensityId)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_PlanMgmtSvcTypeID')
    CREATE INDEX IX_AutoActivityRuleException_PlanMgmtSvcTypeID ON AutoActivityRuleException(PlanMgmtSvcTypeID)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_PlanMaternicheckIncentiveId')
    CREATE INDEX IX_PlanSorgLog_PlanMaternicheckIncentiveId ON PlanSorgLog(PlanMaternicheckIncentiveId)

if not exists(select * from sysindexes where name = 'IX_TriggerItem_TerminatedBy')
    CREATE INDEX IX_TriggerItem_TerminatedBy ON TriggerItem(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_ReferredToProviderSpecialtyID')
    CREATE INDEX IX_Referral_ReferredToProviderSpecialtyID ON Referral(ReferredToProviderSpecialtyID)

if not exists(select * from sysindexes where name = 'IX_ReferralReportEntry_ReferralRoleID')
    CREATE INDEX IX_ReferralReportEntry_ReferralRoleID ON ReferralReportEntry(ReferralRoleID)

if not exists(select * from sysindexes where name = 'IX_LetterReceiverType_MatrixTypeID')
    CREATE INDEX IX_LetterReceiverType_MatrixTypeID ON LetterReceiverType(MatrixTypeID)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRule_PlanId')
    CREATE INDEX IX_AutoActivityRule_PlanId ON AutoActivityRule(PlanId)

if not exists(select * from sysindexes where name = 'IX_Problem_StatusChangedBy')
    CREATE INDEX IX_Problem_StatusChangedBy ON Problem(StatusChangedBy)

if not exists(select * from sysindexes where name = 'IX_EligibilityPCP_PCPSpecialtyID')
    CREATE INDEX IX_EligibilityPCP_PCPSpecialtyID ON EligibilityPCP(PCPSpecialtyID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewFreqUnit_ModifiedBy')
    CREATE INDEX IX_ClinicalReviewFreqUnit_ModifiedBy ON ClinicalReviewFreqUnit(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Problem_ProblemDescriptionID')
    CREATE INDEX IX_Problem_ProblemDescriptionID ON Problem(ProblemDescriptionID)

if not exists(select * from sysindexes where name = 'IX_EventReferralDiagnose_CMSId')
    CREATE INDEX IX_EventReferralDiagnose_CMSId ON EventReferralDiagnose(CMSId)

if not exists(select * from sysindexes where name = 'IX_ReferralUnitType_CreatedBy')
    CREATE INDEX IX_ReferralUnitType_CreatedBy ON ReferralUnitType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Plan_MaternichekIncentiveId')
    CREATE INDEX IX_Plan_MaternichekIncentiveId ON [dbo].[Plan](MaternichekIncentiveId)

if not exists(select * from sysindexes where name = 'IX_Facility_FacilityTypeID')
    CREATE INDEX IX_Facility_FacilityTypeID ON Facility(FacilityTypeID)

if not exists(select * from sysindexes where name = 'IX_TriggerItem_CreatedBy')
    CREATE INDEX IX_TriggerItem_CreatedBy ON TriggerItem(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_ReferredToProviderLocationID')
    CREATE INDEX IX_Referral_ReferredToProviderLocationID ON Referral(ReferredToProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_ReferralReportEntry_ReferralDetailID')
    CREATE INDEX IX_ReferralReportEntry_ReferralDetailID ON ReferralReportEntry(ReferralDetailID)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_PlanID')
    CREATE INDEX IX_LetterDraftQueue_PlanID ON LetterDraftQueue(PlanID)

if not exists(select * from sysindexes where name = 'IX_SubscriberCoverage_CreatedBy')
    CREATE INDEX IX_SubscriberCoverage_CreatedBy ON SubscriberCoverage(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_EligibilityPCP_PCPLocationID')
    CREATE INDEX IX_EligibilityPCP_PCPLocationID ON EligibilityPCP(PCPLocationID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewFreqUnit_CreatedBy')
    CREATE INDEX IX_ClinicalReviewFreqUnit_CreatedBy ON ClinicalReviewFreqUnit(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Activity_ProblemId')
    CREATE INDEX IX_Activity_ProblemId ON Activity(ProblemId)

if not exists(select * from sysindexes where name = 'IX_ImageLink_CMSID')
    CREATE INDEX IX_ImageLink_CMSID ON ImageLink(CMSID)

if not exists(select * from sysindexes where name = 'IX_WCAssessment_WorkersCompId')
    CREATE INDEX IX_WCAssessment_WorkersCompId ON WCAssessment(WorkersCompId)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_ReferralUrgencyID')
    CREATE INDEX IX_ReferralDetail_ReferralUrgencyID ON ReferralDetail(ReferralUrgencyID)

if not exists(select * from sysindexes where name = 'IX_PatientLevelOfDisease_AssessmentGUID')
    CREATE INDEX IX_PatientLevelOfDisease_AssessmentGUID ON PatientLevelOfDisease(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_ReferralUnitType_ModifiedBy')
    CREATE INDEX IX_ReferralUnitType_ModifiedBy ON ReferralUnitType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_CMSStatusHistory_AssignedTeamId')
    CREATE INDEX IX_CMSStatusHistory_AssignedTeamId ON CMSStatusHistory(AssignedTeamId)

if not exists(select * from sysindexes where name = 'IX_FacilityLocation_FacilityID')
    CREATE INDEX IX_FacilityLocation_FacilityID ON FacilityLocation(FacilityID)

if not exists(select * from sysindexes where name = 'IX_TriggerItem_ModifiedBy')
    CREATE INDEX IX_TriggerItem_ModifiedBy ON TriggerItem(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ReferralReportEntry_ProviderLocationID')
    CREATE INDEX IX_ReferralReportEntry_ProviderLocationID ON ReferralReportEntry(ProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_PlanID')
    CREATE INDEX IX_LetterNonPrintedQueue_PlanID ON LetterNonPrintedQueue(PlanID)

if not exists(select * from sysindexes where name = 'IX_SubscriberCoverage_ModifiedBy')
    CREATE INDEX IX_SubscriberCoverage_ModifiedBy ON SubscriberCoverage(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianReviewRequestReason_CreatedBy')
    CREATE INDEX IX_PhysicianReviewRequestReason_CreatedBy ON PhysicianReviewRequestReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Activity_CMSID')
    CREATE INDEX IX_Activity_CMSID ON Activity(CMSID)

if not exists(select * from sysindexes where name = 'IX_WCAssessment_BodySystemId')
    CREATE INDEX IX_WCAssessment_BodySystemId ON WCAssessment(BodySystemId)

if not exists(select * from sysindexes where name = 'IX_PatientLevelOfDisease_ContentOwnerID')
    CREATE INDEX IX_PatientLevelOfDisease_ContentOwnerID ON PatientLevelOfDisease(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_EmailParagraph_CreatedBy')
    CREATE INDEX IX_EmailParagraph_CreatedBy ON EmailParagraph(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMSStatusHistory_StatusTypeId')
    CREATE INDEX IX_CMSStatusHistory_StatusTypeId ON CMSStatusHistory(StatusTypeId)

if not exists(select * from sysindexes where name = 'IX_Answer_QuestionID')
    CREATE INDEX IX_Answer_QuestionID ON Answer(QuestionID)

if not exists(select * from sysindexes where name = 'IX_VitalNumberQuestion_LogicID')
    CREATE INDEX IX_VitalNumberQuestion_LogicID ON VitalNumberQuestion(LogicID)

if not exists(select * from sysindexes where name = 'IX_Event_FacilityID')
    CREATE INDEX IX_Event_FacilityID ON Event(FacilityID)

if not exists(select * from sysindexes where name = 'IX_OrganizationType_CreatedBy')
    CREATE INDEX IX_OrganizationType_CreatedBy ON OrganizationType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_PlanID')
    CREATE INDEX IX_LetterPrintedQueue_PlanID ON LetterPrintedQueue(PlanID)

if not exists(select * from sysindexes where name = 'IX_DateActualProjected_ModifiedBy')
    CREATE INDEX IX_DateActualProjected_ModifiedBy ON DateActualProjected(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianReviewRequestReason_ModifiedBy')
    CREATE INDEX IX_PhysicianReviewRequestReason_ModifiedBy ON PhysicianReviewRequestReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderSpecialty_SpecialtyID')
    CREATE INDEX IX_ProviderSpecialty_SpecialtyID ON ProviderSpecialty(SpecialtyID)

if not exists(select * from sysindexes where name = 'IX_EventReferralProcedure_CMSId')
    CREATE INDEX IX_EventReferralProcedure_CMSId ON EventReferralProcedure(CMSId)

if not exists(select * from sysindexes where name = 'IX_WCAssessment_BodySubSystemId')
    CREATE INDEX IX_WCAssessment_BodySubSystemId ON WCAssessment(BodySubSystemId)

if not exists(select * from sysindexes where name = 'IX_PatientLevelOfDisease_LevelOfDiseaseTypeID')
    CREATE INDEX IX_PatientLevelOfDisease_LevelOfDiseaseTypeID ON PatientLevelOfDisease(LevelOfDiseaseTypeID)

if not exists(select * from sysindexes where name = 'IX_EmailParagraph_ModifiedBy')
    CREATE INDEX IX_EmailParagraph_ModifiedBy ON EmailParagraph(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Answer_AnswerTypeID')
    CREATE INDEX IX_Answer_AnswerTypeID ON Answer(AnswerTypeID)

if not exists(select * from sysindexes where name = 'IX_EmailTextResource_LogicID')
    CREATE INDEX IX_EmailTextResource_LogicID ON EmailTextResource(LogicID)

if not exists(select * from sysindexes where name = 'IX_OrganizationType_ModifiedBy')
    CREATE INDEX IX_OrganizationType_ModifiedBy ON OrganizationType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_PrimaryProblemID')
    CREATE INDEX IX_Referral_PrimaryProblemID ON Referral(PrimaryProblemID)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_PlanId')
    CREATE INDEX IX_PlanSorgLog_PlanId ON PlanSorgLog(PlanId)

if not exists(select * from sysindexes where name = 'IX_DateActualProjected_CreatedBy')
    CREATE INDEX IX_DateActualProjected_CreatedBy ON DateActualProjected(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_EligibilityPlan_EligibilityId')
    CREATE INDEX IX_EligibilityPlan_EligibilityId ON EligibilityPlan(EligibilityId)

if not exists(select * from sysindexes where name = 'IX_VitalNumberQuestion_CreatedBy')
    CREATE INDEX IX_VitalNumberQuestion_CreatedBy ON VitalNumberQuestion(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMSProblem_ProblemId')
    CREATE INDEX IX_CMSProblem_ProblemId ON CMSProblem(ProblemId)

if not exists(select * from sysindexes where name = 'IX_Maternichek_CMSId')
    CREATE INDEX IX_Maternichek_CMSId ON Maternichek(CMSId)

if not exists(select * from sysindexes where name = 'IX_WCAssessment_DeficitId')
    CREATE INDEX IX_WCAssessment_DeficitId ON WCAssessment(DeficitId)

if not exists(select * from sysindexes where name = 'IX_ReferralType_CreatedBy')
    CREATE INDEX IX_ReferralType_CreatedBy ON ReferralType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemTrigger_LogicId')
    CREATE INDEX IX_PackingListItemTrigger_LogicId ON PackingListItemTrigger(LogicId)

if not exists(select * from sysindexes where name = 'IX_WorkStatusSubStatus_ModifiedBy')
    CREATE INDEX IX_WorkStatusSubStatus_ModifiedBy ON WorkStatusSubStatus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_PCPID')
    CREATE INDEX IX_Referral_PCPID ON Referral(PCPID)

if not exists(select * from sysindexes where name = 'IX_LetterMatrixType_CreatedBy')
    CREATE INDEX IX_LetterMatrixType_CreatedBy ON LetterMatrixType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_EligibilityPlan_PlanTypeId')
    CREATE INDEX IX_EligibilityPlan_PlanTypeId ON EligibilityPlan(PlanTypeId)

if not exists(select * from sysindexes where name = 'IX_SubscriberCoverageHistory_SubscriberCoverageID')
    CREATE INDEX IX_SubscriberCoverageHistory_SubscriberCoverageID ON SubscriberCoverageHistory(SubscriberCoverageID)

if not exists(select * from sysindexes where name = 'IX_VitalNumberQuestion_ModifiedBy')
    CREATE INDEX IX_VitalNumberQuestion_ModifiedBy ON VitalNumberQuestion(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Event_PrimaryProblemID')
    CREATE INDEX IX_Event_PrimaryProblemID ON Event(PrimaryProblemID)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_CMSID')
    CREATE INDEX IX_LetterPrintedQueue_CMSID ON LetterPrintedQueue(CMSID)

if not exists(select * from sysindexes where name = 'IX_WCAssessment_QualifierId')
    CREATE INDEX IX_WCAssessment_QualifierId ON WCAssessment(QualifierId)

if not exists(select * from sysindexes where name = 'IX_ReferralType_ModifiedBy')
    CREATE INDEX IX_ReferralType_ModifiedBy ON ReferralType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientMeasurement_LogicID')
    CREATE INDEX IX_PatientMeasurement_LogicID ON PatientMeasurement(LogicID)

if not exists(select * from sysindexes where name = 'IX_FacilityFocus_FacilityID')
    CREATE INDEX IX_FacilityFocus_FacilityID ON FacilityFocus(FacilityID)

if not exists(select * from sysindexes where name = 'IX_WorkStatusSubStatus_CreatedBy')
    CREATE INDEX IX_WorkStatusSubStatus_CreatedBy ON WorkStatusSubStatus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_PCPNetworkID')
    CREATE INDEX IX_Referral_PCPNetworkID ON Referral(PCPNetworkID)

if not exists(select * from sysindexes where name = 'IX_Outcome_ResultFrom')
    CREATE INDEX IX_Outcome_ResultFrom ON Outcome(ResultFrom)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_PlanID')
    CREATE INDEX IX_IntakeLog_PlanID ON IntakeLog(PlanID)

if not exists(select * from sysindexes where name = 'IX_LetterMatrixType_ModifiedBy')
    CREATE INDEX IX_LetterMatrixType_ModifiedBy ON LetterMatrixType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Plan_SpecialProcedureId')
    CREATE INDEX IX_Plan_SpecialProcedureId ON [dbo].[Plan](SpecialProcedureId)

if not exists(select * from sysindexes where name = 'IX_SubscriberCoverage_SubscriberEligibilityID')
    CREATE INDEX IX_SubscriberCoverage_SubscriberEligibilityID ON SubscriberCoverage(SubscriberEligibilityID)

if not exists(select * from sysindexes where name = 'IX_POCDeficitStatus_CreatedBy')
    CREATE INDEX IX_POCDeficitStatus_CreatedBy ON POCDeficitStatus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderSpecialty_ProviderID')
    CREATE INDEX IX_ProviderSpecialty_ProviderID ON ProviderSpecialty(ProviderID)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_ProblemID')
    CREATE INDEX IX_LetterDraftQueue_ProblemID ON LetterDraftQueue(ProblemID)

if not exists(select * from sysindexes where name = 'IX_PatientMeasurement_CMSID')
    CREATE INDEX IX_PatientMeasurement_CMSID ON PatientMeasurement(CMSID)

if not exists(select * from sysindexes where name = 'IX_WCAssessment_SubDeficitId')
    CREATE INDEX IX_WCAssessment_SubDeficitId ON WCAssessment(SubDeficitId)

if not exists(select * from sysindexes where name = 'IX_LetterTemplate_CreatedBy')
    CREATE INDEX IX_LetterTemplate_CreatedBy ON LetterTemplate(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Answer_ContentOwnerID')
    CREATE INDEX IX_Answer_ContentOwnerID ON Answer(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_PatientMedication_LogicID')
    CREATE INDEX IX_PatientMedication_LogicID ON PatientMedication(LogicID)

if not exists(select * from sysindexes where name = 'IX_CaseClosedReason_ModifiedBy')
    CREATE INDEX IX_CaseClosedReason_ModifiedBy ON CaseClosedReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_ReferredFromPCIID')
    CREATE INDEX IX_Referral_ReferredFromPCIID ON Referral(ReferredFromPCIID)

if not exists(select * from sysindexes where name = 'IX_Note_CreatedBy')
    CREATE INDEX IX_Note_CreatedBy ON Note(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityFocus_FacilityFocusTypeID')
    CREATE INDEX IX_FacilityFocus_FacilityFocusTypeID ON FacilityFocus(FacilityFocusTypeID)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_PlanSpecialProcedureId')
    CREATE INDEX IX_PlanSorgLog_PlanSpecialProcedureId ON PlanSorgLog(PlanSpecialProcedureId)

if not exists(select * from sysindexes where name = 'IX_POCDeficitStatus_ModifiedBy')
    CREATE INDEX IX_POCDeficitStatus_ModifiedBy ON POCDeficitStatus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_ProblemID')
    CREATE INDEX IX_LetterPrintedQueue_ProblemID ON LetterPrintedQueue(ProblemID)

if not exists(select * from sysindexes where name = 'IX_PatientMeasurement_CMSID')
    CREATE INDEX IX_PatientMeasurement_CMSID ON PatientMeasurement(CMSID)

if not exists(select * from sysindexes where name = 'IX_WCAssessment_SubSubDeficitId')
    CREATE INDEX IX_WCAssessment_SubSubDeficitId ON WCAssessment(SubSubDeficitId)

if not exists(select * from sysindexes where name = 'IX_LetterTemplate_ModifiedBy')
    CREATE INDEX IX_LetterTemplate_ModifiedBy ON LetterTemplate(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Answer_AnswerControlTypeID')
    CREATE INDEX IX_Answer_AnswerControlTypeID ON Answer(AnswerControlTypeID)

if not exists(select * from sysindexes where name = 'IX_CaseClosedReason_CreatedBy')
    CREATE INDEX IX_CaseClosedReason_CreatedBy ON CaseClosedReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_ReferredFromNetworkID')
    CREATE INDEX IX_Referral_ReferredFromNetworkID ON Referral(ReferredFromNetworkID)

if not exists(select * from sysindexes where name = 'IX_EventReferralProcedure_EventID')
    CREATE INDEX IX_EventReferralProcedure_EventID ON EventReferralProcedure(EventID)

if not exists(select * from sysindexes where name = 'IX_Activity_PlanId')
    CREATE INDEX IX_Activity_PlanId ON Activity(PlanId)

if not exists(select * from sysindexes where name = 'IX_Note_TerminatedBy')
    CREATE INDEX IX_Note_TerminatedBy ON Note(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_AssignedToUser')
    CREATE INDEX IX_Referral_AssignedToUser ON Referral(AssignedToUser)

if not exists(select * from sysindexes where name = 'IX_Note_ProblemId')
    CREATE INDEX IX_Note_ProblemId ON Note(ProblemId)

if not exists(select * from sysindexes where name = 'IX_Note_CMSId')
    CREATE INDEX IX_Note_CMSId ON Note(CMSId)

if not exists(select * from sysindexes where name = 'IX_WorkStatus_WorkersCompId')
    CREATE INDEX IX_WorkStatus_WorkersCompId ON WorkStatus(WorkersCompId)

if not exists(select * from sysindexes where name = 'IX_LetterTemplate_TerminatedBy')
    CREATE INDEX IX_LetterTemplate_TerminatedBy ON LetterTemplate(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientMedication_AnswerID')
    CREATE INDEX IX_PatientMedication_AnswerID ON PatientMedication(AnswerID)

if not exists(select * from sysindexes where name = 'IX_PatientFocus_CreatedBy')
    CREATE INDEX IX_PatientFocus_CreatedBy ON PatientFocus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_ReferredToType')
    CREATE INDEX IX_Referral_ReferredToType ON Referral(ReferredToType)

if not exists(select * from sysindexes where name = 'IX_PresentationGroup_ContentOwnerID')
    CREATE INDEX IX_PresentationGroup_ContentOwnerID ON PresentationGroup(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_EventReferralDiagnose_EventID')
    CREATE INDEX IX_EventReferralDiagnose_EventID ON EventReferralDiagnose(EventID)

if not exists(select * from sysindexes where name = 'IX_NetworkPlan_PlanId')
    CREATE INDEX IX_NetworkPlan_PlanId ON NetworkPlan(PlanId)

if not exists(select * from sysindexes where name = 'IX_Note_AppendID')
    CREATE INDEX IX_Note_AppendID ON Note(AppendID)

if not exists(select * from sysindexes where name = 'IX_Problem_PatientSubscriberLogID')
    CREATE INDEX IX_Problem_PatientSubscriberLogID ON Problem(PatientSubscriberLogID)

if not exists(select * from sysindexes where name = 'IX_Referral_CreatedBy')
    CREATE INDEX IX_Referral_CreatedBy ON Referral(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Outcome_ProblemId')
    CREATE INDEX IX_Outcome_ProblemId ON Outcome(ProblemId)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_CMSID')
    CREATE INDEX IX_PhysicianReview_CMSID ON PhysicianReview(CMSID)

if not exists(select * from sysindexes where name = 'IX_WorkStatus_StatusId')
    CREATE INDEX IX_WorkStatus_StatusId ON WorkStatus(StatusId)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_DecisionReasonID')
    CREATE INDEX IX_ReferralDetail_DecisionReasonID ON ReferralDetail(DecisionReasonID)

if not exists(select * from sysindexes where name = 'IX_EventType_CreatedBy')
    CREATE INDEX IX_EventType_CreatedBy ON EventType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientLevelOfDisease_AnswerID')
    CREATE INDEX IX_PatientLevelOfDisease_AnswerID ON PatientLevelOfDisease(AnswerID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupFALevel_FALevelID')
    CREATE INDEX IX_SecurityGroupFALevel_FALevelID ON SecurityGroupFALevel(FALevelID)

if not exists(select * from sysindexes where name = 'IX_Event_StartDateAP')
    CREATE INDEX IX_Event_StartDateAP ON Event(StartDateAP)

if not exists(select * from sysindexes where name = 'IX_PatientFocus_ModifiedBy')
    CREATE INDEX IX_PatientFocus_ModifiedBy ON PatientFocus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_ReferredToProviderNetworkID')
    CREATE INDEX IX_Referral_ReferredToProviderNetworkID ON Referral(ReferredToProviderNetworkID)

if not exists(select * from sysindexes where name = 'IX_PlanContact_PlanID')
    CREATE INDEX IX_PlanContact_PlanID ON PlanContact(PlanID)

if not exists(select * from sysindexes where name = 'IX_Note_AppendID')
    CREATE INDEX IX_Note_AppendID ON Note(AppendID)

if not exists(select * from sysindexes where name = 'IX_QuestionnairePresentationGroup_ContentOwnerID')
    CREATE INDEX IX_QuestionnairePresentationGroup_ContentOwnerID ON QuestionnairePresentationGroup(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_Referral_ModifiedBy')
    CREATE INDEX IX_Referral_ModifiedBy ON Referral(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientProblem_ProblemId')
    CREATE INDEX IX_PatientProblem_ProblemId ON PatientProblem(ProblemId)

if not exists(select * from sysindexes where name = 'IX_POCDeficit_CMSId')
    CREATE INDEX IX_POCDeficit_CMSId ON POCDeficit(CMSId)

if not exists(select * from sysindexes where name = 'IX_WorkStatus_SubStatusId')
    CREATE INDEX IX_WorkStatus_SubStatusId ON WorkStatus(SubStatusId)

if not exists(select * from sysindexes where name = 'IX_EventType_ModifiedBy')
    CREATE INDEX IX_EventType_ModifiedBy ON EventType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ReportCriteriaResponse_AnswerID')
    CREATE INDEX IX_ReportCriteriaResponse_AnswerID ON ReportCriteriaResponse(AnswerID)

if not exists(select * from sysindexes where name = 'IX_Event_EndDateAP')
    CREATE INDEX IX_Event_EndDateAP ON Event(EndDateAP)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_UserID')
    CREATE INDEX IX_LetterDraftQueue_UserID ON LetterDraftQueue(UserID)

if not exists(select * from sysindexes where name = 'IX_Referral_PlanSorgLogID')
    CREATE INDEX IX_Referral_PlanSorgLogID ON Referral(PlanSorgLogID)

if not exists(select * from sysindexes where name = 'IX_Event_EventTypeID')
    CREATE INDEX IX_Event_EventTypeID ON Event(EventTypeID)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_MatrixTypeID')
    CREATE INDEX IX_LetterMatrix_MatrixTypeID ON LetterMatrix(MatrixTypeID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupPlanLevel_PlanID')
    CREATE INDEX IX_SecurityGroupPlanLevel_PlanID ON SecurityGroupPlanLevel(PlanID)

if not exists(select * from sysindexes where name = 'IX_Note_CreatedBy')
    CREATE INDEX IX_Note_CreatedBy ON Note(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeProvider_GroupPracticeLocationID')
    CREATE INDEX IX_GroupPracticeProvider_GroupPracticeLocationID ON GroupPracticeProvider(GroupPracticeLocationID)

if not exists(select * from sysindexes where name = 'IX_Activity_ParentActivityID')
    CREATE INDEX IX_Activity_ParentActivityID ON Activity(ParentActivityID)

if not exists(select * from sysindexes where name = 'IX_MeasurementType_CreatedBy')
    CREATE INDEX IX_MeasurementType_CreatedBy ON MeasurementType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLocation_LocationID')
    CREATE INDEX IX_ProviderLocation_LocationID ON ProviderLocation(LocationID)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_ProblemID')
    CREATE INDEX IX_PhysicianReview_ProblemID ON PhysicianReview(ProblemID)

if not exists(select * from sysindexes where name = 'IX_EventType_CreatedBy')
    CREATE INDEX IX_EventType_CreatedBy ON EventType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AnswerRange_AnswerID')
    CREATE INDEX IX_AnswerRange_AnswerID ON AnswerRange(AnswerID)

if not exists(select * from sysindexes where name = 'IX_Problem_PlanSORGLogID')
    CREATE INDEX IX_Problem_PlanSORGLogID ON Problem(PlanSORGLogID)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_CreatedBy')
    CREATE INDEX IX_LetterDraftQueue_CreatedBy ON LetterDraftQueue(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_PatientSubscriberLogID')
    CREATE INDEX IX_Referral_PatientSubscriberLogID ON Referral(PatientSubscriberLogID)

if not exists(select * from sysindexes where name = 'IX_Event_EventSourceID')
    CREATE INDEX IX_Event_EventSourceID ON Event(EventSourceID)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_LetterSetID')
    CREATE INDEX IX_LetterMatrix_LetterSetID ON LetterMatrix(LetterSetID)

if not exists(select * from sysindexes where name = 'IX_GuidelineProduct_CreatedBy')
    CREATE INDEX IX_GuidelineProduct_CreatedBy ON GuidelineProduct(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_MeasurementType_ModifiedBy')
    CREATE INDEX IX_MeasurementType_ModifiedBy ON MeasurementType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ReportCriteria_ReportCriteriaTypeID')
    CREATE INDEX IX_ReportCriteria_ReportCriteriaTypeID ON ReportCriteria(ReportCriteriaTypeID)

if not exists(select * from sysindexes where name = 'IX_EventSource_CreatedBy')
    CREATE INDEX IX_EventSource_CreatedBy ON EventSource(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientMeasurement_AnswerID')
    CREATE INDEX IX_PatientMeasurement_AnswerID ON PatientMeasurement(AnswerID)

if not exists(select * from sysindexes where name = 'IX_Problem_ProviderID')
    CREATE INDEX IX_Problem_ProviderID ON Problem(ProviderID)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_ModifiedBy')
    CREATE INDEX IX_LetterDraftQueue_ModifiedBy ON LetterDraftQueue(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_AdmittingDxType')
    CREATE INDEX IX_Referral_AdmittingDxType ON Referral(AdmittingDxType)

if not exists(select * from sysindexes where name = 'IX_QuestionnairePresentationGroup_PresentationGroupID')
    CREATE INDEX IX_QuestionnairePresentationGroup_PresentationGroupID ON QuestionnairePresentationGroup(PresentationGroupID)

if not exists(select * from sysindexes where name = 'IX_Event_Resolution')
    CREATE INDEX IX_Event_Resolution ON Event(Resolution)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_LetterTypeID')
    CREATE INDEX IX_LetterMatrix_LetterTypeID ON LetterMatrix(LetterTypeID)

if not exists(select * from sysindexes where name = 'IX_PlanSORG_PlanId')
    CREATE INDEX IX_PlanSORG_PlanId ON PlanSORG(PlanId)

if not exists(select * from sysindexes where name = 'IX_GuidelineProduct_ModifiedBy')
    CREATE INDEX IX_GuidelineProduct_ModifiedBy ON GuidelineProduct(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ImageLink_ReferralID')
    CREATE INDEX IX_ImageLink_ReferralID ON ImageLink(ReferralID)

if not exists(select * from sysindexes where name = 'IX_ReferralAppointment_CreatedBy')
    CREATE INDEX IX_ReferralAppointment_CreatedBy ON ReferralAppointment(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProblemReferral_ProblemId')
    CREATE INDEX IX_ProblemReferral_ProblemId ON ProblemReferral(ProblemId)

if not exists(select * from sysindexes where name = 'IX_EventSource_ModifiedBy')
    CREATE INDEX IX_EventSource_ModifiedBy ON EventSource(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Response_AnswerID')
    CREATE INDEX IX_Response_AnswerID ON Response(AnswerID)

if not exists(select * from sysindexes where name = 'IX_Problem_GroupPracticeProviderID')
    CREATE INDEX IX_Problem_GroupPracticeProviderID ON Problem(GroupPracticeProviderID)

if not exists(select * from sysindexes where name = 'IX_ProblemEvent_ProblemId')
    CREATE INDEX IX_ProblemEvent_ProblemId ON ProblemEvent(ProblemId)

if not exists(select * from sysindexes where name = 'IX_BenefitServiceType_ModifiedBy')
    CREATE INDEX IX_BenefitServiceType_ModifiedBy ON BenefitServiceType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_DRG_Code')
    CREATE INDEX IX_Referral_DRG_Code ON Referral(DRG_Code)

if not exists(select * from sysindexes where name = 'IX_PresentationGroupQuestion_PresentationGroupID')
    CREATE INDEX IX_PresentationGroupQuestion_PresentationGroupID ON PresentationGroupQuestion(PresentationGroupID)

if not exists(select * from sysindexes where name = 'IX_CoveredType_ModifiedBy')
    CREATE INDEX IX_CoveredType_ModifiedBy ON CoveredType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ImageLink_PhysicianReviewID')
    CREATE INDEX IX_ImageLink_PhysicianReviewID ON ImageLink(PhysicianReviewID)

if not exists(select * from sysindexes where name = 'IX_ReferralAppointment_ModifiedBy')
    CREATE INDEX IX_ReferralAppointment_ModifiedBy ON ReferralAppointment(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_ProblemID')
    CREATE INDEX IX_LetterNonPrintedQueue_ProblemID ON LetterNonPrintedQueue(ProblemID)

if not exists(select * from sysindexes where name = 'IX_EventSource_CreatedBy')
    CREATE INDEX IX_EventSource_CreatedBy ON EventSource(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Network_AddressID')
    CREATE INDEX IX_Network_AddressID ON Network(AddressID)

if not exists(select * from sysindexes where name = 'IX_VitalNumberResponse_AnswerID')
    CREATE INDEX IX_VitalNumberResponse_AnswerID ON VitalNumberResponse(AnswerID)

if not exists(select * from sysindexes where name = 'IX_Problem_ProviderSpecialtyID')
    CREATE INDEX IX_Problem_ProviderSpecialtyID ON Problem(ProviderSpecialtyID)

if not exists(select * from sysindexes where name = 'IX_ProblemEvent_EventID')
    CREATE INDEX IX_ProblemEvent_EventID ON ProblemEvent(EventID)

if not exists(select * from sysindexes where name = 'IX_BenefitServiceType_CreatedBy')
    CREATE INDEX IX_BenefitServiceType_CreatedBy ON BenefitServiceType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_ProviderLocationID')
    CREATE INDEX IX_Event_ProviderLocationID ON Event(ProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_CoveredType_CreatedBy')
    CREATE INDEX IX_CoveredType_CreatedBy ON CoveredType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_POCDeficitSource_CreatedBy')
    CREATE INDEX IX_POCDeficitSource_CreatedBy ON POCDeficitSource(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ReferralScheduledBy_CreatedBy')
    CREATE INDEX IX_ReferralScheduledBy_CreatedBy ON ReferralScheduledBy(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationNetwork_NetworkID')
    CREATE INDEX IX_FacilityLocationNetwork_NetworkID ON FacilityLocationNetwork(NetworkID)

if not exists(select * from sysindexes where name = 'IX_LogicAnswer_AnswerID')
    CREATE INDEX IX_LogicAnswer_AnswerID ON LogicAnswer(AnswerID)

if not exists(select * from sysindexes where name = 'IX_ProblemEvent_PatientId')
    CREATE INDEX IX_ProblemEvent_PatientId ON ProblemEvent(PatientId)

if not exists(select * from sysindexes where name = 'IX_CMS_ModifiedBy')
    CREATE INDEX IX_CMS_ModifiedBy ON CMS(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_AssignedToTeam')
    CREATE INDEX IX_Referral_AssignedToTeam ON Referral(AssignedToTeam)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PatientRelatedProblemID')
    CREATE INDEX IX_PatientSubscriberLog_PatientRelatedProblemID ON PatientSubscriberLog(PatientRelatedProblemID)

if not exists(select * from sysindexes where name = 'IX_CaseSource_CreatedBy')
    CREATE INDEX IX_CaseSource_CreatedBy ON CaseSource(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_POCDeficitSource_ModifiedBy')
    CREATE INDEX IX_POCDeficitSource_ModifiedBy ON POCDeficitSource(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ReportCriteriaResponse_ReportCriteriaID')
    CREATE INDEX IX_ReportCriteriaResponse_ReportCriteriaID ON ReportCriteriaResponse(ReportCriteriaID)

if not exists(select * from sysindexes where name = 'IX_ReferralScheduledBy_ModifiedBy')
    CREATE INDEX IX_ReferralScheduledBy_ModifiedBy ON ReferralScheduledBy(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_NetworkFocus_NetworkID')
    CREATE INDEX IX_NetworkFocus_NetworkID ON NetworkFocus(NetworkID)

if not exists(select * from sysindexes where name = 'IX_EventConsultingProvider_EventID')
    CREATE INDEX IX_EventConsultingProvider_EventID ON EventConsultingProvider(EventID)

if not exists(select * from sysindexes where name = 'IX_CMS_CreatedBy')
    CREATE INDEX IX_CMS_CreatedBy ON CMS(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PatientRelatedEventID')
    CREATE INDEX IX_PatientSubscriberLog_PatientRelatedEventID ON PatientSubscriberLog(PatientRelatedEventID)

if not exists(select * from sysindexes where name = 'IX_LetterSet_MatrixTypeID')
    CREATE INDEX IX_LetterSet_MatrixTypeID ON LetterSet(MatrixTypeID)

if not exists(select * from sysindexes where name = 'IX_CaseSource_ModifiedBy')
    CREATE INDEX IX_CaseSource_ModifiedBy ON CaseSource(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_ReferralDetailID')
    CREATE INDEX IX_LetterMatrix_ReferralDetailID ON LetterMatrix(ReferralDetailID)

if not exists(select * from sysindexes where name = 'IX_MatrixType_CreatedBy')
    CREATE INDEX IX_MatrixType_CreatedBy ON MatrixType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLanguage_ProviderID')
    CREATE INDEX IX_ProviderLanguage_ProviderID ON ProviderLanguage(ProviderID)

if not exists(select * from sysindexes where name = 'IX_EventResolution_ModifiedBy')
    CREATE INDEX IX_EventResolution_ModifiedBy ON EventResolution(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Event_ProviderNetworkID')
    CREATE INDEX IX_Event_ProviderNetworkID ON Event(ProviderNetworkID)

if not exists(select * from sysindexes where name = 'IX_EventConsultingProvider_ProviderID')
    CREATE INDEX IX_EventConsultingProvider_ProviderID ON EventConsultingProvider(ProviderID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupOrganizationLevel_CreatedBy')
    CREATE INDEX IX_SecurityGroupOrganizationLevel_CreatedBy ON SecurityGroupOrganizationLevel(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PatientSubscriberRelationshipID')
    CREATE INDEX IX_PatientSubscriberLog_PatientSubscriberRelationshipID ON PatientSubscriberLog(PatientSubscriberRelationshipID)

if not exists(select * from sysindexes where name = 'IX_LetterTemplate_LetterSetID')
    CREATE INDEX IX_LetterTemplate_LetterSetID ON LetterTemplate(LetterSetID)

if not exists(select * from sysindexes where name = 'IX_ConversionUnitOfMeasure_ModifiedBy')
    CREATE INDEX IX_ConversionUnitOfMeasure_ModifiedBy ON ConversionUnitOfMeasure(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_MatrixType_ModifiedBy')
    CREATE INDEX IX_MatrixType_ModifiedBy ON MatrixType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLanguage_LanguageID')
    CREATE INDEX IX_ProviderLanguage_LanguageID ON ProviderLanguage(LanguageID)

if not exists(select * from sysindexes where name = 'IX_EventResolution_CreatedBy')
    CREATE INDEX IX_EventResolution_CreatedBy ON EventResolution(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_FacilityNetworkID')
    CREATE INDEX IX_Event_FacilityNetworkID ON Event(FacilityNetworkID)

if not exists(select * from sysindexes where name = 'IX_EventConsultingProvider_ProviderSpecialtyID')
    CREATE INDEX IX_EventConsultingProvider_ProviderSpecialtyID ON EventConsultingProvider(ProviderSpecialtyID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupOrganizationLevel_ModifiedBy')
    CREATE INDEX IX_SecurityGroupOrganizationLevel_ModifiedBy ON SecurityGroupOrganizationLevel(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP1_ID')
    CREATE INDEX IX_PatientSubscriberLog_PCP1_ID ON PatientSubscriberLog(PCP1_ID)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_PhysicianReviewRequestReasonID')
    CREATE INDEX IX_PhysicianReview_PhysicianReviewRequestReasonID ON PhysicianReview(PhysicianReviewRequestReasonID)

if not exists(select * from sysindexes where name = 'IX_LetterTemplate_MatrixTypeID')
    CREATE INDEX IX_LetterTemplate_MatrixTypeID ON LetterTemplate(MatrixTypeID)

if not exists(select * from sysindexes where name = 'IX_ConversionUnitOfMeasure_CreatedBy')
    CREATE INDEX IX_ConversionUnitOfMeasure_CreatedBy ON ConversionUnitOfMeasure(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceType_CreatedBy')
    CREATE INDEX IX_ManagementServiceType_CreatedBy ON ManagementServiceType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ReportCriteriaResponse_ContentOwnerID')
    CREATE INDEX IX_ReportCriteriaResponse_ContentOwnerID ON ReportCriteriaResponse(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_EventResolution_CreatedBy')
    CREATE INDEX IX_EventResolution_CreatedBy ON EventResolution(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Organization_OrganizationLevelID')
    CREATE INDEX IX_Organization_OrganizationLevelID ON Organization(OrganizationLevelID)

if not exists(select * from sysindexes where name = 'IX_Event_PCPNetworkID')
    CREATE INDEX IX_Event_PCPNetworkID ON Event(PCPNetworkID)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireOrganizationPlan_QuestionnaireID')
    CREATE INDEX IX_QuestionnaireOrganizationPlan_QuestionnaireID ON QuestionnaireOrganizationPlan(QuestionnaireID)

if not exists(select * from sysindexes where name = 'IX_EventConsultingProvider_ProviderLocationID')
    CREATE INDEX IX_EventConsultingProvider_ProviderLocationID ON EventConsultingProvider(ProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_IntakeCallType_CreatedBy')
    CREATE INDEX IX_IntakeCallType_CreatedBy ON IntakeCallType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP1_LocationID')
    CREATE INDEX IX_PatientSubscriberLog_PCP1_LocationID ON PatientSubscriberLog(PCP1_LocationID)

if not exists(select * from sysindexes where name = 'IX_Event_AssignedTeamID')
    CREATE INDEX IX_Event_AssignedTeamID ON Event(AssignedTeamID)

if not exists(select * from sysindexes where name = 'IX_LetterTemplate_ReceiverTypeID')
    CREATE INDEX IX_LetterTemplate_ReceiverTypeID ON LetterTemplate(ReceiverTypeID)

if not exists(select * from sysindexes where name = 'IX_Provider_CreatedBy')
    CREATE INDEX IX_Provider_CreatedBy ON Provider(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceType_ModifiedBy')
    CREATE INDEX IX_ManagementServiceType_ModifiedBy ON ManagementServiceType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_FreqUOMID')
    CREATE INDEX IX_ClinicalReviewDecision_FreqUOMID ON ClinicalReviewDecision(FreqUOMID)

if not exists(select * from sysindexes where name = 'IX_ReferralAppointment_ReferralScheduledByID')
    CREATE INDEX IX_ReferralAppointment_ReferralScheduledByID ON ReferralAppointment(ReferralScheduledByID)

if not exists(select * from sysindexes where name = 'IX_NetworkFocus_ModifiedBy')
    CREATE INDEX IX_NetworkFocus_ModifiedBy ON NetworkFocus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Organization_OrganizationTypeID')
    CREATE INDEX IX_Organization_OrganizationTypeID ON Organization(OrganizationTypeID)

if not exists(select * from sysindexes where name = 'IX_EventConsultingProvider_ProviderLocationNetworkID')
    CREATE INDEX IX_EventConsultingProvider_ProviderLocationNetworkID ON EventConsultingProvider(ProviderLocationNetworkID)

if not exists(select * from sysindexes where name = 'IX_IntakeCallType_ModifiedBy')
    CREATE INDEX IX_IntakeCallType_ModifiedBy ON IntakeCallType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP1_SpecialtyID')
    CREATE INDEX IX_PatientSubscriberLog_PCP1_SpecialtyID ON PatientSubscriberLog(PCP1_SpecialtyID)

if not exists(select * from sysindexes where name = 'IX_Provider_StatusChangedBy')
    CREATE INDEX IX_Provider_StatusChangedBy ON Provider(StatusChangedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLocation_CreatedBy')
    CREATE INDEX IX_ProviderLocation_CreatedBy ON ProviderLocation(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_POCIntervention_GoalID')
    CREATE INDEX IX_POCIntervention_GoalID ON POCIntervention(GoalID)

if not exists(select * from sysindexes where name = 'IX_NetworkFocus_TerminatedBy')
    CREATE INDEX IX_NetworkFocus_TerminatedBy ON NetworkFocus(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_Organization_ParentOrganizationID')
    CREATE INDEX IX_Organization_ParentOrganizationID ON Organization(ParentOrganizationID)

if not exists(select * from sysindexes where name = 'IX_NetworkPlan_NetworkID')
    CREATE INDEX IX_NetworkPlan_NetworkID ON NetworkPlan(NetworkID)

if not exists(select * from sysindexes where name = 'IX_EventConsultingProvider_RoleID')
    CREATE INDEX IX_EventConsultingProvider_RoleID ON EventConsultingProvider(RoleID)

if not exists(select * from sysindexes where name = 'IX_Response_CreatedBy')
    CREATE INDEX IX_Response_CreatedBy ON Response(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP1_TypeID')
    CREATE INDEX IX_PatientSubscriberLog_PCP1_TypeID ON PatientSubscriberLog(PCP1_TypeID)

if not exists(select * from sysindexes where name = 'IX_Event_FacilityLocationID')
    CREATE INDEX IX_Event_FacilityLocationID ON Event(FacilityLocationID)

if not exists(select * from sysindexes where name = 'IX_LetterTemplate_FormTypeID')
    CREATE INDEX IX_LetterTemplate_FormTypeID ON LetterTemplate(FormTypeID)

if not exists(select * from sysindexes where name = 'IX_ContentOwner_ModifiedBy')
    CREATE INDEX IX_ContentOwner_ModifiedBy ON ContentOwner(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocation_LocationID')
    CREATE INDEX IX_FacilityLocation_LocationID ON FacilityLocation(LocationID)

if not exists(select * from sysindexes where name = 'IX_ProviderLocation_ModifiedBy')
    CREATE INDEX IX_ProviderLocation_ModifiedBy ON ProviderLocation(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationService_ProviderServiceTypeID')
    CREATE INDEX IX_ProviderLocationService_ProviderServiceTypeID ON ProviderLocationService(ProviderServiceTypeID)

if not exists(select * from sysindexes where name = 'IX_AssessmentQuestionnaireOrder_AssessmentGUID')
    CREATE INDEX IX_AssessmentQuestionnaireOrder_AssessmentGUID ON AssessmentQuestionnaireOrder(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_NetworkFocus_CreatedBy')
    CREATE INDEX IX_NetworkFocus_CreatedBy ON NetworkFocus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemTrigger_MORGId')
    CREATE INDEX IX_PackingListItemTrigger_MORGId ON PackingListItemTrigger(MORGId)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireOrganizationPlan_SORGID')
    CREATE INDEX IX_QuestionnaireOrganizationPlan_SORGID ON QuestionnaireOrganizationPlan(SORGID)

if not exists(select * from sysindexes where name = 'IX_Response_ModifiedBy')
    CREATE INDEX IX_Response_ModifiedBy ON Response(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP2_ID')
    CREATE INDEX IX_PatientSubscriberLog_PCP2_ID ON PatientSubscriberLog(PCP2_ID)

if not exists(select * from sysindexes where name = 'IX_Event_RefProviderLocationID')
    CREATE INDEX IX_Event_RefProviderLocationID ON Event(RefProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_ContentOwner_CreatedBy')
    CREATE INDEX IX_ContentOwner_CreatedBy ON ContentOwner(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLocation_TerminatedBy')
    CREATE INDEX IX_ProviderLocation_TerminatedBy ON ProviderLocation(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_ReferralRole_CreatedBy')
    CREATE INDEX IX_ReferralRole_CreatedBy ON ReferralRole(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemTrigger_ORGId')
    CREATE INDEX IX_PackingListItemTrigger_ORGId ON PackingListItemTrigger(ORGId)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationNetwork_NetworkID')
    CREATE INDEX IX_GroupPracticeLocationNetwork_NetworkID ON GroupPracticeLocationNetwork(NetworkID)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireOrganizationPlan_PlanID')
    CREATE INDEX IX_QuestionnaireOrganizationPlan_PlanID ON QuestionnaireOrganizationPlan(PlanID)

if not exists(select * from sysindexes where name = 'IX_OrganizationLevel_CreatedBy')
    CREATE INDEX IX_OrganizationLevel_CreatedBy ON OrganizationLevel(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_ReferralID')
    CREATE INDEX IX_ReferralDetail_ReferralID ON ReferralDetail(ReferralID)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP2_LocationID')
    CREATE INDEX IX_PatientSubscriberLog_PCP2_LocationID ON PatientSubscriberLog(PCP2_LocationID)

if not exists(select * from sysindexes where name = 'IX_Event_PCPGroupLocationID')
    CREATE INDEX IX_Event_PCPGroupLocationID ON Event(PCPGroupLocationID)

if not exists(select * from sysindexes where name = 'IX_PatientAuthorizer_CreatedBy')
    CREATE INDEX IX_PatientAuthorizer_CreatedBy ON PatientAuthorizer(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Question_MasterQuestionID')
    CREATE INDEX IX_Question_MasterQuestionID ON Question(MasterQuestionID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeProvider_CreatedBy')
    CREATE INDEX IX_GroupPracticeProvider_CreatedBy ON GroupPracticeProvider(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_POCIntervention_InterventionStatusID')
    CREATE INDEX IX_POCIntervention_InterventionStatusID ON POCIntervention(InterventionStatusID)

if not exists(select * from sysindexes where name = 'IX_ReferralRole_ModifiedBy')
    CREATE INDEX IX_ReferralRole_ModifiedBy ON ReferralRole(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemTrigger_SORGId')
    CREATE INDEX IX_PackingListItemTrigger_SORGId ON PackingListItemTrigger(SORGId)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationNetwork_NetworkID')
    CREATE INDEX IX_ProviderLocationNetwork_NetworkID ON ProviderLocationNetwork(NetworkID)

if not exists(select * from sysindexes where name = 'IX_OrganizationLevel_ModifiedBy')
    CREATE INDEX IX_OrganizationLevel_ModifiedBy ON OrganizationLevel(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_ReferralStatusID')
    CREATE INDEX IX_ReferralDetail_ReferralStatusID ON ReferralDetail(ReferralStatusID)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP2_SpecialtyID')
    CREATE INDEX IX_PatientSubscriberLog_PCP2_SpecialtyID ON PatientSubscriberLog(PCP2_SpecialtyID)

if not exists(select * from sysindexes where name = 'IX_PatientAuthorizer_ModifiedBy')
    CREATE INDEX IX_PatientAuthorizer_ModifiedBy ON PatientAuthorizer(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LogicAnswer_LogicID')
    CREATE INDEX IX_LogicAnswer_LogicID ON LogicAnswer(LogicID)

if not exists(select * from sysindexes where name = 'IX_POCDeficitPriority_CreatedBy')
    CREATE INDEX IX_POCDeficitPriority_CreatedBy ON POCDeficitPriority(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterTemplateMatrixField_CreatedBy')
    CREATE INDEX IX_LetterTemplateMatrixField_CreatedBy ON LetterTemplateMatrixField(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_MORGId')
    CREATE INDEX IX_AutoActivityRuleException_MORGId ON AutoActivityRuleException(MORGId)

if not exists(select * from sysindexes where name = 'IX_NetworkContact_NetworkID')
    CREATE INDEX IX_NetworkContact_NetworkID ON NetworkContact(NetworkID)

if not exists(select * from sysindexes where name = 'IX_MeasurementLevelOfDisease_MeasurementTypeID')
    CREATE INDEX IX_MeasurementLevelOfDisease_MeasurementTypeID ON MeasurementLevelOfDisease(MeasurementTypeID)

if not exists(select * from sysindexes where name = 'IX_OutcomeIndicator_CreatedBy')
    CREATE INDEX IX_OutcomeIndicator_CreatedBy ON OutcomeIndicator(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP2_TypeID')
    CREATE INDEX IX_PatientSubscriberLog_PCP2_TypeID ON PatientSubscriberLog(PCP2_TypeID)

if not exists(select * from sysindexes where name = 'IX_Plan_CreatedBy')
    CREATE INDEX IX_Plan_CreatedBy ON [dbo].[Plan](CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderFocus_ProviderFocusTypeID')
    CREATE INDEX IX_ProviderFocus_ProviderFocusTypeID ON ProviderFocus(ProviderFocusTypeID)

if not exists(select * from sysindexes where name = 'IX_Outcome_OutcomeRiskID')
    CREATE INDEX IX_Outcome_OutcomeRiskID ON Outcome(OutcomeRiskID)

if not exists(select * from sysindexes where name = 'IX_POCDeficitPriority_ModifiedBy')
    CREATE INDEX IX_POCDeficitPriority_ModifiedBy ON POCDeficitPriority(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterTemplateMatrixField_ModifiedBy')
    CREATE INDEX IX_LetterTemplateMatrixField_ModifiedBy ON LetterTemplateMatrixField(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_ORGId')
    CREATE INDEX IX_AutoActivityRuleException_ORGId ON AutoActivityRuleException(ORGId)

if not exists(select * from sysindexes where name = 'IX_OutcomeIndicator_ModifiedBy')
    CREATE INDEX IX_OutcomeIndicator_ModifiedBy ON OutcomeIndicator(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP3_ID')
    CREATE INDEX IX_PatientSubscriberLog_PCP3_ID ON PatientSubscriberLog(PCP3_ID)

if not exists(select * from sysindexes where name = 'IX_Plan_ModifiedBy')
    CREATE INDEX IX_Plan_ModifiedBy ON [dbo].[Plan](ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Outcome_ReferralDetailID')
    CREATE INDEX IX_Outcome_ReferralDetailID ON Outcome(ReferralDetailID)

if not exists(select * from sysindexes where name = 'IX_ManagementServicesRateType_CreatedBy')
    CREATE INDEX IX_ManagementServicesRateType_CreatedBy ON ManagementServicesRateType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PresentationGroupQuestion_CreatedBy')
    CREATE INDEX IX_PresentationGroupQuestion_CreatedBy ON PresentationGroupQuestion(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleException_SORGId')
    CREATE INDEX IX_AutoActivityRuleException_SORGId ON AutoActivityRuleException(SORGId)

if not exists(select * from sysindexes where name = 'IX_SpecialProcedureItem_SpecialProcedureId')
    CREATE INDEX IX_SpecialProcedureItem_SpecialProcedureId ON SpecialProcedureItem(SpecialProcedureId)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_UserID')
    CREATE INDEX IX_LetterPrintedQueue_UserID ON LetterPrintedQueue(UserID)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_UnitTypeID')
    CREATE INDEX IX_ReferralDetail_UnitTypeID ON ReferralDetail(UnitTypeID)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP3_LocationID')
    CREATE INDEX IX_PatientSubscriberLog_PCP3_LocationID ON PatientSubscriberLog(PCP3_LocationID)

if not exists(select * from sysindexes where name = 'IX_Event_PatientSubscriberLogID')
    CREATE INDEX IX_Event_PatientSubscriberLogID ON Event(PatientSubscriberLogID)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_StatusID')
    CREATE INDEX IX_PhysicianReview_StatusID ON PhysicianReview(StatusID)

if not exists(select * from sysindexes where name = 'IX_Plan_TerminatedBy')
    CREATE INDEX IX_Plan_TerminatedBy ON [dbo].[Plan](TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_PatientSubscriberLogID')
    CREATE INDEX IX_ReferralDetail_PatientSubscriberLogID ON ReferralDetail(PatientSubscriberLogID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocation_LocationID')
    CREATE INDEX IX_GroupPracticeLocation_LocationID ON GroupPracticeLocation(LocationID)

if not exists(select * from sysindexes where name = 'IX_ManagementServicesRateType_ModifiedBy')
    CREATE INDEX IX_ManagementServicesRateType_ModifiedBy ON ManagementServicesRateType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionnairePresentationGroupOrder_AssessmentQuestionnaireOrderID')
    CREATE INDEX IX_QuestionnairePresentationGroupOrder_AssessmentQuestionnaireOrderID ON QuestionnairePresentationGroupOrder(AssessmentQuestionnaireOrderID)

if not exists(select * from sysindexes where name = 'IX_PresentationGroupQuestion_ModifiedBy')
    CREATE INDEX IX_PresentationGroupQuestion_ModifiedBy ON PresentationGroupQuestion(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRule_MORGId')
    CREATE INDEX IX_AutoActivityRule_MORGId ON AutoActivityRule(MORGId)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_PlanSORGID')
    CREATE INDEX IX_PlanSorgLog_PlanSORGID ON PlanSorgLog(PlanSORGID)

if not exists(select * from sysindexes where name = 'IX_PatientMeasurement_MeasurementTypeID')
    CREATE INDEX IX_PatientMeasurement_MeasurementTypeID ON PatientMeasurement(MeasurementTypeID)

if not exists(select * from sysindexes where name = 'IX_WorkStatusStatus_ModifiedBy')
    CREATE INDEX IX_WorkStatusStatus_ModifiedBy ON WorkStatusStatus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP3_SpecialtyID')
    CREATE INDEX IX_PatientSubscriberLog_PCP3_SpecialtyID ON PatientSubscriberLog(PCP3_SpecialtyID)

if not exists(select * from sysindexes where name = 'IX_Event_PlanSorgLogID')
    CREATE INDEX IX_Event_PlanSorgLogID ON Event(PlanSorgLogID)

if not exists(select * from sysindexes where name = 'IX_OutcomeReason_CreatedBy')
    CREATE INDEX IX_OutcomeReason_CreatedBy ON OutcomeReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterReceiverType_CreatedBy')
    CREATE INDEX IX_LetterReceiverType_CreatedBy ON LetterReceiverType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_UserDefinedFieldPresentationValue_CreatedBy')
    CREATE INDEX IX_UserDefinedFieldPresentationValue_CreatedBy ON UserDefinedFieldPresentationValue(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRule_ORGId')
    CREATE INDEX IX_AutoActivityRule_ORGId ON AutoActivityRule(ORGId)

if not exists(select * from sysindexes where name = 'IX_PatientMeasurement_PatientID')
    CREATE INDEX IX_PatientMeasurement_PatientID ON PatientMeasurement(PatientID)

if not exists(select * from sysindexes where name = 'IX_WorkStatusStatus_CreatedBy')
    CREATE INDEX IX_WorkStatusStatus_CreatedBy ON WorkStatusStatus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PCP3_TypeID')
    CREATE INDEX IX_PatientSubscriberLog_PCP3_TypeID ON PatientSubscriberLog(PCP3_TypeID)

if not exists(select * from sysindexes where name = 'IX_OutcomeReason_ModifiedBy')
    CREATE INDEX IX_OutcomeReason_ModifiedBy ON OutcomeReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterReceiverType_ModifiedBy')
    CREATE INDEX IX_LetterReceiverType_ModifiedBy ON LetterReceiverType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionnairePresentationGroupOrder_PresentationGroupID')
    CREATE INDEX IX_QuestionnairePresentationGroupOrder_PresentationGroupID ON QuestionnairePresentationGroupOrder(PresentationGroupID)

if not exists(select * from sysindexes where name = 'IX_UserDefinedFieldPresentationValue_ModifiedBy')
    CREATE INDEX IX_UserDefinedFieldPresentationValue_ModifiedBy ON UserDefinedFieldPresentationValue(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRule_SORGId')
    CREATE INDEX IX_AutoActivityRule_SORGId ON AutoActivityRule(SORGId)

if not exists(select * from sysindexes where name = 'IX_BaseUnitOfMeasure_ModifiedBy')
    CREATE INDEX IX_BaseUnitOfMeasure_ModifiedBy ON BaseUnitOfMeasure(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_EligibilityID')
    CREATE INDEX IX_ReferralDetail_EligibilityID ON ReferralDetail(EligibilityID)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecision_PhysicianDecisionRoleID')
    CREATE INDEX IX_PhysicianDecision_PhysicianDecisionRoleID ON PhysicianDecision(PhysicianDecisionRoleID)

if not exists(select * from sysindexes where name = 'IX_CMSType_ModifiedBy')
    CREATE INDEX IX_CMSType_ModifiedBy ON CMSType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PlanUnitOfMeasure_CreatedBy')
    CREATE INDEX IX_PlanUnitOfMeasure_CreatedBy ON PlanUnitOfMeasure(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_BenefitServiceItem_ModifiedBy')
    CREATE INDEX IX_BenefitServiceItem_ModifiedBy ON BenefitServiceItem(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PlanSORG_SORGID')
    CREATE INDEX IX_PlanSORG_SORGID ON PlanSORG(SORGID)

if not exists(select * from sysindexes where name = 'IX_InterventionTemplate_InterventionTypeID')
    CREATE INDEX IX_InterventionTemplate_InterventionTypeID ON InterventionTemplate(InterventionTypeID)

if not exists(select * from sysindexes where name = 'IX_BaseUnitOfMeasure_CreatedBy')
    CREATE INDEX IX_BaseUnitOfMeasure_CreatedBy ON BaseUnitOfMeasure(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMSType_CreatedBy')
    CREATE INDEX IX_CMSType_CreatedBy ON CMSType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PlanUnitOfMeasure_ModifiedBy')
    CREATE INDEX IX_PlanUnitOfMeasure_ModifiedBy ON PlanUnitOfMeasure(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_BenefitServiceItem_CreatedBy')
    CREATE INDEX IX_BenefitServiceItem_CreatedBy ON BenefitServiceItem(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_OrganizationSynonym_OrganizationID')
    CREATE INDEX IX_OrganizationSynonym_OrganizationID ON OrganizationSynonym(OrganizationID)

if not exists(select * from sysindexes where name = 'IX_Outcome_CreatedBy')
    CREATE INDEX IX_Outcome_CreatedBy ON Outcome(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterGraphic_CreatedBy')
    CREATE INDEX IX_LetterGraphic_CreatedBy ON LetterGraphic(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PresentationGroup_CreatedBy')
    CREATE INDEX IX_PresentationGroup_CreatedBy ON PresentationGroup(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_InterventionTemplateLogic_InterventionTemplateID')
    CREATE INDEX IX_InterventionTemplateLogic_InterventionTemplateID ON InterventionTemplateLogic(InterventionTemplateID)

if not exists(select * from sysindexes where name = 'IX_LetterSet_CreatedBy')
    CREATE INDEX IX_LetterSet_CreatedBy ON LetterSet(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_OrganizationFocus_OrganizationID')
    CREATE INDEX IX_OrganizationFocus_OrganizationID ON OrganizationFocus(OrganizationID)

if not exists(select * from sysindexes where name = 'IX_Outcome_ModifiedBy')
    CREATE INDEX IX_Outcome_ModifiedBy ON Outcome(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberCoveragePCP_PCPLocationID')
    CREATE INDEX IX_PatientSubscriberCoveragePCP_PCPLocationID ON PatientSubscriberCoveragePCP(PCPLocationID)

if not exists(select * from sysindexes where name = 'IX_LetterGraphic_ModifiedBy')
    CREATE INDEX IX_LetterGraphic_ModifiedBy ON LetterGraphic(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationService_FacilityLocationID')
    CREATE INDEX IX_FacilityLocationService_FacilityLocationID ON FacilityLocationService(FacilityLocationID)

if not exists(select * from sysindexes where name = 'IX_PresentationGroup_ModifiedBy')
    CREATE INDEX IX_PresentationGroup_ModifiedBy ON PresentationGroup(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_InterventionTemplate_POCGoalTypeID')
    CREATE INDEX IX_InterventionTemplate_POCGoalTypeID ON InterventionTemplate(POCGoalTypeID)

if not exists(select * from sysindexes where name = 'IX_LetterSet_ModifiedBy')
    CREATE INDEX IX_LetterSet_ModifiedBy ON LetterSet(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupOrganizationLevel_OrganizationID')
    CREATE INDEX IX_SecurityGroupOrganizationLevel_OrganizationID ON SecurityGroupOrganizationLevel(OrganizationID)

if not exists(select * from sysindexes where name = 'IX_PatientMeasurement_AssessmentGUID')
    CREATE INDEX IX_PatientMeasurement_AssessmentGUID ON PatientMeasurement(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_UserID')
    CREATE INDEX IX_LetterNonPrintedQueue_UserID ON LetterNonPrintedQueue(UserID)

if not exists(select * from sysindexes where name = 'IX_EventReferralDiagnose_ReferralId')
    CREATE INDEX IX_EventReferralDiagnose_ReferralId ON EventReferralDiagnose(ReferralId)

if not exists(select * from sysindexes where name = 'IX_Organization_DefaultPlanSORGID')
    CREATE INDEX IX_Organization_DefaultPlanSORGID ON Organization(DefaultPlanSORGID)

if not exists(select * from sysindexes where name = 'IX_GuidelineCode_GuidelineSourceSetID')
    CREATE INDEX IX_GuidelineCode_GuidelineSourceSetID ON GuidelineCode(GuidelineSourceSetID)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_EventID')
    CREATE INDEX IX_LetterPrintedQueue_EventID ON LetterPrintedQueue(EventID)

if not exists(select * from sysindexes where name = 'IX_GuidelineProductCategoryLink_CreatedBy')
    CREATE INDEX IX_GuidelineProductCategoryLink_CreatedBy ON GuidelineProductCategoryLink(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationService_FacilityLocationServiceTypeID')
    CREATE INDEX IX_FacilityLocationService_FacilityLocationServiceTypeID ON FacilityLocationService(FacilityLocationServiceTypeID)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRule_CMSType')
    CREATE INDEX IX_AutoActivityRule_CMSType ON AutoActivityRule(CMSType)

if not exists(select * from sysindexes where name = 'IX_LengthOfStayRegion_CreatedBy')
    CREATE INDEX IX_LengthOfStayRegion_CreatedBy ON LengthOfStayRegion(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemTrigger_PlanId')
    CREATE INDEX IX_PackingListItemTrigger_PlanId ON PackingListItemTrigger(PlanId)

if not exists(select * from sysindexes where name = 'IX_PresentationGroupQuestionOrder_QuestionnairePresentationGroupOrderID')
    CREATE INDEX IX_PresentationGroupQuestionOrder_QuestionnairePresentationGroupOrderID ON PresentationGroupQuestionOrder(QuestionnairePresentationGroupOrderID)

if not exists(select * from sysindexes where name = 'IX_QuestionnairePresentationGroup_CreatedBy')
    CREATE INDEX IX_QuestionnairePresentationGroup_CreatedBy ON QuestionnairePresentationGroup(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_OrganizationContact_OrganizationID')
    CREATE INDEX IX_OrganizationContact_OrganizationID ON OrganizationContact(OrganizationID)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleType_ModifiedBy')
    CREATE INDEX IX_AutoActivityRuleType_ModifiedBy ON AutoActivityRuleType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_EventReferralProcedure_ReferralId')
    CREATE INDEX IX_EventReferralProcedure_ReferralId ON EventReferralProcedure(ReferralId)

if not exists(select * from sysindexes where name = 'IX_Organization_PrimarySynonymID')
    CREATE INDEX IX_Organization_PrimarySynonymID ON Organization(PrimarySynonymID)

if not exists(select * from sysindexes where name = 'IX_GuidelineCode_GuidelineID')
    CREATE INDEX IX_GuidelineCode_GuidelineID ON GuidelineCode(GuidelineID)

if not exists(select * from sysindexes where name = 'IX_GuidelineProductCategoryLink_ModifiedBy')
    CREATE INDEX IX_GuidelineProductCategoryLink_ModifiedBy ON GuidelineProductCategoryLink(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LengthOfStayRegion_ModifiedBy')
    CREATE INDEX IX_LengthOfStayRegion_ModifiedBy ON LengthOfStayRegion(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PresentationGroupQuestionOrder_PresentationGroupID')
    CREATE INDEX IX_PresentationGroupQuestionOrder_PresentationGroupID ON PresentationGroupQuestionOrder(PresentationGroupID)

if not exists(select * from sysindexes where name = 'IX_QuestionnairePresentationGroup_ModifiedBy')
    CREATE INDEX IX_QuestionnairePresentationGroup_ModifiedBy ON QuestionnairePresentationGroup(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_MORGId')
    CREATE INDEX IX_IntakeLog_MORGId ON IntakeLog(MORGId)

if not exists(select * from sysindexes where name = 'IX_AAUser_CreatedBy')
    CREATE INDEX IX_AAUser_CreatedBy ON AAUser(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRuleType_CreatedBy')
    CREATE INDEX IX_AutoActivityRuleType_CreatedBy ON AutoActivityRuleType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_PatientID')
    CREATE INDEX IX_LetterPrintedQueue_PatientID ON LetterPrintedQueue(PatientID)

if not exists(select * from sysindexes where name = 'IX_POCIntervention_ActivityID')
    CREATE INDEX IX_POCIntervention_ActivityID ON POCIntervention(ActivityID)

if not exists(select * from sysindexes where name = 'IX_PatientCOB_PatientID')
    CREATE INDEX IX_PatientCOB_PatientID ON PatientCOB(PatientID)

if not exists(select * from sysindexes where name = 'IX_NamePrefix_CreatedBy')
    CREATE INDEX IX_NamePrefix_CreatedBy ON NamePrefix(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Language_CreatedBy')
    CREATE INDEX IX_Language_CreatedBy ON Language(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AnswerRange_CreatedBy')
    CREATE INDEX IX_AnswerRange_CreatedBy ON AnswerRange(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_SORGId')
    CREATE INDEX IX_IntakeLog_SORGId ON IntakeLog(SORGId)

if not exists(select * from sysindexes where name = 'IX_AAUser_ModifiedBy')
    CREATE INDEX IX_AAUser_ModifiedBy ON AAUser(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientMeasurement_ContentOwnerID')
    CREATE INDEX IX_PatientMeasurement_ContentOwnerID ON PatientMeasurement(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_AnswerType_CreatedBy')
    CREATE INDEX IX_AnswerType_CreatedBy ON AnswerType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_MatrixTypeID')
    CREATE INDEX IX_LetterPrintedQueue_MatrixTypeID ON LetterPrintedQueue(MatrixTypeID)

if not exists(select * from sysindexes where name = 'IX_Activity_InterventionID')
    CREATE INDEX IX_Activity_InterventionID ON Activity(InterventionID)

if not exists(select * from sysindexes where name = 'IX_PatientCOB_OtherInsuranceType')
    CREATE INDEX IX_PatientCOB_OtherInsuranceType ON PatientCOB(OtherInsuranceType)

if not exists(select * from sysindexes where name = 'IX_NamePrefix_ModifiedBy')
    CREATE INDEX IX_NamePrefix_ModifiedBy ON NamePrefix(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Language_ModifiedBy')
    CREATE INDEX IX_Language_ModifiedBy ON Language(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AnswerRange_ModifiedBy')
    CREATE INDEX IX_AnswerRange_ModifiedBy ON AnswerRange(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_ORGId')
    CREATE INDEX IX_IntakeLog_ORGId ON IntakeLog(ORGId)

if not exists(select * from sysindexes where name = 'IX_AAUser_CreatedBy')
    CREATE INDEX IX_AAUser_CreatedBy ON AAUser(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AnswerType_ModifiedBy')
    CREATE INDEX IX_AnswerType_ModifiedBy ON AnswerType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ICD9Keyword_ICD9Code')
    CREATE INDEX IX_ICD9Keyword_ICD9Code ON ICD9Keyword(ICD9Code)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_LetterTemplateID')
    CREATE INDEX IX_LetterPrintedQueue_LetterTemplateID ON LetterPrintedQueue(LetterTemplateID)

if not exists(select * from sysindexes where name = 'IX_CMSStatusType_ModifiedBy')
    CREATE INDEX IX_CMSStatusType_ModifiedBy ON CMSStatusType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_UserDefinedField_UserDefinedEntityID')
    CREATE INDEX IX_UserDefinedField_UserDefinedEntityID ON UserDefinedField(UserDefinedEntityID)

if not exists(select * from sysindexes where name = 'IX_FacilityFocus_CreatedBy')
    CREATE INDEX IX_FacilityFocus_CreatedBy ON FacilityFocus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationNetworkHistory_TerminatedBy')
    CREATE INDEX IX_ProviderLocationNetworkHistory_TerminatedBy ON ProviderLocationNetworkHistory(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_Note_PhysicianReviewDetailID')
    CREATE INDEX IX_Note_PhysicianReviewDetailID ON Note(PhysicianReviewDetailID)

if not exists(select * from sysindexes where name = 'IX_LevelOfDiseaseType_CreatedBy')
    CREATE INDEX IX_LevelOfDiseaseType_CreatedBy ON LevelOfDiseaseType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceItem_CreatedBy')
    CREATE INDEX IX_ManagementServiceItem_CreatedBy ON ManagementServiceItem(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Note_ReferralId')
    CREATE INDEX IX_Note_ReferralId ON Note(ReferralId)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecision_PhysicianDecisionReasonID')
    CREATE INDEX IX_PhysicianDecision_PhysicianDecisionReasonID ON PhysicianDecision(PhysicianDecisionReasonID)

if not exists(select * from sysindexes where name = 'IX_HCPCSKeyword_HCPCSCode')
    CREATE INDEX IX_HCPCSKeyword_HCPCSCode ON HCPCSKeyword(HCPCSCode)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_ReceiverTypeID')
    CREATE INDEX IX_LetterPrintedQueue_ReceiverTypeID ON LetterPrintedQueue(ReceiverTypeID)

if not exists(select * from sysindexes where name = 'IX_CMSStatusType_CreatedBy')
    CREATE INDEX IX_CMSStatusType_CreatedBy ON CMSStatusType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_UserDefinedField_UserDefinedFieldPresentationTypeID')
    CREATE INDEX IX_UserDefinedField_UserDefinedFieldPresentationTypeID ON UserDefinedField(UserDefinedFieldPresentationTypeID)

if not exists(select * from sysindexes where name = 'IX_FacilityFocus_TerminatedBy')
    CREATE INDEX IX_FacilityFocus_TerminatedBy ON FacilityFocus(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationNetworkHistory_TerminatedBy')
    CREATE INDEX IX_ProviderLocationNetworkHistory_TerminatedBy ON ProviderLocationNetworkHistory(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_Note_PhysicianRevIndPhyReviewID')
    CREATE INDEX IX_Note_PhysicianRevIndPhyReviewID ON Note(PhysicianRevIndPhyReviewID)

if not exists(select * from sysindexes where name = 'IX_LevelOfDiseaseType_ModifiedBy')
    CREATE INDEX IX_LevelOfDiseaseType_ModifiedBy ON LevelOfDiseaseType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceItem_ModifiedBy')
    CREATE INDEX IX_ManagementServiceItem_ModifiedBy ON ManagementServiceItem(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ICD9toCPTMapping_ICD9Code')
    CREATE INDEX IX_ICD9toCPTMapping_ICD9Code ON ICD9toCPTMapping(ICD9Code)

if not exists(select * from sysindexes where name = 'IX_LetterCustomText_QueueID')
    CREATE INDEX IX_LetterCustomText_QueueID ON LetterCustomText(QueueID)

if not exists(select * from sysindexes where name = 'IX_PatientFocusHistory_CreatedBy')
    CREATE INDEX IX_PatientFocusHistory_CreatedBy ON PatientFocusHistory(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PlanPayorHEDISType_CreatedBy')
    CREATE INDEX IX_PlanPayorHEDISType_CreatedBy ON PlanPayorHEDISType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_CMSStatusHistory_CMSRiskId')
    CREATE INDEX IX_CMSStatusHistory_CMSRiskId ON CMSStatusHistory(CMSRiskId)

if not exists(select * from sysindexes where name = 'IX_ReferralAuthorizationDecision_CreatedBy')
    CREATE INDEX IX_ReferralAuthorizationDecision_CreatedBy ON ReferralAuthorizationDecision(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemSent_AssessmentGUID')
    CREATE INDEX IX_PackingListItemSent_AssessmentGUID ON PackingListItemSent(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_Explanation_CreatedBy')
    CREATE INDEX IX_Explanation_CreatedBy ON Explanation(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceItem_TerminatedBy')
    CREATE INDEX IX_ManagementServiceItem_TerminatedBy ON ManagementServiceItem(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_ICD9toCPTMapping_CPTCode')
    CREATE INDEX IX_ICD9toCPTMapping_CPTCode ON ICD9toCPTMapping(CPTCode)

if not exists(select * from sysindexes where name = 'IX_Patient_PrimaryCOBId')
    CREATE INDEX IX_Patient_PrimaryCOBId ON Patient(PrimaryCOBId)

if not exists(select * from sysindexes where name = 'IX_CMSRisk_ModifiedBy')
    CREATE INDEX IX_CMSRisk_ModifiedBy ON CMSRisk(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Subscriber_NamePrefixId')
    CREATE INDEX IX_Subscriber_NamePrefixId ON Subscriber(NamePrefixId)

if not exists(select * from sysindexes where name = 'IX_PlanPayorHEDISType_ModifiedBy')
    CREATE INDEX IX_PlanPayorHEDISType_ModifiedBy ON PlanPayorHEDISType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ReferralAuthorizationDecision_ModifiedBy')
    CREATE INDEX IX_ReferralAuthorizationDecision_ModifiedBy ON ReferralAuthorizationDecision(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Explanation_ModifiedBy')
    CREATE INDEX IX_Explanation_ModifiedBy ON Explanation(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ReferralDetail_ReferralAuthorizationDecisionID')
    CREATE INDEX IX_ReferralDetail_ReferralAuthorizationDecisionID ON ReferralDetail(ReferralAuthorizationDecisionID)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceItem_ModifiedBy')
    CREATE INDEX IX_ManagementServiceItem_ModifiedBy ON ManagementServiceItem(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ProblemReferral_ReferralId')
    CREATE INDEX IX_ProblemReferral_ReferralId ON ProblemReferral(ReferralId)

if not exists(select * from sysindexes where name = 'IX_GuidelineCategory_GuidelineSourceSetID')
    CREATE INDEX IX_GuidelineCategory_GuidelineSourceSetID ON GuidelineCategory(GuidelineSourceSetID)

if not exists(select * from sysindexes where name = 'IX_LetterReferral_QueueID')
    CREATE INDEX IX_LetterReferral_QueueID ON LetterReferral(QueueID)

if not exists(select * from sysindexes where name = 'IX_CMSRisk_CreatedBy')
    CREATE INDEX IX_CMSRisk_CreatedBy ON CMSRisk(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_InsuranceType_CreatedBy')
    CREATE INDEX IX_InsuranceType_CreatedBy ON InsuranceType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ContactRole_CreatedBy')
    CREATE INDEX IX_ContactRole_CreatedBy ON ContactRole(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_POCGoal_CreatedBy')
    CREATE INDEX IX_POCGoal_CreatedBy ON POCGoal(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementServiceItem_TerminatedBy')
    CREATE INDEX IX_ManagementServiceItem_TerminatedBy ON ManagementServiceItem(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_ProblemReferral_ReferralId')
    CREATE INDEX IX_ProblemReferral_ReferralId ON ProblemReferral(ReferralId)

if not exists(select * from sysindexes where name = 'IX_GuidelineIndicator_GuidelineID')
    CREATE INDEX IX_GuidelineIndicator_GuidelineID ON GuidelineIndicator(GuidelineID)

if not exists(select * from sysindexes where name = 'IX_PlanNote_CreatedBy')
    CREATE INDEX IX_PlanNote_CreatedBy ON PlanNote(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Subscriber_AddressID')
    CREATE INDEX IX_Subscriber_AddressID ON Subscriber(AddressID)

if not exists(select * from sysindexes where name = 'IX_InsuranceType_ModifiedBy')
    CREATE INDEX IX_InsuranceType_ModifiedBy ON InsuranceType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ContactRole_ModifiedBy')
    CREATE INDEX IX_ContactRole_ModifiedBy ON ContactRole(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationNetworkHistory_FacilityLocationNetworkHistoryID')
    CREATE INDEX IX_FacilityLocationNetworkHistory_FacilityLocationNetworkHistoryID ON FacilityLocationNetworkHistory(FacilityLocationNetworkHistoryID)

if not exists(select * from sysindexes where name = 'IX_POCGoal_ModifiedBy')
    CREATE INDEX IX_POCGoal_ModifiedBy ON POCGoal(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_NetworkType_CreatedBy')
    CREATE INDEX IX_NetworkType_CreatedBy ON NetworkType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GuidelineIndicator_GuidelineSourceSetID')
    CREATE INDEX IX_GuidelineIndicator_GuidelineSourceSetID ON GuidelineIndicator(GuidelineSourceSetID)

if not exists(select * from sysindexes where name = 'IX_PlanNote_ModifiedBy')
    CREATE INDEX IX_PlanNote_ModifiedBy ON PlanNote(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientLevelOfDisease_CreatedBy')
    CREATE INDEX IX_PatientLevelOfDisease_CreatedBy ON PatientLevelOfDisease(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationNetworkHistory_TerminatedBy')
    CREATE INDEX IX_FacilityLocationNetworkHistory_TerminatedBy ON FacilityLocationNetworkHistory(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_ActivitySubType_CreatedBy')
    CREATE INDEX IX_ActivitySubType_CreatedBy ON ActivitySubType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_NetworkType_ModifiedBy')
    CREATE INDEX IX_NetworkType_ModifiedBy ON NetworkType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_CPTKeyword_CPTCode')
    CREATE INDEX IX_CPTKeyword_CPTCode ON CPTKeyword(CPTCode)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_LetterTemplateID')
    CREATE INDEX IX_LetterNonPrintedQueue_LetterTemplateID ON LetterNonPrintedQueue(LetterTemplateID)

if not exists(select * from sysindexes where name = 'IX_CMSPhase_ModifiedBy')
    CREATE INDEX IX_CMSPhase_ModifiedBy ON CMSPhase(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientLevelOfDisease_ModifiedBy')
    CREATE INDEX IX_PatientLevelOfDisease_ModifiedBy ON PatientLevelOfDisease(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationNetworkHistory_TerminatedBy')
    CREATE INDEX IX_FacilityLocationNetworkHistory_TerminatedBy ON FacilityLocationNetworkHistory(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_AssessmentQuestionnaire_ContentOwnerID')
    CREATE INDEX IX_AssessmentQuestionnaire_ContentOwnerID ON AssessmentQuestionnaire(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationNetworkHistory_ProviderLocationNetworkHistoryID')
    CREATE INDEX IX_ProviderLocationNetworkHistory_ProviderLocationNetworkHistoryID ON ProviderLocationNetworkHistory(ProviderLocationNetworkHistoryID)

if not exists(select * from sysindexes where name = 'IX_ActivitySubType_ModifiedBy')
    CREATE INDEX IX_ActivitySubType_ModifiedBy ON ActivitySubType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianRequest_PhysicianReviewRequestDetailTypeID')
    CREATE INDEX IX_PhysicianRequest_PhysicianReviewRequestDetailTypeID ON PhysicianRequest(PhysicianReviewRequestDetailTypeID)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecision_CreatedBy')
    CREATE INDEX IX_PhysicianDecision_CreatedBy ON PhysicianDecision(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_ReferralUnitID')
    CREATE INDEX IX_LetterMatrix_ReferralUnitID ON LetterMatrix(ReferralUnitID)

if not exists(select * from sysindexes where name = 'IX_DentalKeyword_DentalCode')
    CREATE INDEX IX_DentalKeyword_DentalCode ON DentalKeyword(DentalCode)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_ReceiverTypeID')
    CREATE INDEX IX_LetterNonPrintedQueue_ReceiverTypeID ON LetterNonPrintedQueue(ReceiverTypeID)

if not exists(select * from sysindexes where name = 'IX_CMSPhase_CreatedBy')
    CREATE INDEX IX_CMSPhase_CreatedBy ON CMSPhase(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_SubscriberId')
    CREATE INDEX IX_IntakeLog_SubscriberId ON IntakeLog(SubscriberId)

if not exists(select * from sysindexes where name = 'IX_InsuranceStatus_CreatedBy')
    CREATE INDEX IX_InsuranceStatus_CreatedBy ON InsuranceStatus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemSent_CreatedBy')
    CREATE INDEX IX_PackingListItemSent_CreatedBy ON PackingListItemSent(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationNetworkHistory_TerminatedBy')
    CREATE INDEX IX_GroupPracticeLocationNetworkHistory_TerminatedBy ON GroupPracticeLocationNetworkHistory(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecision_PhysicianReviewRequestDetailTypeID')
    CREATE INDEX IX_PhysicianDecision_PhysicianReviewRequestDetailTypeID ON PhysicianDecision(PhysicianReviewRequestDetailTypeID)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecision_ModifiedBy')
    CREATE INDEX IX_PhysicianDecision_ModifiedBy ON PhysicianDecision(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupUser_CreatedBy')
    CREATE INDEX IX_SecurityGroupUser_CreatedBy ON SecurityGroupUser(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_UserDefinedFieldPresentationValue_UserDefinedFieldID')
    CREATE INDEX IX_UserDefinedFieldPresentationValue_UserDefinedFieldID ON UserDefinedFieldPresentationValue(UserDefinedFieldID)

if not exists(select * from sysindexes where name = 'IX_AnswerRange_ContentOwnerID')
    CREATE INDEX IX_AnswerRange_ContentOwnerID ON AnswerRange(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_InsuranceStatus_ModifiedBy')
    CREATE INDEX IX_InsuranceStatus_ModifiedBy ON InsuranceStatus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemSent_CreatedBy')
    CREATE INDEX IX_PackingListItemSent_CreatedBy ON PackingListItemSent(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_MedicalEquipment_CreatedBy')
    CREATE INDEX IX_MedicalEquipment_CreatedBy ON MedicalEquipment(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_WCUnit_ModifiedBy')
    CREATE INDEX IX_WCUnit_ModifiedBy ON WCUnit(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Guideline_GuidelineSourceSetID')
    CREATE INDEX IX_Guideline_GuidelineSourceSetID ON Guideline(GuidelineSourceSetID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupUser_ModifiedBy')
    CREATE INDEX IX_SecurityGroupUser_ModifiedBy ON SecurityGroupUser(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_SubscriberId')
    CREATE INDEX IX_PatientSubscriberLog_SubscriberId ON PatientSubscriberLog(SubscriberId)

if not exists(select * from sysindexes where name = 'IX_PlanNoteType_CreatedBy')
    CREATE INDEX IX_PlanNoteType_CreatedBy ON PlanNoteType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemSent_AssessmentGUID')
    CREATE INDEX IX_PackingListItemSent_AssessmentGUID ON PackingListItemSent(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireType_CreatedBy')
    CREATE INDEX IX_QuestionnaireType_CreatedBy ON QuestionnaireType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_MedicalEquipment_ModifiedBy')
    CREATE INDEX IX_MedicalEquipment_ModifiedBy ON MedicalEquipment(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCUnit_CreatedBy')
    CREATE INDEX IX_WCUnit_CreatedBy ON WCUnit(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_NetworkFocus_NetworkFocusTypeID')
    CREATE INDEX IX_NetworkFocus_NetworkFocusTypeID ON NetworkFocus(NetworkFocusTypeID)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_EventID')
    CREATE INDEX IX_LetterNonPrintedQueue_EventID ON LetterNonPrintedQueue(EventID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupUser_UserID')
    CREATE INDEX IX_SecurityGroupUser_UserID ON SecurityGroupUser(UserID)

if not exists(select * from sysindexes where name = 'IX_PatientLevelOfDisease_AnswerRangeID')
    CREATE INDEX IX_PatientLevelOfDisease_AnswerRangeID ON PatientLevelOfDisease(AnswerRangeID)

if not exists(select * from sysindexes where name = 'IX_PlanNoteType_ModifiedBy')
    CREATE INDEX IX_PlanNoteType_ModifiedBy ON PlanNoteType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireType_ModifiedBy')
    CREATE INDEX IX_QuestionnaireType_ModifiedBy ON QuestionnaireType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ActivityType_CreatedBy')
    CREATE INDEX IX_ActivityType_CreatedBy ON ActivityType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityInitializationFieldName_ModifiedBy')
    CREATE INDEX IX_AutoActivityInitializationFieldName_ModifiedBy ON AutoActivityInitializationFieldName(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityRule_StateId')
    CREATE INDEX IX_AutoActivityRule_StateId ON AutoActivityRule(StateId)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberCoverage_SubscriberCoverageId')
    CREATE INDEX IX_PatientSubscriberCoverage_SubscriberCoverageId ON PatientSubscriberCoverage(SubscriberCoverageId)

if not exists(select * from sysindexes where name = 'IX_GuidelineIndicatorTip_GuidelineIndicatorID')
    CREATE INDEX IX_GuidelineIndicatorTip_GuidelineIndicatorID ON GuidelineIndicatorTip(GuidelineIndicatorID)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_MatrixTypeID')
    CREATE INDEX IX_LetterNonPrintedQueue_MatrixTypeID ON LetterNonPrintedQueue(MatrixTypeID)

if not exists(select * from sysindexes where name = 'IX_CMSIntensity_ModifiedBy')
    CREATE INDEX IX_CMSIntensity_ModifiedBy ON CMSIntensity(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationNetwork_FacilityLocationID')
    CREATE INDEX IX_FacilityLocationNetwork_FacilityLocationID ON FacilityLocationNetwork(FacilityLocationID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeType_ModifiedBy')
    CREATE INDEX IX_GroupPracticeType_ModifiedBy ON GroupPracticeType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_UserDefinedField_CreatedBy')
    CREATE INDEX IX_UserDefinedField_CreatedBy ON UserDefinedField(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ActivityType_ModifiedBy')
    CREATE INDEX IX_ActivityType_ModifiedBy ON ActivityType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityInitializationFieldName_CreatedBy')
    CREATE INDEX IX_AutoActivityInitializationFieldName_CreatedBy ON AutoActivityInitializationFieldName(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GuidelineIndicatorTip_GuidelineSourceSetID')
    CREATE INDEX IX_GuidelineIndicatorTip_GuidelineSourceSetID ON GuidelineIndicatorTip(GuidelineSourceSetID)

if not exists(select * from sysindexes where name = 'IX_CMSIntensity_CreatedBy')
    CREATE INDEX IX_CMSIntensity_CreatedBy ON CMSIntensity(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Outcome_UserDefinedID')
    CREATE INDEX IX_Outcome_UserDefinedID ON Outcome(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeType_CreatedBy')
    CREATE INDEX IX_GroupPracticeType_CreatedBy ON GroupPracticeType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_UserDefinedField_ModifiedBy')
    CREATE INDEX IX_UserDefinedField_ModifiedBy ON UserDefinedField(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_CreatedBy')
    CREATE INDEX IX_ClinicalReviewDecision_CreatedBy ON ClinicalReviewDecision(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_TriggerList_CreatedBy')
    CREATE INDEX IX_TriggerList_CreatedBy ON TriggerList(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_VitalNumberResponse_QuestionID')
    CREATE INDEX IX_VitalNumberResponse_QuestionID ON VitalNumberResponse(QuestionID)

if not exists(select * from sysindexes where name = 'IX_PhysicianRequest_CreatedBy')
    CREATE INDEX IX_PhysicianRequest_CreatedBy ON PhysicianRequest(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_UserDefinedID')
    CREATE INDEX IX_ClinicalReviewDecision_UserDefinedID ON ClinicalReviewDecision(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupOrganizationLevel_OrganizationTypeID')
    CREATE INDEX IX_SecurityGroupOrganizationLevel_OrganizationTypeID ON SecurityGroupOrganizationLevel(OrganizationTypeID)

if not exists(select * from sysindexes where name = 'IX_PatientAllergy_CreatedBy')
    CREATE INDEX IX_PatientAllergy_CreatedBy ON PatientAllergy(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ComplexDataValue_CreatedBy')
    CREATE INDEX IX_ComplexDataValue_CreatedBy ON ComplexDataValue(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_ModifiedBy')
    CREATE INDEX IX_ClinicalReviewDecision_ModifiedBy ON ClinicalReviewDecision(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_TriggerList_ModifiedBy')
    CREATE INDEX IX_TriggerList_ModifiedBy ON TriggerList(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PlanSORG_GuidelineSourceSet')
    CREATE INDEX IX_PlanSORG_GuidelineSourceSet ON PlanSORG(GuidelineSourceSet)

if not exists(select * from sysindexes where name = 'IX_EmailParagraph_EmailID')
    CREATE INDEX IX_EmailParagraph_EmailID ON EmailParagraph(EmailID)

if not exists(select * from sysindexes where name = 'IX_PhysicianRequest_ModifiedBy')
    CREATE INDEX IX_PhysicianRequest_ModifiedBy ON PhysicianRequest(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Provider_UserDefinedID')
    CREATE INDEX IX_Provider_UserDefinedID ON Provider(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_PatientAllergy_ModifiedBy')
    CREATE INDEX IX_PatientAllergy_ModifiedBy ON PatientAllergy(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ComplexDataValue_ModifiedBy')
    CREATE INDEX IX_ComplexDataValue_ModifiedBy ON ComplexDataValue(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_POCGoalOutcome_CreatedBy')
    CREATE INDEX IX_POCGoalOutcome_CreatedBy ON POCGoalOutcome(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationNetwork_TerminatedBy')
    CREATE INDEX IX_GroupPracticeLocationNetwork_TerminatedBy ON GroupPracticeLocationNetwork(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_WorkersComp_StateClaimFiledInId')
    CREATE INDEX IX_WorkersComp_StateClaimFiledInId ON WorkersComp(StateClaimFiledInId)

if not exists(select * from sysindexes where name = 'IX_EmailParagraph_TextResourceID')
    CREATE INDEX IX_EmailParagraph_TextResourceID ON EmailParagraph(TextResourceID)

if not exists(select * from sysindexes where name = 'IX_NoteType_CreatedBy')
    CREATE INDEX IX_NoteType_CreatedBy ON NoteType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Facility_UserDefinedID')
    CREATE INDEX IX_Facility_UserDefinedID ON Facility(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_Answer_CreatedBy')
    CREATE INDEX IX_Answer_CreatedBy ON Answer(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Response_AnswerTypeID')
    CREATE INDEX IX_Response_AnswerTypeID ON Response(AnswerTypeID)

if not exists(select * from sysindexes where name = 'IX_WorkStatus_CreatedBy')
    CREATE INDEX IX_WorkStatus_CreatedBy ON WorkStatus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_POCGoalOutcome_ModifiedBy')
    CREATE INDEX IX_POCGoalOutcome_ModifiedBy ON POCGoalOutcome(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationNetwork_CreatedBy')
    CREATE INDEX IX_GroupPracticeLocationNetwork_CreatedBy ON GroupPracticeLocationNetwork(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_FacilityStateID')
    CREATE INDEX IX_LetterMatrix_FacilityStateID ON LetterMatrix(FacilityStateID)

if not exists(select * from sysindexes where name = 'IX_NoteType_ModifiedBy')
    CREATE INDEX IX_NoteType_ModifiedBy ON NoteType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Patient_NamePrefixId')
    CREATE INDEX IX_Patient_NamePrefixId ON Patient(NamePrefixId)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_UserDefinedID')
    CREATE INDEX IX_PhysicianReview_UserDefinedID ON PhysicianReview(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_ReferralAppointment_ReferralDetailID')
    CREATE INDEX IX_ReferralAppointment_ReferralDetailID ON ReferralAppointment(ReferralDetailID)

if not exists(select * from sysindexes where name = 'IX_Answer_ModifiedBy')
    CREATE INDEX IX_Answer_ModifiedBy ON Answer(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WorkStatus_ModifiedBy')
    CREATE INDEX IX_WorkStatus_ModifiedBy ON WorkStatus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AssessmentParagraph_CreatedBy')
    CREATE INDEX IX_AssessmentParagraph_CreatedBy ON AssessmentParagraph(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterDecision_QueueID')
    CREATE INDEX IX_LetterDecision_QueueID ON LetterDecision(QueueID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationNetwork_ModifiedBy')
    CREATE INDEX IX_GroupPracticeLocationNetwork_ModifiedBy ON GroupPracticeLocationNetwork(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_GuidelineIndicatorTip_CreatedBy')
    CREATE INDEX IX_GuidelineIndicatorTip_CreatedBy ON GuidelineIndicatorTip(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocation_UserDefinedID')
    CREATE INDEX IX_FacilityLocation_UserDefinedID ON FacilityLocation(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_EventReferralProcedure_LinkedPxType')
    CREATE INDEX IX_EventReferralProcedure_LinkedPxType ON EventReferralProcedure(LinkedPxType)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeFocus_GroupPracticeFocusTypeID')
    CREATE INDEX IX_GroupPracticeFocus_GroupPracticeFocusTypeID ON GroupPracticeFocus(GroupPracticeFocusTypeID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeServiceType_ModifiedBy')
    CREATE INDEX IX_GroupPracticeServiceType_ModifiedBy ON GroupPracticeServiceType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrixField_CreatedBy')
    CREATE INDEX IX_LetterMatrixField_CreatedBy ON LetterMatrixField(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AssessmentParagraph_ModifiedBy')
    CREATE INDEX IX_AssessmentParagraph_ModifiedBy ON AssessmentParagraph(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupFALevel_CreatedBy')
    CREATE INDEX IX_SecurityGroupFALevel_CreatedBy ON SecurityGroupFALevel(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_EventID')
    CREATE INDEX IX_LetterDraftQueue_EventID ON LetterDraftQueue(EventID)

if not exists(select * from sysindexes where name = 'IX_GuidelineIndicatorTip_ModifiedBy')
    CREATE INDEX IX_GuidelineIndicatorTip_ModifiedBy ON GuidelineIndicatorTip(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Patient_LanguageID')
    CREATE INDEX IX_Patient_LanguageID ON Patient(LanguageID)

if not exists(select * from sysindexes where name = 'IX_GroupPractice_UserDefinedID')
    CREATE INDEX IX_GroupPractice_UserDefinedID ON GroupPractice(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_OrganizationFocus_OrgFocusCodeID')
    CREATE INDEX IX_OrganizationFocus_OrgFocusCodeID ON OrganizationFocus(OrgFocusCodeID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeServiceType_CreatedBy')
    CREATE INDEX IX_GroupPracticeServiceType_CreatedBy ON GroupPracticeServiceType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrixField_ModifiedBy')
    CREATE INDEX IX_LetterMatrixField_ModifiedBy ON LetterMatrixField(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientMedication_CreatedBy')
    CREATE INDEX IX_PatientMedication_CreatedBy ON PatientMedication(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupFALevel_ModifiedBy')
    CREATE INDEX IX_SecurityGroupFALevel_ModifiedBy ON SecurityGroupFALevel(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PlanSORG_PayorGroupID')
    CREATE INDEX IX_PlanSORG_PayorGroupID ON PlanSORG(PayorGroupID)

if not exists(select * from sysindexes where name = 'IX_CMSAcuity_ModifiedBy')
    CREATE INDEX IX_CMSAcuity_ModifiedBy ON CMSAcuity(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Network_UserDefinedID')
    CREATE INDEX IX_Network_UserDefinedID ON Network(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_TeamUser_CreatedBy')
    CREATE INDEX IX_TeamUser_CreatedBy ON TeamUser(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireLetterMatrix_CreatedBy')
    CREATE INDEX IX_QuestionnaireLetterMatrix_CreatedBy ON QuestionnaireLetterMatrix(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientMedication_ModifiedBy')
    CREATE INDEX IX_PatientMedication_ModifiedBy ON PatientMedication(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_NetworkFocusType_CreatedBy')
    CREATE INDEX IX_NetworkFocusType_CreatedBy ON NetworkFocusType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_ReferralDetailID')
    CREATE INDEX IX_LetterNonPrintedQueue_ReferralDetailID ON LetterNonPrintedQueue(ReferralDetailID)

if not exists(select * from sysindexes where name = 'IX_CMSAcuity_CreatedBy')
    CREATE INDEX IX_CMSAcuity_CreatedBy ON CMSAcuity(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLocation_UserDefinedID')
    CREATE INDEX IX_ProviderLocation_UserDefinedID ON ProviderLocation(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupDiagnosisLevel_GroupID')
    CREATE INDEX IX_SecurityGroupDiagnosisLevel_GroupID ON SecurityGroupDiagnosisLevel(GroupID)

if not exists(select * from sysindexes where name = 'IX_TeamUser_ModifiedBy')
    CREATE INDEX IX_TeamUser_ModifiedBy ON TeamUser(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireLetterMatrix_ModifiedBy')
    CREATE INDEX IX_QuestionnaireLetterMatrix_ModifiedBy ON QuestionnaireLetterMatrix(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_TeamUser_TeamId')
    CREATE INDEX IX_TeamUser_TeamId ON TeamUser(TeamId)

if not exists(select * from sysindexes where name = 'IX_ActivityCompletion_CreatedBy')
    CREATE INDEX IX_ActivityCompletion_CreatedBy ON ActivityCompletion(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_NetworkFocusType_ModifiedBy')
    CREATE INDEX IX_NetworkFocusType_ModifiedBy ON NetworkFocusType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_ReferralDetailID')
    CREATE INDEX IX_LetterPrintedQueue_ReferralDetailID ON LetterPrintedQueue(ReferralDetailID)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_ReceiverTypeID')
    CREATE INDEX IX_LetterDraftQueue_ReceiverTypeID ON LetterDraftQueue(ReceiverTypeID)

if not exists(select * from sysindexes where name = 'IX_Question_CreatedBy')
    CREATE INDEX IX_Question_CreatedBy ON Question(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocation_UserDefinedID')
    CREATE INDEX IX_GroupPracticeLocation_UserDefinedID ON GroupPracticeLocation(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_PhysicianReview_ReferralDetailID')
    CREATE INDEX IX_PhysicianReview_ReferralDetailID ON PhysicianReview(ReferralDetailID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupProcedureLevel_GroupID')
    CREATE INDEX IX_SecurityGroupProcedureLevel_GroupID ON SecurityGroupProcedureLevel(GroupID)

if not exists(select * from sysindexes where name = 'IX_TeamUser_UserId')
    CREATE INDEX IX_TeamUser_UserId ON TeamUser(UserId)

if not exists(select * from sysindexes where name = 'IX_TriggerItem_TriggerListId')
    CREATE INDEX IX_TriggerItem_TriggerListId ON TriggerItem(TriggerListId)

if not exists(select * from sysindexes where name = 'IX_PresentationGroupQuestionOrder_CreatedBy')
    CREATE INDEX IX_PresentationGroupQuestionOrder_CreatedBy ON PresentationGroupQuestionOrder(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_EligibilityPCP_PlanID')
    CREATE INDEX IX_EligibilityPCP_PlanID ON EligibilityPCP(PlanID)

if not exists(select * from sysindexes where name = 'IX_ActivityCompletion_ModifiedBy')
    CREATE INDEX IX_ActivityCompletion_ModifiedBy ON ActivityCompletion(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCSubSubDeficit_ModifiedBy')
    CREATE INDEX IX_WCSubSubDeficit_ModifiedBy ON WCSubSubDeficit(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_ReferralDetailID')
    CREATE INDEX IX_LetterDraftQueue_ReferralDetailID ON LetterDraftQueue(ReferralDetailID)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_MatrixTypeID')
    CREATE INDEX IX_LetterDraftQueue_MatrixTypeID ON LetterDraftQueue(MatrixTypeID)

if not exists(select * from sysindexes where name = 'IX_Question_ModifiedBy')
    CREATE INDEX IX_Question_ModifiedBy ON Question(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Patient_AssignedTeamId')
    CREATE INDEX IX_Patient_AssignedTeamId ON Patient(AssignedTeamId)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupPlanLevel_GroupID')
    CREATE INDEX IX_SecurityGroupPlanLevel_GroupID ON SecurityGroupPlanLevel(GroupID)

if not exists(select * from sysindexes where name = 'IX_SpecialProcedure_CreatedBy')
    CREATE INDEX IX_SpecialProcedure_CreatedBy ON SpecialProcedure(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Location_MailingAddressID')
    CREATE INDEX IX_Location_MailingAddressID ON Location(MailingAddressID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewRequest_EventID')
    CREATE INDEX IX_ClinicalReviewRequest_EventID ON ClinicalReviewRequest(EventID)

if not exists(select * from sysindexes where name = 'IX_PackingListItemTrigger_CreatedBy')
    CREATE INDEX IX_PackingListItemTrigger_CreatedBy ON PackingListItemTrigger(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Contact_CreatedBy')
    CREATE INDEX IX_Contact_CreatedBy ON Contact(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_WCSubSubDeficit_CreatedBy')
    CREATE INDEX IX_WCSubSubDeficit_CreatedBy ON WCSubSubDeficit(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_OutcomeRisk_CreatedBy')
    CREATE INDEX IX_OutcomeRisk_CreatedBy ON OutcomeRisk(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Patient_AddressID')
    CREATE INDEX IX_Patient_AddressID ON Patient(AddressID)

if not exists(select * from sysindexes where name = 'IX_AutoActivityInitialization_RuleID')
    CREATE INDEX IX_AutoActivityInitialization_RuleID ON AutoActivityInitialization(RuleID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupFALevel_GroupID')
    CREATE INDEX IX_SecurityGroupFALevel_GroupID ON SecurityGroupFALevel(GroupID)

if not exists(select * from sysindexes where name = 'IX_Event_FacilityTypeID')
    CREATE INDEX IX_Event_FacilityTypeID ON Event(FacilityTypeID)

if not exists(select * from sysindexes where name = 'IX_SpecialProcedure_ModifiedBy')
    CREATE INDEX IX_SpecialProcedure_ModifiedBy ON SpecialProcedure(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Location_BillingAddressID')
    CREATE INDEX IX_Location_BillingAddressID ON Location(BillingAddressID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewRequest_DurUOMID')
    CREATE INDEX IX_ClinicalReviewRequest_DurUOMID ON ClinicalReviewRequest(DurUOMID)

if not exists(select * from sysindexes where name = 'IX_BenefitServiceItem_BenefitServiceId')
    CREATE INDEX IX_BenefitServiceItem_BenefitServiceId ON BenefitServiceItem(BenefitServiceId)

if not exists(select * from sysindexes where name = 'IX_PackingListItemTrigger_ModifiedBy')
    CREATE INDEX IX_PackingListItemTrigger_ModifiedBy ON PackingListItemTrigger(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Eligibility_SORGID')
    CREATE INDEX IX_Eligibility_SORGID ON Eligibility(SORGID)

if not exists(select * from sysindexes where name = 'IX_Contact_ModifiedBy')
    CREATE INDEX IX_Contact_ModifiedBy ON Contact(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementService_CreatedBy')
    CREATE INDEX IX_ManagementService_CreatedBy ON ManagementService(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_AssessmentGUID')
    CREATE INDEX IX_LetterPrintedQueue_AssessmentGUID ON LetterPrintedQueue(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationNetworkHistory_FacilityLocationNetworkID')
    CREATE INDEX IX_FacilityLocationNetworkHistory_FacilityLocationNetworkID ON FacilityLocationNetworkHistory(FacilityLocationNetworkID)

if not exists(select * from sysindexes where name = 'IX_OutcomeRisk_ModifiedBy')
    CREATE INDEX IX_OutcomeRisk_ModifiedBy ON OutcomeRisk(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityInitialization_ExceptionID')
    CREATE INDEX IX_AutoActivityInitialization_ExceptionID ON AutoActivityInitialization(ExceptionID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupOrganizationLevel_GroupID')
    CREATE INDEX IX_SecurityGroupOrganizationLevel_GroupID ON SecurityGroupOrganizationLevel(GroupID)

if not exists(select * from sysindexes where name = 'IX_PlanMaternichekIncentive_CreatedBy')
    CREATE INDEX IX_PlanMaternichekIncentive_CreatedBy ON PlanMaternichekIncentive(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Location_ServiceAddressID')
    CREATE INDEX IX_Location_ServiceAddressID ON Location(ServiceAddressID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewRequest_ClinicalReviewTypeID')
    CREATE INDEX IX_ClinicalReviewRequest_ClinicalReviewTypeID ON ClinicalReviewRequest(ClinicalReviewTypeID)

if not exists(select * from sysindexes where name = 'IX_Plan_BenefitServiceId')
    CREATE INDEX IX_Plan_BenefitServiceId ON [dbo].[Plan](BenefitServiceId)

if not exists(select * from sysindexes where name = 'IX_PxType_CreatedBy')
    CREATE INDEX IX_PxType_CreatedBy ON PxType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_EventTypeID')
    CREATE INDEX IX_LetterMatrix_EventTypeID ON LetterMatrix(EventTypeID)

if not exists(select * from sysindexes where name = 'IX_Eligibility_RelationshipID')
    CREATE INDEX IX_Eligibility_RelationshipID ON Eligibility(RelationshipID)

if not exists(select * from sysindexes where name = 'IX_WCQualifier_ModifiedBy')
    CREATE INDEX IX_WCQualifier_ModifiedBy ON WCQualifier(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ManagementService_ModifiedBy')
    CREATE INDEX IX_ManagementService_ModifiedBy ON ManagementService(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_AssessmentGUID')
    CREATE INDEX IX_LetterNonPrintedQueue_AssessmentGUID ON LetterNonPrintedQueue(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_CoverageStatus_CreatedBy')
    CREATE INDEX IX_CoverageStatus_CreatedBy ON CoverageStatus(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_AutoActivityInitialization_FieldNameID')
    CREATE INDEX IX_AutoActivityInitialization_FieldNameID ON AutoActivityInitialization(FieldNameID)

if not exists(select * from sysindexes where name = 'IX_AssessmentPOCDeficit_POCDeficitTypeID')
    CREATE INDEX IX_AssessmentPOCDeficit_POCDeficitTypeID ON AssessmentPOCDeficit(POCDeficitTypeID)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupUser_GroupID')
    CREATE INDEX IX_SecurityGroupUser_GroupID ON SecurityGroupUser(GroupID)

if not exists(select * from sysindexes where name = 'IX_PlanMaternichekIncentive_ModifiedBy')
    CREATE INDEX IX_PlanMaternichekIncentive_ModifiedBy ON PlanMaternichekIncentive(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewRequest_ClinicalReviewDescriptionID')
    CREATE INDEX IX_ClinicalReviewRequest_ClinicalReviewDescriptionID ON ClinicalReviewRequest(ClinicalReviewDescriptionID)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_PlanBenefitServiceId')
    CREATE INDEX IX_PlanSorgLog_PlanBenefitServiceId ON PlanSorgLog(PlanBenefitServiceId)

if not exists(select * from sysindexes where name = 'IX_ActivityType_ActivityPrimaryTypeID')
    CREATE INDEX IX_ActivityType_ActivityPrimaryTypeID ON ActivityType(ActivityPrimaryTypeID)

if not exists(select * from sysindexes where name = 'IX_PxType_ModifiedBy')
    CREATE INDEX IX_PxType_ModifiedBy ON PxType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCQualifier_CreatedBy')
    CREATE INDEX IX_WCQualifier_CreatedBy ON WCQualifier(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeCallSource_CreatedBy')
    CREATE INDEX IX_IntakeCallSource_CreatedBy ON IntakeCallSource(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionExplanation_ExplanationID')
    CREATE INDEX IX_QuestionExplanation_ExplanationID ON QuestionExplanation(ExplanationID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeProvider_ProviderLocationID')
    CREATE INDEX IX_GroupPracticeProvider_ProviderLocationID ON GroupPracticeProvider(ProviderLocationID)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_AssessmentGUID')
    CREATE INDEX IX_LetterDraftQueue_AssessmentGUID ON LetterDraftQueue(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_CoverageStatus_ModifiedBy')
    CREATE INDEX IX_CoverageStatus_ModifiedBy ON CoverageStatus(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientAllergy_PatientId')
    CREATE INDEX IX_PatientAllergy_PatientId ON PatientAllergy(PatientId)

if not exists(select * from sysindexes where name = 'IX_AssessmentPOCDeficit_LogicID')
    CREATE INDEX IX_AssessmentPOCDeficit_LogicID ON AssessmentPOCDeficit(LogicID)

if not exists(select * from sysindexes where name = 'IX_OutcomeResultFrom_CreatedBy')
    CREATE INDEX IX_OutcomeResultFrom_CreatedBy ON OutcomeResultFrom(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecisionReason_CreatedBy')
    CREATE INDEX IX_PhysicianDecisionReason_CreatedBy ON PhysicianDecisionReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_WCProvider_ModifiedBy')
    CREATE INDEX IX_WCProvider_ModifiedBy ON WCProvider(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeCallSource_ModifiedBy')
    CREATE INDEX IX_IntakeCallSource_ModifiedBy ON IntakeCallSource(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterFormType_CreatedBy')
    CREATE INDEX IX_LetterFormType_CreatedBy ON LetterFormType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientContact_PatientID')
    CREATE INDEX IX_PatientContact_PatientID ON PatientContact(PatientID)

if not exists(select * from sysindexes where name = 'IX_AssessmentPOCDeficit_POCDeficitTypeID')
    CREATE INDEX IX_AssessmentPOCDeficit_POCDeficitTypeID ON AssessmentPOCDeficit(POCDeficitTypeID)

if not exists(select * from sysindexes where name = 'IX_GroupPractice_TypeID')
    CREATE INDEX IX_GroupPractice_TypeID ON GroupPractice(TypeID)

if not exists(select * from sysindexes where name = 'IX_OutcomeResultFrom_ModifiedBy')
    CREATE INDEX IX_OutcomeResultFrom_ModifiedBy ON OutcomeResultFrom(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecisionReason_ModifiedBy')
    CREATE INDEX IX_PhysicianDecisionReason_ModifiedBy ON PhysicianDecisionReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCProvider_CreatedBy')
    CREATE INDEX IX_WCProvider_CreatedBy ON WCProvider(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ImageLink_EventID')
    CREATE INDEX IX_ImageLink_EventID ON ImageLink(EventID)

if not exists(select * from sysindexes where name = 'IX_MedicationTerminationReason_CreatedBy')
    CREATE INDEX IX_MedicationTerminationReason_CreatedBy ON MedicationTerminationReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterFormType_ModifiedBy')
    CREATE INDEX IX_LetterFormType_ModifiedBy ON LetterFormType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_MorgID')
    CREATE INDEX IX_LetterMatrix_MorgID ON LetterMatrix(MorgID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeFocusType_ModifiedBy')
    CREATE INDEX IX_GroupPracticeFocusType_ModifiedBy ON GroupPracticeFocusType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewRequest_EDILogDetailID')
    CREATE INDEX IX_ClinicalReviewRequest_EDILogDetailID ON ClinicalReviewRequest(EDILogDetailID)

if not exists(select * from sysindexes where name = 'IX_Assessment_ExportLogID')
    CREATE INDEX IX_Assessment_ExportLogID ON Assessment(ExportLogID)

if not exists(select * from sysindexes where name = 'IX_WorkersComp_CreatedBy')
    CREATE INDEX IX_WorkersComp_CreatedBy ON WorkersComp(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterReferral_CreatedBy')
    CREATE INDEX IX_LetterReferral_CreatedBy ON LetterReferral(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ImageLink_PatientID')
    CREATE INDEX IX_ImageLink_PatientID ON ImageLink(PatientID)

if not exists(select * from sysindexes where name = 'IX_MedicationTerminationReason_ModifiedBy')
    CREATE INDEX IX_MedicationTerminationReason_ModifiedBy ON MedicationTerminationReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewType_ModifiedBy')
    CREATE INDEX IX_ClinicalReviewType_ModifiedBy ON ClinicalReviewType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientProblem_PatientId')
    CREATE INDEX IX_PatientProblem_PatientId ON PatientProblem(PatientId)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_OrgID')
    CREATE INDEX IX_LetterMatrix_OrgID ON LetterMatrix(OrgID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewUnit_ReportUnitID')
    CREATE INDEX IX_ClinicalReviewUnit_ReportUnitID ON ClinicalReviewUnit(ReportUnitID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeFocusType_CreatedBy')
    CREATE INDEX IX_GroupPracticeFocusType_CreatedBy ON GroupPracticeFocusType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewRequest_ReqUOMID')
    CREATE INDEX IX_ClinicalReviewRequest_ReqUOMID ON ClinicalReviewRequest(ReqUOMID)

if not exists(select * from sysindexes where name = 'IX_InsurancePayor_AddressID')
    CREATE INDEX IX_InsurancePayor_AddressID ON InsurancePayor(AddressID)

if not exists(select * from sysindexes where name = 'IX_POCDeficit_DeficitPriorityId')
    CREATE INDEX IX_POCDeficit_DeficitPriorityId ON POCDeficit(DeficitPriorityId)

if not exists(select * from sysindexes where name = 'IX_WorkersComp_ModifiedBy')
    CREATE INDEX IX_WorkersComp_ModifiedBy ON WorkersComp(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterReferral_ModifiedBy')
    CREATE INDEX IX_LetterReferral_ModifiedBy ON LetterReferral(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCSubDeficit_ModifiedBy')
    CREATE INDEX IX_WCSubDeficit_ModifiedBy ON WCSubDeficit(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewType_CreatedBy')
    CREATE INDEX IX_ClinicalReviewType_CreatedBy ON ClinicalReviewType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_SorgID')
    CREATE INDEX IX_LetterMatrix_SorgID ON LetterMatrix(SorgID)

if not exists(select * from sysindexes where name = 'IX_SubscriberCoverage_SubscriberId')
    CREATE INDEX IX_SubscriberCoverage_SubscriberId ON SubscriberCoverage(SubscriberId)

if not exists(select * from sysindexes where name = 'IX_AssessmentLevelOfDisease_LevelOfDiseaseTypeID')
    CREATE INDEX IX_AssessmentLevelOfDisease_LevelOfDiseaseTypeID ON AssessmentLevelOfDisease(LevelOfDiseaseTypeID)

if not exists(select * from sysindexes where name = 'IX_Network_TypeID')
    CREATE INDEX IX_Network_TypeID ON Network(TypeID)

if not exists(select * from sysindexes where name = 'IX_ReferralReportEntry_CreatedBy')
    CREATE INDEX IX_ReferralReportEntry_CreatedBy ON ReferralReportEntry(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewRequest_ProblemID')
    CREATE INDEX IX_ClinicalReviewRequest_ProblemID ON ClinicalReviewRequest(ProblemID)

if not exists(select * from sysindexes where name = 'IX_POCDeficit_DeficitSourceId')
    CREATE INDEX IX_POCDeficit_DeficitSourceId ON POCDeficit(DeficitSourceId)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationService_CreatedBy')
    CREATE INDEX IX_FacilityLocationService_CreatedBy ON FacilityLocationService(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_ClinicalReviewDecisionReasonID')
    CREATE INDEX IX_LetterMatrix_ClinicalReviewDecisionReasonID ON LetterMatrix(ClinicalReviewDecisionReasonID)

if not exists(select * from sysindexes where name = 'IX_WCInjuryBodyPart_CreatedBy')
    CREATE INDEX IX_WCInjuryBodyPart_CreatedBy ON WCInjuryBodyPart(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ImageLink_ImageID')
    CREATE INDEX IX_ImageLink_ImageID ON ImageLink(ImageID)

if not exists(select * from sysindexes where name = 'IX_WCSubDeficit_CreatedBy')
    CREATE INDEX IX_WCSubDeficit_CreatedBy ON WCSubDeficit(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationNetworkHistory_ProviderLocationNetworkID')
    CREATE INDEX IX_ProviderLocationNetworkHistory_ProviderLocationNetworkID ON ProviderLocationNetworkHistory(ProviderLocationNetworkID)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_PlanModifiedByUserId')
    CREATE INDEX IX_PlanSorgLog_PlanModifiedByUserId ON PlanSorgLog(PlanModifiedByUserId)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_PlanID')
    CREATE INDEX IX_LetterMatrix_PlanID ON LetterMatrix(PlanID)

if not exists(select * from sysindexes where name = 'IX_AssessmentLevelOfDisease_LogicID')
    CREATE INDEX IX_AssessmentLevelOfDisease_LogicID ON AssessmentLevelOfDisease(LogicID)

if not exists(select * from sysindexes where name = 'IX_ReferralReportEntry_ModifiedBy')
    CREATE INDEX IX_ReferralReportEntry_ModifiedBy ON ReferralReportEntry(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewRequest_FreqUOMID')
    CREATE INDEX IX_ClinicalReviewRequest_FreqUOMID ON ClinicalReviewRequest(FreqUOMID)

if not exists(select * from sysindexes where name = 'IX_POCDeficit_DeficitStatusId')
    CREATE INDEX IX_POCDeficit_DeficitStatusId ON POCDeficit(DeficitStatusId)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationService_TerminatedBy')
    CREATE INDEX IX_FacilityLocationService_TerminatedBy ON FacilityLocationService(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_ClinicalReviewDecisionReasonID')
    CREATE INDEX IX_ClinicalReviewDecision_ClinicalReviewDecisionReasonID ON ClinicalReviewDecision(ClinicalReviewDecisionReasonID)

if not exists(select * from sysindexes where name = 'IX_WCInjuryBodyPart_ModifiedBy')
    CREATE INDEX IX_WCInjuryBodyPart_ModifiedBy ON WCInjuryBodyPart(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireTrigger_CreatedBy')
    CREATE INDEX IX_QuestionnaireTrigger_CreatedBy ON QuestionnaireTrigger(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_ReferralTypeID')
    CREATE INDEX IX_LetterMatrix_ReferralTypeID ON LetterMatrix(ReferralTypeID)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_SORGCreatedBy')
    CREATE INDEX IX_PlanSorgLog_SORGCreatedBy ON PlanSorgLog(SORGCreatedBy)

if not exists(select * from sysindexes where name = 'IX_Outcome_PatientId')
    CREATE INDEX IX_Outcome_PatientId ON Outcome(PatientId)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberCoverage_PatientEligibilityID')
    CREATE INDEX IX_PatientSubscriberCoverage_PatientEligibilityID ON PatientSubscriberCoverage(PatientEligibilityID)

if not exists(select * from sysindexes where name = 'IX_AssessmentLevelOfDisease_LevelOfDiseaseTypeID')
    CREATE INDEX IX_AssessmentLevelOfDisease_LevelOfDiseaseTypeID ON AssessmentLevelOfDisease(LevelOfDiseaseTypeID)

if not exists(select * from sysindexes where name = 'IX_GroupPractice_CreatedBy')
    CREATE INDEX IX_GroupPractice_CreatedBy ON GroupPractice(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_ClinicalReviewRequestID')
    CREATE INDEX IX_ClinicalReviewDecision_ClinicalReviewRequestID ON ClinicalReviewDecision(ClinicalReviewRequestID)

if not exists(select * from sysindexes where name = 'IX_Plan_InsurancePayorId')
    CREATE INDEX IX_Plan_InsurancePayorId ON [dbo].[Plan](InsurancePayorId)

if not exists(select * from sysindexes where name = 'IX_POCDeficit_AssessmentGUID')
    CREATE INDEX IX_POCDeficit_AssessmentGUID ON POCDeficit(AssessmentGUID)

if not exists(select * from sysindexes where name = 'IX_ProviderServiceType_CreatedBy')
    CREATE INDEX IX_ProviderServiceType_CreatedBy ON ProviderServiceType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PlanType_ModifiedBy')
    CREATE INDEX IX_PlanType_ModifiedBy ON PlanType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_QuestionnaireTrigger_ModifiedBy')
    CREATE INDEX IX_QuestionnaireTrigger_ModifiedBy ON QuestionnaireTrigger(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Referral_ReferralTypeID')
    CREATE INDEX IX_Referral_ReferralTypeID ON Referral(ReferralTypeID)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_SORGModifiedBy')
    CREATE INDEX IX_PlanSorgLog_SORGModifiedBy ON PlanSorgLog(SORGModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberCoverage_RelationShipID')
    CREATE INDEX IX_PatientSubscriberCoverage_RelationShipID ON PatientSubscriberCoverage(RelationShipID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_EventProcedureID')
    CREATE INDEX IX_ClinicalReviewDecision_EventProcedureID ON ClinicalReviewDecision(EventProcedureID)

if not exists(select * from sysindexes where name = 'IX_PatientMedication_PatientID')
    CREATE INDEX IX_PatientMedication_PatientID ON PatientMedication(PatientID)

if not exists(select * from sysindexes where name = 'IX_PlanSORG_LOSRegion')
    CREATE INDEX IX_PlanSORG_LOSRegion ON PlanSORG(LOSRegion)

if not exists(select * from sysindexes where name = 'IX_GroupPractice_ModifiedBy')
    CREATE INDEX IX_GroupPractice_ModifiedBy ON GroupPractice(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PlanType_CreatedBy')
    CREATE INDEX IX_PlanType_CreatedBy ON PlanType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_CreatedBy')
    CREATE INDEX IX_IntakeLog_CreatedBy ON IntakeLog(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GuidelineIndicator_CreatedBy')
    CREATE INDEX IX_GuidelineIndicator_CreatedBy ON GuidelineIndicator(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberCoverage_PatientId')
    CREATE INDEX IX_PatientSubscriberCoverage_PatientId ON PatientSubscriberCoverage(PatientId)

if not exists(select * from sysindexes where name = 'IX_GroupPractice_StatusChangedBy')
    CREATE INDEX IX_GroupPractice_StatusChangedBy ON GroupPractice(StatusChangedBy)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_CreatedBy')
    CREATE INDEX IX_LetterMatrix_CreatedBy ON LetterMatrix(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ImageLink_CreatedBy')
    CREATE INDEX IX_ImageLink_CreatedBy ON ImageLink(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_ModifiedBy')
    CREATE INDEX IX_IntakeLog_ModifiedBy ON IntakeLog(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_GuidelineIndicator_ModifiedBy')
    CREATE INDEX IX_GuidelineIndicator_ModifiedBy ON GuidelineIndicator(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Note_PatientId')
    CREATE INDEX IX_Note_PatientId ON Note(PatientId)

if not exists(select * from sysindexes where name = 'IX_AssessmentRisk_LogicID')
    CREATE INDEX IX_AssessmentRisk_LogicID ON AssessmentRisk(LogicID)

if not exists(select * from sysindexes where name = 'IX_PatientMedication_MedicationTerminationReasonId')
    CREATE INDEX IX_PatientMedication_MedicationTerminationReasonId ON PatientMedication(MedicationTerminationReasonId)

if not exists(select * from sysindexes where name = 'IX_GroupPractice_StatusChangedBy')
    CREATE INDEX IX_GroupPractice_StatusChangedBy ON GroupPractice(StatusChangedBy)

if not exists(select * from sysindexes where name = 'IX_POCDeficit_DeficitTypeID')
    CREATE INDEX IX_POCDeficit_DeficitTypeID ON POCDeficit(DeficitTypeID)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_ModifiedBy')
    CREATE INDEX IX_LetterMatrix_ModifiedBy ON LetterMatrix(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ImageLink_ModifiedBy')
    CREATE INDEX IX_ImageLink_ModifiedBy ON ImageLink(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupDiagnosisLevel_CreatedBy')
    CREATE INDEX IX_SecurityGroupDiagnosisLevel_CreatedBy ON SecurityGroupDiagnosisLevel(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDurUnit_ModifiedBy')
    CREATE INDEX IX_ClinicalReviewDurUnit_ModifiedBy ON ClinicalReviewDurUnit(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Activity_PatientId')
    CREATE INDEX IX_Activity_PatientId ON Activity(PatientId)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberCoveragePCP_PatientSubscriberCoverageId')
    CREATE INDEX IX_PatientSubscriberCoveragePCP_PatientSubscriberCoverageId ON PatientSubscriberCoveragePCP(PatientSubscriberCoverageId)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_DecUOMID')
    CREATE INDEX IX_ClinicalReviewDecision_DecUOMID ON ClinicalReviewDecision(DecUOMID)

if not exists(select * from sysindexes where name = 'IX_AssessmentRisk_RiskTypeID')
    CREATE INDEX IX_AssessmentRisk_RiskTypeID ON AssessmentRisk(RiskTypeID)

if not exists(select * from sysindexes where name = 'IX_PatientMedication_StatusID')
    CREATE INDEX IX_PatientMedication_StatusID ON PatientMedication(StatusID)

if not exists(select * from sysindexes where name = 'IX_GuidelineTip_CreatedBy')
    CREATE INDEX IX_GuidelineTip_CreatedBy ON GuidelineTip(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeFocus_GroupPracticeID')
    CREATE INDEX IX_GroupPracticeFocus_GroupPracticeID ON GroupPracticeFocus(GroupPracticeID)

if not exists(select * from sysindexes where name = 'IX_LetterMatrix_TerminatedBy')
    CREATE INDEX IX_LetterMatrix_TerminatedBy ON LetterMatrix(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_PlanSorgLog_PlanTriggerListId')
    CREATE INDEX IX_PlanSorgLog_PlanTriggerListId ON PlanSorgLog(PlanTriggerListId)

if not exists(select * from sysindexes where name = 'IX_WCDurableMedicalEquipment_CreatedBy')
    CREATE INDEX IX_WCDurableMedicalEquipment_CreatedBy ON WCDurableMedicalEquipment(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_SecurityGroupDiagnosisLevel_ModifiedBy')
    CREATE INDEX IX_SecurityGroupDiagnosisLevel_ModifiedBy ON SecurityGroupDiagnosisLevel(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDurUnit_CreatedBy')
    CREATE INDEX IX_ClinicalReviewDurUnit_CreatedBy ON ClinicalReviewDurUnit(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_PatientId')
    CREATE INDEX IX_IntakeLog_PatientId ON IntakeLog(PatientId)

if not exists(select * from sysindexes where name = 'IX_Patient_UserDefinedID')
    CREATE INDEX IX_Patient_UserDefinedID ON Patient(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_ClinicalReviewDescriptionID')
    CREATE INDEX IX_ClinicalReviewDecision_ClinicalReviewDescriptionID ON ClinicalReviewDecision(ClinicalReviewDescriptionID)

if not exists(select * from sysindexes where name = 'IX_PatientMedication_StatusReasonID')
    CREATE INDEX IX_PatientMedication_StatusReasonID ON PatientMedication(StatusReasonID)

if not exists(select * from sysindexes where name = 'IX_GuidelineTip_ModifiedBy')
    CREATE INDEX IX_GuidelineTip_ModifiedBy ON GuidelineTip(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocation_GroupPracticeID')
    CREATE INDEX IX_GroupPracticeLocation_GroupPracticeID ON GroupPracticeLocation(GroupPracticeID)

if not exists(select * from sysindexes where name = 'IX_AssessmentQuestionnaire_CreatedBy')
    CREATE INDEX IX_AssessmentQuestionnaire_CreatedBy ON AssessmentQuestionnaire(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_WCDurableMedicalEquipment_ModifiedBy')
    CREATE INDEX IX_WCDurableMedicalEquipment_ModifiedBy ON WCDurableMedicalEquipment(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_MedicationStatusReason_CreatedBy')
    CREATE INDEX IX_MedicationStatusReason_CreatedBy ON MedicationStatusReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationService_TerminatedBy')
    CREATE INDEX IX_GroupPracticeLocationService_TerminatedBy ON GroupPracticeLocationService(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientSubscriberLog_PatientId')
    CREATE INDEX IX_PatientSubscriberLog_PatientId ON PatientSubscriberLog(PatientId)

if not exists(select * from sysindexes where name = 'IX_Organization_UserDefinedID')
    CREATE INDEX IX_Organization_UserDefinedID ON Organization(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_Event_StatusID')
    CREATE INDEX IX_Event_StatusID ON Event(StatusID)

if not exists(select * from sysindexes where name = 'IX_POCGoalType_ModifiedBy')
    CREATE INDEX IX_POCGoalType_ModifiedBy ON POCGoalType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_AssessmentQuestionnaire_ModifiedBy')
    CREATE INDEX IX_AssessmentQuestionnaire_ModifiedBy ON AssessmentQuestionnaire(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Subscriber_UserDefinedID')
    CREATE INDEX IX_Subscriber_UserDefinedID ON Subscriber(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_WCDeficit_CreatedBy')
    CREATE INDEX IX_WCDeficit_CreatedBy ON WCDeficit(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_MedicationStatusReason_ModifiedBy')
    CREATE INDEX IX_MedicationStatusReason_ModifiedBy ON MedicationStatusReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Contact_AddressID')
    CREATE INDEX IX_Contact_AddressID ON Contact(AddressID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationService_ModifiedBy')
    CREATE INDEX IX_GroupPracticeLocationService_ModifiedBy ON GroupPracticeLocationService(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_Plan_UserDefinedID')
    CREATE INDEX IX_Plan_UserDefinedID ON [dbo].[Plan](UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_DurationUOMID')
    CREATE INDEX IX_ClinicalReviewDecision_DurationUOMID ON ClinicalReviewDecision(DurationUOMID)

if not exists(select * from sysindexes where name = 'IX_POCGoalType_CreatedBy')
    CREATE INDEX IX_POCGoalType_CreatedBy ON POCGoalType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderFocusType_CreatedBy')
    CREATE INDEX IX_ProviderFocusType_CreatedBy ON ProviderFocusType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_WCDeficit_ModifiedBy')
    CREATE INDEX IX_WCDeficit_ModifiedBy ON WCDeficit(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_OutcomeType_CreatedBy')
    CREATE INDEX IX_OutcomeType_CreatedBy ON OutcomeType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderLocationContact_ContactID')
    CREATE INDEX IX_ProviderLocationContact_ContactID ON ProviderLocationContact(ContactID)

if not exists(select * from sysindexes where name = 'IX_NetworkPlanHistory_NetworkPlanID')
    CREATE INDEX IX_NetworkPlanHistory_NetworkPlanID ON NetworkPlanHistory(NetworkPlanID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationService_CreatedBy')
    CREATE INDEX IX_GroupPracticeLocationService_CreatedBy ON GroupPracticeLocationService(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_Problem_UserDefinedID')
    CREATE INDEX IX_Problem_UserDefinedID ON Problem(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDecision_LinkedProcedureType')
    CREATE INDEX IX_ClinicalReviewDecision_LinkedProcedureType ON ClinicalReviewDecision(LinkedProcedureType)

if not exists(select * from sysindexes where name = 'IX_PlanHEDISType_CreatedBy')
    CREATE INDEX IX_PlanHEDISType_CreatedBy ON PlanHEDISType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_ProviderFocusType_ModifiedBy')
    CREATE INDEX IX_ProviderFocusType_ModifiedBy ON ProviderFocusType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_InsurancePayor_CreatedBy')
    CREATE INDEX IX_InsurancePayor_CreatedBy ON InsurancePayor(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_OutcomeType_ModifiedBy')
    CREATE INDEX IX_OutcomeType_ModifiedBy ON OutcomeType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_NoteTerminationReason_CreatedBy')
    CREATE INDEX IX_NoteTerminationReason_CreatedBy ON NoteTerminationReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_MorgID')
    CREATE INDEX IX_LetterNonPrintedQueue_MorgID ON LetterNonPrintedQueue(MorgID)

if not exists(select * from sysindexes where name = 'IX_Event_UserDefinedID')
    CREATE INDEX IX_Event_UserDefinedID ON Event(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_PlanHEDISType_ModifiedBy')
    CREATE INDEX IX_PlanHEDISType_ModifiedBy ON PlanHEDISType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCTreatmentPlan_CreatedBy')
    CREATE INDEX IX_WCTreatmentPlan_CreatedBy ON WCTreatmentPlan(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_InsurancePayor_ModifiedBy')
    CREATE INDEX IX_InsurancePayor_ModifiedBy ON InsurancePayor(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCSetting_ModifiedBy')
    CREATE INDEX IX_WCSetting_ModifiedBy ON WCSetting(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_InsurancePayorContact_ContactID')
    CREATE INDEX IX_InsurancePayorContact_ContactID ON InsurancePayorContact(ContactID)

if not exists(select * from sysindexes where name = 'IX_NoteTerminationReason_ModifiedBy')
    CREATE INDEX IX_NoteTerminationReason_ModifiedBy ON NoteTerminationReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_OrgID')
    CREATE INDEX IX_LetterNonPrintedQueue_OrgID ON LetterNonPrintedQueue(OrgID)

if not exists(select * from sysindexes where name = 'IX_Referral_UserDefinedID')
    CREATE INDEX IX_Referral_UserDefinedID ON Referral(UserDefinedID)

if not exists(select * from sysindexes where name = 'IX_PatientMedication_ContentOwnerID')
    CREATE INDEX IX_PatientMedication_ContentOwnerID ON PatientMedication(ContentOwnerID)

if not exists(select * from sysindexes where name = 'IX_POCGoalReason_ModifiedBy')
    CREATE INDEX IX_POCGoalReason_ModifiedBy ON POCGoalReason(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_POCGoal_DeficitId')
    CREATE INDEX IX_POCGoal_DeficitId ON POCGoal(DeficitId)

if not exists(select * from sysindexes where name = 'IX_WCTreatmentPlan_ModifiedBy')
    CREATE INDEX IX_WCTreatmentPlan_ModifiedBy ON WCTreatmentPlan(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_WCBodySystem_CreatedBy')
    CREATE INDEX IX_WCBodySystem_CreatedBy ON WCBodySystem(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_WCSetting_CreatedBy')
    CREATE INDEX IX_WCSetting_CreatedBy ON WCSetting(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PatientContact_ContactID')
    CREATE INDEX IX_PatientContact_ContactID ON PatientContact(ContactID)

if not exists(select * from sysindexes where name = 'IX_OutcomeSubIndicator_CreatedBy')
    CREATE INDEX IX_OutcomeSubIndicator_CreatedBy ON OutcomeSubIndicator(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_LetterNonPrintedQueue_SorgID')
    CREATE INDEX IX_LetterNonPrintedQueue_SorgID ON LetterNonPrintedQueue(SorgID)

if not exists(select * from sysindexes where name = 'IX_LengthOfStay_HCIA_RegionId')
    CREATE INDEX IX_LengthOfStay_HCIA_RegionId ON LengthOfStay(HCIA_RegionId)

if not exists(select * from sysindexes where name = 'IX_POCGoalReason_CreatedBy')
    CREATE INDEX IX_POCGoalReason_CreatedBy ON POCGoalReason(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_POCGoal_GoalOutcomeId')
    CREATE INDEX IX_POCGoal_GoalOutcomeId ON POCGoal(GoalOutcomeId)

if not exists(select * from sysindexes where name = 'IX_UserDefined_CreatedBy')
    CREATE INDEX IX_UserDefined_CreatedBy ON UserDefined(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItem_CMSTypeId')
    CREATE INDEX IX_PackingListItem_CMSTypeId ON PackingListItem(CMSTypeId)

if not exists(select * from sysindexes where name = 'IX_WCBodySystem_ModifiedBy')
    CREATE INDEX IX_WCBodySystem_ModifiedBy ON WCBodySystem(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationNetwork_TerminatedBy')
    CREATE INDEX IX_FacilityLocationNetwork_TerminatedBy ON FacilityLocationNetwork(TerminatedBy)

if not exists(select * from sysindexes where name = 'IX_Event_ContactID')
    CREATE INDEX IX_Event_ContactID ON Event(ContactID)

if not exists(select * from sysindexes where name = 'IX_OutcomeSubIndicator_ModifiedBy')
    CREATE INDEX IX_OutcomeSubIndicator_ModifiedBy ON OutcomeSubIndicator(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_MorgID')
    CREATE INDEX IX_LetterPrintedQueue_MorgID ON LetterPrintedQueue(MorgID)

if not exists(select * from sysindexes where name = 'IX_LetterDecision_ClinicalReviewDecisionID')
    CREATE INDEX IX_LetterDecision_ClinicalReviewDecisionID ON LetterDecision(ClinicalReviewDecisionID)

if not exists(select * from sysindexes where name = 'IX_FacilityType_ModifiedBy')
    CREATE INDEX IX_FacilityType_ModifiedBy ON FacilityType(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_POCGoal_GoalTermId')
    CREATE INDEX IX_POCGoal_GoalTermId ON POCGoal(GoalTermId)

if not exists(select * from sysindexes where name = 'IX_UserDefined_ModifiedBy')
    CREATE INDEX IX_UserDefined_ModifiedBy ON UserDefined(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemSent_PackingListItemId')
    CREATE INDEX IX_PackingListItemSent_PackingListItemId ON PackingListItemSent(PackingListItemId)

if not exists(select * from sysindexes where name = 'IX_EventReferralProcedure_CreatedBy')
    CREATE INDEX IX_EventReferralProcedure_CreatedBy ON EventReferralProcedure(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_FacilityLocationNetwork_CreatedBy')
    CREATE INDEX IX_FacilityLocationNetwork_CreatedBy ON FacilityLocationNetwork(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_IntakeLog_IntakeCallReasonID')
    CREATE INDEX IX_IntakeLog_IntakeCallReasonID ON IntakeLog(IntakeCallReasonID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationNetworkHistory_GroupPracticeLocationNetworkID')
    CREATE INDEX IX_GroupPracticeLocationNetworkHistory_GroupPracticeLocationNetworkID ON GroupPracticeLocationNetworkHistory(GroupPracticeLocationNetworkID)

if not exists(select * from sysindexes where name = 'IX_ClinicalReviewDescription_ModifiedBy')
    CREATE INDEX IX_ClinicalReviewDescription_ModifiedBy ON ClinicalReviewDescription(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_LetterPrintedQueue_OrgID')
    CREATE INDEX IX_LetterPrintedQueue_OrgID ON LetterPrintedQueue(OrgID)

if not exists(select * from sysindexes where name = 'IX_LetterDraftQueue_ClinicalReviewDecisionID')
    CREATE INDEX IX_LetterDraftQueue_ClinicalReviewDecisionID ON LetterDraftQueue(ClinicalReviewDecisionID)

if not exists(select * from sysindexes where name = 'IX_GroupPracticeLocationNetwork_GroupPracticeLocationID')
    CREATE INDEX IX_GroupPracticeLocationNetwork_GroupPracticeLocationID ON GroupPracticeLocationNetwork(GroupPracticeLocationID)

if not exists(select * from sysindexes where name = 'IX_FacilityType_CreatedBy')
    CREATE INDEX IX_FacilityType_CreatedBy ON FacilityType(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_POCGoal_GoalTypeId')
    CREATE INDEX IX_POCGoal_GoalTypeId ON POCGoal(GoalTypeId)

if not exists(select * from sysindexes where name = 'IX_ProblemDescription_CreatedBy')
    CREATE INDEX IX_ProblemDescription_CreatedBy ON ProblemDescription(CreatedBy)

if not exists(select * from sysindexes where name = 'IX_PackingListItemTrigger_PackingListItemId')
    CREATE INDEX IX_PackingListItemTrigger_PackingListItemId ON PackingListItemTrigger(PackingListItemId)

if not exists(select * from sysindexes where name = 'IX_EventReferralProcedure_ModifiedBy')
    CREATE INDEX IX_EventReferralProcedure_ModifiedBy ON EventReferralProcedure(ModifiedBy)

if not exists(select * from sysindexes where name = 'IX_PhysicianDecision_PhysicianReviewDecisionID')
    CREATE INDEX IX_PhysicianDecision_PhysicianReviewDecisionID ON PhysicianDecision(PhysicianReviewDecisionID)

