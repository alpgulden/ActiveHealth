using System;
using System.IO;
using System.Data;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Security.Permissions;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using X12Parsing;				// our parsing objects
using ActiveAdvice.DataLayer;   // get to the Intake Log
using System.Collections;		// CollectionBase
using NetsoftUSA.DataLayer;

namespace InterfaceReader
{
    /// <summary>
    /// Summary description for EDIreader.
    /// </summary>
    public class EDIreader
    {
        #region parsing array
        IBenefitInquiry []Parser = {   new TransactionSetHeader(),                   // ST
                                       new InterchangeControlHeader(),               // ISA
                                       new InterchangeControlTrailer(),              // IEA
                                       new GroupHeader(),                            // GS
                                       new GroupTrailer(),                           // GE
                                       new DependentLevel(),                         // HL
                                       new BeginningHierarchicalTransfer(),          // BHT
                                       new DependentName(),                          // NM1
                                       new DependentAdditionalIdentification(),      // REF
                                       new DependentAddress(),                       // N3
                                       new DependentContactInformation(),            // PER
                                       new DependentDemographicInformation(),        // DMG
                                       new DependentRelationship(),                  // INS
                                       new DependentDate(),                          // DTP
                                       new DependentBenefitInformation(),            // EB
                                       new DependentBenefitRelatedProvider(),        // PRV
                                       new DependentEligibilityInformation(),        // LS
									   new x12UM(),                                  // UM
									   new x12HSD(),                                 // HSD
									   new x12CR6(),                                 // CR6
									   new x12SE(),                                  // SE
                                       new LoopTrailer()                             // LE
                                   };
        #endregion parsing array

		public EDIreader()
        {
            //
            // TODO: Add constructor logic here
            //
        }

		~EDIreader()
		{
			if (this.sw_errorlog != null)
			{
				sw_errorlog.Flush();
				sw_errorlog.Close();
			}
		}
		#region Cancel logic
		bool cancel = false;
		/// <summary>
		/// Cancel
		/// Set this property to inform the object that it is being 
		/// canceled from another thread. Note that the variable is
		/// lock'd to avoid thread problems...
		/// </summary>
		public bool Cancel
		{
			set
			{ 
				lock(this)
				{
					cancel = value; 
				}
			}
		}

		/// <summary>
		/// IsCanceled
		/// Returns 'true' to acknowledge that the Cancel
		/// has been received and the object is cleaning up
		/// and canceling.
		/// </summary>
		public bool IsCanceled
		{
			get 
			{
				bool c;
				lock(this)
				{
					c = cancel;
				}
				return c; 
			}
		}
		#endregion

		#region variables
		protected string errorLogFileName   = null;   // file to write errors too
		protected string ConnectionString   = null;   // dns to the database
		protected StreamWriter sw_errorlog  = null;   // stream to write errors too
		protected int write_error_log_count = 0;      // running count of errors we encountered
		protected int max_error_log_count   = 15;     // max # of errors to write to event log per parsing
		#endregion

		//
        // ParseFile():
        // This routine will open up the file and begin parsing the data
        public int ParseFile(string rootname, System.String FileName, String connection, string errorlogfilename)
        {
			StreamReader sr = null;
            try
            {
                this.errorLogFileName      = errorlogfilename;
                FileIOPermission filePerm  = new FileIOPermission(FileIOPermissionAccess.Read, FileName);
                filePerm.Assert();

                this.ConnectionString    = connection;
                sr          = new StreamReader(FileName);

				this.EDILog.FileName = rootname;			// save the name the provider sent us

                // Now parse the file contents
                ParseX12(sr);
				sr.Close();
            }
            catch(Exception ex)
            {
				if (sr != null)
					sr.Close(); // close our stream to free the file...
                string message = ex.Message;
                if (!EventLog.SourceExists("EligibilityInterface") )
                    EventLog.CreateEventSource("EligibilityInterface", "ActiveAdvice");
                EventLog.WriteEntry("EligibilityInterface", ex.Message, EventLogEntryType.Error);
                return -1; // throw(ex);
            }

            return 0;
        }

		protected EDILog edilog = null;
		protected EDILog EDILog
		{
			get
			{
				if (null == edilog)
				{
					edilog = new EDILog();
					edilog.IsNew = true;
				}
				return edilog;
			}
		}

        public int ParseX12(StreamReader sr)
        {
            const int max_parts        = 50;
            int line_number            = 0;
            char []splitter            = {'\0', '\0'};    // empty splitter

            string input_line        = sr.ReadLine();
			if (input_line.Substring(0, 3) == "ISA")
			{
				splitter[0] = input_line[input_line.Length - 2]; // get our delimiter "ISA*.......*P*>"
				//                                 ^--- our delimiter after the 'P'
                splitter[1] = input_line[input_line.Length - 1]; // get our sub-delimiter
			}
            // If the ISA is not the first record, then we don't have a delimiter and can't proceed, throw error
            if (splitter[0] == '\0')
            {
                Exception e = new Exception("ISA not first element, cannot proceed without delimiter! (line #" + line_number.ToString()+")");
                throw e;
            }

			// Keep track of the delimiters...
			this.EDILog.ESEP	= splitter[0].ToString();
			this.EDILog.SubESEP = splitter[1].ToString();

			// set the sub-element delimiter into the parsing objects
			if (splitter[1] != '\0')
			{
				for (int i = 0; i < Parser.Length; i++)
					Parser[i].Delimiter = splitter[1];
			}
            // Now walk the rest of the lines in the file...
            do
            {
                // If someone cancels us, then we are done for
                if (IsCanceled)
                    return 0; // we are forced to exit...
				IBenefitInquiry po = null;
				try
				{
					line_number++;

					string []parts = ParsingFunctions.Splitter(input_line, splitter, max_parts); // input_line.Split(splitter, max_parts);
					string TransactionSetID = parts[0]; // first is the parse code
					for (int i = 0; i < Parser.Length; i++)
					{
						if (Parser[i].TransactionSetID == TransactionSetID)
						{
							Parser[i].ParseHeader(parts, sr);
							po            = Parser[i];
							break; // process the next line...
						}
					}
				}
				catch(Exception ex)
				{
					string msg = "Element invalid, line #" + line_number.ToString() + ", TransactionSetID = " + po.TransactionSetID;
					msg += "\r\n" + ex.Message;
					this.WriteErrorLog(msg, EventLogEntryType.Error);
					if (ex.Message == "NOT executing Process step for manual debugging")
						throw ex;
				}

                if (po == null)
                    continue;

                // Validate what we read
                if (!po.ValidateData())
                {
                    string msg = "Element invalid, line #" + line_number.ToString() + ", TransactionSetID = " + po.TransactionSetID;
                    msg += "\r\nLine = \'" + input_line + "\'";
                    this.WriteErrorLog(msg, EventLogEntryType.Warning);
					continue; // don't bother processing element...
                }

				// we have valid data, let's process it...
                try
                {
                    ProcessElement(po, line_number);
                }
                catch(Exception e)
                {
                    string msg = "Element invalid, line #" + line_number.ToString() + ", TransactionSetID = " + po.TransactionSetID;
                    msg += "\r\n" + e.Message;
                    this.WriteErrorLog(msg, EventLogEntryType.Error);
                    if (e.Message == "NOT executing Process step for manual debugging")
                        throw e;
                }
            }
            while ( (input_line = sr.ReadLine() ) != null);

			this.EDILog.LineCount = line_number;
			try
			{
				EDILog.Save();
			}
			catch(Exception e)
			{
				Exception ex = new Exception("error saving EDILog", e);
				throw ex;
			}

            return 0;
        }// end of method ParseX12

		#region parsing variables
//        enum LoopType 
//        {
//            noLoop = 0, 
//            infosourceLoop     =  20, 
//            inforeceiverLoop   =  21, 
//            subscriberLoop     =  22,
//            subscriberLoop_PCP = 122, // in subscriber loop, fetching PCP information
//            dependentLoop      =  23,
//            dependentLoop_PCP  = 123  // in dependent loop, fetching PCP information
//        };
//        LoopType loopType               = LoopType.noLoop;
//        bool ignoreLoop                 = false;
//        bool ignoreSubscriber           = false;    // ignore all subscriber related data
//        bool eligibilityBenefits        = false;
//        string AlternateSubscriberID    = null;
//        string AlternatePlanID          = null;
		#endregion
		

		protected string    loop278                      = null;					// loop we are processing
		protected string    transactionSetControlNumber  = null;					// transaction set we are processing
		protected string    transactionSetIdentifierCode = null;					// should always be 278
		protected int       segmentcount                 = 0;
		protected string    functionalIdentifierCode     = null;
		protected string    groupControlNumber           = null;
		protected int       transactionsetcount          = 0;
		protected string    interchangecontrolnumber     = null;
		protected int       functionalgroupcount         = 0;
		protected bool      IsRequest                    = false;				// from BHT01 & BHT02, must be "0078" & "13" respectively
		protected string    referenceIdentification      = null;					// from BHT03
		protected DateTime  hierarchicalDate             = DateTime.MinValue;	// BHT04 & BHT05
		protected x12_2000A o2000A                       = null;                // receiver
		protected x12_2010B o2010B                       = null;
		protected x12_2010C o2010C                       = null;				// subscriber
		protected x12_2010D o2010D						 = null;				// patient
		protected x12_2010E o2010E                       = null;
		protected x12_2010ECollection o2010Elist         = null;
		protected x12_2000F o2000F                       = null;
		protected void InitObjects()
		{
			o2000A = null; o2010B = null; o2010C = null; o2010D = null; o2010E = null; o2010Elist = null; o2000F = null; loop278 = null;
			ediIntakeLog = null; ediEvent = null; ediPatientCoverage = null; ediPatient = null; ediSubscriber = null; ediReferral = null; ediProblem = null;
		}

		protected EDIControlCollection edicontrols = null;
		protected EDIControlCollection ReceiverInfo
		{
			get
			{
				if (null == edicontrols)
				{
					edicontrols = new EDIControlCollection();
					edicontrols.SelectAllEDIControlByActive(-1, true);
				}
				return edicontrols;
			}
		}

		protected UMOIdentificationQualifierCollection umoiqc = null;
		protected UMOIdentificationQualifierCollection ReceiverTypes
		{
			get
			{
				if (null == umoiqc)
				{
					umoiqc = new UMOIdentificationQualifierCollection();
					umoiqc.SelectAllUMOIdentificationQualifiersByActive(-1, true);
				}
				return umoiqc;
			}
		}

		// Verify that the receiver is one we recognize
		bool ValidReceiver(string receiverid, string receivertype)
		{
			// verify the receiver type
			if (null == ReceiverTypes.FindBy(receivertype) )
				return false;	// didn't find the type!
			foreach(EDIControl ec in ReceiverInfo)
			{
				if (ec.UmoName == receiverid)
					return true;
			}

			return false; // didn't find the receiver...
		}

		protected EDIRequestorDetailCollection edirdc = null;
		protected EDIRequestorDetailCollection RequesterInfo
		{
			get
			{
				if (null == edirdc)
				{
					edirdc = new EDIRequestorDetailCollection();
					edirdc.SelectAllEDIRequesterDetailsByActive(-1, true);
				}
				return edirdc;
			}
		}
		protected EDIApplicationSenderCodeCollection ediasc = null;
		protected EDIApplicationSenderCodeCollection RequesterTypes
		{
			get
			{
				if (null == ediasc)
				{
					ediasc = new EDIApplicationSenderCodeCollection();
					ediasc.SelectAllEDIApplicationSenderCodesByActive(-1, true);
				}
				return ediasc;
			}
		}
		bool ValidRequester(string requesterid, string requestertype)
		{
			if (null == RequesterTypes.FindBy(requestertype) )
				return false; // didn't find the type!!
			foreach(EDIRequestorDetail rd in RequesterInfo)
			{
				if (rd.IDCode == requesterid)
					return true;
			}

			return false; // didn't find a matching requester
		}

		void ProcessElement(IBenefitInquiry pe, int line_number)
        {
			segmentcount++;
			switch(pe.TransactionSetID)
			{
				case "ISA":
					InterchangeControlHeader ich	= (InterchangeControlHeader)pe;
					interchangecontrolnumber		= ich.InterchangeControlNumber;
					this.EDILog.ReceiverID			= ich.InterchangeReceiverID;
					this.EDILog.ReceiverIDType		= ich.InterchangeIDQualifierReceiver;
					this.EDILog.ReceiveDate			= ich.InterchangeDateTime;
					this.EDILog.LineCount			= 0; // can't initialize till done parsing
					return;
				case "IEA":
					InterchangeControlTrailer ict = (InterchangeControlTrailer)pe;
					if (ict.InterchangeControlNumber != interchangecontrolnumber)
					{
						string msg = "interchange control #'s differ!! incorrect ISA/IEA pairing!!";
						this.WriteErrorLog(msg, EventLogEntryType.Warning);
					}
					if (ict.NumberIncludedFunctionalGroups != functionalgroupcount)
					{
						string msg = "functional group miscount!!!";
						this.WriteErrorLog(msg, EventLogEntryType.Warning);
					}
					return;
				case "GS":
					GroupHeader gh = (GroupHeader)pe;
					functionalIdentifierCode = gh.FunctionalIdentifierCode;
					groupControlNumber       = gh.GroupControlNumber;
					return;
				case "GE":
					functionalIdentifierCode = null;
					GroupTrailer gt = (GroupTrailer)pe;
					if (gt.GroupControlNumber != groupControlNumber)
					{
						string msg = "group control #'s differ!! incorrect GS/GE pairing!!";
						this.WriteErrorLog(msg, EventLogEntryType.Warning);
					}
					if (gt.NumberTransactionSets != transactionsetcount)
					{
						string msg = "transaction set miscount!!!";
						this.WriteErrorLog(msg, EventLogEntryType.Warning);
					}
					// count the functional groups
					functionalgroupcount++;
					return;
				case "ST":
					TransactionSetHeader tsh     = (TransactionSetHeader)pe;
					transactionSetControlNumber  = tsh.TransactionSetControlNumber;
					transactionSetIdentifierCode = tsh.TransactionSetIdentifierCode;
					segmentcount = 0;

					o2010Elist = new x12_2010ECollection();
					return;
				case "SE":
					// Okay we are at the end of a "segment", so let's process the 
					// data we've collected

					x12SE se = (x12SE)pe;
					if (transactionSetControlNumber != se.TransactionSetControlNumber)
					{
						string msg = "transaction control #'s differ!! incorrect ST/SE pairing!!";
						this.WriteErrorLog(msg, EventLogEntryType.Warning);
					}
					if (segmentcount != se.NumberOfIncludedSegments)
					{
						string msg = "transaction segment miscount!!!";
						this.WriteErrorLog(msg, EventLogEntryType.Warning);
					}

					// Verify the requester & receiver are known
//					if (o2000A.NM103 == "Active Health Management")
					bool validRequester = ValidRequester(o2000A.NM109, o2000A.NM108);
					bool validReceiver  = ValidReceiver (o2010B.NM109, o2010B.NM108);
					if (validRequester && validReceiver)
					{
						// Process this transaction Set
						string errmsg = ProcessTransactionSet(o2000A, o2010B, o2010C, o2010D, o2010Elist);
						if (null != errmsg)
						{
							string msg = String.Format("Transaction #{0} at line #{1} rejected! reason is \"{2}\"", transactionSetControlNumber, line_number, errmsg);
							this.WriteErrorLog(msg, System.Diagnostics.EventLogEntryType.Warning);
						}
					}
					else
					{
						// process invalid requests and/or receivers here
						string msg = "";
						if (!validRequester)
							msg = String.Format("invalid requester, type = {0}, id = {1}", o2000A.NM108, o2000A.NM109);
						if (!validReceiver)
						{
							if (msg != "")
								msg += "\r\n";
							msg += String.Format("invalid receiver, type = {0}, id = {1}", o2010B.REF01, o2010B.REF02);
						}
						this.WriteErrorLog(msg, System.Diagnostics.EventLogEntryType.Warning);
					}

					// Clean up for the next transaction set...
					transactionSetControlNumber  = null;
					transactionSetIdentifierCode = null;
					transactionsetcount++;
					IsRequest = false; // wait for next BHT to define the transfer
					InitObjects(); // clear out our state for next parsing pass...
					return;
				case "BHT":
					BeginningHierarchicalTransfer bht = (BeginningHierarchicalTransfer)pe;
					IsRequest               = (bht.HierarchicalStructureCode == "0078") && (bht.TransactionSetPurposeCode == "13");
					referenceIdentification = bht.ReferenceIdentification;
					hierarchicalDate        = bht.HierarchicalDate;
					return;
				default:
					break;
			}

			// not a 278 Health Care Services Review Information, ignore until next GS/GE group
			if (functionalIdentifierCode != "HI") 
				return;

			// ignore transaction segments until we're back in a 278 loop
			if (transactionSetIdentifierCode != "278")
				return;
			if (!IsRequest)
				return;

			// The "HL" segment switches our loop state. So process
			// this separately and get out.
			if (pe.TransactionSetID == "HL")
			{	
				DependentLevel dpl = (DependentLevel)pe;
				switch(dpl.HierarchicalLevelCode)
				{
					case "20": // information source
						loop278 = "2000A";
						o2000A = new x12_2000A();
						break;
					case "21": // information receiver
						loop278 = "2000B";
						o2010B = new x12_2010B();
						break;
					case "22": // subscriber
						loop278 = "2000C";
						o2010C = new x12_2010C();
						break;
					case "23": // dependent
						loop278 = "2000D";
						o2010D = new x12_2010D();
						break;
					case "19": // provider of service
						loop278 = "2000E";
						o2010E = new x12_2010E();
						o2010Elist.AddRecord(o2010E);
						break;
					case "SS": // service level
						loop278 = "2000F";
						o2000F = new x12_2000F();
						o2010E.AddService(o2000F);
						break;
					default:
						break;
				}
				return;
			}

			// Now handle all the other segments...
			switch(loop278)
			{
				case "2000A": // receiver
					o2000A.ProcessLoop(pe);
					return;
				case "2000B": // requester
					o2010B.ProcessLoop(pe);
					return;
				case "2000C":  // Patient (Subscriber)
					o2010C.ProcessLoop(pe);
					return;
				case "2000D":  // Patient (Dependent)
					o2010D.ProcessLoop(pe);
					return;
				case "2000E":  // Service supplier (i.e. facility)
					o2010E.ProcessLoop(pe);
					return;
				case "2000F":  // Services
					o2000F.ProcessLoop(pe);
					return;
				default:
					break;
			}// end of processing loops

        }// end of method ProcessElement()

		/// <summary>
		/// ParseTransactionSet():
		/// At this point we have all the information we need to turn our parsed information
		/// into a set of Active Advice objects
		/// </summary>
		/// <param name="x2000A"></param>
		/// <param name="x2010B"></param>
		/// <param name="x2010C"></param>
		/// <param name="x2010D"></param>
		/// <param name="x2010Elist"></param>
		string ProcessTransactionSet(x12_2000A x2000A, x12_2010B x2010B, x12_2010C x2010C, x12_2010D x2010D, x12_2010ECollection x2010Elist)
		{
			// Fill in the intake log
			FillIntakeLog(x2010B, x2010C, x2010D, x2010Elist);
			ediIntakeLog.CreatedBy	= EDIuserid;
			ediIntakeLog.CreateTime	= DateTime.Now;

			// Get Eligibility/coverage information
			if (ediIntakeLog.PatientMemberID == null)
				return "unique identifier for patient not found";

			if (!ProcessIntakeLog())
				return "error processing intakelog information";

			// If we didn't match the patient with Eligibility information we reject it
			if (ediIntakeLog.EligibilityId == 0)
				return "no eligibility record found";

			if (!FindExistingPatientSubscriberCoverage())
				return "error looking for existing Patient/Subscriber/Coverage";

			// Okay we have some valid patient information, time to decide what type
			// of request this is and what objects we need to create
			bool addEvent = false, addReferral = false;
			foreach(x12_2010E serviceprovider in x2010Elist)
			{
				foreach(x12_2000F service in serviceprovider.l2000F)
				{
					addEvent	= service.UM01 == "AR" || service.UM01 == "HS";
					addReferral = service.UM01 == "SC";
				}
				if (addEvent || addReferral)
					break;
			}

			if (!addEvent && !addReferral)
			{
				// This is just an empty intake???
				return "no referral or event to add!";
			}
			if (addEvent)
				SaveEvent(x2010Elist);
			if (addReferral)
			{
				bool haveReferral = CreateReferral(x2010Elist);
				if (haveReferral)
					SaveReferral();
			}
			return null;
		}

		// Only fetch the EDI user id once.
		int ediuserid = 0;
		bool ediuseridsearched = false;
		int EDIuserid
		{
			get
			{
				if (ediuseridsearched)
					return ediuserid;

				ediuseridsearched = true;
				AAUserCollection users = new AAUserCollection();
				users.GetAllAAUsers(-1);
				foreach(AAUser user in users)
				{
					if (user.LoginName == "EDI")
					{
						ediuserid = user.UserId;
						return ediuserid;
					}
				}
				return 0; // not found!!!
			}
		}


		int IntakeResolutionIDByCode(string code)
		{
			IntakeResolutionCollection irc = new IntakeResolutionCollection();
			irc.LoadIntakeResolutionsByActive(-1, true);
			return irc.Lookup_IntakeResolutionIDByCode(code);
		}
		int EventStatusIDByCode(string code)
		{
			SystemStatusCollection ssc		= new SystemStatusCollection();
			ssc.LoadSystemStatusesByActive(-1, true);
			return ssc.Lookup_StatusIdByCode(code);
		}
		int EventTypeID(x12_2010ECollection x2010Elist)
		{
			EventTypeCollection etc			= new EventTypeCollection();
			etc.LoadEventTypesByActive(-1, true);
			string eventtype				= MapEventType(x2010Elist);
			return etc.Lookup_EventTypeIDByCode(eventtype);
		}
		int EventSourceID(x12_2010ECollection x2010Elist)
		{
			EventSourceCollection esc		= new EventSourceCollection();
			esc.LoadEventSourcesByActive(-1, true);
			string eventsource				= MapEventSource(x2010Elist);
			return esc.Lookup_EventSourceIDByCode(eventsource);
		}
		int DateActualProjectedID(string code)
		{
			DateActualProjectedCollection dap = new DateActualProjectedCollection();
			dap.LoadDateActualProjectedByActive(-1, true);
			return dap.Lookup_DateActualProjectedIDByCode(code);
		}

		/// <summary>
		/// CreateEvent()
		/// creates the event object and initializes it from the parsed data.
		/// This is called just prior to saving the event.
		/// </summary>
		/// <param name="x2010Elist"></param>
		/// <returns>=true, then successful</returns>
		bool CreateEvent(x12_2010ECollection x2010Elist)
		{

			try
			{
				ediEvent.StartDate				= ediIntakeLog.ServiceDate;
				ediEvent.StatusID				= EventStatusIDByCode("OPEN");
				ediEvent.StatusChangeTime		= DateTime.Now;
				ediEvent.StatusChangedBy		= EDIuserid;
				ediEvent.CreatedBy				= EDIuserid;
				ediEvent.CreateTime				= DateTime.Now;
				ediEvent.StartDateAP			= DateActualProjectedID("A");				// Actual
				ediEvent.EventTypeID			= EventTypeID(x2010Elist);					// UM03 Service Type
				ediEvent.EventSourceID			= EventSourceID(x2010Elist);				//EMER/URG, UM06
				ediEvent.Description			= "EDI Review Requests";
				ediEvent.PrimaryProblemID		= FindEDIProblem();							// find EDI problem, also locates our Patient
				ediEvent.PatientId				= ediPatient.PatientId;						// =0 if we don't have a patient object yet
				MapFacility(x2010Elist);
				MapProvider(x2010Elist);
				ediEvent.PhysicianReview		= false;
				ediEvent.MaternityEvent			= false;
				ediEvent.NewbornEvent			= false;
				ediEvent.ServiceDate			= ediIntakeLog.ServiceDate;
				ediEvent.LOSObservedPatients	= 0; // populated after Dx/Px codes loaded
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				return false;
			}

			return true;
		}

		#region entity properties
		protected IntakeLog ilog = null;
		IntakeLog ediIntakeLog
		{
			get
			{
				if (null == ilog)
				{
					ilog = new IntakeLog();
					ilog.IsNew = true;
				}
				return ilog;
			}
			set { ilog = value; }
		}

		protected Event evt = null;
		Event ediEvent
		{
			get
			{
				if (evt == null)
					evt = new Event(ediPatient, true); // new event
				return evt;
			}
			set
			{
				evt = value;
			}

		}
		protected Subscriber subscriber = null;
		protected Subscriber ediSubscriber
		{
			get 
			{
				if (null == subscriber)
					subscriber = new Subscriber(true);
				return subscriber;
			}
			set { subscriber = value; }
		}
		protected Patient patient = null;
		protected Patient ediPatient
		{
			get
			{
				if (null == patient)
					patient = new Patient(true); // new patient
				return patient;
			}
			set { patient = value; }
		}
		Referral referral = null;
		Referral ediReferral
		{
			get
			{
				if (null == referral)
					referral = new Referral();
				return referral;
			}
			set { referral = value; }
		}

		Problem problem = null;
		Problem ediProblem
		{
			get
			{
				if (null == problem)
					problem = new Problem(ediPatient);

				return problem;
			}
			set
			{
				problem = value;
			}
		}

		PatientCoverageData patientCoverageData = null;
		PatientCoverageData ediPatientCoverageData
		{
			get
			{
				if (null == patientCoverageData)
				{
					patientCoverageData = new PatientCoverageData();
					patientCoverageData.IsNew = true;
				}
				return patientCoverageData;
			}
			set
			{
				patientCoverageData = value;
			}
		}
		PatientCoverage patientCoverage = null;
		PatientCoverage ediPatientCoverage
		{
			get
			{
				if (null == patientCoverage)
					patientCoverage = new PatientCoverage(true);
				return patientCoverage;
			}
			set
			{
				patientCoverage = value;
			}
		}
#endregion

		/// <summary>
		/// SaveEvent()
		/// This method will save the Event to the database.
		/// If required, coverage is pulled from the eligibility
		/// tables.
		/// </summary>
		/// <returns></returns>
		bool SaveEvent(x12_2010ECollection x2010Elist)
		{
			try
			{

				// create & initialize our Event object. Do this first, that way
				// if there's a problem we aren't creating other db objects
				if (!CreateEvent(x2010Elist) )
				{
					// there was an error with the event
					return false;
				}

				// If the PatientCoverage is "new" then we need to fill it in from 
				// eligibility tables
				if (ediPatientCoverage.IsNew)
				{
					// If we don't have existing Patient Coverage, then get a list of
					// coverages from the Eligibility table
					AvailableCoverageCollection acc = new AvailableCoverageCollection();
					acc.GenerateEligibilityCoverageList(-1, ediIntakeLog.EligibilityId, ediEvent.ServiceDate);
					if (acc.Count < 1)
						return false;	// there's no coverage available!

					// We don't care what coverage, so take the first
					ediPatientCoverage.PatientEligibilityID			= acc[0].PatientEligibilityID;
					ediPatientCoverage.SubscriberEligibilityID		= acc[0].SubscriberEligibilityID;
					ediPatientCoverage.SORGID						= acc[0].SORGID;
					ediPatientCoverage.PlanID						= acc[0].PlanID;
					ediPatientCoverage.AlternatePatientID			= ediIntakeLog.PatientMemberID;

					Eligibility elig							= new Eligibility();
					if (!elig.Load(ediPatientCoverage.PatientEligibilityID) )
					{
						// couldn't load the eligibility information
						return false;
					}
					ediPatient.MedicaidID						= elig.MedicaidId;
					ediPatient.MedicareID						= elig.MedicareId;
					ediPatientCoverage.AlternateInsuranceID		= elig.AlternateInsuranceID;
					ediPatientCoverage.AlternateSubscriberID	= elig.AlternateSubscriberID;
					ediPatientCoverage.RelationShipID			= elig.RelationshipID;

					EligibilityPlan eligp = new EligibilityPlan();
					if (!eligp.Load(ediPatientCoverage.PatientEligibilityID, ediPatientCoverage.PlanID) )
					{
						// Couldn't load the eligibility information...
						return false;
					}

					// Create a coverage "history" record that is associated with this PatientCoverage
					ediPatientCoverageData					= new PatientCoverageData(ediPatientCoverage);
					ediPatientCoverageData.Active			= true;
					ediPatientCoverageData.EffectiveDate	= eligp.EffectiveDate;
					ediPatientCoverageData.TerminationDate	= eligp.TerminationDate;
					// If the coverage has a termination date, then set the terminated by userid & time
					if (ediPatientCoverageData.TerminationDate == DateTime.MinValue) // it's null
					{
						ediPatientCoverageData.TerminatedBy		= this.EDIuserid;
						ediPatientCoverageData.TerminationDate	= DateTime.Now;
					}
				}

				// Starting to save stuff, start up a transaction
				ediSubscriber.Save(ediPatient, ediPatientCoverage, (ediPatient.IsChanged) ); // save patient if it doesn't exist or has changed

				// Save our Intake Log, first update the Patient & Subscriber Ids
				ediIntakeLog.PatientId			= ediPatient.PatientId;
				ediIntakeLog.SubscriberId		= ediSubscriber.SubscriberId;
				ediIntakeLog.PlanID				= ediPatientCoverage.PlanID;
				ediIntakeLog.SORGId				= ediPatientCoverage.SORGID;
				ediIntakeLog.IntakeResolutionID	= this.IntakeResolutionIDByCode("ADDE"); // we're adding an event!
				ediIntakeLog.Save();

				if (ediProblem.IsNew) // problem is new, needs saving
				{
					ediProblem.ProblemDescriptionID	= this.EDIProblemDescriptionID;
					ediProblem.Patient				= ediPatient;
					ediProblem.Save(ediPatientCoverage);
				}

				// Okay we can finally save the Event since we have saved:
				//    - Subscriber
				//    - Patient
				//    - PatientCoverage (& PatientCoverageData)
				//    - PatientSubscriberLog
				//    - IntakeLog
				//    - Problem

				ediEvent.Save(ediPatientCoverage, ediProblem);
				return true;
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				return false;
			}

		}// end of method

		int MapProvider(x12_2010ECollection x2010Elist)
		{
			foreach(x12_2010E serviceprovider in x2010Elist)
			{
				if ( ( (serviceprovider.NM101 == "1T") || (serviceprovider.NM101 == "SJ") ) &&
					 ( (serviceprovider.REF01 == "N5") ||
					   (serviceprovider.REF01 == "ZH") ||
					   (serviceprovider.REF01 == "1G") ) )
				{
					string alternateproviderid = serviceprovider.REF02;
					// Look up the provider information...
					ProviderCollection pc = new ProviderCollection();
				}
			}

			return 0; // not found
		}


		int MapFacility(x12_2010ECollection x2010Elist)
		{
			foreach(x12_2010E serviceprovider in x2010Elist)
			{
				if ( ( (serviceprovider.NM101 == "FA") && (serviceprovider.REF01 == "SJ") ) &&
				 	 ( (serviceprovider.REF01 == "N5") ||
					   (serviceprovider.REF01 == "ZH") ||
					   (serviceprovider.REF01 == "N7") ) )
				{
					string alternatefacilityid = serviceprovider.REF02;
					// Look up the facility information...
					ActiveAdvice.DataLayer.Facility f = new ActiveAdvice.DataLayer.Facility();
					if (f.LoadFacilityByAlternateID(alternatefacilityid) )
					{
						ediEvent.FacilityID = f.FacilityID;
					}
				}
			}

			return 0; // not found
		}


		int ediProblemDescriptionID = 0;
		bool checkedProblemDescription = false;
		int EDIProblemDescriptionID
		{
			get
			{
				if (checkedProblemDescription)
					return ediProblemDescriptionID;

				checkedProblemDescription = true;
				ProblemDescriptionCollection pdc = new ProblemDescriptionCollection();
				pdc.LoadProblemDescriptionsByActive(-1, true);
				foreach(ProblemDescription pd in pdc)
				{
					if (pd.Code == "EDI")
					{
						ediProblemDescriptionID = pd.CodeId;
						return ediProblemDescriptionID;
					}
				}

				return 0; // didn't find anything
			}
		}

		int FindEDIProblem()
		{
			if (0 == EDIProblemDescriptionID)
				return 0; // bad, we are missing a code table value!!

			if (ediPatient.IsNew) // new patients can't possible have problems...
				return 0;

			ProblemCollection pc = new ProblemCollection();
			pc.LoadLinkedPatientProblemsByDescID(ediPatient, EDIProblemDescriptionID);
			if (pc.Count < 1)
				return 0; // don't have an existing Problem with "EDI" as the description

			ediProblem = pc[0];
			return ediProblem.ProblemID;
		}

		// Map the x12 service type to the AHM system 
		string MapEventSource(x12_2010ECollection x2010Elist)
		{
			foreach (x12_2010E serviceprovider in x2010Elist)
			{
				foreach(x12_2000F service in serviceprovider.l2000F)
				{
					if (service.UM06 != null)
					{
						switch(service.UM06)
						{
							case "03":
							case "3":
								return "EMER";
							case "U":
								return "URGE";
						}
						return "UNKN";
					}
				}
			}

			return "UNKN";
		}


		// Map the x12 service type to the AHM system 
		string MapEventType(x12_2010ECollection x2010Elist)
		{
			foreach (x12_2010E serviceprovider in x2010Elist)
			{
				foreach(x12_2000F service in serviceprovider.l2000F)
				{
					if (service.UM03 != null)
					{
						return "UNKN";
					}
				}
			}

			return "UNKN";
		}

		bool CreateReferral(x12_2010ECollection x2010Elist)
		{
			return false;
		}

		bool SaveReferral()
		{
			return false;
		}
		void FillIntakeLog(x12_2010B x2010B, x12_2010C x2010C, x12_2010D x2010D, x12_2010ECollection x2010Elist)
		{

			// Find the "service date" record in the services list...
			foreach(x12_2010E serviceprovider in x2010Elist)
			{
				foreach(x12_2000F service in serviceprovider.l2000F)
				{
					if (service.DTP01 == "472")
					{
						ediIntakeLog.ServiceDate = service.DTP03;
						break;
					}
				}
			}
			ediIntakeLog.CallerFName = x2010B.PER02;
			ediIntakeLog.CallerLName = x2010B.NM103;
			if (x2010B.PER02 == null)
			{
				if (x2010B.NM102 == "1")
					ediIntakeLog.CallerFName = x2010B.NM104;
				if (x2010B.NM102 == "2")
				{
					ediIntakeLog.CallerFName = null;
					ediIntakeLog.CallerLName = null;
				}
			}

			if (x2010B.PER03 == "TE")
				ediIntakeLog.CallerPhone = x2010B.PER04;
			if (x2010B.PER05 == "EX")
				ediIntakeLog.CallerPhoneExt = x2010B.PER06;

			ediIntakeLog.SubscriberSSN		= x2010C.REF02_SY;
			ediIntakeLog.SubscriberMemberID	= x2010C.NM109_MI;
			ediIntakeLog.SubscriberFname		= x2010C.NM103;
			ediIntakeLog.SubscriberLName		= x2010C.NM104;
			ediIntakeLog.SubscriberMI			= x2010C.NM105;
			if (x2010D != null) // patient is not subscriber
				ediIntakeLog.PatientMemberID			= x2010D.NM109_MI;
			else
				ediIntakeLog.PatientMemberID	= ediIntakeLog.SubscriberMemberID;

		}


		bool ProcessIntakeLog()
		{
			ediIntakeLog.EligibilityId = 0; // indicates that no eligibility data was found

			if (ediIntakeLog.PatientMemberID == null)
				return false;

			// Okay let's see if we have eligibility information for this alternateid...
			EligibilityCollection ec = new EligibilityCollection();
			ec.SelectAllByMembershipID(-1, ediIntakeLog.PatientMemberID);
			if (ec.Count < 1)
				return false;

			// okay, we have a collection of eligibility records that match
			// the current patient alternate id. We need to find the first one
			// that has valid coverage
			foreach(Eligibility e in ec)
			{
				// Determine if the current eligibility has valid coverage
				// for the "service date"
				ediIntakeLog.EligibilityId	= e.EligibilityId;
				ediIntakeLog.PatientDOB		= e.MemberDOB;
				ediIntakeLog.PatientFName		= e.FirstName;
				ediIntakeLog.PatientLName		= e.LastName;
				ediIntakeLog.PatientMI		= e.MiddleInitial;
				ediIntakeLog.PatientSSN		= e.MemberSSN;
				ediIntakeLog.MORGId			= e.MORGID;
				ediIntakeLog.ORGId			= e.ORGID;
				ediIntakeLog.SORGId			= e.SORGID;
				ediIntakeLog.PatientGender	= e.MemberGender;

				// Get all the subscribers for this member. Since we can
				// only search by the "alternate id" we could get multiple
				// matches, so filter out the ones that don't matter...
				EligibilityCollection subscribers = new EligibilityCollection();
				subscribers.SelectAllByMembershipID(-1, e.AlternateSubscriberID);
				foreach(Eligibility subscriber in subscribers)
				{
					// find the subscriber for this member (i.e. same MOS)
					if ( (e.MORGID == subscriber.MORGID) &&
						 (e.ORGID  == subscriber.ORGID)  &&
						 (e.SORGID == subscriber.SORGID) )
					{
						// found subscriber, fill in intake log
						ediIntakeLog.SubscriberMemberID	= subscriber.MembershipId;
						ediIntakeLog.SubscriberFname		= subscriber.FirstName;
						ediIntakeLog.SubscriberLName		= subscriber.LastName;
						ediIntakeLog.SubscriberMI			= subscriber.MiddleInitial;
						ediIntakeLog.SubscriberSSN		= subscriber.MemberSSN;
						return true;
					}
				}// end of traversing the subscriber eligibility records
			}

			return false; // we are missing something!
		}

		/// <summary>
		/// FindExistingPatientSubscriberCoverage()
		/// Initialize our local copies of Patient,
		/// Subscriber & PatientCoverage with 
		/// existing values from the database if
		/// they exist.
		/// 
		/// Possible to find only Patient, or all 3
		/// </summary>
		/// <returns>bool, =true then successful (doesn't mean found existing coverages)</returns>
		bool FindExistingPatientSubscriberCoverage()
		{
			// Okay we have processed the intake log info, so we have info to 
			// create a patient from

			try
			{
				// See if the patient exists...
				PatientCoverageCollection pcc = new PatientCoverageCollection();
				pcc.LoadPatientCoveragesByAlternateID(-1, ediIntakeLog.PatientMemberID);
				bool havePatient = false;
				foreach(PatientCoverage pc in pcc)
				{
					if (!havePatient) // don't want to waste time re-creating Patient
					{
						ediPatient	= pc.Patient; // get the patient record
						havePatient		= true;
					}
					if (pc.AlternateSubscriberID == ediIntakeLog.SubscriberMemberID)
					{
						ediSubscriber			= pc.Subscriber;
						ediPatientCoverage	= pc;
						return true;
					}
				}
			}
			catch(Exception e)
			{
				string msg = e.Message;
				return false;
			}

			return true;
		}

		/// <summary>
		/// WriteErrorLog()
		/// Write a string to the error ediIntakeLog. If the file hasn't been
		/// openend, it will be opened. Keeps a member variable to
		/// track the stream.
		/// </summary>
		/// <param name="logmsg">string, error message to display in the log</param>
		protected void WriteErrorLog(string logmsg, EventLogEntryType type)
		{
			try
			{
				if (!EventLog.SourceExists("EDI Interface") )
					EventLog.CreateEventSource("EligibilityInterface", "ActiveAdvice");
				if (++write_error_log_count < this.max_error_log_count)
 					EventLog.WriteEntry("EDI Interface", logmsg, type);

				// if we have a filename, create our error log stream if not created yet...
				if ( (null == sw_errorlog) && (this.errorLogFileName != null) )
				{
					// Let's open an error log
					sw_errorlog = new StreamWriter(this.errorLogFileName, true, System.Text.Encoding.ASCII);
					if (null == sw_errorlog) return;
					sw_errorlog.AutoFlush = true;	// write stuff out immediately so we don't lose it
				}
				if (sw_errorlog != null)
				{
					sw_errorlog.Write(DateTime.Now.ToString("[mm.dd.yyyy@hh:mm:ss]"));
					sw_errorlog.WriteLine(logmsg);
				}
			}
			catch(Exception ex)
			{
				if (++write_error_log_count < this.max_error_log_count)
				{
					if (!EventLog.SourceExists("EligibilityInterface") )
						EventLog.CreateEventSource("EligibilityInterface", "ActiveAdvice");
					EventLog.WriteEntry("EligibilityInterface", ex.Message, EventLogEntryType.Error);
				}
			}
		}

	}// end of class

	public class x12_2000A
	{
		public string NM102, NM103, NM108, NM109;
		public string PER01, PER02;
		public void ProcessLoop(IBenefitInquiry pe)
		{
			switch(pe.TransactionSetID)
			{
				case "NM1":
					DependentName dn = (DependentName)pe;
					NM102 = dn.EntityTypeQualifier;
					NM103 = dn.LastName;
					NM108 = dn.IdentificationCodeQualifier;
					NM109 = dn.IdentificationCode;
					break;
				case "PER":
					DependentContactInformation dci = (DependentContactInformation)pe;
					PER01 = dci.ContactFunctionCode;
					PER02 = dci.Name;
					break;
			}
		}
	}

	public class x12_2010B
	{
		public string REF01, REF02;
		public string NM101, NM102, NM103, NM104, NM108, NM109;
		public string PER02, PER03, PER04, PER05, PER06;

		public void ProcessLoop(IBenefitInquiry pe)
		{
			switch(pe.TransactionSetID)
			{
				case "PER":
					DependentContactInformation dci = (DependentContactInformation)pe;
					PER03 = dci.CommunicationNumberQualifier[0];
					if (dci.CommunicationNumberQualifier[0] == "TE") // it's a telephone #
						PER04 = dci.CommunicationNumber[0];
					PER05 = dci.CommunicationNumberQualifier[1];
					if (dci.CommunicationNumberQualifier[1] == "EX") // it's an extension
						PER06 = dci.CommunicationNumber[1];

					PER02 = dci.Name;
					break;
				case "NM1":
					DependentName dn = (DependentName)pe;
					NM102 = dn.EntityTypeQualifier;
					NM103 = dn.LastName;
					NM104 = dn.FirstName;
					NM108 = dn.IdentificationCodeQualifier;
					NM109 = dn.IdentificationCode;
					break;
				case "REF":
					DependentAdditionalIdentification dai = (DependentAdditionalIdentification)pe;
					REF01 = dai.ReferenceIdentificationQualifier;
					REF02 = dai.ReferenceIdentification;
					break;
			}// end of switch
		}// end of method
	}// end of class

	public class x12_2010C // Subscriber
	{
		public string NM109_MI;
		public string REF02_SY;
		public string NM103, NM104, NM105;
		public void ProcessLoop(IBenefitInquiry pe)
		{
			switch(pe.TransactionSetID)
			{
				case "REF":
					DependentAdditionalIdentification dai = (DependentAdditionalIdentification)pe;
					if (dai.ReferenceIdentificationQualifier == "SY")
						REF02_SY = dai.ReferenceIdentification;
					break;
				case "NM1":
					DependentName dn = (DependentName)pe;
					if (dn.IdentificationCodeQualifier == "MI")
						NM109_MI = dn.IdentificationCode;
					NM103 = dn.LastName;
					NM104 = dn.FirstName;
					NM105 = dn.MiddleName;
					break;
			}
		}
	}// end of class

	public class x12_2010D // Patient
	{
		public string NM109_MI;
		public string REF02_SY;
		public string NM103, NM104, NM105;
		public void ProcessLoop(IBenefitInquiry pe)
		{
			switch(pe.TransactionSetID)
			{
				case "REF":
					DependentAdditionalIdentification dai = (DependentAdditionalIdentification)pe;
					if (dai.ReferenceIdentificationQualifier == "SY")
						REF02_SY = dai.ReferenceIdentification;
					break;
				case "NM1":
					DependentName dn = (DependentName)pe;
					if (dn.IdentificationCodeQualifier == "MI")
						NM109_MI = dn.IdentificationCode;
					NM103 = dn.LastName;
					NM104 = dn.FirstName;
					NM105 = dn.MiddleName;
					break;
			}
		}
	}// end of class

	public class x12_2010E
	{
		public x12_2010E() {} // public constructor

		public x12_2000FCollection l2000F = new x12_2000FCollection();
		public string REF01,REF02;
		public string NM101;
		public string PRV03;
		public void AddService(x12_2000F o2000F)
		{
			l2000F.AddRecord(o2000F);
		}

		public void ProcessLoop(IBenefitInquiry pe)
		{
			switch(pe.TransactionSetID)
			{
				case "REF":
					DependentAdditionalIdentification dai = (DependentAdditionalIdentification)pe;
					REF01 = dai.ReferenceIdentificationQualifier;
					REF02 = dai.ReferenceIdentification;
					break;
				case "NM1":
					DependentName dn = (DependentName)pe;
					NM101 = dn.EntityIdentifierCode;
					break;
				case "PRV":
					DependentBenefitRelatedProvider dbr = (DependentBenefitRelatedProvider)pe;
					PRV03 = dbr.ReferenceIdentification;
					break;
			}// end of switch
		}// end of method
	}// end of class

	public class x12_2010ECollection : CollectionBase
	{
		public x12_2010ECollection() {}

		public virtual int AddRecord(x12_2010E data)
		{
			int index = List.Add(data);
			OnSetComplete(index, data, data);
			return index;
		}
		public x12_2010E GetAt(int index)
		{
			return base.List[index] as x12_2010E;
		}
		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public x12_2010E this[int index]
		{
			get
			{
				return (x12_2010E)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

	}// end of x12_2010ECollection

	public class x12_2000F
	{
		public string UM01, UM03, UM04, UM06;
		public string DTP01;
		public DateTime DTP03;

		public x12_2000F() { }

		public void ProcessLoop(IBenefitInquiry pe)
		{
			switch(pe.TransactionSetID)
			{
				case "UM":
					x12UM um = (x12UM)pe;
					UM01 = um.RequestCategoryCode;
					UM03 = um.ServiceTypeCode;
					UM04 = um.FacilityTypeCode;
					break;
				case "DTP":
					DependentDate dd = (DependentDate)pe;
					DTP01 = dd.DateTimeQualifier;
					DTP03 = dd.DateTimePeriod;
					break;
				case "REF":
					break;
				case "PRV":
					break;
			}
		}
	}// end of class
	public class x12_2000FCollection : CollectionBase
	{
		public x12_2000FCollection() {}

		public virtual int AddRecord(x12_2000F data)
		{
			int index = List.Add(data);
			OnSetComplete(index, data, data);
			return index;
		}
		public x12_2000F GetAt(int index)
		{
			return base.List[index] as x12_2000F;
		}
		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public x12_2000F this[int index]
		{
			get
			{
				return (x12_2000F)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

	}// end of x12_2000FCollection

}// end of namespace
