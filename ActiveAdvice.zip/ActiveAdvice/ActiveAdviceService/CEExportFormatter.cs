using System;
using System.IO;
using System.Data;
using System.Reflection;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;

namespace ActiveAdviceService
{
	/// <summary>
	/// Summary description for CEExportFormatter.
	/// </summary>
	[TableMapping(null)]
	public class CEExportFormatter : BaseDataClass
	{
		public CEExportFormatter(CEExportArguments args)
		{
			// we have all the arguments we need embedded in the
			// task string

			if (!ReadCareEngineData(args))
			{
				Exception e = new Exception("Error writing out Care Engine export data", null);
				throw e;
			}
		}

		private bool ReadCareEngineData(CEExportArguments args)
		{
			StreamWriter sw_ce = null;
			try
			{
				sw_ce = new StreamWriter(args.FileName, false, System.Text.Encoding.ASCII);
				if (null == sw_ce)
					return false;

				// First fill in our tables with the data we wish to export
				System.Guid batch = System.Guid.NewGuid();
				int count = Convert.ToInt32(SqlData.SPExecScalar("usp_Staging_ExportCareEngine", new object[] { batch, SQLDataDirect.MakeDBValue(args.MORGID, 0), SQLDataDirect.MakeDBValue(args.ORGID, 0), SQLDataDirect.MakeDBValue(args.SORGID, 0), SQLDataDirect.MakeDBValue(args.StartDate), SQLDataDirect.MakeDBValue(args.EndDate)}));

				// Write out the header, it's format is:
				//    H07/02/200416:092271

				string header = "H" + DateTime.Now.ToString("MM/dd/yyyyhh:mm") + count.ToString();
				sw_ce.WriteLine(header);
				// Okay we have a result set, time to read it in...
				Staging_CEExportCollection responses = new Staging_CEExportCollection();
				responses.LoadCareEngineExportByBatchNumber(-1, batch);

				// Now read our data and output it to the file...
				foreach (Staging_CEExport response in responses)
				{
					string response_line = "D" + CEExportFormatter.FormatOutput(response);
					sw_ce.WriteLine(response_line);
				}

				CollectionIndexer responsesBypatient = responses.IndexBy_PatientID;

				responses = null; // free these up...

				Staging_CEExportMedicationCollection medications = new Staging_CEExportMedicationCollection();
				medications.SelectAllCEExportMedicationByBatchNumber(-1, batch);
				foreach(Staging_CEExportMedication medication in medications)
				{
					Staging_CEExport response = (Staging_CEExport)responsesBypatient.LookupMember("patientId", medication.PatientID);
					string patient_line    = CEExportFormatter.FormatOutput(response);
					string medication_line = CEExportFormatter.FormatOutput(medication);
					string detail_line     = "D" + patient_line.Substring(0, 370) + medication_line.Substring(371, medication_line.Length - 371);
					sw_ce.WriteLine(medication_line);
				}

				responsesBypatient = null;
				medications        = null; // free up...

				Staging_CEExportPatientCollection patients = new Staging_CEExportPatientCollection();
				patients.SelectAllCCExportPatientByBatchNumber(-1, batch);
				foreach(Staging_CEExportPatient patient in patients)
				{
					string patient_line = "D" + CEExportFormatter.FormatOutput(patient);
					sw_ce.WriteLine(patient_line);
				}
				patients = null;

				string trailer = "T" + count.ToString();
				sw_ce.WriteLine(trailer);
			}
			catch(Exception e)
			{
				if (null != sw_ce)
					sw_ce.Close();
				string msg = e.Message;
				throw e;
			}

			if (null != sw_ce)
				sw_ce.Close();

			return true; // success!
		}

		/// <summary>
		/// FormatElement()
		/// this method will take in the input data type
		/// and produce a string of the specified length.
		/// If the string is too short to fit the field 
		/// required, the string is "left-padded" with spaces,
		/// if it is too large then it is right-truncated.
		/// 
		/// Certain assumptions are made:
		///     DateTime .... Year = 1 indicates a NULL value
		///     Int ......... =0, NULL value
		///     
		/// </summary>
		/// <param name="length">size of the target field</param>
		/// <param name="element">object to convert to string</param>
		/// <returns>string, converted datum to a string value & padded/truncated to length</returns>
		protected static string FormatElement(int length, object element)
		{
			string s;
			if (element == null)
				s = "";
			else if (element.GetType() == typeof(System.DateTime))
			{
				if ( ((DateTime)element).Year == 1)	// our value of null is a year of '1'
					s = "";
				else
					s = ((DateTime)element).ToString("MM/dd/yyyy");
			}
			else if (element.GetType() == typeof(System.Int32) )
			{
				int i = Convert.ToInt32(element);
				if (i == 0)
					s = ""; // null value
				else
					s = i.ToString();
			}
			else if (element.GetType() == typeof(System.Char) )
			{
				char c = Convert.ToChar(element);
				if (c == '\0') // it's a null?
					s = "";
				else
					s = c.ToString();
			}
			else
			{
				s = element.ToString();
				if (s.Length < 1)
					s = "";
			}

			int l = s.Length;
			if (l > length)
				s = s.Substring(0, length); // right truncation
			else if (l < length)
				s = s.PadRight(length, ' ');

			return s;
		}

		/// <summary>
		/// FormatOutput
		/// This method will traverse all the properties for the
		/// current object and create a formatted output string
		/// based on the start/end values in the ImportExportFieldPos attribute.
		/// </summary>
		/// <returns>string filled with properties that is the proper length</returns>
		public static string FormatOutput(object t)
		{
			try
			{
				MemberInfo[] members = t.GetType().GetMembers();
				int max_pos = 0;
				for (int i = 0; i < members.Length; i++)
				{
					Object[] customAttr = members[i].GetCustomAttributes(typeof(ImportExportFieldPos), true);
					for (int j = 0; j < customAttr.Length; j++)
					{
						if (customAttr[j].GetType() == typeof(ImportExportFieldPos) )
						{
							ImportExportFieldPos fp = (ImportExportFieldPos)customAttr[j];
							if (fp.End > max_pos)
								max_pos = fp.End;
						}
					}
				}// end of cycling through members

				if (0 == max_pos) // didn't find anything!!
					return "";

				// Okay, we know how large of a string we need.
				string output = new string(' ', max_pos+1);

				for (int i = 0; i < members.Length; i++)
				{
					// Now cycle through the members and convert their values
					Object[] customAttr = members[i].GetCustomAttributes(true);
					for (int j = 0; j < customAttr.Length; j++)
					{
						// when we find a property with a "ImportExportFieldPos" attribute
						// convert to a string and put it into our output string
						if (customAttr[j].GetType() == typeof(ImportExportFieldPos) )
						{
							ImportExportFieldPos fp = (ImportExportFieldPos)customAttr[j];
							PropertyInfo pi = t.GetType().GetProperty(members[i].Name);
							Object obj = pi.GetValue(t,BindingFlags.GetProperty,null, null, null);
							string s = CEExportFormatter.FormatElement((fp.End - fp.Start)+1, obj);
							output = output.Remove(fp.Start-1, (fp.End - fp.Start)+1); // clip out the string piece to replace
							output = output.Insert(fp.Start-1, s); // insert the new piece
						}
					}
				}

				return output; // not successsful
			}
			catch(Exception ex)
			{
				string msg = ex.Message;
				throw(ex);
			}
		}// end of method
	}
}
