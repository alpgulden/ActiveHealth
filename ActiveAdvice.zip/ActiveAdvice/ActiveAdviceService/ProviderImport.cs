using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Collections.Specialized;
using System.Security.Permissions;
using System.Diagnostics;

namespace InterfaceReader
{

	public class ProviderParser
	{
		//
		// ParseFile():
		// This routine will open up the file and begin parsing the data
		protected string ConnectionString;
		public int ParseFile(System.String FileName, System.String strConnection, String errorlogfilename)
		{
			try
			{
				FileIOPermission filePerm = new FileIOPermission(FileIOPermissionAccess.Read, FileName);
				filePerm.Assert();
				StreamReader sr = new StreamReader(FileName);
				ConnectionString = strConnection;
				this.ParseLine(sr);
			}
			catch(Exception ex)
			{
				string message = ex.Message;

				if (!EventLog.SourceExists("ProviderInterface") )
					EventLog.CreateEventSource("ProviderInterface", "ActiveAdvice");
				EventLog.WriteEntry("ProviderInterface", ex.Message + (ex.InnerException != null ? "\n\n" + ex.InnerException.Message : ""), EventLogEntryType.Error);
				throw ex;
			}
			return 0;
		}

		public bool VerifyCheckDigit(int CheckDigit, int Record10Count, int Record20Count, int Record21Count,
			int Record22Count, int Record30Count, int Record50Count, int Record60Count,
			int Record80Count, int Record90Count)
		{
		
			// Compute the check digit
			int computed_checkdigit = 10 * Record10Count +
				                      20 * Record20Count +
				                      21 * Record21Count +
				                      22 * Record22Count +
				                      30 * Record30Count +
				                      50 * Record50Count +
				                      60 * Record60Count +
				                      80 * Record80Count +
				                      90 * Record90Count;

			return (computed_checkdigit == CheckDigit);
		}

		public int ParseLine(StreamReader sr)
		{
			string input_line;
			System.Guid batch_guid = new System.Guid(); batch_guid = Guid.NewGuid();
			RecordData rd = new RecordData();
			int Record10Count = 0, Record20Count = 0, Record21Count = 0, Record22Count = 0;
			int Record30Count = 0, Record50Count = 0, Record60Count = 0, Record80Count = 0, Record00Count = 0;
			int linecnt		= 0;
			int errorcnt	= 0;
			const int maxerrors = 15;
			bool ignoredataset = false, ignoreline = false;
			Address           pAddress           = new Address();
			FileHeader        pFileHeader        = new FileHeader();
			Provider          pProvider          = new Provider();
			GroupPractice     pGroupPractice     = new GroupPractice();
			Facility          pFacility          = new Facility();
			Network           pNetwork           = new Network();
			Location          pLocation          = new Location();
			NetworkFacility   pNetworkFacility   = new NetworkFacility();
			NetworkProvider   pNetworkProvider   = new NetworkProvider();
			Language          pLanguage          = new Language();
			Specialty         pSpecialty         = new Specialty();
			GroupPracticeLink pGroupPracticeLink = new GroupPracticeLink();
			FileSetTrailer    pFileSetTrailer    = new FileSetTrailer();
			DataSetTrailer    pDataSetTrailer    = new DataSetTrailer();

			while ( (input_line = sr.ReadLine() ) != null)
			{
				linecnt++;
				rd.Header(input_line);
				RecordData pd;
				switch(rd.RecordType)
				{
					case 0:
						pd = pFileHeader;
						Record00Count++;
						break;
					case 10:	// Provider / Group Practice / Facilty
						switch(rd.FileType)
						{
							case "PRV":
								pd = pProvider;			break;
							case "FAC":
								pd = pFacility;			break;
							case "GRP":
								pd = pGroupPractice;	break;
							case "NET":
								pd = pNetwork;			break;
							default:
								return -5; // unknown entity
						}
						Record10Count++;
						break;
					case 20:
						pd = pLocation;
						Record20Count++;
						break;
					case 21:
						pd = pAddress;
						Record21Count++;
						break;
					case 22:
						switch(rd.FileType)
						{
							case "FAC":
								pd = pNetworkFacility;	break;
							case "PRV":
								pd = pNetworkProvider;	break;
							default:
								return -6;
						}
						Record22Count++;
						break;
					case 30:
						pd = pLanguage;
						Record30Count++;
						break;
					case 50:
						pd = pSpecialty;
						Record50Count++;
						break;
					case 60:
						pd = pGroupPracticeLink;
						Record60Count++;
						break;
					case 80:
						pd = pDataSetTrailer;
						Record80Count++;
						break;
					case 90:
						pd = pFileSetTrailer;
						break;
					default:
						// Unknown record type, abort for now
						return -2;
				}// end of switch

				pd.Initialize();				// clear out the object
				pd.batch_guid	= batch_guid;	// tie together in the database...
				pd.FileType		= rd.FileType;
				pd.RecordType	= rd.RecordType;
				pd.ClientID		= rd.ClientID;
				try
				{
					pd.ParseData(input_line);
					if (!pd.ValidateData())
					{
						// Okay there's a problem. Since an exception wasn't thrown,
						// it isn't a "show-stopper"

						// Decision: Do we chuck the Entity (Provider/Facility/Network/Group Practice) or just the link
						if (pd.RecordType == 10) // this is an entity
							ignoredataset	= true;
						else
							ignoreline		= true;

						if (++errorcnt < maxerrors) // don't fillup the event log
						{
							if (!EventLog.SourceExists("ProviderInterface") )
								EventLog.CreateEventSource("ProviderInterface", "ActiveAdvice");

							string msg	= "Error on " +  pd.FileType + pd.RecordType;
							if (pd.error_msg != null)
								msg = " {\"" + pd.error_msg + "\"} at";
							msg += " line #" + linecnt.ToString();
							if (ignoredataset)	msg = "Error with entity, " + msg + ", ignoring until data set trailer";
							else				msg = "Error with link, " + msg + ", ignoring link only";
							EventLog.WriteEntry("ProviderInterface", msg, EventLogEntryType.Error);
						}
					}
				}
				catch(Exception ex)
				{
					string message = ex.Message;
					Exception e = new Exception("Error parsing record type " + pd.RecordType.ToString() + ", at line #" + linecnt.ToString(), ex);
					throw e;
				}
				if (pd.RecordType == 90)
				{
					FileSetTrailer fst = (FileSetTrailer)pd;
					fst.ParseData(input_line);
//					if (!VerifyCheckDigit(fst.CheckDigit, Record10Count, Record20Count, Record21Count, Record22Count, Record30Count, Record50Count, Record60Count, Record80Count, 1) )
//					{
//						// Error with data records, don't write to the data store!!!
//						return -1;
//					}
//					int TotalRecordCount = Record00Count + Record10Count + Record20Count + Record21Count + Record22Count + Record30Count + Record50Count + Record60Count + Record80Count + 1;
//					if (TotalRecordCount != fst.TotalNumberOfRecords)
//					{
//						// Mismatch in data records processed...
//						return -3;
//					}
				}
				// Write out parsed info... if we are allowed...
				if (!ignoreline && !ignoredataset)
					pd.WriteToStaging(ConnectionString);
				if ( (pd.RecordType == 80) && ignoredataset)
					ignoredataset = false;
				ignoreline = false;
			}// end of while loop

			if (errorcnt > 1) // slap a warning into the EventLog that we had lots of errors
			{
				if (!EventLog.SourceExists("ProviderInterface") )
					EventLog.CreateEventSource("ProviderInterface", "ActiveAdvice");

				string msg	= "There were " + errorcnt.ToString() + " errors parsing the input data (of " + linecnt.ToString() + " lines)\n" +
					          "please review the event log to determine the problem";
				if (errorcnt > maxerrors)
					msg += "\nThe error log does not contain all errors, only the first " + maxerrors.ToString() + "\n" +
						     " were written to the event log";
				EventLog.WriteEntry("ProviderInterface", msg, EventLogEntryType.Warning);
			}

			// Done processing everything...
			EntityDB process = new EntityDB();
			process.ProcessStaging(ConnectionString, batch_guid);

			return 0;
		}// end of method ParseLine
	}// end of class TestRecordParsing

	/// <summary>
	/// Summary description for RecordData.
	/// RecordData forms the base class for the Provider Interface 
	/// parsing classes.
	/// </summary>

	public class RecordData
	{
		public string FileType;
		public string ClientID;
		public int RecordType;
		public System.Guid batch_guid;
		public string error_msg;		// store any error messages here...
		virtual public void ParseData(string input) { return; }
		virtual public int WriteToStaging(string ConnectionString) { return -1; }
		virtual public bool ValidateData() { return false; }
		virtual public void Initialize() { return; }

		public int Header(string input)
		{
			FileType			= ReadValue(input,0, 3);
			ClientID			= ReadValue(input,3, 3);
			RecordType			= ReadValueInt(input,6,2);

			return 0;
		}

		public static void SQLexceptionHandler(SqlCommand cmd, SqlException se)
		{
			string msg = cmd.CommandText + " failure\nParameters:\n";
			for (int i = 0; i < cmd.Parameters.Count; i++)
			{
				try
				{
					msg += "    " + cmd.Parameters[i].ParameterName + "=" + (cmd.Parameters[i].Value == null ? "<null>" : cmd.Parameters[i].Value.ToString()) + "\n";
				}
				catch(Exception ex)
				{
					string messg = ex.Message;
				}
			}
			msg += "\n{Inner Exception}\n" + se.Message;
			Exception e = new Exception(msg, se);
			throw e;
		}// end of method SQLexceptionhandler

		public int ReadValueInt(string input, int start, int length)
		{
			string s = ReadValue(input, start, length);
			if (s == null)
				return 0;
			else
				return Convert.ToInt32(s);
		}
		public string ReadValue(string input, int start, int length)
		{
			if (input.Length < start)
				return null;
			if (input.Length <= (start+length))
				length = input.Length - start;
			string str = input.Substring(start, length).Trim();
			if (str == "") str = null;
			return str;
		}

		protected DateTime AddHHMMSS(DateTime dt, string hhmmss)
		{
			int hours	= Convert.ToInt32(hhmmss.Substring(0,2) );
			int minutes	= Convert.ToInt32(hhmmss.Substring(2,2) );
			int seconds	= Convert.ToInt32(hhmmss.Substring(4,2) );
			dt.AddHours((double)hours);
			dt.AddMinutes((double)minutes);
			dt.AddSeconds((double)seconds);
			return dt;
		}

		protected DateTime ConvertCCYYMMDD(string ccyymmdd)
		{
			if ( (ccyymmdd == null) || (ccyymmdd.Trim().Length == 0) ) // all blanks...
				return new DateTime(1,1,1); // some dates are empty (i.e. termination dates)

			int century = 0;
			int idx = 0;
			if (ccyymmdd.Length > 6) // have century
			{
				century = Convert.ToInt32(ccyymmdd.Substring(0, 2)) * 100;
				idx = 2;
			}
			int year = Convert.ToInt32(ccyymmdd.Substring(0+idx,2));
			if (century == 0)
				year += (year > 50 ? 1900 : 2000); 
			else
				year += century;

			int month = Convert.ToInt32(ccyymmdd.Substring(2+idx,2));
			int day   = Convert.ToInt32(ccyymmdd.Substring(4+idx,2));
			return new System.DateTime(year, month, day, 0, 0, 0, 0);
		}
	}

	public class FileHeader : RecordData
	{
		override public bool ValidateData()
		{
			// If this is an unrecognized type, then just get out by
			// throwing an exception
			if ( (FileType != "PRV") && 
				 (FileType != "GRP") &&
				 (FileType != "NET") &&
				 (FileType != "FAC") )
			{
				Exception e = new Exception("Error with FileHeader, invalid FileType \"" + FileType.ToString() + "\"");
				throw e;
			}

			return true;
		}

		override public int WriteToStaging(string ConnectionString)
		{
			// Write the following to staging:
			//     - batch_number
			//     - filetype
			//     - clientid
			//     - createdatetime
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Staging_WriteFileHeader", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@createdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (CreateDateTime.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = CreateDateTime;

				inparm				= cmd.Parameters.Add("@filetype", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FileType;

				inparm				= cmd.Parameters.Add("@clientid", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.ClientID;

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}

			return rowsAffected;
		}

		override public void ParseData(string input)
		{
			this.CreateDateTime	= this.ConvertCCYYMMDD(ReadValue(input,8,8) );
			this.CreateDateTime = this.AddHHMMSS(CreateDateTime, ReadValue(input,16,6) );
		}

		override public void Initialize()
		{
			CreateDateTime = new System.DateTime(1,1,1);
		}

		DateTime CreateDateTime;
	}// end of class FileHeader00

	public class GroupPractice : RecordData
	{
		protected string Type, AlternateID, Name, Email;
		protected string FederalTaxID, UPIN, MedicareID, Status;
		protected DateTime StatusDate;
		protected string []UserDefined = new string[6];

		override public void Initialize()
		{
			Type = null; AlternateID = null; Name = null; Email = null;
			FederalTaxID = null; UPIN = null; MedicareID = null; Status = null;
			StatusDate = new DateTime(1,1,1);
			for (int i = 0; i < 6; i++) UserDefined[i] = null;
		}
		override public bool ValidateData()
		{
			if ( (AlternateID == "") || (AlternateID == null) )
				return false;

			return true;
		}// end of method ValidateData()

		override public int WriteToStaging(string ConnectionString)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Staging_GroupPracticeFacility", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@filetype", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FileType;

				inparm				= cmd.Parameters.Add("@clientID", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.ClientID;

				inparm				= cmd.Parameters.Add("@alternateid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateID;

				inparm				= cmd.Parameters.Add("@name", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Name;

				inparm				= cmd.Parameters.Add("@type", SqlDbType.VarChar, 4);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Type;

				inparm				= cmd.Parameters.Add("@federaltaxid", SqlDbType.VarChar, 15);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FederalTaxID;

				inparm				= cmd.Parameters.Add("@upin", SqlDbType.VarChar, 15);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UPIN;

				inparm				= cmd.Parameters.Add("@medicareid", SqlDbType.VarChar, 15);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MedicareID;

				inparm				= cmd.Parameters.Add("@email", SqlDbType.VarChar, 60);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Email;

				inparm				= cmd.Parameters.Add("@status", SqlDbType.Char, 1);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Status;

				inparm				= cmd.Parameters.Add("@statusdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (StatusDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = StatusDate;

				inparm				= cmd.Parameters.Add("@userdefined1", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[0];

				inparm				= cmd.Parameters.Add("@userdefined2", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[1];

				inparm				= cmd.Parameters.Add("@userdefined3", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[2];

				inparm				= cmd.Parameters.Add("@userdefined4", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[3];

				inparm				= cmd.Parameters.Add("@userdefined5", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[4];

				inparm				= cmd.Parameters.Add("@userdefined6", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[5];

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}

			return rowsAffected;
		}// end of method WriteToStaging()

		override public void ParseData(string input)
		{
			AlternateID		= ReadValue(input,8, 30);
			Type			= ReadValue(input,38,4);
			Name			= ReadValue(input,42, 45);
			FederalTaxID	= ReadValue(input,87,15);
			UPIN			= ReadValue(input,102,15);
			MedicareID		= ReadValue(input,117,15);
			Email			= ReadValue(input,132,60);
			Status			= ReadValue(input,192,1);
			StatusDate		= ConvertCCYYMMDD(ReadValue(input,193,8) );
			for (int i = 0; i < 6; i++)
				UserDefined[i] = ReadValue(input,(201+i*45), 45);
		}
	}// end of class GroupPractice

	public class Facility : GroupPractice
	{
		override public bool ValidateData()
		{
			if ( (AlternateID == "") || (AlternateID == null) )
				return false;

			return true;
		}// end of method ValidateData()

		override public void ParseData(string input)
		{
			Type			= ReadValue(input,8,4);
			AlternateID		= ReadValue(input,12, 30);
			Name			= ReadValue(input,42, 45);
			FederalTaxID	= ReadValue(input,87,15);
			UPIN			= ReadValue(input,102,15);
			MedicareID		= ReadValue(input,117,15);
			Email			= ReadValue(input,132,60);
			Status			= ReadValue(input,192,1);
			StatusDate		= ConvertCCYYMMDD(ReadValue(input,193,8) );
			for (int i = 0; i < 6; i++)
				UserDefined[i] = ReadValue(input,(201+i*45), 45);
		}
	}// end class Facility

	public class Provider : RecordData
	{
		override public bool ValidateData()
		{
			if ( (AlternateID == "") || (AlternateID == null) )
			{
				this.error_msg	= "missing AlternateID";
				return false;
			}
			if ( (FirstName == "") || (FirstName == null) )
			{
				error_msg = "missing first name";
				return false;
			}
			if ( (LastName == "") || (LastName == null) )
			{
				error_msg = "missing last name";
				return false;
			}
			if ( (this.Reviewer == "") || (Reviewer == null) )
			{
				error_msg = "missing Reviewer";
				return false;
			}
			if ( (this.Status == "") || (Status == null) )
			{
				error_msg = "missing Status";
				return false;
			}
			if (StatusDate.Year == 1)
			{
				error_msg = "missing StatusDate";
				return false;
			}

		return true;
		}

		override public void ParseData(string input)
		{
			AlternateID		= ReadValue(input,8, 30);
			Prefix			= ReadValue(input,38, 4);
			LastName		= ReadValue(input,42, 30);
			FirstName		= ReadValue(input,72, 30);
			MiddleName		= ReadValue(input,102, 30);
			Suffix			= ReadValue(input,132, 10);
			Gender			= ReadValue(input,142, 1);
			Reviewer		= ReadValue(input,143, 1);
			FederalTaxID	= ReadValue(input,144, 15);
			UPIN			= ReadValue(input,159, 15);
			MedicaireID		= ReadValue(input,174, 15);
			Email			= ReadValue(input,189, 60);
			Beeper			= ReadValue(input,249, 20);
			BeeperExtension	= ReadValue(input,269, 6);
			Status			= ReadValue(input,275, 1);
			StatusDate		= ConvertCCYYMMDD(ReadValue(input,276, 8) );
			for (int i = 0; i < 6; i++)
				UserDefined[i] = this.ReadValue(input, (284+i*45), 45);
		}

		override public int WriteToStaging(string ConnectionString)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Staging_WriteProvider", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@filetype", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FileType;

				inparm				= cmd.Parameters.Add("@clientID", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.ClientID;

				inparm				= cmd.Parameters.Add("@alternateid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateID;

				inparm				= cmd.Parameters.Add("@prefix", SqlDbType.VarChar, 4);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Prefix;

				inparm				= cmd.Parameters.Add("@lastname", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value = this.LastName;

				inparm				= cmd.Parameters.Add("@firstname", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value = this.FirstName;

				inparm				= cmd.Parameters.Add("@middlename", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value = this.MiddleName;

				inparm				= cmd.Parameters.Add("@suffix", SqlDbType.VarChar, 10);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value = this.Suffix;

				inparm				= cmd.Parameters.Add("@gender", SqlDbType.Char, 1);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value = this.Gender;

				inparm				= cmd.Parameters.Add("@reviewer", SqlDbType.Char, 1);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Reviewer;

				inparm				= cmd.Parameters.Add("@federaltaxid", SqlDbType.VarChar, 15);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FederalTaxID;

				inparm				= cmd.Parameters.Add("@upin", SqlDbType.VarChar, 15);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UPIN;

				inparm				= cmd.Parameters.Add("@medicareid", SqlDbType.VarChar, 15);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MedicaireID;

				inparm				= cmd.Parameters.Add("@email", SqlDbType.VarChar, 60);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Email;

				inparm				= cmd.Parameters.Add("@beeper", SqlDbType.VarChar, 20);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Beeper;

				inparm				= cmd.Parameters.Add("@beeperext", SqlDbType.VarChar, 6);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.BeeperExtension;

				inparm				= cmd.Parameters.Add("@status", SqlDbType.Char, 1);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Status;

				inparm				= cmd.Parameters.Add("@statusdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (StatusDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = StatusDate;

				inparm				= cmd.Parameters.Add("@userdefined1", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[0];

				inparm				= cmd.Parameters.Add("@userdefined2", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[1];

				inparm				= cmd.Parameters.Add("@userdefined3", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[2];

				inparm				= cmd.Parameters.Add("@userdefined4", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[3];

				inparm				= cmd.Parameters.Add("@userdefined5", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[4];

				inparm				= cmd.Parameters.Add("@userdefined6", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[5];

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}

			return rowsAffected;
		}// end of method WriteToStaging()

		override public void Initialize()
		{
			City = null; State = null; Zip = null; County = null; Country = null;
			Phone = null; PhoneExtension = null; Fax = null; FaxExtension = null;
			EffectiveDate = new DateTime(1,1,1); TermDate = new DateTime(1,1,1);
		}
		// Data for Networks (networks have addresses)
		#region "variables"		public string Address1, Address2, Address3;
		public string City, State, Zip, County, Country;
		public string Phone, PhoneExtension, Fax, FaxExtension;
		public DateTime EffectiveDate, TermDate;

		public string AlternateID;
		public string Prefix;
		public string LastName;
		public string FirstName;
		public string MiddleName;
		public string Suffix;
		public string Gender;
		public string Reviewer;
		public string FederalTaxID;
		public string UPIN;
		public string MedicaireID;
		public string Email;
		public string Beeper;
		public string BeeperExtension;
		public string Status;
		public DateTime StatusDate;
		public string []UserDefined = new string[6];

		public string Type;			// Facility/Group Practice "Type"
		public string Name;			// Facility/Group Practice Name
		#endregion
	}// end of class Provider

	public class FileSetTrailer : RecordData
	{
		override public bool ValidateData() {return true;}
		override public int WriteToStaging(string ConnectionString)
		{
			// Write the following to staging:
			//     - batch_number
			//     - filetype
			//     - clientid
			//     - createdatetime
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Write_FileSetTrailer", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@filetype", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FileType;

				inparm				= cmd.Parameters.Add("@clientid", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.ClientID;

				inparm				= cmd.Parameters.Add("@checkdigit", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.CheckDigit;

				inparm				= cmd.Parameters.Add("@totalnumberrecords", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.TotalNumberOfRecords;

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}

			return rowsAffected;
		}

		override public void ParseData(string input)
		{
			CheckDigit				= ReadValueInt(input,8,15);
			TotalNumberOfRecords	= ReadValueInt(input,23,6);
		}

		override public void Initialize()
		{
			CheckDigit = 0; TotalNumberOfRecords = 0;
		}
		public int CheckDigit;
		public int TotalNumberOfRecords;

	}// end of class fileset trailer

	public class DataSetTrailer : RecordData
	{

		override public bool ValidateData()	{return true;}

		override public int WriteToStaging(string ConnectionString)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Write_DataSetTrailer", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@filetype", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FileType;

				inparm				= cmd.Parameters.Add("@clientid", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.ClientID;

				inparm				= cmd.Parameters.Add("@alternateid", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateID;

				inparm				= cmd.Parameters.Add("@record20count", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Record20Count;

				inparm				= cmd.Parameters.Add("@record21count", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Record21Count;

				inparm				= cmd.Parameters.Add("@record22count", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Record22Count;

				inparm				= cmd.Parameters.Add("@record30count", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Record30Count;

				inparm				= cmd.Parameters.Add("@record50count", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Record50Count;

				inparm				= cmd.Parameters.Add("@record60count", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Record60Count;

				inparm				= cmd.Parameters.Add("@totalrecordcount", SqlDbType.Int);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.TotalRecordCount;

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					string msg = cmd.CommandText + " failure\nParameters:\n";
					for (int i = 0; i < cmd.Parameters.Count; i++)
						msg += "    " + cmd.Parameters[i].ParameterName + "=" + cmd.Parameters[i].Value.ToString() + "\n";
					Exception e = new Exception(msg, se);
					throw e;
				}
			}

			return rowsAffected;
		}

		override public void ParseData(string input)
		{
			bool legacy = false;
			if (legacy)
			{
				AlternateID			= ReadValue(input,8,30);
				Record20Count		= ReadValueInt(input,38,3);
				Record21Count		= ReadValueInt(input,41,3);
				Record22Count		= ReadValueInt(input,44,3);
				Record30Count		= ReadValueInt(input,47,3);
				Record50Count		= ReadValueInt(input,50,3);
				Record60Count		= ReadValueInt(input,53,3);
				TotalRecordCount	= ReadValueInt(input,56,3);
			}
			else
			{
				AlternateID			= ReadValue(input,8,30);
				Record20Count		= ReadValueInt(input,38,7);
				Record21Count		= ReadValueInt(input,45,7);
				Record22Count		= ReadValueInt(input,52,7);
				Record30Count		= ReadValueInt(input,59,7);
				Record50Count		= ReadValueInt(input,66,7);
				Record60Count		= ReadValueInt(input,73,7);
				TotalRecordCount	= ReadValueInt(input,80,8);
			}
		}

		override public void Initialize()
		{
			AlternateID = null; Record20Count = 0; Record21Count = 0;
			Record22Count = 0; Record30Count = 0; Record50Count = 0;
			Record60Count = 0; TotalRecordCount = 0;
		}
		public string AlternateID;
		public int Record20Count;
		public int Record21Count;
		public int Record22Count;
		public int Record30Count;
		public int Record50Count;
		public int Record60Count;
		public int TotalRecordCount;

	}// end of class DataSetTrailer

	public class GroupPracticeLink : RecordData
	{
		override public int WriteToStaging(string ConnectionString)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Write_Staging_GroupPracticeLink", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@filetype", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FileType;

				inparm				= cmd.Parameters.Add("@clientid", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.ClientID;

				inparm				= cmd.Parameters.Add("@provideralternateid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.ProviderAlternateID;

				inparm				= cmd.Parameters.Add("@grouplocationalternateid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.GroupLocationAlternateID;

				inparm				= cmd.Parameters.Add("@grouppracticealternateid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.GroupPracticeAlternateID;

				inparm				= cmd.Parameters.Add("@startdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (StartDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = StartDate;

				inparm				= cmd.Parameters.Add("@enddate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (EndDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = EndDate;

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}

			return rowsAffected;
		}

		override public void ParseData(string input)
		{
			this.ProviderAlternateID		= ReadValue(input,8,30);
			this.GroupLocationAlternateID	= ReadValue(input,38,30);
			this.StartDate					= this.ConvertCCYYMMDD(ReadValue(input,68, 8) );
			this.EndDate					= this.ConvertCCYYMMDD(ReadValue(input,98, 8) );
			this.GroupPracticeAlternateID	= ReadValue(input,84,30);
		}
		override public void Initialize()
		{
			ProviderAlternateID = null; GroupLocationAlternateID = null;
			StartDate = new DateTime(1,1,1); EndDate = new DateTime(1,1,1); GroupPracticeAlternateID = null;
		}
		public string ProviderAlternateID;
		public string GroupLocationAlternateID;
		public DateTime StartDate;
		public DateTime EndDate;
		public string GroupPracticeAlternateID;

	}// end of class GroupPracticeLink

	public class Specialty : RecordData
	{
		override public bool ValidateData()
		{
			if ( (AlternateID == "") || (AlternateID == null) )
				return false;
			if ( (SpecialtyCode == "") || (SpecialtyCode == null) )
				return false;

			return true;
		}// end of method ValidateData()

		override public void ParseData(string input)
		{
			AlternateID			= ReadValue(input,8,30);
			SpecialtyCode		= ReadValue(input,38,4);
			PrimaryIndicator	= ReadValue(input,42,1);
			BoardStatus			= ReadValue(input,43,4);
			BoardStartDate		= this.ConvertCCYYMMDD(ReadValue(input,47,8));
			BoardEndDate		= this.ConvertCCYYMMDD(ReadValue(input,55,8));
		}

		override public void Initialize()
		{
			AlternateID = null; SpecialtyCode = null; PrimaryIndicator = null;
			BoardStatus = null; BoardStartDate = new DateTime(1,1,1); BoardEndDate = new DateTime(1,1,1);
		}
		public string AlternateID;
		public string SpecialtyCode;
		public string PrimaryIndicator;
		public string BoardStatus;
		public DateTime BoardStartDate;
		public DateTime BoardEndDate;

	}// end of class Specialty50

	public class Language : RecordData
	{
		override public bool ValidateData()
		{
			if ( (AlternateID == "") && (AlternateID == null) )
				return false;
			if ( (LanguageCode == "") && (LanguageCode == null) )
				return false;
			return true;
		}

		override public void ParseData(string input)
		{
			AlternateID		= ReadValue(input,8,30);
			LanguageCode	= ReadValue(input,38,4);
		}
		override public void Initialize()
		{
			AlternateID = null; LanguageCode = null;
		}
		public string AlternateID;
		public string LanguageCode;
	}// end of class Language30

	public class Network : RecordData
	{
		override public bool ValidateData()
		{
			if ( (AlternateID == "") || (AlternateID == null) )
			{
				this.error_msg = "missing AlternateID";	return false;
			}
			if ( (NetworkType == "") || (NetworkType == null) )
			{
				this.error_msg = "missing NetworkType";	return false;
			}
			if (this.EffectiveDate.Year == 1)
			{
				this.error_msg = "missing EffectiveDate (Network Start Date)";	return false;
			}

			if ( (TermDate.Year != 1) &&
				 (EffectiveDate > TermDate) )
			{
				this.error_msg = "EffectiveDate more recent than TerminationDate";	return false;
			}

			return true;
		}// end of method ValidateData()

		override public int WriteToStaging(string ConnectionString)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Write_Staging_Network", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@filetype", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FileType;

				inparm				= cmd.Parameters.Add("@clientID", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.ClientID;

				inparm				= cmd.Parameters.Add("@alternateid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateID;

				inparm				= cmd.Parameters.Add("@name", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Name;

				inparm				= cmd.Parameters.Add("@type", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.NetworkType;

				inparm				= cmd.Parameters.Add("@address1", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Address1;

				inparm				= cmd.Parameters.Add("@address2", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Address2;

				inparm				= cmd.Parameters.Add("@address3", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Address3;

				inparm				= cmd.Parameters.Add("@city", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.City;

				inparm				= cmd.Parameters.Add("@state", SqlDbType.VarChar, 2);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.State;

				inparm				= cmd.Parameters.Add("@zip", SqlDbType.VarChar, 10);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Zip;

				inparm				= cmd.Parameters.Add("@county", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.County;

				inparm				= cmd.Parameters.Add("@country", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Country;

				inparm				= cmd.Parameters.Add("@phone", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Phone;

				inparm				= cmd.Parameters.Add("@phoneext", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.PhoneExtension;

				inparm				= cmd.Parameters.Add("@fax", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Fax;

				inparm				= cmd.Parameters.Add("@faxext", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FaxExtension;

				inparm				= cmd.Parameters.Add("@effdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (EffectiveDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = EffectiveDate;

				inparm				= cmd.Parameters.Add("@termdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (TermDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = TermDate;

				inparm				= cmd.Parameters.Add("@userdefined1", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[0];

				inparm				= cmd.Parameters.Add("@userdefined2", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[1];

				inparm				= cmd.Parameters.Add("@userdefined3", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[2];

				inparm				= cmd.Parameters.Add("@userdefined4", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[3];

				inparm				= cmd.Parameters.Add("@userdefined5", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[4];

				inparm				= cmd.Parameters.Add("@userdefined6", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UserDefined[5];

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}

			return rowsAffected;
		}// end of method WriteToStaging()

		protected string Address1, Address2, Address3, City, State, County, Country, Zip;
		protected string []UserDefined = new string[6];
		protected string AlternateID, Email, Fax, FaxExtension, Phone, PhoneExtension, Name, NetworkType;
		protected DateTime EffectiveDate, TermDate;
		override public void ParseData(string input)
		{
			NetworkType			= ReadValue(input,8, 4);
			AlternateID			= ReadValue(input,12,30);
			Name				= ReadValue(input,42,45);
			Address1			= ReadValue(input,87,45);
			Address2			= ReadValue(input,132,45);
			Address3			= ReadValue(input,177,45);
			City				= ReadValue(input,222,45);
			State				= ReadValue(input,267,2);
			Zip					= ReadValue(input,269,10);
			County				= ReadValue(input,279,30);
			Country				= ReadValue(input,309,30);
			Phone				= ReadValue(input,339,20);
			PhoneExtension		= ReadValue(input,359,6);
			Fax					= ReadValue(input,365,20);
			FaxExtension		= ReadValue(input,385,6);
			Email				= ReadValue(input,391, 60);
			EffectiveDate		= this.ConvertCCYYMMDD(ReadValue(input,451,8) );
			TermDate			= this.ConvertCCYYMMDD(ReadValue(input,459,8) );
			for (int i = 0; i < 6; i++)
				UserDefined[i] = ReadValue(input, 467+(i*45), 45);
		}
		override public void Initialize()
		{
			AlternateID = null; Email = null; Fax = null; FaxExtension = null;
			Phone = null; PhoneExtension = null; Name = null; NetworkType = null;
			EffectiveDate = new DateTime(1,1,1); TermDate = new DateTime(1,1,1);
		}
	}// end of class Network

	public class NetworkFacility : RecordData
	{
		override public bool ValidateData()
		{
			if ( (AlternateID == "") || (AlternateID == null) )
				return false;
			if ( (AlternateLocationID == "") || (AlternateLocationID == null) )
				return false;
			if ( (NetworkAlternateID == "") || (NetworkAlternateID == null) )
				return false;
			if (this.StartDate.Year == 1) // must have an Effective date
				return false;
//			if ( (NetworkEntityAlternateID == "") || (NetworkEntityAlternateID == null) )
//				return false;

			return true;
		}// end of method ValidateData()

		override public int WriteToStaging(string ConnectionString)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Write_Staging_NetworkFacility", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@filetype", SqlDbType.VarChar);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FileType;

				inparm				= cmd.Parameters.Add("@clientID", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.ClientID;

				inparm				= cmd.Parameters.Add("@alternateid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateID;

				inparm				= cmd.Parameters.Add("@alternatelocationid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateLocationID;

				inparm				= cmd.Parameters.Add("@networkalternateid", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.NetworkAlternateID;

				inparm				= cmd.Parameters.Add("@networkentityalternateid", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.NetworkEntityAlternateID;

				inparm				= cmd.Parameters.Add("@startdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (StartDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = StartDate;

				inparm				= cmd.Parameters.Add("@enddate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (EndDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = EndDate;

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}

			return rowsAffected;
		}// end of method WriteToStaging()

		override public void ParseData(string input)
		{
			AlternateID					= ReadValue(input,8,30);
			AlternateLocationID			= ReadValue(input,38,30);
			NetworkAlternateID			= ReadValue(input,68,30);
			NetworkEntityAlternateID	= ReadValue(input,98,30);
			StartDate					= this.ConvertCCYYMMDD(ReadValue(input,128,8) );
			EndDate						= this.ConvertCCYYMMDD(ReadValue(input,136,8) );
		}

		override public void Initialize()
		{
			AlternateID = null; AlternateLocationID = null; NetworkAlternateID = null;
			NetworkEntityAlternateID = null; StartDate = new DateTime(1,1,1); EndDate = new DateTime(1,1,1);
		}
		string AlternateID, AlternateLocationID, NetworkAlternateID, NetworkEntityAlternateID;
		DateTime StartDate, EndDate;
	}// end of class NetworkFacility

	public class NetworkProvider : NetworkFacility
	{
	}// end of class NetworkProvider

	public class Address : RecordData
	{
		override public bool ValidateData()
		{
			if ( (AlternateID == "") || (AlternateID == null) )
			{
				this.error_msg = "missing AlternateID";	return false;
			}
			if ( (AlternateLocationID == "") || (AlternateLocationID == null) )
			{
				this.error_msg = "missing AlternateLocationID";	return false;
			}

			if ( (this.City == "") || (this.City == null) )
			{
				this.error_msg = "missing City";	return false;
			}
			if ( (this.State == "") || (this.State == null) )
			{
				this.error_msg = "missing State";	return false;
			}
			if ( (this.Zip == "") || (this.Zip == null) )
			{
				this.error_msg = "missing Zip";	return false;
			}


			return true;
		}
		override public int WriteToStaging(string ConnectionString)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Write_Staging_Address", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@filetype", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FileType;

				inparm				= cmd.Parameters.Add("@clientid", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.ClientID;

				inparm				= cmd.Parameters.Add("@alternateid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateID;

				inparm				= cmd.Parameters.Add("@alternatelocationid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateLocationID;

				inparm				= cmd.Parameters.Add("@addresstype", SqlDbType.VarChar, 1);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AddressType;

				inparm				= cmd.Parameters.Add("@line1", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Line1;

				inparm				= cmd.Parameters.Add("@line2", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Line2;

				inparm				= cmd.Parameters.Add("@line3", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Line3;

				inparm				= cmd.Parameters.Add("@city", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.City;

				inparm				= cmd.Parameters.Add("@state", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.State;

				inparm				= cmd.Parameters.Add("@zip", SqlDbType.VarChar, 10);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Zip;

				inparm				= cmd.Parameters.Add("@county", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.County;

				inparm				= cmd.Parameters.Add("@country", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Country;

				inparm				= cmd.Parameters.Add("@phone", SqlDbType.VarChar, 20);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Phone;

				inparm				= cmd.Parameters.Add("@phone_ext", SqlDbType.VarChar, 6);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.PhoneExtension;

				inparm				= cmd.Parameters.Add("@fax", SqlDbType.VarChar, 20);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Fax;

				inparm				= cmd.Parameters.Add("@fax_ext", SqlDbType.VarChar, 6);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FaxExtension;

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}

			return rowsAffected;
		}

		override public void ParseData(string input)
		{
			AlternateID			= ReadValue(input,8,30);
			AlternateLocationID	= ReadValue(input,38,30);
			AddressType			= ReadValue(input,68,1);
			Line1				= ReadValue(input,69,45);
			Line2				= ReadValue(input,114,45);
			Line3				= ReadValue(input,159,45);
			City				= ReadValue(input,204,45);
			State				= ReadValue(input,249,2);
			Zip					= ReadValue(input,251,10);
			County				= ReadValue(input,261,30);
			Country				= ReadValue(input,291,30);
			Phone				= ReadValue(input,321,20);
			PhoneExtension		= ReadValue(input,341,6);
			Fax					= ReadValue(input,347,20);
			FaxExtension		= ReadValue(input,367,6);
		}

		override public void Initialize()
		{
			AlternateID = null; AlternateLocationID = null; AddressType = null;
			Line1 = null; Line2 = null; Line3 = null;
			City = null; State = null; Zip = null; County = null; Country = null;
			Phone = null; PhoneExtension = null; Fax = null; FaxExtension = null;
		}
		protected string AlternateID;
		protected string AlternateLocationID;
		protected string AddressType;
		protected string Line1, Line2, Line3;
		protected string City, State, Zip, County, Country;
		protected string Phone, PhoneExtension, Fax, FaxExtension;

	} // end of class Address21

	public class Location : RecordData
	{
		override public bool ValidateData()
		{
			if ( (AlternateID == "") || (AlternateID == null) )
			{
				this.error_msg = "missing AlternateID";	return false;
			}
			if ( (LocationAlternateID == "") || (LocationAlternateID == null) )
			{
				this.error_msg = "missing LocationAlternateID";	return false;
			}
			if ( (this.Status == "") || (this.Status == null) )
			{
				this.error_msg = "missing Status";	return false;
			}
			if (StatusDate.Year == 1)
			{
				this.error_msg = "missing StatusDate"; return false;
			}

			return true;
		}// end of method ValidateData()

		override public int WriteToStaging(string ConnectionString)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd = new SqlCommand("usp_Write_Staging_Location", connection);
				cmd.CommandType = CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.batch_guid;

				inparm				= cmd.Parameters.Add("@filetype", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FileType;

				inparm				= cmd.Parameters.Add("@clientid", SqlDbType.VarChar, 3);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.ClientID;

				inparm				= cmd.Parameters.Add("@alternateid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.AlternateID;

				inparm				= cmd.Parameters.Add("@locationalternateid", SqlDbType.VarChar, 30);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.LocationAlternateID;

				inparm				= cmd.Parameters.Add("@federaltaxid", SqlDbType.VarChar, 15);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.FederalTaxID;

				inparm				= cmd.Parameters.Add("@medicareid", SqlDbType.VarChar, 15);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.MedicareID;

				inparm				= cmd.Parameters.Add("@upin", SqlDbType.VarChar, 15);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.UPIN;

				inparm				= cmd.Parameters.Add("@status", SqlDbType.VarChar, 1);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Status;

				inparm				= cmd.Parameters.Add("@statusdate", SqlDbType.DateTime);
				inparm.Direction	= ParameterDirection.Input;
				if (StatusDate.Year == 1) inparm.Value = DBNull.Value; else inparm.Value = StatusDate;

				inparm				= cmd.Parameters.Add("@locationname", SqlDbType.VarChar, 45);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= this.Name;

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				connection.Open();
				rowsAffected = cmd.ExecuteNonQuery();
			}

			return rowsAffected;
		}

		override public void ParseData(string input)
		{
			AlternateID			= ReadValue(input,8,30);
			LocationAlternateID	= ReadValue(input,38,30);
			Name				= ReadValue(input,68,45);	// relevant only for Group Practice record (FileType = "GRP")
			Status				= ReadValue(input,113, 1);
			StatusDate			= ConvertCCYYMMDD(ReadValue(input,114, 8));
			FederalTaxID		= ReadValue(input,122,15);
			UPIN				= ReadValue(input,137,15);
			MedicareID			= ReadValue(input,152,15);

			for (int i = 0; i < 6; i++)
				UserDefined[i] = ReadValue(input,(167+i*45), 45);
		}

		override public void Initialize()
		{
			Name = null; AlternateID = null; LocationAlternateID = null;
			FederalTaxID = null; UPIN = null; MedicareID = null; Status = null;
			StatusDate = new DateTime(1,1,1);
			for (int i = 0; i < 6; i++) UserDefined[i] = null;
		}
		public string Name;		// only valid for Group Practice location
		public string AlternateID;
		public string LocationAlternateID;
		public string FederalTaxID;
		public string UPIN;
		public string MedicareID;
		public string Status;
		public DateTime StatusDate;
		public string []UserDefined = new string[6];
	}// end of class Location20

	class EntityDB
	{
		public int ProcessStaging(string ConnectionString, Guid batch)
		{
			int rowsAffected = 0;
			using (SqlConnection connection = new SqlConnection(ConnectionString))
			{
				SqlCommand cmd		= new SqlCommand("usp_Staging_ProcessStaging", connection);
				cmd.CommandTimeout	= 300; // 5 minutes
				cmd.CommandType		= CommandType.StoredProcedure;

				SqlParameter inparm;
				inparm				= cmd.Parameters.Add("@batch", SqlDbType.UniqueIdentifier);
				inparm.Direction	= ParameterDirection.Input;
				inparm.Value		= batch;

				SqlParameter returnValueParam	= cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
				returnValueParam.Direction		= ParameterDirection.ReturnValue;

				try
				{
					connection.Open();
					rowsAffected = cmd.ExecuteNonQuery();
				}
				catch(SqlException se)
				{
					RecordData.SQLexceptionHandler(cmd, se);
				}
			}

			return rowsAffected;
		}// end of method WriteProvider()
	}// end of class EntityDB
}// end of namespace EligibilityReader
