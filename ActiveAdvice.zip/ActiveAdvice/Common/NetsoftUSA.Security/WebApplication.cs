using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;
using Microsoft.Win32;
using System.Text;
using System.Web.Security;
using System.Security.Principal;
using System.Security.Permissions;
using System.Resources;
using System.Configuration;
using System.Xml;
using System.Collections.Specialized;
using System.Reflection;
using System.Diagnostics;
using System.Data.SqlClient;
using NetsoftUSA.Security;
using System.Web.Caching;


namespace NetsoftUSA.Security
{
	/// <summary>
	/// Defines the methods, events and properties and events common to all application
	/// objects in the web application.
	/// NetsoftUSA.Web.WebApplication class is derived from System.Web.HttpApplication
	///
	/// </summary>
	public class WebApplication : System.Web.HttpApplication
	{
		//
		// Constants for writing events to EventLog
		//

		protected static string	EventLogSource = "NS";
		protected static string	EventLogName = "Application";
		protected static string	EventLogMachine = ".";

		protected static string ConnectionStringLocation = "";
		protected static string ConnectionStringRegistryPath = null;
		protected static string ConnectionStringRegistryKey = null;

		public static string ConnectionString	= null;

		public static bool ConfigurationInMemory = false;

		public static int SessionTimeOut = 1;

		EventLog webApplicationEvent = null;


		public virtual void Application_Start(Object sender, EventArgs e)
		{
			EnsureConfiguration();
		}
 
		public virtual void Session_Start(Object sender, EventArgs e)
		{

		}

		public virtual void Application_BeginRequest(Object sender, EventArgs e)
		{
			EnsureConfiguration();
		}

		public virtual void Application_EndRequest(Object sender, EventArgs e)
		{

		}

		public virtual void Application_AuthenticateRequest(Object sender, EventArgs e)
		{
			//TODO Retrieve session timeout information from system settings table and use for cache expiration
			// Extract the forms authentication cookie
			string cookieName = FormsAuthentication.FormsCookieName;
			HttpCookie authCookie = Context.Request.Cookies[cookieName];
			if(null == authCookie)
			{
				// User is not authenticated or auth cookie is expired.
				return;
			}
			//Authentication cookie is found now we need to decrypt it.
			FormsAuthenticationTicket authTicket = null;
			try
			{
				authTicket = FormsAuthentication.Decrypt(authCookie.Value);
			}
			catch (Exception ex)
			{
				//TODO handle the exception
				// Log exception details 
				return;
			}
			if (null == authTicket)
			{
				// Cookie failed to decrypt.
				return;
			}
			//Create a form identity from the authentication ticket.
			FormsIdentity ID = new FormsIdentity(authTicket);
			// Check to see whether the Principal was cached. 
			string CachedPrincipalKey = "CachedPrincipal" +  ID.Name;
			if (HttpContext.Current.Cache[CachedPrincipalKey] == null)
			{
				//Create the principal. Getroles method retrieves the roles for this user identity
				//PrincipalEx principal = new PrincipalEx(ID,  WebAccount.GetRoles(CurrentUserIdentity.Name));
				GenericPrincipal principal = new GenericPrincipal(ID,  WebAccount.GetRoles(ID.Name));
				// Add principal to cache
				HttpContext.Current.Cache.Add(
					CachedPrincipalKey,
					principal, 
					null,
					DateTime.MaxValue, 
					new TimeSpan(0,SessionTimeOut,0), //Cache must expire when the session times out
					CacheItemPriority.Normal, 
					null);
				HttpContext.Current.User = principal; 
			}
			else
			{
				GenericPrincipal principal = (GenericPrincipal) Context.Cache.Get(CachedPrincipalKey);
				HttpContext.Current.User = principal;
			}
			return; 
			
		}

		public virtual void Application_Error(Object sender, EventArgs e)
		{

		}

		public virtual void Session_End(Object sender, EventArgs e)
		{

		}

		public virtual void Application_End(Object sender, EventArgs e)
		{

		}
	


		protected static void CheckIfPopupWindow()
		{
			// TODO: Add code here to check if the current page is one of the popup pages
			// If that is the case then:
			// Redirect the user to a page that contains javascript code to close the popup window 
			// and redirects the user to the login screen in main window.
		}

		
		protected virtual void EnsureConfiguration()
		{
			if (!ConfigurationInMemory)
			{
				//Set the Event Log parameters
				EventLogSource = ConfigHelper.GetConfigValue("ApplicationName");
				EventLogName = ConfigHelper.GetConfigValue("EventLogName");
				EventLogMachine = ConfigHelper.GetConfigValue("EventLogMachine");

				// Get the registry location of the connection string from the config file
				ConnectionStringLocation = ConfigHelper.GetConfigValue("ConnectionStringLocation");
				ConnectionStringRegistryPath = ConfigHelper.GetConfigValue("ConnectionStringRegistryPath");
				ConnectionStringRegistryKey = ConfigHelper.GetConfigValue("ConnectionStringRegistryKey");

				// Initialize the event log
				webApplicationEvent = new EventLog(EventLogName, EventLogMachine, EventLogSource);

				ReadConnectionString();

				ConfigurationInMemory = true;
			}
		}


		protected virtual void ReadConnectionString()
		{
	
			// Get the connection string from the registry
			string encryptedConnectionString = null;
			
			switch (ConnectionStringLocation.ToUpper())
			{
				case "REGISTRY":

					try
					{
						encryptedConnectionString = ConfigHelper.GetRegistryValue(ConnectionStringRegistryPath, ConnectionStringRegistryKey);
					}
					catch(Exception ex)
					{
						webApplicationEvent.WriteEntry("An error occurred while reading the connection string from registry. Error Details: " + ex.Message, EventLogEntryType.Error);
						throw new Exception(String.Format("An error occurred while reading the connection string from registry. Error Details: {0}", ex.Message), ex);
					}

					try
					{
						WebApplication.ConnectionString = CryptoHelper.Decrypt(encryptedConnectionString);
					}
					catch (Exception ex)
					{
						webApplicationEvent.WriteEntry("An error occurred while decrypting the connection string. Error Message:" + ex.Message, EventLogEntryType.Error);
					}
				
					break;
				case "UWEBCONFIG":

					try
					{
						WebApplication.ConnectionString = ConfigHelper.GetConfigValue("UnEncryptedConnectionString");
					}
					catch(Exception ex)
					{
						webApplicationEvent.WriteEntry("An error occurred while reading the connection string from webconfig. Error Details: " + ex.Message, EventLogEntryType.Error);
						throw new Exception(String.Format("An error occurred while reading the connection string from webconfig. Error Details: {0}", ex.Message), ex);
					}

					break;
				default: // WEBCONFIG

					try
					{
						encryptedConnectionString = ConfigHelper.GetConfigValue("EncryptedConnectionString");
					}
					catch(Exception ex)
					{
						webApplicationEvent.WriteEntry("An error occurred while reading the connection string from webconfig. Error Details: " + ex.Message, EventLogEntryType.Error);
						throw new Exception(String.Format("An error occurred while reading the connection string from webconfig. Error Details: {0}", ex.Message), ex);
					}

					try
					{
						WebApplication.ConnectionString = CryptoHelper.Decrypt(encryptedConnectionString);
					}
					catch (Exception ex)
					{
						webApplicationEvent.WriteEntry("An error occurred while decrypting the connection string. Error Message:" + ex.Message, EventLogEntryType.Error);
					}
					break;
			}

		}


		public static void SetPrincipal(FormsAuthenticationTicket authTicket)
		{
			// When the ticket was created, the UserData property was assigned a
			// pipe delimited string.
			string[] ticketData = authTicket.UserData.Split(new char[]{'|'});

			string[] userData = ticketData[1].Split(new char[]{','});

			// Create an Identity object
			FormsIdentity formsID = new FormsIdentity(authTicket);

			// This principal will flow throughout the request.
			PrincipalEx principal = new PrincipalEx(formsID, new string[] {"test"});

			// Attach the new principal object to the current HttpContext object
			//Context.User = principal;		}
		}	
	}
}
