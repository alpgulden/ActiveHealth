using System;
using System.Data;
using System.Web.Security;
using System.Security.Cryptography;
using System.Data.SqlClient;
using NetsoftUSA.Security.Cryptography;
using System.Collections;


namespace NetsoftUSA.Security
{
	/// <summary>
	/// Summary description for Account.
	/// </summary>
	public class WebAccount
	{
		public WebAccount()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public enum AccountStatus
		{
			Unknown								= 0,
			Normal								= 1,
			LockedOut							= 2
		};

		private static string CreateSalt(int size)
		{
			// Generate a cryptographic random number using the cryptographic
			// service provider
			RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
			byte[] buff = new byte[size];
			rng.GetBytes(buff);
			// Return a Base64 string representation of the random number
			return Convert.ToBase64String(buff);
		}

		private static string CreatePasswordHash(string pwd, string salt)
		{
			string saltAndPwd = String.Concat(pwd, salt);
			string hashedPwd =
				FormsAuthentication.HashPasswordForStoringInConfigFile(saltAndPwd, "SHA1");
			
			return hashedPwd;
		}

		public static void CreateAccount( string userID, string password)
		{
			string salt = CreateSalt(5);
			string passwordHash = CreatePasswordHash(password,salt);


		/*
			SqlConnection conn = new SqlConnection(NetsoftUSA.Web.WebApplication.connectionString);
			SqlCommand cmd = new SqlCommand("usp_CreateAccount", conn );
			cmd.CommandType = CommandType.StoredProcedure;
			SqlParameter sqlParam = null;
			sqlParam = cmd.Parameters.Add("@userID", SqlDbType.VarChar, 255);
			sqlParam.Value = userID;
			sqlParam = cmd.Parameters.Add("@passwordHash ", SqlDbType.VarChar, 40);
			sqlParam.Value = passwordHash;
			sqlParam = cmd.Parameters.Add("@salt", SqlDbType.VarChar, 10);
			sqlParam.Value = salt;
			try
			{
				conn.Open();
				cmd.ExecuteNonQuery();
			}
			catch( Exception ex )
			{
				// Code to check for primary key violation (duplicate account name)
				// or other database errors omitted for clarity
				throw new Exception("Exception adding account. " + ex.Message);
			}
			finally
			{
				conn.Close();
			}
			*/
		}

		public static bool VerifyPassword(string suppliedLoginName,
			string suppliedPassword )
		{
			bool passwordMatch = false;
			bool loginFound = false;
			// Get the salt and pwd from the database based on the user name.
			SqlConnection conn = new SqlConnection(NetsoftUSA.Security.WebApplication.ConnectionString);
			SqlCommand cmd = new SqlCommand( "usp_getPassword", conn );
			cmd.CommandType = CommandType.StoredProcedure;
			SqlParameter sqlParam = cmd.Parameters.Add("@LoginName",
				SqlDbType.VarChar, 50);
			sqlParam.Value = suppliedLoginName;
			try
			{
				conn.Open();
				SqlDataReader reader = cmd.ExecuteReader();
				reader.Read(); // Advance to the one and only row
				loginFound = reader.HasRows;
				if (!loginFound)
				{
					return passwordMatch;
				}
				// Return output parameters from returned data stream
				int userID = reader.GetInt32(0);
				string dbPasswordHash = reader.GetString(1);
				string salt = reader.GetString(2);
				int status =  reader.GetInt32(3);
				bool active = reader.GetBoolean(4);;
				int failedlogins = reader.GetInt32(5);;
				reader.Close();
				if (!active)
				{
					throw new Exception("Account is not Active. Please contact your system administrator.");
				}
				if (status!= 1)
				{
					throw new Exception("Account is locked out. Please contact your system administrator.");
				}
					

				// Now take the salt and the password entered by the user
				// and concatenate them together.
				string passwordAndSalt = String.Concat(suppliedPassword, salt);
				// Now hash them
				string hashedPasswordAndSalt =
					FormsAuthentication.HashPasswordForStoringInConfigFile(
					passwordAndSalt, "SHA1");
				// Now verify them.
				passwordMatch = hashedPasswordAndSalt.Equals(dbPasswordHash);

				//If Login failed we need to update the counter for the failed login attempts
				if (!passwordMatch && loginFound)
				{
					SqlCommand cmdUpdateFailedLogin = new SqlCommand( "usp_UpdateFailedLogin", conn );
					cmdUpdateFailedLogin.CommandType = CommandType.StoredProcedure;
					SqlParameter sqlParamFailedLogin = cmdUpdateFailedLogin.Parameters.Add("@LoginName",
						SqlDbType.VarChar, 50);
					sqlParamFailedLogin.Value = suppliedLoginName;
					cmdUpdateFailedLogin.ExecuteNonQuery();
				}
				else
				{ 
					//if login successful reset the failed login counters to 0
					SqlCommand cmdResetFailedLogin = new SqlCommand( "usp_ResetFailedLogin", conn );
					cmdResetFailedLogin.CommandType = CommandType.StoredProcedure;
					SqlParameter sqlParamResetFailedLogin = cmdResetFailedLogin.Parameters.Add("@LoginName",
						SqlDbType.VarChar, 50);
					sqlParamResetFailedLogin.Value = suppliedLoginName;
					cmdResetFailedLogin.ExecuteNonQuery();
				}
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
			finally
			{
				conn.Close();
			}
			return passwordMatch;
		}

		public static string[] GetRoles(string userName)
		{
			// Retrieves the user's list of roles from the database
			// and returns an array that can be used to create a principal object
			ArrayList roleArray = new ArrayList();
			SqlConnection conn = new SqlConnection(NetsoftUSA.Security.WebApplication.ConnectionString);
			SqlCommand cmd = new SqlCommand( "usp_getRoles", conn );
			cmd.CommandType = CommandType.StoredProcedure;
			SqlParameter sqlParam = cmd.Parameters.Add("@LoginName",SqlDbType.VarChar,50);
			sqlParam.Value = userName;
			
				conn.Open();
				SqlDataReader reader = cmd.ExecuteReader();
			try
			{
				if (!reader.HasRows)
				{
					return null;
				}
				// Return output parameters from returned data stream
				while (reader.Read())
				{
					roleArray.Add(reader.GetString(0));
				}

				reader.Close();

			}
			catch
			{

			}
			return (string[]) roleArray.ToArray(typeof(string));
		}
	}
}
