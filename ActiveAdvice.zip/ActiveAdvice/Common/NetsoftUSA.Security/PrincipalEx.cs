using System;
using System.Web;
using System.Web.Security;
using System.Security.Principal;
using System.Security.Permissions;




namespace NetsoftUSA.Security
{
	/// <summary>
	/// Summary description for PrincipalEx.
	/// </summary>
	public class PrincipalEx : GenericPrincipal
	{
        
		public PrincipalEx(System.Security.Principal.IIdentity identity, string[] roles): base(identity, roles)
		{
	
		}
	


	}
	/*
		public class WebIdentity: GenericIdentity
		{
			public WebIdentity(string name)
			{
			}
			private int userID;
			private string firstName;
			private string lastName;

			public virtual int UserID 
			{
				get
				{
					return userID;
				}

				set
				{
					userID = value;
				}
			}
			public virtual string FirstName
			{
				get 
				{
					return firstName;
				}
				set
				{
					firstName = value;
				}
			}
			public virtual string LastName
			{
				get
				{
					return lastName;
				}
				set
				{
					lastName = value;
				}
			}

		


		}
		*/
}
