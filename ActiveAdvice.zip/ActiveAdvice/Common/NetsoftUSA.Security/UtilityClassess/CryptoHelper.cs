using System;
using System.Data;
using System.Web.Security;
using System.Security.Cryptography;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text;
using System.Web;
using NetsoftUSA.Security.Cryptography;

namespace NetsoftUSA.Security
{
	/// <summary>
	/// Contains the utility methods to utilize cryptography functions easier
	/// </summary>
	public class CryptoHelper
	{
		public CryptoHelper()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		/// <summary>
		/// Generates a random salt value of a given size
		/// </summary>
		/// <param name="size">Size of the salt value</param>
		/// <returns>Salt</returns>
		private static string CreateSalt(int size)
		{
			// Generate a cryptographic random number using the cryptographic
			// service provider
			RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
			byte[] buff = new byte[size];
			rng.GetBytes(buff);
			// Return a Base64 string representation of the random number
			return Convert.ToBase64String(buff);
		}
			

		/// <summary>
		/// Creates the hash value of the given string
		/// </summary>
		/// <param name="strValue">The string to be hashed</param>
		/// <param name="salt">The salt value</param>
		/// <returns>Hashed string</returns>
		private static string CreateHashedString(string strValue, string salt)
		{
			string saltAndString = String.Concat(strValue, salt);
			string hashedString =
				FormsAuthentication.HashPasswordForStoringInConfigFile(saltAndString, "SHA1");

			return hashedString;
		}


		public static string Encrypt(string parameter)
		{
			DataProtector dp = new DataProtector(DataProtector.Store.USE_MACHINE_STORE);
			try
			{
				byte[] dataToEncrypt = Encoding.ASCII.GetBytes(parameter);
				// Not passing optional entropy
				// Could pass random value (stored by the application) for added security
				// when using DPAPI with the machine store.
				return Convert.ToBase64String(dp.Encrypt(dataToEncrypt, null));
			}
			catch(Exception ex)
			{
				return null;
			}
		}

		public static string Decrypt(string parameter)
		{
			DataProtector dp = new DataProtector(DataProtector.Store.USE_MACHINE_STORE);
			try
			{
				byte[] dataToDecrypt = Convert.FromBase64String(parameter);
				// Optional entropy parameter is null.
				// If entropy was used within the Encrypt method, the same entropy parameter
				// must be supplied here

				return Encoding.ASCII.GetString(dp.Decrypt(dataToDecrypt, null));

			}
			catch(Exception ex)
			{
				return null;
			}
		}


		public static string EncryptQueryStringParameter(string parameter, bool urlEncode)
		{
			try
			{
				string encryptedString = Encrypt(parameter);

				if (urlEncode && encryptedString != null)
				{
					return HttpUtility.UrlEncode(encryptedString, System.Text.Encoding.UTF8);
				}

				return encryptedString;
			}
			catch(Exception ex)
			{
				return null;
			}
		}


		public static string DecryptQueryStringParameter(string parameter, bool urlEncode)
		{
			try
			{
				string decryptedString = Encrypt(parameter);

				if (urlEncode && decryptedString != null)
				{
					return HttpUtility.UrlDecode(decryptedString, System.Text.Encoding.UTF8);
				}

				return decryptedString;
			}
			catch(Exception ex)
			{
				return null;
			}
		}



	}
}
