using System;
using System.Text.RegularExpressions;
using System.Data.SqlTypes;

namespace NetsoftUSA.Security.Validation
{

	// this enum is used by InputValidator class to evaluate the expression
	public enum ValidationType 
	{
		Numeric,
		String,
		Date
	}

	// this will be used to indicate the type of validation
	public enum ValidateFor 
	{
		ZipCode,
		SSN,
		Email,
		FreeText,
		PhoneNumber,
		Number,
		Currency,
		Date,
		AlphaNumeric
	}


	/// <summary>
	/// Summary description for InputValidator.
	/// </summary>
	public class InputValidator
	{

		#region Regular Expressions
		private const string RegEx_USZIP = @"\d{5}(-\d{4})?"; // 11103 or 11103-1234
		private const string RegEx_USPhoneNumber = @"^\(?\d{3}\)?\s|-\d{3}-\d{4}$"; // (914) 123-4567
		private const string RegEx_Email = @"^\w+((-\w+)|(\.\w+))*\@\w+((\.|-)\w+)*\.\w+$";
		private const string RegEx_Alphabets = @"^[a-zA-Z]+$";
		private const string RegEx_AlphabetsWithSpace = @"^[a-zA-Z ]+$";
		private const string RegEx_AlphaNumeric = @"^[a-zA-Z0-9]+$";
		private const string RegEx_SSN = @"^\d{3}[\-]*\d{2}[\-]*\d{4}$"; // 999-99-9999 or 999999999 
		private const string RegEx_SQLInjection1 = @"[\']";
		private const string RegEx_SQLInjection2 = @"[\-][\-]"; // check for --
		private const string RegEx_HTMLTag = @".*<(.*)>.*<\/\1>.*"; // check for HTML tags
		private const string RegEx_IsNumber = @"^\d+$";
		private const string RegEx_IsAlpha = @"^\[a-zA-Z]+$";
		#endregion
		//public static string RegEx_Email = @"^[\w-\.]{1,}\@([\da-zA-Z-]{1,}\.){1,}[\da-zA-Z-]{2,3}$"; // a@b.com(.tr)	


		public InputValidator()
		{
			//
			// TODO: Add constructor logic here
			//
		}



		
		// validate string for email with length range
		public static bool ValidateInput(string validate, ValidationType validationType, int minLength, int maxLength, ValidateFor validateFor)
		{
			if (validationType == ValidationType.String && validateFor == ValidateFor.Email)
			{
				// check length
				if (validate.Length < minLength || validate.Length >  maxLength)
					return false;
				else
				{
					// check if it's a valid email
					if (Regex.IsMatch(validate,RegEx_Email))
					{
						// check for injection
						if (Regex.IsMatch(validate,RegEx_SQLInjection1))
							return false;
						else if (Regex.IsMatch(validate,RegEx_SQLInjection2))
							return false;
						else
							return true;
					}
					else
						return false;
				}
			}

				// check for Zipcode
			else if (validationType == ValidationType.String && validateFor == ValidateFor.ZipCode)
			{
				if (validate.Length < minLength || validate.Length >  maxLength)
					return false;
				else
				{
					// check if it's a valid email
					if (Regex.IsMatch(validate,RegEx_USZIP))
					{
						// check for injection
						if (Regex.IsMatch(validate,RegEx_SQLInjection1))
							return false;
						else if (Regex.IsMatch(validate,RegEx_SQLInjection2))
							return false;
						else
							return true;
					}
					else
						return false;
				}
			}
			
			else if (validationType == ValidationType.String && validateFor == ValidateFor.FreeText)
			{
				if (validate.Length < minLength || validate.Length > maxLength)
					return false;
				else
					// perform other checks
				{
					// check for HTML Tags
					
					if (Regex.IsMatch(validate,RegEx_HTMLTag))
						return false;
					else
						return true;
				}
			}
			
			

			else if (validationType == ValidationType.Numeric && validateFor == ValidateFor.Currency)
			{
				try
				{
					SqlDouble currencyToValidate = SqlDouble.Parse(validate);

					if (currencyToValidate < SqlDouble.Parse(minLength.ToString()) || currencyToValidate > SqlDouble.Parse(maxLength.ToString()))
						return false;
					else 
						return true;
				}
				catch
				{
					return false;
				}
			}

			else if (validationType == ValidationType.Numeric && validateFor == ValidateFor.Number)
			{
				try
				{
					int numberToValidate = int.Parse(validate);

					// process parsed number 
					if ( numberToValidate < minLength || numberToValidate > maxLength)
						return false;
						// if the number is in range
					else
						return true;
				}


					//if the string cannot be parsed as a number return false
				catch
				{
					return false;
				}	
			}

			else if (validationType == ValidationType.Numeric && validateFor == ValidateFor.Number)
			{
				try
				{
					SqlInt32  currencyToValidate = SqlInt32.Parse(validate);
					if (currencyToValidate < SqlInt32.Parse(minLength.ToString()) || currencyToValidate > SqlInt32.Parse(maxLength.ToString()))
						return false;
					else 
						return true;
				}
				catch
				{
				
					return false;
				}
			}
			
			else
				return false;
		}
			









		// validate string for email without length range
		public static bool ValidateInput(string validate, ValidationType validationType, ValidateFor validateFor)
		{
			if (validationType == ValidationType.String && validateFor == ValidateFor.Email)
			{

				// check if it's a valid email
				if (Regex.IsMatch(validate,RegEx_Email))
				{
					// check for injection
					if (Regex.IsMatch(validate,RegEx_SQLInjection1))
						return false;
					else if (Regex.IsMatch(validate,RegEx_SQLInjection2))
						return false;
					else
						return true;
				}
				else
					return false;
			}
				// check for Zipcode
			else if (validationType == ValidationType.String && validateFor == ValidateFor.ZipCode)
			{
				// check if it's a valid email
				if (Regex.IsMatch(validate,RegEx_USZIP))
				{
					// check for injection
					if (Regex.IsMatch(validate,RegEx_SQLInjection1))
						return false;
					else if (Regex.IsMatch(validate,RegEx_SQLInjection2))
						return false;
					else
						return true;
				}
				else
					return false;
			}
			else if (validationType == ValidationType.String && validateFor == ValidateFor.PhoneNumber)
			{
				// check if it's a valid email
				if (Regex.IsMatch(validate,RegEx_USZIP))
				{
					// check for injection
					if (Regex.IsMatch(validate,RegEx_SQLInjection1))
						return false;
					else if (Regex.IsMatch(validate,RegEx_SQLInjection2))
						return false;
					else
						return true;
				}
				else
					return false;
			}

			else if (validationType == ValidationType.String && validateFor == ValidateFor.SSN)
			{
				if (Regex.IsMatch(validate, RegEx_SSN))
					return true;
				else
					return false;
			}

			else if (validationType == ValidationType.String && validateFor == ValidateFor.FreeText)
			{
				// check for HTML Tags
				if (Regex.IsMatch(validate,RegEx_SQLInjection1))
					return false;
				else if (Regex.IsMatch(validate,RegEx_SQLInjection2))
					return false;
				else if (Regex.IsMatch(validate,RegEx_HTMLTag))
					return false;
				else
					return true;
			}
			else
				return false;

		}
			
		


		/// <summary>
		///		Validates a string to determine if it can be converted to a SQL Double 
		///		data type
		///		and if it's in the specified value range
		/// </summary>
		/// <param name="validate"></param>
		/// <param name="validationType"></param>
		/// <param name="minValue"></param>
		/// <param name="maxValue"></param>
		/// <param name="validateFor"></param>
		/// <returns></returns>		
		public static bool ValidateInput(string validate, ValidationType validationType, double minValue, double maxValue, ValidateFor validateFor)
		{
			if (validationType == ValidationType.Numeric && validateFor == ValidateFor.Currency)
			{
				try
				{
					SqlDouble currencyToValidate = SqlDouble.Parse(validate);
					if (currencyToValidate < SqlDouble.Parse(minValue.ToString()) || currencyToValidate > SqlDouble.Parse(maxValue.ToString()))
						return false;
					else 
						return true;
				}
				catch
				{
					return false;
				}
			}
			else
				return false;
		}


		/// <summary>
		///		Validates a string to see if it's convertible to Sql Decimal data type
		///		and then it checks to determine if the value is in the specified range
		/// </summary>
		/// <param name="validate"></param>
		/// <param name="validationType"></param>
		/// <param name="minValue"></param>
		/// <param name="maxValue"></param>
		/// <param name="validateFor"></param>
		/// <returns>true/false</returns>
		public static bool ValidateInput(string validate, ValidationType validationType, decimal minValue, decimal maxValue, ValidateFor validateFor)
		{
			if (validationType == ValidationType.Numeric && validateFor == ValidateFor.Currency)
			{
				try
				{
					SqlDecimal currencyToValidate = SqlDecimal.Parse(validate);
					if (currencyToValidate < SqlDecimal.Parse(minValue.ToString()) || currencyToValidate > SqlDecimal.Parse(maxValue.ToString()))
						return false;
					else 
						return true;
				}
				catch
				{
					return false;
				}
			}
			else
				return false;
		}


		public static bool ValidateInput(decimal validate, ValidationType validationType, decimal minValue, decimal maxValue, ValidateFor validateFor)
		{
			if (validationType == ValidationType.Numeric && validateFor == ValidateFor.Currency)
			{
				try
				{
					SqlDecimal currencyToValidate = System.Data.SqlTypes.SqlDecimal.Parse(validate.ToString());
				
					if (currencyToValidate < SqlDecimal.Parse(minValue.ToString()) || currencyToValidate > SqlDecimal.Parse(maxValue.ToString()))
						return false;
					else 
						return true;
				}
				catch
				{
					return false;
				}
			}
			else
				return false;
		}


		/// <summary>
		///		Validates the input to determine if it contains only numbers. Then it checks
		///		the value stored in the string to ensure it's in the specified range.
		/// </summary>
		/// <param name="validate">String to validate</param>
		/// <param name="minValue">Minimum value of the value stored in the string (numeric)</param>
		/// <param name="maxValue">Maximum value of the value stored in the string (numeric)</param>
		/// <returns></returns>
		public static bool IsNumber(string validate, int minValue, int maxValue)
		{
			if(Regex.IsMatch(validate,RegEx_IsNumber))
			{
				if (int.Parse(validate) < maxValue && int.Parse(validate) > minValue)
					return true;
				else
					return false;
			}
			else
				return false;
		}


		/// <summary>
		///		Validates the input to determine if it contains only numbers.
		/// </summary>
		/// <param name="validate">String to validate</param>
		/// <returns></returns>
		public static bool IsNumber(string validate)
		{
			if (Regex.IsMatch(validate, RegEx_IsNumber))
				return true;
			else
				return false;
		}


		/// <summary>
		///		Validate the string to ensure it only contains letters. Then it checks the length
		///		of the string to make sure it's in the specified range.
		/// </summary>
		/// <param name="validate">String to validate</param>
		/// <param name="minLength">Minimum length of the string</param>
		/// <param name="maxLength">Maximum length of the string</param>
		/// <returns></returns>
		public static bool IsAlpha(string validate, int minLength, int maxLength)
		{
			if (Regex.IsMatch(validate,RegEx_IsAlpha))
			{
				if(validate.Length < maxLength && validate.Length > minLength)
					return true;
				else
					return false;
			}
			else 
				return false;
		}


		/// <summary>
		/// Validates a string to ensure it only contains letters.
		/// </summary>
		/// <param name="validate">String to validate</param>
		/// <returns></returns>
		public static bool IsAlpha(string validate)
		{
			if (Regex.IsMatch(validate,RegEx_IsAlpha))
				return true;
			else
				return false;
		}



	}
}
