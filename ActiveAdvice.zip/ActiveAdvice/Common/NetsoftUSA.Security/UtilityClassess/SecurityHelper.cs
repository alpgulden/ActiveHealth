using System;
using System.Data;
using System.Web.Security;
using System.Security.Cryptography;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text;
using System.Web;
using NetsoftUSA.Security.Cryptography;

namespace NetsoftUSA.Security
{
	/// <summary>
	/// Summary description for SecurityHelper.
	/// </summary>
	public class SecurityHelper
	{
		public SecurityHelper()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		/// <summary>
		/// Sets the authentication ticket with the parameters provided
		/// </summary>
		/// <param name="userID">User ID</param>
		/// <param name="userData">Custom data to be stored in thr cookie (permissions, roles etc.)</param>
		/// <param name="expirationDate">Expritaion date</param>
		/// <param name="redirect">True if the caller wants this method to handle the redirection</param>
		public static void SetAuthTicket(string userID, string userData, DateTime expirationDate, bool persistent, bool autoRedirect)
		{
			// Create the authentication ticket
			FormsAuthenticationTicket authTicket = new
				FormsAuthenticationTicket(1, // version
				userID, // User ID
				DateTime.Now, // creation
				expirationDate,// Expiration
				persistent, // Persistent
				userData); // User data

			// Now encrypt the ticket.
			string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
			
			// Create a cookie and add the encrypted ticket to the
			// cookie as data.
			HttpCookie authCookie =
				new HttpCookie(FormsAuthentication.FormsCookieName,
				encryptedTicket);

			// Add the cookie to the outgoing cookies collection.
			HttpContext.Current.Response.Cookies.Add(authCookie);

			if (autoRedirect)
			{
				// Redirect the user to the originally requested page
				if (FormsAuthentication.GetRedirectUrl(userID, false) != null)
					HttpContext.Current.Response.Redirect( FormsAuthentication.GetRedirectUrl(userID, false));
			}
		}


		public static FormsAuthenticationTicket GetAuthTicket()
		{
			string cookieName = FormsAuthentication.FormsCookieName;
			HttpCookie authCookie = HttpContext.Current.Request.Cookies[cookieName];
			if(null == authCookie)
			{
				// There is no authentication cookie.
				return null;
			}

			//Authentication cookie is found, now we need to decrypt it.
			FormsAuthenticationTicket authTicket = null;
			try
			{
				authTicket = FormsAuthentication.Decrypt(authCookie.Value);
			}
			catch(Exception ex)
			{
				return null;
			}

			if (null == authTicket)
			{
				// Cookie failed to decrypt.
				return null;
			}

			// If the ticket expired do sign out
			if (authTicket.Expired)
			{
				FormsAuthentication.SignOut();
				return null;
			}


			return authTicket;
		}


	}
}
