using System;
using System.Collections.Specialized;
using System.Configuration;
using Microsoft.Win32;

namespace NetsoftUSA.Security
{
	/// <summary>
	/// Summary description for ConfigHelper.
	/// </summary>
	public class ConfigHelper
	{
		public static string defaultConfigSection = "NSApplicationSettings";	

		public ConfigHelper()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		public static string GetConfigValue(string key)
		{
			return GetConfigValue(defaultConfigSection, key);
		}

		public static string GetConfigValue(string configSection, string key)
		{
			try
			{
				NameValueCollection section = (NameValueCollection)ConfigurationSettings.GetConfig(configSection);
				return section.GetValues(key)[0];
			}
			catch(Exception ex) 
			{
				throw new Exception(String.Format("An error occured while accessing configuration value {0} in section {1}. Error Details: {2}", key, configSection, ex.Message), ex);
			}
		}


		public static string GetRegistryValue(string registryPath, string registryKey)
		{
			try
			{
				RegistryKey regKey = Registry.LocalMachine.OpenSubKey(registryPath);
				return (string)regKey.GetValue(registryKey);
			}
			catch(Exception ex) 
			{
				throw new Exception(String.Format("An error occured while accessing registry value {0} in {1}. Error Details: {2}", registryKey, registryPath, ex.Message), ex);
			}
		}

	}
}
