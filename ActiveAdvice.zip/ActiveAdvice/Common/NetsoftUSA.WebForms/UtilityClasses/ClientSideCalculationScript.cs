using System;
using NetsoftUSA.DataLayer;
using System.Reflection;
using System.Web.UI;
using System.Text;
using System.Collections;
using System.Collections.Specialized;

namespace NetsoftUSA.WebForms
{
	#region ClientSideCalculationScript

	/// <summary>
	/// Summary description for ClientSideCalculationScript.
	/// </summary>
	public class ClientSideCalculationScript : GenericScript
	{
		private ControlCollection controls;		// controls to work on
		private Hashtable boundControls;

		public ClientSideCalculationScript(Type type, object dataObject, ControlCollection controls)
			: base (type, dataObject)
		{
			this.controls = controls;
		}

		private Control GetControlBoundToMember(string memberName)
		{
			return boundControls[memberName] as Control;
		}

		public override string MakeScriptForGet(string memberName)
		{
			Control ctl = GetControlBoundToMember(memberName);
			if (ctl == null)
				return null;
			string ctlId = ctl.ClientID;
			string acc = String.Format("GetElemValue('{0}')", ctlId);
			Type t = ReflectionHelper.GetMemberType(type, memberName);
			if (t == typeof(string))
				return acc;
			else if (t == typeof(int) || t == typeof(long))
				return String.Format("ParseInt({0})", acc);
			else if (t == typeof(DateTime))
				return String.Format("ParseDate({0})", acc);
			else
				return String.Format("ParseFloat({0})", acc);
		}

		public override string MakeScriptForSet(string memberName)
		{
			Control ctl = GetControlBoundToMember(memberName);
			if (ctl == null)
				return null;
			string ctlId = ctl.ClientID;
			return String.Format("SetElemValue('{0}', {{0}})", ctlId);
		}

		public string GenerateClientScript(string targetMember, GenericScriptAttribute genScrAtt, bool calcOrValidation, bool exceptionsHandled)
		{
			if (calcOrValidation)
			{
				// calculation script
				string setScript = MakeScriptForSet(targetMember);
				if (setScript == null)
					return null;		// not found in the controls
				string s = String.Format( setScript, SubstituteMacros(genScrAtt.JScript) );
				if (exceptionsHandled)
					s = String.Format("try {{ {0}; }} catch(e) {{ window.alert('Error in {1}: ' + e) }}\r\n", s, targetMember);
				else
					s += "\r\n";
				return s;
			}
			else
			{
				// validation script
				string s = "arguments.IsValid = " + SubstituteMacros(genScrAtt.JScript);
				if (exceptionsHandled)
					s = String.Format("try {{ {0}; }} catch(e) {{ window.alert('Error in {1}: ' + e) }}\r\n", s, targetMember);
				else
					s += "\r\n";
				return String.Format("function {0}(source, arguments)\r\n{{\r\n{1}}}\r\n", genScrAtt.GetUniqueFunctionName(), s); 
			}
		}

		public string GenerateClientScript(MemberInfo mi, bool calcOrValidation, bool exceptionsHandled)
		{
			GenericScriptAttribute genScrAtt = GenericScriptAttribute.GetFromMember(mi);
			if (genScrAtt == null || genScrAtt.JScript == null)
				throw new ArgumentException(String.Format("Member {0}.{1} has no generic script declared", mi.DeclaringType.Name, mi.Name));

			return GenerateClientScript(mi.Name, genScrAtt, calcOrValidation, exceptionsHandled);
			/*ControlTypeAttribute ctlType = ControlTypeAttribute.GetFromMember(mi, false);
			if (ctlType != null)
				if (ctlType.ClientFormatter != null)
					s += ";" + ctlType.cli			// The formatter uses this.value!!! Can't call client formatter here!
			*/
		}

		public string GenerateClientScript(string memberName, bool calcOrValidation, bool exceptionsHandled)
		{
			return GenerateClientScript(ReflectionHelper.GetFieldOrProp(type, memberName), calcOrValidation, exceptionsHandled);
		}

		/// <summary>
		/// this must be called before generating script
		/// </summary>
		public void FindBoundControls()
		{
			boundControls = new Hashtable();

			FindBoundControls(this.controls);
		}

		private void FindBoundControls(ControlCollection controls)
		{
			foreach (Control control in controls)
			{
				IObjectBoundControl ictl = control as IObjectBoundControl;
				if (ictl != null)	// if this is of expected type web control
				{
					if (control is  IClientValidatableMarker) // OBTextBox || control is OBComboBox || control is 
					{
						string sourceMember = ictl.GetSourceObjectMember();
						if (sourceMember != null)
							boundControls[sourceMember] = control;
					}
				}
				else
				{
					if (control.Controls.Count != 0)
						FindBoundControls(control.Controls);
				}
			}
		}
		
		/// <summary>
		/// Builds the content of the client calculation function (calculations for all the members)
		/// </summary>
		/// <param name="sb"></param>
		public void GenerateClientScriptsForMembers(StringBuilder sb, StringBuilder sbVal, bool exceptionsHandled)
		{
			FindBoundControls();
			StringCollection col = GetScriptedMembersInDependecyOrder();
			for (int i = 0; i < col.Count; i++)
			{
				string memberName = col[i];
				if (memberName.Length >= 4 && memberName.Substring(0, 4) == "Vld_")
					sbVal.Append(this.GenerateClientScript(memberName, false, exceptionsHandled));
				else
					sb.Append(this.GenerateClientScript(memberName, true, exceptionsHandled));
			}
		}
		

		/*
		protected void GenerateClientScripts(StringBuilder sb, ControlCollection controls, bool exceptionsHandled)
		{
			for (int i = 0; i < this.controls.Count; i++)
			{
				Control ctl = this.controls[i];
				if (ctl.Controls.Count > 0)
				{
					
				}
			}
		}


		public string GenerateClientScripts(bool exceptionsHandled)
		{
			for (int i = 0; i < this.controls.Count; i++)
			{
				Control ctl = this.controls[i];
				if ctl.
			}
		}*/

	}

	#endregion
}
