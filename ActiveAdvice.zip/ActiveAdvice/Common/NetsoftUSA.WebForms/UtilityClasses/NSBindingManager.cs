using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using NetsoftUSA.DataLayer;
using System.Diagnostics;

namespace NetsoftUSA.WebForms
{
	public class BindingEventArgs : EventArgs
	{
		public bool cancelDefault = false;
		public int[] rowIds = null;
	}

	/// <summary>
	/// Manages the associated data component's dataMember
	/// in the related bindingManager's context.
	/// </summary>
	public class DCBinding
	{
		public delegate void BeforeNavigateEventHandler(object sender, BindingEventArgs e);
		public delegate void SearchEventHandler(object sender, BindingEventArgs e);
		public delegate void DeleteRecordEventHandler(object sender, BindingEventArgs e);
		public delegate void DeleteRecordsEventHandler(object sender, BindingEventArgs e);

		#region Private members
		private DCBase dataComp;		// managed data component
		private string dataMember;		// managed data member of the data component
		private NSBindingManager bindingManager;		// parent binding manager
		private BasePage page;							// page that owns this binding manager
		private bool autoValidate = true;		// automatically validates all records before save operation

		/// <summary>
		/// Recursively traverse the controls in the page and notify the new position
		/// </summary>
		private void UpdateAllRowPositions(ControlCollection controls, bool bindData)
		{
			int rowPos = dataComp.GetTableRowPos(dataMember);

			foreach (Control control in controls)
			{
				NSDataGrid grid = control as NSDataGrid;
				if (grid != null)
				{
					if (dataComp == grid.DataSourceObject)
					{
						if (dataMember == grid.DataMemberName)
						{
							int pageIndex = grid.CurrentPageIndex;
							grid.CurrentRowPos = rowPos;
							if (bindData || pageIndex != grid.CurrentPageIndex)
								grid.BindGrid();		// bind grid to reveal changes
						}
					}
				}
				else
				{
					// check if this is a controls collection
					if (control.Controls.Count != 0)
						UpdateAllRowPositions(control.Controls, bindData);
				}
			}
		}

		private void validate()
		{
			if (autoValidate)
			{
				dataComp.Validators.Validate();
				if (!dataComp.Validators.IsValid)
					throw new Exception("There are invalid items");
			}
		}

		#endregion

		#region Constructors
		/// <summary>
		/// Create the Data Component Binding to manage the specified
		/// dataComp and dataMember in the context of the specified bindingManger.
		/// </summary>
		/// <param name="bindingManager"></param>
		/// <param name="dataComp"></param>
		/// <param name="dataMember"></param>
		public DCBinding(NSBindingManager bindingManager, DCBase dataComp, string dataMember)
		{
			this.bindingManager = bindingManager;
			this.dataComp = dataComp;
			this.dataMember = dataMember;
			this.page = bindingManager.page;

		}
		#endregion

		#region Events

		public event DCBinding.BeforeNavigateEventHandler BeforeNavigateEvent;
		public event EventHandler NavigateEvent;
		public event DCBinding.SearchEventHandler SearchEvent;
		public event DCBinding.DeleteRecordEventHandler DeleteEvent;
		public event DCBinding.DeleteRecordsEventHandler DeleteRecordsEvent;
		public event EventHandler LoadDataEvent;

		#endregion

		#region Public members
		public DCBase DataComp
		{
			get
			{
				return dataComp;
			}
		}

		public string DataMember
		{
			get
			{
				return dataMember;
			}
		}

		/// <summary>
		/// Should validation be call before save?
		/// </summary>
		public bool AutoValidate
		{
			get
			{
				return autoValidate;
			}
			set
			{
				autoValidate = value;
			}
		}
		#endregion

		#region Record navigation functions
		/// <summary>
		/// Controls the current row position in the associated dataComp-dataMember
		/// </summary>
		/// <param name="navigate"></param>
		public int Navigate(DCTableNavigate navigate)
		{
			// First save the currently displaying data
			if (BeforeNavigateEvent != null)
			{
				BindingEventArgs e = new BindingEventArgs();
				BeforeNavigateEvent(this, e);
				if (e.cancelDefault)
					return dataComp.GetTableRowPos(dataMember);
			}
			try
			{
				InternalUpdateData(true);
				dataComp.NavigateTable(dataMember, navigate);
				if (NavigateEvent != null)
					NavigateEvent(this, new EventArgs());
				InternalUpdateData(false);
			}
			catch(Exception ex)
			{
				page.RaisePageException(ex);
			}
			return dataComp.GetTableRowPos(dataMember);
		}

		/// <summary>
		/// Controls the current row position in the associated dataComp-dataMember
		/// </summary>
		/// <param name="rowNum"></param>
		public int Navigate(int rowNum)
		{
			// First save the currently displaying data
			if (BeforeNavigateEvent != null)
			{
				BindingEventArgs e = new BindingEventArgs();
				BeforeNavigateEvent(this, e);
				if (e.cancelDefault)
					return dataComp.GetTableRowPos(dataMember);
			}
			try
			{
				InternalUpdateData(true);
				dataComp.SetTableRowPos(dataMember, rowNum);
				if (NavigateEvent != null)
					NavigateEvent(this, new EventArgs());
				InternalUpdateData(false);
			}
			catch(Exception ex)
			{
				page.RaisePageException(ex);
			}
			return dataComp.GetTableRowPos(dataMember);
		}

		/// <summary>
		/// Must be called just after loading the data component
		/// possbily in page load.  Do not attempt to call
		/// navigate before calling this.
		/// </summary>
		/// <param name="rowNum"></param>
		public void InitialNavigate(int rowNum)
		{
			dataComp.SetTableRowPos(dataMember, rowNum);
			UpdateData(false);
			Navigate(rowNum);
		}

		public void InitialNavigate()
		{
			int rowNum = dataComp.GetTableRowPos(dataMember);
			if (rowNum == -1)
				InitialNavigate(0);
			else
			{
				dataComp.AdjustRowPos(dataMember);
				rowNum = dataComp.GetTableRowPos(dataMember);
				InitialNavigate(rowNum);
			}
		}

		/// <summary>
		/// Must be called just after loading the data component
		/// The difference from method InitialNavigate(int rowNum)
		/// is that this overload checks for the query string
		/// and if it finds "ID=xx", it uses that
		/// </summary>
		/// <param name="rowNum"></param>
		public void InitialNavigate(string sid)
		{
			//check for the ID= param in the query string
			//string sid = parpage.Request.QueryString["ID"];
			if (sid != null && sid != "")
			{
				int id = int.Parse(sid);
				DataTable tbl = this.dataComp.GetTable(dataMember);
				DataRow row = tbl.Rows.Find(id);
				if (row != null)
					for (int i = 0; i < tbl.Rows.Count; i++)
					{
						if (tbl.Rows[i] == row)
						{
							InitialNavigate(i);
							return;
						}
					}
			}
			InitialNavigate();
		}

		/// <summary>
		/// Must be called just after loading the component from cache.
		/// Thus, it'll use it's current row position.
		/// </summary>
		/*public void InitialNavigate()		// go to whereever the cursor is
		{
			int rowNum = dataComp.GetTableRowPos(dataMember);
			UpdateData(false);
			Navigate(rowNum);
		}*/

		public void CreateSelectFor(DCBinding targetBinding)
		{
			SqlCommand select = dataComp.CreateSelect(dataMember);
            targetBinding.DataComp.SetSelectCommand(select);
		}

		public void CreateSelectFor(DCBinding targetBinding, string[] columns)
		{
			SqlCommand select = dataComp.CreateSelect(dataMember, columns);
			targetBinding.DataComp.SetSelectCommand(select);
		}

		#endregion

		#region Record manipulation functions

		/// <summary>
		/// Return currently selected data row for the associated data componet and
		/// data member.
		/// </summary>
		/// <returns></returns>
		public DataRow GetCurrentDataRow()
		{
			return dataComp.GetCurrentDataRow(dataMember);
		}

		/// <summary>
		/// Return currently selected data row view for the associated data componet and
		/// data member.
		/// </summary>
		/// <returns></returns>
		public DataRowView GetCurrentDataRowView()
		{
			return dataComp.GetCurrentDataRowView(dataMember);
		}

		/// <summary>
		/// NewRecord the current for the associated dataComp-dataMember
		/// </summary>
		public void NewRecord()
		{
			// First save the currently displaying data
			try
			{
				InternalUpdateData(true);
			}
			catch(System.Data.NoNullAllowedException noNullEx)
			{
				page.SetPageMessage(noNullEx.Message, EnumPageMessageType.Error);
				page.PageError = true;
			}
			catch(Exception ex)
			{
				page.RaisePageException(ex);
				return;
			}

			try
			{
				dataComp.NewRecord(dataMember);
			}
			catch(Exception ex)
			{
				page.RaisePageException(ex);
			}
			InternalUpdateData(false);
		}

		/// <summary>
		/// Save the associated dataComp
		/// </summary>
		public void SaveData()
		{
			// First save the currently displaying data
			try
			{
				InternalUpdateData(true);
				dataComp.SaveData();
				//InternalUpdateData(false);
				LoadData();
			}
			catch(Exception ex)
			{
				page.RaisePageException(ex);
			}
		}

		/// <summary>
		/// Load the associated dataComp
		/// </summary>
		public void LoadData()
		{
			// First save the currently displaying data
			// page.UpdateData(dataComp, dataMember, true);  *** no need
			try
			{
				//int rowNum = dataComp.GetTableRowPos(dataMember);
				dataComp.LoadData();			// this is a generic load method, parameters should be set to the object earlier!
				//InitialNavigate(rowNum);
				//dataComp.SetTableRowPos(dataMember, rowNum);
				InternalUpdateData(false);

				if (LoadDataEvent != null)
					LoadDataEvent(this, new EventArgs());
			}
			catch(Exception ex)
			{
				page.RaisePageException(new Exception("Error loading data", ex));
			}
		}

		/// <summary>
		/// Search data.  There's no default implementations.  Just raises an event.
		/// </summary>
		public void Search()
		{
			try
			{
				if (SearchEvent != null)
				{
					BindingEventArgs e = new BindingEventArgs();
					SearchEvent(this, e);
				}
			}
			catch(Exception ex)
			{
				page.RaisePageException(new Exception("Error loading data", ex));
			}
		}

		/// <summary>
		/// Delete the current for the associated dataComp-dataMember
		/// </summary>
		public void DeleteRecord()
		{
			// First save the currently displaying data
			// page.UpdateData(dataComp, dataMember, true);     **no need
			try
			{
				if (DeleteEvent != null)
				{
					BindingEventArgs e = new BindingEventArgs();
					DeleteEvent(this, e);
					if (e.cancelDefault)
						return;
				}

				dataComp.DeleteRecord(dataMember);
				InternalUpdateData(false);
			}
			catch(Exception ex)
			{
				page.RaisePageException(ex);
			}
		}

		/// <summary>
		/// Deletes specified records for the associated dataComp-dataMember
		/// </summary>
		public void DeleteRecords(int[] rowIds)
		{
			// First save the currently displaying data
			try
			{
				if (DeleteRecordsEvent != null)
				{
					BindingEventArgs e = new BindingEventArgs();
					e.rowIds = rowIds;
					DeleteRecordsEvent(this, e);
					if (e.cancelDefault)
						return;
				}
				InternalUpdateData(true);
				dataComp.DeleteRecords(dataMember, rowIds);
				InternalUpdateData(false);
			}
			catch(Exception ex)
			{
				page.RaisePageException(ex);
			}
		}

		public void CancelChanges()
		{
			// First save the currently displaying data
			// page.UpdateData(dataComp, dataMember, true);  ** no need
			try
			{
				//InternalUpdateData(true);
				dataComp.RejectChanges(dataMember);
				InternalUpdateData(false);
			}
			catch(Exception ex)
			{
				page.RaisePageException(ex);
			}
		}

		/// <summary>
		/// Update the data between control and the associated dataComp-dataMember.
		/// This also updates the row positions for grids.
		/// </summary>
		/// <param name="Save"></param>
		private void InternalUpdateData(bool Save)
		{
			if (Save)
				if (dataComp.GetTableRowPos(dataMember) == -1)
					return;  // do nothing

			page.UpdateData(dataComp, dataMember, Save);
			if (Save)
				if (page.PageError)
					throw page.Exception;

			if (Save)
				validate();		// this will throw if validation fails
			else
				UpdateAllRowPositions(page.Controls, true);
		}

		public void UpdateData(bool Save)
		{
			page.UpdateData(dataComp, dataMember, Save);
			if (Save)
			{
				// nop
			}
			else
				UpdateAllRowPositions(page.Controls, true);
		}

		public DataTable Table
		{
			get
			{
				return dataComp.GetTable(dataMember);
			}
		}

		public DataView DefaultView
		{
			get
			{
				return dataComp.GetTable(dataMember).DefaultView;
			}
		}

		public DataRowView CurrentRowView
		{
			get
			{
				return dataComp.GetCurrentDataRowView(dataMember);
			}
		}

		public DataRow CurrentRow
		{
			get
			{
				return dataComp.GetCurrentDataRow(dataMember);
			}
		}

		#endregion
	}

	/// <summary>
	/// You can add a datacomponet-datamember declaration to this binding manager
	/// and use it to navigate the underlying dataview of the datatable and 
	/// perform basic read, insert, update, delete operations.
	/// The BasePage provides an NSBindingManager.
	/// </summary>
	public class NSBindingManager
	{
		#region Private members
		internal BasePage page;		// The owner page
		private Hashtable bindings;	// A hash table of dataComp+dataMember objects
		#endregion

		#region Constructors
		/// <summary>
		/// Create a binding manager in the context of the specified page.
		/// </summary>
		/// <param name="page"></param>
		public NSBindingManager(BasePage page)
		{
			this.page = page;
			bindings = new Hashtable();
		}
		#endregion

		#region Public members
		/// <summary>
		/// Create a hash key for the specified dataComp and dataMember
		/// </summary>
		/// <param name="dataComp"></param>
		/// <param name="dataMember"></param>
		/// <returns></returns>
		protected static string MakeHashKey(DCBase dataComp, string dataMember)
		{
			return dataComp.GetHashCode().ToString() + "." + dataMember;
		}

		/// <summary>
		/// Create a DCBinding to manage the specified dataComp and dataMember.
		/// If the specifed binding exists, throws exception.
		/// </summary>
		/// <param name="dataComp"></param>
		/// <param name="dataMember"></param>
		/// <returns></returns>
		public DCBinding Add(DCBase dataComp, string dataMember)
		{
			if (dataComp == null)
				return null;
			string key = MakeHashKey(dataComp, dataMember);
			if (bindings.Contains(key))
				throw new Exception("Binding already exists.  Use EnsureBinding if you want to add if not available, or use if available");
			DCBinding binding = new DCBinding(this, dataComp, dataMember);
			bindings.Add(key, binding);
			return binding;
		}

		/// <summary>
		/// Create a DCBinding to manage the specified dataComp and dataMember.
		/// If the specifed binding exists, it is returned.
		/// </summary>
		/// <param name="dataComp"></param>
		/// <param name="dataMember"></param>
		/// <returns></returns>
		public DCBinding EnsureBinding(DCBase dataComp, string dataMember)
		{
			if (dataComp == null)
				return null;
			string key = MakeHashKey(dataComp, dataMember);
			if (bindings.Contains(key))
				return (DCBinding)bindings[key];
			DCBinding binding = new DCBinding(this, dataComp, dataMember);
			bindings.Add(key, binding);
			return binding;
		}

		/// <summary>
		/// Removes the binding managed for the specified dataComp and data Member.
		/// </summary>
		/// <param name="dataComp"></param>
		/// <param name="dataMember"></param>
		/// <returns></returns>
		public void Remove(DCBase dataComp, string dataMember)
		{
			string key = dataComp.GetHashCode().ToString() + "." + dataMember;
			bindings.Remove(key);
		}

		/// <summary>
		/// Remove just the specified data component's bindings from binding manager.
		/// </summary>
		/// <param name="dataComp"></param>
		public void Remove(DCBase dataComp)
		{
			foreach (DCBinding binding in bindings)
			{
				if (binding.DataComp == dataComp)
					Remove(dataComp, binding.DataMember);
			}		
		}

		/// <summary>
		/// Remove just the specified data members from binding manager.
		/// </summary>
		/// <param name="dataMember"></param>
		public void Remove(string dataMember)
		{
			foreach (DCBinding binding in bindings)
			{
				if (binding.DataMember == dataMember)
					Remove(binding.DataComp, dataMember);
			}		
		}

		/// <summary>
		/// Remove all bidings from the binding manager
		/// </summary>
		public void Clear()
		{
			bindings.Clear();
		}

		/// <summary>
		/// Removes the binding managed for the specified dataComp and data Member.
		/// </summary>
		/// <param name="dataComp"></param>
		/// <param name="dataMember"></param>
		/// <returns></returns>
		public DCBinding GetBinding(DCBase dataComp, string dataMember)
		{
			string key = MakeHashKey(dataComp, dataMember);
			return (DCBinding)bindings[key];
		}

		#endregion
	}
}
