using System;
using System.Web.UI.WebControls;
using System.Collections;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for DataGridCollectionBinder.
	/// </summary>
	public class DataGridCollectionBinder
	{
		private DataGrid dataGrid;
		private IList collection;
		private string dataKeyMember;

		public DataGridCollectionBinder(DataGrid dataGrid, IList collection, string dataKeyMember)
		{
			this.dataGrid = dataGrid;
			this.collection = collection;
			this.dataKeyMember = dataKeyMember;
		}

		public void DataBind()
		{
			this.dataGrid.DataSource = this.collection;
			if (this.dataKeyMember != null)
				this.dataGrid.DataKeyField = this.dataKeyMember;
			this.dataGrid.DataBind();
		}

	}
}
