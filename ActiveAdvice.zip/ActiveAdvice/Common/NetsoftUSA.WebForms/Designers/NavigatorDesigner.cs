using System;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.Design;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Designer object used in the VS design time for Navigator control.
	/// </summary>
	public class NavigatorDesigner : ControlDesigner
	{
		public NavigatorDesigner() : base()
		{
		}

		/// <summary>
		/// Called by the design time environment to get a representative html string
		/// </summary>
		/// <returns></returns>
		public override string GetDesignTimeHtml()
		{
			// Get the navigator control's current instance
			Navigator navigator = (Navigator)Component;
			StringWriter sw = new StringWriter();
			HtmlTextWriter tw = new HtmlTextWriter(sw);

			// populate controls inside an empty container
			Control control = new Control();
			navigator.CreateChildControls(control.Controls);
			// render them into html writer
			control.RenderControl(tw);
			// return as html text
			return sw.ToString();
		}
	}
}
