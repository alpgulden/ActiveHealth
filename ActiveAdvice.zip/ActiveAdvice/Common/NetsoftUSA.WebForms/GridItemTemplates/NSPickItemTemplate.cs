using System;
using System.Web.UI.WebControls ;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Data;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for NSPickItemTemplate.
	/// </summary>
	public class NSPickItemTemplate :ITemplate
	{
		#region Private members
		private string valueField;
		private string formattedField;
		private NSDataGrid grid; 
		#endregion

		public NSPickItemTemplate(string valueField , string formattedField, NSDataGrid grid)
		{
			this.valueField = valueField;
			this.formattedField = formattedField;
			this.grid = grid;
		}

		#region ITemplate Members

		public void InstantiateIn(Control container)
		{
			HtmlButton bt = new HtmlButton();
			bt.Attributes["class"] = grid.getValidCss(grid.CssClassCommmandButton, NSDataGrid.CssClassCommmandButtonAll);
			container.Controls.Add(bt);
			bt.DataBinding+=new EventHandler(bt_DataBinding);
			bt.InnerText = "Pick";
			bt.Attributes["onclick"] = /*grid.ID +*/ "PickItem(this)";
		}

		#endregion

		private void bt_DataBinding(object sender, EventArgs e)
		{
			if (!grid.PickButton)
				return;
			HtmlButton bt = (HtmlButton)sender;
			DataGridItem container = (DataGridItem)bt.NamingContainer;
			DataRowView rowView =(DataRowView)container.DataItem;
			string val = grid.DataSourceObject.FormatTableItem(rowView, valueField, false);
			string text = grid.DataSourceObject.SubstituteTableItems(rowView, formattedField);
			bt.Attributes["valueField"] = val;
			bt.Attributes["formattedField"] = text;
		}
	}
}
