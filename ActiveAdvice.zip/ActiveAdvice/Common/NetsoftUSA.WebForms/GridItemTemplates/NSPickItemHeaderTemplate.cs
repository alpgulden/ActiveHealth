using System;
using System.Web.UI.WebControls ;
using System.Web;
using System.Web.UI;
using System.Data;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for NSPickItemHeaderTemplate.
	/// </summary>
	public class NSPickItemHeaderTemplate :ITemplate
	{
		#region Private members
		private NSDataGrid grid; 
		#endregion

		public NSPickItemHeaderTemplate(NSDataGrid grid)
		{
			this.grid = grid;
		}

		#region ITemplate Members

		public void InstantiateIn(Control container)
		{
			TextBox pickTarget = new TextBox();
			//pickTarget.EnableViewState = false;
			pickTarget.Style["display"] = "none";
			//container.Controls.Add(bt);
			pickTarget.ID = grid.ID + "_PickTarget";
			container.Controls.Add(pickTarget);
			grid.pickTarget = pickTarget;
			pickTarget.DataBinding+=new EventHandler(pickTarget_DataBinding);
		}

		#endregion

		private void pickTarget_DataBinding(object sender, EventArgs e)
		{
			TextBox tb = (TextBox)sender;
			if (grid.pickTargetTextData != null)
				tb.Text = grid.pickTargetTextData;
		}
	}
}
