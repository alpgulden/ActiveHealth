using System;
using System.Web.UI.WebControls ;
using System.Web;
using System.Web.UI;
using System.Diagnostics;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NSDataGrid item header template used for selection checkboxes.
	/// </summary>
	public class NSGridSelectItemHeaderTemplate : ITemplate
	{
		private NSDataGrid ownerGrid;
		public NSGridSelectItemHeaderTemplate(NSDataGrid ownerGrid)
		{
			this.ownerGrid = ownerGrid;
		}
		#region ITemplate Members

		public void InstantiateIn(Control container)
		{
			// Create a checkbox control for record selection
			CheckBox cb = new CheckBox();
			cb.Attributes["onclick"] = "toggleAll(" + ownerGrid.UniqueID + ", 0, this)";
			container.Controls.Add(cb);
		}

		#endregion
	}
}
