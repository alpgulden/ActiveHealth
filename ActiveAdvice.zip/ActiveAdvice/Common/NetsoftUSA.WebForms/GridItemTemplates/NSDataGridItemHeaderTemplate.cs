using System;
using System.Web.UI.WebControls ;
using System.Web;
using System.Web.UI;
using System.Data;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for NSPickItemHeaderTemplate.
	/// </summary>
	public class NSDataGridItemHeaderTemplate :ITemplate
	{
		#region Private members
		private NSDataGrid grid; 
		private string dataMember;		// which field to display
		private string headerText;
		#endregion

		public NSDataGridItemHeaderTemplate(string dataMember, NSDataGrid grid, string headerText)
		{
			this.dataMember = dataMember;
			this.grid = grid;
			this.headerText = headerText;
		}

		#region ITemplate Members

		public void InstantiateIn(Control container)
		{
			/*
			NSLabel headerLabel = new headerLabel();
			headerLabel.Text = headerText;
			*/

			string dmember = dataMember.Replace('.', '_');
			ColumnSelCheckBox chkUseInSearch = new ColumnSelCheckBox();
			//chkUseInSearch.CssClass = grid.HeaderStyle.CssClass;
			chkUseInSearch.ID = dmember + "_chkSearch";
			chkUseInSearch.Text = headerText;
			container.Controls.Add(chkUseInSearch);

			NSExpandable searchBox = new NSExpandable();
			searchBox.ID = dmember + "_Exp";
			container.Controls.Add(searchBox);
			NSMultiBox multiBox = new NSMultiBox();
			multiBox.CssClass = grid.getValidCss(grid.CssClassSearchBoxes, NSDataGrid.CssClassSearchBoxesAll);
			multiBox.ID = dmember + "_MB";
			searchBox.ID = dmember + "mbSrch";
			multiBox.DataSourceObject = grid.SearchDataSourceObject;
			multiBox.DataMemberName = dataMember;
			chkUseInSearch.parentGrid = grid;
			chkUseInSearch.DataSourceObject = grid.SearchDataSourceObject;
			chkUseInSearch.DataMemberName = dataMember;
			searchBox.Controls.Add(multiBox);
			searchBox.controllingCheckBoxCtl = chkUseInSearch;
		}

		#endregion

	}
}
