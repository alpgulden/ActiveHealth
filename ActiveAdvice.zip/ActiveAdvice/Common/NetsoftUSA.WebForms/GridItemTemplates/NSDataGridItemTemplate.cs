using System;
using System.Web.UI.WebControls ;
using System.Web;
using System.Web.UI;
using System.Data;
using NetsoftUSA.DataLayer;
using System.Diagnostics;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Generic item template for displaying formatted data component
	/// items.
	/// </summary>
	public class NSDataGridItemTemplate :ITemplate
	{
		#region Private members
		private string dataMember;		// which field to display
		private bool editMode;			// display NSTextBox for edit mode, and NSLabel for display mode
		private NSDataGrid grid; 
		#endregion

		public NSDataGridItemTemplate(string dataMember, NSDataGrid grid, bool editMode)
		{
			this.dataMember = dataMember;
			this.grid = grid;
			this.editMode = editMode;
		}

		#region ITemplate Members

		public void InstantiateIn(Control container)
		{
			//if (false)//true) //editMode)	// Create NSTextBox
			if (editMode)	// Create NSTextBox
			{
				NSMultiBox mb = new NSMultiBox();
				//tb.BackColor = System.Drawing.Color.Transparent; 
				mb.DataSourceObject = grid.DataSourceObject;
				mb.DataMemberName = dataMember;
				container.Controls.Add(mb);
				
				mb.DataBinding+=new EventHandler(mb_DataBinding);
			}
			else	// Create NSLabel
			{
				NSLabel lb = new NSLabel();
				lb.DataSourceObject = grid.DataSourceObject;
				lb.DataMemberName = dataMember;
				lb.FormatWithValue = false;
				//lb.Width = Unit.Pixel(100);
				container.Controls.Add(lb);
				lb.DataBinding+=new EventHandler(lb_DataBinding);
			}
		}

		#endregion

		private void mb_DataBinding(object sender, EventArgs e)
		{
			NSMultiBox mb = (NSMultiBox)sender;
			TableCell cell = (TableCell)mb.Parent;
			DataGridItem container = (DataGridItem)mb.NamingContainer;
			mb.SetCurrentDataRowView((DataRowView)container.DataItem);
			mb.UpdateData(false);
		}

		private void lb_DataBinding(object sender, EventArgs e)
		{
			NSLabel lb = (NSLabel)sender;
			lb.Width = Unit.Percentage(100);
			DataGridItem container = (DataGridItem)lb.NamingContainer;
			TableCell cell = (TableCell)lb.Parent;
			//cell.Wrap = false;
			lb.SetCurrentDataRowView((DataRowView)container.DataItem);
			lb.UpdateData(false);
			if (lb.Text == "")
				Debug.WriteLine("lb.text = ''");
		}
	}
}
