using System;
using System.Web.UI.WebControls ;
using System.Web;
using System.Web.UI;
using System.Diagnostics;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NSDataGrid item template used for selection checkboxes.
	/// </summary>
	public class NSGridSelectItemTemplate : ITemplate
	{
		private NSDataGrid ownerGrid;
		public NSGridSelectItemTemplate(NSDataGrid ownerGrid)
		{
			this.ownerGrid = ownerGrid;
		}
		#region ITemplate Members

		public void InstantiateIn(Control container)
		{
			// Create a checkbox control for record selection
			CheckBox cb = new CheckBox();
			container.Controls.Add(cb);
		}

		#endregion
	}
}
