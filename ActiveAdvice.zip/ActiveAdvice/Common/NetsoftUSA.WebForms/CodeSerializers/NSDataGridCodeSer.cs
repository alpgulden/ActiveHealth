using System;
using System.CodeDom;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.ComponentModel.Design.Serialization;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// This class is used by the VS.NET when generating design time code
	/// for the NSDataGrid control.
	/// </summary>
	internal class NSDataGridCodeSer : CodeDomSerializer
	{
		public NSDataGridCodeSer() : base()
		{
		}

		public override object Deserialize(IDesignerSerializationManager manager, object codeObject)
		{
			// Get the base class serializer.
			CodeDomSerializer baseClassSerializer = (CodeDomSerializer) manager.GetSerializer(typeof(NSTextBox).BaseType, typeof(CodeDomSerializer));
			// Default functionality.
			return baseClassSerializer.Deserialize(manager, codeObject);
		}

		public override object Serialize(IDesignerSerializationManager manager, object value)
		{
			// Get the base class serializer.
			CodeDomSerializer baseClassSerializer = (CodeDomSerializer) manager.GetSerializer(typeof(NSTextBox).BaseType, typeof(CodeDomSerializer));
			object codeObject = baseClassSerializer.Serialize(manager, value);
			CodeStatementCollection statements = codeObject as CodeStatementCollection;
			if (statements != null)
			{
				string name = manager.GetName(value);
				NSDataGrid dataGrid = value as NSDataGrid;
				if (dataGrid.DataSourceName != null)
					if (dataGrid.DataSourceName.Length > 0)
					{
						// create 'dataGrid.DataSourceObject = DataSourceName'   assignment statement
						CodeExpression left = new CodeSnippetExpression(name + ".DataSourceObject");
						CodeExpression right = new CodeSnippetExpression(dataGrid.DataSourceName);
						CodeAssignStatement assign = new CodeAssignStatement(left, right);
						statements.Add(assign);
					}

				if (dataGrid.SearchDataSourceName != null)
					if (dataGrid.SearchDataSourceName.Length > 0)
					{
						CodeExpression left = new CodeSnippetExpression(name + ".SearchDataSourceObject");
						CodeExpression right = new CodeSnippetExpression(dataGrid.SearchDataSourceName);
						CodeAssignStatement assign = new CodeAssignStatement(left, right);
						statements.Add(assign);

					}
			}
			return codeObject;
		}

	}
}
