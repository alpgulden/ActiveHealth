using System;
using System.CodeDom;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.ComponentModel.Design.Serialization;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// This class is used by the VS.NET when generating design time code
	/// for the NSMultiBox control.
	/// </summary>
	internal class NSMultiBoxCodeSer : CodeDomSerializer
	{
		public NSMultiBoxCodeSer() : base()
		{
		}

		public override object Deserialize(IDesignerSerializationManager manager, object codeObject)
		{
			// Get the base class serializer.
			CodeDomSerializer baseClassSerializer = (CodeDomSerializer) manager.GetSerializer(typeof(NSTextBox).BaseType, typeof(CodeDomSerializer));
			// Default functionality.
			return baseClassSerializer.Deserialize(manager, codeObject);
		}

		public override object Serialize(IDesignerSerializationManager manager, object value)
		{
			// Get the base class serializer.
			CodeDomSerializer baseClassSerializer = (CodeDomSerializer) manager.GetSerializer(typeof(NSTextBox).BaseType, typeof(CodeDomSerializer));
			object codeObject = baseClassSerializer.Serialize(manager, value);
			CodeStatementCollection statements = codeObject as CodeStatementCollection;
			if (statements != null)
			{
				string name = manager.GetName(value);
				NSMultiBox mb = value as NSMultiBox;
				if (mb.DataSourceName != null)
					if (mb.DataSourceName.Length > 0)
					{
						// create 'tb.DataSourceObject = DataSourceName'   assignment statement
						CodeExpression left = new CodeSnippetExpression(name + ".DataSourceObject");
						CodeExpression right = new CodeSnippetExpression(mb.DataSourceName);
						CodeAssignStatement assign = new CodeAssignStatement(left, right);
						statements.Add(assign);
					}
			}
			return codeObject;
		}
	}
}
