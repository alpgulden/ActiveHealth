using System;
using System.Windows.Forms.Design;
using System.Drawing.Design;
using System.Web.UI;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for LangMessageEditor.
	/// </summary>
	public class LangMessageEditor : UITypeEditor
	{
		private IWindowsFormsEditorService edSvc;

		public LangMessageEditor()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public override object EditValue(System.ComponentModel.ITypeDescriptorContext context, IServiceProvider provider, object value)
		{
			edSvc = (IWindowsFormsEditorService)provider.GetService(typeof(IWindowsFormsEditorService));

			string msg = Convert.ToString(value);
			Control ctl = (Control)context.Instance;
			string assemblyName = null, className = null;
			System.ComponentModel.Design.IDesignerHost hst = context.Container as System.ComponentModel.Design.IDesignerHost;
			string cn = hst.RootComponentClassName;
			Type t = null;
			try
			{
				t = Type.GetType(cn);
			}
			catch
			{
			}
			if (t != null && MainLanguageClassAttribute.GetMainLanguageClassFromType(t, ref assemblyName, ref className))
			{
				LangMessageBuilder langMessageBuilder = new LangMessageBuilder(msg, className + "," + assemblyName);
				langMessageBuilder.DropDownClosed +=new NetsoftUSA.WebForms.LangMessageBuilder.DropDownClosedHandler(langMessageBuilder_DropDownClosed);
				edSvc.DropDownControl(langMessageBuilder);
				if (langMessageBuilder.Accepted)
				{
					context.OnComponentChanged();
					return langMessageBuilder.Msg;
				}
				else
					return value;
			}	
			else
			{
				return value;
			}
			
		}

		public override UITypeEditorEditStyle GetEditStyle(System.ComponentModel.ITypeDescriptorContext context)
		{
			return UITypeEditorEditStyle.DropDown;
		}

		private void langMessageBuilder_DropDownClosed(object sender, EventArgs e)
		{
			if (edSvc != null)
				edSvc.CloseDropDown();
		}
	}
}
