using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using NetsoftUSA.DataLayer;
using System.Reflection;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for LangMessageBuilder.
	/// </summary>
	internal class LangMessageBuilder : System.Windows.Forms.UserControl
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.ListBox lsMsgs;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtMsg;
		private System.Windows.Forms.TextBox txtFilter;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.LinkLabel linkClose;
		private string langClassName = null;
		private bool accepted = false;

		#region Events
		public delegate void DropDownClosedHandler(object sender, EventArgs e);
		public event DropDownClosedHandler DropDownClosed;
		#endregion

		public LangMessageBuilder()
		{
		}

		public LangMessageBuilder(string msg, string langClassName)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.txtMsg.Text = msg;
			this.langClassName = langClassName;
			FillMessages();
			int i1 = this.txtMsg.Text.IndexOf("@");
			if (i1 >= 0)
			{
				int i2 = this.txtMsg.Text.IndexOf("@", i1 + 1);
				if (i2 >= 0)
				{
					this.txtMsg.SelectionStart = i1;
					this.txtMsg.SelectionLength = i2 - i1 + 1;
					string msgID = this.txtMsg.SelectedText.Trim('@');
					int msgIndex = lsMsgs.FindStringExact(msgID);
					if (msgIndex >= 0)
						lsMsgs.SelectedIndex = msgIndex;
				}
			}

		}

		private void OnDropDownClosed()
		{
			if (DropDownClosed != null)
				DropDownClosed(this, new EventArgs());
		}

		private void FillMessages()
		{
			lsMsgs.Items.Clear();
			if (langClassName == null)
				return;

			Type t = null;
			
			try
			{
				t = Type.GetType(langClassName);
			}
			catch
			{}

			if (t == null)
				return;

			string filter = txtFilter.Text.ToUpper();
			System.Reflection.MemberInfo[] members = t.FindMembers(
				MemberTypes.Field | MemberTypes.Property,
				BindingFlags.Public | BindingFlags.Instance, null, null);
			for (int i = 0; i < members.Length; i++)
			{
				MemberInfo mi = members[i];
				if (mi.MemberType == MemberTypes.Field || mi.MemberType == MemberTypes.Property)
					if (mi.Name != "langID" && mi.Name != "LangID")
					{
						bool bAdd = false;
						if (filter == "")
							bAdd = true;
						else
							bAdd = mi.Name.ToUpper().IndexOf(filter) >= 0;
					
						if (bAdd)
							lsMsgs.Items.Add(mi.Name);
					}
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtMsg = new System.Windows.Forms.TextBox();
			this.lsMsgs = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txtFilter = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.linkClose = new System.Windows.Forms.LinkLabel();
			this.SuspendLayout();
			// 
			// txtMsg
			// 
			this.txtMsg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtMsg.Location = new System.Drawing.Point(4, 16);
			this.txtMsg.Name = "txtMsg";
			this.txtMsg.Size = new System.Drawing.Size(288, 20);
			this.txtMsg.TabIndex = 0;
			this.txtMsg.Text = "";
			this.txtMsg.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMsg_KeyDown);
			this.txtMsg.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMsg_KeyPress);
			this.txtMsg.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtMsg_KeyUp);
			// 
			// lsMsgs
			// 
			this.lsMsgs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lsMsgs.IntegralHeight = false;
			this.lsMsgs.Location = new System.Drawing.Point(4, 56);
			this.lsMsgs.Name = "lsMsgs";
			this.lsMsgs.Size = new System.Drawing.Size(288, 192);
			this.lsMsgs.Sorted = true;
			this.lsMsgs.TabIndex = 2;
			this.lsMsgs.DoubleClick += new System.EventHandler(this.lsMsgs_DoubleClick);
			this.lsMsgs.SelectedIndexChanged += new System.EventHandler(this.lsMsgs_SelectedIndexChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(2, 41);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(176, 23);
			this.label1.TabIndex = 3;
			this.label1.Text = "Messages in Language Class:";
			// 
			// txtFilter
			// 
			this.txtFilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtFilter.Location = new System.Drawing.Point(30, 250);
			this.txtFilter.Name = "txtFilter";
			this.txtFilter.Size = new System.Drawing.Size(264, 20);
			this.txtFilter.TabIndex = 4;
			this.txtFilter.Text = "";
			this.txtFilter.TextChanged += new System.EventHandler(this.txtFilter_TextChanged);
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label2.Location = new System.Drawing.Point(0, 252);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(40, 23);
			this.label2.TabIndex = 5;
			this.label2.Text = "Filter:";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(3, 1);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(176, 23);
			this.label3.TabIndex = 6;
			this.label3.Text = "Enter a message with MsgID\'s:";
			// 
			// linkClose
			// 
			this.linkClose.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
			this.linkClose.Location = new System.Drawing.Point(262, 1);
			this.linkClose.Name = "linkClose";
			this.linkClose.Size = new System.Drawing.Size(40, 16);
			this.linkClose.TabIndex = 8;
			this.linkClose.TabStop = true;
			this.linkClose.Text = "Close";
			this.linkClose.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkClose_LinkClicked);
			// 
			// LangMessageBuilder
			// 
			this.BackColor = System.Drawing.SystemColors.ControlLight;
			this.Controls.Add(this.txtMsg);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtFilter);
			this.Controls.Add(this.lsMsgs);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.linkClose);
			this.Name = "LangMessageBuilder";
			this.Size = new System.Drawing.Size(296, 272);
			this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMsg_KeyPress);
			this.Load += new System.EventHandler(this.LangMessageBuilder_Load);
			this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtMsg_KeyUp);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMsg_KeyDown);
			this.ResumeLayout(false);

		}
		#endregion

		private void LangMessageBuilder_Load(object sender, System.EventArgs e)
		{
		}

		private void InsertMsgID()
		{
			string msgID = (string)lsMsgs.SelectedItem;
			if (msgID == null)
				return;
			msgID = "@" + msgID + "@";
			int start = txtMsg.SelectionStart;
			string s = txtMsg.Text.Remove(txtMsg.SelectionStart, txtMsg.SelectionLength);
			txtMsg.Text = s.Insert(txtMsg.SelectionStart, msgID);
			txtMsg.SelectionStart = start;
			txtMsg.SelectionLength = msgID.Length;
		}

		private void lsMsgs_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			InsertMsgID();
		}

		private void txtFilter_TextChanged(object sender, System.EventArgs e)
		{
			FillMessages();
		}

		private void lsMsgs_DoubleClick(object sender, System.EventArgs e)
		{
			this.accepted = true;
			OnDropDownClosed();
		}

		private void linkClose_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			OnDropDownClosed();
		}

		private void txtMsg_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			System.Diagnostics.Debug.WriteLine(e.KeyChar);
			if (e.KeyChar == (char)13)
			{
				this.accepted = true;

				OnDropDownClosed();
			}
		}

		private void txtMsg_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
		}

		private void txtMsg_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			/*System.Diagnostics.Debug.WriteLine(e.KeyCode);
			if (e.KeyCode == System.Windows.Forms.Keys.Enter)
			{
				this.accepted = true;

				//OnDropDownClosed();
			}*/
		}


		public string Msg
		{
			get { return txtMsg.Text; }
			set { txtMsg.Text = value; }
		}

		public bool Accepted
		{
			get { return accepted; }
		}
	}
}
