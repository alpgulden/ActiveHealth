using System;
using System.Web.UI;
using System.ComponentModel;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for PageScroller.
	/// </summary>
	public class PageScroller: System.Web.UI.HtmlControls.HtmlInputHidden, IPostBackDataHandler	
	{
		private string scrollToControlClientID = null;
		
		[DefaultValue(false)]
		public bool AutoScroll
		{
			get 
			{
				if (ViewState["AutoScroll"] == null)
				{
					ViewState["AutoScroll"] = false;
				}
				return (bool)ViewState["AutoScroll"];
			}
			set {ViewState["AutoScroll"] = value;}
		}

		[DefaultValue(0)]
		public int VPos
		{
			get 
			{
				if(ViewState["VPos"]==null)
				{
					ViewState["VPos"] = 0;
				}
				return (int)ViewState["VPos"];
			}
			set { ViewState["VPos"] = value; }
		}

		[DefaultValue(0)]
		public int HPos
		{
			get
			{
				if(ViewState["HPos"]==null)
				{
					ViewState["HPos"] = 0;
				}
				return (int)ViewState["HPos"];
			}
			set { ViewState["HPos"] = value; }
		}
    


		public bool LoadPostData(String postDataKey, System.Collections.Specialized.NameValueCollection values) 
		{
			if (AutoScroll)
			{
				bool _returnV;
				bool _returnH;

				if (values[this.UniqueID] == null)
					return false;

				string Val = values[this.UniqueID].Trim();
				string[] _Val = Val.Split(new char[] {'&'});
				if(_Val.Length > 1)
				{
					if(!HPos.ToString().Equals(_Val[0])  && _Val[0].Trim()!=null )
					{
						HPos= Int32.Parse(_Val[0]);
						_returnH = true;  
					}
					else _returnH = false;

					if(!VPos.ToString().Equals(_Val[1])  && _Val[1].Trim()!=null )
					{
						VPos= Int32.Parse(_Val[1]);
						_returnV = true;  
					}
					else _returnV=false;  
				}
				else
				{
					HPos = 0;
					VPos = 0;
					return false;
				}

				if(_returnV || _returnH) return false; 

				else return false;    
			}
			return false;
		}
    

		public void ScrollToControl(Control ctrl)
		{
			scrollToControlClientID = ctrl.ClientID;
		}



		protected override void OnPreRender(EventArgs e) 
		{   
    
			string saveScrollPosition = 
				@"
			<script language='Javascript'>
		
var isDHTML = 0;
var isID = 0;
var isAll = 0;
var isLayers = 0;

if(document.getElementById)
{
	isID = 1;
	isDHTML = 1;
}
else
{
	if(document.all)
	{
		isAll = 1;
		isDHTML = 1;
	}
	else
	{
		browserVersion = parseInt(navigator.appVersion);
		if((navigator.appName.indexOf('Netscape') != -1) && (browserVersion == 4))
		{
			isLayers = 1;
			isDHTML = 1;
		}
	}
}

function findDOM(objectID)
{
	if (isID)
	{
		return (document.getElementById(objectID));
	}
	else
	{
		if (isAll)
		{
			return (document.all[objectID]);
		}
		else
		{
			if (isLayers)
			{
				return (document.layers[objectID]);
			}
		}
	}

} 

Navig = navigator.appName

if(Navig == 'Netscape') {
	document.body = new Object;
	setInterval('testScroll()', 50);
}


function saveScroll() 
{
		if (findDOM('" + this.ClientID + @"'))
		{
			if (document.all)
			{
				findDOM('" + this.ClientID + @"').value = document.body.scrollLeft + '&' + document.body.scrollTop;
			}
			else
			{
				findDOM('" + this.ClientID + @"').value = window.pageYOffset + '&' + window.pageXOffset;
			}
		}

}

";

			if (AutoScroll)
			{
				saveScrollPosition +=@" window.onscroll = saveScroll; ";
			}
		

saveScrollPosition +=@"
</script>
			";

			if((AutoScroll || scrollToControlClientID != null) && !Page.IsClientScriptBlockRegistered("saveScrollPosition"))
			{
				Page.RegisterClientScriptBlock("saveScrollPosition", saveScrollPosition);
			}


			string gotoScrollPosition = @"
<script language='javascript'>
var targetX, targetY;
";
			if (scrollToControlClientID != null)
			{
				gotoScrollPosition +=@"targetY = findDOM('" + scrollToControlClientID + @"').style.top; targetX = 0; alert(targetY); index = 0; a = 0 / index;";
			}
			else
			{
				gotoScrollPosition +=@"targetY = " + this.HPos + @";
				targetX = "+ this.VPos + @";";
			}

gotoScrollPosition += @"

window.scrollTo(targetY, targetX);

			</script>";

			if((AutoScroll || scrollToControlClientID != null) && !Page.IsStartupScriptRegistered("gotoScrollPosition"))
			{
				Page.RegisterStartupScript("gotoScrollPosition", gotoScrollPosition);
			}
		}    
	}

}
