using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Data;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	public class NavigatorButtonEventArgs : EventArgs
	{
		public bool cancelDefault = false;
	}

	/// <summary>
	/// Control that facilitates basic record navigation buttons
	/// that control the bound DataSource and DataMember.
	/// </summary>
	[ToolboxData("<{0}:Navigator runat=server></{0}:Navigator>"),
		Designer(typeof(NetsoftUSA.WebForms.NavigatorDesigner)),
		System.ComponentModel.Design.Serialization.DesignerSerializer(
			typeof(NetsoftUSA.WebForms.NavigatorCodeSer), 
			typeof(System.ComponentModel.Design.Serialization.CodeDomSerializer))
	]
	public class Navigator : System.Web.UI.WebControls.WebControl, INamingContainer
	{
		#region Static members

		public static string CssClassButtonAll = "";

		#endregion

		public delegate void LoadEventHandler(object sender, NavigatorButtonEventArgs e);
		public delegate void SearchEventHandler(object sender, NavigatorButtonEventArgs e);
		public delegate void DeleteRecordEventHandler(object sender, NavigatorButtonEventArgs e);
		public delegate void NewRecordEventHandler(object sender, NavigatorButtonEventArgs e);
		public delegate void AfterNewRecordEventHandler(object sender, EventArgs e);
	
		#region Private Members
		private string dataSourceName;	// actual source dataset name
		private NetsoftUSA.DataLayer.DCBase dataSource = null;	// actual source data component
		private string dataMember;		// in the form of Table.Field

		private string cssClassButton;

		#region Events
		public event LoadEventHandler LoadEvent;
		public event SearchEventHandler SearchEvent;
		public event DeleteRecordEventHandler DeleteRecordEvent;
		public event NewRecordEventHandler NewRecordEvent;
		public event AfterNewRecordEventHandler AfterNewRecordEvent;
		#endregion

		private Button butFirst;
		private Button butPrevious;
		private Button butNext;
		private Button butLast;
		private Button butLoad;
		private Button butSearch;
		private Button butSave;
		private Button butNew;
		private Button butDelete;
		private Button butCancel;
		private HtmlInputButton butClose;

		private bool butFirstVisible = true;
		private bool butPreviousVisible = true;
		private bool butNextVisible = true;
		private bool butLastVisible = true;
		private bool butLoadVisible = true;
		private bool butSearchVisible = true;
		private bool butSaveVisible = true;
		private bool butNewVisible = true;
		private bool butDeleteVisible = true;
		private bool butCancelVisible = true;
		private bool butCloseVisible = true;

		private DCBinding binding;
		/// <summary>
		/// This creates the necessary binding to the dataSource-dataMember.
		/// All navigation is performed through this binding.
		/// If there's a binding object already created, it'll be reused.
		/// </summary>
		private void addBinding()
		{
			try
			{
				binding = ((BasePage)Page).BindingManager.EnsureBinding(dataSource, dataMember);
			}
			catch(Exception)
			{
			}
		}

		private string getValidCssClassButton()
		{
			if (this.cssClassButton != null)
				if (this.cssClassButton != "")
					return this.cssClassButton;
			return Navigator.CssClassButtonAll;
		}

		#endregion

		#region Public functions

		[DefaultValue(true)]
		public bool FirstButton
		{
			get { return butFirstVisible; }
			set { butFirstVisible = value; }
		}
		
		[DefaultValue(true)]
		public bool PreviousButton
		{
			get { return butPreviousVisible; }
			set { butPreviousVisible = value; }
		}

		[DefaultValue(true)]
		public bool NextButton
		{
			get { return butNextVisible; }
			set { butNextVisible = value; }
		}

		[DefaultValue(true)]
		public bool LastButton
		{
			get { return butLastVisible; }
			set { butLastVisible = value; }
		}

		[DefaultValue(true)]
		public bool LoadButton
		{
			get { return butLoadVisible; }
			set { butLoadVisible = value; }
		}

		[DefaultValue(true)]
		public bool SearchButton
		{
			get { return butSearchVisible; }
			set { butSearchVisible = value; }
		}

		[DefaultValue(true)]
		public bool SaveButton
		{
			get { return butSaveVisible; }
			set { butSaveVisible = value; }
		}

		[DefaultValue(true)]
		public bool NewButton
		{
			get { return butNewVisible; }
			set { butNewVisible = value; }
		}

		[DefaultValue(true)]
		public bool DeleteButton
		{
			get { return butDeleteVisible; }
			set { butDeleteVisible = value; }
		}

		[DefaultValue(true)]
		public bool CancelButton
		{
			get { return butCancelVisible; }
			set { butCancelVisible = value; }
		}

		[DefaultValue(true)]
		public bool CloseButton
		{
			get { return butCloseVisible; }
			set { butCloseVisible = value; }
		}

		/// <summary>
		/// Data source object name to be used for navigation.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataSourceConverter))
		]
		public string DataSourceName
		{
			get
			{
				return dataSourceName;
			}
			set
			{
				dataSourceName = value;

				//!!! add code to set dataSource object
			}
		}

		/// <summary>
		/// Data source object to be used
		/// </summary>
		[Browsable(false)]
		public NetsoftUSA.DataLayer.DCBase DataSourceObject
		{
			get
			{
				return dataSource;
			}
			set
			{
				dataSource = value;		// code serializer generated code calls this.

			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataTableOnlyConverter))
		]
		public string DataMemberName
		{
			get
			{
				return dataMember;
			}
			set
			{
				dataMember = value;
			}
		}

		protected override void CreateChildControls()
		{
			CreateChildControls(this.Controls);
		}

		/// <summary>
		/// Called by the Navigator designer to reuse the html output for the control.
		/// </summary>
		/// <param name="controls"></param>
		internal void CreateChildControls(ControlCollection controls)
		{	
			addBinding();

			Table tbl = new Table();
			tbl.Width = this.Width;
			//tbl.Height = this.Height;
			controls.Add(tbl);

			TableRow row = new TableRow();
			tbl.Rows.Add(row);
			TableCell cell;
			Button but;

			cell = new TableCell();
			row.Cells.Add(cell);
			but = new Button();
			but.CssClass = getValidCssClassButton();
			cell.Controls.Add(but);
			but.Text = "|<<";
			butFirst = but;
			butFirst.Click +=new EventHandler(butFirst_Click);

			cell = new TableCell();
			row.Cells.Add(cell);
			but = new Button();
			but.CssClass = getValidCssClassButton();
			cell.Controls.Add(but);
			but.Text = "<<";
			butPrevious = but;
			butPrevious.Click +=new EventHandler(butPrevious_Click);

			cell = new TableCell();
			row.Cells.Add(cell);
			but = new Button();
			but.CssClass = getValidCssClassButton();
			cell.Controls.Add(but);
			but.Text = ">>";
			butNext = but;
			butNext.Click +=new EventHandler(butNext_Click);

			cell = new TableCell();
			row.Cells.Add(cell);
			but = new Button();
			but.CssClass = getValidCssClassButton();
			cell.Controls.Add(but);
			but.Text = ">>|";
			butLast = but;
			butLast.Click +=new EventHandler(butLast_Click);

			cell = new TableCell();
			row.Cells.Add(cell);
			but = new Button();
			but.CssClass = getValidCssClassButton();
			cell.Controls.Add(but);
			but.Text = "Load";
			butLoad = but;
			butLoad.Click +=new EventHandler(butLoad_Click);

			cell = new TableCell();
			row.Cells.Add(cell);
			but = new Button();
			but.CssClass = getValidCssClassButton();
			cell.Controls.Add(but);
			but.Text = "Search";
			butSearch = but;
			butSearch.Click +=new EventHandler(butSearch_Click);

			cell = new TableCell();
			row.Cells.Add(cell);
			but = new Button();
			but.CssClass = getValidCssClassButton();
			cell.Controls.Add(but);
			but.Text = "Save";
			butSave = but;
			butSave.Click +=new EventHandler(butSave_Click);

			cell = new TableCell();
			row.Cells.Add(cell);
			but = new Button();
			but.CssClass = getValidCssClassButton();
			cell.Controls.Add(but);
			but.Text = "New";
			butNew = but;
			butNew.Click +=new EventHandler(butNew_Click);

			cell = new TableCell();
			row.Cells.Add(cell);
			but = new Button();
			but.CssClass = getValidCssClassButton();
			cell.Controls.Add(but);
			but.Text = "Delete";
			butDelete = but;
			butDelete.Click +=new EventHandler(butDelete_Click);

			cell = new TableCell();
			row.Cells.Add(cell);
			but = new Button();
			but.CssClass = getValidCssClassButton();
			cell.Controls.Add(but);
			but.Text = "Cancel";
			butCancel = but;
			butCancel.Click +=new EventHandler(butCancel_Click);

			cell = new TableCell();
			row.Cells.Add(cell);

			cell = new TableCell();
			//cell.Width = Unit.Percentage(100);
			cell.HorizontalAlign = HorizontalAlign.Right;
			cell.BorderWidth = 1;
			row.Cells.Add(cell);
			butClose = new HtmlInputButton();
			butClose.Attributes["class"] = getValidCssClassButton();
			cell.Controls.Add(butClose);
			butClose.Value = "Close";
			butClose.Attributes["onclick"] = "window.close()";

			this.Height = tbl.Height;
		}
			
		/// <summary>
		/// May be called from the WebForm to control the navigator current record position.
		/// </summary>
		/// <param name="navigate"></param>
		public void Navigate(DCTableNavigate navigate)
		{
			binding.Navigate(navigate);
		}

		/// <summary>
		/// Load the data from database
		/// </summary>
		public void LoadData()
		{
			if (LoadEvent != null)
			{
				NavigatorButtonEventArgs e = new NavigatorButtonEventArgs();
				LoadEvent(this, e);
				if (e.cancelDefault)
					return;
			}
			binding.LoadData();
		}

		/// <summary>
		/// Search is handled by the client page.
		/// There's no default implementation.
		/// </summary>
		public void Search()
		{
			if (SearchEvent != null)
			{
				NavigatorButtonEventArgs e = new NavigatorButtonEventArgs();
				SearchEvent(this, e);
				if (e.cancelDefault)
					return;
			}			 
			// delegate to binding.
			binding.Search();
		}

		/// <summary>
		/// Save the current UI content into DataComponent and update database
		/// </summary>
		public void SaveData()
		{
			binding.SaveData();
		}

		public void NewRecord()
		{
			if (NewRecordEvent != null)
			{
				NavigatorButtonEventArgs e = new NavigatorButtonEventArgs();
				NewRecordEvent(this, e);
				if (e.cancelDefault)
					return;
			}
			binding.NewRecord();
			if (AfterNewRecordEvent != null)
			{
				EventArgs e = new EventArgs();
				AfterNewRecordEvent(this, e);
			}
		}

		public void CancelChanges()
		{
			binding.CancelChanges();
		}

		[Category("Appearance")]
		public string CssClassButton
		{
			get { return cssClassButton; }
			set { cssClassButton = value; }
		}

		public virtual void DeleteRecord()
		{
			if (DeleteRecordEvent != null)
			{
				NavigatorButtonEventArgs e = new NavigatorButtonEventArgs();
				DeleteRecordEvent(this, e);
				if (e.cancelDefault)
					return;
			}
			binding.DeleteRecord();
		}

		private void ArrangeButtonStates()
		{
			butFirst.Visible = butFirstVisible;
			butPrevious.Visible = butPreviousVisible;
			butNext.Visible = butNextVisible;
			butLast.Visible = butLastVisible;
			butLoad.Visible = butLoadVisible;
			butSave.Visible = butSaveVisible;
			butNew.Visible = butNewVisible;
			butDelete.Visible = butDeleteVisible;
			butSearch.Visible = butSearchVisible;
			butClose.Visible = butCloseVisible;

			butFirst.Enabled = true;
			butPrevious.Enabled = true;
			butNext.Enabled = true;
			butLast.Enabled = true;
			butLoad.Enabled = true;
			butSave.Enabled = true;
			butNew.Enabled = true;
			butDelete.Enabled = true;

			DataTable dataTable = dataSource.GetTable(dataMember);
			int rowPos = dataSource.GetTableRowPos(dataMember);
			int rowCount = dataTable.DefaultView.Count;

			if (rowCount == 0)
			{
				butFirst.Enabled = false;
				butPrevious.Enabled = false;
				butNext.Enabled = false;
				butLast.Enabled = false;
				butDelete.Enabled = false;
			}
			
			if (rowPos == 0)
			{
				butFirst.Enabled = false;
				butPrevious.Enabled = false;
			}

			if (rowPos == rowCount - 1)
			{
				butLast.Enabled = false;
				butNext.Enabled = false;
			}
		}

		#endregion

		private void butFirst_Click(object sender, EventArgs e)
		{
			Navigate(DCTableNavigate.First);
		}

		private void butPrevious_Click(object sender, EventArgs e)
		{
			Navigate(DCTableNavigate.Previous);
		}

		private void butNext_Click(object sender, EventArgs e)
		{
			Navigate(DCTableNavigate.Next);
		}

		private void butLast_Click(object sender, EventArgs e)
		{
			Navigate(DCTableNavigate.Last);
		}

		private void butLoad_Click(object sender, EventArgs e)
		{
			LoadData();
			//Navigate(DCTableNavigate.First);
		}

		private void butSave_Click(object sender, EventArgs e)
		{
			SaveData();
			//Navigate(DCTableNavigate.First);
		}

		private void butNew_Click(object sender, EventArgs e)
		{
			NewRecord();
		}

		private void butDelete_Click(object sender, EventArgs e)
		{
			DeleteRecord();
		}

		private void butCancel_Click(object sender, EventArgs e)
		{
			CancelChanges();
		}

		protected override void OnPreRender(EventArgs e)
		{
			ArrangeButtonStates();
			base.OnPreRender (e);
		}

		private void butSearch_Click(object sender, EventArgs e)
		{
			Search();
		}
	}
}
