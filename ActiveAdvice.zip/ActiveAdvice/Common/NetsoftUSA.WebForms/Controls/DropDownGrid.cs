using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using NetsoftUSA.WebForms;
using System.Data;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for DropDownGrid.
	/// </summary>
	[ToolboxData("<{0}:DropDownGrid runat=server></{0}:DropDownGrid>")]
	public class DropDownGrid : BaseDropDown
	{
		//NSDataGrid grid;
		protected override void CreateChildControls()
		{
			/*
			grid = new NSDataGrid();
			grid.ID = this.ID + "_DropDownGrid";
			grid.SelectButton = false;
			grid.SelectCheckBoxes = false;
			grid.PickTargetInThisWindow = true;
			grid.PickButton = true;
			grid.PickValueField = "Value";
			grid.PickFormattedField = "@Value-@Text";
			grid.SetPickTargetID(pickTarget);
			Controls.Add(grid);*/
		}


		public override void FillCombo()
		{/*
			//string selVal = this.SelectedValue;
			if (rowView != null)
			{
				DataSet ds = dataSource.CreateDataSetForPossibleValues(rowView, dataField);
				DCGeneric dc = new DCGeneric();
				dc.SetMainDataSet(ds);
				grid.DataSourceObject = dc;
				grid.DataMemberName = "Main";
				
				grid.BindGrid();
			}*/
		}

	}
}
