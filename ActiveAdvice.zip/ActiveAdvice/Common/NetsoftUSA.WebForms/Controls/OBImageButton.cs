using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Reflection;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NetsoftUSA.WebForms.IObjectBoundControl implementer for a image button type
	/// UI control.  Validation and Formatting functionalities are abstracted 
	/// from this control.
	/// </summary>
	[DefaultProperty("ImageUrl"), 
		ToolboxData("<{0}:OBImageButton runat=server></{0}:OBImageButton>")
	]
	public class OBImageButton: System.Web.UI.WebControls.ImageButton, IObjectBoundControl //, INamingContainer
	{
		#region private members
		private string sourceClassName;	// source object's class type to be used in design time
		private object sourceObject = null;	// actual source object
		private string sourceMember;		// source member of the source object
		private bool disableBinding = false;	// disable data binding to NSDataComps

		private string errorDisplay;	// if this is not null, it will be displayed when rendering
		private string errorLongDisplay;	// if this is not null, it will be displayed in tooltip when rendering
		//private NSLabel errorLabel;

		private string altTextToTranslate;	// the text to be translated and set to text
		private string urlFormatString = "{0}";		// the string to format the url

		private bool objectBound = false;
		#endregion

		#region Constructors

		public OBImageButton() : base()
		{
			/*errorLabel = new NSLabel();
			errorLabel.ForeColor = System.Drawing.Color.Red;
			*/
		}
		#endregion

		#region IObjectBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
			if (disableBinding)
				return;

			errorDisplay = "";
			errorLongDisplay = "";
			if (sourceObject != null && sourceMember != null)
			{
				if (!Save)
				{	
					// data to object
					try
					{
						string s = ReflectionHelper.GetMemberValueAsString(sourceObject, sourceMember);
						this.ImageUrl = GetFormattedUrl(s);
					}
					catch(Exception ex)
					{
						errorDisplay = "???"; //ex.Message;
						errorLongDisplay = ex.Message;
						((BasePage)Page).RaisePageException(ex);
					}
				}
			}
		}

		public object GetSourceObject()
		{
			return sourceObject;
		}

		public string GetSourceObjectMember()
		{
			return sourceMember;
		}

		public void SetSourceObject(object obj)
		{
			SourceObject = obj;
		}

		public void SetSourceObjectMember(string om)
		{
			SourceMemberName = om;
		}

		[Browsable(false)]
		public bool IsReadOnly
		{ 
			get { return true; } 
			set { }
		}

		[Browsable(false)]
		public bool IsEnabled
		{ 
			get { return this.Enabled; } 
			set { this.Enabled = value; }
		}

		#endregion
		
		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
			Browsable(true),
			TypeConverter(typeof(NetsoftUSA.WebForms.SourceClassNamesConverter))
		]
		public string SourceClassName
		{
			get	{ return sourceClassName; }
			set	{ sourceClassName = value; }
		}

		/// <summary>
		/// Source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public object SourceObject
		{
			get	{	return sourceObject;	}
			set	
			{	
				sourceObject = value; 
				// once an object is bound, set it as object bound
				// so that the control won't be disabled
				objectBound = !disableBinding && sourceObject != null && sourceMember != null;
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
			Browsable(true),
			TypeConverter(typeof(NetsoftUSA.DataLayer.ClassMemberConverter))
		]
		public string SourceMemberName
		{
			get	{ return sourceMember; }
			set
			{ 
				sourceMember = value; 
			}
		}


		public Type GetDataType()
		{
			if (sourceObject != null)
				return ReflectionHelper.GetMemberType(sourceObject, sourceMember);
			else
				return ReflectionHelper.GetMemberType(Type.GetType(sourceClassName), sourceMember);
		}

		[DefaultValue(false)]
		public bool DisableBinding
		{
			get
			{
				return disableBinding;
			}
			set
			{
				disableBinding = value;
			}
		}

		[Category("Appearance")]
		[Editor(typeof(LangMessageEditor), typeof(System.Drawing.Design.UITypeEditor))]
		public string AltTextToTranslate
		{
			get	{ return altTextToTranslate; }
			set	
			{ 
				altTextToTranslate = value; 
			}
		}
		[Editor(typeof(LangMessageEditor), typeof(System.Drawing.Design.UITypeEditor))]
		[Category("NetsoftUSA.WebForms Binding")]
		[DefaultValue("{0}")]
		public string UrlFormatString
		{
			get
			{
				return urlFormatString;
			}
			set
			{
				if (value == "" || value == null)
					urlFormatString = "{0}";
				else
					urlFormatString = value;
			}
		}

		private string GetFormattedUrl(string s)
		{
			if (s == null)
				s = "";
			return ((BasePage)this.Page).Language.Translate(true, urlFormatString, s);
		}

		#endregion
	
		protected override void Render(HtmlTextWriter writer)
		{
			base.Render (writer);
			/*
			string oldText = this.AlternateText;
			bool oldEnabled = this.Enabled;
			if (this.Site != null)
				if (this.Site.DesignMode)
				{
					if (!disableBinding && sourceMember != null && sourceMember != "")
					{
						this.Text = "[" + sourceMember + "]";
						base.Render(writer);
						this.Text = oldText;
						return;
					}
					else
					{
						SetTranslatedText();
						base.Render(writer);
						this.Text = oldText;
						return;
					}
				}

			if (objectBound)
			{
				base.Render (writer);
				if (errorDisplay != null)
					if (errorDisplay.Length > 0)
					{
						errorLabel.Text = errorDisplay;

						if (errorLongDisplay != null)
							if (errorLongDisplay.Length > 0)
							{
								errorLabel.ToolTip = errorLongDisplay;
								errorLabel.Font.Underline = true;
							}
						errorLabel.RenderControl(writer);

						this.Text = oldText;
						this.Enabled = oldEnabled;
					}
			}
			else
			{
				//this.Text = ((BasePage)this.Page).Language.Translate(this.textToTranslate);
				//this.Enabled = false;
				base.Render (writer);
			}*/

			
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			errorDisplay = (string)ViewState["err"];
			objectBound = (bool)ViewState["ob"];
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);

			//if (!this.objectBound)
				SetTranslatedText();
		}


		private void SetTranslatedText()
		{
			try
			{
				if (this.altTextToTranslate != null && this.altTextToTranslate != "")
					this.AlternateText = ((BasePage)this.Page).Language.Translate(this.altTextToTranslate);
				else
					this.AlternateText = this.AlternateText;
			}
			catch(Exception ex)
			{
				this.AlternateText = ex.Message;
			}
		}

		protected override object SaveViewState()
		{
			ViewState["err"] = errorDisplay;
			ViewState["ob"] = objectBound;

			return base.SaveViewState ();
		}

	}
}
