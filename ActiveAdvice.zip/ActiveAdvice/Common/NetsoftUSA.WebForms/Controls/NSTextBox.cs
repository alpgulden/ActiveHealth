using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NetsoftUSA.WebForms.IDataBoundControl implementer for a textbox type
	/// UI control.  Validation and Formatting functionalities are abstracted 
	/// from this control.
	/// </summary>
	[DefaultProperty("Text"), 
		ToolboxData("<{0}:NSTextBox runat=server></{0}:NSTextBox>"),
		System.ComponentModel.Design.Serialization.DesignerSerializer(
			typeof(NetsoftUSA.WebForms.NSTextBoxCodeSer), 
			typeof(System.ComponentModel.Design.Serialization.CodeDomSerializer))
	]
	public class NSTextBox : System.Web.UI.WebControls.TextBox, IDataBoundControl, INamingContainer	
	{
		#region private members
		private string dataSourceName;	// actual source dataset name
		private NetsoftUSA.DataLayer.DCBase dataSource = null;	// actual source data component
		private string dataMember;	// in the form of Table.Field
		private string dataTable;	// parsed from dataMember
		private string dataField;	// parsed from dataMember
		private bool disablePK = true;		// disable if the columns is primary key
		private bool usePickPage = true;
		private bool disableBinding = false;	// disable data binding to NSDataComps

		private string errorDisplay;	// if this is not null, it will be displayed when rendering
		private string errorLongDisplay;	// if this is not null, it will be displayed in tooltip when rendering
		//private NSLabel errorLabel;
		private string pickPage = null;
		private WindowOpener pickWindow;

		private DataRowView rowView = null;	// Row view to use, if null, use data comp's current row view
		#endregion

		#region Constructors
		public NSTextBox() : base()
		{
			/*errorLabel = new NSLabel();
			errorLabel.ForeColor = System.Drawing.Color.Red;
			*/
		}
		#endregion

		#region IDataBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
			if (disableBinding)
				return;

			errorDisplay = "";
			errorLongDisplay = "";
			if (dataSource != null)
			{
				if (dataMember != null)
				{
					if ((dataTable != null) && (dataField != null))
					{
						// find out table using the contained main dataset
						DataSet ds = dataSource.GetMainDataSet();
						DataTable table = ds.Tables[dataTable];
						DataColumn col = table.Columns[dataField];
						if (col == null)
							col = new DataColumn(dataField, typeof(string));
						this.Enabled = true;
						DataRowView rowView = GetCurrentDataRowView();
						if (rowView == null)
							return;

						bool pk = false;
						if (table.PrimaryKey.Length > 0)
							if (table.PrimaryKey[0] == col)
								pk = true;

						if (pk && disablePK)
							this.Enabled = false;	// This is a primary key

						if (Save)		// Save = true;
						{	// control to data
							// normay the formatter object will be employed here
							try
							{
								// if null is allowed, set null for empty string
								dataSource.ParseTableItem(rowView, dataField, this.Text);

								if (this.Text == "")
									if (!col.AllowDBNull)// && !pk)
									{
										errorDisplay = this.dataField + " can't be null";
										//throw new System.Data.NoNullAllowedException (this.dataField + " can't be null");
										
									}
							}
							catch(System.Data.ReadOnlyException)
							{
								// ignore
							}
							catch(System.Data.NoNullAllowedException noNull)
							{
								/*if (pk)
								{
									// ignore
								}
								else
								{*/
									errorDisplay = this.dataField + " can't be null";
									((BasePage)Page).RaisePageException(noNull);
								//}
							}
							catch(System.ArgumentException argEx)
							{
								errorDisplay = "Invalid entry";
								((BasePage)Page).RaisePageException(argEx);
							}
							catch(Exception ex)
							{
								errorDisplay = "???"; //ex.Message;
								errorLongDisplay = ex.Message;
								((BasePage)Page).RaisePageException(ex);
							}

							// If no error occured handle custom validation
							if (errorDisplay == "")
							{
								try
								{
									dataSource.ValidateTableItem(rowView, dataField);
								}
								catch(ValidationException valEx)
								{
									errorDisplay = valEx.Message;
									errorLongDisplay = valEx.LongMessage;
									((BasePage)Page).RaisePageException(valEx);
								}
								catch(Exception ex)
								{
									errorDisplay = "???"; //ex.Message;
									errorLongDisplay = ex.Message;
									((BasePage)Page).RaisePageException(ex);
								}
							}
						}
						else	// Save = false;
						{	
							// data to control
							// normay the formatter object will be employed here
							try
							{
								
								this.Text = dataSource.FormatTableItem(rowView, dataField, true);
								if (this.Text == "")
									if (!col.AllowDBNull)// && !pk)
									{
										throw new System.Data.NoNullAllowedException ("*");
									}
							}
							catch(Exception ex)
							{
								errorDisplay = "???"; //ex.Message;
								errorLongDisplay = ex.Message;
								((BasePage)Page).RaisePageException(ex);
							}
						}
					}
				}
			}
		}

		public DCBase GetDataSource()
		{
			return dataSource;
		}

		public string GetDataMember()
		{
			return dataMember;
		}

		public void SetDataSource(DCBase dc)
		{
			dataSource = dc;
		}

		public void SetDataMember(string dm)
		{
			DataMemberName = dm;
		}

		/// <summary>
		/// Forces the textbox to use the specifed rowView instead of 
		/// getting current rowview from datacomponent.
		/// </summary>
		/// <param name="rowView"></param>
		public void SetCurrentDataRowView(DataRowView rowView)
		{
			this.rowView = rowView;
		}

		public DataRowView GetCurrentDataRowView()
		{
			if (this.rowView == null)
			{
				if (dataSource != null)
					return dataSource.GetCurrentDataRowView(dataTable);
				else
					return null;
			}
			else
				return rowView;
		}

		#endregion

		/*
		#region IObjectBoundControl Members

		public object GetSourceObject()
		{
			// TODO:  Add NSTextBox.GetSourceObject implementation
			return null;
		}

		public string GetSourceObjectMember()
		{
			// TODO:  Add NSTextBox.GetSourceObjectMember implementation
			return null;
		}

		public void SetSourceObject(object obj)
		{
			// TODO:  Add NSTextBox.SetSourceObject implementation
		}

		public void SetSourceObjectMember(string om)
		{
			// TODO:  Add NSTextBox.SetSourceObjectMember implementation
		}

		#endregion
*/
		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
			Browsable(true),
			TypeConverter(typeof(NetsoftUSA.DataLayer.DataSourceConverter))
		]
		public string DataSourceName
		{
			get
			{
				return dataSourceName;
			}
			set
			{
				dataSourceName = value;

				//!!! add code to set dataSource object
			}
		}

		/// <summary>
		/// Data source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public NetsoftUSA.DataLayer.DCBase DataSourceObject
		{
			get
			{
				return dataSource;
			}
			set
			{
				dataSource = value;		// code serializer generated code calls this.
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
			Browsable(true),
			TypeConverter(typeof(NetsoftUSA.DataLayer.DataTableAndItemConverter))
		]
		public string DataMemberName
		{
			get
			{
				return dataMember;
			}
			set
			{
				dataMember = value;
				dataTable = null;
				dataField = null;

				if (dataMember != null)
				{
					string[] memberTerms = dataMember.Split('.');
					if (memberTerms.Length == 2)
					{
						dataTable = memberTerms[0];
						dataField = memberTerms[1];
					}
					else
					{
						if (dataMember != "")
						{
							dataMember = null;
							throw new Exception("This type of data member not handled yet!");
						}
					}
				}
			}
		}


		// This function gets only the value portion of the text.
		// For example 2-Question  will return 2
		public string GetValText()
		{
			string[] terms = Text.Split('-');
			if (terms[0].Length == 0)
				return Text;
			else
				return terms[0];
		}

		public Type GetDataType()
		{
			return dataSource.GetTable(dataTable).Columns[dataField].DataType;
		}

		public object GetValue()
		{
			return Convert.ChangeType(GetValText(), GetDataType());
		}

		[DefaultValue(true)]
		public bool UsePickPage
		{
			get
			{
				return usePickPage;
			}
			set
			{
				usePickPage = value;
			}
		}

		[DefaultValue(false)]
		public bool DisableBinding
		{
			get
			{
				return disableBinding;
			}
			set
			{
				disableBinding = value;
			}
		}

		[DefaultValue(true)]
		public bool DisablePK
		{
			get
			{
				return disablePK;
			}
			set
			{
				disablePK = value;
			}
		}

		#endregion
	
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);			
			if (usePickPage)
			{
				DataRowView rowView = GetCurrentDataRowView();
				if (rowView != null)
					pickPage = dataSource.GetPickPageForTableItem(rowView, dataField);

				if (pickPage != null)
				{
					pickWindow = new WindowOpener();
					pickWindow.ID = this.ID + "_PickWindow";
					pickWindow.WindowName = pickWindow.ID;
					pickWindow.NavigateURL = pickPage;
					pickWindow.ToolBar = false;
					pickWindow.MenuBar = false;
					pickWindow.AddressBar = false;
					pickWindow.LinksBar = false;
					pickWindow.PickTargetCtl = this;
					pickWindow.PickSource = "NSDataGrid1";
					pickWindow.Visible = true;
					pickWindow.Text = "...";
					pickWindow.PrepareForRender(this.Page);
					//this.Controls.Add(pickWindow);
				}
			}
		}

		protected override void Render(HtmlTextWriter writer)
		{
			string oldText = this.Text;
			bool oldEnabled = this.Enabled;
			if (this.Site != null)
				if (this.Site.DesignMode)
				{
					this.Text = dataMember;
					base.Render(writer);
					return;
				}

			bool render = true;
			if (dataSource != null && dataTable != null)
				if (!dataSource.IsValidRowPos(dataTable))
					render = false;
			if (render)
			{
				base.Render (writer);
				if (pickWindow != null)
					pickWindow.RenderControl(writer);

				if (errorDisplay != null)
					if (errorDisplay.Length > 0)
					{
						NSLabel errorLabel = new NSLabel();
						errorLabel.ForeColor = System.Drawing.Color.Red;
						errorLabel.Text = errorDisplay;

						if (errorLongDisplay != null)
							if (errorLongDisplay.Length > 0)
							{
								errorLabel.ToolTip = errorLongDisplay;
								errorLabel.Font.Underline = true;
							}
						errorLabel.RenderControl(writer);
						//writer.Write("<SPAN fontcolor=red> " + errorDisplay + "</SPAN>");
					}
			}
			else
			{
				this.Text = "";
				this.Enabled = false;
				base.Render (writer);
			}
			/*if (this.Site != null)
				if (this.Site.DesignMode)
				{
					writer.WriteLine("<font face='arial' size=1>" + dataMember + "</font>");
				}*/

			this.Text = oldText;
			this.Enabled = oldEnabled;
		}

		/*
		[Browsable(true), 
		DesignerSerializationVisibility(DesignerSerializationVisibility.Content)
		]
		public NSLabel ErrorLabel
		{
			get
			{
				return errorLabel;
			}
		}*/

		protected override void CreateChildControls()
		{
			base.CreateChildControls ();
		}


		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			errorDisplay = (string)ViewState["err"];
		}

		protected override object SaveViewState()
		{
			ViewState["err"] = errorDisplay;

			return base.SaveViewState ();
		}

	}
}
