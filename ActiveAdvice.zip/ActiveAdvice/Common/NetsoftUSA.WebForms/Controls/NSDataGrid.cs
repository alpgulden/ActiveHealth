using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using NetsoftUSA.DataLayer;
using System.Diagnostics;
using System.Text;
using System.Data;
using System.Collections;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Data Grid control which can be data bound to a Data Component
	/// instead of a DataSet
	/// </summary>
	[ToolboxData("<{0}:NSDataGrid runat=server></{0}:NSDataGrid>"),
		System.ComponentModel.Design.Serialization.DesignerSerializer(
		typeof(NetsoftUSA.WebForms.NSDataGridCodeSer), 
		typeof(System.ComponentModel.Design.Serialization.CodeDomSerializer))
	]
	public class NSDataGrid : System.Web.UI.WebControls.DataGrid, INamingContainer
	{
		#region Static members
		
		public static string CssClassAlternatingItemAll = "";
		public static string CssClassEditItemAll = "";
		public static string CssClassFooterAll = "";
		public static string CssClassHeaderAll = "";
		public static string CssClassItemAll = "";
		public static string CssClassPagerAll = "";
		public static string CssClassSelectedItemAll = "";
		public static string CssClassCommmandButtonAll = "";
		public static string CssClassSearchBoxesAll = "";

		#endregion

		#region Private members
		private string dataSourceName;	// actual source data component name
		private NetsoftUSA.DataLayer.DCBase dataSource = null;	// actual source data component
		private string dataMember;	// in the form of Table.Field

		private string searchDataSourceName;	// data component to be used used for search fields
		private NetsoftUSA.DataLayer.DCBase searchDataSource = null;

		private string pickValueField;
		private string pickFormattedField;

		private DCBinding binding;
		private DCBinding bindingSearcher;
		private bool columnsCreated = false;

		internal TextBox pickTarget = null;			// the uniqueid of the pick target hidden inputbox
		internal string pickTargetID;			// the uniqueid of the pick target hidden inputbox
		//private bool pickTargetInThisWindow = false;	// pick target is in this window, not in the opener
		internal string pickTargetName;			// the uniqueid of the pick target hidden inputbox
		internal string pickTargetTextData;
		private bool selectButton = true;
		private bool selectCheckBoxes = true;
		private bool pickButton = false;
		private bool pickButtonCloses = false;		// pickbutton will close the window
		private bool enableSearchColumns = false;
		private bool editable = false;				// allow edit?
		private bool autoEdit = false;				// automatically set edit mode when a row is selected
		private bool handleSearch = true;			// handle search event of binding

		private int keepOnRowNum = -1;		// if this is set, selected indexchanged event will keep on this row
		//internal CheckBox[] selectionCheckBoxes = null;		// accessed by the NSGridItemTemplate to keep a collection of checkboxes

		// the css classes will override css styles and will also provide central control
		// for all NSDataGrid controls
		private string cssClassAlternatingItem = null;
		private string cssClassEditItem = null;
		private string cssClassFooter = null;
		private string cssClassHeader = null;
		private string cssClassItem = null;
		private string cssClassPager = null;
		private string cssClassSelectedItem = null;
		private string cssClassCommmandButton = null;
		private string cssClassSearchBoxes = null;

		private void setValidCssToStyle(Style style, string css, string cssAll)
		{
			if (css != null)
				if (css != "")
				{
					style.CssClass = css;
					return;
				}
			if (cssAll != null)
				if (cssAll != "")
				{
					style.CssClass = cssAll;
					return;
				}
		}

		internal string getValidCss(string css, string cssAll)
		{
			if (css != null)
				if (css != "")
				{
					return css;
				}
			return cssAll;
		}

		public bool getColumnCheck(string colName)
		{
			return Convert.ToBoolean(ViewState[colName + "_check"]);
		}

		public void setColumnCheck(string colName, bool check)
		{
			ViewState[colName + "_check"] = check;
		}

		/// <summary>
		/// This creates the necessary binding to the dataSource-dataMember.
		/// All navigation is performed through this binding.
		/// If there's a binding object already created, it'll be reused.
		/// </summary>
		private void addBinding()
		{
			try
			{
				binding = ((BasePage)Page).BindingManager.EnsureBinding(dataSource, dataMember);
				binding.SearchEvent +=new DCBinding.SearchEventHandler(binding_SearchEvent);
				binding.DeleteEvent +=new NetsoftUSA.WebForms.DCBinding.DeleteRecordEventHandler(binding_DeleteEvent);
				binding.NavigateEvent +=new EventHandler(binding_NavigateEvent);
			}
			catch(Exception)
			{ }
			try
			{
				bindingSearcher = ((BasePage)Page).BindingManager.EnsureBinding(searchDataSource, dataMember);
			}
			catch(Exception)
			{ }
		}
		#endregion

		#region Constructors
		public NSDataGrid() : base()
		{
			//this.AutoGenerateColumns = false;
		}
		#endregion

		#region Protected functions

		/// <summary>
		/// Create extra columns specific to NSDataGrid (the selection checkboxes column)
		/// </summary>
		protected void CreateColumns()
		{
			//Columns.Clear();		
			TemplateColumn tplCol = null;
			//col.HeaderText = "Sel";

			
			tplCol = new TemplateColumn();
			tplCol.HeaderTemplate = new NSPickItemHeaderTemplate(this);
			tplCol.ItemTemplate = new NSPickItemTemplate(pickValueField, pickFormattedField, this);
			tplCol.Visible = pickButton;
			Columns.AddAt(0, tplCol); 
			
			if (selectButton)
			{
				ButtonColumn butCol = new ButtonColumn();
				butCol.Text = "Select";
				butCol.ButtonType = ButtonColumnType.PushButton;
				butCol.CommandName = "Select";
				butCol.ItemStyle.Width = Unit.Pixel(70);
				//setValidCssToStyle(butCol.ItemStyle, cssClassCommmandButton, NSDataGrid.CssClassCommmandButtonAll);
				Columns.AddAt(0, butCol); 
			}
			if (selectCheckBoxes)
			{
				tplCol = new TemplateColumn();
				tplCol.HeaderTemplate = new NSGridSelectItemHeaderTemplate(this);
				tplCol.ItemTemplate = new NSGridSelectItemTemplate(this);
				tplCol.ItemStyle.Width = Unit.Pixel(16);
				Columns.AddAt(0, tplCol); 
			}
						
			if (this.AutoGenerateColumns)
			{
				// Add all table columns
				foreach (DataColumn col in dataSource.GetTable(dataMember).Columns)
				{
					tplCol = new TemplateColumn();
					//tplCol.HeaderText = col.ColumnName;
					string dmember = dataMember + "." + col.ColumnName;
					string headerText = DataSourceObject.GetColumnDesc(dataMember, col.ColumnName);
					if (enableSearchColumns)
						tplCol.HeaderTemplate = new NSDataGridItemHeaderTemplate(dmember, this, headerText);
					else
						tplCol.HeaderText = headerText;
					tplCol.ItemTemplate = new NSDataGridItemTemplate(dmember, this, false);
					if (this.editable)
						tplCol.EditItemTemplate = new NSDataGridItemTemplate(dmember, this, true);
					//tpl.item
					Columns.Add(tplCol);
				}
			}
			// Replace all bound columns with template columns
			for (int i = 0; i < Columns.Count; i++)
			{
				BoundColumn boundCol = Columns[i] as BoundColumn;
				
				if (boundCol != null)
				{
					string dataField = boundCol.DataField;
					tplCol = new TemplateColumn();
					//tplCol.HeaderText = boundCol.HeaderText;
					string dmember = dataMember + "." + dataField;
					string headerText = boundCol.HeaderText;
					
					if (headerText == null || headerText == "")
						headerText = DataSourceObject.GetColumnDesc(dataMember, dataField);

					if (enableSearchColumns)
						tplCol.HeaderTemplate = new NSDataGridItemHeaderTemplate(dmember, this, headerText);
					else
						tplCol.HeaderText = headerText;
					tplCol.ItemTemplate = new NSDataGridItemTemplate(dmember, this, false);
					if (this.editable)
						tplCol.EditItemTemplate = new NSDataGridItemTemplate(dmember, this, true);
					
					Columns.AddAt(i, tplCol);
					Columns.RemoveAt(i + 1);
				}
			}

			this.AutoGenerateColumns = false;		// prevent default autogenerate
			columnsCreated = true;
		}

		public void registerClientScripts(Page page)
		{
			if (!page.IsClientScriptBlockRegistered("PickItemTemplate"))
			{
				if (pickButton)
				{
					if (pickTarget != null)
					{
						pickTargetID = pickTarget.ClientID;
						pickTargetName = pickTarget.UniqueID;
					}
					StringBuilder s = new StringBuilder();
					//s.Append("<SCRIPT FOR=window EVENT=onload>\n");
					s.Append(" try {\n");
					s.Append(" set_"+ this.ID + "_PickTarget(" + this.ID + "_PickTarget);\n");
					s.Append(" } catch(e)\n");
					s.Append(" { }\n");
					//s.Append("</SCRIPT>\n");
					((BasePage)page).RegisterOnLoadScript("PickItemTemplateOnload", s.ToString());

					s = new StringBuilder();
					s.Append("<SCRIPT language='JAVASCRIPT'>\n");
					// set_Grid_PickTarget(s)
					s.Append("function set_"+ this.ID + "_PickTarget(s) {\n");
					s.Append("  document.all[\"" + pickTargetID + "\"].value=s;\n");
					s.Append("}\n");
					// PickItem(item)
					s.Append("function PickItem(item) {\n");
					s.Append("  var targetCtl = document.all[\"" + pickTargetID + "\"].value;\n");
					s.Append("  try {\n");
					s.Append("  window.opener.document.all[targetCtl].value=item.formattedField;\n");
					s.Append("  } catch(e) {\n");
					s.Append("  window.alert(\"Can't access target field \" + targetCtl +");
					s.Append("  \"  \\r\\nThe calling window may have been closed.\"); }\n");
					if (PickButtonCloses)
						s.Append("  window.close();\n");
					s.Append("}\n");
					s.Append("\n");
					s.Append("</SCRIPT>\n");
					page.RegisterClientScriptBlock("PickItemTemplate", s.ToString());
				}
			}
		}



		/*
		public void registerClientScripts(Page page)
		{
			if (!page.IsClientScriptBlockRegistered("PickItemTemplate"))
			{
				if (pickButton)
				{
					if (pickTarget != null)
					{
						pickTargetID = pickTarget.ClientID;
						pickTargetName = pickTarget.UniqueID;
					}
					StringBuilder s = new StringBuilder();
					//s.Append("<SCRIPT FOR=window EVENT=onload>\n");
					s.Append(" try {\n");
					s.Append(" set_"+ this.ID + "_PickTarget('" + this.ID + "_PickTarget');\n");
					s.Append(" } catch(e)\n");
					s.Append(" { }\n");
					//s.Append("</SCRIPT>\n");
					((BasePage)page).RegisterOnLoadScript(this.ID + "_PickItemTemplateOnload", s.ToString());

					s = new StringBuilder();
					s.Append("<SCRIPT language='JAVASCRIPT'>\n");
					// set_Grid_PickTarget(s)
					s.Append("function set_"+ this.ID + "_PickTarget(s) {\n");
					s.Append("  document.all[\"" + pickTargetID + "\"].value=s;\n");
					s.Append("}\n");
					// PickItem(item)
					s.Append("function " + this.ID + "_PickItem(item) {\n");
					s.Append("  var targetCtl = document.all[\"" + pickTargetID + "\"].value;\n");
					s.Append("  try {\n");
					if (!pickTargetInThisWindow)
						s.Append("  window.opener");
					else
						s.Append("  ");
					s.Append("document.all[targetCtl].value=item.formattedField;\n");
					s.Append("  } catch(e) {\n");
					s.Append("  window.alert(\"Can't access target field \" + targetCtl +");
					s.Append("  \"  \\r\\nThe calling window may have been closed.\"); }\n");
					if (PickButtonCloses)
						s.Append("  window.close();\n");
					s.Append("}\n");
					s.Append("\n");
					s.Append("</SCRIPT>\n");
					page.RegisterClientScriptBlock(this.ID + "_PickItemTemplate", s.ToString());
				}
			}
		}*/

		protected override void OnEditCommand(DataGridCommandEventArgs e)
		{
			int editRowIndex = e.Item.ItemIndex;

			int curRow = this.CurrentRowPos;
			NavigateToIndex(editRowIndex);
				
			if (((BasePage)this.Page).PageError)
			{	
				keepOnRowNum = curRow;
				return;
			}

			EditItemIndex = editRowIndex;
			base.OnEditCommand (e);
		}

		protected override void OnCancelCommand(DataGridCommandEventArgs e)
		{
			CancelEdit();
			base.OnCancelCommand (e);
		}

		public void CommitEdit(int editRowIndex)
		{
			NavigateToIndex(editRowIndex);
			if (((BasePage)this.Page).PageError)
				return;
			EditItemIndex = -1;
			BindGrid();
		}

		public void CancelEdit()
		{
			EditItemIndex = -1;
			BindGrid();
		}
		protected override void OnUpdateCommand(DataGridCommandEventArgs e)
		{
			CommitEdit(e.Item.ItemIndex);
			base.OnUpdateCommand (e);
		}



		/*
		public void BeginEdit(int rowIndex)
		{
			EditItemIndex = rowIndex;
			vaEditRow = exds.FetchRecord(dataView, EditItemIndex).CloneNet();
		}

		public void CommitEdit()
		{
			if (EditItemIndex >= 0)
			{
				UpdateRow(EditItemIndex);
				EditItemIndex = -1;
				vaEditRow = null;
			}
		}*/

		protected override void OnPreRender(EventArgs e)
		{	
			EnsureChildControls();
			if (!Page.IsPostBack)
			{
				// Automatically bind for the first time.
				BindGrid();
			}
			string css = getValidCss(cssClassCommmandButton, NSDataGrid.CssClassCommmandButtonAll);
			Table tbl = (Table)this.Controls[0];//.Controls[0];
			ArrayList buttonCols = new ArrayList();
			for (int i = 0; i < Columns.Count; i++)
			{
				ButtonColumn butCol = Columns[i] as ButtonColumn;
				if (butCol != null)
					buttonCols.Add(i);
				/*else
				{
					TemplateColumn tplCol = Columns[i] as TemplateColumn;
					if (tplCol != null)
						buttonCols.Add(i);
				}*/
			}

			if (buttonCols.Count > 0)
			{
				foreach (TableRow row in tbl.Rows)
				{
					if (row.Cells.Count == Columns.Count)
					{
						// determine button cols
						for (int i = 0; i < buttonCols.Count; i++)
						{
							TableCell cell = row.Cells[ (int)buttonCols[i] ];
							foreach (Control ctl in cell.Controls)
							{
								Button bt = ctl as Button;
								if (bt != null)
								{
									bt.CssClass = css;
								}
							}
						}
					}
				}
			}

			registerClientScripts(this.Page);
		}

	
		protected override void LoadViewState(object savedState)
		{
			// We create columns if not already created.
			base.LoadViewState (savedState);

			if (Page.IsPostBack)
			{
				pickButton = false;
				object opickButton = ViewState["PickButton"];
				if (opickButton != null)
					if ((bool)opickButton)
						pickButton = true;

				if (pickButton)
				{
					pickTargetName = (string)ViewState["PickTargetName"];
					pickTargetID = (string)ViewState["PickTargetID"];
					if (pickTargetName != null)
						pickTargetTextData = (string)Page.Request.Form[pickTargetName];
				}

				/*if (true)
				{
					// update necessary search items
					DataTable tbl = this.DataSourceObject.GetTable(dataMember);
					foreach (DataColumn col in tbl.Columns)
					{
						
					}
				}*/
			}
			if (!columnsCreated)
				this.CreateColumns();
		}

		//protected override rai

		protected override object SaveViewState()
		{
			/*
			object baseState = base.SaveViewState();

			object[] allStates = new object[4];
			allStates[0] = baseState;
			allStates[1] = pickButton;
			allStates[2] = pickTargetName;
			allStates[3] = pickTargetID;
			*/

			ViewState["PickButton"] = pickButton;
			ViewState["PickTargetName"] = pickTargetName;
			ViewState["PickTargetID"] = pickTargetID;

			//return allStates;
			return base.SaveViewState();
		}

		
		protected override void OnSelectedIndexChanged(EventArgs e)
		{
			// if keepOnRowNum is set for some reason, selected index won't change
			if (keepOnRowNum != -1)
				CurrentRowPos = keepOnRowNum;
		}
	
		protected override void OnPageIndexChanged(DataGridPageChangedEventArgs e)
		{
			// keep the binding (hence all page) synchronized
			// when the page is changed
			int oldRowPos = this.CurrentRowPos;
			base.OnPageIndexChanged (e);
			this.CurrentPageIndex = e.NewPageIndex;
			this.CurrentRowPos = this.TopOfPage;
			int newRowNum = binding.Navigate(this.CurrentRowPos);
			// if not successfull naviagting to new position, revert back to old pos
			if (newRowNum != CurrentRowPos)
				this.CurrentRowPos = oldRowPos;
		}
	
		protected override void CreateChildControls()
		{
			addBinding();
			base.CreateChildControls ();

			/*
			pickTarget = new TextBox();
			pickTarget.Visible = true;
			pickTarget.EnableViewState = true;
			//pickTarget.Style["visibility"] = "hidden";
			pickTarget.ID = this.ID + "_PickTarget";
			Controls.Add(pickTarget);
			*/
			if (!this.Page.IsPostBack)
			{
				setValidCssToStyle(this.AlternatingItemStyle, cssClassAlternatingItem, NSDataGrid.CssClassAlternatingItemAll);
				setValidCssToStyle(this.EditItemStyle, cssClassEditItem, NSDataGrid.CssClassEditItemAll);
				setValidCssToStyle(this.FooterStyle, cssClassFooter, NSDataGrid.CssClassFooterAll);
				setValidCssToStyle(this.HeaderStyle, cssClassHeader, NSDataGrid.CssClassHeaderAll);
				setValidCssToStyle(this.ItemStyle, cssClassItem, NSDataGrid.CssClassItemAll);
				setValidCssToStyle(this.PagerStyle, cssClassPager, NSDataGrid.CssClassPagerAll);
				setValidCssToStyle(this.SelectedItemStyle, cssClassSelectedItem, NSDataGrid.CssClassSelectedItemAll);
				//private string cssClassCommmandButton = null;
				//private string cssClassSearchBoxes = null;
			}
		}
	
		protected override void OnItemCommand(DataGridCommandEventArgs e)
		{
			if (e.CommandName == "Select")
			{
				int rowNum = GetAbsoluteRowNum(e.Item.ItemIndex);
				int newRowNum = binding.Navigate(rowNum);
				if (((BasePage)this.Page).PageError)
				//if (newRowNum != rowNum)
					keepOnRowNum = newRowNum;	// if not successfull navigating
				/*else
				{
					if (editable && autoEdit)
						this.EditItemIndex = newRowNum;
				}*/
			}
			base.OnItemCommand (e);
		}	

		#endregion

		#region Public functions

		[DefaultValue(false)]
		public bool EnableSearchColumns
		{
			get
			{
				return enableSearchColumns;
			}
			set
			{
				enableSearchColumns = value;
			}
		}

		[DefaultValue(false)]
		public bool Editable
		{
			get
			{
				return editable;
			}
			set
			{
				editable = value;
			}
		}

		[DefaultValue(false)]
		public bool AutoEdit
		{
			get
			{
				return autoEdit;
			}
			set
			{
				autoEdit = value;
			}
		}

		[DefaultValue(true)]
		public bool HandleSearch
		{
			get
			{
				return handleSearch;
			}
			set
			{
				handleSearch = value;
			}
		}

		[DefaultValue(true)]
		public bool SelectButton
		{
			get
			{
				return selectButton;
			}
			set
			{
				selectButton = value;
			}
		}

		[DefaultValue(true)]
		public bool SelectCheckBoxes
		{
			get
			{
				return selectCheckBoxes;
			}
			set
			{
				selectCheckBoxes = value;
			}
		}

		[DefaultValue(false)]
		public bool PickButton
		{
			get
			{
				return pickButton;
			}
			set
			{
				pickButton = value;
			}
		}

		[DefaultValue(false)]
		public bool PickButtonCloses
		{
			get
			{
				return pickButtonCloses;
			}
			set
			{
				pickButtonCloses = value;
			}
		}

		public string PickValueField
		{
			get
			{
				return pickValueField;
			}
			set
			{
				pickValueField = value;
			}
		}

		public string PickFormattedField
		{
			get
			{
				return pickFormattedField;
			}
			set
			{
				pickFormattedField = value;
			}
		}

		public bool Navigate(int RowNum)
		{
			int newRowNum = binding.Navigate(RowNum);
			if (newRowNum != RowNum)
				return false;
			else
				return true;
		}

		public bool NavigateToIndex(int ItemIndex)
		{
			int rowNum = GetAbsoluteRowNum(ItemIndex);
			return Navigate(rowNum);
		}

		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataSourceConverter))
		]
		public string DataSourceName
		{
			get
			{
				return dataSourceName;
			}
			set
			{
				dataSourceName = value;

				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						//DataSourceObject = this.Site.Container.Components[dataSourceName] as DCBase;
						//BindGrid();
					}

				return;
				/*
				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						// set the base data grid's DataSource (of DataSet type)
						try
						{
							DCBase dataComp = this.Site.Container.Components[dataSourceName] as DCBase;
							if (dataComp != null)
							{
								this.DataSource = dataComp.GetMainDataSet();
								this.DataMember = ((System.Data.DataSet)this.DataSource).DataSetName;
							}
							else
								this.DataSource = null;
							
						}
						catch(Exception)
						{
						}
					}
				*/
				//!!! add code to set dataSource object
			}
		}

		/// <summary>
		/// Data source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public NetsoftUSA.DataLayer.DCBase DataSourceObject
		{
			get
			{
				return dataSource;
			}
			set
			{
				dataSource = value;		// code serializer generated code calls this.
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataTableOnlyConverter))
		]
		public string DataMemberName
		{
			get
			{
				return dataMember;
			}
			set
			{
				dataMember = value;

				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						//DataSourceObject = this.Site.Container.Components[dataSourceName] as DCBase;
						//BindGrid();
					}

				return;
				/*
				if (this.Site != null)
                    if (this.Site.DesignMode)
					{
						// Set the base datagrid's data member
						this.DataMember = dataMember;
					}
				*/
			}
		}

		/// <summary>
		/// Data source object name to be used for binding this control's search fields.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataSourceConverter))
		]
		public string SearchDataSourceName
		{
			get
			{
				return searchDataSourceName;
			}
			set
			{
				string dsname = value;
				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						if (dsname != null && dsname != "")
						{
							DCBase dc = this.Site.Container.Components[dsname] as DCBase;
							if (dc != null)
								if (!dc.IsSearcher)
									throw new Exception("This data component is not set as searcher!  Set its IsSearcher property to true first.");
						}
					}
				

				searchDataSourceName = value;

				if (this.Site != null)
					if (this.Site.DesignMode)
					{
					}

				return;
			}
		}

		/// <summary>
		/// Data source object to be used for binding this control's search fields.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public NetsoftUSA.DataLayer.DCBase SearchDataSourceObject
		{
			get
			{
				return searchDataSource;
			}
			set
			{
				searchDataSource = value;		// code serializer generated code calls this.
			}
		}

		/// <summary>
		/// Communicates to the bound data component and 
		/// binds data to the related dataview for the specified
		/// data member.
		/// </summary>
		public void BindGrid()
		{
			if (!columnsCreated)
				this.CreateColumns();

			System.Data.DataSet ds = DataSourceObject.GetMainDataSet();
			DataSource = GetDataView();
			DataBind();
			if (searchDataSource != null)
				bindingSearcher.UpdateData(false);
		}

		/// <summary>
		/// Return the checkbox control for only the given 
		/// row number.
		/// </summary>
		/// <param name="rowId"></param>
		/// <returns></returns>
		public CheckBox GetSelectionCheckBox(int rowId)
		{
			return (CheckBox)this.Items[rowId].Cells[0].Controls[0];
		}

		/// <summary>
		/// Return an array of check box controls used for selecting
		/// rows.
		/// </summary>
		/// <returns></returns>
		public int[] GetSelectedRows()
		{
			System.Collections.ArrayList selectedRows = new System.Collections.ArrayList();
			if (!selectButton)
			{
				for (int i = 0; i < this.Items.Count; i++)
				{
					if (GetSelectionCheckBox(i).Checked)
						selectedRows.Add(GetAbsoluteRowNum(i));
				}
			}
			return (int[])selectedRows.ToArray(typeof(int));
		}

		/// <summary>
		/// Returns the data view that the grid is working on 
		/// for the bound data component and data member's 
		/// default view.
		/// </summary>
		/// <returns></returns>
		public System.Data.DataView GetDataView()
		{
			DataView dw = dataSource.GetTable(dataMember).DefaultView;
			return dw;
		}

		/// <summary>
		/// Create a new row on the underlying data component
		/// </summary>
		public void NewRow()
		{
			dataSource.NewRecord(dataMember);
			CurrentRowPos = dataSource.GetTableRowPos(dataMember);
		}

		/// <summary>
		/// Delete the given data row of the bound data component.
		/// Note that the rowId's are only row indexes and may point
		/// to different records as the data table changes.
		/// </summary>
		/// <param name="rowId">The row number</param>
		public void DeleteRow(int rowId)
		{
			dataSource.DeleteRecord(dataMember, rowId);
			CurrentRowPos = dataSource.GetTableRowPos(dataMember);
		}

		/// <summary>
		/// Delte the given rows
		/// </summary>
		/// <param name="rowIds">An array of row numbers to delete</param>
		public void DeleteRows(int[] rowIds)
		{
			dataSource.DeleteRecords(dataMember, rowIds);
			CurrentRowPos = dataSource.GetTableRowPos(dataMember);
		}

		/// <summary>
		/// Delete only those rows checked by the user
		/// </summary>
		public void DeleteSelectedRows()
		{
			DeleteRows(GetSelectedRows());
		}

		[DefaultValue(-1)]
		public int CurrentRowPos
		{
			get
			{
				return this.CurrentPageIndex * this.PageSize + this.SelectedIndex;
			}
			set
			{
				this.CurrentPageIndex = value / this.PageSize;
				this.SelectedIndex = value % this.PageSize;

				if (editable && autoEdit)
					this.EditItemIndex = this.SelectedIndex;
			}
		}

		/// <summary>
		/// Return the absolute row number of the top of this page
		/// </summary>
		public int TopOfPage
		{
			get
			{
				return GetAbsoluteRowNum(0);
			}
		}

		/// <summary>
		/// Return the absolute row number of the given row number for the current page
		/// </summary>
		/// <param name="rowNum"></param>
		/// <returns></returns>
		public int GetAbsoluteRowNum(int rowNumInPage)
		{
			return this.CurrentPageIndex * this.PageSize + rowNumInPage;
		}

		public string[] GetCheckedColumns()
		{
			System.Collections.ArrayList checkedColumns = new System.Collections.ArrayList();
			foreach (DataColumn col in dataSource.GetTable(dataMember).Columns)
			{
				if (getColumnCheck(col.ColumnName))
					checkedColumns.Add(col.ColumnName); 
			}
			return (string[])checkedColumns.ToArray(typeof(string));
		}

		public void ApplySearch()
		{
			bindingSearcher.UpdateData(true);
			if (((BasePage)this.Page).PageError)
				return;
			string[] checkedColumns = GetCheckedColumns();
			bindingSearcher.CreateSelectFor(binding, checkedColumns);
			binding.LoadData();
			bindingSearcher.UpdateData(false);
			binding.Navigate(0);
		}

		#endregion

		private void binding_SearchEvent(object sender, BindingEventArgs e)
		{
			// implements the search event generated by the binding.
			if (handleSearch)
				this.ApplySearch();
		}

		private void binding_DeleteEvent(object sender, BindingEventArgs e)
		{
			int[] selRows = GetSelectedRows();
			if (selRows.Length > 0)
			{
				binding.DeleteRecords(selRows);
				e.cancelDefault = true;
			}
		}

		private void binding_NavigateEvent(object sender, EventArgs e)
		{
			if (bindingSearcher != null)
				bindingSearcher.UpdateData(true);
		}

		/*
		[DefaultValue(false)]
		public bool PickTargetInThisWindow
		{
			get
			{
				return pickTargetInThisWindow;
			}
			set
			{
				pickTargetInThisWindow = value;
			}
		}*/

		[Category("Appearance")]
		public string CssClassAlternatingItem
		{
			get { return cssClassAlternatingItem; }
			set 
			{ 
				cssClassAlternatingItem = value; 
				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						this.AlternatingItemStyle.CssClass = "";
						setValidCssToStyle(this.AlternatingItemStyle, cssClassAlternatingItem, NSDataGrid.CssClassAlternatingItemAll);
					}
			}
		}

		[Category("Appearance")]
		public string CssClassEditItem
		{
			get { return cssClassEditItem; }
			set 
			{ 
				cssClassEditItem = value; 
				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						this.EditItemStyle.CssClass = "";
						setValidCssToStyle(this.EditItemStyle, cssClassEditItem, NSDataGrid.CssClassEditItemAll);
					}
			}
		}
		
		[Category("Appearance")]
		public string CssClassFooter
		{
			get { return cssClassFooter; }
			set 
			{ 
				cssClassFooter = value; 
				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						this.FooterStyle.CssClass = "";
						setValidCssToStyle(this.FooterStyle, cssClassFooter, NSDataGrid.CssClassFooterAll);
					}
			}
		}

		[Category("Appearance")]
		public string CssClassHeader
		{
			get { return cssClassHeader; }
			set
			{ 
				cssClassHeader = value; 
				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						this.HeaderStyle.CssClass = "";
						setValidCssToStyle(this.HeaderStyle, cssClassHeader, NSDataGrid.CssClassHeaderAll);
					}
			}
		}

		[Category("Appearance")]
		public string CssClassItem
		{
			get { return cssClassItem; }
			set 
			{ 
				cssClassItem = value; 
				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						this.ItemStyle.CssClass = "";
						setValidCssToStyle(this.ItemStyle, cssClassItem, NSDataGrid.CssClassItemAll);
					}
			}
		}

		[Category("Appearance")]
		public string CssClassPager
		{
			get { return cssClassPager; }
			set 
			{ 
				cssClassPager = value; 
				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						this.PagerStyle.CssClass = "";
						setValidCssToStyle(this.PagerStyle, cssClassPager, NSDataGrid.CssClassPagerAll);
					}
			}
		}

		[Category("Appearance")]
		public string CssClassSelectedItem
		{
			get { return cssClassSelectedItem; }
			set 
			{ 
				cssClassSelectedItem = value; 
				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						this.SelectedItemStyle.CssClass = "";
						setValidCssToStyle(this.SelectedItemStyle, cssClassSelectedItem, NSDataGrid.CssClassSelectedItemAll);
					}
			}
		}

		[Category("Appearance")]
		public string CssClassCommmandButton
		{
			get { return cssClassCommmandButton; }
			set { cssClassCommmandButton = value; }
		}

		[Category("Appearance")]
		public string CssClassSearchBoxes
		{
			get { return cssClassSearchBoxes; }
			set { cssClassSearchBoxes = value; }
		}

		internal void SetPickTargetID(string pickTargetID)
		{
			pickTargetTextData = pickTargetID;
		}
	}
}
