using System;
using System.Web.UI.WebControls;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for DummyValidator.
	/// </summary>
	public class DummyValidator : BaseValidator
	{
		public new void RegisterValidatorCommonScript()
		{
			base.RegisterValidatorCommonScript();
		}

		protected override bool EvaluateIsValid()
		{
			return true;
		}

		protected override bool ControlPropertiesValid()
		{
			return true;
		}

		
	}
}
