using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Collections;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebControls;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for OBMultiTextBox.
	/// </summary>
	[ToolboxData("<{0}:OBMultiTextBox runat=server></{0}:OBMultiTextBox>")]
	public class OBMultiTextBox : MultiTextBox, IObjectBoundControl, INamingContainer
	{
		#region private members
		private string sourceClassName;	// source object's class type to be used in design time
		private Type type;
		private object sourceObject = null;	// actual source object
		private string sourceMember;		// source member of the source object
		private bool disableBinding = false;	// disable data binding to NSDataComps

		private string errorDisplay;	// if this is not null, it will be displayed when rendering
		private string errorLongDisplay;	// if this is not null, it will be displayed in tooltip when rendering
		//private NSLabel errorLabel;

		private bool objectBound = false;
		
		private OBTextBox obTextBox = null;
		#endregion

		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);
			EnsureChildControls();

			if (sourceMember != null)
			{
				try
				{
					type = Type.GetType(sourceClassName);
				}
				catch
				{
				}
			}
		}


		#region IObjectBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
			if (disableBinding)
				return;

			errorDisplay = "";
			errorLongDisplay = "";
			if (sourceObject != null && sourceMember != null)
			{
				if (Save)		// Save = true;
				{	// control to data
					// normay the formatter object will be employed here
					try
					{
						ReflectionHelper.SetMemberValueFromString(sourceObject, sourceMember, this.Text);
					}
					catch(System.Data.ReadOnlyException)
					{
						// ignore
					}
					catch(System.ArgumentException argEx)
					{
						errorDisplay = "Invalid entry";
						((BasePage)Page).RaisePageException(argEx);
					}
					catch(Exception ex)
					{
						errorDisplay = "???"; //ex.Message;
						errorLongDisplay = ex.Message;
						((BasePage)Page).RaisePageException(ex);
					}

					/*// If no error occured handle custom validation
					if (errorDisplay == "")
					{
						try
						{
							dataSource.ValidateTableItem(rowView, dataField);
						}
						catch(ValidationException valEx)
						{
							errorDisplay = valEx.Message;
							errorLongDisplay = valEx.LongMessage;
							((BasePage)Page).RaisePageException(valEx);
						}
						catch(Exception ex)
						{
							errorDisplay = "???"; //ex.Message;
							errorLongDisplay = ex.Message;
							((BasePage)Page).RaisePageException(ex);
						}
					}*/
				}
				else
				{	// data to control
					// normay the formatter object will be employed here
					try
					{
						//Type type = Type.GetType(sourceClassName);
						//if (type != null)
						//{
							//MemberInfo mi = null;
							//mi = type.GetField(sourceMember);

							this.Text = ReflectionHelper.GetMemberValueAsString(sourceObject, sourceMember);
							//if (mi == null)
							//	mi = type.GetProperty(sourceMember);
							//if (mi != null)
							//{
							//	this.Text = sval;
							//}
						//}
					}
					catch(Exception ex)
					{
						errorDisplay = "???"; //ex.Message;
						errorLongDisplay = ex.Message;
						((BasePage)Page).RaisePageException(ex);
					}
				}
			}
		}

		public object GetSourceObject()
		{
			return sourceObject;
		}

		public string GetSourceObjectMember()
		{
			return sourceMember;
		}

		public void SetSourceObject(object obj)
		{
			SourceObject = obj;
		}

		public void SetSourceObjectMember(string om)
		{
			SourceMemberName = om;
		}

		[Browsable(false)]
		public bool IsReadOnly
		{ 
			get { return this.ReadOnly;} 
			set { this.ReadOnly = value; }
		}

		[Browsable(false)]
		public bool IsEnabled
		{ 
			get { return this.Enabled; } 
			set { this.Enabled = value; }
		}

		#endregion


		protected override void CreateChildControls()
		{
			base.CreateChildControls ();

			if (txtOutput != null)
			{
				obTextBox = txtOutput as OBTextBox;
	
				if (obTextBox != null)
				{
					obTextBox.ValueSet += new EventHandler(obTextBox_ValueSet);
				}
			}
		}

		public bool IsViewOnly
		{
			get
			{
				if (((BasePage)Page).IsViewOnly)
					return true;
				return ((BasePage)Page).ClassBindings.GetViewOnly(type);
			}
		}

		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			bool oldEnabled = this.Enabled;
			if (this.IsViewOnly)
			{
				string readonlyText = null;
				if (this.MultiTextBoxType == EnumMultiTextBoxType.USState)
				{
					DropDownList dd = this.GetDropDownListControl("state");
					if (dd != null)
						if (dd.SelectedItem != null)
							readonlyText = dd.SelectedItem.Text;
				}
				else
					readonlyText = this.Text;
				writer.Write("<span class='{0}'>{1}</span>", this.CssClass, readonlyText);
				return;
				/*for (int i = 0; i < this.Controls.Count; i ++)
				{
					//(WebControl) this.Controls[i]
				}*/
			}

			if (objectBound || txtOutput != null)
			{
				base.Render (writer);
				if (errorDisplay != null)
					if (errorDisplay.Length > 0)
					{
						NSLabel errorLabel = new NSLabel();
						errorLabel.ForeColor = System.Drawing.Color.Red;
						errorLabel.Text = errorDisplay;
						errorLabel.RenderControl(writer);
					}
			}
			else
			{
				this.Enabled = false;
				base.Render (writer);
			}

			this.Enabled = oldEnabled;
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			errorDisplay = (string)ViewState["err"];
			objectBound = (bool)ViewState["ob"];

			bool valsSaved = (bool)ViewState["vals"];
			if (valsSaved)		// values were saved
			{
				EnsureChildControls();
				BindComboData();
				foreach (DictionaryEntry entry in this.inputCtls)
				{
					string subItem = (string)entry.Key;
					string sval = (string)ViewState["v_" + subItem];
					WebControl ctl = entry.Value as WebControl;
					ctl.EnableViewState = false;		// we set enable view state false so that ctl values are not further loaded
					SetControlValue(ctl, sval);
				}
			}
		}

		protected override object SaveViewState()
		{
			ViewState["err"] = errorDisplay;
			ViewState["ob"] = objectBound;

			bool saveVals = this.IsViewOnly;
			ViewState["vals"] = saveVals;
			if (saveVals)	// save the values in readonly mode
			{
				//PrepareControlsContent();
				ViewState["ob"] = objectBound;
				foreach (DictionaryEntry entry in this.inputCtls)
				{
					string subItem = (string)entry.Key;
					WebControl ctl = entry.Value as WebControl;
					ctl.EnableViewState = false;	// don't save view state, because we manually save values
					string sval = GetControlValue(ctl);
					ViewState["v_" + subItem] = sval;
				}
			}

			return base.SaveViewState ();
		}

		private void obTextBox_ValueSet(object sender, EventArgs e)
		{
			this.Text = obTextBox.Text;
		}

		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.WebForms.SourceClassNamesConverter))
		]
		public string SourceClassName
		{
			get	{ return sourceClassName; }
			set	{ sourceClassName = value; }
		}

		/// <summary>
		/// Source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public object SourceObject
		{
			get	{	return sourceObject;	}
			set	
			{	
				sourceObject = value; 
				// once an object is bound, set it as object bound
				// so that the control won't be disabled
				objectBound = !disableBinding && sourceObject != null && sourceMember != null;
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.ClassMemberConverter))
		]
		public string SourceMemberName
		{
			get	{ return sourceMember; }
			set
			{ 
				sourceMember = value; 
			}
		}

		public Type GetDataType()
		{
			if (sourceObject != null)
				return ReflectionHelper.GetMemberType(sourceObject, sourceMember);
			else
				return ReflectionHelper.GetMemberType(Type.GetType(sourceClassName), sourceMember);
		}

		public object GetValue()
		{
			return Convert.ChangeType(this.Text, GetDataType());
		}

		[DefaultValue(false)]
		public bool DisableBinding
		{
			get
			{
				return disableBinding;
			}
			set
			{
				disableBinding = value;
			}
		}
		#endregion

	}
}
