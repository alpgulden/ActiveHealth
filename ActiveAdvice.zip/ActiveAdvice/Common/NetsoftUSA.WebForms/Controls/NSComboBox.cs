using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;


namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NetsoftUSA.WebForms.IDataBoundControl implementer for a combobox type
	/// UI control.  Validation and Formatting functionalities are abstracted 
	/// from this control.
	/// </summary>
	[ToolboxData("<{0}:NSComboBox runat=server></{0}:NSComboBox>"),
	System.ComponentModel.Design.Serialization.DesignerSerializer(
		typeof(NetsoftUSA.WebForms.NSComboBoxCodeSer), 
		typeof(System.ComponentModel.Design.Serialization.CodeDomSerializer))]
	public class NSComboBox : System.Web.UI.WebControls.DropDownList, IDataBoundControl, INamingContainer
	{
		#region private members
		private string dataSourceName;	// actual source dataset name
		private NetsoftUSA.DataLayer.DCBase dataSource = null;	// actual source data component
		private string dataMember;	// in the form of Table.Field
		private string dataTable;	// parsed from dataMember
		private string dataField;	// parsed from dataMember

		private string errorDisplay;	// if this is not null, it will be displayed when rendering
		private string errorLongDisplay;	// if this is not null, it will be displayed in tooltip when rendering

		private DataRowView rowView = null;	// Row view to use, if null, use data comp's current row view
		private string selVal = "";
		private bool useSelectedValue = true;
		private bool allowNonExistantComboItems = false;	// if an item doesn't exist, it's added

		//private NSLabel errorLabel;
		#endregion

		public NSComboBox()
		{
			/*errorLabel = new NSLabel();
			errorLabel.ForeColor = System.Drawing.Color.Red;
			*/
		}

		#region Private members
		/// <summary>
		/// Use datacomponent's GetPossibleValues to create combo data
		/// </summary>
		private void FillCombo(DataRowView rowView)
		{
			//string selVal = this.SelectedValue;
			if (rowView != null)
			{
				DataSet ds = dataSource.CreateDataSetForPossibleValues(rowView, dataField);
				this.DataSource = ds.Tables[0].DefaultView;
				this.DataValueField = "Value";
				this.DataTextField = "Text";
				this.DataBind();

				DataTable table = DataSourceObject.GetMainDataSet().Tables[dataTable];
				DataColumn col = table.Columns[dataField];
				if (col.AllowDBNull || selVal == "")
					this.Items.Insert(0, new ListItem("", ""));

				ListItem li = this.Items.FindByValue(selVal);

				if (li == null)
					if (allowNonExistantComboItems)
					{
						li = new ListItem(selVal);
						this.Items.Add(li);
					}

				this.SelectedIndex = this.Items.IndexOf(li);
			}
		}
		#endregion
		#region IDataBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
			errorDisplay = "";
			errorLongDisplay = "";
			if (dataSource != null)
			{
				if (dataMember != null)
				{
					if ((dataTable != null) && (dataField != null))
					{
						// find out table using the contained main dataset
						DataSet ds = dataSource.GetMainDataSet();
						DataTable table = ds.Tables[dataTable];
						DataColumn col = table.Columns[dataField];
						this.Enabled = true;
						DataRowView rowView = GetCurrentDataRowView();
						if (rowView == null)
							return;
						//try
						//{
						//sDataRow row = table.Rows[rowNum];

						if (Save)
						{	// control to data
							// normay the formatter object will be employed here
							try
							{
								// if null is allowed, set null for empty string
								//if (selVal.Length > 0)

								if (useSelectedValue)
									selVal = this.SelectedValue;

								if (selVal == "")
									if (!col.AllowDBNull)
									{
										errorDisplay = this.dataField + " can't be null";
										//	rowView[dataField] = DBNull.Value;
										//else
										//throw new System.Data.NoNullAllowedException();
										return;
									}

								dataSource.ParseTableItem(rowView, dataField, selVal);
									
							}
							catch(System.Data.ReadOnlyException)
							{
								// ignore
							}
							catch(System.Data.NoNullAllowedException noNull)
							{
								errorDisplay = this.dataField + " can't be null";
								((BasePage)Page).RaisePageException(noNull);
							}
							catch(System.ArgumentException argEx)
							{
								errorDisplay = "Invalid entry";
								((BasePage)Page).RaisePageException(argEx);
							}
							catch(Exception ex)
							{
								errorDisplay = "???"; //ex.Message;
								errorLongDisplay = ex.Message;
								((BasePage)Page).RaisePageException(ex);
							}

							// If no error occured handle custom validation
							if (errorDisplay == "")
							{
								try
								{
									dataSource.ValidateTableItem(rowView, dataField);
								}
								catch(ValidationException valEx)
								{
									errorDisplay = valEx.Message;
									errorLongDisplay = valEx.LongMessage;
									((BasePage)Page).RaisePageException(valEx);
								}
								catch(Exception ex)
								{
									errorDisplay = "???"; //ex.Message;
									errorLongDisplay = ex.Message;
									((BasePage)Page).RaisePageException(ex);
								}
							}
						}
						else
						{	// data to control
							// normay the formatter object will be employed here
							try
							{
								//if (table.PrimaryKey.Length > 0)
								//	if (table.PrimaryKey[0] == col)
								//		this.Enabled = false;	// This is a primary key
									
								selVal = dataSource.FormatTableItem(rowView, dataField, true).Split('-')[0];
								useSelectedValue = false;
								if (selVal == "")
									if (!col.AllowDBNull)
									{
										//errorDisplay = "*";
										throw new System.Data.NoNullAllowedException ("*");
									}
							}
							catch(Exception ex)
							{
								errorDisplay = "???"; //ex.Message;
								errorLongDisplay = ex.Message;
								//this.Enabled = false;
								((BasePage)Page).RaisePageException(ex);
							}

							DataRowView rv = GetCurrentDataRowView();
							if (rv != null)
								FillCombo(rv);
						}
						/*
						}
						catch(System.Data.NoNullAllowedException noNull)
						{
							throw noNull;
						}
						catch(System.ArgumentException argEx)
						{
							throw argEx;
						}
						catch(Exception)
						{
							this.Enabled = false;
						}*/
					}
				}
			}
		}

		public DCBase GetDataSource()
		{
			return dataSource;
		}

		public string GetDataMember()
		{
			return dataMember;
		}

		public void SetDataSource(DCBase dc)
		{
			dataSource = dc;
		}

		public void SetDataMember(string dm)
		{
			DataMemberName = dm;
		}

		#endregion

		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataSourceConverter))
		]
		public string DataSourceName
		{
			get
			{
				return dataSourceName;
			}
			set
			{
				dataSourceName = value;

				//!!! add code to set dataSource object
			}
		}

		/// <summary>
		/// Data source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public NetsoftUSA.DataLayer.DCBase DataSourceObject
		{
			get
			{
				return dataSource;
			}
			set
			{
				dataSource = value;		// code serializer generated code calls this.
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataTableAndItemConverter))
		]
		public string DataMemberName
		{
			get
			{
				return dataMember;
			}
			set
			{
				dataMember = value;
				dataTable = null;
				dataField = null;

				if (dataMember != null)
				{
					string[] memberTerms = dataMember.Split('.');
					if (memberTerms.Length == 2)
					{
						dataTable = memberTerms[0];
						dataField = memberTerms[1];
					}
					else
					{
						if (dataMember != "")
						{
							dataMember = null;
							throw new Exception("This type of data member not handled yet!");
						}
					}
				}
			}
		}

		/// <summary>
		/// Forces the textbox to use the specifed rowView instead of 
		/// getting current rowview from datacomponent.
		/// </summary>
		/// <param name="rowView"></param>
		public void SetCurrentDataRowView(DataRowView rowView)
		{
			this.rowView = rowView;
		}

		public DataRowView GetCurrentDataRowView()
		{
			if (this.rowView == null)
			{
				if (dataSource != null)
					return dataSource.GetCurrentDataRowView(dataTable);
				else
					return null;
			}
			else
				return rowView;
		}

		[DefaultValue(false)]
		public bool AllowNonExistantComboItems
		{
			get { return allowNonExistantComboItems; }
			set { allowNonExistantComboItems = value; }
		}

		public string GetValText()
		{
			return this.SelectedValue;
		}

		#endregion
	
		protected override void Render(HtmlTextWriter writer)
		{
			int oldSelIndex = this.SelectedIndex;
			bool oldEnabled = this.Enabled;

			bool render = true;
			if (dataSource != null && dataTable != null)
				if (!dataSource.IsValidRowPos(dataTable))
					render = false;
			if (render)
			{
				base.Render (writer);
				if (errorDisplay != null)
					if (errorDisplay.Length > 0)
					{
						NSLabel errorLabel = new NSLabel();
						errorLabel.ForeColor = System.Drawing.Color.Red;
						errorLabel.Text = errorDisplay;
						errorLabel.RenderControl(writer);
						//writer.Write("<SPAN fontcolor=red> " + errorDisplay + "</SPAN>");
					}
			}
			else
			{
				this.SelectedIndex = -1;
				this.Enabled = false;
				base.Render (writer);
			}

			this.SelectedIndex = oldSelIndex;
			this.Enabled = oldEnabled;
		}

		/*
		[Browsable(true), 
		DesignerSerializationVisibility(DesignerSerializationVisibility.Content),
		]
		public NSLabel ErrorLabel
		{
			get
			{
				return errorLabel;
			}
		}*/

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			//DataRowView rv = GetCurrentDataRowView();
			//if (rv != null)
			//	FillCombo(rv);
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			errorDisplay = (string)ViewState["err"];
		}

		protected override object SaveViewState()
		{
			ViewState["err"] = errorDisplay;

			return base.SaveViewState ();
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);

			if (Page.IsPostBack)
			{
				selVal = this.SelectedValue;
			}
		}
	}
}
