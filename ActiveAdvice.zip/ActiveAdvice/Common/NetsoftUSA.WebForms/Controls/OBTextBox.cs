using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Reflection;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NetsoftUSA.WebForms.IObjectBoundControl implementer for a textbox type
	/// UI control.  Validation and Formatting functionalities are abstracted 
	/// from this control.
	/// </summary>
	[DefaultProperty("Text"), 
		ToolboxData("<{0}:OBTextBox runat=server></{0}:OBTextBox>")
	]
	public class OBTextBox : System.Web.UI.WebControls.TextBox, IObjectBoundControl, IClientValidatableMarker, INamingContainer, IControlGroupProvider
	{
		#region Events
		public event EventHandler ValueSet;
		#endregion

		#region private members
		private string sourceClassName;	// source object's class type to be used in design time
		private Type type = null;
		private object sourceObject = null;	// actual source object
		private string sourceMember;		// source member of the source object
		private bool disablePK = true;		// disable if the columns is primary key
		private bool usePickPage = true;
		private bool useDBType = true;		// use DBType attribute declared on the source member
		private bool disableBinding = false;	// disable data binding to NSDataComps
		private bool autoSizeWidth = false;		// automatically size the width using the maxlen

		private string errorDisplay;	// if this is not null, it will be displayed when rendering
		private string errorLongDisplay;	// if this is not null, it will be displayed in tooltip when rendering
		//private NSLabel errorLabel;

		private bool objectBound = false;
		private string pickPage = null;
		private WindowOpener pickWindow;
		private bool dropDownButton = false;
		private string dropDownScript = null;
		private bool dropDownOnMouseOver = false;
		private string customDropDownControl = null;
		PropertyInfo pi = null;
		private bool pk = false;		// detected from type type.member TableMappingAttribute
		private string clientFormatterScript=null;
		private string lostFocusScript = null;

		private bool clientVisible = true;		// is visible at the client

		private bool emptyInBlankForm = true;	// must appear as empty if BasePage.BlankForm = true
		private bool noUpdateIfReadOnly = true;	// if readonly, do not update the bound member
		private bool viewOnlyMode = false;		// display this textbox in viewonly mode, whatever the class binding and page viewonly properties are

		// per-field security
		private bool preventAccessToChange = false;
		private bool preventAccessToSee = false;
		private bool preventAccessToRead = false;

		// global css classes
		public static string CssClassForReadOnly = "";
		public static string CssClassEditable = "";

		public static string OnChangeScript = null;

		private string controlGroup = "";

		#endregion

		#region Constructors

		public OBTextBox() : base()
		{
			/*errorLabel = new NSLabel();
			errorLabel.ForeColor = System.Drawing.Color.Red;
			*/
		}
		#endregion

		#region IObjectBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
			if (disableBinding)
				return;

			errorDisplay = "";
			errorLongDisplay = "";
			if (sourceObject != null && sourceMember != null)
			{
				if (pk && disablePK)
					this.Enabled = false;	// This is a primary key

				if (Save)		// Save = true;
				{	// control to object
					if (!(this.ReadOnly && this.noUpdateIfReadOnly))
					{
						try
						{
							// if null is allowed, set null for empty string
							//if (sourceMember == "Fmt_BalloonAmount")
							//	Debug.WriteLine("a");
							ControlTypeAttribute.SetMemberValueFromString(sourceObject, pi, this.Text);
							//ReflectionHelper.SetMemberValueFromString(sourceObject, sourceMember, this.Text);
						}
						catch(System.ArgumentException argEx)
						{
							errorDisplay = "Invalid entry";
							((BasePage)Page).RaisePageException(argEx);
						}
						catch(Exception ex)
						{
							errorDisplay = "???"; //ex.Message;
							errorLongDisplay = ex.Message;
							((BasePage)Page).RaisePageException(ex);
						}

						/*

						// If no error occured handle custom validation
						if (errorDisplay == "")
						{
							try
							{
								dataSource.ValidateTableItem(rowView, dataField);
							}
							catch(ValidationException valEx)
							{
								errorDisplay = valEx.Message;
								errorLongDisplay = valEx.LongMessage;
								((BasePage)Page).RaisePageException(valEx);
							}
							catch(Exception ex)
							{
								errorDisplay = "???"; //ex.Message;
								errorLongDisplay = ex.Message;
								((BasePage)Page).RaisePageException(ex);
							}
						}
						*/
					}
				}
				else	// Save = false;
				{	
					// data to object
					try
					{
						this.Text = GetMemberValueAsString();
						OnValueSet();
					}
					catch(Exception ex)
					{
						errorDisplay = "???"; //ex.Message;
						errorLongDisplay = ex.Message;
						((BasePage)Page).RaisePageException(ex);
					}
				}
			}
		}

		private string GetMemberValueAsString()
		{
			if (this.emptyInBlankForm)
				if (((BasePage)Page).BlankForm)
					if (!this.IsViewOnly)
						return "";

			return ControlTypeAttribute.GetMemberValueAsString(sourceObject, pi);
			//return ReflectionHelper.GetMemberValueAsString(sourceObject, sourceMember);
		}

		public object GetSourceObject()
		{
			return sourceObject;
		}

		public string GetSourceObjectMember()
		{
			return sourceMember;
		}

		public void SetSourceObject(object obj)
		{
			SourceObject = obj;
		}

		public void SetSourceObjectMember(string om)
		{
			SourceMemberName = om;
		}

		[Browsable(false)]
		public bool IsReadOnly
		{ 
			get { return this.ReadOnly;} 
			set { this.ReadOnly = value; }
		}

		[Browsable(false)]
		public bool IsEnabled
		{ 
			get { return this.Enabled; } 
			set { this.Enabled = value; }
		}

		#endregion
		
		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
			Browsable(true),
			TypeConverter(typeof(NetsoftUSA.WebForms.SourceClassNamesConverter))
		]
		public string SourceClassName
		{
			get	{ return sourceClassName; }
			set	{ sourceClassName = value; }
		}

		/// <summary>
		/// Source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public object SourceObject
		{
			get	{	return sourceObject;	}
			set	
			{	
				sourceObject = value; 
				// once an object is bound, set it as object bound
				// so that the control won't be disabled
				objectBound = !disableBinding && sourceObject != null && sourceMember != null;
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
			Browsable(true),
			TypeConverter(typeof(NetsoftUSA.DataLayer.ClassMemberConverter))
		]
		public string SourceMemberName
		{
			get	{ return sourceMember; }
			set
			{ 
				sourceMember = value; 
				
			}
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);

			if (sourceMember != null)
			{
				try
				{
					type = Type.GetType(sourceClassName);
					pi = type.GetProperty(sourceMember);
				}
				catch
				{
				}
			}
		}


		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);
			pickPage = null;
			pk = false;
			if (sourceMember != null)
			{
				if (type != null)
				{
					if (TableMappingAttribute.GetPKMemberFromClass(type) == sourceMember)
						pk = true;

					//pi = type.GetProperty(sourceMember);
					if (pi != null)
					{
						PickPageAttribute pickPageAttrib = PickPageAttribute.GetFromMember(pi);
						if (pickPageAttrib != null)
							pickPage = pickPageAttrib.Page;

						if (useDBType)
						{
							DBTypeAttribute dbTypeAttrib = DBTypeAttribute.GetFromMember(pi);
							if (dbTypeAttrib != null)
							{
								if (dbTypeAttrib.Length != 0)
									this.MaxLength = dbTypeAttrib.Length;
							}
						}

						ControlTypeAttribute ctlTypeAttrib = ControlTypeAttribute.GetFromProp(pi, true);
						if (ctlTypeAttrib != null)
						{
							this.MaxLength = ctlTypeAttrib.MaxLength;

							if (ctlTypeAttrib.ClientFormatter != null)
								clientFormatterScript = ctlTypeAttrib.ClientFormatter;

							int accessLevel = ((BasePage)Page).AccessLevel;
							if (accessLevel < ctlTypeAttrib.MinAccessToChange)
								preventAccessToChange = true;
							if (accessLevel < ctlTypeAttrib.MinAccessToSee)
								preventAccessToSee = true;
							if (accessLevel < ctlTypeAttrib.MinAccessToRead)
								preventAccessToRead = true;

						}
					}

				}

			}

			if (autoSizeWidth)
			{
				int width = this.MaxLength * 8;
				if (width < 8)
					width = 8;
				this.Width = Unit.Pixel(width);
			}

		}


		// This function gets only the value portion of the text.
		// For example 2-Question  will return 2
		public string GetValText()
		{
			string[] terms = Text.Split('-');
			if (terms[0].Length == 0)
				return Text;
			else
				return terms[0];
		}

		public Type GetDataType()
		{
			if (sourceObject != null)
				return ReflectionHelper.GetMemberType(sourceObject, sourceMember);
			else
				return ReflectionHelper.GetMemberType(Type.GetType(sourceClassName), sourceMember);
		}

		public object GetValue()
		{
			return Convert.ChangeType(GetValText(), GetDataType());
		}

		[DefaultValue(true)]
		public bool UsePickPage
		{
			get
			{
				return usePickPage;
			}
			set
			{
				usePickPage = value;
			}
		}

		[DefaultValue(false)]
		[Category("NetsoftUSA.WebForms Custom DropDown")]
		public bool DropDownButton
		{
			get
			{
				return dropDownButton;
			}
			set
			{
				dropDownButton = value;
			}
		}

		[Category("NetsoftUSA.WebForms Custom DropDown")]
		public string DropDownScript
		{
			get
			{
				return dropDownScript;
			}
			set
			{
				dropDownScript = value;
			}
		}

		[Category("NetsoftUSA.WebForms Custom DropDown")]
		[DefaultValue(false)]
		public bool DropDownOnMouseOver
		{
			get
			{
				return dropDownOnMouseOver;
			}
			set
			{
				dropDownOnMouseOver = value;
			}
		}

		[Category("NetsoftUSA.WebForms Custom DropDown")]
		[TypeConverter(typeof(CustomDropDownTypeConverter))]
		public string CustomDropDownControl
		{
			get
			{
				return customDropDownControl;
			}
			set
			{
				customDropDownControl = value;
			}
		}

		[DefaultValue(true)]
		public bool UseDBType
		{
			get
			{
				return useDBType;
			}
			set
			{
				useDBType = value;
			}
		}

		[DefaultValue(false)]
		public bool DisableBinding
		{
			get
			{
				return disableBinding;
			}
			set
			{
				disableBinding = value;
			}
		}

		[DefaultValue(false)]
		public bool AutoSizeWidth
		{
			get
			{
				return autoSizeWidth;
			}
			set
			{
				autoSizeWidth = value;
			}
		}

		[DefaultValue(true)]
		public bool DisablePK
		{
			get
			{
				return disablePK;
			}
			set
			{
				disablePK = value;
			}
		}

		#endregion
	
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);	

			bool designMode = this.Site != null && this.Site.DesignMode;
			if (!designMode)
				if (usePickPage)
				{
					if (pickPage != null)
					{
						pickWindow = new WindowOpener();
						pickWindow.ID = this.ClientID + "_PickWindow";
						pickWindow.WindowName = pickWindow.ID;
						pickWindow.NavigateURL = pickPage;
						pickWindow.ToolBar = false;
						pickWindow.MenuBar = false;
						pickWindow.AddressBar = false;
						pickWindow.LinksBar = false;
						pickWindow.PickTargetCtl = this;
						//pickWindow.PickSource = "NSDataGrid1";
						pickWindow.Visible = true;
						pickWindow.Text = "...";
						pickWindow.PrepareForRender(this.Page);
					}
				}

			string onBlur = null;
			if (lostFocusScript != null)
			{
				onBlur += lostFocusScript; // String.Format("this.value=" + clientFormatterScript, "this.value");
			}
			if (clientFormatterScript != null)
			{
				if (onBlur != null)
					onBlur += ";";
					onBlur += "this.value=" + clientFormatterScript; // String.Format("this.value=" + clientFormatterScript, "this.value");
			}
			

			if (onBlur != null)
				this.Attributes["OnBlur"] = onBlur;

			if (dropDownButton)
			{
				if (customDropDownControl != null)
				{
					// a custom dropdown is specified on the control
					CustomDropDown custDD = this.Page.FindControl(customDropDownControl) as CustomDropDown;
					if (custDD != null)
					{
						dropDownScript = custDD.OpenDropDownScript(this);
					}
				}
				/*else		// detect custom control from the attribute declared on source member
				{
					string custDDClass = CustomDropDownAttribute.GetCustomDropDown(mi);
					if (custDDClass != null)
					{
						// a custom dropdown is specified on the bound source member
						string instanceName = "custDD_" + custDDClass.Replace('.', '_');
						CustomDropDown custDD = this.Page.FindControl(instanceName) as CustomDropDown;
						if (custDD == null)
						{
							custDD = ((BasePage)this.Page).LoadCustomControl(instanceName, custDDClass) as CustomDropDown;
						}
						dropDownScript = custDD.OpenDropDownScript(this);
					}
				}*/
			}


			this.Attributes["onchange"] = "if (typeof(OBTextBox_OnChange) == 'function') OBTextBox_OnChange('" + this.ClientID + "');"; 

			if (!designMode)
				if (!this.clientVisible)
					this.Style["Display"] = "none";
		}

		private void InternalRender(HtmlTextWriter writer)
		{
			bool origReadOnly = this.ReadOnly;
			bool origVisible = this.Visible;
			TextBoxMode origtextmode = this.TextMode;

			if (preventAccessToChange)
				this.ReadOnly = true;
			if (preventAccessToSee)
				this.Visible = false;
			if (preventAccessToRead)
				this.TextMode = TextBoxMode.Password;

			if (this.ReadOnly)
				this.CssClass = OBTextBox.CssClassForReadOnly;
			else
				this.CssClass = OBTextBox.CssClassEditable;

			base.Render (writer);

			if (this.dropDownButton)
			{
				Image img = new Image();
				img.ImageUrl = "Images/dropdown.gif";
				string dropDownEvent = null;
				if (dropDownOnMouseOver)
					dropDownEvent = "onMouseOver";
				else
					dropDownEvent = "onClick";
				img.Attributes[dropDownEvent] = dropDownScript;
				img.Visible = this.Visible;
				img.RenderControl(writer);
			}

			this.ReadOnly = origReadOnly;
			this.Visible = origVisible;
			this.TextMode = origtextmode;
			this.CssClass = "";
		}

		public bool IsViewOnly
		{
			get
			{
				if (this.viewOnlyMode)
					return true;
				if (((BasePage)Page).IsViewOnly)
					return true;
				return ((BasePage)Page).ClassBindings.GetViewOnly(type);
			}
		}

		protected override void Render(HtmlTextWriter writer)
		{
			//if (this.ID == "DealerID_CompanyName")
			//	Debug.WriteLine("hi");
			string oldText = this.Text;
			bool oldEnabled = this.Enabled;
			if (this.Site != null)
				if (this.Site.DesignMode)
				{
					this.Text = sourceMember;
					InternalRender(writer);
					this.Text = oldText;
					return;
				}

			if (this.IsViewOnly)
			{
				string style = null;
				if (!this.clientVisible)
					style = "style='display:none' ";
				if (this.preventAccessToRead)
					writer.Write("<span {0}class='{1}'>*</span>", style, this.CssClass);
				else
					if (!preventAccessToSee)
						writer.Write("<span {0}class='{1}'>{2}</span>", style, this.CssClass, this.Text);
				return;
			}

			if (objectBound || disableBinding)
			{
				InternalRender(writer);


				if (pickWindow != null)
					pickWindow.RenderControl(writer);

				if (errorDisplay != null)
					if (errorDisplay.Length > 0)
					{
						NSLabel errorLabel = new NSLabel();
						errorLabel.ForeColor = System.Drawing.Color.Red;
						errorLabel.Text = errorDisplay;

						if (errorLongDisplay != null)
							if (errorLongDisplay.Length > 0)
							{
								errorLabel.ToolTip = errorLongDisplay;
								errorLabel.Font.Underline = true;
							}
						errorLabel.RenderControl(writer);
					}

				/*
				if (dbTypeAttrib != null)
				{
					if (!dbTypeAttrib.Nullable)
					{
						RequiredFieldValidator rfv = new RequiredFieldValidator();
						rfv.ControlToValidate = this.ID;
						rfv.ErrorMessage = String.Format("'{0}' can't be null.", FieldDescriptionAttribute.GetDescription(mi, true));
						rfv.RenderControl(writer);
					}
				}
				*/

				/*  doesn't work!  we can't add to controls.
				Type dt = GetDataType();
				if (dt == typeof(int))
				{
					CompareValidator vld = new CompareValidator();
					vld.ControlToValidate = ClientID;
					vld.Type = ValidationDataType.Integer;
					vld.Operator = ValidationCompareOperator.DataTypeCheck;
					vld.ErrorMessage = "Invalid number";
					//this.Controls.Add(vld);	
					vld.RenderControl(writer);
				}
				*/
			}
			else
			{
				this.Text = "";
				this.Enabled = false;
				InternalRender(writer);
			}

			this.Text = oldText;
			this.Enabled = oldEnabled;
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			object[] data = (object[])ViewState["d"];
			errorDisplay = (string)data[0];
			objectBound = (bool)data[1];
			clientVisible = (bool)data[2];
			//errorDisplay = (string)ViewState["err"];
			//objectBound = (bool)ViewState["ob"];
			//clientVisible = (bool)ViewState["vis"];
		}

		protected override object SaveViewState()
		{
			ViewState["d"] = new object[] { errorDisplay, objectBound, clientVisible };
			//ViewState["err"] = errorDisplay;
			//ViewState["ob"] = objectBound;
			//ViewState["vis"] = clientVisible;

			return base.SaveViewState ();
		}

		public override string Text
		{
			get
			{
				return base.Text;
			}
			set
			{
				base.Text = value;
			}
		}

		public string ClientFormatterScript
		{
			get { return this.clientFormatterScript; }
			set { this.clientFormatterScript = value; }
		}

		public string LostFocusScript
		{
			get { return this.lostFocusScript; }
			set { this.lostFocusScript = value; }
		}

		[DefaultValue(true)]
		public bool ClientVisible
		{
			get { return this.clientVisible; }
			set { this.clientVisible = value; }
		}

		[DefaultValue(true)]
		public bool EmptyInBlankForm
		{
			get { return this.emptyInBlankForm; }
			set { this.emptyInBlankForm = value; }
		}

		public virtual void OnValueSet()
		{
			if (ValueSet != null)
				ValueSet(this, new EventArgs());
		}

		[DefaultValue(true)]
		public bool NoUpdateIfReadOnly
		{
			get { return this.noUpdateIfReadOnly; }
			set { this.noUpdateIfReadOnly = value; }
		}

		[DefaultValue(false)]
		public bool ViewOnlyMode
		{
			get { return this.viewOnlyMode; }
			set { this.viewOnlyMode = value; }
		}
		
		#region IControlGroupProvider Members

		/// <summary>
		/// If controlGroup is not specified, the control will inherit it from its parent
		/// </summary>
		[DefaultValue("")]
		public string ControlGroup
		{
			get { return this.controlGroup; }
			set { this.controlGroup = value; }
		}

		#endregion
	}
}
