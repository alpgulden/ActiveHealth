using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for OBCheckBox.
	/// </summary>
	[ToolboxData("<{0}:OBCheckBox runat=server></{0}:OBCheckBox>")]
	public class OBCheckBox : System.Web.UI.WebControls.CheckBox, IObjectBoundControl, INamingContainer
	{
		#region Global
		// global css classes
		public static bool BindTextsToDescriptions = false;
		#endregion

		#region protected members
		private string sourceClassName;	// source object's class type to be used in design time
		private Type type = null;
		private object sourceObject = null;	// actual source object
		private string sourceMember;		// source member of the source object
		private bool disableBinding = false;	// disable data binding to NSDataComps

		private string errorDisplay;	// if this is not null, it will be displayed when rendering
		private string errorLongDisplay;	// if this is not null, it will be displayed in tooltip when rendering
		//private NSLabel errorLabel;

		private string formatString = "{0}";		// display as 'fielddescription:'

		private bool objectBound = false;

		#endregion

		#region Constructors
		public OBCheckBox() : base()
		{
			/*errorLabel = new NSLabel();
			errorLabel.ForeColor = System.Drawing.Color.Red;
			*/
		}
		#endregion

		#region IObjectBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public virtual void UpdateData(bool Save)
		{
			if (disableBinding)
				return;

			errorDisplay = "";
			errorLongDisplay = "";
			if (sourceObject != null && sourceMember != null)
			{
				if (!Save)
				{
					try
					{
						object val = ReflectionHelper.GetMemberValue(sourceObject, sourceMember);
						this.Checked = Convert.ToBoolean(val);

						if (((BasePage)Page).CheckBoxDescriptionsOn)
						{
							string s = null;
							if (type != null)
								s = FieldDescriptionAttribute.GetDescription(type, sourceMember, true);
							if (s == null)
								s = sourceMember;
							
							this.Text = GetFormattedDesc(s);
						}

					}
					catch(System.ArgumentException argEx)
					{
						errorDisplay = "Invalid entry";
						((BasePage)Page).RaisePageException(argEx);
					}
					catch(Exception ex)
					{
						errorDisplay = "???"; //ex.Message;
						errorLongDisplay = ex.Message;
						((BasePage)Page).RaisePageException(ex);
					}

					// If no error occured handle custom validation
					/*if (errorDisplay == "")
					{
						try
						{
							dataSource.ValidateTableItem(rowView, dataField);
						}
						catch(ValidationException valEx)
						{
							errorDisplay = valEx.Message;
							errorLongDisplay = valEx.LongMessage;
							((BasePage)Page).RaisePageException(valEx);
						}
						catch(Exception ex)
						{
							errorDisplay = "???"; //ex.Message;
							errorLongDisplay = ex.Message;
							((BasePage)Page).RaisePageException(ex);
						}
					}*/
				}
				else
				{
					try
					{
						ReflectionHelper.SetMemberValue(sourceObject, sourceMember, this.Checked);
					}
					catch(Exception ex)
					{
						//this.Enabled = false;
						errorDisplay = "???"; //ex.Message;
						errorLongDisplay = ex.Message;
						((BasePage)Page).RaisePageException(ex);
					}
				}
			}
		}

		private string GetFormattedDesc(string s)
		{
			if (s == null)
				s = "";
			return ((BasePage)this.Page).Language.Translate(true, formatString, s);
		}

		public object GetSourceObject()
		{
			return sourceObject;
		}

		public string GetSourceObjectMember()
		{
			return sourceMember;
		}

		public void SetSourceObject(object obj)
		{
			SourceObject = obj;
		}

		public void SetSourceObjectMember(string om)
		{
			SourceMemberName = om;
		}

		[Browsable(false)]
		public bool IsReadOnly
		{ 
			get { return !this.Enabled; } 
			set { this.Enabled = !value; }
		}

		[Browsable(false)]
		public bool IsEnabled
		{ 
			get { return this.Enabled; } 
			set { this.Enabled = value; }
		}

		#endregion

		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.WebForms.SourceClassNamesConverter))
		]
		public string SourceClassName
		{
			get	{ return sourceClassName; }
			set	{ sourceClassName = value; }
		}

		/// <summary>
		/// Source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public object SourceObject
		{
			get	{	return sourceObject;	}
			set	
			{	
				sourceObject = value; 
				// once an object is bound, set it as object bound
				// so that the control won't be disabled
				objectBound = !disableBinding && sourceObject != null && sourceMember != null;
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.ClassMemberConverter))
		]
		public string SourceMemberName
		{
			get	{ return sourceMember; }
			set
			{ 
				sourceMember = value; 
			}
		}

		public string GetValText()
		{
			if (this.Checked)
				return "1";
			else
				return "0";
		}

		public Type GetDataType()
		{
			if (sourceObject != null)
				return ReflectionHelper.GetMemberType(sourceObject, sourceMember);
			else
				return ReflectionHelper.GetMemberType(Type.GetType(sourceClassName), sourceMember);
		}

		[DefaultValue(false)]
		public bool DisableBinding
		{
			get
			{
				return disableBinding;
			}
			set
			{
				disableBinding = value;
			}
		}

		[Editor(typeof(LangMessageEditor), typeof(System.Drawing.Design.UITypeEditor))]
		[Category("NetsoftUSA.WebForms Binding")]
		[DefaultValue("{0}")]
		public string FormatString
		{
			get
			{
				return formatString;
			}
			set
			{
				if (value == "" || value == null)
					formatString = "{0}";
				else
					formatString = value;
			}
		}

		#endregion

		public bool IsViewOnly
		{
			get
			{
				if (((BasePage)Page).IsViewOnly)
					return true;
				return ((BasePage)Page).ClassBindings.GetViewOnly(type);
			}
		}

		protected override void Render(HtmlTextWriter writer)
		{
			bool oldChecked = this.Checked;
			bool oldEnabled = this.Enabled;

			if (this.IsViewOnly)
			{
				//writer.Write("<span class='{0}'>{1}</span>", this.CssClass, this.Checked.ToString());
				//return;
				this.Enabled = false;
			}

			if (objectBound)
			{
				base.Render (writer);
				if (errorDisplay != null)
					if (errorDisplay.Length > 0)
					{
						NSLabel errorLabel = new NSLabel();
						errorLabel.ForeColor = System.Drawing.Color.Red;
						errorLabel.Text = errorDisplay;
						errorLabel.RenderControl(writer);
					}
			}
			else
			{
				this.Checked = false;
				this.Enabled = false;
				base.Render (writer);
			}

			this.Checked = oldChecked;
			this.Enabled = oldEnabled;
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			errorDisplay = (string)ViewState["err"];
			objectBound = (bool)ViewState["ob"];
		}

		protected override object SaveViewState()
		{
			ViewState["err"] = errorDisplay;
			ViewState["ob"] = objectBound;

			return base.SaveViewState ();
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);

			if (sourceMember != null)
			{
				try
				{
					type = Type.GetType(sourceClassName);
				}
				catch
				{
				}
			}
		}

	}
}
