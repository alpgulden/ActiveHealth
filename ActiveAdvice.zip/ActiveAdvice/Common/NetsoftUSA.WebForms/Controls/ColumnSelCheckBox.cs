using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for ColumnSelCheckBox.
	/// </summary>
	[ToolboxData("<{0}:ColumnSelCheckBox runat=server></{0}:ColumnSelCheckBox>")
	]
	internal class ColumnSelCheckBox : NSCheckBox
	{

		internal NSDataGrid parentGrid = null;	// May be set by the grid to access column selection info for the bound column
		// instead of updating the field's content

		public ColumnSelCheckBox() : base()
		{
		}

		public override void UpdateData(bool Save)
		{
			if (dataSource != null)
			{
				if (dataMember != null)
				{
					if ((dataTable != null) && (dataField != null))
					{
						if (!Save)
							this.Checked = parentGrid.getColumnCheck(dataField);
						else
							parentGrid.setColumnCheck(dataField, this.Checked);
					}
				}
			}
		}
	}
}
