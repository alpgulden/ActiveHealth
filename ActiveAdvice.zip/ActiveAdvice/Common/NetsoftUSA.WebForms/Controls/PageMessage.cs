using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Collections;

namespace NetsoftUSA.WebForms
{

	public enum EnumPageMessageType
	{
		// main messages
		Info = 0,
		Warning = 1,
		Error = 2,
		// secondary messages
		AddInfo = 3,			// collected and displayed as a list of messages
		AddWarning = 4,			// collected and displayed as a list of messages
		AddError = 5			// collected and displayed as a list of messages
	}

	/// <summary>
	/// Summary description for PageMessage.
	/// </summary>
	[DefaultProperty("Text"), 
	ToolboxData("<{0}:PageMessage runat=server></{0}:PageMessage>")
	]
	public class PageMessage : System.Web.UI.WebControls.Label
	{
		// used by all application
		public static string CssClassInfoAll = "";
		public static string CssClassWarningAll = "";
		public static string CssClassErrorAll = "";

		// used by this instance
		private string cssClassInfo = null;
		private string cssClassWarning = null;
		private string cssClassError = null;

		private PageSecondaryMessageCollection messages;
		
		private EnumPageMessageType messageType; // = EnumPageMessageType.Info;

		internal string getValidCss(string css, string cssAll)
		{
			if (css != null)
				if (css != "")
				{
					return css;
				}
			return cssAll;
		}

		public PageSecondaryMessageCollection Messages
		{
			get
			{
				if (this.messages == null)
					this.messages = new PageSecondaryMessageCollection();
				return this.messages;
			}
		}

		internal string getMessageCssClass(EnumPageMessageType messageType)
		{
			if (this.Text == "")
			{
				return null;
			}
			return getMessageCssClassForType(messageType);
		}

		internal string getMessageCssClassForType(EnumPageMessageType messageType)
		{
			switch(messageType)
			{
				case EnumPageMessageType.Info:
					return getValidCss(this.cssClassInfo, CssClassInfoAll);
				case EnumPageMessageType.Warning:
					return getValidCss(this.cssClassWarning, CssClassWarningAll);
				case EnumPageMessageType.Error:
					return getValidCss(this.cssClassError, CssClassErrorAll);
			}
			return null;
		}

		internal void setMessageCssClass(EnumPageMessageType messageType)
		{
			CssClass = getMessageCssClass(messageType);
		}

		public PageMessage() : base()
		{
			this.EnableViewState = false;
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);
			BasePage page = (BasePage)this.Page;
			page.SetPageMessageEvent+=new NetsoftUSA.WebForms.BasePage.SetPageMessageEventHandler(page_SetPageMessageEvent);
			page.SetPageLongMessageEvent+=new NetsoftUSA.WebForms.BasePage.SetPageLongMessageEventHandler(page_SetPageLongMessageEvent);
		}


		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);
		}

		private void page_SetPageMessageEvent(object sender, SetPageMessageEventArgs e)
		{
			switch (e.messageType)
			{
				case EnumPageMessageType.AddInfo:
					this.Messages.Add(new PageSecondaryMessage(e.message, EnumPageMessageType.Info));
					return;
				case EnumPageMessageType.AddWarning:
					this.Messages.Add(new PageSecondaryMessage(e.message, EnumPageMessageType.Warning));
					return;
				case EnumPageMessageType.AddError:
					this.Messages.Add(new PageSecondaryMessage(e.message, EnumPageMessageType.Error));
					return;
			}

			this.Text = ((BasePage)this.Page).Language.Translate(e.message);
			this.ToolTip = "";
			this.messageType = e.messageType;
			//this.setMessageCssClass(e.messageType);
		}

		public static string PrepareForPlaneText(string html)
		{
			if (html != null)
			{
				html = html.Replace("<BR>", "\r\n");
				html = html.Replace("<br>", "\r\n");
			}
			return html;
		}

		private void page_SetPageLongMessageEvent(object sender, SetPageMessageEventArgs e)
		{
			this.ToolTip = PrepareForPlaneText(((BasePage)this.Page).Language.Translate(e.message));
		}

		[Category("Appearance")]
		public string CssClassInfo
		{
			get { return cssClassInfo; }
			set 
			{ 
				cssClassInfo = value; 
				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						this.CssClass = getValidCss(this.cssClassInfo, PageMessage.CssClassInfoAll);
					}
			}
		}
		
		[Category("Appearance")]
		public string CssClassWarning
		{
			get { return cssClassWarning; }
			set 
			{ 
				cssClassWarning = value; 
			}
		}

		[Category("Appearance")]
		public string CssClassError
		{
			get { return cssClassError; }
			set 
			{ 
				cssClassError = value; 
			}
		}

		protected override void Render(HtmlTextWriter writer)
		{
			writer.WriteBeginTag("DIV");
			writer.WriteAttribute("CLASS", getMessageCssClass(messageType));
			writer.Write(HtmlTextWriter.TagRightChar);
			base.Render (writer);
			writer.WriteEndTag("DIV");
	
			// display secondary messages
			if (this.messages != null)
			{
				foreach (PageSecondaryMessage msg in messages)
				{
					writer.WriteBeginTag("DIV");
					writer.WriteAttribute("CLASS", getMessageCssClassForType(msg.MessageType));
					writer.Write(HtmlTextWriter.TagRightChar);
					writer.Write(msg.Message);
					writer.WriteEndTag("DIV");
				}
			}

		}
	}

	public class PageSecondaryMessage
	{
		public string Message;
		public EnumPageMessageType MessageType;

		public PageSecondaryMessage(string message, EnumPageMessageType messageType)
		{
			this.Message = message;
			this.MessageType = messageType;
		}
	}

	public class PageSecondaryMessageCollection : CollectionBase
	{
		//[NonSerialized]
		//private CollectionIndexer indexBy_OrganizationTypeID;

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PageSecondaryMessage this[int index]
		{
			get
			{
				return (PageSecondaryMessage)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		
		/// <summary>
		/// Adds message to the collection
		/// </summary>
		public int Add(PageSecondaryMessage msg)
		{
			return this.List.Add(msg);
		}

	}

}
