using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.WebForms;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Automatically determines textbox/combobox/checkbox depending on the data type.
	/// </summary>
	[ToolboxData("<{0}:NSMultiBox runat=server></{0}:NSMultiBox>"),
		System.ComponentModel.Design.Serialization.DesignerSerializer(
			typeof(NetsoftUSA.WebForms.NSMultiBoxCodeSer), 
			typeof(System.ComponentModel.Design.Serialization.CodeDomSerializer))
	]
	public class NSMultiBox : System.Web.UI.WebControls.WebControl, IDataBoundControl, INamingContainer
	{
		#region private members
		private string dataSourceName;	// actual source dataset name
		private NetsoftUSA.DataLayer.DCBase dataSource = null;	// actual source data component
		private string dataMember;	// in the form of Table.Field
		private string dataTable;	// parsed from dataMember
		private string dataField;	// parsed from dataMember

		private DataRowView rowView = null;	// Row view to use, if null, use data comp's current row view

		// Possible types
		NSComboBox nsComboBox = null;
		NSTextBox nsTextBox = null;
		NSCheckBox nsCheckBox = null;
		// dropdown control
		HtmlInputButton comboButton = null;
		NSExpandable nsExp = null;
		BaseDropDown dropDown = null;			// dropdown control
		// IDataBoundControl of one of above
		IDataBoundControl containedDataBound = null;

		#endregion

		public NSMultiBox() : base()
		{
		}

		#region IDataBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
			EnsureChildControls();
			rowView = GetCurrentDataRowView();
			DetermineControlType(rowView);
			if (containedDataBound != null)
			{
				containedDataBound.UpdateData(Save);
			}
		}

		public DCBase GetDataSource()
		{
			return dataSource;
		}

		public string GetDataMember()
		{
			return dataMember;
		}

		public void SetDataSource(DCBase dc)
		{
			dataSource = dc;
		}

		public void SetDataMember(string dm)
		{
			dataMember = dm;
		}

		/// <summary>
		/// Forces the textbox to use the specifed rowView instead of 
		/// getting current rowview from datacomponent.
		/// </summary>
		/// <param name="rowView"></param>
		public void SetCurrentDataRowView(DataRowView rowView)
		{
			this.rowView = rowView;
		}

		public DataRowView GetCurrentDataRowView()
		{
			if (this.rowView == null)
				return dataSource.GetCurrentDataRowView(dataTable);
			else
				return rowView;
		}

		#endregion

		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataSourceConverter))
		]
		public string DataSourceName
		{
			get
			{
				return dataSourceName;
			}
			set
			{
				dataSourceName = value;

				//!!! add code to set dataSource object
			}
		}

		/// <summary>
		/// Data source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public NetsoftUSA.DataLayer.DCBase DataSourceObject
		{
			get
			{
				return dataSource;
			}
			set
			{
				dataSource = value;		// code serializer generated code calls this.
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataTableAndItemConverter))
		]
		public string DataMemberName
		{
			get
			{
				return dataMember;
			}
			set
			{
				dataMember = value;
				dataTable = null;
				dataField = null;

				if (dataMember != null)
				{
					string[] memberTerms = dataMember.Split('.');
					if (memberTerms.Length == 2)
					{
						dataTable = memberTerms[0];
						dataField = memberTerms[1];
					}
					else
					{
						if (dataMember != "")
						{
							dataMember = null;
							throw new Exception("This type of data member not handled yet!");
						}
					}
				}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		protected override void CreateChildControls()
		{
			nsComboBox = new NSComboBox();
			nsComboBox.ID = "CB";
			this.Controls.Add(nsComboBox);
			nsComboBox.CssClass = this.CssClass;

			nsTextBox = new NSTextBox();
			nsTextBox.ID = this.ID + "TB";
			this.Controls.Add(nsTextBox);
			nsTextBox.CssClass = this.CssClass;

			comboButton = new HtmlInputButton();
			comboButton.ID = this.ID + "_ComBut";
			this.Controls.Add(comboButton);
			comboButton.Attributes["class"] = this.CssClass;

			nsExp = new NSExpandable();
			nsExp.ID = this.ID + "_Exp";
			//nsExp.OpenButton = comboButton.ID;
			nsExp.toggleButtonCtl = comboButton;
			nsExp.AutoHide = true;

			dropDown = (BaseDropDown)new DropDownGrid();
			dropDown.ID = this.ID +"_CTL";

			nsExp.Controls.Add(dropDown);

			this.Controls.Add(nsExp);
		}

		private void SetActiveControl(Control ctl)
		{
			nsTextBox.Visible = false;
			nsComboBox.Visible = false;
			nsExp.Visible = false;
			comboButton.Visible = false;
			containedDataBound = (IDataBoundControl)ctl;
			ctl.Visible = true;
		}

		private void DetermineControlType(DataRowView rowView)
		{
        	DataTable table = null;
			
			try
			{
				table = dataSource.GetTable(dataTable);
			}
			catch(Exception ex)
			{
				//if (dataTable == null)
				//{
				// Create empty content.
				nsTextBox.Text = ex.Message;
				SetActiveControl(nsTextBox);
				return;
				//}
			}

			/*
			DataColumn col = null;
			
			try
			{
				col = table.Columns[dataField];
			}
			catch(Exception ex)
			{
				// may be virtual formatted field, just assume textbox
			}*/

			//if (rowView == null)
			//	rowView = new DataRowView

			
			//object[] values =null;
			
			//try
			//{
			//	values = dataSource.GetPossibleValues(rowView, dataField);
			//}
			//catch(Exception ex)
			//{
			//}

			//if (values != null)
			//{
				NSComboStyle comboStyle = dataSource.GetComboStyleForTableItem(rowView, dataField);
			if (comboStyle == NSComboStyle.DropDownList)
			{
				// assume combobox
				SetActiveControl(nsComboBox);
			}
			else
			{
				// assume textbox
				SetActiveControl(nsTextBox);
			}
			/*
			{
					// assume textbox with dropdown grid
					SetActiveControl(nsTextBox);
					comboButton.Visible = true;
					nsExp.Visible = true;
					nsExp.Floating = true;
					dropDown.SetCurrentDataRowView(rowView);
					dropDown.SetDataSource(dataSource);
					dropDown.SetDataMember(dataMember);
					dropDown.PickTargetCtl = nsTextBox;
				}*/
			//}
			//else
			//{
				// assume textbox
			//	SetActiveControl(nsTextBox);
			//}
			containedDataBound.SetCurrentDataRowView(rowView);
			containedDataBound.SetDataSource(dataSource);
			containedDataBound.SetDataMember(dataMember);
		}

		public string Text
		{
			get
			{
				if (this.nsTextBox.Visible)
					return nsTextBox.Text;
				if (this.nsCheckBox.Visible)
					return nsCheckBox.Checked.ToString();
				if (this.nsComboBox.Visible)
					return nsComboBox.SelectedValue;
				return "";
			}
		}

		public string GetValText()
		{
			if (this.nsTextBox.Visible)
				return nsTextBox.GetValText();
			if (this.nsCheckBox.Visible)
				return nsCheckBox.GetValText();
			if (this.nsComboBox.Visible)
				return nsComboBox.GetValText();
			return "";
		}

		#endregion
	}
}
