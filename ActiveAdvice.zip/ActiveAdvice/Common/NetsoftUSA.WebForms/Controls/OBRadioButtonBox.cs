using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Reflection;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NetsoftUSA.WebForms.IDataBoundControl implementer for a combobox type
	/// UI control.  Validation and Formatting functionalities are abstracted 
	/// from this control.
	/// </summary>
	[ToolboxData("<{0}:OBRadioButtonBox runat=server></{0}:OBRadioButtonBox>") /*,
	System.ComponentModel.Design.Serialization.DesignerSerializer(
		typeof(NetsoftUSA.WebForms.OBComboBoxCodeSer), 
		typeof(System.ComponentModel.Design.Serialization.CodeDomSerializer))*/]
	public class OBRadioButtonBox : System.Web.UI.WebControls.RadioButtonList, IObjectBoundControl, INamingContainer, IClientValidatableMarker
	{
		#region private members
		private string sourceClassName;	// source object's class type to be used in design time
		private Type type = null;
		private object sourceObject = null;	// actual source object
		private string sourceMember;		// source member of the source object
		private bool disableBinding = false;	// disable data binding to NSDataComps

		private string errorDisplay;	// if this is not null, it will be displayed when rendering
		private string errorLongDisplay;	// if this is not null, it will be displayed in tooltip when rendering
		//private NSLabel errorLabel;

		private bool objectBound = false;
		private bool allowNonExistantItems = false;	// if an item doesn't exist, it's added

		private string onClickScript = null;		// script to be used for each radio button
		
		#endregion

		public OBRadioButtonBox()
		{
			/*errorLabel = new NSLabel();
			errorLabel.ForeColor = System.Drawing.Color.Red;
			*/
		}

		#region IObjectBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
			if (disableBinding)
				return;

			errorDisplay = "";
			errorLongDisplay = "";
			if (sourceObject != null && sourceMember != null)
			{
				if (Save)		// Save = true;
				{	// control to data
					// normay the formatter object will be employed here
					try
					{
						if (this.Items.Count > 0)
						{
							ReflectionHelper.SetMemberValueFromString(sourceObject, sourceMember, this.SelectedValue);
						}
					}
					catch(System.Data.ReadOnlyException)
					{
						// ignore
					}
					catch(System.ArgumentException argEx)
					{
						errorDisplay = "Invalid entry";
						((BasePage)Page).RaisePageException(argEx);
					}
					catch(Exception ex)
					{
						errorDisplay = "???"; //ex.Message;
						errorLongDisplay = ex.Message;
						((BasePage)Page).RaisePageException(ex);
					}

					/*// If no error occured handle custom validation
					if (errorDisplay == "")
					{
						try
						{
							dataSource.ValidateTableItem(rowView, dataField);
						}
						catch(ValidationException valEx)
						{
							errorDisplay = valEx.Message;
							errorLongDisplay = valEx.LongMessage;
							((BasePage)Page).RaisePageException(valEx);
						}
						catch(Exception ex)
						{
							errorDisplay = "???"; //ex.Message;
							errorLongDisplay = ex.Message;
							((BasePage)Page).RaisePageException(ex);
						}
					}*/
				}
				else
				{	// data to control
					// normay the formatter object will be employed here
					try
					{
						//type = Type.GetType(sourceClassName);
						this.Items.Clear();
						if (type != null)
						{
							MemberInfo mi = null;
							mi = type.GetField(sourceMember);
							
							string sval = ReflectionHelper.GetMemberValueAsString(sourceObject, sourceMember);
							if (sval == null)
								sval = "";
							string pkMember = TableMappingAttribute.GetPKMemberFromClass(type);
							//object pkVal = ReflectionHelper.GetMemberValue(sourceObject, pkMember, true);

							if (mi == null)
								mi = type.GetProperty(sourceMember);
							if (mi != null)
							{
								Array vals = FieldValuesMemberAttribute.GetFieldValues(sourceObject, mi);
								string[] svals = FieldValuesMemberAttribute.GetFormattedFieldValues(sourceObject, mi);

								if (vals != null)
								{
									for (int i = 0; i < vals.GetLength(0); i++)
									{
										string sdesc = svals[i];
										sdesc = ((BasePage)this.Page).Language.Translate(sdesc);
										object val = null;
										if (vals.Rank == 1)
											val = vals.GetValue(i);
										else if (vals.Rank == 2)
											val = vals.GetValue(i, 0);
										this.Items.Add(new ListItem(sdesc, Convert.ToString(val)));
									}
								}

								this.SelectedValue = sval;
							}
						}
					}
					catch(Exception ex)
					{
						errorDisplay = "???"; //ex.Message;
						errorLongDisplay = ex.Message;
						((BasePage)Page).RaisePageException(ex);
					}
				}
			}
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);

			if (sourceMember != null)
			{
				try
				{
					type = Type.GetType(sourceClassName);
				}
				catch
				{
				}
			}
		}

		public override string SelectedValue
		{
			get
			{
				/*string s = "";
				foreach (ListItem li in this.Items)
				{
					if (li.Selected)
					{
						if (s.Length > 0)
							s += ",";
						s += li.Value;
					}
				}
				return s;*/
				return base.SelectedValue;
			}
			set
			{
				ClearSelection();
				if (value == null || value == "")
				{
					return;
				}

				base.SelectedValue = value;
				return;
				/*string[] terms = value.Split(',');
				for (int i = 0; i < terms.Length; i++)
				{
					string sval = terms[i];
					ListItem li = this.Items.FindByValue(sval);
					if (allowNonExistantItems)
						if (li == null)
						{
							li = new ListItem("(" + sval + ")", sval);
							//li = new ListItem(sval, sval);
							this.Items.Add(li);
						}
					if (li != null)
						li.Selected = true;
				}*/
			}
		}


		public object GetSourceObject()
		{
			return sourceObject;
		}

		public string GetSourceObjectMember()
		{
			return sourceMember;
		}

		public void SetSourceObject(object obj)
		{
			SourceObject = obj;
		}

		public void SetSourceObjectMember(string om)
		{
			SourceMemberName = om;
		}

		[Browsable(false)]
		public bool IsReadOnly
		{ 
			get { return !this.Enabled; } 
			set { this.Enabled = !value; }
		}

		[Browsable(false)]
		public bool IsEnabled
		{ 
			get { return this.Enabled; } 
			set { this.Enabled = value; }
		}

		#endregion

		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.WebForms.SourceClassNamesConverter))
		]
		public string SourceClassName
		{
			get	{ return sourceClassName; }
			set	{ sourceClassName = value; }
		}

		/// <summary>
		/// Source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public object SourceObject
		{
			get	{	return sourceObject;	}
			set	
			{	
				sourceObject = value; 
				// once an object is bound, set it as object bound
				// so that the control won't be disabled
				objectBound = !disableBinding && sourceObject != null && sourceMember != null;
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.ClassMemberConverter))
		]
		public string SourceMemberName
		{
			get	{ return sourceMember; }
			set
			{ 
				sourceMember = value; 
			}
		}

		[DefaultValue(false)]
		public bool AllowNonExistantItems
		{
			get { return allowNonExistantItems; }
			set { allowNonExistantItems = value; }
		}

		public string GetValText()
		{
			return this.SelectedValue;
		}

		public Type GetDataType()
		{
			if (sourceObject != null)
				return ReflectionHelper.GetMemberType(sourceObject, sourceMember);
			else
				return ReflectionHelper.GetMemberType(Type.GetType(sourceClassName), sourceMember);
		}

		public object GetValue()
		{
			return Convert.ChangeType(GetValText(), GetDataType());
		}

		[DefaultValue(false)]
		public bool DisableBinding
		{
			get
			{
				return disableBinding;
			}
			set
			{
				disableBinding = value;
			}
		}

		#endregion
	
		public bool IsViewOnly
		{
			get
			{
				if (((BasePage)Page).IsViewOnly)
					return true;
				return ((BasePage)Page).ClassBindings.GetViewOnly(type);
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			this.Attributes["value"] = this.SelectedValue;
		}


		protected override void Render(HtmlTextWriter writer)
		{
			string oldSelVal = this.SelectedValue;
			bool oldEnabled = this.Enabled;

			if (this.Site != null)
				if (this.Site.DesignMode)
				{
					if (!disableBinding && sourceMember != null && sourceMember != "")
					{
						this.Items.Clear();
						this.Items.Add(sourceMember);
						base.Render(writer);
						this.Items.Clear();
						this.SelectedValue = oldSelVal;
						return;
					}
				}

			if (this.IsViewOnly)
			{
				string s = null;
				if (this.SelectedItem != null)
					s = this.SelectedItem.Text;
				writer.Write("<span class='{0}'>{1}</span>", this.CssClass, s);
				return;
			}

			if (objectBound || disableBinding)
			{
				base.Render (writer);
				if (errorDisplay != null)
					if (errorDisplay.Length > 0)
					{
						NSLabel errorLabel = new NSLabel();
						errorLabel.ForeColor = System.Drawing.Color.Red;
						errorLabel.Text = errorDisplay;
						errorLabel.RenderControl(writer);
					}
			}
			else
			{
				this.SelectedValue = "";
				this.Enabled = false;

				for (int i = 0; i < this.Items.Count; i++)
				{
					this.Items[i].Attributes["OnClick"] = this.ClientID + ".value=this.value;" + onClickScript;
					//if (this.onClickScript == null)
					//	this.Items[i].Attributes.Remove("OnClick");
					//else
					//	this.Items[i].Attributes["OnClick"] = onClickScript;
				}

				base.Render (writer);
			}

			this.SelectedValue = oldSelVal;
			this.Enabled = oldEnabled;
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			errorDisplay = (string)ViewState["err"];
			objectBound = (bool)ViewState["ob"];
		}

		protected override object SaveViewState()
		{
			ViewState["err"] = errorDisplay;
			ViewState["ob"] = objectBound;

			return base.SaveViewState ();
		}

		public string OnClickScript
		{
			get { return onClickScript; }
			set { onClickScript = value; }
		}

	}
}
