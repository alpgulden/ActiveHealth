using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for NSLabel.
	/// </summary>
	[DefaultProperty("Text"), 
		ToolboxData("<{0}:NSLabel runat=server></{0}:NSLabel>"),
		System.ComponentModel.Design.Serialization.DesignerSerializer(
		typeof(NetsoftUSA.WebForms.NSLabelCodeSer), 
		typeof(System.ComponentModel.Design.Serialization.CodeDomSerializer))
	]
	public class NSLabel : System.Web.UI.WebControls.Label, IDataBoundControl, INamingContainer
	{
		#region private members
		private string dataSourceName;	// actual source dataset name
		private NetsoftUSA.DataLayer.DCBase dataSource = null;	// actual source data component
		private string dataMember;	// in the form of Table.Field
		private string dataTable;	// parsed from dataMember
		private string dataField;	// parsed from dataMember

		private DataRowView rowView = null;	// Row view to use, if null, use data comp's current row view
		private bool formatWithValue = true;
		private bool displayDescription = false;	// display 
		#endregion

		#region IDataBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
			if (dataSource != null)
			{
				if (dataMember != null)
				{
					if ((dataTable != null) && (dataField != null))
					{
						if (!Save)
						{
							// find out table using the contained main dataset
							DataSet ds = dataSource.GetMainDataSet();
							DataTable table = ds.Tables[dataTable];
							DataColumn col = table.Columns[dataField];
							this.Enabled = true;
							DataRowView rowView = GetCurrentDataRowView();
							if (rowView == null)
								return;
							try
							{
								//sDataRow row = table.Rows[rowNum];

								// data to control
								// normay the formatter object will be employed here
								if (displayDescription)
								{
									string s = DataSourceObject.GetDescriptionForTableItem(rowView, dataField);
									if (s != null)
										this.Text = s;
									else
									{
										if (this.Text == "")
										{
											this.Text = dataField;
										}
									}
								}
								else
									this.Text = DataSourceObject.FormatTableItem(rowView, dataField, formatWithValue);
							}
							catch(System.Data.NoNullAllowedException noNull)
							{
								throw noNull;
							}
							catch(System.ArgumentException argEx)
							{
								throw argEx;
							}
							catch(Exception)
							{
								this.Enabled = false;
							}
						}
					}
				}
			}
		}

		public DCBase GetDataSource()
		{
			return dataSource;
		}

		public string GetDataMember()
		{
			return dataMember;
		}

		public void SetDataSource(DCBase dc)
		{
			dataSource = dc;
		}

		public void SetDataMember(string dm)
		{
			DataMemberName = dm;
		}

		/// <summary>
		/// Forces the textbox to use the specifed rowView instead of 
		/// getting current rowview from datacomponent.
		/// </summary>
		/// <param name="rowView"></param>
		public void SetCurrentDataRowView(DataRowView rowView)
		{
			this.rowView = rowView;
		}

		public DataRowView GetCurrentDataRowView()
		{
			if (this.rowView == null)
			{
				if (dataSource != null)
					return dataSource.GetCurrentDataRowView(dataTable);
				else
					return null;
			}
			else
				return rowView;
		}

		#endregion

		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataSourceConverter))
		]
		public string DataSourceName
		{
			get
			{
				return dataSourceName;
			}
			set
			{
				dataSourceName = value;

				//!!! add code to set dataSource object
			}
		}

		/// <summary>
		/// Data source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public NetsoftUSA.DataLayer.DCBase DataSourceObject
		{
			get
			{
				return dataSource;
			}
			set
			{
				dataSource = value;		// code serializer generated code calls this.
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataTableAndItemConverter))
		]
		public string DataMemberName
		{
			get
			{
				return dataMember;
			}
			set
			{
				dataMember = value;
				dataTable = null;
				dataField = null;

				if (dataMember != null)
				{
					string[] memberTerms = dataMember.Split('.');
					if (memberTerms.Length == 2)
					{
						dataTable = memberTerms[0];
						dataField = memberTerms[1];
					}
					else
					{
						if (dataMember != "")
						{
							dataMember = null;
							throw new Exception("This type of data member not handled yet!");
						}
					}
				}
			}
		}



		/// <summary>
		/// Format items with value, so that it can be parsed again
		/// </summary>
		[Category("Behavior"), DefaultValue(true)]
		public bool FormatWithValue
		{
			get {	return formatWithValue;	}
			set	{	formatWithValue = value; }
		}

		/// <summary>
		/// Display field descriptions instead of value
		/// </summary>
		[Category("Behavior"), DefaultValue(false)]
		public bool DisplayDescription
		{
			get {	return displayDescription;	}
			set	{	displayDescription = value; }
		}

		#endregion

		protected override void Render(HtmlTextWriter writer)
		{
			string oldText = this.Text;
			if (this.Site != null)
				if (this.Site.DesignMode)
				{
					if (dataSourceName != null && dataSourceName != "")
						{
							this.Text = dataMember;
							if (this.Text == "")
								this.Text = "Unbound";
						}

					/*
					if (DataSourceObject != null)
					{
						if (dataMember != null && dataMember != "")
						{
							string s = DataSourceObject.GetColumnDesc(dataTable, dataField);
							if (s != null)
								this.Text = s + "*";
							else
								this.Text = dataField  + "*";
						}
					}*/
				}

			// automatic detection features
			bool hyperlink = false;
			if ((this.Text.IndexOf("http:") >= 0) || (this.Text.IndexOf("www.") >= 0))
				hyperlink = true;

			if (hyperlink)
			{
				writer.WriteBeginTag("A");
				writer.WriteAttribute("HREF", this.Text);
			}
			base.Render (writer);
			if (hyperlink)
			{
				writer.WriteEndTag("A");
			}

			this.Text = oldText;
		}

	}
}
