using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Reflection;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NetsoftUSA.WebForms.IObjectBoundControl implementer for a field label type
	/// UI control.  This control displays the FieldDescription defined on a
	/// bound SourceMember.
	/// </summary>
	[DefaultProperty("Text"), 
	ToolboxData("<{0}:OBFieldLabel runat=server></{0}:OBFieldLabel>")
	]
	public class OBFieldLabel : System.Web.UI.WebControls.Label, IObjectBoundControl, INamingContainer
	{
		#region private members
		private string sourceClassName;	// source object's class type to be used in design time
		private Type type = null;
		private object sourceObject = null;	// actual source object
		private string sourceMember;		// source member of the source object
		private bool disableBinding = false;

		private bool enableRequiredMark = true;
        
		private string formatString = "{0}:";		// display as 'fielddescription:'

		private bool objectBound = false;

		#endregion

		#region Constructors

		public OBFieldLabel() : base()
		{
		}
		#endregion

		#region IObjectBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
		}

		public object GetSourceObject()
		{
			return sourceObject;
		}

		public string GetSourceObjectMember()
		{
			return sourceMember;
		}

		public void SetSourceObject(object obj)
		{
			SourceObject = obj;
		}

		public void SetSourceObjectMember(string om)
		{
			SourceMemberName = om;
		}

		[Browsable(false)]
		public bool IsReadOnly
		{ 
			get { return true; } 
			set { }
		}

		[Browsable(false)]
		public bool IsEnabled
		{ 
			get { return this.Enabled; } 
			set { this.Enabled = value; }
		}

		#endregion
		
		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.WebForms.SourceClassNamesConverter))
		]
		public string SourceClassName
		{
			get	{ return sourceClassName; }
			set	
			{ 
				sourceClassName = value; 
				OnTypeBound();
			}
		}

		/// <summary>
		/// Source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public object SourceObject
		{
			get	{	return sourceObject;	}
			set	
			{	
				sourceObject = value; 
				// once an object is bound, set it as object bound
				// so that the control won't be disabled
				objectBound = !disableBinding && sourceObject != null && sourceMember != null;
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.ClassMemberConverter))
		]
		public string SourceMemberName
		{
			get	{ return sourceMember; }
			set 
			{ 
				sourceMember = value; 
			}
		}

		[DefaultValue(false)]
		public bool DisableBinding
		{
			get
			{
				return disableBinding;
			}
			set
			{
				disableBinding = value;
			}
		}

		[DefaultValue(true)]
		public bool EnableRequiredMark
		{
			get
			{
				return enableRequiredMark;
			}
			set
			{
				enableRequiredMark = value;
			}
		}



		[Editor(typeof(LangMessageEditor), typeof(System.Drawing.Design.UITypeEditor))]
		[Category("NetsoftUSA.WebForms Binding")]
		[DefaultValue("{0}:")]
		public string FormatString
		{
			get
			{
				return formatString;
			}
			set
			{
				if (value == "" || value == null)
					formatString = "{0}:";
				else
					formatString = value;
			}
		}

		#endregion

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			objectBound = (bool)ViewState["ob"];
		}

		protected override object SaveViewState()
		{
			ViewState["ob"] = objectBound;

			return base.SaveViewState ();
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);

			OnTypeBound();
		}

		protected virtual void OnTypeBound()
		{
			if (sourceMember != null)
			{
				try
				{
					type = Type.GetType(sourceClassName);
				}
				catch
				{
				}
			}
		}

		private string GetFormattedDesc(string s)
		{
			if (s == null)
				s = "";
			return ((BasePage)this.Page).Language.Translate(true, formatString, s);
		}

		public bool IsViewOnly
		{
			get
			{
				if (((BasePage)Page).IsViewOnly)
					return true;
				return ((BasePage)Page).ClassBindings.GetViewOnly(type);
			}
		}

		protected override void Render(HtmlTextWriter writer)
		{
			bool design = false;
			if (this.Site != null)
				if (this.Site.DesignMode)
					design = true;

			if (!disableBinding)
			{
				try
				{

					string s = null;
					//type = Type.GetType(sourceClassName);
					if (type != null)
						s = FieldDescriptionAttribute.GetDescription(type, sourceMember, true);
					if (s == null)
						s = sourceMember;
					ControlTypeAttribute ctlTypeAttrib = ControlTypeAttribute.GetFromProp(type, sourceMember, true);
					if (ctlTypeAttrib.ControlType == EnumControlTypes.CheckBox)
						if (((BasePage)Page).CheckBoxDescriptionsOn)
							return;		// just don't render field labes if

					this.Text = GetFormattedDesc(s);
					if (!this.IsViewOnly && this.enableRequiredMark)
						if (((BasePage)Page).RequiredValidationsEnabled && ((BasePage)Page).ValidationsEnabled)
							if ((ctlTypeAttrib.ClientValidators & EnumClientValidators.Required) != 0)
								if (ctlTypeAttrib.ClientScriptForConditionalRequired == null)
									this.Text += "<font color=red>*</font>";

					int accessLevel = ((BasePage)Page).AccessLevel;
					if (!design)
						if (accessLevel < ctlTypeAttrib.MinAccessToSee)
							return;		// don't render
				}
				catch(Exception ex)
				{
					if (design)
						this.Text = String.Format("[{0}]", sourceMember);
					else
						this.Text = String.Format("{0} has erronous format string ({1})", sourceMember, ex.Message);
				}
			}
			base.Render (writer);
		}


	}
}
