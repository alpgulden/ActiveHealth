using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Text;

namespace NetsoftUSA.WebForms
{
	public enum WindowOpenerButtonType
	{
		Button = 0,
		HyperLink = 1,
		ImageButton = 2
	}

	public enum WindowMode
	{
		NewWindow = 0,
		SameWindow = 1,
		ModalDialog = 2,
		ModelessDialog = 3
	}

	/// <summary>
	/// Summary description for WindowOpener.
	/// </summary>
	[DefaultProperty("Text"),
	Designer(typeof(NetsoftUSA.WebForms.WindowOpenerDesigner)),
	ToolboxData("<{0}:WindowOpener runat=server></{0}:WindowOpener>")]
	public class WindowOpener : System.Web.UI.WebControls.WebControl, INamingContainer
	{
		private string navigateURL = "";
		private string text = "";
		private string windowName;
		private Unit windowTop;
		private Unit windowLeft;
		private Unit windowWidth;
		private Unit windowHeight;
		private bool toolBar = true;
		private bool statusBar = true;
		private bool menuBar = true;
		private bool scrollBars = true;
		private bool resizable = true;
		private bool copyHistory = true;
		private bool addressBar = true;
		private bool linksBar = true;
		private WindowOpenerButtonType buttonType = WindowOpenerButtonType.Button;
		private string afterOpenScript = "";
		private string pickSource = "";			// For example:  NSDataGrid1
		private string pickTarget = "";			// For example:  txtLogicID
		private Control pickTargetCtl = null;

		private WindowMode windowMode = WindowMode.NewWindow;

		System.Web.UI.HtmlControls.HtmlButton button = null;
		System.Web.UI.HtmlControls.HtmlAnchor anchor = null;
		System.Web.UI.HtmlControls.HtmlImage imageButton = null;

		public WindowOpener() : base()
		{
			//base.Target = "_blank";
		}

		public WindowOpener(string windowName, string navigateUrl, Unit windowWidth, Unit windowHeight) : base()
		{
			this.windowName = windowName;
			this.windowWidth = windowWidth;
			this.windowHeight = windowHeight;
			this.NavigateURL = navigateUrl;

			//base.Target = "_blank";
		}

		[DefaultValue(WindowMode.NewWindow)]
		public WindowMode WindowMode
		{
			get { return this.windowMode; }
			set { this.windowMode = value; }
		}

		public string WindowName
		{
			get
			{
				return windowName;
			}
			set
			{
				windowName = value;
			}
		}

		public string NavigateURL
		{
			get
			{
				return navigateURL;
			}
			set
			{
				navigateURL = value;
			}
		}

		public string Text
		{
			get
			{
				return text;
			}
			set
			{
				text = value;
			}
		}

		public Unit WindowTop
		{
			get 
			{
				return windowTop;
			}
			set 
			{ 
				windowTop = value;
			}
		}

		public Unit WindowLeft
		{
			get 
			{
				return windowLeft;
			}
			set 
			{ 
				windowLeft = value;
			}
		}

		public Unit WindowWidth
		{
			get 
			{
				return windowWidth;
			}
			set 
			{ 
				windowWidth = value;
			}
		}

		public Unit WindowHeight
		{
			get 
			{
				return windowHeight;
			}
			set 
			{ 
				windowHeight = value;
			}
		}

		[DefaultValue(true)]
		public bool ToolBar
		{
			get
			{
				return toolBar;
			}
			set
			{
				toolBar = value;
			}
		}

		[DefaultValue(true)]
		public bool StatusBar
		{
			get
			{
				return statusBar;
			}
			set
			{
				statusBar = value;
			}
		}

		[DefaultValue(true)]
		public bool MenuBar
		{
			get
			{
				return menuBar;
			}
			set
			{
				menuBar = value;
			}
		}

		[DefaultValue(true)]
		public bool ScrollBars
		{
			get
			{
				return scrollBars;
			}
			set
			{
				scrollBars = value;
			}
		}

		[DefaultValue(true)]
		public bool Resizable
		{
			get
			{
				return resizable;
			}
			set
			{
				resizable = value;
			}
		}

		[DefaultValue(true)]
		public bool CopyHistory
		{
			get
			{
				return copyHistory;
			}
			set
			{
				copyHistory = value;
			}
		}

		[DefaultValue(true)]
		public bool AddressBar
		{
			get
			{
				return addressBar;
			}
			set
			{
				addressBar = value;
			}
		}

		[DefaultValue(true)]
		public bool LinksBar
		{
			get
			{
				return linksBar;
			}
			set
			{
				linksBar = value;
			}
		}

		public string AfterOpenScript
		{
			get
			{
				return afterOpenScript;
			}
			set
			{
				afterOpenScript = value;
			}
		}

		[Category("Picking"),
		Description("The NSDataGrid control in the opened window that you want to pick the data from")]
		public string PickSource
		{
			get
			{
				return pickSource;
			}
			set
			{
				pickSource = value;
			}
		}

		[Category("Picking"),
		TypeConverter(typeof(TextBoxTypeConverter))]
		public string PickTarget
		{
			get
			{
				return pickTarget;
			}
			set
			{
				pickTarget= value;
			}
		}

		[Category("Appearance"), DefaultValue(WindowOpenerButtonType.Button)]
		public WindowOpenerButtonType ButtonType
		{
			get { return buttonType; }
			set { buttonType = value; }
		}

		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public Control PickTargetCtl
		{
			get
			{
				return pickTargetCtl;
			}
			set
			{
				pickTargetCtl = value;
			}
		}

		public void registerClientScripts()
		{
			registerClientScripts(this.Page);
		}

		private Control getValidPickTargetCtl()
		{
			if (pickTargetCtl != null)
				return pickTargetCtl;
			try
			{
				return Page.FindControl(pickTarget);
			}
			catch(Exception)
			{
				return null;
			}
		}

		private string getValidPickTargetCtlValText()
		{
			Control ctl = getValidPickTargetCtl();
			string s = null;
			if (ctl == null)
				return "";
			if (ctl is NSTextBox)
				return ((NSTextBox)ctl).GetValText();
			if (ctl is NSMultiBox)
				return ((NSMultiBox)ctl).GetValText();

			if (ctl is TextBox)
				s = ((TextBox)ctl).Text;
			if (ctl is HtmlInputText)
				s = ((HtmlInputText)ctl).Value;
			if (s == null)
				return "";
			string[] terms = s.Split('-');
			return terms[0];
		}

		private string getValidPickTargetCtlText()
		{
			Control ctl = getValidPickTargetCtl();
			if (ctl == null)
				return "";
			if (ctl is TextBox)
				return ((TextBox)ctl).Text;
			if (ctl is HtmlInputText)
				return ((HtmlInputText)ctl).Value;
			if (ctl is NSMultiBox)
				return ((NSMultiBox)ctl).Text;
			return "";
		}

		private string getPickTargetClientID()
		{
			if (pickTargetCtl != null)
				return pickTargetCtl.ClientID;
			try
			{
				return Page.FindControl(pickTarget).ClientID;
			}
			catch(Exception)
			{
				return null;
			}
		}

		public void registerClientScripts(Page page)
		{
			string clientScriptName = "WindowOpener_" + this.ClientID;
			string pickTargetCliID = getPickTargetClientID();

			if (!((BasePage)page).IsDeclarationScriptRegistered(clientScriptName))
			{
				StringBuilder s = new StringBuilder();
				string svarname = this.ClientID;

				s.Append("var " + svarname);
				s.Append("=new WindowOpener('");

				if (windowName == null || windowName == "")
				{
					Random ran = new Random(this.GetHashCode());
					s.Append("WindowOpener_" + ran.Next().ToString());
				}
				else
					s.Append(windowName);
				s.Append("','");
				string url = NavigateURL;
				//url = url.Replace("@pickTarget@", "'+" + getPickTargetClientID() + "+'");		// add a js expression in the string
				url = url.Replace("@pickTargetVal@", "@" + getPickTargetClientID() + "@");		//getValidPickTargetCtlValText()
				//url = url.Replace("@pickTargetText@", "'+" + getValidPickTargetCtlText() + "+'");
				s.Append(url);
				s.Append("','");
				s.Append(windowWidth);
				s.Append("','");
				s.Append(windowHeight);
				s.Append("');\n");
				if (!windowLeft.IsEmpty)
					s.Append(svarname + ".windowLeft=\"" + windowLeft.ToString() + "\";");
				if (!windowTop.IsEmpty)
					s.Append(svarname + ".windowTop=\"" + windowTop.ToString() + "\";");
				if (!toolBar)
					s.Append(svarname + ".toolBar=0;");
				if (!menuBar)
					s.Append(svarname + ".menuBar=0;");
				if (!scrollBars)
					s.Append(svarname + ".scrollBars=0;");
				if (!resizable)
					s.Append(svarname + ".resizable=0;");
				if (!copyHistory)
					s.Append(svarname + ".copyHistory=0;");
				if (!addressBar)
					s.Append(svarname + ".addressBar=0;");
				if (!linksBar)
					s.Append(svarname + ".linksBar=0;");
				if (windowMode != WindowMode.NewWindow)
					s.Append(svarname + ".windowMode=" + (int)windowMode + ";");

				// script specific to this window opener
				// called after window opens
				s.Append("\n");
				s.Append("function " + svarname + "_afterOpen()\n");
				s.Append("{\n");
				if (pickSource != null && pickSource != "")
				{
					s.Append("  if (this.window) this.window." + pickSource + "_PickTarget='" + pickTargetCliID + "';\n");
					s.Append("  try {\n");
					s.Append("  if (this.window) this.window.set_" + pickSource + "_PickTarget('" + pickTargetCliID + "');\n");
					s.Append("  } catch (e) { }\n");
				}
				else if (pickTargetCliID != null) // condition added by V 
				{
					s.Append("  if (this.window) this.window.PickTarget='" + pickTargetCliID + "';\n");
					s.Append("  try {\n");
					s.Append("  if (this.window) this.window.set_PickTarget('" + pickTargetCliID + "');\n");
					s.Append("  } catch (e) { }\n");
				}

				if (afterOpenScript != null && afterOpenScript != "")
					s.Append(this.afterOpenScript + ";");
				s.Append("}\n");
				s.Append(svarname + ".afterOpen = " + svarname + "_afterOpen;\n");
				((BasePage)page).RegisterDeclarationScript(clientScriptName, s.ToString());
			}
		}
	
		public string getWindowOpenScript()
		{
			return this.ClientID + ".open()";
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
			windowName = (string)ViewState["WName"];
			windowWidth = (Unit)ViewState["WWidth"];
			windowHeight = (Unit)ViewState["WHeight"];
		}
	
		protected override object SaveViewState()
		{
			ViewState["WName"] = windowName;
			ViewState["WWidth"] = windowWidth;
			ViewState["WHeight"] = windowHeight;
			return base.SaveViewState ();
		}
	
		public void PrepareForRender(Page page)
		{
			EnsureChildControls();
			if (!this.Enabled)
				return;

			registerClientScripts(page);
			if (button!=null)
				button.Attributes["onclick"] = "javascript:" + getWindowOpenScript();
			if (anchor!=null)
				anchor.Attributes["href"] = "javascript:" + getWindowOpenScript();
			if (imageButton!=null)
				imageButton.Attributes["onclick"] = "javascript:" + getWindowOpenScript();
		}

		protected override void OnPreRender(EventArgs e)
		{
			PrepareForRender(this.Page);
			base.OnPreRender (e);
		}
		protected override void Render(HtmlTextWriter writer)
		{	//string s = this.NavigateURL;
			//this.NavigateUrl = "";
			base.Render (writer);
			//this.NavigateUrl = s;
		}

		protected override void CreateChildControls()
		{
			CreateChildControls(this.Controls);
		}

		internal void CreateChildControls(ControlCollection controls)
		{
			switch (buttonType)
			{
				case WindowOpenerButtonType.Button: 
					button = new System.Web.UI.HtmlControls.HtmlButton();
					button.InnerText = text;
					controls.Add(button);
					break;
				case WindowOpenerButtonType.HyperLink: 
					anchor = new System.Web.UI.HtmlControls.HtmlAnchor();
					anchor.InnerText = text;
					controls.Add(anchor);
					break;
				case WindowOpenerButtonType.ImageButton: 
					imageButton = new System.Web.UI.HtmlControls.HtmlImage();
					imageButton.Src = text;
					imageButton.Style["cursor"] = "hand";
					controls.Add(imageButton);
					break;
			}
		}
	}
}
