using System;
using System.Web.UI.WebControls;
using System.Web;
using System.Collections;
using System.Web.UI;


namespace NetsoftUSA.WebForms
{

	public class NSValidationSummary
	{
		ValidatorCollection vCollection;

		public NSValidationSummary(ValidatorCollection vCollection)
		{
			this.vCollection = vCollection;
		}

		public void AddErrorMessage(string msg) 
		{
			vCollection.Add(new ErrorValidator(msg));
		}
	
	}

	class ErrorValidator : IValidator 
	{

		private string errorMsg;

		public ErrorValidator(string msg) 
		{
			errorMsg = msg;
		}

		public string ErrorMessage
		{
			get{ return errorMsg;}
			set{ errorMsg = value;}
		}

		public bool IsValid
		{
			get{return false;}
			set{}
		}

		public void Validate() 
		{
		}
	}
}
