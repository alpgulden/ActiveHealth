using System;
using System.Collections;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for ControlGroup.
	/// </summary>
	public class ControlGroup
	{
		private string groupKey;
		private string groupName;
		private string parentGroup;

		private ArrayList subGroups = new ArrayList(5);

		private bool isDirty = false;

		public ControlGroup()
		{
		}

		public ControlGroup(string groupKey, string groupName, string parentGroup)
		{
			this.groupKey = groupKey;
			this.groupName = groupName;
			this.parentGroup = parentGroup;
		}

		public string GroupKey
		{
			get 
			{
				return groupKey;
			}
			set
			{
				groupKey = value;
			}
		}

		public string GroupName
		{
			get 
			{
				return groupName;
			}
			set
			{
				groupName = value;
			}
		}

		public string ParentGroup
		{
			get 
			{
				return parentGroup;
			}
			set
			{
				parentGroup = value;
			}
		}

		public bool IsDirty
		{
			get
			{
				return isDirty;
			}
			set
			{
				isDirty = value;
			}
		}

		public ArrayList SubGroups
		{
			get
			{
				return subGroups;
			}
		}


		public void AddSubGroup(ControlGroup controlGroup)
		{
            this.subGroups.Add(controlGroup);
		}


	}
}
