using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.IO;
using System.Xml;
using System.Diagnostics;
using System.Data;
using System.Collections;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for CSVImportWizard.
	/// </summary>
	[ToolboxData("<{0}:CSVImportWizard runat=server></{0}:CSVImportWizard>"),
	Designer(typeof(NetsoftUSA.WebForms.CSVImportWizardDesigner))]
	public class CSVImportWizard : System.Web.UI.WebControls.WebControl, INamingContainer
	{
		#region Private members
		
		private int loadedColumns = 0;						// number of columns whose definition was loaded from file
		private bool dataRendered = false;
		private string cacheKey = null;
		//private string targetTable;					// target database table
		private int maxColumns = 256;					// must be set at design time
		private int maxRowsDisplayed = 10;				// displayed number of rows

		private CSVImporter csvImporter;
		private Stream inputStream;					// input stream to use

		// properties to be set at design time
		private int linesToSkip = 0;
		private string seperator = ",";


		//private DropDownList[] ddColNames;
		//private TextBox[] txtColNames;
		//private TextBox[] txtFormats;

		Table tbl;					// html table to show
		TextBox txtSeperator;		// seperator
		TextBox txtLinesToSkip;		// number of lines to skip
		TableRow ddColNamesRow;		// the row for the colNames
		TableRow txtColNamesRow;	// the row for the controls 
		TableRow txtFormatsRow;		// the row for the controls 

		Button butAddColumn;

		private void CloseInputStream()
		{
			if (inputStream != null)
			{
				inputStream.Close();
			}
		}

		#endregion

		#region Overridden functions

		protected override void OnUnload(EventArgs e)
		{
			base.OnUnload (e);

			CloseInputStream();
		}


		protected override void CreateChildControls()
		{
			CreateChildControls(this.Controls);
		}

		internal void CreateChildControls(ControlCollection controls)
		{
			//ddColNames = new DropDownList[maxColumns];
			//txtColNames = new TextBox[maxColumns];
			//txtFormats = new TextBox[maxColumns];

			// create the html table

			Table butTable = new Table();
			controls.Add(butTable);
			TableRow row = new TableRow();
			butTable.Rows.Add(row);
			butTable.BorderWidth = 0;
			TableCell cell = new TableCell();
			row.Cells.Add(cell);
			
			Label lb = new Label();
			lb.Text = "Seperator:";
			cell.Controls.Add(lb);
			txtSeperator = new TextBox();
			txtSeperator.ID = this.ID + "_seperator";
			txtSeperator.Width = 40;
			txtSeperator.Text = seperator;
			txtSeperator.MaxLength = 1;
			cell.Controls.Add(txtSeperator);

			lb = new Label();
			lb.Text = "&nbsp&nbsp&nbspLines to skip:";
			cell.Controls.Add(lb);
			txtLinesToSkip = new TextBox();
			txtLinesToSkip.ID = this.ID + "_linesToSkip";
			txtLinesToSkip.Width = 40;
			txtLinesToSkip.Text = linesToSkip.ToString();
			txtLinesToSkip.MaxLength = 5;
			cell.Controls.Add(txtLinesToSkip);

			lb = new Label();
			lb.Text = "&nbsp&nbsp&nbsp";
			cell.Controls.Add(lb);

			// buttons
			butAddColumn = new Button();
			butAddColumn.Text = "Add Column";
			butAddColumn.Click+=new EventHandler(butAddColumn_Click);
			cell.Controls.Add(butAddColumn);

			Button butRefresh = new Button();
			butRefresh.Text = "Refresh";
			cell.Controls.Add(butRefresh);
			butRefresh.Click+=new EventHandler(butRefresh_Click);

			tbl = new Table();
			tbl.CellSpacing = 0;
			tbl.BorderStyle = BorderStyle.Inset;
			ddColNamesRow = new TableRow();
			tbl.Rows.Add(ddColNamesRow);

			txtColNamesRow = new TableRow();
			tbl.Rows.Add(txtColNamesRow);

			txtFormatsRow = new TableRow();
			tbl.Rows.Add(txtFormatsRow);

			controls.Add(tbl);

			cell = new TableCell();
			cell.Text = "Table Column:";
			cell.Wrap = false;
			cell.Visible = false;
			ddColNamesRow.Cells.Add(cell);

			cell = new TableCell();
			cell.Text = "Column Name:";
			cell.Wrap = false;
			cell.Visible = false;
			txtColNamesRow.Cells.Add(cell);

			cell = new TableCell();
			cell.Text = "Column Formats:";
			cell.Wrap = false;
			cell.Visible = false;
			txtFormatsRow.Cells.Add(cell);

			for (int i = 0; i < maxColumns; i++)
			{
				// ddColName
				cell = new TableCell();
				cell.Width = Unit.Pixel(200);
				ddColNamesRow.Cells.Add(cell);
				//cell.EnableViewState = false;
				cell.Visible = false;
				DropDownList ddColName = new DropDownList();
				ddColName.Width = Unit.Pixel(100); //Unit.Percentage(100);
				//ddColNames[i] = ddColName;
				cell.Controls.Add(ddColName);

				Button butDelColumn = new Button();
				butDelColumn.CommandName = i.ToString();	// which column
				butDelColumn.Text = "X";
				butDelColumn.EnableViewState = false;
				butDelColumn.ToolTip = "Delete this column";
				butDelColumn.Visible = false;
				cell.Controls.Add(butDelColumn);
				butDelColumn.Command+=new CommandEventHandler(butDelColumn_Command);

				// txtColName
				cell = new TableCell();
				txtColNamesRow.Cells.Add(cell);
				cell.Visible = false;
				TextBox txtColName = new TextBox();
				txtColName.Width = Unit.Pixel(100); //Unit.Percentage(100);
				//txtColNames[i] = txtColName;
				cell.Controls.Add(txtColName);

				// txtFormats
				cell = new TableCell();
				txtFormatsRow.Cells.Add(cell);
				cell.Visible = false;
				TextBox txtFormat = new TextBox();
				txtFormat.TextMode = TextBoxMode.MultiLine;
				txtFormat.Width = Unit.Pixel(120); //Unit.Percentage(100); 
				txtFormat.Height = Unit.Pixel(60); //Unit.Percentage(100); 
				//txtFormats[i] = txtFormat;
				cell.Controls.Add(txtFormat);
			}

			if (this.Site != null)
			{
				if (this.Site.DesignMode)
				{
					Label msg = new Label();
					msg.Text = "Netsoft-USA CSV File Import Wizard";
					controls.Add(msg);
				}
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			if (!dataRendered)
				RenderData();
		}

		protected override object SaveViewState()
		{
			ViewState["loadedColumns"] = loadedColumns;

			return base.SaveViewState ();
		}


		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
			loadedColumns = (int)ViewState["loadedColumns"];
		}


		public void RenderData()
		{
			SetParamsOnCSVImporter();

			//DetectColumnsInTextStream();
			EnsureChildControls();
			dataRendered = true;

			int columns = 0;	// number of columns to be displayed
			if (inputStream == null)
			{
				
			}
			else
			{
				inputStream.Seek(0, SeekOrigin.Begin);
				StreamReader stm = new StreamReader(inputStream);
				string line;
				int lineNum = 0;
				string[] valueStrings = new string[maxColumns];
				
				while ((line = stm.ReadLine()) != null)
				{
					lineNum++;
					if (lineNum > maxRowsDisplayed)
						break;				// Display max num of lines
					NetsoftUSA.DataLayer.CSVImporter.ParseRowValuesCSV(line, valueStrings, csvImporter.Seperator);

					TableRow row = new TableRow();
					tbl.Rows.Add(row);
					
					TableCell cell = new TableCell();
					row.Cells.Add(cell);

					// add parsed values to columns
					for (int i = 0; i < maxColumns; i++)
					{
						if (valueStrings[i] != null)
						{
							if (i + 1 > columns)
								columns = i + 1;

							cell = new TableCell();
							row.Cells.Add(cell);
							cell.Text = valueStrings[i];
						}
						else
						{
							break;		// end of columns for this row
						}
					}
				}
			}

			DataTable dataTable = null;
			string[] colNames = null;
			if (csvImporter != null)
				if (csvImporter.TargetTable != null)
					if (csvImporter.TargetTable != "")
					{
						dataTable = csvImporter.GetTableDefinition(csvImporter.TargetTable);
						colNames = new string[dataTable.Columns.Count];
						for (int i = 0; i < dataTable.Columns.Count; i++)
						{
							colNames[i] = dataTable.Columns[i].ColumnName;
						}
					}

			int textCols = columns;
			if (loadedColumns > columns)
				columns = loadedColumns;

			// make all columns invisible
			for (int i = 1; i < maxColumns + 1; i++)
			{
				ddColNamesRow.Cells[i].Visible = false;
				//ddColNamesRow.Cells[i].Controls[1].Visible = false;
				txtColNamesRow.Cells[i].Visible = false;
				txtFormatsRow.Cells[i].Visible = false;
			}
			// make columns visible
			for (int i = 0; i < columns + 1; i++)
			{
				ddColNamesRow.Cells[i].Visible = true;
				if (i > textCols)
                    ddColNamesRow.Cells[i].Controls[1].Visible = true;
				txtColNamesRow.Cells[i].Visible = true;
				txtFormatsRow.Cells[i].Visible = true;

				// fill the col names drop down list
				if (i > 0)
				{
					if (colNames != null)
					{
						DropDownList dd = (DropDownList)ddColNamesRow.Cells[i].Controls[0];
						TextBox txtColName = (TextBox)txtColNamesRow.Cells[i].Controls[0];
						int selIndex = dd.SelectedIndex;
						string selVal = dd.SelectedValue;
						dd.DataSource = colNames;
						dd.DataBind();
						dd.Items.Insert(0, (string)null);
						if (selVal == "")
						{
							ListItem selItem = dd.Items.FindByValue(txtColName.Text);
							if (selItem != null)
								selItem.Selected = true;
						}
						else
						{
							txtColName.Text = selVal;
							try
							{
								dd.SelectedIndex = selIndex;
							}
							catch(Exception)
							{
								dd.SelectedIndex = dd.Items.IndexOf(dd.Items.FindByValue(selVal));
							}

							if (dd.SelectedItem != null)
								if (dd.SelectedItem.Value != selVal)
									txtColName.Text = dd.SelectedItem.Value;
						}
					}
				}
			}
		}

		#endregion

		#region Public members

		[DefaultValue(",")]
		public string Seperator
		{
			get { return seperator; }
			set 
			{ 
				seperator = value; 
				EnsureChildControls();
				if (seperator.Length > 1)
					seperator = seperator.Substring(0, 1);

				txtSeperator.Text = seperator;
			}
		}

		[DefaultValue((int)0)]
		public int LinesToSkip
		{
			get { return linesToSkip; }
			set
			{
				linesToSkip = value;
				EnsureChildControls();
				if (linesToSkip < 0)
					linesToSkip = -linesToSkip;
				txtLinesToSkip.Text = linesToSkip.ToString();
			}
		}

		//[Browsable(false)]
		public CSVImporter CSVImporter
		{
			get { return csvImporter; }
			set { csvImporter = value; }
		}

		[Browsable(false)]
		public Stream InputStream
		{
			get { return inputStream; }
			set
			{
				CloseInputStream();
				inputStream = value;

				// auto manage caching if there's a cache name
				if (cacheKey != null)
					this.CacheState(cacheKey);

				//PrepareCSVImporter();
			}
		}

		public void LoadState(string key)
		{
			string cacheName = this.Page.Session.SessionID + ".csvImportWizard." + key;
			//this.inputStream = (Stream)this.Page.Cache[cacheName];

			string fname = Path.Combine(Path.GetTempPath(), cacheName);

			if (File.Exists(fname))
			{
				CloseInputStream();
				inputStream = new FileStream(fname, FileMode.Open);
			}
		}

		public void CacheState(string key)
		{
			string cacheName = this.Page.Session.SessionID + ".csvImportWizard." + key;
			//this.Page.Cache[cacheName] = this.inputStream;
			string fname = Path.Combine(Path.GetTempPath(), cacheName);
			if (inputStream == null)
			{
				File.Delete(fname);
			}
			else
			{
				inputStream.Seek(0, SeekOrigin.Begin);
				FileStream fs = new FileStream(fname, FileMode.Create);
				byte[] buffer = new byte[inputStream.Length];
				inputStream.Read(buffer, 0, (int)inputStream.Length);
				fs.Write(buffer, 0, (int)inputStream.Length);
				fs.Flush();
				fs.Close();
			}
		}

		public virtual void ManageCaching(string key)
		{
			cacheKey = key;		// will be used in prerender for CacheState
			if (this.Page.IsPostBack)
				this.LoadState(key);
		}

		public void ClearCache()
		{
			ClearCache(cacheKey);
		}

		public void ClearCache(string key)
		{
			string cacheName = this.Page.Session.SessionID + ".csvImportWizard." + key;
			string fname = Path.Combine(Path.GetTempPath(), cacheName);
			File.Delete(fname);
		}

		public string[] GetColumnNames()
		{
			RenderData();
			ArrayList colNames = new ArrayList();
			//string[] colNames = new string[txtColNamesRow.Cells.Count - 1];
			for (int i = 1; i < txtColNamesRow.Cells.Count; i++)
			{
				if (!txtColNamesRow.Cells[i].Visible)
					break;			// end of columns
				TextBox txtColName = (TextBox)txtColNamesRow.Cells[i].Controls[0];
				DropDownList ddColName = (DropDownList)ddColNamesRow.Cells[i].Controls[0];
				string colName = txtColName.Text;
				if (colName == "")
					colName = ddColName.SelectedValue;
				if (colName == null)
					colName = "";

				colNames.Add(colName);
			}
			return (string[])colNames.ToArray(typeof(string));
		}

		private void SetParamsOnCSVImporter()
		{
			if (txtSeperator.Text.Length > 0)
				csvImporter.Seperator = txtSeperator.Text[0];
			if (txtLinesToSkip.Text.Length > 0)
			{
				try
				{
					csvImporter.LinesToSkip = int.Parse(txtLinesToSkip.Text);
				}
				catch(Exception)
				{
					csvImporter.LinesToSkip = 0;
				}
			}
		}

		public void PrepareCSVImporter()
		{
			SetParamsOnCSVImporter();

			RenderData();

			ArrayList colNames = new ArrayList();
			//string[] colNames = new string[txtColNamesRow.Cells.Count - 1];
			for (int i = 1; i < txtColNamesRow.Cells.Count; i++)
			{
				if (!txtColNamesRow.Cells[i].Visible)
					break;			// end of columns
				TextBox txtColName = (TextBox)txtColNamesRow.Cells[i].Controls[0];
				DropDownList ddColName = (DropDownList)ddColNamesRow.Cells[i].Controls[0];
				string colName = txtColName.Text;
				if (colName == "")
					colName = ddColName.SelectedValue;
				if (colName == null)
					colName = "";

				colNames.Add(colName);

				// get formats
				TextBox txtFormats = (TextBox)txtFormatsRow.Cells[i].Controls[0];
				string[] fmts = txtFormats.Text.Split('\n', '\r');
				if (fmts.Length > 0)
				{
					ArrayList formats = new ArrayList();
					for (int j = 0; j < fmts.Length; j++)
					{
						if (fmts[j] != "")
							formats.Add(fmts[j]);
					}
					if (formats.Count > 0)
					{
						csvImporter.SetColumnFormats(colName, (string[])formats.ToArray(typeof(string)));
					}
					else
						csvImporter.SetColumnFormats(colName, null);
				}
				else
					csvImporter.SetColumnFormats(colName, null);
			}

			csvImporter.TargetColumns = (string[])colNames.ToArray(typeof(string));

			// rewind the stream
			if (InputStream != null)
				inputStream.Seek(0, SeekOrigin.Begin);
		}

		public void Import()
		{
			if (inputStream != null)
			{
				PrepareCSVImporter();
				csvImporter.Import(inputStream);
			}
		}

		public void SaveColumnDef(string fileName)
		{
			//RenderData();
			PrepareCSVImporter();
			string path = Page.Server.MapPath(fileName); 
			
			XmlDocument xdoc = new XmlDocument();
			XmlElement xCSVElem = xdoc.CreateElement("CSVImportWizard");
			XmlNode xnode = xdoc.AppendChild(xCSVElem);

			XmlElement xImportDef = xdoc.CreateElement("ImportDEF");
			xCSVElem.AppendChild(xImportDef);
			xImportDef.SetAttribute("SEPERATOR", csvImporter.Seperator.ToString());
			xImportDef.SetAttribute("LINESTOSKIP", csvImporter.LinesToSkip.ToString());
			
			xnode = xCSVElem.AppendChild(xdoc.CreateElement("ColumnDEF"));

			for (int i = 1; i < txtColNamesRow.Cells.Count; i++)
			{
				if (!txtColNamesRow.Cells[i].Visible)
					break;			// end of columns

				TextBox txtColName = (TextBox)txtColNamesRow.Cells[i].Controls[0];
				DropDownList ddColName = (DropDownList)ddColNamesRow.Cells[i].Controls[0];
				string colName = txtColName.Text;
				if (colName == "")
					colName = ddColName.SelectedValue;
				if (colName == null)
					colName = "";

				XmlElement xColElem = xdoc.CreateElement("COLUMN");
				xnode.AppendChild(xColElem);

				xColElem.SetAttribute( "NAME", colName);
				
				XmlElement xColFormats = xdoc.CreateElement("FORMATS");
				
				TextBox txtFormats = (TextBox)txtFormatsRow.Cells[i].Controls[0];

				string[] formatLines = txtFormats.Text.Split('\n', '\r');
				for (int l = 0; l < formatLines.Length; l ++)
				{
					if (formatLines[l] != "")
					{
						XmlElement xFormatElem = xdoc.CreateElement("FORMAT");
						xColFormats.AppendChild(xFormatElem);
						xFormatElem.SetAttribute("DEF", formatLines[l]);
					}
				}

				if (xColFormats.ChildNodes.Count > 0)
                    xColElem.AppendChild(xColFormats);
			}

			//Debug.WriteLine(xdoc.OuterXml);
			xdoc.Save(path);
		}

		public void LoadColumnDef(string fileName)
		{
			//RenderData();
			loadedColumns = 0;
			string path = Page.Server.MapPath(fileName); 
			
			XmlDocument xdoc = new XmlDocument();
			xdoc.Load(path);
			XmlElement xCSVElem = xdoc.DocumentElement;

			XmlNodeList xImportDefList = xCSVElem.GetElementsByTagName("ImportDEF");
			if (xImportDefList != null)
			{
				if (xImportDefList.Count > 0)
				{
					XmlElement xImportDef = (XmlElement)xImportDefList.Item(0);
					string sep = xImportDef.GetAttribute("SEPERATOR");
					if (sep.Length > 0)
					{
						csvImporter.Seperator = sep[0];
					}

					txtSeperator.Text = csvImporter.Seperator.ToString();

					string linesToSkip = xImportDef.GetAttribute("LINESTOSKIP");
					if (linesToSkip.Length > 0)
					{
						csvImporter.LinesToSkip = int.Parse(linesToSkip);
					}

					txtLinesToSkip.Text = csvImporter.LinesToSkip.ToString();
				}
			}

			XmlNodeList xColumnDefList = xCSVElem.GetElementsByTagName("ColumnDEF");
			XmlElement xColumnDef = (XmlElement)xColumnDefList[0];

			loadedColumns = xColumnDef.ChildNodes.Count;

			for (int i = 0; i < xColumnDef.ChildNodes.Count; i++)
			{
				XmlElement xColElem = (XmlElement)xColumnDef.ChildNodes[i];

				string colName = xColElem.GetAttribute("NAME");
				TextBox txtColName = (TextBox)txtColNamesRow.Cells[i + 1].Controls[0];
				DropDownList ddColName = (DropDownList)ddColNamesRow.Cells[i + 1].Controls[0];

				txtColName.Text = colName;
				TextBox txtFormats = (TextBox)txtFormatsRow.Cells[i + 1].Controls[0];
				txtFormats.Text = "";

				XmlNodeList xColFormatsNode = xColElem.GetElementsByTagName("FORMATS");
				if (xColFormatsNode != null)
				{
					if (xColFormatsNode.Count > 0)
					{
						XmlElement xColFormats = (XmlElement)xColFormatsNode[0];						

						for (int l = 0; l < xColFormats.ChildNodes.Count; l ++)
						{
							XmlElement xFormatElem = (XmlElement)xColFormats.ChildNodes[l];
							string formatDef = xFormatElem.GetAttribute("DEF");
							if (formatDef != "")
							{
								if (txtFormats.Text != "")
									txtFormats.Text += "\r\n";
								txtFormats.Text += formatDef;
							}
						}
					}
				}
			}
		}

		#endregion

		private void butAddColumn_Click(object sender, EventArgs e)
		{
			EnsureChildControls();
			RenderData();
			for (int i = 0; i < ddColNamesRow.Cells.Count; i++)
			{
				if (!ddColNamesRow.Cells[i].Visible)
				{
					//ddColNamesRow.Cells[i].Visible = true;
					loadedColumns = i;
					break;
				}
			}
			dataRendered = false;
		}

		private void butDelColumn_Command(object sender, CommandEventArgs e)
		{
			int iCol = int.Parse(e.CommandName) + 1;
			if (iCol >= 0 && iCol < ddColNamesRow.Cells.Count)
			{
				// shift column data to left
				for (int i = iCol; i < ddColNamesRow.Cells.Count - 1; i++)
				{
					((DropDownList)ddColNamesRow.Cells[i].Controls[0]).SelectedIndex = ((DropDownList)ddColNamesRow.Cells[i+1].Controls[0]).SelectedIndex;
					((DropDownList)ddColNamesRow.Cells[i].Controls[0]).SelectedValue = ((DropDownList)ddColNamesRow.Cells[i+1].Controls[0]).SelectedValue;
					((TextBox)txtColNamesRow.Cells[i].Controls[0]).Text = ((TextBox)txtColNamesRow.Cells[i+1].Controls[0]).Text;
					((TextBox)txtFormatsRow.Cells[i].Controls[0]).Text = ((TextBox)txtFormatsRow.Cells[i+1].Controls[0]).Text;
				}
				loadedColumns--;
			}
		}

		private void butRefresh_Click(object sender, EventArgs e)
		{
		}
	}
}
