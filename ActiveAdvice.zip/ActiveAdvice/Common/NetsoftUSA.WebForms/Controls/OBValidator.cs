using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using NetsoftUSA.WebForms;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Automatically creates validator controls at runtime
	/// </summary>
	[ToolboxData("<{0}:OBValidator runat=server></{0}:OBValidator>")]
	public class OBValidator : System.Web.UI.WebControls.WebControl, IObjectBoundControl//, INamingContainer // validators won't work if activated
	{
		public static string ValidationErrorMarker = "<==";		// Can be set by the application once and for all

		#region private members

		private string sourceClassName;	// source object's class type to be used in design time
		private object sourceObject = null;	// actual source object
		private string sourceMember;		// source member of the source object
		private string valMember;
		private bool disableBinding = false;	// disable data binding
		private bool newLine = true;			// each validator in a new line <BR>
		//private bool requiredValidatorOnly = false;		// use only required validator
		private EnumValidatorBehavior validatorBehavior = EnumValidatorBehavior.Default;
		private bool objectBound = false;

		private string controlToValidate = null;
		private string controlGroup = "";

		protected WebControl ctrlToValidate = null; 

		private string fieldDescription = null;
		Type type = null;
		PropertyInfo pi = null;

		CustomValidator cv = null;

		#endregion

		#region Constructors

		public OBValidator() : base()
		{
		}

		#endregion

		#region IObjectBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
			if (disableBinding)
				return;

			if (Save)
			{
				
				/*if (cv != null)
				{
					cv.Validate();
				}*/
			}
		}

		public object GetSourceObject()
		{
			return sourceObject;
		}

		public string GetSourceObjectMember()
		{
			return sourceMember;
		}

		public void SetSourceObject(object obj)
		{
			SourceObject = obj;
			EnsureChildControls();	// make actual server side validation controls available!
		}

		public void SetSourceObjectMember(string om)
		{
			SourceMemberName = om;
		}

		[Browsable(false)]
		public bool IsReadOnly
		{ 
			get { return true; } 
			set { }
		}

		[Browsable(false)]
		public bool IsEnabled
		{ 
			get { return this.Enabled; } 
			set { this.Enabled = value; }
		}

		#endregion

		#region Public functions

		public void ValidateCustom()
		{
			EnsureChildControls();
			if (cv != null)
			{
				ValidateForGet(cv);
			}
		}



		[TypeConverter(typeof(ValidatedControlConverter))]
		public string ControlToValidate
		{
			get
			{
				return controlToValidate;
			}
			set
			{
				controlToValidate = value;
			}
		}

		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.WebForms.SourceClassNamesConverter))
		]
		public string SourceClassName
		{
			get	{ return sourceClassName; }
			set	
			{ 
				sourceClassName = value; 
				OnTypeBound();
			}
		}

		private bool ValidationsOnlyInSummary
		{
			get
			{
				return ((BasePage)Page).ValidationsOnlyInSummary;
			}
		}

		/// <summary>
		/// Source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public object SourceObject
		{
			get	{	return sourceObject;	}
			set	
			{	
				sourceObject = value; 
				// once an object is bound, set it as object bound
				// so that the control won't be disabled
				objectBound = !disableBinding && sourceObject != null && sourceMember != null;

				if (this.sourceObject != null)
					if (cv != null)
					{
						string sdesc = ReflectionHelper.GetMemberValueAsString(this.sourceObject, valMember);
						cv.ErrorMessage = ((BasePage)this.Page).Language.Translate(sdesc, fieldDescription);
						if (ValidationsOnlyInSummary)
						{
							cv.Text = ValidationErrorMarker;
							cv.ToolTip = cv.ErrorMessage;
						}
					}
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.ClassMemberConverter))
		]
		public string SourceMemberName
		{
			get	{ return sourceMember; }
			set 
			{ 
				sourceMember = value; 
				if (type == null)
					OnTypeBound();	// if not bound, do type binding again.
			}
		}

		[Category("NetsoftUSA.WebForms Binding")]
		[DefaultValue(EnumValidatorBehavior.Default)]
		public EnumValidatorBehavior ValidatorBehavior
		{
			get { return this.validatorBehavior; }
			set { this.validatorBehavior = value; }
		}

		[DefaultValue(false)]
		public bool DisableBinding
		{
			get
			{
				return disableBinding;
			}
			set
			{
				disableBinding = value;
			}
		}

		[DefaultValue(true)]
		public bool NewLine
		{
			get { return newLine; }
			set { newLine = value; }
		}

		#endregion

		private void AddBR()
		{
			if (newLine && !ValidationsOnlyInSummary)
				if (this.Controls.Count > 0)
				{
					Label lb = new Label();
					lb.Text = "<BR>";
					this.Controls.Add(lb);
				}
		}

		private void AddRequiredValidator(ControlTypeAttribute ctlType)
		{
			if (!((BasePage)Page).RequiredValidationsEnabled && ((validatorBehavior & EnumValidatorBehavior.ForceRequired) == 0))
				return;
			AddBR();
			RequiredFieldValidator rv = GetNewRequiredFieldValidator();
			rv.Display = ValidatorDisplay.Dynamic;
			//rv.Width = 0;

			if (ctlType.ClientScriptForConditionalRequired != null)
				rv.Attributes["ConditionScript"] = ctlType.ClientScriptForConditionalRequired;

			if (ctlType.RequiredError == null)
				rv.ErrorMessage = String.Format("Field '{0}' is required.", fieldDescription);
			else
				rv.ErrorMessage = ((BasePage)Page).Language.Translate(ctlType.RequiredError, fieldDescription);
			if (ValidationsOnlyInSummary)
			{
				rv.Text = ValidationErrorMarker;
				rv.ToolTip = rv.ErrorMessage;
			}
			rv.ControlToValidate = controlToValidate;
			rv.ID = "req" + this.ID;
			this.Controls.Add(rv);

		}


		protected virtual RequiredFieldValidator GetNewRequiredFieldValidator()
		{
			return new RequiredFieldValidator();
		}


		private void AddDataTypeValidator(ValidationDataType dataType)
		{
			AddBR();
			CompareValidator cv = new CompareValidator();
			//cv.Width = 0;
			cv.Operator = ValidationCompareOperator.DataTypeCheck;
			cv.Type = dataType;
			cv.ErrorMessage = String.Format("Field '{0}' must be {1}.", fieldDescription, dataType.ToString());
			//cv.ErrorMessage = ((BasePage)Page).Language.Translate(ctlType.RequiredError, fieldDescription);
			if (ValidationsOnlyInSummary)
			{
				cv.Text = ValidationErrorMarker;
				cv.ToolTip = cv.ErrorMessage;
			}
			cv.ControlToValidate = controlToValidate;
			cv.ID = "dtv" + dataType.ToString() + this.ID;
			this.Controls.Add(cv);
		}

		private void AddRangeValidator(ValidationDataType dataType, object minValue, object MaxValue, string rangeError)
		{
			AddBR();
			System.Web.UI.WebControls.RangeValidator rv = new System.Web.UI.WebControls.RangeValidator();// CompareValidator();
			//cv.Width = 0;
			string Min = Convert.ToString(minValue);
			string Max = Convert.ToString(MaxValue);
			if (minValue != null)
				rv.MinimumValue = Min;
			else
			{
				if (dataType == ValidationDataType.Integer ||
					dataType == ValidationDataType.Double ||
					dataType == ValidationDataType.Currency)
					rv.MinimumValue = "0";
				else
					rv.MinimumValue = null;
			}
			if (MaxValue != null)
				rv.MaximumValue = Max;
			else
			{
				switch (dataType)
				{
					case ValidationDataType.Integer:
						rv.MaximumValue = int.MaxValue.ToString();
						break;
					case ValidationDataType.Double:
						rv.MaximumValue = double.MaxValue.ToString();
						break;
					case ValidationDataType.Currency:
						rv.MaximumValue = Decimal.MaxValue.ToString();
						break;
					default:
						rv.MaximumValue = null;
						break;
				}
			}
			rv.Type = dataType;
			
			if (rangeError != null)
				rv.ErrorMessage = ((BasePage)Page).Language.Translate(rangeError, fieldDescription, Min, Max);
			else
				rv.ErrorMessage = String.Format("Field '{0}' must be between {1} and {2}.", fieldDescription, Min, Max);
			if (ValidationsOnlyInSummary)
			{
				rv.Text = ValidationErrorMarker;
				rv.ToolTip = rv.ErrorMessage;
			}
			rv.ControlToValidate = controlToValidate;
			rv.ID = "ranv" + dataType.ToString() + this.ID;
			this.Controls.Add(rv);
		}

		private string getValidationFriendlyName(string valType)
		{
			switch (valType)
			{
				case "USSSN": 
					return "SS #";
				case "USZipCode": 
					return "Zip Code";
				case "USPhoneNumber": 
					return "Phone Number";
				default:
					return valType;
			}
		}

		private void AddRegexValidator(string valType, string valex)
		{
			AddRegexValidator(valType, valex, null);
		}

		private void AddRegexValidator(string valType, string valex, string errorMsg)
		{
			AddBR();
			RegularExpressionValidator rv = new RegularExpressionValidator();
			//rv.Width = 0;
			rv.ValidationExpression = valex;
			if (errorMsg == null)
				rv.ErrorMessage = String.Format("Field '{0}' must be a valid {1}.", fieldDescription, getValidationFriendlyName(valType));
			else
				rv.ErrorMessage = ((BasePage)Page).Language.Translate(errorMsg, fieldDescription);
			if (ValidationsOnlyInSummary)
			{
				rv.Text = ValidationErrorMarker;
				rv.ToolTip = rv.ErrorMessage;
			}
			rv.ControlToValidate = controlToValidate;
			rv.ID = "rxv" + valType + this.ID;
			this.Controls.Add(rv);
		}

		private void AddCustomValidator(string valMember)
		{
			AddBR();
			cv = new CustomValidator();
			//cv.Width = 0;
			cv.ControlToValidate = controlToValidate;
			cv.ID = "custv" + valMember + this.ID;
			cv.ServerValidate+=new ServerValidateEventHandler(cv_ServerValidate);
	
			ClientScriptAttribute clientScript = null;
			//string validatorMember = ValidatorMemberAttribute.GetValidatorMember(mi);
			//if (validatorMember != null)
			clientScript = ClientScriptAttribute.GetFromMember(pi.DeclaringType, valMember);

			//ClientScriptAttribute clientScript = ClientScriptAttribute.GetClientValidationScriptAttrib(mi);
			if (clientScript != null)
			{
				string clientScriptKey = clientScript.Name;
				if (!this.Page.IsClientScriptBlockRegistered(clientScriptKey))
				{
					string s = String.Format("<script>\r\nfunction {0}(source, arguments)\r\n{{\r\n{1}\r\n}}\r\n</script>\r\n", clientScriptKey, clientScript.JScript); 
					this.Page.RegisterClientScriptBlock("clientScript", s);
				}
				cv.ClientValidationFunction = clientScriptKey;

				string sdesc = ReflectionHelper.GetMemberValueAsString(this.sourceObject, valMember);
				cv.ErrorMessage = ((BasePage)this.Page).Language.Translate(sdesc, fieldDescription);
				if (ValidationsOnlyInSummary)
				{
					cv.Text = ValidationErrorMarker;
					cv.ToolTip = cv.ErrorMessage;
				}
			}
			else
			{
				// check if the generic script is defined
				// registers
				GenericScriptAttribute genScrAtt = GenericScriptAttribute.GetFromMember(pi.DeclaringType, valMember);
				if (genScrAtt != null)
				{
					cv.ClientValidationFunction = genScrAtt.GetUniqueFunctionName();
					if (this.sourceObject != null)
					{
						string sdesc = ReflectionHelper.GetMemberValueAsString(this.sourceObject, valMember);
						cv.ErrorMessage = ((BasePage)this.Page).Language.Translate(sdesc, fieldDescription);
						if (ValidationsOnlyInSummary)
						{
							cv.Text = ValidationErrorMarker;
							cv.ToolTip = cv.ErrorMessage;
						}
					}
					else
					{
						cv.ErrorMessage = (string)ViewState["cvm"];
						if (ValidationsOnlyInSummary)
						{
							cv.Text = ValidationErrorMarker;
							cv.ToolTip = cv.ErrorMessage;
						}
					}
				}
			}
			this.Controls.Add(cv);
		}

		protected virtual void OnTypeBound()
		{
			if (sourceMember != null)
			{
				try
				{
					type = Type.GetType(sourceClassName);
					pi = type.GetProperty(sourceMember);
					//if (pi != null)
					//	memberType = pi.PropertyType;
				}
				catch
				{
				}
			}
		}
		
		/// <summary>
		/// 
		/// </summary>
		protected override void CreateChildControls()
		{
			try
			{
				if (!((BasePage)Page).ValidationsEnabled)
					return;

				/*type = Type.GetType(sourceClassName);
				if (type == null)
					return;

				pi = type.GetProperty(sourceMember);*/

				fieldDescription = FieldDescriptionAttribute.GetDescription(pi, true);
				fieldDescription = ((BasePage)Page).Language.Translate(fieldDescription);
				ControlTypeAttribute ctlType = ControlTypeAttribute.GetFromProp(pi, true);
				valMember = ValidatorMemberAttribute.GetValidatorMember(pi);
				//return;	// cancel validations
				switch (validatorBehavior)
				{
					case EnumValidatorBehavior.ForceNotRequired:
						break;	// never add required validator
					case EnumValidatorBehavior.ForceRequired:
						AddRequiredValidator(ctlType);	// always add required validator
						break;
					default:
						//break;	//  !!!! temporary until combo validation fixed!
						
						// add required if declared
						if ((ctlType.ClientValidators & EnumClientValidators.Required) != 0)
							AddRequiredValidator(ctlType);
						break;
				}

				if (validatorBehavior != EnumValidatorBehavior.RequiredOnly)
				{
					ValidationDataType dataType = ValidationDataType.String;
					if ((ctlType.ClientValidators & EnumClientValidators.Integer) != 0)
					{
						dataType = ValidationDataType.Integer;
						AddDataTypeValidator(ValidationDataType.Integer);
					}

					if ((ctlType.ClientValidators & EnumClientValidators.Double) != 0)
					{
						dataType = ValidationDataType.Double;
						AddDataTypeValidator(ValidationDataType.Double);
					}

					if ((ctlType.ClientValidators & EnumClientValidators.Date) != 0)
					{
						dataType = ValidationDataType.Date;
						AddDataTypeValidator(ValidationDataType.Date);
					}

					if ((ctlType.ClientValidators & EnumClientValidators.DateTime) != 0)
					{
						AddRegexValidator("DateTime", ValidationExpression.DateTime);
					}

					if ((ctlType.ClientValidators & EnumClientValidators.Currency) != 0)
					{
						dataType = ValidationDataType.Currency;
						AddDataTypeValidator(ValidationDataType.Currency);
					}

					if ((ctlType.ClientValidators & EnumClientValidators.String) != 0)
						AddDataTypeValidator(ValidationDataType.String);

					if ((ctlType.ClientValidators & EnumClientValidators.URL) != 0)
						AddRegexValidator("URL", ValidationExpression.URL);

					if ((ctlType.ClientValidators & EnumClientValidators.Email) != 0)
						AddRegexValidator("Email", ValidationExpression.Email);
				
					if ((ctlType.ClientValidators & EnumClientValidators.USZipCode) != 0)
						AddRegexValidator("USZipCode", ValidationExpression.USZipCode);

					if ((ctlType.ClientValidators & EnumClientValidators.USSSN) != 0)
						AddRegexValidator("USSSN", ValidationExpression.USSSN);

					if ((ctlType.ClientValidators & EnumClientValidators.USPhoneNumber) != 0)
						AddRegexValidator("USPhoneNumber", ValidationExpression.USPhoneNumber);

					if ((ctlType.ClientValidators & EnumClientValidators.USPhoneNumberRaw) != 0)
						AddRegexValidator("USPhoneNumber", ValidationExpression.USPhoneNumberRaw);

					if (ctlType.RegExValidator != null)
						AddRegexValidator("RegEx", ctlType.RegExValidator);

					if (ctlType.MinValue != null || ctlType.MaxValue != null)
						AddRangeValidator(dataType, ctlType.MinValue, ctlType.MaxValue, ctlType.RangeError);

					if (valMember != null)
						AddCustomValidator(valMember);
				}
			}
			catch(Exception ex)
			{
				Debug.WriteLine(ex.ToString());
				return;
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			if (this.controlToValidate != null)
			{
				ctrlToValidate = NamingContainer.FindControl(this.controlToValidate) as WebControl;
				if (ctrlToValidate != null)
				{
					this.Attributes["ControlType"] = ctrlToValidate.GetType().Name;
					
					// Set each validator's controltype attribute 
					foreach (WebControl control in this.Controls)
					{
						System.Web.UI.IValidator vld = control as System.Web.UI.IValidator;
						if (vld != null)
						{
							control.Attributes["ControlType"] = ctrlToValidate.GetType().Name;

						}
					}

				}

				this.Style["DISPLAY"] = "none";
			}



//			// fill the controlGroup attributes of contained controls
//			foreach (WebControl ctl in this.Controls)
//			{
//				System.Web.UI.IValidator vld = ctl as System.Web.UI.IValidator;
//				if (vld != null)
//				{
//					ctl.Attributes["ControlGroup"] = this.controlGroup;
//				}
//			}
		}


		protected override void Render(HtmlTextWriter writer)
		{
			if (this.Site != null)
				if (this.Site.DesignMode)
				{
					Label lb = new Label();
					//lb.Text = "<div alt='aa' style='overflow:auto;width:64;height:32;border:1px solid black'> " + this.sourceMember + "! </div>";
					//lb.Text = "[ !!! ]";// this.sourceMember + "!";
					lb.Text = ValidationErrorMarker; //this.sourceMember + "!";
					//lb.Font.Size = FontUnit.Point(5);
					lb.ForeColor = System.Drawing.Color.Red;
					lb.RenderControl(writer);
					return;
				}

			if (this.IsViewOnly || !IsTargetControlEnabled)	//((BasePage)Page).DataEntryPage 
			{
				this.Enabled = false; // Hide all the validators

				// Set each validator's controltype attribute 
				foreach (WebControl control in this.Controls)
				{
					System.Web.UI.IValidator vld = control as System.Web.UI.IValidator;
					if (vld != null)
					{
						control.Enabled = false;

					}
				}
			}
			//else
			base.Render(writer);
		}

		public bool IsViewOnly
		{
			get
			{
				if (((BasePage)Page).IsViewOnly)
					return true;
				return ((BasePage)Page).ClassBindings.GetViewOnly(type);
			}
		}

		public virtual bool IsTargetControlEnabled
		{
			get
			{
				if (ctrlToValidate == null) return true;
				IObjectBoundControl iobctl = ctrlToValidate as IObjectBoundControl;
				if (iobctl != null)
					return iobctl.IsEnabled;
				else
					return ctrlToValidate.Enabled;
			}
		}


		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			objectBound = (bool)ViewState["ob"];
		}

		protected override object SaveViewState()
		{
			ViewState["ob"] = objectBound;
			string cvm = null;
			if (cv != null)
				cvm = cv.ErrorMessage;
			ViewState["cvm"] = cvm;

			return base.SaveViewState ();
		}

		private bool ValidateForGet(CustomValidator cv)
		{
			if (pi == null || this.sourceObject == null)
			{
				cv.IsValid = true;
				return true;
			}

			try
			{
				// the validation may return a warning prompt message
				// or throw an exception.
				// if it throws, the validator.IsValid = false
				string prompt = ValidatorMemberAttribute.ValidateMemberForGet(pi, this.sourceObject);
				string sdesc = ((BasePage)this.Page).Language.Translate(prompt);
				if (prompt != null && prompt != "")
					cv.IsValid = false;
				else
					cv.IsValid = true;
				cv.ErrorMessage = sdesc;
				if (ValidationsOnlyInSummary)
				{
					cv.Text = ValidationErrorMarker;
					cv.ToolTip = cv.ErrorMessage;
				}
				return false;
			}
			catch (ValidationException vlex)
			{
				// get-validation thrown an exception!  validation failed!
				cv.IsValid = false;
				cv.ErrorMessage = vlex.Message;
				if (ValidationsOnlyInSummary)
					cv.Text = ValidationErrorMarker;
				cv.ToolTip = vlex.LongMessage;
				return false;
			}
		}

		private void cv_ServerValidate(object source, ServerValidateEventArgs args)
		{
			if (pi == null || this.sourceObject == null)
			{
				args.IsValid = true;
				return;
			}

			try
			{
				if (((BasePage)this.Page).IsSavingToObject)	// reading from control and saving to object
					ValidatorMemberAttribute.ValidateMemberForSet(pi, this.sourceObject, args.Value);
				else	// reading from object and populating to control
					ValidatorMemberAttribute.ValidateMemberForGet(pi, this.sourceObject);
			}
			catch (ValidationException vlex)
			{
				CustomValidator cv = (CustomValidator)source;
				args.IsValid = false;
				cv.ErrorMessage = vlex.Message;
				if (ValidationsOnlyInSummary)
					cv.Text = ValidationErrorMarker;
				cv.ToolTip = vlex.LongMessage;
				return;
			}
			args.IsValid = true;
		}

		[DefaultValue("")]
		public string ControlGroup
		{
			get { return this.controlGroup; }
			set { this.controlGroup = value; }
		}

	}



	public enum EnumValidatorBehavior
	{
		Default = 0,
		ForceRequired = 1,
		ForceNotRequired = 2,
		RequiredOnly = 3
	}
}
