using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Text;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for NSExpandable.
	/// </summary>
	[ToolboxData("<{0}:NSExpandable runat=server>Netsoft USA Expandable Control</{0}:NSExpandable>")]
	public class NSExpandable : Panel
	{
		private bool expanded = false;
		private bool floating = false;		// make the expandable floating over the page
		private bool autoHide = false;		// expandable will hide when the mouse is clicked outside

		private string controllingCheckBox = null;
		private string toggleButton = null;
		private string closeButton = null;
		private string openButton = null;
		private string abspos = "";

		internal CheckBox controllingCheckBoxCtl = null;
		internal HtmlInputButton toggleButtonCtl = null;

		public NSExpandable() : base()
		{
		}

		/// <summary> 
		/// Render this control to the output parameter specified.
		/// </summary>
		/// <param name="output"> The HTML writer to write out to </param>
		/*protected override void Render(HtmlTextWriter output)
		{
			output.Write("");
		}*/

		public void registerClientScripts()
		{
			string svarname = ClientObjectName;
			((BasePage)Page).RegisterDeclarationScript(svarname, 
				"var " + svarname +
				"=new Expandable(" + this.ClientID +
				", " + floating.ToString().ToLower() + 
				", " + autoHide.ToString().ToLower() + ");\n");
		}

		public string getIsExpandedScript()
		{
			return ClientObjectName + ".isExpanded()";
		}

		public string getExpandScript(string expand)
		{
			return ClientObjectName + ".expand( " + expand + ")";
		}

		public string getExpandScript(bool expand)
		{
			return getExpandScript(expand.ToString().ToLower());
		}

		public string getExpandScript(CheckBox chkBox)
		{
			return ClientObjectName + ".expandForCheckBox()";
			//return "window.alert(" + chkBox.ClientID + ".checked" + ");" + getExpandScript(chkBox.ClientID + ".checked");
		}

		public string getExpandScript(HtmlInputCheckBox chkBox)
		{
			return ClientObjectName + ".expandForCheckBox()";
			//return getExpandScript(chkBox.ClientID + ".checked");
		}

		public string getToggleExpandScript()
		{
			return ClientObjectName + ".toggleExpand()";
		}

		public string ClientObjectName
		{
			get
			{
				return "Expandable_" + this.ClientID; // ID;
			}
		}

		private void ManageControllingButton(string butID, HtmlInputButton buttonCtl, string script, string chkBoxID)
		{
			//string objName = this.ClientObjectName;
			//script += ";" + chkBoxID + ".checked=" + objName + ".isExpanded()";
			try
			{
				if (buttonCtl != null)
				{
					//expanded = htmlchk.Checked;
					buttonCtl.Attributes["onclick"] = ";" + script;
				}

				Control ctl = this.Page.FindControl(butID);
				Button but = ctl as Button;
				if (but != null)
				{
					but.Attributes["onclick"] = ";" + script;
				}
				else
				{
					HtmlButton htmlbut = ctl as HtmlButton;
					if (htmlbut != null)
					{
						//expanded = htmlchk.Checked;
						htmlbut.Attributes["onclick"] += ";" + script;
					}
					else
					{
						HtmlInputButton htmlinpbut = ctl as HtmlInputButton;
						if (htmlinpbut != null)
						{
							//expanded = htmlchk.Checked;
							htmlinpbut.Attributes["onclick"] += ";" + script;
						}
					}
				}
			}
			catch (Exception)
			{
				// ignore
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			EnsureChildControls();

			if (floating)
			{
				string[] pos = null;
				if (abspos != "")
					pos = abspos.Split(',');
				else
					pos = new string[2] {"", ""};

				this.Style["POSITION"] = "ABSOLUTE";
				this.Style["Z-INDEX"] = "10000";
				this.Style["LEFT"] = pos[0];
				this.Style["TOP"] = pos[1];
				/*if (this.Style["BACKGROUND-COLOR"] == null)
					this.Style["BACKGROUND-COLOR"] = "window";*/
			}

			string svarname = ClientObjectName;
			string chkID = null;
			bool bAutoPostBack = false;
			if (controllingCheckBox != null || controllingCheckBoxCtl != null)
			{
				try
				{
					Control ctl = controllingCheckBoxCtl;
					if (ctl == null)
						ctl = this.Page.FindControl(controllingCheckBox);
					CheckBox chk = ctl as CheckBox;
					if (chk != null)
					{
						chkID = chk.ClientID;
						expanded = chk.Checked;
						if (chk.AutoPostBack)
							bAutoPostBack = true;
						else
							chk.Attributes["onclick"] = ";" + getExpandScript(chk);
						
					}
					else
					{
						chkID = chk.ClientID;
						HtmlInputCheckBox htmlchk = ctl as HtmlInputCheckBox;
						if (htmlchk != null)
						{
							expanded = htmlchk.Checked;
							htmlchk.Attributes["onclick"] = ";" + getExpandScript(htmlchk);
						}
					}
				}
				catch (Exception)
				{
					// ignore
				}
			}
			
			if (!bAutoPostBack)
			{
				registerClientScripts();

				// associate the client object with the controlling checkbox
				((BasePage)Page).RegisterOnLoadScript(svarname + "_CtlChkBox", 
					svarname + ".controllingCheckBox=document.all['" + chkID + "'];\n");
			}

			if (toggleButton != null || toggleButtonCtl != null)
				ManageControllingButton(toggleButton, toggleButtonCtl, getToggleExpandScript(), chkID);

			if (openButton != null)
				ManageControllingButton(openButton, null, getExpandScript(true), chkID);

			if (closeButton != null)
				ManageControllingButton(closeButton, null, getExpandScript(false), chkID);

			/*
			if (controllingButton != null)
			{
				try
				{
					Control ctl = this.Page.FindControl(controllingButton);
					Button but = ctl as Button;
					if (but != null)
					{
						but.Attributes["onclick"] = "javascript:" + getToggleExpandScript();
					}
					else
					{
						HtmlButton htmlbut = ctl as HtmlButton;
						if (htmlbut != null)
						{
							//expanded = htmlchk.Checked;
							htmlbut.Attributes["onclick"] = "javascript:" + getToggleExpandScript();
						}
						else
						{
							HtmlInputButton htmlinpbut = ctl as HtmlInputButton;
							if (htmlinpbut != null)
							{
								//expanded = htmlchk.Checked;
								htmlinpbut.Attributes["onclick"] = "javascript:" + getToggleExpandScript();
							}
						}
					}
				}
				catch (Exception ex)
				{
					// ignore
				}
			}*/

			if (expanded)
				this.Style["DISPLAY"] = "";
			else
				this.Style["DISPLAY"] = "NONE";

			base.OnPreRender (e);
		}

		[Browsable(true), DefaultValue(false)]
		public bool Expanded
		{
			get
			{
				return expanded;
			}
			set
			{
				expanded = value;
			}
		}

		[Browsable(true), DefaultValue(false)]
		public bool Floating
		{
			get
			{
				return floating;
			}
			set
			{
				floating = value;
			}
		}

		[Browsable(true), DefaultValue(false)]
		public bool AutoHide
		{
			get
			{
				return autoHide;
			}
			set
			{
				autoHide = value;
			}
		}

		[Category("Controlling button"),
		TypeConverter(typeof(CheckBoxTypeConverter))]
		public string ControllingCheckBox
		{
			get
			{
				return controllingCheckBox;
			}
			set
			{
				controllingCheckBox = value;
			}
		}


		[Category("Controlling button"),
		TypeConverter(typeof(ButtonTypeConverter))]
		public string ToggleButton
		{
			get
			{
				return toggleButton;
			}
			set
			{
				toggleButton = value;
			}
		}

		[Category("Controlling button"),
		TypeConverter(typeof(ButtonTypeConverter))]
		public string OpenButton
		{
			get
			{
				return openButton;
			}
			set
			{
				openButton = value;
			}
		}

		[Category("Controlling button"),
		TypeConverter(typeof(ButtonTypeConverter))]
		public string CloseButton
		{
			get
			{
				return closeButton;
			}
			set
			{
				closeButton = value;
			}
		}

		protected override void Render(HtmlTextWriter writer)
		{
			base.Render (writer);

			if (floating)
			{
				writer.Write("<input type=hidden id='{0}' name='{0}' value=\"{1}\">", 
					this.ClientID + "_abspos",
					abspos);
			}
		}

		protected override void LoadViewState(object savedState)
		{
			if (Page.IsPostBack)
			{
				abspos = Page.Request.Form[this.ClientID + "_abspos"];
			}

			base.LoadViewState (savedState);
		}

	}

}
