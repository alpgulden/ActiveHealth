using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Reflection;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NetsoftUSA.WebForms.IObjectBoundControl implementer for a button type
	/// UI control.  Validation and Formatting functionalities are abstracted 
	/// from this control.
	/// </summary>
	[DefaultProperty("Text"), 
		ToolboxData("<{0}:OBButton runat=server></{0}:OBButton>")
	]
	public class OBButton : System.Web.UI.WebControls.Button, IObjectBoundControl, IControlGroupProvider, IIsDirtyCheck //, INamingContainer
	{
		#region private members
		private string sourceClassName;	// source object's class type to be used in design time
		private object sourceObject = null;	// actual source object
		private string sourceMember;		// source member of the source object
		private bool disableBinding = false;	// disable data binding to NSDataComps

		private string errorDisplay;	// if this is not null, it will be displayed when rendering
		private string errorLongDisplay;	// if this is not null, it will be displayed in tooltip when rendering
		//private NSLabel errorLabel;

		private string textToTranslate;	// the text to be translated and set to text
		private string textToTranslateParameters;	// parameters to be translated and substituted into {0}, {1} .. in textToTranslate

		private bool objectBound = false;

		private string controlGroup = "";
		private bool checksForIsDirty = true;

		private string onClickScript = null;

		public static string CssAll = "";
		private string css = null;

		#endregion

		#region Constructors

		public OBButton() : base()
		{
			/*errorLabel = new NSLabel();
			errorLabel.ForeColor = System.Drawing.Color.Red;
			*/
		}
		#endregion

		#region IObjectBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
			if (disableBinding)
				return;

			errorDisplay = "";
			errorLongDisplay = "";
			if (sourceObject != null && sourceMember != null)
			{
				if (!Save)
				{	
					// data to object
					try
					{
						this.Text = ReflectionHelper.GetMemberValueAsString(sourceObject, sourceMember);
					}
					catch(Exception ex)
					{
						errorDisplay = "???"; //ex.Message;
						errorLongDisplay = ex.Message;
						((BasePage)Page).RaisePageException(ex);
					}
				}
			}
		}

		public object GetSourceObject()
		{
			return sourceObject;
		}

		public string GetSourceObjectMember()
		{
			return sourceMember;
		}

		public void SetSourceObject(object obj)
		{
			SourceObject = obj;
		}

		public void SetSourceObjectMember(string om)
		{
			SourceMemberName = om;
		}

		[Browsable(false)]
		public bool IsReadOnly 
		{ 
			get { return true; } 
			set {}
		}

		[Browsable(false)]
		public bool IsEnabled
		{ 
			get { return this.Enabled; } 
			set { this.Enabled = value; }
		}

		#endregion
		
		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
			Browsable(true),
			TypeConverter(typeof(NetsoftUSA.WebForms.SourceClassNamesConverter))
		]
		public string SourceClassName
		{
			get	{ return sourceClassName; }
			set	{ sourceClassName = value; }
		}

		/// <summary>
		/// Source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public object SourceObject
		{
			get	{	return sourceObject;	}
			set	
			{	
				sourceObject = value; 
				// once an object is bound, set it as object bound
				// so that the control won't be disabled
				objectBound = !disableBinding && sourceObject != null && sourceMember != null;
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
			Browsable(true),
			TypeConverter(typeof(NetsoftUSA.DataLayer.ClassMemberConverter))
		]
		public string SourceMemberName
		{
			get	{ return sourceMember; }
			set
			{ 
				sourceMember = value; 
			}
		}


		// This function gets only the value portion of the text.
		// For example 2-Question  will return 2
		public string GetValText()
		{
			string[] terms = Text.Split('-');
			if (terms[0].Length == 0)
				return Text;
			else
				return terms[0];
		}

		public Type GetDataType()
		{
			if (sourceObject != null)
				return ReflectionHelper.GetMemberType(sourceObject, sourceMember);
			else
				return ReflectionHelper.GetMemberType(Type.GetType(sourceClassName), sourceMember);
		}

		public object GetValue()
		{
			return Convert.ChangeType(GetValText(), GetDataType());
		}

		[DefaultValue(false)]
		public bool DisableBinding
		{
			get
			{
				return disableBinding;
			}
			set
			{
				disableBinding = value;
			}
		}

		[Category("Appearance")]
		[Editor(typeof(LangMessageEditor), typeof(System.Drawing.Design.UITypeEditor))]
		public string TextToTranslate
		{
			get	{ return textToTranslate; }
			set	
			{ 
				textToTranslate = value; 
			}
		}

		[Category("Appearance")]
		[Editor(typeof(LangMessageEditor), typeof(System.Drawing.Design.UITypeEditor))]
		[DefaultValue((string)null)]
		public string TextToTranslateParameters
		{
			get	{ return textToTranslateParameters; }
			set	
			{ 
				textToTranslateParameters = value; 
			}
		}

		[Category("Appearance")]
		public string Css
		{
			get { return css; }
			set 
			{ 
				css = value; 
				if (this.Site != null)
					if (this.Site.DesignMode)
					{
						this.CssClass = getValidCss(this.css, OBButton.CssAll);
					}
			}
		}


		internal string getValidCss(string css, string cssAll)
		{
			if (css != null)
				if (css != "")
				{
					return css;
				}
			return cssAll;
		}


		#endregion
	
		protected override void OnPreRender(EventArgs e)
		{
			this.CssClass = getValidCss(this.css, OBButton.CssAll);
			this.Attributes["onclick"] = onClickScript + ";if ( typeof(OBButton_OnClick) == 'function' && !OBButton_OnClick('" + this.ClientID + "')) return false;";
			base.OnPreRender (e);
		}


		protected override void Render(HtmlTextWriter writer)
		{
			string oldText = this.Text;
			bool oldEnabled = this.Enabled;
			if (this.Site != null)
				if (this.Site.DesignMode)
				{
					if (!disableBinding && sourceMember != null && sourceMember != "")
					{
						this.Text = "[" + sourceMember + "]";
						base.Render(writer);
						this.Text = oldText;
						return;
					}
					else
					{
						//SetTranslatedText();
						this.Text = textToTranslate;
						base.Render(writer);
						this.Text = oldText;
						return;
					}
				}

			if (objectBound)
			{
				base.Render (writer);
				if (errorDisplay != null)
					if (errorDisplay.Length > 0)
					{
						NSLabel errorLabel = new NSLabel();
						errorLabel.ForeColor = System.Drawing.Color.Red;
						errorLabel.Text = errorDisplay;

						if (errorLongDisplay != null)
							if (errorLongDisplay.Length > 0)
							{
								errorLabel.ToolTip = errorLongDisplay;
								errorLabel.Font.Underline = true;
							}
						errorLabel.RenderControl(writer);

						this.Text = oldText;
						this.Enabled = oldEnabled;
					}
			}
			else
			{
				//this.Text = ((BasePage)this.Page).Language.Translate(this.textToTranslate);
				//this.Enabled = false;
				//if (!this.objectBound)
				SetTranslatedText();
				base.Render (writer);
			}

			
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			errorDisplay = (string)ViewState["err"];
			objectBound = (bool)ViewState["ob"];
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);

			//if (!this.objectBound)
			//	SetTranslatedText();
		}


		private void SetTranslatedText()
		{
			try
			{
				if (this.textToTranslate != null && this.textToTranslate != "")
				{
					string[] parameters = null;
					if (this.textToTranslateParameters != null)
						parameters = this.textToTranslateParameters.Split('|');
					this.Text = ((BasePage)this.Page).Language.Translate(true, this.textToTranslate, parameters);
				}
				else
					this.Text = this.Text;
			}
			catch(Exception ex)
			{
				this.Text = ex.Message;
			}
		}

		protected override object SaveViewState()
		{
			ViewState["err"] = errorDisplay;
			ViewState["ob"] = objectBound;

			return base.SaveViewState ();
		}


		/// <summary>
		/// If controlGroup is not specified, the control will inherit it from its parent
		/// </summary>
		[DefaultValue("")]
		public string ControlGroup
		{
			get { return this.controlGroup; }
			set { this.controlGroup = value; }
		}

		public bool ChecksForIsDirty
		{
			get { return this.checksForIsDirty; }
			set { this.checksForIsDirty = value; }
		}

		public string OnClickScript
		{
			get { return this.onClickScript; }
			set { this.onClickScript = value; }
		}


	}
}
