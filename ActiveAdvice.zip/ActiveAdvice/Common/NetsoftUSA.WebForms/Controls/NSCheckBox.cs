using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for NSLabel.
	/// </summary>
	[ToolboxData("<{0}:NSCheckBox runat=server></{0}:NSCheckBox>")
		/*System.ComponentModel.Design.Serialization.DesignerSerializer(
		typeof(NetsoftUSA.WebForms.NSLabelCodeSer), 
		typeof(System.ComponentModel.Design.Serialization.CodeDomSerializer))*/
	]
	public class NSCheckBox : System.Web.UI.WebControls.CheckBox, IDataBoundControl, INamingContainer
	{
		#region protected members
		protected string dataSourceName;	// actual source dataset name
		protected NetsoftUSA.DataLayer.DCBase dataSource = null;	// actual source data component
		protected string dataMember;	// in the form of Table.Field
		protected string dataTable;	// parsed from dataMember
		protected string dataField;	// parsed from dataMember

		private string errorDisplay;	// if this is not null, it will be displayed when rendering
		private string errorLongDisplay;	// if this is not null, it will be displayed in tooltip when rendering
		//private NSLabel errorLabel;

		protected DataRowView rowView = null;	// Row view to use, if null, use data comp's current row view

		#endregion

		#region Constructors
		public NSCheckBox() : base()
		{
			/*errorLabel = new NSLabel();
			errorLabel.ForeColor = System.Drawing.Color.Red;
			*/
		}
		#endregion


		#region IDataBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public virtual void UpdateData(bool Save)
		{
			errorDisplay = "";
			errorLongDisplay = "";
			if (dataSource != null)
			{
				if (dataMember != null)
				{
					if ((dataTable != null) && (dataField != null))
					{
						if (!Save)
						{
							// find out table using the contained main dataset
							DataSet ds = dataSource.GetMainDataSet();
							DataTable table = ds.Tables[dataTable];
							DataColumn col = table.Columns[dataField];
							this.Enabled = true;
							DataRowView rowView = GetCurrentDataRowView();
							if (rowView == null)
								return;
							try
							{
								// normay the formatter object will be employed here
								this.Checked = Convert.ToBoolean(rowView[dataField]); //DataSourceObject.FormatTableItem(rowView, dataField, formatWithValue);
							}
							catch(System.Data.NoNullAllowedException noNull)
							{
								errorDisplay = this.dataField + " can't be null";
								((BasePage)Page).RaisePageException(noNull);
							}
							catch(System.ArgumentException argEx)
							{
								errorDisplay = "Invalid entry";
								((BasePage)Page).RaisePageException(argEx);
							}
							catch(Exception ex)
							{
								errorDisplay = "???"; //ex.Message;
								errorLongDisplay = ex.Message;
								((BasePage)Page).RaisePageException(ex);
							}

							// If no error occured handle custom validation
							if (errorDisplay == "")
							{
								try
								{
									dataSource.ValidateTableItem(rowView, dataField);
								}
								catch(ValidationException valEx)
								{
									errorDisplay = valEx.Message;
									errorLongDisplay = valEx.LongMessage;
									((BasePage)Page).RaisePageException(valEx);
								}
								catch(Exception ex)
								{
									errorDisplay = "???"; //ex.Message;
									errorLongDisplay = ex.Message;
									((BasePage)Page).RaisePageException(ex);
								}
							}
						}
						else
						{
							// data to control
							// normay the formatter object will be employed here
							try
							{
								rowView[dataField] = this.Checked;
							}
							catch(Exception ex)
							{
								//this.Enabled = false;
								errorDisplay = "???"; //ex.Message;
								errorLongDisplay = ex.Message;
								((BasePage)Page).RaisePageException(ex);
							}
						}
					}
				}
			}
		}

		public DCBase GetDataSource()
		{
			return dataSource;
		}

		public string GetDataMember()
		{
			return dataMember;
		}

		public void SetDataSource(DCBase dc)
		{
			dataSource = dc;
		}

		public void SetDataMember(string dm)
		{
			DataMemberName = dm;
		}

		#endregion

		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataSourceConverter))
		]
		public string DataSourceName
		{
			get
			{
				return dataSourceName;
			}
			set
			{
				dataSourceName = value;

				//!!! add code to set dataSource object
			}
		}

		/// <summary>
		/// Data source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public NetsoftUSA.DataLayer.DCBase DataSourceObject
		{
			get
			{
				return dataSource;
			}
			set
			{
				dataSource = value;		// code serializer generated code calls this.
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.DataTableAndItemConverter))
		]
		public string DataMemberName
		{
			get
			{
				return dataMember;
			}
			set
			{
				dataMember = value;
				dataTable = null;
				dataField = null;

				if (dataMember != null)
				{
					string[] memberTerms = dataMember.Split('.');
					if (memberTerms.Length == 2)
					{
						dataTable = memberTerms[0];
						dataField = memberTerms[1];
					}
					else
					{
						if (dataMember != "")
						{
							dataMember = null;
							throw new Exception("This type of data member not handled yet!");
						}
					}
				}
			}
		}

		/// <summary>
		/// Forces the textbox to use the specifed rowView instead of 
		/// getting current rowview from datacomponent.
		/// </summary>
		/// <param name="rowView"></param>
		public void SetCurrentDataRowView(DataRowView rowView)
		{
			this.rowView = rowView;
		}

		public DataRowView GetCurrentDataRowView()
		{
			if (this.rowView == null)
				return dataSource.GetCurrentDataRowView(dataTable);
			else
				return rowView;
		}

		public string GetValText()
		{
			if (this.Checked)
				return "1";
			else
				return "0";
		}

		protected override void Render(HtmlTextWriter writer)
		{
			bool oldChecked = this.Checked;
			bool oldEnabled = this.Enabled;

			bool render = true;
			if (dataSource != null && dataTable != null)
				if (!dataSource.IsValidRowPos(dataTable))
					render = false;
			if (render)
			{
				base.Render (writer);
				if (errorDisplay != null)
					if (errorDisplay.Length > 0)
					{
						NSLabel errorLabel = new NSLabel();
						errorLabel.ForeColor = System.Drawing.Color.Red;
						errorLabel.Text = errorDisplay;
						errorLabel.RenderControl(writer);
						//writer.Write("<SPAN fontcolor=red> " + errorDisplay + "</SPAN>");
					}
			}
			else
			{
				this.Checked = false;
				this.Enabled = false;
				base.Render (writer);
			}

			this.Checked = oldChecked;
			this.Enabled = oldEnabled;
		}


		#endregion
	}
}
