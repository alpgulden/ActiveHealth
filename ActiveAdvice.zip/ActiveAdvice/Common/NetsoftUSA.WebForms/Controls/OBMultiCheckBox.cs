using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Reflection;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NetsoftUSA.WebForms.IDataBoundControl implementer for a combobox type
	/// UI control.  Validation and Formatting functionalities are abstracted 
	/// from this control.
	/// </summary>
	[ToolboxData("<{0}:OBMultiCheckBox runat=server></{0}:OBMultiCheckBox>") /*,
	System.ComponentModel.Design.Serialization.DesignerSerializer(
		typeof(NetsoftUSA.WebForms.OBComboBoxCodeSer), 
		typeof(System.ComponentModel.Design.Serialization.CodeDomSerializer))*/]
	public class OBMultiCheckBox : System.Web.UI.WebControls.CheckBoxList, IObjectBoundControl, INamingContainer
	{
		#region private members
		private string sourceClassName;	// source object's class type to be used in design time
		private Type type = null;
		private object sourceObject = null;	// actual source object
		private string sourceMember;		// source member of the source object
		private bool disableBinding = false;	// disable data binding to NSDataComps
		private bool noUpdateIfReadOnly = true;	// if readonly, do not update the bound member

		private string errorDisplay;	// if this is not null, it will be displayed when rendering
		private string errorLongDisplay;	// if this is not null, it will be displayed in tooltip when rendering
		//private NSLabel errorLabel;

		private bool objectBound = false;
		private bool allowNonExistantItems = false;	// if an item doesn't exist, it's added
		
		#endregion

		public OBMultiCheckBox()
		{
			/*errorLabel = new NSLabel();
			errorLabel.ForeColor = System.Drawing.Color.Red;
			*/
		}

		#region IObjectBoundControl Members

		/// <summary>
		/// Called by the base page.
		/// </summary>
		/// <param name="Save"></param>
		public void UpdateData(bool Save)
		{
			if (disableBinding)
				return;

			errorDisplay = "";
			errorLongDisplay = "";
			if (sourceObject != null && sourceMember != null)
			{
				if (Save)		// Save = true;
				{	
					if (!(this.IsReadOnly && this.noUpdateIfReadOnly))
					{
						// control to data
						// normay the formatter object will be employed here
						try
						{
							if (this.Items.Count > 0)
							{
								ReflectionHelper.SetMemberValueFromString(sourceObject, sourceMember, this.SelectedValue);
							}
						}
						catch(System.Data.ReadOnlyException)
						{
							// ignore
						}
						catch(System.ArgumentException argEx)
						{
							errorDisplay = "Invalid entry";
							((BasePage)Page).RaisePageException(argEx);
						}
						catch(Exception ex)
						{
							errorDisplay = "???"; //ex.Message;
							errorLongDisplay = ex.Message;
							((BasePage)Page).RaisePageException(ex);
						}

						/*// If no error occured handle custom validation
						if (errorDisplay == "")
						{
							try
							{
								dataSource.ValidateTableItem(rowView, dataField);
							}
							catch(ValidationException valEx)
							{
								errorDisplay = valEx.Message;
								errorLongDisplay = valEx.LongMessage;
								((BasePage)Page).RaisePageException(valEx);
							}
							catch(Exception ex)
							{
								errorDisplay = "???"; //ex.Message;
								errorLongDisplay = ex.Message;
								((BasePage)Page).RaisePageException(ex);
							}
						}*/
					}
				}
				else
				{	// data to control
					// normay the formatter object will be employed here
					try
					{
						//type = Type.GetType(sourceClassName);
						this.Items.Clear();
						if (type != null)
						{
							MemberInfo mi = null;
							mi = type.GetField(sourceMember);
							
							string sval = ReflectionHelper.GetMemberValueAsString(sourceObject, sourceMember);
							if (sval == null)
								sval = "";
							string pkMember = TableMappingAttribute.GetPKMemberFromClass(type);
							object pkVal = ReflectionHelper.GetMemberValue(sourceObject, pkMember, true);

							if (mi == null)
								mi = type.GetProperty(sourceMember);
							if (mi != null)
							{
								Array vals = FieldValuesMemberAttribute.GetFieldValues(sourceObject, mi);
								string[] svals = FieldValuesMemberAttribute.GetFormattedFieldValues(sourceObject, mi);

								if (vals != null)
								{
									for (int i = 0; i < vals.Length; i++)
									{
										string sdesc = svals[i];
										sdesc = ((BasePage)this.Page).Language.Translate(sdesc);
										this.Items.Add(new ListItem(sdesc, Convert.ToString(vals.GetValue(i))));
									}
								}

								this.SelectedValue = sval;
							}
						}
					}
					catch(Exception ex)
					{
						errorDisplay = "???"; //ex.Message;
						errorLongDisplay = ex.Message;
						((BasePage)Page).RaisePageException(ex);
					}
				}
			}
		}

		[DefaultValue(true)]
		public bool NoUpdateIfReadOnly
		{
			get { return this.noUpdateIfReadOnly; }
			set { this.noUpdateIfReadOnly = value; }
		}

		public override string SelectedValue
		{
			get
			{
				string s = "";
				foreach (ListItem li in this.Items)
				{
					if (li.Selected)
					{
						if (s.Length > 0)
							s += ",";
						s += li.Value;
					}
				}
				return s;
			}
			set
			{
				ClearSelection();
				if (value == null || value == "")
					return;
				string[] terms = value.Split(',');
				for (int i = 0; i < terms.Length; i++)
				{
					string sval = terms[i];
					ListItem li = this.Items.FindByValue(sval);
					if (allowNonExistantItems)
						if (li == null)
						{
							li = new ListItem("(" + sval + ")", sval);
							//li = new ListItem(sval, sval);
							this.Items.Add(li);
						}
					if (li != null)
						li.Selected = true;
				}
			}
		}


		public object GetSourceObject()
		{
			return sourceObject;
		}

		public string GetSourceObjectMember()
		{
			return sourceMember;
		}

		public void SetSourceObject(object obj)
		{
			SourceObject = obj;
		}

		public void SetSourceObjectMember(string om)
		{
			SourceMemberName = om;
		}

		[Browsable(false)]
		public bool IsReadOnly
		{ 
			get { return !this.Enabled; } 
			set { this.Enabled = !value; }
		}

		[Browsable(false)]
		public bool IsEnabled
		{ 
			get { return this.Enabled; } 
			set { this.Enabled = value; }
		}

		#endregion

		#region Public functions
		/// <summary>
		/// Data source object name to be used for binding this control.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.WebForms.SourceClassNamesConverter))
		]
		public string SourceClassName
		{
			get	{ return sourceClassName; }
			set	{ sourceClassName = value; }
		}

		/// <summary>
		/// Source object to be used for binding this control.
		/// </summary>
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public object SourceObject
		{
			get	{	return sourceObject;	}
			set	
			{	
				sourceObject = value; 
				// once an object is bound, set it as object bound
				// so that the control won't be disabled
				objectBound = !disableBinding && sourceObject != null && sourceMember != null;
			}
		}

		/// <summary>
		/// Data member name in data source object to be used in binding.
		/// For a DataSet object, the format should be DataTable.DataField.
		/// </summary>
		[Category("NetsoftUSA.WebForms Binding"), 
		Browsable(true),
		TypeConverter(typeof(NetsoftUSA.DataLayer.ClassMemberConverter))
		]
		public string SourceMemberName
		{
			get	{ return sourceMember; }
			set
			{ 
				sourceMember = value; 
			}
		}

		[DefaultValue(false)]
		public bool AllowNonExistantItems
		{
			get { return allowNonExistantItems; }
			set { allowNonExistantItems = value; }
		}

		public string GetValText()
		{
			return this.SelectedValue;
		}

		public Type GetDataType()
		{
			if (sourceObject != null)
				return ReflectionHelper.GetMemberType(sourceObject, sourceMember);
			else
				return ReflectionHelper.GetMemberType(Type.GetType(sourceClassName), sourceMember);
		}

		public object GetValue()
		{
			return Convert.ChangeType(GetValText(), GetDataType());
		}

		[DefaultValue(false)]
		public bool DisableBinding
		{
			get
			{
				return disableBinding;
			}
			set
			{
				disableBinding = value;
			}
		}

		#endregion
	
		protected override void Render(HtmlTextWriter writer)
		{
			string oldSelVal = this.SelectedValue;
			bool oldEnabled = this.Enabled;

			if (this.Site != null)
				if (this.Site.DesignMode)
				{
					if (sourceMember != null && sourceMember != "")
					{
						this.Items.Clear();
						this.Items.Add(sourceMember);
						base.Render(writer);
						this.Items.Clear();
						this.SelectedValue = oldSelVal;
						return;
					}
				}

			if (objectBound || disableBinding)
			{
				base.Render (writer);
				if (errorDisplay != null)
					if (errorDisplay.Length > 0)
					{
						NSLabel errorLabel = new NSLabel();
						errorLabel.ForeColor = System.Drawing.Color.Red;
						errorLabel.Text = errorDisplay;
						errorLabel.RenderControl(writer);
					}
			}
			else
			{
				this.SelectedValue = "";
				this.Enabled = false;
				base.Render (writer);
			}

			this.SelectedValue = oldSelVal;
			this.Enabled = oldEnabled;
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			errorDisplay = (string)ViewState["err"];
			objectBound = (bool)ViewState["ob"];
		}

		protected override object SaveViewState()
		{
			ViewState["err"] = errorDisplay;
			ViewState["ob"] = objectBound;

			return base.SaveViewState ();
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);

			if (sourceMember != null)
			{
				try
				{
					type = Type.GetType(sourceClassName);
				}
				catch
				{
				}
			}
		}


		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);
			
		}

		public int GetSumOfChecked()
		{
			int sum = 0;
			for (int i = 0; i < this.Items.Count; i++)
				sum |= this.Items[i].Selected ? Convert.ToInt32( this.Items[i].Value ) : 0;
			return sum;
		}

		public void SetSumOfChecked(int value)
		{
			for (int i = 0; i < this.Items.Count; i++)
			{
				int val = Convert.ToInt32( this.Items[i].Value );
				if ((val & value) == val)		// if this item's value exactly matches the anded value.
					this.Items[i].Selected = true;
				else
					this.Items[i].Selected = false;
			}
		}

	}
}
