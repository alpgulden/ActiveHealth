using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for NSValidator.
	/// </summary>
	[ToolboxData("<{0}:NSValidator runat=server></{0}:NSValidator>")]
	public class NSValidator : System.Web.UI.WebControls.BaseValidator //, System.Web.UI.IValidator
	{
		#region IValidator Members

		/*
		public void Validate()
		{
			
		}*/

		/*
		public bool IsValid
		{
			get
			{
				// TODO:  Add NSValidator.IsValid getter implementation
				return false;
			}
			set
			{
				// TODO:  Add NSValidator.IsValid setter implementation
			}
		}*/

		/*
		public string ErrorMessage
		{
			get
			{
				return errorMsg;
			}
			set
			{
				errorMsg = value;
			}
		}*/

		#endregion
	
		protected override bool EvaluateIsValid()
		{
			NSTextBox tb = this.Page.FindControl(this.ControlToValidate) as NSTextBox;
			if (tb != null)
			{
				ValidatorManager validators = tb.DataSourceObject.Validators;
				validators.Validate();
				if (validators.IsValid)
					return true;
				else
				{
					ErrorMessage = String.Join("<br>", validators.MergeMessages());
					return false;
				}
			}
			else
				return false;
		}
	}
}
