using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Reflection;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NetsoftUSA.WebForms.IObjectBoundControl implementer for a button type
	/// UI control.  Validation and Formatting functionalities are abstracted 
	/// from this control.
	/// </summary>
	[DefaultProperty("Text"), 
		ToolboxData("<{0}:DefaultButton runat=server></{0}:DefaultButton>")
	]
	public class DefaultButton : System.Web.UI.WebControls.Button
	{
		#region Constructors

		public DefaultButton() : base()
		{
			/*errorLabel = new NSLabel();
			errorLabel.ForeColor = System.Drawing.Color.Red;
			*/
		}
		#endregion

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			bool design = false;
			if (this.Site != null)
				if (this.Site.DesignMode)
				{
					this.Text = "[]";
					design = true;
				}

			if (!design)
			{
				this.Width = 0;
				this.Height = 0;
				this.Attributes["OnClick"] = "javascript:return false;";
			}
		}


	}
}
