using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Reflection;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// NetsoftUSA.WebForms.IObjectBoundControl implementer for a button type
	/// UI control.  Validation and Formatting functionalities are abstracted 
	/// from this control.
	/// </summary>
	[ToolboxData("<{0}:ItemPicker runat=server></{0}:ItemPicker>")
	]
	public class ItemPicker : System.Web.UI.WebControls.WebControl
	{
		private TextBox pickTarget;
		#region Constructors

		public ItemPicker() : base()
		{
		}
		#endregion

		protected override void CreateChildControls()
		{
			pickTarget = new TextBox();
			pickTarget.ID = "PickTarget";
			/*bool design = false;
			if (this.Site != null)
				if (this.Site.DesignMode)
					design = true;

			if (!design)*/
				pickTarget.Style["display"] = "none";
			//else
			//	pickTarget.Style["display"] = "";
			this.Controls.Add(pickTarget);

			((BasePage)Page).SetPickTargetControl(pickTarget);
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);

			/*bool design = false;
			if (this.Site != null)
				if (this.Site.DesignMode)
				{
					design = true;		
				}*/

			/*if (!design)
			{
				this.Width = 0;
				this.Height = 0;
				this.Attributes["OnClick"] = "javascript:return false;";
			}*/
		}

		protected override void Render(HtmlTextWriter writer)
		{
			bool design = false;
			if (this.Site != null)
				if (this.Site.DesignMode)
					design = true;

			if (design)
				writer.Write("<table border=1><tr><td>Item Picker</td></tr></table>");
			else
				base.Render (writer);
		}

		protected override void LoadViewState(object savedState)
		{
			EnsureChildControls();
			base.LoadViewState (savedState);
			pickTarget.Text = (string)ViewState["PT"];
		}

		protected override object SaveViewState()
		{
			EnsureChildControls();
			ViewState["PT"] = pickTarget.Text;
			return base.SaveViewState ();
		}




	}
}
