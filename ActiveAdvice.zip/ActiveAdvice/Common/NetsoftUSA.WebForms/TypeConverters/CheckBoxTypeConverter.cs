using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;


namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Type converter used by checkbox refferring properties.
	/// </summary>
	public class CheckBoxTypeConverter : TypeConverter
	{
		public CheckBoxTypeConverter() : base()
		{
		}

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;		// We support a list of possible data source at design time
		}

		public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			System.Collections.ArrayList ls = new System.Collections.ArrayList();
			ls.Add(null);
			Control ctl = (Control)context.Instance;
			
			foreach (Control c in ctl.Page.Controls)
			{
				if (c is CheckBox || c is System.Web.UI.HtmlControls.HtmlInputCheckBox)
				{
					if (c.Site != null)
						ls.Add(c.Site.Name);
				}
			}
			ls.Sort();
			return new System.ComponentModel.TypeConverter.StandardValuesCollection(ls);
		}
	}
}
