using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Type converter used by textbox/nstextbox refferring properties.
	/// </summary>
	public class TextBoxTypeConverter : TypeConverter
	{
		public TextBoxTypeConverter() : base()
		{
		}

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;		// We support a list of possible data source at design time
		}

		private void FindTextBoxes(ControlCollection controls, System.Collections.ArrayList ls)
		{
			foreach (Control c in controls)
			{
				if (c is TextBox || 
					c is System.Web.UI.HtmlControls.HtmlInputControl || 
					c is NSTextBox)
				{
					if (c.Site != null)
						ls.Add(c.Site.Name);
				}
				else
					if (c.Controls.Count > 0)
						FindTextBoxes(c.Controls, ls);
			}
		}

		public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			System.Collections.ArrayList ls = new System.Collections.ArrayList();
			ls.Add(null);
			Control ctl = (Control)context.Instance;
			
			FindTextBoxes(ctl.Page.Controls, ls);

			ls.Sort();
			return new System.ComponentModel.TypeConverter.StandardValuesCollection(ls);
		}
	}
}
