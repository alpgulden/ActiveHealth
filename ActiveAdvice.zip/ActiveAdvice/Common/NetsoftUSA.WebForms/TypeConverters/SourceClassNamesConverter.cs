using System;
using System.Data;
using System.ComponentModel;
using System.Web.UI;
using System.Reflection;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Enlists the classnames specified for the containing BasePage
	/// </summary>
	public class SourceClassNamesConverter : TypeConverter
	{
		public SourceClassNamesConverter()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;		// We support a list of possible data members obtained from the MainDataSet of the data component
		}

		public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			System.Collections.ArrayList ls = new System.Collections.ArrayList();
			ls.Add(null);
			Control ctl = context.Instance as Control;

			if (ctl != null)
			{
				BasePage page = ctl.Page as BasePage;
				if (page != null)
				{
					if (page.SourceClassNames != null)
					{
						for (int i = 0; i < page.SourceClassNames.Length; i++)
						{
							string className = page.SourceClassNames[i];
							int iAst = className.IndexOf(".*");
							if (iAst >= 0)
							{
								string assemblyName = className.Substring(0, iAst);
								Assembly asm = null;
								try
								{
									asm = System.Reflection.Assembly.Load(assemblyName);
								}
								catch(Exception ex)
								{
									System.Diagnostics.Debug.WriteLine(ex);
									// ignore
									ls.Add("Unknown assembly name '" + assemblyName +"'!");
								}
								if (asm != null)
								{
									Type[] types = asm.GetTypes();
									for (int j = 0; j < types.Length; j++)
									{
										Type type = types[j];
										if (type.IsPublic)
											if (type.IsClass || type.IsInterface)
												ls.Add(type.FullName + "," + assemblyName);
									}
								}
							}
							else
								ls.Add(className);
						}

						ls.Sort();
					}
				}
			}

			return new System.ComponentModel.TypeConverter.StandardValuesCollection(ls);
		}
	}
}
