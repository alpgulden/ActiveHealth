using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;


namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Type converter used by checkbox refferring properties.
	/// </summary>
	public class ButtonTypeConverter : TypeConverter
	{
		public ButtonTypeConverter() : base()
		{
		}

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;		// We support a list of possible data source at design time
		}

		private void FindButtons(ControlCollection controls, System.Collections.ArrayList ls)
		{
			foreach (Control c in controls)
			{
				if (c is Button || c is System.Web.UI.HtmlControls.HtmlButton || c is System.Web.UI.HtmlControls.HtmlInputButton)
				{
					if (c.Site != null)
						ls.Add(c.Site.Name);
				}
				else
					if (c.Controls.Count > 0)
						FindButtons(c.Controls, ls);
			}
		}

		public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			System.Collections.ArrayList ls = new System.Collections.ArrayList();
			ls.Add(null);
			Control ctl = (Control)context.Instance;
			
			FindButtons(ctl.Page.Controls, ls);

			ls.Sort();
			return new System.ComponentModel.TypeConverter.StandardValuesCollection(ls);
		}
	}
}
