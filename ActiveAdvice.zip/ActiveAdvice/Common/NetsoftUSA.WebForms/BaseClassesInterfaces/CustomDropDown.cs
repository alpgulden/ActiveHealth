using System;
using System.Web.UI;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for CustomDropDown.
	/// </summary>
	public class CustomDropDown : System.Web.UI.UserControl //, INamingContainer
	{
		private NSExpandable exp = null;

		public CustomDropDown()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		protected override void CreateChildControls()
		{
			base.CreateChildControls ();
		}

		public virtual NSExpandable GetExpandableControl()
		{
			// The custom control must override this if it has a different expandable
			if (exp == null)
				exp = this.FindControl("NSExpandable1") as NSExpandable;

			if (exp != null)
			{
				exp.Floating = true;
				exp.AutoHide = true;
			}

			return exp;
		}

		public virtual string OpenDropDownScript(Control targetCtl)
		{
			return String.Format("OpenCustomDropDown({0},'{1}')", GetExpandableControl().ClientObjectName, targetCtl.ClientID);
		}

		public virtual string SetTargetValueScript(string val)
		{
			return SetTargetValueScript(val, false);
		}

		public virtual string SetTargetValueScript(string val, bool scriptedValue)
		{
			return SetTargetValueScript(val, scriptedValue, true);
		}

		public virtual string SetTargetValueScript(string val, bool scriptedValue, bool closeAfterSelect)
		{
			NSExpandable exp = GetExpandableControl();
			string fmtString = null;
			if (scriptedValue)
				fmtString = "SetTargetCtlValue({0},{1})";
			else
				fmtString = "SetTargetCtlValue({0},\"{1}\")";
			string s = String.Format(fmtString, exp.ClientObjectName, val);

			if (closeAfterSelect)
				s += ";" + exp.getToggleExpandScript();

			return s;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
		}


	}
}
