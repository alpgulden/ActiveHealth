using System;
using System.Data;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// This interface is implemented by any web UI controls
	/// that want to perform automatic data binding inside a
	/// page derived from NetsoftUSA.WebForms.BasePage
	/// </summary>
	public interface IDataBoundControl
	{
		void UpdateData(bool Save);
		DCBase GetDataSource();
		string GetDataMember();
		void SetDataSource(DCBase dc);
		void SetDataMember(string dm);
		void SetCurrentDataRowView(DataRowView rowView);
		DataRowView GetCurrentDataRowView();
	}

	public interface IObjectBoundControl
	{
		object GetSourceObject();
		string GetSourceObjectMember();
		void SetSourceObject(object obj);
		void SetSourceObjectMember(string om);
		void UpdateData(bool Save);
		bool IsReadOnly { get; set; }
		bool IsEnabled { get; set; }
	}

	/// <summary>
	/// Controls that can be validated in the client side are marked with this interface
	/// </summary>
	public interface IClientValidatableMarker
	{
	}

	/// <summary>
	/// Groupable controls provide their group names on this interface
	/// </summary>
	public interface IControlGroupProvider
	{
		string ControlGroup { get; set;}
	}

	public interface IIsDirtyCheck
	{
		bool ChecksForIsDirty { get; set;}
	}

	public interface IControlledGrouper
	{
		bool IsGroupSet  { get; set;}
	}

}
