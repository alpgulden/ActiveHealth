using System;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for BaseApplication.
	/// </summary>
	public class BaseApplication : System.Web.HttpApplication
	{
		public BaseApplication()
		{
			//
			// TODO: Add constructor logic here
			//
		}

	}
}
