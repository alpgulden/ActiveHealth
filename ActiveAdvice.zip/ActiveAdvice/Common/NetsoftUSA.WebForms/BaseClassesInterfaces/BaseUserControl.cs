using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Data;
using System.Text;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for BaseUserControl.
	/// </summary>
	public class BaseUserControl : System.Web.UI.UserControl
	{
		public object LoadObject(Type type)
		{
			return ((BasePage)Page).LoadObject(type);
		}

		public object LoadObject(Type type, bool ensure)
		{
			return ((BasePage)Page).LoadObject(type, ensure);
		}

		public void CacheObject(Type type, object obj)
		{
			((BasePage)Page).CacheObject(type, obj);
		}

		public bool IsValid
		{
			get { return ((BasePage)Page).IsValid; }
		}

		public void RaisePageException(Exception ex)
		{
			((BasePage)Page).RaisePageException(ex);
		}

		public void SetPageMessage(string msg, EnumPageMessageType messageType, params object[] parameters)
		{
			((BasePage)Page).SetPageMessage(msg, messageType, parameters);
		}

		public void UpdateFromObject(ControlCollection controls, object sourceObject, bool validation)
		{
			((BasePage)Page).UpdateFromObject(controls, sourceObject, validation);
		}

		public new BasePage Page
		{
			get
			{
				return (BasePage)base.Page;
			}
		}

		public void UpdateFromObject(ControlCollection controls, object sourceObject)
		{
			((BasePage)Page).UpdateFromObject(controls, sourceObject);
		}

		public void UpdateToObject(ControlCollection controls, object targetObject, bool validation)
		{
			((BasePage)Page).UpdateToObject(controls, targetObject, validation);
		}

		public void UpdateToObject(ControlCollection controls, object targetObject)
		{
			((BasePage)Page).UpdateToObject(controls, targetObject);
		}

		public NetsoftUSA.DataLayer.Language Language
		{
			get { return ((BasePage)Page).Language; }
		}

	}

}
