using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	/// <summary>
	/// Summary description for BaseDropDown.
	/// </summary>
	[ToolboxData("<{0}:BaseDropDown runat=server></{0}:BaseDropDown>")]
	public abstract class BaseDropDown : System.Web.UI.Control, IDataBoundControl
	{
		#region protected members
		protected NetsoftUSA.DataLayer.DCBase dataSource = null;	// actual source data component
		protected string dataMember;	// in the form of Table.Field
		protected string dataTable;	// parsed from dataMember
		protected string dataField;	// parsed from dataMember
		protected string pickTarget;
		protected Control pickTargetCtl = null;
		protected DataRowView rowView;
		#endregion

		#region Public members
		public NetsoftUSA.DataLayer.DCBase DataSourceObject
		{
			get
			{
				return dataSource;
			}
			set
			{
				dataSource = value;		// code serializer generated code calls this.
			}
		}

		public string DataMemberName
		{
			get
			{
				return dataMember;
			}
			set
			{
				dataMember = value;
				dataTable = null;
				dataField = null;

				if (dataMember != null)
				{
					string[] memberTerms = dataMember.Split('.');
					if (memberTerms.Length == 2)
					{
						dataTable = memberTerms[0];
						dataField = memberTerms[1];
					}
					else
					{
						if (dataMember != "")
						{
							dataMember = null;
							throw new Exception("This type of data member not handled yet!");
						}
					}
				}
			}
		}

		public string PickTarget
		{
			get
			{
				return pickTarget;
			}
			set
			{
				pickTarget = value;
			}
		}

		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public Control PickTargetCtl
		{
			get
			{
				return pickTargetCtl;
			}
			set
			{
				pickTargetCtl = value;
			}
		}

		public string getPickTargetClientID()
		{
			if (pickTargetCtl != null)
				return pickTargetCtl.ClientID;
			return Page.FindControl(pickTarget).ClientID;
		}
		#endregion

		#region Overridable functions
		public abstract void FillCombo();
		#endregion

		#region IDataBoundControl Members

		public void UpdateData(bool Save)
		{
			//if (!Save)
			//	FillCombo();
		}

		public NetsoftUSA.DataLayer.DCBase GetDataSource()
		{
			return dataSource;
		}

		public string GetDataMember()
		{
			return dataMember;
		}

		public void SetDataSource(NetsoftUSA.DataLayer.DCBase dc)
		{
			DataSourceObject = dc;
		}

		public void SetDataMember(string dm)
		{
			DataMemberName = dm;
		}

		public void SetCurrentDataRowView(System.Data.DataRowView rowView)
		{
			this.rowView = rowView;
		}

		public System.Data.DataRowView GetCurrentDataRowView()
		{
			return this.rowView;
		}

		#endregion

		protected override void OnPreRender(EventArgs e)
		{
			FillCombo();
		}

	}
}
