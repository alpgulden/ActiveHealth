using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using NetsoftUSA.DataLayer;

namespace NetsoftUSA.WebForms
{
	public  enum EnumPageType
	{
		DataEntryPage = 0,
		SearchPage = 1,
		DisplayPage = 2
		//,
		//ReportPage = 2
	}

	public enum InitialCachingType
	{
		DontLoad = 0,
		Load = 1,
		UseFromCache = 2,
		CheckQueryString = 3
	}

	public enum ObjectCachingMethod
	{
		DontCache = 0,
		UseSession = 1,
		UseCache = 2,
		UseViewState = 3
	}

	public class SetPageMessageEventArgs : EventArgs
	{
		public EnumPageMessageType messageType = EnumPageMessageType.Info;
		public string message;
		public SetPageMessageEventArgs(string message, EnumPageMessageType messageType)
		{
			this.message = message;
			this.messageType = messageType;
		}
		public SetPageMessageEventArgs(string message)
		{
			this.message = message;
		}
	}


	public class ControlExtraProperties
	{
		public string ControlID;
		public string ControlGroup;
		public string ControlParentID;
		public bool CausesValidation;
		public bool ChecksForDirty;

		public ControlExtraProperties(string controlID, string controlGroup, string controlParentID, bool causesValidation, bool checksForDirty)
		{
			this.ControlID = controlID;
			this.ControlGroup = controlGroup;
			this.ControlParentID = controlParentID;
			this.CausesValidation = causesValidation;
			this.ChecksForDirty = checksForDirty;
		}
	}

	/// <summary>
	/// The base web form functionality to automatically
	/// populate and update data on the web form.  Use this 
	/// base class to derive a new WebForms page.
	/// </summary>
	[Designer("Microsoft.VSDesigner.WebForms.WebFormDesigner,Microsoft.VSDesigner")]
	public class BasePage : System.Web.UI.Page
	{
		#region Events
		public delegate void SetPageMessageEventHandler(object sender, SetPageMessageEventArgs e);
		public event SetPageMessageEventHandler SetPageMessageEvent;
		public delegate void SetPageLongMessageEventHandler(object sender, SetPageMessageEventArgs e);
		public event SetPageLongMessageEventHandler SetPageLongMessageEvent;
		#endregion

		#region Private members
		protected Hashtable pageParams = null;
		private Language language;							// the object that has messages on its members for the current language
		private NSBindingManager bindingManager;
		private bool pageError = false;
		private Exception exception = null;
		private bool isSavingToObject = false;				// is saving to object or loading from object to controls
		private string backPage = null;
		//private string textToTranslateParameters = null;	// The labels that has no TextToTranslateParameters uses these
		//private string sourceClassName = null;		// the default source class name used by OB (object bound) controls.
		//private object sourceObject = null;			// the default binding object for the page.

		private ObjectCachingMethod cachingMethod = ObjectCachingMethod.UseSession;		// caching method for caching objects
		private string[] sourceClassNames = null;		// used to display in drop down of controls

		private Hashtable onloadScripts = new Hashtable();
		private Hashtable declarationScripts = new Hashtable();
		//private NameValueCollection declarationScripts = new NameValueCollection();

		private Hashtable pageControls = new Hashtable(); // stores the controls and the groups they are attached to
		private Hashtable controlGroups = new Hashtable(); // stores the groups

		internal TextBox pickTarget = null;			// the uniqueid of the pick target hidden inputbox
		internal string pickTargetID;			// the uniqueid of the pick target hidden inputbox
		internal string pickTargetName;			// the uniqueid of the pick target hidden inputbox
		internal string pickTargetTextData;
		private bool pickButton = false;

		private EnumPageType pageType = EnumPageType.DataEntryPage;
		private bool validationsEnabled = true;
		private bool requiredValidationsEnabled = true;
		private bool dirtyCheckEnabled = true;

		private bool validationsOnlyInSummary = false;	// whether validation messages will be displayed only in summary

		private bool viewOnlyMode = false;		// show controls in this page in viewonly mode
		private bool printPreviewMode = false;	// show page in print preview mode
		private bool blankForm = false;			// leaves form controls blank, when they're updated. This is not saved between postbacks

		
		private bool autoScroll = false; // whether the page should scroll back to its last position before a postback
        private string scrollToControlID = null; // ClientID for a control that the page is going to scroll to

		private ClassBindingMap classBindingMap = null;

		private int accessLevel = 0;

		// Declarative per-page security
		private bool hasAccessToEdit = true;		// must be set by the page

		private WindowMode windowMode = WindowMode.SameWindow;		// the window mode that this page was opened. usually passed by the windowopener

		private string selectedMenuItem;
		protected override void OnLoad(EventArgs e)
		{
			if (!IsPostBack)		// save the http referrer at the first hit to this page
			{
				ViewState["PgRef"] = this.HttpReferrer;
				ViewState["CallBackFunction"] = Request.QueryString["CallBackFunction"];
				string wmode = Request.QueryString["WindowMode"];
				if (wmode != null)
				{
					//try
					//{
					this.windowMode = (WindowMode)WindowMode.Parse(typeof(WindowMode), wmode, true);
					//}
					//catch(Exception ex)
					//{
					//}
				}
			}

			base.OnLoad (e);
		}

		public string HttpReferrer
		{
			get { return this.Request.ServerVariables["HTTP_REFERER"]; }
		}

		public string PageReferrer
		{
			get { return (string)ViewState["PgRef"]; }
			set { ViewState["PgRef"] = value; }		// if this is somehow set, RedirectToReferrer will go to the given page
		}

		public string CallbackFunction
		{
			get { return (string)ViewState["CallBackFunction"]; }
			set { ViewState["CallBackFunction"] = value; }
		}

		public bool HasCallbackFunction
		{
			get 
			{ 
				string cbf = this.CallbackFunction;
				return cbf != null && cbf != "";
			}
		}

		[DefaultValue(false)]
		public bool AutoScroll
		{
			get { return autoScroll; }
			set { autoScroll = value; }
		}

		[Browsable(false)]
		public string ScrollToControlID
		{
			get { return scrollToControlID;}
			set { scrollToControlID = value; }
		}

		private int vPos;
		private int hPos;

		[Browsable(false)]
		public int VPos
		{
			get { return vPos; }
			set { vPos = value; }
		}

		[Browsable(false)]
		public int HPos
		{
			get { return hPos; }
			set { hPos = value; }
		}


		public void ScrollToControl(Control ctrl)
		{
			this.scrollToControlID = ctrl.ClientID;
		}

		public void ScrollToControlByClientID(string ctrlClientID)
		{
			this.scrollToControlID = ctrlClientID;
		}


		[Browsable(false)]
		public bool IsPopup
		{
			get 
			{ 
				return this.HasCallbackFunction || this.windowMode != WindowMode.SameWindow;
			}
		}

		public void TransferToReferrer()
		{
			Server.Transfer(PageReferrer);
		}

		public void EnsureValidationScript()
		{
			DummyValidator dummy = new DummyValidator();
			this.Page.Controls.Add(dummy);
			dummy.RegisterValidatorCommonScript();
			this.Page.Controls.Remove(dummy);
			dummy = null;
		}
		
        
		private void registerClientScripts()
		{
			EnsureValidationScript();
			registerPickItemScript();
			RegisterControlGroupsScripts();
			RegisterScrollScript();

			if (!this.IsClientScriptBlockRegistered("NetsoftUSA.WebForms"))
				RegisterClientScriptBlock("NetsoftUSA.WebForms", "<SCRIPT src='NSWebForms.js'></SCRIPT>\n");
			
			if (declarationScripts.Count > 0)
			{
				StringBuilder s = new StringBuilder();
				
				s.Append("<SCRIPT >\n");	//FOR=window EVENT=onload
				foreach (DictionaryEntry item in declarationScripts)
				{
					s.Append((string)item.Value);
				}
				s.Append("</SCRIPT>\n");
				RegisterStartupScript("DeclarationScripts", s.ToString());
			}

			if (onloadScripts.Count > 0)
			{
				StringBuilder s = new StringBuilder();
				s.Append("<SCRIPT>\n");
				foreach (DictionaryEntry item in onloadScripts)
				{
					s.Append((string)item.Value);
				}
				s.Append("</SCRIPT>\n");
				RegisterStartupScript("OnLoadScripts", s.ToString());
			}
		}

		public void registerPickItemScript()
		{
			if (pickButton && !IsClientScriptBlockRegistered("PickItemScript"))
			{
				//pickTarget = (TextBox)this.FindControl("PickTarget");
				if (pickTarget != null)
				{
					pickTargetID = pickTarget.ClientID;
					pickTargetName = pickTarget.UniqueID;
				}
				StringBuilder s = new StringBuilder();
				//s.Append("<SCRIPT FOR=window EVENT=onload>\n");
				s.Append(" try {\n");
				s.Append(" set_PickTarget(PickTarget);\n");
				s.Append(" } catch(e)\n");
				s.Append(" { }\n");
				//s.Append("</SCRIPT>\n");
				RegisterOnLoadScript("PickItemTemplateOnload", s.ToString());

				s = new StringBuilder();
				s.Append("<SCRIPT language='JAVASCRIPT'>\n");
				// set_Grid_PickTarget(s)
				s.Append("function set_PickTarget(s) {\n");
				s.Append("  document.all[\"" + pickTargetID + "\"].value=s;\n");
				s.Append("}\n");
				// PickItem(item)
				s.Append("function PickItem(item, targetID) {\n");
				s.Append("  var targetCtl = null;\n");
				s.Append("  if (targetID!=null)\n");
				s.Append("    targetCtl = targetID.replace('*',document.all[\"" + pickTargetID + "\"].value);\n");
				s.Append("  else\n");
				s.Append("    targetCtl = document.all[\"" + pickTargetID + "\"].value;\n");
				s.Append("  try {\n");
				s.Append("  window.opener.document.all[targetCtl].value=item;\n");
				s.Append("  } catch(e) {\n");
				s.Append("  window.alert(\"Can't access target field \" + targetCtl +");
				s.Append("  \"  \\r\\nThe calling window may have been closed.\"); }\n");
				/*if (PickButtonCloses)
					s.Append("  window.close();\n");*/
				s.Append("}\n");
				s.Append("\n");
				s.Append("</SCRIPT>\n");
				RegisterClientScriptBlock("PickItemTemplate", s.ToString());
			}
		}

		public void RegisterScrollScript()
		{
			string saveScrollPosition = 
				@"
			
			<script language='Javascript'>
				
				document.write('<Input id=\'ScrollSaver\' type=\'hidden\' name=\'ScrollSaver\' />');

				window.onscroll = saveScroll; 
			</script>";

			if((this.autoScroll) && !Page.IsStartupScriptRegistered("saveScrollPosition"))
			{
				Page.RegisterStartupScript("saveScrollPosition", saveScrollPosition);
			}


			string gotoScrollPosition = @"
<script language='javascript'>
";
			if (scrollToControlID != null)
			{
				gotoScrollPosition +=@"doScrollToControl('" + scrollToControlID + @"');";
			} 
			else
			{
				gotoScrollPosition +=@"doScroll(" + this.HPos + ", " + this.VPos + ");";
			}

			gotoScrollPosition += @"

			</script>";

			if((this.autoScroll || scrollToControlID != null) && !Page.IsStartupScriptRegistered("gotoScrollPosition"))
			{
				Page.RegisterStartupScript("gotoScrollPosition", gotoScrollPosition);
			}
		}

		#endregion

		#region Constructors
		public BasePage() : base()
		{
			bindingManager = new NSBindingManager(this);
		}
		#endregion

		#region Public members

		[DefaultValue(false)]
		public bool ViewOnlyMode
		{
			get { return this.viewOnlyMode; }
			set { this.viewOnlyMode = value; }
		}

		[DefaultValue(false)]
		public bool PrintPreviewMode
		{
			get { return this.printPreviewMode; }
			set { this.printPreviewMode = value; }
		}

		/*public virtual bool IsNewRecord
		{
			get
			{
				return this.blankForm;
			}
		}*/

		public bool IsViewOnly
		{
			get 
			{ 
				/*if (this.IsNewRecord)
				{
					// new record
					if (this.accessLevel < this.minAccessToCreate)
						return true;
				}
				else
				{
					// existing record
					if (this.accessLevel < this.minAccessToChange)
						return true;
				}*/

				return !this.hasAccessToEdit || this.viewOnlyMode || this.printPreviewMode;
			}
		}

		[DefaultValue(false)]
		public bool ValidationsOnlyInSummary
		{
			get { return this.validationsOnlyInSummary; }
			set { this.validationsOnlyInSummary = value; }
		}

		public string GetPickItemScript(string itemValue)
		{
			return GetPickItemScript(itemValue, false);
		}

		public string GetPickItemScript(string itemValue, bool isScriptValue)
		{
			if (isScriptValue)
				return String.Format("PickItem({0})", itemValue);
			else
				return String.Format("PickItem('{0}')", itemValue);
		}

		public string GetPickItemScript(string itemValue, string targetID)
		{
			return GetPickItemScript(itemValue, false, targetID);
		}

		public string GetPickItemScript(string itemValue, bool isScriptValue, string targetID)
		{
			if (isScriptValue)
				return String.Format("PickItem({0},'{1}')", itemValue, targetID);
			else
				return String.Format("PickItem('{0}','{1}')", itemValue, targetID);
		}

		public string GetCallbackFunctionScriptDirectParams(string parameters)
		{
			return String.Format( "window.opener.{0}({1});", this.CallbackFunction, parameters );
		}

		public string GetCallbackFunctionScript(params object[] parameters)
		{
			string s = null;

			for (int i = 0; i < parameters.Length; i++)
			{
				if (i > 0)
					s += ", ";
				object param = parameters[i];
				if (param == null)
					s += "null";
				else
				{
					if (param is string)
						s += "&quot;" + param + "&quot;";
					else
						s += param;
				}
			}

			return GetCallbackFunctionScriptDirectParams(s);
		}

		public string GetCallbackFunctionHyperLink(string linkCaption, params object[] parameters)
		{
			string pickScript = GetCallbackFunctionScript(parameters);
			string hyperLink = String.Format("<a href='#' onclick=\"{0}window.close();return false;\">{1}</a>", pickScript, Language.Translate(linkCaption) );
			return hyperLink;
		}

		/// <summary>
		/// Only valid in the update object process.
		/// Used by the OBValidator to detect the population mode
		/// </summary>
		[Browsable(false)]
		public bool IsSavingToObject
		{
			get
			{
				return isSavingToObject;
			}
		}

		/// <summary>
		/// Returns the NSBindingManager instance used in the context of this page.
		/// This object manages the added dataComp-dataMember pairs.
		/// </summary>
		public NSBindingManager BindingManager
		{
			get
			{
				return bindingManager;
			}
		}

		#region OB (Object Bound) control binding operations

		/*[Category("NetsoftUSA.WebForms Binding")]
		public string SourceClassName
		{
			get { return sourceClassName; } 
			set { sourceClassName = value; }
		}*/

		[Category("NetsoftUSA.WebForms Binding"),
		Description("Specified class names are listed in the SourceClassName property of OB (object bound) controls")]
		public string[] SourceClassNames
		{
			get { return sourceClassNames; } 
			set { sourceClassNames = value; }
		}

		[DefaultValue(EnumPageType.DataEntryPage)]
		public virtual EnumPageType PageType
		{
			get { return this.pageType; }
			set { this.pageType = value; }
		}

		[DefaultValue(WindowMode.SameWindow)]
		public WindowMode WindowMode
		{
			get { return this.windowMode; }
			set { this.windowMode = value; }
		}

		[Browsable(false)]
		public bool IsDataEntryPage
		{
			get { return this.pageType == EnumPageType.DataEntryPage; }
		}

		[Browsable(false)]
		public bool IsSearchPage
		{
			get { return this.pageType == EnumPageType.SearchPage; }
		}

		[DefaultValue (true)]
		public bool ValidationsEnabled
		{
			get { return this.validationsEnabled; }
			set { this.validationsEnabled = value; }
		}
		
		[DefaultValue (true)]
		public bool RequiredValidationsEnabled
		{
			get { return this.requiredValidationsEnabled; }
			set { this.requiredValidationsEnabled = value; }
		}

		[DefaultValue(true)]
		public bool DirtyCheckEnabled
		{
			get { return this.dirtyCheckEnabled; }
			set { this.dirtyCheckEnabled = value; }
		}

		/*
		[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden) ]
		public object SourceObject
		{
			get	{	return sourceObject;	}
			set	{	sourceObject = value; 	}
		}*/

		/// <summary>
		/// Bind given (OB) controls to the specified source object
		/// </summary>
		/// <param name="controls"></param>
		/// <param name="sourceObject"></param>
		public void BindToObject(ControlCollection controls, object sourceObject)
		{
			foreach (Control control in controls)
			{
				IObjectBoundControl ictl = control as IObjectBoundControl;
				if (ictl != null)	// if this is of expected type web control
				{
					ictl.SetSourceObject(sourceObject);
				}
				else
				{
					if (control.Controls.Count != 0)
						BindToObject(control.Controls, sourceObject);
				}
			}
		}

		/*
		public void BindToClass(ControlCollection controls, Type type)
		{
			foreach (Control control in controls)
			{
				IObjectBoundControl ictl = control as IObjectBoundControl;
				if (ictl != null)	// if this is of expected type web control
				{
					ictl.SetSourceObject(sourceObject);
				}
				else
				{
					if (control.Controls.Count != 0)
						BindToObject(control.Controls, sourceObject);
				}
			}
		}*/

		/// <summary>
		/// Run all the OBValidator objects
		/// </summary>
		/// <param name="controls"></param>
		/// <param name="Save"></param>
		public void ValidateObject(ControlCollection controls, bool Save, bool customOnly)
		{
			this.isSavingToObject = Save;
			foreach (Control control in controls)
			{
				OBValidator val = control as OBValidator;
				if (val != null)	// if this is of expected type web control
				{
					if (customOnly)
						val.ValidateCustom();
					// else full validation
				}
				else
				{
					if (control.Controls.Count != 0)
						ValidateObject(control.Controls, Save, customOnly);
				}
			}
		}

		public virtual bool Validate(bool Save)
		{
			//if (!loadValidation && !Save)
			//if (!Save)
			//	return true;	// not validated on Save = false
			
			if (Save)
			{
				this.isSavingToObject = Save;
				Validate();
			}
			else
			{
				// run only bound object validations over OBValidator!
				this.isSavingToObject = Save;
				Validate();
				ValidateObject(this.Controls, Save, true);		// custom validators not automatically called in load
			}

			return IsValid;
		}

		/// <summary>
		/// Update the data in the already bound controls.
		/// Each control may be bound to a different object.
		/// </summary>
		/// <param name="controls"></param>
		/// <param name="Save"></param>
		public void UpdateObject(ControlCollection controls, bool Save)
		{
			foreach (Control control in controls)
			{
				IObjectBoundControl ictl = control as IObjectBoundControl;
				if (ictl != null)	// if this is of expected type web control
				{
					ictl.UpdateData(Save);
				}
				else
				{
					if (control.Controls.Count != 0)
						UpdateObject(control.Controls, Save);
				}
			}
		}

		public void UpdateFromObject(Control control, object obj)
		{
			IObjectBoundControl ictl = control as IObjectBoundControl;
			if (ictl != null)	// if this is of expected type web control
			{
				ictl.SetSourceObject(obj);
				ictl.UpdateData(false);
			}
		}

		public void UpdateToObject(Control control, object obj)
		{
			IObjectBoundControl ictl = control as IObjectBoundControl;
			if (ictl != null)	// if this is of expected type web control
			{
				ictl.SetSourceObject(obj);
				ictl.UpdateData(true);
			}
		}

		public void UpdateToObject(ControlCollection controls)
		{
			UpdateObject(controls, true);
		}

		public void UpdateToObject(ControlCollection controls, object targetObject)
		{
			UpdateObject(controls, targetObject, true);
		}

		public void UpdateToObject(ControlCollection controls, object targetObject, bool validation)
		{
			UpdateObject(controls, targetObject, true, validation);
		}

		public void UpdateFromObject(ControlCollection controls)
		{
			UpdateObject(controls, false);
		}

		public void UpdateFromObject(ControlCollection controls, object sourceObject)
		{
			UpdateObject(controls, sourceObject, false, false);
		}

		public void UpdateFromObject(ControlCollection controls, object sourceObject, bool validation)
		{
			UpdateObject(controls, sourceObject, false, validation);
		}

		/// <summary>
		/// Bind and then update the given object with the OB controls
		/// </summary>
		/// <param name="controls"></param>
		/// <param name="sourceObject"></param>
		/// <param name="Save"></param>
		public void UpdateObject(ControlCollection controls, object sourceObject, bool Save, bool validation)
		{
			BindToObject(controls, sourceObject);
			if (validation)
				if (!Validate(Save))
					if (Save)	// if not is valid then do not update 
						return;

			UpdateObject(controls, Save);

			if (Save)
			{
				// Automatically mark the object as dirty when it is updated from controls.
				BaseDataClass data = sourceObject as BaseDataClass;
				if (data != null)
					data.MarkDirty();
			}
		}

		public void UpdateObject(ControlCollection controls, object sourceObject, bool Save)
		{
			UpdateObject(controls, sourceObject, Save, true);
		}

		public void UpdateFromCollection(DataGrid dataGrid, IList collection, bool obControls, string dataKeyMember)
		{
			dataGrid.DataSource = collection;
			if (dataKeyMember != null)
				dataGrid.DataKeyField = dataKeyMember;
			if (obControls)
				dataGrid.ItemDataBound +=new DataGridItemEventHandler(dataGrid_ItemDataBound);
			dataGrid.DataBind();
		}

		public void UpdateFromCollection(DataList dataList, IList collection, bool obControls, string dataKeyMember)
		{
			dataList.DataSource = collection;
			if (dataKeyMember != null)
				dataList.DataKeyField = dataKeyMember;
			if (obControls)
				dataList.ItemDataBound +=new DataListItemEventHandler(dataList_ItemDataBound);
			dataList.DataBind();
		}

		private void dataGrid_ItemDataBound(object sender, DataGridItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
				this.UpdateFromObject(e.Item.Controls, e.Item.DataItem);
		}

		private void dataList_ItemDataBound(object sender, DataListItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
				this.UpdateFromObject(e.Item.Controls, e.Item.DataItem);
		}

		public void UpdateToCollection(DataGrid dataGrid, IList collection, bool validation)
		{
			for (int i = 0; i < dataGrid.Items.Count; i++)
			{
				DataGridItem gridItem = dataGrid.Items[i];
				object obj = collection[i];
				this.UpdateToObject(gridItem.Controls, obj);
			}
		}

		public void UpdateToCollection(DataList dataList, IList collection, bool validation)
		{
			for (int i = 0; i < dataList.Items.Count; i++)
			{
				DataListItem listItem = dataList.Items[i];
				object obj = collection[i];
				this.UpdateToObject(listItem.Controls, obj);
			}
		}

		public void UpdateToCollection(DataGrid dataGrid, IList collection)
		{
			UpdateToCollection(dataGrid, collection, false);
		}

		public void UpdateToCollection(DataList dataList, IList collection)
		{
			UpdateToCollection(dataList, collection, false);
		}

		public void RenderClientFunctions(ControlCollection controls, object sourceObject, string calcFunctionName)
		{
			RenderClientFunctions(null, controls, sourceObject, calcFunctionName);
		}

		public void RenderClientFunctions(Type type, ControlCollection controls, object sourceObject, string calcFunctionName)
		{
			if (sourceObject != null)
			{
				string scriptBlockName = "ClientCalcAndVlds_" + calcFunctionName;
				if (!this.IsClientScriptBlockRegistered(scriptBlockName))
				{
					ClientSideCalculationScript clientCalc = new ClientSideCalculationScript(type, sourceObject, controls);
					StringBuilder sb = new StringBuilder();
					StringBuilder sbVal = new StringBuilder();
					sb.Append("<script>\r\n");
					sb.Append("function ");
					sb.Append(calcFunctionName);
					sb.Append("()\r\n");
					sb.Append("{\r\n");
					bool exceptionsHandled = true;
#if DEBUG
					exceptionsHandled = false;
#endif
					clientCalc.GenerateClientScriptsForMembers(sb, sbVal, exceptionsHandled);
					sb.Append("}\r\n");

					sb.Append(sbVal);

					sb.Append("</script>\r\n");

					this.RegisterClientScriptBlock(scriptBlockName, sb.ToString());
					//this.RegisterStartupScript(scriptBlockName, sb.ToString());
				}
			}
		}

		#endregion

		#region Group functions
		
		/// <summary>
		/// This method loops through all the controls in the controls collection provided, and sets the group name property as needed.
		/// </summary>
		/// <param name="controls">Controls collection</param>
		/// <param name="group">Group name to be set</param>
		public void SetControlGroups(ControlCollection controls, string controlGroup)
		{

			if (controlGroup == "default")
			{
				AddControlGroup(controlGroup, "");
			}

			// Loop through all the controls in the collection 
			foreach (Control control in controls)
			{
				IControlGroupProvider ctrl = control as IControlGroupProvider;
				if (ctrl != null) // If the control supports grouping
				{
					bool isGroupSet = false;
					IControlledGrouper icon = ctrl as IControlledGrouper;
					if (icon != null) // If the control is controlled. (Currently only ContentPanel is a controlled grouper)
					{
						isGroupSet = icon.IsGroupSet; 
					}

					if (!isGroupSet) // We do not want to go over same content panel twice
					{
						// If the group property on the control is not set
						if (ctrl.ControlGroup == null || ctrl.ControlGroup == "")
						{
							IIsDirtyCheck dc = control as IIsDirtyCheck;
							if (control.Visible)
							{
								if (dc != null)
									SetControlProperties(control.ClientID, new ControlExtraProperties(control.ClientID, controlGroup, control.Parent.ClientID, false, ((BasePage)Page).DirtyCheckEnabled && dc.ChecksForIsDirty));
								else
									SetControlProperties(control.ClientID, new ControlExtraProperties(control.ClientID, controlGroup, control.Parent.ClientID, false, false));

								// Set the group property
								ctrl.ControlGroup = controlGroup;
								// And propagate it to the children of the control, unless it's a controlled grouper
								if (icon == null) 
									if (control.Controls.Count > 0)
										SetControlGroups(control.Controls, controlGroup);
							}
						}
						else
						{
							// There is a group change
							AddControlGroup(ctrl.ControlGroup, controlGroup);

							IIsDirtyCheck dc = control as IIsDirtyCheck;

							if (control.Visible)
							{
								if (dc != null)
									SetControlProperties(control.ClientID, new ControlExtraProperties(control.ClientID, ctrl.ControlGroup, control.Parent.ClientID, false, ((BasePage)Page).DirtyCheckEnabled && dc.ChecksForIsDirty));
								else
									SetControlProperties(control.ClientID, new ControlExtraProperties(control.ClientID, ctrl.ControlGroup, control.Parent.ClientID, false, false));

								// Propagate the value to the children of the control
								if (control.Controls.Count > 0)
									SetControlGroups(control.Controls, ctrl.ControlGroup);

							}
						}
					}
				}
				else
				{
					// If the control does not support grouping, just loop throuh it's children
					if (control.Controls.Count != 0)
						SetControlGroups(control.Controls, controlGroup);
				}
			}

		}

		public void SetControlProperties(string key, ControlExtraProperties controlProperties)
		{
			if (!pageControls.ContainsKey(key))
			{
				//throw new Exception("The control " + key + " is already in the page controls collection.");
				pageControls.Add(key, controlProperties);
			}
		}

		/// <summary>
		/// Adds a new group to the controlGroups collection
		/// </summary>
		/// <param name="controlGroup">New group</param>
		/// <param name="parentControlGroup">Parent group</param>
		public void AddControlGroup(string controlGroup, string parentControlGroup)
		{
			// We don't want to put the same group into the hashtable twice
			if (controlGroup == parentControlGroup)
				return;

			// If the key is there and it's empty
			if ((controlGroups.ContainsKey(controlGroup) && controlGroups[controlGroup] == null)
				|| !(controlGroups.ContainsKey(controlGroup)))
			{
				// Create the controlgroup and put it into the hashtable
				ControlGroup group = new ControlGroup(controlGroup, "Group " + controlGroup, parentControlGroup);
				controlGroups[controlGroup] = group;

				// Add this group into subgroup collections of parent and grandparent groups.
				ControlGroup pControlGroup = null;
				string parControlGroup = parentControlGroup;
				while (parControlGroup!= null && controlGroups.ContainsKey(parControlGroup))
				{
					pControlGroup = ((ControlGroup)controlGroups[parControlGroup]);
					pControlGroup.AddSubGroup(group);
					parControlGroup = pControlGroup.ParentGroup;
				}

			}
			else if (((ControlGroup)controlGroups[controlGroup]).ParentGroup != parentControlGroup) // If this group is already attached to a different parent group, throw an exception
			{
				throw new Exception("A group cannot be a under more than one group Group '" + controlGroup + "' ");
			}
		}



		public void RegisterControlGroupsScripts()
		{
			if (!IsClientScriptBlockRegistered("ControlGroupsScript"))
			{
				StringBuilder s = new StringBuilder();
				//s.Append("<SCRIPT FOR=window EVENT=onload>\n");
				s.Append(" try {\n");
				s.Append(" LoadGroups();\n");
				s.Append(" } catch(e)\n");
				s.Append(" { }\n");
				//s.Append("</SCRIPT>\n");
				RegisterOnLoadScript("ControlGroupsScriptOnLoad", s.ToString());

				s = new StringBuilder();
				s.Append("<SCRIPT language='JAVASCRIPT'>\n");
				// set_Grid_PickTarget(s)
				s.Append("function LoadGroups() {\n");

				// Groups and their relations
				// s.Append("var PageControlGroups = {};\n");
				foreach (DictionaryEntry entry in controlGroups)
				{
					ControlGroup group = (ControlGroup)entry.Value;

					s.Append("Page_ControlGroups[\"" + group.GroupKey + "\"] = [");
					// Add the current group itself to its subgroups too, to make it easier to check on the client 
					s.Append("\"" + group.GroupKey + "\"");

					// Add all the subgroups 
					foreach (ControlGroup sub in group.SubGroups)
					{
						s.Append(", \"" + sub.GroupKey + "\"");
					}
					s.Append("];\n");
				}

				// Dirty Flags
				// s.Append("var PageDirtyFlags = {};\n");

				foreach (DictionaryEntry entry in controlGroups)
				{
					ControlGroup group = (ControlGroup)entry.Value;
					s.Append("Page_DirtyFlags[\"" + group.GroupKey + "\"] = [" + (group.IsDirty.ToString().ToLower()) + "];\n");
				}

				foreach (DictionaryEntry entry in pageControls)
				{
					ControlExtraProperties controlProperties = (ControlExtraProperties)entry.Value;
					s.Append("Page_Controls[\"" + entry.Key + "\"] = [\"" + controlProperties.ControlID + "\", \""  + controlProperties.ControlParentID + "\", \"" + controlProperties.ControlGroup + "\", " + controlProperties.CausesValidation.ToString().ToLower() + ", " + controlProperties.ChecksForDirty.ToString().ToLower() + "];\n");
				}

				s.Append("\n");
				s.Append("}\n");

				s.Append("</SCRIPT>\n");
				RegisterClientScriptBlock("ControlGroupsScript", s.ToString());
			}
		}




		#endregion


		


		
		
		#region DCBase bound controls binding operations

		/// <summary>
		/// Synhronizes between data and bound controls.
		/// </summary>
		/// <param name="controls">The control collection to be updated</param>
		/// <param name="save">If save is true, control to data, if save is false, data to control</param>
		public void UpdateData(ControlCollection controls, bool save)
		{
			foreach (Control control in controls)
			{
				IDataBoundControl ictl = control as IDataBoundControl;
				// Check if this control is an NetsoftUSA.WebForms.IDataBoundControl implementer
				if (ictl != null)	// if this is of expected type web control
				{
					ictl.UpdateData(save);
				}
				else
				{
					// check if this is a controls collection
					if (control.Controls.Count != 0)
						//if (!(control is NSDataGrid))
						UpdateData(control.Controls, save);
				}
			}
		}

		/// <summary>
		/// Synhronizes between data and bound control for only those
		/// controls with the specified dataSource and dataMember.
		/// dataMember's table part is used for matching.
		/// </summary>
		/// <param name="dataSource"></param>
		/// <param name="dataMember"></param>
		/// <param name="controls"></param>
		/// <param name="save"></param>
		public void UpdateData(DCBase dataSource, string dataMember, ControlCollection controls, bool save)
		{
			if (dataSource.GetCurrentDataRowView(dataMember) == null)
				return;

			foreach (Control control in controls)
			{
				IDataBoundControl ictl = control as IDataBoundControl;
				// Check if this control is an NetsoftUSA.WebForms.IDataBoundControl implementer
				if (ictl != null)	// if this is of expected type web control
				{
					if (dataSource == ictl.GetDataSource())
					{
						string dmember = ictl.GetDataMember();
						if (dmember.Split('.')[0] == dataMember)
							ictl.UpdateData(save);
					}
				}
				else
				{
					// check if this is a controls collection
					if (control.Controls.Count != 0)
						//if (!(control is NSDataGrid))
						UpdateData(dataSource, dataMember, control.Controls, save);
				}
			}

			/*
			if (save)
			{
				// If saving into dataset, then end edit for the row
				try
				{
					dataSource.GetCurrentDataRowView(dataMember).EndEdit();
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}*/
		}

		/// <summary>
		/// Synhronizes between data and bound control for only those
		/// controls with the specified dataSource and dataMember.
		/// dataMember's table part is used for matching.
		/// </summary>
		/// <param name="dataSource"></param>
		/// <param name="dataMember"></param>
		/// <param name="save"></param>
		public void UpdateData(DCBase dataSource, string dataMember, bool save)
		{
			UpdateData(dataSource, dataMember, this.Controls, save);

			if (save)
			{
				// If saving into dataset, then end edit for the row
				try
				{
					DataRowView rowView = dataSource.GetCurrentDataRowView(dataMember);
					if (rowView != null)
						rowView.EndEdit();
				}
				catch(Exception ex)
				{
					this.RaisePageException(ex);
				}
			}
		}

		/// <summary>
		/// Synhronizes all controls between data and bound control.
		/// </summary>
		/// <param name="save">If save is true, control to data, if save is false, data to control</param>
		public void UpdateData(bool save)
		{
			UpdateData(this.Controls, save);
		}

		#endregion

		/// <summary>
		/// The deriving page can override this and provide an appropriate language object
		/// </summary>
		public virtual Language Language
		{
			get
			{
				if (language == null)
				{
					if (this.Site != null)
						if (this.Site.DesignMode)
						{
							language = new Language("EN");
							return language;
						}

					string assemblyName = null, className = null;
					if (MainLanguageClassAttribute.GetMainLanguageClassFromType(this.GetType(), ref assemblyName, ref className))
					{
						
						Type t = Type.GetType(className + "," + assemblyName);
						language = (NetsoftUSA.DataLayer.Language)Activator.CreateInstance(t, new object[] { "EN" });
					}
					else
						language = new Language("EN");	// default language
				}
				return language;
			}
		}

		
		/// <summary>
		/// Called by web page between postbacks.
		/// </summary>
		public virtual void CacheState(string key, NetsoftUSA.DataLayer.DCBase dataComp)
		{
			DataSet ds = dataComp.GetMainDataSet();
			Session[key] = ds;
			/*
			string cacheName = this.Page.Session.SessionID + ".dc." + key;
			this.Cache[cacheName] = ds;*/
		}

		public virtual void LoadState(string key, NetsoftUSA.DataLayer.DCBase dataComp)
		{
			DataSet ds = (DataSet)Session[key];
			dataComp.SetMainDataSet(ds);
			/*string cacheName = this.Page.Session.SessionID + ".dc." + key;
			DataSet ds = (DataSet)this.Cache[cacheName];
			dataComp.SetMainDataSet(ds);*/
		}

		public void CacheObject(Type type, object obj)
		{
			string key = CachingKeyAttribute.GetCachingKeyFromType(type, true);
			CacheObject(key, obj);
		}

		public virtual void CacheObject(string key, object obj)
		{
			CacheObject(key, obj, this.cachingMethod);
		}

		public void CacheObject(string key, object obj, ObjectCachingMethod cachingMethod)
		{
			if (key == null)
			{
				if (obj != null)
					key = CachingKeyAttribute.GetCachingKeyFromType(obj.GetType(), true);
			}

			switch (cachingMethod)
			{
				case ObjectCachingMethod.UseCache:
					Cache[key] = obj;
					break;
				case ObjectCachingMethod.UseSession:
					Session[key] = obj;
					break;
				case ObjectCachingMethod.UseViewState:
					ViewState[key] = obj;
					break;
			}
		}

		public virtual object LoadObject(string key, ObjectCachingMethod cachingMethod)
		{
			switch (cachingMethod)
			{
				case ObjectCachingMethod.UseCache:
					return Cache[key];
				case ObjectCachingMethod.UseSession:
					return Session[key];
				case ObjectCachingMethod.UseViewState:
					return ViewState[key];
			}
			return null;
		}

		public object LoadObject(string key)
		{
			return LoadObject(key, this.cachingMethod);

		}

		public object LoadObject(string key, Type type)
		{
			return LoadObject(key, type, false);
		}

		public object LoadObject(string key, Type type, bool ensure)
		{
			if (key == null)
			{
				key = CachingKeyAttribute.GetCachingKeyFromType(type, true);
			}

			object obj = LoadObject(key);
			if (obj == null)
				if (ensure)
					obj = BaseDataClass.CreateAnyDataObject(type, true);
			return obj;
		}

		public object LoadObject(Type type)
		{
			return LoadObject(type, false);
		}

		public object LoadObject(Type type, bool ensure)
		{
			return LoadObject(null, type, ensure);
		}

		/// <summary>
		/// Manages the server side caching of the given dataComp under given key
		/// </summary>
		/// <param name="key"></param>
		/// <param name="dataComp"></param>
		/// <param name="initialCachingType"></param>
		public virtual void ManageCaching(string key, NetsoftUSA.DataLayer.DCBase dataComp, InitialCachingType initialCachingType)
		{
			if (!this.IsPostBack)
			{
				bool bUseCache = false;
				bool bLoad = true;

				switch(initialCachingType)
				{
					case InitialCachingType.Load:
						bLoad = true;
						bUseCache = false;
						break;
					case InitialCachingType.DontLoad:
						bLoad = false;
						bUseCache = false;
						break;
					case InitialCachingType.UseFromCache:
						bLoad = false;
						bUseCache = true;
						break;
					case InitialCachingType.CheckQueryString:
						if (Request.QueryString["UseCache"] == "1")
						{
							bUseCache = true;
							bLoad = false;
						}
						else if (Request.QueryString["DontLoad"] == "1")
						{
							bUseCache = false;
							bLoad = false;
						}
						else
						{
							bUseCache = false;
							bLoad = true;
						}
						break;
				}
				if (bUseCache)
				{
					this.LoadState(key, dataComp);
					if (dataComp.GetMainDataSet() == null)
						bLoad = true;		// could not load from cache, reload the data
				}
				if (bLoad)
				{
					if (dataComp.IsSearcher)
						dataComp.LoadSearcher();
					else
						dataComp.LoadData();
					this.CacheState(key, dataComp);
				}
			}
			else
			{
				this.LoadState(key, dataComp);
			}
		}

		/// <summary>
		/// The deriving classes may override this to capture the page exception
		/// thrown by NetsoftUSA.WebForms or NetsoftUSA.DataLayer objects.
		/// </summary>
		/// <param name="ex"></param>
		public virtual void RaisePageException(Exception ex)
		{
			exception = ex;

			pageError = true;

			ExceptionWithParameters pex = ex as ExceptionWithParameters;
			if (pex != null)		// translate exception
			{
				string translatedMsg = this.Language.Translate(true, pex.Message, pex.Parameters);
				SetPageMessage(translatedMsg, EnumPageMessageType.Error);
				SetPageLongMessage(translatedMsg);
				return;
			}

			if (ex is SqlException)
			{
				SqlException dex = (SqlException)ex;
				string ufm = null;
				switch (dex.Number)
				{
					case 2601:  ufm = "This record already exists in the database."; break;
					//case 2601:  ufm = "This key already exists in the database."; break;
					default:  ufm = "A database error has been encountered."; break;
				}
				SetPageMessage(ufm, EnumPageMessageType.Error);
				SetPageLongMessage("({0}) - {1}", dex.Number, dex.Message);
				return;
			}

			if (ex is System.Data.ConstraintException)
			{
				SetPageMessage("Constraint exception occured!", EnumPageMessageType.Error);
				SetPageLongMessage(ex.Message);
				return;
			}

			if (ex is NetsoftUSA.DataLayer.ValidationException)
			{
				NetsoftUSA.DataLayer.ValidationException valEx = ex as NetsoftUSA.DataLayer.ValidationException;
				
				string msg = "";
				if (valEx.Field != null && valEx.Field != "")
					msg = "Error in field '" + valEx.Field + "'. ";
				msg += "Please correct!";
				SetPageMessage(msg, EnumPageMessageType.Error);
				SetPageLongMessage(msg + "<BR>" + valEx.Message);
				return;
			}

			if (ex is NetsoftUSA.DataLayer.SQLInvalidParameterizedClauseException)
			{
				string msg = "";
				msg += "Invalid input in page caused SQL parser error!  Please correct.";
				SetPageMessage(msg, EnumPageMessageType.Error);
				SetPageLongMessage(msg + "<BR>" + ex.Message);
				return;
			}

			if (ex is System.Data.ReadOnlyException ||
				ex is System.Data.NoNullAllowedException ||
				ex is System.ArgumentException)
			{
				SetPageMessage("Please correct errors!", EnumPageMessageType.Error);
				SetPageLongMessage(ex.ToString());
			}
			else
			{
				SetPageMessage(ex.Message, EnumPageMessageType.Error); 
				SetPageLongMessage(ex.ToString());
			}
		}

		/// <summary>
		/// The deriving classes may override this to 
		/// show the messages set by the NetsoftUSA.WebForms and NetsoftUSA.DataLayer.
		/// </summary>
		/// <param name="msg"></param>
		public virtual void SetPageMessage(string msg, EnumPageMessageType messageType)
		{
			if (SetPageMessageEvent != null)
				SetPageMessageEvent(this, new SetPageMessageEventArgs(msg, messageType));
			else	// default behavior directly dumps out
				Response.Write("<BR>" + msg + "<BR>");
		}

		public void SetPageMessage(string msg, EnumPageMessageType messageType, params object[] parameters)
		{
			msg = Language.Translate(true, msg, parameters);
			SetPageMessage(msg, messageType);
		}

		public virtual void SetPageLongMessage(string msg)
		{
			if (SetPageLongMessageEvent != null)
				SetPageLongMessageEvent(this, new SetPageMessageEventArgs(msg));
			else	// default behavior directly dumps out
				Response.Write("<BR>" + msg + "<BR>");
		}

		public void SetPageLongMessage(string msg, params object[] parameters)
		{
			msg = Language.Translate(true, msg, parameters);
			SetPageLongMessage(msg);
		}

		[Browsable(false)]
		public bool PageError
		{
			get
			{
				return pageError;
			}
			set
			{
				pageError = value;
				if (pageError)
					exception = new Exception("Page error");
				else
					exception = null;
			}
		}

		[Browsable(false)]
		public Exception Exception
		{
			get
			{
				return exception;
			}
		}

		public bool IsOnLoadScriptRegistered(string name)
		{
			return onloadScripts.Contains(name);
		}

		public void RegisterOnLoadScript(string name, string script)
		{
			if (!onloadScripts.Contains(name))
				onloadScripts[name] = script;
		}

		public bool IsDeclarationScriptRegistered(string name)
		{
			return declarationScripts.Contains(name);
		}

		public void RegisterDeclarationScript(string name, string script)
		{
			if (!declarationScripts.Contains(name))
				declarationScripts[name] = script;
		}

		[Browsable(true)]
		[DefaultValue(ObjectCachingMethod.UseSession)]
		public ObjectCachingMethod CachingMethod
		{
			get { return cachingMethod; }
			set { cachingMethod = value; }
		}

		public Control LoadCustomControl(string id, string controlPath)
		{
			// not allowed to be called from the child controls!..
			Control ctl = this.Page.LoadControl(controlPath);
			ctl.ID = id;
			Controls.Add(ctl);
			return ctl;
		}

		#endregion

		#region Protected members
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
		}

		protected override void Render(HtmlTextWriter writer)
		{
			SetControlGroups(this.Controls, "default");

			registerClientScripts();
			
			base.Render (writer);
		}


		#endregion 


		public string BackPage
		{
			get
			{
				if (this.backPage == null)
					this.backPage = BackPageAttribute.GetBackPageFromType(this.GetType());
				return this.backPage;
			}
			set
			{
				this.backPage = value; 
			}
		}

		public string SelectedMenuItem
		{
			get
			{
				return this.selectedMenuItem;
			}
			set
			{
				selectedMenuItem = value;
			}
		}

		public virtual void RedirectBack()
		{
			// if there's no BackPage declared on the page, just redirect to the same page
			string page = this.BackPage;
			if (page == null)
				page = this.PageName;
			
			NavigateAway();
			Redirect(page);
		}	

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			if (IsPostBack)
			{
				pickButton = false;
				object opickButton = ViewState["PickButton"];
				if (opickButton != null)
					if ((bool)opickButton)
						pickButton = true;

				if (pickButton)
				{
					pickTargetName = (string)ViewState["PickTargetName"];
					pickTargetID = (string)ViewState["PickTargetID"];
					if (pickTargetName != null)
						pickTargetTextData = (string)Request.Form[pickTargetName];
				}

				this.viewOnlyMode = (bool)ViewState["VwOnly"];
				this.printPreviewMode = (bool)ViewState["Prnt"];
				this.accessLevel = (int)ViewState["Acl"];
				this.hasAccessToEdit = (bool)ViewState["AcE"];
				this.backPage = (string)ViewState["BckPg"];
				this.windowMode = (WindowMode)ViewState["wmod"];
				this.PageType = (EnumPageType)ViewState["pageType"];

				this.autoScroll = (bool)ViewState["autoScroll"];

				if (Request["ScrollSaver"] != null)
				{
					string scrollTo = Request["ScrollSaver"];
					string[] pos = scrollTo.Split('&');

					if (pos.Length > 1)
					{
						this.hPos = Int32.Parse(pos[0]);
						this.vPos = Int32.Parse(pos[1]);
					}
					else
					{
						this.hPos = 0;
						this.vPos = 0;
					}
				}

				//classBindingMap = (ClassBindingMap)ViewState["ClsBnd"];
				classBindingMap = ClassBindingMap.DeserializeFromViewState(ViewState["ClsBnd"]);
				//Hashtable ht = ViewState["ClsBnd"] as Hashtable;

				/*if (true)
				{
					// update necessary search items
					DataTable tbl = this.DataSourceObject.GetTable(dataMember);
					foreach (DataColumn col in tbl.Columns)
					{
						
					}
				}*/
			}
		}

		protected override object SaveViewState()
		{
			ViewState["PickButton"] = pickButton;
			ViewState["PickTargetName"] = pickTargetName;
			ViewState["PickTargetID"] = pickTargetID;
			ViewState["VwOnly"] = viewOnlyMode;
			ViewState["Prnt"] = printPreviewMode;
			ViewState["Acl"] = accessLevel;
			ViewState["AcE"] = hasAccessToEdit;
			ViewState["BckPg"] = this.backPage;
			ViewState["wmod"] = this.windowMode;
			ViewState["pageType"] = (int)this.pageType;

			ViewState["autoScroll"] = this.autoScroll;
			ViewState["vPos"] = this.vPos;
			ViewState["hPos"] = this.hPos;

			ViewState["ClsBnd"] = ClassBindingMap.SerializeToViewState(classBindingMap);

			//return allStates;
			return base.SaveViewState();
		}

		protected override void CreateChildControls()
		{
			base.CreateChildControls ();

			//pickTarget = (TextBox)this.FindControl("PickTarget");
		}

		[DefaultValue(false)]
		public bool PickButton
		{
			get
			{
				return pickButton;
			}
			set
			{
				pickButton = value;
			}
		}

		// This is not saved between postbacks
		[DefaultValue(false)]
		public bool BlankForm
		{
			get
			{
				return blankForm;
			}
			set
			{
				blankForm = value;
			}
		}

		internal void SetPickTargetID(string pickTargetID)
		{
			pickTargetTextData = pickTargetID;
		}

		// Called by the ItemPicker control in the page
		internal void SetPickTargetControl(TextBox pickTarget)
		{
			this.pickTarget = pickTarget;
		}

		public ClassBindingProperties GetClassBindingProperties(Type dataClass, bool ensure)
		{
			if (classBindingMap == null)
			{
				if (!ensure)
					return null;
				classBindingMap = new ClassBindingMap();
			}

			ClassBindingProperties props = classBindingMap.Get(dataClass, ensure);
			
			return props;
		}

		public ClassBindingMap ClassBindings
		{
			get
			{
				if (classBindingMap == null)
				{
					classBindingMap = new ClassBindingMap();
				}
				return classBindingMap;
			}
		}

		[DefaultValue(0)]
		public int AccessLevel
		{
			get { return this.accessLevel; }
			set { this.accessLevel = value; }
		}

		[DefaultValue(true)]
		public bool HasAccessToEdit
		{
			get { return this.hasAccessToEdit; }
			set { this.hasAccessToEdit = value; }
		}

		public string PageName
		{
			get { return ReflectionHelper.GetPageNameFromClass(this.GetType()); }
		}

		public static Hashtable GetPageSessionParams()
		{
			HttpContext context = HttpContext.Current;
			return context.Session["PageSessionParams"] as Hashtable;
		}

		public static void RemovePageSessionParams()
		{
			HttpContext context = HttpContext.Current;
			context.Session["PageSessionParams"] = null;
		}

		public static Hashtable PullPageSessionParams()
		{
			Hashtable pageParams = GetPageSessionParams();
			RemovePageSessionParams();
			return pageParams;
		}

		public static Hashtable EnsurePageSessionParams()
		{
			HttpContext context = HttpContext.Current;

			Hashtable pageParams = context.Session["PageSessionParams"] as Hashtable;
			if (pageParams == null)
			{
				pageParams = new Hashtable();
				context.Session["PageSessionParams"] = pageParams;
			}

			return pageParams;
		}

		public Hashtable PageParams
		{
			get 
			{
				if (this.pageParams == null)
					this.pageParams = PullPageSessionParams(); 
				return this.pageParams;
			}
		}

		/// <summary>
		/// Push a parameter to the session to be used by the page
		/// </summary>
		/// <param name="name"></param>
		/// <param name="value"></param>
		public static void PushParam(string name, object value)
		{
			Hashtable pageParams = EnsurePageSessionParams();
			pageParams[name] = value;
		}

		/// <summary>
		/// Explicitly push the calling page context as a parameter
		/// </summary>
		/// <param name="name"></param>
		/// <param name="pageURL"></param>
		public static void PushCallingPage(string pageURL)
		{
			PushParam("CallingPage", pageURL);
		}

		public static void PushCallingPage(BasePage callingPage)
		{
			if (callingPage == null)
				PushParam("CallingPage", null);
			else
				PushParam("CallingPage", callingPage.PageName);
		}

		public static void PushCurrentCallingPage()
		{
			BasePage page = HttpContext.Current.Handler as BasePage;
			PushCallingPage(page);
		}

		public bool HasParam(string name)
		{
			if (this.PageParams == null)
				return false;
			return this.PageParams.ContainsKey(name);
		}

		/// <summary>
		/// A page can check a parameter under a specific name only once for after it was pushed.
		/// Usually the caller will push paramteres and redirect to the target page, where the target
		/// page pulls these paremeters once.
		/// </summary>
		/// <param name="name"></param>
		/// <returns></returns>
		public object GetParam(string name)
		{
			if (this.PageParams == null)
				return null;
			else
				return this.PageParams[name];
		}

		public static object PullParam(string name)
		{
			Hashtable pageParms = PullPageSessionParams();
			if (pageParms == null)
				return null;
			else
				return pageParms[name];
		}

		public object GetParamOrGetFromCache(string paramName, Type cachedClass)
		{
			if (HasParam(paramName))
			{
				// a param was passed, this means use from param
				return GetParam(paramName);
			}
			else
			{
				// the param was not passed, this means use from cache
				return this.LoadObject(cachedClass, false);
			}
		}

		/// <summary>
		/// If this returns false, it means
		/// </summary>
		/// <param name="paramName"></param>
		/// <param name="cacheKey"></param>
		/// <returns></returns>
		public object GetParamOrGetFromCache(string paramName, string cacheKey)
		{
			if (HasParam(paramName))
			{
				// a param was passed, this means use from param
				return GetParam(paramName);
			}
			else
			{
				// the param was not passed, this means use from cache
				return this.LoadObject(cacheKey);
			}
		}

		/// <summary>
		/// A page can check a parameter under a specific name only once for after it was pushed.
		/// Usually the caller will push paramteres and redirect to the target page, where the target
		/// page pulls these paremeters once.
		/// </summary>
		/// <param name="name"></param>
		/// <returns></returns>
		public int GetParamInt(string name, int defaultValue)
		{
			object val = GetParam(name);
			if (val == null)
				return defaultValue;
			else 
				return Convert.ToInt32(val);
		}

		public bool GetParamBool(string name, bool defaultValue)
		{
			object val = GetParam(name);
			if (val == null)
				return defaultValue;
			else 
				return Convert.ToBoolean(val);
		}

		public DateTime GetParamDateTime(string name, DateTime defaultValue)
		{
			object val = GetParam(name);
			if (val == null)
				return defaultValue;
			else 
				return Convert.ToDateTime(val);
		}

		public DateTime GetParamDateTime(string name)
		{
			return GetParamDateTime(name, DateTime.MinValue);
		}

		/// <summary>
		/// A page can check a parameter under a specific name only once for after it was pushed.
		/// Usually the caller will push paramteres and redirect to the target page, where the target
		/// page pulls these paremeters once.
		/// </summary>
		/// <param name="name"></param>
		/// <returns></returns>
		public object GetParam(string name, object ValueForNull)
		{
			object val = GetParam(name);
			if (val == null)
				return ValueForNull;
			else
				return val;
		}

		public static void Redirect(string url)
		{
			HttpContext context = HttpContext.Current;
			BasePage basePage = context.Handler as BasePage;
			if (basePage != null)
				basePage.NavigateAway();
			context.Response.Redirect(url);
		}

		public static void Redirect(Type pageClass)
		{
			Redirect(  ReflectionHelper.GetPageNameFromClass(pageClass)  );
		}

		public static void Redirect(string url, bool endReponse)
		{
			HttpContext context = HttpContext.Current;
			BasePage basePage = context.Handler as BasePage;
			if (basePage != null)
				basePage.NavigateAway();
			context.Response.Redirect(url, endReponse);
		}

		public bool CheckBoxDescriptionsOn
		{
			get { return OBCheckBox.BindTextsToDescriptions; }
		}

		/// <summary>
		/// The | seperated parameters given by this property can be used by
		/// OBLabel controls on the page.  If the label doesn't have its own
		/// TextToTranslateParameters value set, this value is used instead.
		/// </summary>
		//public string TextToTranslateParameters
		//{
		//	get { return this.textToTranslateParameters; }
		//	set { this.textToTranslateParameters = value; }
		//}

		/// <summary>
		/// This is called whenever you redirect to another page by invoking the Redirect method
		/// </summary>
		public virtual void NavigateAway()
		{
			// navigating away from this page.

		}

	}

	[Serializable]
	public class ClassBindingMap : Hashtable
	{
		public ClassBindingProperties Get(Type dataClass, bool ensure)
		{
			ClassBindingProperties props = null;
			if (dataClass != null)
				props = (ClassBindingProperties)this[dataClass.FullName];
			if (props == null)
				if (ensure)
				{
					props = new ClassBindingProperties(dataClass);
					this.Set(props);
				}
			return props;
		}

		public void Set(ClassBindingProperties classBindingProps)
		{
			this[classBindingProps.dataClass] = classBindingProps;
		}

		public bool GetReadOnly(Type dataClass)
		{
			ClassBindingProperties props = Get(dataClass, false);
			if (props == null)
				return false;
			else
				return props.ReadOnly;
		}

		public bool GetViewOnly(Type dataClass)
		{
			ClassBindingProperties props = Get(dataClass, false);
			if (props == null)
				return false;
			else
				return props.ViewOnly;
		}

		internal static object SerializeToViewState(ClassBindingMap classBindingMap)
		{
			if (classBindingMap == null)
				return null;
			ArrayList arr = new ArrayList();
			foreach(DictionaryEntry de in classBindingMap)
			{
				 arr.Add(de.Value);
			}
			return arr;
		}

		internal static ClassBindingMap DeserializeFromViewState(object o)
		{
			ArrayList arr = o as ArrayList;
			if (o == null)
				return null;
			ClassBindingMap map = new ClassBindingMap();
			foreach(ClassBindingProperties prop in arr)
			{
				map.Set(prop);
			}
			return map;
		}

	}

	[Serializable]
	public class ClassBindingProperties
	{
		//public  Flags
		internal string dataClass = null;	// what type of class to be bound
		private bool readOnly = false;		// this type of controls will be readonly
		private bool viewOnly = false;		// this type of controls will be viewonly

		public ClassBindingProperties(Type dataClass)
		{
			this.dataClass = dataClass.FullName;
		}

		public bool ReadOnly
		{
			get { return this.readOnly; }
			set { this.readOnly = value; }
		}

		public bool ViewOnly
		{
			get { return this.viewOnly; }
			set { this.viewOnly = value; }
		}

	}

}
