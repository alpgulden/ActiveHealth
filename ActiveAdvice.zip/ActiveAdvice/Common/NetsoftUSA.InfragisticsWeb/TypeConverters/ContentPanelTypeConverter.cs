using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;


namespace NetsoftUSA.InfragisticsWeb
{
	/// <summary>
	/// Summary description for ContentPanelTypeConverter.
	/// </summary>
	public class ContentPanelTypeConverter : TypeConverter
	{
		public ContentPanelTypeConverter() : base()
		{
		}


		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;		// We support a list of possible data source at design time
		}

		private void FindContentPanels(ControlCollection controls, System.Collections.ArrayList ls)
		{
			foreach (Control c in controls)
			{
				if (c is ContentPanel)
				{
					if (c.Site != null)
						ls.Add(c.Site.Name);
				}
				else
					if (c.Controls.Count > 0)
					FindContentPanels(c.Controls, ls);
			}
		}

		public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			System.Collections.ArrayList ls = new System.Collections.ArrayList();
			ls.Add(null);
			Control ctl = (Control)context.Instance;
			
			FindContentPanels(ctl.Page.Controls, ls);

			ls.Sort();
			return new System.ComponentModel.TypeConverter.StandardValuesCollection(ls);
		}

	}
}
