using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using Infragistics.WebUI.UltraWebListbar;
using NetsoftUSA.WebForms;
using System.Runtime.Serialization;

namespace NetsoftUSA.InfragisticsWeb
{
	
	[Serializable]
	public class ListbarButtonExtraProperties : ISerializable 
	{
		private string controlGroup = "";
		private bool checksForIsDirty = false;
		private bool visible = true;
		private Item item = null;
		
		public ListbarButtonExtraProperties(Item item, string controlGroup, bool checksForIsDirty)
			: this(item, controlGroup, checksForIsDirty, true)
		{
			
		}

		public ListbarButtonExtraProperties(Item item, string controlGroup, bool checksForIsDirty, bool visible)
		{
			this.controlGroup = controlGroup;
			this.checksForIsDirty = checksForIsDirty;
			this.visible = visible;
			this.item = item;
		}

		
		public bool Enabled
		{
			get {return this.Item.Enabled;}
			set {this.Item.Enabled = value;}
		}

		public string ControlGroup
		{
			get {return this.controlGroup;}
			set {this.controlGroup = value;}
		}

		public bool ChecksForIsDirty
		{
			get {return this.checksForIsDirty;}
			set {this.checksForIsDirty = value;}
		}

		public bool Visible
		{
			get {return this.visible;}
			set {this.visible = value;}
		}

		public Item Item
		{
			get {return this.item;}
		}

		public ListbarButtonExtraProperties(SerializationInfo info, StreamingContext context)
		{
		}

		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
		}
	}

	/// <summary>
	/// Summary description for WebListBar.
	/// </summary>
	[ToolboxData("<{0}:WebListBar runat=server></{0}:WebListBar>")]
	public class WebListBar : UltraWebListbar, IControlGroupProvider, IControlledGrouper
	{
		private string controlGroup = "";
		private bool isGroupSet;

		public WebListBar()
		{
		}

		
		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);
			// We have to populate the buttons every time anyway. No need for viewstate.
			this.EnableViewState= false;
			this.ItemClicked += new ItemClickedEventHandler(WebListBar_ItemClicked);

			BasePage page = this.Page as BasePage;
			if (page != null)
			{
				page.ApplyCss(this);
				page.RegisterPageSubMenuControl(this);
				page.PopulateSubNavigation(this);
				
			}
			
		}


		protected override void Render(HtmlTextWriter writer)
		{
			string dStyle = this.DefaultItemStyle.CssClass;
			string hStyle = this.DefaultItemHoverStyle.CssClass;
			string sStyle = this.DefaultItemSelectedStyle.CssClass;

			foreach (Group listbarGroup in this.Groups)
			{
				foreach (object groupItem in listbarGroup.Items)
				{
					Item item = groupItem as Item;
					if (item != null)
					{
						ListbarButtonExtraProperties props = item.Tag as ListbarButtonExtraProperties;
						if (props != null && !props.Visible)
						{
							item.DefaultStyle.CustomRules = "display:none;";
							item.HoverStyle.CustomRules = "display:none;";
							item.SelectedStyle.CustomRules ="display:none;";
						}

					}
				}
			}
			BasePage page = this.Page as BasePage;
			if (page != null)
			{
				page.SelectSideMenuItem(this);
			}
			base.Render (writer);
		}


		public Infragistics.WebUI.UltraWebListbar.Group AddGroup(string title, string key)
		{
//			//temporary fix
			return null;
			if (this.Groups.FromKey(key) == null)
			{
				string translatedText = ((BasePage)this.Page).Language.Translate(title);
				return this.Groups.Add(translatedText, key);
			}

			return null;
		}


		public ListbarButtonExtraProperties AddItem(Infragistics.WebUI.UltraWebListbar.Group group, string title, string key, bool checksForIsDirty)
		{
			return AddItem(true, group, title, key, checksForIsDirty);
		}


		public ListbarButtonExtraProperties AddItem(bool visible, Infragistics.WebUI.UltraWebListbar.Group group, string title, string key, bool checksForIsDirty)
		{
			ListbarButtonExtraProperties props = null;

//			//temporary fix
			group = this.Groups.FromKey("Default");

			if (group != null)
			{
				Infragistics.WebUI.UltraWebListbar.Item item = group.Items.FromKey(key);
				if (item == null)
				{
					string translatedText = ((BasePage)this.Page).Language.Translate(title);
					item = group.Items.Add(translatedText, key);
					props = new ListbarButtonExtraProperties(item, null, checksForIsDirty);
					item.Tag = props;
				}
			}

			return props;
		}


		public ListbarButtonExtraProperties AddItem(Infragistics.WebUI.UltraWebListbar.Group group, string title, string key)
		{
			return AddItem(true, group, title, key);
		}

		public ListbarButtonExtraProperties AddItem(bool visible, Infragistics.WebUI.UltraWebListbar.Group group, string title, string key)
		{
			return AddItem(group, title, key, true);
		}


		public ListbarButtonExtraProperties AddItem(string title, string key)
		{
			return AddItem(true, title, key);
		}

		/// <summary>
		/// Adds the provided item to the default group
		/// </summary>
		/// <param name="title"></param>
		/// <param name="key"></param>
		/// <returns></returns>
		public ListbarButtonExtraProperties AddItem(bool visible, string title, string key)
		{
			Infragistics.WebUI.UltraWebListbar.Group defaultGroup = this.Groups.FromKey("Default");
			return AddItem(defaultGroup, title, key);
		}


		public ListbarButtonExtraProperties AddItem(string title, string key, bool checksForDirty)
		{
			return AddItem(true, title, key, checksForDirty);
		}

		public ListbarButtonExtraProperties AddItem(bool visible, string title, string key, bool checksForDirty)
		{
			Infragistics.WebUI.UltraWebListbar.Group defaultGroup = this.Groups.FromKey("Default");
			return AddItem(defaultGroup, title, key, checksForDirty);
		}


		private void WebListBar_ItemClicked(object sender, WebListbarItemEvent e)
		{
			BasePage page = this.Page as BasePage;
			if (page != null)
			{
				page.OnSubNavigationItemClick(this, e.Item);
			}	
		}		
		
		
		/// <summary>
		/// If controlGroup is not specified, the control will inherit it from its parent
		/// </summary>
		[DefaultValue("")]
		public string ControlGroup
		{
			get { return this.controlGroup; }
			set 
			{ 
				this.controlGroup = value; 
			
				BasePage page = this.Page as BasePage;
				if (page != null)
				{	
					foreach (Group listbarGroup in this.Groups)
					{
						foreach (object groupItem in listbarGroup.Items)
						{
							Item item = groupItem as Item;
							if (item != null)
							{
								ListbarButtonExtraProperties props = item.Tag as ListbarButtonExtraProperties;
								if (props == null)
								{
									props = new ListbarButtonExtraProperties(item, this.controlGroup, true);
								}
								if (props.ControlGroup != null && props.ControlGroup != "")
									page.SetControlProperties(item.Key, new ControlExtraProperties(item.ID, props.ControlGroup, this.ClientID, false, props.ChecksForIsDirty));
								else
									page.SetControlProperties(item.Key, new ControlExtraProperties(item.ID, this.controlGroup, this.ClientID, false, props.ChecksForIsDirty));

							}
						}
					}
				}				
			}
		}
		
		#region IControlledGrouper Members

		public bool IsGroupSet
		{
			get
			{
				return isGroupSet;
			}
			set
			{
				isGroupSet = value;
			}
		}

		#endregion

	}
}
