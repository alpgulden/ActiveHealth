using System;

namespace NetsoftUSA.InfragisticsWeb
{
	/// <summary>
	/// Summary description for ToolbarButton.
	/// </summary>
	public class ToolbarButton : Infragistics.WebUI.UltraWebToolbar.TBarButton
	{
		public ToolbarButton() : base()
		{

		}

		public ToolbarButton(string text) : base(text)
		{

		}		

	}
}
