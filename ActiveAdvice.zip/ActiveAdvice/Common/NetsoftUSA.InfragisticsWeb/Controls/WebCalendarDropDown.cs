using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Reflection;
using NetsoftUSA.WebForms;
using Infragistics.WebUI.WebDataInput;

namespace NetsoftUSA.InfragisticsWeb
{
	/// <summary>
	/// Summary description for WebCalendarDropDown.
	/// </summary>
	[ToolboxData("<{0}:WebCalendarDropDown runat=server></{0}:WebCalendarDropDown>")] 
	public class WebCalendarDropDown : Infragistics.WebUI.WebSchedule.WebCalendar, IControlGroupProvider
	{		
		private string controlGroup = "";

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);
		}


		protected override void OnPreRender(EventArgs e)
		{
			bool designMode = this.Site != null && this.Site.DesignMode;
			try
			{
				this.ClientSideEvents.InitializeCalendar = "initCalendarEvent";
				this.ClientSideEvents.DateClicked = "calendarDateClickedEvent";	
				if (!designMode)
					this.Style["display"] = "none";
			}
			catch
			{}

			base.OnPreRender (e);
		}

		protected override void Render(HtmlTextWriter writer)
		{
			bool designMode = this.Site != null && this.Site.DesignMode;

			base.Render (writer);

			try
			{
				this.ClientSideEvents.InitializeCalendar = null;
				this.ClientSideEvents.DateClicked = null;
				if (!designMode)
					this.Style.Remove("display");
			}
			catch
			{}
		}

		/// <summary>
		/// If controlGroup is not specified, the control will inherit it from its parent
		/// </summary>
		[DefaultValue("")]
		public string ControlGroup
		{
			get { return this.controlGroup; }
			set { this.controlGroup = value; }
		}

	}
}
