using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using Infragistics.WebUI.UltraWebTab;
using Infragistics.WebUI.Shared;
using Infragistics.WebUI.UltraWebToolbar;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using System.Runtime.Serialization;

namespace NetsoftUSA.InfragisticsWeb
{
	/// <summary>
	/// Summary description for WebTab.
	/// </summary>
	
	[Serializable]
	public class TabExtraProperties : ISerializable 
	{
		public string ControlGroup = "";


		public TabExtraProperties(string controlGroup)
		{
			this.ControlGroup = controlGroup;
		}

		public TabExtraProperties(SerializationInfo info, StreamingContext context)
		{
			return;
		}

		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			return;
		}

	}




	[ToolboxData("<{0}:WebTab runat=server></{0}:WebTab>")]

	public class WebTab : Infragistics.WebUI.UltraWebTab.UltraWebTab, IControlGroupProvider, IControlledGrouper
	{

		public static Infragistics.WebUI.Shared.Style defaultTabStyle;
		public static Infragistics.WebUI.Shared.Style hoverTabStyle;
		public static Infragistics.WebUI.Shared.Style selectedTabStyle;

		public static Infragistics.WebUI.UltraWebTab.RoundedImage roundedImage;

		private string controlGroup = "";
		private bool isGroupSet;

		public WebTab() : base()
		{
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);
			((BasePage)this.Page).PopulateTabItems(this);
			this.TabClick += new TabClickEventHandler(WebTab_TabClick);
		}


		protected override void CreateChildControls()
		{
			base.CreateChildControls();
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);


			BasePage page = this.Page as BasePage;
			if (page != null)
			{
				page.RegisterPageTabControl(this);
				page.ApplyCss(this);
			}

			foreach (TabItem tabItem in this.Tabs)
			{
				if (tabItem is Tab)
				{
					ContentPane contentPane = ((Tab)tabItem).ContentPane;

					if (contentPane.FindControl(tabItem.Key + "_TabToolbar") == null)
					{
						WebToolbar webToolbar = new WebToolbar(ToolbarType.TabToolbar);
						contentPane.Controls.AddAt(0, webToolbar);
						webToolbar.ID = tabItem.Key + "_TabToolbar";
                   
						if (page != null)
						{
							// Call the OnPopulateToolbarItems method on BasePage passing a reference to this toolbar
							page.PopulateToolbarItems(webToolbar, (Tab)tabItem);
							
							webToolbar.ButtonClicked += new Infragistics.WebUI.UltraWebToolbar.UltraWebToolbar.ButtonClickedEventHandler(webToolbar_ButtonClicked);
						}
					}					
				}

			}

			this.TabClick += new TabClickEventHandler(WebTab_TabClick);
		}

		protected override object SaveViewState()
		{
			return base.SaveViewState ();
		}


		protected override void OnPreRender(EventArgs e)
		{
			this.ClientSideEvents.BeforeSelectedTabChange = "WebTab_BeforeSelectedTabChange";

			base.OnPreRender (e);
		}


		protected override void Render(HtmlTextWriter writer)
		{
			if (this.Tabs.Count > 0)
			{
				string[] texts = new string[this.Tabs.Count];
				Language lang = ((BasePage)this.Page).Language;

				// Translate all the tab texts and store originals in a string array
				for (int i = 0; i < this.Tabs.Count; i++)			
				{
					texts[i] = this.Tabs[i].Text;
					this.Tabs[i].Text = lang.Translate(this.Tabs[i].Text);
				}

				try
				{
					// Render the control with translated texts
					base.Render (writer);
				}
				catch (Exception ex)
				{
					throw ex;					
				}
				finally
				{
					// Restore the original texts
					for (int i = 0; i < this.Tabs.Count; i++)			
					{
						this.Tabs[i].Text = texts[i];
					}
				}

			}
			else
				base.Render (writer);
		}



		private void webToolbar_ButtonClicked(object sender, ButtonEvent be)
		{
			BasePage page = this.Page as BasePage;
			if (page != null)
			{
				page.OnToolbarButtonClick((WebToolbar)sender, be.Button);
			}
		}


		
		public Infragistics.WebUI.UltraWebTab.Tab AddTab(string title, string key)
		{
			return AddTab(title, key, this.controlGroup);
		}


		/// <summary>
		/// This method adds creates a tab on this control with the provided title and key. 
		/// It first tries to allocate a blank tab and use that. Otherwise it creates a new one.
		/// </summary>
		/// <param name="title">Title of the tab</param>
		/// <param name="key">Key to be used for easy access to the tab</param>
		/// <returns></returns>
		public Infragistics.WebUI.UltraWebTab.Tab AddTab(string title, string key, string controlGroup)
		{
			// Add it if only it is not already on the webtab
			if (this.Tabs.FromKeyTab(key) == null)
			{
				string translatedText = ((BasePage)this.Page).Language.Translate(title);

				// If there is a blank tab use that first.
				foreach (TabItem tabItem in this.Tabs)
				{
					if (tabItem is Tab && tabItem.Text.Equals(""))
					{
						tabItem.Text = translatedText;
						tabItem.Key = key;
						tabItem.Tag = new TabExtraProperties(controlGroup);
						return (Tab)tabItem;
					}
				}

				// Otherwise add a new tab
				Tab tab = new Tab(translatedText);
				tab.Key = key;
				tab.Tag = new TabExtraProperties(controlGroup);
				return (Tab)this.Tabs.Add(tab);
			}


			return null;
		}

		
		public Infragistics.WebUI.UltraWebTab.Tab GetTab(string key)
		{
			return this.Tabs.FromKeyTab(key);
		}



	
		private void WebTab_TabClick(object sender, WebTabEvent e)
		{
			string currentKey = e.PreviousSelectedTab.Key;
			string newKey = e.Tab.Key;

			string currentTabGroup = ""; 
			string newTabGroup = "";
	
			// Let's see if the groups support Tab Grouping
			if (currentKey.IndexOf("_") > 0) currentTabGroup = currentKey.Substring(0, currentKey.IndexOf("_"));
			if (newKey.IndexOf("_") > 0) newTabGroup = newKey.Substring(0, newKey.IndexOf("_"));
		
			// If we're switching between groups that means we need postback
			if (currentTabGroup != newTabGroup)
			{
				BasePage page = this.Page as BasePage;
				if (page != null)
				{
					page.OnTabClick((WebTab)sender, e.Tab, e.PreviousSelectedTab);
				}
			}
		}


		/// <summary>
		/// If controlGroup is not specified, the control will inherit it from its parent
		/// </summary>
		[DefaultValue("")]
		public string ControlGroup
		{
			get { return this.controlGroup; }
			set 
			{ 
				this.controlGroup = value; 
			
				BasePage page = this.Page as BasePage;
				if (page != null)
				{		
					foreach (TabItem tabItem in this.Tabs)
					{
						Tab tab = tabItem as Tab;
						if (tab != null)
						{
							TabExtraProperties props = tabItem.Tag as TabExtraProperties;
							if (props == null)
							{
								props = new TabExtraProperties(this.controlGroup);
							}

							if (props.ControlGroup != null && props.ControlGroup != "")
							{
								page.SetControlProperties(tab.Key, new ControlExtraProperties(tab.ID, props.ControlGroup, this.ClientID, false, false));
								page.SetControlGroups(tab.ContentPane.Controls, props.ControlGroup);
							}
							else
							{
								page.SetControlProperties(tab.Key, new ControlExtraProperties(tab.ID, this.controlGroup, this.ClientID, false, false));
								page.SetControlGroups(tab.ContentPane.Controls, this.controlGroup);
							}
							
						}
					}
				}
			}
		}

		public string SelectedTabKey
		{
			get
			{
				if (this.SelectedTabObject == null)
					return null;
				else
					return this.SelectedTabObject.Key;
			}
			set
			{
				if (value == null)
				{
					// go to first tab
					if (this.Tabs.Count > 0)
						this.SelectedTabIndex = 0;		// firts tab
					else
						this.SelectedTabObject = null;
				}
				else
					this.SelectedTabObject = this.GetTab(value);
			}
		}
		
	
			
		#region IControlledGrouper Members

		public bool IsGroupSet
		{
			get
			{
				return isGroupSet;
			}
			set
			{
				isGroupSet = value;
			}
		}

		#endregion
	}
}
