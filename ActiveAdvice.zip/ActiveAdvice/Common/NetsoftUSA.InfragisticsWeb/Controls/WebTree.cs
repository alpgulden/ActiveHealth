using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using Infragistics.WebUI.UltraWebNavigator;
using System.Collections;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;

namespace NetsoftUSA.InfragisticsWeb
{
	/// <summary>
	/// Summary description for WebTree.
	/// </summary>
	[ToolboxData("<{0}:WebTree runat=server></{0}:WebTree>")]
	public class WebTree : Infragistics.WebUI.UltraWebNavigator.UltraWebTree
	{
		public WebTree() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public void FillNodeCssAttribs(Infragistics.WebUI.UltraWebNavigator.Node node, string CssClass, string HoverClass, string ImageUrl)
		{
			for (int i = 0; i < node.Nodes.Count; i++)
			{
				if (CssClass != null)
					node.Nodes[i].CssClass = CssClass;
				if (HoverClass != null)
					node.Nodes[i].HoverClass = HoverClass;
				if (ImageUrl != null)
					node.Nodes[i].ImageUrl = ImageUrl;
			}
		}

		public void FillNodeCssAttribs(Infragistics.WebUI.UltraWebNavigator.Node node, string CssClass, string HoverClass)
		{
			FillNodeCssAttribs(node, CssClass, HoverClass, null);
		}

		public void FillFromCollection(Infragistics.WebUI.UltraWebNavigator.Node node, BaseDataCollectionClass col, string memberToText, string memberToDataKey, string memberToTag)
		{
			for (int i = 0; i < col.Count; i++)
			{
				BaseDataClass data = col.GetAt(i);
				Infragistics.WebUI.UltraWebNavigator.Node nd = AddDataObject(node, data, memberToText, memberToDataKey, memberToTag);
				if (memberToDataKey == null)
					nd.DataKey = i;
			}
		}

		public Infragistics.WebUI.UltraWebNavigator.Node AddDataObject(Infragistics.WebUI.UltraWebNavigator.Node node, BaseDataClass data, string memberToText, string memberToDataKey, string memberToTag)
		{
			if (data == null)
				return null;
			string sval = data.GetStr(memberToText);
			Node nd = null;
			if (memberToTag != null)
				nd = node.Nodes.Add(sval, data.GetDB(memberToTag));
			else
				nd = node.Nodes.Add(sval);
			if (memberToDataKey != null)
				nd.DataKey = data.GetDB(memberToDataKey);

			return nd;
		}

	}
}
