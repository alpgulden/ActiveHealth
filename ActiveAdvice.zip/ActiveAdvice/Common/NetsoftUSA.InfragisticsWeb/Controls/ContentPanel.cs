using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using System.IO;
using NetsoftUSA.WebForms;

namespace NetsoftUSA.InfragisticsWeb
{
	/// <summary>
	/// Summary description for ContentPanel.
	/// </summary>
	[ToolboxData("<{0}:ContentPanel runat=server></{0}:ContentPanel>")]
	[Designer(typeof(NetsoftUSA.InfragisticsWeb.ContentPanelDesigner))]
	public class ContentPanel : System.Web.UI.WebControls.Panel, IControlGroupProvider, IControlledGrouper
	{
		private string controlGroup = "";
		private bool toBeRendered = true;
		private bool isGroupSet = false;
		private bool visibleInPrintPreviewMode = true;		// whether this pannel will be visible in the preview mode

		[Browsable(false)]
		public bool ToBeRendered
		{
			get {return toBeRendered;}
			set {toBeRendered = value;}
		}

		public ContentPanel() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
		}

		protected override void Render(HtmlTextWriter writer)
		{
			bool designMode = this.Site != null && this.Site.DesignMode;

//			writer.Write("Design Mode: " + designMode.ToString() + "<BR>");
//			writer.Write("Site: " + (this.Site == null).ToString() + "<BR>");
//			writer.Write("Site Design Mode: " + this.Site.DesignMode.ToString() + "<BR>");

			// Do not render the control if not in design mode and ToBeRendered is set to false by another control.
			if (designMode || toBeRendered)
			{
//				if (designMode)
//				{
//					writer.Write("zirt pirt");
//				}

				if (!this.visibleInPrintPreviewMode)
					if (((BasePage)Page).PrintPreviewMode)
						return;		// don't render.
				base.Render (writer);
			}
		}

		/// <summary>
		/// If controlGroup is not specified, the control will inherit it from its parent
		/// </summary>
		[DefaultValue("")]
		public string ControlGroup
		{
			get { return this.controlGroup; }
			set { this.controlGroup = value; }
		}

		public bool IsGroupSet
		{
			get { return this.isGroupSet; }
			set { this.isGroupSet = value; }
		}

		/// <summary>
		/// If this property is false, the panel won't display when Page.PrintPreviewMode = true
		/// </summary>
		[DefaultValue(true)]
		public bool VisibleInPrintPreviewMode
		{
			get { return this.visibleInPrintPreviewMode; }
			set { this.visibleInPrintPreviewMode = value; }
		}

	}
}
