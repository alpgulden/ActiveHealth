using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using System.IO;
using NetsoftUSA.WebForms;

namespace NetsoftUSA.InfragisticsWeb
{
	/// <summary>
	/// Summary description for ContentPlaceHolder.
	/// </summary>
	
	[ToolboxData("<{0}:ContentPlaceHolder runat=server></{0}:ContentPlaceHolder>")]
	public class ContentPlaceHolder : System.Web.UI.WebControls.PlaceHolder, IControlGroupProvider
	{
		private string controlGroup = "";
		private string controlToRender = null;
		private ContentPanel contentPanel = null;

		[TypeConverter(typeof(ContentPanelTypeConverter))]
		public string ControlToRender
		{
			get
			{
				return controlToRender;
			}
			set 
			{
				controlToRender = value;
			}
		}

		public ContentPanel ContentPanel
		{
			get 
			{
				if (contentPanel == null) 
					 contentPanel = this.Page.FindControl(controlToRender) as ContentPanel;
				return contentPanel; 
			}
		}
		

		public ContentPlaceHolder() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			bool designMode = this.Site != null && this.Site.DesignMode;

//			writer.Write("Design Mode: " + designMode.ToString() + "<BR>");
//			writer.Write("Site: " + (this.Site == null).ToString() + "<BR>");
//			writer.Write("Site Design Mode: " + this.Site.DesignMode.ToString() + "<BR>");

			// Do not render the control if not in design mode and ToBeRendered is set to false by another control.
			if (!designMode && this.ContentPanel != null)
			{
				this.ContentPanel.ToBeRendered = true;

				StringWriter sw = new StringWriter();
				HtmlTextWriter tw = new HtmlTextWriter(sw);

				this.ContentPanel.RenderControl(tw);
				writer.Write(sw.ToString());

				this.ContentPanel.ToBeRendered = false;
			}

			base.Render(writer);
		}

	


		/// <summary>
		/// If controlGroup is not specified, the control will inherit it from its parent
		/// </summary>
		[DefaultValue("")]
		public string ControlGroup
		{
			get { return this.controlGroup; }
			set 
			{ 
				this.controlGroup = value; 
               
				BasePage page = this.Page as BasePage;
				if (page != null && this.ContentPanel != null)
				{
					// Loop through the children of the contentpanel
					if (this.ContentPanel.ControlGroup == null || this.ContentPanel.ControlGroup == "")
						page.SetControlGroups(this.ContentPanel.Controls, this.ControlGroup);
					else
					{
						page.AddControlGroup(this.ContentPanel.ControlGroup, this.ControlGroup);
						page.SetControlGroups(this.ContentPanel.Controls, this.ContentPanel.ControlGroup);
					}

					// Set this propery so that next time SetControlGroups method visits this contentpanel it won't process it again.
					this.ContentPanel.IsGroupSet = true;
				}
						
			}
		}

	}
}
