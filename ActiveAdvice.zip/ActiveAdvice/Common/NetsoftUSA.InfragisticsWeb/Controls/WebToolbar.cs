using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using Infragistics.WebUI.UltraWebToolbar;
using NetsoftUSA.WebForms;
using System.Runtime.Serialization;
using System.Drawing.Text;
using System.Drawing;
using System.Drawing.Imaging;

namespace NetsoftUSA.InfragisticsWeb
{

	public enum ToolbarType
	{
		TabToolbar = 0,
		PageToolbar = 1
	}

	[Flags]
	public enum ToolbarButtons
	{
		Save = 2,
		Cancel = 4,
        SaveCancel = Save | Cancel,
	}

	public class ToolbarButtonClickEventArgs : EventArgs
	{
		public ToolbarButtonClickEventArgs()
		{
		}
	}

	[Serializable]
	public class ToolbarButtonExtraProperties : ISerializable 
	{
		private string controlGroup = "";
		private bool causesValidation = false;
		private bool checksForIsDirty = false;
		private bool visible = true;
		private TBarButton item = null;

		public ToolbarButtonExtraProperties(TBarButton item, string controlGroup, bool causesValidation, bool checksForIsDirty)
			: this(item, controlGroup, causesValidation, checksForIsDirty, true)
		{
			
		}

		public ToolbarButtonExtraProperties(TBarButton item, string controlGroup, bool causesValidation, bool checksForIsDirty, bool visible)
		{
			this.controlGroup = controlGroup;
			this.causesValidation = causesValidation;
			this.checksForIsDirty = checksForIsDirty;
			this.visible = visible;
			this.item = item;
		}


		public bool Enabled
		{
			get {return this.item.Enabled;}
			set {this.item.Enabled = value;}
		}

		public string ControlGroup
		{
			get {return this.controlGroup;}
			set {this.controlGroup = value;}
		}

		public bool CausesValidation
		{
			get {return this.causesValidation;}
			set {this.causesValidation = value;}
		}

		public bool ChecksForIsDirty
		{
			get {return this.checksForIsDirty;}
			set {this.checksForIsDirty = value;}
		}

		public bool Visible
		{
			get {return this.visible;}
			set {this.visible = value;}
		}

		public TBarButton Item
		{
			get {return this.item;}
		}


		public ToolbarButtonExtraProperties(SerializationInfo info, StreamingContext context)
		{
			return;
		}

		public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			return;
		}

	}

	/// <summary>
	/// Summary description for WebToolbar.
	/// </summary>
	[ToolboxData("<{0}:WebToolbar ToolbarType=\"PageToolbar\" runat=server></{0}:WebToolbar>")]
	public class WebToolbar : Infragistics.WebUI.UltraWebToolbar.UltraWebToolbar, IControlGroupProvider, IControlledGrouper
	{
		private ToolbarType toolbarType;
		private string controlGroup = "";
		private bool isGroupSet;

        
		public ToolbarType ToolbarType
		{
			get 
			{
				return toolbarType;
			}
			set
			{
				toolbarType = value;
			}
		}


		public WebToolbar(): base()
		{
		}

		public WebToolbar(ToolbarType toolbarType)
		{
			this.ToolbarType = toolbarType;
		}

		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
		}

		protected override void CreateChildControls()
		{
			base.CreateChildControls ();
		}


		

		public ToolbarButtonExtraProperties AddButton(string text, string key)
		{
			return AddButton(true, text, key, this.controlGroup); 
		}

		public ToolbarButtonExtraProperties AddButton(bool visible, string text, string key)
		{
			return AddButton(visible, text, key, this.controlGroup); 
		}

		public ToolbarButtonExtraProperties AddButton(string text, string key, string controlGroup)
		{
			return AddButton(true, text, key, controlGroup);
		}

		public ToolbarButtonExtraProperties AddButton(bool visible, string text, string key, string controlGroup)
		{
			bool causesValidation = false;
			if (key == "Save") causesValidation = true;
			return AddButton(visible, text, key, controlGroup, causesValidation);
		}

		public ToolbarButtonExtraProperties AddButton(string text, string key, bool causesValidation)
		{
			return AddButton(true, text, key, this.controlGroup, causesValidation);
		}

		public ToolbarButtonExtraProperties AddButton(bool visible, string text, string key, bool causesValidation)
		{
			return AddButton(visible, text, key, this.controlGroup, causesValidation);
		}

		public ToolbarButtonExtraProperties AddButton(string text, string key, string controlGroup, bool causesValidation)
		{
			return AddButton(true, text, key, controlGroup, causesValidation);
		}

		public ToolbarButtonExtraProperties AddButton(bool visible, string text, string key, string controlGroup, bool causesValidation)
		{
			bool checksForIsDirty = true;
			if (key == "Save") checksForIsDirty = false;

			return AddButton(visible, text, key, controlGroup, causesValidation, checksForIsDirty);
		}

		public ToolbarButtonExtraProperties AddButton(string text, string key, bool causesValidation, bool checksForIsDirty)
		{
			return AddButton(true, text, key, this.controlGroup, causesValidation, checksForIsDirty);
		}

		public ToolbarButtonExtraProperties AddButton(bool visible, string text, string key, bool causesValidation, bool checksForIsDirty)
		{
			return AddButton(visible, text, key, this.controlGroup, causesValidation, checksForIsDirty);
		}

		public ToolbarButtonExtraProperties AddButton(string text, string key, string controlGroup, bool causesValidation, bool checksForIsDirty)
		{
			return AddButton(true, text, key, controlGroup, causesValidation, checksForIsDirty);
		}

		public ToolbarButtonExtraProperties AddButton(bool visible, string text, string key, string controlGroup, bool causesValidation, bool checksForIsDirty)
		{
			TBarButton button;
			ToolbarButtonExtraProperties props = null;

			button = (TBarButton)this.Items.FromKey(key);
			
			if (button == null)
			{
				string translatedText = ((BasePage)this.Page).Language.Translate(text);
				button = this.Items.AddButton(translatedText, key);
				props = new ToolbarButtonExtraProperties(button, controlGroup, causesValidation, checksForIsDirty, visible);
				button.Tag = props;
			}

			return props;
		}


		public void AddPreset(ToolbarButtons buttons)
		{
			AddPreset(buttons, this.controlGroup);
		}

		public void AddPreset(ToolbarButtons buttons, string controlGroup)
		{
			if ((buttons & ToolbarButtons.Save) != 0) 
				this.AddButton("@GENERICPAGESAVEBUTTON@", "Save", controlGroup, true, false);
			if ((buttons & ToolbarButtons.Cancel) != 0) 
				this.AddButton("@GENERICPAGECANCELBUTTON@", "Cancel", controlGroup, false, true);
		}


		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);

			// We have to populate the buttons every time anyway. No need for viewstate.
			this.EnableViewState= false;
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);

			this.ClientSideEvents.Click = "Toolbar_Click";

			BasePage page = this.Page as BasePage;
			if (page != null)
			{
				page.ApplyCss(this);
				if (this.ToolbarType == ToolbarType.PageToolbar)
				{
					page.RegisterPageToolbarControl(this);
					page.PopulateToolbarItems(this);	
				}
			}

			if (this.ToolbarType != ToolbarType.TabToolbar)
				this.ButtonClicked += new ButtonClickedEventHandler(WebToolbar_ButtonClicked);
		}


		protected override void Render(HtmlTextWriter writer)
		{
			int buttonWidth = 0;
			string dStyle = this.DefaultStyle.CssClass;
			string hStyle = this.HoverStyle.CssClass;
			string sStyle = this.SelectedStyle.CssClass;

			foreach (object item in this.Items)
			{
				TBarButton button = item as TBarButton;
				if (button != null)
				{
					ToolbarButtonExtraProperties props = button.Tag as ToolbarButtonExtraProperties;
					if (props != null && !props.Visible)
						buttonWidth = 0;
					else
						buttonWidth = 50 + (button.Text.Length * 5);
						
						
					if (this.ToolbarType == ToolbarType.TabToolbar || buttonWidth == 0)
					{
						button.DefaultStyle.Width = Unit.Pixel(buttonWidth);
						button.HoverStyle.Width = Unit.Pixel(buttonWidth);
						button.SelectedStyle.Width = Unit.Pixel(buttonWidth);

						button.DefaultStyle.CssClass = dStyle;
						button.HoverStyle.CssClass = hStyle;
						button.SelectedStyle.CssClass = sStyle;
					}
				}
			}
			
			base.Render (writer);
		}


		protected override void OnButtonClicked(TBarButton button, bool bDepressed)
		{
			base.OnButtonClicked (button, bDepressed);
		}


		private void WebToolbar_ButtonClicked(object sender, ButtonEvent be)
		{
			BasePage page = this.Page as BasePage;
			if (page != null)
			{
				page.OnToolbarButtonClick(this, be.Button);
			}
		}

		/// <summary>
		/// If controlGroup is not specified, the control will inherit it from its parent
		/// </summary>
		[DefaultValue("")]
		public string ControlGroup
		{
			get { return this.controlGroup; }
			set 
			{ 
				this.controlGroup = value; 
			
				BasePage page = this.Page as BasePage;
				if (page != null)
				{		
					foreach (object item in this.Items)
					{
						TBarButton button = item as TBarButton;
						
						if (button != null)
						{
							ToolbarButtonExtraProperties props = button.Tag as ToolbarButtonExtraProperties;
							if (props == null)
							{
								props = new ToolbarButtonExtraProperties(button, this.controlGroup, false, false);
							}
							if (props.ControlGroup != null && props.ControlGroup != "")
								page.SetControlProperties(button.Key, new ControlExtraProperties(button.ID, props.ControlGroup, this.ClientID, props.CausesValidation, props.ChecksForIsDirty));
							else
								page.SetControlProperties(button.Key, new ControlExtraProperties(button.ID, this.controlGroup, this.ClientID, props.CausesValidation, props.ChecksForIsDirty));
							
						}
					}
				}
			}
		}
		
		#region IControlledGrouper Members

		public bool IsGroupSet
		{
			get
			{
				return isGroupSet;
			}
			set
			{
				isGroupSet = value;
			}
		}

		#endregion

	}
}

