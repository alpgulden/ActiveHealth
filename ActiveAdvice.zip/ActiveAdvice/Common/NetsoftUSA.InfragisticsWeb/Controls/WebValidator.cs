using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using NetsoftUSA.WebForms;
using NetsoftUSA.DataLayer;


namespace NetsoftUSA.InfragisticsWeb
{
	/// <summary>
	/// Summary description for WebValidator.
	/// </summary>
	[ToolboxData("<{0}:WebValidator runat=server></{0}:WebValidator>")]
	public class WebValidator : OBValidator
	{
		public WebValidator() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[Browsable(false)]
		public override bool IsTargetControlEnabled
		{
			get
			{
				return base.IsTargetControlEnabled;
				/*
				if (!base.IsTargetControlEnabled) return false;

				Infragistics.WebUI.WebDataInput.WebTextEdit ctrl = ctrlToValidate as Infragistics.WebUI.WebDataInput.WebTextEdit;
				if (ctrl != null)
				{
					return !ctrl.ReadOnly;
				}

				return true;*/
			}
		}

		protected override RequiredFieldValidator GetNewRequiredFieldValidator()
		{
			return new WebRequiredFieldValidator();
		}

	}

	public class WebRequiredFieldValidator : RequiredFieldValidator
	{
		protected override bool EvaluateIsValid()
		{
			if (base.EvaluateIsValid()) return true;

			// ConditionScript is client side, there is currently no way to evaluate that script 
			// and see if we should force the required field validator. So we just ignore it.
			if (this.Attributes["ConditionScript"] != null) return true;
            
            return false;
		}

	}


}
