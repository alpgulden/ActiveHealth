using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using NetsoftUSA.WebForms;
using System.Reflection;

namespace NetsoftUSA.InfragisticsWeb
{
	/// <summary>
	/// Summary description for WebButton.
	/// </summary>
	[DefaultProperty("Text"), 
	ToolboxData("<{0}:WebButton runat=server></{0}:WebButton>")
	]
	public class WebButton : OBButton
	{

		public WebButton() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

	}
}
