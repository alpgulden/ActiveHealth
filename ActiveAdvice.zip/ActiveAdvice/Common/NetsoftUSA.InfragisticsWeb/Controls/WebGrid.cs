#define V20043
using System;
using System.Text;
using System.Xml;
using System.ComponentModel;
using System.Web.UI.Design;

using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Reflection;
using NetsoftUSA.DataLayer;
using Infragistics.WebUI.UltraWebGrid;
using NetsoftUSA.WebForms;
using System.Diagnostics;
using System.Collections;

namespace NetsoftUSA.InfragisticsWeb
{
	#region ColumnBindingData class attached to each column.Tag

	public class ColumnBindingData
	{
		public ControlTypeAttribute controlTypeAtt;
		public PropertyInfo pi;
		public bool isPK;
		public bool translate;			// if this is true, the grid will translate the strings in this column

		public ColumnBindingData(PropertyInfo pi, bool isPK)
		{
			this.pi = pi;
			this.isPK = isPK;
			this.controlTypeAtt = ControlTypeAttribute.GetFromProp(pi, true);
		}
	}

	#endregion

	/// <summary>
	/// Web Grid that can bind and manage NetsoftUSA Data objects.
	/// </summary>
	[ToolboxData("<{0}:WebGrid runat=server></{0}:WebGrid>")]
	public class WebGrid : UltraWebGrid
	{
		#region Events

		public delegate void ColumnsBoundToDataClassHandler(object sender, EventArgs e);
		[Category("NetsoftUSA DataCollection/DataObject Binding")]
		public event ColumnsBoundToDataClassHandler ColumnsBoundToDataClass;
		public event ColumnsBoundToDataClassHandler BeforeColumnsBoundToDataClass;
		public delegate void RowBoundToDataObjectHandler(object sender, RowBindingEventArgs e);
		[Category("NetsoftUSA DataCollection/DataObject Binding")]
		public event RowBoundToDataObjectHandler RowBoundToDataObject;

		public event EventHandler SelectedRowIndexChanged;

		#endregion

		#region private members

		[NonSerialized]
		ArrayList deletedRows = new ArrayList();
		private bool keepCollectionIndices = true;
		private bool keepPKs = true;
		private int selectedColumnIndex = -1;

		// standard buttons options
		private bool editButton = false;	// standard buttons
		private bool editButtonOnRight = false;	// 

		private bool showSelectedRowIcon = false;

		private bool clientSideSearcher = false;

		int selRowIndex = -1;
        
		#endregion

		public static string EditButtonText = "Edit";
		public static string CssClassForSelectedRows = "";
		public static string SelectedRowIconHTML = ">>>";		// you can set something like "<img src=pics/selectedRow.gif>"

		public WebGrid() : base()
		{
			//Debug.WriteLine("WebGrid");
			//
			// TODO: Add constructor logic here
			//
		}

		private string Translate(string msg)
		{
			if (msg == null)
				return "";
			return ((BasePage)this.Page).Language.Translate(msg);
		}

		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);

			if (this.DisplayLayout.SelectedRowStyleDefault.CssClass == "")
			{
				this.DisplayLayout.SelectedRowStyleDefault.CssClass = CssClassForSelectedRows;
				//this.DisplayLayout.SelectedRowStyleDefault.BackColor = System.Drawing.Color.LemonChiffon;
			}
			this.DisplayLayout.CellClickActionDefault = CellClickAction.RowSelect;
			this.DisplayLayout.SelectTypeRowDefault = SelectType.Single;
		}


		protected override void OnPreRender(EventArgs e)
		{
			//if (this.showSelectedRowIcon)
			//	this.DisplayLayout.allow
			base.OnPreRender (e);
		}

		protected override void Render(HtmlTextWriter writer)
		{
			if (this.clientSideSearcher)
			{
				string findText = Translate("@FIND@");
				string findNextText = Translate("@FINDNEXT@");

				Table table = new Table();
				table.Width = Unit.Percentage(100);
				TableRow tableRow = new TableRow();
				table.Rows.Add(tableRow);
				TableCell tableCell = new TableCell();
				tableRow.Cells.Add(tableCell);
				tableCell.HorizontalAlign = HorizontalAlign.Right;
				tableCell.VerticalAlign = VerticalAlign.Bottom;

				TextBox textBox = new TextBox();
				tableCell.Controls.Add(textBox);
				textBox.CssClass = WebTextEdit.CssClassEditable;
				textBox.ID = this.ClientID + "_FindTextBox";
								
				Button button = new Button();
				tableCell.Controls.Add(button);
				button.Width = Unit.Pixel(50);
				button.ID = this.ClientID + "_FindButton";
				button.CausesValidation = false;
				button.CssClass = WebButton.CssAll;
				button.Text = findText;
				
				textBox.Attributes["onclick"] = String.Format("javascript:ResetFind('{0}', '{1}', '{2}');", button.ClientID, findText, findNextText);
				button.Attributes["onclick"] = String.Format("javascript:FindValue('{0}', {1}, '{2}', '{3}', '{4}'); return false;", this.ClientID, "this", textBox.ClientID, findText, findNextText);

				table.RenderControl(writer);
			}

			base.Render (writer);
		}



		public override bool OnSelectedCellsChange(SelectedCellsCollection selectedCells)
		{
			selectedColumnIndex = -1;

			if (selectedCells != null)
				if (selectedCells.Count > 0)
				{
					selectedColumnIndex = selectedCells[0].Column.Index;
				}
			return base.OnSelectedCellsChange (selectedCells);
		}

		public override bool OnSelectedRowsChange(SelectedRowsCollection selectedRows)
		{
			selectedColumnIndex = -1;

			if (selectedRows != null)
				if (selectedRows.Count > 0)
				{
				}
			return base.OnSelectedRowsChange (selectedRows);
		}



		/// <summary>
		/// Called by 
		/// </summary>
		/// <param name="type"></param>
		private void BindColumnsToDataClassForSave(Type type)
		{
			BaseDataClass data = (BaseDataClass)Activator.CreateInstance(type);
			Hashtable pkfields = null;
			if (data.PKFields == null)
				pkfields = new Hashtable();
			else
				pkfields = NSGlobal.CreateHashtable(data.PKFields);

			// 

			for (int i = 0; i < this.Columns.Count; i++)
			{
				UltraGridColumn col = this.Columns[i];
				// if the column is bound, use its key to bind to a public property of the given type
				if (col.IsBound)
				{
					string member = col.Key;
					PropertyInfo pi = type.GetProperty(member);
					if (pi == null)
						throw new Exception(
							String.Format("{0} no public property for the given column key {1}", type.ToString(), member));

					// there's a property for the given member
					ColumnBindingData colBinding = new ColumnBindingData(pi, pkfields.ContainsKey(member));
					col.Tag = colBinding;		// attach to columns

					
				}
			}
		}

		/// <summary>
		/// Fill column properties from the data class
		/// </summary>
		public void BindColumnsToDataClass(Type type, BaseDataClass data)
		{
			if (data == null)
				data = (BaseDataClass)Activator.CreateInstance(type);
			Hashtable pkfields = null;
			if (data.PKFields == null)
				pkfields = new Hashtable();
			else
				pkfields = NSGlobal.CreateHashtable(data.PKFields);

			OnBeforeColumnsBoundToDataClass();

			for (int i = 0; i < this.Columns.Count; i++)
			{
				UltraGridColumn col = this.Columns[i];

				// if the column is bound, use its key to bind to a public property of the given type
				if (col.IsBound)
				{
					string member = col.Key;
					PropertyInfo pi = type.GetProperty(member);
					if (pi == null)
						throw new Exception(
							String.Format("{0} no public property for the given column key {1}", type.ToString(), member));

					// there's a property for the given member
					ColumnBindingData colBinding = new ColumnBindingData(pi, pkfields.ContainsKey(member));
					col.Tag = colBinding;		// attach to columns
					col.HeaderText = Translate(FieldDescriptionAttribute.GetDescription(pi, true));
					col.DataType = pi.PropertyType.ToString(); 

					if (col.Format == null || col.Format == "")
					{
						string dateFormat = colBinding.controlTypeAtt.GetDateFormattingString();
						if (dateFormat != null)
							col.Format = dateFormat;
					}

					// If not a custom column type, detect column type,
					// populate value lists, etc.
					if (col.Type != ColumnType.Custom)
					{
						// check lookup collection.  if available use it.
						string colValMember = null;
						string colDescMember = null;
						BaseDataCollectionClass lookupCol = FieldValuesMemberAttribute.GetLookupCollection(data, pi, ref colValMember, ref colDescMember) as BaseDataCollectionClass;
						if (lookupCol != null)
						{
							col.Type = ColumnType.DropDownList;
							col.ValueList.ValueListItems.Clear();
							for (int j = 0; j < lookupCol.Count; j++)
							{
								BaseDataClass elem = lookupCol.GetAt(j);
								col.ValueList.ValueListItems.Add(elem.GetDB(colValMember), elem.GetStr(colDescMember));
							}
						}
						else
						{
							// Try field values
							Array vals = ControlTypeAttribute.GetFieldValues(data, pi);
							if (vals != null)
							{
								string[] svals = FieldValuesMemberAttribute.GetFormattedFieldValues(data, pi, vals);
								col.Type = ColumnType.DropDownList;
								col.ValueList.ValueListItems.Clear();
								for (int j = 0; j < vals.GetLength(0); j++)
								{
									string sdesc = NetsoftUSA.DataLayer.Formatting.ParseDescriptionPart(svals[j]);
									sdesc = ((BasePage)this.Page).Language.Translate(sdesc);
									object val = null;
									if (vals.Rank == 1)
										val = vals.GetValue(j);
									else if (vals.Rank == 2)
										val = vals.GetValue(j, 0);

									col.ValueList.ValueListItems.Add(val, sdesc);
								}
							}

						}
					}
					else // col.Type == ColumnType.Custom
					{
						if (col.EditorControlID != null && col.EditorControlID != "")
						{
							Control ctl = this.Parent.FindControl(col.EditorControlID);
							IObjectBoundControl iobc = ctl as IObjectBoundControl;
							if (iobc != null)
							{
								// bind the Netsoft USA control to an instance of the data class
								iobc.SetSourceObject(data);
								iobc.UpdateData(false);
							}

							// recreate validators
							//col.Validators.Clear();
							//col.Validators.Add(new ValidatorItem("vld" + ctl.ID));
						}
					}

				}
			}

			// add standard buttons

			if (this.editButton)
				AddEditButton("Edit", WebGrid.EditButtonText, 0);
			if (this.editButtonOnRight)
				AddEditButton("Edit", WebGrid.EditButtonText);

			OnColumnsBoundToDataClass();

			if (this.showSelectedRowIcon)
				AddImageColumn("SelectedRowIcon", null, null, 0); //.Width = 30;
		}

		public UltraGridColumn AddEditButton(string key, string text)
		{
			return AddEditButton(key, text, -1);
		}

		public UltraGridColumn AddEditButton(string key, string text, int index)
		{
			UltraGridColumn col = AddButtonColumn(key, text, index);
			col.Type = ColumnType.Button;
			col.CellStyle.CssClass = "gridButtonDefault";
			col.CellButtonStyle.CssClass = "gridButtonDefault";
			col.CellButtonDisplay = CellButtonDisplay.OnMouseEnter;
			col.Width = 60;
			return col;
		}

		public UltraGridColumn AddButtonColumn(string key, string text)
		{
			return AddButtonColumn(key, text, -1);
		}

		public UltraGridColumn AddButtonColumn(string key, string text, int index)
		{
			text = Translate(text);
			UltraGridColumn col = null;
			if (index == -1)
			{
				col = this.Columns.FromKey(key);
				if (col == null)
				{
					int i = this.Columns.Add(key, text);
					col = Columns[i];
				}
			}
			else
			{
				col = this.Columns.FromKey(key);
				if (col == null)
				{
					col = new UltraGridColumn(key, text, ColumnType.Button, null);
					this.Columns.Insert(index, col);
				}
			}
			
			if (col != null)
			{
				//grid.Columns[i].CellButtonDisplay = CellButtonDisplay.Always;
				
				col.Header.Caption = text;
				col.NullText = text;
				col.Type = ColumnType.Button;
				col.CellStyle.CssClass = "gridButtonDefault";
				col.CellButtonStyle.CssClass = "gridButtonDefault";
				col.CellButtonDisplay = CellButtonDisplay.OnMouseEnter;
				//col.Width = 100;
			}
			return col;
		}


		public UltraGridColumn AddColumn(string key, string text)
		{
			return AddColumn(key, text, -1, false, false);
		}

		public UltraGridColumn AddColumn(string key, string text, bool isBound)
		{
			return AddColumn(key, text, -1, false, isBound);
		}

		public UltraGridColumn AddColumn(string key, string text, int index)
		{
			return AddColumn(key, text, index, false, false);
		}

		public UltraGridColumn AddColumnWithButtonLook(string key, string text, int index)
		{
			return AddColumn(key, text, index, true, false);
		}

		public UltraGridColumn AddColumn(string key, string text, int index, bool buttonLook, bool isBound)
		{
			text = Translate(text);
			UltraGridColumn col = null;
			if (index == -1)
			{
				int i = this.Columns.Add(key, text);
				col = Columns[i];
			}
			else
			{
				col = this.Columns.FromKey(key);
				if (col == null)
				{
					col = new UltraGridColumn(key, text, ColumnType.NotSet, null);
					this.Columns.Insert(index, col);
				}
			}
			
			if (col != null)
			{
				col.IsBound = isBound;
				//grid.Columns[i].CellButtonDisplay = CellButtonDisplay.Always;
				if (buttonLook)
				{
					col.Header.Caption = text;
					col.NullText = text;
					col.Type = ColumnType.NotSet;
					col.CellStyle.CssClass = "gridButtonDefault";
					col.CellButtonStyle.CssClass = "gridButtonDefault";
					col.CellButtonDisplay = CellButtonDisplay.OnMouseEnter;
				}
				//col.Width = 100;
			}
			return col;
		}

		public UltraGridColumn AddImageColumn(string key, string header, string imgSrc, int index)
		{
			UltraGridColumn col = null;
			if (index == -1)
			{
				int i = this.Columns.Add(key, header);
				col = Columns[i];
			}
			else
			{
				col = this.Columns.FromKey(key);
				if (col == null)
				{
					col = new UltraGridColumn(key, header, ColumnType.NotSet, null);
					this.Columns.Insert(index, col);
				}
			}
			
			if (col != null)
			{
				//grid.Columns[i].CellButtonDisplay = CellButtonDisplay.Always;
				col.Header.Caption = header;
				if (imgSrc == null)
					col.NullText = null;
				else
					col.NullText = "<img src='" + imgSrc + "'>";
				col.Type = ColumnType.NotSet;
				//col.CellStyle.CssClass = "gridButtonDefault";
				//col.CellButtonStyle.CssClass = "gridButtonDefault";
				//col.CellButtonDisplay = CellButtonDisplay.OnMouseEnter;
				col.Width = 20;
			}
			return col;
		}

		private void FillRowFromObject(UltraGridRow row, BaseDataClass data)
		{
//			if (keepCollectionIndices)
//				row.DataKey = row.Index;
//			else
//				row.DataKey = null;
			//else
			//	row.DataKey = data.PK;
			if (keepPKs)
				row.Tag = data.PK;
			row.Hidden = data.IsMarkedForDeletion;
			for (int i = 0; i < this.Columns.Count; i++)
			{
				UltraGridColumn col = this.Columns[i];
				if (col.IsBound)
				{
					ColumnBindingData colBinding = col.Tag as ColumnBindingData;
					if (colBinding != null)
					{
						UltraGridCell cell = row.Cells[i];
						// cell.Value = ControlTypeAttribute.GetMemberValueForDB(data, colBinding.pi);
						object val = ControlTypeAttribute.GetMemberValueUseNull(data, colBinding.pi);
						if (colBinding.translate)
							if (val is string)
								val = ((BasePage)Page).Language.Translate((string)val);
						cell.Value = val;
					}
				}
			}
		}

		/// <summary>
		/// Updates the status and data of a data object from the given row's status and data.
		/// </summary>
		/// <param name="data"></param>
		/// <param name="row"></param>
		private void FillObjectFromRow(BaseDataClass data, UltraGridRow row)
		{
			DataChanged chg = row.DataChanged;
			if (chg == DataChanged.Deleted)		// not normally called
			{
				data.MarkDel();		// mark for deletion
				row.DataChanged = DataChanged.Unchanged;		// reset datachanged flag
				return;
			}

			if (chg == DataChanged.Added || chg == DataChanged.Modified)
			{
				if (chg == DataChanged.Modified)
					data.MarkDirty();

				for (int i = 0; i < this.Columns.Count; i++)
				{
					UltraGridCell cell = row.Cells[i];
					if (cell.DataChanged)	// update only when the data is changed
					{
						UltraGridColumn col = this.Columns[i];
						if (col.IsBound)
						{
							ColumnBindingData colBinding = col.Tag as ColumnBindingData;
							if (colBinding != null)
							{
								if (!colBinding.isPK || data.InsertPK)
								{
									// update member from the cell value
									ControlTypeAttribute.SetMemberValueFromDB(data, colBinding.pi, cell.Value);
								}
							}

							cell.DataChanged = false;	// if the column is bound, reset its changed status
						}
					}
				}

				row.DataChanged = DataChanged.Unchanged;	// reset datachanged flag
			}
		}

		public void UpdateFromCollection(BaseDataCollectionClass col)
		{
			UpdateFromCollection(col, false);
		}

		public void UpdateFromCollection(BaseDataCollectionClass col, bool append)
		{
			int oldCount = this.Rows.Count;
			selRowIndex = this.SelectedRowIndex;
			if (!append)
				ClearRows();
			if (col == null)
				return;
			Type type = col.ElementType;
			if (type == null)
				throw new Exception("No element type declared on collection class " + col.GetType());

			// Bind columns to data clas
			BindColumnsToDataClass(type, col.ElementInstance);

			ICollectionElementFilter ielemFilter = col as ICollectionElementFilter;

			// Add rows from the given collection
			for (int i = 0; i < col.Count; i++)
			{
				// decide if this element is filetered or not
				if (ielemFilter == null || ielemFilter.FilterElement(i))
				{
					BaseDataClass data = col.GetAt(i);
					UltraGridRow row = new UltraGridRow();
					row.DataKey = i;	// keep the collection index
					this.Rows.Add(row);
					//FillRowFromObject(row, data);
					//OnRowBoundToDataObject(row, data);
				}
			}

			//this.DisplayLayout.Pager.PageCount = 
			if (this.keepCollectionIndices && this.DisplayLayout.Pager.AllowPaging)
			{
				// fill only the current page
				this.DisplayLayout.Pager.CurrentPageIndex = 0;
				UpdateFromCollection(this.DisplayLayout.Pager.CurrentPageIndex, col);
			}
			else
			{
				// fill all rows
				if (append)
					UpdateFromCollectionFromIndex(oldCount, col);		// start from the old count.  if appending, this will cause the filling of newly added rows
				else
					UpdateFromCollectionFromIndex(0, col);		// start from the old count.  if appending, this will cause the filling of newly added rows
			}

			if (!append)		// set the selected index only if not appending
			{
				if (selRowIndex < 0 && this.Rows.Count > 0)
					this.SelectedRowIndex = 0;		// if there was no row selected earlier, and there are some rows now, use the first one.
				else
					this.SelectedRowIndex = selRowIndex;
			}
		}

		public void UpdateFromCollectionFromIndex(int startIndex, BaseDataCollectionClass col)
		{
			if (col == null)
				return;
			Type type = col.ElementType;
			if (type == null)
				throw new Exception("No element type declared on collection class " + col.GetType());

			// Bind columns to data clas
			BindColumnsToDataClass(type, col.ElementInstance);

			int endIndex = this.Rows.Count;	// col.Count;
			// Fill rows from the given collection
			for (int i = startIndex; i < endIndex; i++)
			{
				int colIndex = this.GetColIndexFromRowIndex(i);
				BaseDataClass data = col.GetAt(colIndex);
				UltraGridRow row = this.Rows[i]; //new UltraGridRow();
				//this.Rows.Add(row);
				FillRowFromObject(row, data);
				OnRowBoundToDataObject(row, data);
			}

			if (this.showSelectedRowIcon)
			{
				// make the first row selected
				if (this.Rows.Count > 0)
					this.DisplayLayout.ActiveRow = this.Rows[0];
			}
		}

		public void UpdateFromCollection(int pageIndex, BaseDataCollectionClass col)
		{
			if (col == null)
				return;
			Type type = col.ElementType;
			if (type == null)
				throw new Exception("No element type declared on collection class " + col.GetType());

			// Bind columns to data clas
			BindColumnsToDataClass(type, col.ElementInstance);

			int startIndex = 0;
			int endIndex = this.Rows.Count;	// col.Count;
			if (pageIndex >= 0) // this.DisplayLayout.Pager.AllowPaging)
			{
				startIndex = pageIndex * this.DisplayLayout.Pager.PageSize;
				endIndex = startIndex + this.DisplayLayout.Pager.PageSize;
			}
			// Fill rows from the given collection
			for (int i = startIndex; i < endIndex; i++)
			{
				int colIndex = this.GetColIndexFromRowIndex(i);
				BaseDataClass data = col.GetAt(colIndex);
				UltraGridRow row = this.Rows[i]; //new UltraGridRow();
				//this.Rows.Add(row);
				FillRowFromObject(row, data);
				OnRowBoundToDataObject(row, data);
			}

			if (this.showSelectedRowIcon)
			{
				// make the first row selected
				if (this.Rows.Count > 0)
					this.DisplayLayout.ActiveRow = this.Rows[0];
			}
		}

		public void ClearRows()
		{
			this.Rows.Clear();
			this.deletedRows.Clear();
		}

		/// <summary>
		/// Create the necessary bound grid columns for the given member names
		/// </summary>
		/// <param name="memberNames"></param>
		public void CreateColumnsForMembers(params string[] memberNames)
		{
			// create columns for the given members at runtime.
			ClearRows();
			this.Columns.Clear();

			for (int i = 0; i < memberNames.Length; i++)
			{
				string member = memberNames[i];
				int icol = this.Columns.Add(member);
				UltraGridColumn column = this.Columns[icol];
				column.IsBound = true;		// must be bound
			}
		}

		/// <summary>
		/// Create the necessary bound grid columns for the given member names and
		/// bind the given collection.
		/// </summary>
		/// <param name="col"></param>
		/// <param name="memberNames"></param>
		/*public void UpdateFromCollection(BaseDataCollectionClass col, params string[] memberNames)
		{
			if (memberNames != null)
				CreateColumnsForMembers(memberNames);

			UpdateFromCollection(col);
		}*/

		public void UpdateToCollection(BaseDataCollectionClass col)
		{
			if (col == null)
				return;
			Type type = col.ElementType;
			if (type == null)
				throw new Exception("No element type declared on collection class " + col.GetType());

			if (!keepCollectionIndices)
				throw new Exception("To update to collection KeepCollectionIndices must be set to True");

			// Bind columns to data clas
			BindColumnsToDataClassForSave(type);

			// Fill rows from the given collection
			for (int i = 0; i < this.Rows.Count; i++)
			{
				UltraGridRow row = this.Rows[i];
				BaseDataClass data = null;
				if (row.DataChanged != DataChanged.Unchanged)
				{
					if (row.DataChanged == DataChanged.Added)
					{
						data =  col.NewRecord(true);
						row.DataKey = col.AddRecord(data);		// set datakey to collection index
					}
					else
					{
						try
						{
							int colIndex = (int)row.DataKey;
							data = col.GetAt(colIndex);
						}
						catch(IndexOutOfRangeException ex)
						{
							throw new IndexOutOfRangeException("The target collection's ({0}) collection indices do not match those of the WebGrid.  You must update back to the same collection.", ex);
						}
					}
					if (data != null)
					{
						FillObjectFromRow(data, row);
					}
				}
			}

			// handle deleted rows
			for (int i = deletedRows.Count - 1; i >= 0; i--)
			{
				int delIndex = (int)deletedRows[i];		// collection index
				
				try
				{
					BaseDataClass data = col.GetAt(delIndex);
					data.MarkDel();
					deletedRows.RemoveAt(i);
				}
				catch(IndexOutOfRangeException ex)
				{
					throw new IndexOutOfRangeException("The target collection's ({0}) collection indices do not match those of the WebGrid.  You must update back to the same collection.", ex);
				}
			}
		}

		protected override object SaveViewState()
		{
			for (int i = 0; i < Columns.Count; i++)
			{
				this.Columns[i].Tag = null;		// do not serialize ColumnBindingData
			}
			ViewState["DeletedRows"] = this.deletedRows;
			ViewState["SelCol"] = selectedColumnIndex;
			return base.SaveViewState ();
		}

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			this.deletedRows = (ArrayList)ViewState["DeletedRows"];
			selectedColumnIndex = (int)ViewState["SelCol"];
		}

		protected virtual void OnBeforeColumnsBoundToDataClass()
		{
			if (BeforeColumnsBoundToDataClass != null)
				BeforeColumnsBoundToDataClass(this, new EventArgs());
		}

		protected virtual void OnColumnsBoundToDataClass()
		{
			if (ColumnsBoundToDataClass != null)
				ColumnsBoundToDataClass(this, new EventArgs());
		}

		protected virtual void OnRowBoundToDataObject(UltraGridRow row, BaseDataClass data)
		{
			if (RowBoundToDataObject != null)
				RowBoundToDataObject(this, new RowBindingEventArgs(row, data) );
		}

		public override bool OnDeleteRowBatch(UltraGridRow row, int index)
		{
			bool result = base.OnDeleteRowBatch (row, index);
			if (!result)
				deletedRows.Add(row.DataKey);		// save the colection indices of deleted rows
			return result;
		}

		/* #region IPostBackDataHandler Members

		public void RaisePostDataChangedEvent()
		{
			base.RaisePostDataChangedEvent();
		}

		public bool LoadPostData(string postDataKey, System.Collections.Specialized.NameValueCollection values)
		{
			//try
			//{
				return base.LoadPostData(postDataKey, values);
			//}
			//catch(Exception ex)
			//{
			//	Debug.WriteLine("WebGrid LoadPostData error:  \r\n" + ex.Message);
			//	throw;
			//}
			return false;
		}

		#endregion*/

		public void SetColumnTranslate(string columnKey, bool value)
		{
			ColumnBindingData colBinding = this.Columns.FromKey(columnKey).Tag as ColumnBindingData;
			colBinding.translate = value;
		}

		public bool GetColumnTranslate(string columnKey)
		{
			ColumnBindingData colBinding = this.Columns.FromKey(columnKey).Tag as ColumnBindingData;
			return colBinding.translate;
		}

		[DefaultValue(false)]
		[Category("Standard Buttons")]
		public bool EditButton
		{
			get { return this.editButton; }
			set { this.editButton = value; }
		}

		[DefaultValue(false)]
		[Category("Standard Buttons")]
		public bool EditButtonOnRight
		{
			get { return this.editButtonOnRight; }
			set { this.editButtonOnRight = value; }
		}

		[DefaultValue(false)]
		[Category("Standard Buttons")]
		public bool ShowSelectedRowIcon
		{
			get { return this.showSelectedRowIcon; }
			set { this.showSelectedRowIcon = value; }
		}

		[DefaultValue(true)]
		public bool KeepCollectionIndices
		{
			get { return this.keepCollectionIndices; }
			set { this.keepCollectionIndices = value; }
		}

		[DefaultValue(true)]
		public bool KeepPKs
		{
			get { return this.keepPKs; }
			set { this.keepPKs = value; }
		}

		[DefaultValue((int)-1)]
		public int SelectedColumnIndex
		{
			get { return this.selectedColumnIndex; }
			set { this.selectedColumnIndex = value; }
		}

		[DefaultValue((int)-1)]
		public int SelectedRowIndex
		{
			get 
			{ 
				// tried it, doesn't work!
				if (this.DisplayLayout.ActiveRow != null)
					return this.DisplayLayout.ActiveRow.Index;
				return -1;
			}
			set 
			{
				int oldRow = this.selRowIndex;
				if (this.Rows.Count == 0)
				{
					this.DisplayLayout.ActiveRow = null;
				}
				else
				{
					int selectedRowIndex = value;
					if (selectedRowIndex < 0)
						this.DisplayLayout.ActiveRow = null;
					else
					{
						if (selectedRowIndex >= this.Rows.Count)
							selectedRowIndex = this.Rows.Count - 1;		// if beyond last row, set to last row
						this.DisplayLayout.ActiveRow = this.Rows[selectedRowIndex];
					}

					if (showSelectedRowIcon)
					{
						// mark the row that's selected
						for (int i = 0; i < this.Rows.Count; i++)
						{
							if (selectedRowIndex == i)
								this.Rows[i].Cells.FromKey("SelectedRowIcon").Text = WebGrid.SelectedRowIconHTML;
							else
								this.Rows[i].Cells.FromKey("SelectedRowIcon").Text = null;
						}
					}

					selRowIndex = this.SelectedRowIndex;
				}

				if (oldRow != this.SelectedRowIndex)		// changed
					OnSelectedRowIndexChanged();
			}
		}

		protected virtual void OnSelectedRowIndexChanged()
		{
			if (SelectedRowIndexChanged != null)
				SelectedRowIndexChanged(this, new EventArgs());
		}

		[DefaultValue(false)]
		public bool ClientSideSearcher
		{
			get
			{
				return this.clientSideSearcher;
			}
			set
			{
				this.clientSideSearcher = value;
			}
		}

		/// <summary>
		/// Returns the corresponding collection for the selected row
		/// </summary>
		public int SelectedColectionIndex
		{
			get
			{
				return GetColIndexFromRowIndex(SelectedRowIndex);
			}
		}

		/// <summary>
		/// Returns the corresponding PK for the selected row
		/// </summary>
		public object[] SelectedRowPK
		{
			get
			{
				return GetPKFromRowIndex(SelectedRowIndex);
			}
		}

		public int SelectedRowPKInt
		{
			get
			{
				return GetPKIntFromRowIndex(SelectedRowIndex);
			}
		}

		public object GetDataKeyFromClickEvent(ClickEventArgs e)
		{
			if (e.Row != null)
				return e.Row.DataKey;
			if (e.Cell != null)
				return e.Cell.Row.DataKey;
			return null;
		}

		public int GetColIndexFromClickEvent(ClickEventArgs e)
		{
			object o = GetDataKeyFromClickEvent(e);
			if (o == null)
				return -1;
			return (int)o;
		}

		public object[] GetPKFromClickEvent(ClickEventArgs e)
		{
			if (e.Row != null)
				return (object[])e.Row.Tag;
			if (e.Cell != null)
				if (e.Cell.Row != null)
					return (object[])e.Cell.Row.Tag;
			return null;
		}

		public int GetPKIntFromClickEvent(ClickEventArgs e)
		{
			object[] pk = GetPKFromClickEvent(e);
			if (pk == null)
				return -1;
			return (int)pk[0];
		}

		public object GetDataKeyFromCellEvent(CellEventArgs e)
		{
			if (e.Cell != null)
				return e.Cell.Row.DataKey;
			return null;
		}

		public int GetColIndexFromCellEvent(CellEventArgs e)
		{
			object o = GetDataKeyFromCellEvent(e);
			if (o == null)
				return -1;
			return (int)o;
		}

		public object[] GetPKFromCellEvent(CellEventArgs e)
		{
			if (e.Cell != null)
				if (e.Cell.Row != null)
					return (object[])e.Cell.Row.Tag;
			object o = GetDataKeyFromCellEvent(e);
			if (o == null)
				return null;
			return (object[])o;
		}

		public int GetPKIntFromCellEvent(CellEventArgs e)
		{
			object[] pk = GetPKFromCellEvent(e);
			if (pk == null)
				return -1;
			return (int)pk[0];
		}

		public object[] GetPKFromRowIndex(int index)
		{
			if (index < 0)
				return null;
			return (object[])this.Rows[index].Tag;
		}

		public int GetPKIntFromRowIndex(int index)
		{
			if (index < 0)
				return 0;
			object[] pk = GetPKFromRowIndex(index);
			return (int)pk[0];
		}

		public int GetColIndexFromRowIndex(int index)
		{
			if (index < 0)
				return -1;
			object o = this.Rows[index].DataKey;
			if (o == null)
				return -1;
			return (int)o;
		}

		/*public string GetColumnKeyFromCellEvent(CellEventArgs e)
		{
			if (e.Cell == null)
				return null;

			if (e.Cell.Row == null)
				return null;

			int i = e.Cell.Row.Index;

			return this.Rows[i].Cells[e.Cell.Column.Index].Key;

		}*/

		public override void OnClickCellButton(UltraGridCell cell)
		{
			// Select button is special, it sets the selected row index
			if (cell.Key == "Select")
				this.SelectedRowIndex = cell.Row.Index;

			base.OnClickCellButton (cell);
		}

	}

	#region RowBindingEventArgs

	public class RowBindingEventArgs : EventArgs
	{
		public UltraGridRow row;
		public BaseDataClass data;
		public RowBindingEventArgs(UltraGridRow row, BaseDataClass data)
		{
			this.row = row;
			this.data = data;
		}
	}

	#endregion

}