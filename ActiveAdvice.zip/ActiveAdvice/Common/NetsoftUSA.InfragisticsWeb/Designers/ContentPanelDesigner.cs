using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.Design;
using System.Web.UI.Design.WebControls;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using System.IO;


namespace NetsoftUSA.InfragisticsWeb
{
	/// <summary>
	/// Summary description for ContentPanelDesigner.
	/// </summary>
	public class ContentPanelDesigner : System.Web.UI.Design.WebControls.PanelDesigner
	{
		public ContentPanelDesigner()  : base()
		{
		}


		/// <summary>
		/// Called by the design time environment to get a representative html string
		/// </summary>
		/// <returns></returns>
		public override string GetDesignTimeHtml()
		{
			return "zirt pirt <BR>" + base.GetDesignTimeHtml();
		}

	}

}
