using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Collections;
using NetsoftUSA.DataLayer;
using NetsoftUSA.InfragisticsWeb;
using Infragistics.WebUI.UltraWebTab;
using Infragistics.WebUI.UltraWebListbar;
using Infragistics.WebUI.UltraWebToolbar;


namespace NetsoftUSA.InfragisticsWeb
{
	#region Security 
	public enum WindowType
	{
		Main = 1,
		Popup = 2
	}

	[Flags()]
	public enum PageTimeOutOptions
	{
		NoTimeOut = 1,
		TrackTimeOut = 2,
		RedirectAfterTimeOut = 4,
		CloseChildWindows = 8,
		Default = TrackTimeOut | RedirectAfterTimeOut | CloseChildWindows
	}



	public class SetTabToolbarsEventArgs : EventArgs
	{
		//		public EnumPageMessageType messageType = EnumPageMessageType.Info;
		//		public string message;
		//		public SetTabToolbarsEventArgs(string message, EnumPageMessageType messageType)
		//		{
		//			this.message = message;
		//			this.messageType = messageType;
		//		}
	}
	#endregion

	/// <summary>
	/// The base web form functionality to automatically
	/// populate and update data on the web form.  Use this 
	/// base class to derive a new WebForms page that also uses Netsoft USA Infragistics
	/// control wrappers.
	/// </summary>
	[Designer("Microsoft.VSDesigner.WebForms.WebFormDesigner,Microsoft.VSDesigner")]
	public class BasePage : NetsoftUSA.WebForms.BasePage
	{
		protected const string WindowTypeParameterName = "w";
		protected const string TimeOutCheckerFunctionName = "CheckTimeout();";

		protected WindowType windowType = WindowType.Main;
		protected PageTimeOutOptions pageTimeOutOptions = PageTimeOutOptions.Default;

		
		protected ArrayList PageTabControls = new ArrayList(1);
		protected ArrayList PageToolbarControls = new ArrayList(1);
		protected ArrayList PageSubMenuControls = new ArrayList(1);

		#region Constructor

		public BasePage() : base()
		{
			// TODO: Re-Factor this block into a generic method in InputValidator class.
			try
			{
				HttpRequest request = HttpContext.Current.Request;
				string windowType = request.QueryString[WindowTypeParameterName];
				if (windowType != null)
				{
					int wType = Convert.ToInt32(windowType);
					if (Enum.IsDefined(typeof(WindowType), wType))
						this.WindowType = (WindowType)wType;
				}
			}
			catch
			{
				// Just ignore the querystring parameter
			}

			
			
			/*if (PageTimeOutOptions == PageTimeOutOptions.TrackTimeOut && PageBody != null)
			{
				PageBody.Attributes.Add("onload", TimeOutCheckerFunctionName);

				//this.Page.

			}*/

			

		}

		#endregion

		private void registerClientScripts()
		{
			registerPickItemScript();

			if (!this.IsClientScriptBlockRegistered("NetsoftUSA.InfragisticsWeb"))
				RegisterClientScriptBlock("NetsoftUSA.InfragisticsWeb", "<SCRIPT src='NSInfragistics.js'></SCRIPT>\n");
		}

		protected override void Render(HtmlTextWriter writer)
		{
			registerClientScripts();
			base.Render (writer);
		}


		protected WindowType WindowType
		{
			get 
			{
				return windowType;
			}
			set 
			{
				if (Enum.IsDefined(typeof(WindowType), value))
				{
					windowType = value;
					if (windowType == WindowType.Popup)
						pageTimeOutOptions = PageTimeOutOptions.NoTimeOut;
				}
			}
		}

		protected PageTimeOutOptions PageTimeOutOptions
		{
			get 
			{
				return pageTimeOutOptions;
			}
			set
			{
				if (Enum.IsDefined(typeof(PageTimeOutOptions), value))
				{
					pageTimeOutOptions = value;
				}
			}
		}

		
		public virtual void PopulateTabItems(WebTab webTab)
		{
			
		}

		public virtual void OnTabChange(WebTab webTab, Infragistics.WebUI.UltraWebTab.WebTabEvent e)
		{

		}


		public virtual void PopulateToolbarItems(WebToolbar toolbar, Infragistics.WebUI.UltraWebTab.Tab tab)
		{
			

		}

		public virtual void PopulateToolbarItems(WebToolbar toolbar)
		{
			

		}

		public virtual void PopulateSubNavigation(WebListBar listbar)
		{

		}

		public virtual void SelectSideMenuItem(WebListBar listBar)
		{

		}

		public virtual string SelectMainMenuItem()
		{
			return null;
		}
		public virtual void OnToolbarButtonClick(WebToolbar toolbar, Infragistics.WebUI.UltraWebToolbar.TBarButton button)
		{
			System.Reflection.MethodInfo mi = this.GetType().GetMethod("OnToolbarButtonClick_" + button.Key);
			if (mi != null)
			{
				mi.Invoke(this, new object[] {toolbar, button});
			}
		}

		public virtual void OnTabClick(WebTab tabControl, Tab newTab, Tab previousTab)
		{

			System.Reflection.MethodInfo mi = this.GetType().GetMethod("OnTabClick_" + newTab.Key);
			if (mi != null)
			{
				mi.Invoke(this, new object[] {tabControl, newTab, previousTab});
			}
			
		}

		public virtual void OnSubNavigationItemClick(WebListBar listbar, Infragistics.WebUI.UltraWebListbar.Item item)
		{
			System.Reflection.MethodInfo mi = this.GetType().GetMethod("OnSubNavigationItemClick_" + item.Key);
			if (mi != null)
			{
				mi.Invoke(this, new object[] {listbar, item});
			}
		}

		public virtual void OnMainNavigationItemClick(string key)
		{
			System.Reflection.MethodInfo mi = this.GetType().GetMethod("OnMainNavigationItemClick_" + key);
			if (mi != null)
			{
				mi.Invoke(this, new object[] {});
			}
		}


		public virtual void ApplyCss(WebToolbar toolbar)
		{

		}

		public virtual void ApplyCss(WebTab webTab)
		{

		}

		public virtual void ApplyCss(WebListBar listBar)
		{
		}

		public void RegisterPageTabControl(WebTab webTab)
		{
			PageTabControls.Add(webTab);
		}

		public void RegisterPageToolbarControl(WebToolbar webToolbar)
		{
			PageToolbarControls.Add(webToolbar);
		}

		public void RegisterPageSubMenuControl(WebListBar webListbar)
		{
			PageSubMenuControls.Add(webListbar);
		}


		#region PageItem Property Setters
		protected virtual void SetPageTabItemVisible(string key, bool visible)
		{
			foreach (WebTab pageTabControl in PageTabControls)
			{
				Tab tab = pageTabControl.Tabs.FromKeyTab(key);
				if (tab != null) tab.Visible = visible;
			}
		}

		protected virtual void SetPageTabItemActive(string key)
		{
			foreach (WebTab pageTabControl in PageTabControls)
			{
				Tab tab = pageTabControl.Tabs.FromKeyTab(key);
				if (tab != null) pageTabControl.SelectedTabObject = tab;
			}
		}

		protected virtual string GetPageTabActiveItem()
		{
			return "";
			foreach (WebTab pageTabControl in PageTabControls)
			{
				if(pageTabControl.SelectedTab>0)
					return pageTabControl.Tabs[pageTabControl.SelectedTab].Key;
			}
		}

		protected virtual void SetPageTabToolbarItemVisible(string key, bool visible)
		{
			WebToolbar toolbar = null;

			foreach (WebTab pageTabControl in PageTabControls)
			{
				foreach (Tab tab in pageTabControl.Tabs)
				{
					toolbar = (WebToolbar)tab.ContentPane.FindControl(tab.Key + "_TabToolbar");
					if (toolbar != null)
					{
						TBarButton button = toolbar.Items.FromKeyButton(key);
						if (button != null) 
						{
							ToolbarButtonExtraProperties props = button.Tag as ToolbarButtonExtraProperties;
							if (props != null) props.Visible = visible;
						}
					}
				}
			}
		}

		protected virtual void SetPageToolbarItemVisible(string key, bool visible)
		{
			foreach (WebToolbar pageToolbarControl in PageToolbarControls)
			{
				TBarButton button = pageToolbarControl.Items.FromKeyButton(key);
				if (button != null) 
				{
					ToolbarButtonExtraProperties props = button.Tag as ToolbarButtonExtraProperties;
					if (props != null) props.Visible = visible;
				}
			}		
		}

		protected virtual void SetPageSubMenuItemVisible(string key, bool visible)
		{
			foreach (WebListBar pageSubMenuControl in PageSubMenuControls)
			{
				foreach (Group group in pageSubMenuControl.Groups)
				{
					//if (group.Key == key) pageSubMenuControl.Groups.Remove(group);
					Item item = group.Items.FromKey(key);
					if (item != null)
					{
						ListbarButtonExtraProperties props = item.Tag as ListbarButtonExtraProperties;
						if (props != null) props.Visible = visible;
					}
				}
			}
		}

		
		protected virtual void SetPageTabItemEnabled(string key, bool enabled)
		{
			foreach (WebTab pageTabControl in PageTabControls)
			{
				Tab tab = pageTabControl.Tabs.FromKeyTab(key);
				if (tab != null) tab.Enabled = enabled;
			}
		}

		protected virtual void SetPageTabToolbarItemEnabled(string key, bool enabled)
		{
			WebToolbar toolbar = null;

			foreach (WebTab pageTabControl in PageTabControls)
			{
				foreach (Tab tab in pageTabControl.Tabs)
				{
					toolbar = (WebToolbar)tab.ContentPane.FindControl(tab.Key + "_TabToolbar");
					if (toolbar != null)
					{
						TBarButton button = toolbar.Items.FromKeyButton(key);
						if (button != null) button.Enabled = enabled;
					}
				}
			}
		}

		protected virtual void SetPageToolbarItemEnabled(string key, bool enabled)
		{
			foreach (WebToolbar pageToolbarControl in PageToolbarControls)
			{
				TBarButton button = pageToolbarControl.Items.FromKeyButton(key);
				if (button != null) button.Enabled = enabled;
			}
		}

		protected virtual void SetPageSubMenuItemEnabled(string key, bool enabled)
		{
			foreach (WebListBar pageSubMenuControl in PageSubMenuControls)
			{
				foreach (Group group in pageSubMenuControl.Groups)
				{
					Item item = group.Items.FromKey(key);
					if (item != null) item.Enabled = enabled;
				}
			}
		}


		#endregion


		/// <summary>
		/// Push the target tab to go to after the page is loaded.
		/// </summary>
		/// <param name="tabKey"></param>
		public static void PushTargetTab(string targetTabKey)
		{
			PushParam("TargetTab", targetTabKey);
		}

		/// <summary>
		/// Get the target tab key that was pushed when this page was called with Redirect.
		/// </summary>
		public string TargetTabKey
		{
			get
			{
				return (string)this.GetParam("TargetTab", null);
			}
		}

	}
}
