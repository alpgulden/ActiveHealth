using System;
using System.Collections;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// This interface should be implemented by reusable custom validators
	/// written to be used with data component.
	/// </summary>
	public interface IValidator
	{
		DCBase DataComp { get; set; }
		string DataMember { get; set; }
		bool IsValid { get; set; }
		void Validate();
		string getMessage();
	}

	/// <summary>
	/// The base validator class that implements basic functionality
	/// for the IValidator interface.  You can derive from this class
	/// instead of directly implementing IValidator interface.
	/// </summary>
	public class BaseValidator : IValidator
	{
		#region Protected members
		protected bool bIsValid;
		protected string message;
		protected DCBase dataComp;
		protected string dataMember;
		protected string dataTable;
		protected string dataField;

		static public void parseTableAndField(string memberStr, ref string dataTable, ref string dataField)
		{
			dataTable = "";
			dataField = "";
			if (memberStr != null)
			{
				string[] memberTerms = memberStr.Split('.');
				if (memberTerms.Length > 0)
					dataTable = memberTerms[0];

				if (memberTerms.Length > 1)
					dataField = memberTerms[1];
			}
		}

		protected void parseTableAndField(string memberStr)
		{
			parseTableAndField(memberStr, ref dataTable, ref dataField);
		}
		#endregion

		#region IValidator Members

		public DCBase DataComp
		{
			get
			{
				return dataComp;
			}
			set
			{
				dataComp = value;
			}
		}

		public string DataMember
		{
			get
			{
				return dataMember;
			}
			set
			{
				dataMember = value;
				// parse data member into table and field
				parseTableAndField(dataMember);
			}
		}

		/// <summary>
		/// May be overridden by custom validators
		/// </summary>
		public virtual bool IsValid
		{
			get
			{
				return bIsValid;
			}
			set
			{
				bIsValid = value;
			}
		}

		/// <summary>
		/// Must be overridden by custom validators to perfom actual validation logic.
		/// </summary>
		public virtual void Validate()
		{
			// noop
		}

		public string getMessage()
		{
			return message;	// default message is empty
		}

		#endregion
	}

	/// <summary>
	/// Manages a named collection of validator objects.
	/// </summary>
	public class ValidatorCollection : DictionaryBase
	{
		#region Private members
		//
		#endregion

		#region Constructors
		public ValidatorCollection() : base()
		{
		}
		#endregion

		#region Protected overrides
		protected override void OnInsert(object key, object value)
		{
			if (!(key is String))
				throw new ArgumentException("key must be of type string", "key");
			else
			{
				string sKey = (string)key;

				if (Dictionary.Contains(key))
					throw new ArgumentException("key '" + sKey + "' already exists", "key");
			
				IValidator vld = (IValidator)value;

				// no problem
			}
		}

		protected override void OnRemove(object key, object value)
		{
			if (!(key is String))
				throw new ArgumentException("key must be of type string", "key");
		}

		protected override void OnSet(object key, object oldValue, object newValue)
		{
			if (!(key is String))
				throw new ArgumentException("key must be of type string", "key");
			else
			{
				string sKey = (string)key;

				IValidator vld = (IValidator)newValue;
			}
		}

		protected override void OnValidate(object key, object value)
		{
			if (!(key is String))
				throw new ArgumentException("key must be of type string", "key");
			else
			{
				string sKey = (string)key;

				IValidator vld = (IValidator)value;
			}
		}
		#endregion

		#region Public members
		public IValidator this[string key]
		{
			get
			{
				return (IValidator)Dictionary[key];
			}
			set
			{
				Dictionary[key] = value;		// add to dictionary
			}
		}

		public ICollection Keys
		{
			get
			{
				return Dictionary.Keys;
			}
		}

		public void Add(string key, IValidator validator)
		{
			if (key == null)
			{
				key = "";
				try
				{
					key = validator.DataComp.GetType().ToString();
				}
				catch(Exception)
				{	// ignore
				}
				key += "." + Convert.ToString(validator.DataMember);
			}
			Dictionary.Add(key, validator);
		}
	
		public bool Contains(string key)
		{
			return Dictionary.Contains(key);
		}

		public void Remove(string key)
		{
			Dictionary.Remove(key);
		}

		public string[] MergeMessages()
		{
			ArrayList msgs = new ArrayList();
			foreach (DictionaryEntry item in this)
			{
				IValidator vld = (IValidator)item.Value;
				if (vld != null)
				{
					if (!vld.IsValid)
					{
						msgs.Add(vld.getMessage());
					}
				}
			}

			return (string[])msgs.ToArray(typeof(string));
		}
		#endregion
	}

	/// <summary>
	/// Manages a named collection of validator objects and also provides
	/// batch validation functions and binding to a specific dataComp.
	/// </summary>
	public class ValidatorManager : ValidatorCollection
	{
		#region Private members
		private DCBase dataComp;

		private bool bIsValid;		// Validation result
		private ValidatorCollection failedValidators;	// Collection of failed validators
		#endregion

		#region Constructors
		public ValidatorManager(DCBase dataComp) : base()
		{
			this.dataComp = dataComp;
		}
		#endregion

		#region Public Members

		public new IValidator this[string key]
		{
			/*
			get
			{
				return base[key];
			}*/
			set
			{
				value.DataComp = dataComp;		// associate with relevant data component
				base[key] = value;				// add to dictionary
			}
		}

		public void Add(string key, string dataMember, IValidator validator)
		{
			validator.DataComp = dataComp;		// associate with relevant data component
			validator.DataMember = dataMember;	// associate with the given data member
			base.Add(key, validator);
		}

		public new void Add(string key, IValidator validator)
		{
			validator.DataComp = dataComp;		// associate with relevant data component
			base.Add(key, validator);
		}

		public new void Remove(string key)
		{
			base[key].DataComp = null;		// disassociate with relevant data component
			Dictionary.Remove(key);
		}
		
		/*
		public void ValidateAll()
		{
			failedValidators = new ValidatorCollection();
			bIsValid = true;			
			foreach record
			Validate();
		}*/

		private void InternalValidate()
		{
			// False if only one of the validators fail
			foreach (DictionaryEntry item in this)
			{
				NetsoftUSA.DataLayer.IValidator vld = (IValidator)item.Value;
				try
				{
					vld.Validate();
				}
				catch(Exception)
				{
					// some error occured, assume it to be valid
					vld.IsValid = true;
				}
				if (!vld.IsValid)
				{
					bIsValid = false;		// failed
					failedValidators.Add((string)item.Key, vld);		// add to failed validators collection
				}
			}
		}

		public void Validate()
		{
			failedValidators = new ValidatorCollection();
			bIsValid = true;
			InternalValidate();
		}

		/// <summary>
		/// Return all failed validators.  You should access this
		/// method only after validator
		/// </summary>
		public ValidatorCollection FailedValidators
		{
			get
			{
				return failedValidators;
			}
		}

		public bool IsValid
		{
			get
			{
				return bIsValid;
			}
			set
			{
				bIsValid = value;
			}
		}

		#endregion
	}
}
