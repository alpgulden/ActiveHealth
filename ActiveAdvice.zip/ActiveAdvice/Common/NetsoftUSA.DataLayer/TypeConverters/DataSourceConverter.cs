using System;
using System.ComponentModel;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Type converter used by DCBase type DataSource properties.
	/// </summary>
	public class DataSourceConverter : TypeConverter
	{
		public DataSourceConverter() : base()
		{		
		}

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;		// We support a list of possible data source at design time
		}

		public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			System.Collections.ArrayList ls = new System.Collections.ArrayList();
			ls.Add(null);
			foreach (object o in context.Container.Components)
			{
				Component comp = o as Component;
				if (comp != null)			
					if (comp is DCBase)		// if the component is of Data Component type
					{
						if (comp.Site != null)
							ls.Add(comp.Site.Name);
					}
			}
			ls.Sort();
			return new System.ComponentModel.TypeConverter.StandardValuesCollection(ls);
		}
	}
}
