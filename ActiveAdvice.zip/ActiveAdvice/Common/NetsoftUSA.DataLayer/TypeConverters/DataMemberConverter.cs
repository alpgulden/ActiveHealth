using System;
using System.Data;
using System.ComponentModel;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Enlists table and field items in a dataset.
	/// </summary>
	public class BaseDataMemberConverter : TypeConverter
	{
		private bool bTablesOnly = false;

		public BaseDataMemberConverter(bool tablesOnly) : base()
		{
			bTablesOnly = tablesOnly;
		}

		public bool TablesOnly
		{
			get
			{
				return bTablesOnly;
			}
			set
			{
				bTablesOnly = value;
			}
		}

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;		// We support a list of possible data members obtained from the MainDataSet of the data component
		}

		private DCBase GetDataSource(ITypeDescriptorContext context)
		{
			// Get the relevant datasource specified in the object's DataSourceName public property
			// We use late bound invocation to access the public property, so the
			// type of the actual object is not important.
			DCBase dataSource = null;
			Type tobj = context.Instance.GetType();
			System.Reflection.PropertyInfo pi = null;

			//System.Diagnostics.TextWriterTraceListener listener = new System.Diagnostics.TextWriterTraceListener("c:\\design7.log", "filelistener");
			//System.Diagnostics.Trace.Listeners.Clear();
			//System.Diagnostics.Trace.Listeners.Add(listener);
			
			System.ComponentModel.Design.IDesignerHost desHost = context.Container as System.ComponentModel.Design.IDesignerHost;

			if (desHost.RootComponent is DCBase)
			{
				DCBase dc = desHost.RootComponent as DCBase;
				
				//if (dc.GetMainDataSet() == null)
				//	System.Diagnostics.Trace.WriteLine("null ds");
				//else
				//	System.Diagnostics.Trace.WriteLine(Convert.ToString(dc.GetMainDataSet()));
				//System.Diagnostics.Trace.Listeners.Remove("filelistener");
				//listener.Close();
				return dc;
			}
			
			//System.Diagnostics.Trace.Listeners.Remove("filelistener");
			//listener.Close();
			/*
			// Ise DataComp property if exists
			try
			{
				pi = tobj.GetProperty("DataComp");
			}
			catch(Exception)
			{
			}
			if (pi != null)
			{
				dataSource = pi.GetValue(context.Instance, null) as DCBase;
				if (dataSource != null)
					return dataSource;
			}*/

			// Use DataSourceName otherwise
			pi = tobj.GetProperty("DataSourceName");
			object oDataSourceName = pi.GetValue(context.Instance, null);
			string sDataSourceName = (string)oDataSourceName;
			dataSource = context.Container.Components[sDataSourceName] as DCBase;
			return dataSource;
		}

		public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			System.Collections.ArrayList ls = new System.Collections.ArrayList();
			ls.Add(null);
			// Obtain the dataSource specified on object's public property 'DataSourceName'
			DCBase dataSource = GetDataSource(context);
			if (dataSource != null)
			{
				// if generic datasource, then just display the TableMappingName of it
				DCGeneric gen = dataSource as DCGeneric;
				if (gen != null)
					ls.Add(gen.TableMappingName);
				else
				{
					DataSet ds = null;
					bool useGlobalString = dataSource.UseGlobalConnectionString;
					try
					{
						dataSource.UseGlobalConnectionString = false;
						dataSource.LoadDataEmpty();
						ds = dataSource.GetMainDataSet();
					}
					catch(Exception ex)
					{
						ls.Add(ex.ToString());
					}
					finally
					{
						dataSource.UseGlobalConnectionString = useGlobalString;
					}
					if (ds != null)
					{
						// Now enumerate the available items
						foreach (DataTable tbl in ds.Tables)
						{
							if (bTablesOnly)
							{
								ls.Add(tbl.TableName);
							}
							else
							{
								System.Collections.ArrayList lsItems = new System.Collections.ArrayList();

								ls.Add("-- Table " + tbl.TableName + " columns --");
								foreach (DataColumn col in tbl.Columns)
								{
									lsItems.Add(tbl.TableName + "." + col.ColumnName);
								}

								lsItems.Sort();
								ls.AddRange(lsItems);
								lsItems.Clear();

								string[] formattedItems = dataSource.GetFormattedTableItems(tbl.TableName);
								if (formattedItems != null)
								{
									ls.Add("-- Table " + tbl.TableName + " formatted items --");

									foreach (string fmtItem in formattedItems)
									{
										// if the formatter is not on already existing column name
										if (!tbl.Columns.Contains(fmtItem))
										{
											if (!lsItems.Contains(tbl.TableName + "." + fmtItem))
                                                lsItems.Add(tbl.TableName + "." + fmtItem);
										}
									}

									lsItems.Sort();
									ls.AddRange(lsItems);
									lsItems.Clear();
								}

								
							}
						}
					}
				}

			}
			return new System.ComponentModel.TypeConverter.StandardValuesCollection(ls);
		}
	}

	/// <summary>
	/// Type converter used by DataMember properties that accept 'Table.Field'.
	/// </summary>
	public class DataTableAndItemConverter : BaseDataMemberConverter
	{
		public DataTableAndItemConverter() : base(false)
		{
		}
	}

	/// <summary>
	/// Type converter used by DataMember properties that accept only 'Table'
	/// </summary>
	public class DataTableOnlyConverter : BaseDataMemberConverter
	{
		public DataTableOnlyConverter() : base(true)
		{
		}
	}
}
