using System;
using System.Data;
using System.ComponentModel;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Enlists the properties and fields of a class
	/// </summary>
	public class ClassMemberConverter : TypeConverter
	{
		public ClassMemberConverter()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;		// We support a list of possible data members obtained from the MainDataSet of the data component
		}

		public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			System.Collections.ArrayList ls = new System.Collections.ArrayList();
			ls.Add(null);
			Type tctl = context.Instance.GetType();

			// Use SourceClassName
			System.Reflection.PropertyInfo pi = tctl.GetProperty("SourceClassName");
			string sourceClassName = Convert.ToString(pi.GetValue(context.Instance, null));
			
			if (sourceClassName != null && sourceClassName != "")
			{
				Type tsource = null;
				try
				{
					tsource = Type.GetType(sourceClassName);
				}
				catch(Exception ex)
				{
					ls.Add(ex.Message);
					return new System.ComponentModel.TypeConverter.StandardValuesCollection(ls);
				}

				if (tsource == null)
				{
					ls.Add("Invalid source class name");
					return new System.ComponentModel.TypeConverter.StandardValuesCollection(ls);
				}

				ColumnsMappingModeAttribute mapMode = new ColumnsMappingModeAttribute(ColumnMappingModes.Public);

				System.Reflection.MemberInfo[] members = 
					ColumnMappingAttribute.FindColumnMappingMembers(
					System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field, mapMode,
					false,
					tsource);
				foreach (System.Reflection.MemberInfo mi in members)
				{
					if (!ColumnMappingAttribute.IsCollection(
						ColumnMappingAttribute.GetMemberDataType(mi)))
						ls.Add(mi.Name);
				}

				ls.Sort();
			}

			return new System.ComponentModel.TypeConverter.StandardValuesCollection(ls);
		}
	}
}
