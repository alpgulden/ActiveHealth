using System;
using System.Reflection;
using System.Collections;

namespace NetsoftUSA.DataLayer
{
	#region PickPage Attribute

	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property | AttributeTargets.Method)]
	public class PickPageAttribute : Attribute
	{
		public string Page;
		public PickPageAttribute(string page)
		{
			this.Page = page;
		}

		public static PickPageAttribute GetFromMember(MemberInfo mi)
		{
			if (mi != null)
			{
				object[] attribs = mi.GetCustomAttributes(typeof(PickPageAttribute), true);
				if (attribs.Length > 0)
					return (PickPageAttribute)attribs[0];
			}
			return null;
		}
	}

	#endregion

	/*#region CustomDropDown Attribute

	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property | AttributeTargets.Method)]
	public class CustomDropDownAttribute : Attribute
	{
		public string customDropDown;
		public CustomDropDownAttribute(string customDropDown)
		{
			this.customDropDown = customDropDown;
		}

		public static CustomDropDownAttribute GetFromMember(MemberInfo mi)
		{
			if (mi != null)
			{
				object[] attribs = mi.GetCustomAttributes(typeof(CustomDropDownAttribute), true);
				if (attribs.Length > 0)
					return (CustomDropDownAttribute)attribs[0];
			}
			return null;
		}

		public static string GetCustomDropDown(MemberInfo mi)
		{
			CustomDropDownAttribute att = GetFromMember(mi);
			if (att == null)
				return null;
			return att.customDropDown;
		}
	}

	#endregion*/

	#region ValidatorMember Attribute

	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class ValidatorMemberAttribute : Attribute
	{
		public string ValidatorMember;
		public ValidatorMemberAttribute(string ValidatorMember)
		{
			this.ValidatorMember = ValidatorMember;
		}

		public static ValidatorMemberAttribute GetFromMember(MemberInfo mi)
		{
			if (mi != null)
			{
				object[] attribs = mi.GetCustomAttributes(typeof(ValidatorMemberAttribute), true);
				if (attribs.Length > 0)
					return (ValidatorMemberAttribute)attribs[0];
			}
			return null;
		}

		public static string GetValidatorMember(MemberInfo mi)
		{
			ValidatorMemberAttribute vm = GetFromMember(mi);
			if (vm == null)
				return null;
			else
				return vm.ValidatorMember;
		}

		// will throw if there's any problem
		public void ValidateMemberForSet(object obj, string s)
		{
			ReflectionHelper.SetMemberValueFromString(obj, this.ValidatorMember, s);	// is successful?
		}

		public string ValidateMemberForGet(object obj)
		{
			return ReflectionHelper.GetMemberValueAsString(obj, this.ValidatorMember);
		}

		public static void ValidateMemberForSet(MemberInfo mi, object obj, string s)
		{
			ValidatorMemberAttribute vm = GetFromMember(mi);
			if (vm != null)
				vm.ValidateMemberForSet(obj, s);
		}

		public static string ValidateMemberForGet(MemberInfo mi, object obj)
		{
			ValidatorMemberAttribute vm = GetFromMember(mi);
			if (vm != null)
				return vm.ValidateMemberForGet(obj);
			return null;
		}

	}

	#endregion

	#region ClientScript Attribute

	/// <summary>
	/// Declare the Client Script validation using this attribute.
	/// </summary>
	public class ClientScriptAttribute : Attribute
	{
		public string Name;
		public string JScript;

		public ClientScriptAttribute(string Name)
		{
			this.Name = Name;
		}

		public ClientScriptAttribute(string Name, string JScript)
		{
			this.Name = Name;
			this.JScript = JScript;
		}

		public static ClientScriptAttribute GetFromMember(MemberInfo mi)
		{
			ClientScriptAttribute att = (ClientScriptAttribute)ClientScriptAttribute.GetCustomAttribute(mi, typeof(ClientScriptAttribute));
			return att;
		}

		//GetValidationScritAttrib
		public static ClientScriptAttribute GetFromMember(Type type, string memberName)
		{
			return ClientScriptAttribute.GetFromMember(ReflectionHelper.GetFieldOrProp(type, memberName));
		}

		public static ClientScriptAttribute GetClientValidationScriptAttrib(MemberInfo mi)
		{
			string validatorMember = ValidatorMemberAttribute.GetValidatorMember(mi);
			if (validatorMember != null)
			{
				ClientScriptAttribute att = ClientScriptAttribute.GetFromMember(mi.DeclaringType, validatorMember);
				return att;
			}
			return null;
		}

	}

	#endregion

	#region GenericScript Attribute

	/// <summary>
	/// Declare the Generic Script that can be used as both serverside and clientside
	/// </summary>
	public class GenericScriptAttribute : Attribute
	{
		public string Name;
		public string JScript;
		public Type type;

		public GenericScriptAttribute(string Name)
		{
			this.Name = Name;
		}

		public GenericScriptAttribute(string Name, string JScript)
		{
			this.Name = Name;
			this.JScript = JScript;
		}

		/*public static GenericScriptAttribute GetFromMember(MemberInfo mi)
		{
		
			GenericScriptAttribute att = (GenericScriptAttribute)GenericScriptAttribute.GetCustomAttribute(mi, typeof(GenericScriptAttribute));
			att.type = mi.DeclaringType;
			return att;
		}*/

		public static GenericScriptAttribute GetFromMember(Type type, string memberName)
		{
			return GetFromMember(ReflectionHelper.GetFieldOrProp(type, memberName));
		}

		public static GenericScriptAttribute GetFromMember(MemberInfo mi)
		{
			GenericScriptAttribute att = (GenericScriptAttribute)GenericScriptAttribute.GetCustomAttribute(mi, typeof(GenericScriptAttribute));
			att.type = mi.ReflectedType;
			return att;
		}

		public string GetUniqueFunctionName()
		{
			return this.type.FullName.Replace('.', '_') + "_" + this.Name;
		}

	}

	#endregion

	#region FormatterFunction Attribute

	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class FormatterFunctionAttribute : Attribute
	{
		public string formatterFunction;
		public FormatterFunctionAttribute(string formatterFunction)
		{
			this.formatterFunction = formatterFunction;
		}

		public static FormatterFunctionAttribute GetFromMember(MemberInfo mi)
		{
			if (mi != null)
			{
				object[] attribs = mi.GetCustomAttributes(typeof(FormatterFunctionAttribute), true);
				if (attribs.Length > 0)
					return (FormatterFunctionAttribute)attribs[0];
			}
			return null;
		}

		public static string GetFormatterFunction(MemberInfo mi)
		{
			FormatterFunctionAttribute ff = FormatterFunctionAttribute.GetFromMember(mi);
			if (ff == null)
				return null;
			return ff.formatterFunction;
		}

		public static string GetFormatterFunction(Type type, string memberName)
		{
			return GetFormatterFunction(ReflectionHelper.GetFieldOrProp(type, memberName));
		}

		public static string InvokeFormatterFunction(object obj, string function, object value, bool withValue)
		{
			Type type = obj.GetType();
			MethodInfo method = type.GetMethod(function);
			return ReflectionHelper.InvokeFormatterFunction(obj, method, value, withValue);
		}

		public static string UseFormatterForMember(object obj, string memberName, object value, bool withValue)
		{
			Type type = obj.GetType();
			MemberInfo mi = ReflectionHelper.GetFieldOrProp(type, memberName);
			string function = GetFormatterFunction(mi);
			MethodInfo method = type.GetMethod(function);
			return ReflectionHelper.InvokeFormatterFunction(obj, method, value, withValue);
		}
		
	}

	#endregion

	#region FieldValuesMember Attribute

	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class FieldValuesMemberAttribute : Attribute
	{
		public string fieldValuesMember;
		public string lookupCollectionMember;		// keeps a collection of possible value records
		public string collectionValueMember;
		public string collectionDescriptionMember;
		public FieldValuesMemberAttribute(string fieldValuesMember)
		{
			this.fieldValuesMember = fieldValuesMember;
		}

		public FieldValuesMemberAttribute(string lookupCollectionMember, string collectionValueMember, string collectionDescriptionMember)
		{
			this.lookupCollectionMember = lookupCollectionMember;
			this.collectionValueMember = collectionValueMember;
			this.collectionDescriptionMember = collectionDescriptionMember;
		}

		public static FieldValuesMemberAttribute GetFromMember(MemberInfo mi)
		{
			if (mi != null)
			{
				object[] attribs = mi.GetCustomAttributes(typeof(FieldValuesMemberAttribute), true);
				if (attribs.Length > 0)
					return (FieldValuesMemberAttribute)attribs[0];
			}
			return null;
		}

		public Array GetFieldValues(object obj)
		{
			if (this.fieldValuesMember == null)
				return null;
			Array vals = (Array)ReflectionHelper.GetMemberValue(obj, this.fieldValuesMember);
			if (vals == null)
				return null;

			Type t = vals.GetType();

			if (t.IsArray)
			{
				return vals;
				/*Array arr = (Array)vals;
				object[] oVals = new object[arr.Length];
				for (int i = 0; i < arr.Length; i++)
				{
					oVals[i] = arr.GetValue(i);
				}
				return oVals;*/
			}

			string s = Convert.ToString(vals);
			return s.Split(',');
		}

		public static Array GetFieldValues(object obj, MemberInfo mi)
		{
			FieldValuesMemberAttribute fv = FieldValuesMemberAttribute.GetFromMember(mi);
			if (fv == null)
				return null;
			return fv.GetFieldValues(obj);
		}

		public static string[] GetFormattedFieldValues(object obj, MemberInfo mi)
		{
			Array vals = GetFieldValues(obj, mi);
			return GetFormattedFieldValues(obj, mi, vals);
		}

		public static string[] GetFormattedFieldValues(object obj, MemberInfo mi, System.Array vals)
		{
			if (vals == null)
				return null;
			string[] fmtVals = null;

			string formatterFunction = FormatterFunctionAttribute.GetFormatterFunction(mi);
			if (formatterFunction == null)
			{
				
				if (vals.Rank == 1)		// only values
				{
					// use the accessor directly
					object tempObj = null;

					// create an instance of the same object to work on.
					// either clone or create of the same type.
					ICloneable iCloneable = obj as ICloneable;
					if (iCloneable != null)
						tempObj = iCloneable.Clone();
					else
						tempObj = Activator.CreateInstance(obj.GetType());


					fmtVals = new string[vals.Length];
					for (int i = 0; i < vals.Length; i++)
					{
						string sval = Convert.ToString(vals.GetValue(i));
						ReflectionHelper.SetMemberValueFromString(tempObj, mi.Name, sval);
						fmtVals[i] = ReflectionHelper.GetMemberValueAsString(tempObj, mi.Name);
					}
				}
				else if (vals.Rank == 2)		// values and descriptions
				{
					if (vals.GetLength(1) < 2)
						throw new Exception("Field Values array must contain both values and descriptions"); 
					fmtVals = new string[vals.GetLength(0)];
					for (int i = 0; i < fmtVals.Length; i++)
					{
						string sval = Convert.ToString(vals.GetValue(i, 0));
						fmtVals[i] = Convert.ToString(vals.GetValue(i, 1));
					}
				}
				// vals.Rank > 2 ===> invalid case 
			}
			else
			{
				fmtVals = new string[vals.Length];
				// Use formatter function
				for (int i = 0; i < vals.Length; i++)
				{
					fmtVals[i] = FormatterFunctionAttribute.InvokeFormatterFunction(obj, formatterFunction, vals.GetValue(i), false); 
				}
				
			}

			return fmtVals;
		}

		public IList GetLookupCollection(object obj)
		{
			if (this.lookupCollectionMember == null)
				return null;
			return (IList)ReflectionHelper.GetMemberValue(obj, this.lookupCollectionMember);
		}

		public static IList GetLookupCollection(object obj, PropertyInfo pi, ref string collectionValueMember, ref string collectionDescriptionMember)
		{
			Type tobj = obj.GetType();
			FieldValuesMemberAttribute att = FieldValuesMemberAttribute.GetFromMember(pi);
			if (att == null)
				return null;
			if (att.lookupCollectionMember == null)
				return null;
			collectionValueMember = att.collectionValueMember;
			collectionDescriptionMember = att.collectionDescriptionMember;
			return att.GetLookupCollection(obj);
		}
	}

	#endregion

	#region ComboStyle Attribute

	public class ComboStyleAttribute : Attribute
	{
		public NSComboStyle ComboStyle;
		public ComboStyleAttribute(NSComboStyle comboStyle)
		{
			this.ComboStyle = comboStyle;
		}
	}

	#endregion

	#region JoinedColumn Attribute

	public class JoinedColumnAttribute : Attribute
	{
		public string JoinTable;
		public string JoinColumn;
		public string LeftRelationColumn;
		public string RightRelationColumn;
		public string Alias;

		public JoinedColumnAttribute(string JoinTable, string JoinColumn, string LeftRelationColumn, string RightRelationColumn)
		{
			this.JoinTable = JoinTable;
			this.JoinColumn = JoinColumn;
			this.LeftRelationColumn = LeftRelationColumn;
			this.RightRelationColumn = RightRelationColumn;
		}
	}

	#endregion

	#region FieldDescription Attribute

	/// <summary>
	/// Declare the Field Description using this attribute.
	/// </summary>
	public class FieldDescriptionAttribute : Attribute
	{
		public string Description;
		public FieldDescriptionAttribute(string Description)
		{
			this.Description = Description;
		}

		public static string GetDescription(object obj, string memberName)
		{
			Type type = obj.GetType();
			return GetDescription(type, memberName);
		}

		public static string GetDescription(Type type, string memberName, bool useDefault)
		{
			string desc = GetDescription(type, memberName);
			if (desc == null)
				return "@" + memberName.ToUpper() + "@";
			else
				return desc;
		}
		
		public static string GetDescription(Type type, string memberName)
		{
			FieldInfo fi = type.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (fi != null)
				return GetDescription(fi);

			PropertyInfo pi = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (pi != null)
				return GetDescription(pi);

			throw new ArgumentException(String.Format("{0} doesn't support property or field {1}", type.Name, memberName));
		}

		public static string GetDescription(MemberInfo mi)
		{
			FieldDescriptionAttribute att = (FieldDescriptionAttribute)FieldDescriptionAttribute.GetCustomAttribute(mi, typeof(FieldDescriptionAttribute));
			if (att == null)
				return null;
			else
				return att.Description;
		}
		
		public static string GetDescription(MemberInfo mi, bool useDefault)
		{
			string desc = GetDescription(mi);
			if (desc == null)
				return "@" + mi.Name.ToUpper() + "@";
			else
				return desc;
		}

	}

	#endregion

	#region RecordDescription Attribute

	/// <summary>
	/// Declare the Record Description using this attribute.
	/// </summary>
	public class RecordDescriptionAttribute : Attribute
	{
		public string Description;
		public RecordDescriptionAttribute(string Description)
		{
			this.Description = Description;
		}

		public static string GetDescription(Type type, bool useDefault)
		{
			string desc = GetDescription(type);
			if (desc == null)
				return "@" + type.Name.ToUpper() + "@";
			else
				return desc;
		}
		
		public static string GetDescription(Type type)
		{
			RecordDescriptionAttribute att = (RecordDescriptionAttribute)RecordDescriptionAttribute.GetCustomAttribute(type, typeof(RecordDescriptionAttribute));
			if (att == null)
				return null;
			else
				return att.Description;
		}
		
	}

	#endregion

	#region FieldFormatter Attribute

	/// <summary>
	/// Declare the field formatter type using this attribute.
	/// </summary>
	public class FieldFormatterAttribute : Attribute
	{
		public Type FieldFormatter;
		public FieldFormatterAttribute(Type fieldFormatter)
		{
			this.FieldFormatter = fieldFormatter;
		}
	}

	#endregion

	#region Copiable Attribute

	/// <summary>
	/// If you mark a member Copiable = false, CopyMembers will not copy this member.
	/// </summary>
	public class CopiableAttribute : Attribute
	{
		public bool Copiable = true;
		public string CopyFrom = null;	// the source member when this is copied from
		public string CopyTo = null;	// the target member when this is copied to

		public CopiableAttribute()
		{
		}

		public CopiableAttribute(bool Copiable)
		{
			this.Copiable = Copiable;
		}

		public static CopiableAttribute GetFromMember(MemberInfo mi)
		{
			return (CopiableAttribute)CopiableAttribute.GetCustomAttribute(mi, typeof(CopiableAttribute), true);
		}

		public static CopiableAttribute GetFromMember(Type type, string memberName)
		{
			MemberInfo mi = ReflectionHelper.GetMember(type, memberName, MemberTypes.Field | MemberTypes.Property, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			return GetFromMember(mi);			
		}

		public static bool IsCopiable(Type type, string memberName)
		{
			CopiableAttribute att = GetFromMember(type, memberName);
			if (att == null)
				return true;
			else
				return att.Copiable;
		}

		public static bool IsCopiableFrom(Type type, string memberName, ref string copyFrom)
		{
			CopiableAttribute att = GetFromMember(type, memberName);
			if (att == null)
			{
				copyFrom = memberName;
				return true;
			}
			else
			{
				copyFrom = att.CopyFrom;
				if (copyFrom == null)
					copyFrom = memberName;
				return att.Copiable;
			}
		}

		public static bool IsCopiableTo(Type type, string memberName, ref string copyTo)
		{
			CopiableAttribute att = GetFromMember(type, memberName);
			if (att == null)
			{
				copyTo = memberName;
				return true;
			}
			else
			{
				copyTo = att.CopyTo;
				if (copyTo == null)
					copyTo = memberName;
				return att.Copiable;
			}
		}

	}

	#endregion

	#region ColumnMapping Attribute

	public enum ValuesForNull
	{
		NullObject = 0,
		NullDateTime = 1,
		NullDecimal = 2,
		NullGuid = 3
	}

	// Used as an extra type information for column mapping
	public enum DataStereoType
	{
		None = 0,
		Currency = 1,
		USSSN = 3,
		USZipCode = 4,
		USPhoneNumber = 5,
		Email = 6,
		URL = 7,
		Password = 8,
		USState = 9,
		Day = 10,
		Month = 11,
		Year = 12,
		YesNo = 13,
		TrueFalse = 14,
		Percent = 15,
		Gender = 16,
		DateOnly = 17,
		TimeOnly = 18,
		DateTime = 19,
		FK = 20,					// the field is actually a foreign key.
		PK = 21						// the field is part of PK.
	}

	/// <summary>
	/// Declare the mapped column for a property.
	/// Used with Data object filler/retriever functions.
	/// </summary>
	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class ColumnMappingAttribute: Attribute
	{
		public string ColumnName;
		private object valueForNull = null;	// default causes no value to be mapped to DBNull
		public DataFiller.FillFlags FillFlags = DataFiller.FillFlags.BothWays;
		public SQLGenerationFlags SQLGen = SQLGenerationFlags.None;
		public string InjectInsert;
		public string InjectUpdate;
		public string InjectSelect;
		public string InjectSearch;			// Used only by Search sp templates
		// Joined colum properties
		private string joinRelation;	// join relation to be used to gather this column's value.  the value comes from the right table.
		public string JoinColumn;		// which column to be joined.  The ColumnName becomes alias
		private DataStereoType stereoType = DataStereoType.None;		// used to declare extra type information
		private Type type;		// type of the column set when the attribute is obtained from a field or property

		public ColumnMappingAttribute()
		{
		}

		public ColumnMappingAttribute(string ColumnName)
		{
			this.ColumnName = ColumnName;
		}

		public ColumnMappingAttribute(string ColumnName, object ValueForNull)
			: this(ColumnName)
		{
			this.ValueForNull = ValueForNull;
		}

		public ColumnMappingAttribute(string ColumnName, object ValueForNull, DataFiller.FillFlags FillFlags)
			: this(ColumnName, ValueForNull)
		{
			this.FillFlags = FillFlags;
		}

		public ColumnMappingAttribute(string ColumnName, object ValueForNull, DataFiller.FillFlags FillFlags, SQLGenerationFlags SQLGen)
			: this(ColumnName, ValueForNull, FillFlags)
		{
			this.SQLGen = SQLGen;
		}

		#region Private Members
		
		

		#endregion

		#region Member filter delegates

		private static bool FilterFindColumnMappingMembers(MemberInfo objMemberInfo, Object objSearch)
		{
			object[] attribs = objMemberInfo.GetCustomAttributes(typeof(ColumnMappingAttribute), true);

			if (attribs != null)
				if (attribs.Length > 0)
					return true;

			return false;
		}

		private static bool FilterFindColumnMappingMembersAndCollections(MemberInfo objMemberInfo, Object objSearch)
		{
			object[] attribs = objMemberInfo.GetCustomAttributes(typeof(ColumnMappingAttribute), true);

			if (attribs != null)
				if (attribs.Length > 0)
					return true;

			if (IsCollection(GetMemberDataType(objMemberInfo)))
				if (SimpleRelationAttribute.GetFromMember(objMemberInfo) != null)	// ilk
					return true;

			return false;
		}
		
		private static bool FilterFindColumnMappingMembersCollectionsAndContained(MemberInfo objMemberInfo, Object objSearch)
		{
			if (ColumnMappingAttribute.GetFromMember(objMemberInfo) != null)
				return true;

			if (SPLoadChildAttribute.GetFromMember(objMemberInfo) != null)
				return true;

			if (ContainedAttribute.GetFromMember(objMemberInfo) != null)
				return true;

			if (SimpleRelationAttribute.GetFromMember(objMemberInfo) != null)
				return true;

			return false;
		}

		#endregion

		#region Public functions

		public DataStereoType StereoType
		{
			get 
			{
				return this.stereoType;
			}
			set
			{
				this.stereoType = value;
				if (this.stereoType == DataStereoType.FK)
					this.valueForNull = (int)0;
			}
		}

		public string JoinRelation
		{
			get { return this.joinRelation; }
			set 
			{
				this.joinRelation = value;
				if (value != null)
				{
					// join columns are not insertable/updatable
					FillFlags = DataFiller.FillFlags.DataToObject;
					SQLGen = SQLGenerationFlags.NoInsertUpdate;
				}
			}
		}

		public bool IsJoinColumn
		{
			get { return JoinRelation != null; }
		}

		public bool GetJoinRelation(out string left, out string right)
		{
			if (JoinRelation == null)
			{
				left = null;
				right = null;
				return false;
			}

			SQLParser.ParseLogicalExp(JoinRelation, out left, out right, '=');
			return true;
		}

		public object ValueForNull
		{
			get
			{
				return valueForNull;
			}
			set
			{
				valueForNull = DetermineValueForNullFromValuesForNull(value);
			}
		}

		public static object DetermineValueForNullFromValuesForNull(object value)
		{
			if (value is ValuesForNull)
				switch ((ValuesForNull)value)
				{
					case ValuesForNull.NullObject:
						return null;
					case ValuesForNull.NullDateTime:
						return DateTime.MinValue;
					case ValuesForNull.NullDecimal:
						return Decimal.MinValue;
					case ValuesForNull.NullGuid:
						return Guid.Empty;
				}

			return value;
		}

		public static object DetermineValueForNull(Type type)
		{
			if (type == typeof(System.Decimal))
				return Decimal.MinValue;
			if (type == typeof(System.DateTime))
				return DateTime.MinValue;
			if (type == typeof(System.Double))
				return double.NaN;
			if (type == typeof(float))
				return float.NaN;
			if (type == typeof(System.Single))
				return Single.NaN;
			if (type == typeof(System.Guid))
				return Guid.Empty;
			return null;
		}

		public object GetValueForNull()
		{
			if (valueForNull is ValuesForNull)
				switch ((ValuesForNull)valueForNull)
				{
					case ValuesForNull.NullObject:
						return null;
					case ValuesForNull.NullDateTime:
						return DateTime.MinValue;
					case ValuesForNull.NullDecimal:
						return Decimal.MinValue;
					case ValuesForNull.NullGuid:
						return Guid.Empty;
				}
			return valueForNull;
		}

		public static Type GetMemberDataType(MemberInfo mi)
		{
			FieldInfo fi = mi as FieldInfo;
			if (fi != null)
				return fi.FieldType;

			PropertyInfo pi = mi as PropertyInfo;
			if (pi != null)
				return pi.PropertyType;

			return null;
		}

		public static bool IsCollection(Type memberType)
		{
			return  memberType.GetInterface("IList") != null;
		}

		public bool IsDataToObject
		{
			get { return (FillFlags & DataFiller.FillFlags.DataToObject) != 0; }
		}

		public bool IsObjectToData
		{
			get { return (FillFlags & DataFiller.FillFlags.ObjectToData) != 0; }
		}

		public bool IsNotNull
		{
			get { return (FillFlags & DataFiller.FillFlags.NotNull) != 0; }
		}

		public static ColumnMappingAttribute GetFromPropInfo(PropertyInfo pi, bool useDefault)
		{
			ColumnMappingAttribute attrib = (ColumnMappingAttribute)ColumnMappingAttribute.GetCustomAttribute(pi, typeof(ColumnMappingAttribute), true);
			if (attrib != null)
			{
				attrib.Type = pi.PropertyType;
				return attrib;
			}

			if (useDefault)
			{
				attrib = new ColumnMappingAttribute(pi.Name);
				attrib.Type = pi.PropertyType;
				return attrib;
			}
			else
				return null;
		}

		public static ColumnMappingAttribute GetFromFieldInfo(FieldInfo fi, bool useDefault)
		{
			ColumnMappingAttribute attrib = (ColumnMappingAttribute)ColumnMappingAttribute.GetCustomAttribute(fi, typeof(ColumnMappingAttribute), true);
			if (attrib != null)
			{
				attrib.Type = fi.FieldType;
				return attrib;
			}

			if (useDefault)
			{
				attrib = new ColumnMappingAttribute(fi.Name);
				attrib.Type = fi.FieldType;
				return attrib;
			}
			else
				return null;
		}

		public static ColumnMappingAttribute GetFromMember(MemberInfo mi)
		{
			ColumnMappingAttribute attrib = (ColumnMappingAttribute)ColumnMappingAttribute.GetCustomAttribute(mi, typeof(ColumnMappingAttribute), true);
			if (attrib != null)
			{
				FieldInfo fi = mi as FieldInfo;
				if (fi != null)
					attrib.Type = fi.FieldType;
				else
				{
					PropertyInfo pi = mi as PropertyInfo;
					if (pi != null)
						attrib.Type = pi.PropertyType;
					else
						attrib.Type = typeof(string);		// unknown case
				}
				return attrib;
			}

			return null;
		}

		public static ColumnMappingAttribute GetFromType(Type type, string memberName)
		{
			MemberInfo mi = ReflectionHelper.GetMember(type, memberName, MemberTypes.Field | MemberTypes.Property, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			return GetFromMember(mi);
		}

		public static System.Reflection.MemberInfo[] FindColumnMappingMembers(System.Reflection.MemberTypes memberType, bool collections, Type type)
		{
			ColumnsMappingModeAttribute mapMode = ColumnsMappingModeAttribute.GetFromType(type);
			return FindColumnMappingMembers(memberType, mapMode, collections, type);
		}

		public static System.Reflection.MemberInfo[] FindColumnMappingMembers(System.Reflection.MemberTypes memberType, ColumnsMappingModeAttribute mapMode, bool collections, Type type)
		{
			System.Reflection.BindingFlags bindingFlg = System.Reflection.BindingFlags.Instance;
			if (mapMode.IsPublic)
				bindingFlg |= System.Reflection.BindingFlags.Public;
			if (mapMode.IsNonPublic)
				bindingFlg |= System.Reflection.BindingFlags.NonPublic;

			MemberFilter memberFilter = null;
			if (mapMode.IsMappedOnly)
			{
				if (collections)	// both mapped and collections
					memberFilter = new MemberFilter(FilterFindColumnMappingMembersAndCollections);
				else				// only mapped
					memberFilter = new MemberFilter(FilterFindColumnMappingMembers);
			}
			// otherwise all 

			System.Reflection.MemberInfo[] members = type.FindMembers(
				memberType,
				bindingFlg,
				memberFilter, null);

			return members;
		}

		public static System.Reflection.MemberInfo[] FindColumnMappingMembersAndContained(System.Reflection.MemberTypes memberType, Type type)
		{
			ColumnsMappingModeAttribute mapMode = ColumnsMappingModeAttribute.GetFromType(type);
			return FindColumnMappingMembersAndContained(memberType, mapMode, type);
		}

		public static System.Reflection.MemberInfo[] FindColumnMappingMembersAndContained(System.Reflection.MemberTypes memberType, ColumnsMappingModeAttribute mapMode, Type type)
		{
			System.Reflection.BindingFlags bindingFlg = System.Reflection.BindingFlags.Instance;
			if (mapMode.IsPublic)
				bindingFlg |= System.Reflection.BindingFlags.Public;
			if (mapMode.IsNonPublic)
				bindingFlg |= System.Reflection.BindingFlags.NonPublic;

			MemberFilter memberFilter = new MemberFilter(FilterFindColumnMappingMembersCollectionsAndContained);
			// otherwise all 

			System.Reflection.MemberInfo[] members = type.FindMembers(
				memberType,
				bindingFlg,
				memberFilter, null);

			return members;
		}

		public static string GetColumnNameForMember(Type type, string memberName)
		{
			MemberInfo[] members = type.GetMember(memberName, 
				MemberTypes.Field | MemberTypes.Property, 
				BindingFlags.Public | BindingFlags.NonPublic |
				BindingFlags.Instance);
			if (members != null)
				if (members.Length > 0)
				{
					MemberInfo mi = members[0];
					ColumnMappingAttribute colMap = ColumnMappingAttribute.GetFromMember(mi);
					if (colMap != null)
						if (colMap.ColumnName != null)
							return colMap.ColumnName;
					return mi.Name;
				}
			throw new ArgumentException(String.Format("Class {0} declares a nonexistant member {1}", type.Name, memberName));
		}

		public static string[] GetMappedMemberNames(Type type)
		{
			MemberInfo[] members = 
				FindColumnMappingMembers(
				System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field,
				false,
				type);
			string[] mappedMembers = new string[members.Length];
			for (int i = 0; i < members.Length; i++)
			{
				mappedMembers[i] = members[i].Name;
			}

			return mappedMembers;
		}

		/*public static string[] GetMappedColumnNames(Type type, bool useSQLHintAttrib)
		{
			if (useSQLHintAttrib)
			{
				SQLHintAttribute sqlHint = SQLHintAttribute.GetFromType(type);
				if (sqlHint != null)
					if (sqlHint.columns != null)
						return SQLParser.ParseColumnNames(sqlHint.columns);
			}

			MemberInfo[] members = 
				FindColumnMappingMembers(
				System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field,
				false,
				type);
			string[] columnNames = new string[members.Length];
			for (int i = 0; i < members.Length; i++)
			{
				MemberInfo mi = members[i];

				ColumnMappingAttribute colMap = ColumnMappingAttribute.GetFromMember(mi);
				string colName = mi.Name;
				if (colMap != null)
					if (colMap.ColumnName != null)
						colName = colMap.ColumnName;
				columnNames[i] = colName;
			}

			return columnNames;
		}*/

		public static ColumnInfo[] GetMappedColumns(Type type, bool useSQLHintAttrib)
		{
			ColumnInfo[] colInfos;
			if (useSQLHintAttrib)
			{
				SQLHintAttribute sqlHint = SQLHintAttribute.GetFromType(type);
				if (sqlHint != null)
					if (sqlHint.columns != null)
					{
						string[] cols = SQLParser.ParseColumnNames(sqlHint.columns);
						colInfos = new ColumnInfo[cols.Length];
						for (int i = 0; i < cols.Length; i++)
							colInfos[i] = new ColumnInfo(cols[i], typeof(string));
						return colInfos;
					}
			}

			MemberInfo[] members = 
				FindColumnMappingMembers(
				System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field,
				false,
				type);
			colInfos = new ColumnInfo[members.Length];
			for (int i = 0; i < members.Length; i++)
			{
				MemberInfo mi = members[i];

				ColumnMappingAttribute colMap = ColumnMappingAttribute.GetFromMember(mi);
				string colName = mi.Name;
				ColumnInfo colInfo = null;

				if (colMap != null)
				{
					if (colMap.ColumnName != null)
						colName = colMap.ColumnName;
					colInfo = new ColumnInfo(colName, colMap);
					//colInfo.SqlGenFlags = colMap.SQLGen;
				}
				else
					colInfo = new ColumnInfo(colName, mi.ReflectedType);
				colInfos[i] = colInfo;
			}

			return colInfos;
		}

		public Type Type
		{
			get
			{
				return this.type;
			}
			set
			{
				this.type = value;
				if (this.valueForNull == null)
					this.valueForNull = DetermineValueForNull(type);
			}
		}

		#endregion
	}

	[Flags()]
	public enum ColumnMappingModes
	{
		Public = 1,
		NonPublic = 2,
		MappedOnly = 64
	}

	#endregion

	#region ColumnMapping Attribute

	/// <summary>
	/// Declare the database type info for column
	/// </summary>
	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class DBTypeAttribute: Attribute
	{
		public string TypeName;			// database type name
		public int Precision;
		public int Length;
		public int Scale;
		public int Radix;
		public bool Nullable;
		public string DBDefault;
		
		public DBTypeAttribute()
		{
		}

		public DBTypeAttribute(string TypeName)
		{
			this.TypeName = TypeName;
		}

		public DBTypeAttribute(string TypeName, int Length)
			: this(TypeName)
		{
			this.Length = Length;
		}

		#region Private Members

		#endregion

		#region Public functions

		public static DBTypeAttribute GetFromMember(MemberInfo mi)
		{
			DBTypeAttribute att = (DBTypeAttribute)DBTypeAttribute.GetCustomAttribute(mi, typeof(DBTypeAttribute));
			return att;
		}

		#endregion
	}

	#endregion

	#region WhereMapping Attribute

	/// <summary>
	/// Declares how the property/field is to be used in
	/// where clause when generating the sql statements.
	/// </summary>
	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class WhereMappingAttribute: Attribute
	{
		public WhereFlags WhereFlags = WhereFlags.InAll;
		
		public WhereMappingAttribute(WhereFlags WhereFlags)
		{
			this.WhereFlags = WhereFlags;
		}

		public bool InSelect
		{
			get { return (WhereFlags & WhereFlags.InSelect) != 0; }
		}

		public bool InUpdate
		{
			get { return (WhereFlags & WhereFlags.InUpdate) != 0; }
		}

		public bool InDelete
		{
			get { return (WhereFlags & WhereFlags.InDelete) != 0; }
		}

		public static WhereMappingAttribute GetFromMember(MemberInfo mi, bool useDefault)
		{
			WhereMappingAttribute[] attribs = (WhereMappingAttribute[])mi.GetCustomAttributes(typeof(WhereMappingAttribute), true);
			if (attribs != null)
				if (attribs.Length > 0)
					return attribs[0];

			if (useDefault)
			{
				return new WhereMappingAttribute(WhereFlags.InAll);
			}
			else
				return null;
		}
	}

	
	[Flags()]
	public enum WhereFlags
	{
		InSelect = 1,
		InUpdate = 2,
		//InInsert = 4,		// where not needed
		InDelete = 8,
		InModify = InUpdate /*| InInsert*/ | InDelete,
		InAll = InSelect | InUpdate /*| InInsert*/ | InDelete
	}

	#endregion

	#region ColumnsMappingMode Attribute

	/// <summary>
	/// Automatically map 
	/// </summary>
	[AttributeUsage(AttributeTargets.Class)]
	public class ColumnsMappingModeAttribute : Attribute
	{
		public ColumnMappingModes MappingMode = ColumnMappingModes.MappedOnly | ColumnMappingModes.NonPublic | ColumnMappingModes.Public;
		public ColumnsMappingModeAttribute()
		{
		}
		public ColumnsMappingModeAttribute(ColumnMappingModes mappingMode)
		{
			this.MappingMode = mappingMode;
		}

		public bool IsPublic
		{
			get { return (MappingMode & ColumnMappingModes.Public) != 0; }
		}

		public bool IsNonPublic
		{
			get { return (MappingMode & ColumnMappingModes.NonPublic) != 0; }
		}

		public bool IsMappedOnly
		{
			get { return (MappingMode & ColumnMappingModes.MappedOnly) != 0; }
		}

		public static ColumnsMappingModeAttribute GetFromType(Type type, bool useDefault)
		{
			ColumnsMappingModeAttribute[] attribs = (ColumnsMappingModeAttribute[])type.GetCustomAttributes(typeof(ColumnsMappingModeAttribute), true);
			if (attribs != null)
				if (attribs.Length > 0)
					return attribs[0];

			if (useDefault)
				return new ColumnsMappingModeAttribute();
			else
				return null;
		}

		public static ColumnsMappingModeAttribute GetFromType(Type type)
		{
			return GetFromType(type, true);
		}
	}

	#endregion

	#region ElementType Attribute

	/// <summary>
	/// Describes the element type for a collection.
	/// Used by the data object filler/retriever functions.
	/// </summary>
	[AttributeUsage(AttributeTargets.Class)]
	public class ElementTypeAttribute : Attribute
	{
		public Type ElemType = null;
		public ElementTypeAttribute(Type elemType)
		{
			this.ElemType = elemType;
		}

		public static ElementTypeAttribute GetFromType(Type type)
		{
			ElementTypeAttribute[] attribs = (ElementTypeAttribute[])type.GetCustomAttributes(typeof(ElementTypeAttribute), true);
			if (attribs != null)
				if (attribs.Length > 0)
					return attribs[0];
			return null;
		}

		public static ElementTypeAttribute GetFromCollection(IList collection)
		{
			Type type = collection.GetType();
			return GetFromType(type);
		}
	}

	#endregion

	#region SimpleRelation Attribute

	/// <summary>
	/// Describes the element type for a collection.
	/// Used by the data object filler/retriever functions.
	/// </summary>
	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class SimpleRelationAttribute : Attribute
	{
		public string ParentTable = null;
		public string ParentColumn = null;
		public string ChildTable = null;
		public string ChildColumn = null;

		private System.Data.DataRelation dataRel = null;

		public SimpleRelationAttribute()
		{
		}

		public SimpleRelationAttribute(string ParentTableDotColumn, string ChildTableDotColumn)
		{
			this.ParentTableDotColumn = ParentTableDotColumn;
			this.ChildTableDotColumn = ChildTableDotColumn;
		}

		/// <summary>
		/// Accesses parent's 'table.column'
		/// </summary>
		public string ParentTableDotColumn
		{
			get	{	return this.ParentTable + "." + this.ParentColumn;	}
			set	
			{	
				dataRel = null; 
				DCBase.ParseTableAndColumn(value, ref this.ParentTable, ref this.ParentColumn);	
				if (this.ParentTable == "")
					this.ParentTable = null;
			}
		}

		/// <summary>
		/// Accesses child's 'table.column'
		/// </summary>
		public string ChildTableDotColumn
		{
			get	{	return this.ChildTable + "." + this.ChildColumn;	}
			set	
			{	
				dataRel = null;
				DCBase.ParseTableAndColumn(value, ref this.ChildTable, ref this.ChildColumn);	
				if (this.ChildTable == "")
					this.ChildTable = null;
			}
		}

		/// <summary>
		/// Autmatically creates a DataRelation object and returns it.
		/// </summary>
		public System.Data.DataRelation DataRelation
		{
			get
			{
				if (dataRel != null)
					return dataRel;

				dataRel = new System.Data.DataRelation(null, 
					this.ParentTable, this.ChildTable, 
					new string[] { this.ParentColumn },
					new string[] { this.ChildColumn }, false );

				return dataRel;
			}
		}

		public static SimpleRelationAttribute GetFromMember(MemberInfo mi)
		{
			SimpleRelationAttribute[] attribs = (SimpleRelationAttribute[])mi.GetCustomAttributes(typeof(SimpleRelationAttribute), true);
			if (attribs != null)
				if (attribs.Length > 0)
					return attribs[0];

			return null;
		}
	}

	#endregion

	#region ControlType Attribute

	[Flags]
	public enum EnumControlTypes
	{
		Undeclared = 0,
		TextBox = 1,
		ComboBox = 2,
		CheckBox = 4,
		MultiCheckBox = 8,
		RadioButtonBox = 16,
		List = 32,
		FieldLabel = 64,			// shows field descriptions
		Label = 128,				// shows field content in a label
		Button = 256,
		LinkButton = 512,
		ImageButton = 1024,
		HyperLink = 2048,
		Image = 4096,
		Literal = 8192
	}

	[Flags]
	public enum EnumClientValidators
	{
		None = 0,
		Required = 1,			// required field
		String = 2,
		Integer = 4,
		Double = 8,
		Date = 16,
		Currency = 32,
		Email = 64,
		URL = 128,
		USPhoneNumber = 256,
		USSSN = 512,
		USZipCode = 1024,
		USPhoneNumberRaw = 2048,
		DateTime = 4096
	}

	// used to assign ready sets of property values to ControlType attribute.
	public enum EnumControlTypeMacros
	{
		None = 0,
		Currency = 1,
		ShortDate = 2,
		USSSN = 3,
		USZipCode = 4,
		USPhoneNumber = 5,
		Int = 6,
		IntThousands = 7,
		Double = 8,
		DoubleThousands = 9,
		Email = 10,
		URL = 11,
		Password = 12,
		USState = 13,
		Day = 14,
		Month = 15,
		Year = 16,
		YesNo = 17,
		TrueFalse = 18,
		Percent = 19,
		IntLookup = 20,
		StringLookup = 21,
		USPhoneNumberExt = 22,
		Gender = 23,
		ShortDateTime = 24
	}

	public class ClientFormatters
	{
		public const string FormatCurrency = "FormatCurrency(this.value)";
		public const string FormatPhone = "FormatPhone(this.value)";
		public const string FormatThousands = "FormatThousands(this.value)";
		public const string FormatAllUpperCase = "FormatAllUpperCase(this.value)";
		public const string FormatAllLowerCase = "FormatAllLowerCase(this.value)";
	}

	/// <summary>
	/// Declare the mapped column for a property.
	/// Used with Data object filler/retriever functions.
	/// </summary>
	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public class ControlTypeAttribute: Attribute
	{
		public EnumControlTypes ControlType = EnumControlTypes.TextBox;
		public EnumClientValidators ClientValidators = EnumClientValidators.None;
		public string ClientScriptForConditionalRequired = null;
		public string RegExValidator = null;
		public int MaxLength = 0;
		public object MinValue = null;
		public object MaxValue = null;
		public DataStereoType StereoType = DataStereoType.None;

		public string ClientFormatter=null;		// client formatter script
		public string InputMask=null;			// input mask to be used
		public bool ThousandsSeperator = false;	// only used by WebNumericEdit

		// messages to display
		public string RequiredError = null;		// error message to be used if RequiredValidator fails
		public string RangeError = null;		// error message to be used if RangeValidator fails
		public string RegExError = null;		// error message to be used if RegExValidator fails

		public object ValueForNull = null;	// default causes no value to be mapped to DBNull

		private EnumControlTypeMacros macro;

		// Declarative per-field security
		public int MinAccessToSee = 0;		// min access level to see the controls bound
		public int MinAccessToRead = 0;		// min access level to read the value
		public int MinAccessToChange = 0;		// min access level to see this
		
		public ControlTypeAttribute()
		{
		}

		public ControlTypeAttribute(EnumControlTypes ControlType)
		{
			this.ControlType = ControlType;
		}

		public ControlTypeAttribute(EnumControlTypes ControlType, int MaxLength)
			: this(ControlType)
		{
			this.MaxLength = MaxLength;
		}

		public ControlTypeAttribute(EnumControlTypes ControlType, EnumClientValidators ClientValidators)
			: this(ControlType)
		{
			this.ClientValidators = ClientValidators;
		}

		public ControlTypeAttribute(EnumControlTypes ControlType, int MaxLength, EnumClientValidators ClientValidators)
			: this(ControlType, MaxLength)
		{
			this.ClientValidators = ClientValidators;
		}

		#region Private Members

		#endregion

		#region Public functions

		public EnumControlTypeMacros Macro
		{
			get
			{
				return macro;
			}
			set
			{
				this.macro = value;
				switch(this.macro)
				{
					case EnumControlTypeMacros.Currency:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.Currency;
						this.ClientFormatter = ClientFormatters.FormatCurrency;
						this.MaxLength = 20;
						this.StereoType = DataStereoType.Currency;
						break;
					case EnumControlTypeMacros.ShortDate:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.Date;
						this.StereoType = DataStereoType.DateOnly;
						this.MaxLength = 10;
						break;
					case EnumControlTypeMacros.ShortDateTime:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.DateTime;
						this.StereoType = DataStereoType.DateTime;
						this.MaxLength = 20;
						break;
					case EnumControlTypeMacros.USSSN:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.USSSN;
						this.MaxLength = 20;
						this.StereoType = DataStereoType.USSSN;
						this.InputMask = "###-##-####";
						break;
					case EnumControlTypeMacros.USZipCode:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.USZipCode;
						this.MaxLength = 10;
						this.StereoType = DataStereoType.USZipCode;
						this.InputMask = "#####";
						break;
					case EnumControlTypeMacros.USPhoneNumber:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.USPhoneNumberRaw;
						this.ClientFormatter = ClientFormatters.FormatPhone;
						this.MaxLength = 20;
						this.StereoType = DataStereoType.USPhoneNumber;
						this.InputMask = "(###)-###-####";
						break;
					case EnumControlTypeMacros.USPhoneNumberExt:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.USPhoneNumberRaw;
						this.ClientFormatter = ClientFormatters.FormatPhone;
						this.MaxLength = 22;
						this.StereoType = DataStereoType.USPhoneNumber;
						this.InputMask = "(###)-###-#### Ext:#####";
						break;
					case EnumControlTypeMacros.Int:
						this.ControlType = EnumControlTypes.TextBox | EnumControlTypes.ComboBox;
						this.ClientValidators = EnumClientValidators.Integer;
						this.MaxLength = 15;
						this.ThousandsSeperator = false;
						break;
					case EnumControlTypeMacros.IntThousands:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.Integer;
						this.ClientFormatter = ClientFormatters.FormatThousands;
						this.ThousandsSeperator = true;
						this.MaxLength = 20;
						break;
					case EnumControlTypeMacros.IntLookup:
						this.ControlType = EnumControlTypes.ComboBox;
						//this.ClientValidators = EnumClientValidators.Integer;
						this.ValueForNull = (int)0;
						this.MaxLength = 15;
						break;
					case EnumControlTypeMacros.StringLookup:
						this.ControlType = EnumControlTypes.ComboBox;
						break;
					case EnumControlTypeMacros.Double:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.Double;
						this.MaxLength = 15;
						this.ThousandsSeperator = false;
						break;
					case EnumControlTypeMacros.DoubleThousands:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.Double;
						this.ClientFormatter = ClientFormatters.FormatThousands;
						this.ThousandsSeperator = true;
						this.MaxLength = 20;
						break;
					case EnumControlTypeMacros.Email:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.Email;
						this.StereoType = DataStereoType.Email;
						break;
					case EnumControlTypeMacros.URL:
						this.ControlType = EnumControlTypes.TextBox;
						this.ClientValidators = EnumClientValidators.URL;
						this.StereoType = DataStereoType.URL;
						break;
					case EnumControlTypeMacros.Password:
						this.ControlType = EnumControlTypes.TextBox;
						this.StereoType = DataStereoType.Password;
						break;
					case EnumControlTypeMacros.USState:
						this.ControlType = EnumControlTypes.ComboBox | EnumControlTypes.TextBox;
						this.StereoType = DataStereoType.USState;
						this.MaxLength = 2;
						this.InputMask = ">LL";
						break;
					case EnumControlTypeMacros.Gender:
						this.ControlType = EnumControlTypes.ComboBox | EnumControlTypes.TextBox;
						this.StereoType = DataStereoType.Gender;
						this.MaxLength = 1;
						this.InputMask = ">L";
						break;
					case EnumControlTypeMacros.Day:
						this.ControlType = EnumControlTypes.ComboBox | EnumControlTypes.TextBox;
						this.StereoType = DataStereoType.Day;
						this.MaxLength = 2;
						this.InputMask = "##";
						break;
					case EnumControlTypeMacros.Month:
						this.ControlType = EnumControlTypes.ComboBox | EnumControlTypes.TextBox;
						this.StereoType = DataStereoType.Month;
						this.InputMask = "##";
						break;
					case EnumControlTypeMacros.Year:
						this.ControlType = EnumControlTypes.ComboBox | EnumControlTypes.TextBox;
						this.StereoType = DataStereoType.Year;
						this.MaxLength = 4;
						this.InputMask = "####";
						break;
					case EnumControlTypeMacros.YesNo:
						this.ControlType = EnumControlTypes.ComboBox | EnumControlTypes.CheckBox | EnumControlTypes.TextBox;
						this.StereoType = DataStereoType.YesNo;
						this.MaxLength = 5;
						break;
					case EnumControlTypeMacros.TrueFalse:
						this.ControlType = EnumControlTypes.ComboBox | EnumControlTypes.CheckBox | EnumControlTypes.TextBox;
						this.StereoType = DataStereoType.TrueFalse;
						this.MaxLength = 7;
						break;
					case EnumControlTypeMacros.Percent:
						this.ControlType = EnumControlTypes.TextBox|EnumControlTypes.ComboBox;
						this.ClientValidators = EnumClientValidators.Double;
						this.ClientFormatter = ClientFormatters.FormatThousands;
						this.MaxLength = 10;
						this.ThousandsSeperator = false;
						this.StereoType = DataStereoType.Percent;
						break;
				}
			}
		}

		public string GetDateFormattingString()
		{
			switch (this.StereoType)
			{
				case DataStereoType.DateOnly:
					return "MM/dd/yyyy";
				case DataStereoType.TimeOnly:
					return "HH:MM";
				case DataStereoType.DateTime:
					return "MM/dd/yyy hh:mm";
				default:
					return null;		// not date or time
			}
		}

		public bool IsRequired
		{
			get { return (ClientValidators & EnumClientValidators.Required) != 0; }
			set 
			{ 
				if (value)
					ClientValidators |= EnumClientValidators.Required;
				else
					ClientValidators ^= EnumClientValidators.Required;
			}
		}

		public static ControlTypeAttribute GetFromProp(Type type, string memberName, bool useDefault)
		{
			PropertyInfo pi = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (pi != null)
				return GetFromProp(pi, useDefault);
			if (useDefault)
				return new ControlTypeAttribute();
			else
				return null;
		}

		public static ControlTypeAttribute GetFromProp(PropertyInfo pi, bool useDefault)
		{
			if (pi == null)
				return new ControlTypeAttribute();
			ControlTypeAttribute att = (ControlTypeAttribute)ControlTypeAttribute.GetCustomAttribute(pi, typeof(ControlTypeAttribute));
			if (att == null)
				if (useDefault)
					att = new ControlTypeAttribute();
			if (att != null)
				if (att.ValueForNull == null)
				{
					// determine valuefornull automatically from member type
					Type memberType = pi.PropertyType;
					if (memberType != null)
						att.ValueForNull = ColumnMappingAttribute.DetermineValueForNull(memberType);
				}
			return att;
		}

		public static EnumControlTypes GetControlType(PropertyInfo pi)
		{
			return GetControlType(pi, true);
		}

		public static EnumControlTypes GetControlType(PropertyInfo pi, bool useDefault)
		{
			ControlTypeAttribute att = (ControlTypeAttribute)ControlTypeAttribute.GetCustomAttribute(pi, typeof(ControlTypeAttribute));
			if (att == null || att.ControlType == EnumControlTypes.Undeclared)
			{
				if (useDefault)
					return EnumControlTypes.TextBox;
				else
					return EnumControlTypes.Undeclared;
			}
			else
				return att.ControlType;
		}

		public static object GetValueForNull(PropertyInfo pi)
		{
			return ControlTypeAttribute.GetFromProp(pi, true).ValueForNull;
		}

		public static void SetMemberValueFromString(object obj, PropertyInfo pi, string sval)
		{
			if (sval == null || sval == "")
				pi.SetValue(obj, ControlTypeAttribute.GetFromProp(pi, true).ValueForNull, null);
			else
				pi.SetValue(obj, Convert.ChangeType(sval, pi.PropertyType), null);
		}

		public static object GetMemberValueForDB(object obj, PropertyInfo pi)
		{
			object val = pi.GetValue(obj, null);
			if (val == null)
				return DBNull.Value;
			if (val.Equals(ControlTypeAttribute.GetFromProp(pi, true).ValueForNull))
				return DBNull.Value;
			return val;
		}

		public static object GetMemberValueUseNull(object obj, PropertyInfo pi)
		{
			object val = GetMemberValueForDB(obj, pi);
			return val is DBNull ? null : val;
		}

		public static void SetMemberValueFromDB(object obj, PropertyInfo pi, object val)
		{
			if (val == null || val == DBNull.Value)
				pi.SetValue(obj, ControlTypeAttribute.GetFromProp(pi, true).ValueForNull, null);
			else
				pi.SetValue(obj, Convert.ChangeType(val, pi.PropertyType), null);
		}

		public static string GetMemberValueAsString(object obj, PropertyInfo pi)
		{
			object val = pi.GetValue(obj, null);
			if (val == null)
				return "";
			ControlTypeAttribute ctlTypeAtt = ControlTypeAttribute.GetFromProp(pi, true);
			if (val.Equals(ctlTypeAtt.ValueForNull))
				return "";
			if (val is DateTime)
			{
				string fmtStr = ctlTypeAtt.GetDateFormattingString();
				return ((DateTime)val).ToString(fmtStr);
			}
			return Convert.ToString(val);
		}

		public static string GetMemberValueAsString(object obj, string property)
		{
			PropertyInfo pi = obj.GetType().GetProperty(property);
			return GetMemberValueAsString(obj, pi);
		}

		public bool IsUndeclared
		{
			get { return (ControlType & EnumControlTypes.Undeclared) != 0; }
		}

		public bool IsTextBox
		{
			get { return (ControlType & EnumControlTypes.TextBox) != 0; }
		}

		public bool IsComboBox
		{
			get { return (ControlType & EnumControlTypes.ComboBox) != 0; }
		}

		public bool IsFieldLabel
		{
			get { return (ControlType & EnumControlTypes.FieldLabel) != 0; }
		}

		public bool IsLabel
		{
			get { return (ControlType & EnumControlTypes.Label) != 0; }
		}

		public bool IsList
		{
			get { return (ControlType & EnumControlTypes.List) != 0; }
		}

		public bool IsRadioButtonBox
		{
			get { return (ControlType & EnumControlTypes.RadioButtonBox) != 0; }
		}

		public bool IsCheckBox
		{
			get { return (ControlType & EnumControlTypes.CheckBox) != 0; }
		}

		public bool IsMultiCheckBox
		{
			get { return (ControlType & EnumControlTypes.MultiCheckBox) != 0; }
		}

		public bool IsButton
		{
			get { return (ControlType & EnumControlTypes.Button) != 0; }
		}

		public static System.Array GetFieldValues(object sourceObject, MemberInfo mi)
		{
			Array vals = FieldValuesMemberAttribute.GetFieldValues(sourceObject, mi);
			if (vals == null)
			{
				PropertyInfo pi = mi as PropertyInfo;
				if (pi != null)
				{
					ControlTypeAttribute ctlType = ControlTypeAttribute.GetFromProp(pi, false);
					if (ctlType != null)
					{
						switch (ctlType.StereoType)
						{
							case DataStereoType.USState:
								return NSGlobal.StatesAndNames;
							case DataStereoType.Gender:
								return NSGlobal.GenderCodesAndNames;
							case DataStereoType.Day:
								return NSGlobal.Days;
							case DataStereoType.Month:
								return NSGlobal.MonthsAndNames;
							case DataStereoType.Year:
								return NSGlobal.Years;
							case DataStereoType.YesNo:
								return NSGlobal.YesNo;
							case DataStereoType.TrueFalse:
								return NSGlobal.TrueFalse;
						}
					}
				}
			}
			return vals;
		}

		#endregion
	}

	#endregion

	#region TableMapping Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class TableMappingAttribute : Attribute
	{
		public string TableName;
		public string PKMemberName;
		public bool InsertPK;
		public bool UseJoinColumns = false;

		public TableMappingAttribute(string TableName)
			: this(TableName, null, false)
		{
		}

		public TableMappingAttribute(string PKMemberName, bool InsertPK)
			: this(null, PKMemberName, InsertPK)
		{
		}

		public TableMappingAttribute(string TableName, string PKMemberName)
			: this(TableName, PKMemberName, false)
		{
		}

		public TableMappingAttribute(string TableName, string PKMemberName, bool InsertPK)
		{
			this.TableName = TableName;
			this.PKMemberName = PKMemberName;
			this.InsertPK = InsertPK;
		}

		public static TableMappingAttribute GetFromType(Type type)
		{
			TableMappingAttribute[] attribs = (TableMappingAttribute[])type.GetCustomAttributes(typeof(TableMappingAttribute), true);
			if (attribs != null)
				if (attribs.Length > 0)
					return attribs[0];

			return null;
		}

		public static TableMappingAttribute GetFromObject(object obj)
		{
				Type type = obj.GetType();
			return GetFromType(type);
		}

		public static TableMappingAttribute GetFromCollection(IList collection)
		{
			Type type = collection.GetType();
			ElementTypeAttribute elemType = ElementTypeAttribute.GetFromCollection(collection);
			if (elemType.ElemType == null)
				throw new ArgumentException(String.Format("The collection class {0} must provide an element type!", type.Name));
			return GetFromType(elemType.ElemType);
		}

		public static string GetPKMemberFromClass(Type type)
		{
			TableMappingAttribute tmAtt = TableMappingAttribute.GetFromType(type);
			if (tmAtt == null)
				return null;
			else
				return tmAtt.PKMemberName;
		}

		public static string GetPKMemberFromObject(object obj)
		{
			return GetPKMemberFromClass(obj.GetType());
		}

		public static string GetPKColumnFromClass(Type type)
		{
			string pkMemberName = GetPKMemberFromClass(type);
			if (pkMemberName == null)
				return null;
			else
			{
				return ColumnMappingAttribute.GetColumnNameForMember(type, pkMemberName);
			}
		}

		public static string GetPKColumnFromObject(object obj)
		{
			return GetPKColumnFromClass(obj.GetType());
		}

		public string GetTableNameForType(Type type)
		{
			return TableName;

			/*  // No defaults for table mapping!
			if (TableName != null)
				return TableName;

			return type.Name;*/
		}

		public static string GetTableNameFromClass(Type type, bool useDefault)
		{
			TableMappingAttribute tm = GetFromType(type);
			string tableName = null;
			if (tm != null)
				tableName = tm.TableName;

			if (tableName != null)
				return tableName;

			if (useDefault)
				return type.Name;
			else
				return null;
		}

		public static string GetTableNameFromClass(Type type)
		{
			return GetTableNameFromClass(type, true);
		}

		public static string GetTableNameFromObject(object obj, bool useDefault)
		{
			return GetTableNameFromClass(obj.GetType(), useDefault);
		}

		public static string GetTableNameFromObject(object obj)
		{
			return GetTableNameFromClass(obj.GetType());
		}

		public static string GetPKColumns(Type type)
		{
			string memberName = GetPKMemberFromClass(type);
			if (memberName == null)
				return null;
			string[] PK = memberName.Split(',');
			string[] PKCols = new string[PK.Length];
			for (int i = 0; i < PK.Length; i++)
				PKCols[i] = ColumnMappingAttribute.GetColumnNameForMember(type, PK[i]);
			return String.Join(",", PKCols);
		}

		public static object[] GetPKMemberVals(object obj)
		{
			Type type = obj.GetType();
			string memberName = GetPKMemberFromClass(type);
			string[] PK = memberName.Split(',');
			object[] vals = new object[PK.Length];
			for (int i = 0; i < PK.Length; i++)
				vals[i] = ReflectionHelper.GetMemberValue(obj, PK[i], true);
			return vals;
			/*
			Type type = obj.GetType();
			string memberName = GetPKMemberFromClass(type);
			FieldInfo fi = type.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (fi != null)
				return fi.GetValue(obj);

			PropertyInfo pi = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (pi != null)
				return pi.GetValue(obj, null);

			return DBNull.Value;*/
		}

		public static void SetPKMemberVal(object obj, object value)
		{
			Type type = obj.GetType();
			string memberName = GetPKMemberFromClass(type);
			ReflectionHelper.SetMemberValue(obj, memberName, value);
			/*
			Type type = obj.GetType();
			string memberName = GetPKMemberFromClass(type);
			FieldInfo fi = type.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (fi != null)
			{
				object val = Convert.ChangeType(value, fi.FieldType);
				fi.SetValue(obj, val);
				return;
			}

			PropertyInfo pi = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (pi != null)
			{
				object val = Convert.ChangeType(value, pi.PropertyType);
				pi.SetValue(obj, val, null);
				return;
			}*/
		}


	}

	#endregion

	#region BackPage Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class BackPageAttribute : Attribute
	{
		public string backPage;

		public BackPageAttribute(string backPage)
		{
			this.backPage = backPage;
		}

		public BackPageAttribute(Type pageClass)
		{
			this.backPage = ReflectionHelper.GetPageNameFromClass(pageClass);
		}

		public static BackPageAttribute GetFromType(Type type)
		{
			BackPageAttribute att = (BackPageAttribute)BackPageAttribute.GetCustomAttribute(type, typeof(BackPageAttribute));
			return att;
		}

		public static string GetBackPageFromType(Type type)
		{
			BackPageAttribute att = BackPageAttribute.GetFromType(type);
			if (att != null)
				return att.backPage;
			else
				return null;
		}

	}

	#endregion

	#region TableLinkage Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class TableLinkageAttribute : Attribute
	{
		public Type LeftClass;
		public Type RightClass;
		public string LeftClassMember;
		public string RightClassMember;

		public TableLinkageAttribute(Type LeftClass, string LeftClassMember, Type RightClass, string RightClassMember)
		{
			this.LeftClass = LeftClass;
			this.LeftClassMember = LeftClassMember;
			this.RightClass = RightClass;
			this.RightClassMember = RightClassMember;
		}

		public static TableLinkageAttribute GetFromType(Type type)
		{
			TableLinkageAttribute att = (TableLinkageAttribute)TableLinkageAttribute.GetCustomAttribute(type, typeof(TableLinkageAttribute));
			return att;
		}

	}

	#endregion

	#region CachingKey Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class CachingKeyAttribute : Attribute
	{
		public string cachingKey;

		public CachingKeyAttribute(string cachingKey)
		{
			this.cachingKey = cachingKey;
		}

		public static CachingKeyAttribute GetFromType(Type type)
		{
			CachingKeyAttribute att = (CachingKeyAttribute)CachingKeyAttribute.GetCustomAttribute(type, typeof(CachingKeyAttribute));
			return att;
		}

		public static string GetCachingKeyFromType(Type type, bool useDefault)
		{
			CachingKeyAttribute att = CachingKeyAttribute.GetFromType(type);
			if (att == null)
			{
				if (useDefault)
					return type.FullName;
				else
					return null;
			}
			else
				return att.cachingKey;
		}

	}

	#endregion

	#region MainDataClass Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class MainDataClassAttribute : Attribute
	{
		public string ClassName;

		public MainDataClassAttribute(string ClassName)
		{
			this.ClassName = ClassName;
		}

		public static MainDataClassAttribute GetFromType(Type type)
		{
			MainDataClassAttribute att = (MainDataClassAttribute)MainDataClassAttribute.GetCustomAttribute(type, typeof(MainDataClassAttribute));
			return att;
		}

		public static string GetMainDataClassFromType(Type type)
		{
			MainDataClassAttribute att = MainDataClassAttribute.GetFromType(type);
			if (att == null)
				return null;
			else
				return att.ClassName;
		}

		public static bool GetMainDataClassFromType(Type type, ref string assemblyName, ref string className)
		{
			MainDataClassAttribute att = MainDataClassAttribute.GetFromType(type);
			if (att == null)
				return false;
			else
			{
				string dataClass = att.ClassName;
				if (dataClass == null)
					return false;
				string[] terms = dataClass.Split(',');
				if (terms.Length > 0)
					assemblyName = terms[1].Trim();
				else
					assemblyName = type.Assembly.FullName;
				className = terms[0].Trim();
				return true;
			}
		}

	}

	#endregion

	#region MainLanguageClass Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class MainLanguageClassAttribute : Attribute
	{
		public string ClassName;

		public MainLanguageClassAttribute(string ClassName)
		{
			this.ClassName = ClassName;
		}

		public static MainLanguageClassAttribute GetFromType(Type type)
		{
			MainLanguageClassAttribute att = (MainLanguageClassAttribute)MainLanguageClassAttribute.GetCustomAttribute(type, typeof(MainLanguageClassAttribute), true);
			return att;
		}

		public static string GetMainLanguageClassFromType(Type type)
		{
			MainLanguageClassAttribute att = MainLanguageClassAttribute.GetFromType(type);
			if (att == null)
				return null;
			else
				return att.ClassName;
		}

		public static bool GetMainLanguageClassFromType(Type type, ref string assemblyName, ref string className)
		{
			MainLanguageClassAttribute att = MainLanguageClassAttribute.GetFromType(type);
			if (att == null)
				return false;
			else
			{
				string dataClass = att.ClassName;
				if (dataClass == null)
					return false;
				string[] terms = dataClass.Split(',');
				if (terms.Length > 0)
					assemblyName = terms[1].Trim();
				else
					assemblyName = type.Assembly.FullName;
				className = terms[0].Trim();
				if (className.IndexOf('.') < 0)
					className = assemblyName + "." + className;
				return true;
			}
		}

	}

	#endregion

	#region SQLHint Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class SQLHintAttribute : Attribute
	{
		public string columns;

		public SQLHintAttribute(string columns)
		{
			this.columns = columns;
		}

		public static SQLHintAttribute GetFromType(Type type)
		{
			SQLHintAttribute[] attribs = (SQLHintAttribute[])type.GetCustomAttributes(typeof(SQLHintAttribute), true);
			if (attribs != null)
				if (attribs.Length > 0)
					return attribs[0];

			return null;
		}

		public static SQLHintAttribute GetFromObject(object obj)
		{
			Type type = obj.GetType();
			return GetFromType(type);
		}

	}

	#endregion

	#region SPDeclarationAttribute Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class SPDeclarationAttribute : Attribute
	{
		public string spName;

		public SPDeclarationAttribute(string spName)
		{
			this.spName = spName;
		}

		public static SPDeclarationAttribute GetFromType(Type attribType, Type type)
		{
			SPDeclarationAttribute[] attribs = (SPDeclarationAttribute[])type.GetCustomAttributes(attribType, true);
			if (attribs != null)
				if (attribs.Length > 0)
					return attribs[0];

			return null;
		}

		public static string GetSPFromType(Type attribType, Type type)
		{
			SPDeclarationAttribute spAtt = SPDeclarationAttribute.GetFromType(attribType, type);
			if (spAtt == null)
				return null;
			else
				return spAtt.spName;
		}

	}

	#endregion

	#region SPLoadAttribute Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class SPLoadAttribute : SPDeclarationAttribute
	{
		public SPLoadAttribute(string loadProcedure)
			: base(loadProcedure)
		{
		}

		public static SPDeclarationAttribute GetFromType(Type type)
		{
			return GetFromType(typeof(SPLoadAttribute), type);
		}

		public static string GetSPFromType(Type type)
		{
			return GetSPFromType(typeof(SPLoadAttribute), type);
		}
	}

	#endregion

	#region SPUpdateAttribute Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class SPUpdateAttribute : SPDeclarationAttribute
	{
		public SPUpdateAttribute(string updateProcedure)
			: base(updateProcedure)
		{
		}

		public static SPDeclarationAttribute GetFromType(Type type)
		{
			return GetFromType(typeof(SPUpdateAttribute), type);
		}

		public static string GetSPFromType(Type type)
		{
			return GetSPFromType(typeof(SPUpdateAttribute), type);
		}
	}

	#endregion

	#region SPInsertAttribute Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class SPInsertAttribute : SPDeclarationAttribute
	{
		public SPInsertAttribute(string insertProcedure)
			: base(insertProcedure)
		{
		}

		public static SPDeclarationAttribute GetFromType(Type type)
		{
			return GetFromType(typeof(SPInsertAttribute), type);
		}

		public static string GetSPFromType(Type type)
		{
			return GetSPFromType(typeof(SPInsertAttribute), type);
		}
	}

	#endregion

	#region SPDeleteAttribute Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class SPDeleteAttribute : SPDeclarationAttribute
	{
		public SPDeleteAttribute(string deleteProcedure)
			: base(deleteProcedure)
		{
		}

		public static SPDeclarationAttribute GetFromType(Type type)
		{
			return GetFromType(typeof(SPDeleteAttribute), type);
		}

		public static string GetSPFromType(Type type)
		{
			return GetSPFromType(typeof(SPDeleteAttribute), type);
		}
	}

	#endregion

	#region SPExistsAttribute Attribute

	[AttributeUsage(AttributeTargets.Class)]
	public class SPExistsAttribute : SPDeclarationAttribute
	{
		public SPExistsAttribute(string existsProcedure)
			: base(existsProcedure)
		{
		}

		public static SPDeclarationAttribute GetFromType(Type type)
		{
			return GetFromType(typeof(SPExistsAttribute), type);
		}

		public static string GetSPFromType(Type type)
		{
			return GetSPFromType(typeof(SPExistsAttribute), type);
		}
	}

	#endregion

	#region SPLoadChildAttribute Attribute

	[AttributeUsage(AttributeTargets.Property)]
	public class SPLoadChildAttribute : SPDeclarationAttribute
	{
		public string FKMembers;

		public SPLoadChildAttribute(string loadProcedure, string FKMembers)
			: base(loadProcedure)
		{
			this.FKMembers = FKMembers;
		}

		public string[] GetFKMembers()
		{
			if (FKMembers == null)
				return null;
			return FKMembers.Split(',');
		}

		public static SPLoadChildAttribute GetFromMember(MemberInfo mi)
		{
			return (SPLoadChildAttribute)SPLoadChildAttribute.GetCustomAttribute(mi, typeof(SPLoadChildAttribute), true);
		}

		public static SPLoadChildAttribute GetFromPropInfo(PropertyInfo pi)
		{
			return (SPLoadChildAttribute)SPLoadChildAttribute.GetCustomAttribute(pi, typeof(SPLoadChildAttribute), true);
		}

		public static SPLoadChildAttribute GetFromProp(Type type, string propName)
		{
			PropertyInfo pi = type.GetProperty(propName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			return GetFromPropInfo(pi);
		}

		public static SPLoadChildAttribute GetFromProp(object obj, string propName)
		{
			if (obj == null)
				return null;
			return GetFromProp(obj.GetType(), propName);
		}

	}

	#endregion

	#region SPAutoGen Attribute

	[AttributeUsage(AttributeTargets.Class, AllowMultiple=true)]
	public class SPAutoGen : Attribute
	{
		public string spName;
		public string spTemplate;
		public string teplateArgs;
		public string InjectPreOperation;			// something to be executed before the main part of the sp
		public string InjectPostOperation;			// something to be executed before the main part of the sp
		public string InjectWhere;					// something to be injected into the where clause
		public string InjectParameters;					// something to be injected into the where clause
		public string InjectOrderBy;					// something to be injected into the orderby clause

		public SPAutoGen(string spName, string spTemplate)
		{
			this.spName = spName;
			this.spTemplate = spTemplate;
		}

		public SPAutoGen(string spName, string spTemplate, string templateArgs)
		{
			this.spName = spName;
			this.spTemplate = spTemplate;
			this.teplateArgs = teplateArgs;
		}

		public static SPAutoGen GetFromType(Type type)
		{
			return (SPAutoGen)SPAutoGen.GetCustomAttribute(type, typeof(SPAutoGen));
		}

	}

	#endregion

	#region Contained Attribute

	public class ContainedAttribute : Attribute
	{
		public ContainedAttribute()
		{
		}

		public static ContainedAttribute GetFromMember(MemberInfo mi)
		{
			return (ContainedAttribute)ContainedAttribute.GetCustomAttribute(mi, typeof(ContainedAttribute), true);
		}
	}

	#endregion

	#region LanguageTable Attribute

	/// <summary>
	/// Declare a language class using on a language table with this attribute.
	/// </summary>
	public class LanguageTableAttribute : Attribute
	{
		public string TableName;
		public string MsgIDcolumn;
		public string LangIDcolumn;
		public string MessageColumn;

		public LanguageTableAttribute(string TableName, string MsgIDcolumn, string LangIDcolumn, string MessageColumn)
		{
			this.TableName = TableName;
			this.MsgIDcolumn = MsgIDcolumn;
			this.LangIDcolumn = LangIDcolumn;
			this.MessageColumn = MessageColumn;
		}

		public static LanguageTableAttribute GetFromType(Type type)
		{
			LanguageTableAttribute[] attribs = (LanguageTableAttribute[])type.GetCustomAttributes(typeof(LanguageTableAttribute), true);
			if (attribs != null)
				if (attribs.Length > 0)
					return attribs[0];

			return null;
		}

	}

	#endregion
	
	#region SelectedMenuItem Attribute
	[AttributeUsage(AttributeTargets.Class)]
	public class SelectedMenuItemAttribute : Attribute
	{
		private string menuItem;

		public string MenuItem
		{
			get
			{
				return menuItem;
			}
			set
			{
				menuItem = value;
			}
		}
		public SelectedMenuItemAttribute(string menu)
		{
			this.menuItem = menu;
		}

		public static SelectedMenuItemAttribute GetFromType(Type type)
		{
			SelectedMenuItemAttribute[] attribs = (SelectedMenuItemAttribute[])type.GetCustomAttributes(typeof(SelectedMenuItemAttribute), true);
			if (attribs != null)
				if (attribs.Length > 0)
					return attribs[0];

			return null;
		}

		public static string GetMenuItemFromType(Type type)
		{
			SelectedMenuItemAttribute attrib = GetFromType(type);
			if(attrib != null)
				return attrib.MenuItem;
			else
				return null;
		}
		public static SelectedMenuItemAttribute GetFromObject(object obj)
		{
			Type type = obj.GetType();
			return GetFromType(type);
		}
	}
	#endregion

	#region SelectedMenuItem Attribute
	[AttributeUsage(AttributeTargets.Class)]
	public class SelectedMainMenuItemAttribute : Attribute
	{
		private string menuItem;

		public string MenuItem
		{
			get
			{
				return menuItem;
			}
			set
			{
				menuItem = value;
			}
		}
		public SelectedMainMenuItemAttribute(string menu)
		{
			this.menuItem = menu;
		}

		public static SelectedMainMenuItemAttribute GetFromType(Type type)
		{
			SelectedMainMenuItemAttribute[] attribs = (SelectedMainMenuItemAttribute[])type.GetCustomAttributes(typeof(SelectedMainMenuItemAttribute), true);
			if (attribs != null)
				if (attribs.Length > 0)
					return attribs[0];

			return null;
		}

		public static string GetMenuItemFromType(Type type)
		{
			SelectedMainMenuItemAttribute attrib = GetFromType(type);
			if(attrib != null)
				return attrib.MenuItem;
			else
				return null;
		}
		public static SelectedMainMenuItemAttribute GetFromObject(object obj)
		{
			Type type = obj.GetType();
			return GetFromType(type);
		}
	}
	#endregion

}
