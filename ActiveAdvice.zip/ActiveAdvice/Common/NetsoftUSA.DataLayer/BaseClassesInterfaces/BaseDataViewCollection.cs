using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Summary description for DataViewCollectionBase.
	/// </summary>
	public class BaseDataViewCollection : IEnumerable
	{
		protected DataView dv;

		public BaseDataViewCollection()
		{
		}

		#region IEnumerable Members

		public IEnumerator GetEnumerator()
		{
			return new DataViewCollectionEnumerator(this);
		}

		#endregion

		#region ICollection Members

		public int Count
		{
			get { return dv.Count; }
		}

		public void CopyTo(System.Array array, int index)
		{
			for (int i = index; i < this.Count; i++)
			{
				array.SetValue(this.GetItem(i, false),  i - index);
			}
		}

		/*public bool IsSynchronized
		{
			get { return true; }
		}

		public object SyscRoot
		{
			get { return dv.Table.DataSet.;
		}*/

		#endregion

		internal class DataViewCollectionEnumerator : IEnumerator
		{
			private BaseDataViewCollection dvc;
			private object currentElem;
			int i = 0;

			public DataViewCollectionEnumerator(BaseDataViewCollection dvc)
			{
				this.dvc = dvc;
			}

			#region IEnumerator Members

			public void Reset()
			{
				i = 0;
			}

			public object Current
			{
				get
				{
					return currentElem;
				}
			}

			public bool MoveNext()
			{
				if (i + 1 >= dvc.Count)
					return false;
				i++;
				currentElem = dvc.GetItem(i, false);
				return true;
			}

			#endregion

		}

		// --------------------------------

		protected void FillIntoObject(int i, object obj, bool collections)
		{
			DataViewFiller.FillIntoObject(dv[i], obj, true, collections);
		}

		protected void FillFromObject(int i, object obj, bool collections)
		{
			DataViewFiller.FillFromObject(dv[i], obj, true, collections);
		}

		protected object NewElem()
		{
			ElementTypeAttribute elemTypeAttrib = ElementTypeAttribute.GetFromType(this.GetType());
			if (elemTypeAttrib == null)
				throw new ArgumentException("The collection class {0} must provide an ElementType attribute!", this.GetType().Name);

			return Activator.CreateInstance(elemTypeAttrib.ElemType);
		}

		protected object GetItem(int i, bool collections)
		{
			object obj = NewElem();
			FillIntoObject(i, obj, collections);
			return obj;
		}

		protected void SetItem(int i, object obj, bool collections)
		{
			FillFromObject(i, obj, collections);
		}

		public DataRowView GetRowView(int i)
		{
			return dv[i];
		}
		
		// --------------------------------
		#region Public members

		public DataView DataView
		{	get	{ return this.dv; }
			set { this.dv = value; }
		}

		#endregion

	}

	
}
