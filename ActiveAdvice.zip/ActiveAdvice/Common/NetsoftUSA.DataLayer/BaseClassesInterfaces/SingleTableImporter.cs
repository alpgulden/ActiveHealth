using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Collections;
using System.Text.RegularExpressions;

namespace NetsoftUSA.DataLayer
{
	#region Exception classes
	public class ImportCancelAllException : Exception
	{
		public ImportCancelAllException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		public ImportCancelAllException(string message)
			: base(message)
		{
		}
	}
	#endregion

	#region EventArgs classes
	public class ImportEventArgs : EventArgs
	{
		public bool cancelDefault = false;
		public bool cancelAll = false;
		public int lineNum;
		public ImportEventArgs(int lineNum)
		{
			this.lineNum = lineNum;
		}
	}

	public class BeforeImportEventArgs : ImportEventArgs
	{
		public string[] valueStrings;

		public BeforeImportEventArgs(int lineNum, string[] valueStrings)
			: base(lineNum)
		{
			this.valueStrings = valueStrings;
		}
	}

	public class RowInsertEventArgs : ImportEventArgs
	{
		public SqlCommand insertCommand;
		public string[] valueStrings;

		public RowInsertEventArgs(int lineNum, string[] valueStrings, SqlCommand insertCommand)
			: base(lineNum)
		{
			this.insertCommand = insertCommand;
			this.valueStrings = valueStrings;
		}
	}

	public class RowInsertErrorEventArgs : ImportEventArgs
	{
		public Exception exception;
		public string errorMsg;

		public RowInsertErrorEventArgs(int lineNum, string errorMsg, Exception exception)
			: base(lineNum)
		{
			this.errorMsg = errorMsg;
			this.exception = exception;
		}
	}
	#endregion

	/// <summary>
	/// Single table importers should derive from this
	/// </summary>
	public abstract class SingleTableImporter : BaseFileImporter
	{
		#region Events
		public delegate void ImportStartedHandler(object sender, ImportEventArgs e);
		public event SingleTableImporter.ImportStartedHandler ImportStarted;

		public delegate void RowInsertErrorEventHandler(object sender, RowInsertErrorEventArgs e);
		public event SingleTableImporter.RowInsertErrorEventHandler RowInsertErrorEvent;

		public delegate void BeforeInsertHandler(object sender, BeforeImportEventArgs e);
		public event SingleTableImporter.BeforeInsertHandler BeforeInsert;

		public delegate void RowInsertEventHandler(object sender, RowInsertEventArgs e);
		public event SingleTableImporter.RowInsertEventHandler RowInsertEvent;

		#endregion

		#region Protected members

		//protected static char[] formatChars = new char[] { '@', '#' };

		protected string targetTable;		// table to be inserted
		protected string[] targetColumns;		// columns to be inserted
		protected string[] textColumns;			// those items that are not extra

		protected Hashtable columnFormats = new Hashtable();		// formats for columns
		// these are created after InitializeImport
		protected Hashtable columnIndices;		// What is the index of column for a given name?
		protected SqlCommand command;			// sql command generated for given table
		protected string[] validColumns;		// valid columns to be used in the insert
		protected DataTable schemaTable;		// this is an empty table contaning column info

		#endregion

		#region Constructors
		public SingleTableImporter() : base()
		{
		}
		#endregion

		#region Virtual functions that can be overridden
		
		protected virtual bool OnImportStarted()
		{
			if (ImportStarted != null)
			{
				ImportEventArgs e = new ImportEventArgs(-1);
				ImportStarted(this, e);
				if (e.cancelAll)
					return false;
			}
			return true;
		}

		protected virtual void OnRowInsertError(int lineNum, Exception ex)
		{
			string s = String.Format("<b>{0}</b> Line Number <b>{1}</b> -->  {2}", this.GetType().ToString(), lineNum, ex.Message);

			numErrors++;

			if (RowInsertErrorEvent != null)
			{
				RowInsertErrorEventArgs e = new RowInsertErrorEventArgs(lineNum, s, ex);
				RowInsertErrorEvent(this, e);
				if (e.cancelAll)
					throw new ImportCancelAllException("Import cancelled at line " + lineNum);
				if (e.cancelDefault)
					return;
			}
			Trace.WriteLine(s, "RowInsertError");
		}

		protected virtual bool OnBeforeInsert(int lineNum, string[] valueStrings)
		{
			if (BeforeInsert != null)
			{
				BeforeImportEventArgs e = new BeforeImportEventArgs(lineNum, valueStrings);
				BeforeInsert(this, e);
				if (e.cancelAll)
					throw new ImportCancelAllException("Import cancelled at line " + lineNum);
				return !e.cancelDefault;
			}
			else
				return true;
		}

		protected virtual bool OnRowInsert(int lineNum, string[] valueStrings, SqlCommand insertCommand)
		{
			if (RowInsertEvent != null)
			{
				RowInsertEventArgs e = new RowInsertEventArgs(lineNum, valueStrings, insertCommand);
				RowInsertEvent(this, e);
				if (e.cancelAll)
					throw new ImportCancelAllException("Import cancelled at line " + lineNum);
				return !e.cancelDefault;
			}
			else
				return true;
		}

		#endregion

		#region Protected helper functions to be used by the deriving classes

		protected bool InitializeImport()
		{
			numErrors = 0;
			schemaTable = GetTableDefinition(targetTable);
			validColumns = GetValidColumns(schemaTable, targetColumns);
			command = CreateInsertStatement(schemaTable, validColumns);
			command.Connection = connection;
			connection.Open();

			// Prepare column indices
			columnIndices = new Hashtable();
			for (int i = 0; i < targetColumns.Length; i++)
			{
				columnIndices[targetColumns[i]] = i;
			}

			// Detect substitutable columns
			// we may correct adding normal/extra columns here.
			ArrayList arrTextColumns = new ArrayList();
			for (int i = 0; i < targetColumns.Length; i++)
			{
				bool bSubs = false;
				string colName = targetColumns[i];
				string[] formats = (string[])columnFormats[colName];
				if (formats != null)
				{
					if (formats.Length > 0)
					{
						string format = formats[0];
						if (format.IndexOf("@") >= 0)
						{
							// substitutable items!
							bSubs = true;
						}
					}
				}

				if (!bSubs)
					arrTextColumns.Add(colName);
			}
			// all those columns that must be read from the text!
			textColumns = (string[])arrTextColumns.ToArray(typeof(string));

			// fire import started event
			return OnImportStarted();
				
		}

		protected string ProcessFormattedColumn(string[] valueStrings, string format)
		{
			if (format == null)
				return "";
			/*if (format.Substring(0, 2) == "@=")	// default value definition
			{
				return format.Substring(2);	// return whatever is after :
			}*/

			string quot = "\"";
			Regex regex = new Regex("@=" + quot + "(?<qvalue>[^\n\r]*)" + quot + "|@=(?<value>\\w*)|@(?<fieldName>\\w*)",
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			string substituted = "";
			int lastpos = 0;
			int ipos = 0;
			for (match = regex.Match(format); match.Success; match = match.NextMatch())
			{
				// extract param name from match
				string fieldName;
				string val;
				int ilen = 0;
				// quoted value
				val = match.Groups["qvalue"].Value;
				if (val != "")
				{
					ilen = val.Length;
					ipos = match.Groups["qvalue"].Index - 1;
					substituted += format.Substring(lastpos, ipos - lastpos - 2);
					substituted += val;
					ipos ++;
				}
				
				else
				{
					// direct value
					val = match.Groups["value"].Value;
					if (val != "")
					{
						// value
						ilen = val.Length;
						ipos = match.Groups["value"].Index - 1;
						substituted += format.Substring(lastpos, ipos - lastpos - 1);
						substituted += val;
					}
					else
					{
						fieldName = match.Groups["fieldName"].Value;
						ipos = match.Groups["fieldName"].Index - 1;
						
						if (fieldName != null)
						{
							if (fieldName != "")
							{
								ilen = fieldName.Length;
								int colIndex = (int)columnIndices[fieldName];
								val = valueStrings[colIndex];
								substituted += format.Substring(lastpos, ipos - lastpos);
								substituted += val;
							}
						}
					}
				}

				lastpos = ipos + ilen + 1;
			}
			ipos = format.Length;
			substituted += format.Substring(lastpos, ipos - lastpos);
			return substituted;
		}

		/// <summary>
		/// Parse text and fill valueStrings.
		/// Called by the overridden ParseRowValues
		/// </summary>
		/// <param name="text"></param>
		/// <param name="valueStrings"></param>
		protected void ParseRowValuesCSV(string text, string[] valueStrings, char seperator)
		{
			string[] textValues = new string[textColumns.Length];
			// read normal text columns
			CSVImporter.ParseRowValuesCSV(text, textValues, seperator);

			// substitute read valus into valueStrings
			for (int i = 0; i < textColumns.Length; i++)
			{
				string colName = textColumns[i];
				int index = (int)columnIndices[colName];
				valueStrings[index] = textValues[i];
			}

			// then merge extra columsn in!
			for (int i = 0; i < targetColumns.Length; i++)
			{
				string colName = targetColumns[i];
				string[] formats = (string[])columnFormats[colName];
				if (formats != null)
				{
					if (formats.Length > 0)
					{
						string format = formats[0];
						if (format.IndexOf("@") >= 0)
						{
							valueStrings[i] = ProcessFormattedColumn(valueStrings, format);
						}
					}
				}
			}
		}

		#endregion

		#region Overridden functions

		/// <summary>
		/// Parse text and fill valueStrings.
		/// Overridden to handle extra columns using format definitions.
		/// </summary>
		/// <param name="text"></param>
		/// <param name="valueStrings"></param>
		public override void ParseRowValues(string text, string[] valueStrings)
		{
			ParseRowValuesCSV(text, valueStrings, ',');
		}

		public override object ConvertColumnValue(string sval, DataColumn col)
		{
			// handle special datetime formatting for each column
			if (col.DataType == typeof (DateTime))
			{
				System.IFormatProvider format =
					new System.Globalization.CultureInfo("en-US", true);
				string[] formats = (string[])columnFormats[col.ColumnName];
				if (formats != null)
				{
					DateTime dt = DateTime.ParseExact(sval, formats, format, System.Globalization.
						DateTimeStyles.AllowWhiteSpaces);
					return dt;
				}
			}
			else
			{
				// check if there's a mapping definition:
				// example:
				// #M:1		M maps to value 1
				// #F:0		F maps to value 0
				string[] formats = (string[])columnFormats[col.ColumnName];
				if (formats != null)
				{
					for (int i = 0; i < formats.Length; i++)
					{
						string format = formats[i];
						if (format.Length > 0)
						{
							if (format[0] == '#')	// a mapping definition
							{
								int iColumn = format.IndexOf(":");
								if (iColumn >= 0)
								{
									if (string.Compare(format, 1, sval, 0, iColumn - 1, true) == 0)
									{
										sval = format.Substring(iColumn + 1);
										break;
									}
									else if (string.Compare(format, 1, "*", 0, iColumn - 1, true) == 0)
									{
										// default value for all others
										sval = format.Substring(iColumn + 1);
									}
								}
							}
						}
					}
				}
			}
			
			return base.ConvertColumnValue (sval, col);
		}

		#endregion

		#region Public members

		/// <summary>
		/// The target table that the imported rows will be inserted
		/// </summary>
		public string TargetTable
		{
			get
			{
				return targetTable;
			}
			set
			{
				targetTable = value;
			}
		}

		/// <summary>
		/// The target columsn to be inserted
		/// </summary>
		public string[] TargetColumns
		{
			get
			{
				return targetColumns;
			}
			set
			{
				targetColumns = value;
			}
		}

		/// <summary>
		/// The column formats to be used when converting to value
		/// </summary>
		public Hashtable ColumnFormats
		{
			get
			{
				return columnFormats;
			}
		}

		public void SetColumnFormats(string colName, params string[] formats)
		{
			if (formats == null)
				columnFormats.Remove(colName);
			else
				columnFormats[colName] = formats;
		}

		public void SetColumnFormat(string colName, string format)
		{
			if (format == null)
				columnFormats.Remove(colName);
			else
				columnFormats[colName] = new string[] { format };
		}

		public string[] GetColumnFormats(string colName)
		{
			return (string[])columnFormats[colName];
		}

		public string GetColumnFormat(string colName)
		{
			return ((string[])columnFormats[colName])[0];
		}

		/// <summary>
		/// Use this function to get a columns index once,
		/// and use the index without recalling this function.
		/// </summary>
		/// <param name="colName"></param>
		/// <returns></returns>
		public int GetColumnIndex(string colName)
		{
			return (int)columnIndices[colName];
		}

		#endregion
	}
}
