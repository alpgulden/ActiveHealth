using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using NetsoftUSA.DataLayer;
using System.Text;
using System.Diagnostics;

namespace NetsoftUSA.DataLayer
{
	/*#region EventArgs classes
	public class FillElemFromReaderEventArgs : EventArgs
	{
		//public bool cancelDefault = false;
		//public bool cancelAll = false;
		public int rowNum;
		public int rowNum;
		public FillElemFromReaderEventArgs(int rowNum, SqlDataReader rdr, object data)
		{
			this.lineNum = lineNum;
		}
	}
	#endregion*/

	/// <summary>
	/// Summary description for BaseDataCollectionClass.
	/// </summary>
	public class BaseDataCollectionClass : CollectionBase, ICloneable
	{
		#region Events

		public delegate void CollectionLoadedHandler(object sender, EventArgs e);
		public event BaseDataCollectionClass.CollectionLoadedHandler CollectionLoaded;

		#endregion

		[NonSerialized]
		private BaseDataClass elementInstance;
		[NonSerialized]
		private Type elementType;
		[NonSerialized]
		private string loadProcName = null;
		[NonSerialized]
		private string loadAsChildProcName = null;
		[NonSerialized]
		private BaseDataClass parentDataObject;
		[NonSerialized]
		private string[] fkFields = null;

		public BaseDataCollectionClass()
		{
			
		}

		public void UnuseElementTransactions()
		{
			for (int i = 0; i < this.List.Count; i++)
			{
				BaseDataClass data = this.List[i] as BaseDataClass;
				if (data != null)
					data.SqlData.UnuseTransaction();
			}
		}

		public Type ElementType
		{
			get
			{
				if (elementType == null)
				{
					Type type = this.GetType();
					ElementTypeAttribute elemTypeAttrib = ElementTypeAttribute.GetFromType(type);
					if (elemTypeAttrib == null)
						throw new ArgumentException ("An ElementTypeAttribute must be specified!");

					elementType = elemTypeAttrib.ElemType;
				}
				return elementType;
			}
			set
			{
				this.elementType = value;
				elementInstance = null;
				loadProcName = null;
				loadAsChildProcName = null;
			}
		}

		public BaseDataClass ElementInstance
		{
			get
			{
				if (elementInstance == null)
					elementInstance = NewRecord(false);
				return elementInstance;
			}
		}

		protected string LoadProcName
		{
			get 
			{ 
				if (this.loadProcName == null)
				{
					this.loadProcName = "usp_LoadGroupPracticeProviderLink";
				}
				return this.loadProcName;
			}
			set { this.loadProcName = value; }
		}

		protected string LoadAsChildProcName
		{
			get 
			{ 
				if (this.loadAsChildProcName == null)
				{
					this.loadAsChildProcName = "usp_Load" + parentDataObject.GetType().Name + this.ElementInstance.TableName;
				}
				return this.loadAsChildProcName;
			}
			set { this.loadAsChildProcName = value; }
		}

		public SQLDataDirect SqlData
		{
			get
			{
				return ElementInstance.SqlData;
			}
			set
			{
				ElementInstance.SqlData = value;
			}
		}

		public BaseDataClass GetAt(int index)
		{
			return base.List[index] as BaseDataClass;
		}


		/*public virtual BaseDataClass CreateElement()
		{
			return (BaseDataClass)Activator.CreateInstance(this.ElementType);
		}*/

		/// <summary>
		/// Create a new instance of the element type and make all New method if initAsNewRecord is true.
		/// </summary>
		public virtual BaseDataClass NewRecord(bool initAsNewRecord)
		{
			BaseDataClass data = (BaseDataClass)Activator.CreateInstance(this.ElementType);
			if (initAsNewRecord)
			{
				data.NewRecord();
				SetFKOnElement(data);
			}
			return data;
		}

		public virtual int AddRecord(BaseDataClass data)
		{
			int index = List.Add(data);
			OnSetComplete(index, data, data);
			SetFKOnElement(data);
			return index;
		}

		public virtual void AppendToCollection(IEnumerable col)
		{
			foreach (object elem in col)
			{
				this.AddRecord((BaseDataClass)elem);
			}
		}

		public virtual void InsertRecord(int index, BaseDataClass data)
		{
			List.Insert(index, data);
			SetFKOnElement(data);
		}

		public virtual void RemoveRecord(BaseDataClass data)
		{
			List.Remove(data);
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		protected int Read(SqlDataReader sourceRdr, int maxRecords, bool ignoreAssignmentError)
		{
			try
			{
				return SqlData.ReadCollection(sourceRdr, maxRecords, this, ignoreAssignmentError, false);
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in BaseDataCollectionClass.Read:\r\n" + ex.Message);
				throw;
			}
		}

		protected int Read(SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			return Read(sourceRdr, -1, ignoreAssignmentError);
		}

		protected int SPExecRead(string spName, int maxRecords, bool ignoreAssignmentError, params object[] parameters)
		{
			try
			{
				return this.SqlData.SPExecReadCol(spName, maxRecords, this, ignoreAssignmentError, parameters);
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in BaseDataCollectionClass.SPExecRead:\r\n" + ex.Message);
				throw;
			}
		}

		protected int SPExecReadCol(string spName, int maxRecords, object paramsObj, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			try
			{
				return this.SqlData.SPExecReadCol(spName, maxRecords, this, paramsObj, ignoreAssignmentError, extraParamNames, extraParamValues);
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in BaseDataCollectionClass.SPExecReadCol:\r\n" + ex.Message);
				throw;
			}
		}

		protected int SPExecReadCol(string spName, int maxRecords, object paramsObj, bool ignoreAssignmentError)
		{
			try
			{
				return this.SqlData.SPExecReadCol(spName, maxRecords, this, paramsObj, ignoreAssignmentError);
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in BaseDataCollectionClass.SPExecReadCol:\r\n" + ex.Message);
				throw;
			}
		}

		protected virtual void SaveElement(object elem)
		{
			BaseDataClass data = elem as BaseDataClass;
			if (data != null)
			{
				data.SqlData.Transaction = this.SqlData.Transaction;
				data.SqlData.Principal = this.SqlData.Principal;
				try
				{
					if (data.IsNew || data.IsMarkedForDeletion || data.IsDirty) 
						data.InternalSave();
					else
						System.Diagnostics.Debug.WriteLine("Skipped " + elem.ToString());
				}
				finally
				{
					data.SqlData.UnuseTransaction();
				}
			}
		}

		protected void SaveElement(int index)
		{
			SaveElement(this.List[index]);
		}

		protected virtual void SynchronizeElement(object elem, DataSyncFlags syncFlags)
		{
			BaseDataClass data = elem as BaseDataClass;
			if (data != null)
			{
				data.SqlData.Transaction = this.SqlData.Transaction;
				data.SqlData.Principal = this.SqlData.Principal;
				try
				{
					data.Synchronize(syncFlags);
				}
				finally
				{
					data.SqlData.UnuseTransaction();
				}
			}
		}

		protected void SynchronizeElement(int index, DataSyncFlags syncFlags)
		{
			SynchronizeElement(this.List[index], syncFlags);
		}
		
		protected virtual void RemoveDeletedElement(int index)
		{
			BaseDataClass data = this.List[index] as BaseDataClass;
			if (data != null)
				if (data.IsNewlyDeletedInDB)
				{
					data.OnCompleteSave();
					this.List.RemoveAt(index);
				}
		}

		/// <summary>
		/// Walk on the elements and save them all
		/// </summary>
		protected virtual void InternalSaveElements()
		{
			if (this.parentDataObject != null)
			{
				if (!CheckParentRecordStatus())
					return;
			}

			for (int i = 0; i < this.Count; i++)
				SaveElement(i);
		}

		protected void SaveElements()
		{
			SaveElements(true);
		}

		protected void SaveElements(bool removeDeleted)
		{
			InternalSaveElements();
			if (removeDeleted)
				RemoveDeletedElements();

			// complete saves so that flags are reset
			for (int i = 0; i < List.Count; i++)
			{
				BaseDataClass data = List[i] as BaseDataClass;
				if (data != null)
					data.OnCompleteSave();
			}
		}

		/// <summary>
		/// Walk on the elements and synchronize them all
		/// </summary>
		protected virtual void SynchronizeElements(DataSyncFlags syncFlags)
		{
			if (this.parentDataObject != null)
			{
				if (!CheckParentRecordStatus())
					return;
			}

			for (int i = 0; i < this.Count; i++)
				SynchronizeElement(i, syncFlags);
			if ((syncFlags & DataSyncFlags.RemoveDeleted) != 0)
				RemoveDeletedElements();
		}

		protected void SynchronizeElements()
		{
			SynchronizeElements(DataSyncFlags.RemoveDeleted);
		}

		protected void RemoveDeletedElements()
		{
			for (int i = this.Count - 1; i >= 0; i--)
				RemoveDeletedElement(i);
		}

		/// <summary>
		/// Marking a record as new will cause it to be inserted as a new record
		/// </summary>
		/// <param name="index"></param>
		public void MarkNew(int index)
		{
			BaseDataClass data = this.List[index] as BaseDataClass;
			if (data != null)
			{
				if (!data.IsNew)
					data.NewRecord();
			}
		}

		/// <summary>
		/// Marking a record for as dirty allows it to be saved when the collection is saved or synchronized.
		/// </summary>
		/// <param name="index"></param>
		public void MarkDirty(int index)
		{
			BaseDataClass data = this.List[index] as BaseDataClass;
			if (data != null)
				data.MarkDirty();
		}

		/// <summary>
		/// Returns true if the element is dirty;
		/// </summary>
		/// <param name="index"></param>
		/// <returns></returns>
		public bool IsDirty(int index)
		{
			BaseDataClass data = this.List[index] as BaseDataClass;
			if (data != null)
				return data.IsDirty;
			return false;
		}

		/// <summary>
		/// Returns true if the element is new.
		/// </summary>
		/// <param name="index"></param>
		/// <returns></returns>
		public bool IsNew(int index)
		{
			BaseDataClass data = this.List[index] as BaseDataClass;
			if (data != null)
				return data.IsNew;
			return false;
		}

		/// <summary>
		/// Returns true if the element is new or dirty.
		/// </summary>
		/// <param name="index"></param>
		/// <returns></returns>
		public bool IsNewOrDirty(int index)
		{
			BaseDataClass data = this.List[index] as BaseDataClass;
			if (data != null)
				return data.IsNewOrDirty;
			return false;
		}

		/// <summary>
		/// Returns true if at least one element is new or dirty or marked for deletion.
		/// </summary>
		public bool IsChanged
		{
			get
			{
				foreach (BaseDataClass data in this)
				{
					if (data.IsChanged)
						return true;
				}
				return false;
			}
		}

		/// <summary>
		/// Marking a record for deletion causes it to be deleted when the collection is saved or synchronized.
		/// </summary>
		/// <param name="index"></param>
		public void MarkDel(int index)
		{
			BaseDataClass data = this.List[index] as BaseDataClass;
			if (data != null)
				data.MarkDel();
		}

		public bool IsMarkedForDeletion(int index)
		{
			BaseDataClass data = this.List[index] as BaseDataClass;
			if (data != null)
				return data.IsMarkedForDeletion;
			return false;
		}

		/// <summary>
		/// Marking a record for reload allows it to be reloaded when the collection is synchronized.
		/// </summary>
		/// <param name="index"></param>
		public void MarkReload(int index)
		{
			BaseDataClass data = this.List[index] as BaseDataClass;
			if (data != null)
				data.MarkReload();
		}

		public bool IsMarkedForReload(int index)
		{
			BaseDataClass data = this.List[index] as BaseDataClass;
			if (data != null)
				return data.IsMarkedForReload;
			return false;
		}

		public void MarkAllDel()
		{
			for (int i = 0; i < this.Count; i++)
				MarkDel(i);
		}

		public void MarkAllDirty()
		{
			for (int i = 0; i < this.Count; i++)
				MarkDirty(i);
		}

		public void MarkAllReload()
		{
			for (int i = 0; i < this.Count; i++)
				MarkReload(i);
		}

		protected BaseDataClass ParentDataObject
		{
			get { return this.parentDataObject; }
			set 
			{
				this.parentDataObject = value; 
				this.loadAsChildProcName = null;
			}
		}

		protected string[] FKFields
		{
			get 
			{ 
				//if (this.fkFields == null)
				//	this.fkFields = this.TableMapping.PKMemberName.Split(',');
				return this.fkFields;
			}
			set { this.fkFields = value; }
		}

		protected string FKFieldsStr
		{
			get { return String.Join(",", this.fkFields); }
			set 
			{ 
				if (value == null)
					fkFields = null;
				else
					fkFields = value.Split(',');
			}
		}

		/// <summary>
		/// Uses the specified parent data object to load this collection
		/// as child.
		/// </summary>
		/// <param name="spName"></param>
		/// <returns></returns>
		protected virtual int LoadAsChild(params object[] parameters)
		{
			this.Clear();
			if (parentDataObject == null)
				throw new Exception("Can't load child collection.  Parent data object is null!");
			if (parentDataObject.IsNew)
				return 0;		// object is new, just return
			if (parentDataObject.IsNullPK)
				return 0;		// null pk, just return
			return SPExecuteLoadAsChild(parameters);
		}

		protected virtual void SetFKOnElement(BaseDataClass data)
		{
			if (this.parentDataObject != null)
				data.Set(this.fkFields, this.parentDataObject.PK);
		}

		protected void SetFKOnElement(int index)
		{
			BaseDataClass data = this.List[index] as BaseDataClass;
			if (data != null)
				SetFKOnElement(data);
		}

		protected void PrepareElements()
		{
			if (this.parentDataObject == null)
				return;
			if (this.fkFields == null)
				return;
			if (true) //always do this -- this.parentDataObject.IsNewlyInsertedInDB)
			{	
				// all child records should also be inserted as new
				for (int i = 0; i < this.Count; i++)
				{
					if (this.parentDataObject.IsNew || this.parentDataObject.IsNewlyInsertedInDB)
						MarkNew(i);			// the element must be marked as new!
					SetFKOnElement(i);	// it's FK must be set from the parent's PK.
				}
			}
			/*else if (this.parentDataObject.IsNew)		// tried to save this collection before the parent was saved.
			{
				// all child records should also be inserted as new
				for (int i = 0; i < this.Count; i++)
				{
					MarkNew(i);			// the element must be marked as new!
				}
			}*/
		}

		/// <summary>
		/// Returns false if the child collection should continue saving.
		/// Throws exception if there's a problem with the parent record's status.
		/// </summary>
		/// <returns></returns>
		private bool CheckParentRecordStatus()
		{
			if (this.parentDataObject.IsNew)
			{
				if (!this.parentDataObject.InsertPK)
					throw new Exception("Can't save/synchronize the child collection!  The parent record has not been saved yet.");
				else
				{
					if (this.parentDataObject.IsNullPK)
						throw new Exception("Can't save/synchronize the child collection!  The parent must have a non-null PK.");
				}

				if (this.parentDataObject.IsMarkedForDeletion || this.parentDataObject.IsNewlyDeletedInDB)
					return false;		// don't save/synchronize
			}

			return true;
		}

		protected virtual void SaveAsChild(bool removeDeleted)
		{
			this.PrepareElements();
			this.SqlData.EnsureTransaction();		// Make sure this is transactional
			try
			{
				this.SaveElements(removeDeleted);
				this.SqlData.CommitTransaction();
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in SaveAsChild:\r\n" + ex.Message);
				this.SqlData.RollbackTransaction();
				throw;
			}
		}

		protected virtual void SynchronizeAsChild(DataSyncFlags syncFlags)
		{
			this.PrepareElements();
			this.SqlData.EnsureTransaction();		// Make sure this is transactional
			try
			{
				this.SynchronizeElements(syncFlags);
				this.SqlData.CommitTransaction();
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in SynchronizeAsChild:\r\n" + ex.Message);
				this.SqlData.RollbackTransaction();
				throw;
			}
		}

		protected virtual int SPExecuteLoadAsChild(params object[] parameters)
		{
			if (parameters == null || parameters.Length == 0)
				parameters = parentDataObject.PK;
			try
			{
				return this.SqlData.SPExecReadCol(this.LoadAsChildProcName, -1, this, false, parameters);
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in SPExecuteLoadAsChild:\r\n" + ex.Message);
				throw;
			}
		}

		/// <summary>
		/// Ensure the given type of child collection is created.
		/// Load it if not already loaded or forceReload is true.
		/// if FKFields is null, it's used from the SPLoadChild attribute declared on the child property.
		/// </summary>
		/// <param name="childPropName"></param>
		/// <param name="parentDataObject"></param>
		/// <param name="collectionType"></param>
		/// <param name="collection"></param>
		/// <param name="forceReload"></param>
		/// <param name="FKFields"></param>
		/// <returns></returns>
		public static BaseDataCollectionClass LoadChildCollection(string childPropName, BaseDataClass parentDataObject, Type collectionType, BaseDataCollectionClass collection, bool forceReload, string[] FKFields, params object[] parameters)
		{
			return LoadChildCollection(childPropName, null, parentDataObject, collectionType, collection, forceReload, FKFields);
		}

		/// <summary>
		/// Ensure the given type of child collection is created.
		/// Use the given stored proc name and load it if not already loaded or forceReload is true.
		/// if spName is null, it's used from the SPLoadChild attribute declared on the child property.
		/// if FKFields is null, it's used from the SPLoadChild attribute declared on the child property.
		/// </summary>
		/// <param name="childPropName"></param>
		/// <param name="spName"></param>
		/// <param name="parentDataObject"></param>
		/// <param name="collectionType"></param>
		/// <param name="collection"></param>
		/// <param name="forceReload"></param>
		/// <param name="FKFields"></param>
		/// <returns></returns>
		public static BaseDataCollectionClass LoadChildCollection(string childPropName, string spName, BaseDataClass parentDataObject, Type collectionType, BaseDataCollectionClass collection, bool forceReload, string[] FKFields, params object[] parameters)
		{
			if (collection == null || forceReload)
			{
				if (collection == null)
				{
					collection = (BaseDataCollectionClass)Activator.CreateInstance(collectionType);
					collection.ParentDataObject = parentDataObject;
				}
				else
					collection.Clear();
				

				if (childPropName != null)
				{
					// get from SPLoadChild attribute
					SPLoadChildAttribute sploadChildAtt = SPLoadChildAttribute.GetFromProp(parentDataObject, childPropName);
					if (sploadChildAtt != null)
					{
						// attribute declared
						// direct parameters override attribute declarations
						if (FKFields == null)
							FKFields = sploadChildAtt.GetFKMembers();
						if (spName == null)
							spName = sploadChildAtt.spName;
					}
				}

				collection.LoadAsChildProcName = spName;

				if (FKFields == null)		// if fk fields were not specified, use parent's primary key fields
					collection.FKFields = parentDataObject.PKFields;
				else
					collection.FKFields = FKFields;


				//if (useParentTransaction)
					if (collection.parentDataObject != null)
					{
						collection.SqlData.Transaction = collection.parentDataObject.SqlData.Transaction;
						collection.SqlData.Principal = collection.parentDataObject.SqlData.Principal;
					}

				collection.LoadAsChild(parameters);
			}

			return collection;
		}

		/// <summary>
		/// If the given collection is not null, it's SaveAsChild method is invoked.
		/// This ensures each member is saved, fk values are set as necessary,
		/// and deleted elements are removed from the collection.
		/// </summary>
		/// <param name="collection"></param>
		public static void SaveChildCollection(BaseDataCollectionClass collection, bool useParentTransaction)
		{
			if (collection == null)
				return;

			if (useParentTransaction)
				if (collection.parentDataObject != null)
				{
					collection.SqlData.Transaction = collection.parentDataObject.SqlData.Transaction;
					collection.SqlData.Principal = collection.parentDataObject.SqlData.Principal;
				}
			collection.SaveAsChild(true);
		}

		/// <summary>
		/// This ensures each member is synchronized to db and fk values are set as necessary.
		/// </summary>
		/// <param name="collection"></param>
		/// <param name="syncFlags"></param>
		public static void SynchronizeChildCollection(BaseDataCollectionClass collection, DataSyncFlags syncFlags, bool useParentTransaction)
		{
			if (collection == null)
				return;

			if (useParentTransaction)
				if (collection.parentDataObject != null)
				{
					collection.SqlData.Transaction = collection.parentDataObject.SqlData.Transaction;
					collection.SqlData.Principal = collection.parentDataObject.SqlData.Principal;
				}

			collection.SynchronizeAsChild(syncFlags);
		}

		/// <summary>
		/// This ensures each member is synchronized to db, fk values are set as necessary,
		/// and deleted elements are removed from the collection.
		/// </summary>
		/// <param name="collection"></param>
		public static void SynchronizeChildCollection(BaseDataCollectionClass collection, bool useParentTransaction)
		{
			SynchronizeChildCollection(collection, DataSyncFlags.RemoveDeleted, useParentTransaction);
		}

		public override string ToString()
		{
			return ToString (true, true);
		}

		public virtual string ToString(bool statusFlags, bool objectData)
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("Collection ");
			sb.Append(this.GetType().ToString());
			sb.Append(" of ");
			sb.Append(Convert.ToString( this.ElementType ));
			sb.Append(" elements:\r\n");
			sb.Append("Count:");
			sb.Append(this.Count);
			sb.Append("\r\n");
			for (int i = 0; i < List.Count; i++)
			{
				sb.Append("[");
				sb.Append(i);
				sb.Append("]  ");
				BaseDataClass data = List[i] as BaseDataClass;
				if (data == null)
					sb.Append("null");
				else
				{
					if (statusFlags)
					{
						sb.Append(data.GetType());
						sb.Append("\r\nStatus Flags are { ");
						sb.Append(data.StatusFlagsToString());
						sb.Append(" }\r\n");
					}
					if (objectData)
						sb.Append(data.ToString());
				}
			}
			return sb.ToString();
		}

		/// <summary>
		/// Called when the collection is loaded
		/// </summary>
		protected internal virtual void OnCollectionLoaded()
		{
			if (CollectionLoaded != null)
				CollectionLoaded(this, new EventArgs());
		}

		/// <summary>
		/// Called when the object is filled from reader.
		/// </summary>
		protected internal virtual void OnFillElemFromReader(int rowNumber, SqlDataReader rdr, object data)
		{
			// no impl.
		}

		#region ICloneable Members

		public object Clone()
		{
			return Clone(false, true);	// perform a deep copy and mark everything new
		}

		#endregion

		/// <summary>
		/// Create a copied instance of this collection.  If shallowCopy is true,
		/// only the references of elements are copied.  Otherwise, each element is
		/// cloned.
		/// </summary>
		/// <param name="shallowCopy"></param>
		/// <returns></returns>
		public BaseDataCollectionClass Clone(bool shallowCopy, bool markNew)
		{
			BaseDataCollectionClass cloned = Activator.CreateInstance(this.GetType()) as BaseDataCollectionClass;
			CopyElementsTo(cloned, shallowCopy, markNew);
			return cloned;
		}

		/// <summary>
		/// Copies the elements in this collection into the given target collection.
		/// If shallowCopy is true, only the references will be added, otherwise
		/// each element will be cloned.
		/// </summary>
		/// <param name="targetCol"></param>
		/// <param name="shallowCopy"></param>
		public void CopyElementsTo(BaseDataCollectionClass targetCol, bool shallowCopy, bool markNew)
		{
			foreach (BaseDataClass elem in this)
			{
				BaseDataClass copied = elem;
				if (!shallowCopy)
				{
					// make clone
					copied = elem.Clone(markNew);
				}
				targetCol.AddRecord(copied);
			}
		}

		/// <summary>
		/// Copies the elements in the given source collection into the this collection.
		/// If shallowCopy is true, only the references will be added, otherwise
		/// each element will be cloned.
		/// </summary>
		/// <param name="sourceCol"></param>
		/// <param name="shallowCopy"></param>
		public void CopyElementsFrom(BaseDataCollectionClass sourceCol, bool shallowCopy, bool markNew)
		{
			foreach (BaseDataClass elem in sourceCol)
			{
				BaseDataClass copied = elem;
				if (!shallowCopy)
				{
					// make clone
					copied = elem.Clone(markNew);
				}
				this.AddRecord(copied);
			}
		}

	}


	/// <summary>
	/// Implement this filter to allow your collection to be filtered using the logic
	/// you provide.
	/// </summary>
	public interface ICollectionElementFilter
	{
		bool FilterElement(int index);			// if this is true, the element will be included
	}


}
