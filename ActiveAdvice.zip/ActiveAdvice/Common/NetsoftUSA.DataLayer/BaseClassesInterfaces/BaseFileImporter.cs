using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;

namespace NetsoftUSA.DataLayer
{
	#region Interfaces
	interface IFileImporter
	{
		SqlConnection Connection { get; set; }
		void Import(Stream stream);
	}
	#endregion

	/// <summary>
	/// This is the base class that file importer classes may deriver from.
	/// But this is optional, and a class could implement IFileImporter instead.
	/// </summary>
	public abstract class BaseFileImporter: IFileImporter
	{
		#region Private members

		protected SqlConnection connection;
		protected int numErrors = 0;

		#endregion

		#region Constructors

		public BaseFileImporter()
		{
		}

		#endregion

		#region IFileImporter Members

		public SqlConnection Connection
		{
			get
			{
				return connection;
			}
			set
			{
				connection = value;
			}
		}

		#endregion

		#region Virtual functions to be overridden

		public abstract void Import(Stream stream);

		/// <summary>
		/// Parses the given text and places extracted values into the specified valueStrings array
		/// Deriving classes may override this to implement specialized parsing.
		/// </summary>
		/// <param name="text"></param>
		/// <param name="valueStrings"></param>
		public virtual void ParseRowValues(string text, string[] valueStrings)
		{
			CSVImporter.ParseRowValuesCSV(text, valueStrings, ',');
		}

		/// <summary>
		/// Converts a given string to given column's data type.
		/// Deriving classes may override this.
		/// </summary>
		/// <param name="sval"></param>
		/// <param name="col"></param>
		/// <returns></returns>
		public virtual object ConvertColumnValue(string sval, DataColumn col)
		{
			return Convert.ChangeType(sval, col.DataType);
		}

		/// <summary>
		/// Columsn and valueStrings must match!
		/// Deriving classes may, override this and do additional processing
		/// like merging multiple columns into a single parameter etc.
		/// </summary>
		/// <param name="columns"></param>
		/// <param name="valueStrings"></param>
		/// <param name="schemaTable"></param>
		/// <param name="parameters"></param>
		public virtual void FillColumnValuesIntoParameters(string[] columns, string[] valueStrings, DataTable schemaTable, SqlParameterCollection parameters)
		{
			if (columns.Length != valueStrings.Length)
				throw new Exception("Number of columns and values must match!");

			for (int i = 0; i < columns.Length; i++)
			{
				string colName = columns[i];
				string paramName = "@" + colName;
				if (parameters.Contains(paramName))
				{
					// this column is in the parameters collection, use it!
					string sval = valueStrings[i];
					object val = DBNull.Value;
					if (sval != null)
					{
						sval = sval.Trim().Trim('\'', '\"');
						DataColumn col = schemaTable.Columns[colName];
						Type dataType = col.DataType;
						bool bkeepNull = false;
						if (sval == "")
							if (col.AllowDBNull)
								bkeepNull = true;

						if (!bkeepNull)
						{
							// convert to appropriate db type
							try
							{
								val = ConvertColumnValue(sval, col);
							}
							/*catch(InvalidCastException ex)
							{
								throw new InvalidCastException("Can't convert column [" 
									+ colName + "] value \"" + sval + "\" into type " +
									dataType.ToString(), ex);
							}*/
							catch(Exception ex)
							{
								throw new Exception("Can't convert column [" 
									+ colName + "] value \"" + sval + "\" into type " +
									dataType.ToString(), ex);
							}
						}
					}
					
					parameters[paramName].Value = val;

				}
			}
		}

		#endregion

		#region Public members

		public string[] GetInsertableColumns(DataTable table)
		{
			ArrayList cols = new ArrayList();
			foreach (DataColumn col in table.Columns)
			{
				if (!col.AutoIncrement && !col.ReadOnly)
				{
					cols.Add(col.ColumnName);
				}
			}
			return (string[])cols.ToArray(typeof(string));
		}

		public DataTable GetTableDefinition(string targetTable)
		{
			DataSet ds = new DataSet();
			SqlDataAdapter da = new SqlDataAdapter("select * from [" + targetTable + "] where 1=2", connection.ConnectionString);
			da.Fill(ds, targetTable);
			DataTable dataTable = ds.Tables[targetTable];
			return dataTable;
		}

		public string[] GetValidColumns(DataTable dataTable, string[] columns)
		{
			ArrayList cols = new ArrayList();
			foreach (string colName in columns)
			{
				if (colName != null)
					if (colName != "")
						if (dataTable.Columns.Contains(colName))
						{
							DataColumn col = dataTable.Columns[colName];
							// additional checking if required.
							cols.Add(colName);	
						}
			}

			return (string[])cols.ToArray(typeof(string));
		}

		public System.Data.SqlClient.SqlCommand CreateInsertStatement(DataTable dataTable, string[] validColumns)
		{
			SqlCommand cmd = new SqlCommand();

			// make param names as @colname
			string[] valueParams = new string[validColumns.Length];
			for (int i = 0; i < validColumns.Length; i++)
			{
				valueParams[i] = "@" + validColumns[i];
			}

			// create command text
			string scols = "";
			for (int i = 0; i < validColumns.Length; i++)
			{
				if (i > 0)
					scols += ",";
				scols += "[" + validColumns[i] + "]";
			}

			cmd.CommandText = "insert into [" + dataTable.TableName + "] (" 
				+ scols
				+ ") values (" + String.Join(",", valueParams) + ")";

			// create parameters

			for (int i = 0; i < valueParams.Length; i++)
			{
				DataColumn col = dataTable.Columns[validColumns[i]];
				cmd.Parameters.Add(valueParams[i], DBNull.Value);
			}
			return cmd;
		}

		#endregion
	}
}
