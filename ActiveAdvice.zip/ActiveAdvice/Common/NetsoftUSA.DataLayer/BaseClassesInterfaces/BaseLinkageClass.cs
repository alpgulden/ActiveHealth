using System;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Classes mapping linkage tables must derive from this data class.
	/// TableLinkage Attribute defined on the derived class is used by the methods.
	/// 
	/// [TableLinkageAttribute(typeof(leftclass), "leftfk", typeof(rightclass), "rightfk")]
	///	public class thelink : BaseLinkageClass
	///	{
	///	}
	/// </summary>
	public class BaseLinkageClass : BaseDataClass
	{
		TableLinkageAttribute tableLinkage;

		public BaseLinkageClass()
		{
		}

		public TableLinkageAttribute TableLinkageAttrib
		{
			get 
			{ 
				if (tableLinkage == null)
					tableLinkage = TableLinkageAttribute.GetFromType(this.GetType());
				return tableLinkage;
			}
		}

		/// <summary>
		/// Depending on the given object's type, i
		/// </summary>
		/// <param name="sourceObject"></param>
		/// <param name="?"></param>
		public void SetFKMemberFor(Type sourceClass, object FKValue)
		{
			TableLinkageAttribute att = this.TableLinkageAttrib;
			if (att == null)
				throw new Exception(
					String.Format("No TableLinkage attribute defined on class {0}", this.GetType()));
			if (sourceClass == att.LeftClass)
				this.Set(att.LeftClassMember, FKValue);
			else if (sourceClass == att.RightClass)
				this.Set(att.RightClassMember, FKValue);
			else
				throw new Exception(
					String.Format("This linkage class can't link objects of the given class {0}", sourceClass.FullName));
		}

		public void SaveLinkage()
		{
			base.InternalSave();
		}

	}
}
