using System;
using System.ComponentModel;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Reflection;

namespace NetsoftUSA.DataLayer
{
	public enum DCTableNavigate
	{
		Previous = -1,
		Next = 1,
		First = -2,
		Last = 2
	}

	public enum NSComboStyle
	{
		None = 0,
		DropDownList = 1,
		DropDownGrid = 2
	}

	/// <summary>
	/// This exception can be thrown by validation functions.
	/// </summary>
	public class ValidationException : Exception
	{
		private string field;
		private string longMessage;

		public ValidationException(string field, string message, string longMessage, Exception innerException)
			: base(message, innerException)
		{
			this.field = field;
			this.longMessage = longMessage;
		}

		public ValidationException(string field, string message, Exception innerException)
			: base(message, innerException)
		{
			this.field = field;
		}

		public ValidationException(string field, string message, string longMessage) : base(message)
		{
			this.field = field;
			this.longMessage = longMessage;
		}

		public ValidationException(string field, string message) : base(message)
		{
			this.field = field;
		}

		public string Field
		{
			get { return field; }
			set { field = value; }
		}

		public string LongMessage
		{
			get { return longMessage; }
			set { longMessage = value; }
		}
	}

	public delegate string FieldFormatterDelegate(DataRowView rowView, bool WithValue);
	public delegate void FieldParserDelegate(DataRowView rowView, string str);

	/// <summary>
	/// Base data component class.  You should create your own data component
	/// class and derive from this.
	/// </summary>
	// No we cannot declare the class as abstract for designer requirements
	// so we provide empty virtual functions
	//[ToolboxItem(ToolboxItemFilterType.Prevent)]
	public class DCBase : System.ComponentModel.Component
	{
		#region Private members 
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private bool isSearcher = false;			
		private bool emptyDataSet = false;			// causes 0 number of rows 
		private bool useGlobalConnectionString = true;

		// The dataset and adapter is found from the metadata of the deriving class.
		private System.Reflection.FieldInfo dsField;
		private System.Reflection.FieldInfo adpField;

		private ValidatorManager validators = null;

		private NameValueCollection columnNames = new NameValueCollection();


		private System.Reflection.FieldInfo FindDataSetFromMetadata(object dc)
		{
			if (dsField == null)
			{
				dsField = FindFieldOfType(dc, typeof(DataSet));
				if (dsField == null)
					throw new Exception("No DataSet found on this data component");
			}
			
			return dsField;
		}

		private System.Reflection.FieldInfo FindAdapterFromMetadata(object dc)
		{
			if (adpField == null)
			{
				adpField = FindFieldOfType(dc, typeof(System.Data.Common.DbDataAdapter));
				if (adpField == null)
					throw new Exception("No Data Adapter found on this data component");
			}
			
			return adpField;
		}

		public static bool FilterFindMethodsForAttrib(MemberInfo objMemberInfo, Object objSearch)
		{
			if (objMemberInfo.Name.Length < 7)
				return false;
			if (objMemberInfo.Name.Substring(0, 7) != "Format_")
				return false;
			object[] attribs = objMemberInfo.GetCustomAttributes((Type)objSearch, true);

			if (attribs != null)
				if (attribs.Length > 0)
					return true;

			return false;
		}

		private System.Reflection.MemberInfo[] FindMethodsForAttrib(Type attrib)
		{
			Type type = this.GetType();
			System.Reflection.MemberInfo[] members = type.FindMembers(
				System.Reflection.MemberTypes.Method,
				System.Reflection.BindingFlags.Public 
				| System.Reflection.BindingFlags.NonPublic 
				| System.Reflection.BindingFlags.Instance 
				/*| System.Reflection.BindingFlags.FlattenHierarchy*/,
                new MemberFilter(FilterFindMethodsForAttrib), attrib);

			return members;
		}

		static private System.Reflection.FieldInfo FindFieldOfType(object dc, Type ofType)
		{
			Type type = dc.GetType();
			System.Reflection.MemberInfo[] members = type.FindMembers(
				System.Reflection.MemberTypes.Field, // | 
				//System.Reflection.MemberTypes.Property,
				System.Reflection.BindingFlags.Public 
				| System.Reflection.BindingFlags.NonPublic 
				| System.Reflection.BindingFlags.Instance 
				/*| System.Reflection.BindingFlags.FlattenHierarchy*/,
				null, null);

			foreach (System.Reflection.MemberInfo mi in members)
			{
				if (mi.MemberType == System.Reflection.MemberTypes.Field)
				{
					System.Reflection.FieldInfo fi = (System.Reflection.FieldInfo)mi;
					if (fi.FieldType == ofType ||
						fi.FieldType.IsSubclassOf (ofType))
					{
						return fi;
					}
				}
			}
			return null;
		}

		private System.Reflection.MethodInfo FindFieldFormatterMethod(string table, string fieldName)
		{
			return GetType().GetMethod("Format_" + table + "_" + fieldName);
		}

		private System.Reflection.MethodInfo FindFieldParserMethod(string table, string fieldName)
		{
			return GetType().GetMethod("Parse_" + table + "_" + fieldName);
		}

		private System.Reflection.MethodInfo FindFieldValuesMethod(string table, string fieldName)
		{
			return GetType().GetMethod("FieldValues_" + table + "_" + fieldName);
		}

		private System.Reflection.MethodInfo FindFieldValidatorMethod(string table, string fieldName)
		{
			return GetType().GetMethod("Validate_" + table + "_" + fieldName);
		}

		#endregion
		
		#region Constructors

		public DCBase(System.ComponentModel.IContainer container)
		{
			///
			/// Required for Windows.Forms Class Composition Designer support
			///
			container.Add(this);
			InitializeComponent();
			InitializeComponent2();
		}

		public DCBase()
		{
			///
			/// Required for Windows.Forms Class Composition Designer support
			///
			InitializeComponent();

			InitializeComponent2();
		}

		private void InitializeComponent2()
		{
			// The collection of validators attached to this component
			validators = new ValidatorManager(this);
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Virtual functions to be overridden by descendants

		/// <summary>
		/// May be overridden by the custom data component to provide the
		/// default dataset object contained.
		/// If not provided, the dataset is obtained from the class' metadata.
		/// </summary>
		/// <returns></returns>
		public virtual DataSet GetMainDataSet()
		{
			FindDataSetFromMetadata(this);
			return (DataSet)dsField.GetValue(this);
		}

		/// <summary>
		/// May be overridden by the custom data component to set the
		/// default dataset object contained.
		/// If not provided, the dataset is obtained from the class' metadata.
		/// </summary>
		/// <param name="ds"></param>
		public virtual void SetMainDataSet(DataSet ds)
		{
			FindDataSetFromMetadata(this);
			dsField.SetValue(this, ds);
		}

		/// <summary>
		/// May be overridden by the data component.
		/// Used for implementing default LoadData and SaveData functionality.
		/// If not provided, the dataset is obtained from the class' metadata.
		/// </summary>
		/// <returns></returns>
		public virtual System.Data.Common.DbDataAdapter GetMainDataAdapter()
		{
			FindAdapterFromMetadata(this);
			return (System.Data.Common.DbDataAdapter)adpField.GetValue(this);
		}

		public virtual void OnCreateFinalSelect(ref SqlCommand selectCmd)
		{
			SQLParser parser = new SQLParser(selectCmd.CommandText);
			bool bChanged = false;

			string baseTable = null;
			if (parser.Tables.Count > 0)
				baseTable = SQLParser.NoBracket(parser.Tables[0]);

			//baseTable = ds.Tables[0].TableName;

			System.Reflection.MemberInfo[] members = FindMethodsForAttrib(typeof(JoinedColumnAttribute));
			foreach (System.Reflection.MemberInfo mi in members)
			{
				if (mi.MemberType == System.Reflection.MemberTypes.Method)
				{
					System.Reflection.MethodInfo method = (System.Reflection.MethodInfo)mi;
					string pref = "Format_" + baseTable;
					if (method.Name.Substring(0, pref.Length) == pref)
					{
						// get attribute
						object[] attribs = method.GetCustomAttributes(typeof(JoinedColumnAttribute), true);

						if (attribs != null)
							if (attribs.Length > 0)
							{
								JoinedColumnAttribute joinCol = (JoinedColumnAttribute)attribs[0];
								string alias = joinCol.Alias;
								if (alias == null || alias == "")
									alias = method.Name.Substring(pref.Length + 1);
								if (joinCol.JoinColumn == alias)
									alias = "";
								parser.AddJoinedColumn(joinCol.JoinTable, joinCol.JoinColumn, joinCol.LeftRelationColumn, "=", joinCol.RightRelationColumn, alias);
								bChanged = true;
							}
					}
				}
			}

			if (isSearcher || emptyDataSet)
			{
				parser.WhereClause = "1=2";	// return 0 rows
				bChanged = true;
			}

			if (bChanged)
			{
				selectCmd.CommandText = parser.Build();
			}
		}

		/// <summary>
		/// The actual data component may override this function to implement
		/// data gathering. Default implementation fills the MainDataSet
		/// using the MainDataAdapter.
		/// </summary>
		public virtual void LoadData()
		{
			DataSet ds = GetMainDataSet();
			System.Data.Common.DbDataAdapter da = GetMainDataAdapter();
			System.Data.SqlClient.SqlDataAdapter sda = (System.Data.SqlClient.SqlDataAdapter)da;
			
			ds.Clear();
			LoadData(sda, ds);
			AdjustRowPositions();
		}

		/// <summary>
		/// Returns a complete dataset with 0 number of rows in the
		/// contained tables.
		/// Called in design time to determine the table schemas.
		/// </summary>
		public virtual void LoadDataEmpty()
		{
			emptyDataSet = true;
			try
			{
				LoadData();
			}
			catch(Exception ex)
			{
				throw ex;
			}
			finally
			{
				emptyDataSet = false;
			}
		}

		/// <summary>
		/// This can be called only if the data component is a searcher.
		/// </summary>
		public virtual void LoadSearcher()
		{
			if (!isSearcher)
				throw new Exception("The data component is not marked as a 'searcher'!  Set IsSearcher property first.");

			// loads data with 0 rows in it
            
			LoadData();

			DataSet ds = GetMainDataSet();
			foreach (DataTable tbl in ds.Tables)
			{
				tbl.ChildRelations.Clear();
			}
			foreach (DataTable tbl in ds.Tables)
			{
				foreach (DataColumn col in tbl.Columns)
				{
					col.AutoIncrement = false;
					col.AllowDBNull = true;
					col.ReadOnly = false;
				}
				/*foreach (Constraint constraint in tbl.Constraints)
				{
					int a;
				}*/
				
				tbl.ParentRelations.Clear();
				tbl.Constraints.Clear();
				tbl.PrimaryKey = null;
				foreach (DataColumn col in tbl.Columns)
				{
					col.Unique = false;
				}
				tbl.Rows.Clear();
				tbl.Rows.Add(tbl.NewRow());
			}
			/*foreach (DataTable tbl in ds.Tables)
			{
				tbl.PrimaryKey = null;
			}*/
			ds.Relations.Clear();
		}

		/// <summary>
		/// The actual data component may override this function to implement
		/// data updating. Default implementation updates the MainDataSet
		/// using the MainDataAdapter.
		/// </summary>
		public virtual void SaveData()
		{
			SaveData(GetMainDataAdapter(), GetMainDataSet().GetChanges());
		}

		public void SaveData(System.Data.Common.DbDataAdapter da, DataSet ds)
		{	
			if (ds == null)
				return;
			SqlDataAdapter sda = (SqlDataAdapter)da;
			// other commands will be automatically generated
			if (useGlobalConnectionString)
				sda.SelectCommand.Connection.ConnectionString = NSGlobal.ConnectionString;
			System.Data.SqlClient.SqlCommandBuilder cb = new System.Data.SqlClient.SqlCommandBuilder(sda);
			sda.InsertCommand = cb.GetInsertCommand();
			sda.UpdateCommand = cb.GetUpdateCommand();
			sda.DeleteCommand = cb.GetDeleteCommand();

			sda.Update(ds);
		}

		/// <summary>
		/// Create a new record in the specified data table.
		/// This also sets the current row position to the last record.
		/// </summary>
		/// <param name="table"></param>
		public virtual void NewRecord(string table)
		{
			DataTable dataTable = GetTable(table);
			DataView dataView = dataTable.DefaultView;
			//DataRow row = dataTable.NewRow();			// Changed!
			DataRowView rowView = dataView.AddNew();	// Use the dataview instead
			if (InitNewRecord(table, rowView))
			{
				//dataTable.Rows.Add(row);		// Changed!
				Exception exThrow = null;
				try
				{
					rowView.EndEdit();				// We update the relatd dataView
				}
				catch (Exception ex)
				{
					exThrow = ex;		// Save and throw after navigate
				}

				NavigateTable(table, DCTableNavigate.Last);

				if (exThrow != null)
					throw exThrow;
			}
			else
				rowView.CancelEdit();

			//return rowView[dataTable.PrimaryKey[0].ColumnName];
		}

		/// <summary>
		/// Overridden by the data component to fill default values to a newly added record.
		/// if the return value is true, the row is added, otherwise cancelled.
		/// </summary>
		/// <param name="table">Which table</param>
		/// <param name="rowView">The row view</param>
		public virtual bool InitNewRecord(string table, DataRowView rowView)
		{
			// default implementation is nop
			return true;
		}

		// Direct access to current row's items
		// overridable by the derived classes
		public virtual object GetItem(DataRowView rowView, string colName)
		{
			return rowView[colName];
		}

		public virtual void SetItem(DataRowView rowView, string colName, object val)
		{
			rowView[colName] = val;
		}

		/// <summary>
		/// The deriving data component may override this to return any formatted
		/// string for a given field.
		/// This is one of the ways to for converting between string and object
		/// for fields of a data component.
		/// The default just returns the string.
		/// </summary>
		/// <param name="rowView"></param>
		/// <param name="col"></param>
		/// <returns></returns>
		public virtual string FormatTableItem(DataRowView rowView, string colName, bool WithValue)
		{
			// always check for null
			try
			{
				if (rowView[colName] == DBNull.Value)
					return "";
			}
			catch(ArgumentException)
			{
				// ignore
			}

			System.Reflection.MethodInfo mi = FindFieldFormatterMethod(rowView.Row.Table.TableName, colName);
			if (mi != null)
			{
				string s = null;
				try
				{
					s = (string)mi.Invoke(this, new object[] { rowView, WithValue });
				}
				catch(System.Reflection.TargetInvocationException invocationEx)
				{
					throw invocationEx.InnerException;
				}
				catch(Exception ex)
				{
					throw ex;//.InnerException;
				}

				/*FieldFormatterDelegate fieldFmt = new FieldFormatterDelegate(this);
				if (fieldFmt != null)
					fieldFmt.Method.Invoke(RowView
				*/
				if (s != null)
					return s;
			}

			return rowView[colName].ToString();
		}

		/// <summary>
		/// A deriving data component may override this use the given 
		/// string to parse and set related colum/columns
		/// </summary>
		/// <param name="rowView"></param>
		/// <param name="colName"></param>
		/// <param name="?"></param>
		public virtual void ParseTableItem(DataRowView rowView, string colName, string str)
		{
			System.Reflection.MethodInfo mi = FindFieldParserMethod(rowView.Row.Table.TableName, colName);
			if (mi != null)
			{
				bool bHandled = false;
				try
				{
					bHandled = (bool)(mi.Invoke(this, new object[] { rowView, str }));
				}
				catch(System.Reflection.TargetInvocationException invocationEx)
				{
					throw invocationEx.InnerException;
				}
				catch(Exception ex)
				{
					throw ex;//.InnerException;
				}
				/*FieldFormatterDelegate fieldFmt = new FieldFormatterDelegate(this);
				if (fieldFmt != null)
					fieldFmt.Method.Invoke(RowView
				*/
				if (bHandled)
					return;
			}

			if (str == "")		// all empty string assignments will set dbnull.  If null is not allowed, this function will throw
			{
				if (!rowView.Row.Table.Columns[colName].AllowDBNull)
					throw new System.Data.NoNullAllowedException();
				rowView[colName] = DBNull.Value;
				return;
			}

			rowView[colName] = str;
		}

		public virtual string[] GetFormattedTableItems(string table)
		{
			// determine formatted items from metadata of this class
			Type type = GetType();
			System.Reflection.MemberInfo[] members = type.FindMembers(
				System.Reflection.MemberTypes.Method,
				System.Reflection.BindingFlags.Public
				| System.Reflection.BindingFlags.Instance,
				null, null);

			ArrayList arr = new ArrayList();
			foreach (System.Reflection.MemberInfo mi in members)
			{
				if (mi.MemberType == System.Reflection.MemberTypes.Method)
				{
					System.Reflection.MethodInfo method = (System.Reflection.MethodInfo)mi;
					string name = method.Name;
					string[] terms = name.Split('_');
					// must be in the form Format_TableName_FieldName()
					if (terms.Length == 3)
					{
						if (terms[0] == "Format" || terms[0] == "Parse" || terms[0] == "FieldValues")
							if (terms[1] == table)
								//if (!arr.Contains(terms[2]))
									arr.Add(terms[2]);
					}
				}
			}
			if (arr.Count > 0)
				return (string[])arr.ToArray(typeof(string));
			else
				return null;
		}

		public virtual object[] GetPossibleValues(DataRowView rowView, string colName)
		{
			System.Reflection.MethodInfo mi = FindFieldValuesMethod(rowView.Row.Table.TableName, colName);
			if (mi != null)
			{

				return (object[])mi.Invoke(this, new object[] { rowView });
				/*FieldFormatterDelegate fieldFmt = new FieldFormatterDelegate(this);
				if (fieldFmt != null)
					fieldFmt.Method.Invoke(RowView
				*/
			}
			return null;
		}


		/// <summary>
		/// Returns the pick page for the given table item.
		/// </summary>
		/// <param name="rowView"></param>
		/// <param name="colName"></param>
		/// <returns></returns>
		public virtual string GetPickPageForTableItem(DataRowView rowView, string colName)
		{
			System.Reflection.MethodInfo mi = FindFieldFormatterMethod(rowView.Row.Table.TableName, colName);
			if (mi != null)
			{
				object[] attribs = mi.GetCustomAttributes(typeof(PickPageAttribute), true);
				if (attribs.Length > 0)
					return ((PickPageAttribute)attribs[0]).Page;
			}
			return null;
		}

		public virtual NSComboStyle GetComboStyleForTableItem(DataRowView rowView, string colName)
		{
			System.Reflection.MethodInfo mi = FindFieldValuesMethod(rowView.Row.Table.TableName, colName);
			if (mi != null)
			{
				object[] attribs = mi.GetCustomAttributes(typeof(ComboStyleAttribute), true);
				if (attribs.Length > 0)
					return ((ComboStyleAttribute)attribs[0]).ComboStyle;
			}
			return NSComboStyle.None;
		}

		/// <summary>
		/// Overrride this to determine column description depending on the rowView values!
		/// </summary>
		/// <param name="rowView"></param>
		/// <param name="colName"></param>
		/// <returns></returns>
		public virtual string GetDescriptionForTableItem(DataRowView rowView, string colName)
		{
			// try looking up from the mapping
			return GetColumnDesc(rowView.Row.Table.TableName, colName);
		}

		/// <summary>
		/// Override this to determine column description depending on given TableName
		/// at runtime.  The default uses the description mapping and description
		/// attribute on the Format_ method.
		/// </summary>
		/// <param name="TableName"></param>
		/// <param name="ColumnName"></param>
		/// <returns></returns>
		public virtual string GetColumnDesc(string TableName, string ColumnName)
		{
			try
			{
				return columnNames[TableName+"."+ColumnName];
			}
			catch(Exception)
			{
				System.Reflection.MethodInfo mi = FindFieldFormatterMethod(TableName, ColumnName);
				if (mi != null)
				{
					object[] attribs = mi.GetCustomAttributes(typeof(FieldDescriptionAttribute), true);
					if (attribs.Length > 0)
						return ((FieldDescriptionAttribute)attribs[0]).Description;
				}
				
				return null;
			}
		}

		/// <summary>
		/// The deriving data component may override this to validate a field
		/// </summary>
		/// <param name="rowView"></param>
		/// <param name="col"></param>
		/// <returns></returns>
		public virtual void ValidateTableItem(DataRowView rowView, string colName)
		{
			System.Reflection.MethodInfo mi = FindFieldValidatorMethod(rowView.Row.Table.TableName, colName);
			if (mi != null)
			{
				try
				{
					mi.Invoke(this, new object[] { rowView });
				}
				catch(System.Reflection.TargetInvocationException invocationEx)
				{
					throw invocationEx.InnerException;
				}
				catch(Exception ex)
				{
					throw ex;//.InnerException;
				}
				/*FieldFormatterDelegate fieldFmt = new FieldFormatterDelegate(this);
				if (fieldFmt != null)
					fieldFmt.Method.Invoke(RowView
				*/
			}
		}

		public virtual void RejectChanges(string table)
		{
			DataTable dataTable = GetTable(table);
			DataRowView rowView = GetCurrentDataRowView(table);
			if (rowView != null)
				rowView.CancelEdit();
			dataTable.RejectChanges();
			AdjustRowPos(table);
		}

		public virtual void DeleteRecord(string table, int rowNum)
		{
			DataTable dataTable = GetTable(table);
			DataView dataView = dataTable.DefaultView;
			//dataTable.Rows[rowNum].Delete();		// Changed!
			dataView.Delete(rowNum);				// Delete from the related dataView.
			AdjustRowPos(table);
		}

		/// <summary>
		/// Delete the currently selected record for the specified table.
		/// Use SetTableRowPos function to select record.
		/// </summary>
		/// <param name="table"></param>
		public virtual void DeleteRecord(string table)
		{
			DeleteRecord(table, GetTableRowPos(table));
		}

		/// <summary>
		/// Return currently selected row position for the specified table.
		/// </summary>
		/// <param name="table"></param>
		/// <returns></returns>
		public virtual int GetTableRowPos(string table)
		{
			try
			{
				return (int)GetTable(table).ExtendedProperties["RowPos"];
			}
			catch(Exception)
			{
				return -1;		// Invalid row position
			}
		}
		
		/// <summary>
		/// Sets the current row position for the specified table.
		/// The row position is kept in the related dataset.table object
		/// to make use of server side data caching.
		/// </summary>
		/// <param name="table"></param>
		/// <param name="rowNum"></param>
		public virtual void SetTableRowPos(string table, int rowNum)
		{
			DataTable dataTable = GetTable(table);

			if ((rowNum < -1) || (rowNum >= dataTable.DefaultView.Count))
				rowNum = -1;		// Invalid row
			//throw new IndexOutOfRangeException("Table row number is out of range");
			dataTable.ExtendedProperties["RowPos"] = rowNum;
		}

		#endregion

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion

		#region Public members

		[DefaultValue(true)]
		public bool UseGlobalConnectionString
		{
			get	{	return useGlobalConnectionString; }
			set	{	useGlobalConnectionString = value; }
		}

		public void LoadData(System.Data.Common.DbDataAdapter da, DataSet ds)
		{
			if (ds == null)
				ds = GetMainDataSet();

			SqlDataAdapter sda = (SqlDataAdapter)da;
			SqlCommand cmdOldSelect = sda.SelectCommand;
			string sqlSelect = cmdOldSelect.CommandText;
			try
			{
				// allow modification of select command before load!
				SqlCommand cmd  = cmdOldSelect;
				OnCreateFinalSelect(ref cmd);
				sda.SelectCommand = cmd;
				if (useGlobalConnectionString)
					sda.SelectCommand.Connection.ConnectionString = NSGlobal.ConnectionString;
				
				if (sda.SelectCommand.Connection.State == ConnectionState.Closed)
					sda.SelectCommand.Connection.Open();

				sda.Fill(ds);
			}
			finally
			{
				// Set original select command and content back
				sda.SelectCommand = cmdOldSelect;
				if (cmdOldSelect.CommandText != sqlSelect)
					cmdOldSelect.CommandText = sqlSelect;

				sda.SelectCommand.Connection.Close();
			}
		}

		public void SetColumnDesc(string TableName, string ColumnName, string Description)
		{
			columnNames[TableName+"."+ColumnName] = Description;
		}

		public DataSet CreateDataSetForPossibleValues(DataRowView rowView, string colName)
		{
			/*
			if (rowView.IsEdit)
			{
				try
				{
					rowView.EndEdit();
				}
				catch(Exception ex)
				{
					//ignore
					Debug.WriteLine(ex.ToString());
				}
			}
			rowView.BeginEdit();
			*/
			object oldVal = rowView[colName];
			string tableName = rowView.Row.Table.TableName;
			object[] values = this.GetPossibleValues(rowView, colName);
			if (values == null)
				throw new Exception(String.Format("GetPossibleValues returned null for field '{0}' of table '{1}'!", colName, tableName));
			DataSet ds = new DataSet();
			DataTable table = ds.Tables.Add("Main");
			table.Columns.Add("Value",  GetTable(tableName).Columns[colName].DataType);
			table.Columns.Add("Text", typeof(string));
			foreach (object val in values)
			{
				rowView[colName] = val;
				string formatted = FormatTableItem(rowView, colName, false);
				table.Rows.Add( new object[] { val, formatted } );
			}
			/*
			rowView.CancelEdit();
			rowView.BeginEdit();
			*/
			rowView[colName] = oldVal;
			return ds;
		}

		public void InitRowPositions()
		{
			DataSet ds = GetMainDataSet();
			foreach (DataTable tbl in ds.Tables)
			{
				SetTableRowPos(tbl.TableName, -1);	// Invalidate current row pos
			}
		}

		public void AdjustRowPositions()
		{
			DataSet ds = GetMainDataSet();
			foreach (DataTable tbl in ds.Tables)
			{
				AdjustRowPos(tbl.TableName);
			}
		}

		public void AdjustRowPos(string table)
		{
			try
			{
				DataTable dataTable = GetTable(table);
				if (GetTableRowPos(table) >= dataTable.DefaultView.Count)
					NavigateTable(table, DCTableNavigate.Last);
			}
			catch(Exception)
			{
				// ignore any errors
			}
		}

		/// <summary>
		/// Delete the given rows
		/// </summary>
		/// <param name="rowIds">An array of row numbers to delete</param>
		public void DeleteRecords(string table, int[] rowIds)
		{
			//Array.Sort(rowIds); 
			DataTable dataTable = GetTable(table);
			DataView dataView = dataTable.DefaultView;
			for (int i = rowIds.Length - 1; i >= 0 ; i--)
			{
				try
				{
					DeleteRecord(table, rowIds[i]);
				}
				catch(IndexOutOfRangeException)
				{
					// Ignore invalid row ids.
				}
			}


		}

		

		/// <summary>
		/// Helper function to return specified data table from the main dataset.
		/// </summary>
		/// <param name="table"></param>
		/// <returns></returns>
		public DataTable GetTable(string table)
		{
			if (GetMainDataSet() == null)
				return null;
			return GetMainDataSet().Tables[table];
		}

		/// <summary>
		/// Helper function to return specified data view from the main dataset.
		/// </summary>
		/// <param name="table"></param>
		/// <returns></returns>
		public DataView GetTableView(string table)
		{
			return GetTable(table).DefaultView;
		}

		/// <summary>
		/// Navigate the current table row position to prev, next, first, last.
		/// </summary>
		/// <param name="table"></param>
		/// <param name="navigate"></param>
		public void NavigateTable(string table, DCTableNavigate navigate)
		{
			switch (navigate)
			{
				case DCTableNavigate.First:
					SetTableRowPos(table, 0);
					break;
				case DCTableNavigate.Last:
					SetTableRowPos(table, GetTable(table).DefaultView.Count - 1);
					break;
				case DCTableNavigate.Previous:
					SetTableRowPos(table, GetTableRowPos(table) - 1);
					break;
				case DCTableNavigate.Next:
					SetTableRowPos(table, GetTableRowPos(table) + 1);
					break;
			}
		}

		/// <summary>
		/// Validatate the current row position for the specified table
		/// </summary>
		/// <param name="table"></param>
		/// <returns></returns>
		public bool IsValidRowPos(string table)
		{
			DataTable dataTable = GetTable(table);
			if (dataTable.DefaultView.Count == 0)
				return false;
			if (GetTableRowPos(table) < dataTable.DefaultView.Count)
				return true;
			else
				return false;
		}

		public ValidatorManager Validators
		{
			get
			{
				return validators;
			}
		}

		public DataRowView GetCurrentDataRowView(string table)
		{
			DataTable dataTable = GetTable(table);
			int rowPos = GetTableRowPos(table);
			if (rowPos == -1)
				return null;
			else
				return dataTable.DefaultView[rowPos];
		}

		public DataRow GetCurrentDataRow(string table)
		{
			DataRowView rowView = GetCurrentDataRowView(table);
			if (rowView == null)
				return null;
			else
				return GetCurrentDataRowView(table).Row;
		}

		public void FilterChildren(string ParentTable, string ParentColumn, string ChildTable, string ChildColumn)
		{
			DataRowView rowParent = GetCurrentDataRowView(ParentTable);
			if (rowParent == null)
				GetTableView(ChildTable).RowFilter = "";
			else
			{
				object val = rowParent[ParentColumn];
				string filterFormat;
				if (val is String || val is DateTime || val is Guid)
					filterFormat = "{0}='{1}'";
				else
					filterFormat = "{0}={1}";
				GetTableView(ChildTable).RowFilter = String.Format(filterFormat, ChildColumn, val);
			}

			/*TODO:  Complete automatic child filtering
			 * 
			DataSet ds = GetMainDataSet();
			DataTable dataTable = GetTable(table);
			//int rowPos = GetTableRowPos(table);
			//if (rowPos == -1)
			//	return null;

			DataRowView rowView = GetCurrentDataRowView(table);
			if (rowView == null)
				return null;

			foreach (DataRelation rel in ds.Relations)
			{
				DataColumn[] cols = rel.ParentColumns;
				foreach (DataColumn col in cols)
				{
					if (col.Table.TableName == table)
					{
						rel.ChildKeyConstraint. rowView.
					}
				}
			}*/
		}

		/// <summary>
		/// Substitutes the items in the given string with values from data component.
		/// The formate must be in the form:  
		/// "@Field1-@Field2..."
		/// </summary>
		/// <example>
		///   "@SectionID-@Description (Title is:@Title)"
		/// </example>
		/// <param name="rowView"></param>
		/// <param name="formattedString"></param>
		/// <returns></returns>
		public string SubstituteTableItems(DataRowView rowView, string formattedString)
		{
			if (formattedString == null)
				return "";
			Regex regex = new Regex("@(?<fieldName>\\w+)", 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			string substituted = "";
			int lastpos = 0;
			int ipos = 0;
			for (match = regex.Match(formattedString); match.Success; match = match.NextMatch())
			{
				// extract param name from match
				string fieldName = match.Groups["fieldName"].Value;
				ipos = match.Groups["fieldName"].Index - 1;
				int ilen = fieldName.Length;
				string val = "";
				try
				{
					val = FormatTableItem(rowView, fieldName, true);
				}
				catch (Exception ex)
				{
					// display if any error
					val = "[" + ex.Message + "]";
				}
				substituted += formattedString.Substring(lastpos, ipos - lastpos);
				substituted += val;
				lastpos = ipos + ilen + 1;
			}
			ipos = formattedString.Length;
			substituted += formattedString.Substring(lastpos, ipos - lastpos);
			return substituted;
		}
	
		/// <summary>
		/// Sets the select command of the main data adapter.
		/// It also keeps the same connection as the previous sql command.
		/// </summary>
		/// <param name="select"></param>
		public void SetSelectCommand(System.Data.SqlClient.SqlCommand select)
		{
			SqlDataAdapter adp = (SqlDataAdapter)GetMainDataAdapter();
			select.Connection = adp.SelectCommand.Connection;
			adp.SelectCommand = select;
		}

		///////////////////////////////////////////
	
		/// <summary>
		/// If this property is set to true, this data component
		/// and all its descendants behave as a searcher.
		/// A searcher data component clears all the data, constraints
		/// and relations it contains and provides free data entry
		/// to be used with binding to search fields.
		/// CreateSelect function creates the necessary sql command
		/// for the current data inside the searcher data component.
		/// </summary>
		[Browsable(true), DefaultValue(false)]
		public bool IsSearcher
		{
			get 
			{ 
				return isSearcher; 
			}
			set 
			{ 
				isSearcher = value;
			}
		}

		/// <summary>
		/// This function creates a select command with
		/// all it parameters using the given table's data
		/// in the contained dataset.
		/// </summary>
		/// <param name="table"></param>
		/// <returns></returns>
		public SqlCommand CreateSelect(string table)
		{
			return CreateSelect(table, null);
		}

		public SqlCommand CreateSelect(string table, string[] columns)
		{
			Hashtable columnsLookup = null;
			
			if (columns != null)
			{
				columnsLookup = new Hashtable();
				foreach (string item in columns)
				{
					columnsLookup.Add(item, null);
				}
			}

			SqlCommand select = new SqlCommand();

			DataSet ds = GetMainDataSet();
			DataTable tbl = ds.Tables[table];
			SqlDataAdapter adp = (SqlDataAdapter)GetMainDataAdapter();
			
			//string where = "";

			DataRowView rowView = GetCurrentDataRowView(table);
			ArrayList includeCols = new ArrayList();
			foreach (DataColumn col in tbl.Columns)
			{
				object val = rowView[col.ColumnName];
				string sval;
				bool bNull = false;;
				if (val == null || val == DBNull.Value)
					bNull = true;

				if (val is string)
				{
					sval = (string)val;
					if (sval == "")
						bNull = true;
				}

				if (!bNull)
				{
					if (columnsLookup != null)
						if (!columnsLookup.Contains(col.ColumnName))
							bNull = true;

					if (!bNull)
						includeCols.Add(col);
				}
			}

			string commandText = adp.SelectCommand.CommandText;
			SQLParser parser = new SQLParser(commandText);

			if (parser.WhereClause != "")
				if (includeCols.Count > 0)
					parser.WhereClause = "(" + parser.WhereClause + ")";

			for (int i = 0; i < includeCols.Count; i++)
			{
				//if (i != 0)
				//	where += " AND ";

				DataColumn col = (DataColumn)includeCols[i];
				string paramName = "@" + col.ColumnName;
				//where += col.ColumnName + " like " + paramName;
				parser.AndWhere(SQLParser.MakeFullColumnDesc(col.ColumnName), " like ", paramName);
				select.Parameters.Add(paramName, "%" +rowView[col.ColumnName] + "%");
			}

			
			if (includeCols.Count > 0)
			{
				//parser.WhereClause = where;
				commandText = parser.Build();
				//commandText += " where " + where;
			}

			select.CommandText = commandText;

			return select;
		}

		#endregion

		#region Static functions

		public static object GetNullValueForType(Type type)
		{
			if (type == typeof(string))
				return null;
			else if (type == typeof(bool))
				return false;
			else if (type.IsValueType)
				return Convert.ChangeType(0, type);
			else if (type.IsClass )
				return null;
			else
				return null;
		}

		static public void ParseTableAndColumn(string TableDotColumn, ref string table, ref string column)
		{
			table = null;
			column = null;
			if (TableDotColumn != null)
			{
				string[] terms = TableDotColumn.Split('.');
				if (terms.Length > 0)
					table = terms[0].Trim('[', ']');

				if (terms.Length > 1)
					column = terms[1].Trim('[', ']');
			}
		}
		
		#endregion

		#region Parser functions
		public object ParseSeperator(string str, char seperator)
		{
			string[] terms = str.Split(seperator);
			string s = terms[0];
			object val;
			if (s == "")
				val = DBNull.Value;
			else
				val = int.Parse(s);
			return val;
		}

		public object ParseSeperator(string str)
		{
			return ParseSeperator(str, '-');
		}

		public object ParseDDMMYYYY(string str)
		{
			if (str == "")
				return DBNull.Value;

			System.IFormatProvider format =
				new System.Globalization.CultureInfo("en-US", true);
			string[] formats = { "dd/MM/yyyy", "dd/MM/yy", 
								   "d/m/yyyy", "dd/m/yyyy", "d/mm/yyyy",
								   "d/m/yy", "dd/m/yy", "d/mm/yy" };
			DateTime dt = DateTime.ParseExact(str, formats, format, System.Globalization.
				DateTimeStyles.AllowWhiteSpaces);

			return dt;
		}

		// directly parses into the rowView
		public bool ParsePassword(DataRowView rowView, string colName, string str)
		{
			// ignore if the field is not entered!
			if (str == "*")
				return true;
			if (str == "")
				return true;

			// effect field only if there's text
			rowView[colName] = str;
			return true;
		}

		#endregion

		#region Formatter functions

		public string FormatYesNo(object val, bool WithValue)
		{
			string s = "";
			if (val == DBNull.Value)
				return "";
			bool bval = Convert.ToBoolean(val);
			switch(bval)
			{
				case true:
					s = "Yes";
					break;
				case false:
					s = "No";
					break;
			}
			if (WithValue)
				return val + "-" + s;
			else
				return s;
		}

		public string FormatGender(object val, bool WithValue)
		{
			string s = "";
			if (val == DBNull.Value)
				return "";
			switch((int)val)
			{
				case 0:
					s = "Female";
					break;
				case 1:
					s = "Male";
					break;
			}
			if (WithValue)
				return val + "-" + s;
			else
				return s;
		}

		public string FormatTableLookup(object val, bool WithValue, string formattedString, string tableName, string relField)
		{
			string s = "";
			if (val == DBNull.Value)
				return "";
			DataRowView rowView = NSGlobal.TableLookup(tableName, "*", relField + "=@" + relField, val);
			
			s = SubstituteTableItems(rowView, formattedString);
			if (WithValue)
				return val + "-" + s;
			else
				return s;
		}

		public string FormatTableLookup(string cachingKey, object val, bool WithValue, string formattedString, string tableName, string relField, string columns, string where, params object[] parameters)
		{
			DataSet ds = GetDataSetFromTable(cachingKey, tableName, columns, where, parameters); 
			return FormatThruDataTable(val, WithValue, formattedString, ds.Tables[0], relField);
		}

		public string FormatThruDataTable(object val, bool WithValue, string formattedString, DataTable dataTable, string relField)
		{
			string s = "";
			if (val == DBNull.Value)
				return "";

			string sval;
			if (val is String)
				sval = "'" + (string)val + "'";
			else
				sval = Convert.ToString(val);

			string filter = String.Format("[%s]=[%s]", relField, sval);
			DataView view = new DataView(dataTable);
			view.RowFilter = filter;

			DataRowView rowView = null;
			
			if (view.Count > 0)
				rowView = view[0];
			
			s = SubstituteTableItems(rowView, formattedString);
			if (WithValue)
				return val + "-" + s;
			else
				return s;
		}

		public string FormatDDMMYYYY(object val, char seperator)
		{
			if (val == DBNull.Value)
				return "";
			DateTime dt = (DateTime)val;
			return dt.ToString("dd/MM/yyyy");
		}

		public string FormatDDMMYYYY(object val)
		{
			return FormatDDMMYYYY(val, '/');
		}

		public string FormatThruType(object val, Type type, bool WithValue)
		{
			if (val == DBNull.Value)
				return "";

			val = Convert.ChangeType(val, type);

			if (WithValue)
				return val.ToString() + "-" + val.ToString();
			else
				return val.ToString();
		}

		public string FormatThruArray(object val, bool WithValue, params string[] array)
		{
			if (val == DBNull.Value)
				return "";

			int ival = (int)Convert.ToInt32(val);
			string s = array[ival];

			if (WithValue)
				return val.ToString() + "-" + s;
			else
				return s;
		}

		public string FormatThruArray(object val, ArrayList array, bool WithValue)
		{
			if (val == DBNull.Value)
				return "";

			int ival = (int)Convert.ToInt32(val);
			string s = array[ival].ToString();

			if (WithValue)
				return val.ToString() + "-" + s;
			else
				return s;
		}

		public string FormatThruDictionary(object val, IDictionary dict, bool WithValue)
		{
			if (val == DBNull.Value)
				return "";

			if (!dict.Contains(val))
				return null;

			string s = dict[val].ToString();

			if (WithValue)
				return val.ToString() + "-" + s;
			else
				return s;
		}

		public string FormatPassword(object val, bool WithValue)
		{
			// if the field is null in the row, return emtpy string, forcing it to be entered
			if (val == DBNull.Value)
				return "";
			else	// return false string to the client (only if the user changes, it will be considered)
				return "*";	// never reveal password!
		}

		#endregion

		#region Typed item accessor functions

		#region Generic accessors
		public object GetItem(string table, string colName)
		{
			return GetItem(GetCurrentDataRowView(table), colName);
		}

		public void SetItem(string table, string colName, object val)
		{
			SetItem(GetCurrentDataRowView(table), colName, val);
		}

		// these are helper functions that provide typed access to items
		public object GetItem(DataRowView rowView, string colName, object ValueForNull)
		{
			object o = GetItem(rowView, colName);
			if (o is DBNull || o == null)
				return ValueForNull;
			else
				return o;
		}

		public void SetItem(DataRowView rowView, string colName, object val, object ValueForNull)
		{
			if (val.Equals(ValueForNull))
				SetItem(rowView, colName, DBNull.Value);
			else
				SetItem(rowView, colName, val);
		}

		/// <summary>
		/// these are helper functions that provide typed access to items.
		/// if the value is not null, the value is converted to the specified type.
		/// if the data value is DBNull or null, then the returned value
		/// is determined according to the type specified
		/// </summary>
		/// <param name="rowView"></param>
		/// <param name="colName"></param>
		/// <param name="type"></param>
		/// <returns></returns>
		public object GetItem(DataRowView rowView, string colName, Type type)
		{
			object o = GetItem(rowView, colName);
			if (o is DBNull || o == null)
			{
				return GetNullValueForType(type);
			}
			else
			{
				return Convert.ChangeType(o, type);
			}
		}

		/// <summary>
		/// Sets the data columns value.  Assumes the item
		/// is of the specified type.  Uses the null value
		/// for the specified type.
		/// </summary>
		/// <param name="rowView"></param>
		/// <param name="colName"></param>
		/// <param name="val"></param>
		/// <param name="type"></param>
		public void SetItem(DataRowView rowView, string colName, object val, Type type)
		{
			object ValueForNull = GetNullValueForType(type);
			if (val.Equals(ValueForNull))
				SetItem(rowView, colName, DBNull.Value);
			else
				SetItem(rowView, colName, val);
		}
		#endregion

		#region Int typed access
		public int GetItemInt(DataRowView rowView, string colName, int ValueForNull)
		{
			return Convert.ToInt32(GetItem(rowView, colName, ValueForNull));
		}

		public void SetItemInt(DataRowView rowView, string colName, int val, int ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public int GetItemInt(DataRowView rowView, string colName)
		{
			return Convert.ToInt32(GetItem(rowView, colName));
		}

		public void SetItemInt(DataRowView rowView, string colName, int val)
		{
			SetItem(rowView, colName, val);
		}
		#endregion

		#region bool typed access
		public bool GetItemBool(DataRowView rowView, string colName, bool ValueForNull)
		{
			return Convert.ToBoolean(GetItem(rowView, colName, ValueForNull));
		}

		public void SetItemBool(DataRowView rowView, string colName, bool val, bool ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public bool GetItemBool(DataRowView rowView, string colName)
		{
			return Convert.ToBoolean(GetItem(rowView, colName));
		}

		public void SetItemBool(DataRowView rowView, string colName, bool val)
		{
			SetItem(rowView, colName, val);
		}
		#endregion

		#region string typed access
		public string GetItemString(DataRowView rowView, string colName, string ValueForNull)
		{
			return Convert.ToString(GetItem(rowView, colName, ValueForNull));
		}

		public void SetItemString(DataRowView rowView, string colName, string val, string ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public string GetItemString(DataRowView rowView, string colName)
		{
			return Convert.ToString(GetItem(rowView, colName, null));
		}

		public void SetItemString(DataRowView rowView, string colName, string val)
		{
			SetItem(rowView, colName, val, null);
		}
		#endregion

		#region DateTime typed access
		public DateTime GetItemDateTime(DataRowView rowView, string colName, DateTime ValueForNull)
		{
			return Convert.ToDateTime(GetItem(rowView, colName, ValueForNull));
		}

		public void SetItemDateTime(DataRowView rowView, string colName, DateTime val, DateTime ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public DateTime GetItemStringDateTime(DataRowView rowView, string colName)
		{
			return Convert.ToDateTime(GetItem(rowView, colName, null));
		}

		public void SetItemDateTime(DataRowView rowView, string colName, DateTime val)
		{
			SetItem(rowView, colName, val, null);
		}
		#endregion

		#region float typed access
		public float GetItemFloat(DataRowView rowView, string colName, float ValueForNull)
		{
			return Convert.ToSingle(GetItem(rowView, colName, ValueForNull));
		}

		public void SetItemFloat(DataRowView rowView, string colName, float val, float ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public float GetItemStringFloat(DataRowView rowView, string colName)
		{
			return Convert.ToSingle(GetItem(rowView, colName, null));
		}

		public void SetItemFloat(DataRowView rowView, string colName, float val)
		{
			SetItem(rowView, colName, val, null);
		}
		#endregion

		#region double typed access
		public double GetItemDouble(DataRowView rowView, string colName, double ValueForNull)
		{
			return Convert.ToDouble(GetItem(rowView, colName, ValueForNull));
		}

		public void SetItemDouble(DataRowView rowView, string colName, double val, double ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public double GetItemStringDouble(DataRowView rowView, string colName)
		{
			return Convert.ToDouble(GetItem(rowView, colName, null));
		}

		public void SetItemDouble(DataRowView rowView, string colName, double val)
		{
			SetItem(rowView, colName, val, null);
		}
		#endregion

		#region decimal typed access
		public decimal GetItemDecimal(DataRowView rowView, string colName, decimal ValueForNull)
		{
			return Convert.ToDecimal(GetItem(rowView, colName, ValueForNull));
		}

		public void SetItemDecimal(DataRowView rowView, string colName, decimal val, decimal ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public decimal GetItemDecimal(DataRowView rowView, string colName)
		{
			return Convert.ToDecimal(GetItem(rowView, colName, null));
		}

		public void SetItemDecimal(DataRowView rowView, string colName, decimal val)
		{
			SetItem(rowView, colName, val, null);
		}
		#endregion

		#region char typed access
		public char GetItemChar(DataRowView rowView, string colName, char ValueForNull)
		{
			return Convert.ToChar(GetItem(rowView, colName, ValueForNull));
		}

		public void SetItemChar(DataRowView rowView, string colName, char val, char ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public char GetItemStringChar(DataRowView rowView, string colName)
		{
			return Convert.ToChar(GetItem(rowView, colName, null));
		}

		public void SetItemChar(DataRowView rowView, string colName, char val)
		{
			SetItem(rowView, colName, val, null);
		}
		#endregion

		#region byte typed access
		public byte GetItemByte(DataRowView rowView, string colName, byte ValueForNull)
		{
			return Convert.ToByte(GetItem(rowView, colName, ValueForNull));
		}

		public void SetItemByte(DataRowView rowView, string colName, byte val, byte ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public byte GetItemStringByte(DataRowView rowView, string colName)
		{
			return Convert.ToByte(GetItem(rowView, colName, null));
		}

		public void SetItemByte(DataRowView rowView, string colName, byte val)
		{
			SetItem(rowView, colName, val, null);
		}
		#endregion

		#region Int64 typed access
		public Int64 GetItemInt64(DataRowView rowView, string colName, Int64 ValueForNull)
		{
			return Convert.ToInt64(GetItem(rowView, colName, ValueForNull));
		}

		public void SetItemInt64(DataRowView rowView, string colName, Int64 val, Int64 ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public Int64 GetItemStringInt64(DataRowView rowView, string colName)
		{
			return Convert.ToInt64(GetItem(rowView, colName, null));
		}

		public void SetItemInt64(DataRowView rowView, string colName, Int64 val)
		{
			SetItem(rowView, colName, val, null);
		}
		#endregion

		#region byte[] typed access
		public byte[] GetItemBytes(DataRowView rowView, string colName, byte[] ValueForNull)
		{
			return (byte[])GetItem(rowView, colName, ValueForNull);
		}

		public void SetItemBytes(DataRowView rowView, string colName, byte[] val, byte[] ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public byte[] GetItemStringBytes(DataRowView rowView, string colName)
		{
			return (byte[])GetItem(rowView, colName, null);
		}

		public void SetItemBytes(DataRowView rowView, string colName, byte[] val)
		{
			SetItem(rowView, colName, val, null);
		}
		#endregion

		#region Guid typed access
		public Guid GetItemGuid(DataRowView rowView, string colName, Guid ValueForNull)
		{
			return (Guid)GetItem(rowView, colName, ValueForNull);
		}

		public void SetItemGuid(DataRowView rowView, string colName, Guid val, Guid ValueForNull)
		{
			SetItem(rowView, colName, val, ValueForNull);
		}

		public Guid GetItemStringGuid(DataRowView rowView, string colName)
		{
			return (Guid)GetItem(rowView, colName, null);
		}

		public void SetItemGuid(DataRowView rowView, string colName, Guid val)
		{
			SetItem(rowView, colName, val, null);
		}
		#endregion

		#endregion

		#region Data object filler/retriever functions

		// moved to DataFiller class


		#endregion

		#region Possible values functions

		/// <summary>
		/// Return a list of possible values for gender
		/// </summary>
		/// <returns></returns>
		public object[] GetGenderValues()
		{
			return new object[] { 0, 1 };
		}

		/// <summary>
		/// Returns an array of possible values (true/false) for a boolean field
		/// </summary>
		/// <returns></returns>
		public object[] GetYesNoValues()
		{
			return new object[] { false, true };
		}

		/// <summary>
		/// Returns an array of possible values (true/false) for a boolean field
		/// </summary>
		/// <returns></returns>
		public object[] GetBooleanValues()
		{
			return new object[] { false, true };
		}

		/// <summary>
		/// Get an array of possible values in the given dictionary
		/// </summary>
		/// <param name="dict"></param>
		/// <returns></returns>
		public object[] GetDictionaryValues(IDictionary dict)
		{
			object[] arr = new object[dict.Keys.Count];
			dict.Keys.CopyTo(arr, 0);
			return arr;
		}

		/// <summary>
		/// Return all specified items in the Values array.
		/// Used as a helper.
		/// </summary>
		/// <example>
		/// arr = GetValues("item1", "item2", ...
		/// </example>
		/// <param name="Values"></param>
		/// <returns></returns>
		public object[] GetValues(params object[] Values)
		{
			return Values;
		}

		/// <summary>
		/// Returns an array of all integer values in the specified range
		/// </summary>
		/// <returns></returns>
		public object[] GetRangeValues(int min, int count)
		{
			if (count == 0)
				return null;
			// Just return possible index values from 0 to Values.Length
			object[] arr = new object[count];
			for (int i = 0; i < count; i++)
				arr[i] = i;
			return arr;
		}

		/// <summary>
		/// Returns an array of all date values in the specified range
		/// </summary>
		/// <returns></returns>
		public object[] GetDaysRangeValues(DateTime startDate, int count)
		{
			if (count == 0)
				return null;
			// Just return possible index values from 0 to Values.Length
			object[] arr = new object[count];
			for (int i = 0; i < count; i++)
				arr[i] = startDate.AddDays((double)count);
			return arr;
		}

		/// <summary>
		/// Returns an array of all date values in the specified range
		/// </summary>
		/// <returns></returns>
		public object[] GetMonthsRangeValues(DateTime startDate, int count)
		{
			if (count == 0)
				return null;
			// Just return possible index values from 0 to Values.Length
			object[] arr = new object[count];
			for (int i = 0; i < count; i++)
				arr[i] = startDate.AddMonths(count);
			return arr;
		}

		/// <summary>
		/// Returns an array of all date values in the specified range
		/// </summary>
		/// <returns></returns>
		public object[] GetYearsRangeValues(DateTime startDate, int count)
		{
			if (count == 0)
				return null;
			// Just return possible index values from 0 to Values.Length
			object[] arr = new object[count];
			for (int i = 0; i < count; i++)
				arr[i] = startDate.AddYears(count);
			return arr;
		}

		/// <summary>
		/// Just return possible index values from 0 to Values.Length
		/// </summary>
		/// <param name="stringArray"></param>
		/// <returns></returns>
		public object[] GetArrayValues(params string[] stringArray)
		{
			return GetRangeValues(0, stringArray.Length);
		}

		public object[] GetDataTableValues(DataTable dataTable, string relField)
		{
			object[] arr = new object[dataTable.Rows.Count];			
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				DataRow row = dataTable.Rows[i];
				
				arr[i] = row[relField];
			}

			return arr;
		}

		public object[] GetDataViewValues(DataView dataView, string relField)
		{
			object[] arr = new object[dataView.Count];			
			for (int i = 0; i < dataView.Count; i++)
			{
				DataRowView rowView = dataView[i];
				arr[i] = rowView[relField];
			}

			return arr;
		}

		public object[] GetDataViewValues(DataView dataView, string relField, string rowFilter)
		{
			object[] arr = null;
			string oldFilter = dataView.RowFilter;
			try
			{
				dataView.RowFilter = rowFilter;
				arr = GetDataViewValues(dataView, relField);
			}
			finally
			{
				dataView.RowFilter = oldFilter;
			}
			return arr;
		}

		public object[] GetColumnValuesFromLookupTable(string cachingKey, string TableName, string columnName, string columns, string where, params object[] parameters)
		{
			DataSet ds = GetDataSetFromTable(cachingKey, TableName, columns, where, parameters);
			return NSGlobal.GetColumnValuesFromDataTable(ds.Tables[0], columnName, null);
		}

		public object[] GetColumnValuesFromLookupSelect(string cachingKey, string columnName, string Select, params object[] parameters)
		{
			DataSet ds = GetDataSetFromSelect(cachingKey, Select, parameters);
			return NSGlobal.GetColumnValuesFromDataTable(ds.Tables[0], columnName, null);
		}

		#endregion

		#region Cached Data Access functions
		
		/// <summary>
		/// Returns the caching manager associated with the
		/// contained main dataset.  If it dosn't exist,
		/// it's created and associated with the dataset.
		/// </summary>
		/// <returns></returns>
		public CachingManager GetCachingManager()
		{
			DataSet ds = GetMainDataSet();
			CachingManager cm = ds.ExtendedProperties["CachingManager"] as CachingManager;
			if (cm == null)
			{
				cm = new CachingManager();
				ds.ExtendedProperties["CachingManager"] = cm;
			}

			return cm;
		}

		public CachingManager CachingManager
		{
			get
			{
				return GetCachingManager();
			}
		}

		public DataSet GetDataSetFromTable(string cachingKey, string tableName, string columns, string where, params object[] parameters)
		{
			DataSet ds = CachingManager.GetCachedDataSet(cachingKey);
			if (ds == null)
			{
				ds = NSGlobal.GetDataSetFromTable(tableName, columns, where, parameters);
				CachingManager.SetCachedDataSet(cachingKey, ds);
			}
			return ds;
		}

		public DataSet GetDataSetFromSelect(string cachingKey, string Select, params object[] parameters)
		{
			DataSet ds = CachingManager.GetCachedDataSet(cachingKey);
			if (ds == null)
			{
				ds = NSGlobal.GetDataSetFromSelect(Select, parameters);
				CachingManager.SetCachedDataSet(cachingKey, ds);
			}
			return ds;
		}

		#endregion
	}
}
