using System;
using System.Collections;
using System.Reflection;
using System.Data.SqlClient;
using System.Diagnostics;

namespace NetsoftUSA.DataLayer
{
	[Flags]
	public enum DataSyncFlags
	{
		None = 0,
		ReloadInserted = 1,
		ReloadUpdated = 2,
		ReloadUnchanged = 4,
		ReloadInsertedUpdated = ReloadInserted | ReloadUpdated,
		ReloadAll = ReloadInserted | ReloadUpdated | ReloadUnchanged,
		RemoveDeleted = 8
	}

	/// <summary>
	/// Summary description for BaseDataClass.
	/// </summary>
	public class BaseDataClass : ICloneable
	{
		// NOTE:  private members can't be accessed over reflection when referred from an external assembly

		[NonSerialized]
		private string recordDescription;

		[NonSerialized]
		protected SQLDataDirect sqlData;
		[NonSerialized]
		private string tableName = null;
		[NonSerialized]
		private string rootName = null;
		[NonSerialized]
		private string[] pkFields = null;
		[NonSerialized]
		private TableMappingAttribute tblMappingAttrib = null;
		[NonSerialized]
		private string loadProcName = null;
		[NonSerialized]
		private string insertProcName = null;
		[NonSerialized]
		private string updateProcName = null;
		[NonSerialized]
		private string deleteProcName = null;
		[NonSerialized]
		private BaseDataClass parentDataObject = null;

		// record flags
		protected bool isNew = false;
		protected bool isDirty = false;
		protected bool isNewlyInsertedInDB = false;
		protected bool isMarkedForDeletion = false;
		protected bool isMarkedForReload = false;
		protected bool isNewlyDeletedInDB = false;
		protected bool isNewlyUpdatedInDB = false;
		protected bool isNewlyLoadedFromDB = false;

		public BaseDataClass()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static object CreateAnyDataObject(Type type, bool initNew)
		{
			object obj = Activator.CreateInstance(type);
			if (initNew)
			{
				BaseDataClass data = obj as BaseDataClass;
				if (data != null)
					data.NewRecord();
			}
			return obj;
		}

		public static BaseDataClass CreateBaseDataObject(Type type, bool initNew)
		{
			BaseDataClass data = (BaseDataClass)Activator.CreateInstance(type);
			if (initNew)
				data.NewRecord();
			return data;
		}

		public virtual SQLDataDirect SqlData
		{
			get
			{
				if (this.sqlData == null)
					this.sqlData = SQLDataDirect.CreateSqlDataForType(this.GetType(), false);
				return this.sqlData;
			}
			set
			{
				this.sqlData = value;
			}
		}

		protected BaseDataClass ParentDataObject
		{
			get { return this.parentDataObject; }
			set 
			{
				this.parentDataObject = value; 
			}
		}

		public string RecordDescription
		{
			get
			{
				if (this.recordDescription == null)
					this.recordDescription = RecordDescriptionAttribute.GetDescription(this.GetType(), true);
				return this.recordDescription;
			}
			set
			{
				this.recordDescription = value;
			}
		}

		protected internal string TableName
		{
			get 
			{ 
				if (this.tableName == null)
					this.tableName = this.TableMapping.TableName;
				return this.tableName;
			}
			set { this.tableName = value; }
		}

		protected string RootName
		{
			get 
			{ 
				if (this.rootName == null)
					this.rootName = this.GetType().Name;
				return this.rootName;
			}
			set { this.rootName = value; }
		}

		public string[] PKFields
		{
			get 
			{ 
				if (this.pkFields == null)
				{
					if (this.TableMapping != null && this.TableMapping.PKMemberName != null)
						this.pkFields = this.TableMapping.PKMemberName.Split(',');
				}
				return this.pkFields;
			}
			set { this.pkFields = value; }
		}

		public object Get(string fieldName)
		{
			return ReflectionHelper.GetMemberValue(this, fieldName, false);
		}

		public object Get(string fieldName, Type type)
		{
			return ReflectionHelper.GetMemberValue(this, fieldName, type);
		}

		public string GetStr(string fieldName)
		{
			return ReflectionHelper.GetMemberValueAsString(this, fieldName);
		}

		public object GetDB(string fieldName)
		{
			return ReflectionHelper.GetMemberValue(this, fieldName, true);
		}

		public void Set(string fieldName, object value, bool allowException)
		{
			try
			{
				this.Set(fieldName, value);
			}
			catch
			{
				if (allowException)
					throw;
			}
		}

		public void Set(string fieldName, object value)
		{
			ReflectionHelper.SetMemberValue(this, fieldName, value);
		}

		public void SetStr(string fieldName, string s)
		{
			ReflectionHelper.SetMemberValueFromString(this, fieldName, s);
		}

		public object[] Get(string[] fields)
		{
			object[] vals = new object[fields.Length];
			for (int i = 0; i < fields.Length; i++)
			{
				vals[i] = Get(fields[i]);
			}
			return vals;
		}

		public string[] GetStr(string[] fields)
		{
			string[] svals = new string[fields.Length];
			for (int i = 0; i < fields.Length; i++)
			{
				svals[i] = GetStr(fields[i]);
			}
			return svals;
		}

		public void Set(string[] fields, object[] values)
		{
			for (int i = 0; i < fields.Length; i++)
				Set(fields[i], values[i]);
		}

		public void SetStr(string[] fields, string[] svalues)
		{
			for (int i = 0; i < fields.Length; i++)
				SetStr(fields[i], svalues[i]);
		}

		public void Set(string[] fields, object val)
		{
			for (int i = 0; i < fields.Length; i++)
				Set(fields[i], val);
		}

		public void SetStr(string[] fields, string sval)
		{
			for (int i = 0; i < fields.Length; i++)
				SetStr(fields[i], sval);
		}

		public object[] GetDB(string[] fields)
		{
			object[] vals = new object[fields.Length];
			for (int i = 0; i < fields.Length; i++)
			{
				vals[i] = GetDB(fields[i]);
			}
			return vals;
		}

		public virtual object[] PK
		{
			get
			{
				return GetDB(this.PKFields);
			}
			set
			{
				Set(this.PKFields, value);
			}
		}

		public virtual string PKString
		{
			get
			{
				string[] pk = this.GetStr(this.PKFields);
				return String.Join(",", pk);
			}
			set
			{
				if (value == null || value == "")
				{
					this.SetNullPK();
				}
				else
				{
					string[] svals = value.Split(',');
					this.SetStr(this.PKFields, svals);
				}
			}
		}

		public bool IsNullPK
		{
			get
			{
				object[] pk = this.PK;
				for (int i = 0; i < pk.Length; i++)
					if (pk[i] == null || pk[i] == DBNull.Value)
						return true;

				return false;
			}
			set
			{
				if (value)		// set all values null
					SetNullPK();
			}
		}

		public void SetNullPK()
		{
			string[] pkFields = this.PKFields;
			if (pkFields == null)
				return;
			object[] pk = new object[pkFields.Length ];
			for (int i = 0; i < pk.Length; i++)
				pk[i] = DBNull.Value;
			this.PK = pk;
		}

		/// <summary>
		/// Deriving classes can implement this to create a new pk.  The default implementation
		/// sets all pk values to null.
		/// </summary>
		public virtual void SetNewPK()
		{
			this.SetNullPK();	//	sets all pk fields to null
		}

		public bool IsDBNull(string fieldName)
		{
			return GetDB(fieldName) == DBNull.Value;
		}

		public void SetDBNull(string fieldName)
		{
			Set(fieldName, DBNull.Value);
		}

		protected string LoadProcName
		{
			get 
			{ 
				if (this.loadProcName == null)
				{
					this.loadProcName = SPLoadAttribute.GetSPFromType(this.GetType());
					if (this.loadProcName == null)
						this.loadProcName = "usp_Load" + this.RootName;
				}
				return this.loadProcName;
			}
			set { this.loadProcName = value; }
		}

		protected string InsertProcName
		{
			get
			{ 
				if (this.insertProcName == null)
				{
					this.insertProcName = SPInsertAttribute.GetSPFromType(this.GetType());
					if (this.insertProcName == null)
						this.insertProcName = "usp_Insert" + this.RootName;
				}
				return this.insertProcName;
			}
			set { this.insertProcName = value; }
		}

		protected string UpdateProcName
		{
			get 
			{ 
				if (this.updateProcName == null)
				{
					this.updateProcName = SPUpdateAttribute.GetSPFromType(this.GetType());
					if (this.updateProcName == null)
						this.updateProcName = "usp_Update" + this.RootName;
				}
				return this.updateProcName;
			}
			set { this.updateProcName = value; }
		}

		protected string DeleteProcName
		{
			get 
			{ 
				if (this.deleteProcName == null)
				{
					this.deleteProcName = SPDeleteAttribute.GetSPFromType(this.GetType());
					if (this.deleteProcName == null)
						this.deleteProcName = "usp_Delete" + this.RootName;
				}
				return this.deleteProcName;
			}
			set { this.deleteProcName = value; }
		}

		public bool IsNewOrDirty
		{
			get { return this.isNew || this.isDirty; }
		}

		/// <summary>
		/// Returns true if new, dirty or marked for deletion.
		/// </summary>
		public bool IsChanged
		{
			get { return this.isNew || this.isDirty || this.isMarkedForDeletion; }
		}

		public bool IsNew
		{
			get { return this.isNew; }
			set { this.isNew = value; }
		}

		public bool IsDirty
		{
			get { return this.isDirty; }
			set { this.isDirty = value; }
		}

		public bool IsNewlyLoadedFromDB
		{
			get { return this.isNewlyLoadedFromDB; }
			set { this.isNewlyLoadedFromDB = value; }
		}

		public bool IsNewlyInsertedInDB
		{
			get { return this.isNewlyInsertedInDB; }
			set { this.isNewlyInsertedInDB = value; }
		}

		public bool IsMarkedForDeletion
		{
			get { return this.isMarkedForDeletion; }
			set { this.isMarkedForDeletion = value; }
		}

		public bool IsMarkedForReload
		{
			get { return this.isMarkedForReload; }
			set { this.isMarkedForReload = value; }
		}

		public bool IsNewlyDeletedInDB
		{
			get { return this.isNewlyDeletedInDB; }
			set { this.isNewlyDeletedInDB = value; }
		}

		public bool IsNewlyUpdatedInDB
		{
			get { return this.isNewlyUpdatedInDB; }
			set { this.isNewlyUpdatedInDB = value; }
		}
		
		#region Metadata functions

		#region Overridable metadata functions

		protected virtual TableMappingAttribute TableMapping
		{
			get 
			{ 
				if (this.tblMappingAttrib == null)
					this.tblMappingAttrib = TableMappingAttribute.GetFromObject(this);
				return this.tblMappingAttrib;
			}
		}

		public virtual bool InsertPK
		{
			get
			{
				if (this.TableMapping == null)
					return false;
				return this.TableMapping.InsertPK;
			}
		}

		#endregion

		#region Utility metada functions

		public string[] GetMappedMembers()
		{
			return ColumnMappingAttribute.GetMappedMemberNames(this.GetType());
			/*ArrayList memberNames = new ArrayList();

			Type tobj = this.GetType();

			MemberInfo[] members = 
				ColumnMappingAttribute.FindColumnMappingMembers(
				System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field, 
				false,
				tobj);

			foreach (MemberInfo mi in members)
			{
				ColumnMappingAttribute colMap = ColumnMappingAttribute.GetFromMember(mi);
				if (colMap != null)
					memberNames.Add(mi.Name);
			}

			return (string[])memberNames.ToArray(typeof(string));*/
		}

		/// <summary>
		/// Returns the column name mapped to the given member name.
		/// </summary>
		/// <param name="memberName"></param>
		/// <returns></returns>
		protected string GetColumnMapping(string memberName)
		{
			ColumnMappingAttribute colMap = ColumnMappingAttribute.GetFromType(this.GetType(), memberName);
			if (colMap == null)
				return null;
			else
				return colMap.ColumnName;
		}

		/*protected string[] GetMembersForColumn(string columnName)
		{
			// find members that map to the given column Name and return the member names.
		}*/

		public void CopyMembersTo(object targetObject, bool copyExisting, bool ignoreAssignmentErrors, params string[] memberNames)
		{
			Type type = this.GetType();
			string stype = type.Name;
			Type targetType = targetObject.GetType();
			string stargetType = targetType.Name;
			for (int i = 0; i < memberNames.Length; i++)
			{
				string memberName = memberNames[i];
				try
				{
					string copyTo = null;
					if (CopiableAttribute.IsCopiableTo(type, memberName, ref copyTo))
					{
						if (!copyExisting || (ReflectionHelper.HasMember(type, memberName) && ReflectionHelper.HasMember(targetType, copyTo) ))
						{
							Debug.WriteLine(
								String.Format("Copying {0}.{1} to {2}.{3}", stype, memberName, stargetType, copyTo ));
							ReflectionHelper.SetMemberValue(targetObject, copyTo, this.GetDB(memberName));
						}
					}
				}
				catch(Exception ex)
				{
					Debug.WriteLine("Error copying:\r\n" + ex);
					if (!ignoreAssignmentErrors)
						throw;
				}

			}
		}

		public bool EqualsMembers(object targetObject, bool ignoreComparisonErrors, string[] memberNames, string[] membersToExclude)
		{
			Hashtable excludedMembers = null; 

			if (membersToExclude != null)
			{
				excludedMembers = new Hashtable();
				for (int i = 0; i < membersToExclude.Length; i++)
					excludedMembers[membersToExclude[i]] = i;
			}

			Type type = this.GetType();
			for (int i = 0; i < memberNames.Length; i++)
			{
				string memberName = memberNames[i];
				if (excludedMembers == null || !excludedMembers.ContainsKey(memberName))
				{
					// if not excluded
					try
					{
						//object srcVal = this.GetDB(memberName);
						object srcVal = Get(memberName);
						object tgtVal = ReflectionHelper.GetMemberValue(targetObject, memberName);
						if (srcVal == null)
						{
							if (tgtVal != null)
							{
								Debug.WriteLine("EqualsMembers found different member value for " + memberName);
								return false;
							}
						}
						else
						{
							if (!srcVal.Equals(tgtVal))
							{
								Debug.WriteLine("EqualsMembers found different member value for " + memberName);
								return false;
							}
						}
					}
					catch
					{
						if (!ignoreComparisonErrors)
							throw;
					}

				}
				else
				{
					Debug.WriteLine("EqualsMembers excluded " + memberName + " from comparison");
				}

			}

			Debug.WriteLine("EqualsMembers found that all specified member values are equal");
			return true;		// everything is equal
		}

		public bool EqualsMappedMembers(object targetObject, bool ignoreComparisonErrors)
		{
			return EqualsMappedMembers(targetObject, ignoreComparisonErrors, null);
		}

		public bool EqualsMappedMembers(object targetObject, bool ignoreComparisonErrors, string[] membersToExclude)
		{
			return EqualsMembers(targetObject, ignoreComparisonErrors, this.GetMappedMembers(), membersToExclude);
		}

		protected void CopyStateMembersTo(object targetObject)
		{
			if (targetObject is BaseDataClass)
			{
				CopyMembersTo(targetObject, true, false, 
					"isNew", "isDirty", "isNewlyInsertedInDB", "isMarkedForDeletion", "isMarkedForReload", "isNewlyDeletedInDB", "isNewlyUpdatedInDB");
			}
		}

		protected void CopyStateMembersFrom(object sourceObject)
		{
			if (sourceObject is BaseDataClass)
			{
				CopyMembersFrom(sourceObject, false, true, 
					new string[] { "isNew", "isDirty", "isNewlyInsertedInDB", "isMarkedForDeletion", "isMarkedForReload", "isNewlyDeletedInDB", "isNewlyUpdatedInDB" });
			}
		}

		public void CopyMappedMembersTo(object targetObject, bool copyExisting, bool ignoreAssignmentErrors, bool copyState)
		{
			if (copyState)
				CopyStateMembersTo(targetObject);
			CopyMembersTo(targetObject, copyExisting, ignoreAssignmentErrors, this.GetMappedMembers());
		}

		public void CopyMembersFrom(object sourceObject, bool copyExisting, bool ignoreAssignmentErrors, string[] memberNames)
		{
			Type type = this.GetType();
			string stype = type.Name;
			Type srcType = sourceObject.GetType();
			string ssrcType = srcType.Name;
			for (int i = 0; i < memberNames.Length; i++)
			{
				string memberName = memberNames[i];
				try
				{
					string copyFrom = null;
					
					if (CopiableAttribute.IsCopiableFrom(type, memberName, ref copyFrom))
					{
						if (!copyExisting || (ReflectionHelper.HasMember(type, memberName) && ReflectionHelper.HasMember(srcType, copyFrom) ))
						{
							Debug.WriteLine(
								String.Format("Copying from {0}.{1} to {2}.{3}", ssrcType, copyFrom, stype, memberName ));
							this.Set(memberName, ReflectionHelper.GetMemberValueFromPath(sourceObject, copyFrom, true));
						}
					}
				}
				catch(Exception ex)
				{
					Debug.WriteLine("Error copying:\r\n" + ex);
					if (!ignoreAssignmentErrors)
						throw;
				}

			}
		}

		public void CopyMembersFrom(object sourceObject, bool copyExisting, bool ignoreAssignmentErrors, bool copyState)
		{
			if (copyState)
				CopyStateMembersFrom(sourceObject);
			CopyMembersFrom(sourceObject, copyExisting, ignoreAssignmentErrors, this.GetMappedMembers());
		}

		/// <summary>
		/// Set all mapped members to null
		/// </summary>
		/// <param name="targetObj"></param>
		/// <param name="mappedMembers"></param>
		/// <param name="containedAndCollections"></param>
		public void SetMembersNull(bool mappedMembers, bool containedAndCollections)
		{
			if (!mappedMembers && !containedAndCollections)
				return;		// no op
			Type tobj = this.GetType();
			MemberInfo[] members = 
				ColumnMappingAttribute.FindColumnMappingMembersAndContained(
				System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field, 
				tobj);

			foreach (MemberInfo mi in members)
			{
				try
				{
					if (mappedMembers && containedAndCollections)
						SetDBNull(mi.Name);
					else
					{
						ContainedAttribute containedAtt = ContainedAttribute.GetFromMember(mi);
						SPLoadChildAttribute sploadAtt = SPLoadChildAttribute.GetFromMember(mi);
						if (containedAtt != null || sploadAtt != null)
						{
							// either conatined or collection
							if (containedAndCollections)
								SetDBNull(mi.Name);
						}
						else
						{
							// ordinary column mapping member
							if (mappedMembers)
								SetDBNull(mi.Name);
						}
					}
				}
				catch
				{
					// ignore any assignment error
				}

			}
		}

		#endregion

		#endregion

		#region Synchronization level overridables and utility functions

		#region Overridable Synchronization-level functions

		/// <summary>
		/// Make this record new so that it'll be created in the db.
		/// Also sets all the contained objects and collections and collections to null
		/// forcing them to be reloaded.
		/// </summary>
		protected internal virtual void NewRecord()
		{
			this.SetNewPK();	//	sets all pk fields to null
			this.SetMembersNull(false, true);		// nullify all contained objects and collections
			this.isNew = true;
			this.isDirty = false;
			this.isNewlyInsertedInDB = false;
			this.isMarkedForDeletion = false;
			this.isMarkedForReload = false;
			this.isNewlyDeletedInDB = false;
			this.isNewlyUpdatedInDB = false;
		}

		protected internal void Save()
		{
			InternalSave();
			OnCompleteSave();
		}

		protected internal virtual void InternalSave()
		{
			if (this.isNewlyDeletedInDB)		// already deleted.  do nothing.
				return;

			if (this.isNew)			// if ismarkedfordeletion, ignore
			{
				// new, insert it if not also deleted
				if (this.isMarkedForDeletion)	// ignore if both new and deleted, don't reset the isnew and ismarkedfordeletion flags.
					this.isNewlyDeletedInDB = true;	// assume deleted
				else
					this.InternalInsert();
			}
			else
			{
				// not new, delete it or update it
				if (this.isMarkedForDeletion)
					this.InternalDelete();
				else
					this.InternalUpdate();
			}
		}

		protected internal void Synchronize(DataSyncFlags syncFlags)
		{
			if (this.isMarkedForReload)		// reload without saving
			{
				this.Load(null);
				return;
			}

			if (this.IsNew)
			{
				this.InternalSave();
				if ((syncFlags & DataSyncFlags.ReloadInserted) != 0)
					this.InternalLoad(null);		// if deleted, this is ignored
				OnCompleteSave();
				return;
			}
			else if (this.IsMarkedForDeletion)
			{
				this.InternalSave();		// deleted record can't be reloaded
				return;
			}
			else if (this.IsDirty)
			{
				this.InternalSave();
				if ((syncFlags & DataSyncFlags.ReloadUpdated) != 0)
					this.InternalLoad(null);		// if deleted, this is ignored
				OnCompleteSave();
				return;
			}

			// unchanged
			if ((syncFlags & DataSyncFlags.ReloadUnchanged) != 0)
				this.InternalLoad(null);		// if deleted, this is ignored
			OnCompleteSave();
		}

		#endregion

		#region Synchronization utility functions

		protected internal void Synchronize()
		{
			this.Synchronize(DataSyncFlags.None);
		}		

		/// Marking a record for as new sets the pk to null and marks the record as new
		public void MarkNew()
		{
			this.isNew = true;
			if (!this.InsertPK)
				this.SetNewPK();
		}

		/// Marking a record for as dirty allows it to be saved when the data object is saved or synchronized.
		public void MarkDirty()
		{
			this.isDirty = true;
		}

		/// Marking a record for deletion causes it to be deleted when the data object is saved or synchronized.
		public void MarkDel()
		{
			this.isMarkedForDeletion = true;
		}

		/// Marking a record for reload allows it to be reloaded when the data object is synchronized.
		public void MarkReload()
		{
			this.isMarkedForReload = true;
		}

		#endregion

		#endregion

		#region Operation Level Overridables for Load/Update/Insert/Delete

		/// <summary>
		/// Loads the object for the given primary key values by calling the appropriate stored procedure.
		/// </summary>
		/// 
		protected bool Load(params object[] keys)
		{
			bool result = InternalLoad(keys);
			this.isNewlyInsertedInDB = false;
			this.isNewlyDeletedInDB = false;
			this.isNewlyUpdatedInDB = false;
			return result;
		}

		protected virtual bool InternalLoad(params object[] keys)
		{
			if (keys == null || keys.Length == 0)			// reload same record
			{
				keys = this.PK;
				if (this.isNewlyDeletedInDB)		// newly deleted, do not load
					return false;
			}
			bool result = false;
			try
			{
				result = SPExecuteLoad(keys);
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in InternalLoad: \r\n" + ex.Message);
				// do not change flags!
				throw;
			}
			this.isNew = false;
			this.isDirty = false;
			this.isMarkedForDeletion = false;
			this.isMarkedForReload = false;

			// Load operation should not reset these flags.  Their values must be kept after any operation
			// until the user sets them manually.  Use OnSaveComplete function to do it.
			//this.isNewlyInsertedInDB = false;
			//this.isNewlyDeletedInDB = false;
			//this.isNewlyUpdatedInDB = false;
			this.isNewlyLoadedFromDB = true;

			return result;
		}

		/// <summary>
		/// Inserts the object into the table by calling the appropriate stored procedure.  If the primary key is null, it'll be inserted.
		/// </summary>
		protected virtual object InternalInsert()
		{
			object pkVal = null;
			try
			{
				pkVal = this.SPExecuteInsert();
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in InternalInsert: \r\n" + ex.Message);
				// do not change flags!
				throw;
			}

			if (!this.InsertPK)
				this.PK = new object[] { pkVal };

			this.isNew = false;
			this.isNewlyInsertedInDB = true;
			this.isDirty = false;
			this.isMarkedForDeletion = false;
			this.isMarkedForReload = false;
			this.isNewlyDeletedInDB = false;
			this.isNewlyUpdatedInDB = false;

			return pkVal;
		}

		/// <summary>
		/// Updates the object in the underlying table by calling the appropriate stored procedure.
		/// </summary>
		protected virtual void InternalUpdate()
		{
			//object pkVal = null;
			try
			{
				
				this.SPExecuteUpdate();
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in InternalUpdate: \r\n" + ex.Message);
				// do not change flags!
				throw;
			}

			this.isNew = false;
			this.isNewlyInsertedInDB = false;
			this.isDirty = false;
			this.isMarkedForDeletion = false;
			this.isMarkedForReload = false;
			this.isNewlyDeletedInDB = false;
			this.isNewlyUpdatedInDB = true;
		}

		/// <summary>
		/// Deletes the object from the underlying table by calling the appropriate stored procedure.
		/// </summary>
		protected virtual void InternalDelete()
		{
			//object pkVal = null;
			try
			{
				this.SPExecuteDelete(this.PK);
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in InternalDelete: \r\n" + ex.Message);
				// do not change flags!
				throw;
			}
			this.isNew = false;
			this.isNewlyInsertedInDB = false;
			this.isDirty = false;
			this.isMarkedForDeletion = false;
			this.isMarkedForReload = false;
			this.isNewlyDeletedInDB = true;
			this.isNewlyUpdatedInDB = false;
		}

		
		#region Utility functions

		/// <summary>
		/// 
		/// </summary>
		protected internal virtual void OnCompleteSave()
		{
			this.isNewlyInsertedInDB = false;
			this.isNewlyDeletedInDB = false;
			this.isNewlyUpdatedInDB = false;
		}

		/// <summary>
		/// Deletes any record with the given primary key values.  The current record's status is not effected.
		/// </summary>
		/// <param name="keys"></param>
		protected void Delete(params object[] keys)
		{
			this.SPExecuteDelete(this.PK);
		}

		#endregion

		#endregion

		#region SP-Execution Level Overridables for CRUD operations

		protected virtual bool SPExecuteLoad(object[] keys)
		{
			try
			{
				return this.SqlData.SPExecReadObj(this.LoadProcName, this, false, keys);
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in SPExecuteLoad:\r\n" + ex.Message);
				throw;
			}
		}

		protected virtual object SPExecuteInsert()
		{
			try
			{
				return this.SqlData.SPExecScalar(this.InsertProcName, this, false);
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in SPExecuteInsert:\r\n" + ex.Message);
				throw;
			}
		}
		
		protected virtual void SPExecuteUpdate()
		{
			try
			{
				this.SqlData.SPExecNonQuery(this.UpdateProcName, this, false);
				//if (this.SqlData.SPExecNonQuery(this.UpdateProcName, this, false) < 1)
				//	throw new Exception(
				//		String.Format("SPExecuteUpdate couldn't find the record to be updated PK={0} SP={1}", this.PKString, this.UpdateProcName));
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in SPExecuteUpdate:\r\n" + ex.Message);
				throw;
			}
			
		}

		protected virtual void SPExecuteDelete(object[] keys)
		{
			try
			{
				this.SqlData.SPExecNonQuery(this.DeleteProcName, keys);
			}
			catch(Exception ex)
			{
				Debug.WriteLine("Exception in SPExecuteDelete:\r\n" + ex.Message);
				throw;
			}
		}

		#endregion

		#region Data reader-object mapping level overridables.

		/// <summary>
		/// Override this function when custom or quicker mapping is required.
		/// </summary>
		/// <param name="sourceRdr"></param>
		/// <param name="ignoreAssignmentError"></param>
		protected internal virtual void FillFromReader(SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			SQLDataFiller.FillIntoObject(sourceRdr, this, ignoreAssignmentError);
		}

		#endregion

		#region ICloneable Members

		/// <summary>
		/// Create a data object by copying all the mapped members
		/// but not the record status flags.  The cloned object
		/// is marked as new.
		/// </summary>
		/// <returns></returns>
		public object Clone()
		{
			return Clone(true);
		}

		#endregion

		public virtual BaseDataClass Clone(bool markNew)
		{
			BaseDataClass cloned = (BaseDataClass)Activator.CreateInstance(this.GetType());
			CopyMappedMembersTo(cloned, false, true, false);
			if (markNew)
				cloned.MarkNew();
			return cloned;
		}

		#region Contained Data Object helper functions

		public static BaseDataClass EnsureContainedDataObject(BaseDataClass parentDataObject, Type type, BaseDataClass containedDataObj, bool forceReload, params object[] PK)
		{
			if (forceReload || containedDataObj == null)
			{
				containedDataObj = (BaseDataClass)Activator.CreateInstance(type);
				containedDataObj.parentDataObject = parentDataObject;
				containedDataObj.SqlData.Principal = parentDataObject.SqlData.Principal;

				if (parentDataObject.isNew || !containedDataObj.Load(PK))	// use existing record
					containedDataObj.NewRecord();	// create a new object
			}
			return containedDataObj;
		}

		#endregion

		#region Utility functions

		public string StatusFlagsToString()
		{
			return String.Format(
				"IsNew:{0}  IsDirty:{1}  IsMarkedForDeletion:{2}  IsNewlyLoadedFromDB:{3}  IsNewlyUpdatedInDB:{4}  IsNewlyInsertedInDB:{5}  IsNewlyDeletedInDB:{6}"
				, this.isNew, this.isDirty, this.isMarkedForDeletion
				, this.isNewlyLoadedFromDB, this.isNewlyUpdatedInDB, this.IsNewlyInsertedInDB, this.isNewlyDeletedInDB);
		}

		#endregion

	}

}
