using System;
using System.Diagnostics;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using Microsoft.ApplicationBlocks.Data;
using System.Reflection;
using System.Collections;


namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Summary description for NSGlobal.
	/// </summary>
	public class NSGlobal
	{
		//private static NSGlobal instance;

		private static Hashtable cache = new Hashtable();	// the memory cache that acts like web application cache

		public static readonly string[,] statesArray = { { "AK", "Alaska" },
												{ "AL", "Alabama" },
												{ "AR", "Arkansas" },
												{ "AZ", "Arizona" },
												{ "CA", "California" },
												{ "CO", "Colorado" },
												{ "CT", "Connecticut" },
												{ "DC", "District of Columbia" },
												{ "DE", "Delaware" },
												{ "FL", "Florida" },
												{ "GA", "Georgia" },
												{ "GU", "Guam" },
												{ "HI", "Hawaii" },
												{ "IA", "Iowa" },
												{ "ID", "Idaho" },
												{ "IL", "Illinois" },
												{ "IN", "Indiana" },
												{ "KS", "Kansas" },
												{ "KY", "Kentucky" },
												{ "LA", "Louisiana" },
												{ "MA", "Massachusetts" },
												{ "MD", "Maryland" },
												{ "ME", "Maine" },
												{ "MI", "Michigan" },
												{ "MN", "Minnesota" },
												{ "MO", "Missouri" },
												{ "MS", "Mississippi" },
												{ "MT", "Montana" },
												{ "NC", "North Carolina" },
												{ "ND", "North Dakota" },
												{ "NE", "Nebraska" },
												{ "NH", "New Hampshire" },
												{ "NJ", "New Jersey" },
												{ "NM", "New Mexico" },
												{ "NV", "Nevada" },
												{ "NY", "New York" },
												{ "OH", "Ohio" },
												{ "OK", "Oklahoma" },
												{ "OR", "Oregon" },
												{ "PA", "Pennsylvania" },
												{ "RI", "Rhode Island" },
												{ "SC", "South Carolina" },
												{ "SD", "South Dakota" },
												{ "TN", "Tennessee" },
												{ "TX", "Texas" },
												{ "UT", "Utah" },
												{ "VA", "Virginia" },
												{ "VT", "Vermont" },
												{ "WA", "Washington" },
												{ "WI", "Wisconsin" },
												{ "WV", "West Virginia" },
												{ "WY", "Wyoming" }
												 };

		public static readonly string[,] monthsArray = { { "1", "Jan", "January" },
												{ "2", "Feb", "February" },
												{ "3", "Mar", "March" },
												{ "4", "Apr", "April" },
												{ "5", "May", "May" },
												{ "6", "Jun", "June" },
												{ "7", "Jul", "July" },
												{ "8", "Aug", "August" },
												{ "9", "Sep", "September" },
												{ "10", "Oct", "October" },
												{ "11", "Nov", "November" },
												{ "12", "Dec", "December" }
												 };

		public static readonly string[,] yesNo = { { "1", "Yes" },
													{ "0", "No" } };
		
		public static readonly string[,] trueFalse = { { "1", "True" },
													{ "0", "False" } };

		public static readonly string[,] genderArray = { { "M", "Male" },
														 { "F", "Female" } };

		private static string[] stateCodes = null;
		private static string[,] monthsAndAbbr = null;
		private static string[,] monthsAndNames = null;
		private static int[] daysArray = null;
		private static int[] yearsArray = null;

		// You can change the connection string to work with.
		// Even though we use design time features, we change it
		// using this string at runtime.
		public static string ConnectionString = "";

		public static void FillDataSetFromTable(DataSet targetDS, string TableName, string columns, string where, params object[] parameters)
		{
			string select = "select " + columns + " from [" + TableName + "]";
			if (where != null)
				select += " where " + where;
			System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(NSGlobal.ConnectionString);
			System.Data.SqlClient.SqlDataAdapter adp = new System.Data.SqlClient.SqlDataAdapter(select, conn);

			if (where != null)
			{
				Regex regex = new Regex("@(?<paramName>\\S+)", 
					RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
				Match match;
				int i = 0;
				for (match = regex.Match(where); match.Success; match = match.NextMatch())
				{
					// extract param name from match
					string paramName = match.Groups["paramName"].Value;
					adp.SelectCommand.Parameters.Add("@"+paramName, parameters[i]);
					i ++;
				}
			}

			adp.Fill(targetDS);
		}

		public static void FillDataSetFromSelect(DataSet targetDS, string Select, params object[] parameters)
		{
			System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(NSGlobal.ConnectionString);
			System.Data.SqlClient.SqlDataAdapter adp = new System.Data.SqlClient.SqlDataAdapter(Select, conn);

			Regex regex = new Regex("@(?<paramName>\\S+)", 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			int i = 0;
			for (match = regex.Match(Select); match.Success; match = match.NextMatch())
			{
				// extract param name from match
				string paramName = match.Groups["paramName"].Value;
				adp.SelectCommand.Parameters.Add("@"+paramName, parameters[i]);
				i ++;
			}

			adp.Fill(targetDS);
		}

		public static DataSet GetDataSetFromTable(string TableName, string columns, string where, params object[] parameters)
		{
			DataSet ds = new DataSet();
			try
			{
				FillDataSetFromTable(ds, TableName, columns, where, parameters);
			}
			catch(Exception ex)
			{
				Debug.WriteLine(ex.ToString());
			}
			return ds;
		}

		public static DataSet GetDataSetFromSelect(string Select, params object[] parameters)
		{
			DataSet ds = new DataSet();
			try
			{
				FillDataSetFromSelect(ds, Select, parameters);
			}
			catch(Exception ex)
			{
				Debug.WriteLine(ex.ToString());
			}
			return ds;
		}

		public static DataRowView TableLookup(string TableName, string columns, string where, params object[] parameters)
		{
			DataSet ds = GetDataSetFromTable(TableName, columns, where, parameters);
			return ds.Tables[0].DefaultView[0];
		}

		public static DataRowView SelectLookup(string Select, params object[] parameters)
		{
			DataSet ds = new DataSet();
			try
			{
				FillDataSetFromSelect(ds, Select, parameters);
			}
			catch(Exception ex)
			{
				Debug.WriteLine(ex.ToString());
			}
			return ds.Tables[0].DefaultView[0];
		}

		public static object[] GetPKValuesFromDataTable(DataTable table, string filter)
		{
			return GetColumnValuesFromDataTable(table, table.PrimaryKey[0].ColumnName, filter);
		}

		public static object[] GetColumnValuesFromDataView(DataView dataView, string columnName)
		{
			object[] vals = new object[dataView.Count];

			for (int i = 0; i < dataView.Count; i++)
			{
				DataRowView rv = dataView[i];
				vals[i] = rv[columnName];
			}

			return vals;
		}

		public static object[] GetColumnValuesFromDataTable(DataTable dataTable, string columnName)
		{
			object[] vals = new object[dataTable.Rows.Count];

			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				DataRow r = dataTable.Rows[i];
				vals[i] = r[columnName];
			}

			return vals;
		}

		public static object[] GetColumnValuesFromDataTable(DataTable table, string columnName, string filter)
		{

			DataView dv = new DataView(table);
			dv.RowFilter = filter;
			return GetColumnValuesFromDataView(dv, columnName);
		}

		/// <summary>
		/// Returns an array of the specified property or field's values
		/// for each object in the given collection.
		/// </summary>
		/// <param name="collection"></param>
		/// <param name="elementType"></param>
		/// <param name="propOrFieldName"></param>
		/// <returns></returns>
		public static object[] GetFieldValuesFromCollection(IList collection, Type elementType, string propOrFieldName)
		{
			PropertyInfo pi = null;
			FieldInfo fi = null;

			fi = elementType.GetField(propOrFieldName, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
			if (fi == null)
			{
				pi = elementType.GetProperty(propOrFieldName, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
				if (pi == null)
					throw new ArgumentException(String.Format("Class {0} doesn't have a field or property named {1}", elementType.Name, propOrFieldName));
			}

			Type fieldType = null;
			if (fi != null)
				fieldType = fi.FieldType;
			else
				fieldType = pi.PropertyType;

			// Create a typed array
			//System.Array values = Array.CreateInstance(fieldType, new int[] { collection.Count });
			object[] values = new object[collection.Count];

			for (int i = 0; i < collection.Count; i++)
			{
				object obj = collection[i];
				object val = null;
				if (fi != null)
					val = fi.GetValue(obj);
				else
					val = pi.GetValue(obj, null);

				values.SetValue(val, i);
			}

			return values;
		}

		public static object[] GetFieldValuesFromCollection(IList collection, string propOrFieldName)
		{
			Type type = collection.GetType();
			ElementTypeAttribute elemTypeAttrib = ElementTypeAttribute.GetFromType(type);
			if (elemTypeAttrib == null)
				throw new Exception("An ElementTypeAttribute must be specified!");

			return GetFieldValuesFromCollection(collection, elemTypeAttrib.ElemType, propOrFieldName);
		}

		public static object[] GetKeys(DataView dataView)
		{
			string keyColumn = dataView.Table.PrimaryKey[0].ColumnName;
			return GetColumnValuesFromDataView(dataView, keyColumn);
		}

		public static object[] GetKeys(DataTable dataTable)
		{
			string keyColumn = dataTable.PrimaryKey[0].ColumnName;
			return GetColumnValuesFromDataTable(dataTable, keyColumn);
		}

		public static object[] GetColumnValuesFromLookupTable(string TableName, string columnName, string where, params object[] parameters)
		{
			DataSet ds = new DataSet();

			FillDataSetFromTable(ds, TableName, columnName, where, parameters);
			return GetColumnValuesFromDataTable(ds.Tables[0], columnName, null);
		}

		public static object[] GetColumnValuesFromDataReader(SqlDataReader rdr, int colIndex)
		{
			ArrayList list = new ArrayList();
			
			while (rdr.Read())
			{
				list.Add(rdr.GetValue(colIndex));
			}

			object[] values = new object[list.Count];

			list.CopyTo(values, 0);		

			return values;
		}

		public static object[] GetColumnValuesFromLookupSelect(string columnName, string Select, params object[] parameters)
		{
			DataSet ds = new DataSet();

			FillDataSetFromSelect(ds, Select, parameters);
			return GetColumnValuesFromDataTable(ds.Tables[0], columnName, null);
		}

		public static void FillDataSetColumnWidths(DataSet ds)
		{
			foreach (DataTable table in ds.Tables)
			{
				FillTableColumnWidths(table);
			}
		}

		public static void FillTableColumnWidths(DataTable table)
		{
			FillTableColumnWidths(table, table.TableName);
		}

		public static void FillTableColumnWidths(DataTable table, string tableName)
		{
			DataSet dsCols = SqlHelper.ExecuteDataset(
				NSGlobal.ConnectionString, CommandType.StoredProcedure, "[dbo].[sp_columns]", new SqlParameter("@table_name", tableName));
			if (dsCols != null)
			{
				DataTable tblCols = dsCols.Tables[0];
				for (int i = 0; i < table.Columns.Count; i++)
				{
					DataColumn col = table.Columns[i];
					if (col.DataType == typeof(string))
					{
						string colName = col.ColumnName;
						DataRow[] rows = tblCols.Select("[COLUMN_NAME]='" + colName + "'");
						if (rows != null)
							if (rows.Length > 0)
							{
								col.MaxLength = (int)rows[0]["LENGTH"];
							}
					}
				}
			}
		}

		public static void FillHashtable(Hashtable hashTable, object[] values)
		{
			for (int i = 0; i < values.Length; i++)
			{
				hashTable.Add(values[i], values[i]);
			}
		}

		public static void FillHashtableWithIndices(Hashtable hashTable, object[] values)
		{
			for (int i = 0; i < values.Length; i++)
			{
				hashTable.Add(values[i], i);
			}
		}

		public static void FillHashtable(Hashtable hashTable, object[] keys, IList values)
		{
			for (int i = 0; i < keys.Length; i++)
			{
				hashTable.Add(keys[i], values[i]);
			}
		}

		public static Hashtable CreateHashtable(object[] values)
		{
			Hashtable hashTable = new Hashtable();
			FillHashtable(hashTable, values);
			return hashTable;
		}

		public static Hashtable CreateHashtableWithIndices(object[] values)
		{
			Hashtable hashTable = new Hashtable();
			FillHashtableWithIndices(hashTable, values);
			return hashTable;
		}

		public static Hashtable CreateHashtable(object[] keys, IList values)
		{
			Hashtable hashTable = new Hashtable();
			FillHashtable(hashTable, keys, values);
			return hashTable;
		}

		public static DataSet ExecuteDataset(SqlConnection connection, string command, string tableName, params SqlParameter[] sqlParams)
		{
			DataSet ds = new DataSet();
			SqlDataAdapter da = new SqlDataAdapter(command, connection);
			if (sqlParams != null)
				foreach (SqlParameter param in sqlParams)
					da.SelectCommand.Parameters.Add(param);
			da.Fill(ds, tableName);
			return ds;
		}

		public static DataSet ExecuteDataset(string connectionString, string command, string tableName, params SqlParameter[] sqlParams)
		{
			return ExecuteDataset(new SqlConnection(connectionString), command, tableName, sqlParams);
		}

		public static string[,] StatesAndNames
		{
			get
			{
				return statesArray;
			}
		}

		public static string[,] GenderCodesAndNames
		{
			get
			{
				return genderArray;
			}
		}

		public static string[] StateCodes
		{
			get
			{
				if (stateCodes == null)
				{
					stateCodes = new string[statesArray.GetLength(0)];
					for (int i = 0; i < statesArray.GetLength(0); i++)
						stateCodes[i] = statesArray[i, 0];
				}
				return stateCodes;
			}
		}

		public static string[,] MonthsAndAbbr
		{
			get
			{
				if (monthsAndAbbr == null)
				{
					monthsAndAbbr = new string[monthsArray.GetLength(0), 2];
					for (int i = 0; i < statesArray.GetLength(0); i++)
					{
						monthsAndAbbr[i, 0] = monthsArray[i, 0];
						monthsAndAbbr[i, 1] = monthsArray[i, 1];
					}
				}
				return monthsAndAbbr;
			}
		}

		public static string[,] MonthsAndNames
		{
			get
			{
				if (monthsAndNames == null)
				{
					monthsAndNames = new string[monthsArray.GetLength(0), 2];
					for (int i = 0; i < statesArray.GetLength(0); i++)
					{
						monthsAndNames[i, 0] = monthsArray[i, 0];
						monthsAndNames[i, 1] = monthsArray[i, 2];
					}
				}
				return monthsAndNames;
			}
		}

		public static int[] GetNumbersArray(int first, int last)
		{
			int[] arr = new int[last - first + 1];
			for (int i = first; i <= last; i++)
			{
				arr[i] = i;
			}
			return arr;
		}

		public static int[] Days
		{
			get
			{
				if (daysArray == null)
					daysArray = GetNumbersArray(1, 31);
				return daysArray;
			}
		}

		public static int[] Years
		{
			get
			{
				if (yearsArray == null)
					yearsArray = GetNumbersArray(1900, 2020);
				return yearsArray;
			}
		}

		public static string[,] YesNo
		{
			get
			{
				return yesNo;
			}
		}

		public static string[,] TrueFalse
		{
			get
			{
				return trueFalse;
			}
		}

		public static bool HasAnyNull(object[] values)
		{
			for (int i = 0; i < values.Length; i++)
				if (values[i] is DBNull)
					return true;
			return false;
		}

		/*public static NSGlobal Instance
		{
			get 
			{ 
				if (NSGlobal.instance == null)
					NSGlobal.instance = new NSGlobal();
				return NSGlobal.instance;
			}
			set { NSGlobal.instance = value; }
		}*/

		public static object EnsureCachedObject(string key, Type type, ref bool initilize)
		{
			lock (cache.SyncRoot)
			{
				object obj = cache[key];
				if (obj == null)
				{
					obj = Activator.CreateInstance(type);
					initilize = true;		// the caller should initialize this object
					cache[key] = obj;		// cache the new instance
				}
				return obj;
			}
		}

		public static object GetCachedObject(string key)
		{
			return cache[key];
		}

		public static void CacheObject(string key, object obj)
		{
			lock (cache.SyncRoot)
			{
				cache[key] = obj;
			}
		}

		public static string[] CachedKeys
		{
			get
			{
				string[] arr = new string[cache.Keys.Count]; 
				cache.Keys.CopyTo(arr, 0);
				return arr;
			}
		}

		public static void ClearCache(string key)
		{
			lock (cache.SyncRoot)
			{
				cache.Remove(key);
			}
		}

		public static void ClearCache(string[] keys)
		{
			lock (cache.SyncRoot)
			{
				for (int i = 0; i < keys.Length; i++)
					cache.Remove(keys[i]);
			}
		}

		public static void ClearCache()
		{
			lock (cache.SyncRoot)
			{
				cache.Clear();
			}
		}

		public static void ClearCache(Type type, bool derived)
		{
			lock (cache.SyncRoot)
			{
				// detect objects of the given type
				ArrayList toremove = new ArrayList();
				foreach (DictionaryEntry de in cache)
				{
					object obj = de.Value;
					if (obj != null)
					{
						if (derived)
						{
							if (type.IsInstanceOfType(obj))
								toremove.Add(de.Key);
						}
						else
						{
							if (obj.GetType() == type)
								toremove.Add(de.Key);
						}
					}
				}

				// clear found items
				for (int i = 0; i < toremove.Count; i++)
				{
					cache.Remove((string)toremove[i]);
				}

			}
		}

	}
}
