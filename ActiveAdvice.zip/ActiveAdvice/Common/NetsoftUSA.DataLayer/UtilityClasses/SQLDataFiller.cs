using System;
using System.Data;
using System.Data.SqlClient;
using NetsoftUSA.DataLayer;
using System.Collections;
using System.Reflection;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Fills an object to/from an SQLDataDirect
	/// data source.  This means filling operations
	/// are directly done to the database without
	/// using a dataset.
	/// </summary>
	public class SQLDataFiller
	{
		#region Data Accessors

		public class SQLDataAccessor :DataFiller.IDataAccessor, IDisposable
		{
			private SQLDataDirect sqlData;
			private object[] values;

			public SQLDataAccessor(SQLDataDirect sqlData)
			{
				this.sqlData = sqlData;
				values = this.sqlData.MakeRowBuffer();
			}

			#region IEnumerable Members

			public IEnumerator GetEnumerator()
			{
				return sqlData.GetEnumerator();
			}

			#endregion

			#region IDataAccessor Members

			public object[] GetKeys()
			{
				return sqlData.Keys;
			}

			public object Get(object[] keys)
			{
				sqlData.SelectRow(values, keys);
				return values;
			}

			public object New()
			{
				values = sqlData.MakeRowBuffer();
				return values;
			}

			public void Update(object data)
			{
				sqlData.UpdateRow((object[])data);
			}

			public void Insert(object data)
			{
				sqlData.InsertRow((object[])data);
			}

			public void Delete(object[] keys)
			{
				sqlData.DeleteRow(keys);
			}

			public void DeleteAll()
			{
				sqlData.DeleteAll();
			}

			public DataFiller.IItemAccessor GetItemAccessor(object data)
			{
				return new SQLDataItemAccessor(sqlData, (object[])data);
			}

			#endregion

			#region IDisposable Members

			public void Dispose()
			{
				if (this.sqlData != null)
				{
					this.sqlData.CloseConnection();
				}
			}

			#endregion
		}

	
		/// <summary>
		/// Used as an item accessor on the given objec[] value buffer
		/// </summary>
		public class SQLDataItemAccessor :DataFiller.IItemAccessor, DataFiller.IRelationalDataProvider
		{
			private object[] values;
			private SQLDataDirect sqlData;

			public SQLDataItemAccessor(SQLDataDirect sqlData, object[] values)
			{
				this.sqlData = sqlData;
				this.values = (object[])values;
			}

			#region IItemAccessor Members

			public void SetData(object data)
			{
				this.values = (object[])data;
			}

			public object GetData()
			{
				return this.values;
			}

			public void SetItem(string colName, object val)
			{
				sqlData.SetItem(values, colName, val);
			}

			public object GetItem(string colName)
			{
				return sqlData.GetItem(values, colName);
			}

			#endregion

			#region IRelationalDataProvider Members

			public DataFiller.IDataAccessor CreateRelatedData(SimpleRelationAttribute rel, IList collection)
			{
				object val = sqlData.GetItem(values, rel.ParentColumn);
				string filter = null;

				string sval = null;
				if (val is String || val is DateTime || val is Guid)
					sval = "'" + Convert.ToString(val) + "'";
				else
					sval = Convert.ToString(val);

				if (rel.ChildTable == null)
					filter = String.Format("[{0}]={1}", rel.ChildColumn, sval);
				else
					filter = String.Format("[{0}].[{1}]={2}", rel.ChildTable, rel.ChildColumn, sval);
				
				string childTableName = rel.ChildTable;
				
				ElementTypeAttribute elemTypeAttrib = ElementTypeAttribute.GetFromCollection(collection);
				if (elemTypeAttrib == null)
					throw new ArgumentException("The collection class {0} must provide an ElementType attribute!", collection.GetType().Name);
				Type elemType = elemTypeAttrib.ElemType;
				if (elemType == null)
					throw new ArgumentException("The collection class {0} must provide an element type!", collection.GetType().Name);
				TableMappingAttribute tm = TableMappingAttribute.GetFromType(elemType);
				if (tm == null)
					throw new ArgumentException("Class {0} must provide element type and the element define a TableMapping attribute!", collection.GetType().Name);

				if (childTableName == null)
					childTableName = tm.GetTableNameForType(elemType);

				string pkColName = ColumnMappingAttribute.GetColumnNameForMember(elemType, tm.PKMemberName);
				//string[] cols = ColumnMappingAttribute.GetMappedColumnNames(elemType, true);
				ColumnInfo[] cols = ColumnMappingAttribute.GetMappedColumns(elemType, true);
				SQLDataDirect childSqlData = SQLDataDirect.CreateSqlDataForType(elemType, new SqlConnection(sqlData.ConnectionString), cols, filter, null, true);
					//new SQLDataDirect(new SqlConnection(sqlData.ConnectionString), childTableName, pkColName, SQLParser.MergeColumnNames(cols), filter);
				childSqlData.InsertPK = tm.InsertPK;
				return new SQLDataAccessor(childSqlData);
			}

			#endregion
		}
		#endregion

		#region Object filler functions

		/// <summary>
		/// Fills the public fields/properties of the given
		/// target object
		/// </summary>
		/// <param name="rowView"></param>
		/// <param name="TargetObject"></param>
		public static void FillIntoObject(SQLDataDirect sqlData, object[] values, object targetObj, bool ignoreAssignmentError, bool collections)
		{
			SQLDataItemAccessor sqlDataItemAcc = new SQLDataItemAccessor(sqlData, values);
			DataFiller.DataFillerParams parms = new DataFiller.DataFillerParams(targetObj, sqlDataItemAcc, ignoreAssignmentError, collections);
			DataFiller.FillIntoObject(parms);
		}

		public static void FillIntoObject(SQLDataDirect sqlData, object key, object targetObj, bool ignoreAssignmentError, bool collections)
		{
			object[] values = sqlData.MakeRowBuffer();
			sqlData.SelectRow(values, new object[] { key });

			FillIntoObject(sqlData, values, targetObj, ignoreAssignmentError, collections);
		}

		public static void FillIntoObject(SQLDataDirect sqlData, object[] values, object targetObj, string propOrFieldName, bool ignoreAssignmentError, bool collections)
		{
			SQLDataItemAccessor sqlDataItemAcc = new SQLDataItemAccessor(sqlData, values);
			DataFiller.DataFillerParams parms = new DataFiller.DataFillerParams(targetObj, sqlDataItemAcc, ignoreAssignmentError, collections);
			DataFiller.FillIntoObject(parms, propOrFieldName);
		}

		public static void FillIntoObject(SQLDataDirect sqlData, object key, object targetObj, string propOrFieldName, bool ignoreAssignmentError, bool collections)
		{
			object[] values = sqlData.MakeRowBuffer();
			sqlData.SelectRow(values, new object[] { key });

			FillIntoObject(sqlData, values, targetObj, propOrFieldName, ignoreAssignmentError, collections);
		}

		/// <summary>
		/// Used for on-demand load of a collection property
		/// </summary>
		/// <param name="sqlData"></param>
		/// <param name="targetObj"></param>
		/// <param name="propOrFieldName"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="collections"></param>
		public static void FillIntoObject(SQLDataDirect sqlData, object targetObj, string propOrFieldName, bool ignoreAssignmentError, bool collections)
		{
			object[] values = sqlData.MakeRowBuffer();
			sqlData.FillFromObject(values, targetObj, ignoreAssignmentError, false);	// first fill the containing class's all members into buffer

			FillIntoObject(sqlData, values, targetObj, propOrFieldName, ignoreAssignmentError, collections);
		}

		// 

		public static void FillFromObject(SQLDataDirect sqlData, object[] values, object sourceObj, bool ignoreAssignmentError, bool collections)
		{
			SQLDataItemAccessor sqlDataItemAcc = new SQLDataItemAccessor(sqlData, values);
			DataFiller.DataFillerParams parms = new DataFiller.DataFillerParams(sourceObj, sqlDataItemAcc, ignoreAssignmentError, collections);
			DataFiller.FillFromObject(parms);
		}

		public static object[] FillFromObject(SQLDataDirect sqlData, object sourceObj, bool ignoreAssignmentError, bool collections)
		{
			object[] values = sqlData.MakeRowBuffer();
			FillFromObject(sqlData, values, sourceObj, ignoreAssignmentError, collections);
			return values;
		}

		public static void FillFromObject(SQLDataDirect sqlData, object[] values, object sourceObj, string propOrFieldName, bool ignoreAssignmentError, bool collections)
		{
			SQLDataItemAccessor sqlDataItemAcc = new SQLDataItemAccessor(sqlData, values);
			DataFiller.DataFillerParams parms = new DataFiller.DataFillerParams(sourceObj, sqlDataItemAcc, ignoreAssignmentError, collections);
			DataFiller.FillFromObject(parms, propOrFieldName);
		}

		/// <summary>
		/// Used to save only a collection member of a data class.
		/// </summary>
		/// <param name="sqlData"></param>
		/// <param name="sourceObj"></param>
		/// <param name="propOrFieldName"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="collections"></param>
		/// <returns></returns>
		public static object[] FillFromObject(SQLDataDirect sqlData, object sourceObj, string propOrFieldName, bool ignoreAssignmentError, bool collections)
		{
			object[] values = sqlData.MakeRowBuffer();
			sqlData.FillFromObject(values, sourceObj, ignoreAssignmentError, false);	// first fill the containing class's all members into buffer

			FillFromObject(sqlData, values, sourceObj, propOrFieldName, ignoreAssignmentError, collections);
			return values;
		}

		/// <summary>
		/// Directly fill an object from the given data source. Also nullifies the contained
		/// and collection objects marked with SimpleRelation, SPLoadChild, or Contained attributes.
		/// </summary>
		/// <param name="sourceRdr"></param>
		/// <param name="targetObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		public static void FillIntoObject(SqlDataReader sourceRdr, object targetObj, bool ignoreAssignmentError)
		{
			Type tobj = targetObj.GetType();
			MemberInfo[] members = 
				ColumnMappingAttribute.FindColumnMappingMembersAndContained(
				System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field, 
				tobj);

			foreach (MemberInfo mi in members)
			{
				ColumnMappingAttribute colMap = ColumnMappingAttribute.GetFromMember(mi);
				if (colMap != null)
				{
					if ((colMap.FillFlags & DataFiller.FillFlags.DataToObject) != 0)
					{
						try
						{
							object val = sourceRdr[colMap.ColumnName];
							ReflectionHelper.SetMemberValue(targetObj, mi.Name, val);
						}
						catch(Exception ex)
						{
							if (!colMap.IsJoinColumn)	// joined columns are filled only when available
							{

								//System.Diagnostics.Debug.WriteLine(ex);
								if (!ignoreAssignmentError)
								{
									throw new Exception(
										String.Format("Column mapping error for member {0} of {1}! Mapped column name is [{2}] ", mi.Name, tobj, colMap.ColumnName), ex);
								}

							}
						}
					}
				}
				else
				{
					// nullify if contained or child collection
					if (SPLoadChildAttribute.GetFromMember(mi) != null ||
						ContainedAttribute.GetFromMember(mi) != null)
					{
						try
						{
							ReflectionHelper.SetMemberValue(targetObj, mi.Name, null);
						}
						catch
						{
							// always ignore assignment error.  the set method 
							// may not have been implemented by the target class at all.
						}
					}
				}
			}
		}

		#endregion

		#region Collection filler functions
		
		/// <summary>
		/// Basic function that appends the given sql data direct object's rows
		/// into the given IList based collection.  The elements
		/// added to the collection are of the type specified 
		/// type.  The collection is not cleared first.  
		/// No duplicate checking is done.
		/// </summary>
		/// <param name="sqlData"></param>
		/// <param name="collection"></param>
		/// <param name="elemType"></param>
		/// <param name="ignoreAssignmentError"></param>
		public static void AppendToCollection(SQLDataDirect sqlData, IList collection, Type elemType, bool ignoreAssignmentError, bool collections)
		{
			SQLDataAccessor dataAccessor = new SQLDataAccessor(sqlData);
			using (dataAccessor)
			{
				DataFiller.AppendToCollection(dataAccessor, collection, elemType, ignoreAssignmentError, collections);
			}
		}

		/// <summary>
		/// Basic function that appends the given sql data direct object's rows
		/// into the given IList based collection.  The elements
		/// added to the collection are of the type specified 
		/// by the collection's ElementType.  The collection
		/// is not cleared first.  No duplicate checking is done.
		/// </summary>
		/// <param name="sqlData"></param>
		/// <param name="collection"></param>
		/// <param name="ignoreAssignmentError"></param>
		public static void AppendToCollection(SQLDataDirect sqlData, IList collection, bool ignoreAssignmentError, bool collections)
		{
			SQLDataAccessor dataAccessor = new SQLDataAccessor(sqlData);
			using (dataAccessor)
			{
				DataFiller.AppendToCollection(dataAccessor, collection, ignoreAssignmentError, collections);
			}
		}

		public static void AppendKeysToCollection(SQLDataDirect sqlData, IList collection)
		{
			for (int i = 0; i < sqlData.Keys.Length; i++)
			{
				collection.Add(sqlData.Keys[i]);
			}
		}

		public static void FillFromCollection(SQLDataDirect sqlData, IList collection, bool ignoreAssignmentError, bool collections)
		{
			SQLDataAccessor dataAccessor = new SQLDataAccessor(sqlData);
			using (dataAccessor)
			{
				DataFiller.FillFromCollection(dataAccessor, collection, ignoreAssignmentError, collections);
			}
		}

		#endregion
	}
}
