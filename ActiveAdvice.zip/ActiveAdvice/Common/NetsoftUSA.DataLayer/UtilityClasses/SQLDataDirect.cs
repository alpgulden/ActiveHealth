using System;
using System.Data;
using System.Data.SqlClient;
using NetsoftUSA.DataLayer;
using System.Collections;
using System.Diagnostics;
using System.Text;
using Microsoft.ApplicationBlocks.Data;

namespace NetsoftUSA.DataLayer
{
	#region Enumerations

	/// <summary>
	/// SQLDataDirect uses this flag when generating sql statement.s
	/// You can specificy if a column is used in generation of four
	/// types of sql statements.  By default, all colums defined by
	/// ColumnMapping attribute are used.
	/// </summary>
	[Flags()]
	public enum SQLGenerationFlags
	{
		None = 0,
		NoInsert = 1,
		NoUpdate = 2,
		NoInsertUpdate = NoInsert | NoUpdate,
		NoSelect = 4
	}

	#endregion

	#region ColumnInfo Class

	/// <summary>
	/// Used by the SQLDataDirect class to store information
	/// about columns.  A collection of ColumnInfo objects
	/// can be imported to the SQLDataDirect object (ImportColumnInfoMap).
	/// </summary>
	public class ColumnInfo
	{
		private Type type;
		private string columnName;
		private SQLGenerationFlags sqlGenFlags = SQLGenerationFlags.None;
		public string InjectInsert;
		public string InjectUpdate;
		public string InjectSelect;

		private bool isJoinColumn;
		private string joinTableLeft;
		private string joinColumnLeft;
		private string joinTableRight;
		private string joinColumnRight;

		public ColumnInfo(string columnName, Type type)
		{
			this.columnName = columnName;
			this.type = type;
		}

		public ColumnInfo(string columnName, ColumnMappingAttribute colMap)
		{
			this.columnName = columnName;
			this.type = colMap.Type;
			this.sqlGenFlags = colMap.SQLGen;
			this.InjectInsert = colMap.InjectInsert;
			this.InjectUpdate = colMap.InjectUpdate;
			this.InjectSelect = colMap.InjectSelect;
			this.isJoinColumn = colMap.IsJoinColumn;
			if (this.isJoinColumn)
			{
				string left;
				string right;
				colMap.GetJoinRelation(out left, out right);
				SQLParser.ParseColumn(left, out joinTableLeft, out joinColumnLeft);
				SQLParser.ParseColumn(right, out joinTableRight, out joinColumnRight);
			}
		}

		public string ColumnName
		{
			get { return columnName; }
		}

		public SQLGenerationFlags SqlGenFlags
		{
			get { return sqlGenFlags; }
			set { sqlGenFlags = value; }
		}

		public bool IsJoinColumn
		{
			get { return this.isJoinColumn; }
			set { this.isJoinColumn = value; }
		}

		public string JoinTableLeft
		{
			get { return this.joinTableLeft; }
			set { this.joinTableLeft = value; }
		}

		public string JoinColumnLeft
		{
			get { return this.joinColumnLeft; }
			set { this.joinColumnLeft = value; }
		}

		public string JoinTableRight
		{
			get { return this.joinTableRight; }
			set { this.joinTableRight = value; }
		}

		public string JoinColumnRight
		{
			get { return this.joinColumnRight; }
			set { this.joinColumnRight = value; }
		}
		
		public string JoinRelation
		{
			get
			{
				if (this.isJoinColumn)
					return String.Format("[{0}].[{1}]=[{2}].[{3}]", this.joinTableLeft, this.joinColumnLeft, this.joinTableRight, this.joinColumnRight);
				else
					return null;
			}
		}

		public string LeftJoinStatement
		{
			get
			{
				if (this.isJoinColumn)
					return "left join [" + this.joinTableRight + "] on " + this.JoinRelation;
				else
					return null;
			}
		}

		public Type Type
		{
			get
			{
				return this.type;
			}
		}
	}

	#endregion

	#region SQLDataDirect Class

	/// <summary>
	/// Directly accesses an SQL database.  Data rows
	/// are filled into an object[] array.
	/// This class is enumerable.  Rows for the
	/// specified filter are returned directly 
	/// from database.  This class can also fill members
	/// of a data given class (see Fill methods).
	/// A good technique is to keep a SQLDataDirect
	/// instance in a data class implementation
	/// and use its fill methods to fill the members
	/// of that data class.  Use this as a helper to build
	/// strongly typed data classes.
	/// </summary>
	public class SQLDataDirect : IEnumerable	
	{
		#region Private members

		private object[] keys;
		private Hashtable keyIndices;

		private SqlConnection connection;
		private string tableName;
		private string columns;
		private string where;
		private string sort;
		private bool insertPK;			// use PK in the insert statement
		private string[] PK = null;
		private int[] pkIndex = null;

		private string[] columnArray;
		private Hashtable columnInfoMap;		// created on demand
		private Hashtable columnIndices;

		private SqlCommand selectKeysCommand;
		private SqlCommand selectCommand;
		private SqlCommand updateCommand;
		private SqlCommand insertCommand;
		private SqlCommand deleteCommand;
		private SqlCommand existsCommand;
		private SqlCommand sqlCommand;

		// stored procedure access.
		// if a stored procedure name is set, it'll be used to create the command
		private string spLoad = null;
		private string spUpdate = null;
		private string spInsert = null;
		private string spDelete = null;
		private string spExists = null;

		// SQLParser may be given in the constructor for query and iteration purposes
		private SQLParser sql;

		private string joinStatements;		// prepared once
		private bool useJoinColumns = true;

		private SqlTransaction transaction;
		private bool isForeignTransaction = false;

		// User security context
		NetsoftUSA.Security.PrincipalEx principal;

		#endregion

		#region Public Constructors

		public SQLDataDirect(string connection, string tableName, string PK, string columns, bool detectColumns)
			: this(new SqlConnection(connection), tableName, PK, columns, null, null, detectColumns)
		{
		}

		public SQLDataDirect(string connection, string tableName, string PK, string columns, string filter, bool detectColumns)
			: this(new SqlConnection(connection), tableName, PK, columns, filter, null, detectColumns)
		{
		}

		public SQLDataDirect(SqlConnection connection, string tableName, string PK, string columns, bool detectColumns)
			: this(connection, tableName, PK, columns, null, null, detectColumns)
		{
		}

		public SQLDataDirect(SqlConnection connection, string tableName, string PK, string columns, string filter, bool detectColumns)
			: this(connection, tableName, PK, columns, filter, null, detectColumns)
		{
		}

		/* doesn't work! wouldn't be much efficient either.
		 * private string FindPK(string tableName)
		{
			OpenConnection();
			try
			{
				DataSet ds = NSGlobal.ExecuteDataset(this.Connection, "select * from ["+tableName+"] where 1=2", tableName);
				//DataSet ds = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(
				//	this.Connection, CommandType.Text, "select * from ["+tableName+"] where 1=2");
				return ds.Tables[0].PrimaryKey[0].ColumnName;
			}
			finally
			{
				CloseConnection();
			}
		}*/

		public SQLDataDirect(SqlConnection connection, string tableName, string PK, string columns, string filter, string sort, bool detectColumns)
		{
			this.connection = connection;
			this.tableName = tableName;
			//if (PK == null)
			//	PK = FindPK(tableName);
			if (PK  != null)
				this.PK = PK.Split(',');

			// parse columns, store each column name in an array
			// and a map of array indices.
			if (columns == null || columns == "" || columns == "*")
				if (detectColumns)
					columns = SQLParser.MergeColumnNames(SQLParser.FindTableColumns(connection, tableName, false, false));

			this.columns = columns;
			columnArray = columns.Split(',');
			columnIndices = new Hashtable();
			for (int i = 0; i < columnArray.Length; i++)
			{
				string s = columnArray[i].Trim(' ', '[', ']');
				columnArray[i] = s;
				if (s != "")
					columnIndices.Add(s, i);
			}

			if (this.PK != null)
			{
				pkIndex = new int[this.PK.Length];
				for (int i = 0; i < this.PK.Length; i++)
					pkIndex[i] = GetColumnIndex(this.PK[i]);
			}

			this.where = filter;
			this.sort = sort;
		}

		public SQLDataDirect(string connection, SQLParser sql, bool detectColumns)
			: this(new SqlConnection(connection), sql, detectColumns)
		{
		}

		public SQLDataDirect(SqlConnection connection, SQLParser sql, bool detectColumns)
		{
			this.sql = sql;
			this.connection = connection;

			this.columnArray = sql.GetSimpleColumnNames(connection, false);
			columns = SQLParser.MergeColumnNames(columnArray);
			tableName = sql.Tables[0];

			columnIndices = new Hashtable();
			for (int i = 0; i < columnArray.Length; i++)
			{
				string s = columnArray[i];
				if (s != "")
					columnIndices.Add(s, i);
			}
		}
		
		#endregion

		private Hashtable ColumnInfoMap
		{
			get
			{   
				if (columnInfoMap == null)
					columnInfoMap = new Hashtable();
				return columnInfoMap;
			}
		}

		public ColumnInfo GetColumnInfo(string colName, bool useDefault)
		{
			try
			{
				return (ColumnInfo)ColumnInfoMap[colName];
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex);
				if (useDefault)
					return new ColumnInfo(colName, typeof(string));
				else
					return null;
			}
		}

		public ColumnInfo EnsureColumnInfo(string colName)
		{
			try
			{
				return (ColumnInfo)ColumnInfoMap[colName];
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex);
				ColumnInfo colInfo = new ColumnInfo(colName, typeof(string));
				ColumnInfoMap[colName] = colInfo;
				return colInfo;
			}
		}

		public string GetInjectSelect(string colName)
		{
			ColumnInfo colInfo = GetColumnInfo(colName, false);
			if (colInfo == null)
				return null;

			return colInfo.InjectSelect;
		}

		public string GetInjectInsert(string colName)
		{
			ColumnInfo colInfo = GetColumnInfo(colName, false);
			if (colInfo == null)
				return null;

			return colInfo.InjectInsert;
		}

		public string GetInjectUpdate(string colName)
		{
			ColumnInfo colInfo = GetColumnInfo(colName, false);
			if (colInfo == null)
				return null;

			return colInfo.InjectUpdate;
		}

		public bool IsColSelectExcluded(string colName)
		{
			ColumnInfo colInfo = GetColumnInfo(colName, false);

			return IsColSelectExcluded(colInfo);
		}

		public bool IsColSelectExcluded(ColumnInfo colInfo)
		{
			if (colInfo == null)
				return false;
			if (colInfo.IsJoinColumn)
				if (!useJoinColumns)
					return true;
			return (colInfo.SqlGenFlags & SQLGenerationFlags.NoSelect) != 0;
		}

		public bool IsColInsertExcluded(string colName)
		{
			ColumnInfo colInfo = GetColumnInfo(colName, false);

			return IsColInsertExcluded(colInfo);
		}

		public bool IsColInsertExcluded(ColumnInfo colInfo)
		{
			if (colInfo == null)
				return false;
			if (colInfo.IsJoinColumn)
				return true;
			return (colInfo.SqlGenFlags & SQLGenerationFlags.NoInsert) != 0;
		}

		public bool IsColUpdateExcluded(string colName)
		{
			ColumnInfo colInfo = GetColumnInfo(colName, false);

			return IsColUpdateExcluded(colInfo);
		}

		public bool IsColUpdateExcluded(ColumnInfo colInfo)
		{
			if (colInfo == null)
				return false;
			if (colInfo.IsJoinColumn)
				return true;
			return (colInfo.SqlGenFlags & SQLGenerationFlags.NoUpdate) != 0;
		}

		public void SetColSQLGenFlags(string colName, SQLGenerationFlags sqlGenFlags)
		{
			EnsureColumnInfo(colName).SqlGenFlags = sqlGenFlags;
		}

		public void ImportColumnInfoMap(ColumnInfo[] colInfos)
		{
			this.columnInfoMap = null;
			Hashtable map = this.ColumnInfoMap;
			for (int i = 0; i < colInfos.Length; i++)
			{
				ColumnInfo colInfo = colInfos[i];
				map[colInfo.ColumnName] = colInfo;
			}
		}

		private string MakeColName(ColumnInfo colInfo)
		{
			if (colInfo.IsJoinColumn)
				return String.Format("[{0}].[{1}]", colInfo.JoinTableRight, colInfo.ColumnName);
			else
				return String.Format("[{0}].[{1}]", this.tableName, colInfo.ColumnName);
		}

		private string MakeColName(string col)
		{
			if (this.HasJoinStatements)
			{
				ColumnInfo colInfo = GetColumnInfo(col, false);
				if (colInfo != null)
					return MakeColName(colInfo);
				else
					return String.Format("[{0}]", col);
			}
			else
				return String.Format("[{0}]", col);
		}

		private string MakeColNames(string columns)
		{
			string[] columnArray = SQLParser.ParseColumnNames(columns);
			return MakeColNames(columnArray);
		}

		private string MakeColNames(string[] columnArray)
		{
			string colNames = null;
			for (int i = 0; i < columnArray.Length; i++)
			{
				string colName = columnArray[i];
				if (!IsColSelectExcluded(colName))
				{
					if (colNames != null)
						colNames += ",";
					colNames += MakeColName(colName);
				}
			}
			return colNames;
		}

		#region SQL Command creators

		private SqlCommand SelectKeysCommand
		{
			get
			{
				if (selectKeysCommand == null)
				{
					string sql = "select " + MakeColNames(PK) + " from [" + tableName + "]";

					sql = AppendJoinStatements(sql);
					selectKeysCommand = new SqlCommand(sql, connection);
					AppendFilterAndSort(selectKeysCommand, true);
				}

				OpenConnection();
				return selectKeysCommand;
			}
		}

		private bool HasJoinStatements
		{
			get
			{
				if (!this.useJoinColumns)
					return false;
				string joinStatements = this.JoinStatements;
				if (joinStatements != null && joinStatements.Length != 0)
					return true;
				else
					return false;
			}
		}

		private string AppendJoinStatements(string sql)
		{
			string joinStatements = this.JoinStatements;
			if (joinStatements != null && joinStatements.Length != 0)
				sql += " " + JoinStatements;
			return sql;
		}

		private void AppendFilterAndSort(SqlCommand cmd, bool useWhereKeyword)
		{
			SQLParser.AppendFilterAndSort(cmd, this.where, this.sort, useWhereKeyword);
		}

		/*private string AppendFilterAndSort(string sql)
		{
			if (where != null && where != "")
				sql += " where " + where;

			if (sort != null && sort != "")
				sql += " order by " + sort;

			return sql;
		}*/

		public string JoinStatements
		{
			get
			{
				if (!this.useJoinColumns)
					return null;
				if (joinStatements == null)
					joinStatements = CreateJoinStatements();
				return joinStatements;
			}
		}

		private string CreateJoinStatements()
		{
			if (columnInfoMap == null)
				return null;
			
			Hashtable usedJoins = new Hashtable();
			foreach (DictionaryEntry colInfEntry in columnInfoMap)
			{
				ColumnInfo colInf = (ColumnInfo)colInfEntry.Value;
				if (colInf.IsJoinColumn)
				{
					if (!usedJoins.Contains(colInf.JoinTableRight))
					{
						usedJoins[colInf.JoinTableRight] = colInf.LeftJoinStatement;
					}
				}
			}

			StringBuilder joinClauses = new StringBuilder();
			bool anyJoins = false;
			foreach (DictionaryEntry joinEntry in usedJoins)
			{
				string join = (string)joinEntry.Value;
				joinClauses.Append(join);
				joinClauses.Append(' ');
				anyJoins = true;
			}

			if (!anyJoins)
				this.useJoinColumns = false;	// no longer try to detect the join columns

			return joinClauses.ToString();
		}

		public SqlCommand SelectRowsCommand(string columns, string where, string sort)
		{
			if (columns == null)
				columns = this.columns;

			if (where == null)
				where = this.where;

			if (sort == null)
				sort = this.sort;

			//string sql = "select " + columns + " from [" + tableName + "]";
			string sql = "select " + MakeColNames(columns) + " from [" + tableName + "]";

			sql = AppendJoinStatements(sql);
			SqlCommand cmd = new SqlCommand(sql, connection);
			AppendFilterAndSort(cmd, true);
			
			OpenConnection();
			return cmd;
		}

		public void ResetSelectCommand()
		{
			selectCommand = null;
		}

		public string GetWhereForPK()
		{
			if (PK == null)
				return null;
			if (PK.Length == 0)
				return null;

			string sql = "(";
			for (int i = 0; i < PK.Length; i++)
			{
				if (i > 0)
					sql += " and ";
				sql += String.Format("{0}=@{1}", MakeColName(PK[i]), PK[i]);
			}

			sql += ")";

			return sql;
		}

		public SqlCommand SelectCommand
		{
			get
			{
				if (selectCommand == null)
				{	
					if (spLoad != null)
					{	// stored procedure for SELECT  (key)
						selectCommand = new SqlCommand(spLoad, connection);
						SelectCommand.CommandType = CommandType.StoredProcedure;
						//selectCommand.Parameters.Add("@ID", DBNull.Value);
						AddPKCommandParams(selectCommand);
					}
					else
					{
						//string sql = String.Format("select {0} from [{1}]",
						//	columns, tableName);
						string sql = String.Format("select {0} from [{1}]",
							MakeColNames(this.columnArray), tableName);

						sql = AppendJoinStatements(sql);
						sql += " where " + GetWhereForPK();

						selectCommand = new SqlCommand(sql, connection);
						AddPKCommandParams(selectCommand);
					}
				}

				OpenConnection();
				return selectCommand;
			}
		}

		public void SelectCommandParams(object[] Keys)
		{
			//selectCommand.Parameters["@ID"].Value = Key;
			SetPKCommandParams(selectCommand, Keys);
		}

		public bool IsPK(string columnName)
		{
			for (int i = 0; i < PK.Length; i++)
				if (String.Compare(columnName, PK[i], true) == 0)
					return true;

			return false;
		}

		public SqlCommand UpdateCommand
		{
			get
			{
				if (updateCommand == null)
				{
					if (spUpdate != null)
					{	// update stored proc
						updateCommand = new SqlCommand();
						updateCommand.CommandType = CommandType.StoredProcedure;
						//updateCommand.Parameters.Add("@ID", DBNull.Value);
						AddPKCommandParams(updateCommand);

						for (int i = 0; i < columnArray.Length; i++)
						{
							string col = columnArray[i];
							ColumnInfo colInfo = GetColumnInfo(col, false);
							if (!IsColUpdateExcluded(colInfo))
								if (!IsPK(col))	// if not PK
								{
									string parName  = MakeParamName(col);
									//updateCommand.Parameters.Add(parName, DBNull.Value);
									updateCommand.Parameters.Add(parName, SQLParser.TypeToSqlDbType(colInfo.Type));
								}
						}

						updateCommand.CommandText = spUpdate;
						updateCommand.Connection = this.Connection;
					}
					else
					{	// update sql statement
						updateCommand = new SqlCommand();
						string setCols = "";
						for (int i = 0; i < columnArray.Length; i++)
						{
							string col = columnArray[i];
							ColumnInfo colInfo = GetColumnInfo(col, false);
							if (!IsColUpdateExcluded(colInfo))
								if (!IsPK(col))	// if not PK
								{
									if (setCols != "")
										setCols += ", ";
									string parName = MakeParamName(col);

									if (colInfo.InjectUpdate != null)
										setCols += String.Format("[{0}]={1}", col, colInfo.InjectUpdate);
									else
										setCols += String.Format("[{0}]={1}", col, parName);
									//updateCommand.Parameters.Add(parName, SQLParser.TypeToSqlDbType(colInfo.Type)); // DBNull.Value);
									updateCommand.Parameters.Add(parName, SQLParser.TypeToSqlDbType(colInfo.Type)); // DBNull.Value);
								}
						}

						string sql = String.Format("update [{0}] set {1} where {2}",
							tableName, setCols, GetWhereForPK());
						//updateCommand.Parameters.Add("@ID", DBNull.Value);
						AddPKCommandParams(updateCommand);

						updateCommand.CommandText = sql;
						updateCommand.Connection = this.Connection;
					}
				}

				OpenConnection();
				return updateCommand;
			}
		}

		public SqlCommand ExistsCommand
		{
			get
			{
				if (existsCommand == null)
				{	
					if (spExists != null)
					{	// stored procedure for exists  (key)
						existsCommand = new SqlCommand(spExists, connection);
						existsCommand.CommandType = CommandType.StoredProcedure;
						//existsCommand.Parameters.Add("@ID", DBNull.Value);
						AddPKCommandParams(existsCommand);
					}
					else
					{
						string sql = String.Format("select count(*) from [{0}] where {1}",
							tableName, GetWhereForPK());
						existsCommand = new SqlCommand(sql, connection);
						//existsCommand.Parameters.Add("@ID", DBNull.Value);
						AddPKCommandParams(existsCommand);
					}
				}

				OpenConnection();
				return existsCommand;
			}
		}

		public void AddPKCommandParams(SqlCommand cmd)
		{
			for (int i = 0; i < PK.Length; i++)
				cmd.Parameters.Add("@" + PK[i], DBNull.Value);
		}

		public void SetPKCommandParams(SqlCommand cmd, object[] Keys)
		{
			for (int i = 0; i < PK.Length; i++)
				cmd.Parameters["@" + PK[i]].Value = Keys[i];
		}

		public void ExistsCommandParams(object[] Keys)
		{
			SetPKCommandParams(existsCommand, Keys);
		}

		public static object MakeDBValue(object val)
		{
			if (val == null)
				return DBNull.Value;
			else
			{
				// automatically detect null value for some 
				// of the standard types.
				if (val is DateTime)
					if ((DateTime)val == DateTime.MinValue)
						return DBNull.Value;
				if (val is decimal)
					if ((decimal)val == decimal.MinValue)
						return DBNull.Value;
				if (val is float)
					if (float.IsNaN((float)val))
						return DBNull.Value;
				if (val is double)
					if (double.IsNaN((double)val))
						return DBNull.Value;
				return val;
			}
		}

		public static object MakeDBValue(object val, object valueForNull)
		{
			if (val == null)
				return DBNull.Value;
			
			if (val.Equals(valueForNull))
				return DBNull.Value;
			else
				return val;
		}

		public void UpdateCommandParams(object[] values, object[] Keys)
		{
			SetPKCommandParams(updateCommand, Keys);
			for (int i = 0; i < columnArray.Length; i++)
			{
				string col = columnArray[i];
				if (!IsColUpdateExcluded(col))
					if (!IsPK(col))	// if not PK
					{
						string parName  = MakeParamName(col);
						updateCommand.Parameters[parName].Value = MakeDBValue(values[i]);
					}
			}
		}

		public SqlCommand InsertCommand
		{
			get
			{
				if (insertCommand == null)
				{
					if (spInsert != null)
					{	// insert stored proc
						insertCommand = new SqlCommand();
						insertCommand.CommandType = CommandType.StoredProcedure;

						for (int i = 0; i < columnArray.Length; i++)
						{
							string col = columnArray[i];
							ColumnInfo colInfo = GetColumnInfo(col, false);
							if (!IsColInsertExcluded(colInfo))
								if (insertPK || !IsPK(col))	// if not PK
								{
									string parName  = MakeParamName(col);
									insertCommand.Parameters.Add(parName, SQLParser.TypeToSqlDbType(colInfo.Type)); //DBNull.Value);
								}
						}

						insertCommand.CommandText = spInsert;
						insertCommand.Connection = this.Connection;
					}
					else
					{	// insert sql statement
						insertCommand = new SqlCommand();
						string cols = "";
						string parNames = "";
						for (int i = 0; i < columnArray.Length; i++)
						{
							string col = columnArray[i];
							ColumnInfo colInfo = GetColumnInfo(col, false);
							if (!IsColInsertExcluded(colInfo))
								if (insertPK || !IsPK(col))	// if not PK
								{
									string parName  = MakeParamName(col);

									if (cols != "")
									{
										cols += ", ";
										parNames += ", ";
									}
									cols += "[" + col + "]";

									if (colInfo.InjectInsert != null)
										parNames += colInfo.InjectInsert;
									else
										parNames += parName;
									
									insertCommand.Parameters.Add(parName, SQLParser.TypeToSqlDbType(colInfo.Type)); // DBNull.Value);
								}
						}

						string sql = String.Format("insert into [{0}] ({1}) values ({2})",
							tableName, cols, parNames);

						if (!insertPK)
							sql += ";select @@IDENTITY";

						insertCommand.CommandText = sql;
						insertCommand.Connection = this.Connection;
					}
				}

				OpenConnection();
				return insertCommand;
			}
		}

		public void InsertCommandParams(object[] values)
		{
			for (int i = 0; i < columnArray.Length; i++)
			{
				string col = columnArray[i];
				if (!IsColInsertExcluded(col))
					if (insertPK || !IsPK(col))	// if not PK
					{
						string parName  = MakeParamName(col);
						insertCommand.Parameters[parName].Value = values[i]; // MakeDBValue(values[i]);
					}
			}
		}

		public SqlCommand DeleteCommand
		{
			get
			{
				if (deleteCommand == null)
				{
					if (spDelete != null)
					{	// delete stored proc
						deleteCommand = new SqlCommand(spDelete, connection);
						deleteCommand.CommandType = CommandType.StoredProcedure;
						//deleteCommand.Parameters.Add("@ID", DBNull.Value);
						AddPKCommandParams(deleteCommand);
					}
					else
					{	// delete sql statement
						string sql = String.Format("delete from [{0}] where {1}",
							tableName, GetWhereForPK());

						deleteCommand = new SqlCommand(sql, connection);
						//deleteCommand.Parameters.Add("@ID", DBNull.Value);
						AddPKCommandParams(deleteCommand);
					}
				}

				OpenConnection();
				return deleteCommand;
			}
		}

		public void DeleteCommandParams(object[] Keys)
		{
			//deleteCommand.Parameters["@ID"].Value = Key;
			SetPKCommandParams(deleteCommand, Keys);
		}

		public SqlCommand SQLCommand
		{
			get
			{
				if (sqlCommand == null)
				{
					sqlCommand = sql.CreateSqlCommand(connection, false);
				}

				OpenConnection();
				return sqlCommand;
			}
		}

		public SqlCommand SelectByColumnValuesCommand(string[] columnNames, object[] columnValues, bool excludeNullColumns)
		{
			return SelectByColumnValuesCommand(columnNames ,columnValues, excludeNullColumns, null);
		}

		public SqlCommand SelectByColumnValuesCommand(string[] columnNames, object[] columnValues, bool excludeNullColumns, string sort)
		{
			return SelectByColumnValuesCommand(columnNames, null, columnValues, excludeNullColumns, sort);
		}

		public SqlCommand SelectByColumnValuesCommand(string[] columnNames, string[] operators, object[] columnValues, bool excludeNullColumns, string sort)
		{
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = this.Connection;

			string where = "";
			for (int i = 0; i < columnNames.Length; i++)
			{
				string col = columnNames[i];
				object val = columnValues[i];
				if (excludeNullColumns && val is DBNull)
					continue;
				else
				{
					if (where.Length > 0)
						where += " and ";
					string par = MakeParamName(col);
					string op = "=";
					if (operators != null)
						op = operators[i];
					where += String.Format("{0} {1} {2}", MakeColName(col), op, par);
					cmd.Parameters.Add(par, val);
				}
			}

			//string sql = String.Format("select {0} from [{1}] where {2}",
			//	columns, tableName, where);
			string sql = String.Format("select {0} from [{1}] ",
				MakeColNames(this.columnArray), tableName, where);

			sql = AppendJoinStatements(sql);
			sql += String.Format(" where {0}", where);

			if (sort != null)
				sql += " order by " + sort;

			cmd.CommandText = sql;

			OpenConnection();
			return cmd;
		}

		/// <summary>
		/// Make a stored proc command with the paramters specified
		/// </summary>
		/// <param name="sproc"></param>
		/// <param name="paramNames"></param>
		/// <param name="columnValues"></param>
		/// <returns></returns>
		public SqlCommand StoredProcCommand(string sproc, string[] paramNames, object[] columnValues)
		{
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = this.Connection;
			SQLParamFiller.FillParameters(cmd.Parameters, paramNames, columnValues);

			cmd.CommandText = sproc;
			cmd.CommandType = CommandType.StoredProcedure;

			OpenConnection();
			return cmd;
		}

		/// <summary>
		/// Make an sql command and fill the paramters collection with the specified parameters
		/// </summary>
		/// <param name="sql"></param>
		/// <param name="paramNames"></param>
		/// <param name="columnValues"></param>
		/// <returns></returns>
		public SqlCommand MakeSQLCommand(string sql, string[] paramNames, object[] columnValues)
		{
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = this.Connection;
			SQLParamFiller.FillParameters(cmd.Parameters, paramNames, columnValues);

			cmd.CommandText = sql;
			cmd.CommandType = CommandType.Text;

			OpenConnection();
			return cmd;
		}

		/// <summary>
		/// Make a sql command and also extract parameters and fill parameters
		/// </summary>
		/// <param name="sql"></param>
		/// <returns></returns>
		public SqlCommand MakeSQLCommand(string sql)
		{
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = this.Connection;
			SQLParser.ExtractParameters(sql, cmd.Parameters);
			cmd.CommandText = sql;
			cmd.CommandType = CommandType.Text;

			OpenConnection();
			return cmd;
		}

		#endregion

		#region Private functions


		#endregion

		#region Public functions

		public void OpenConnection()
		{
			if (this.transaction != null)
				return;							// fix-1
			if (connection.State != ConnectionState.Open)
				connection.Open();
		}

		public SqlTransaction BeginOuterTransaction()
		{
			OpenConnection();
			this.isForeignTransaction = true;
			this.transaction = connection.BeginTransaction();
			return this.transaction;
		}

		public SqlTransaction BeginTransaction()
		{
			OpenConnection();
			this.isForeignTransaction = false;
			this.transaction = connection.BeginTransaction();
			return this.transaction;
		}

		public SqlTransaction BeginTransaction(string transactionName)
		{
			OpenConnection();
			this.isForeignTransaction = false;
			this.transaction = connection.BeginTransaction(transactionName);
			return this.transaction;
		}

		public SqlTransaction BeginTransaction(IsolationLevel iso)
		{
			OpenConnection();
			this.isForeignTransaction = false;
			this.transaction = connection.BeginTransaction(iso);
			return this.transaction;
		}

		public SqlTransaction BeginTransaction(IsolationLevel iso, string transactionName)
		{
			OpenConnection();
			this.isForeignTransaction = false;
			this.transaction = connection.BeginTransaction(iso, transactionName);
			return this.transaction;
		}

		//-- Use if passed or create new transaction

		public SqlTransaction EnsureTransaction()
		{
			if (transaction == null)
				return this.BeginTransaction();
			return transaction;
		}

		public SqlTransaction EnsureTransaction(string transactionName)
		{
			if (transaction == null)
				return this.BeginTransaction(transactionName);
			return transaction;
		}

		public SqlTransaction EnsureTransaction(IsolationLevel iso)
		{
			if (transaction == null)
				return this.BeginTransaction(iso);
			return transaction;
		}

		public SqlTransaction EnsureTransaction(IsolationLevel iso, string transactionName)
		{
			if (transaction == null)
				return this.BeginTransaction(iso, transactionName);
			return transaction;
		}

		//--

		public void CommitTransaction()
		{
			if (this.transaction == null)
				return;
			if (!this.isForeignTransaction)
			{
				this.Transaction.Commit();
			}
			this.CloseTransaction();
		}

		public void RollbackTransaction()
		{
			if (this.transaction == null)
				return;
			if (!this.isForeignTransaction)
				this.Transaction.Rollback();
			this.CloseTransaction();
		}

		public void RollbackTransaction(string transactionName)
		{
			if (this.transaction == null)
				return;
			if (!this.isForeignTransaction)
				this.Transaction.Rollback(transactionName);
			this.CloseTransaction();
		}

		/// <summary>
		/// If there's a transacation, the call to this function does nothing.
		/// </summary>
		public void CloseConnection()
		{
			if (transaction != null)		// if there's a transaction, do not close the connection, because it may be in use by others
				return;
			if (connection == null)
				return;
			if (connection.State != ConnectionState.Closed)
				connection.Close();
			if (connection.State != ConnectionState.Closed)
			{
				Debug.WriteLine("connection state not closed");
			}
		}

		/// <summary>
		/// Closing transaction also closes connection
		/// </summary>
		public void CloseTransaction()
		{
			if (transaction == null)
				return;
			if (!isForeignTransaction)		// fix-1
			{
				if (this.connection != null)
					if (this.connection.State != ConnectionState.Closed)
						this.connection.Close();
			}
			transaction = null;
			isForeignTransaction = false;
		}

		/// <summary>
		/// If a transaction is set, its connection is used.
		/// </summary>
		public SqlTransaction Transaction
		{
			get { return this.transaction; }
			set 
			{
				CloseConnection();		// fix-1
				this.transaction = value; 
				this.isForeignTransaction = this.transaction != null;	// don't commit or rollback this transaction
			}
		}

		public bool IsForeignTransaction
		{
			get
			{
				return this.isForeignTransaction;
			}
		}
		
		public void RequireTransaction(SqlTransaction transaction)
		{
			if (transaction == null)
				throw new Exception("Null transaction can't be used!");
			this.Transaction = transaction;
		}

		public void UnuseTransaction()
		{
			this.Transaction = null;
		}

		public void UseTransaction(SQLDataDirect sqlData)
		{
			if (sqlData.Transaction == null)
				throw new Exception("SqlData specified has no transaction to use!");
			this.Transaction = sqlData.Transaction;
		}

		public void UseTransaction(BaseDataClass data)
		{
			if (data.SqlData.Transaction == null)
				throw new Exception("SqlData of the specified data object has no transaction to use!");
			this.Transaction = data.SqlData.Transaction;
		}

		public void UseTransaction(BaseDataCollectionClass dataCol)
		{
			if (dataCol.SqlData.Transaction == null)
				throw new Exception("The specified data collection has no transaction to use!");
			this.Transaction = dataCol.SqlData.Transaction;
		}

		public SqlConnection Connection
		{
			get
			{
				if (this.transaction != null)
					return this.transaction.Connection;
				else
					return this.connection;
			}
			set
			{
				this.connection = value;
				this.transaction = null;
			}
		}

		public string ConnectionString
		{
			get
			{
				return this.Connection.ConnectionString;
			}
		}

		public bool HasTransaction
		{
			get { return this.transaction != null; }
		}

		public bool HasSQL
		{
			get
			{
				return this.sql != null;
			}
		}

		public bool InsertPK
		{
			get { return insertPK; }
			set { insertPK = value; }
		}

		public void LoadKeys(string filter, string sort)
		{
			if (filter != null)
				this.where = filter;
			if (sort != null)
				this.sort = sort;
			LoadKeys();
		}

		public void LoadKeys(string filter)
		{
			LoadKeys(filter, null);
		}

		public void LoadKeys()
		{
			SqlCommand cmd = SelectKeysCommand;
			SqlDataReader rdr = null;
			try
			{
				rdr = cmd.ExecuteReader();
				keys = NSGlobal.GetColumnValuesFromDataReader(rdr, 0);
			}
			finally
			{
				if (rdr != null)
					rdr.Close();
				CloseConnection();
			}
			keyIndices = NSGlobal.CreateHashtableWithIndices(keys);
		}

		public object[] Keys
		{
			get
			{ 
				if (keys == null)
					LoadKeys();
				return keys; 
			}
		}

		/// <summary>
		/// Create an empty buffer to keep a row data
		/// </summary>
		/// <returns></returns>
		public object[] MakeRowBuffer()
		{
			return new object[this.columnArray.Length];
		}

		public static string ValueToSQLString(object value)
		{
			if (value is string)
				return "'" + (string)value + "'";
			else
				return Convert.ToString(value);
		}

		public static string MakeParamName(string s)
		{
			return "@" + s.Replace(" ", "_").Replace("/", "_");
		}

		public SqlDataReader ExecuteReader(string columns, string where, string sort)
		{
			SqlCommand cmd = SelectRowsCommand(columns, where, sort);
			return cmd.ExecuteReader();
		}

		public SqlDataReader ExecuteReader(string columns, string where)
		{
			SqlCommand cmd = SelectRowsCommand(columns, where, null);
			return cmd.ExecuteReader();
		}

		public SqlDataReader ExecuteReader(string where)
		{
			SqlCommand cmd = SelectRowsCommand(null, where, null);
			return cmd.ExecuteReader();
		}

		public SqlDataReader ExecuteReader()
		{
			SqlCommand cmd = null;
			if (sql != null)
				cmd = SQLCommand;
			else
				cmd = SelectRowsCommand(null, null, null);
			return cmd.ExecuteReader();
		}

		/*
		public SqlDataReader ExecuteReader(string columns, string where, string sort)
		{
			SqlCommand cmd = SelectRowsCommand(columns, where, sort);
			//SelectCommandParams(Key);
			return cmd.ExecuteReader();
		}*/

		public bool Exists(object[] Keys)
		{
			if (Keys == null || NSGlobal.HasAnyNull(Keys))
				return false;
			SqlCommand cmd = ExistsCommand;
			SqlDataReader rdr = null;
			try
			{
				ExistsCommandParams(Keys);

				rdr = cmd.ExecuteReader(CommandBehavior.SingleRow | CommandBehavior.CloseConnection);
				if (rdr.Read())
				{
					int count = (int)rdr.GetValue(0);
					return count > 0;
				}
			}
			finally
			{
				if (rdr != null)
					rdr.Close();
				CloseConnection();
			}
			return false;
		}

		public bool SelectRow(object[] values, object[] Keys)
		{
			SqlCommand cmd = SelectCommand;
			SqlDataReader rdr = null;
			try
			{
				SelectCommandParams(Keys);

				rdr = cmd.ExecuteReader(CommandBehavior.SingleRow | CommandBehavior.CloseConnection);
				if (rdr.Read())
				{
					rdr.GetValues(values);
					return true;
				}
			}
			finally
			{
				if (rdr != null)
					rdr.Close();
				CloseConnection();
			}
			return false;
		}

		public SqlDataReader ExecuteReader(string[] columnNames, object[] columnValues, bool excludeNullColumns)
		{
			return ExecuteReader(false, columnNames, columnValues, excludeNullColumns, null);
		}

		public SqlDataReader ExecuteReader(string[] columnNames, object[] columnValues, bool excludeNullColumns, string sort)
		{
			return ExecuteReader(false, columnNames, columnValues, excludeNullColumns, sort);
		}

		public SqlDataReader ExecuteReader(bool singleRow, string[] columnNames, object[] columnValues, bool excludeNullColumns)
		{
			return ExecuteReader(singleRow, columnNames, columnValues, excludeNullColumns, null);
		}

		public SqlDataReader ExecuteReader(bool singleRow, string[] columnNames, string[] operators, object[] columnValues, bool excludeNullColumns)
		{
			return ExecuteReader(singleRow, columnNames, operators, columnValues, excludeNullColumns, null);
		}

		public SqlDataReader ExecuteReader(bool singleRow, string[] columnNames, string[] operators, object[] columnValues, bool excludeNullColumns, string sort)
		{
			SqlCommand cmd = SelectByColumnValuesCommand(columnNames, operators, columnValues, excludeNullColumns, sort);
			System.Data.CommandBehavior cmdBeh = CommandBehavior.Default;
			if (singleRow)
				cmdBeh |= CommandBehavior.CloseConnection | CommandBehavior.SingleRow;
			SqlDataReader rdr = cmd.ExecuteReader(cmdBeh);
			return rdr;
		}

		public SqlDataReader ExecuteReader(bool singleRow, string[] columnNames, object[] columnValues, bool excludeNullColumns, string sort)
		{
			return ExecuteReader(singleRow, columnNames, null, columnValues, excludeNullColumns, sort);
		}

		public SqlDataReader ExecuteSQL(bool singleRow, string sql, string[] paramNames, object[] paramValues)
		{
			SqlCommand cmd = MakeSQLCommand(sql, paramNames, paramValues);
			System.Data.CommandBehavior cmdBeh = CommandBehavior.Default;
			if (singleRow)
				cmdBeh |= CommandBehavior.CloseConnection | CommandBehavior.SingleRow;
			SqlDataReader rdr = cmd.ExecuteReader(cmdBeh);
			return rdr;
		}

		public int ExecuteSQL(string sql, string[] paramNames, object[] paramValues)
		{
			SqlCommand cmd = MakeSQLCommand(sql, paramNames, paramValues);
			try
			{
				return cmd.ExecuteNonQuery();
			}
			finally
			{
				CloseConnection();
			}
		}

		public object ExecuteSQLScalar(string sql, string[] paramNames, object[] paramValues)
		{
			SqlCommand cmd = MakeSQLCommand(sql, paramNames, paramValues);
			try
			{
				return cmd.ExecuteScalar();
			}
			finally
			{
				CloseConnection();
			}
		}

		public SqlDataReader ExecuteProcedure(bool singleRow, string sproc, string[] paramNames, object[] paramValues)
		{
			SqlCommand cmd = StoredProcCommand(sproc, paramNames, paramValues);

			System.Data.CommandBehavior cmdBeh = CommandBehavior.Default;
			if (singleRow)
				cmdBeh |= CommandBehavior.CloseConnection | CommandBehavior.SingleRow;
			SqlDataReader rdr = cmd.ExecuteReader(cmdBeh);
			return rdr;
		}

		public int ExecuteProcedure(string sproc, string[] paramNames, object[] paramValues)
		{
			SqlCommand cmd = StoredProcCommand(sproc, paramNames, paramValues);
			try
			{
				return cmd.ExecuteNonQuery();
			}
			finally
			{
				CloseConnection();
			}
		}

		public object ExecuteProcedureScalar(string sproc, string[] paramNames, object[] paramValues)
		{
			SqlCommand cmd = StoredProcCommand(sproc, paramNames, paramValues);
			try
			{
				return cmd.ExecuteScalar();
			}
			finally
			{
				CloseConnection();
			}
		}

		public SqlDataReader ExecuteReader(Type type, string[] memberNames, object[] memberValues, bool excludeNullMembers)
		{
			return ExecuteReader(type, false, memberNames, memberValues, excludeNullMembers, null);
		}

		public SqlDataReader ExecuteReader(Type type, bool singleRow, string[] memberNames, object[] memberValues, bool excludeNullMembers)
		{
			return ExecuteReader(type, singleRow, memberNames, memberValues, excludeNullMembers, null);
		}

		public SqlDataReader ExecuteReader(Type type, bool singleRow, string[] memberNames, string[] operators, object[] memberValues, bool excludeNullMembers)
		{
			return ExecuteReader(type, singleRow, memberNames, operators, memberValues, excludeNullMembers, null);
		}

		public SqlDataReader ExecuteReader(Type type, bool singleRow, string[] memberNames, string[] operators, object[] memberValues, bool excludeNullMembers, string sort)
		{
			string[] colNames = new string[memberNames.Length];
			object[] colValues = new string[memberValues.Length];

			for (int i = 0; i < memberValues.Length; i++)
				colValues[i] = ReflectionHelper.MemberToDBValue(type, memberNames[i], memberValues[i]);

			for (int i = 0; i < memberNames.Length; i++)
				colNames[i] = ColumnMappingAttribute.GetColumnNameForMember(type, memberNames[i]);

			return ExecuteReader(singleRow, colNames, operators, colValues, excludeNullMembers, sort);
		}

		public SqlDataReader ExecuteReader(Type type, bool singleRow, string[] memberNames, object[] memberValues, bool excludeNullMembers, string sort)
		{
			return ExecuteReader(type, singleRow, memberNames, null, memberValues, excludeNullMembers, sort);
		}

		public bool SelectRow(object[] values, string[] columnNames, object[] columnValues, bool excludeNullColumns)
		{
			SqlDataReader rdr = null;
			try
			{
				rdr = ExecuteReader(true, columnNames, columnValues, excludeNullColumns);
				if (rdr.Read())
				{
					rdr.GetValues(values);
					return true;
				}
			}
			finally
			{
				if (rdr != null)
					rdr.Close();
				CloseConnection();
			}
			return false;
		}

		public bool SelectObj(object targetObj, bool ignoreAssignmentError, bool collections, bool excludeNullMembers,  string memberNames, params object[] memberValues)
		{
			string[] names = memberNames.Split(',');
			for (int i = 0; i < names.Length; i++)
				names[i] = names[i].Trim();
			return SelectObj(targetObj, ignoreAssignmentError, collections, excludeNullMembers, names, memberValues);
		}

		public bool SelectObj(object targetObj, bool ignoreAssignmentError, bool collections, bool excludeNullMembers,  string[] memberNames, object[] memberValues)
		{
			Type type = targetObj.GetType();

			object[] values = MakeRowBuffer();

			object[] memDBVals = new object[memberValues.Length];
			for (int i = 0; i < memberValues.Length; i++)
				memDBVals[i] = ReflectionHelper.MemberToDBValue(type, memberNames[i], memberValues[i]);

			for (int i = 0; i < memberNames.Length; i++)
				memberNames[i] = ColumnMappingAttribute.GetColumnNameForMember(type, memberNames[i]);

			if (!SelectRow(values, memberNames, memDBVals, excludeNullMembers))
				return false;
			FillIntoObject(values, targetObj, ignoreAssignmentError, collections);
			return true;
		}

		public bool ExistsObj(object targetObj)
		{
			object[] pkVals = TableMappingAttribute.GetPKMemberVals(targetObj);
			return Exists(pkVals);
		}

		/// <summary>
		/// Directly read a row and fill in to given object
		/// </summary>
		/// <param name="targetObj"></param>
		/// <param name="Key"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="collections"></param>
		/// <returns></returns>
		public bool SelectObj(object targetObj, object[] Keys, bool ignoreAssignmentError, bool collections)
		{
			object[] values = MakeRowBuffer();
			if (!SelectRow(values, Keys))
				return false;
			FillIntoObject(values, targetObj, ignoreAssignmentError, collections);
			return true;
		}

		public bool SelectObj(object targetObj, object Key, bool ignoreAssignmentError, bool collections)
		{
			return SelectObj(targetObj, new object[] { Key }, ignoreAssignmentError, collections);
		}

		public bool SelectObj(object targetObj, bool ignoreAssignmentError, bool collections)
		{
			object[] keys = TableMappingAttribute.GetPKMemberVals(targetObj);
			return SelectObj(targetObj, keys, ignoreAssignmentError, collections);
		}

		public bool ReadObj(SqlDataReader sourceRdr, object targetObj, bool ignoreAssignmentError, bool collections)
		{
			if (sourceRdr != null)
				if (sourceRdr.Read())
				{
					//object[] values = MakeRowBuffer();
					//sourceRdr.GetValues(values);
					//FillIntoObject(values, targetObj, ignoreAssignmentError, collections);
					//return true;
					BaseDataClass data = targetObj as BaseDataClass;
					if (data != null)
						data.FillFromReader(sourceRdr, ignoreAssignmentError);
					else
						SQLDataFiller.FillIntoObject(sourceRdr, targetObj, ignoreAssignmentError);
					return true;
				}

			return false;
		}

		public int ReadCollection(SqlDataReader sourceRdr, int maxRecords, IList collection, bool ignoreAssignmentError, bool collections)
		{
			Type type = collection.GetType();
			ElementTypeAttribute elemTypeAttrib = ElementTypeAttribute.GetFromType(type);
			if (elemTypeAttrib == null)
				throw new Exception("An ElementTypeAttribute must be specified!");

			return ReadCollection(sourceRdr, maxRecords, collection, elemTypeAttrib.ElemType, ignoreAssignmentError, collections);
		}

		/// <summary>
		/// Read from the given data reader into specified collection.
		/// maxRecords is the maximum number of records to read.
		/// If this is negative, all records will be read.
		/// Returns the number of actual records read
		/// </summary>
		/// <param name="sourceRdr"></param>
		/// <param name="maxRecords"></param>
		/// <param name="collection"></param>
		/// <param name="elemType"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="collections"></param>
		/// <returns></returns>
		public int ReadCollection(SqlDataReader sourceRdr, int maxRecords, IList collection, Type elemType, bool ignoreAssignmentError, bool collections)
		{
			if (elemType == null)
				throw new Exception("An element type must be specified!");

			int count = 0;

			BaseDataCollectionClass baseDataCol = collection as BaseDataCollectionClass;

			if (sourceRdr != null)
			{
				while (maxRecords < 0 || count < maxRecords)
				{
					if (!sourceRdr.Read())
						break;
					object elem = null;
					if (baseDataCol != null)
					{
						elem = baseDataCol.NewRecord(false);
						baseDataCol.AddRecord((BaseDataClass)elem);
					}
					else
					{
						elem = Activator.CreateInstance(elemType);
						collection.Add(elem);
					}

					BaseDataClass data = elem as BaseDataClass;
					if (data != null)
					{
						if (baseDataCol != null)
							baseDataCol.OnFillElemFromReader(count, sourceRdr, data);
						data.FillFromReader(sourceRdr, ignoreAssignmentError);
					}
					else
						SQLDataFiller.FillIntoObject(sourceRdr, elem, ignoreAssignmentError);

					count++;
				}
			}

			if (baseDataCol != null)
				baseDataCol.OnCollectionLoaded();
			return count;
		}

		public object[] GetPKValues(object[] values)
		{
			object[] keys = new object[PK.Length];
			for (int i = 0; i < PK.Length; i++)
				keys[i] = values[pkIndex[i]];

			return keys;
		}

		public void UpdateRow(object[] values)
		{
			object[] keys = GetPKValues(values);
			UpdateRow(values, keys);
		}

		public void UpdateRow(object[] values, params object[] Keys)
		{
			SqlCommand cmd = UpdateCommand;
			UpdateCommandParams(values, Keys);
			try
			{
				if (cmd.ExecuteNonQuery() < 1)
					throw new Exception("Record for update not found!");
			}
			finally
			{
				CloseConnection();
			}
		}

		public void UpdateObj(object sourceObj, bool ignoreAssignmentError, bool collections)
		{
			object[] values = MakeRowBuffer();
			FillFromObject(values, sourceObj, ignoreAssignmentError, collections);
			UpdateRow(values);
		}

		public object InsertRow(object[] values)
		{
			object id = DBNull.Value;
			SqlCommand cmd = InsertCommand;
			InsertCommandParams(values);
			try
			{
				if (insertPK)
					cmd.ExecuteNonQuery();
				else
				{
					id = cmd.ExecuteScalar();
					if (pkIndex.Length == 1)
						values[pkIndex[0]] = id;
				}
			}
			finally
			{
				CloseConnection();
			}

			return id;
		}

		public void InsertObj(object sourceObj, bool ignoreAssignmentError, bool collections)
		{
			object[] values = MakeRowBuffer();
			FillFromObject(values, sourceObj, ignoreAssignmentError, collections);
			object id = InsertRow(values);
			if (id != DBNull.Value)
				TableMappingAttribute.SetPKMemberVal(sourceObj, id);
		}

		public object UpdateOrInsertRow(object[] values)
		{
			object[] pkVal = GetPKValues(values);
			
			if (NSGlobal.HasAnyNull(pkVal))
				return InsertRow(values);
			else
			{
				UpdateRow(values);
				return DBNull.Value;
			}
		}

		// !!! add code to handle insert parent first then children
		public void UpdateOrInsertObj(object sourceObj, bool ignoreAssignmentError, bool collections)
		{
			object[] values = MakeRowBuffer();
			FillFromObject(values, sourceObj, ignoreAssignmentError, collections);
			object id = UpdateOrInsertRow(values);
			if (id != DBNull.Value)
				TableMappingAttribute.SetPKMemberVal(sourceObj, id);
		}

		public void DeleteRow(params object[] Keys)
		{
			SqlCommand cmd = DeleteCommand;
			DeleteCommandParams(Keys);
			try
			{
				cmd.ExecuteNonQuery();
			}
			finally
			{
				CloseConnection();
			}
		}

		public void DeleteObj(object sourceObj)
		{
			object[] values = MakeRowBuffer();
			FillFromObject(values, sourceObj, true, false);
			DeleteRow(GetPKValues(values));
		}

		public void DeleteAll()
		{
			if (keys == null)
				LoadKeys();
			for (int i = 0; i < keys.Length; i++)
			{
				DeleteRow(new object[] { keys[i] } );
			}
		}

		public string[] PKColumns
		{
			get	{ return PK; }
		}

		public string PKColumnNames
		{
			get	{ return String.Join(",", PK); }
		}

		public int[] PKColumnIndices
		{
			get	{ return pkIndex; }
		}

		// stored proc declaration functions
		public string SPLoad
		{
			get { return spLoad; }
			set 
			{ 
				spLoad = value; 
				selectCommand = null;	// force reconstruct
			}
		}

		public string SPExists
		{
			get { return spExists; }
			set 
			{ 
				spExists = value; 
				existsCommand = null;	// force reconstruct
			}
		}

		public string SPUpdate
		{
			get { return spUpdate; }
			set 
			{ 
				spUpdate = value; 
				updateCommand = null;	// force reconstruct
			}
		}

		public string SPInsert
		{
			get { return spInsert; }
			set 
			{ 
				spInsert = value; 
				insertCommand = null;	// force reconstruct
			}
		}

		public string SPDelete
		{
			get { return spDelete; }
			set 
			{ 
				spDelete = value; 
				deleteCommand = null;	// force reconstruct
			}
		}

		#endregion

		#region Row buffer item access
		
		public int GetColumnIndex(string colName)
		{
			//try
			//{
			return (int)columnIndices[colName];
			//}
			//catch(Exception ex)
			//{
			//	throw;
			//}
		}

		public object GetItem(object[] values, string colName)
		{
			return values[GetColumnIndex(colName)];
		}

		public void SetItem(object[] values, string colName, object value)
		{
			values[GetColumnIndex(colName)] = value;
		}

		#endregion

		#region IEnumerable Members

		public IEnumerator GetEnumerator()
		{
			return new SQLDataDirectEnumerator(this);
		}

		#endregion

		#region SQLDataDirect Enumerator 

		private class SQLDataDirectEnumerator : IEnumerator
		{
			private SQLDataDirect sqlData;
			//private int iPos = 0;
			//private object[] values;

			private SqlDataReader rdr;

			public SQLDataDirectEnumerator(SQLDataDirect sqlData)
			{
				this.sqlData = sqlData;
				//this.values = sqlData.MakeRowBuffer();
				Reset();
			}

			#region IEnumerator Members

			public void Reset()
			{
				//iPos = 0;
				//values = sqlData.MakeRowBuffer();

				if (rdr != null)
					rdr.Close();

				if (sqlData.HasSQL)
				{
					rdr = sqlData.SQLCommand.ExecuteReader();
				}
				else
					rdr = sqlData.ExecuteReader(null, null, null);
			}

			public object Current
			{
				get
				{
					object[] values = sqlData.MakeRowBuffer();
					rdr.GetValues(values);
					return values;
				}
			}

			public bool MoveNext()
			{
				return rdr.Read();
			}

			#endregion
		}

		#endregion

		#region Public static functions

		/*
		public static SQLDataDirect CreateSqlDataForQuery(Type type, SQLParser sql, SqlConnection connection)
		{
			TableMappingAttribute tm = TableMappingAttribute.GetFromType(type);
			if (tm == null)
				throw new ArgumentException(String.Format("Class {0} must provide element type and the element define a TableMapping attribute!", type.Name));
			string pkColName = ColumnMappingAttribute.GetColumnNameForMember(type, tm.PKMemberName);
			string tableName = tm.GetTableNameForType(type);
			SQLDataDirect sqlData = new SQLDataDirect(connection, tableName, pkColName, SQLParser.MergeColumnNames(cols), filter, sort);
			sqlData.InsertPK = tm.InsertPK;
			return sqlData;

			return new SQLDataDirect(connection, sql);
		}

		*/

		public static SQLDataDirect CreateSqlDataForQuery(SQLParser sql, bool detectColumns)
		{
			return new SQLDataDirect(NSGlobal.ConnectionString, sql, detectColumns);
		}

		public static SQLDataDirect CreateSqlDataForQuery(SQLParser sql, SqlConnection connection, bool detectColumns)
		{
			return new SQLDataDirect(connection, sql, detectColumns);
		}

		public static SQLDataDirect CreateSqlDataForQuery(SQLParser sql, string connection, bool detectColumns)
		{
			return new SQLDataDirect(connection, sql, detectColumns);
		}

		public static string[] GetColNamesFromColInfos(ColumnInfo[] colInfos)
		{
			string[] colNames = new string[colInfos.Length];
			for (int i = 0; i < colInfos.Length; i++)
				colNames[i] = colInfos[i].ColumnName;
			return colNames;
		}

		public static SQLDataDirect CreateSqlDataForType(Type type, SqlConnection connection, ColumnInfo[] cols, string filter, string sort, bool detectColumns)
		{
			string[] colNames = GetColNamesFromColInfos(cols);
			SQLDataDirect sqlData = CreateSqlDataForType(type, connection, colNames, filter, sort, detectColumns);
			if (sqlData != null)
			{
				sqlData.ImportColumnInfoMap(cols);
			}
			return sqlData;
		}

		public static SQLDataDirect CreateSqlDataForType(Type type, SqlConnection connection, string[] cols, string filter, string sort, bool detectColumns)
		{
			TableMappingAttribute tm = TableMappingAttribute.GetFromType(type);
			if (tm == null)
				throw new ArgumentException(String.Format("Class {0} must provide element type and the element define a TableMapping attribute!", type.Name));
			string pkColName = TableMappingAttribute.GetPKColumns(type);
			string tableName = tm.GetTableNameForType(type);
			SQLDataDirect sqlData = new SQLDataDirect(connection, tableName, pkColName, SQLParser.MergeColumnNames(cols), filter, sort, detectColumns);
			
			sqlData.SPLoad = SPLoadAttribute.GetSPFromType(type);
			sqlData.SPUpdate = SPUpdateAttribute.GetSPFromType(type);
			sqlData.SPInsert = SPInsertAttribute.GetSPFromType(type);
			sqlData.SPDelete = SPDeleteAttribute.GetSPFromType(type);
			sqlData.SPExists = SPExistsAttribute.GetSPFromType(type);

			sqlData.InsertPK = tm.InsertPK;
			sqlData.useJoinColumns = tm.UseJoinColumns;
			return sqlData;
		}

		public static SQLDataDirect CreateSqlData(object obj, SqlConnection connection, string[] cols, string filter, string sort, bool detectColumns)
		{
			return CreateSqlDataForType(obj.GetType(), connection, cols, filter, sort, detectColumns);
		}

		public static SQLDataDirect CreateSqlDataForType(Type type, SqlConnection connection, string filter, string sort, bool detectColumns)
		{
			ColumnInfo[] cols = ColumnMappingAttribute.GetMappedColumns(type, true);
			return CreateSqlDataForType(type, connection, cols, filter, sort, detectColumns);
		}

		public static SQLDataDirect CreateSqlData(object obj, SqlConnection connection, string filter, string sort, bool detectColumns)
		{
			return CreateSqlDataForType(obj.GetType(), connection, filter, sort, detectColumns);
		}

		public static SQLDataDirect CreateSqlDataForType(Type type, string filter, string sort, bool detectColumns)
		{
			return CreateSqlDataForType(type, new SqlConnection(NSGlobal.ConnectionString), filter, sort, detectColumns);
		}

		public static SQLDataDirect CreateSqlDataForType(Type type, string filter, bool detectColumns)
		{
			return CreateSqlDataForType(type, new SqlConnection(NSGlobal.ConnectionString), filter, null, detectColumns);
		}

		public static SQLDataDirect CreateSqlDataForType(Type type, string connection, string filter, string sort, bool detectColumns)
		{
			return CreateSqlDataForType(type, new SqlConnection(connection), filter, sort, detectColumns);
		}

		public static SQLDataDirect CreateSqlData(object obj, string connection, string filter, string sort, bool detectColumns)
		{
			return CreateSqlDataForType(obj.GetType(), new SqlConnection(connection), filter, sort, detectColumns);
		}

		public static SQLDataDirect CreateSqlDataForType(Type type, bool detectColumns)
		{
			return CreateSqlDataForType(type, new SqlConnection(NSGlobal.ConnectionString), null, null, detectColumns);
		}

		public static SQLDataDirect CreateSqlData(object obj, bool detectColumns)
		{
			return CreateSqlDataForType(obj.GetType(), detectColumns);
		}

		#endregion

		#region Filler functions

		public void FillIntoObject(object[] values, object targetObj, bool ignoreAssignmentError, bool collections)
		{
			SQLDataFiller.FillIntoObject(this, values, targetObj, ignoreAssignmentError, collections);
		}

		public void FillFromObject(object[] values, object sourceObj, bool ignoreAssignmentError, bool collections)
		{
			SQLDataFiller.FillFromObject(this, values, sourceObj, ignoreAssignmentError, collections);
		}

		#endregion

		#region Whitebox Testers
		/*
		public static void Test()
		{
			SqlConnection conn = new SqlConnection(NSGlobal.Global.ConnectionString);
			SQLDataDirect sqld = new SQLDataDirect(
					conn, 
					"Confirmations", "ConfirmationLineID",
					"ConfirmationLineID, SectionID, SortOrder");

			object[] values = sqld.MakeRowBuffer();

			foreach (object key in sqld.Keys)
			{
				sqld.SelectRow(values, key);
				Debug.WriteLine(values.Length);
				int iSortOrder = sqld.GetColumnIndex("SortOrder");
				values[2] = (int)values[2] + 1;
				sqld.UpdateRow(values, key);
				//sqld.InsertRow(values);
			}

			Debug.WriteLine("ok");
		}*/

		#endregion
	
		public object EnsureKeyedListItem(IList list, int index, Type elemType, bool ignoreAssignmentError, bool collections)
		{
			object item = list[index];
			if (item == null)
				return null;
			Type itemType = item.GetType();
			if (itemType.IsClass)
			{
				if (!(item is string))
					return item;
			}

			object elem = Activator.CreateInstance(elemType);
			if (this.SelectObj(elem, new object[] { item }, ignoreAssignmentError, collections))
			{
				list[index] = elem;
				return elem;
			}
			return null;
		}

		public bool UseJoinColumns
		{
			get { return this.useJoinColumns; }
			set { this.useJoinColumns = value; }
		}

		/// <summary>
		/// Invokes the given stored procedure passing the specified parameters and returns 
		/// a DataSet.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="parameters"></param>
		/// <returns></returns>
		public DataSet SPExecDataSet(string spName, params object[] parameters)
		{
			OpenConnection();
			DataSet ds = null;
			try
			{
				if (this.Transaction != null)
					ds = SqlHelper.ExecuteDataset(this.Transaction, spName, parameters);
				else
					ds = SqlHelper.ExecuteDataset(this.Connection, spName, parameters);
			}
			finally
			{
				CloseConnection();
			}
			return ds;
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified paramsObj and
		/// the given extra parameters and returns a DataSet.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="extraParamNames"></param>
		/// <param name="extraParamValues"></param>
		/// <returns></returns>
		public DataSet SPExecDataSet(string spName, object paramsObj, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			SqlParameter[] sqlParams = SqlHelperParameterCache.GetSpParameterSet(this.ConnectionString, spName, false);
			SQLParamFiller.FillParameters(sqlParams, paramsObj, ignoreAssignmentError, extraParamNames, extraParamValues);
			return SPExecDataSet(spName, sqlParams);
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified paramsObj and
		/// returns a DataSet.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <returns></returns>
		public DataSet SPExecDataSet(string spName, object paramsObj, bool ignoreAssignmentError)
		{
			return SPExecDataSet(spName, paramsObj, ignoreAssignmentError, null, null);
		}

		/// <summary>
		/// Invokes the given stored procedure passing the specified parameters and returns 
		/// the SqlDataReader.  Handles connection open automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="parameters"></param>
		/// <returns></returns>
		public SqlDataReader SPExecRead(string spName, params object[] parameters)
		{
			OpenConnection();
			SqlDataReader rdr = null;
			if (this.Transaction != null)
				rdr = SqlHelper.ExecuteReader(this.Transaction, spName, parameters);
			else
				rdr = SqlHelper.ExecuteReader(this.Connection, spName, parameters);
			return rdr;
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified paramsObj and
		/// the given extra parameters and returns the SqlDataReader.  Handles connection open automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="extraParamNames"></param>
		/// <param name="extraParamValues"></param>
		/// <returns></returns>
		public SqlDataReader SPExecRead(string spName, object paramsObj, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			SqlParameter[] sqlParams = SqlHelperParameterCache.GetSpParameterSet(this.ConnectionString, spName, false);
			SQLParamFiller.FillParameters(sqlParams, paramsObj, ignoreAssignmentError, extraParamNames, extraParamValues);
			return SPExecRead(spName, sqlParams);
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified paramsObj and
		/// returns the SqlDataReader.  Handles connection open automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <returns></returns>
		public SqlDataReader SPExecRead(string spName, object paramsObj, bool ignoreAssignmentError)
		{
			return SPExecRead(spName, paramsObj, ignoreAssignmentError, null, null);
		}

		/// <summary>
		/// Invokes the given stored procedure passing the specified parameters and returns 
		/// the scalar result.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="parameters"></param>
		/// <returns></returns>
		public object SPExecScalar(string spName, params object[] parameters)
		{
			OpenConnection();
			try
			{
				if (this.Transaction != null)
					return SqlHelper.ExecuteScalar(this.Transaction, spName, parameters);
				else
					return SqlHelper.ExecuteScalar(this.Connection, spName, parameters);
			}
			finally
			{
				CloseConnection();
			}
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified paramsObj
		/// and the given extra parameters and returns the scalar result.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="extraParamNames"></param>
		/// <param name="extraParamValues"></param>
		/// <returns></returns>
		public object SPExecScalar(string spName, object paramsObj, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			SqlParameter[] sqlParams = SqlHelperParameterCache.GetSpParameterSet(this.ConnectionString, spName, false);
			SQLParamFiller.FillParameters(sqlParams, paramsObj, ignoreAssignmentError, extraParamNames, extraParamValues);
			return SPExecScalar(spName, sqlParams);
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified paramsObj 
		/// and returns the scalar result.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <returns></returns>
		public object SPExecScalar(string spName, object paramsObj, bool ignoreAssignmentError)
		{
			return SPExecScalar(spName, paramsObj, ignoreAssignmentError, null, null);
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified multiple paramsObjs
		/// and the given extra parameters and returns the scalar result.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="extraParamNames"></param>
		/// <param name="extraParamValues"></param>
		/// <returns></returns>
		public object SPExecScalar(string spName, object[] paramsObjs, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			SqlParameter[] sqlParams = SqlHelperParameterCache.GetSpParameterSet(this.ConnectionString, spName, false);
			SQLParamFiller.FillParameters(sqlParams, paramsObjs, ignoreAssignmentError, extraParamNames, extraParamValues);
			return SPExecScalar(spName, sqlParams);
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified paramsObj 
		/// and returns the scalar result.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <returns></returns>
		public object SPExecScalar(string spName, object[] paramsObjs, bool ignoreAssignmentError)
		{
			return SPExecScalar(spName, paramsObjs, ignoreAssignmentError, null, null);
		}

		/// <summary>
		/// Invokes the given stored procedure passing the specified parameters and returns 
		/// the number of records effected.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="parameters"></param>
		/// <returns></returns>
		public int SPExecNonQuery(string spName, params object[] parameters)
		{
			OpenConnection();
			try
			{
				if (this.Transaction != null)
					return SqlHelper.ExecuteNonQuery(this.Transaction, spName, parameters);
				else
					return SqlHelper.ExecuteNonQuery(this.Connection, spName, parameters);
			}
			finally
			{
				CloseConnection();
			}
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified paramsObj and
		/// the given extra parameters and returns the number of records effected.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="extraParamNames"></param>
		/// <param name="extraParamValues"></param>
		/// <returns></returns>
		public int SPExecNonQuery(string spName, object paramsObj, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			SqlParameter[] sqlParams = SqlHelperParameterCache.GetSpParameterSet(this.ConnectionString, spName);
			SQLParamFiller.FillParameters(sqlParams, paramsObj, ignoreAssignmentError, extraParamNames, extraParamValues);
			return SPExecNonQuery(spName, sqlParams);
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified paramsObj and
		/// returns the number of records effected.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <returns></returns>
		public int SPExecNonQuery(string spName, object paramsObj, bool ignoreAssignmentError)
		{
			return SPExecNonQuery(spName, paramsObj, ignoreAssignmentError, null, null);
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified multiple paramsObjs and
		/// the given extra parameters and returns the number of records effected.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="extraParamNames"></param>
		/// <param name="extraParamValues"></param>
		/// <returns></returns>
		public int SPExecNonQuery(string spName, object[] paramsObjs, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			SqlParameter[] sqlParams = SqlHelperParameterCache.GetSpParameterSet(this.ConnectionString, spName);
			SQLParamFiller.FillParameters(sqlParams, paramsObjs, ignoreAssignmentError, extraParamNames, extraParamValues);
			return SPExecNonQuery(spName, sqlParams);
		}

		/// <summary>
		/// Invokes the given stored procedure passing the mapped members of the specified multiple paramsObjs and
		/// returns the number of records effected.  Handles connection open/close automatically.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <returns></returns>
		public int SPExecNonQuery(string spName, object[] paramsObjs, bool ignoreAssignmentError)
		{
			return SPExecNonQuery(spName, paramsObjs, ignoreAssignmentError, null, null);
		}

		/// <summary>
		/// Directly executes the given stored procedure passing the given parameters.  The
		/// returned result is filled into the target object.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="targetObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="parameters"></param>
		/// <returns></returns>
		public bool SPExecReadObj(string spName, object targetObj, bool ignoreAssignmentError, params object[] parameters)
		{
			SqlDataReader rdr = SPExecRead(spName, parameters);
			try
			{
				return this.ReadObj(rdr, targetObj, ignoreAssignmentError, false);
			}
			finally
			{
				if (rdr != null)
					rdr.Close();
				CloseConnection();
			}
		}

		/// <summary>
		/// Directly executes the given stored procedure passing the mapped members of the specified paramsObj.  
		/// The returned result is filled into the target object.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="targetObj"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <returns></returns>
		public bool SPExecReadObj(string spName, object targetObj, object paramsObj, bool ignoreAssignmentError)
		{
			return SPExecReadObj(spName, targetObj, ignoreAssignmentError, null, null);
		}

		/// <summary>
		/// Directly executes the given stored procedure passing the mapped members of the specified paramsObj
		/// and the given extra parameters.  The returned result is filled into the target object.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="targetObj"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="extraParamNames"></param>
		/// <param name="extraParamValues"></param>
		/// <returns></returns>
		public bool SPExecReadObj(string spName, object targetObj, object paramsObj, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			SqlParameter[] sqlParams = SqlHelperParameterCache.GetSpParameterSet(this.ConnectionString, spName);
			SQLParamFiller.FillParameters(sqlParams, paramsObj, ignoreAssignmentError, extraParamNames, extraParamValues);
			return SPExecReadObj(spName, targetObj, ignoreAssignmentError, sqlParams);
		}

		/// <summary>
		/// Directly executes the given stored procedure passing the mapped members of the specified multiple paramsObjs.
		/// The returned result is filled into the target object.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="targetObj"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <returns></returns>
		public bool SPExecReadObj(string spName, object targetObj, object[] paramsObjs, bool ignoreAssignmentError)
		{
			return SPExecReadObj(spName, targetObj, ignoreAssignmentError, null, null);
		}

		/// <summary>
		/// Directly executes the given stored procedure passing the mapped members of the specified multiple paramsObj
		/// and the given extra parameters.  The returned result is filled into the target object.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="targetObj"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="extraParamNames"></param>
		/// <param name="extraParamValues"></param>
		/// <returns></returns>
		public bool SPExecReadObj(string spName, object targetObj, object[] paramsObjs, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			SqlParameter[] sqlParams = SqlHelperParameterCache.GetSpParameterSet(this.ConnectionString, spName);
			SQLParamFiller.FillParameters(sqlParams, paramsObjs, ignoreAssignmentError, extraParamNames, extraParamValues);
			return SPExecReadObj(spName, targetObj, ignoreAssignmentError, sqlParams);
		}

		/// <summary>
		/// Directly executes the given stored procedure passing the given parameters.  The
		/// returned result is filled into the target collection.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="maxRecords"></param>
		/// <param name="collection"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="parameters"></param>
		/// <returns></returns>
		public int SPExecReadCol(string spName, int maxRecords, IList collection, bool ignoreAssignmentError, params object[] parameters)
		{
			SqlDataReader rdr = SPExecRead(spName, parameters);
			try
			{
				return this.ReadCollection(rdr, maxRecords, collection, ignoreAssignmentError, false);
			}
			finally
			{
				if (rdr != null)
					rdr.Close();
				CloseConnection();
			}
		}

		/// <summary>
		/// Directly executes the given stored procedure passing the mapped members of the specified paramsObj
		/// and the given extra parameters.  The returned result is filled into the target collection.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="maxRecords"></param>
		/// <param name="collection"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="extraParamNames"></param>
		/// <param name="extraParamValues"></param>
		/// <returns></returns>
		public int SPExecReadCol(string spName, int maxRecords, IList collection, object paramsObj, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			SqlParameter[] sqlParams = SqlHelperParameterCache.GetSpParameterSet(this.ConnectionString, spName);
			SQLParamFiller.FillParameters(sqlParams, paramsObj, ignoreAssignmentError, extraParamNames, extraParamValues);
			return SPExecReadCol(spName, maxRecords, collection, ignoreAssignmentError, sqlParams);
		}

		/// <summary>
		/// Directly executes the given stored procedure passing the mapped members of the specified paramsObj.  
		/// The returned result is filled into the target collection.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="maxRecords"></param>
		/// <param name="collection"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <returns></returns>
		public int SPExecReadCol(string spName, int maxRecords, IList collection, object paramsObj, bool ignoreAssignmentError)
		{
			return SPExecReadCol(spName, maxRecords, collection, paramsObj, ignoreAssignmentError, null, null);
		}

		/// <summary>
		/// Directly executes the given stored procedure passing the mapped members of the specified multiple paramsObj
		/// and the given extra parameters.  The returned result is filled into the target collection.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="maxRecords"></param>
		/// <param name="collection"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="extraParamNames"></param>
		/// <param name="extraParamValues"></param>
		/// <returns></returns>
		public int SPExecReadCol(string spName, int maxRecords, IList collection, object[] paramsObjs, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			SqlParameter[] sqlParams = SqlHelperParameterCache.GetSpParameterSet(this.ConnectionString, spName);
			SQLParamFiller.FillParameters(sqlParams, paramsObjs, ignoreAssignmentError, extraParamNames, extraParamValues);
			return SPExecReadCol(spName, maxRecords, collection, ignoreAssignmentError, sqlParams);
		}

		/// <summary>
		/// Directly executes the given stored procedure passing the mapped members of the specified multiple paramsObj.  
		/// The returned result is filled into the target collection.
		/// </summary>
		/// <param name="spName"></param>
		/// <param name="maxRecords"></param>
		/// <param name="collection"></param>
		/// <param name="paramsObj"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <returns></returns>
		public int SPExecReadCol(string spName, int maxRecords, IList collection, object[] paramsObjs, bool ignoreAssignmentError)
		{
			return SPExecReadCol(spName, maxRecords, collection, paramsObjs, ignoreAssignmentError, null, null);
		}

		public NetsoftUSA.Security.PrincipalEx Principal
		{
			get { return this.principal; }
			set { this.principal = value; }
		}

	}

	#endregion
}
