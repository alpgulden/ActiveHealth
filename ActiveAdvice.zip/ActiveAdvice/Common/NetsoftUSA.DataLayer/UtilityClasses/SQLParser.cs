using System;
using System.Collections;
using System.Collections.Specialized;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Data;
using System.Text;

namespace NetsoftUSA.DataLayer
{
	#region Special Exceptions

	public class SQLParseException : Exception
	{
		public SQLParseException(string message) : base(message)
		{
		}

		public SQLParseException(string message, Exception innerException) : base(message, innerException)
		{
		}
	}

	public class SQLInvalidParameterizedClauseException : Exception
	{
		public SQLInvalidParameterizedClauseException(string message) : base(message)
		{
		}

		public SQLInvalidParameterizedClauseException(string message, Exception innerException) : base(message, innerException)
		{
		}
	}

	#endregion

	#region Join Clause Classes

	public enum JoinType
	{
		Inner = 0,
		Outer = 1,
		Left = 2,
		Right = 3
	}

	public class JoinClause
	{
		public JoinType JoinType;
		private string joinTable;
		public string JoinTable
		{	get { return joinTable; }
			set { joinTable = SQLParser.NoBracket(value); }
		}
		public string LeftOperand;
		public string RightOperand;
		public string Operator;

		public JoinClause(JoinType joinType, string joinTable, string leftOperand, string Operator, string rightOperand)
		{
			this.JoinType = joinType;
			this.JoinTable = joinTable;
			this.LeftOperand = leftOperand;
			this.Operator = Operator;
			this.RightOperand = rightOperand;
		}

		public static string GetJoinType(JoinType joinType)
		{
			switch(joinType)
			{
				case JoinType.Inner:
					return "inner";
				case JoinType.Outer:
					return "outer";
				case JoinType.Left:
					return "left";
				case JoinType.Right:
					return "right";
				default:
					return "";
			}
		}

		public string Build()
		{
			return JoinClause.GetJoinType(JoinType) 
				+ " join " 
				+ SQLParser.Bracket(JoinTable) + " on "
				+ SQLParser.MakeFullColumnDesc(LeftOperand) + " "
				+ Operator + " "
				+ SQLParser.MakeFullColumnDesc(RightOperand);
		}
	}

	public class JoinClauseCollection : System.Collections.CollectionBase
	{
		public JoinClause this[int index]
		{
			get
			{
				return (JoinClause)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		public int Add(JoinClause joinClause)
		{
			return List.Add(joinClause);
		}

		public int IndexOf(JoinClause joinClause)
		{
			return List.IndexOf(joinClause);
		}

		public void Insert(int index, JoinClause joinClause)
		{
			List.Insert(index, joinClause);
		}

		public void Remove(JoinClause joinClause)
		{
			List.Remove(joinClause);
		}

		public int FindJoinTable(string joinTable)
		{
			joinTable = SQLParser.NoBracket(joinTable);
			for (int i = 0; i < List.Count; i++)
			{
				JoinClause jc = (JoinClause)List[i];
				if (jc.JoinTable == joinTable)
					return i;
			}
			return -1;
		}
	}

	#endregion

	#region SQLColumn classes
	public class SQLColumn
	{
		private string expression;
		private string alias;

		public SQLColumn(string expression, string alias)
		{
			this.expression = expression.Trim();
			this.alias = alias.Trim();
		}

		public SQLColumn(string expression)
		{
			this.alias = "";
			Expression = expression;
		}

		public string Alias
		{
			get { return alias; }
			set	{ alias = value; }
		}

		public string Expression
		{
			get { return expression; }
			set
			{
				this.expression = value.Trim();
				int iAsBegin = SQLParser.IndexOfIgnoreCase(expression, " as ");

				if (iAsBegin >= 0)
				{
					this.expression = expression.Substring(0, iAsBegin).Trim();
					this.alias = expression.Substring(iAsBegin);
				}
				else
				{
					this.expression = expression.Trim();
				}
			}
		}

		public string Build(string baseTable)
		{
			if (alias == "")
				return SQLParser.MakeFullColumnDesc(expression, baseTable);
			else
				return SQLParser.MakeFullColumnDesc(expression, baseTable) + " as " + SQLParser.Bracket(alias);
		}

		public string Build()
		{
			if (alias == "")
				return this.expression;
			else
				return this.expression + " as " + SQLParser.Bracket(alias);
		}

		public string GetValidColumnName()
		{
			if (alias == null || alias == "")
				return this.expression;
			else
				return SQLParser.Bracket(alias);
		}
	}

	public class SQLColumnCollection : System.Collections.CollectionBase
	{
		public SQLColumn this[int index]
		{
			get
			{
				return (SQLColumn)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		public int Add(SQLColumn Column)
		{
			return List.Add(Column);
		}

		public int IndexOf(SQLColumn Column)
		{
			return List.IndexOf(Column);
		}

		public void Insert(int index, SQLColumn Column)
		{
			List.Insert(index, Column);
		}

		public void Remove(SQLColumn Column)
		{
			List.Remove(Column);
		}

		public int FindColumnByExpression(string expression)
		{
			for (int i = 0; i < List.Count; i++)
			{
				SQLColumn column = (SQLColumn)List[i];
				if (column.Expression == expression)
					return i;
			}
			return -1;
		}

		public int FindColumnByAlias(string alias)
		{
			for (int i = 0; i < List.Count; i++)
			{
				SQLColumn column = (SQLColumn)List[i];
				if (column.Alias == alias)
					return i;
			}
			return -1;
		}
	}
	#endregion

	#region SQLOrderBy classes

	public enum SQLOrderDir
	{
		ASC = 1,
		DESC = -1
	}

	public class SQLOrderBy
	{
		private string expression;
		private SQLOrderDir orderDir = SQLOrderDir.ASC;

		public SQLOrderBy(string expression, SQLOrderDir orderDir)
		{
			this.expression = expression.Trim();
			this.orderDir = orderDir;
		}

		public SQLOrderBy(string expression)
		{
			this.Expression = expression;
		}

		public SQLOrderDir OrderDir
		{
			get { return orderDir; }
			set	{ orderDir = value; }
		}

		public string Expression
		{
			get { return expression; }
			set 
			{ 
				this.expression = value.Trim();
				int iDescBegin = SQLParser.IndexOfIgnoreCase(expression, " desc");
				if (iDescBegin >= 0)
				{
					this.expression = expression.Substring(0, iDescBegin).Trim();
					this.orderDir = SQLOrderDir.DESC;
				}
				else
				{
					int iAscBegin = SQLParser.IndexOfIgnoreCase(expression, " asc");
					if (iAscBegin >= 0)
					{
						this.expression = expression.Substring(0, iAscBegin).Trim();
						this.orderDir = SQLOrderDir.ASC;
					}
					else
					{
						this.expression = expression.Trim();
						this.orderDir = SQLOrderDir.ASC;
					}
				}
			}
		}

		public string Build()
		{
			if (orderDir == SQLOrderDir.ASC)
				return expression + " ASC";
			else
				return expression + " DESC";
		}

		public string Build(string baseTable)
		{
			if (orderDir == SQLOrderDir.ASC)
				return SQLParser.MakeFullColumnDesc(expression, baseTable) + " ASC";
			else
				return SQLParser.MakeFullColumnDesc(expression, baseTable) + " DESC";
		}
	}

	public class SQLOrderByCollection : System.Collections.CollectionBase
	{
		public SQLOrderBy this[int index]
		{
			get
			{
				return (SQLOrderBy)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		public int Add(SQLOrderBy OrderBy)
		{
			return List.Add(OrderBy);
		}

		public int IndexOf(SQLOrderBy OrderBy)
		{
			return List.IndexOf(OrderBy);
		}

		public void Insert(int index, SQLOrderBy OrderBy)
		{
			List.Insert(index, OrderBy);
		}

		public void Remove(SQLOrderBy OrderBy)
		{
			List.Remove(OrderBy);
		}

		public int FindOrderByExpression(string expression)
		{
			for (int i = 0; i < List.Count; i++)
			{
				SQLOrderBy orderBy = (SQLOrderBy)List[i];
				if (orderBy.Expression == expression)
					return i;
			}
			return -1;
		}

		public void Parse(string orderByClause)
		{
			this.Clear();
			string[] orderByTerms = orderByClause.Split(',');

			for (int i = 0; i < orderByTerms.Length; i++)
			{
				this.Add(new SQLOrderBy(orderByTerms[i]));
			}
		}

		public string Build()
		{
			return Build(null);
		}

		public string Build(string baseTable)
		{
			string s = "";
			for (int i = 0; i < this.List.Count; i++)
			{
				SQLOrderBy orderBy = (SQLOrderBy)List[i];
				if (i > 0)
					s += ",";
				
				if (baseTable == null || baseTable == "")
					s+= orderBy.Build();
				else
					s += orderBy.Build(baseTable);
			}
			return s;
		}
	}
	#endregion

	/// <summary>
	/// This class can parse a given simple select statement into its components
	/// </summary>
	public class SQLParser
	{

		protected const string StringParamMatchRegex = @"@(?<item>[0-9a-zA-Z_.:]+)@\|(?<value>[^|]*)\|";

		#region Private members

		private string statement;

		private string commandType = "SELECT";
		private SQLColumnCollection columns = new SQLColumnCollection();
		private StringCollection tables = new StringCollection();
		//private StringCollection whereExpressions = new StringCollection();
		private string whereClause;
		private JoinClauseCollection joinClauses = new JoinClauseCollection();
		private SQLOrderByCollection orderByItems = new SQLOrderByCollection();

		// this is to fix a misbehavior in sql: when you define an alias for a column
		// you can't use it in the where clause!
		private string substituteColumnAliases(string s)
		{
			for (int i = 0; i < columns.Count; i ++)
			{
				SQLColumn col = columns[i];
				if (col.Alias != null && col.Alias != "")
				{
					string alias = Bracket(col.Alias);
					s = s.Replace(alias, col.Expression);
				}
			}
			return s;
		}

		public static int IndexOfIgnoreCase(string s, string substr)
		{
			return SQLParser.IndexOfIgnoreCase(s, substr, 0);
		}

		public static int IndexOfIgnoreCase(string s, string substr, int start)
		{
			int length = substr.Length;
			for (int i = start; i < s.Length - length + 1; i++)
			{
				if (string.Compare(s, i, substr, 0, length, true) == 0)
					return i;
			}
			return -1;
		}

		#endregion

		#region Constructors

		public SQLParser()
		{
		}

		public SQLParser(string SQLStatement)
		{
			Parse(SQLStatement);
		}

		#endregion

		#region Public members

		public string Statement
		{
			get { return statement; }
			set { statement = value; }
		}

		public int FindFirstOf(int startindex, string s, params string[] substrs)
		{
			int[] starts = new int[substrs.Length];
			for (int i = 0; i < substrs.Length; i++)
			{
				starts[i] = IndexOfIgnoreCase(statement, substrs[i], startindex);
			}
			Array.Sort(starts);
			for (int i = 0 ; i < starts.Length; i++)
			{
				// The nearest substrs
				if (starts[i] != -1)
				{
					return starts[i];
				}

			}
			return -1;
		}

		public void Parse()
		{
			// parse the first word: select, insert, update, delete
			commandType = "";
			whereClause = "";
			columns.Clear();
			tables.Clear();
			joinClauses.Clear();
			orderByItems.Clear();

			int iCmdEnd = statement.IndexOf(" ");
			if (iCmdEnd < 0)
				return;

			// parse command type
			commandType = statement.Substring(0, iCmdEnd).Trim().ToUpper();

			int iFromStart = IndexOfIgnoreCase(statement, " from ", iCmdEnd);
			if (iFromStart < 0)
				return;
			int iFromEnd = iFromStart + 6;

			// parse columns
			string scols = statement.Substring(iCmdEnd, iFromStart - iCmdEnd).Trim();
			string[] cols = scols.Split(',');
			for (int i = 0; i < cols.Length; i++)
			{
				string s = cols[i].Trim();
				if (s != "")
					columns.Add(new SQLColumn(s));
			}

			
			//int iWhereStart = IndexOfIgnoreCase(statement, " where ", iFromEnd);
			//int iWhereEnd;
			int iJoinTermPos = -1;

			string stables = null;
			//if (iWhereStart < 0)
			//{
				//iWhereEnd = -1;

				/*int[] joinStarts = new int[5];
				joinStarts[0] = IndexOfIgnoreCase(statement, " join ", iFromEnd);
				joinStarts[1] = IndexOfIgnoreCase(statement, " inner join ", iFromEnd);
				joinStarts[2] = IndexOfIgnoreCase(statement, " left join ", iFromEnd);
				joinStarts[3] = IndexOfIgnoreCase(statement, " right join ", iFromEnd);
				joinStarts[4] = IndexOfIgnoreCase(statement, " outer join ", iFromEnd);
				Array.Sort(joinStarts);
				for (int l = 0 ; l < joinStarts.Length; l++)
				{
					// The nearest join clause
					if (joinStarts[l] != -1)
					{
						stables = statement.Substring(iFromEnd, joinStarts[l] - iFromEnd).Trim();
						iJoinTermPos = joinStarts[l];
						break;
					}
				}*/
				int pos = FindFirstOf(iFromEnd, statement, " where ", " join ", " inner join ", " left join ", " right join ", " outer join ");
				if (pos >= 0)
				{
					stables = statement.Substring(iFromEnd, pos - iFromEnd).Trim();
					iJoinTermPos = pos;
					//break;
				}

				if (stables == null)
                    stables = statement.Substring(iFromEnd).Trim();
			//}
			//else
			//{
			//	iWhereEnd = iWhereStart + 7;
			//	stables = statement.Substring(iFromEnd, iWhereStart - iFromEnd).Trim();

			//	iJoinTermPos = iWhereEnd;
			//}

			// parse tables
			string[] tbls = stables.Split(',');
			for (int i = 0; i < tbls.Length; i++)
			{
				string s = tbls[i].Trim();
				if (s != "")
					tables.Add(NoBracket(s));
			}

			if (iJoinTermPos < 0)
				return;

			int iOrderByStart = -1, iOrderByEnd = -1;
			int iWhereStart = -1, iWhereEnd = -1;
			while (iJoinTermPos < statement.Length)
			{
				int iJoinOrWhere = FindFirstOf(iJoinTermPos, statement, " where ", " join ", " order by ");
				int iJoinStart = iJoinOrWhere;
				//int iJoinStart = IndexOfIgnoreCase(statement, " join ", iJoinTermPos);
				if (iJoinOrWhere >= 0)
				{
					if (statement.Substring(iJoinOrWhere, 3) == " wh")	// this is where
					{
						// parse the where at the end
						iWhereStart = iJoinOrWhere;
						iWhereEnd = iWhereStart + 7;
						break;
					}
					else if (statement.Substring(iJoinOrWhere, 4) == " ord")	// this is order by
					{
						iOrderByStart = iJoinOrWhere;
						iOrderByEnd = iOrderByStart + 10;
						break;
					}
				}

				int iJoinEnd;
				string sjointype = "";
				JoinType joinType = JoinType.Inner;

				if (iJoinStart < 0)
				{
					//whereClause = statement.Substring(iWhereEnd).Trim();
					iJoinEnd = -1;
					break;
				}
				else
				{	
					iJoinEnd = iJoinStart + 6;
					// parse one word backward to detect the type of join
					for (int j = iJoinStart - 1; j >=0 && statement[j] != ' '; j--)
					{
						sjointype = statement[j] + sjointype;
					}

					// determine the join type
					if (sjointype == "inner")
					{
						joinType = JoinType.Inner;
						iJoinStart -= 6;
					}
					else if (sjointype == "outer")
					{
						joinType = JoinType.Outer;
						iJoinStart -= 6;
					}
					else if (sjointype == "left")
					{
						joinType = JoinType.Left;
						iJoinStart -= 5;
					}
					else if (sjointype == "right")
					{
						joinType = JoinType.Outer;
						iJoinStart -= 6;
					}
					else // another word 
					{
						joinType = JoinType.Inner;
					}

					//if (iJoinTermPos == iWhereEnd)		// if this is the first join only
					//	whereClause = statement.Substring(iWhereEnd, iJoinStart - iWhereEnd).Trim();
				}

				// parse terms: inner join [Table2] on [a] = [b]

				int iOnStart = IndexOfIgnoreCase(statement, " on ", iJoinEnd);
				if (iOnStart < 0)
					throw new SQLParseException("'on' keyword expected in the join clause. SQL statement was:\n" + statement);
				int iOnEnd = iOnStart + 4;

				string sjointable = statement.Substring(iJoinEnd, iOnStart - iJoinEnd).Trim();

				string soperator = "=";
				int iOperatorStart = IndexOfIgnoreCase(statement, soperator, iOnEnd);
				if (iOperatorStart < 0)
					throw new SQLParseException("'=' expected in the join clause. SQL statement was:\n" + statement);
				int iOperatorEnd = iOperatorStart + soperator.Length;

				string sLeftOperand = statement.Substring(iOnEnd, iOperatorStart - iOnEnd).Trim();

				int iBlankStart = statement.IndexOf(" ", iOperatorEnd);
				if (iBlankStart < 0)
					iBlankStart = statement.Length;
				//int iBlankEnd = iBlankStart + 1;

				string sRightOperand = statement.Substring(iOperatorEnd, iBlankStart - iOperatorEnd).Trim();

				iJoinTermPos = iBlankStart;

				// add the extracted join clause into the joinclauses collection
				JoinClause joinClause = new JoinClause(joinType, sjointable, sLeftOperand, soperator, sRightOperand);
				joinClauses.Add(joinClause);
			}

			// we don't parse the where clause further because it can be complex and
			// for now we don't need to use the resulting parsed where.
			if (iWhereStart >= 0)
			{
				iOrderByStart = FindFirstOf(iWhereEnd, statement, " order by ");
				if (iOrderByStart < 0)
					whereClause = statement.Substring(iWhereEnd).Trim();
				else
				{
					iOrderByEnd = iOrderByStart + 10;
					whereClause = statement.Substring(iWhereEnd, iOrderByStart - iWhereEnd).Trim();
				}
			}

			if (iOrderByStart >= 0)
			{
				// rest is order by
				string sorderby = statement.Substring(iOrderByEnd);
				orderByItems.Parse(sorderby);
			}
		}

		public void AndWhere(string expression)
		{
			whereClause = whereClause.Trim();
			expression = expression.Trim();
			if (whereClause.Length > 0)
				whereClause += " AND " + expression;
			else
				whereClause = expression;
		}

		public void AndWhere(string leftOp, string op, string rightOp)
		{
			AndWhere(leftOp + op + rightOp);
		}

		public void Parse(string SQLStatement)
		{
			this.Statement = SQLStatement;
			Parse();
		}

		public static string MergeColumn(string tableName, string colName)
		{
			if (tableName == "")
				return Bracket(colName);
			else
				return Bracket(tableName) + "." + Bracket(colName);
		}

		public static void ParseColumn(string fullColDesc, out string tableName, out string colName)
		{
			string[] terms = fullColDesc.Split('.');
			if (terms.Length == 0)
			{
				tableName = "";
				colName = "";
			}
			else if (terms.Length == 1)
			{
				tableName = "";
				colName = NoBracket(terms[0]);
			}
			else if (terms.Length == 2)
			{
				tableName = NoBracket(terms[0]);
				colName = NoBracket(terms[1]);
			}
			else
				throw new ArgumentException("Invalid column descriptor");
		}

		public static void ParseLogicalExp(string exp, out string left, out string right, char op)
		{
			string[] terms = exp.Split(op);
			if (terms.Length != 2)
				throw new ArgumentException("Invalid logical expression");
			else
			{
				left = terms[0];
				right = terms[1];
			}
		}

		public static string MakeFullColumnDesc(string fullColDesc)
		{
			return MakeFullColumnDesc(fullColDesc, "");
		}

		public static string MakeFullColumnDesc(string fullColDesc, string baseTable)
		{
			string tableName;
			string columnName;
			ParseColumn(fullColDesc, out tableName, out columnName);

			if (tableName == "")
				tableName = baseTable;
			return MergeColumn(tableName, columnName);
		}

		/// <summary>
		/// Builds an sql statement using the components parsed.
		/// </summary>
		/// <returns></returns>
		public string Build()
		{
			string scolumns = "";

			string baseTable = tables[0];

			bool bFullColumnName = false;
			string sjoins = "";
			for (int i = 0; i < joinClauses.Count; i++)
			{
				JoinClause joinClause = joinClauses[i];
				sjoins += " " + joinClause.Build();
				bFullColumnName = true;
			}

			for (int i = 0; i < columns.Count; i++)
			{
				if (i > 0)
					scolumns += ",";

				if (bFullColumnName)
					scolumns += columns[i].Build(baseTable);
				else
					scolumns += columns[i].Build();
			}

			string stables = "";
			for (int i = 0; i < tables.Count; i++)
			{
				if (i > 0)
					stables += ",";
				stables += Bracket(tables[i]);
			}

			string stmt = commandType + " " + scolumns + " from " + stables;

			stmt += sjoins;

			if (whereClause != null && whereClause != "")
			{
				// replace all aliases with full column descriptors

				string where = substituteColumnAliases(whereClause);

				stmt += " where " + where;
			}

			if (orderByItems.Count > 0)
			{
				if (bFullColumnName)
					stmt += " order by " + orderByItems.Build();
				else
					stmt += " order by " + orderByItems.Build(baseTable);
			}

			return stmt;
		}

		/// <summary>
		/// Builds the sql statement and assigns the results to itself.
		/// </summary>
		public void Rebuild()
		{
			Statement = Build();
		}

		public SQLColumnCollection Columns
		{
			get { return columns; }
		}

		public StringCollection Tables
		{
			get { return tables; }
		}

		public string WhereClause
		{
			get { return whereClause; }
			set { whereClause = value; }
		}

		public JoinClauseCollection JoinClauses
		{
			get { return joinClauses; }
		}

		public SQLOrderByCollection OrderByItems
		{
			get { return orderByItems; }
		}

		public void AddColumn(string Expression, string Alias)
		{
			columns.Add(new SQLColumn(Expression, Alias));
		}

		public void AddColumn(string Expression)
		{
			columns.Add(new SQLColumn(Expression));
		}

		public void AddTable(string Table)
		{
			tables.Add(NoBracket(Table));
		}

		public void AddJoinedColumn(string JoinTable, string JoinColumn, string LeftRelationColumn, string Operator, string RightRelationColumn)
		{
			AddJoinedColumn(JoinTable, JoinColumn, LeftRelationColumn, Operator, RightRelationColumn, "");
		}

		public void AddJoinedColumn(string JoinTable, string JoinColumn, string LeftRelationColumn, string Operator, string RightRelationColumn, string Alias)
		{
			JoinTable = NoBracket(JoinTable);
			JoinColumn = NoBracket(JoinColumn);
			AddColumn(JoinTable + "." + JoinColumn, Alias);
			
			// add the joinClause only if not already added
			if (joinClauses.FindJoinTable(JoinTable) < 0)
				joinClauses.Add(new JoinClause(JoinType.Left, JoinTable, LeftRelationColumn, Operator, RightRelationColumn));
		}

		public void AddJoinedColumn(string JoinTable, string JoinColumn, string LeftRelationColumn, string RightRelationColumn)
		{
			AddJoinedColumn(JoinTable, JoinColumn, LeftRelationColumn, "=", RightRelationColumn);
		}

		public static string NoBracket(string term)
		{
			return term.Trim('[', ']');
		}

		public static string Bracket(string term)
		{
			if (term == "*")
				return term;
			else
				return "[" + NoBracket(term) + "]";
		}

		public static void ExtractParameters(string expression, SqlParameterCollection parameters)
		{
			Regex regex = new Regex("@(?<paramName>\\S+)", 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			//int i = 0;
			for (match = regex.Match(expression); match.Success; match = match.NextMatch())
			{
				// extract param name from match
				string paramName = match.Groups["paramName"].Value;
				if (!parameters.Contains(paramName))
					parameters.Add("@"+paramName, DBNull.Value);
			}
		}

		public void ExtractParameters(SqlParameterCollection parameters)
		{
			ExtractParameters(statement, parameters);
		}

		public void CreateSqlCommand(SqlCommand command, bool rebuild)
		{
			if (rebuild || statement == null)
			{
				command.Parameters.Clear();
				this.Rebuild();
			}
			command.CommandText = statement;
			command.CommandType = CommandType.Text;
			ExtractParameters(command.Parameters);
		}

		public void CreateSqlCommand(SqlCommand command)
		{
			CreateSqlCommand(command, true);
		}

		public SqlCommand CreateSqlCommand(SqlConnection connection, bool rebuild)
		{
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = connection;
			CreateSqlCommand(cmd, rebuild);
			return cmd;
		}

		public SqlCommand CreateSqlCommand(SqlConnection connection)
		{
			return CreateSqlCommand(connection, true);
		}

		public SqlCommand CreateSqlCommand(string connection, bool rebuild)
		{
			return CreateSqlCommand(new SqlConnection(connection), rebuild);
		}

		public SqlCommand CreateSqlCommand(string connection)
		{
			return CreateSqlCommand(new SqlConnection(connection), true);
		}

		
		public static string[] FindTableColumns(SqlConnection connection, string tableName, bool tableDotColumn, bool bracket)
		{
			return FindQueryColumnsFrom(connection, "select * from ["+tableName+"] where 1=2", tableDotColumn, bracket);
		}

		public static string[] FindQueryColumnsFrom(SqlConnection connection, string sql, bool tableDotColumn, bool bracket)
		{
			string[] columns = null;
			if (connection.State == ConnectionState.Closed)
				connection.Open();
			try
			{
				DataSet ds = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(
					connection, CommandType.Text, sql);
				DataTable tbl = ds.Tables[0];
				columns = new string[tbl.Columns.Count];
				for (int i = 0; i < tbl.Columns.Count; i++)
				{
					columns[i] = tbl.Columns[i].ColumnName;
					/*
					if (tableDotColumn)
					{
						
						if (bracket)
							columns[i] = "[" + tableName + "].[" + tbl.Columns[i].ColumnName + "]";
						else
							columns[i] = tableName + "." + tbl.Columns[i].ColumnName;
					}
					else
					{
						if (bracket)
							columns[i] = "[" + tbl.Columns[i].ColumnName + "]";
						else
							columns[i] = tbl.Columns[i].ColumnName;
					}*/
				}
			}
			finally
			{
				connection.Close();
			}

			if (columns == null)
				columns = new string[0];

			return columns;
		}

		public string[] GetColumnNames()
		{
			string[] colNames = new string[columns.Count];
			for (int i = 0; i < columns.Count; i++)
			{
				SQLColumn col = columns[i];
				colNames[i] = col.GetValidColumnName();
			}
			return colNames;
		}

		public string[] GetSimpleColumnNamesByEmptyQuery(SqlConnection connection, bool bracket)
		{
			string[] colNames = null;
			string oldWhere = this.whereClause;

			try
			{
				this.whereClause = "1=2";	// temporarily return 0 rows
				string s = this.Build();
				colNames = FindQueryColumnsFrom(connection, s, false, false);

			}
			finally
			{
				this.whereClause = oldWhere;
			}

			return colNames;
		}

		/// <summary>
		/// Examines all columns and all tables and joinclauses and returns
		/// a list of all column names.  If there are any * or table.*
		/// expressions, there's returned as full list of columns.
		/// </summary>
		/// <param name="connection"></param>
		/// <param name="bracket"></param>
		/// <returns></returns>
		public string[] GetSimpleColumnNamesByAnalysis(SqlConnection connection, bool bracket)
		{
			ArrayList allCols = new ArrayList();
			string mainTable = this.Tables[0];
			bool multiTable = false;
			if (tables.Count > 1)
				multiTable = true;
			else if (joinClauses.Count > 0)
				multiTable = true;
			for (int i = 0; i < columns.Count; i++)
			{
				string colName = columns[i].GetValidColumnName();
				if (colName == "*")
				{
					string[] cols = FindTableColumns(connection, mainTable, multiTable, bracket);
					allCols.AddRange(cols);
				}
				else	// is it in 'TableName.*' form
				{
					int astIdx = colName.IndexOf(".*");
					if (astIdx >= 0)
					{
						string tableName = colName.Substring(0, astIdx);
						tableName = NoBracket(tableName);
						string[] cols = FindTableColumns(connection, tableName, true, bracket);
						allCols.AddRange(cols);
					}
				}
			}

			// add 
			for (int j = 0; j < joinClauses.Count; j++)
			{
				string joinTable = joinClauses[j].JoinTable;
				if (!tables.Contains(joinTable))
				{
					string[] cols = FindTableColumns(connection, joinTable, true, bracket);
					allCols.AddRange(cols);
				}
			}
			
			return (string[])allCols.ToArray(typeof(string));
		}

		public string[] GetSimpleColumnNames(SqlConnection connection, bool bracket)
		{
			//if (tables.Count > 1 || joinClauses.Count > 0)
				return GetSimpleColumnNamesByEmptyQuery(connection, bracket);
			//else
			//	return GetSimpleColumnNamesByAnalysis(connection);
		}

		private static void ParseParamNameType(string item, out string paramName, out Type type)
		{
			string stype;
			ParseParamNameType(item, out paramName, out stype);
			type = Type.GetType(stype);
			if (type == null)
				throw new SQLInvalidParameterizedClauseException("Unknown type declaration (" + stype + ") in @ParamName:Type@Value@");
		}

		private static void ParseParamNameType(string item, out string paramName, out string type)
		{
			string[] terms = item.Split(':');

			if (terms.Length == 1)
			{
				paramName = terms[0];
				type = "System.String";
				return;
			}
			if (terms.Length == 2)
			{
				paramName = terms[0];
				type = terms[1];
				return;
			}

			throw new SQLInvalidParameterizedClauseException("Invalid @ParameterName:Type@Value@ declaration!");
		}

		public static string PrepareParameterizedClause(SqlParameterCollection parameters, string clause)
		{	
			try
			{
				Regex regex = new Regex( StringParamMatchRegex, 
					RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
				Match match;
				string substituted = "";
				int lastpos = 0;
				int ipos = 0;
			
				for (match = regex.Match(clause); match.Success; match = match.NextMatch())
				{
					// extract item name from match
					string item = match.Groups["item"].Value;
					string itemValue = match.Groups["value"].Value;
					ipos = match.Groups["item"].Index - 1;
					int ilen = item.Length;
					if (ilen > 0)
					{
						string paramName;
						object paramVal;
						Type type;
						ParseParamNameType(item, out paramName, out type);
						if (type == typeof(DBNull))
							paramVal = DBNull.Value;
						else
							paramVal = Convert.ChangeType(itemValue, type);		// convert to the specified type
						if (!parameters.Contains(paramName))
							parameters.Add("@"+paramName, paramVal);
						else
							parameters[paramName].Value = paramVal;
						substituted += clause.Substring(lastpos, ipos - lastpos);
						substituted += "@" + paramName;
					}
					lastpos = ipos + ilen + itemValue.Length + 4;
				}
				ipos = clause.Length;
				substituted += clause.Substring(lastpos, ipos - lastpos);

				return substituted;
			}
			catch(Exception ex)
			{
				throw new SQLInvalidParameterizedClauseException("Invalid parameterized clause! (" + clause + ")", ex); 
			}
		}

		#endregion

		#region Static functions

		public static string[] CreateSubstitutableStrings(SqlParameterCollection parameters)
		{
			if (parameters.Count == 0)
				return null;
			string[] sParams = new string[parameters.Count];
			for (int i = 0; i < parameters.Count; i++)
			{
				object val = parameters[i].Value;
				if (val is string)
				{
					sParams[i] = "'" + (string)val + "'";
				}
				else
					sParams[i] = val.ToString();
			}

			return sParams;
		}

		public static string MergeColumnNames(string[] columns)
		{
			string s = "";
			for (int i = 0; i < columns.Length; i++)
			{
				if (i > 0)
					s += ",";
				s += MakeFullColumnDesc(columns[i]);
			}
			return s;
		}

		public static string[] ParseColumnNames(string columns)
		{
			string[] columnArray = columns.Split(',');
			for (int i = 0; i < columnArray.Length; i++)
			{
				string tableName;
				string colName;
				ParseColumn(columnArray[i], out tableName, out colName);
				if (tableName == "")
					columnArray[i] = colName;
				else
					columnArray[i] = MergeColumn(tableName, colName);
			}
			return columnArray;
		}

		/// <summary>
		/// Returns a securely substitable string value to be used when
		/// constructing a sql statement.
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static string GetSecureSubstitutable(string value)
		{
			if (value == null)
				return null;
			value = value.Replace("'", "");
			return value;
		}

		public static string GetSecureSubstitutable(object value)
		{
			string s = Convert.ToString(value);
			if (value is string)
				return "'" + GetSecureSubstitutable(s) + "'";
			else if (value is DateTime)
				return "'" + ((DateTime)value).ToShortDateString() + "'";
			else if (value is Guid)
				return "'" + ((Guid)value).ToString() + "'";
			else
				return GetSecureSubstitutable(s);
		}

		public static string GetMultiKeyWhereExpression(object[] keys, bool InKeyword)
		{
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < keys.Length; i++)
			{
				if (i > 0)
					sb.Append(",");
				sb.Append(GetSecureSubstitutable(keys[i]));
			}

			if (sb.Length > 0)
				if (InKeyword)
					return " in (" + sb.ToString() + ")";

			return sb.ToString();
		}

		/// <summary>
		/// General purpose string append function with also uses a given
		/// delimiter if the source string is not empty.
		/// </summary>
		/// <param name="src"></param>
		/// <param name="delim"></param>
		/// <param name="append"></param>
		/// <returns></returns>
		public static string AppendDelim(string src, string delim, string append)
		{
			if (src == null)
				return append;

			if (src.Length == 0)
				return append;

			return src + delim + append;
		}

		public static string AppendDelim(string src, string delim, string append, params object[] args)
		{
			return AppendDelim(src, delim, String.Format(append, args));
		}

		public static void AppendFilterAndSort(SqlCommand cmd, string where, string sort, bool useWhereKeyword)
		{
			string sql = cmd.CommandText;

			if (where != null && where != "")
			{
				if (useWhereKeyword)
					sql += " where ";
				else
					sql += " and ";		// use and keyword
				sql += SQLParser.PrepareParameterizedClause(cmd.Parameters, where);
			}

			if (sort != null && sort != "")
				sql += " order by " + sort;

			cmd.CommandText = sql;
		}

		public string StringParam(string paramName, object value)
		{
			string sval = null;
			Type type;
			if (value == null || value is DBNull)
				type = typeof(DBNull);
			else
			{
				type = value.GetType();
				sval = Convert.ToString(value);
			}

			string stype;
			if (value is string)
				stype = null;
			else
				stype = ":" + type.FullName;
			return String.Format("@{0}{1}@|{2}|", paramName, stype, sval);
		}

		public static SqlDbType TypeToSqlDbType(Type type)
		{
			if (type == typeof(string))
				return SqlDbType.VarChar;
			if (type == typeof(int))
				return SqlDbType.Int;
			if (type == typeof(System.Int16))
				return SqlDbType.SmallInt;
			if (type == typeof(float))
				return SqlDbType.Float;
			if (type == typeof(System.Double))
				return SqlDbType.Float;
			if (type == typeof(System.Decimal))
				return SqlDbType.Decimal;
			if (type == typeof(System.DateTime))
				return SqlDbType.DateTime;
			if (type == typeof(bool))
				return SqlDbType.Bit;
			if (type == typeof(char))
				return SqlDbType.Char;
			if (type == typeof(Guid))
				return SqlDbType.UniqueIdentifier;

			return SqlDbType.VarChar;
		}

		#endregion
	}
}
