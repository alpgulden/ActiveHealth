using System;
using System.IO;
using System.Diagnostics;
using System.Collections;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Creates an in memory hash table for quickly
	/// accessing a collection's elements by given members
	/// or if no members are specified, by the given object instance.
	/// </summary>
	public class CollectionIndexer
	{
		private IList collection;
		private string[] members;
		private Hashtable hash = new Hashtable();

		public CollectionIndexer(IList collection, string[] members)
			: this(collection, members, false)
		{
		}

		public CollectionIndexer(IList collection, string[] members, bool build)
		{
			this.collection = collection;
			BaseDataCollectionClass dataCol = this.collection as BaseDataCollectionClass;
			if (dataCol != null)
				dataCol.CollectionLoaded +=new NetsoftUSA.DataLayer.BaseDataCollectionClass.CollectionLoadedHandler(dataCol_CollectionLoaded);

			this.members = members;

			if (build)
				Rebuild();
		}


		private string GetHashKey(object[] vals)
		{
			if (vals == null)
				return "";
			string hash = "";
			for (int i = 0; i < vals.Length; i++)
			{
				object o = vals[i];
				if (o == null)
					hash += "*";
				else
					hash += "|" + o.ToString();
			}
			return hash;
			
			//return GenerateArrayHashCode(vals);
		}


		private void AddObjIndex(int index, object obj)
		{
			object[] vals = null;
			if (obj != null)
				vals = ReflectionHelper.GetMemberValues(obj, members);
			
			hash.Add(GetHashKey(vals), index);
		}

		public int IndexOf(params object[] memberVals)
		{
			if (memberVals.Length != members.Length)
				throw new ArgumentException("Invalid indexer members values");
			object oindex = hash[GetHashKey(memberVals)];
			if (oindex == null)
				return -1;
			else
				return (int)oindex;
		}

		public int IndexOfObject(object obj)
		{
			object[] vals = null;
			if (obj != null)
				vals = ReflectionHelper.GetMemberValues(obj, members);
			
			return IndexOf(vals);
		}

		public object GetObject(params object[] memberVals)
		{
			int i = IndexOf(memberVals);
			if (i >= 0)
				return collection[i];
			else
				return null;
		}

		public object LookupMember(string memberToLookup, params object[] memberVals)
		{
			object obj = GetObject(memberVals);
			if (obj == null)
				return null;
			else
				return ReflectionHelper.GetMemberValue(obj, memberToLookup);
		}

		public string LookupStringMember(string memberToLookup, params object[] memberVals)
		{
			return Convert.ToString( LookupMember(memberToLookup, memberVals) );
		}

		public int LookupIntMember(string memberToLookup, params object[] memberVals)
		{
			return Convert.ToInt32( LookupMember(memberToLookup, memberVals) );
		}

		public string LookupAndFormat(string substitutionFormat, params object[] memberVals)
		{
			return Formatting.SubstituteByObjectMembers(substitutionFormat, memberVals);
		}

		public void Rebuild()
		{
			lock(collection.SyncRoot)
			{
				hash.Clear();
				for (int i = 0; i < collection.Count; i++)
				{
					AddObjIndex(i, collection[i]);
				}
			}
		}

		/// <summary>
		/// Generates a hash code using all of the 
		/// elements in the given array.  The hash
		/// code attempts to make the output
		/// as unique as possible.  Always
		/// returns the same value for the same
		/// combination.
		/// </summary>
		/// <param name="arr"></param>
		/// <returns></returns>
		public static int GenerateArrayHashCode(object[] arr)
		{
			if (arr == null)
				return 0;
			int hash = 0;
			for (int i = 0; i < arr.Length; i++)
			{
				object o = arr[i];
				if (o == null)
					hash ^= i;
				else
					hash ^= arr[i].GetHashCode();
			}
			return hash;
		}

		private void dataCol_CollectionLoaded(object sender, EventArgs e)
		{
			this.Rebuild();
		}

	}
}
