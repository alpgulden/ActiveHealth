using System;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Compares the existance of values in two arrays
	/// and creates a difference map.
	/// </summary>
	public class ArrayDelta
	{
		#region Enumerations

		public enum DeltaKind
		{
			Both = 0,
			Only1st = 1,
			Only2nd = 2
		}

		#endregion

		#region Private members

		private Hashtable delta = new Hashtable();

		#endregion
		
		#region Constructors

		public ArrayDelta(object[] array1, object[] array2)
		{
			Hashtable hash1 = NSGlobal.CreateHashtable(array1);
			Hashtable hash2 = NSGlobal.CreateHashtable(array2);

			for (int i = 0; i < array1.Length; i++)
			{
				object val1 = array1[i];
				if (hash2.Contains(val1))
					delta[val1] = DeltaKind.Both;
				else
					delta[val1] = DeltaKind.Only1st;
			}

			for (int i = 0; i < array2.Length; i++)
			{
				object val2 = array2[i];
				if (hash1.Contains(val2))
					delta[val2] = DeltaKind.Both;
				else
					delta[val2] = DeltaKind.Only2nd;
			}
		}

		#endregion

		#region Public functions

		public object[] GetAllValues()
		{
			object[] arr = new object[delta.Keys.Count];
			delta.Keys.CopyTo(arr, 0);
			return arr;
		}

		public DeltaKind GetDeltaKind(object value)
		{
			return (DeltaKind)delta[value];
		}

		public DeltaKind this[object value]
		{
			get
			{
				return (DeltaKind)delta[value];
			}
		}

		#endregion

		#region Whitebox Testers

		/*
		public static void Test()
		{
			object[] keys1 = new object[] { 1, 3, 4      , 12, 14 };
			object[] keys2 = new object[] { 1, 3, 4, 5, 6,     14 };
			ArrayDelta arrDelta = new ArrayDelta(keys1, keys2);
			object[] allValues = arrDelta.GetAllValues();
			for (int i = 0; i < allValues.Length; i++)
			{
				Debug.WriteLine(arrDelta.GetDeltaKind(allValues[i]).ToString());
			}
		}
		*/

		#endregion
	}
}
