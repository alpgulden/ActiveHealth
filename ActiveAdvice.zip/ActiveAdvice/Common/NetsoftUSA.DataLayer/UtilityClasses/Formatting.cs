using System;
using System.Text.RegularExpressions;
using System.Collections;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Formatting helper functions.
	/// </summary>
	public class Formatting
	{
		protected const string HashTableItemMatchRegex = "@(?<itemName>[0-9a-zA-Z_]+)@";

		public static string ParseDescriptionPart(string sval, char sep)
		{
			if (sval == null)
				return null;

			string[] terms = sval.Split(sep);
			if (terms.Length > 1)
				return terms[1];
			
			return terms[0];
		}

		public static string ParseDescriptionPart(string sval)
		{
			return ParseDescriptionPart(sval, '|');
		}

		public static string ParseValuePart(string sval, char sep)
		{
			if (sval == null)
				return null;

			string[] terms = sval.Split(sep);
			if (terms.Length > 0)
				return terms[0];
			
			return sval;
		}

		public static string ParseValuePart(string sval)
		{
			return ParseValuePart(sval, '|');
		}

		public static string FormatValueDesc(string value, string desc)
		{
			if (desc != null)
				return value + "|" + desc;
			else
				return value;
		}

		public static string FormatDecimal(Decimal value, string format)
		{
			if (value == Decimal.MinValue)
				return null;
			else
				return value.ToString(format);
		}

		public static string FormatDecimal(Decimal value, Decimal ValueForNull)
		{
			if (value == ValueForNull)
				return null;
			else
				return value.ToString();
		}

		public static Decimal ParseDecimal(string s, System.Globalization.NumberStyles style)
		{
			if (s == null || s == "")
				return Decimal.MinValue;
			else
				return Decimal.Parse(s, style);
		}

		public static Decimal ParseDecimal(string s, Decimal ValueForNull)
		{
			if (s == null || s == "")
				return ValueForNull;
			else
				return Decimal.Parse(s);
		}

		public static string FormatShortDate(DateTime value)
		{
			if (value == DateTime.MinValue)
				return null;
			else
				return value.ToShortDateString();
		}

		public static string FormatShortTime(DateTime value)
		{
			if (value == DateTime.MinValue)
				return null;
			else
				return value.ToShortTimeString();
		}

		public static DateTime ParseDate(string s)
		{
			if (s == null || s == "")
				return DateTime.MinValue;
			else
				return DateTime.Parse(s);
		}

		public static DateTime ParseShortDate(string s)
		{
			if (s == null || s == "")
				return DateTime.MinValue;
			else
				return DateTime.Parse(s);
		}

		public static DateTime ParseTime(string s)
		{
			if (s == null || s == "")
				return DateTime.MinValue;
			else
				return DateTime.Parse(s);
		}

		public static DateTime ParseTime(DateTime date, string s)
		{
			if (s == null || s == "")
				return new DateTime(date.Year, date.Month, date.Day);
			else
			{
				DateTime time = DateTime.Parse(s);
				return new DateTime(date.Year, date.Month, date.Day, time.Hour, time.Minute, time.Second, time.Millisecond);
			}
		}

		//

		public static string FormatInt(int value)
		{
			return value.ToString();
		}

		public static string FormatInt(int value, int valueForNull)
		{
			if (value == valueForNull)
				return null;
			else
				return value.ToString(); 
		}

		public static int ParseInt(string s, int valueForNull)
		{
			
			if (s == null || s == "")
				return valueForNull;
			else
				return int.Parse(s);
		}

		public static int ParseInt(string s)
		{
			return int.Parse(s);
		}

		public static string FormatIntThousands(int value, int valueForNull)
		{
			if (value == valueForNull)
				return null;
			else
				return value.ToString("C").Trim('$');
		}

		public static int ParseIntThousands(string s, int valueForNull)
		{
			
			if (s == null || s == "")
				return valueForNull;
			else
			{
				s = s.Replace(",", "");
				return int.Parse(s);
			}
		}

		//
		public static string FormatFloat(float value)
		{
			if (value == float.MinValue)
				return null;
			else
				return value.ToString().Trim('$'); 
		}

		public static float ParseFloat(string s)
		{
			
			if (s == null || s == "")
				return float.MinValue;
			else
				return float.Parse(s);
		}

		public static string FormatFloatThousands(float value)
		{
			if (value == float.MinValue)
				return null;
			else
				return value.ToString("C").Trim('$');
		}

		public static float ParseFloatThousands(string s)
		{
			
			if (s == null || s == "")
				return float.MinValue;
			else
			{
				s = s.Replace(",", "");
				return float.Parse(s);
			}
		}

		//
		public static string FormatDouble(double value)
		{
			if (value == double.MinValue)
				return null;
			else
				return value.ToString(); 
		}

		public static double ParseDouble(string s)
		{
			
			if (s == null || s == "")
				return double.MinValue;
			else
				return double.Parse(s);
		}

		public static string FormatDoubleThousands(double value)
		{
			if (value == double.MinValue)
				return null;
			else
				return value.ToString("C").Trim('$');
		}

		public static double ParseDoubleThousands(string s)
		{
			
			if (s == null || s == "")
				return double.MinValue;
			else
			{
				s = s.Replace(",", "");
				return double.Parse(s);
			}
		}

		//
		public static string FormatDecimal(decimal value)
		{
			if (value == decimal.MinValue)
				return null;
			else
				return value.ToString(); 
		}

		public static decimal ParseDecimal(string s)
		{
			
			if (s == null || s == "")
				return decimal.MinValue;
			else
				return decimal.Parse(s);
		}

		public static string FormatDecimalThousands(decimal value)
		{
			if (value == decimal.MinValue)
				return null;
			else
				return value.ToString("C").Trim('$');
		}

		public static decimal ParseDecimalThousands(string s)
		{
			
			if (s == null || s == "")
				return decimal.MinValue;
			else
			{
				s = s.Replace(",", "");
				return decimal.Parse(s);
			}
		}
		//
		public static string FormatCurrency(Decimal value, bool dollarSign)
		{
			if (value == Decimal.MinValue)
				return null;

			if (dollarSign)
				return value.ToString("C");
			else
				return value.ToString("C").Trim('$');
		}

		public static string FormatCurrency(Decimal value)
		{
			return FormatCurrency(value, false);
		}

		public static Decimal ParseCurrency(string s)
		{
			if (s == null || s == "")
				return Decimal.MinValue;

			return Decimal.Parse(s, 
				System.Globalization.NumberStyles.Currency);
				/*System.Globalization.NumberStyles.AllowCurrencySymbol | 
				System.Globalization.NumberStyles.AllowDecimalPoint |
				System.Globalization.NumberStyles.AllowThousands |*/
				
		}

		public static string FormatUSSSN(string s)
		{
			if (s == null)
				return s;

			return String.Format("{0}-{1}-{2}", s.Substring(0, 3), s.Substring(3, 2), s.Substring(5, 4));
		}

		public static string ParseUSSSN(string ssn)
		{
			if (ssn == null)
				return ssn;
			else
				return ssn.Replace("-", "");
		}

		public static string FormatUSSSN(int ssn)
		{
			if (ssn == 0)
				return null;

			return FormatUSSSN(ssn.ToString());
		}

		public static int ParseUSSSNInt(string ssn)
		{
			if (ssn == null)
				return 0;
			else
				return int.Parse(ParseUSSSN(ssn));
		}

		// 
		public static string FormatUSZipCode(string s)
		{
			if (s == null)
				return s;

			return String.Format("{0}-{1}", s.Substring(0, 5), s.Substring(5, 4));
		}

		public static string ParseUSZipCode(string ssn)
		{
			if (ssn == null)
				return ssn;
			else
				return ssn.Replace("-", "");
		}

		public static string FormatUSZipCode(int zip)
		{
			if (zip == 0)
				return null;

			return FormatUSZipCode(zip.ToString());
		}

		public static int ParseUSZipCodeInt(string zip)
		{
			if (zip == null)
				return 0;
			else
				return int.Parse(ParseUSZipCode(zip));
		}

		// 
		public static string FormatUSPhoneNumber(string s)
		{
			if (s == null)
				return s;

			switch (s.Length)
			{
				case 10:
					return String.Format("({0}) {1}-{2}", s.Substring(0, 3), s.Substring(3, 3), s.Substring(6,4));
				case 11:
					return String.Format("1 ({0}) {1}-{2}", s.Substring(1, 3), s.Substring(4, 3), s.Substring(7,4));
				case 7:
					return String.Format("{1}-{2}", s.Substring(0, 3), s.Substring(4,4));
				default:
					return s;	// unknown number of digits
			}
		}

		public static string ParseUSPhoneNumber(string phone)
		{
			if (phone == null)
				return phone;
			else
			{
				phone = phone.Replace("-", "");
				phone = phone.Replace("(", "");
				phone = phone.Replace(")", "");
				phone = phone.Replace(" ", "");
				return phone;
			}
		}

		public static string FormatUSPhoneNumber(int phone)
		{
			if (phone == 0)
				return null;

			return FormatUSPhoneNumber(phone.ToString());
		}

		public static int ParseUSPhoneNumberInt(string phone)
		{
			if (phone == null)
				return 0;
			else
				return int.Parse(ParseUSPhoneNumber(phone));
		}


		//

		public static string SubstituteByObjectMembers(string expression, object obj)
		{
			if (expression == null)
				return null;

			if (obj == null)
				return expression;

			Regex regex = new Regex( HashTableItemMatchRegex , 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			string substituted = "";
			int lastpos = 0;
			int ipos = 0;
			for (match = regex.Match(expression); match.Success; match = match.NextMatch())
			{
				// extract item name from match
				string itemName = match.Groups["itemName"].Value;
				ipos = match.Groups["itemName"].Index - 1;
				int ilen = itemName.Length;
				if (ilen > 0)
				{
					string val = ControlTypeAttribute.GetMemberValueAsString(obj, itemName);
					substituted += expression.Substring(lastpos, ipos - lastpos);
					substituted += val;
				}
				lastpos = ipos + ilen + 2;
			}
			ipos = expression.Length;
			substituted += expression.Substring(lastpos, ipos - lastpos);
			return substituted;
		}

		public static string SubstituteByHashtable(string expression, Hashtable hashTable)
		{
			if (expression == null)
				return null;

			if (hashTable == null)
				return expression;

			Regex regex = new Regex( HashTableItemMatchRegex , 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			string substituted = "";
			int lastpos = 0;
			int ipos = 0;
			for (match = regex.Match(expression); match.Success; match = match.NextMatch())
			{
				// extract item name from match
				string itemName = match.Groups["itemName"].Value;
				ipos = match.Groups["itemName"].Index - 1;
				int ilen = itemName.Length;
				if (ilen > 0)
				{
					string val = Convert.ToString(hashTable[itemName]);
					substituted += expression.Substring(lastpos, ipos - lastpos);
					substituted += val;
				}
				lastpos = ipos + ilen + 2;
			}
			ipos = expression.Length;
			substituted += expression.Substring(lastpos, ipos - lastpos);
			return substituted;
		}

		public static string[] ExtractSubstitutables(string expression)
		{
			if (expression == null)
				return null;

			Regex regex = new Regex( HashTableItemMatchRegex , 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			Hashtable map = new Hashtable();
			for (match = regex.Match(expression); match.Success; match = match.NextMatch())
			{
				// extract item name from match
				string itemName = match.Groups["itemName"].Value;
				map[itemName] = null;
			}
			string[] arr = new string[map.Count];
			int i = 0;
			foreach (DictionaryEntry entry in map)
				arr[i++] = Convert.ToString(entry.Key);
			return arr;
		}

		public static string[] ExtractSubstitutablesAndStatics(string expression)
		{
			if (expression == null)
				return null;

			Regex regex = new Regex( HashTableItemMatchRegex , 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			ArrayList list = new ArrayList();
			int lastpos = 0;
			int ipos = 0;
			string stat = null;
			for (match = regex.Match(expression); match.Success; match = match.NextMatch())
			{
				// extract item name from match
				string itemName = match.Groups["itemName"].Value;
				ipos = match.Groups["itemName"].Index - 1;
				int ilen = itemName.Length;
				if (ilen > 0)
				{
					stat = expression.Substring(lastpos, ipos - lastpos);
					if (stat.Length > 0)
						list.Add(stat);	// add chars before
					list.Add("@" + itemName + "@");	// add item name
				}
				lastpos = ipos + ilen + 2;
			}
			ipos = expression.Length;
			stat = expression.Substring(lastpos, ipos - lastpos); //add chars after
			if (stat.Length > 0)
				list.Add(stat);

			return (string[])list.ToArray(typeof(string));
		}

		public static string[] ExtractSubstitutablesAndStatics(string expression, Hashtable hashTable)
		{
			string[] arr = ExtractSubstitutablesAndStatics(expression);
			for (int i = 0; i < arr.Length; i++)
			{
				string item = arr[i];
				if (item.Length >= 1)
				{
					if (item[0] == '@' && item[item.Length - 1] == '@')
					{
						// this is a substitutable item name
						item = item.Trim('@');
						arr[i] = Convert.ToString(hashTable[item]);		// replace this with its value in hashtable
					}
				}
			}

			return arr;
		}

		/// <summary>
		/// Parse the given string into a given hashTable by groupnames.
		///      ParseIntoHashtable("5/6/2004", "(?<month>[0-9]{1,2})/(?<day>[0-9]{1,2})/(?<year>[0-9]{2,4})");
		///    will return a hastable with following key-value pairs:
		///      "month", "5"
		///      "day", "6"
		///      "year", "2004"
		/// </summary>
		/// <param name="s"></param>
		/// <param name="regExp"></param>
		/// <param name="hashTable"></param>
		/// <returns></returns>
		public static bool ParseIntoHashtable(string s, string regExp, Hashtable hashTable)
		{
			Regex regex = new Regex( regExp, 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match = regex.Match(s);
			if (match.Success)		// check only first match
			{
				string[] groupNames = regex.GetGroupNames();
				for (int i = 1; i < groupNames.Length; i++)
				{
					string groupName = groupNames[i];
					Group group = match.Groups[groupName];
					hashTable[groupName] = group.Value;
				}
				return true;
			}
			else
				return false;
		}

		public static Hashtable ParseIntoHashtable(string s, string regExp)
		{
			Hashtable hashTable = new Hashtable();
			if (ParseIntoHashtable(s, regExp, hashTable))
				return hashTable;
			else
				return null;
		}

		public static string RemoveChars(string s, params char[] chars)
		{
			if (s == null)
				return null;
			for (int i = 0; i < chars.Length; i++)
			{
				s = s.Replace(chars[i].ToString(), "");
			}
			return s;
		}

	}
}
