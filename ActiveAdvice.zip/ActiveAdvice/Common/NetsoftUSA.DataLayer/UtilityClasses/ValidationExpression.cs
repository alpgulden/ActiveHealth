using System;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// static regular expression strings to be used with validation
	/// </summary>
	public class ValidationExpression
	{
		static public string Email = @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
		static public string URL = @"http://([\w-]+\.)+[\w-]+(/[\w- ./?%&=]*)?";
		static public string USPhoneNumber = @"((\(\d{3}\)-?)|(\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}";
		static public string USPhoneNumberRaw = @"[0123456789]{10}([0123456789\s]*)?";
		//static public string USSSN = @"(\d{3})?-(\d{2})?-(\d{4})?";
		static public string USSSN = @"(\d{3}-\d{2}-\d{4})|(--)";
		static public string USZipCode = @"(\d{5})?(-)?(\d{4})?";
		static public string DateTime = @"\d{1,2}/\d{1,2}/\d{2,4} \d{2}:\d{2}";		// correct this!
	}
}
