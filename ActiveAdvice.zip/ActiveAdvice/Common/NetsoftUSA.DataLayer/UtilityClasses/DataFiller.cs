using System;
using System.Data;
using NetsoftUSA.DataLayer;
using System.Reflection;
using System.Collections;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Utility class that fills a given object from
	/// the specified data source, or vice versa.
	/// The target object may be a user defined
	/// c# class.  The class may define column
	/// and collection mapping attributes that
	/// govern filling operations.
	/// 
	/// Use this class's static functions as helpers
	/// when developing strongly typed database
	/// mapped classes and collections.  
	/// 
	/// </summary>
	public class DataFiller
	{
		#region Enumerations

		[Flags()]
		public enum FillFlags
		{
			NoFill = 0,
			DataToObject = 1,
			ObjectToData = 2,
			BothWays = DataToObject | ObjectToData,
			NotNull = 4
		}

		#endregion

		#region IDataAccessor Interface

		public interface IDataAccessor : IEnumerable
		{
			object[] GetKeys();
			object Get(object[] keys);
			object New();
			void Update(object data);
			void Insert(object data);
			void Delete(object[] keys);
			void DeleteAll();
			IItemAccessor GetItemAccessor(object data);
		}

		#endregion

		#region IItemAccessor Interface
		/// <summary>
		/// This interface is implemented by data source accessors.
		/// For example a datarowview accessor implements this
		/// to access a data item in the row view.
		/// </summary>
		public interface IItemAccessor
		{
			void SetData(object data);		// data to work on
			object GetData();
			void SetItem(string colName, object val);	// work on item of data
			object GetItem(string colName);
		}
		#endregion

		#region IRelationalDataProvider Interface
		/// <summary>
		/// Implementer should
		/// create a data object for the 
		/// given relation and return it.
		/// </summary>
		public interface IRelationalDataProvider
		{
			IDataAccessor CreateRelatedData(SimpleRelationAttribute rel, IList forTargetCollection);
		}
		#endregion

		#region DataFillerParams Class

		public class DataFillerParams
		{
			public object obj;		// target object (not data)
			public IItemAccessor itemAccessor;
			public bool ignoreAssignmentError;
			public bool collections;

			public DataFillerParams(object obj, IItemAccessor itemAccessor, bool ignoreAssignmentError, bool collections)
			{
				this.obj = obj;
				this.itemAccessor = itemAccessor;
				this.ignoreAssignmentError = ignoreAssignmentError;
				this.collections = collections;
			}
		}

		#endregion

		#region CollectionDataFillerParams Class

		public class CollectionDataFillerParams
		{
			public IList collection;
			public IDataAccessor dataAccessor;
			public bool ignoreAssignmentError;
			public bool collections;

			public CollectionDataFillerParams(IList collection, IDataAccessor dataAccessor, bool ignoreAssignmentError, bool collections)
			{
				this.collection = collection;
				this.dataAccessor = dataAccessor;
				this.ignoreAssignmentError = ignoreAssignmentError;
				this.collections = collections;
			}
		}

		#endregion

		#region Single item access helper functions with default value for DBNull/Null

		public static object GetItem(DataFillerParams parms, string colName, object ValueForNull)
		{
			object o = parms.itemAccessor.GetItem(colName);
			if (o is DBNull || o == null)
				return ValueForNull;
			else
				return o;
		}

		public static bool EqualsValueForNull(object val, object ValueForNull)
		{
			if (val == null)
			{
				if (ValueForNull == null)
					return true;
				else
					return false;
			}
			else
			{
				if (val.Equals(ValueForNull))
					return true;
				else
					return false;
			}
		}

		public static void SetItem(DataFillerParams parms, string colName, object val, ColumnMappingAttribute colMap)
		{
			if (EqualsValueForNull(val, colMap.GetValueForNull()))
			{
				if (colMap.IsNotNull)	// if not nullable, allow default
					parms.itemAccessor.SetItem(colName, null);
				else
					parms.itemAccessor.SetItem(colName, DBNull.Value);
			}
			else
				parms.itemAccessor.SetItem(colName, val);
		}

		#endregion

		#region Reflection helper functions	


		#endregion

		#region Object's Prop/Field accessor functions

		private static void SetPropOrFieldFromData(DataFillerParams parms, MemberInfo PropOrField)
		{
			bool isField = PropOrField is FieldInfo;
			PropertyInfo prop = null;
			FieldInfo field = null;

			if (isField)
				field = PropOrField as FieldInfo;
			else
				prop = PropOrField as PropertyInfo;

			ColumnMappingAttribute colMap = null;
			
			if (isField)
				colMap = ColumnMappingAttribute.GetFromFieldInfo(field, true);
			else
				colMap = ColumnMappingAttribute.GetFromPropInfo(prop, true);

			// Is Data To Object filling enabled?
			if (!colMap.IsDataToObject)
				return;

			string colName = colMap.ColumnName;
			if (colName == null)
				colName = PropOrField.Name;

			try
			{
				object val = GetItem(parms, colName, colMap.GetValueForNull());
				if (isField)
					field.SetValue(parms.obj, val); //Convert.ChangeType(val, field.FieldType));
				else
					prop.SetValue(parms.obj, val, null);
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex);
				if (!parms.ignoreAssignmentError)
					throw;
			}
		}

		
		private static void SetDataFromPropOrField(DataFillerParams parms, MemberInfo PropOrField)
		{
			bool isField = PropOrField is FieldInfo;
			PropertyInfo prop = null;
			FieldInfo field = null;

			if (isField)
				field = PropOrField as FieldInfo;
			else
				prop = PropOrField as PropertyInfo;

			ColumnMappingAttribute colMap = null;

			if (isField)
				colMap = ColumnMappingAttribute.GetFromFieldInfo(field, true);
			else
				colMap = ColumnMappingAttribute.GetFromPropInfo(prop, true);

			// Is Object To Data filling enabled?
			if (!colMap.IsObjectToData)
				return;

			string colName = colMap.ColumnName;
			if (colName == null)
				colName = PropOrField.Name;

			try
			{
				object val = null;

				if (isField)
					val = field.GetValue(parms.obj);
				else
					val = prop.GetValue(parms.obj, null);

				SetItem(parms, colName, val, colMap);
				//colMap.fi
			}
			catch (System.Data.ReadOnlyException)
			{
				// ignore
			}
			catch(Exception ex)
			{
				System.Diagnostics.Debug.WriteLine(ex);
				if (!parms.ignoreAssignmentError)
					throw;
			}
		}

		
		private static void FillIntoCollectionPropOrField(DataFillerParams parms, MemberInfo mi)
		{
			SimpleRelationAttribute dataRel = SimpleRelationAttribute.GetFromMember(mi);
			if (dataRel == null)
				return;
			IList collection = ReflectionHelper.GetIListMember(mi, parms.obj);
			collection.Clear();
			IDataAccessor dataSource = ((IRelationalDataProvider)parms.itemAccessor).CreateRelatedData(dataRel, collection);
			using(dataSource as IDisposable)
			{
				AppendToCollection(dataSource, collection, parms.ignoreAssignmentError, parms.collections);
			}
		}

		private static void FillFromCollectionPropOrField(DataFillerParams parms, MemberInfo mi)
		{
			SimpleRelationAttribute dataRel = SimpleRelationAttribute.GetFromMember(mi);
			if (dataRel == null)
				return;
			IList collection = ReflectionHelper.GetIListMember(mi, parms.obj);
			IDataAccessor dataAccessor = ((IRelationalDataProvider)parms.itemAccessor).CreateRelatedData(dataRel, collection);
			using(dataAccessor as IDisposable)
			{
				FillFromCollection(dataAccessor, collection, parms.ignoreAssignmentError, parms.collections);
			}
		}

		#endregion

		#region Public generic filler functions

		public static void FillIntoObject(DataFillerParams parms)
		{
			Type tobj = parms.obj.GetType();
			MemberInfo[] members = 
				ColumnMappingAttribute.FindColumnMappingMembers(
				System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field, 
				parms.collections,
				tobj);
			foreach (MemberInfo mi in members)
			{
				if (parms.collections)
				{
					Type memberType = ColumnMappingAttribute.GetMemberDataType(mi);
					if (ColumnMappingAttribute.IsCollection(memberType))
					{
						FillIntoCollectionPropOrField(parms, mi);
						continue;
					}
				}

				SetPropOrFieldFromData(parms, mi);
			}
		}

		public static void FillFromObject(DataFillerParams parms)
		{
			Type tobj = parms.obj.GetType();
			MemberInfo[] members = 
				ColumnMappingAttribute.FindColumnMappingMembers(
				System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field, 
				parms.collections,
				tobj);
			foreach (MemberInfo mi in members)
			{
				if (parms.collections)
				{
					Type memberType = ColumnMappingAttribute.GetMemberDataType(mi);
					if (ColumnMappingAttribute.IsCollection(memberType))
					{
						FillFromCollectionPropOrField(parms, mi);
						continue;
					}
				}

				SetDataFromPropOrField(parms, mi);
			}
		}

		public static void FillIntoObject(DataFillerParams parms, string propOrFieldName)
		{
			MemberInfo mi = ReflectionHelper.FindPropOrFieldByName(parms.obj.GetType(), propOrFieldName);

			Type memberType = ColumnMappingAttribute.GetMemberDataType(mi);
			if (ColumnMappingAttribute.IsCollection(memberType))
			{
				FillIntoCollectionPropOrField(parms, mi);
			}

			// other types like nested objects should be handled here
		}

		public static void FillFromObject(DataFillerParams parms, string propOrFieldName)
		{
			MemberInfo mi = ReflectionHelper.FindPropOrFieldByName(parms.obj.GetType(), propOrFieldName);

			Type memberType = ColumnMappingAttribute.GetMemberDataType(mi);
			if (ColumnMappingAttribute.IsCollection(memberType))
			{
				FillFromCollectionPropOrField(parms, mi);
			}

			// other types like nested objects should be handled here
		}

		#endregion

		#region Public generic Collection filler functions
		
		/// <summary>
		/// Fill the collection from given dataSource
		/// using the item accessor specified.
		/// dataSource has multiple data items.  Each item is
		/// filled into a new instance of elemType
		/// and added into the collection.
		/// </summary>
		/// <param name="dataSource"></param>
		/// <param name="itemAccessor"></param>
		/// <param name="collection"></param>
		/// <param name="elemType"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="collections"></param>
		public static void AppendToCollection(IDataAccessor dataAccessor, IList collection, Type elemType, bool ignoreAssignmentError, bool collections)
		{
			if (elemType == null)
				throw new Exception("An element type must be specified!");

			// iterate on the datasource
			// create elemType and fill each of them with data
			foreach (object data in dataAccessor)
			{
				IItemAccessor itemAccessor = dataAccessor.GetItemAccessor(data);
				object elem = Activator.CreateInstance(elemType);
				DataFillerParams parms = new DataFillerParams(elem, itemAccessor, ignoreAssignmentError, collections);
				FillIntoObject(parms);
				collection.Add(elem);
			}
		}

		/// <summary>
		/// Fill the collection from given dataSource
		/// using the item accessor specified.
		/// dataSource has multiple data items.  Each item is
		/// filled into a new instance of the collection's
		/// declared ElementType
		/// and added into the collection.
		/// </summary>
		/// <param name="dataSource"></param>
		/// <param name="itemAccessor"></param>
		/// <param name="collection"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="collections"></param>
		public static void AppendToCollection(IDataAccessor dataAccessor, IList collection, bool ignoreAssignmentError, bool collections)
		{
			Type type = collection.GetType();
			ElementTypeAttribute elemTypeAttrib = ElementTypeAttribute.GetFromType(type);
			if (elemTypeAttrib == null)
				throw new Exception("An ElementTypeAttribute must be specified!");

			AppendToCollection(dataAccessor, collection, elemTypeAttrib.ElemType, ignoreAssignmentError, collections);
		}

		/// <summary>
		/// Fill dataSource from the collection
		/// using the item accessor specified.
		/// dataSource has multiple data items.  Each item is
		/// filled into a new instance of elemType
		/// and added into the collection.
		/// </summary>
		/// <param name="dataSource"></param>
		/// <param name="itemAccessor"></param>
		/// <param name="collection"></param>
		/// <param name="elemType"></param>
		/// <param name="ignoreAssignmentError"></param>
		/// <param name="collections"></param>
		public static void FillFromCollection(IDataAccessor dataAccessor, IList collection, bool ignoreAssignmentError, bool collections)
		{
			//if (elemType == null)
			//	throw new Exception("An element type must be specified!");

			object[] collKeys = ReflectionHelper.GetKeyValues(collection);
			object[] dataKeys = dataAccessor.GetKeys();

			// map collection its keys to use it for looking up the collection elements
			Hashtable collHash = NSGlobal.CreateHashtable(collKeys, collection);

			// compare data and collection keys

			ArrayDelta arrDelta = new ArrayDelta(collKeys, dataKeys);

			object[] allKeys = arrDelta.GetAllValues();

			// Walk on all the keys and take appropriate action
			for (int i = 0; i <  allKeys.Length; i++)
			{
				object key = allKeys[i];
				ArrayDelta.DeltaKind delta = arrDelta[key];
				switch (delta)
				{
					case ArrayDelta.DeltaKind.Both:
					{
						// The key exists in both the collection and the data.
						// update the data from collection
						object obj = collHash[key];
						object data = dataAccessor.Get(new object[] { key });
						DataFiller.DataFillerParams parms = 
							new DataFillerParams(obj, 
							dataAccessor.GetItemAccessor(data),
							ignoreAssignmentError,
							collections);
						FillFromObject(parms);
						dataAccessor.Update(data);
						break;
					}
					case ArrayDelta.DeltaKind.Only1st:
					{
						// The key exists only in collection.
						// Insert it into the data.
						object obj = collHash[key];
						object data = dataAccessor.New();
						DataFiller.DataFillerParams parms = 
							new DataFillerParams(obj, 
							dataAccessor.GetItemAccessor(data),
							ignoreAssignmentError,
							collections);
						FillFromObject(parms);
						dataAccessor.Insert(data);  // we don't set PK member on the data object
						break;
					}
					case ArrayDelta.DeltaKind.Only2nd:
					{
						// The key exists only in data.
						// Delete it from the data.
						dataAccessor.Delete(new object[] { key });
						break;
					}
				}
			}
		}

		/*
		public static void FillFromCollection(IDataAccessor dataAccessor, IList collection, bool ignoreAssignmentError, bool collections)
		{
			Type type = collection.GetType();
			ElementTypeAttribute elemTypeAttrib = ElementTypeAttribute.GetFromType(type);
			if (elemTypeAttrib == null)
				throw new Exception("An ElementTypeAttribute must be specified!");

			FillFromCollection(dataAccessor, collection, elemTypeAttrib.ElemType, ignoreAssignmentError, collections);
		}*/

		#endregion

	}
}