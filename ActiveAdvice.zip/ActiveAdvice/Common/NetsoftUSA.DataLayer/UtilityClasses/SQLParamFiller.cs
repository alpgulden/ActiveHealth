using System;
using System.Data;
using System.Data.SqlClient;
using NetsoftUSA.DataLayer;
using System.Collections;
using System.Reflection;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Fills an object to/from a SqlParameterCollection
	/// </summary>

	public class SQLParamFiller
	{
		/// <summary>
		/// Used as an item accessor on the given rowView
		/// </summary>
		public class SQLParamAccessor :DataFiller.IItemAccessor
		{
			//private SqlParameterCollection parameters;
			private SqlParameterCollection parameters;

			public SQLParamAccessor(SqlParameterCollection parameters)
			{
				this.parameters = parameters;
			}

			#region IItemAccessor Members

			public void SetData(object data)
			{
				parameters = (SqlParameterCollection)data;
			}

			public object GetData()
			{
				return parameters;
			}

			public void SetItem(string colName, object val)
			{
				string name = "@" + colName;
				SqlParameter par = parameters[name];
				if (par == null)
					par = parameters.Add(name, val);
				par.Value = val;
			}

			public object GetItem(string colName)
			{
				return parameters["@" + colName].Value;
			}

			#endregion
		}

		#region Object filler functions

		/// <summary>
		/// Fills the public fields/properties of the given
		/// target object from the given parameters collection
		/// </summary>
		/// <param name="parameters"></param>
		/// <param name="TargetObject"></param>
		public static void FillIntoObject(SqlParameterCollection parameters, object targetObj, bool ignoreAssignmentError)
		{
			SQLParamAccessor paramAccessor = new SQLParamAccessor(parameters);
			DataFiller.DataFillerParams parms = new DataFiller.DataFillerParams(targetObj, paramAccessor, ignoreAssignmentError, false);
			DataFiller.FillIntoObject(parms);
		}

		/// <summary>
		/// Fills the parameters collection from given object's public fields/properties
		/// </summary>
		/// <param name="parameters"></param>
		/// <param name="SourceObject"></param>
		public static void FillFromObject(SqlParameterCollection parameters, object sourceObj, bool ignoreAssignmentError)
		{
			SQLParamAccessor paramAccessor = new SQLParamAccessor(parameters);
			DataFiller.DataFillerParams parms = new DataFiller.DataFillerParams(sourceObj, paramAccessor, ignoreAssignmentError, false);
			DataFiller.FillFromObject(parms);
		}

		public static void FillParameters(SqlParameterCollection parameters, string[] paramNames, object[] paramValues)
		{
			if (paramValues != null)
			{
				if (paramNames != null)
				{
					if (paramNames.Length != paramValues.Length)
						throw new ArgumentException("Either paramNames and paramValues values must have same" +
							" number of elements or paramNames must be null and the paramValues must contain" +
							" only SqlParameter objects!");
				}

				for (int i = 0; i < paramValues.Length; i++)
				{
					string par = null;
					if (paramNames != null)
						par = paramNames[i];
					object val = paramValues[i];
					if (val is SqlParameter)
						parameters.Add(val as SqlParameter);
					else
						parameters.Add("@" + par, val);
				}
			}
		}

		public static void FillParameters(SqlParameter[] parameters, object sourceObj, bool ignoreAssignmentError)
		{
			FillParameters(parameters, sourceObj, ignoreAssignmentError, null, null);
		}

		public static void FillParameters(SqlParameter[] parameters, object sourceObj, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			// Fill paramters into a hastable for quick access.
			Hashtable paramsHash = new Hashtable();
			for (int i = 0; i < parameters.Length; i++)
			{
				SqlParameter sqlParam = parameters[i];
				string paramName = sqlParam.ParameterName;
				// set the parameter value directly in this pass
				if (paramName == null)
					throw new Exception("Null parameter name in FillParameters!");

				paramsHash[sqlParam.ParameterName] = sqlParam;
				try
				{
					sqlParam.Value = ReflectionHelper.GetMemberValue(sourceObj, paramName.Substring(1), true);
				}
				catch(ArgumentException argex)
				{
					// ignore if the member can't be found.
					// an non-member parameter name is valid.
				}
				catch(Exception ex)
				{
					System.Diagnostics.Debug.WriteLine(ex);
					if (!ignoreAssignmentError)
						throw;
				}
			}

			/*			Optimization:  Instead of iterating on all the column-mapped members, we just directly get the member value using the parameter name.
			
			Type tobj = sourceObj.GetType();
			MemberInfo[] members = 
				ColumnMappingAttribute.FindColumnMappingMembers(
				System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field, 
				false,
				tobj);

			foreach (MemberInfo mi in members)
			{
				ColumnMappingAttribute colMap = ColumnMappingAttribute.GetFromMember(mi);
				if (colMap != null)
				{
					if ((colMap.FillFlags & DataFiller.FillFlags.ObjectToData) != 0)
					{
						SqlParameter sqlParam = (SqlParameter)paramsHash["@" + mi.Name]; // colMap.ColumnName];
						if (sqlParam != null)
						{
							try
							{
								object val = ReflectionHelper.GetMemberValue(sourceObj, mi.Name, true);
								sqlParam.Value = val;
							}
							catch(Exception ex)
							{
								System.Diagnostics.Debug.WriteLine(ex);
								if (!ignoreAssignmentError)
									throw;
							}
						}
					}
				}
			}*/

			// set extra param values 
			if (extraParamNames != null && extraParamValues != null)
			{
				for (int i = 0; i < extraParamNames.Length; i++)
				{
					SqlParameter sqlParam = (SqlParameter)paramsHash["@" + extraParamNames[i]];
					sqlParam.Value = extraParamValues[i];
				}
			}

		}

		public static void FillParameters(SqlParameter[] parameters, object[] sourceObjs, bool ignoreAssignmentError)
		{
			for (int i = 0; i < sourceObjs.Length; i++)
				FillParameters(parameters, sourceObjs[i], ignoreAssignmentError);
		}

		public static void FillParameters(SqlParameter[] parameters, object[] sourceObjs, bool ignoreAssignmentError, string[] extraParamNames, object[] extraParamValues)
		{
			for (int i = 0; i < sourceObjs.Length; i++)
				FillParameters(parameters, sourceObjs[i], ignoreAssignmentError, extraParamNames, extraParamValues);
		}

		#endregion
	}
	
}
