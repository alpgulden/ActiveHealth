using System;
using System.Data;
using System.Collections;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Manages caching of datasets etc under string key names.
	/// If the key name starts with *, it is globaly cached 
	/// in a static variable.
	/// </summary>
	public class CachingManager
	{
		static Hashtable globalCache = new Hashtable();
		private Hashtable instanceCache = new Hashtable();

		public CachingManager()
		{
		}

		protected string GetGlobalCachingKey(string cachingKey)
		{
			if (cachingKey.Length >= 1)
			{
				if (cachingKey[0] == '*')
					return cachingKey.Substring(1);	// a global caching key
			}
			return null;	// not a global caching key
		}

		public DataSet GetCachedDataSet(string cachingKey)
		{
			if (cachingKey == null)
				return null;	// always unchached
			string globalKey = GetGlobalCachingKey(cachingKey);

			if (globalKey != null)
				return globalCache[cachingKey] as DataSet;
			else
				return instanceCache[cachingKey] as DataSet;
		}

		public void SetCachedDataSet(string cachingKey, DataSet ds)
		{
			if (cachingKey == null)
				return;			// always unchached
			string globalKey = GetGlobalCachingKey(cachingKey);

			if (globalKey != null)
				globalCache[cachingKey] = ds;
			else
				instanceCache[cachingKey] = ds;
		}
	}
}
