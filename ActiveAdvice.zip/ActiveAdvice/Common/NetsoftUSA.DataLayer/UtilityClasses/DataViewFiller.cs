using System;
using System.Data;
using NetsoftUSA.DataLayer;
using System.Collections;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Fills an object to/from a DataView
	/// </summary>

	public class DataViewFiller
	{
		#region Data Accessors

		public class DataViewAccessor :DataFiller.IDataAccessor
		{
			private DataView dataView;

			public DataViewAccessor(DataView dataView)
			{
				this.dataView = dataView;
			}
		

			#region IEnumerable Members

			public IEnumerator GetEnumerator()
			{
				return dataView.GetEnumerator();
			}

			#endregion

			#region IDataAccessor Members

			public object[] GetKeys()
			{
				return NSGlobal.GetKeys(dataView);
			}

			public object Get(object[] keys)
			{
				int i = dataView.Find(keys);
				return dataView[i];
			}

			public object New()
			{
				return dataView.AddNew();
			}

			public void Update(object data)
			{
				DataRowView rv = (DataRowView)data;
				rv.EndEdit();
			}

			public void Insert(object data)
			{
				DataRowView rv = (DataRowView)data;
				rv.EndEdit();
			}

			public void Delete(object[] keys)
			{
				int i = dataView.Find(keys);
				dataView.Delete(i);
			}

			public void DeleteAll()
			{
				for (int i = dataView.Count - 1; i >= 0; i--)
				{
					dataView.Delete(i);
				}
			}

			public DataFiller.IItemAccessor GetItemAccessor(object data)
			{
				return new DataRowViewAccessor((DataRowView)data);
			}

			#endregion
		}

	
		/// <summary>
		/// Used as an item accessor on the given rowView
		/// </summary>
		public class DataRowViewAccessor :DataFiller.IItemAccessor, DataFiller.IRelationalDataProvider
		{
			private DataRowView rowView;

			public DataRowViewAccessor(DataRowView rowView)
			{
				this.rowView = rowView;
			}

			#region IItemAccessor Members

			public void SetData(object data)
			{
				rowView = (DataRowView)data;
			}

			public object GetData()
			{
				return rowView;
			}

			public void SetItem(string colName, object val)
			{
				rowView[colName] = val;
			}

			public object GetItem(string colName)
			{
				return rowView[colName];
			}

			#endregion

			#region IRelationalDataProvider Members

			public DataFiller.IDataAccessor CreateRelatedData(SimpleRelationAttribute rel, IList collection)
			{
				DataSet ds = rowView.DataView.Table.DataSet;
				object val = rowView[rel.ParentColumn];
				string filter = null;
				if (val is String || val is DateTime || val is Guid)
					filter = String.Format("[{0}]='{1}'", rel.ChildColumn, Convert.ToString(val));
				else
					filter = String.Format("[{0}]={1}", rel.ChildColumn, Convert.ToString(val));
				
				string childTableName = rel.ChildTable;
				if (childTableName == null)
				{
					ElementTypeAttribute elemTypeAttrib = ElementTypeAttribute.GetFromCollection(collection);
					if (elemTypeAttrib == null)
						throw new ArgumentException("The collection class {0} must provide an ElementType attribute!", collection.GetType().Name);
					Type elemType = elemTypeAttrib.ElemType;
					if (elemType == null)
						throw new ArgumentException("The collection class {0} must provide an element type!", collection.GetType().Name);
					TableMappingAttribute tm = TableMappingAttribute.GetFromType(elemType);
					if (tm == null)
						throw new ArgumentException("Class {0} must provide element type and the element define a TableMapping attribute!", collection.GetType().Name);
					childTableName = tm.GetTableNameForType(elemType);
				}

				DataTable childTable = ds.Tables[childTableName];
				string sort = childTable.PrimaryKey[0].ColumnName;
				DataView view = new DataView(childTable, filter, sort, DataViewRowState.CurrentRows);
				return new DataViewAccessor(view);
			}

			#endregion
		}
		#endregion

		#region Object filler functions

		/// <summary>
		/// Fills the public fields/properties of the given
		/// target object
		/// </summary>
		/// <param name="rowView"></param>
		/// <param name="TargetObject"></param>
		public static void FillIntoObject(DataRowView rowView, object targetObj, bool ignoreAssignmentError, bool collections)
		{
			DataRowViewAccessor rowViewAccessor = new DataRowViewAccessor(rowView);
			DataFiller.DataFillerParams parms = new DataFiller.DataFillerParams(targetObj, rowViewAccessor, ignoreAssignmentError, collections);
			DataFiller.FillIntoObject(parms);
		}

		public static void FillIntoObject(DataRowView rowView, object targetObj, string propOrFieldName, bool ignoreAssignmentError, bool collections)
		{
			DataRowViewAccessor rowViewAccessor = new DataRowViewAccessor(rowView);
			DataFiller.DataFillerParams parms = new DataFiller.DataFillerParams(targetObj, rowViewAccessor, ignoreAssignmentError, collections);
			DataFiller.FillIntoObject(parms, propOrFieldName);
		}

		/// <summary>
		/// Fills the rowView from given object's public fields/properties
		/// </summary>
		/// <param name="rowView"></param>
		/// <param name="SourceObject"></param>
		public static void FillFromObject(DataRowView rowView, object sourceObj, bool ignoreAssignmentError, bool collections)
		{
			DataRowViewAccessor rowViewAccessor = new DataRowViewAccessor(rowView);
			DataFiller.DataFillerParams parms = new DataFiller.DataFillerParams(sourceObj, rowViewAccessor, ignoreAssignmentError, collections);
			DataFiller.FillFromObject(parms);
		}

		public static void FillFromObject(DataRowView rowView, object sourceObj, string propOrFieldName, bool ignoreAssignmentError, bool collections)
		{
			DataRowViewAccessor rowViewAccessor = new DataRowViewAccessor(rowView);
			DataFiller.DataFillerParams parms = new DataFiller.DataFillerParams(sourceObj, rowViewAccessor, ignoreAssignmentError, collections);
			DataFiller.FillFromObject(parms, propOrFieldName);
		}

		#endregion

		#region Collection filler functions

		/// <summary>
		/// Basic function that appends the given dataView's rows
		/// into the given IList based collection.  The elements
		/// added to the collection are of the type specified 
		/// type.  The collection is not cleared first.  
		/// No duplicate checking is done.
		/// </summary>
		/// <param name="dataView"></param>
		/// <param name="collection"></param>
		/// <param name="elemType"></param>
		/// <param name="ignoreAssignmentError"></param>
		public static void AppendToCollection(DataView dataView, IList collection, Type elemType, bool ignoreAssignmentError, bool collections)
		{
			DataViewAccessor dvAccessor = new DataViewAccessor(dataView);
			DataFiller.AppendToCollection(dvAccessor, collection, elemType, ignoreAssignmentError, collections);
		}

		/// <summary>
		/// Basic function that appends the given dataView's rows
		/// into the given IList based collection.  The elements
		/// added to the collection are of the type specified 
		/// by the collection's ElementType.  The collection
		/// is not cleared first.  No duplicate checking is done.
		/// </summary>
		/// <param name="dataView"></param>
		/// <param name="collection"></param>
		/// <param name="ignoreAssignmentError"></param>
		public static void AppendToCollection(DataView dataView, IList collection, bool ignoreAssignmentError, bool collections)
		{
			DataViewAccessor dvAccessor = new DataViewAccessor(dataView);
			DataFiller.AppendToCollection(dvAccessor, collection, ignoreAssignmentError, collections);
		}

		public static void FillFromCollection(DataView dataView, IList collection, bool ignoreAssignmentError, bool collections)
		{
			DataViewAccessor dvAccessor = new DataViewAccessor(dataView);
			DataFiller.FillFromCollection(dvAccessor, collection, ignoreAssignmentError, collections);
		}

		#endregion
	}
	
}
