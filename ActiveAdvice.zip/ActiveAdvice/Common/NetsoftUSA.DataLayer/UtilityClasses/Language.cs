using System;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Collections;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Summary description for Language.
	/// </summary>
	public class Language
	{
		protected const string MemberMatchRegex = "@(?<memberName>[0-9a-zA-Z_]+)@";

		private string langID;

		public Language()
		{
			FillWithMessageIDs();
		}

		public Language(string langID)
		{
			this.langID = langID;
		}

		public string LangID
		{
			get	{	return langID;	}
		}

		// load using the attribute declarations on the language class
		protected void LoadFromTable()
		{
			LanguageTableAttribute languageTableAtt = LanguageTableAttribute.GetFromType(this.GetType());
			if (languageTableAtt != null)
			{
				LoadFromTable(languageTableAtt.TableName, languageTableAtt.MsgIDcolumn, languageTableAtt.LangIDcolumn, languageTableAtt.MessageColumn);
			}
		}

		protected void LoadFromTable(string tableName)
		{
			LoadFromTable(tableName, "MsgID", "LangID", "Message");
		}

		protected void LoadFromTable(string tableName, string MsgIDcolumn, string LangIDcolumn, string MessageColumn)
		{
			string cacheKey = "LanguageDS_" + tableName + "_" + LangIDcolumn;
			DataSet ds = NSGlobal.GetCachedObject(cacheKey) as DataSet;
			if (ds == null)
			{
				ds = SqlHelper.ExecuteDataset(
					NSGlobal.ConnectionString, CommandType.Text,
					String.Format("select * from [{0}] where [{1}]=@LangID", tableName, LangIDcolumn),
					new SqlParameter("@LangID", this.langID));
				NSGlobal.CacheObject(cacheKey, ds);
			}

			DataTable tbl = ds.Tables[0];
			if (tbl.Rows.Count == 0)
				throw new Exception("Language " + this.langID + " not found!");

			// fill all the members with the messages from table
			Type type = this.GetType();
			MemberInfo[] members = 
				type.FindMembers(System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field,
				BindingFlags.Instance | BindingFlags.Public, null, null);
			foreach (MemberInfo mi in members)
			{
				string msgID = mi.Name;
				if (msgID != "langID" && msgID != "LangID")
				{
					DataRow[] rows = tbl.Select(String.Format("[{0}]='{1}'", MsgIDcolumn, msgID));
					if (rows.Length > 0)
					{
						try
						{
							ReflectionHelper.SetMemberValue(this, msgID, rows[0][MessageColumn]);
						}
						catch
						{ // ignore
						}
					}
					/*else
						ReflectionHelper.SetMemberValue(this, msgID, null);*/
				}
			}

		}

		/// <summary>
		/// Fill all the members with message ids.
		/// </summary>
		protected void FillWithMessageIDs()
		{
			// fill all the members with the messages from table
			Type type = this.GetType();
			MemberInfo[] members = 
				type.FindMembers(System.Reflection.MemberTypes.Property | System.Reflection.MemberTypes.Field,
				BindingFlags.Instance | BindingFlags.Public, null, null);
			foreach (MemberInfo mi in members)
			{
				string msgID = mi.Name;
				try
				{
					ReflectionHelper.SetMemberValue(this, msgID, "@" + msgID + "@");
				}
				catch
				{ // ignore
				}
			}

		}

		public string TranslateSingle(string messageID)
		{
			return ReflectionHelper.GetMemberValueAsString(this, messageID);
		}

		public string Translate(string expression)
		{
			if (expression == null)
				return null;

			if (expression == "")
				return "";

			Regex regex = new Regex( MemberMatchRegex , 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			string substituted = "";
			int lastpos = 0;
			int ipos = 0;
			for (match = regex.Match(expression); match.Success; match = match.NextMatch())
			{
				// extract param name from match
				string memberName = match.Groups["memberName"].Value;
				ipos = match.Groups["memberName"].Index - 1;
				int ilen = memberName.Length;
				if (ilen > 0)
				{
					string val = null;
					try
					{
						val = ReflectionHelper.GetMemberValueAsString(this, memberName);
					}
					catch
					{
						// ignore any errors
					}

					if (val == null)
						val = "@" + memberName + "@";
					substituted += expression.Substring(lastpos, ipos - lastpos);
					substituted += val;
					
				}
				lastpos = ipos + ilen + 2;
			}
			ipos = expression.Length;
			substituted += expression.Substring(lastpos, ipos - lastpos);
			return substituted;
		}

		public string Translate(string expression, params object[] args)
		{
			if (args == null)
				return Translate(expression);
			else
				return String.Format(Translate(expression), args);
		}

		public string Translate(bool translateArgs, string expression, params object[] args)
		{
			if (!translateArgs)
				return Translate(expression, args);

			if (args != null)
			{
				// translate the arguments too
				for (int i = 0; i < args.Length; i++)
				{
					object arg = args[i];
					if (arg is string)
						args[i] = Translate((string)arg);
				}
				return String.Format(Translate(expression), args);
			}
			else
				return Translate(expression);
		}

		public void Translate(object[] tobeTranslated)
		{
			// translate the arguments too
			if (tobeTranslated == null)
				return;
			for (int i = 0; i < tobeTranslated.Length; i++)
			{
				object arg = tobeTranslated[i];
				if (arg is string)
					tobeTranslated[i] = Translate((string)arg);
			}
		}
		

	}
}
