using System;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Summary description for ExceptionWithParameters.
	/// </summary>
	public class ExceptionWithParameters : Exception
	{
		public object[] Parameters;
		public ExceptionWithParameters(string msg, Exception innerException) : base(msg, innerException)
		{
		}

		public ExceptionWithParameters(string msg) : base(msg)
		{
		}

		public ExceptionWithParameters(string msg, Exception innerException, params object[] parameters) : base(msg, innerException)
		{
			this.Parameters = parameters;
		}

		public ExceptionWithParameters(string msg, params object[] parameters) : base(msg)
		{
			this.Parameters = parameters;
		}
	}
}
