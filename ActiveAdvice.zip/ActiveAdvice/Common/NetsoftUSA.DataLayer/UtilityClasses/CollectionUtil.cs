using System;
using System.Collections;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Sorts given collections by the specied members.
	/// Copies to and from array and provides various
	/// utility functionalities to be used with collections.
	/// </summary>
	public class CollectionUtil
	{
		#region GenericMemberComparer
		// Compares specified members of objects
		class GenericMemberComparer : IComparer 
		{
			private string[] members;
			private bool ascending;
			private bool ignoreCase;

			private bool logicTrue;
			private bool logicFalse;

			public GenericMemberComparer(bool ascending, bool ignoreCase, string[] members)
			{
				this.members = members;
				this.ascending = ascending;
				this.ignoreCase = ignoreCase;

				if (ascending)
				{
					logicTrue = true;
					logicFalse = false;
				}
				else
				{	// reverse logic for descending
					logicTrue = false;
					logicFalse = true;
				}
			}

			// greater than operator is enough for all >, =, and < operators
			public bool GreaterThan(object xval, object yval)
			{
				if (ignoreCase)
					if (xval is String)
					{
						if (xval == null)
							return logicFalse;		// either equal or less, but not greater!

						if (yval == null)
							return logicTrue;		// xval not null, yval is null =>  xval is greater

						if (string.Compare((string)xval, (string)yval, true) > 0)
							return logicTrue;
						else
							return logicFalse;
					}

				IComparable comp = xval as IComparable;
				if (comp == null)
					return logicFalse;

				if (yval == null)
					return logicTrue;		// xval not null, yval is null =>  xval is greater

				if (comp.CompareTo(yval) > 0)
					return logicTrue;
				else
					return logicFalse;
			}

			public int Compare(object x, object y)
			{
				for (int i = 0; i < members.Length; i++)
				{
					string member = members[i];
					object xval = ReflectionHelper.GetMemberValue(x, member);
					object yval = ReflectionHelper.GetMemberValue(y, member);

					if (GreaterThan(xval, yval))
						return 1;		// x is greater
					if (GreaterThan(yval, xval))
						return -1;		// y is greater
				}

				// all equal
				return 0;
			}
		}

		#endregion

		public static void ArrayToCollection(System.Array array, IList collection) 
		{
			collection.Clear();
			AppendToCollection(array, collection);
		}

		public static void AppendToCollection(IList range, IList collection) 
		{
			foreach(object o in range) 
			{
				collection.Add(o);
			}
		}

		public static object[] CollectionToArray(IList collection) 
		{
			object[] array = new object[collection.Count];
			collection.CopyTo(array, 0);
			return array;
		}

		public static void SortBy(System.Array array, bool ascending, bool ignoreCase, string[] memberNames) 
		{
			Array.Sort(array, new GenericMemberComparer(ascending, ignoreCase, memberNames));
		}

		public static void SortBy(IList collection, bool ascending, bool ignoreCase, string[] memberNames) 
		{
			object[] array = CollectionToArray(collection);
			SortBy(array, ascending, ignoreCase, memberNames);
			ArrayToCollection(array, collection);
		}

		/// <summary>
		/// For each element of the given collection, set the given values to the given members.
		/// </summary>
		/// <param name="collection"></param>
		/// <param name="memberNames"></param>
		/// <param name="values"></param>
		public static void SetCollectionMembers(IList collection, string[] memberNames, object[] values)
		{
			foreach (object item in collection)
			{
				if (item != null)
				{
					ReflectionHelper.SetMemberValues(item, memberNames, values);
				}
			}
		}

		/// <summary>
		/// For each element of the given collection enumerate starting from 'start' set
		/// the enumeration to given member and increment by 'step'.
		/// </summary>
		/// <param name="collection"></param>
		/// <param name="memberName"></param>
		/// <param name="start"></param>
		/// <param name="step"></param>
		public static void EnumerateCollectionMember(IList collection, string memberName, int start, int step)
		{
			foreach (object item in collection)
			{
				if (item != null)
				{
					ReflectionHelper.SetMemberValue(item, memberName, start);
					start += step;
				}
			}
		}

		public static void AddArrayToList(Array arr, ArrayList list)
		{
			for (int i = 0; i < arr.Length; i++)
				list.Add(arr.GetValue(i));
		}

		public static object[] JoinArrays(Array arr1, Array arr2)
		{
			ArrayList list = new ArrayList();
			AddArrayToList(arr1, list);
			AddArrayToList(arr2, list);
			return (object[])list.ToArray();
		}

		public static string[] JoinArrays(string[] arr1, string[] arr2)
		{
			ArrayList list = new ArrayList();
			AddArrayToList(arr1, list);
			AddArrayToList(arr2, list);
			return (string[])list.ToArray(typeof(string));
		}

	}
}
