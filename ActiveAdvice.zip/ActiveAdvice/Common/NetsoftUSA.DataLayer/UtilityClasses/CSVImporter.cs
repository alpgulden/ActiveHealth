using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.IO;

namespace NetsoftUSA.DataLayer
{
	public class LineSkippedEventArgs : ImportEventArgs
	{
		public string line;

		public LineSkippedEventArgs(int lineNum, string line)
			: base(lineNum)
		{
			this.line = line;
		}
	}
	/// <summary>
	/// Imports a given CSV text file into a target table.
	/// </summary>
	public class CSVImporter : SingleTableImporter
	{
		#region Events

		public delegate void LineSkippedEventHandler(object sender, LineSkippedEventArgs e);
		public event CSVImporter.LineSkippedEventHandler LineSkipped;

		#endregion

		#region Private members

		private char seperator = ',';
		protected int linesToSkip = 0;			// lines to skip from top

		#endregion

		#region Constructors

		public CSVImporter() : base()
		{
		}

		#endregion

		#region Virtual functions
		
		protected virtual bool OnLineSkipped(int lineNum, string line)
		{
			if (LineSkipped != null)
			{
				LineSkippedEventArgs e = new LineSkippedEventArgs(lineNum, line);
				LineSkipped(this, e);
				if (e.cancelAll)
					throw new ImportCancelAllException("Import cancelled at line " + lineNum);
				return !e.cancelDefault;
			}
			else
				return true;
		}

		#endregion

		#region Overridden functions

		public override void ParseRowValues(string text, string[] valueStrings)
		{
			// base ParseRowValuesCSV
			base.ParseRowValuesCSV(text, valueStrings, seperator);
		}


		public override void Import(Stream stream)
		{
			if (!InitializeImport())
				return;		// cancelled
			//connection.Open();
			// command variable is now ready.

			StreamReader stm = new StreamReader(stream);
			string line;
			int lineNum = 0;
			string[] valueStrings = new string[targetColumns.Length];
			while ((line = stm.ReadLine()) != null)
			{
				lineNum++;

				if (lineNum - 1 < linesToSkip)
				{
					if (OnLineSkipped(lineNum, line))
						continue;	// if returned false, skip is cancelled!
				}

				try
				{
					ParseRowValues(line, valueStrings);
					if (OnBeforeInsert(lineNum, valueStrings))
					{
						FillColumnValuesIntoParameters(targetColumns, valueStrings, schemaTable, command.Parameters);
						if (OnRowInsert(lineNum, valueStrings, command))
							command.ExecuteNonQuery();
					}
				}
				catch(ImportCancelAllException)
				{
					break;
				}
				catch(Exception ex) 
				{
					// don't throw but allow logging!
					OnRowInsertError(lineNum, ex);
				}
			}
		}

		#endregion

		#region Public members

		/// <summary>
		/// What seperator to use when parsing a line of data.  The default is ','.
		/// </summary>
		public char Seperator
		{
			get { return seperator; }
			set { seperator = value; }
		}

		/// <summary>
		/// How many lines to skip from top
		/// </summary>
		public int LinesToSkip
		{
			get { return linesToSkip; }
			set
			{
				linesToSkip = value; 
				if (linesToSkip < 0)
					linesToSkip = -linesToSkip;
			}
		}

		#endregion

		#region Public static utility functions
		
		/// <summary>
		/// Parsing a char-delimited text
		/// </summary>
		/// <param name="text"></param>
		/// <param name="valueStrings"></param>
		/// <param name="seperator"></param>
		public static new void ParseRowValuesCSV(string text, string[] valueStrings, char seperator)
		{
			string errMsg = "Invalid number of column values!  There must be " + valueStrings.Length + " columns!";
			// the most simplistic parsing would be:	text.Split(seperator);
			// but we must also consider quoted strings and seperator chars may be included in them
			int i;
			for (i = 0; i < valueStrings.Length; i++)
			{
				valueStrings[i] = null;
			}
			i = 0;
			string quot = "\"";
			string sep = seperator.ToString();
			text = sep + text;		// makes parsing easier (search for ,* or ,"*" pattern)
			if (sep == "|")
				sep = "\\x7C";
			Regex regex = new Regex(
				sep + @"\s*" + quot + @"(?<valueQuot>[^" + sep + "\n\r]*)" + quot +
				"|" + sep + @"\s*(?<value>[^" + sep + "\n\r]*)"		//[0-9/.]
				, RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			string sval;
			for (match = regex.Match(text); match.Success; match = match.NextMatch())
			{
				if (i > valueStrings.Length)
					throw new ArgumentException(errMsg);
				// extract param name from match
				sval = match.Groups["valueQuot"].Value;
				if (sval != "")
					valueStrings[i] = sval;
				else
					valueStrings[i] = match.Groups["value"].Value;
				
				i++;
			}
			//if (i < valueStrings.Length)
			//	throw new ArgumentException(errMsg);
		}

		#endregion
	}
}
