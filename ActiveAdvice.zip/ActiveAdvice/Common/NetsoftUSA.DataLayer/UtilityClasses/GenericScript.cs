using System;
using Microsoft.JScript.Vsa;
using Microsoft.JScript;
using System.Diagnostics;
using System.Collections;
using System.Collections.Specialized;
using System.Reflection;
using System.Text.RegularExpressions;

namespace NetsoftUSA.DataLayer
{
	#region GenericScript
	/// <summary>
	/// Summary description for GenericScript.
	/// </summary>
	public abstract class GenericScript
	{
		protected const string MemberMatchRegex = "@(?<memberName>[0-9a-zA-Z_]+)@";

		private VsaEngine engine;
		protected object dataObject;		// data object whose members are accessed 
		protected Type type;

		public GenericScript(Type type, object dataObject)
		{
			this.dataObject = dataObject;
			if (type == null)
				this.type = dataObject.GetType();
			else
				this.type = type;
		}

		// create engine on demand
		public VsaEngine Engine
		{
			get
			{
				if (engine == null)
					engine = VsaEngine.CreateEngine();
				return engine;
			}
		}

		// these two must be overridden by the derived classes
		// to provide proper script generation.
		public abstract string MakeScriptForGet(string memberName);
		public abstract string MakeScriptForSet(string memberName);

		protected string SubstituteMacros(string expression)
		{
			if (expression == null)
				return "";

			Regex regex = new Regex( MemberMatchRegex , 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			string substituted = "";
			int lastpos = 0;
			int ipos = 0;
			for (match = regex.Match(expression); match.Success; match = match.NextMatch())
			{
				// extract param name from match
				string memberName = match.Groups["memberName"].Value;
				ipos = match.Groups["memberName"].Index - 1;
				int ilen = memberName.Length;
				if (ilen > 0)
				{
					string val = MakeScriptForGet(memberName);
					substituted += expression.Substring(lastpos, ipos - lastpos);
					substituted += val;
				}
				lastpos = ipos + ilen + 2;
			}
			ipos = expression.Length;
			substituted += expression.Substring(lastpos, ipos - lastpos);
			return substituted;
		}

		public Hashtable ExtractDependencies(string expression)
		{
			Hashtable dep = new Hashtable();
			if (expression == null)
				return dep;

			Regex regex = new Regex( MemberMatchRegex , 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			for (match = regex.Match(expression); match.Success; match = match.NextMatch())
			{
				string fieldName = match.Groups["memberName"].Value;
				dep[fieldName] = fieldName;
			}

			return dep;
		}

		public Hashtable ExtractDependenciesForMemberScript(MemberInfo mi)
		{
			GenericScriptAttribute genScrAtt = GenericScriptAttribute.GetFromMember(mi);
			if (genScrAtt == null || genScrAtt.JScript == null)
				throw new ArgumentException(String.Format("Member {0}.{1} has no generic script declared", mi.DeclaringType.Name, mi.Name));
		
			return ExtractDependencies(genScrAtt.JScript);
		}

		public Hashtable ExtractDependenciesForMemberScript(string memberName)
		{
			return ExtractDependenciesForMemberScript(ReflectionHelper.GetFieldOrProp(type, memberName));
		}

		protected void GetScriptedMembersInDependecyOrder(StringCollection members, MemberInfo mi)
		{
			string memberName = mi.Name;
			try
			{
				// add dependency calculators / items first
				Hashtable deps = ExtractDependenciesForMemberScript(mi);
				foreach (DictionaryEntry item in deps)
				{
					string depName = (string)item.Key;
					if (depName != memberName)
						GetScriptedMembersInDependecyOrder(members, ReflectionHelper.GetFieldOrProp(type, depName));
				}

				// then add this member
				if (!members.Contains(memberName))
				{
					members.Add(memberName);
				}
			}
			catch
			{
			}
		}

		protected void GetScriptedMembersInDependecyOrder(StringCollection members)
		{
			System.Reflection.MemberInfo[] mis = type.GetMembers(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			/*FindMembers(
				MemberTypes.Field | MemberTypes.Property,
				BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance,
				null, null);*/

			for (int i = 0; i < mis.Length; i++)
			{
				MemberInfo mi = mis[i];
				GetScriptedMembersInDependecyOrder(members, mi);
			}
		}

		/// <summary>
		/// Get the scripted members for this class in dependency order. 
		/// This will give the actual client side calculation order.
		/// </summary>
		/// <returns></returns>
		public StringCollection GetScriptedMembersInDependecyOrder()
		{
			StringCollection members = new StringCollection();
			GetScriptedMembersInDependecyOrder(members);
			return members;
		}

	}

	#endregion

	#region CalculateExpression

	public class ServerSideCalculationScript : GenericScript
	{
		public ServerSideCalculationScript(Type type, object dataObject)
			: base (type, dataObject)
		{
		}

		public override string MakeScriptForGet(string memberName)
		{
			object val = ReflectionHelper.GetMemberValue(this.dataObject, memberName, true);

			if (val == null || val == DBNull.Value)
				return "null";

			string s = val as string;
			if (s != null)
			{
				s = s.Replace("\"", "\\\"");	// '"' -> '\"'
				return "\"" + s + "\"";
			}

			return System.Convert.ToString(val);
		}

		public override string MakeScriptForSet(string memberName)
		{
			return null;
		}

		public object Calculate(string expression)
		{
			string substituted = SubstituteMacros(expression);
			object result = Eval.JScriptEvaluate(substituted, this.Engine);
			return result;
		}

		public bool EvaluateBoolExpression(string expression)
		{
			return System.Convert.ToBoolean(Calculate(expression));
		}

		public object CalculateMemberScript(MemberInfo mi)
		{
			GenericScriptAttribute genScrAtt = GenericScriptAttribute.GetFromMember(mi);
			if (genScrAtt == null || genScrAtt.JScript == null)
				throw new ArgumentException(String.Format("Member {0}.{1} has no generic script declared", mi.DeclaringType.Name, mi.Name));
		
			return Calculate(genScrAtt.JScript);
		}

		public bool EvaluateBoolMemberScript(MemberInfo mi)
		{
			return System.Convert.ToBoolean(CalculateMemberScript(mi));
		}

		public object CalculateMemberScript(string memberName)
		{
			return CalculateMemberScript(ReflectionHelper.GetFieldOrProp(type, memberName));
		}

		public bool EvaluateBoolMemberScript(string memberName)
		{
			return System.Convert.ToBoolean(CalculateMemberScript(memberName));
		}


	}

	#endregion

}
