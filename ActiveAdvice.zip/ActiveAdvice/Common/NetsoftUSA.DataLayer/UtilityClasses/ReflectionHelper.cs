using System;
using System.Reflection;
using System.Collections;

namespace NetsoftUSA.DataLayer
{
	/// <summary>
	/// Helper functions to be used for reflection
	/// </summary>
	public class ReflectionHelper
	{

		public static MemberInfo GetMember(Type type, string memberName, MemberTypes memberTypes, BindingFlags bindingFlags)
		{
			MemberInfo[] members = type.GetMember(memberName, 
				memberTypes, 
				bindingFlags);
			if (members != null)
				if (members.Length > 0)
					return members[0];

			throw new ArgumentException(String.Format("Class member {0} not found in {1}", memberName, type.Name));
		}

		public static MemberInfo GetFieldOrProp(Type type, string memberName, BindingFlags bindingFlags)
		{
			return GetMember(type, memberName, 
				MemberTypes.Field | MemberTypes.Property, 
				bindingFlags);
		}

		public static MemberInfo GetFieldOrProp(Type type, string memberName)
		{
			return GetFieldOrProp(type, memberName,
				BindingFlags.Public | BindingFlags.NonPublic |
				BindingFlags.Instance);
		}

		public static object[] GetKeyValues(IList collection)
		{
			Type type = collection.GetType();
			ElementTypeAttribute elemTypeAttrib = ElementTypeAttribute.GetFromType(type);
			if (elemTypeAttrib == null)
				throw new ArgumentException ("An ElementTypeAttribute must be specified!");

			Type elemType = elemTypeAttrib.ElemType;

			TableMappingAttribute tblMap = TableMappingAttribute.GetFromType(elemType);

			if (tblMap == null)
			{
				// No TableMapping declared on the data class!
				// Will support this later!
				throw new ArgumentException (String.Format("Class {0} must specify a PK member using TableMapping attribute", elemType.ToString()) );
			}

			return NSGlobal.GetFieldValuesFromCollection(collection, elemType, tblMap.PKMemberName);
		}

		public static System.Reflection.MemberInfo FindPropOrFieldByName(Type tobj, string propOrFieldName)
		{
			FieldInfo fi = tobj.GetField(propOrFieldName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (fi != null)
				return fi;

			PropertyInfo pi = tobj.GetProperty(propOrFieldName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (pi != null)
				return pi;

			return null;
		}

		public static IList GetIListMember(MemberInfo mi, object obj)
		{
			FieldInfo fi = mi as FieldInfo;
			if (fi != null)
				return fi.GetValue(obj) as IList;

			PropertyInfo pi = mi as PropertyInfo;
			if (pi != null)
				return pi.GetValue(obj, null) as IList;

			return null;
		}

		public static Type GetMemberType(Object obj, string memberName)
		{
			return GetMemberType(obj.GetType(), memberName);
		}

		public static Type GetMemberType(Type type, string memberName)
		{
			FieldInfo fi = type.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (fi != null)
				return fi.FieldType;

			PropertyInfo pi = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (pi != null)
				return pi.PropertyType;

			throw new ArgumentException(String.Format("{0} doesn't support property or field {1}", type.Name, memberName));
		}

		public static object GetMemberValue(object obj, string memberName, Type asType)
		{
			return Convert.ChangeType(GetMemberValue(obj, memberName), asType);
		}

		public static bool HasMember(Type type, string memberName)
		{
			FieldInfo fi = type.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (fi != null)
				return true;

			PropertyInfo pi = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			if (pi != null)
				return true;

			return false;
		}

		public static bool HasMember(object obj, string memberName)
		{
			return HasMember(obj.GetType(), memberName);
		}

		public static object GetMemberValue(object obj, string memberName)
		{
			Type type = obj.GetType();
			FieldInfo fi = type.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			try
			{
				if (fi != null)
					return fi.GetValue(obj);

				PropertyInfo pi = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
				if (pi != null)
					return pi.GetValue(obj, null);
			}
			catch(System.Reflection.TargetInvocationException invocationEx)
			{
				throw invocationEx.InnerException;
			}
			catch(Exception ex)
			{
				throw ex;//.InnerException;
			}

			throw new ArgumentException(String.Format("{0} doesn't support property or field {1}", type.Name, memberName));
		}

		/// <summary>
		/// Get the member value for the given propery path.
		/// You can use "Address.Zip" type of path in the memberPath.
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="memberPath"></param>
		/// <returns></returns>
		public static object GetMemberValueFromPath(object obj, string memberPath, bool useValueForNull)
		{
			int dotIndex = memberPath.IndexOf('.');
			if (dotIndex < 0)
				return GetMemberValue(obj, memberPath, useValueForNull);		// direct member name

			// . found.  A member name with path
			string prop = memberPath.Substring(0, dotIndex);
			string subProp = memberPath.Substring(dotIndex + 1);
			object subObj = GetMemberValue(obj, prop);
			return GetMemberValueFromPath(subObj, subProp);	// recurse into the rest of the path using the subObj
		}

		public static object GetMemberValueFromPath(object obj, string memberPath)
		{
			return GetMemberValueFromPath(obj, memberPath, false);
		}

		public static object HasMemberForPath(Type type, string memberPath)
		{
			int dotIndex = memberPath.IndexOf('.');
			if (dotIndex < 0)
				return HasMember(type, memberPath);	// direct access to member

			// . found.  A member name with path
			string prop = memberPath.Substring(0, dotIndex);
			string subProp = memberPath.Substring(dotIndex + 1);

			PropertyInfo pi = type.GetProperty(prop);
			if (pi != null)
				return HasMemberForPath(pi.PropertyType, subProp);	// recurse into the rest of the path using the sub type

			FieldInfo fi = type.GetField(prop);
			if (fi != null)
				return HasMemberForPath(fi.FieldType, subProp);	// recurse into the rest of the path using the sub type

			// neither property nor field found!
			return false;
		}

		public static object MemberToDBValue(MemberInfo mi, object value)
		{
			object val = value;

			ColumnMappingAttribute colAtt = ColumnMappingAttribute.GetFromMember(mi);
			if (colAtt == null)
				return val;
			else
			{
				if (colAtt.ValueForNull == null)
				{
					if (val == null)
						return DBNull.Value;
					else
						return val;
				}
				if (colAtt.ValueForNull.Equals(val))
					return DBNull.Value;
				else
					return val;
			}
		}

		public static object MemberToDBValue(Type type, string memberName, object value)
		{
			FieldInfo fi = type.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			MemberInfo mi = fi;
			if (fi == null)
			{
				PropertyInfo pi = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
				if (pi != null)
					mi = pi;
				else
					throw new ArgumentException(String.Format("{0} doesn't support property or field {1}", type.Name, memberName));
			}

			return MemberToDBValue(mi, value);
		}

		public static object[] GetMemberValues(object obj, string[] memberNames)
		{
			return GetMemberValues(obj, memberNames, false);
		}

		public static object[] GetMemberValues(object obj, string[] memberNames, bool useValueForNull)
		{
			object[] vals = new object[memberNames.Length];
			for (int i = 0; i < memberNames.Length; i++)
			{
				vals[i] = GetMemberValue(obj, memberNames[i], useValueForNull);
			}
			return vals;
		}

		public static object GetMemberValue(object obj, string memberName, bool useValueForNull)
		{
			Type type = obj.GetType();
			FieldInfo fi = type.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			//MemberInfo[] members = type.GetMember(memberName, MemberTypes.Field | MemberTypes.Property, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			//MemberInfo memi = members[0];
			//FieldInfo fi = memi as FieldInfo;
			MemberInfo mi = fi;
			object val = null;
			try
			{
				if (fi != null)
				{
					val = fi.GetValue(obj);;
				}
				else
				{
					PropertyInfo pi = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
					if (pi != null)
					{
						mi = pi;
						val = pi.GetValue(obj, null);
					}
					else
						throw new ArgumentException(String.Format("{0} doesn't support property or field {1}", type.Name, memberName));
				}

				if (useValueForNull)
				{
					ColumnMappingAttribute colAtt = ColumnMappingAttribute.GetFromMember(mi);
					object valueForNull = null;
					if (colAtt != null)
						valueForNull = colAtt.ValueForNull;
					/*else		// assume null is always DBNull
					{*/
					if (valueForNull == null) //colAtt.ValueForNull == null)
					{
						if (val == null)
							return DBNull.Value;
						else
							return val;
					}
					if (valueForNull.Equals(val)) // colAtt.ValueForNull.Equals(val))
						return DBNull.Value;
					else
						return val;
					//}
				}
			}
			catch(System.Reflection.TargetInvocationException invocationEx)
			{
				throw invocationEx.InnerException;
			}
			catch(Exception ex)
			{
				throw ex;//.InnerException;
			}

			return val;	
		}

		public static void SetMemberValue(object obj, string memberName, object value)
		{
			Type type = obj.GetType();
			FieldInfo fi = type.GetField(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
			try
			{
				if (fi != null)
				{
					if (value == null || value is DBNull)
					{
						ColumnMappingAttribute colAtt = ColumnMappingAttribute.GetFromMember(fi);
						if (colAtt == null)
							fi.SetValue(obj, DCBase.GetNullValueForType(fi.FieldType));
						else
							fi.SetValue(obj, colAtt.ValueForNull);
						return;
					}

					object val = Convert.ChangeType(value, fi.FieldType);
					fi.SetValue(obj, val);
					return;
				}

				PropertyInfo pi = type.GetProperty(memberName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
				if (pi != null)
				{
					if (value == null || value is DBNull)
					{
						ColumnMappingAttribute colAtt = ColumnMappingAttribute.GetFromMember(pi);
						if (colAtt == null)
							pi.SetValue(obj, DCBase.GetNullValueForType(pi.PropertyType), null);
						else
							pi.SetValue(obj, colAtt.ValueForNull, null);
						return;
					}

					object val = Convert.ChangeType(value, pi.PropertyType);
					pi.SetValue(obj, val, null);
					return;
				}
			}
			catch(System.Reflection.TargetInvocationException invocationEx)
			{
				throw invocationEx.InnerException;
			}
			catch(Exception ex)
			{
				throw ex;//.InnerException;
			}

			throw new ArgumentException(String.Format("{0} doesn't support property or field {1}", type.Name, memberName));
		}

		/// <summary>
		/// Set the given values to the given members.
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="memberNames"></param>
		/// <param name="values"></param>
		public static void SetMemberValues(object obj, string[] memberNames, object[] values)
		{
			for (int i = 0; i < memberNames.Length; i++)
			{
				SetMemberValue(obj, memberNames[i], values[i]);
			}
		}

		public static string InvokeFormatterFunction(object obj, MethodInfo method, object value, bool withValue)
		{
			try
			{
				object o = method.Invoke(obj, new object[] { value, withValue } );
				if (o == null)
					return "";
				else
					return Convert.ToString(o);
			}
			catch(System.Reflection.TargetInvocationException invocationEx)
			{
				throw invocationEx.InnerException;
			}
			catch(Exception ex)
			{
				throw ex;//.InnerException;
			}
		}

		public static void SetMemberValueFromString(object obj, string memberName, string s)
		{
			if (s == null || s == "")
				SetMemberValue(obj, memberName, null);
			else
				SetMemberValue(obj, memberName, s);
		}

		public static string GetMemberValueAsString(object obj, string memberName)
		{
			object val = GetMemberValue(obj, memberName, true);
			if (val is DBNull)
				return null;
			else
				return Convert.ToString(val);
		}

		public static string GetPageNameFromClass(Type pageClass)
		{
			string name = pageClass.Name;
			if (name.Length >= 5)
				if (name.Substring(name.Length - 5) == "_aspx")
					name = name.Substring(0, name.Length - 5);
			return name + ".aspx";
		}

		public static System.Reflection.MemberInfo[] FindMethodsForAttrib(Type type, Type attrib)
		{
			System.Reflection.MemberInfo[] members = type.FindMembers(
				System.Reflection.MemberTypes.Method,
				System.Reflection.BindingFlags.Public 
				| System.Reflection.BindingFlags.NonPublic 
				| System.Reflection.BindingFlags.Instance 
				/*| System.Reflection.BindingFlags.FlattenHierarchy*/,
				new MemberFilter(FilterFindMethodsForAttrib), attrib);

			return members;
		}

		private static bool FilterFindMethodsForAttrib(MemberInfo objMemberInfo, Object objSearch)
		{
			/*if (objMemberInfo.Name.Length < 7)
				return false;
			if (objMemberInfo.Name.Substring(0, 7) != "Format_")
				return false;*/
			object[] attribs = objMemberInfo.GetCustomAttributes((Type)objSearch, true);

			if (attribs != null)
				if (attribs.Length > 0)
					return true;

			return false;
		}

	}
}
