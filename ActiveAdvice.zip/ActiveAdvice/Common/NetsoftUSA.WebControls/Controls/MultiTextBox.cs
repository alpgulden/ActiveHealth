using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Collections;

namespace NetsoftUSA.WebControls
{
	/// <summary>
	/// Summary description for MultiTextBox.
	/// </summary>
	
	public enum EnumMultiTextBoxType
	{
		Custom = 0,
		USTelephone = 1,
		USDate = 2,
		USDateCombo = 3,		// date with combos
		USStateAbbr = 4,		// state selection combo with state abbreviations
		USState = 5,			// state selection combo with state names
		Time12 = 6,
		Time24 = 7,
		TimeCombo24 = 8,
		TimeCombo12 = 9
	}

	/*public class DropDownFillEventArgs : EventArgs
	{
		public bool handled = false;
		public DropDownList ddControl = null;
		public DropDownFillEventArgs(DropDownList ddControl)
		{
			this.ddControl = ddControl;
		}
	}*/

	[DefaultProperty("Text"),
	ToolboxData("<{0}:MultiTextBox runat=server></{0}:MultiTextBox>"),
	Designer(typeof(NetsoftUSA.WebControls.MultiTextBoxDesigner))]
	[ValidationPropertyAttribute("Text")]
	public class MultiTextBox : System.Web.UI.WebControls.WebControl, INamingContainer
	{
		//public delegate void DropDownFillHandler(object sender, DropDownFillEventArgs e);
		//public event DropDownFillHandler DropDownFill;

		private static readonly string[,] StatesArray = { { "AK", "Alaska" },
												{ "AL", "Alabama" },
												{ "AR", "Arkansas" },
												{ "AZ", "Arizona" },
												{ "CA", "California" },
												{ "CO", "Colorado" },
												{ "CT", "Connecticut" },
												{ "DC", "District of Columbia" },
												{ "DE", "Delaware" },
												{ "FL", "Florida" },
												{ "GA", "Georgia" },
												{ "GU", "Guam" },
												{ "HI", "Hawaii" },
												{ "IA", "Iowa" },
												{ "ID", "Idaho" },
												{ "IL", "Illinois" },
												{ "IN", "Indiana" },
												{ "KS", "Kansas" },
												{ "KY", "Kentucky" },
												{ "LA", "Louisiana" },
												{ "MA", "Massachusetts" },
												{ "MD", "Maryland" },
												{ "ME", "Maine" },
												{ "MI", "Michigan" },
												{ "MN", "Minnesota" },
												{ "MO", "Missouri" },
												{ "MS", "Mississippi" },
												{ "MT", "Montana" },
												{ "NC", "North Carolina" },
												{ "ND", "North Dakota" },
												{ "NE", "Nebraska" },
												{ "NH", "New Hampshire" },
												{ "NJ", "New Jersey" },
												{ "NM", "New Mexico" },
												{ "NV", "Nevada" },
												{ "NY", "New York" },
												{ "OH", "Ohio" },
												{ "OK", "Oklahoma" },
												{ "OR", "Oregon" },
												{ "PA", "Pennsylvania" },
												{ "RI", "Rhode Island" },
												{ "SC", "South Carolina" },
												{ "SD", "South Dakota" },
												{ "TN", "Tennessee" },
												{ "TX", "Texas" },
												{ "UT", "Utah" },
												{ "VA", "Virginia" },
												{ "VT", "Vermont" },
												{ "WA", "Washington" },
												{ "WI", "Wisconsin" },
												{ "WV", "West Virginia" },
												{ "WY", "Wyoming" }
											  };

		private static readonly string[,] MonthsArray = { { "1", "Jan", "January" },
												{ "2", "Feb", "February" },
												{ "3", "Mar", "March" },
												{ "4", "Apr", "April" },
												{ "5", "May", "May" },
												{ "6", "Jun", "June" },
												{ "7", "Jul", "July" },
												{ "8", "Aug", "August" },
												{ "9", "Sep", "September" },
												{ "10", "Oct", "October" },
												{ "11", "Nov", "November" },
												{ "12", "Dec", "December" }
											};

			// How the data passed to this control will be parsed out
			private string parseRegEx = null;		// e.g.:   (?<month>[0-9]{1,2})/(?<day>[0-9]{1,2})/(?<year>[0-9]{2,4})
		// How the data items in this control will be used to format the output string
		private string formatExp = null;		// e.g.:   @month@/@day@/@year@
		// How the data will be displayed in controls.  Each sub-field's control type can be specifed seperatelly
		private string displayExp = null;		// e.g.:   @month:TextBox@<b>/</b>@day:TextBox@/@year:TextBox@

		private string formattingArg = null;	// used in the client side

		protected Hashtable inputCtls;		// used to store input controls
		protected ArrayList inputs;
		protected TextBox txtOutput;			// the textbox to which the output will be written as formatted and validated
		private string outputTextBox = null;
		
		private EnumMultiTextBoxType multiTextBoxType = EnumMultiTextBoxType.USDate;

		private bool readOnly = false;

		public MultiTextBox() : base()
		{
			MultiTextBoxType = EnumMultiTextBoxType.USDate;
		}

		/*protected virtual bool OnDropDownFill(DropDownList ddControl)
		{
			if (DropDownFill != null)
			{
				DropDownFillEventArgs evArgs = new DropDownFillEventArgs(ddControl);
				DropDownFill(this, evArgs);
				return evArgs.handled;
			}
			return false;
		}*/

		private void ParseSubfieldAndControlType(string item, out string subField, out string ctlType, out string size, out string combovalues)
		{
			string[] terms = item.Split(':');
			ctlType = "TextBox";
			size = null;
			combovalues = null;
			if (terms.Length == 1)
				subField = terms[0];
			else
			{
				subField = terms[0];
				if (terms[1].Length > 0)
					ctlType = terms[1];
				if (terms.Length > 2)
					size = terms[2];
				if (terms.Length > 3)
					combovalues = terms[3];
			}
		}

		private WebControl CreateSubfieldControl(ControlCollection controls, string subField, string ctlType, string size, string combovalues)
		{
			WebControl ctl = null;
			switch (ctlType)
			{
				case "TextBox":
				{
					TextBox tb = new TextBox();
					if (size != null)
					{
						tb.MaxLength =  int.Parse(size);
						if (tb.MaxLength > 0)
							tb.Width = tb.MaxLength * 16; // Unit.Parse(width);
					}
					ctl = tb;
					break;
				}
				case "DropDownList":
					ctl = new DropDownList();
					break;
				case "LinkButton":
					ctl = new LinkButton();
					break;
				case "HyperLink":
					ctl = new HyperLink();
					break;
				default:
					ctl = new TextBox();
					break;
			}
			if (ctl != null)
			{
				ctl.ID = subField;
				inputCtls[subField] = ctl;
				controls.Add(ctl);
				if (combovalues != null)
					ctl.Attributes["combo"] = combovalues;
			}
			//ctl.EnableViewState = false;
			return ctl;
		}

		protected void SetControlValue(WebControl ctl, string sval)
		{
			TextBox tb = ctl as TextBox;
			if (tb != null)
			{
				tb.Text = sval;
				return;
			}

			DropDownList dd = ctl as DropDownList;
			if (dd != null)
			{
				dd.SelectedValue = sval;
				return;
			}

			LinkButton lb = ctl as LinkButton;
			if (lb != null)
			{
				lb.Text = sval;
				return;
			}

			HyperLink hl = ctl as HyperLink;
			if (hl != null)
			{
				hl.Text = sval;
				return;
			}
		}

		protected string GetControlValue(WebControl ctl)
		{
			TextBox tb = ctl as TextBox;
			if (tb != null)
				return tb.Text;

			DropDownList dd = ctl as DropDownList;
			if (dd != null)
				return dd.SelectedValue;

			LinkButton lb = ctl as LinkButton;
			if (lb != null)
				return lb.Text;

			HyperLink hl = ctl as HyperLink;
			if (hl != null)
				return hl.Text;

			return null;
		}

		private Literal CreateStaticControl(ControlCollection controls, string staticContent)
		{
			Literal lit = new Literal();
			lit.Text = staticContent;
			//lit.EnableViewState = false;
			controls.Add(lit);
			return lit;
		}

		/// <summary>
		/// Called by the designer to reuse the html output for the control.
		/// </summary>
		/// <param name="controls"></param>
		internal void CreateChildControls(ControlCollection controls)
		{
			inputCtls = new Hashtable();

			int j = 0;
			try
			{
				/*if (displayExp == null)
					CreateStaticControl(controls, "[" + null + "]");
				else
					CreateStaticControl(controls, "[" + displayExp + "]");*/
				j = 109;
				string[] parsed = Util.ExtractSubstitutablesAndStatics(displayExp);
				j = 110;
				inputs = new ArrayList();
				for (int i = 0; i < parsed.Length; i++)
				{
					string item = parsed[i];
					if (item != null)
					{
						j = 112;
						WebControl ctl = null;
						if (item.Length >= 1)
						{
							if (item[0] == '@' && item[item.Length - 1] == '@')
							{
								j = 113;
								// This is a named item. Used it as a sub-field entry
								item = item.Trim('@');
								string subField, ctlType, width, combovalues;
								ParseSubfieldAndControlType(item, out subField, out ctlType, out width, out combovalues);
								j = 114;
								ctl = CreateSubfieldControl(controls, subField, ctlType, width, combovalues);
								inputs.Add(ctl);
							}
						}
				
						if (ctl == null)
						{
							// create literal controls for the static items to be displayed
							j = 115;
							Literal staticCtl = CreateStaticControl(controls, item);
							j = 120;
						}
					}
				}

				//txtOutput = new TextBox();
				j = 121;
				try
				{
					if (outputTextBox != null)
						if (this.Parent != null)
							txtOutput = this.Parent.FindControl(outputTextBox) as TextBox;
				}
				catch
				{
				}

				j = 122;
				//txtOutput.ID = this.ID; //;"Output";
				//this.Controls.Add(txtOutput);

				Hashtable ctlNames = new Hashtable();
				j = 123;
				for (int i = 0; i < inputs.Count; i++)
					ctlNames[((WebControl)inputs[i]).ID] = "@" + ((WebControl)inputs[i]).ClientID + "@";
				formattingArg = Util.SubstituteByHashtable(this.formatExp, ctlNames);

				/*for (int i = 0; i < inputs.Count; i++)
				{
					TextBox tb = inputs[i] as TextBox;
					if (tb != null)
					{
						if (i < inputs.Count - 1)
						{
							string nextCtlID = ((WebControl)inputs[i + 1]).ClientID;
							tb.Attributes["onkeypress"] = "if (this.value.length>=this.maxLength) " + nextCtlID + ".focus();";
						}

						if (txtOutput != null)
							tb.Attributes["onpropertychange"] = "GetElem('" + txtOutput.ClientID + "').value=FormatMTB('" + formattingArg + "')";
						//else
						//{
						//	tb.Attributes["onblur"] = txtOutput.ClientID + ".value=" + 
						//}
					}
					else
					{
						WebControl ctl = inputs[i] as WebControl;
						if (txtOutput != null && ctl != null)
							if (!(ctl is HyperLink) && !(ctl is LinkButton))
								ctl.Attributes["onpropertychange"] = "GetElem('" + txtOutput.ClientID + "').value=FormatMTB('" + formattingArg + "')";
					}
				}*/
			}
			catch(Exception ex)
			{
				Label l = new Label();
				l.Text = j.ToString() + " - " + ex.Message;
				controls.Add(l);
			}

			//if (!Page.IsPostBack)
			if (this.Site != null && this.Site.DesignMode)
			{
				PrepareControlsContent();
				BindComboData();
			}
			else
			{
				if (!this.Page.IsPostBack)
					BindComboData();
			}
		}

		public string GetTextOutputControlScript()
		{
			return "GetElem('" + txtOutput.ClientID + "')";
		}

		public string GetInputControlScript(string subItem)
		{
			WebControl ctl = (WebControl)inputCtls[subItem];
			return "GetElem('" + ctl.ClientID + "')";
		}

		protected override void CreateChildControls()
		{
			CreateChildControls(this.Controls);
		}

		public string GetRootClientID()
		{
			if (inputCtls.Count > 0)
			{
				foreach (DictionaryEntry de in inputCtls)
				{
					string key = (string)de.Key;
					WebControl ctl = (WebControl)de.Value;
					string cliID = ctl.ClientID;
					return cliID.Substring(0, cliID.Length - key.Length);
				}
			}

			return null;
		}

		protected void PrepareControlsContent()
		{

			try
			{
				for (int i = 0; i < inputs.Count; i++)
				{
					TextBox tb = inputs[i] as TextBox;
					if (tb != null)
					{
						if (i < inputs.Count - 1)
						{
							string nextCtlID = ((WebControl)inputs[i + 1]).ClientID;
							tb.Attributes["onkeypress"] = "if (this.value.length>=this.maxLength) " + nextCtlID + ".focus();";
						}

						if (txtOutput != null)
							tb.Attributes["onpropertychange"] = "GetElem('" + txtOutput.ClientID + "').value=FormatMTB('" + formattingArg + "')";
						//else
						//{
						//	tb.Attributes["onblur"] = txtOutput.ClientID + ".value=" + 
						//}
					}
					else
					{
						WebControl ctl = inputs[i] as WebControl;
						if (txtOutput != null && ctl != null)
							if (!(ctl is HyperLink) && !(ctl is LinkButton))
								ctl.Attributes["onpropertychange"] = "GetElem('" + txtOutput.ClientID + "').value=FormatMTB('" + formattingArg + "')";
					}
				}
			}
			catch
			{
			}

			if (this.multiTextBoxType == EnumMultiTextBoxType.USDate ||
				this.multiTextBoxType == EnumMultiTextBoxType.USDateCombo)
			{
				HyperLink hl = this.GetHyperLinkControl("today");
				hl.Text = "Today";
				hl.NavigateUrl = "#";
				hl.Font.Size = FontUnit.XXSmall;
				if (this.Enabled)
					hl.Attributes["OnClick"] = "d=new Date();" + GetInputControlScript("year") + ".value=d.getFullYear();" + GetInputControlScript("month") + ".value=d.getMonth()+1;" + GetInputControlScript("day") + ".value=d.getDate();return false";

				hl = this.GetHyperLinkControl("select");
				hl.Text = "Select";
				hl.NavigateUrl = "#";
				hl.Font.Size = FontUnit.XXSmall;
				if (this.Enabled)
					hl.Attributes["OnClick"] = "javascript:cal=window.open('Calendar.aspx','Calendar','width=250,height=250');cal.PickTarget='" + GetRootClientID() + "';return false";
			}

			

		}

		protected void BindComboData()
		{
			for (int j = 0; j < inputs.Count; j++)
			{
				string comboValues = null;
				DropDownList dd = inputs[j] as DropDownList;
				if (dd != null)
				{
					//if (!OnDropDownFill(dd))		// if dropdown already filled, don't fill
					//{

						comboValues = dd.Attributes["combo"];
						if (comboValues != null)
						{
							string[] rangeterms = comboValues.Split('-');
							if (rangeterms.Length > 1)
							{
								try
								{
									int first = int.Parse(rangeterms[0]);
									int last = int.Parse(rangeterms[1]);
									//if (first > last)
									//	first
									// a range of values was specified
									dd.Items.Clear();
									dd.Items.Add(new ListItem(null, null));
									for (int i = first; i <= last; i++)
										dd.Items.Add(i.ToString());
								}
								catch
								{
								}
								continue;
							}
						}
						switch (comboValues)
						{
							case "months":
							{
								dd.Items.Clear();
								dd.Items.Add(new ListItem(null, null));
								for (int i = 0; i < 12; i++)
									dd.Items.Add(new ListItem(MonthsArray[i, 2], MonthsArray[i, 0]));
								break;
							}

							case "days":
							{
								dd.Items.Clear();
								dd.Items.Add(new ListItem(null, null));
								for (int i = 1; i <= 31; i++)
									dd.Items.Add(i.ToString());
								break;
							}

							case "years":
							{
								dd.Items.Clear();
								dd.Items.Add(new ListItem(null, null));
								for (int i = 1990; i <= 2020; i++)
									dd.Items.Add(i.ToString());
								break;
							}

							case "states":
							{
								dd.Items.Clear();
								dd.Items.Add(new ListItem(null, null));
								for (int i = 0; i < StatesArray.GetLength(0); i++)
									dd.Items.Add(new ListItem(StatesArray[i, 1], StatesArray[i, 0]));
								break;
							}

							case "stateabbrs":
							{
								dd.Items.Clear();
								dd.Items.Add(new ListItem(null, null));
								for (int i = 0; i < StatesArray.GetLength(0); i++)
									dd.Items.Add(new ListItem(StatesArray[i, 0], StatesArray[i, 0]));
								break;
							}

							case "ampm":
							{
								dd.Items.Clear();
								dd.Items.Add(new ListItem(null, null));
								dd.Items.Add("AM");
								dd.Items.Add("PM");
								break;
							}

							case "12hours":
							{
								dd.Items.Clear();
								dd.Items.Add(new ListItem(null, null));
								for (int i = 1; i <= 12; i++)
									dd.Items.Add(i.ToString());
								break;
							}

							case "mins":
							{
								dd.Items.Clear();
								dd.Items.Add(new ListItem(null, null));
								for (int i = 0; i < 60; i++)
									dd.Items.Add(i.ToString());
								break;
							}

							case "24hours":
							{
								dd.Items.Clear();
								dd.Items.Add(new ListItem(null, null));
								for (int i = 0; i <= 23; i++)
									dd.Items.Add(i.ToString());
								break;
							}
						}
					//}
				}
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			if (txtOutput != null)
				this.Attributes["TextOutput"] = txtOutput.ClientID;
			//this.Attributes["Formatting"] = formattingArg;
			base.OnPreRender (e);

			//if (!Page.IsPostBack)
			//{
			//	PrepareControlsContent();
			//}

			//if (txtOutput != null)
			//	this.Text = txtOutput.Text;

			
		}

		/// <summary>
		/// Render this control to the output parameter specified.
		/// </summary>
		/// <param name="output"> The HTML writer to write out to </param>
		protected override void Render(HtmlTextWriter output)
		{
			//if (true) //this.Site != null && this.Site.DesignMode)
			//{
			//}
			if (txtOutput != null)
			{
				this.ReadOnly = txtOutput.ReadOnly;
				this.Enabled = txtOutput.Enabled;
				//this.CssClass = txtOutput.CssClass;
			}

			PrepareControlsContent();

			foreach (DictionaryEntry entry in this.inputCtls)
			{
				string subItem = (string)entry.Key;
				WebControl ctl = entry.Value as WebControl;
				TextBox tb = ctl as TextBox;
				if (tb != null)
				{
					tb.ReadOnly = this.readOnly;
					ctl.Enabled = this.Enabled;
				}
				else
				{
					ctl.Enabled = this.Enabled && !this.readOnly;
				}
			}
			base.Render(output);
		}


		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);

			/*EnsureChildControls();
			foreach (DictionaryEntry entry in this.inputCtls)
			{
				string subItem = (string)entry.Key;
				string sval = (string)ViewState["v_" + subItem];
				WebControl ctl = entry.Value as WebControl;
				SetControlValue(ctl, sval);
			}*/
		}

		protected override object SaveViewState()
		{
			EnsureChildControls();
			/*foreach (DictionaryEntry entry in this.inputCtls)
			{
				string subItem = (string)entry.Key;
				WebControl ctl = entry.Value as WebControl;
				string sval = GetControlValue(ctl);
				ViewState["v_" + subItem] = sval;
			}*/

			return base.SaveViewState ();
		}



		#region Public Properties

		[DefaultValue("MultiTextBox")]
		public string DisplayExp
		{
			get
			{
				return displayExp;
			}
			set
			{
				if (this.multiTextBoxType == EnumMultiTextBoxType.Custom)
					displayExp = value;
			}
		}

		public string FormatExp
		{
			get
			{
				return formatExp;
			}
			set
			{
				if (this.multiTextBoxType == EnumMultiTextBoxType.Custom)
					formatExp = value;
			}
		}

		public string ParseRegEx
		{
			get
			{
				return parseRegEx;
			}
			set
			{
				if (this.multiTextBoxType == EnumMultiTextBoxType.Custom)
					parseRegEx = value;
			}
		}

		/// <summary>
		/// get:  return the formatted value using formatExp
		/// set:  parses using parseRegEx and sets each sub-field
		/// </summary>
		[Bindable(true),
		Category("Appearance"),
		DefaultValue("")]
		public string Text
		{
			get
			{
				EnsureChildControls();
				Hashtable values = new Hashtable();
				bool nullEntry = true;
				foreach (DictionaryEntry entry in this.inputCtls)
				{
					string subItem = (string)entry.Key;
					WebControl ctl = entry.Value as WebControl;
					string sval = GetControlValue(ctl);

					if (sval != null && sval.Length > 0)
						nullEntry = false;
					values[subItem] = sval;
				}

				if (nullEntry)
					return null;
				else
					return Util.SubstituteByHashtable(this.formatExp, values);
			}
			set
			{
				try
				{
					EnsureChildControls();
					if (this.inputCtls != null)
					{
						Hashtable values = Util.ParseIntoHashtable(value, this.parseRegEx);
						foreach (DictionaryEntry entry in this.inputCtls)
						{
							string subItem = (string)entry.Key;
							WebControl ctl = entry.Value as WebControl;

							string sval = null;
							if (values != null)
								sval = (string)values[subItem];
							SetControlValue(ctl, sval);
						}
					}
				}
				catch
				{
				}

			}
		}

		[TypeConverter(typeof(ValidatedControlConverter))]
		public string OutputTextBox
		{
			get
			{
				return outputTextBox;
			}
			set
			{
				outputTextBox = value;
			}
		}

		[DefaultValue(false)]
		public bool ReadOnly
		{
			get
			{
				return readOnly;
			}
			set
			{
				readOnly = value;
			}
		}

		[DefaultValue(EnumMultiTextBoxType.USDate)]
		public NetsoftUSA.WebControls.EnumMultiTextBoxType MultiTextBoxType
		{
			get { return this.multiTextBoxType; }
			set 
			{
				this.multiTextBoxType = value;
				string dateSel = "@today:HyperLink@<BR>@select:HyperLink@";
				switch(this.multiTextBoxType)
				{
					case EnumMultiTextBoxType.USDate:
						this.displayExp = "<table align=left cellspacing=0 cellpadding=0 border=0><tr><td nowrap=true>@month::2@/@day::2@/@year::4@</td><td border=1>" + dateSel + "</td></tr></table>";
						this.formatExp = "@month@/@day@/@year@";
						this.parseRegEx = "(?<month>[0-9]{1,2})/(?<day>[0-9]{1,2})/(?<year>[0-9]{2,4})";
						break;
					case EnumMultiTextBoxType.USDateCombo:
						this.displayExp = "<table align=left cellpadding=0 border=0><tr><td nowrap=true>@month:DropDownList:2:months@/@day:DropDownList:2:days@/@year:DropDownList:4:years@</td><td border=1>" + dateSel + "</td></tr></table>";
						this.formatExp = "@month@/@day@/@year@";
						this.parseRegEx = "(?<month>[0-9]{1,2})/(?<day>[0-9]{1,2})/(?<year>[0-9]{2,4})";
						break;
					case EnumMultiTextBoxType.USTelephone:
						this.displayExp = "(@region::3@)-@part1::3@-@part2::4@";
						this.formatExp = "(@region@)-@part1@-@part2@";
						this.parseRegEx = @"\((?<region>[0-9]{3})\)-(?<part1>[0-9]{3})-(?<part2>[0-9]{4})";
						break;
					case EnumMultiTextBoxType.USState:
						this.displayExp = "@state:DropDownList:2:states@";
						this.formatExp = "@state@";
						this.parseRegEx = @"(?<state>[a-zA-Z]{2})";
						break;
					case EnumMultiTextBoxType.USStateAbbr:
						this.displayExp = "@state:DropDownList:2:stateabbrs@";
						this.formatExp = "@state@";
						this.parseRegEx = @"(?<state>[a-zA-Z]{2})";
						break;
					case EnumMultiTextBoxType.Time12:
						this.displayExp = "@hour::2@:@min::2@ @ampm:DropDownList:2@";
						this.formatExp = "@hour@:@min@ @ampm@";
						this.parseRegEx = @"(?<hour>[0-9]{1,2}):(?<min>[0-9]{1,2}) (?<ampm>[a-zA-Z]{2})";
						break;
					case EnumMultiTextBoxType.Time24:
						this.displayExp = "@hour::2@:@min::2@";
						this.formatExp = "@hour@:@min@";
						this.parseRegEx = @"(?<hour>[0-9]{1,2}):(?<min>[0-9]{1,2})";
						break;
					case EnumMultiTextBoxType.TimeCombo12:
						this.displayExp = "@hour:DropDownList:2:12hours@:@min:DropDownList:2:mins@ @ampm:DropDownList:2:ampm@";
						this.formatExp = "@hour@:@min@ @ampm@";
						this.parseRegEx = @"(?<hour>[0-9]{1,2}):(?<min>[0-9]{1,2}) (?<ampm>[a-zA-Z]{2})";
						break;
					case EnumMultiTextBoxType.TimeCombo24:
						this.displayExp = "@hour:DropDownList:2:24hours@:@min:DropDownList:2:mins@";
						this.formatExp = "@hour@:@min@";
						this.parseRegEx = @"(?<hour>[0-9]{1,2}):(?<min>[0-9]{1,2})";
						break;
				}
			}
		}

		public WebControl GetInputControl(string subfield)
		{
			return inputCtls[subfield] as WebControl;
		}

		public TextBox GetTextBoxControl(string subfield)
		{
			return inputCtls[subfield] as TextBox;
		}

		public DropDownList GetDropDownListControl(string subfield)
		{
			return inputCtls[subfield] as DropDownList;
		}

		public LinkButton GetLinkButtonControl(string subfield)
		{
			return inputCtls[subfield] as LinkButton;
		}

		public HyperLink GetHyperLinkControl(string subfield)
		{
			return inputCtls[subfield] as HyperLink;
		}

		#endregion

	}
}
