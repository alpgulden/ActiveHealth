using System;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.Design;

namespace NetsoftUSA.WebControls
{
	/// <summary>
	/// Designer object used in the VS design time for MultiTextBox control.
	/// </summary>
	public class MultiTextBoxDesigner : ControlDesigner
	{
		public MultiTextBoxDesigner() : base()
		{
		}

		/// <summary>
		/// Called by the design time environment to get a representative html string
		/// </summary>
		/// <returns></returns>
		public override string GetDesignTimeHtml()
		{
			// Get the navigator control's current instance
			int i = 0;
			try
			{
				i = 10;
				MultiTextBox mtb = (MultiTextBox)Component;
				StringWriter sw = new StringWriter();
				i = 20;
				HtmlTextWriter tw = new HtmlTextWriter(sw);
				i = 25;
				// populate controls inside an empty container
				Control control = new Control();
				i = 30;
				mtb.CreateChildControls(control.Controls);
				// render them into html writer
				i = 40;
				control.RenderControl(tw);
				// return as html text
				i = 50;
				return sw.ToString();
			}
			catch(Exception ex)
			{
				return "Line " + i.ToString() + " - " + ex.Message;
			}
		}
	}
}
