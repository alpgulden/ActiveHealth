using System;
using System.Web.Security;
using System.Security.Cryptography;

namespace NetsoftUSA.WebControls
{
	/// <summary>
	/// Summary description for CryptoUtil.
	/// </summary>
	public class CryptoUtil
	{
		public CryptoUtil()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Create a hash of the given password with the given salt.
		/// </summary>
		/// <param name="password"></param>
		/// <param name="salt"></param>
		/// <returns></returns>
		public static string EncryptPassword(string password, string salt)
		{
			return FormsAuthentication.HashPasswordForStoringInConfigFile(
				password + salt, "SHA1");
		}

		/// <summary>
		/// Creates both the salt and the hashed password for the given password
		/// </summary>
		/// <param name="saltSize"></param>
		/// <param name="password"></param>
		/// <param name="hashedPassword"></param>
		/// <param name="salt"></param>
		public static void EncryptPassword(int saltSize, string password, out string hashedPassword, out string salt)
		{
			salt = CreateSalt(saltSize);
			hashedPassword = EncryptPassword(password, salt);
		}

		/// <summary>
		/// Verifies the given password against previously saltedHashedPassword value using the given salt
		/// </summary>
		/// <param name="passwordToVerify"></param>
		/// <param name="salt"></param>
		/// <param name="saltedHashedPassword"></param>
		/// <returns></returns>
		public static bool VerifyPassword(string passwordToVerify, string salt, string saltedHashedPassword)
		{
			string hashToVerify = FormsAuthentication.HashPasswordForStoringInConfigFile(
				passwordToVerify + salt, "SHA1");
			return hashToVerify == saltedHashedPassword;
		}

		/// <summary>
		/// Creates a salt value to be later used in encryption
		/// </summary>
		/// <param name="size">Size of the salt value</param>
		/// <returns>Salt string</returns>
		public static string CreateSalt(int size)
		{
			// Generate a cryptographic random number using the cryptographic
			// service provider
			RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
			byte[] buff = new byte[size];
			rng.GetBytes(buff);
			// Return a Base64 string representation of the random number
			return Convert.ToBase64String(buff);
		}


	}
}
