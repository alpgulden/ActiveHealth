using System;
using System.Text.RegularExpressions;
using System.Collections;

namespace NetsoftUSA.WebControls
{
	/// <summary>
	/// Summary description for Util.
	/// </summary>
	public class Util
	{
		protected const string HashTableItemMatchRegex = @"@(?<itemName>[0-9a-zA-Z_\-:]+)@";

		public static string[] ExtractSubstitutablesAndStatics(string expression)
		{
			if (expression == null)
				return null;

			Regex regex = new Regex( HashTableItemMatchRegex, 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			ArrayList list = new ArrayList();
			int lastpos = 0;
			int ipos = 0;
			string stat = null;
			for (match = regex.Match(expression); match.Success; match = match.NextMatch())
			{
				// extract item name from match
				string itemName = match.Groups["itemName"].Value;
				ipos = match.Groups["itemName"].Index - 1;
				int ilen = itemName.Length;
				if (ilen > 0)
				{
					stat = expression.Substring(lastpos, ipos - lastpos);
					if (stat.Length > 0)
						list.Add(stat);	// add chars before
					list.Add("@" + itemName + "@");	// add item name
				}
				lastpos = ipos + ilen + 2;
			}
			ipos = expression.Length;
			stat = expression.Substring(lastpos, ipos - lastpos); //add chars after
			if (stat.Length > 0)
				list.Add(stat);

			return (string[])list.ToArray(typeof(string));
		}

		/// <summary>
		/// Parse the given string into a given hashTable by groupnames.
		///      ParseIntoHashtable("5/6/2004", "(?<month>[0-9]{1,2})/(?<day>[0-9]{1,2})/(?<year>[0-9]{2,4})");
		///    will return a hastable with following key-value pairs:
		///      "month", "5"
		///      "day", "6"
		///      "year", "2004"
		/// </summary>
		/// <param name="s"></param>
		/// <param name="regExp"></param>
		/// <param name="hashTable"></param>
		/// <returns></returns>
		public static bool ParseIntoHashtable(string s, string regExp, Hashtable hashTable)
		{
			Regex regex = new Regex( regExp, 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match = regex.Match(s);
			if (match.Success)		// check only first match
			{
				string[] groupNames = regex.GetGroupNames();
				for (int i = 1; i < groupNames.Length; i++)
				{
					string groupName = groupNames[i];
					Group group = match.Groups[groupName];
					hashTable[groupName] = group.Value;
				}
				return true;
			}
			else
				return false;
		}

		public static Hashtable ParseIntoHashtable(string s, string regExp)
		{
			Hashtable hashTable = new Hashtable();
			if (ParseIntoHashtable(s, regExp, hashTable))
				return hashTable;
			else
				return null;
		}

		public static string SubstituteByHashtable(string expression, Hashtable hashTable)
		{
			if (expression == null)
				return null;

			if (hashTable == null)
				return expression;

			Regex regex = new Regex( HashTableItemMatchRegex , 
				RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			Match match;
			string substituted = "";
			int lastpos = 0;
			int ipos = 0;
			for (match = regex.Match(expression); match.Success; match = match.NextMatch())
			{
				// extract item name from match
				string itemName = match.Groups["itemName"].Value;
				ipos = match.Groups["itemName"].Index - 1;
				int ilen = itemName.Length;
				if (ilen > 0)
				{
					string val = Convert.ToString(hashTable[itemName]);
					substituted += expression.Substring(lastpos, ipos - lastpos);
					substituted += val;
				}
				lastpos = ipos + ilen + 2;
			}
			ipos = expression.Length;
			substituted += expression.Substring(lastpos, ipos - lastpos);
			return substituted;
		}

	}
}
