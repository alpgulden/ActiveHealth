using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ActivityCompletion]
	/// </summary>
	[SPAutoGen("usp_GetActivityCompletionsByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllActivityCompletions","SelectAll.sptpl","")]
	[SPInsert("usp_InsertActivityCompletion")]
	[SPUpdate("usp_UpdateActivityCompletion")]
	[SPDelete("usp_DeleteActivityCompletion")]
	[SPLoad("usp_LoadActivityCompletion")]
	[TableMapping("ActivityCompletion","activityCompletionID")]
	public class ActivityCompletion : BaseLookupStandard
	{
		[NonSerialized]
		private ActivityCompletionCollection parentActivityCompletionCollection;
		[ColumnMapping("ActivityCompletionID",(int)0)]
		private int activityCompletionID;
		[ColumnMapping("Notepad")]
		private string notepad;
		[ColumnMapping("CodeStatus")]
		private string codeStatus;
	
		public ActivityCompletion()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ActivityCompletionID
		{
			get { return this.activityCompletionID; }
			set { this.activityCompletionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=500)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string CodeStatus
		{
			get { return this.codeStatus; }
			set { this.codeStatus = value; }
		}

		/// <summary>
		/// Parent ActivityCompletionCollection that contains this element
		/// </summary>
		public ActivityCompletionCollection ParentActivityCompletionCollection
		{
			get
			{
				return this.parentActivityCompletionCollection;
			}
			set
			{
				this.parentActivityCompletionCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ActivityCompletion objects
	/// </summary>
	[ElementType(typeof(ActivityCompletion))]
	public class ActivityCompletionCollection : BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ActivityCompletion elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentActivityCompletionCollection = this;
			else
				elem.ParentActivityCompletionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ActivityCompletion elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ActivityCompletion this[int index]
		{
			get
			{
				return (ActivityCompletion)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ActivityCompletion)oldValue, false);
			SetParentOnElem((ActivityCompletion)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}
}
