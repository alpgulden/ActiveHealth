using System;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Derive all ActiveAdvice application exceptions
	/// from this class.
	/// </summary>
	
	public enum AAExceptionAction
	{
		None = 0,
		DisableUI = 1
	}

	public class ActiveAdviceException : NetsoftUSA.DataLayer.ExceptionWithParameters
	{
		AAExceptionAction exceptionAction = AAExceptionAction.None;

		public ActiveAdviceException(AAExceptionAction exceptionAction, string msg, Exception innerException) : base(msg, innerException)
		{
			this.exceptionAction = exceptionAction;
		}

		public ActiveAdviceException(AAExceptionAction exceptionAction, string msg) : base(msg)
		{
			this.exceptionAction = exceptionAction;
		}

		public ActiveAdviceException(AAExceptionAction exceptionAction, string msg, Exception innerException, params object[] parameters) : base(msg, innerException, parameters)
		{
			this.exceptionAction = exceptionAction;
		}

		public ActiveAdviceException(AAExceptionAction exceptionAction, string msg, params object[] parameters) : base(msg, parameters)
		{
			this.exceptionAction = exceptionAction;
		}

		// 

		public ActiveAdviceException(string msg, Exception innerException) : this(AAExceptionAction.None, msg, innerException)
		{
		}

		public ActiveAdviceException(string msg) : this(AAExceptionAction.None, msg)
		{
		}

		public ActiveAdviceException(string msg, Exception innerException, params object[] parameters) : this(AAExceptionAction.None, msg, innerException, parameters)
		{
		}

		public ActiveAdviceException(string msg, params object[] parameters) : this(AAExceptionAction.None, msg, parameters)
		{
		}

	}
}
