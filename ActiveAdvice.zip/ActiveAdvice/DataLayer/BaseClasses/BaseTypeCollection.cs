using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for BaseTypeCollection.
	/// </summary>
	public class BaseTypeCollection: BaseDataCollectionClass
	{
		public BaseTypeCollection()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		public virtual void LoadAll() { }

		public virtual void SearchCodeTypes(string code, string description, bool active) { }

	}
}
