using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// This is the base class for all code classes. 
	/// </summary>
	public class BaseLookup : BaseData
	{
		[ColumnMapping("Description")]
		protected string description;
		[ColumnMapping("Active")]
		protected bool active=true;
		[ColumnMapping("ReadOnly")]
		protected bool readOnly;
		//[ColumnMapping("Notepad")]		// Some (not all) have been changed to Note.  So we don't include this in the base
		//protected string notepad;


		public bool ReadOnly
		{
			get { return this.readOnly; }
		}

		/// <summary>
		/// Generic property to access pk of the code.
		/// </summary>
		public int ID
		{
			get
			{
				return (int)this.PK[0];
			}
			set
			{
				this.PK[0] = value;
			}
		}

		/*[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}*/
	
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		public void New()
		{
			this.NewRecord(); // initialize record state
		}

		public void Delete(int ID)
		{
			base.Delete(ID);
		}

		public new void Save()
		{
			
			base.Save();
		}
	}

	public class BaseLookupWithCode: BaseLookup
	{
		[ColumnMapping("Code")]
		protected string code;

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}
	}

	public class BaseLookupStandard : BaseLookupWithCode
	{
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}
	}

	/// <summary>
	/// Many classes derive from BaseCode.  This ensures, they won't break.
	/// Remove these after changing all
	/// </summary>
	public class BaseCode: BaseLookupWithCode
	{
		
	}

	public class BaseCodeWithNote: BaseCode
	{
		public new void Delete(int ID)
		{
			base.Delete(ID);
		}
	}


	public class BaseLookupCollection : BaseDataCollection
	{
	}

	[ElementType(typeof(BaseLookupWithCode))]
	public class BaseLookupWithCodeCollection : BaseLookupCollection
	{
		
		[NonSerialized]
		private CollectionIndexer indexBy_ID;

		/// <summary>
		/// Hashtable based index on ID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ID
		{
			get
			{
				if (this.indexBy_ID == null)
					this.indexBy_ID = new CollectionIndexer(this, new string[] { "ID" }, true);
				return this.indexBy_ID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on ID fields returns the collection index.  Uses the IndexBy_ID indexer.
		/// </summary>
		public int IndexOfID(int ID)
		{
			return this.IndexBy_ID.IndexOf(ID);
		}

		/// <summary>
		/// Hashtable based search on ID fields returns the object.  Uses the IndexBy_ID indexer.
		/// </summary>
		public BaseLookupWithCode FindByID(int ID)
		{
			return (BaseLookupWithCode)this.IndexBy_ID.GetObject(ID);
		}

		/// <summary>
		/// Looks up by ID and returns Code value.  Uses the IndexBy_ID indexer.
		/// </summary>
		public string Lookup_CodeByID(int ID)
		{
			return this.IndexBy_ID.LookupStringMember("Code", ID);
		}
	}

}
