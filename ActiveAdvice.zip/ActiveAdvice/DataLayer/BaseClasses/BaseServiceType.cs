using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for BaseServiceType.
	/// </summary>
	// Pseudo table mapping for BaseServiceType, attributes will be overwritten by derived classes.
	[TableMapping("ProviderServiceTypes","ProviderServiceTypeID")]/// 
	public class BaseServiceType: NetsoftUSA.DataLayer.BaseDataClass
	{
		[ColumnMapping("Service")]
		protected string service;
		[ColumnMapping("ServiceCode")]
		protected string serviceCode;
		[ColumnMapping("Active")]
		protected bool active;
		[ColumnMapping("Note")]
		protected string note;
	
		public BaseServiceType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		[FieldDescription("@SERVICEDESC@")]
		public string Service
		{
			get { return this.service; }
			set { this.service = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		[FieldDescription("@SERVICECODE@")]
		public string ServiceCode
		{
			get { return this.serviceCode; }
			set { this.serviceCode = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		public new void Save()
		{
			base.Save();
		}
	}
}
