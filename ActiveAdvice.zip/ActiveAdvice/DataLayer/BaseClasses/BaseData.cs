using System;
using System.Diagnostics;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Extends the NetsoftUSA.BaseDataClass features and provides
	/// a centralized management point for all of the application data classes.
	/// </summary>
	public class BaseData : BaseDataClass
	{
		public const string CreateTimeMember = "CreateTime";
		public const string CreatedByMember = "CreatedBy";
		public const string ModifyTimeMember = "ModifyTime";
		public const string ModifiedByMember = "ModifiedBy";
		public const string InactivateTimeMember = "InactivateTime";
		public const string InactivatedByMember = "InactivatedBy";
		public const string TerminateTimeMember = "TerminateTime";
		public const string TerminatedByMember = "TerminatedBy";
		public const string AddTimeMember = "AddTime";
		public const string AddedByMember = "AddedBy";
		public const string ActiveMember = "Active";
		public const string StatusChangedByMember = "StatusChangedBy";
		public const string StatusChangeTimeMember = "StatusChangeTime";


		protected AutoActivityManager autoActivityManager;		// last used autoactivity context

		public BaseData()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Returns the last used autoactivity context.
		/// All classes are responsible for creating the auto activity context
		/// and executing them.
		/// </summary>
		public ActiveAdvice.DataLayer.AutoActivityManager AutoActivityManager
		{
			get { return this.autoActivityManager; }
			set { this.autoActivityManager = value; }
		}

		protected override void NewRecord()
		{
			base.NewRecord ();
			this.autoActivityManager = null;
		}

		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			base.FillFromReader (sourceRdr, ignoreAssignmentError);
			this.autoActivityManager = null;
		}


		protected override void InternalUpdate()
		{
			//this.SqlData.Principal   // get from principal and set user info
			this.Set(ModifyTimeMember, DateTime.Now, false);
			#if DEBUG
			this.Set(ModifiedByMember, 1, false);
			#endif

			base.InternalUpdate ();
		}

		protected override object InternalInsert()
		{
			this.Set(CreateTimeMember, DateTime.Now, false);
			#if DEBUG
			this.Set(CreatedByMember, 1, false);
			#endif
			
			return base.InternalInsert ();
		}

		/// <summary>
		/// Call this whenever you want the InactivateTime and InactivatedBy fields to be set from the current user context
		/// </summary>
		protected void SetInactivatingUser()
		{
			this.Set(InactivateTimeMember, DateTime.Now, false);
			#if DEBUG
			this.Set(InactivatedByMember, 1, false);
			#endif
			// will set the inactivating user from the current user context
			Debug.WriteLine("Inactivating user set for " + this.GetType() + " " + this.PKString);
		}

		/// <summary>
		/// Call this whenever you want the TerminateTime and TerminatedBy fields to be set from the current user context
		/// </summary>
		protected void SetTerminatingUser()
		{
			this.Set(TerminateTimeMember, DateTime.Now, false);
			#if DEBUG
			this.Set(TerminatedByMember, 1, false);
			#endif
			// will set the inactivating user from the current user context
			Debug.WriteLine("Terminating user set for " + this.GetType() + " " + this.PKString);

		}

		/// <summary>
		/// Call this whenever you want the StatusChangedBy and StatusChangedBy fields to be set from the current user context
		/// </summary>
		protected void SetStatusChangingUser()
		{
			// will set the inactivating user from the current user context
			Debug.WriteLine("Status changing user set for " + this.GetType() + " " + this.PKString);
			
			this.Set(StatusChangeTimeMember, DateTime.Now, false);
			this.Set(StatusChangedByMember, 1, false);
		}

		/*/// <summary>
		/// Encrypt SSN number.
		/// For simplicity, we just change to byte[] for now.
		/// </summary>
		/// <param name="SSN"></param>
		/// <returns></returns>
		protected byte[] EncryptSSN(string SSN)
		{
			if (SSN == null)
				return null;
			byte[] buf = new byte[SSN.Length + 1];
			buf[0] = (byte)SSN.Length;		// save the length in the first byte
			for (int i = 0; i < SSN.Length; i++)
			{
				buf[i + 1] = (byte)SSN[i];
			}
			return buf;
		}

		/// <summary>
		/// Decrypt given encrypted SSN.
		/// For simplicity, we just return it as a string.
		/// </summary>
		/// <param name="buf"></param>
		/// <returns></returns>
		protected string DecryptSSN(byte[] buf)
		{
			if (buf == null)
				return null;
			string s = null;
			int length = (int)buf[0];
			for (int i = 1; i <= length; i++)
			{
				s += (char)buf[i];
			}
			return s;
		}*/

		//     [-----
		//     [ -- ]
		// x1    x2   x3
		//
		public static bool IsActiveBetween(DateTime startDate, DateTime endDate, DateTime now)
		{
			if (endDate == DateTime.MinValue)
				return now >= startDate;

			return now >= startDate && now <= endDate;
		}

		// General validator props
		[GenericScript("Vld_TerminationDate", "@TerminationDate@ != null && @TerminationDate@ >= @EffectiveDate@;")]
		protected string Vld_TerminationDate
		{
			get
			{
				return "@ERRTERMDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
				/*DateTime terminationDate = (DateTime)this.Get("terminationDate");
				DateTime effectiveDate = (DateTime)this.Get("effectiveDate");
				if (terminationDate != DateTime.MinValue && !(terminationDate >= effectiveDate))
					throw new ValidationException("TerminationDate", Vld_TerminationDate);  // throw validation exception if failed (don't set the member) 
					*/

				// Can't validate on the server, because the depended 2 members are not filled yet.
			}
		}

		// General valuesof functions
		public string[,] ValuesOf_DiagOrProc
		{
			get
			{
				return new string[,] { { "D", "Diagnostics" }, { "P", "Procedure" }  }; // return possible field values
			}
		}

		public string[,] ValuesOf_Gender
		{
			get
			{
				return new string[,] { { "M", "Male" }, { "F", "Female" }  }; // return possible field values
			}
		}

		public string[,] ValuesOf_CodeType
		{
			get
			{
				string diagProc = (string)this.Get("DiagOrProc");
				return BaseDxPx.GetValuesOfCodeType(diagProc);
			}
		}

		public object[,] ValuesOf_ActiveWithAll
		{
			get
			{
				return new object[,] { { (int)-1, "All"}, { (int)1, "Active"},  { (int)0, "Inactive"}};
			}
		}


		public object[,] ValuesOf_DoNowLater
		{
			get 
			{
				return new object[,] { {(int)0, "Please Select"}, { (int)1, "Do Now"}, {(int)2, "Do Later"}};
			}
		}


		public string[] ValuesOf_HighOp
		{
			get
			{
				return new string[] {"<", "<=", "="};
			}
		}

		public string[] ValuesOf_LowOp
		{
			get
			{
				return new string[] {">", ">=", "="};
			}
		}

		public int[] ValuesOf_CCAnswer
		{
			get 
			{
				int[] values = new int[99];
				for (int index = 0; index < 99; index++)
					values[index] = index + 1;
				return values;
			}
		}

		public object[,] ValuesOf_CCSource
		{
			get 
			{
				return new object[,] { {(int)1, "Doctor"}, { (int)2, "Nurse"}, {(int)3, "Patient"}};
			}
		}

		public virtual void FillSummaryText(SummaryWriter writer)
		{
			// data classes override this
		}

		public string MakeCompositeDiagnosticIdentifier(string dxType, int diagId, int dsm4Axis)
		{
			return String.Format("{0}-{1}-{2}", dxType, diagId, dsm4Axis);
		}

		public void ParseCompositeDiagnosticIdentifier(string composite, ref string dxType, ref int diagId, ref int dsm4Axis)
		{
			dxType = null;
			diagId = 0;
			dsm4Axis = 0;
			if (composite == null)
				return;

			string[] terms = composite.Split('-');
			dxType = terms[0];
			if (terms.Length > 1)
			{
				diagId = Convert.ToInt32( terms[1] );
				if (terms.Length > 2)
				{
					dsm4Axis = Convert.ToInt32( terms[2] );
				}
			}
		}

		public string FormatDiagnosticCodeForDisplay(string dxType, string diagCode)
		{
			if (dxType == null && diagCode == null)
				return "";
			else
				return String.Format("{0} - {1}", dxType, diagCode);
		}

		public string FormatTeamAndUserForDisplay(int teamID, int userID)
		{
			if (teamID == 0 && userID == 0)
				return "";
			else
				return String.Format("{0} - {1}", teamID, userID);
		}

		/// <summary>
		/// Format the status change date and the changing user
		/// </summary>
		public string FormatStatusChangeForDisplay(DateTime statusChangedDate, int statusChangedBy)
		{
			return String.Format("{0} - UID:{1}", 
				Formatting.FormatShortDate(statusChangedDate),
				statusChangedBy);
		}

		public void CalculateYearsMonths(TimeSpan span, ref int years, ref int months)
		{
			years = (int)(span.TotalDays / 365);
			months = (int)((span.TotalDays - years * 365) / 30);
		}

		public void CalculateYearsMonths(DateTime dateStart, DateTime dateEnd, ref int years, ref int months)
		{
			TimeSpan span = dateEnd - dateStart;
			CalculateYearsMonths(span, ref years, ref months);
		}

		public int CalculateMonths(DateTime dateStart, DateTime dateEnd)
		{
			int years = 0, months = 0;
			CalculateYearsMonths(dateStart, dateEnd, ref years, ref months);
			return years * 12 + months;
		}

		public int CalculateYears(DateTime dateStart, DateTime dateEnd)
		{
			int years = 0, months = 0;
			CalculateYearsMonths(dateStart, dateEnd, ref years, ref months);
			if (months >= 6)
				years ++;
			return years;
		}


		public decimal CalculateServiceAmountByRate(decimal amount, decimal rate, decimal baseConversionDivider, decimal baseConversionMultiplier)
		{
			// check for 0 denominator
			if (baseConversionDivider == 0)
				return 0;
			// check for NULLs
			if (baseConversionDivider == decimal.MinValue ||
				baseConversionMultiplier == decimal.MinValue ||
				rate == decimal.MinValue ||
				amount == decimal.MinValue)
				return 0;
			return rate / baseConversionDivider * baseConversionMultiplier * amount;
		}

	}

	/// <summary>
	/// Extends the NetsoftUSA.BaseDataClass features and provides
	/// a centralized management point for all of the application data collection classes.
	/// </summary>
	public class BaseDataCollection : BaseDataCollectionClass
	{
		public BaseDataCollection()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
