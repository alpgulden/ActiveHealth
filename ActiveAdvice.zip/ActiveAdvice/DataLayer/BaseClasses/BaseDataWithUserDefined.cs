using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for BaseDataWithUserDefined.
	/// </summary>
	public class BaseDataWithUserDefined:BaseData
	{
		[ColumnMapping("UserDefinedID",StereoType=DataStereoType.FK)]
		protected int userDefinedID;

		
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int UserDefinedID
		{
			get { return this.userDefinedID; }
			set { this.userDefinedID = value; }
		}

		private UserDefined userDefined;
		public BaseDataWithUserDefined()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Contained UserDefined object
		/// </summary>
		[Contained]
		public UserDefined UserDefined
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.userDefined = (UserDefined)UserDefined.EnsureContainedDataObject(this, typeof(UserDefined), userDefined, false, UserDefinedID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.userDefined;
			}
			set
			{
				this.userDefined = value;
				if (value != null) value.ParentBaseDataWithUserDefined = this; // set this as a parent of the child data class
			}
		}

		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			this.UserDefined.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			{
				base.InternalSave();	// in that case, delete the base first
				UserDefined.MarkDel();	// then allow the deletion of the conatined object
			}
			UserDefined.IsNew = this.IsNew;	// make sure the contained object is new if the containing object is new
			if(UserDefined.UserDefinedID == 0)
				UserDefined.IsNew = true;
			UserDefined.Save();
			this.UserDefinedID = UserDefined.UserDefinedID; // set the fk if the contained object was newly created
			
			base.InternalSave();
			// Save the child collections here.
		}

		protected override void NewRecord()
		{
			
			base.NewRecord ();
			this.UserDefinedID = 0;
		}


	}
}
