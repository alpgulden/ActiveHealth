using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{

	public interface IContactOwner
	{
		BaseDataCollectionClass GetContacts();
		void LoadContacts(bool forceLoad);
		void SaveContacts();
		ContactOwnerType ContactOwnerType { get;}
	}

}
