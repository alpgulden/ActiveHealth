using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [FacilityLocationContact]
	/// </summary>
	[SPInsert("usp_InsertFacilityLocationContact")]
	[SPLoad("usp_LoadFacilityLocationContact")]
	[TableMapping("FacilityLocationContact","facilityLocationID,contactID",true)]
	[TableLinkageAttribute(typeof(FacilityLocation), "facilityLocationID", typeof(Contact), "contactID")]
	public class FacilityLocationContact : BaseLinkageClass
	{
		[NonSerialized]
		private FacilityLocationContactCollection parentFacilityLocationContactCollection;
		[ColumnMapping("FacilityLocationID",(int)0)]
		private int facilityLocationID;
		[ColumnMapping("ContactID",(int)0)]
		private int contactID;
	
		public FacilityLocationContact()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int FacilityLocationID
		{
			get { return this.facilityLocationID; }
			set { this.facilityLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ContactID
		{
			get { return this.contactID; }
			set { this.contactID = value; }
		}

		/// <summary>
		/// Parent FacilityLocationContactCollection that contains this element
		/// </summary>
		public FacilityLocationContactCollection ParentFacilityLocationContactCollection
		{
			get
			{
				return this.parentFacilityLocationContactCollection;
			}
			set
			{
				this.parentFacilityLocationContactCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of FacilityLocationContact objects
	/// </summary>
	[ElementType(typeof(FacilityLocationContact))]
	public class FacilityLocationContactCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Parent FacilityLocation that contains this collection
		/// </summary>
		public FacilityLocation ParentFacilityLocation
		{
			get { return this.ParentDataObject as FacilityLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a FacilityLocation */ }
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(FacilityLocationContact elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentFacilityLocationContactCollection = this;
			else
				elem.ParentFacilityLocationContactCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (FacilityLocationContact elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public FacilityLocationContact this[int index]
		{
			get
			{
				return (FacilityLocationContact)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((FacilityLocationContact)oldValue, false);
			SetParentOnElem((FacilityLocationContact)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}
}
