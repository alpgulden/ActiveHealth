using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [FacilityLocations]
	/// </summary>
	[SPInsert("usp_InsertFacilityLocation")]
	[SPUpdate("usp_UpdateFacilityLocation")]
	[SPDelete("usp_DeleteFacilityLocation")]
	[SPLoad("usp_LoadFacilityLocation")]
	[TableMapping("FacilityLocation","facilityLocationID")]
	public class FacilityLocation : BaseLocation, IContactOwner
	{
		[NonSerialized]
		private FacilityLocationCollection parentFacilityLocationCollection;
		[ColumnMapping("FacilityLocationID",(int)0)]
		private int facilityLocationID;
		[ColumnMapping("FacilityID",(int)0)]
		private int facilityID;
//		[ColumnMapping("TerminateTime")]
//		private new System.DateTime terminateTime;
		//[ColumnMapping("Notepad")]
		//private string notepad;
//		[ColumnMapping("EffectiveDate")]
//		private new System.DateTime terminateTime;

		private FacilityLocationServiceCollection services;
		private FacilityLocationNetworkLinkCollection networks;
		private FacilityLocationContactCollection facilityLocationContacts;
		//private Location location;

		public FacilityLocation()
		{
		}

		public FacilityLocation(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			location=null;
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		[FieldDescription("@FACILITYLOCATIONID@")]
		public int FacilityLocationID
		{
			get { return this.facilityLocationID; }
			set { this.facilityLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@FACILITYID@")]
		public int FacilityID
		{
			get { return this.facilityID; }
			set { this.facilityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@LOCATIONID@")]
		public new int LocationID
		{
			get { return this.locationID; }
			set { this.locationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@CREATETIME@")]
		public new System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@CREATEDBY@")]
		public new int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		public string Phone
		{
			get 
			{
				return this.Location.ServiceAddress.PhoneNumber1;
			}

		}


		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}
		
		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
				
			//this.Location.SqlData.UseTransaction(this.sqlData.Transaction);
			this.Location.Save();
			this.sqlData.EnsureTransaction();
			this.CreatedBy	= 1;
			this.CreateTime	= DateTime.Now;
			if (this.services != null)
			{
				this.Services.SqlData.Transaction = this.SqlData.Transaction;
				this.SaveServices();
			}
			if (this.networks != null)
			{
				this.Networks.SqlData.Transaction = this.SqlData.Transaction;
				this.SaveNetworks();
			}
			this.locationID = this.Location.LocationID;			
			
			base.InternalSave();
			this.sqlData.CommitTransaction();

			// Save the contained objects that must be saved first.
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int facilityLocationID)
		{
			return base.Load(facilityLocationID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int facilityLocationID)
		{
			base.Delete(facilityLocationID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}
		
		/// <summary>
		/// Executes a stored procedure usp_GetStatusForProviderLocationNetwork which retrieves the Network Status based on Plan ID, Start Date and Location ID 
		/// </summary>
		public object GetStatusForFacilityLocationNetworks(int planId,DateTime startDate,int locationID)
		{
			return SqlData.SPExecScalar("usp_GetStatusForFacilityLocationNetwork", new object[] { planId,startDate,locationID });
		}


		/// <summary>
		/// Child Services mapped to related rows of table FacilityLocationServices where [FacilityLocationID] = [FacilityLocationID]
		/// </summary>
		[SPLoadChild("usp_LoadFacilityLocationServices", "facilityLocationID")]
		public FacilityLocationServiceCollection Services
		{
			get { return this.services; }
			set
			{
				this.services = value;
				value.ParentFacilityLocation = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Services collection
		/// </summary>
		public void LoadServices(bool forceReload)
		{
			this.services = (FacilityLocationServiceCollection)FacilityLocationServiceCollection.LoadChildCollection("Services", this, typeof(FacilityLocationServiceCollection), services, forceReload, null);
		}

		/// <summary>
		/// Saves the Services collection
		/// </summary>
		public void SaveServices()
		{
			FacilityLocationServiceCollection.SaveChildCollection(this.services, true);
		}

		/// <summary>
		/// Synchronizes the Services collection
		/// </summary>
		public void SynchronizeServices()
		{
			FacilityLocationServiceCollection.SynchronizeChildCollection(this.services, true);
		}
	
		[FieldDescription("@ADDRESS@")]
		public string ServiceLocation 
		{
			get 
			{ 
				if (this.Location.ServiceAddress != null)
					return this.Location.ServiceAddress.Line1 + " " + this.Location.ServiceAddress.Line2 + "," + this.Location.ServiceAddress.City + "," + this.Location.ServiceAddress.State + "," + this.Location.ServiceAddress.Zip; 
				else
					return null;
			}
		}

		/// <summary>
		/// Child Networks mapped to related rows of table FacilityLocationNetworks where [FacilityLocationID] = [FacilityLocationID]
		/// </summary>
		[SPLoadChild("usp_LoadFacilityLocationNetworks", "facilityLocationID")]
		public FacilityLocationNetworkLinkCollection Networks
		{
			get { return this.networks; }
			set
			{
				this.networks = value;
				value.ParentFacilityLocation = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Networks collection
		/// </summary>
		public void LoadNetworks(bool forceReload)
		{
			this.networks = (FacilityLocationNetworkLinkCollection)FacilityLocationNetworkLinkCollection.LoadChildCollection("Networks", this, typeof(FacilityLocationNetworkLinkCollection), networks, forceReload, null);
		}

		/// <summary>
		/// Saves the Networks collection
		/// </summary>
		public void SaveNetworks()
		{
			FacilityLocationNetworkLinkCollection.SaveChildCollection(this.networks, true);
		}

		/// <summary>
		/// Synchronizes the Networks collection
		/// </summary>
		public void SynchronizeNetworks()
		{
			FacilityLocationNetworkLinkCollection.SynchronizeChildCollection(this.networks, true);
		}

		/// <summary>
		/// Parent FacilityLocationCollection that contains this element
		/// </summary>
		public FacilityLocationCollection ParentFacilityLocationCollection
		{
			get
			{
				return this.parentFacilityLocationCollection;
			}
			set
			{
				this.parentFacilityLocationCollection = value; // parent is set when added to a collection
			}
		}

//		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
//		public System.DateTime ModifyTime
//		{
//			get { return this.modifyTime; }
//			set { this.modifyTime = value; }
//		}
//
//		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
//		public new System.DateTime EffectiveDate
//		{
//			get { return this.effectiveDate; }
//			set { this.effectiveDate = value; }
//		}
//
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public new System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

//		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
//		public new System.DateTime TerminateTime
//		{
//			get { return this.terminateTime; }
//			set { this.terminateTime = value; }
//		}
//
//		[ControlType(Macro=EnumControlTypeMacros.Int)]
//		public new int TerminatedBy
//		{
//			get { return this.terminatedBy; }
//			set { this.terminatedBy = value; }
//		}
//
//		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
//		public string AlternateID
//		{
//			get { return this.alternateID; }
//			set { this.alternateID = value; }
//		}

		/// <summary>
		/// Child FacilityLocationContacts mapped to related rows of table FacilityLocationContact where [FacilityLocationID] = [FacilityLocationID]
		/// </summary>
		[SPLoadChild("usp_LoadFacilityLocationContacts", "facilityLocationID")]
		public FacilityLocationContactCollection FacilityLocationContacts
		{
			get { return this.facilityLocationContacts; }
			set
			{
				this.facilityLocationContacts = value;
				if (value != null)
					value.ParentFacilityLocation = this; // set this as a parent of the child collection
			}
		}
		

		/// <summary>
		/// Loads the FacilityLocationContacts collection
		/// </summary>
		public void LoadFacilityLocationContacts(bool forceReload)
		{
			this.facilityLocationContacts = (FacilityLocationContactCollection)FacilityLocationContactCollection.LoadChildCollection("FacilityLocationContacts", this, typeof(FacilityLocationContactCollection), facilityLocationContacts, forceReload, null);
		}

		/// <summary>
		/// Saves the FacilityLocationContacts collection
		/// </summary>
		public void SaveFacilityLocationContacts()
		{
			FacilityLocationContactCollection.SaveChildCollection(this.facilityLocationContacts, true);
		}

		/// <summary>
		/// Synchronizes the FacilityLocationContacts collection
		/// </summary>
		public void SynchronizeFacilityLocationContacts()
		{
			FacilityLocationContactCollection.SynchronizeChildCollection(this.facilityLocationContacts, true);
		}


		#region IContactOwner Members

		public BaseDataCollectionClass GetContacts()
		{
			if (FacilityLocationContacts == null) LoadFacilityLocationContacts(false);
			return FacilityLocationContacts;
		}

		public void LoadContacts(bool forceLoad)
		{
			this.LoadFacilityLocationContacts(forceLoad);
		}

		public void SaveContacts()
		{
			this.SaveFacilityLocationContacts();
		}

		public ContactOwnerType ContactOwnerType
		{
			get
			{
				return ContactOwnerType.FacilityLocation;
			}
		}

		#endregion

//		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
//		public new string Notepad
//		{
//			get { return this.notepad; }
//			set { this.notepad = value; }
//		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{

			base.NewRecord();
			this.facilityID = 0;
			this.locationID	= 0;
			this.CreateTime	= DateTime.Now;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

	}

	/// <summary>
	/// Strongly typed collection of FacilityLocation objects
	/// </summary>
	[ElementType(typeof(FacilityLocation))]
	public class FacilityLocationCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(FacilityLocation elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentFacilityLocationCollection = this;
			else
				elem.ParentFacilityLocationCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (FacilityLocation elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public FacilityLocation this[int index]
		{
			get
			{
				return (FacilityLocation)List[index];
			}
			set
			{
				List[index] = value;
			}
		}
		
		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, ProviderLocation elem)
		{
			List.Insert(index, elem);		
		}
	

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((FacilityLocation)oldValue, false);
			SetParentOnElem((FacilityLocation)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(FacilityLocation elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((FacilityLocation)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(FacilityLocation elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((FacilityLocation)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int SPLoad(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}


		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Parent Facility that contains this collection
		/// </summary>
		public Facility ParentFacility
		{
			get { return this.ParentDataObject as Facility; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Facility */ }
		}

		public void LoadLocationsWithFilter(int FacilityID, Address Addr)
		{
			Facility fac = new Facility();
			fac.FacilityID = FacilityID;
			object [] prms = { Addr, fac};
			this.Clear();
			this.SqlData.SPExecReadCol("usp_LoadFacilityLocationWithFilter",-1,this, prms, true);
		}
	}
}
