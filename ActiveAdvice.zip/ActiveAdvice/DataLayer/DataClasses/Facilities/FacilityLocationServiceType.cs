using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [FacilityLocationServiceTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllFacilityServiceTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetFacilityLocationServiceTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertFacilityLocationServiceType")]
	[SPUpdate("usp_UpdateFacilityLocationServiceType")]
	[SPDelete("usp_DeleteFacilityLocationServiceType")]
	[SPLoad("usp_LoadFacilityLocationServiceType")]
	[TableMapping("FacilityLocationServiceType","facilityLocationServiceTypeID")]
	public class FacilityLocationServiceType : BaseLookupWithCode
	{
		[NonSerialized]
		private FacilityLocationServiceTypeCollection parentFacilityLocationServiceTypeCollection;
		[ColumnMapping("FacilityLocationServiceTypeID",(int)0)]
		private int facilityLocationServiceTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

	
		public FacilityLocationServiceType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@FACILITYLOCSERVICETYPE@")]
		public int FacilityLocationServiceTypeID
		{
			get { return this.facilityLocationServiceTypeID; }
			set { this.facilityLocationServiceTypeID = value; }
		}



		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int facilityLocationServiceTypeID)
		{
			return base.Load(facilityLocationServiceTypeID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int facilityLocationServiceTypeID)
		{
			base.Delete(facilityLocationServiceTypeID);		
		}

		/// <summary>
		/// Parent FacilityLocationServiceTypeCollection that contains this element
		/// </summary>
		public FacilityLocationServiceTypeCollection ParentFacilityLocationServiceTypeCollection
		{
			get
			{
				return this.parentFacilityLocationServiceTypeCollection;
			}
			set
			{
				this.parentFacilityLocationServiceTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of FacilityLocationServiceType objects
	/// </summary>
	[ElementType(typeof(FacilityLocationServiceType))]
	public class FacilityLocationServiceTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(FacilityLocationServiceType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentFacilityLocationServiceTypeCollection = this;
			else
				elem.ParentFacilityLocationServiceTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (FacilityLocationServiceType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public FacilityLocationServiceType this[int index]
		{
			get
			{
				return (FacilityLocationServiceType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((FacilityLocationServiceType)oldValue, false);
			SetParentOnElem((FacilityLocationServiceType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(FacilityLocationServiceType elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((FacilityLocationServiceType)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(FacilityLocationServiceType elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((FacilityLocationServiceType)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		public override void LoadAll()
		{
			SqlData.SPExecReadCol("usp_GetAllFacilityServiceTypes", -1, this, false);
		}


		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadFacilityLocationServiceTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetFacilityLocationServiceTypesByActive", maxRecords, this, false, new object [] { active });
		}

		/// <summary>
		/// Accessor to a shared FacilityLocationServiceTypeCollection which is cached in NSGlobal
		/// </summary>
		public static FacilityLocationServiceTypeCollection ActiveFacilityLocationServiceTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				FacilityLocationServiceTypeCollection col = (FacilityLocationServiceTypeCollection)NSGlobal.EnsureCachedObject("ActiveFacilityLocationServiceTypes", typeof(FacilityLocationServiceTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadFacilityLocationServiceTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Searches for Facility Service Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchFacilityLocationServiceTypes", -1, this, false, code, description, active);
		}

	}
}
