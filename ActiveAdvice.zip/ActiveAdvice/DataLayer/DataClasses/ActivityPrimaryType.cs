using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ActivityPrimaryType]
	/// </summary>
	[SPAutoGen("usp_SearchActivityPrimaryTypesByCodeDescriptionActive","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllActivityPrimaryTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllActivityPrimaryTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertActivityPrimaryType")]
	[SPUpdate("usp_UpdateActivityPrimaryType")]
	[SPDelete("usp_DeleteActivityPrimaryType")]
	[SPLoad("usp_LoadActivityPrimaryType")]
	[TableMapping("ActivityPrimaryType","activityPrimaryTypeID")]
	public class ActivityPrimaryType : BaseLookupStandard
	{
		[NonSerialized]
		private ActivityPrimaryTypeCollection parentActivityPrimaryTypeCollection;
		[ColumnMapping("ActivityPrimaryTypeID",StereoType=DataStereoType.FK)]
		private int activityPrimaryTypeID;
		[ColumnMapping("NotePad")]
		private string notePad;

		public static string INTERVENTION = "INTV";
	
		public ActivityPrimaryType()
		{

		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ActivityPrimaryTypeID
		{
			get { return this.activityPrimaryTypeID; }
			set { this.activityPrimaryTypeID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int activityPrimaryTypeID)
		{
			return base.Load(activityPrimaryTypeID);
		}

		/// <summary>
		/// Parent ActivityPrimaryTypeCollection that contains this element
		/// </summary>
		public ActivityPrimaryTypeCollection ParentActivityPrimaryTypeCollection
		{
			get
			{
				return this.parentActivityPrimaryTypeCollection;
			}
			set
			{
				this.parentActivityPrimaryTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ActivityPrimaryType objects
	/// </summary>
	[ElementType(typeof(ActivityPrimaryType))]
	public class ActivityPrimaryTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ActivityPrimaryType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentActivityPrimaryTypeCollection = this;
			else
				elem.ParentActivityPrimaryTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ActivityPrimaryType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ActivityPrimaryType this[int index]
		{
			get
			{
				return (ActivityPrimaryType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ActivityPrimaryType)oldValue, false);
			SetParentOnElem((ActivityPrimaryType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllActivityPrimaryTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllActivityPrimaryTypesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared ActivityPrimaryTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ActivityPrimaryTypeCollection ActiveActivityPrimaryTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ActivityPrimaryTypeCollection col = (ActivityPrimaryTypeCollection)NSGlobal.EnsureCachedObject("ActiveActivityPrimaryTypes", typeof(ActivityPrimaryTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllActivityPrimaryTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns ActivityPrimaryTypeID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_ActivityPrimaryTypeIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("ActivityPrimaryTypeID", code);
		}
	}
}
