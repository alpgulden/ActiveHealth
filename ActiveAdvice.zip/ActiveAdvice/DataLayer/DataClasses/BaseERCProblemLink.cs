using NetsoftUSA.DataLayer;
using System;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for BaseERCProblemLink.
	/// </summary>
	[TableMapping("Event","eventID")]
	public abstract class BaseERCProblemLink : BaseData
	{
		//[NonSerialized]
		//protected BaseERCProblemLinkCollection parentBaseERCProblemLinkCollection;
	
		public BaseERCProblemLink()
		{
			
		}

		public abstract int ERCId
		{
			get; //set;
		}

		public abstract int ProblemId
		{
			get; //set;
		}

		public abstract BaseERCProblemLinkCollection ParentBaseERCProblemLinkCollection
		{
			get; set;
		}
	}

	/// <summary>
	/// Strongly typed collection of BaseERCProblemLink objects
	/// This class is a base for Event/Referral/CMS - to Problems linkage
	/// Derrived collections should be loaded from corresponding linkage tables with 
	/// ERCid as a parameter, so collection will contain all problems for given ERC
	/// </summary>
	[ElementType(typeof(BaseERCProblemLink))]
	public abstract class BaseERCProblemLinkCollection : BaseDataCollection
	{
		
		public abstract void SynchronizeFromProblems(ProblemCollection problems);
		public abstract void DetermineLinkedProblems(ProblemCollection problems);
		public abstract void SetPrimaryProblem(Problem problem);
		

		/// <summary>
		/// Parent BaseForEventCMSReferral that contains this collection
		/// </summary>
		public BaseForEventCMSReferral ParentBaseForEventCMSReferral
		{
			get { return this.ParentDataObject as BaseForEventCMSReferral; }
			set { this.ParentDataObject = value; /* parent is set when contained by a BaseForEventCMSReferral */ }
		}
	}
}
