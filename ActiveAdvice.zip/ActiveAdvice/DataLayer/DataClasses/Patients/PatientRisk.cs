using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientLevelOfDisease]
	/// </summary>
	[SPInsert("usp_InsertPatientRisk")]
	[SPUpdate("usp_UpdatePatientRisk")]
	[SPDelete("usp_DeletePatientRisk")]
	[SPLoad("usp_LoadPatientRisk")]
	[SPAutoGen("usp_GetPatientRisksByAssessmentGUID","SelectAllByGivenArgs.sptpl","assessmentGUID")]
	[TableMapping("PatientRisk","patientRiskID")]
	public class PatientRisk : BaseData
	{
		[NonSerialized]
		private PatientRiskCollection parentPatientRiskCollection;
		[ColumnMapping("PatientRiskID",StereoType=DataStereoType.FK)]
		private int patientRiskID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("AssessmentGUID")]
		private string assessmentGUID;
		[ColumnMapping("AssessmentRiskID",StereoType=DataStereoType.FK)]
		private int assessmentRiskID;
		[ColumnMapping("CMSRiskID",StereoType=DataStereoType.FK)]
		private int cMSRiskID;
		[ColumnMapping("RiskDate")]
		private DateTime riskDate;
		[ColumnMapping("RiskDescription")]
		private string riskDescription;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreationTime")]
		private DateTime creationTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifiedTime")]
		private DateTime modifiedTime;
	
		public PatientRisk()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PatientRisk(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientRiskID
		{
			get { return this.patientRiskID; }
			set { this.patientRiskID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssessmentRiskID
		{
			get { return this.assessmentRiskID; }
			set { this.assessmentRiskID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSRiskID
		{
			get { return this.cMSRiskID; }
			set { this.cMSRiskID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime RiskDate
		{
			get { return this.riskDate; }
			set { this.riskDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=400)]
		public string RiskDescription
		{
			get { return this.riskDescription; }
			set { this.riskDescription = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreationTime
		{
			get { return this.creationTime; }
			set { this.creationTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifiedTime
		{
			get { return this.modifiedTime; }
			set { this.modifiedTime = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent PatientRiskCollection that contains this element
		/// </summary>
		public PatientRiskCollection ParentPatientRiskCollection
		{
			get
			{
				return this.parentPatientRiskCollection;
			}
			set
			{
				this.parentPatientRiskCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PatientRisk objects
	/// </summary>
	[ElementType(typeof(PatientRisk))]
	public class PatientRiskCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_AssessmentRiskID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientRisk elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientRiskCollection = this;
			else
				elem.ParentPatientRiskCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientRisk elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientRisk this[int index]
		{
			get
			{
				return (PatientRisk)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientRisk)oldValue, false);
			SetParentOnElem((PatientRisk)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPatientRisks(string assessmentGUID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientRisksByAssessmentGUID", -1, this, false, assessmentGUID);
		}

		/// <summary>
		/// Hashtable based index on assessmentRiskID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_AssessmentRiskID
		{
			get
			{
				if (this.indexBy_AssessmentRiskID == null)
					this.indexBy_AssessmentRiskID = new CollectionIndexer(this, new string[] { "assessmentRiskID" }, true);
				return this.indexBy_AssessmentRiskID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on assessmentRiskID fields returns the object.  Uses the IndexBy_AssessmentRiskID indexer.
		/// </summary>
		public PatientRisk FindBy(int assessmentRiskID)
		{
			return (PatientRisk)this.IndexBy_AssessmentRiskID.GetObject(assessmentRiskID);
		}


		public void ResetIndexers()
		{
			indexBy_AssessmentRiskID = null;
		}
	}
}
