using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// The Intake Log module is the typical initial entry point for Patient information into the ActiveAdvice system. 
	/// All incoming calls or requests are handled by the Intake staff and are entered into the Intake Log. 
	/// Every entry into the Intake log must have a resolution, a resolution being an Event, Note or Activity.
	/// </summary>
	[SPInsert("usp_InsertIntakeLog")]
	[SPUpdate("usp_UpdateIntakeLog")]
	[SPLoad("usp_LoadIntakeLog")]
	[TableMapping("IntakeLog","intakeLogID")]
	public class IntakeLog : BaseData
	{
		[ColumnMapping("IntakeLogID",(int)0)]
		private int intakeLogID;
		[ColumnMapping("ServiceDate")]
		private DateTime serviceDate;
		[ColumnMapping("CallerFName")]
		private string callerFName;
		[ColumnMapping("CallerLName")]
		private string callerLName;
		[ColumnMapping("CallerPhone")]
		private string callerPhone;
		[ColumnMapping("CallerPhoneExt")]
		private string callerPhoneExt;
		[ColumnMapping("CallerOrganization")]
		private string callerOrganization;
		[ColumnMapping("CallerRelation")]
		private string callerRelation;
		[ColumnMapping("PatientSSN",StereoType=DataStereoType.USSSN)]
		private string patientSSN;
		[ColumnMapping("PatientMemberID")]
		private string patientMemberID;
		[ColumnMapping("PatientFName")]
		private string patientFName;
		[ColumnMapping("PatientLName")]
		private string patientLName;
		[ColumnMapping("PatientMI")]
		private string patientMI;
		[ColumnMapping("SubscriberSSN",StereoType=DataStereoType.USSSN)]
		private string subscriberSSN;
		[ColumnMapping("SubscriberFName")]
		private string subscriberFName;
		[ColumnMapping("SubscriberLName")]
		private string subscriberLName;
		[ColumnMapping("SubscriberMI")]
		private string subscriberMI;
		[ColumnMapping("AuthID",StereoType=DataStereoType.FK)]
		private int authID;
		[ColumnMapping("AuthType")]
		private string authType;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("Notepad")]
		private string notepad;
		[ColumnMapping("PatientDOB")]
		private DateTime patientDOB;
		[ColumnMapping("PatientGender",StereoType=DataStereoType.Gender)]
		private string patientGender;
		[ColumnMapping("IntakeCallReasonID",StereoType=DataStereoType.FK)]
		private int intakeCallReasonID;
		[ColumnMapping("IntakeCallSourceID",StereoType=DataStereoType.FK)]
		private int intakeCallSourceID;
		[ColumnMapping("IntakeCallTypeID",StereoType=DataStereoType.FK)]
		private int intakeCallTypeID;
		[ColumnMapping("IntakeResolutionID",StereoType=DataStereoType.FK)]
		private int intakeResolutionID;
		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
		private int planID;
		[ColumnMapping("SORGId",StereoType=DataStereoType.FK)]
		private int sORGId;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		private int patientId;
		[ColumnMapping("SubscriberId",StereoType=DataStereoType.FK)]
		private int subscriberId;
		[ColumnMapping("EligibilityId",StereoType=DataStereoType.FK)]
		private int eligibilityId;
		[ColumnMapping("SubscriberMemberID")]
		private string subscriberMemberID;
	
		// Loaded and cached objects
		private Patient patient;		// patient linked to this intake log
		private Subscriber subscriber;	// subscriber linked to this intake log
		private Organization sorg;		// sorg linked to this intake log
		private Plan plan;				// plan linked to this intake log
		private PatientCoverage patientCoverage;	// the patient-coverage picked by subscriber search

		public IntakeLog()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public IntakeLog(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int IntakeLogID
		{
			get { return this.intakeLogID; }
			set { this.intakeLogID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate/*, IsRequired=true*/)]
		public System.DateTime ServiceDate
		{
			get { return this.serviceDate; }
			set { this.serviceDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		public string CallerFName
		{
			get { return this.callerFName; }
			set { this.callerFName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		public string CallerLName
		{
			get { return this.callerLName; }
			set { this.callerLName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=128)]
		public string CallerOrganization
		{
			get { return this.callerOrganization; }
			set { this.callerOrganization = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string CallerRelation
		{
			get { return this.callerRelation; }
			set { this.callerRelation = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string PatientFName
		{
			get { return this.patientFName; }
			set { this.patientFName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string PatientLName
		{
			get { return this.patientLName; }
			set { this.patientLName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string PatientMI
		{
			get { return this.patientMI; }
			set { this.patientMI = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string SubscriberFName
		{
			get { return this.subscriberFName; }
			set { this.subscriberFName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string SubscriberLName
		{
			get { return this.subscriberLName; }
			set { this.subscriberLName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string SubscriberMI
		{
			get { return this.subscriberMI; }
			set { this.subscriberMI = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AuthID
		{
			get { return this.authID; }
			set { this.authID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string AuthType
		{
			get { return this.authType; }
			set { this.authType = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PatientDOB
		{
			get { return this.patientDOB; }
			set { this.patientDOB = value; }
		}

		[FieldValuesMember("ValuesOf_Gender")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, MaxLength=1)]
		public string PatientGender
		{
			get { return this.patientGender; }
			set { this.patientGender = value; }
		}

		[FieldValuesMember("LookupOf_IntakeCallReasonID", "IntakeCallReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int IntakeCallReasonID
		{
			get { return this.intakeCallReasonID; }
			set { this.intakeCallReasonID = value; }
		}

		[FieldValuesMember("LookupOf_IntakeCallSourceID", "IntakeCallSourceID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int IntakeCallSourceID
		{
			get { return this.intakeCallSourceID; }
			set { this.intakeCallSourceID = value; }
		}

		[FieldValuesMember("LookupOf_IntakeCallTypeID", "IntakeCallTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int IntakeCallTypeID
		{
			get { return this.intakeCallTypeID; }
			set { this.intakeCallTypeID = value; }
		}

		[FieldValuesMember("LookupOf_IntakeResolutionID", "IntakeResolutionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int IntakeResolutionID
		{
			get { return this.intakeResolutionID; }
			set { this.intakeResolutionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanID
		{
			get { return this.planID; }
			set 
			{ 
				this.planID = value; 
				this.plan = null;			// cause reload of plan
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int SORGId
		{
			get { return this.sORGId; }
			set 
			{ 
				this.sORGId = value; 
				this.sorg = null;			// cause reload of sorg
			}
		}

		// dummy for EDIReader
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ORGId
		{
			get { return 0; }
			set { }
		}

		// dummy for EDIReader
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MORGId
		{
			get { return 0; }
			set { }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientId
		{
			get { return this.patientId; }
			set 
			{ 
				this.patientId = value;
				this.patient = null;				// cause reload of patient
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberId
		{
			get { return this.subscriberId; }
			set 
			{ 
				this.subscriberId = value; 
				this.subscriber = null;				// cause reload of subscriber
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EligibilityId
		{
			get { return this.eligibilityId; }
			set { this.eligibilityId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=15)]
		public string CallerPhone
		{
			get { return this.callerPhone; }
			set { this.callerPhone = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, MaxLength=5)]
		public string CallerPhoneExt
		{
			get { return this.callerPhoneExt; }
			set { this.callerPhoneExt = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USSSN)]
		public string PatientSSN
		{
			get { return this.patientSSN; }
			set 
			{ 
				this.patientSSN =  value ; 
				if (this.patientSSN != null)
					if (Formatting.RemoveChars(this.patientSSN, ' ', '-') == "")
						this.patientSSN = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.USSSN)]
		public string SubscriberSSN
		{
			get { return this.subscriberSSN; }
			set 
			{ 
				this.subscriberSSN =  value ; 
				if (this.subscriberSSN != null)
					if (Formatting.RemoveChars(this.subscriberSSN, ' ', '-') == "")
						this.subscriberSSN = null;
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string PatientMemberID
		{
			get { return this.patientMemberID; }
			set { this.patientMemberID = value; }
		}

		[FieldDescription("@ALTIDFORSUBS@")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string SubscriberMemberID
		{
			get { return this.subscriberMemberID; }
			set { this.subscriberMemberID = value; }
		}

		/// <summary>
		/// Intake log is called only to insert a new intake log.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="subscriber"></param>
		/// <param name="patientCoverage"></param>
		public void Save(Patient patient, Subscriber subscriber, PatientCoverage patientCoverage)
		{
			if (!this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "Intake Log cannot be updated!");
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Patient is required to save intake log");
			if (subscriber == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Subscriber is required to save intake log");
			if (patientCoverage == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "PatientCoverage is required to save intake log");

			// establish both in memory and fk relationships.
			this.patientCoverage = patientCoverage;
			this.Patient = patient;
			this.Subscriber = subscriber;
			this.Plan = patientCoverage.Plan;
			this.SORG = patientCoverage.SORG;

			base.Save();
		}

		/// <summary>
		/// Save a new intake log.
		/// This method assumes that the in-memory and fk relationships
		/// to patient, subscriber, sorg and the plan is already set.
		/// </summary>
		public new void Save()
		{
			if (!this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "Intake Log cannot be updated!");
			base.Save();
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int intakeLogID)
		{
			return base.Load(intakeLogID);
		}

		public IntakeCallTypeCollection LookupOf_IntakeCallTypeID
		{
			get
			{
				return IntakeCallTypeCollection.ActiveIntakeCallTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public IntakeResolutionCollection LookupOf_IntakeResolutionID
		{
			get
			{
				return IntakeResolutionCollection.ActiveIntakeResolutions; // Acquire a shared instance from the static member of collection
			}
		}

		public IntakeCallSourceCollection LookupOf_IntakeCallSourceID
		{
			get
			{
				return IntakeCallSourceCollection.IntakeCallSources; // Acquire a shared instance from the static member of collection
			}
		}

		public IntakeCallReasonCollection LookupOf_IntakeCallReasonID
		{
			get
			{
				return IntakeCallReasonCollection.ActiveIntakeCallReasons; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Loads and returns the associated patient.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientId == 0)
				return null;
			Patient patient = new Patient();
			if (patient.Load(this.patientId))
				return patient;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated subscriber.
		/// </summary>
		/// <returns></returns>
		public Subscriber GetSubscriber()
		{
			if (this.subscriberId == 0)
				return null;
			Subscriber subscriber = new Subscriber();
			if (subscriber.Load(this.subscriberId))
				return subscriber;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated SORG.
		/// </summary>
		/// <returns></returns>
		public Organization GetSORG()
		{
			if (this.sORGId == 0)
				return null;
			Organization sorg = new Organization();
			if (sorg.Load(this.sORGId))
				return sorg;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated Plan.
		/// </summary>
		/// <returns></returns>
		public Plan GetPlan()
		{
			if (this.planID == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.planID))
				return plan;
			else
				return null;
		}

		public PatientCoverage PatientCoverage
		{
			get { return this.patientCoverage; }
			set { this.patientCoverage = value; }
		}

		/// <summary>
		/// Loaded and cached patient.
		/// </summary>
		public Patient Patient
		{
			get
			{
				if (this.patient == null)
				{
					if (this.patient == null)
						this.patient = GetPatient();
				}
				return this.patient;
			}
			set
			{
				this.patient = value;
				if (value == null)
					this.patientId = 0;
				else
					this.patientId = patient.PatientId;
			}
		}

		/// <summary>
		/// Loaded and cached subsriber.
		/// </summary>
		public Subscriber Subscriber
		{
			get
			{
				if (this.subscriber == null)
					this.subscriber = this.GetSubscriber();
				return this.subscriber;
			}
			set
			{
				this.subscriber = value;
				if (value == null)
					this.subscriberId = 0;
				else
					this.subscriberId = subscriber.SubscriberId;
			}
		}

		/// <summary>
		/// Loaded and cached SORG
		/// </summary>
		public Organization SORG
		{
			get
			{
				if (this.sorg == null)
					this.sorg = this.GetSORG();
				return this.sorg;
			}
			set
			{
				if (value != null && !value.IsSubOrganization)
					throw new ActiveAdviceException(AAExceptionAction.None, "Only a sub-organization can be linked to IntakeLog");
				this.sorg = value;
				if (value == null)
					this.sORGId = 0;
				else
					this.sORGId = sorg.OrganizationID;
			}
		}

		/// <summary>
		/// Loaded and cached Plan
		/// </summary>
		public Plan Plan
		{
			get
			{
				if (this.plan == null)
					this.plan = GetPlan();
				return this.plan;
			}
			set
			{
				this.plan = value;
				if (value == null)
					this.planID = 0;
				else
					this.planID = plan.PlanId;
			}
		}

		public string SubscriberLastName
		{
			get { return this.Subscriber.LastName; }
		}

		public string SubscriberFirstName
		{
			get { return this.Subscriber.FirstName; }
		}

		[FieldDescription("@SUBSCRIBERNAME@")]
		public string SubscriberFullName
		{
			get { return this.Subscriber.Fmt_FullName; }
		}

		public string PlanName
		{
			get 
			{
				if (this.Plan == null)
					return null;				// no plan.
				return this.Plan.Name; 
			}
		}

		[FieldDescription("@PATIENTNAME@")]
		public string PatientFullName
		{
			get { return this.Patient.Fmt_FullName; }
		}

		public string Fmt_CallerFullName
		{
			get { return this.callerLName + ", " + this.callerFName; }
		}

		public void PullPatientInfo()
		{
			if (this.Patient == null)
				return;
			this.patientSSN = this.Patient.SocialSecurityNumber;
			this.patientFName = this.Patient.FirstName;
			this.patientLName = this.Patient.LastName;
		}

		public void PullSubsriberInfo()
		{
			if (this.Subscriber == null)
				return;
			this.subscriberSSN = this.Subscriber.SocialSecurityNumber;
			this.subscriberFName = this.Subscriber.FirstName;
			this.subscriberLName = this.Subscriber.LastName;
		}

		public void PullFirstMatchingSubscriberInfo()
		{
			if (this.Patient == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Intake has no patient to look for coverages");
			// search for subscriber using patienid, subscriber ssn, and subscriber last name
			PatientCoverageCollection patCovs = new PatientCoverageCollection();
			patCovs.SearchCoveragesOfPatient(this.Patient, this.subscriberSSN, this.SubscriberLName);
			if (patCovs.Count > 0)
			{
				// Use the first coverage to get the subscriber.
				this.PatientCoverage = patCovs[0];
				this.Subscriber = this.patientCoverage.Subscriber;
				this.SORG = this.patientCoverage.SORG;
				this.Plan = this.patientCoverage.Plan;
				this.PullSubsriberInfo();				// set the first name and last name
			}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			//writer.AddLabelandValue("@INTAKELOG@", ControlTypeAttribute.GetMemberValueAsString(this, "IntakeLogID"));
			writer.AddFieldsSubstituted(this, "@Fmt_CallerFullName@", "@CALLERINFO@");
			writer.AddField(this, "ServiceDate");
			writer.StartNewLineInSection();
			if (this.Patient != null)
				writer.AddField(this, "PatientFullName");
			if (this.Subscriber != null)
				writer.AddField(this, "SubscriberFullName");
		}

	}
}
