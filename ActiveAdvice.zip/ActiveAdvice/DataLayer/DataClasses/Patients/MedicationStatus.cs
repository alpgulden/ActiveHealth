using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [MedicationStatus]
	/// </summary>
	[SPAutoGen("usp_GetAllMedicationStatusCodes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetMedicationStatusCodesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertMedicationStatus")]
	[SPUpdate("usp_UpdateMedicationStatus")]
	[SPDelete("usp_DeleteMedicationStatus")]
	[SPLoad("usp_LoadMedicationStatus")]
	[TableMapping("MedicationStatus","codeID")]
	public class MedicationStatus : BaseLookupWithCode
	{
		[NonSerialized]
		private MedicationStatusCollection parentMedicationStatusCollection;
		[ColumnMapping("CodeID",StereoType=DataStereoType.FK)]
		private int codeID;
	
		public MedicationStatus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CodeID
		{
			get { return this.codeID; }
			set { this.codeID = value; }
		}

		/// <summary>
		/// Parent MedicationStatusCollection that contains this element
		/// </summary>
		public MedicationStatusCollection ParentMedicationStatusCollection
		{
			get
			{
				return this.parentMedicationStatusCollection;
			}
			set
			{
				this.parentMedicationStatusCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of MedicationStatus objects
	/// </summary>
	[ElementType(typeof(MedicationStatus))]
	public class MedicationStatusCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_CodeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MedicationStatus elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMedicationStatusCollection = this;
			else
				elem.ParentMedicationStatusCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MedicationStatus elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MedicationStatus this[int index]
		{
			get
			{
				return (MedicationStatus)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MedicationStatus)oldValue, false);
			SetParentOnElem((MedicationStatus)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadMedicationStatusCodesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetMedicationStatusCodesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared MedicationStatusCollection which is cached in NSGlobal
		/// </summary>
		public static MedicationStatusCollection ActiveMedicationStatusCodes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				MedicationStatusCollection col = (MedicationStatusCollection)NSGlobal.EnsureCachedObject("ActiveMedicationStatusCodes", typeof(MedicationStatusCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadMedicationStatusCodesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on codeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_CodeID
		{
			get
			{
				if (this.indexBy_CodeID == null)
					this.indexBy_CodeID = new CollectionIndexer(this, new string[] { "codeID" }, true);
				return this.indexBy_CodeID;
			}
			
		}

		/// <summary>
		/// Looks up by codeID and returns Code value.  Uses the IndexBy_CodeID indexer.
		/// </summary>
		public string Lookup_CodeByCodeID(int codeID)
		{
			return this.IndexBy_CodeID.LookupStringMember("Code", codeID);
		}

	}
}
