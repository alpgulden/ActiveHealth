using System;
using System.Diagnostics;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	/// <summary>
	/// Data class that wraps the entity access functionality to table [Patients]
	/// 
	/// A Patient is a person in need of the health services that AHM and its clients provide. 
	/// The information required to provide services to a patient comes from a variety of sources.
	/// Full or partial patient information may be provided by "external data feeds". Patient 
	/// information may also be collected by a manual process of "eliciting the information" 
	/// from the "patient" or their "care provider". Patient may also be provided by the 
	/// "Client" with the "eligibility information".
	/// To determine if a patient is eligible for services, eligibility information is required. 
	/// 
	/// The patient may be "eligible" through "subscription in a healthcare plan", or by 
	/// "relation to a subscriber". The Health Plan Provider may provide information indicating 
	/// that a subscriber is eligible for services. In cases where this information is not 
	/// provided, services may optionally be rendered to the patient without eligibility 
	/// verification.
	/// 
	/// The Patient record contains demographic information that is required to uniquely 
	/// identify a patient. In addition, Patient records contain additional information that 
	/// provides patient-specific health information such as Medications, Allergies and 
	/// Measurements (i.e. Blood Pressure, height/weight, etc.).
	/// 
	/// </summary>
	[SPInsert("usp_InsertPatient")]
	[SPUpdate("usp_UpdatePatient")]
	[SPDelete("usp_DeletePatient")]
	[SPLoad("usp_LoadPatient")]
	[SPAutoGen("usp_SearchPatients","SearchByArgs.sptpl","patientId, firstName, lastName, socialSecurityNumber, dateOfBirth")]
	[TableMapping("Patient","patientId")]
	public class Patient : BaseDataWithUserDefined, IContactOwner
	{
		[NonSerialized]
		private PatientCollection parentPatientCollection;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		private int patientId;
		[ColumnMapping("LastName")]
		private string lastName;
		[ColumnMapping("FirstName")]
		private string firstName;
		[ColumnMapping("MiddleInitial")]
		private string middleInitial;
		[ColumnMapping("NamePrefixId",StereoType=DataStereoType.FK)]
		private int namePrefixId;
		[ColumnMapping("NameSuffix")]
		private string nameSuffix;
		[ColumnMapping("Gender",StereoType=DataStereoType.Gender)]
		private string gender;
		[ColumnMapping("DateOfBirth")]
		private DateTime dateOfBirth;
		[ColumnMapping("SocialSecurityNumber",StereoType=DataStereoType.USSSN)]
		private string socialSecurityNumber;
		//private Byte[] socialSecurityNumber;
		[ColumnMapping("AddressID")]
		private int addressID;
		[ColumnMapping("LanguageID",StereoType=DataStereoType.FK)]
		private int languageID;
		[ColumnMapping("AssignedTeamId",StereoType=DataStereoType.FK)]
		private int assignedTeamId;
		[ColumnMapping("AssignedUserId",StereoType=DataStereoType.FK)]
		private int assignedUserId;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("PrimaryCOBId",StereoType=DataStereoType.FK)]
		private int primaryCOBId;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("MedicareID")]
		private string medicareID;
		[ColumnMapping("MedicaidID")]
		private string medicaidID;
		[ColumnMapping("RelatedEventID",StereoType=DataStereoType.FK)]
		private int relatedEventID;
		[ColumnMapping("RelatedProblemID",StereoType=DataStereoType.FK)]
		private int relatedProblemID;

		//[ColumnMapping("AsOfDate", SQLGen=SQLGenerationFlags.NoInsert | SQLGenerationFlags.NoUpdate | SQLGenerationFlags.NoSelect, InjectSearch="{0} > @{1}")]
		//private DateTime asOfDateStart;
		/*[ColumnMapping("AsOfDate", SQLGen=SQLGenerationFlags.NoInsert | SQLGenerationFlags.NoUpdate | SQLGenerationFlags.NoSelect, InjectSearch="{0} < @{1}")]
		private DateTime asOfDateEnd;*/

		private Address address;
		private PatientContactCollection patientContacts;
		private PatientFocusHistoryCollection patientFocusHistory;
		private PatientCOBCollection patientCOBs;
		private PatientProblemCollection patientProblems;
		private PatientMedicationCollection patientMedications;
		private PatientAllergyCollection patientAllergies;
		private PatientMeasurementCollection patientMeasurements;
		private PatientCoverageCollection patientCoverages;
		private Event mostRecentEvent;

		//private PatientProblem selectedPatientProblem;				// child items in the hiearchy may use this.

		//private DateTime termDateWhenLoaded;
	
		public Patient()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Patient(string firstName, string lastName, string gender)
		{
			this.NewRecord(); // initialize record state
			this.firstName = firstName;
			this.lastName = lastName;
			this.gender = gender;
		}

		public Patient(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/*/// <summary>
		/// Used to keep the current problem context. Save of child items may use this.
		/// </summary>
		public PatientProblem SelectedPatientProblem
		{
			get { return this.selectedPatientProblem; }
			set { this.selectedPatientProblem = value; }
		}*/

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		[FieldDescription("@LASTNAME@")]
		public string LastName
		{
			get { return this.lastName; }
			set { this.lastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@FIRSTNAME@")]
		public string FirstName
		{
			get { return this.firstName; }
			set { this.firstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		[FieldDescription("@MIDDLEINITIAL@")]
		public string MiddleInitial
		{
			get { return this.middleInitial; }
			set { this.middleInitial = value; }
		}

		[FieldValuesMember("LookupOf_NamePrefixId", "NamePrefixId", "Prefix")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@NAMEPREFIX@")]
		public int NamePrefixId
		{
			get { return this.namePrefixId; }
			set { this.namePrefixId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		[FieldDescription("@NAMESUFFIX@")]
		public string NameSuffix
		{
			get { return this.nameSuffix; }
			set { this.nameSuffix = value; }
		}

		[FieldValuesMember("ValuesOf_Gender")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, MaxLength=1)]
		[FieldDescription("@GENDER@")]
		public string Gender
		{
			get { return this.gender; }
			set { this.gender = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DATEOFBIRTH@")]
		public System.DateTime DateOfBirth
		{
			get { return this.dateOfBirth; }
			set { this.dateOfBirth = value; }
		}

		[FieldValuesMember("LookupOf_LanguageID", "LanguageID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@LANGUAGE@")]
		public int LanguageID
		{
			get { return this.languageID; }
			set { this.languageID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@ASSIGNEDTEAM@")]
		public int AssignedTeamId
		{
			get { return this.assignedTeamId; }
			set { this.assignedTeamId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@ASSIGNEDUSER@")]
		public int AssignedUserId
		{
			get { return this.assignedUserId; }
			set { this.assignedUserId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USSSN)]
		[FieldDescription("@SOCIALSECURITY@")]
		public string SocialSecurityNumber
		{
			get { return this.socialSecurityNumber; }
			set 
			{ 
				this.socialSecurityNumber =  value ; 
				if (this.socialSecurityNumber != null)
					if (Formatting.RemoveChars(this.socialSecurityNumber, ' ', '-') == "")
						this.socialSecurityNumber = null;
			}
			//get { return DecryptSSN(this.socialSecurityNumber); }
			//set { this.socialSecurityNumber = EncryptSSN(value); }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SavePatientFocusHistory();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch(Exception ex)
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				Debug.WriteLine(ex);
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientId)
		{
			return base.Load(patientId);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			//this.effectiveDate = DateTime.Today;
			this.addressID = 0;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}

		/// <summary>
		/// Contained Address object
		/// </summary>
		[Contained]
		public Address Address
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.address = (Address)Address.EnsureContainedDataObject(this, typeof(Address), address, false, addressID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.address;
			}
			set
			{
				this.address = value;
				if (value != null) value.ParentPatient = this; // set this as a parent of the child data class
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			//termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to load child and other objects that must be loaded with this object.
		/// </summary>
		protected override bool InternalLoad(params object[] keys)
		{
			// Do pre-load operations here.
			bool result = base.InternalLoad(keys);
			// Do post-load operations here.
			return result;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			this.Address.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			{
				base.InternalSave();	// in that case, delete the base first
				Address.MarkDel();	// then allow the deletion of the conatined object
			}
			Address.IsNew = this.IsNew;	// make sure the contained object is new if the containing object is new
			Address.Save();
			this.addressID = Address.AddressID; // set the fk if the contained object was newly created
			/*if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}*/

			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Indirect access to the LanguageID.  You can set/get a language code 
		/// instead of language id.
		/// </summary>
		/*[ControlType(Macro=EnumControlTypeMacros.StringLookup, IsRequired=true)]
		public string LanguageCode
		{
			get { return LanguageCollection.ActiveLanguages.Lookup_LanguageCode_By_LanguageID(this.languageID); }
			set { this.languageID = LanguageCollection.ActiveLanguages.Lookup_LanguageID_By_LanguageCode(value); }
		}*/

		public NamePrefixCollection LookupOf_NamePrefixId
		{
			get
			{
				return NamePrefixCollection.ActiveNamePrefixes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Parent PatientCollection that contains this element
		/// </summary>
		public PatientCollection ParentPatientCollection
		{
			get
			{
				return this.parentPatientCollection;
			}
			set
			{
				this.parentPatientCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, IsRequired=true)]
		public string LanguageCode
		{
			get { return LanguageCollection.ActiveLanguages.Lookup_LanguageCodeByLanguageID(this.languageID); }
			set { this.languageID = LanguageCollection.ActiveLanguages.Lookup_LanguageIDByLanguageCode(value); }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PrimaryCOBId
		{
			get { return this.primaryCOBId; }
			set { this.primaryCOBId = value; }
		}

		/// <summary>
		/// Child PatientContacts mapped to related rows of table PatientContact where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientContact", "patientID")]
		public PatientContactCollection PatientContacts
		{
			get { return this.patientContacts; }
			set
			{
				this.patientContacts = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientContacts collection
		/// </summary>
		public void LoadPatientContacts(bool forceReload)
		{
			this.patientContacts = (PatientContactCollection)PatientContactCollection.LoadChildCollection("PatientContacts", this, typeof(PatientContactCollection), patientContacts, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientContacts collection
		/// </summary>
		public void SavePatientContacts()
		{
			PatientContactCollection.SaveChildCollection(this.patientContacts, true);
		}

		/// <summary>
		/// Synchronizes the PatientContacts collection
		/// </summary>
		public void SynchronizePatientContacts()
		{
			PatientContactCollection.SynchronizeChildCollection(this.patientContacts, true);
		}
		
		#region IContactOwner Members

		public BaseDataCollectionClass GetContacts()
		{
			if (PatientContacts == null) LoadPatientContacts(false);
			return PatientContacts;
		}

		public void LoadContacts(bool forceLoad)
		{
			this.LoadPatientContacts(forceLoad);
		}

		public void SaveContacts()
		{
			this.SavePatientContacts();
		}

		public ContactOwnerType ContactOwnerType
		{
			get
			{
				return ContactOwnerType.Patient;
			}
		}

		#endregion

		public LanguageCollection LookupOf_LanguageID
		{
			get
			{
				return LanguageCollection.ActiveLanguages; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(EnumControlTypes.TextBox|EnumControlTypes.ComboBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@NAME@")]
		public string Fmt_FullName
		{
			get { return this.lastName + ", " + this.firstName; }
		}

		[FieldDescription("@AGE@")]
		public string AgeYearMonths
		{
			get
			{
				if (this.dateOfBirth == DateTime.MinValue)
					return "@UNKNOWN@";
				int years = 0, months = 0;
				CalculateYearsMonths(this.dateOfBirth, DateTime.Today, ref years, ref months);
				return String.Format("{0} @YEARS@ {1} @MOS@", years, months);
			}
		}

		[FieldDescription("@AGE@")]
		public int AgeYears
		{
			get
			{
				return CalculateYears(this.dateOfBirth, DateTime.Today);
			}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			writer.AddFieldsSubstituted(this, "@PatientId@-@Fmt_FullName@", Messages.PatientMessages.MessageIDs.PATIENTSUMMARY);
			writer.AddFieldsOnNewLine(this, "SocialSecurityNumber", "Gender");
			writer.AddFieldsOnNewLine(this, "DateOfBirth", "AgeYearMonths");
		}

		/// <summary>
		/// Child PatientFocusHistory mapped to related rows of table PatientFocusHistory where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientFocusHistory", "patientID")]
		public PatientFocusHistoryCollection PatientFocusHistory
		{
			get { return this.patientFocusHistory; }
			set
			{
				this.patientFocusHistory = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientFocusHistory collection
		/// </summary>
		public void LoadPatientFocusHistory(bool forceReload)
		{
			this.patientFocusHistory = (PatientFocusHistoryCollection)PatientFocusHistoryCollection.LoadChildCollection("PatientFocusHistory", this, typeof(PatientFocusHistoryCollection), patientFocusHistory, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientFocusHistory collection
		/// </summary>
		public void SavePatientFocusHistory()
		{
			PatientFocusHistoryCollection.SaveChildCollection(this.patientFocusHistory, true);
		}

		/// <summary>
		/// Synchronizes the PatientFocusHistory collection
		/// </summary>
		public void SynchronizePatientFocusHistory()
		{
			PatientFocusHistoryCollection.SynchronizeChildCollection(this.patientFocusHistory, true);
		}

		/// <summary>
		/// Child PatientCOBs mapped to related rows of table PatientCOB where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientCOBs", "patientID")]
		public PatientCOBCollection PatientCOBs
		{
			get { return this.patientCOBs; }
			set
			{
				this.patientCOBs = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientCOBs collection
		/// </summary>
		public void LoadPatientCOBs(bool forceReload)
		{
			this.patientCOBs = (PatientCOBCollection)PatientCOBCollection.LoadChildCollection("PatientCOBs", this, typeof(PatientCOBCollection), patientCOBs, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientCOBs collection
		/// </summary>
		public void SavePatientCOBs()
		{
			PatientCOBCollection.SaveChildCollection(this.patientCOBs, true);
		}

		/// <summary>
		/// Synchronizes the PatientCOBs collection
		/// </summary>
		public void SynchronizePatientCOBs()
		{
			PatientCOBCollection.SynchronizeChildCollection(this.patientCOBs, true);
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		/// <summary>
		/// Child PatientProblems mapped to related rows of table PatientProblem where [PatientId] = [PatientId]
		/// </summary>
		[SPLoadChild("usp_LoadPatientProblems", "patientId")]
		public PatientProblemCollection PatientProblems
		{
			get { return this.patientProblems; }
			set
			{
				this.patientProblems = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientProblems collection
		/// </summary>
		public void LoadPatientProblems(bool forceReload)
		{
			this.patientProblems = (PatientProblemCollection)PatientProblemCollection.LoadChildCollection("PatientProblems", this, typeof(PatientProblemCollection), patientProblems, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientProblems collection
		/// </summary>
		public void SavePatientProblems()
		{
			PatientProblemCollection.SaveChildCollection(this.patientProblems, true);
		}

		/// <summary>
		/// Synchronizes the PatientProblems collection
		/// </summary>
		public void SynchronizePatientProblems()
		{
			PatientProblemCollection.SynchronizeChildCollection(this.patientProblems, true);
		}


		/// <summary>
		/// Returns the actual collection of problems linked to this patient.
		/// </summary>
		/// <returns></returns>
		public ProblemCollection GetLinkedProblems()
		{
			ProblemCollection problems = new ProblemCollection();
			problems.LoadLinkedPatientProblems(this);
			return problems;
		}
		
		/// <summary>
		/// Returns the actual collection of events linked to this patient.
		/// </summary>
		/// <returns></returns>
		public EventCollection GetLinkedEvents()
		{
			EventCollection events = new EventCollection();
			events.LoadLinkedPatientEvents(this);
			return events;
		}

		/// <summary>
		/// Returns the actual collection of CMS linked to this patient.
		/// </summary>
		/// <returns></returns>
		public CMSCollection GetLinkedCMSs()
		{
			CMSCollection cmss = new CMSCollection();
			cmss.LoadLinkedPatientCMSs(this);
			return cmss;
		}

		/// <summary>
		/// Returns the actual collection of Referrals linked to this patient.
		/// </summary>
		/// <returns></returns>
		public ReferralCollection GetLinkedReferrals()
		{
			ReferralCollection referrals = new ReferralCollection();
			referrals.LoadLinkedPatientReferrals(this);
			return referrals;
		}

		/// <summary>
		/// Gets a collection of an ERC (event/referrral/cms type data objects).
		/// </summary>
		/// <param name="ercType"></param>
		/// <returns></returns>
		public BaseCollectionForEventCMSReferral GetLinkedERCs(EnumERCType ercType)
		{
			switch (ercType)
			{
				/*case EnumERCType.All:
				{
					BaseCollectionForEventCMSReferral all = new BaseCollectionForEventCMSReferral();
					all.AppendToCollection(GetLinkedEvents());			// append events
					all.AppendToCollection(GetLinkedReferrals());		// append referrals
					all.AppendToCollection(GetLinkedCMSs());			// append CMSs.
					return all;
				}*/
				case EnumERCType.Event:
				{
					return GetLinkedEvents();
				}
				case EnumERCType.CMS:
				{
					return GetLinkedCMSs();
				}
				case EnumERCType.Referral:
				{
					return GetLinkedReferrals();
				}
			}
			throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Invalid ERC Type asked from Patient.GetLinkedERCs");
		}

		/// <summary>
		/// Child PatientMedications mapped to related rows of table PatientMedication where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientPatientMedication", "patientID")]
		public PatientMedicationCollection PatientMedications
		{
			get { return this.patientMedications; }
			set
			{
				this.patientMedications = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientMedications collection
		/// </summary>
		public void LoadPatientMedications(bool forceReload)
		{
			this.patientMedications = (PatientMedicationCollection)PatientMedicationCollection.LoadChildCollection("PatientMedications", this, typeof(PatientMedicationCollection), patientMedications, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientMedications collection
		/// </summary>
		public void SavePatientMedications()
		{
			PatientMedicationCollection.SaveChildCollection(this.patientMedications, true);
		}

		/// <summary>
		/// Synchronizes the PatientMedications collection
		/// </summary>
		public void SynchronizePatientMedications()
		{
			PatientMedicationCollection.SynchronizeChildCollection(this.patientMedications, true);
		}

		/// <summary>
		/// Child PatientAllergies mapped to related rows of table PatientAllergy where [PatientId] = [PatientId]
		/// </summary>
		[SPLoadChild("usp_LoadPatientPatientAllergy", "patientId")]
		public PatientAllergyCollection PatientAllergies
		{
			get { return this.patientAllergies; }
			set
			{
				this.patientAllergies = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientAllergies collection
		/// </summary>
		public void LoadPatientAllergies(bool forceReload)
		{
			this.patientAllergies = (PatientAllergyCollection)PatientAllergyCollection.LoadChildCollection("PatientAllergies", this, typeof(PatientAllergyCollection), patientAllergies, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientAllergies collection
		/// </summary>
		public void SavePatientAllergies()
		{
			PatientAllergyCollection.SaveChildCollection(this.patientAllergies, true);
		}

		/// <summary>
		/// Synchronizes the PatientAllergies collection
		/// </summary>
		public void SynchronizePatientAllergies()
		{
			PatientAllergyCollection.SynchronizeChildCollection(this.patientAllergies, true);
		}

		/// <summary>
		/// Child PatientMeasurements mapped to related rows of table PatientMeasurement where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientPatientMeasurement", "patientID")]
		public PatientMeasurementCollection PatientMeasurements
		{
			get { return this.patientMeasurements; }
			set
			{
				this.patientMeasurements = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientMeasurements collection
		/// </summary>
		public void LoadPatientMeasurements(bool forceReload)
		{
			this.patientMeasurements = (PatientMeasurementCollection)PatientMeasurementCollection.LoadChildCollection("PatientMeasurements", this, typeof(PatientMeasurementCollection), patientMeasurements, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientMeasurements collection
		/// </summary>
		public void SavePatientMeasurements()
		{
			PatientMeasurementCollection.SaveChildCollection(this.patientMeasurements, true);
		}

		/// <summary>
		/// Synchronizes the PatientMeasurements collection
		/// </summary>
		public void SynchronizePatientMeasurements()
		{
			PatientMeasurementCollection.SynchronizeChildCollection(this.patientMeasurements, true);
		}

		/// <summary>
		/// Child PatientCoverages mapped to related rows of table PatientCoverage where [PatientId] = [PatientID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientCoverages", "patientID")]
		public PatientCoverageCollection PatientCoverages
		{
			get { return this.patientCoverages; }
			set
			{
				this.patientCoverages = value;
				if (value != null)
					value.ParentPatient = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientCoverages collection
		/// </summary>
		public void LoadPatientCoverages(bool forceReload)
		{
			this.patientCoverages = (PatientCoverageCollection)PatientCoverageCollection.LoadChildCollection("PatientCoverages", this, typeof(PatientCoverageCollection), patientCoverages, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientCoverages collection
		/// </summary>
		public void SavePatientCoverages()
		{
			PatientCoverageCollection.SaveChildCollection(this.patientCoverages, true);
		}

		/// <summary>
		/// Synchronizes the PatientCoverages collection
		/// </summary>
		public void SynchronizePatientCoverages()
		{
			PatientCoverageCollection.SynchronizeChildCollection(this.patientCoverages, true);
		}

		/// <summary>
		/// Load and return a collection of patient coverages from the database.
		/// </summary>
		/// <returns></returns>
		public PatientCoverageCollection GetPatientCoverages()
		{
			PatientCoverageCollection patCovCol = new PatientCoverageCollection();
			patCovCol.LoadPatientCoverages(-1, this.patientId, 0);
			if (patCovCol.Count == 0)
				return null;
			else
				return patCovCol;
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MedicareID
		{
			get { return this.medicareID; }
			set { this.medicareID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MedicaidID
		{
			get { return this.medicaidID; }
			set { this.medicaidID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RelatedEventID
		{
			get { return this.relatedEventID; }
			set { this.relatedEventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RelatedProblemID
		{
			get { return this.relatedProblemID; }
			set { this.relatedProblemID = value; }
		}

		/// <summary>
		/// Get the most recent event of this patient
		/// </summary>
		/// <returns></returns>
		public Event GetMostRecentEvent()
		{
			if (this.IsNew)
				return null;
			Event mostRecentEvent = new Event();
			if (mostRecentEvent.LoadMostRecentEventForPatient(this))
				return mostRecentEvent;
			else
				return null;
		}

		/// <summary>
		/// Loaded and cached most recent event
		/// </summary>
		public Event MostRecentEvent
		{
			get
			{
				if (mostRecentEvent == null)
					mostRecentEvent = GetMostRecentEvent();
				return mostRecentEvent;
			}
		}
		}

	/// <summary>
	/// Strongly typed collection of Patient objects
	/// </summary>
	[ElementType(typeof(Patient))]
	public class PatientCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass//, ICollectionElementFilter
	{
		/*private string filterState = null;		// if this is set, the collection can be filtered by state
		public string FilterState
		{	
			get { return this.filterState; }
			set { this.filterState = value; }
		}*/

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Patient elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientCollection = this;
			else
				elem.ParentPatientCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Patient elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Patient this[int index]
		{
			get
			{
				return (Patient)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Patient)oldValue, false);
			SetParentOnElem((Patient)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Search for patients and load the collection.
		/// </summary>
		public int SearchPatients(int maxRecords, Patient searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchPatients", maxRecords, this, new object[] { searcher }, false);
		}

		/*#region ICollectionElementFilter Members

		public bool FilterElement(int index)
		{
			return (filterState == null) || (this[index].Address.State == filterState);
		}

		#endregion*/
	}



}
