using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientCoverages]
	/// PatientCoverage is a linkage between [Patient], [Subscriber], [Plan] and SORG
	/// Patient may have multiple PatientCoverage's and
	/// Subscriber may have multiple PatientCoverage's too.
	/// This class provides an easy method of accessing the linked objects.
	/// If have a Patient object, you can access Patient.PatientCoverages
	/// collection.  And from any of the PatientCoverage element of this collection
	/// you can ask for the Subscriber object.  But it is not contained by PatientCoverage.
	/// For example :  Patient.PatientCoverages[0].GetSubscriberCoverage()
	/// or :  Subscriber.PatientCoverages[0].GetPatient()
	/// but not :  Patient.PatientCoverages[0].Subscriber.
	/// This object is not responsible for containing and persisting Patient, Subscriber, Plan or SORG
	/// objects.
	/// 
	/// Manual SPs:  usp_SearchCoveragesOfPatient
	/// </summary>
	[SPAutoGen("usp_GetPatientCoveragesByAlternateID","SelectAllByGivenArgs.sptpl","alternatePatientID")]
	[SPAutoGen("usp_GetPatientCoveragesByPatientEligibilityID","SelectAllByGivenArgs.sptpl","patientEligibilityID")]
	[SPInsert("usp_InsertPatientCoverage")]
	[SPUpdate("usp_UpdatePatientCoverage")]
	[SPDelete("usp_DeletePatientCoverage")]
	[SPLoad("usp_LoadPatientCoverage")]
	[SPAutoGen("usp_GetPatientCoverageByIDs","SelectAllByGivenArgs.sptpl","patientID, subscriberID, sORGID, planID")]
	[SPAutoGen("usp_GetPatientCoveragesByPatientIDSubscriberID","SearchByArgs.sptpl","patientID, subscriberID", InjectOrderBy="ORDER BY [PatientCoverage].[PatientCoverageID] DESC")]
	[TableMapping("PatientCoverage","patientCoverageID")]
	public class PatientCoverage : BaseData
	{
		[NonSerialized]
		private PatientCoverageCollection parentPatientCoverageCollection;
		[ColumnMapping("PatientCoverageID",StereoType=DataStereoType.FK)]
		private int patientCoverageID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("SubscriberID",StereoType=DataStereoType.FK)]
		private int subscriberID;
		[ColumnMapping("SORGID",StereoType=DataStereoType.FK)]
		private int sORGID;
		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
		private int planID;
		[ColumnMapping("RelationShipID",StereoType=DataStereoType.FK)]
		private int relationShipID;
		[ColumnMapping("IsPrimary")]
		private bool isPrimary;
		[ColumnMapping("AlternatePatientID")]
		private string alternatePatientID;
		[ColumnMapping("AlternateGroupID")]
		private string alternateGroupID;
		[ColumnMapping("AlternateInsuranceID")]
		private string alternateInsuranceID;
		[ColumnMapping("AlternateSubscriberID")]
		private string alternateSubscriberID;
		[ColumnMapping("PatientEligibilityID",StereoType=DataStereoType.FK)]
		private int patientEligibilityID;
		[ColumnMapping("SubscriberEligibilityID",StereoType=DataStereoType.FK)]
		private int subscriberEligibilityID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

		// The Patient-SubscriberCoverage relationship never gets updated
		// So we can keep object references
		private Patient patient;		// the parent patient
		private Subscriber subscriber;	// subscriber linked to the subscriber-coverage
		private Organization sorg;		// sorg linked to the subscriber-coverage
		private Plan plan;

		private PatientCoverageData latestCoverageData;
		private PatientCoveragePCPCollection patientCoveragePCPs;
	
		public PatientCoverage()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Use this constructor when you want to create a link between a specific [Patient],
		/// [Subscriber], SORG and [Plan]
		/// </summary>
		public PatientCoverage(Patient patient, Subscriber subscriber, Organization sORG, Plan plan)
		{
			this.NewRecord(); // initialize record state
			SetRelationship(patient, subscriber, sORG, plan);
		}

		/// <summary>
		/// Use this constructor when you want to create a link between a specific [Patient] and
		/// [Subscriber]
		/// </summary>
		public PatientCoverage(Patient patient, Subscriber subscriber)
		{
			this.NewRecord(); // initialize record state
			SetRelationship(patient, subscriber);
		}

		/// <summary>
		/// Use this constructor when you want to create the Plan and SORG
		/// linkage at first.  The rest of the linkage must be completed later.
		/// </summary>
		public PatientCoverage(Organization sORG, Plan plan)
		{
			this.NewRecord(); // initialize record state
			SetRelationship(sORG, plan);
		}

		public PatientCoverage(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/// <summary>
		/// The relationship can only be established in using objects.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="subscriber"></param>
		/// <param name="sORG"></param>
		/// <param name="plan"></param>
		public void SetRelationship(Patient patient, Subscriber subscriber, Organization sORG, Plan plan)
		{
			SetRelationship(patient, subscriber);

			if (sORG == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "SORG not specified for PatientCoverage");
			if (plan == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Plan not specified for PatientCoverage");

			// Create a link
			this.sORGID = sORG.OrganizationID;
			this.sorg = sORG;

			this.planID = plan.PlanId;
			this.plan = plan;
		}

		/// <summary>
		/// The relationship can only be established in using objects.
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="subscriber"></param>
		public void SetRelationship(Patient patient, Subscriber subscriber)
		{
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Patient not specified for PatientCoverage");
			if (subscriber == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Subscriber not specified for PatientCoverage");

			// Create a link
			this.patientID = patient.PatientId;
			this.patient = patient;

			this.subscriberID = subscriber.SubscriberId;
			this.subscriber = subscriber;
		}

		/// <summary>
		/// The relationship can only be established in using objects.
		/// </summary>
		/// <param name="plan"></param>
		/// <param name="sORG"></param>
		public void SetRelationship(Organization sORG, Plan plan)
		{
			if (plan == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "Plan not specified for PatientCoverage");
			if (sORG == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "SORG not specified for PatientCoverage");

			// Create a link
			this.planID = plan.PlanId;
			this.plan = plan;

			this.sORGID = sORG.OrganizationID;
			this.sorg = sORG;
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientCoverageId)
		{
			return base.Load(patientCoverageId);
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads and returns the associated patient.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientID == 0)
				return null;
			Patient patient = new Patient();
			if (patient.Load(this.patientID))
				return patient;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated subscriber.
		/// </summary>
		/// <returns></returns>
		public Subscriber GetSubscriber()
		{
			if (this.subscriberID == 0)
				return null;
			Subscriber subscriber = new Subscriber();
			if (subscriber.Load(this.subscriberID))
				return subscriber;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated SORG.
		/// </summary>
		/// <returns></returns>
		public Organization GetSORG()
		{
			if (this.sORGID == 0)
				return null;
			Organization sorg = new Organization();
			if (sorg.Load(this.sORGID))
				return sorg;
			else
				return null;
		}

		/// <summary>
		/// Loads and returns the associated Plan.
		/// </summary>
		/// <returns></returns>
		public Plan GetPlan()
		{
			if (this.planID == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.planID))
				return plan;
			else
				return null;
		}

		/// <summary>
		/// Returns the linked patient object.  This was either passed
		/// in the constructor, or it's loaded from the Patient table.
		/// </summary>
		public Patient Patient
		{
			get
			{
				if (this.patient == null)
				{
					if (this.parentPatientCoverageCollection != null)
						this.patient = this.parentPatientCoverageCollection.ParentPatient;
					if (this.patient == null)
						this.patient = GetPatient();
				}
				return this.patient;
			}
		}

		/// <summary>
		/// Subscriber object indirectly linked to SubscriberCoverage
		/// </summary>
		public Subscriber Subscriber
		{
			get
			{
				if (this.subscriber == null)
					this.subscriber = this.GetSubscriber();
				return this.subscriber;
			}
		}

		/// <summary>
		/// SORG object indirectly linked to SubscriberCoverage
		/// </summary>
		public Organization SORG
		{
			get
			{
				if (this.sorg == null)
					this.sorg = this.GetSORG();
				return this.sorg;
			}
		}

		/// <summary>
		/// Returns the linked plan object.  This was either passed
		/// in the constructor, or it's loaded from the plan table.
		/// </summary>
		public Plan Plan
		{
			get
			{
				if (this.plan == null)
				{
					this.plan = GetPlan();
				}
				return this.plan;
			}
		}

		/*/// <summary>
		/// Returns plan's id linked thru SubscriberCoverage
		/// </summary>
		public int PlanId
		{
			get
			{
				if (this.Plan == null)
					return 0;
				else
					return this.Plan.PlanId;
			}
		}

		/// <summary>
		/// Returns the linked SubscriberCoverage's SORGId.
		/// The SORG that the coverage is linked to.
		/// </summary>
		public int SORGId
		{
			get
			{
				if (this.SORG == null)
					return 0;
				else
					return this.SORG.OrganizationID;
			}
		}*/

		

		[FieldValuesMember("LookupOf_RelationShipID", "RelationshipId", "RelationshipName")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int RelationShipID
		{
			get { return this.relationShipID; }
			set { this.relationShipID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientEligibilityID
		{
			get { return this.patientEligibilityID; }
			set { this.patientEligibilityID = value; }
		}

		public RelationshipTypeCollection LookupOf_RelationShipID
		{
			get
			{
				return RelationshipTypeCollection.ActiveRelationshipTypes; // Acquire a shared instance from the static member of collection
			}
		}
		
		[FieldDescription("@LASTNAME@")]
		public string SubscriberLastName
		{
			get { return this.Subscriber.LastName; }
		}

		[FieldDescription("@FIRSTNAME@")]
		public string SubscriberFirstName
		{
			get { return this.Subscriber.FirstName; }
		}

		[FieldDescription("@SUBSCRIBERNAME@")]
		public string SubscriberFullName
		{
			get { return this.Subscriber.Fmt_FullName; }
		}

		public string PlanName
		{
			get 
			{
				if (this.Plan == null)
					return null;				// no plan.
				return this.Plan.Name; 
			}
		}

		[FieldDescription("@PATIENTNAME@")]
		public string PatientFullName
		{
			get { return this.Patient.Fmt_FullName; }
		}

		/// <summary>
		/// Load this object from db by the given patient id and subscriber coverage id
		/// </summary>
		public bool Load(int patientId, int subscriberId, int sORGID, int planID)
		{
			return SqlData.SPExecReadObj("usp_GetPatientCoverageByIDs", this, false, 
				patientId, subscriberId, sORGID, planID);
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			writer.AddField(this, "SubscriberFullName", Messages.PatientMessages.MessageIDs.SUBSCRIBERNAME );
			writer.AddField(this, "PlanName", Messages.PatientMessages.MessageIDs.PLANNAME );
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			//set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SubscriberID
		{
			get { return this.subscriberID; }
			//set { this.subscriberID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0, IsRequired=true)]
		public int SORGID
		{
			get { return this.sORGID; }
			set 
			{ 
				this.sORGID = value; 
				this.sorg = null;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0, IsRequired=true)]
		public int PlanID
		{
			get { return this.planID; }
			set 
			{ 
				this.planID = value; 
				this.plan = null;
			}
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IsPrimary
		{
			get { return this.isPrimary; }
			set { this.isPrimary = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternatePatientID
		{
			get { return this.alternatePatientID; }
			set { this.alternatePatientID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateGroupID
		{
			get { return this.alternateGroupID; }
			set { this.alternateGroupID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateInsuranceID
		{
			get { return this.alternateInsuranceID; }
			set { this.alternateInsuranceID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateSubscriberID
		{
			get { return this.alternateSubscriberID; }
			set { this.alternateSubscriberID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SubscriberEligibilityID
		{
			get { return this.subscriberEligibilityID; }
			set { this.subscriberEligibilityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		/// <summary>
		/// Parent PatientCoverageCollection that contains this element
		/// </summary>
		public PatientCoverageCollection ParentPatientCoverageCollection
		{
			get
			{
				return this.parentPatientCoverageCollection;
			}
			set
			{
				this.parentPatientCoverageCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientCoverageID
		{
			get { return this.patientCoverageID; }
			set { this.patientCoverageID = value; }
		}

		/// <summary>
		/// Returns the latest coverage in history (PatientCoverageData).
		/// If this record is new, a new one is automatically created.
		/// </summary>
		public PatientCoverageData LatestCoverageData
		{
			get
			{
				if (this.latestCoverageData == null)
				{
					if (this.IsNew || this.IsNewlyInsertedInDB)
						this.latestCoverageData = null;
					else
						this.latestCoverageData = GetLatestCoverageData();

					// if nothing was found, just create new history entry
					if (this.latestCoverageData == null)
						this.latestCoverageData = new PatientCoverageData(this);
				}

				return this.latestCoverageData;
			}
		}

		/// <summary>
		/// Load the latest PatientCoverageData record for this PatientCoverage
		/// and return it.
		/// </summary>
		/// <returns></returns>
		public PatientCoverageData GetLatestCoverageData()
		{
			PatientCoverageData lasestCovData = new PatientCoverageData();
			if (lasestCovData.LoadLatest(this.patientCoverageID))
				return lasestCovData;
			else
				return null;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			if (!this.IsMarkedForDeletion)
			{
				if (this.patientID == 0)
					throw new ActiveAdviceException(AAExceptionAction.None, "Can't save the PatientCoverage without a patient id");

				if (this.subscriberID == 0)
					throw new ActiveAdviceException(AAExceptionAction.None, "Can't save the PatientCoverage without a subscriber id");

				if (this.planID == 0)
					throw new ActiveAdviceException(AAExceptionAction.None, "Can't save the PatientCoverage without a plan id");
				
				if (this.SORG == null)
					throw new ActiveAdviceException(AAExceptionAction.None, "Can't save the PatientCoverage without a SORG");
				if (!this.SORG.IsSubOrganization)
					throw new ActiveAdviceException(AAExceptionAction.None, "Organization {0} is not a SORG", this.SORG.OrganizationID);

				if (this.relationShipID == 0)
					throw new ActiveAdviceException(AAExceptionAction.None, "RelationshipID was not specified for this PatientCoverage");
			}

			base.InternalSave();
			// Save the child collections here.
			SavePatientCoveragePCPs();		// save the patient coverage PCPs.

			KeepCoverageHistoryData();
		}

		/// <summary>
		/// This will check if a new record is needed into the subscriber coverage history
		/// and will create a history entry if necessary.
		/// </summary>
		private void KeepCoverageHistoryData()
		{
			PatientCoverageData history = this.LatestCoverageData;
			if (history.IsNew)
			{
				history.SqlData.Transaction = this.SqlData.Transaction;
				history.PatientCoverageID = this.patientCoverageID;
				history.Save();
			}
			else
			{
				// updating
				// save only if the history was changed
				PatientCoverageData latestInDB = this.GetLatestCoverageData();
				if (latestInDB == null || !latestInDB.EqualsMappedMembers(history, false))
				{
					// there's a change, or there was no log entry in the db so far.
					history = (PatientCoverageData)history.Clone();
					history.SqlData.Transaction = this.SqlData.Transaction;
					history.Save();
				}
			}
		}

		/// <summary>
		/// Child PatientCoveragePCPs mapped to related rows of table PatientCoveragePCP where [PatientCoverageID] = [PatientCoverageID]
		/// </summary>
		[SPLoadChild("usp_LoadPatientCoveragePCPs", "patientCoverageID")]
		public PatientCoveragePCPCollection PatientCoveragePCPs
		{
			get { return this.patientCoveragePCPs; }
			set
			{
				this.patientCoveragePCPs = value;
				if (value != null)
					value.ParentPatientCoverage = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PatientCoveragePCPs collection
		/// </summary>
		public void LoadPatientCoveragePCPs(bool forceReload)
		{
			this.patientCoveragePCPs = (PatientCoveragePCPCollection)PatientCoveragePCPCollection.LoadChildCollection("PatientCoveragePCPs", this, typeof(PatientCoveragePCPCollection), patientCoveragePCPs, forceReload, null);
		}

		/// <summary>
		/// Saves the PatientCoveragePCPs collection
		/// </summary>
		public void SavePatientCoveragePCPs()
		{
			PatientCoveragePCPCollection.SaveChildCollection(this.patientCoveragePCPs, true);
		}

		/// <summary>
		/// Synchronizes the PatientCoveragePCPs collection
		/// </summary>
		public void SynchronizePatientCoveragePCPs()
		{
			PatientCoveragePCPCollection.SynchronizeChildCollection(this.patientCoveragePCPs, true);
		}

		/// <summary>
		/// Imports the Eligibility PCPs into PatientCoveragePCPs.
		/// Called from AvailableCoverage.EnsurePatientCoverageFromEligibility.
		/// 
		/// USE CASE ID: UC3.7
		/// TITLE: UPDATE COVERAGE PROVIDER DATA
		/// REQUIREMENT ID: 1.8.4.5
		/// Step 1.b.ii
		/// 
		/// </summary>
		/// <param name="eligibility"></param>
		public void ImportPatientCoveragePCPsFromEligibility(CoverageSelectionContext coverageSelectionContext, Eligibility eligibility)
		{
			EligibilityPCPCollection eligPCPCol = eligibility.GetAllEligibilityPCPs(this.planID);
			if (eligPCPCol == null)
			{
				coverageSelectionContext.AddToMessageLog("There's no EligibilityPCP record for EligibilityID:{0}, PlanID:{1}", eligibility.EligibilityId, this.planID);
				return;		// Nothing to import
			}

			this.LoadPatientCoveragePCPs(false);

			coverageSelectionContext.AddToMessageLog("Importing EligibilityPCP records for EligibilityID:{0}, PlanID:{1}", eligibility.EligibilityId, this.planID);
			for (int i = 0; i < eligPCPCol.Count; i++)
			{
				EligibilityPCP eligPCP = eligPCPCol[i];
				PatientCoveragePCP patCovPCP = new PatientCoveragePCP(true);

				// copy members from eligibility PCP
				patCovPCP.EffectiveDate = eligPCP.EffectiveDate;
				patCovPCP.TerminationDate = eligPCP.TerminationDate;
				patCovPCP.AsOfDate = eligPCP.AsOfDate;
				if (eligPCP.ProviderLocation != null)
					patCovPCP.ProviderLocationID = eligPCP.ProviderLocation.LocationID;// ProviderLocationID;
				patCovPCP.ProviderSpecialtyTypeID = eligPCP.PCPSpecialtyID;
				patCovPCP.Status = eligPCP.Status;		// not network status

				this.PatientCoveragePCPs.Add(patCovPCP);
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of PatientCoverage objects
	/// </summary>
	[ElementType(typeof(PatientCoverage))]
	public class PatientCoverageCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientCoverage elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientCoverageCollection = this;
			else
				elem.ParentPatientCoverageCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientCoverage elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientCoverage this[int index]
		{
			get
			{
				return (PatientCoverage)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientCoverage)oldValue, false);
			SetParentOnElem((PatientCoverage)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Patient that contains this collection
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.ParentDataObject as Patient; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}

		/// <summary>
		/// Load patient coverages for the given patient and subscriber
		/// </summary>
		public int LoadPatientCoverages(int maxRecords, int patientID, int subscriberID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientCoveragesByPatientIDSubscriberID", maxRecords, this, false,
				SQLDataDirect.MakeDBValue(patientID, (int)0),
				SQLDataDirect.MakeDBValue(subscriberID, (int)0) );
		}

		/// <summary>
		/// Load patient coverages for the given patient and subscriber
		/// </summary>
		public int LoadPatientCoverages(int maxRecords, Patient patient, Subscriber subscriber)
		{
			return LoadPatientCoverages(maxRecords, patient.PatientId, subscriber.SubscriberId);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPatientCoveragesByPatientEligibilityID(int maxRecords, int patientEligibilityID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientCoveragesByPatientEligibilityID", maxRecords, this, false, new object[] { patientEligibilityID });
		}

		/// <summary>
		/// Load patient coverages by the given alternate ID
		/// </summary>
		public int LoadPatientCoveragesByAlternateID(int maxRecords, string alternatePatientID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientCoveragesByAlternateID", maxRecords, this, false, new object[] { alternatePatientID });
		}

		/// <summary>
		/// Search the coverage of a patient by SSN and last name.  Used by Intake.
		/// </summary>
		public int SearchCoveragesOfPatient(Patient patient, string subscriberSSN, string subscriberLName)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchCoveragesOfPatient", -1, this, false, 
				new object[] 
					{	patient.PatientId,
						SQLDataDirect.MakeDBValue(subscriberSSN),
						SQLDataDirect.MakeDBValue(subscriberLName)
					});
		}

	}

}
