using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientAllergy]
	/// </summary>
	[SPInsert("usp_InsertPatientAllergy")]
	[SPUpdate("usp_UpdatePatientAllergy")]
	[SPDelete("usp_DeletePatientAllergy")]
	[SPLoad("usp_LoadPatientAllergy")]
	[TableMapping("PatientAllergy","allergyId")]
	public class PatientAllergy : BaseData
	{
		[NonSerialized]
		private PatientAllergyCollection parentPatientAllergyCollection;
		[ColumnMapping("AllergyId",StereoType=DataStereoType.FK)]
		private int allergyId;
		[ColumnMapping("PatientId")]
		private int patientId;
		[ColumnMapping("AllergyDescription")]
		private string allergyDescription;
		[ColumnMapping("Reaction")]
		private string reaction;
		[ColumnMapping("HowLong")]
		private string howLong;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public PatientAllergy()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PatientAllergy(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int AllergyId
		{
			get { return this.allergyId; }
			set { this.allergyId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		[FieldDescription("@DESCRIPTION@")]
		public string AllergyDescription
		{
			get { return this.allergyDescription; }
			set { this.allergyDescription = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		[FieldDescription("@REACTION@")]
		public string Reaction
		{
			get { return this.reaction; }
			set { this.reaction = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		[FieldDescription("@HOWLONG@")]
		public string HowLong
		{
			get { return this.howLong; }
			set { this.howLong = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@MODIFYBY@")]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int allergyId)
		{
			return base.Load(allergyId);
		}

		/// <summary>
		/// Parent PatientAllergyCollection that contains this element
		/// </summary>
		public PatientAllergyCollection ParentPatientAllergyCollection
		{
			get
			{
				return this.parentPatientAllergyCollection;
			}
			set
			{
				this.parentPatientAllergyCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PatientAllergy objects
	/// </summary>
	[ElementType(typeof(PatientAllergy))]
	public class PatientAllergyCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientAllergy elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientAllergyCollection = this;
			else
				elem.ParentPatientAllergyCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientAllergy elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientAllergy this[int index]
		{
			get
			{
				return (PatientAllergy)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientAllergy)oldValue, false);
			SetParentOnElem((PatientAllergy)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PatientAllergy elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PatientAllergy)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(PatientAllergy elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((PatientAllergy)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Parent Patient that contains this collection
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.ParentDataObject as Patient; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
	}
}
