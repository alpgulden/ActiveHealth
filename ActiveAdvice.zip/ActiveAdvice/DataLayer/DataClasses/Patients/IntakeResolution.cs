using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [IntakeResolution]
	/// </summary>
	[SPInsert("usp_InsertIntakeResolution")]
	[SPUpdate("usp_UpdateIntakeResolution")]
	[SPDelete("usp_DeleteIntakeResolution")]
	[SPLoad("usp_LoadIntakeResolution")]
	[SPAutoGen("usp_GetIntakeResolutionsByActive","SelectAllByGivenArgs.sptpl","active")]
	[TableMapping("IntakeResolution","intakeResolutionID")]
	public class IntakeResolution : BaseLookupStandard
	{
		[NonSerialized]
		private IntakeResolutionCollection parentIntakeResolutionCollection;
		[ColumnMapping("IntakeResolutionID",(int)0)]
		private int intakeResolutionID;
		[ColumnMapping("ResolutionAction")]
		private string resolutionAction;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public IntakeResolution()
		{

			//
			// TODO: Add constructor logic here
			//
		}

		public IntakeResolution(string code, string description, string resolutionAction)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
			this.resolutionAction = resolutionAction;
		}

		public IntakeResolution(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int IntakeResolutionID
		{
			get { return this.intakeResolutionID; }
			set { this.intakeResolutionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=500)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=128)]
		public string ResolutionAction
		{
			get { return this.resolutionAction; }
			set { this.resolutionAction = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Parent IntakeResolutionCollection that contains this element
		/// </summary>
		public IntakeResolutionCollection ParentIntakeResolutionCollection
		{
			get
			{
				return this.parentIntakeResolutionCollection;
			}
			set
			{
				this.parentIntakeResolutionCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int intakeResolutionID)
		{
			return base.Load(intakeResolutionID);
		}
	}

	/// <summary>
	/// Strongly typed collection of IntakeResolution objects
	/// </summary>
	[ElementType(typeof(IntakeResolution))]
	public class IntakeResolutionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns IntakeResolutionID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_IntakeResolutionIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("IntakeResolutionID", code);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadIntakeResolutionsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetIntakeResolutionsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(IntakeResolution elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentIntakeResolutionCollection = this;
			else
				elem.ParentIntakeResolutionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (IntakeResolution elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public IntakeResolution this[int index]
		{
			get
			{
				return (IntakeResolution)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((IntakeResolution)oldValue, false);
			SetParentOnElem((IntakeResolution)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Accessor to a shared IntakeResolutionCollection which is cached in NSGlobal
		/// </summary>
		public static IntakeResolutionCollection ActiveIntakeResolutions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				IntakeResolutionCollection col = (IntakeResolutionCollection)NSGlobal.EnsureCachedObject("ActiveIntakeResolutions", typeof(IntakeResolutionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadIntakeResolutionsByActive(-1, true);
				}
				return col;
			}
		}
	}
}
