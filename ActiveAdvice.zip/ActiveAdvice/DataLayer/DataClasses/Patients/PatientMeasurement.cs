using System;

using NetsoftUSA.DataLayer;
using System.Collections;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientMeasurement]
	/// </summary>
	[SPInsert("usp_InsertPatientMeasurement")]
	[SPUpdate("usp_UpdatePatientMeasurement")]
	[SPDelete("usp_DeletePatientMeasurement")]
	[SPLoad("usp_LoadPatientMeasurement")]
	[SPAutoGen("usp_GetPatientMeasurementsByAssessmentGUID","SelectAllByGivenArgs.sptpl","assessmentGUID")]
	[TableMapping("PatientMeasurement","patientMeasurementID")]
	public class PatientMeasurement : BaseData
	{
		[NonSerialized]
		private PatientMeasurementCollection parentPatientMeasurementCollection;
		[ColumnMapping("PatientMeasurementID",StereoType=DataStereoType.FK)]
		private int patientMeasurementID;
		[ColumnMapping("MeasurementTypeID",StereoType=DataStereoType.FK)]
		private int measurementTypeID;
		[ColumnMapping("MeasurementTypeFFRM")]
		private string measurementTypeFFRM;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("MeasurementValue")]
		private string measurementValue;
		[ColumnMapping("MeasurementDate")]
		private DateTime measurementDate;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("AssessmentGUID")]
		private string assessmentGUID;
		[ColumnMapping("AssessmentMeasurementID",StereoType=DataStereoType.FK)]
		private int assessmentMeasurementID;

		private double measurementValueDouble;
		private MeasurementType measurementType;		
	
		public PatientMeasurement()
		{
		}

		public PatientMeasurement(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int PatientMeasurementID
		{
			get { return this.patientMeasurementID; }
			set { this.patientMeasurementID = value; }
		}

		[FieldDescription("@MEASUREMENT@")]
		public string MeasurementTypeDisplayOnly
		{
			get
			{
				if (this.MeasurementTypeID > 0)
					return MeasurementTypeCollection.ActiveMeasurementTypes.Lookup_DescriptionByCodeId(this.measurementTypeID);
				else
					return this.measurementTypeFFRM;
			}
		}
		
		[FieldValuesMember("LookupOf_MeasurementTypeID", "CodeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@MEASUREMENT@")]
		public int MeasurementTypeID
		{
			get 
			{
				if(this.measurementTypeID > 0)
					this.measurementType = new MeasurementType(this.measurementTypeID);
				else
				{
					this.measurementType = new MeasurementType();
					this.measurementType.PickList = false;
				}
				return this.measurementTypeID; 
			}
			set 
			{ 
				this.measurementTypeID = value; 
				if (value > 0)
					this.measurementType = new MeasurementType(value);
				else
				{
					this.measurementType = new MeasurementType();
					this.measurementType.PickList = false;
				}
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=200)]
		public string MeasurementTypeFFRM
		{
			get { return this.measurementTypeFFRM; }
			set { this.measurementTypeFFRM = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		
		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@RESULTS@")]
		public string MeasurementValue
		{
			get 
			{ 
				if(!this.isDirty)
					SetMeasurementValueDouble();
				
				//return String.Format("{0:0.##}", this.measurementValue); 
				return this.measurementValue; 
			}
			set 
			{ 
				this.measurementValue = value; 	
				SetMeasurementValueDouble();
			}
		}

		private void SetMeasurementValueDouble()
		{
			if(this.measurementValue == null)
			{
				this.measurementValueDouble = 0;
				return;
			}
			try
			{
				this.measurementValueDouble = Double.Parse(this.measurementValue);
			}
			catch(Exception ex)
			{
				this.measurementValueDouble = 0;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public double MeasurementValueDouble
		{
			get { return this.measurementValueDouble; }
		}

		[FieldValuesMember("LookupOf_PickingListValue", "PLValue", "PLValue")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@RESULTS@")]
		public int PickingListValue
		{
			get { return (int)this.measurementValueDouble;}
			set 
			{ 
				if(this.MeasurementTypeFFRM == null && !this.MeasurementType.PickList)
				{
					this.measurementValueDouble = (int)value;
					this.measurementValue = value.ToString();
				}
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		[FieldDescription("@NORMALS@")]
		public string Normals
		{
			get
			{
				if(this.measurementTypeID == 0 || !MeasurementType.PickList)
					return "";
				if(MeasurementType.NormalLow != 0 & MeasurementType.NormalHigh != 0)
				{
					return MeasurementType.NormalLow.ToString() +
						   " - " +
						   MeasurementType.NormalHigh.ToString();
				}
				return "";
			}
		}

		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@RANGE@")]
		public bool Range
		{ // return TRUE if value is outside of Range for specific Measurement Type
			get
			{
				if(this.measurementTypeID == 0 || MeasurementType.PickList == false)
					return false;
				string tmp = this.MeasurementValue; // this will set pm.MeasurementValueDouble
				if(this.measurementValueDouble == 0 
					|| MeasurementType.RangeLow == 0 || MeasurementType.RangeHigh == 0)
					return false;
				if(this.measurementValueDouble < MeasurementType.RangeLow
					| this.measurementValueDouble > MeasurementType.RangeHigh)
					return true;
				else
					return false;
			}
		}
		
		[FieldDescription("@UNITMEASURE@")]
		public string UnitOfMeasure
		{
			get { return MeasurementType.UnitOfMeasureText; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		[FieldDescription("@DATEMEASURED@")]
		public System.DateTime MeasurementDate
		{
			get { return this.measurementDate; }
			set { this.measurementDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@MODIFYTIME@")]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@MODIFYBY@")]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssessmentMeasurementID
		{
			get { return this.assessmentMeasurementID; }
			set { this.assessmentMeasurementID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		[FieldDescription("@INSTRUCTIONTEXT@")]
		public string NotePad
		{
			get 
			{ 
				return this.MeasurementType.NotePad;
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientMeasurementID)
		{
			return base.Load(patientMeasurementID);
		}

		/// <summary>
		/// Parent PatientMeasurementCollection that contains this element
		/// </summary>
		public PatientMeasurementCollection ParentPatientMeasurementCollection
		{
			get
			{
				return this.parentPatientMeasurementCollection;
			}
			set
			{
				this.parentPatientMeasurementCollection = value; // parent is set when added to a collection
			}
		}

		public MeasurementTypeCollection LookupOf_MeasurementTypeID
		{
			get
			{
				return MeasurementTypeCollection.ActiveMeasurementTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Contained MeasurementType object
		/// </summary>
		public MeasurementType MeasurementType
		{
			get
			{
				return this.measurementType;
			}
			set
			{
				this.measurementType = value;
			}
		}

		public MeasurementTypePickListCollection LookupOf_PickingListValue
		{
			get
			{
				this.MeasurementType.LoadMeasurementTypePickLists(false);
				return this.MeasurementType.MeasurementTypePickLists;
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PatientMeasurement objects
	/// </summary>
	[ElementType(typeof(PatientMeasurement))]
	public class PatientMeasurementCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		private int measurementTypeID;

		[NonSerialized]
		private CollectionIndexer indexBy_AssessmentMeasurementID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientMeasurement elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientMeasurementCollection = this;
			else
				elem.ParentPatientMeasurementCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientMeasurement elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientMeasurement this[int index]
		{
			get
			{
				return (PatientMeasurement)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientMeasurement)oldValue, false);
			SetParentOnElem((PatientMeasurement)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PatientMeasurement elem)
		{
			return AddRecord(elem);
		}

		public void ResetIndexers()
		{
			indexBy_AssessmentMeasurementID = null;
		}

		public override int AddRecord(BaseDataClass data)
		{
			int ret = base.AddRecord (data);
			ResetIndexers();
			return ret;
		}
		
		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PatientMeasurement)value, true);
			base.OnInsertComplete (index, value);		
		}


		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((PatientMeasurement)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Parent Patient that contains this collection
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.ParentDataObject as Patient; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}

		public int SelectedMeasurementTypeID
		{
			get { return measurementTypeID; }
			set { measurementTypeID = value;}
		}

		public bool DrawGraph(int typeId, ref ArrayList yValues, ref ArrayList xValues)
		{
			if (typeId == 0)
				return false;
			foreach(PatientMeasurement pm in this)
			{
				string tmp = pm.MeasurementValue; // this will set pm.MeasurementValueDouble
				if(pm.MeasurementTypeID == typeId & pm.MeasurementValueDouble > 0 
				   & pm.MeasurementDate > DateTime.MinValue)
				{
					yValues.Add(pm.MeasurementValueDouble);
					xValues.Add(pm.MeasurementDate);
				}
			}
			return true;
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPatientMeasurements(string assessmentGUID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientMeasurementsByAssessmentGUID", -1, this, false, assessmentGUID);
		}

		/// <summary>
		/// Hashtable based index on assessmentMeasurementID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_AssessmentMeasurementID
		{
			get
			{
				if (this.indexBy_AssessmentMeasurementID == null)
					this.indexBy_AssessmentMeasurementID = new CollectionIndexer(this, new string[] { "assessmentMeasurementID" }, true);
				return this.indexBy_AssessmentMeasurementID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on assessmentMeasurementID fields returns the object.  Uses the IndexBy_AssessmentMeasurementID indexer.
		/// </summary>
		public PatientMeasurement FindBy(int assessmentMeasurementID)
		{
			return (PatientMeasurement)this.IndexBy_AssessmentMeasurementID.GetObject(assessmentMeasurementID);
		}

		/// <summary>
		/// Sorts the collection by the measurementDate members.
		/// </summary>
		public void SortBy_MeasurementDate(bool ascending, bool ignoreCase)
		{
			CollectionUtil.SortBy(this, ascending, ignoreCase, new string[] { "measurementDate" });		
		}


	}
}
