using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientFocusHistory]
	/// </summary>
	[SPInsert("usp_InsertPatientFocusHistory")]
	[SPUpdate("usp_UpdatePatientFocusHistory")]
	[SPDelete("usp_DeletePatientFocusHistory")]
	[SPLoad("usp_LoadPatientFocusHistory")]
	[TableMapping("PatientFocusHistory","patientFocusHistoryID")]
	public class PatientFocusHistory : BaseData
	{
		[NonSerialized]
		private PatientFocusHistoryCollection parentPatientFocusHistoryCollection;
		[ColumnMapping("PatientFocusHistoryID",StereoType=DataStereoType.FK)]
		private int patientFocusHistoryID;
		[ColumnMapping("PatientFocusID",StereoType=DataStereoType.FK)]
		private int patientFocusID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("Active")]
		private bool active = true;
		[ColumnMapping("Description")]
		private string description;
	
		public PatientFocusHistory()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PatientFocusHistory(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public PatientFocusHistory(int patientFocusID)
		{
			this.NewRecord(); // initialize record state
			this.patientFocusID = patientFocusID;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientFocusHistoryID
		{
			get { return this.patientFocusHistoryID; }
			set { this.patientFocusHistoryID = value; }
		}

		[FieldValuesMember("LookupOf_PatientFocusID", "PatientFocusID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int PatientFocusID
		{
			get { return this.patientFocusID; }
			set { this.patientFocusID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientFocusHistoryID)
		{
			return base.Load(patientFocusHistoryID);
		}

		/// <summary>
		/// Parent PatientFocusHistoryCollection that contains this element
		/// </summary>
		public PatientFocusHistoryCollection ParentPatientFocusHistoryCollection
		{
			get
			{
				return this.parentPatientFocusHistoryCollection;
			}
			set
			{
				this.parentPatientFocusHistoryCollection = value; // parent is set when added to a collection
			}
		}

		public PatientFocusCollection LookupOf_PatientFocusID
		{
			get
			{
				return PatientFocusCollection.ActivePatientFocuses; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		[FieldDescription("@FOCUS@")]
		public string FocusDescription
		{
			get { return PatientFocusCollection.ActivePatientFocuses.Lookup_DescriptionByPatientFocusID(this.patientFocusID); }
		}

	}

	/// <summary>
	/// Strongly typed collection of PatientFocusHistory objects
	/// </summary>
	[ElementType(typeof(PatientFocusHistory))]
	public class PatientFocusHistoryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientFocusHistory elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientFocusHistoryCollection = this;
			else
				elem.ParentPatientFocusHistoryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientFocusHistory elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientFocusHistory this[int index]
		{
			get
			{
				return (PatientFocusHistory)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientFocusHistory)oldValue, false);
			SetParentOnElem((PatientFocusHistory)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PatientFocusHistory elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PatientFocusHistory)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent Patient that contains this collection
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.ParentDataObject as Patient; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}
	}
}
