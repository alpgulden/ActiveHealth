using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientCOB]
	/// Other coverage information.
	/// Patient - PatientCOB is a many to many relationship, we'll it as 1-1 for now
	/// </summary>
	[SPInsert("usp_InsertPatientCOB")]
	[SPUpdate("usp_UpdatePatientCOB")]
	[SPDelete("usp_DeletePatientCOB")]
	[SPLoad("usp_LoadPatientCOB")]
	[TableMapping("PatientCOB","patientCOBID")]
	public class PatientCOB : BaseData
	{
		[NonSerialized]
		private PatientCOBCollection parentPatientCOBCollection;
		[ColumnMapping("PatientCOBID",StereoType=DataStereoType.FK)]
		private int patientCOBID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("OtherInsuranceType",StereoType=DataStereoType.FK)]
		private int otherInsuranceType;
		[ColumnMapping("OtherInsuranceName")]
		private string otherInsuranceName;
		[ColumnMapping("Status",StereoType=DataStereoType.FK)]
		private int status;

		public PatientCOB()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PatientCOB(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientCOBID
		{
			get { return this.patientCOBID; }
			set { this.patientCOBID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[FieldValuesMember("LookupOf_OtherInsuranceType", "InsuranceTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int OtherInsuranceType
		{
			get { return this.otherInsuranceType; }
			set { this.otherInsuranceType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string OtherInsuranceName
		{
			get { return this.otherInsuranceName; }
			set { this.otherInsuranceName = value; }
		}

		[FieldValuesMember("LookupOf_Status", "CoverageStatusID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int Status
		{
			get { return this.status; }
			set { this.status = value; }
		}

		/// <summary>
		/// Parent PatientCOBCollection that contains this element
		/// </summary>
		public PatientCOBCollection ParentPatientCOBCollection
		{
			get
			{
				return this.parentPatientCOBCollection;
			}
			set
			{
				this.parentPatientCOBCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientCOBID)
		{
			return base.Load(patientCOBID);
		}

		public InsuranceTypeCollection LookupOf_OtherInsuranceType
		{
			get
			{
				return InsuranceTypeCollection.ActiveInsuranceTypes; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool IsPrimary
		{
			get 
			{
				try
				{
					return this.parentPatientCOBCollection.ParentPatient.PrimaryCOBId == this.patientCOBID;
				}
				catch		// instead of multi-step null checks, we just ignore
				{
					return false;
				}
			}
			set
			{
				if (value && !this.IsNew)
					this.parentPatientCOBCollection.ParentPatient.PrimaryCOBId = this.patientCOBID;
			}
		}

		public CoverageStatusCollection LookupOf_Status
		{
			get
			{
				return CoverageStatusCollection.ActiveCoverageStatusCodes; // Acquire a shared instance from the static member of collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of PatientCOB objects
	/// </summary>
	[ElementType(typeof(PatientCOB))]
	public class PatientCOBCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private Patient parentPatient;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientCOB elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientCOBCollection = this;
			else
				elem.ParentPatientCOBCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientCOB elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientCOB this[int index]
		{
			get
			{
				return (PatientCOB)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientCOB)oldValue, false);
			SetParentOnElem((PatientCOB)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Patient that contains this collection
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.parentPatient; }
			set { this.parentPatient = value; /* parent is set when contained by a Patient */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PatientCOB elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PatientCOB)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
