using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientFocus]
	/// </summary>
	[SPAutoGen("usp_GetAllPatientFocuses","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetPatientFocusesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertPatientFocus")]
	[SPUpdate("usp_UpdatePatientFocus")]
	[SPDelete("usp_DeletePatientFocus")]
	[SPLoad("usp_LoadPatientFocus")]
	[TableMapping("PatientFocus","patientFocusID")]
	public class PatientFocus : BaseLookupWithCode
	{
		[NonSerialized]
		private PatientFocusCollection parentPatientFocusCollection;
		[ColumnMapping("PatientFocusID",StereoType=DataStereoType.FK)]
		private int patientFocusID;
	
		public PatientFocus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientFocusID
		{
			get { return this.patientFocusID; }
			set { this.patientFocusID = value; }
		}

		/// <summary>
		/// Parent PatientFocusCollection that contains this element
		/// </summary>
		public PatientFocusCollection ParentPatientFocusCollection
		{
			get
			{
				return this.parentPatientFocusCollection;
			}
			set
			{
				this.parentPatientFocusCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientFocusID)
		{
			return base.Load(patientFocusID);
		}
	}

	/// <summary>
	/// Strongly typed collection of PatientFocus objects
	/// </summary>
	[ElementType(typeof(PatientFocus))]
	public class PatientFocusCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PatientFocusID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientFocus elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientFocusCollection = this;
			else
				elem.ParentPatientFocusCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientFocus elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientFocus this[int index]
		{
			get
			{
				return (PatientFocus)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientFocus)oldValue, false);
			SetParentOnElem((PatientFocus)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPatientFocusesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPatientFocusesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PatientFocusCollection which is cached in NSGlobal
		/// </summary>
		public static PatientFocusCollection ActivePatientFocuses
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PatientFocusCollection col = (PatientFocusCollection)NSGlobal.EnsureCachedObject("ActivePatientFocuses", typeof(PatientFocusCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPatientFocusesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on patientFocusID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PatientFocusID
		{
			get
			{
				if (this.indexBy_PatientFocusID == null)
					this.indexBy_PatientFocusID = new CollectionIndexer(this, new string[] { "patientFocusID" }, true);
				return this.indexBy_PatientFocusID;
			}
			
		}

		/// <summary>
		/// Looks up by patientFocusID and returns Description value.  Uses the IndexBy_PatientFocusID indexer.
		/// </summary>
		public string Lookup_DescriptionByPatientFocusID(int patientFocusID)
		{
			return this.IndexBy_PatientFocusID.LookupStringMember("Description", patientFocusID);
		}
	}
}
