using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [MedicationTerminationReason]
	/// </summary>
	[SPAutoGen("usp_GetAllMedicationTerminationReasons","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetMedicationTerminationReasonsByActive","SearchByArgs.sptpl","active")]
	[SPInsert("usp_InsertMedicationTerminationReason")]
	[SPUpdate("usp_UpdateMedicationTerminationReason")]
	[SPDelete("usp_DeleteMedicationTerminationReason")]
	[SPLoad("usp_LoadMedicationTerminationReason")]
	[TableMapping("MedicationTerminationReason","codeID")]
	public class MedicationTerminationReason : BaseLookupWithCode
	{
		[NonSerialized]
		private MedicationTerminationReasonCollection parentMedicationTerminationReasonCollection;
		[ColumnMapping("CodeID",StereoType=DataStereoType.FK)]
		private int codeID;
	
		public MedicationTerminationReason()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CodeID
		{
			get { return this.codeID; }
			set { this.codeID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int codeID)
		{
			return base.Load(codeID);
		}

		/// <summary>
		/// Parent MedicationTerminationReasonCollection that contains this element
		/// </summary>
		public MedicationTerminationReasonCollection ParentMedicationTerminationReasonCollection
		{
			get
			{
				return this.parentMedicationTerminationReasonCollection;
			}
			set
			{
				this.parentMedicationTerminationReasonCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of MedicationTerminationReason objects
	/// </summary>
	[ElementType(typeof(MedicationTerminationReason))]
	public class MedicationTerminationReasonCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MedicationTerminationReason elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMedicationTerminationReasonCollection = this;
			else
				elem.ParentMedicationTerminationReasonCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MedicationTerminationReason elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MedicationTerminationReason this[int index]
		{
			get
			{
				return (MedicationTerminationReason)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MedicationTerminationReason)oldValue, false);
			SetParentOnElem((MedicationTerminationReason)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadMedicationTerminationReasonsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetMedicationTerminationReasonsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared MedicationTerminationReasonCollection which is cached in NSGlobal
		/// </summary>
		public static MedicationTerminationReasonCollection ActiveMedicationTerminationReasons
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				MedicationTerminationReasonCollection col = (MedicationTerminationReasonCollection)NSGlobal.EnsureCachedObject("ActiveMedicationTerminationReasons", typeof(MedicationTerminationReasonCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadMedicationTerminationReasonsByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
