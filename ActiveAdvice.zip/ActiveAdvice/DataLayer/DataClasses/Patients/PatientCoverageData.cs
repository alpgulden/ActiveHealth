using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientCoverageData]
	/// PatientCoverageData is the table that keeps the history of changes made to 
	/// effective and termination dates of the coverage.
	/// 
	/// Unmanaged stored procedures called:
	///		dbo.usp_InvalidatePatientCoverageData
	/// </summary>
	[SPInsert("usp_InsertPatientCoverageData")]
	[SPUpdate("usp_UpdatePatientCoverageData")]
	[SPDelete("usp_DeletePatientCoverageData")]
	[SPLoad("usp_LoadPatientCoverageData")]
	[SPAutoGen("usp_GetLatestCoverageData","SelectTop1.sptpl","patientCoverageDataID, DESC, patientCoverageID")]
	[TableMapping("PatientCoverageData","patientCoverageDataID")]
	public class PatientCoverageData : BaseData
	{
		[NonSerialized]
		private PatientCoverageDataCollection parentPatientCoverageDataCollection;
		[ColumnMapping("PatientCoverageDataID",StereoType=DataStereoType.FK)]
		private int patientCoverageDataID;
		[ColumnMapping("PatientCoverageID",StereoType=DataStereoType.FK)]
		private int patientCoverageID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;

		// 
		private DateTime termDateWhenLoaded;

		public PatientCoverageData()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PatientCoverageData(PatientCoverage patientCoverage)
		{
			if (patientCoverage == null)
				throw new Exception("PatientCoverageData can be created only in the context of a PatientCoverage");

			this.NewRecord();

			this.patientCoverageID = patientCoverage.PatientCoverageID;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientCoverageDataID
		{
			get { return this.patientCoverageDataID; }
			set { this.patientCoverageDataID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value.Date; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value.Date; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate /*IsRequired=true*/)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value.Date; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientCoverageDataID)
		{
			return base.Load(patientCoverageDataID);
		}

		/// <summary>
		/// Load the latest SubscriberCoverageHistory record for a given subscriber coverage
		/// </summary>
		public bool LoadLatest(int patientCoverageID)
		{
			return SqlData.SPExecReadObj("usp_GetLatestCoverageData", this, false, patientCoverageID);
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}

			// invalidate other overlapping coverages.
			this.active = this.InvalidatePatientCoverageData(this.patientCoverageID, this.effectiveDate, this.terminationDate);

			base.InternalSave();
			// Save the child collections here.
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientCoverageID
		{
			get { return this.patientCoverageID; }
			set { this.patientCoverageID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Parent PatientCoverageDataCollection that contains this element
		/// </summary>
		public PatientCoverageDataCollection ParentPatientCoverageDataCollection
		{
			get
			{
				return this.parentPatientCoverageDataCollection;
			}
			set
			{
				this.parentPatientCoverageDataCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Invalidates other overlapping coverage data records for the given date range.
		/// Returns valid or invalid.
		/// </summary>
		public bool InvalidatePatientCoverageData(int patientCoverageID, DateTime effectiveDate, DateTime terminationDate)
		{
			return Convert.ToBoolean( SqlData.SPExecScalar("usp_InvalidatePatientCoverageData", 
				new object[] { 
					patientCoverageID, 
					SQLDataDirect.MakeDBValue( effectiveDate ),
					SQLDataDirect.MakeDBValue( terminationDate ) } ) );
		}


	}

	/// <summary>
	/// Strongly typed collection of PatientCoverageData objects
	/// </summary>
	[ElementType(typeof(PatientCoverageData))]
	public class PatientCoverageDataCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientCoverageData elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientCoverageDataCollection = this;
			else
				elem.ParentPatientCoverageDataCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientCoverageData elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientCoverageData this[int index]
		{
			get
			{
				return (PatientCoverageData)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientCoverageData)oldValue, false);
			SetParentOnElem((PatientCoverageData)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PatientCoverageData elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PatientCoverageData)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
