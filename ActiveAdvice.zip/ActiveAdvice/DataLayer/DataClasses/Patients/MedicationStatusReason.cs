using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [MedicationStatusReason]
	/// </summary>
	[SPAutoGen("usp_GetAllMedicationStatusReasons","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetMedicationStatusReasonsByActive","SearchByArgs.sptpl","active")]
	[SPInsert("usp_InsertMedicationStatusReason")]
	[SPUpdate("usp_UpdateMedicationStatusReason")]
	[SPDelete("usp_DeleteMedicationStatusReason")]
	[SPLoad("usp_LoadMedicationStatusReason")]
	[TableMapping("MedicationStatusReason","codeID")]
	public class MedicationStatusReason : BaseLookupWithCode
	{
		[NonSerialized]
		private MedicationStatusReasonCollection parentMedicationStatusReasonCollection;
		[ColumnMapping("CodeID",StereoType=DataStereoType.FK)]
		private int codeID;
	
		public MedicationStatusReason()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CodeID
		{
			get { return this.codeID; }
			set { this.codeID = value; }
		}

		/// <summary>
		/// Parent MedicationStatusReasonCollection that contains this element
		/// </summary>
		public MedicationStatusReasonCollection ParentMedicationStatusReasonCollection
		{
			get
			{
				return this.parentMedicationStatusReasonCollection;
			}
			set
			{
				this.parentMedicationStatusReasonCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int codeID)
		{
			return base.Load(codeID);
		}
	}

	/// <summary>
	/// Strongly typed collection of MedicationStatusReason objects
	/// </summary>
	[ElementType(typeof(MedicationStatusReason))]
	public class MedicationStatusReasonCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MedicationStatusReason elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMedicationStatusReasonCollection = this;
			else
				elem.ParentMedicationStatusReasonCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MedicationStatusReason elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MedicationStatusReason this[int index]
		{
			get
			{
				return (MedicationStatusReason)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MedicationStatusReason)oldValue, false);
			SetParentOnElem((MedicationStatusReason)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadMedicationStatusReasonsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetMedicationStatusReasonsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared MedicationStatusReasonCollection which is cached in NSGlobal
		/// </summary>
		public static MedicationStatusReasonCollection ActiveMedicationStatusReasons
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				MedicationStatusReasonCollection col = (MedicationStatusReasonCollection)NSGlobal.EnsureCachedObject("ActiveMedicationStatusReasons", typeof(MedicationStatusReasonCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadMedicationStatusReasonsByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
