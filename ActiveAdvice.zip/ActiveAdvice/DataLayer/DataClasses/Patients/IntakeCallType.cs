using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [IntakeCallType]
	/// </summary>
	[SPAutoGen("usp_GetIntakeCallTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertIntakeCallType")]
	[SPUpdate("usp_UpdateIntakeCallType")]
	[SPDelete("usp_DeleteIntakeCallType")]
	[SPLoad("usp_LoadIntakeCallType")]
	[TableMapping("IntakeCallType","intakeCallTypeID")]
	public class IntakeCallType : BaseLookupStandard
	{
		[NonSerialized]
		private IntakeCallTypeCollection parentIntakeCallTypeCollection;
		[ColumnMapping("IntakeCallTypeID",(int)0)]
		private int intakeCallTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public IntakeCallType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public IntakeCallType(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		public IntakeCallType(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int IntakeCallTypeID
		{
			get { return this.intakeCallTypeID; }
			set { this.intakeCallTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=500)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Parent IntakeCallTypeCollection that contains this element
		/// </summary>
		public IntakeCallTypeCollection ParentIntakeCallTypeCollection
		{
			get
			{
				return this.parentIntakeCallTypeCollection;
			}
			set
			{
				this.parentIntakeCallTypeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of IntakeCallType objects
	/// </summary>
	[ElementType(typeof(IntakeCallType))]
	public class IntakeCallTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(IntakeCallType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentIntakeCallTypeCollection = this;
			else
				elem.ParentIntakeCallTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (IntakeCallType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public IntakeCallType this[int index]
		{
			get
			{
				return (IntakeCallType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((IntakeCallType)oldValue, false);
			SetParentOnElem((IntakeCallType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadIntakeCallTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetIntakeCallTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared IntakeCallTypeCollection which is cached in NSGlobal
		/// </summary>
		public static IntakeCallTypeCollection ActiveIntakeCallTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				IntakeCallTypeCollection col = (IntakeCallTypeCollection)NSGlobal.EnsureCachedObject("ActiveIntakeCallTypes", typeof(IntakeCallTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadIntakeCallTypesByActive(-1, true);
				}
				return col;
			}
		}
	}
}
