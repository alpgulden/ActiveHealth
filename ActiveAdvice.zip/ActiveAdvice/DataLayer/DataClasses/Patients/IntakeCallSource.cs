using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [IntakeCallSource]
	/// </summary>
	[SPAutoGen("usp_GetIntakeCallSourcesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertIntakeCallSource")]
	[SPUpdate("usp_UpdateIntakeCallSource")]
	[SPDelete("usp_DeleteIntakeCallSource")]
	[SPLoad("usp_LoadIntakeCallSource")]
	[TableMapping("IntakeCallSource","intakeCallSourceID")]
	public class IntakeCallSource : BaseLookupStandard
	{
		[NonSerialized]
		private IntakeCallSourceCollection parentIntakeCallSourceCollection;
		[ColumnMapping("IntakeCallSourceID",(int)0)]
		private int intakeCallSourceID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public IntakeCallSource()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public IntakeCallSource(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public IntakeCallSource(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int IntakeCallSourceID
		{
			get { return this.intakeCallSourceID; }
			set { this.intakeCallSourceID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=500)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Parent IntakeCallSourceCollection that contains this element
		/// </summary>
		public IntakeCallSourceCollection ParentIntakeCallSourceCollection
		{
			get
			{
				return this.parentIntakeCallSourceCollection;
			}
			set
			{
				this.parentIntakeCallSourceCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int intakeCallSourceID)
		{
			return base.Load(intakeCallSourceID);
		}
	}

	/// <summary>
	/// Strongly typed collection of IntakeCallSource objects
	/// </summary>
	[ElementType(typeof(IntakeCallSource))]
	public class IntakeCallSourceCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(IntakeCallSource elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentIntakeCallSourceCollection = this;
			else
				elem.ParentIntakeCallSourceCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (IntakeCallSource elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public IntakeCallSource this[int index]
		{
			get
			{
				return (IntakeCallSource)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((IntakeCallSource)oldValue, false);
			SetParentOnElem((IntakeCallSource)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadIntakeCallSourcesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetIntakeCallSourcesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared IntakeCallSourceCollection which is cached in NSGlobal
		/// </summary>
		public static IntakeCallSourceCollection IntakeCallSources
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				IntakeCallSourceCollection col = (IntakeCallSourceCollection)NSGlobal.EnsureCachedObject("IntakeCallSources", typeof(IntakeCallSourceCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadIntakeCallSourcesByActive(-1, true);
				}
				return col;
			}
		}
	}
}
