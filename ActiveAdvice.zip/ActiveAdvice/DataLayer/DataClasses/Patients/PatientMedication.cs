using System;
using System.Collections;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientMedication]
	/// </summary>
	[SPAutoGen("usp_SearchPatientMedications","SearchByArgs.sptpl","patientID, statusID, active")]
	[SPInsert("usp_InsertPatientMedication")]
	[SPUpdate("usp_UpdatePatientMedication")]
	[SPDelete("usp_DeletePatientMedication")]
	[SPLoad("usp_LoadPatientMedication")]
	[TableMapping("PatientMedication","patientMedicationID")]
	public class PatientMedication : BaseData
	{
		[NonSerialized]
		private PatientMedicationCollection parentPatientMedicationCollection;
		[ColumnMapping("PatientMedicationID",StereoType=DataStereoType.FK)]
		private int patientMedicationID;
		[ColumnMapping("PatientID")]
		private int patientID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("MedicationTerminationReasonId",StereoType=DataStereoType.FK)]
		private int medicationTerminationReasonId;
		[ColumnMapping("Frequency",StereoType=DataStereoType.FK)]
		private int frequency;
		[ColumnMapping("FrequencyUnits",StereoType=DataStereoType.FK)]
		private int frequencyUnits;
		[ColumnMapping("Dosage",StereoType=DataStereoType.FK)]
		private int dosage;
		[ColumnMapping("DosageUnits",StereoType=DataStereoType.FK)]
		private int dosageUnits;
		[ColumnMapping("StatusID",StereoType=DataStereoType.FK)]
		private int statusID;
		[ColumnMapping("StatusReasonID",StereoType=DataStereoType.FK)]
		private int statusReasonID;
		[ColumnMapping("Comments")]
		private string comments;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("MedicationID",StereoType=DataStereoType.FK)]
		private int medicationID;
		[ColumnMapping("AssessmentGUID")]
		private string assessmentGUID;
		[ColumnMapping("QuestionID",StereoType=DataStereoType.FK)]
		private int questionID;
		[ColumnMapping("MedicationFFRM")]
		private string medicationFFRM;
		private Medication medication;

		//The CODE values you should require �reasons� for are: PTSC & PTNT as in BR01.28.3
		public static string[] REASONSTRIGGERS = new string[]{"PTSC", "PTNT"};

		public static bool EnableICMMedications()
		{
			// global variable which affects medication entry workflow.
			// true  (1) represents free entry of a medication name
			// false (0) forces user to pick
			return SystemControlValue.GetInstance.EnableICMMedications;
		}
	
		public PatientMedication()
		{
		}

		public PatientMedication(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@MEDICATIONID@")]
		public int PatientMedicationID
		{
			get { return this.patientMedicationID; }
			set { this.patientMedicationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[FieldValuesMember("LookupOf_MedicationTerminationReasonId", "CodeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@MEDICATIONTERMINATION@")]
		public int MedicationTerminationReasonId
		{
			get { return this.medicationTerminationReasonId; }
			set { this.medicationTerminationReasonId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@FREQUENCY@")]
		public int Frequency
		{
			get { return this.frequency; }
			set { this.frequency = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@FREQUENCYUNITS@")]
		public int FrequencyUnits
		{
			get { return this.frequencyUnits; }
			set { this.frequencyUnits = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@DOSAGE@")]
		public int Dosage
		{
			get { return this.dosage; }
			set { this.dosage = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@DOSAGEUNITS@")]
		public int DosageUnits
		{
			get { return this.dosageUnits; }
			set { this.dosageUnits = value; }
		}

		[FieldValuesMember("LookupOf_StatusID", "CodeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@STATUS@")]
		public int StatusID
		{
			get { return this.statusID; }
			set { this.statusID = value; }
		}

		[FieldValuesMember("LookupOf_StatusReasonID", "CodeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@REASON@")]
		public int StatusReasonID
		{
			get { return this.statusReasonID; }
			set { this.statusReasonID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=200)]
		[FieldDescription("@COMMENT@")]
		public string Comments
		{
			get { return this.comments; }
			set { this.comments = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@MODIFYBY@")]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int MedicationID
		{
			get { return this.medicationID; }
			set { this.medicationID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=75, IsRequired=true)]
		[FieldDescription("@MEDICATION@")]
		public string MedicationFFRM
		{
			get { return this.medicationFFRM; }
			set { this.medicationFFRM = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		[FieldDescription("@NDC@")]
		public string NDC
		{
			get { return this.Medication.NDC; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		[FieldDescription("@BRANDNAME@")]
		public string BrandName
		{
			get { return this.Medication.BrandName; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		[FieldDescription("@GENERICNAME@")]
		public string GenericName
		{
			get { return this.Medication.GenericName; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		[FieldDescription("@ETCNAME@")]
		public string EtcName
		{
			get { return this.Medication.EtcName; }
		}

		#region DB Methods
		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			if (!this.IsMarkedForDeletion)
			{
				try
				{ this.CheckBusinessRules(); }
				catch
				{ throw; }
			}
			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientMedicationID)
		{
			return base.Load(patientMedicationID);
		}
		#endregion

		#region Lookups
		/// <summary>
		/// Parent PatientMedicationCollection that contains this element
		/// </summary>
		public PatientMedicationCollection ParentPatientMedicationCollection
		{
			get
			{
				return this.parentPatientMedicationCollection;
			}
			set
			{
				this.parentPatientMedicationCollection = value; // parent is set when added to a collection
			}
		}

		public MedicationStatusCollection LookupOf_StatusID
		{
			get
			{
				return MedicationStatusCollection.ActiveMedicationStatusCodes; // Acquire a shared instance from the static member of collection
			}
		}

		public MedicationStatusReasonCollection LookupOf_StatusReasonID
		{
			get
			{
				return MedicationStatusReasonCollection.ActiveMedicationStatusReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public MedicationTerminationReasonCollection LookupOf_MedicationTerminationReasonId
		{
			get
			{
				return MedicationTerminationReasonCollection.ActiveMedicationTerminationReasons; // Acquire a shared instance from the static member of collection
			}
		}
		#endregion

		/// <summary>
		/// Contained Medication object
		/// </summary>
		[Contained]
		public Medication Medication
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.medication = (Medication)Medication.EnsureContainedDataObject(this, typeof(Medication), medication, false, medicationID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.medication;
			}
			set
			{
				this.medication = value;
				if (value != null) value.ParentPatientMedication = this; // set this as a parent of the child data class
			}
		}

		private void CheckBusinessRules()
		{
			// BR01.28.3 - The CODE values you should require �reasons� to trigger Termination Reason to be specified
			string str = MedicationStatusCollection.ActiveMedicationStatusCodes.Lookup_CodeByCodeID(this.statusID);
			
			if(str == PatientMedication.REASONSTRIGGERS[0] || str == PatientMedication.REASONSTRIGGERS[1])
			{
				if(this.StatusReasonID == 0)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "With specified " + "@STATUS@" + " you must set " + "@MEDICATIONTERMINATION@");
				else
					this.Active = false; // if Termination Reason was set - PatientMedication is no longer active
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int QuestionID
		{
			get { return this.questionID; }
			set { this.questionID = value; }
		}		
	}

	/// <summary>
	/// Strongly typed collection of PatientMedication objects
	/// </summary>
	[ElementType(typeof(PatientMedication))]
	public class PatientMedicationCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass, ICollectionElementFilter
	{
		[NonSerialized]
		private CollectionIndexer indexBy_AssessmentGUID_QuestionID_MedicationID;

		private string filterAssessmentGUID = null;
		private int filterQuestionID = 0;        // if this is set, the collection can be filtered by questionID

		public string FilterAssessmentGUID
		{
			get { return this.filterAssessmentGUID; }
			set { this.filterAssessmentGUID = value; }
		}

		public int FilterQuestionID
		{     
			get { return this.filterQuestionID; }
			set { this.filterQuestionID = value; }
		}



		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientMedication elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientMedicationCollection = this;
			else
				elem.ParentPatientMedicationCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientMedication elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientMedication this[int index]
		{
			get
			{
				return (PatientMedication)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientMedication)oldValue, false);
			SetParentOnElem((PatientMedication)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Search for patient medications and fill the collection.
		/// </summary>
		public int SearchPatientMedications(int maxRecords, PatientMedication searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchPatientMedications", maxRecords, this, new object[] { searcher }, false);
		}

		/// <summary>
		/// Parent Patient that contains this collection
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.ParentDataObject as Patient; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PatientMedication elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PatientMedication)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Hashtable based index on assessmentGUID, questionID, medicationID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_AssessmentGUID_QuestionID_MedicationID
		{
			get
			{
				if (this.indexBy_AssessmentGUID_QuestionID_MedicationID == null)
					this.indexBy_AssessmentGUID_QuestionID_MedicationID = new CollectionIndexer(this, new string[] { "assessmentGUID", "questionID", "medicationID" }, true);
				return this.indexBy_AssessmentGUID_QuestionID_MedicationID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on assessmentGUID, questionID, medicationID fields returns the object.  Uses the IndexBy_AssessmentGUID_QuestionID_MedicationID indexer.
		/// </summary>
		public PatientMedication FindBy(string assessmentGUID, int questionID, int medicationID)
		{
			return (PatientMedication)this.IndexBy_AssessmentGUID_QuestionID_MedicationID.GetObject(assessmentGUID, questionID, medicationID);
		}

		#region ICollectionElementFilter Members

		public bool FilterElement(int index)
		{
			return ((filterAssessmentGUID == null ||  this[index].AssessmentGUID == filterAssessmentGUID) && (filterQuestionID == 0 || this[index].QuestionID == filterQuestionID));
		}

		#endregion


		/// <summary>
		/// Returns InterventionTemplates filtered by QuestionID
		/// </summary>
		/// <param name="questionID"></param>
		/// <returns></returns>
		public ArrayList FilterBy(string assessmentGUID, int questionID)
		{
			ArrayList its = new ArrayList(10);
			for (int i = 0; i < this.Count; i++)
			{
				if (!this[i].IsMarkedForDeletion && this[i].QuestionID == questionID && this[i].AssessmentGUID == assessmentGUID)
					its.Add(this[i]);
			}
			if (its.Count > 0)
				return its;
			else
				return null;
		}


		public void ResetIndexers()
		{
			indexBy_AssessmentGUID_QuestionID_MedicationID = null;
		}
	}
}
