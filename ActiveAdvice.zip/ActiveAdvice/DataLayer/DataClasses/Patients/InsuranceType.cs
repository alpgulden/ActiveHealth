using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [InsuranceTypes]
	/// </summary>
	[SPAutoGen("usp_SearchInsuranceTypes","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllInsuranceTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetInsuranceTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertInsuranceType")]
	[SPUpdate("usp_UpdateInsuranceType")]
	[SPDelete("usp_DeleteInsuranceType")]
	[SPLoad("usp_LoadInsuranceType")]
	[TableMapping("InsuranceType","insuranceTypeId")]
	public class InsuranceType : BaseLookupWithCode
	{
		[NonSerialized]
		private InsuranceTypeCollection parentInsuranceTypeCollection;
		[ColumnMapping("InsuranceTypeId",StereoType=DataStereoType.FK)]
		private int insuranceTypeId;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

	
		public InsuranceType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int InsuranceTypeId
		{
			get { return this.insuranceTypeId; }
			set { this.insuranceTypeId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Parent InsuranceTypeCollection that contains this element
		/// </summary>
		public InsuranceTypeCollection ParentInsuranceTypeCollection
		{
			get
			{
				return this.parentInsuranceTypeCollection;
			}
			set
			{
				this.parentInsuranceTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of InsuranceType objects
	/// </summary>
	[ElementType(typeof(InsuranceType))]
	public class InsuranceTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(InsuranceType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentInsuranceTypeCollection = this;
			else
				elem.ParentInsuranceTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (InsuranceType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public InsuranceType this[int index]
		{
			get
			{
				return (InsuranceType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((InsuranceType)oldValue, false);
			SetParentOnElem((InsuranceType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetInsuranceTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetInsuranceTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared InsuranceTypeCollection which is cached in NSGlobal
		/// </summary>
		public static InsuranceTypeCollection ActiveInsuranceTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				InsuranceTypeCollection col = (InsuranceTypeCollection)NSGlobal.EnsureCachedObject("ActiveInsuranceTypes", typeof(InsuranceTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetInsuranceTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Searches for Insurance Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchInsuranceTypes", -1, this, false, code, description, active);
		}

		/// <summary>
		///  Loads all Insurance Types into collection.
		/// </summary>
		public override void LoadAll()
		{
			SqlData.SPExecReadCol("usp_GetAllInsuranceTypes", -1, this, false);
		}
	}
}
