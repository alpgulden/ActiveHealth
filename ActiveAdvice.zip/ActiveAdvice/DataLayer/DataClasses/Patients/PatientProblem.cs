using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PatientProblem]
	/// </summary>
	[SPInsert("usp_InsertPatientProblem")]
	[SPUpdate("usp_UpdatePatientProblem")]
	[SPDelete("usp_DeletePatientProblem")]
	[SPLoad("usp_LoadPatientProblem")]
	[TableMapping("PatientProblem","patientId",true)]
	public class PatientProblem : BaseData
	{
		[NonSerialized]
		private PatientProblemCollection parentPatientProblemCollection;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		private int patientId;
		[ColumnMapping("ProblemId",StereoType=DataStereoType.FK)]
		private int problemId;

		private Patient patient;
		private Problem problem;
	
		public PatientProblem()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PatientProblem(Patient patient)
		{
			this.NewRecord();
			if (patient == null)
				throw new Exception("A patient problem can only be created in the context of a patient");
			this.patient = patient;
			this.patientId = patient.PatientId;
		}

		public PatientProblem(Patient patient, Problem problem)
			: this(patient)
		{
			if (problem != null)		// link to given problem
			{
				this.problem = problem;
				this.problemId = problem.ProblemID;
			}
		}

		/// <summary>
		/// Loads and returns the associated patient.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientId == 0)
				return null;
			Patient patient = new Patient();
			if (patient.Load(this.patientId))
				return patient;
			else
				return null;
		}

		/// <summary>
		/// Returns the linked patient object.  This was either passed
		/// in the constructor, or it's loaded from the Patient table.
		/// </summary>
		public Patient Patient
		{
			get
			{
				if (this.patient == null)
				{
					if (this.parentPatientProblemCollection != null)
						this.patient = this.parentPatientProblemCollection.ParentPatient;
					if (this.patient == null)
						this.patient = GetPatient();
				}
				return this.patient;
			}
		}

		/// <summary>
		/// Loads and returns the associated problem.
		/// </summary>
		/// <returns></returns>
		public Problem GetProblem()
		{
			if (this.problemId == 0)
				return null;
			Problem problem = new Problem();
			if (problem.Load(this.problemId))
				return problem;
			else
				return null;
		}

		/// <summary>
		/// Returns the linked problem object.  This was either passed
		/// in the constructor, or it's loaded from the Problem table.
		/// </summary>
		public Problem Problem
		{
			get
			{
				if (this.problem == null)
				{
					// try to get the problem from the parent patientProblemCollection
					if (this.parentPatientProblemCollection != null)
						this.problem = this.parentPatientProblemCollection.ParentProblem;
					// try to get the problem from the db
					if (this.problem == null)
						this.problem = GetProblem();
					// establish in-memory relationship to patient if not already established
					if (this.problem != null)
					{
						if (this.problem.Patient == null)
							this.problem.Patient = this.Patient;		// establish the in-memory relationship of the patient and the problem
					}
				}
				return this.problem;
			}
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PatientId
		{
			get { return this.patientId; }
			//set { this.patientId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ProblemId
		{
			get { return this.problemId; }
			set 
			{
				this.problemId = value;
				this.problem = null;
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int patientId)
		{
			return base.Load(patientId);
		}

		/// <summary>
		/// Parent PatientProblemCollection that contains this element
		/// </summary>
		public PatientProblemCollection ParentPatientProblemCollection
		{
			get
			{
				return this.parentPatientProblemCollection;
			}
			set
			{
				this.parentPatientProblemCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PatientProblem objects
	/// </summary>
	[ElementType(typeof(PatientProblem))]
	public class PatientProblemCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PatientProblem elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPatientProblemCollection = this;
			else
				elem.ParentPatientProblemCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PatientProblem elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PatientProblem this[int index]
		{
			get
			{
				return (PatientProblem)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PatientProblem)oldValue, false);
			SetParentOnElem((PatientProblem)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Patient that contains this collection
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.ParentDataObject as Patient; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}

		/// <summary>
		/// Parent Problem that contains this collection
		/// </summary>
		public Problem ParentProblem
		{
			get { return this.ParentDataObject as Problem; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Problem */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PatientProblem elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PatientProblem)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
