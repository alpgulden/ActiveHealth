using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ActivityTypeSubType]
	/// </summary>
	[TableMapping("ActivityTypeSubType","activityTypeSubTypeId")]
	public class ActivityTypeSubType : BaseDataClass
	{
		[ColumnMapping("ActivityTypeSubTypeId",(int)0)]
		private int activityTypeSubTypeId;
		[ColumnMapping("ActivityTypeId",StereoType=DataStereoType.FK)]
		private int activityTypeId;
		[ColumnMapping("ActivitySubTypeId",StereoType=DataStereoType.FK)]
		private int activitySubTypeId;
	
		public ActivityTypeSubType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ActivityTypeSubTypeId
		{
			get { return this.activityTypeSubTypeId; }
			set { this.activityTypeSubTypeId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ActivityTypeId
		{
			get { return this.activityTypeId; }
			set { this.activityTypeId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ActivitySubTypeId
		{
			get { return this.activitySubTypeId; }
			set { this.activitySubTypeId = value; }
		}
	}
}
