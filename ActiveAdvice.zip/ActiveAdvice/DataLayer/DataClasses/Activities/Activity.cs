using System;
using System.Diagnostics;

using NetsoftUSA.DataLayer;



namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Activity]
	/// </summary>
	//MANUAL SP:  SPAutoGen("usp_SearchActivities","SearchAndSortByArgs.sptpl","patientId, cMSID, planId, problemId, eventID, referralID, reviewID, physicianReviewDetailID, physicianINDPhysicianReviewID, physicianReviewID, activityTypeID, activityPriority, activityCompletionID, isBillable")]
	[SPInsert("usp_InsertActivity")]
	[SPUpdate("usp_UpdateActivity")]
	[SPDelete("usp_DeleteActivity")]
	[SPLoad("usp_LoadActivity")]
	[TableMapping("Activity","activityID")]
	public class Activity : BaseData
	{
		[NonSerialized]
		protected ActivityCollection parentActivityCollection;
		[ColumnMapping("ActivityID",StereoType=DataStereoType.FK)]
		protected int activityID;
		[ColumnMapping("PatientId",StereoType=DataStereoType.FK)]
		protected int patientId;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		protected int cMSID;
		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)]
		protected int planId;
		[ColumnMapping("ProblemId",StereoType=DataStereoType.FK)]
		protected int problemId;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		protected int eventID;
		[ColumnMapping("ReferralID",StereoType=DataStereoType.FK)]
		protected int referralID;
		[ColumnMapping("ReviewID",StereoType=DataStereoType.FK)]
		protected int reviewID;
		[ColumnMapping("PhysicianReviewDetailID",StereoType=DataStereoType.FK)]
		protected int physicianReviewDetailID;
		[ColumnMapping("PhysicianINDPhysicianReviewID",StereoType=DataStereoType.FK)]
		protected int physicianINDPhysicianReviewID;
		[ColumnMapping("ActivityDescription")]
		protected string activityDescription;
		[ColumnMapping("DueDate")]
		protected DateTime dueDate;
		[ColumnMapping("AssignedTeamID",StereoType=DataStereoType.FK)]
		protected int assignedTeamID;
		[ColumnMapping("AssignedUserID",StereoType=DataStereoType.FK)]
		protected int assignedUserID;
		[ColumnMapping("ActivityPriority",StereoType=DataStereoType.FK)]
		protected int activityPriority;
		[ColumnMapping("CompletionNote")]
		protected string completionNote;
		[ColumnMapping("CompletedByUserID",StereoType=DataStereoType.FK)]
		protected int completedByUserID;
		[ColumnMapping("CompletionDate")]
		protected DateTime completionDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ActivityAmount")]
		protected decimal activityAmount;
		[ColumnMapping("ManagementServiceRate")]
		protected decimal managementServiceRate;
		[ColumnMapping("IsBillable")]
		protected bool isBillable;
		[ColumnMapping("BaseAmount")]
		protected decimal baseAmount;
		[ColumnMapping("ExtendedAmount")]
		protected decimal extendedAmount;
		[ColumnMapping("BillableAmount")]
		protected decimal billableAmount;
		[ColumnMapping("BaseConvMult")]
		protected decimal baseConvMult;
		[ColumnMapping("BaseConvDiv")]
		protected decimal baseConvDiv;
		[ColumnMapping("InterventionID",StereoType=DataStereoType.FK)]
		protected int interventionID;
		[ColumnMapping("ActivityCompletionID",StereoType=DataStereoType.FK)]
		protected int activityCompletionID;
		[ColumnMapping("ActivityTypeID",StereoType=DataStereoType.FK)]
		protected int activityTypeID;
		[ColumnMapping("ManagementServiceItemID",StereoType=DataStereoType.FK)]
		protected int managementServiceItemID;
		[ColumnMapping("PhysicianReviewID",StereoType=DataStereoType.FK)]
		protected int physicianReviewID;
		[ColumnMapping("ManagementServiceTypeId",StereoType=DataStereoType.FK)]
		protected int managementServiceTypeId;
		[ColumnMapping("ActivitySubtypeID",StereoType=DataStereoType.FK)]
		protected int activitySubtypeID;
		[ColumnMapping("ParentActivityID",StereoType=DataStereoType.FK)]
		protected int parentActivityID;
		[ColumnMapping("BaseUOMId",StereoType=DataStereoType.FK)]
		protected int baseUOMId;
		[ColumnMapping("ConversionUOMId",StereoType=DataStereoType.FK)]
		protected int conversionUOMId;
		[ColumnMapping("PatientSubscriberLogID",StereoType=DataStereoType.FK)]
		protected int patientSubscriberLogID;			// rate
	
		//[ColumnMapping("ActivityPrimaryTypeID", SQLGen=SQLGenerationFlags.NoInsert | SQLGenerationFlags.NoUpdate | SQLGenerationFlags.NoSelect)]
		protected int primaryType = 0;				// Not in table.  Used to filter activity type
		private string activityCompletionStatus;			// completion status for the selected activity type

		[ColumnMapping("PlanName", JoinColumn="Name", JoinRelation="Activity.PlanId = [Plan].PlanId", SQLGen=SQLGenerationFlags.NoSelect | SQLGenerationFlags.NoUpdate | SQLGenerationFlags.NoUpdate)]
		protected string planName;
		// The linked plan
		protected Plan plan;							// loaded and cached plan
		protected Patient patient;						// loaded and cached patient
		protected PatientSubscriberLog patSubLog;		// loaded and cached pat sub log

		public Activity()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Create an activity for patient.  Even if the activity exists in the database,
		/// you can create an Activity for a specific patient.  
		/// Once you pass the patient object, the in-memory relationship to activity will be established.
		/// </summary>
		/// <param name="patient"></param>
		public Activity(Patient patient, bool initNew)
		{
			if (initNew)
				if (patient == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You can create an activity only in the context of a patient");

			if (initNew)
				this.NewRecord();
			if (this.patient != null)
			{
				this.patient = patient;
				this.patientId = patient.PatientId;
			}
		}

		/// <summary>
		/// Create a new activity for patient and the selected coverage
		/// </summary>
		/// <param name="patient"></param>
		public Activity(Patient patient, PatientCoverage patCov)
		{
			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You can create an activity only in the context of a patient");

			if (patCov == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "You can create a new activity only in the context of a patient-subscriber-coverage");

			this.NewRecord();
			this.patient = patient;
			this.patientId = patient.PatientId;
			
			SetCoverage(patient, patCov);
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ActivityID
		{
			get { return this.activityID; }
			set { this.activityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientId
		{
			get { return this.patientId; }
			set 
			{ 
				this.patientId = value; 
				this.patient = null;
			}
		}

		[FieldValuesMember("LookupOf_CMSID", "CMSID", "ERCDescription")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		[FieldValuesMember("LookupOf_ProblemId", "ProblemID", "ProblemDescriptionToDisplay")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ProblemId
		{
			get { return this.problemId; }
			set { this.problemId = value; }
		}

		[FieldValuesMember("LookupOf_EventID", "EventID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[FieldValuesMember("LookupOf_ReferralID", "ReferralID", "ERCDescription")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReviewID
		{
			get { return this.reviewID; }
			set { this.reviewID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PhysicianReviewDetailID
		{
			get { return this.physicianReviewDetailID; }
			set { this.physicianReviewDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PhysicianINDPhysicianReviewID
		{
			get { return this.physicianINDPhysicianReviewID; }
			set { this.physicianINDPhysicianReviewID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		[FieldDescription("@DESCRIPTION@")]
		public string ActivityDescription
		{
			get { return this.activityDescription; }
			set { this.activityDescription = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDateTime, ClientValidators=EnumClientValidators.Required)]	// don't use date-time validation
		public System.DateTime DueDate
		{
			get { return this.dueDate; }
			set { this.dueDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedTeamID
		{
			get { return this.assignedTeamID; }
			set { this.assignedTeamID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedUserID
		{
			get { return this.assignedUserID; }
			set { this.assignedUserID = value; }
		}

		public string AssignedTeamAndUserDisplay
		{
			get { return FormatTeamAndUserForDisplay( this.assignedTeamID, this.assignedUserID); }
		}

		public string AssignedTeamName
		{
			get { return TeamCollection.AllTeams.Lookup_CodeByTeamId(this.assignedTeamID); }
		}

		public string AssignedUserName
		{
			get { return AAUserCollection.AllUsers.Lookup_LoginNameByUserId(this.assignedUserID); }
		}

		[FieldValuesMember("ValuesOf_ActivityPriority")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ActivityPriority
		{
			get { return this.activityPriority; }
			set { this.activityPriority = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		[FieldDescription("@COMMENT@")]
		public string CompletionNote
		{
			get { return this.completionNote; }
			set { this.completionNote = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CompletionDate
		{
			get { return this.completionDate; }
			set { this.completionDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public decimal ActivityAmount
		{
			get { return this.activityAmount; }
			set { this.activityAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public decimal ManagementServiceRate
		{
			get { return this.managementServiceRate; }
			set { this.managementServiceRate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool IsBillable
		{
			get { return this.isBillable; }
			set { this.isBillable = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public decimal BaseAmount
		{
			get { return this.baseAmount; }
			set { this.baseAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public decimal ExtendedAmount
		{
			get { return this.extendedAmount; }
			set { this.extendedAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@TOTAL@")]
		public decimal BillableAmount
		{
			get { return this.billableAmount; }
			set { this.billableAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public decimal BaseConvMult
		{
			get { return this.baseConvMult; }
			set { this.baseConvMult = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public decimal BaseConvDiv
		{
			get { return this.baseConvDiv; }
			set { this.baseConvDiv = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int InterventionID
		{
			get { return this.interventionID; }
			set { this.interventionID = value; }
		}

		[FieldValuesMember("LookupOf_ActivityCompletionID", "ActivityCompletionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ActivityCompletionID
		{
			get { return this.activityCompletionID; }
			set { this.activityCompletionID = value; }
		}

		[FieldValuesMember("LookupOf_ActivityTypeID", "ActivityTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int ActivityTypeID
		{
			get { return this.activityTypeID; }
			set { this.activityTypeID = value; }
		}

		/// <summary>
		/// Activity Type for the activity type id set.
		/// </summary>
		public ActivityType ActivityType
		{
			get
			{
				if (this.activityTypeID == 0)
					return null;
				else
					return ActivityTypeCollection.ActiveActivityTypes.FindBy(activityTypeID);
			}
		}

		[FieldValuesMember("LookupOf_ManagementServiceItemID", "ManagementServiceItemId", "ServiceTypeDescription")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ManagementServiceItemID
		{
			get { return this.managementServiceItemID; }
			set { this.managementServiceItemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PhysicianReviewID
		{
			get { return this.physicianReviewID; }
			set { this.physicianReviewID = value; }
		}

		//[FieldValuesMember("LookupOf_ManagementServiceTypeId", "ManagementServiceTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ManagementServiceTypeId
		{
			get { return this.managementServiceTypeId; }
			set { this.managementServiceTypeId = value; }
		}

		[FieldValuesMember("LookupOf_ActivitySubtypeID", "ActivitySubtypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ActivitySubtypeID
		{
			get { return this.activitySubtypeID; }
			set { this.activitySubtypeID = value; }
		}

		[FieldValuesMember("LookupOf_BaseUnitOfMeasureId", "BaseUnitOfMeasureId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@BASEUOM@")]
		public int BaseUOMId
		{
			get { return this.baseUOMId; }
			set { this.baseUOMId = value; }
		}

		[FieldDescription("@RATEUNITS@")]
		public string Fmt_BaseUOMID
		{
			get 
			{ 
				return BaseUnitOfMeasureCollection.ActiveBaseUnitOfMeasures.Lookup_DescriptionByBaseUnitOfMeasureId(this.baseUOMId); 
			}
		}

		public BaseUnitOfMeasureCollection LookupOf_BaseUnitOfMeasureId
		{
			get
			{
				return BaseUnitOfMeasureCollection.ActiveBaseUnitOfMeasures; // Acquire a shared instance from the static member of collection
			}
		}


		[FieldValuesMember("LookupOf_ConversionUnitOfMeasureId", "ConversionUnitOfMeasureId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@CONVERSIONUOM@")]
		public int ConversionUOMId
		{
			get { return this.conversionUOMId; }
			set { this.conversionUOMId = value; }
		}

		[FieldDescription("@UNITS@")]
		public string Fmt_ConversionUnitOfMeasureId
		{
			get 
			{ 
				return ConversionUnitOfMeasureCollection.ActiveConversionUnitOfMeasures.Lookup_DescriptionByConversionUnitOfMeasureId(this.conversionUOMId); 
			}
		}

		public ConversionUnitOfMeasureCollection LookupOf_ConversionUnitOfMeasureId
		{
			get
			{
				return ConversionUnitOfMeasureCollection.ActiveConversionUnitOfMeasures; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Parent ActivityCollection that contains this element
		/// </summary>
		public ActivityCollection ParentActivityCollection
		{
			get
			{
				return this.parentActivityCollection;
			}
			set
			{
				this.parentActivityCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Save method for an existing activity.
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			if (this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "You must save a new activity only in the context of a patient-subscriber-coverage");

			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.None,
					"You must save an existing Activity only in the context of a patient");

			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Save method for a new Activity.
		/// A new Activity can be saved only in the context of a selected patient-subscriver-coverage
		/// </summary>
		public void Save(PatientCoverage patCov)
		{
			if (!this.IsNew)
				throw new ActiveAdviceException(AAExceptionAction.None, "Activity.Save(patCov) can be called only for a new activity");

			if (patient == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "A new activity can be saved in the context of a patient");

			if (patCov == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "A new activity can be saved in the context of a patient-coverage");

			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				// set the planId from the selected coverage
				SetCoverage(this.patient, patCov);

				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		protected void SetCoverage(Patient patient, PatientCoverage patCov)
		{
			this.plan = patCov.Plan;
			this.planId = patCov.PlanID;

			PatientSubscriberLog lastPatSubLog = PatientSubscriberLog.GetLastPatientSubscriberLogEntry(patient, patCov);
			if (lastPatSubLog == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI,
					"No patient-subscriber-log entry found for PatientID={0}, PatientCoverageID={1}", patient.PatientId, patCov.PatientCoverageID);
			this.patientSubscriberLogID = lastPatSubLog.PatientSubscriberLogId;
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int activityID)
		{
			return base.Load(activityID);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CompletedByUserID
		{
			get { return this.completedByUserID; }
			set { this.completedByUserID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ParentActivityID
		{
			get { return this.parentActivityID; }
			set { this.parentActivityID = value; }
		}

		public ActivityTypeCollection LookupOf_ActivityTypeID
		{
			get
			{
				// Load all the active activity types for the selected primary type
				if (this.primaryType == 0)
					return ActivityTypeCollection.ActiveActivityTypes;
				else
					return ActivityTypeCollection.GetActiveActivityTypes(this.primaryType); // Acquire a shared instance from the static member of collection
			}
		}

		public ActivitySubTypeCollection LookupOf_ActivitySubtypeID
		{
			get
			{
				ActivityType actType = this.ActivityType;
				if (actType == null)
					return ActivitySubTypeCollection.ActiveActivitySubTypes; // Return all subtypes
				else
					return actType.GetActiveSubTypes();
			}
		}

		public int[] ValuesOf_ActivityPriority
		{
			get
			{
				return new int[] { 1, 2, 3, 4 }; // return possible field values
			}
		}

		[FieldValuesMember("LookupOf_PrimaryType", "ActivityPrimaryTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int PrimaryType
		{
			get { return this.primaryType; }
			set { this.primaryType = value; }
		}

		public ActivityPrimaryTypeCollection LookupOf_PrimaryType
		{
			get
			{
				return ActivityPrimaryTypeCollection.ActiveActivityPrimaryTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// set correct primary type filter combo for current activity type
			if (this.activityTypeID != 0)
			{
				ActivityType atype = ActivityTypeCollection.ActiveActivityTypes.FindBy(this.activityTypeID);
				if (atype != null)
					this.primaryType = atype.ActivityPrimaryTypeID;
			}
		}

		/// <summary>
		/// Get the associated plan from db
		/// </summary>
		/// <returns></returns>
		public Plan GetPlan()
		{
			if (this.planId == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.planId))
				return plan;
			else
				return null;
		}

		/// <summary>
		/// Get the associated plan from db and cache it.
		/// </summary>
		public Plan Plan
		{
			get
			{
				if (this.plan == null)
					this.plan = this.GetPlan();
				return this.plan;
			}
		}

		// This is a joined column coming from Plans table.
		[ControlType(EnumControlTypes.TextBox)]
		public string PlanName
		{
			get 
			{ 
				if (this.planName == null)
				{
					// load from Plans
					Plan plan = this.Plan;
					if (plan != null)
						this.planName = plan.Name;
				}
				return this.planName; 
			}
		}

		public ActivityCompletionCollection LookupOf_ActivityCompletionID
		{
			get
			{
				return ActivityCompletionCollection.ActiveActivityCompletions; // Acquire a shared instance from the static member of collection
			}
		}

		/*public ManagementServiceTypeCollection LookupOf_ManagementServiceTypeId
		{
			get
			{
				return ManagementServiceTypeCollection.ActiveManagementServiceTypes; // Acquire a shared instance from the static member of collection
			}
		}*/

		/// <summary>
		/// Return the linked problems for the parent patient.
		/// </summary>
		public ProblemCollection LookupOf_ProblemId
		{
			get
			{
				if (this.Patient == null)
					return null;
				return this.Patient.GetLinkedProblems();
			}
		}

		/// <summary>
		/// Return the linked events for the parent patient. 
		/// </summary>
		public EventCollection LookupOf_EventID
		{
			get
			{
				if (this.Patient == null)
					return null;
				return this.Patient.GetLinkedEvents();
			}
		}

		/// <summary>
		/// Return the linked CMS's for the parent patient.
		/// </summary>
		public CMSCollection LookupOf_CMSID
		{
			get
			{
				if (this.Patient == null)
					return null;
				return this.Patient.GetLinkedCMSs();
			}
		}

		/// <summary>
		/// Return the linked Referrals for the parent patient.
		/// </summary>
		public ReferralCollection LookupOf_ReferralID
		{
			get
			{
				if (this.Patient == null)
					return null;
				return this.Patient.GetLinkedReferrals();
			}
		}

		/// <summary>
		/// Return the management service items of the associated plan
		/// </summary>
		public ManagementServiceItemCollection LookupOf_ManagementServiceItemID
		{
			get
			{
				if (this.Plan == null)
					return null;

				this.Plan.ManagementService.LoadManagementServiceItems(false);		// ensure management service items loaded
				return this.Plan.ManagementService.ManagementServiceItems;
			}
		}

		
		/// <summary>
		/// Load the event related to this activity and return it.
		/// </summary>
		/// <returns></returns>
		public Event GetEvent()
		{
			if (this.eventID == 0)
				return null;

			Event eventObj = new Event();
			if (eventObj.Load(this.Patient, eventID))
				return eventObj;
			else
				return null;

		}

		/// <summary>
		/// Load the referral related to this activity and return it.
		/// </summary>
		/// <returns></returns>
		public Referral GetReferral()
		{
			if (this.referralID == 0)
				return null;

			Referral referral = new Referral();
			if (referral.Load(referralID))
				return referral;
			else
				return null;

		}

		/// <summary>
		/// Load the cms related to this activity and return it.
		/// </summary>
		/// <returns></returns>
		public CMS GetCMS()
		{
			if (this.cMSID == 0)
				return null;

			CMS cms = new CMS();
			if (cms.Load(cMSID))
				return cms;
			else
				return null;

		}

		/// <summary>
		/// Load the problem related to this activity and return it.
		/// </summary>
		/// <returns></returns>
		public Problem GetProblem()
		{
			if (this.problemId == 0)
				return null;

			Problem problem= new Problem();
			if (problem.Load(problemId))
				return problem;
			else
				return null;

		}

		/// <summary>
		/// Load the patient related to this activity and return it.
		/// </summary>
		/// <returns></returns>
		public Patient GetPatient()
		{
			if (this.patientId == 0)
				return null;

			Patient patient = new Patient();
			if (patient.Load(patientId))
				return patient;
			else
				return null;

		}


		/// <summary>
		/// Load and cache the patient related to this activity.  If a patient was already
		/// passed during construction, it's returned.
		/// </summary>
		public Patient Patient
		{
			get 
			{ 
				if (this.patient == null)
					this.patient = GetPatient();
				return this.patient; 
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string ActivityCompletionCode
		{
			get { return ActivityCompletionCollection.ActiveActivityCompletions.Lookup_CodeByActivityCompletionID(this.activityCompletionID); }
			set { this.activityCompletionID = ActivityCompletionCollection.ActiveActivityCompletions.Lookup_ActivityCompletionIDByCode(value); }
		}

		/// <summary>
		/// Call this whenever you want the CompletedByUserID and CompletionDate fields to be set from the current user context
		/// This is set by the UI
		/// </summary>
		public void SetCompletingUser()
		{
			// will set the inactivating user from the current user context
			Debug.WriteLine("Activity set completing user for  " + this.PKString);
			
			this.completedByUserID = 1;
			this.completionDate = DateTime.Now;
		}

		public ManagementServiceItem PullManagementServiceItemFields()
		{
			ManagementServiceItemCollection serviceitems = this.LookupOf_ManagementServiceItemID;
			if (serviceitems == null)
				return null;
			serviceitems.IndexBy_ManagementServiceItemId.Rebuild();
			ManagementServiceItem serviceItem = serviceitems.FindBy(this.managementServiceItemID);

			if (serviceItem != null)
			{
				// copy fields
				this.managementServiceTypeId = serviceItem.ManagementServiceTypeId;
				this.managementServiceRate = serviceItem.Rate;
				this.baseUOMId = serviceItem.BaseUnitOfMeasureId;
				this.conversionUOMId = serviceItem.ConversionUnitOfMeasureId;
				this.isBillable = serviceItem.Billable;
				this.baseConvMult = (decimal)serviceItem.Multiplier;
				this.baseConvDiv = (decimal)serviceItem.Divider;
			}
			return serviceItem;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientSubscriberLogID
		{
			get { return this.patientSubscriberLogID; }
			set { this.patientSubscriberLogID = value; }
		}

		public void CalculateTotal()
		{
			this.extendedAmount = CalculateServiceAmountByRate(this.activityAmount, this.managementServiceRate, (decimal)baseConvDiv, (decimal)baseConvMult);
			if (this.isBillable)
				this.billableAmount = this.extendedAmount;
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "	activityID= '" + ReflectionHelper.GetMemberValueAsString(this, "activityID") + "'\r\n";
			s += "	activityDescription= '" + ReflectionHelper.GetMemberValueAsString(this, "activityDescription") + "'\r\n";
			s += "	patientId= '" + ReflectionHelper.GetMemberValueAsString(this, "patientId") + "'\r\n";
			s += "	planId= '" + ReflectionHelper.GetMemberValueAsString(this, "planId") + "'\r\n";
			s += "	problemId= '" + ReflectionHelper.GetMemberValueAsString(this, "problemId") + "'\r\n";
			s += "	eventID= '" + ReflectionHelper.GetMemberValueAsString(this, "eventID") + "'\r\n";
			s += "	referralID= '" + ReflectionHelper.GetMemberValueAsString(this, "referralID") + "'\r\n";
			s += "	reviewID= '" + ReflectionHelper.GetMemberValueAsString(this, "reviewID") + "'\r\n";
			s += "	cMSID= '" + ReflectionHelper.GetMemberValueAsString(this, "cMSID") + "'\r\n";
			s += "}\r\n";
			return s;

		}

		public string ActivityCompletionStatus
		{
			get 
			{ 
				if (this.activityCompletionStatus == null)
					this.activityCompletionStatus = ActivityCompletionCollection.ActiveActivityCompletions.Lookup_CodeStatusByActivityCompletionID(this.activityCompletionID);
				return this.activityCompletionStatus;
			}
			set { this.activityCompletionStatus = value; }
		}

		/// <summary>
		/// Returns the loaded and cached patient subscriber log entry
		/// </summary>
		public PatientSubscriberLog PatientSubscriberLog
		{
			get
			{
				if (this.patSubLog == null)
					this.patSubLog = GetPatientSubscriberLog();
				return this.patSubLog;
			}
		}

		/// <summary>
		/// Loads and retuns the linked patient subscriber log entry
		/// </summary>
		/// <returns></returns>
		public PatientSubscriberLog GetPatientSubscriberLog()
		{
			if (this.patientSubscriberLogID == 0)
				return null;
			PatientSubscriberLog patSubLog = new PatientSubscriberLog();
			if (patSubLog.Load(this.patientSubscriberLogID))
				return patSubLog;
			else
				return null;
		}

		public void CopyTo(Activity activity)
		{
			this.CopyMappedMembersTo(activity, false, false, false);
		}

		/// <summary>
		/// Create a copy of this activity.
		/// </summary>
		/// <returns></returns>
		public Activity CreateCopy()
		{
			Activity newAct = new Activity(this.Patient, true);
			this.CopyTo(newAct);
			return newAct;
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.dueDate = DateTime.Today;
		}

	}

	/// <summary>
	/// Strongly typed collection of Activity objects
	/// </summary>
	[ElementType(typeof(Activity))]
	public class ActivityCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Activity elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentActivityCollection = this;
			else
				elem.ParentActivityCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Activity elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Activity this[int index]
		{
			get
			{
				return (Activity)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Activity)oldValue, false);
			SetParentOnElem((Activity)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Search activities and load the collection.
		/// </summary>
		public int SearchActivities(int maxRecords, ActivitySearcher searcher)
		{
			this.Clear();

			if (searcher.SortField == null)
				searcher.SortField = searcher.PKFields[0];
			
			return SqlData.SPExecReadCol("usp_SearchActivities", maxRecords, this, searcher, false, 
				new string[] { "rowCount", "isBillable", "activityPrimaryTypeID" },
				new object[] { 
								 maxRecords < 0 ? 0 : maxRecords,
								 searcher.IsBillable ? (object)true : DBNull.Value,
								 SQLDataDirect.MakeDBValue(searcher.PrimaryType, 0) } );

			// if isbillable = false, don't include this in search.
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Activity elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Activity)value, true);
			base.OnInsertComplete (index, value);		
		}

	}

	/// <summary>
	/// Used in the Activity/Worklist Search page.
	/// </summary>
	public class ActivitySummary : Activity
	{
		[ColumnMapping("PatientFirstName")]
		protected string patientFirstName;
		[ColumnMapping("PatientLastName")]
		protected string patientLastName;

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientFirstName
		{
			get { return this.patientFirstName; }
			set { this.patientFirstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PatientLastName
		{
			get { return this.patientLastName; }
			set { this.patientLastName = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ActivitySummary objects
	/// </summary>
	[ElementType(typeof(ActivitySummary))]
	public class ActivitySummaryCollection : ActivityCollection
	{
		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ActivitySummary this[int index]
		{
			get
			{
				return (ActivitySummary)List[index];
			}
			set
			{
				List[index] = value;
			}
		}
	}

	public enum EnumActivityContext
	{
		Activity = 0,
		WorkList = 1
	}

	/// <summary>
	/// Derives from Activity and contains extra fields that are
	/// used only in the search.
	/// </summary>
	public class ActivitySearcher : Activity
	{
		private EnumActivityContext context = EnumActivityContext.Activity;

		[ColumnMapping(null)]
		private string sortField;
		[ColumnMapping(null)]
		private DateTime fromDueDate;
		[ColumnMapping(null)]
		private DateTime toDueDate;
		[ColumnMapping(null)]
		private DateTime fromCompletionDate;
		[ColumnMapping(null)]
		private DateTime toCompletionDate;

		public ActivitySearcher()
		{
			this.SetMembersNull(true, true);
		}

		[FieldValuesMember("ValuesOf_SortField")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string SortField
		{
			get { return this.sortField; }
			set { this.sortField = value; }
		}

		public string[,] ValuesOf_SortField
		{
			get
			{
				return new string[,] 
				{
					//{ "patientId", "@PATIENT@" },
					{ "activityID", "@ACTIVITYID@" },
					{ "cMSID", "@CMS@" },
					//{ "planId", "@PLAN@" },
					{ "problemId", "@PROBLEM@" },
					{ "eventID", "@EVENT@" },
					{ "referralID", "@REFERRAL@" },
					{ "reviewID", "@REVIEW@" },
					{ "physicianReviewDetailID", "@PHYSICIANREVIEWDETAIL@" },
					//{ "physicianINDPhysicianReviewID", "@PHYSICIANREVIEWDETAIL@" },
					{ "physicianReviewID", "@PHYSICIANREVIEW@" },
					{ "activityTypeDescription", "@ACTIVITYTYPE@" },
					{ "activityPriority", "@PRIORITY@" },
					{ "activityCompletionCode", "@COMPLETIONCODE@" },
					{ "activityCompletionStatus", "@STATUS@" },
					{ "isBillable", "@ISBILLABLE@" },
					{ "completedByUser", "@COMPLETEDBYUSERID@" },
					{ "assignedUser", "@ASSIGNEDUSER@" },
					{ "assignedTeamID", "@ASSIGNEDTEAM@" },
					{ "completionDate", "@COMPLETIONDATE@" },
					{ "dueDate", "@DUEDATE@" },
					{ "interventionID", "@INTERVENTIONID@" }
				};
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime FromDueDate
		{
			get { return this.fromDueDate; }
			set { this.fromDueDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ToDueDate
		{
			get { return this.toDueDate; }
			set { this.toDueDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime FromCompletionDate
		{
			get { return this.fromCompletionDate; }
			set { this.fromCompletionDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ToCompletionDate
		{
			get { return this.toCompletionDate; }
			set { this.toCompletionDate = value; }
		}

		public ActiveAdvice.DataLayer.EnumActivityContext Context
		{
			get { return this.context; }
			set { this.context = value; }
		}

		
	}

}
