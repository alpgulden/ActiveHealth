using System;
using System.Data.SqlClient;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using System.Collections;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Utility class that manages automatic creation of activities
	/// based on auto-activity rules.
	/// </summary>
	public class AutoActivityManager
	{
		private SqlTransaction transaction;
		private Patient patient;
		private PatientCoverage patientCoverage;
		private BaseForEventCMSReferral erc;
		//private ActivityCollection activities = new ActivityCollection();

		private ArrayList messageLog = new ArrayList();		// track of allt the steps performed

		#region Rule filter variables

		[ColumnMapping(null)]
		public DateTime date;
		[ColumnMapping(null, (int)0)]
		public int ruleTypeID;
		[ColumnMapping(null)]
		public string cat;			// rule category
		[ColumnMapping(null, (int)0)]
		public int eventTypeID;
		[ColumnMapping(null, (int)0)]
		public int referralTypeID;
		[ColumnMapping(null, (int)0)]
		public int cmsTypeID;
		[ColumnMapping(null, (int)0)]
		public int decisionTypeID;
		[ColumnMapping(null, (int)0)]
		public int planID;
		[ColumnMapping(null, (int)0)]
		public int managementServiceId;		// from the plan
		[ColumnMapping(null, (int)0)]
		public int morgID;
		[ColumnMapping(null, (int)0)]
		public int orgID;
		[ColumnMapping(null, (int)0)]
		public int sorgID;
		[ColumnMapping(null)]
		public string lastName;
		[ColumnMapping(null)]
		public string zip;
		[ColumnMapping(null, (int)0)]
		public int stateID;
		[ColumnMapping(null)]
		public string facilityFedTaxId;
		[ColumnMapping(null, (int)0)]
		public int facilityNetworkStatusId;
		[ColumnMapping(null, (int)0)]
		public int facilityLocationNetworkId;
		[ColumnMapping(null)]
		public string providerFedTaxId;
		[ColumnMapping(null, (int)0)]
		public int providerNetworkStatusId;
		[ColumnMapping(null, (int)0)]
		public int providerLocationNetworkId;
		[ColumnMapping(null)]
		public string referProviderFedTaxId;
		[ColumnMapping(null, (int)0)]
		public int referProviderNetworkStatusId;
		[ColumnMapping(null, (int)0)]
		public int referProviderLocationNetworkId;
		[ColumnMapping(null, (int)0)]
		public int noteTypeId;
		[ColumnMapping(null, (int)0)]
		public int problemId;

		#endregion

		public AutoActivityManager()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public AutoActivityManager(Patient patient, PatientCoverage patientCoverage)
		{
			this.patient = patient;
			this.patientCoverage = patientCoverage;
		}

		public void SetEventContext(Event evt)
		{
			this.erc = (BaseForEventCMSReferral)evt;
		}

		public void SetReferralContext(Referral referral)
		{
			this.erc = (BaseForEventCMSReferral)referral;
		}

		public void SetCMSContext(CMS cms)
		{
			this.erc = (BaseForEventCMSReferral)cms;
		}

		public System.Data.SqlClient.SqlTransaction Transaction
		{
			get { return this.transaction; }
			set { this.transaction = value; }
		}

		public ArrayList MessageLog
		{
			get { return this.messageLog; }
		}

		public void AddToMessageLog(string msg)
		{
			this.messageLog.Add(msg);
			Debug.WriteLine(msg);
		}

		public void AddToMessageLog(string msg, params object[] parameters)
		{
			AddToMessageLog(String.Format(msg, parameters));
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "}\r\n";

			for (int i = 0; i < this.messageLog.Count; i++)
			{
				s += this.messageLog[i].ToString() + "\r\n";
			}
			
			return s;
		}

		/// <summary>
		/// Find related rules for the current context and execute them.
		/// </summary>
		/// <param name="transaction"></param>
		public void Execute(string ruleTypeCode, SqlTransaction transaction)
		{
			// BR01.2.18	When an event is closed that has open activities associated with it, 
			// the System shall evaluate Closing Event and Closing Event with Open Activities 
			// rules and exceptions.  NOT IMPL

			// BR01.2.19	If an auto activity rule has network status as a criteria but not 
			// network ID then the application shall check to see if any of the provider�s or 
			// facility�s networks are In Network to determine if the rule or exception is met.  NOT IMPL

			this.Transaction = transaction;

			AddToMessageLog("Executing AutoActivity {0}", ruleTypeCode );

			AutoActivityRuleCollection rules = new AutoActivityRuleCollection();
			rules.LoadRules(ruleTypeCode, this);

			foreach (AutoActivityRule rule in rules)
			{
				AutoActivityRuleExceptionCollection exceps = new AutoActivityRuleExceptionCollection();
				exceps.LoadExceptions(ruleTypeCode, rule, this);
				
				if (exceps.Count > 0)
				{
					// There were exceptions matching
					// Create related activities for them.
					foreach (AutoActivityRuleException excep in exceps)
						if (excep.GenerateActivity)
							CreateActivities(excep);
				}
				else
				{
					// There was no matching exceptions
					// Create related activities for this rule.
					CreateActivities(rule);
				}
			}

		}

		/// <summary>
		/// Create activities using the related initialization values.
		/// </summary>
		/// <param name="brule"></param>
		private void CreateActivities(BaseAutoActivityRule brule)
		{
			// BR01.2.11	The System shall not generate an Activity when a Coding 
			// Diagnosis or Coding Procedure rule is met if a CMS case is already open 
			// for the patient.   NOT IMPL

			// BR01.2.12	The System shall notify the User when an Activity cannot 
			// be generated because the Management Service for the plan is not active 
			// on the due date.   NOT IMPL

			AddToMessageLog(String.Format( "Creating activity for {0}", brule.DebugDescription ));

			Event evt = erc as Event;
			Referral referral = erc as Referral;
			CMS cms = erc as CMS;

			brule.LoadAutoActivityInitializationValues(false);

			for (int i = 0; i < brule.AutoActivityInitializationValues.Count; i++)
			{
				AutoActivityInitializationValue init = brule.AutoActivityInitializationValues[i];
				if (init.Active)
				{
					Activity act = new Activity(patient, patientCoverage);
					if (init.ActivityTypeID != 0)
						act.ActivityTypeID = init.ActivityTypeID;
					if (init.AssignedTeamID != 0)
						act.AssignedTeamID = init.AssignedTeamID;
					if (init.AssignedUserID != 0)
						act.AssignedUserID = init.AssignedUserID;
					if (init.CompletionID != 0)
						act.ActivityCompletionID = init.CompletionID;
					DateTime dueDate = DateTime.Today.AddDays(init.DateOffset);
					if (init.DateSource == AutoActivityInitDateSource.SERV)
						dueDate = erc.ERCServiceDate;
					else if (init.DateSource == AutoActivityInitDateSource.END)
					{
						// BR01.2.16	If the due date type (in activity default values) 
						// is equal to End Date and there are multiple decisions, the application 
						// shall use the end date from the most recent decision. If the most 
						// recent decision does not have an end date, the application must use 
						// the current date for the activity due date.

						if (evt != null)
						{
							ClinicalReviewDecision lastDecision = evt.LastDecision;
							if (lastDecision != null)
								if (lastDecision.EndDate != DateTime.MinValue)
									dueDate = lastDecision.EndDate;
						}
						else
						{
							
							if (referral != null)
							{
								ReferralDetail lastDetail = referral.LastDetail;
								if (lastDetail != null)
									if (lastDetail.ValidEndDate != DateTime.MinValue)
										dueDate = lastDetail.ValidEndDate;
							}
						}
					}

					if (evt != null)
						act.EventID = evt.EventID;
					if (referral != null)
						act.ReferralID = referral.ReferralID;
					if (cms != null)
						act.CMSID = cms.CMSID;

					dueDate = dueDate.AddDays(init.DateOffset);
					act.DueDate = dueDate;
					if (init.Description != null)
						act.ActivityDescription = init.Description;
					if (init.PriorityID != 0)
						act.ActivityPriority = init.PriorityID;

					act.SqlData.Transaction = this.transaction;
					act.Save(patientCoverage);
					AddToMessageLog("Activity {0} automatically created.", act.ActivityID);
				}
			}
		}

		public ActiveAdvice.DataLayer.Patient Patient
		{
			get { return this.patient; }
			set { this.patient = value; }
		}

		public ActiveAdvice.DataLayer.PatientCoverage PatientCoverage
		{
			get { return this.patientCoverage; }
			set { this.patientCoverage = value; }
		}

		public ActiveAdvice.DataLayer.BaseForEventCMSReferral ERC
		{
			get { return this.erc; }
			set { this.erc = value; }
		}

		public void PrepareRuleFilterVariables(string ruleTypeCode)
		{
			this.ruleTypeID = AutoActivityRuleTypeCollection.ActiveAutoActivityRuleTypes.Lookup_RuleTypeIdByCode(ruleTypeCode);
			if (this.ruleTypeID == 0)
				throw new ActiveAdviceException(AAExceptionAction.None, "AutoActivity Rule Type {0} not found", ruleTypeCode);
			this.cat = AutoActivityRuleTypeCollection.ActiveAutoActivityRuleTypes.Lookup_CategoryByRuleTypeId(ruleTypeID);
			if (this.cat == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "AutoActivity Rule Type Category for {0} not found", ruleTypeCode);

			Event evt = erc as Event;
			Referral referral = erc as Referral;
			CMS cms = erc as CMS;

			// Find the filters to be used for the current context.

			#region Event, Referral and CMS Type IDs

			this.date = erc.ERCStartDate;

			if (evt != null)
			{
				this.problemId = evt.PrimaryProblemID;
				eventTypeID = evt.EventTypeID;
				if (!evt.IsNew)
				{
					// BR01.2.14	When evaluating event rules and exceptions, the application 
					// must use the decision type from the event�s most recent clinical review 
					// decision. The most recent decision is the one that was added to the database 
					// last. Event rule types are ones with �Event� in the name.
					ClinicalReviewDecision lastDecision = evt.LastDecision;
					if (lastDecision != null)
						this.decisionTypeID = lastDecision.ClinicalReviewDecisionTypeID;
				}
			}

			if (referral != null)
			{
				this.problemId = referral.PrimaryProblemID;
				referralTypeID = referral.ReferralTypeID;
				if (!referral.IsNew)
				{
					// BR01.2.15	When evaluating referral rules and exceptions, the application 
					// must use the decision type from the referral�s most recent decision. The most 
					// recent decision is the one that was added to the database last. Referral rule 
					// types are ones with �Referral� in the name.
					ReferralDetail lastRefDetail = referral.LastDetail;
					if (lastRefDetail != null)
					{
						int referralAuthorizationDecisionID = lastRefDetail.ReferralAuthorizationDecisionID;
						ReferralAuthorizationDecision authDec = ReferralAuthorizationDecisionCollection.ActiveReferralAuthorizationDecisions.FindBy(referralAuthorizationDecisionID);
						if (authDec != null)
							this.decisionTypeID = authDec.ClinicalReviewDecisionTypeCodeID;
					}
				}
			}

			if (cms != null)
			{
				this.problemId = cms.PrimaryProblemID;
				// BR01.2.21	When evaluating Clinical Management Service � Initial Save rules and 
				// exceptions, the application shall use the event type (service category) of the 
				// most recent event.  The most recent event is the one that was added to the database last.

				Event mostRecentEventOfPatient = this.Patient.MostRecentEvent;
				if (mostRecentEventOfPatient != null)
					eventTypeID = mostRecentEventOfPatient.EventTypeID;

				cmsTypeID = cms.CMSTypeID;			// this is not used!!
			}

			#endregion

			#region MORG, ORG, SORG info linked to ERC

			if (this.erc != null)
			{

				if (!erc.SORG.IsSubOrganization)
					throw new ActiveAdviceException(AAExceptionAction.None, "Organization linked to ERC is not a SORG!");

				int[] orgIDs = erc.SORG.ParentOrganizationIDs;
				if (orgIDs == null)
					throw new ActiveAdviceException(AAExceptionAction.None, "SubOrganization path can't be found");

				if (orgIDs.Length < 0)
					throw new ActiveAdviceException(AAExceptionAction.None, "SubOrganization path must contain MORGID and ORGID!");

				sorgID = erc.SORG.OrganizationID;
				orgID = orgIDs[1];
				morgID = orgIDs[0];
			}

			#endregion

			#region Plan information

			if (this.erc != null)
			{
				planID = this.ERC.PlanSORGLog.PlanId;
				this.managementServiceId = this.ERC.PlanSORGLog.Plan.ManagementServiceId;
			}

			#endregion

			#region Patient info lastName, zip, state

			if (this.patient != null)
			{
				lastName = this.patient.LastName;
				zip = this.Patient.Address.Zip;
				string state = this.Patient.Address.State;
				int stateID = 0;
				if (state != null)
					stateID = StateCollection.AllStates.Lookup_StateIDByCode(state);
				//if (stateID == 0)
				//	throw new ActiveAdviceException(AAExceptionAction.None, "Can't find id of state", state);
			}

			#endregion

			#region Primary Diagnostic and Procedure info

			if (this.erc != null)
			{
				string primaryDiagCodeType = null, primaryDiagCode = null;
				string primaryProcCodeType = null, primaryProcCode = null;
				this.ERC.LoadEventReferralDiagnoses(false);
				EventReferralDiagnose primaryDiagnose = this.ERC.EventReferralDiagnoses.PrimaryDiagnose;
				if (primaryDiagnose != null)
				{
					primaryDiagCodeType = primaryDiagnose.DiagnosisType;
					primaryDiagCode = primaryDiagnose.DiagnosisCode;
				}
				this.ERC.LoadEventReferralProcedures(false);
				EventReferralProcedure primaryProcedure = this.ERC.EventReferralProcedures.PrimaryProcedure;
				if (primaryProcedure != null)
				{
					primaryProcCodeType = primaryProcedure.ProcedureType;
					primaryProcCode = primaryProcedure.ProcedureCode;
				}
			}

			#endregion

			#region Facility Info

			// don't know how to get.
			facilityFedTaxId = null;
			facilityNetworkStatusId = 0;
			facilityLocationNetworkId = 0;

			#endregion 

			#region Provider Info

			// don't know how to get.
			providerFedTaxId = null;
			providerNetworkStatusId = 0;
			providerLocationNetworkId = 0;

			#endregion
			
			#region Referring Provider Info

			// don't know how to get.
			referProviderFedTaxId = null;
			referProviderNetworkStatusId = 0;
			referProviderLocationNetworkId = 0;

			#endregion

			#region Note Type
			
			this.noteTypeId = 0;		// don't know how to get

			#endregion

		}

	}
}
