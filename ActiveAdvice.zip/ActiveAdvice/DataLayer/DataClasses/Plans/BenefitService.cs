using System;
using System.Diagnostics;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [BenefitServices]
	/// The Benefit Services provides a location where information pertaining to the 
	/// coverage benefits of a plan is stored in the ActiveAdvice system. This information 
	/// is not associated with any System functionality but is provided for informational 
	/// purposes.  Typically Customer Service, Intake or Administrative staff refers to 
	/// this information when on the phone with a caller.
	/// </summary>
	[SPAutoGen("usp_SearchBenefitServices","SearchByArgs.sptpl","name, listId")]
	[SPAutoGen("usp_GetEffectiveBenefitServicesForDate","SelectActiveRecordsForDate.sptpl","effectiveDate, terminationDate")]
	[SPInsert("usp_InsertBenefitService")]
	[SPUpdate("usp_UpdateBenefitService")]
	[SPDelete("usp_DeleteBenefitService")]
	[SPLoad("usp_LoadBenefitService")]
	[TableMapping("BenefitService","benefitServiceId")]
	public class BenefitService : BaseData
	{
		[NonSerialized]
		private BenefitServiceCollection parentBenefitServiceCollection;
		[ColumnMapping("BenefitServiceId",StereoType=DataStereoType.FK)]
		private int benefitServiceId;
		[ColumnMapping("Name")]
		private string name;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("ListId")]
		private string listId;
		
		private DateTime termDateWhenLoaded;
		private BenefitServiceItemCollection benefitServiceItems;
	
		public BenefitService()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public BenefitService(int benefitServiceId, string name, string listId)
		{
			this.NewRecord(); // initialize record state
			this.benefitServiceId = benefitServiceId;
			this.name = name;
			this.listId = listId;
		}

		public BenefitService(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int BenefitServiceId
		{
			get { return this.benefitServiceId; }
			set { this.benefitServiceId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=128)]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]		// defined in the base
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=15)]
		public string ListId
		{
			get { return this.listId; }
			set { this.listId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SaveBenefitServiceItems(); // save the items in a seperate transaction
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int benefitServiceId)
		{
			return base.Load(benefitServiceId);
		}

		/// <summary>
		/// Use this function to test CRUD operations on this class
		/// </summary>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void TestCRUDOperations()
		{
			for (int i = 0; i < 10; i++)
			{
				BenefitService obj = new BenefitService();  // Use appropriate constructor
				obj.NewRecord();
				// Do other initializations on the object;
				obj.Save();
				Debug.Assert(obj.Load(), "Load failed for BenefitService PK="+obj.PKString);
				// do some change in the properties
				obj.Save();
				obj.MarkDel();  // Mark for deletion
				obj.Save();  // Delete it
			}
		
		}

		/// <summary>
		/// Child BenefitServiceItems mapped to related rows of table BenefitServiceItems where [BenefitServiceId] = [BenefitServiceId]
		/// </summary>
		[SPLoadChild("usp_LoadBenefitServiceItems", "benefitServiceId")]
		public BenefitServiceItemCollection BenefitServiceItems
		{
			get { return this.benefitServiceItems; }
			set
			{
				this.benefitServiceItems = value;
				if (value != null)
					value.ParentBenefitService = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the BenefitServiceItems collection
		/// </summary>
		public void LoadBenefitServiceItems(bool forceReload)
		{
			this.benefitServiceItems = (BenefitServiceItemCollection)BenefitServiceItemCollection.LoadChildCollection("BenefitServiceItems", this, typeof(BenefitServiceItemCollection), benefitServiceItems, forceReload, null);
		}

		/// <summary>
		/// Saves the BenefitServiceItems collection
		/// </summary>
		public void SaveBenefitServiceItems()
		{
			BenefitServiceItemCollection.SaveChildCollection(this.benefitServiceItems, true);
		}

		/// <summary>
		/// Synchronizes the BenefitServiceItems collection
		/// </summary>
		public void SynchronizeBenefitServiceItems()
		{
			BenefitServiceItemCollection.SynchronizeChildCollection(this.benefitServiceItems, true);
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			
			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}

			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Parent BenefitServiceCollection that contains this element
		/// </summary>
		public BenefitServiceCollection ParentBenefitServiceCollection
		{
			get
			{
				return this.parentBenefitServiceCollection;
			}
			set
			{
				this.parentBenefitServiceCollection = value; // parent is set when added to a collection
			}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFields(this, "Name");
				//writer.AddFieldsOnNewLine(this, "EffectiveDate", "TerminationDate");
			}
		}

		/// <summary>
		/// Create a copy of this benefit service.
		/// All items are also copied.
		/// </summary>
		/// <returns></returns>
		public BenefitService CreateCopyOfBenefitService()
		{
			BenefitService bsvc = new BenefitService(true);
			this.CopyMappedMembersTo(bsvc, false, false, false);

			// copy items
			this.LoadBenefitServiceItems(false);
			bsvc.LoadBenefitServiceItems(false);
			this.BenefitServiceItems.CopyElementsTo(bsvc.BenefitServiceItems, false, true);		// deep copy, don't mark new

			return bsvc;
		}

	}

	/// <summary>
	/// Strongly typed collection of BenefitService objects
	/// </summary>
	[ElementType(typeof(BenefitService))]
	public class BenefitServiceCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_BenefitServiceId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(BenefitService elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentBenefitServiceCollection = this;
			else
				elem.ParentBenefitServiceCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (BenefitService elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public BenefitService this[int index]
		{
			get
			{
				return (BenefitService)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((BenefitService)oldValue, false);
			SetParentOnElem((BenefitService)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Load all active benefit services for the given date
		/// </summary>
		public int LoadEffectiveBenefitServicesForDate(int maxRecords, DateTime currentDate)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetEffectiveBenefitServicesForDate", maxRecords, this, false, currentDate);
		}

		/// <summary>
		/// Accessor to a shared BenefitServiceCollection which is cached in NSGlobal
		/// </summary>
		public static BenefitServiceCollection EffectiveBenefitServices
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				BenefitServiceCollection col = (BenefitServiceCollection)NSGlobal.EnsureCachedObject("EffectiveBenefitServices", typeof(BenefitServiceCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadEffectiveBenefitServicesForDate(-1, DateTime.Today);
				}
				return col;
			}
		}

		public static void ClearFromCache()
		{
			NSGlobal.ClearCache(typeof(BenefitServiceCollection), false);
		}

		/// <summary>
		/// Search and load the collection
		/// </summary>
		public int Search(int maxRecords, BenefitService searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchBenefitServices", maxRecords, this, searcher, false);
		}

		/// <summary>
		/// Hashtable based index on benefitServiceId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_BenefitServiceId
		{
			get
			{
				if (this.indexBy_BenefitServiceId == null)
					this.indexBy_BenefitServiceId = new CollectionIndexer(this, new string[] { "benefitServiceId" }, true);
				return this.indexBy_BenefitServiceId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on benefitServiceId fields returns the object.  Uses the IndexBy_BenefitServiceId indexer.
		/// </summary>
		public BenefitService FindBy(int benefitServiceId)
		{
			return (BenefitService)this.IndexBy_BenefitServiceId.GetObject(benefitServiceId);
		}
	}
}
