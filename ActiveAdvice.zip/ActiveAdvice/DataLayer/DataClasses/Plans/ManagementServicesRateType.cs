using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ManagementServicesRateTypes]
	/// </summary>
	/// 
	[SPAutoGen("usp_GetAllManagementServiceRateTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetManagementServicesRateTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertManagementServicesRateType")]
	[SPUpdate("usp_UpdateManagementServicesRateType")]
	[SPDelete("usp_DeleteManagementServicesRateType")]
	[SPLoad("usp_LoadManagementServicesRateType")]
	[TableMapping("ManagementServicesRateType","managementServicesRateTypeId")]
	public class ManagementServicesRateType : BaseLookupWithCode
	{
		[NonSerialized]
		private ManagementServicesRateTypeCollection parentManagementServicesRateTypeCollection;
		[ColumnMapping("ManagementServicesRateTypeId",StereoType=DataStereoType.FK)]
		private int managementServicesRateTypeId;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public ManagementServicesRateType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ManagementServicesRateType(int managementServicesRateTypeId, string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.managementServicesRateTypeId = managementServicesRateTypeId;
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ManagementServicesRateTypeId
		{
			get { return this.managementServicesRateTypeId; }
			set { this.managementServicesRateTypeId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int managementServicesRateTypeId)
		{
			return base.Load(managementServicesRateTypeId);
		}

		/// <summary>
		/// Parent ManagementServicesRateTypeCollection that contains this element
		/// </summary>
		public ManagementServicesRateTypeCollection ParentManagementServicesRateTypeCollection
		{
			get
			{
				return this.parentManagementServicesRateTypeCollection;
			}
			set
			{
				this.parentManagementServicesRateTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of ManagementServicesRateType objects
	/// </summary>
	[ElementType(typeof(ManagementServicesRateType))]
	public class ManagementServicesRateTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ManagementServicesRateType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentManagementServicesRateTypeCollection = this;
			else
				elem.ParentManagementServicesRateTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ManagementServicesRateType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ManagementServicesRateType this[int index]
		{
			get
			{
				return (ManagementServicesRateType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ManagementServicesRateType)oldValue, false);
			SetParentOnElem((ManagementServicesRateType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads the collection with active management service rate types either active or inactive
		/// </summary>
		public int LoadManagementServicesRateTypesByActive(int maxRecords, bool active)
		{
			return SqlData.SPExecReadCol("usp_GetManagementServicesRateTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ManagementServicesRateTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ManagementServicesRateTypeCollection ActiveManagementServicesRateTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ManagementServicesRateTypeCollection col = (ManagementServicesRateTypeCollection)NSGlobal.EnsureCachedObject("ActiveManagementServicesRateTypes", typeof(ManagementServicesRateTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadManagementServicesRateTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Loads all Management Service Rate Types into collection.
		/// </summary>
		public override void LoadAll()
		{
			SqlData.SPExecReadCol("usp_GetAllManagementServiceRateTypes", -1, this, false);
		}

		/// <summary>
		/// Searches for Management Service Rate Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchManagementServicesRateTypes", -1, this, false, code, description, active);
		}
	}
}
