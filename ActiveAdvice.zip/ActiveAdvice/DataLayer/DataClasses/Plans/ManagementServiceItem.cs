using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ManagementServiceItems]
	/// </summary>
	[SPInsert("usp_InsertManagementServiceItem")]
	[SPUpdate("usp_UpdateManagementServiceItem")]
	[SPDelete("usp_DeleteManagementServiceItem")]
	[SPLoad("usp_LoadManagementServiceItem")]
	[TableMapping("ManagementServiceItem","managementServiceItemId")]
	public class ManagementServiceItem : BaseDataWithUserDefined
	{
		[NonSerialized]
		private ManagementServiceItemCollection parentManagementServiceItemCollection;
		[ColumnMapping("ManagementServiceItemId",StereoType=DataStereoType.FK)]
		private int managementServiceItemId;
		[ColumnMapping("ManagementServiceId")]
		private int managementServiceId;
		[ColumnMapping("Insurers")]
		private bool insurers;
		[ColumnMapping("Retirees")]
		private bool retirees;
		[ColumnMapping("Spouses")]
		private bool spouses;
		[ColumnMapping("Rate")]
		private int rate;
		[ColumnMapping("Billable")]
		private bool billable;
		[ColumnMapping("Multiplier")]
		private Decimal multiplier;
		[ColumnMapping("Divider")]
		private Decimal divider;
		[ColumnMapping("ManagementServiceTypeId",StereoType=DataStereoType.FK)]
		private int managementServiceTypeId;
		[ColumnMapping("ManagementServicesRateTypeId",StereoType=DataStereoType.FK)]
		private int managementServicesRateTypeId;
		[ColumnMapping("BaseUnitOfMeasureId",StereoType=DataStereoType.FK)]
		private int baseUnitOfMeasureId;
		[ColumnMapping("ConversionUnitOfMeasureId",StereoType=DataStereoType.FK)]
		private int conversionUnitOfMeasureId;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("Dependents")]
		private bool dependents;

		private DateTime termDateWhenLoaded;
	
		public ManagementServiceItem()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ManagementServiceItem(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public ManagementServiceItem(int managementServiceTypeId, int managementServicesRateTypeId, int baseUnitOfMeasureId, int conversionUnitOfMeasureId)
		{
			this.NewRecord(); // initialize record state
			this.managementServiceTypeId = managementServiceTypeId;
			this.managementServicesRateTypeId = managementServicesRateTypeId;
			this.baseUnitOfMeasureId = baseUnitOfMeasureId;
			this.conversionUnitOfMeasureId = conversionUnitOfMeasureId;
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int ManagementServiceItemId
		{
			get { return this.managementServiceItemId; }
			set { this.managementServiceItemId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ManagementServiceId
		{
			get { return this.managementServiceId; }
			set { this.managementServiceId = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Insurers
		{
			get { return this.insurers; }
			set { this.insurers = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Retirees
		{
			get { return this.retirees; }
			set { this.retirees = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Spouses
		{
			get { return this.spouses; }
			set { this.spouses = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int Rate
		{
			get { return this.rate; }
			set { this.rate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Billable
		{
			get { return this.billable; }
			set { this.billable = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal Multiplier
		{
			get { return this.multiplier; }
			set { this.multiplier = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal Divider
		{
			get { return this.divider; }
			set { this.divider = value; }
		}

		[FieldValuesMember("LookupOf_ManagementServiceTypeId", "ManagementServiceTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@MANAGEMENTSVCTYPE@")]
		public int ManagementServiceTypeId
		{
			get { return this.managementServiceTypeId; }
			set { this.managementServiceTypeId = value; }
		}

		[FieldValuesMember("LookupOf_ManagementServicesRateTypeId", "ManagementServicesRateTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@MANAGEMENTSVCRATETYPE@")]
		public int ManagementServicesRateTypeId
		{
			get { return this.managementServicesRateTypeId; }
			set { this.managementServicesRateTypeId = value; }
		}

		[FieldValuesMember("LookupOf_BaseUnitOfMeasureId", "BaseUnitOfMeasureId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@BASEUOM@")]
		public int BaseUnitOfMeasureId
		{
			get { return this.baseUnitOfMeasureId; }
			set { this.baseUnitOfMeasureId = value; }
		}

		[FieldValuesMember("LookupOf_ConversionUnitOfMeasureId", "ConversionUnitOfMeasureId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@CONVERSIONUOM@")]
		public int ConversionUnitOfMeasureId
		{
			get { return this.conversionUnitOfMeasureId; }
			set { this.conversionUnitOfMeasureId = value; }
		}

		/// <summary>
		/// Parent ManagementServiceItemCollection that contains this element
		/// </summary>
		public ManagementServiceItemCollection ParentManagementServiceItemCollection
		{
			get
			{
				return this.parentManagementServiceItemCollection;
			}
			set
			{
				this.parentManagementServiceItemCollection = value; // parent is set when added to a collection
			}
		}

		public ConversionUnitOfMeasureCollection LookupOf_ConversionUnitOfMeasureId
		{
			get
			{
				return ConversionUnitOfMeasureCollection.ActiveConversionUnitOfMeasures; // Acquire a shared instance from the static member of collection
			}
		}

		public ManagementServicesRateTypeCollection LookupOf_ManagementServicesRateTypeId
		{
			get
			{
				return ManagementServicesRateTypeCollection.ActiveManagementServicesRateTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public BaseUnitOfMeasureCollection LookupOf_BaseUnitOfMeasureId
		{
			get
			{
				return BaseUnitOfMeasureCollection.ActiveBaseUnitOfMeasures; // Acquire a shared instance from the static member of collection
			}
		}

		public ManagementServiceTypeCollection LookupOf_ManagementServiceTypeId
		{
			get
			{
				return ManagementServiceTypeCollection.ActiveManagementServiceTypes; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string ServiceTypeDescription
		{
			get { return ManagementServiceTypeCollection.ActiveManagementServiceTypes.Lookup_DescriptionByManagementServiceTypeId(this.managementServiceTypeId); }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			
			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}

			base.InternalSave();
			// Save the child collections here.

		}

		[FieldDescription("@MANAGEMENTSVCTYPE@")]
		public string ManagementServiceDescription
		{
			get { return ManagementServiceTypeCollection.ActiveManagementServiceTypes.Lookup_DescriptionByManagementServiceTypeId(this.managementServiceTypeId); }
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFields(this, "ManagementServiceDescription");
			}
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Dependents
		{
			get { return this.dependents; }
			set { this.dependents = value; }
		}

		/// <summary>
		/// Create a copy of the management service item.
		/// </summary>
		/// <returns></returns>
		public ManagementServiceItem CreateCopyOfManagementServiceItem()
		{
			return (ManagementServiceItem)this.Clone(true);
		}
		

	}

	/// <summary>
	/// Strongly typed collection of ManagementServiceItem objects
	/// </summary>
	[ElementType(typeof(ManagementServiceItem))]
	public class ManagementServiceItemCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ManagementServiceItemId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ManagementServiceItem elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentManagementServiceItemCollection = this;
			else
				elem.ParentManagementServiceItemCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ManagementServiceItem elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ManagementServiceItem this[int index]
		{
			get
			{
				return (ManagementServiceItem)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ManagementServiceItem)oldValue, false);
			SetParentOnElem((ManagementServiceItem)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ManagementServiceItem elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ManagementServiceItem)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent ManagementService that contains this collection
		/// </summary>
		public ManagementService ParentManagementService
		{
			get { return this.ParentDataObject as ManagementService; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ManagementService */ }
		}

		/// <summary>
		/// Hashtable based index on managementServiceItemId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ManagementServiceItemId
		{
			get
			{
				if (this.indexBy_ManagementServiceItemId == null)
					this.indexBy_ManagementServiceItemId = new CollectionIndexer(this, new string[] { "managementServiceItemId" }, true);
				return this.indexBy_ManagementServiceItemId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on managementServiceItemId fields returns the object.  Uses the IndexBy_ManagementServiceItemId indexer.
		/// </summary>
		public ManagementServiceItem FindBy(int managementServiceItemId)
		{
			return (ManagementServiceItem)this.IndexBy_ManagementServiceItemId.GetObject(managementServiceItemId);
		}
	}
}
