using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PlanPayorHEDISTypes]
	/// </summary>
	[SPAutoGen("usp_GetPlanPayorHEDISTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertPlanPayorHEDISType")]
	[SPUpdate("usp_UpdatePlanPayorHEDISType")]
	[SPDelete("usp_DeletePlanPayorHEDISType")]
	[SPLoad("usp_LoadPlanPayorHEDISType")]
	[TableMapping("PlanPayorHEDISType","hEDISTypeId")]
	public class PlanPayorHEDISType : BaseLookupWithCode
	{
		[NonSerialized]
		private PlanPayorHEDISTypeCollection parentPlanPayorHEDISTypeCollection;
		[ColumnMapping("HEDISTypeId",StereoType=DataStereoType.FK)]
		private int hEDISTypeId;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public PlanPayorHEDISType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PlanPayorHEDISType(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int HEDISTypeId
		{
			get { return this.hEDISTypeId; }
			set { this.hEDISTypeId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int hEDISTypeId)
		{
			return base.Load(hEDISTypeId);
		}

		/// <summary>
		/// Parent PlanPayorHEDISTypeCollection that contains this element
		/// </summary>
		public PlanPayorHEDISTypeCollection ParentPlanPayorHEDISTypeCollection
		{
			get
			{
				return this.parentPlanPayorHEDISTypeCollection;
			}
			set
			{
				this.parentPlanPayorHEDISTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of PlanPayorHEDISType objects
	/// </summary>
	[ElementType(typeof(PlanPayorHEDISType))]
	public class PlanPayorHEDISTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PlanPayorHEDISType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPlanPayorHEDISTypeCollection = this;
			else
				elem.ParentPlanPayorHEDISTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PlanPayorHEDISType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PlanPayorHEDISType this[int index]
		{
			get
			{
				return (PlanPayorHEDISType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PlanPayorHEDISType)oldValue, false);
			SetParentOnElem((PlanPayorHEDISType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPlanPayorHEDISTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPlanPayorHEDISTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PlanPayorHEDISTypeCollection which is cached in NSGlobal
		/// </summary>
		public static PlanPayorHEDISTypeCollection ActivePlanPayorHEDISTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PlanPayorHEDISTypeCollection col = (PlanPayorHEDISTypeCollection)NSGlobal.EnsureCachedObject("ActivePlanPayorHEDISTypes", typeof(PlanPayorHEDISTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPlanPayorHEDISTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Searches for Plan Payor HEDIS Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchPlanPayorHEDISTypes", -1, this, false, code, description, active);
		}
	}
}
