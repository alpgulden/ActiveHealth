using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PlanNoteTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllPlanNoteTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetPlanNoteTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertPlanNoteType")]
	[SPUpdate("usp_UpdatePlanNoteType")]
	[SPDelete("usp_DeletePlanNoteType")]
	[SPLoad("usp_LoadPlanNoteType")]
	[TableMapping("PlanNoteType","planNoteTypeId")]
	public class PlanNoteType : BaseLookupWithCode
	{
		[NonSerialized]
		private PlanNoteTypeCollection parentPlanNoteTypeCollection;
		[ColumnMapping("PlanNoteTypeId",StereoType=DataStereoType.FK)]
		private int planNoteTypeId;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public PlanNoteType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PlanNoteType(int planNoteTypeId, string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.planNoteTypeId = planNoteTypeId;
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PlanNoteTypeId
		{
			get { return this.planNoteTypeId; }
			set { this.planNoteTypeId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int planNoteTypeId)
		{
			return base.Load(planNoteTypeId);
		}

		/// <summary>
		/// Parent PlanNoteTypeCollection that contains this element
		/// </summary>
		public PlanNoteTypeCollection ParentPlanNoteTypeCollection
		{
			get
			{
				return this.parentPlanNoteTypeCollection;
			}
			set
			{
				this.parentPlanNoteTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of PlanNoteType objects
	/// </summary>
	[ElementType(typeof(PlanNoteType))]
	public class PlanNoteTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_code;
		[NonSerialized]
		private CollectionIndexer indexBy_planNoteTypeId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PlanNoteType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPlanNoteTypeCollection = this;
			else
				elem.ParentPlanNoteTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PlanNoteType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PlanNoteType this[int index]
		{
			get
			{
				return (PlanNoteType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PlanNoteType)oldValue, false);
			SetParentOnElem((PlanNoteType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads the collection with plan note types either active or inactive
		/// </summary>
		public int LoadPlanNoteTypesByActive(int maxRecords, bool active)
		{
			return SqlData.SPExecReadCol("usp_GetPlanNoteTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PlanNoteTypeCollection which is cached in NSGlobal
		/// </summary>
		public static PlanNoteTypeCollection ActivePlanNoteTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PlanNoteTypeCollection col = (PlanNoteTypeCollection)NSGlobal.EnsureCachedObject("ActivePlanNoteTypes", typeof(PlanNoteTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPlanNoteTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on planNoteTypeId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_planNoteTypeId
		{
			get
			{
				if (this.indexBy_planNoteTypeId == null)
					this.indexBy_planNoteTypeId = new CollectionIndexer(this, new string[] { "planNoteTypeId" }, true);
				return this.indexBy_planNoteTypeId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on planNoteTypeId fields returns the object.  Uses the IndexBy_planNoteTypeId indexer.
		/// </summary>
		public PlanNoteType FindBy(int planNoteTypeId)
		{
			return (PlanNoteType)this.IndexBy_planNoteTypeId.GetObject(planNoteTypeId);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_code
		{
			get
			{
				if (this.indexBy_code == null)
					this.indexBy_code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_code;
			}
			
		}

		/// <summary>
		/// Hashtable based search on code fields returns the object.  Uses the IndexBy_code indexer.
		/// </summary>
		public PlanNoteType FindBy(string code)
		{
			return (PlanNoteType)this.IndexBy_code.GetObject(code);
		}

		/// <summary>
		///  Loads all Plan Note Types into collection.
		/// </summary>
		public override void LoadAll()
		{
			SqlData.SPExecReadCol("usp_GetAllPlanNoteTypes", -1, this, false);
		}

		/// <summary>
		/// Searches for Plan Note Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchPlanNoteTypes", -1, this, false, code, description, active);
		}

		
	}
}
