using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [BenefitServiceItems]
	/// Items of benefit service.
	/// </summary>
	[SPAutoGen("usp_SearchBenefitServiceItems","SearchByArgs.sptpl","benefitServiceId, description, benefitServiceTypeId")]
	[SPInsert("usp_InsertBenefitServiceItem")]
	[SPUpdate("usp_UpdateBenefitServiceItem")]
	[SPDelete("usp_DeleteBenefitServiceItem")]
	[SPLoad("usp_LoadBenefitServiceItem")]
	[TableMapping("BenefitServiceItem","benefitServiceItemId")]
	public class BenefitServiceItem : BaseDataWithUserDefined
	{
		[NonSerialized]
		private BenefitServiceItemCollection parentBenefitServiceItemCollection;
		[ColumnMapping("BenefitServiceItemId",StereoType=DataStereoType.FK)]
		private int benefitServiceItemId;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("BenefitServiceTypeId",StereoType=DataStereoType.FK)]
		private int benefitServiceTypeId;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("BenefitServiceId")]
		private int benefitServiceId;
		[ColumnMapping("InNetDollarsAnnual")]
		private Decimal inNetDollarsAnnual;
		[ColumnMapping("InNetDaysAnnual")]
		private int inNetDaysAnnual;
		[ColumnMapping("InNetVisitsAnnual")]
		private int inNetVisitsAnnual;
		[ColumnMapping("InNetDollarsLife")]
		private Decimal inNetDollarsLife;
		[ColumnMapping("InNetDaysLife")]
		private int inNetDaysLife;
		[ColumnMapping("InNetVisitsLife")]
		private int inNetVisitsLife;
		[ColumnMapping("InNetPercent")]
		private Decimal inNetPercent;
		[ColumnMapping("InNetCoPay")]
		private Decimal inNetCoPay;
		[ColumnMapping("InNetDeductibleFamily")]
		private Decimal inNetDeductibleFamily;
		[ColumnMapping("InNetDeductibleIndividual")]
		private Decimal inNetDeductibleIndividual;
		[ColumnMapping("InNetOutOfPocketFamily")]
		private Decimal inNetOutOfPocketFamily;
		[ColumnMapping("InNetOutOfPocketIndividual")]
		private Decimal inNetOutOfPocketIndividual;
		[ColumnMapping("InNetCoveredId",StereoType=DataStereoType.FK)]
		private int inNetCoveredId;
		[ColumnMapping("InNetPenalty")]
		private Decimal inNetPenalty;
		[ColumnMapping("InNetExcluded")]
		private bool inNetExcluded = true;
		[ColumnMapping("OutNetDollarsAnnual")]
		private Decimal outNetDollarsAnnual;
		[ColumnMapping("OutNetDaysAnnual")]
		private int outNetDaysAnnual;
		[ColumnMapping("OutNetVisitsAnnual")]
		private int outNetVisitsAnnual;
		[ColumnMapping("OutNetDollarsLife")]
		private Decimal outNetDollarsLife;
		[ColumnMapping("OutNetDaysLife")]
		private int outNetDaysLife;
		[ColumnMapping("OutNetVisitsLife")]
		private int outNetVisitsLife;
		[ColumnMapping("OutNetPercent")]
		private Decimal outNetPercent;
		[ColumnMapping("OutNetCoPay")]
		private Decimal outNetCoPay;
		[ColumnMapping("OutNetDeductibleFamily")]
		private Decimal outNetDeductibleFamily;
		[ColumnMapping("OutNetDeductibleIndividual")]
		private Decimal outNetDeductibleIndividual;
		[ColumnMapping("OutNetOutOfPocketFamily")]
		private Decimal outNetOutOfPocketFamily;
		[ColumnMapping("OutNetOutOfPocketIndividual")]
		private Decimal outNetOutOfPocketIndividual;
		[ColumnMapping("OutNetCoveredId",StereoType=DataStereoType.FK)]
		private int outNetCoveredId;
		[ColumnMapping("OutNetPenalty")]
		private Decimal outNetPenalty;
		[ColumnMapping("OutNetExcluded")]
		private bool outNetExcluded = true;
	
		//[ColumnMapping("InNetwork")]
		//private bool inNetwork;
		//[ColumnMapping("OutNetwork")]
		//private bool outNetwork;
	
		private DateTime termDateWhenLoaded;

		public BenefitServiceItem()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public BenefitServiceItem(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int BenefitServiceItemId
		{
			get { return this.benefitServiceItemId; }
			set { this.benefitServiceItemId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[FieldValuesMember("LookupOf_BenefitServiceTypeId", "BenefitServiceTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int BenefitServiceTypeId
		{
			get { return this.benefitServiceTypeId; }
			set { this.benefitServiceTypeId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int BenefitServiceId
		{
			get { return this.benefitServiceId; }
			set { this.benefitServiceId = value; }
		}

		/// <summary>
		/// Parent BenefitServiceItemCollection that contains this element
		/// </summary>
		public BenefitServiceItemCollection ParentBenefitServiceItemCollection
		{
			get
			{
				return this.parentBenefitServiceItemCollection;
			}
			set
			{
				this.parentBenefitServiceItemCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			
			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}

			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int benefitServiceItemId)
		{
			return base.Load(benefitServiceItemId);
		}

		public BenefitServiceTypeCollection LookupOf_BenefitServiceTypeId
		{
			get
			{
				return BenefitServiceTypeCollection.ActiveBenefitServiceTypes; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@DOLLARSANNUAL@")]
		public decimal InNetDollarsAnnual
		{
			get { return this.inNetDollarsAnnual; }
			set { this.inNetDollarsAnnual = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@DAYSANNUAL@")]
		public int InNetDaysAnnual
		{
			get { return this.inNetDaysAnnual; }
			set { this.inNetDaysAnnual = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@VISITSANNUAL@")]
		public int InNetVisitsAnnual
		{
			get { return this.inNetVisitsAnnual; }
			set { this.inNetVisitsAnnual = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@DOLLARSLIFE@")]
		public decimal InNetDollarsLife
		{
			get { return this.inNetDollarsLife; }
			set { this.inNetDollarsLife = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@DAYSLIFE@")]
		public int InNetDaysLife
		{
			get { return this.inNetDaysLife; }
			set { this.inNetDaysLife = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@VISITSLIFE@")]
		public int InNetVisitsLife
		{
			get { return this.inNetVisitsLife; }
			set { this.inNetVisitsLife = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Percent)]
		[FieldDescription("@PERCENT@")]
		public decimal InNetPercent
		{
			get { return this.inNetPercent; }
			set { this.inNetPercent = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@COPAY@")]
		public decimal InNetCoPay
		{
			get { return this.inNetCoPay; }
			set { this.inNetCoPay = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@DEDUCTIBLEFAMILY@")]
		public decimal InNetDeductibleFamily
		{
			get { return this.inNetDeductibleFamily; }
			set { this.inNetDeductibleFamily = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@DEDUCTIBLEINDIVIDUAL@")]
		public decimal InNetDeductibleIndividual
		{
			get { return this.inNetDeductibleIndividual; }
			set { this.inNetDeductibleIndividual = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@OUTOFPOCKETFAMILY@")]
		public decimal InNetOutOfPocketFamily
		{
			get { return this.inNetOutOfPocketFamily; }
			set { this.inNetOutOfPocketFamily = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@OUTOFPOCKETINDIVIDUAL@")]
		public decimal InNetOutOfPocketIndividual
		{
			get { return this.inNetOutOfPocketIndividual; }
			set { this.inNetOutOfPocketIndividual = value; }
		}

		[FieldValuesMember("LookupOf_CoveredId", "CoveredTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@COVERED@")]
		public int InNetCoveredId
		{
			get { return this.inNetCoveredId; }
			set { this.inNetCoveredId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@PENALTY@")]
		public decimal InNetPenalty
		{
			get { return this.inNetPenalty; }
			set { this.inNetPenalty = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@EXCLUDED@")]
		public bool InNetExcluded
		{
			get { return this.inNetExcluded; }
			set { this.inNetExcluded = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@DOLLARSANNUAL@")]
		public decimal OutNetDollarsAnnual
		{
			get { return this.outNetDollarsAnnual; }
			set { this.outNetDollarsAnnual = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@DAYSANNUAL@")]
		public int OutNetDaysAnnual
		{
			get { return this.outNetDaysAnnual; }
			set { this.outNetDaysAnnual = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@VISITSANNUAL@")]
		public int OutNetVisitsAnnual
		{
			get { return this.outNetVisitsAnnual; }
			set { this.outNetVisitsAnnual = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@DOLLARSLIFE@")]
		public decimal OutNetDollarsLife
		{
			get { return this.outNetDollarsLife; }
			set { this.outNetDollarsLife = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@DAYSLIFE@")]
		public int OutNetDaysLife
		{
			get { return this.outNetDaysLife; }
			set { this.outNetDaysLife = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@VISITSLIFE@")]
		public int OutNetVisitsLife
		{
			get { return this.outNetVisitsLife; }
			set { this.outNetVisitsLife = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Percent)]
		[FieldDescription("@PERCENT@")]
		public decimal OutNetPercent
		{
			get { return this.outNetPercent; }
			set { this.outNetPercent = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@COPAY@")]
		public decimal OutNetCoPay
		{
			get { return this.outNetCoPay; }
			set { this.outNetCoPay = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@DEDUCTIBLEFAMILY@")]
		public decimal OutNetDeductibleFamily
		{
			get { return this.outNetDeductibleFamily; }
			set { this.outNetDeductibleFamily = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@DEDUCTIBLEINDIVIDUAL@")]
		public decimal OutNetDeductibleIndividual
		{
			get { return this.outNetDeductibleIndividual; }
			set { this.outNetDeductibleIndividual = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@OUTOFPOCKETFAMILY@")]
		public decimal OutNetOutOfPocketFamily
		{
			get { return this.outNetOutOfPocketFamily; }
			set { this.outNetOutOfPocketFamily = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@OUTOFPOCKETINDIVIDUAL@")]
		public decimal OutNetOutOfPocketIndividual
		{
			get { return this.outNetOutOfPocketIndividual; }
			set { this.outNetOutOfPocketIndividual = value; }
		}

		[FieldValuesMember("LookupOf_CoveredId", "CoveredTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@COVERED@")]
		public int OutNetCoveredId
		{
			get { return this.outNetCoveredId; }
			set { this.outNetCoveredId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		[FieldDescription("@PENALTY@")]
		public decimal OutNetPenalty
		{
			get { return this.outNetPenalty; }
			set { this.outNetPenalty = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@EXCLUDED@")]
		public bool OutNetExcluded
		{
			get { return this.outNetExcluded; }
			set { this.outNetExcluded = value; }
		}

		public CoveredTypeCollection LookupOf_CoveredId
		{
			get
			{
				return CoveredTypeCollection.ActiveCoveredTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/*[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool InNetwork
		{
			get { return this.inNetwork; }
			set { this.inNetwork = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool OutNetwork
		{
			get { return this.outNetwork; }
			set { this.outNetwork = value; }
		}*/

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFields(this, "Description");
				//writer.AddFieldsOnNewLine(this, "EffectiveDate", "TerminationDate");
			}
		}

		/// <summary>
		/// Create a copy of the special benefit service item.
		/// </summary>
		/// <returns></returns>
		public BenefitServiceItem CreateCopyOfSpecialBenefitServiceItem()
		{
			return (BenefitServiceItem)this.Clone(true);
		}

		
	}

	/// <summary>
	/// Strongly typed collection of BenefitServiceItem objects
	/// </summary>
	[ElementType(typeof(BenefitServiceItem))]
	public class BenefitServiceItemCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(BenefitServiceItem elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentBenefitServiceItemCollection = this;
			else
				elem.ParentBenefitServiceItemCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (BenefitServiceItem elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public BenefitServiceItem this[int index]
		{
			get
			{
				return (BenefitServiceItem)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((BenefitServiceItem)oldValue, false);
			SetParentOnElem((BenefitServiceItem)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(BenefitServiceItem elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((BenefitServiceItem)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent BenefitService that contains this collection
		/// </summary>
		public BenefitService ParentBenefitService
		{
			get { return this.ParentDataObject as BenefitService; }
			set { this.ParentDataObject = value; /* parent is set when contained by a BenefitService */ }
		}

		/// <summary>
		/// Search the benefit service items for the given searcher members.
		/// </summary>
		public int SearchBenefitServiceItems(int maxRecords, BenefitServiceItem searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchBenefitServiceItems", maxRecords, this, new object[] { searcher }, false);
		}
	}
}
