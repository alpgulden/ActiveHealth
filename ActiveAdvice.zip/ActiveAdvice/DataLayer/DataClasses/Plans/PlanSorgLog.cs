using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PlanSorgLog]
	/// Inserts log entries into the PlanSorgLog.
	/// No update, delete allowed.
	/// </summary>
	[SPAutoGen("usp_GetLastPlanSORGLogEntry","SelectTop1.sptpl","planSorgLogId, DESC, planId, sORGID")]
	[SPInsert("usp_InsertPlanSORGLog")]
	[SPUpdate("usp_UpdatePlanSORGLog")]
	[SPDelete("usp_DeletePlanSORGLog")]
	[SPLoad("usp_LoadPlanSORGLog")]
	[TableMapping("PlanSorgLog","planSorgLogId")]
	public class PlanSORGLog : BaseData
	{
		#region Log specific fields

		[ColumnMapping("PlanSorgLogId",StereoType=DataStereoType.FK)][Copiable(false)]
		private int planSorgLogId;
		[ColumnMapping("CreationDate", InjectInsert="getDate()")][Copiable(false)]
		private DateTime creationDate;

		#endregion

		#region Plan fields

		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="planId")]
		private int planId;
		[ColumnMapping("PlanTypeId",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="planTypeId")]
		private int planTypeId;
		[ColumnMapping("PlanName")][Copiable(true, CopyFrom="name")]
		private string planName;
		[ColumnMapping("PlanSearchTerm")][Copiable(false)]		// not in plan!
		private string planSearchTerm;
		[ColumnMapping("PlanAddress1")][Copiable(true, CopyFrom="line1")]
		private string planAddress1;
		[ColumnMapping("PlanAddress2")][Copiable(true, CopyFrom="line2")]
		private string planAddress2;
		[ColumnMapping("PlanAddress3")][Copiable(true, CopyFrom="line3")]
		private string planAddress3;
		[ColumnMapping("PlanCity")][Copiable(true, CopyFrom="city")]
		private string planCity;
		[ColumnMapping("PlanState")][Copiable(false, CopyFrom="state")]
		private string planState;
		[ColumnMapping("PlanZip")][Copiable(true, CopyFrom="zip")]
		private string planZip;
		[ColumnMapping("PlanCounty")][Copiable(true, CopyFrom="county")]
		private string planCounty;
		[ColumnMapping("PlanCountry")][Copiable(true, CopyFrom="country")]
		private string planCountry;
		[ColumnMapping("PlanPhone")][Copiable(true, CopyFrom="phone1")]
		private string planPhone;
		[ColumnMapping("PlanPhoneExtension")][Copiable(true, CopyFrom="phoneExt1")]
		private string planPhoneExtension;
		[ColumnMapping("PlanOtherPhone")][Copiable(true, CopyFrom="phone2")]
		private string planOtherPhone;
		[ColumnMapping("PlanOtherPhoneExtension")][Copiable(true, CopyFrom="phoneExt2")]
		private string planOtherPhoneExtension;
		[ColumnMapping("PlanFax")][Copiable(true, CopyFrom="faxNumber")]
		private string planFax;
		[ColumnMapping("PlanFaxExtension")][Copiable(true, CopyFrom="faxExtension")]
		private string planFaxExtension;
		[ColumnMapping("PlanEmail")][Copiable(true, CopyFrom="email")]
		private string planEmail;
		[ColumnMapping("PlanTriggerListId",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="triggerListId")]
		private int planTriggerListId;
		[ColumnMapping("PlanBenefitServiceId",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="benefitServiceId")]
		private int planBenefitServiceId;
		[ColumnMapping("PlanSpecialProcedureId",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="specialProcedureId")]
		private int planSpecialProcedureId;
		[ColumnMapping("PlanNormalDeny")][Copiable(true, CopyFrom="normalDeny")]
		private bool planNormalDeny;
		[ColumnMapping("PlanCallBeforeDeny")][Copiable(true, CopyFrom="callBeforeDeny")]
		private bool planCallBeforeDeny;
		[ColumnMapping("PlanCallBeforeLetter")][Copiable(true, CopyFrom="callBeforeLetter")]
		private bool planCallBeforeLetter;
		[ColumnMapping("PlanCallForLatePreCert")][Copiable(true, CopyFrom="callForLatePreCert")]
		private bool planCallForLatePreCert;
		[ColumnMapping("PlanDenyNote")][Copiable(true, CopyFrom="planDenyNote")]
		private string planDenyNote;
		[ColumnMapping("PlanEAPReferral")][Copiable(true, CopyFrom="eAPReferral")]
		private bool planEAPReferral;
		[ColumnMapping("PlanPreCertPenalty")][Copiable(true, CopyFrom="preCertPenalty")]
		private string planPreCertPenalty;
		[ColumnMapping("PlanModifiedByUserId",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="modifiedBy")]
		private int planModifiedByUserId;
		[ColumnMapping("PlanModificationDate")][Copiable(true, CopyFrom="modifyTime")]
		private DateTime planModificationDate;
		[ColumnMapping("PlanEffectiveDate")][Copiable(true, CopyFrom="effectiveDate")]
		private DateTime planEffectiveDate;
		[ColumnMapping("PlanTerminationDate")][Copiable(true, CopyFrom="terminationDate")]
		private DateTime planTerminationDate;
		[ColumnMapping("PlanNotificationServicesRequired",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="preCertNotificationServicesRequired")]
		private int planNotificationServicesRequired;
		[ColumnMapping("PlanNotificationServicesREquiredUOMId",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="preCertNotificationServicesRequiredUOM")]
		private int planNotificationServicesREquiredUOMId;
		[ColumnMapping("PlanMaternicheckBeginDate")][Copiable(true, CopyFrom="maternichekBeginDate")]
		private DateTime planMaternicheckBeginDate;
		[ColumnMapping("PlanMaternichekRegistrationWeeks",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="maternichekRegistrationWeeks")]
		private int planMaternichekRegistrationWeeks;
		[ColumnMapping("PlanMaternicheckNote")][Copiable(true, CopyFrom="maternichekNote")]
		private string planMaternicheckNote;
		[ColumnMapping("PlanMaternicheckIncentiveId",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="maternichekIncentiveId")]
		private int planMaternicheckIncentiveId;
		[ColumnMapping("PlanLengthOfStayTrigger",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="lengthOfStayTrigger")]
		private int planLengthOfStayTrigger;
		[ColumnMapping("PlanOutlierTrigger",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="outlierTrigger")]
		private int planOutlierTrigger;
		[ColumnMapping("PlanReferralGoodFor",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="referralGoodFor")]
		private int planReferralGoodFor;
		[ColumnMapping("PlanHEDISTypeId",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="hedisPlanTypeID")]
		private int planHEDISTypeId;
		[ColumnMapping("PlanReviewPercent",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="reviewPercent")]
		private int planReviewPercent;
		[ColumnMapping("PlanHEDISPayorTypeID",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="hEDISPayorTypeID")]
		private int planHEDISPayorTypeID;

		#endregion

		#region Organization fields

		[ColumnMapping("PlanSORGID",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="planSORGID")]
		private int planSORGID;
		[ColumnMapping("SORGID",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="sORGID")]
		private int sORGID;
		[ColumnMapping("SORGAltGroupID")][Copiable(true, CopyFrom="altGroupID")]
		private string sORGAltGroupID;
		[ColumnMapping("SORGAltPlanID")][Copiable(true, CopyFrom="altPlanID")]
		private string sORGAltPlanID;
		[ColumnMapping("SORGAltPlanName")][Copiable(true, CopyFrom="altPlanName")]
		private string sORGAltPlanName;
		[ColumnMapping("SORGDefaultPlan")][Copiable(false)]
		private bool sORGDefaultPlan;
		[ColumnMapping("SORGCheckEligibility")][Copiable(true, CopyFrom="checkEligibility")]
		private bool sORGCheckEligibility;
		[ColumnMapping("SORGEligibilityAddAnyway")][Copiable(true, CopyFrom="eligibilityAddAnyway")]
		private bool sORGEligibilityAddAnyway;
		[ColumnMapping("SORGDRGType",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="dRGType")]
		private int sORGDRGType;
		[ColumnMapping("SORGDRGVersion")][Copiable(true, CopyFrom="dRGVersion")]
		private string sORGDRGVersion;
		[ColumnMapping("SORGRegionID",StereoType=DataStereoType.FK)][Copiable(false)]
		private int sORGRegionID;
		[ColumnMapping("SORGPayorGroupID",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="payorGroupID")]
		private int sORGPayorGroupID;
		[ColumnMapping("SORGGuidelineSourceSet",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="guidelineSourceSet")]
		private int sORGGuidelineSourceSet;
		[ColumnMapping("SORGNote")][Copiable(true, CopyFrom="note")]
		private string sORGNote;
		[ColumnMapping("SORGEffectiveDate")][Copiable(true, CopyFrom="effectiveDate")]
		private DateTime sORGEffectiveDate;
		[ColumnMapping("SORGTerminationDate")][Copiable(true, CopyFrom="terminationDate")]
		private DateTime sORGTerminationDate;
		[ColumnMapping("SORGNumberOfInsured",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="numberOfInsured")]
		private int sORGNumberOfInsured;
		[ColumnMapping("SORGDependentsRatio")][Copiable(true, CopyFrom="dependentsRatio")]
		private Decimal sORGDependentsRatio;
		[ColumnMapping("SORGTotalMembers",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="totalMembers")]
		private int sORGTotalMembers;
		[ColumnMapping("SORGSource",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="source")]
		private int sORGSource;
		[ColumnMapping("SORGCreatedBy",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="createdBy")]
		private int sORGCreatedBy;
		[ColumnMapping("SORGCreateTime")][Copiable(true, CopyFrom="createTime")]
		private DateTime sORGCreateTime;
		[ColumnMapping("SORGModifyTime")][Copiable(true, CopyFrom="modifyTime")]
		private DateTime sORGModifyTime;
		[ColumnMapping("SORGModifiedBy",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="modifiedBy")]
		private int sORGModifiedBy;
		[ColumnMapping("SORGLOSRegion",StereoType=DataStereoType.FK)][Copiable(true, CopyFrom="lOSRegion")]
		private int sORGLOSRegion;
		[ColumnMapping("SORGLOSYear")][Copiable(true, CopyFrom="lOSYear")]
		private string sORGLOSYear;

		#endregion
	
		private Plan plan;

		public PlanSORGLog()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Create a plan-sorg log entry from a PlanSORG directly.
		/// </summary>
		/// <param name="planSORG"></param>
		public PlanSORGLog(PlanSORG planSORG)
			: this(planSORG.Plan, planSORG)
		{
		}

		/// <summary>
		/// Create a plan-sorg log entry from the given plan and plan-sorg
		/// </summary>
		/// <param name="plan"></param>
		/// <param name="planSorg"></param>
		public PlanSORGLog(Plan plan, PlanSORG planSorg)
		{
			if (plan == null)
				throw new Exception("Plan was not passed to PlanSorgLog object");
			if (planSorg == null)
				throw new Exception("SORG was not passed to PlanSorgLog object");
			
			//if (!sorg.IsSubOrganization)
			//	throw new Exception("The passed organization to PlanSorgLog is not a sub-organization!");

			this.NewRecord();

			FillFromPlan(plan);
			FillFromPlanSORG(planSorg);
		}

		private void FillFromPlan(Plan plan)
		{
			//this.CopyMembersFrom(plan, true, false, false);
			//this.CopyMembersFrom(plan.Address, true, false, false);
			this.planId = plan.PlanId;
			this.planTypeId = plan.PlanTypeId;
			this.planName = plan.Name;
			//this.planSearchTerm;	// not in plan!
			this.planAddress1 = plan.Address.Line1;
			this.planAddress2 = plan.Address.Line2;
			this.planAddress3 = plan.Address.Line3;
			this.planCity = plan.Address.City;
			this.planState = plan.Address.State;
			this.planZip = plan.Address.Zip;
			this.planCounty = plan.Address.County;
			this.planCountry = plan.Address.Country;
			this.planPhone = plan.Address.PhoneNumber1;
			this.planPhoneExtension = plan.Address.PhoneExt1;
			this.planOtherPhone = plan.Address.PhoneNumber2;
			this.planOtherPhoneExtension = plan.Address.PhoneExt2;
			this.planFax = plan.Address.FaxNumber;
			this.planFaxExtension = plan.Address.FaxExtension;
			this.planEmail = plan.Address.Email;
			this.planTriggerListId = plan.TriggerListId;
			this.planBenefitServiceId = plan.BenefitServiceId;
			this.planSpecialProcedureId = plan.SpecialProcedureId;
			this.planNormalDeny = plan.NormalDeny;
			this.planCallBeforeDeny = plan.CallBeforeDeny;
			this.planCallBeforeLetter = plan.CallBeforeLetter;
			this.planCallForLatePreCert = plan.CallForLatePreCert;
			this.planDenyNote = plan.PlanDenyNote;
			this.planEAPReferral = plan.EAPReferral;
			this.planPreCertPenalty = plan.PreCertPenalty;
			this.planModifiedByUserId = plan.ModifiedBy;
			this.planModificationDate = plan.ModifyTime;
			this.planEffectiveDate = plan.EffectiveDate;
			this.planTerminationDate = plan.TerminateTime;
			this.planNotificationServicesRequired = plan.PreCertNotificationServicesRequired;
			this.planNotificationServicesREquiredUOMId = plan.PreCertNotificationServicesRequiredUOM;
			this.planMaternicheckBeginDate = plan.MaternichekBeginDate;
			this.planMaternichekRegistrationWeeks = plan.MaternichekRegistrationWeeks;
			this.planMaternicheckNote = plan.MaternichekNote;
			this.planMaternicheckIncentiveId = plan.MaternichekIncentiveId;
			this.planLengthOfStayTrigger = plan.LengthOfStayTrigger;
			this.planOutlierTrigger = plan.OutlierTrigger;
			this.planReferralGoodFor = plan.ReferralGoodFor;
			this.planHEDISTypeId = plan.HedisPlanTypeID;
			this.planReviewPercent = plan.ReviewPercent;
			this.planHEDISPayorTypeID = plan.HEDISPayorTypeID;
		}

		private void FillFromPlanSORG(PlanSORG planSorg)
		{
			// this.CopyMembersFrom(planSorg, true, false, false);
			this.planSORGID = planSorg.PlanSORGID;
			this.sORGID = planSorg.SORGID;
			this.sORGAltGroupID = planSorg.AltGroupID;
			this.sORGAltPlanID = planSorg.AltPlanID;
			this.sORGAltPlanName = planSorg.AltPlanName;
			// this.sORGDefaultPlan =   source unknown!
			this.sORGCheckEligibility = planSorg.CheckEligibility;
			this.sORGEligibilityAddAnyway = planSorg.EligibilityAddAnyway;
			this.sORGDRGType = planSorg.DRGType;
			this.sORGDRGVersion = planSorg.DRGVersion;
			// this.sORGRegionID =   source unknown
			this.sORGPayorGroupID = planSorg.PayorGroupID;
			this.sORGGuidelineSourceSet = planSorg.GuidelineSourceSet;
			this.sORGNote = planSorg.Note;
			this.sORGEffectiveDate = planSorg.EffectiveDate;
			this.sORGTerminationDate = planSorg.TerminationDate;
			this.sORGNumberOfInsured = planSorg.NumberOfInsured;
			this.sORGDependentsRatio = planSorg.DependentsRatio;
			this.sORGTotalMembers = planSorg.TotalMembers;
			this.sORGSource = planSorg.Source;
			this.sORGCreatedBy = planSorg.CreatedBy;
			this.sORGCreateTime = planSorg.CreateTime;
			this.sORGModifyTime = planSorg.ModifyTime;
			this.sORGModifiedBy = planSorg.ModifiedBy;
			this.sORGLOSRegion = planSorg.LOSRegion;
			this.sORGLOSYear = planSorg.LOSYear;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PlanSorgLogId
		{
			get { return this.planSorgLogId; }
			set { this.planSorgLogId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreationDate
		{
			get { return this.creationDate; }
			set { this.creationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanTypeId
		{
			get { return this.planTypeId; }
			set { this.planTypeId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PlanName
		{
			get { return this.planName; }
			set { this.planName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PlanSearchTerm
		{
			get { return this.planSearchTerm; }
			set { this.planSearchTerm = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PlanAddress1
		{
			get { return this.planAddress1; }
			set { this.planAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PlanAddress2
		{
			get { return this.planAddress2; }
			set { this.planAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PlanAddress3
		{
			get { return this.planAddress3; }
			set { this.planAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string PlanCity
		{
			get { return this.planCity; }
			set { this.planCity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string PlanState
		{
			get { return this.planState; }
			set { this.planState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string PlanZip
		{
			get { return this.planZip; }
			set { this.planZip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PlanCounty
		{
			get { return this.planCounty; }
			set { this.planCounty = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string PlanCountry
		{
			get { return this.planCountry; }
			set { this.planCountry = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string PlanPhone
		{
			get { return this.planPhone; }
			set { this.planPhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string PlanPhoneExtension
		{
			get { return this.planPhoneExtension; }
			set { this.planPhoneExtension = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string PlanOtherPhone
		{
			get { return this.planOtherPhone; }
			set { this.planOtherPhone = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string PlanOtherPhoneExtension
		{
			get { return this.planOtherPhoneExtension; }
			set { this.planOtherPhoneExtension = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string PlanFax
		{
			get { return this.planFax; }
			set { this.planFax = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string PlanFaxExtension
		{
			get { return this.planFaxExtension; }
			set { this.planFaxExtension = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string PlanEmail
		{
			get { return this.planEmail; }
			set { this.planEmail = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanTriggerListId
		{
			get { return this.planTriggerListId; }
			set { this.planTriggerListId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanBenefitServiceId
		{
			get { return this.planBenefitServiceId; }
			set { this.planBenefitServiceId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanSpecialProcedureId
		{
			get { return this.planSpecialProcedureId; }
			set { this.planSpecialProcedureId = value; }
		}

		public bool PlanNormalDeny
		{
			get { return this.planNormalDeny; }
			set { this.planNormalDeny = value; }
		}

		public bool PlanCallBeforeDeny
		{
			get { return this.planCallBeforeDeny; }
			set { this.planCallBeforeDeny = value; }
		}

		public bool PlanCallBeforeLetter
		{
			get { return this.planCallBeforeLetter; }
			set { this.planCallBeforeLetter = value; }
		}

		public bool PlanCallForLatePreCert
		{
			get { return this.planCallForLatePreCert; }
			set { this.planCallForLatePreCert = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string PlanDenyNote
		{
			get { return this.planDenyNote; }
			set { this.planDenyNote = value; }
		}

		public bool PlanEAPReferral
		{
			get { return this.planEAPReferral; }
			set { this.planEAPReferral = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string PlanPreCertPenalty
		{
			get { return this.planPreCertPenalty; }
			set { this.planPreCertPenalty = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanModifiedByUserId
		{
			get { return this.planModifiedByUserId; }
			set { this.planModifiedByUserId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PlanModificationDate
		{
			get { return this.planModificationDate; }
			set { this.planModificationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime PlanEffectiveDate
		{
			get { return this.planEffectiveDate; }
			set { this.planEffectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PlanTerminationDate
		{
			get { return this.planTerminationDate; }
			set { this.planTerminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanNotificationServicesRequired
		{
			get { return this.planNotificationServicesRequired; }
			set { this.planNotificationServicesRequired = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanNotificationServicesREquiredUOMId
		{
			get { return this.planNotificationServicesREquiredUOMId; }
			set { this.planNotificationServicesREquiredUOMId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PlanMaternicheckBeginDate
		{
			get { return this.planMaternicheckBeginDate; }
			set { this.planMaternicheckBeginDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanMaternichekRegistrationWeeks
		{
			get { return this.planMaternichekRegistrationWeeks; }
			set { this.planMaternichekRegistrationWeeks = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=90)]
		public string PlanMaternicheckNote
		{
			get { return this.planMaternicheckNote; }
			set { this.planMaternicheckNote = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanMaternicheckIncentiveId
		{
			get { return this.planMaternicheckIncentiveId; }
			set { this.planMaternicheckIncentiveId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanLengthOfStayTrigger
		{
			get { return this.planLengthOfStayTrigger; }
			set { this.planLengthOfStayTrigger = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanOutlierTrigger
		{
			get { return this.planOutlierTrigger; }
			set { this.planOutlierTrigger = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanReferralGoodFor
		{
			get { return this.planReferralGoodFor; }
			set { this.planReferralGoodFor = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanHEDISTypeId
		{
			get { return this.planHEDISTypeId; }
			set { this.planHEDISTypeId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanReviewPercent
		{
			get { return this.planReviewPercent; }
			set { this.planReviewPercent = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanHEDISPayorTypeID
		{
			get { return this.planHEDISPayorTypeID; }
			set { this.planHEDISPayorTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanSORGID
		{
			get { return this.planSORGID; }
			set { this.planSORGID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGID
		{
			get { return this.sORGID; }
			set { this.sORGID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SORGAltGroupID
		{
			get { return this.sORGAltGroupID; }
			set { this.sORGAltGroupID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string SORGAltPlanID
		{
			get { return this.sORGAltPlanID; }
			set { this.sORGAltPlanID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string SORGAltPlanName
		{
			get { return this.sORGAltPlanName; }
			set { this.sORGAltPlanName = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool SORGDefaultPlan
		{
			get { return this.sORGDefaultPlan; }
			set { this.sORGDefaultPlan = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool SORGCheckEligibility
		{
			get { return this.sORGCheckEligibility; }
			set { this.sORGCheckEligibility = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool SORGEligibilityAddAnyway
		{
			get { return this.sORGEligibilityAddAnyway; }
			set { this.sORGEligibilityAddAnyway = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGDRGType
		{
			get { return this.sORGDRGType; }
			set { this.sORGDRGType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string SORGDRGVersion
		{
			get { return this.sORGDRGVersion; }
			set { this.sORGDRGVersion = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGRegionID
		{
			get { return this.sORGRegionID; }
			set { this.sORGRegionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGPayorGroupID
		{
			get { return this.sORGPayorGroupID; }
			set { this.sORGPayorGroupID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGGuidelineSourceSet
		{
			get { return this.sORGGuidelineSourceSet; }
			set { this.sORGGuidelineSourceSet = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string SORGNote
		{
			get { return this.sORGNote; }
			set { this.sORGNote = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime SORGEffectiveDate
		{
			get { return this.sORGEffectiveDate; }
			set { this.sORGEffectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime SORGTerminationDate
		{
			get { return this.sORGTerminationDate; }
			set { this.sORGTerminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGNumberOfInsured
		{
			get { return this.sORGNumberOfInsured; }
			set { this.sORGNumberOfInsured = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal SORGDependentsRatio
		{
			get { return this.sORGDependentsRatio; }
			set { this.sORGDependentsRatio = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGTotalMembers
		{
			get { return this.sORGTotalMembers; }
			set { this.sORGTotalMembers = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGSource
		{
			get { return this.sORGSource; }
			set { this.sORGSource = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGCreatedBy
		{
			get { return this.sORGCreatedBy; }
			set { this.sORGCreatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime SORGCreateTime
		{
			get { return this.sORGCreateTime; }
			set { this.sORGCreateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime SORGModifyTime
		{
			get { return this.sORGModifyTime; }
			set { this.sORGModifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGModifiedBy
		{
			get { return this.sORGModifiedBy; }
			set { this.sORGModifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGLOSRegion
		{
			get { return this.sORGLOSRegion; }
			set { this.sORGLOSRegion = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string SORGLOSYear
		{
			get { return this.sORGLOSYear; }
			set { this.sORGLOSYear = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int planSorgLogId)
		{
			return base.Load(planSorgLogId);
		}

		/// <summary>
		/// Load the object with the last entry in the PlanSORGLog for the given
		/// planId and sorgID.
		/// </summary>
		public bool LoadLastPlanSORGLogEntry(int planId, int sorgID)
		{
			return SqlData.SPExecReadObj("usp_GetLastPlanSORGLogEntry", this, false, planId, sorgID);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Do pre and post-delete operations of this object here.
		/// </summary>
		protected override void InternalDelete()
		{
			throw new Exception("PlanSORGLog can not be deleted!");
			// Do pre-delete operations here (set members before delete, insert/update/delete extra records etc).
			//base.InternalDelete(); // always call this to ensure record flags gets updated properly.
			// Do post-delete operations here (set members after delete, insert/update/delete extra records etc).
		}

		/// <summary>
		/// Do pre and post-update operations of the object here.
		/// </summary>
		protected override void InternalUpdate()
		{
			throw new Exception("PlanSORGLog can not be updated!");
			// Do pre-update operations here (set members before update, insert/update extra records etc).
			//base.InternalUpdate(); // always call this to ensure record flags gets updated properly.
			// Do post-insert operations here (set members after update, insert/update extra records etc).
		}

		public static PlanSORGLog GetLastPlanSORGLogEntry(int planId, int sorgID)
		{
			PlanSORGLog planSorgLog = new PlanSORGLog();
			if (planSorgLog.LoadLastPlanSORGLogEntry(planId, sorgID))
				return planSorgLog;
			else
				return null;	// not found
		}

		public static PlanSORGLog GetLastPlanSORGLogEntry(Plan plan, Organization sorg)
		{
			if (plan == null)
				throw new Exception("Null value passed to GetLastPlanSORGLogEntry for plan");

			if (sorg == null)
				throw new Exception("Null value passed to GetLastPlanSORGLogEntry for sorg");

			if (!sorg.IsSubOrganization)
				throw new Exception("Passed organization to GetLastPlanSORGLogEntry is not a sub-organization");

			return GetLastPlanSORGLogEntry(plan.PlanId, sorg.OrganizationID);
		}

		public Plan GetPlan()
		{
			if (this.planId == 0)
				return null;
			Plan plan = new Plan();
			if (plan.Load(this.planId))
				return plan;
			else
				return null;
		}

		public Plan Plan
		{
			get
			{
				if (this.plan == null)
					this.plan = GetPlan();
				return this.plan;
			}
		}


	}
}
