using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PlanNotes]
	/// Plans can have an unlimited number of note records linked to them. The 
	/// Plan Notes tab allows you to add, edit, and delete notes attached to the plan.
	/// </summary>
	[SPInsert("usp_InsertPlanNote")]
	[SPUpdate("usp_UpdatePlanNote")]
	[SPDelete("usp_DeletePlanNote")]
	[SPLoad("usp_LoadPlanNote")]
	[TableMapping("PlanNote","planNoteId")]
	public class PlanNote : BaseData
	{
		[NonSerialized]
		private PlanNoteCollection parentPlanNoteCollection;
		[ColumnMapping("PlanNoteId",StereoType=DataStereoType.FK)]
		private int planNoteId;
		[ColumnMapping("PlanId")]
		private int planId;
		[ColumnMapping("PlanNoteTypeId")]
		private int planNoteTypeId;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
	
		public PlanNote()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PlanNote(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PlanNoteId
		{
			get { return this.planNoteId; }
			set { this.planNoteId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		[FieldValuesMember("LookupOf_PlanNoteTypeId", "PlanNoteTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@NOTETYPE@")]
		public int PlanNoteTypeId
		{
			get { return this.planNoteTypeId; }
			set { this.planNoteTypeId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=128)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int planNoteId)
		{
			return base.Load(planNoteId);
		}

		/// <summary>
		/// Parent PlanNoteCollection that contains this element
		/// </summary>
		public PlanNoteCollection ParentPlanNoteCollection
		{
			get
			{
				return this.parentPlanNoteCollection;
			}
			set
			{
				this.parentPlanNoteCollection = value; // parent is set when added to a collection
			}
		}

		public PlanNoteTypeCollection LookupOf_PlanNoteTypeId
		{
			get
			{
				return PlanNoteTypeCollection.ActivePlanNoteTypes; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]		// defined in the base
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of PlanNote objects
	/// </summary>
	[ElementType(typeof(PlanNote))]
	public class PlanNoteCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PlanNote elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPlanNoteCollection = this;
			else
				elem.ParentPlanNoteCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PlanNote elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PlanNote this[int index]
		{
			get
			{
				return (PlanNote)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PlanNote)oldValue, false);
			SetParentOnElem((PlanNote)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PlanNote elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PlanNote)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent Plan that contains this collection
		/// </summary>
		public Plan ParentPlan
		{
			get { return this.ParentDataObject as Plan; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Plan */ }
		}
	}
}
