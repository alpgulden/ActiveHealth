using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [InsurancePayorContact]
	/// </summary>
	[SPInsert("usp_InsertInsurancePayorContact")]
	[SPLoad("usp_LoadInsurancePayorContact")]
	[TableMapping("InsurancePayorContact","insurancePayorID,contactID",true)]
	[TableLinkageAttribute(typeof(InsurancePayor), "insurancePayorID", typeof(Contact), "contactID")]
	public class InsurancePayorContact : BaseDataClass
	{
		[NonSerialized]
		private InsurancePayorContactCollection parentInsurancePayorContactCollection;
		[ColumnMapping("InsurancePayorID",StereoType=DataStereoType.FK)]
		private int insurancePayorID;
		[ColumnMapping("ContactID",StereoType=DataStereoType.FK)]
		private int contactID;
	
		public InsurancePayorContact()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int InsurancePayorID
		{
			get { return this.insurancePayorID; }
			set { this.insurancePayorID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ContactID
		{
			get { return this.contactID; }
			set { this.contactID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent InsurancePayorContactCollection that contains this element
		/// </summary>
		public InsurancePayorContactCollection ParentInsurancePayorContactCollection
		{
			get
			{
				return this.parentInsurancePayorContactCollection;
			}
			set
			{
				this.parentInsurancePayorContactCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of InsurancePayorContact objects
	/// </summary>
	[ElementType(typeof(InsurancePayorContact))]
	public class InsurancePayorContactCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(InsurancePayorContact elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentInsurancePayorContactCollection = this;
			else
				elem.ParentInsurancePayorContactCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (InsurancePayorContact elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public InsurancePayorContact this[int index]
		{
			get
			{
				return (InsurancePayorContact)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((InsurancePayorContact)oldValue, false);
			SetParentOnElem((InsurancePayorContact)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent InsurancePayor that contains this collection
		/// </summary>
		public InsurancePayor ParentInsurancePayor
		{
			get { return this.ParentDataObject as InsurancePayor; }
			set { this.ParentDataObject = value; /* parent is set when contained by a InsurancePayor */ }
		}
	}
}
