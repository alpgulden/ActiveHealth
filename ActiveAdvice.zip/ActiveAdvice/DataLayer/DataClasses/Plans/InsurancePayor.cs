using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [InsurancePayors]
	/// </summary>
	[SPAutoGen("usp_SearchInsurancePayors","SearchByArgs.sptpl","alternatePayorId, name")]
	[SPAutoGen("usp_GetEffectiveInsurancePayors","SelectActiveRecordsForDate.sptpl","effectiveDate, terminationDate")]
	[SPInsert("usp_InsertInsurancePayor")]
	[SPUpdate("usp_UpdateInsurancePayor")]
	[SPDelete("usp_DeleteInsurancePayor")]
	[SPLoad("usp_LoadInsurancePayor")]
	[TableMapping("InsurancePayor","insurancePayorId")]
	public class InsurancePayor : BaseDataWithUserDefined
	{
		[NonSerialized]
		private InsurancePayorCollection parentInsurancePayorCollection;
		[ColumnMapping("InsurancePayorId",StereoType=DataStereoType.FK)]
		private int insurancePayorId;
		[ColumnMapping("Name")]
		private string name;
		[ColumnMapping("AlternatePayorId")]
		private string alternatePayorId;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("Notes")]
		private string notes;
		[ColumnMapping("AddressID",StereoType=DataStereoType.FK)]
		private int addressID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;

		private DateTime termDateWhenLoaded;		// the terminate date when the object was loaded
		private Address address;
		private InsurancePayorContactCollection insurancePayorContacts;
	
		public InsurancePayor()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public InsurancePayor(string name, string alternatePayorId)
		{
			this.NewRecord(); // initialize record state
			this.name = name;
			this.alternatePayorId = alternatePayorId;
		}

		public InsurancePayor(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int InsurancePayorId
		{
			get { return this.insurancePayorId; }
			set { this.insurancePayorId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=16)]
		[FieldDescription("@ALTERNATEID@")]
		public string AlternatePayorId
		{
			get { return this.alternatePayorId; }
			set { this.alternatePayorId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Notes
		{
			get { return this.notes; }
			set { this.notes = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SaveInsurancePayorContacts(); // save the items in a seperate transaction
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int insurancePayorId)
		{
			return base.Load(insurancePayorId);
		}

		/// <summary>
		/// Parent InsurancePayorCollection that contains this element
		/// </summary>
		public InsurancePayorCollection ParentInsurancePayorCollection
		{
			get
			{
				return this.parentInsurancePayorCollection;
			}
			set
			{
				this.parentInsurancePayorCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.addressID = 0;
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=128)]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}

		/// <summary>
		/// Contained Address object
		/// </summary>
		[Contained]
		public Address Address
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.address = (Address)Address.EnsureContainedDataObject(this, typeof(Address), address, false, addressID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.address;
			}
			set
			{
				this.address = value;
				if (value != null) value.ParentInsurancePayor = this; // set this as a parent of the child data class
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			this.Address.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			{
				base.InternalSave();	// in that case, delete the base first
				Address.MarkDel();	// then allow the deletion of the conatined object
			}

			Address.IsNew = this.IsNew;		// make sure the address is new if the containing object is new
			Address.Save();
			this.addressID = Address.AddressID; // set the fk if the contained object was newly created
			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}
			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Child InsurancePayorContacts mapped to related rows of table InsurancePayorContact where [InsurancePayorId] = [InsurancePayorID]
		/// </summary>
		[SPLoadChild("usp_LoadInsurancePayorContacts", "insurancePayorID")]
		public InsurancePayorContactCollection InsurancePayorContacts
		{
			get { return this.insurancePayorContacts; }
			set
			{
				this.insurancePayorContacts = value;
				if (value != null)
					value.ParentInsurancePayor = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the InsurancePayorContacts collection
		/// </summary>
		public void LoadInsurancePayorContacts(bool forceReload)
		{
			this.insurancePayorContacts = (InsurancePayorContactCollection)InsurancePayorContactCollection.LoadChildCollection("InsurancePayorContacts", this, typeof(InsurancePayorContactCollection), insurancePayorContacts, forceReload, null);
		}

		/// <summary>
		/// Saves the InsurancePayorContacts collection
		/// </summary>
		public void SaveInsurancePayorContacts()
		{
			InsurancePayorContactCollection.SaveChildCollection(this.insurancePayorContacts, true);
		}

		/// <summary>
		/// Synchronizes the InsurancePayorContacts collection
		/// </summary>
		public void SynchronizeInsurancePayorContacts()
		{
			InsurancePayorContactCollection.SynchronizeChildCollection(this.insurancePayorContacts, true);
		}

		#region IContactOwner Members

		public BaseDataCollectionClass GetContacts()
		{
			if (InsurancePayorContacts == null) LoadInsurancePayorContacts(false);
			return InsurancePayorContacts;
		}

		public void LoadContacts(bool forceLoad)
		{
			this.LoadInsurancePayorContacts(forceLoad);
		}

		public void SaveContacts()
		{
			this.SaveInsurancePayorContacts();
		}

		public ContactOwnerType ContactOwnerType
		{
			get
			{
				return ContactOwnerType.InsurancePayor;
			}
		}

		#endregion

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFields(this, "Name");
				//writer.AddFieldsOnNewLine(this, "EffectiveDate", "TerminationDate");
			}
		}

		/// <summary>
		/// Create a copy of the insurance payor.
		/// </summary>
		/// <returns></returns>
		public InsurancePayor CreateCopyOfInsurancePayor()
		{
			InsurancePayor insurancePayor = (InsurancePayor)this.Clone(true);
			this.Address.CopyMappedMembersTo(insurancePayor.Address, false, false, false);
			return insurancePayor;
		}
	}

	/// <summary>
	/// Strongly typed collection of InsurancePayor objects
	/// </summary>
	[ElementType(typeof(InsurancePayor))]
	public class InsurancePayorCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_InsurancePayorId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(InsurancePayor elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentInsurancePayorCollection = this;
			else
				elem.ParentInsurancePayorCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (InsurancePayor elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public InsurancePayor this[int index]
		{
			get
			{
				return (InsurancePayor)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((InsurancePayor)oldValue, false);
			SetParentOnElem((InsurancePayor)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadEffectiveInsurancePayors(int maxRecords, DateTime currentDate)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetEffectiveInsurancePayors", maxRecords, this, false, currentDate);
		}

		/// <summary>
		/// Accessor to a shared InsurancePayorCollection which is cached in NSGlobal
		/// </summary>
		public static InsurancePayorCollection EffectiveInsurancePayors
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				InsurancePayorCollection col = (InsurancePayorCollection)NSGlobal.EnsureCachedObject("EffectiveInsurancePayors", typeof(InsurancePayorCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadEffectiveInsurancePayors(-1, DateTime.Today);
				}
				return col;
			}
			
		}

		public static void ClearFromCache()
		{
			NSGlobal.ClearCache(typeof(InsurancePayorCollection), false);
		}

		/// <summary>
		/// Search insurance payors by the given searcher object and fill the collection.
		/// </summary>
		public int SearchInsurancePayors(int maxRecords, InsurancePayor searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchInsurancePayors", maxRecords, this, searcher, false);
		}

		/// <summary>
		/// Hashtable based index on insurancePayorId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_InsurancePayorId
		{
			get
			{
				if (this.indexBy_InsurancePayorId == null)
					this.indexBy_InsurancePayorId = new CollectionIndexer(this, new string[] { "insurancePayorId" }, true);
				return this.indexBy_InsurancePayorId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on insurancePayorId fields returns the object.  Uses the IndexBy_InsurancePayorId indexer.
		/// </summary>
		public InsurancePayor FindBy(int insurancePayorId)
		{
			return (InsurancePayor)this.IndexBy_InsurancePayorId.GetObject(insurancePayorId);
		}
	}
}
