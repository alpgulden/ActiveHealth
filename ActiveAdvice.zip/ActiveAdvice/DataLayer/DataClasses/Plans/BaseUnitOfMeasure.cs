using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [BaseUnitOfMeasures]
	/// </summary>
	[SPAutoGen("usp_GetAllBaseUnitOfMeasures","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetBaseUnitOfMeasuresByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertBaseUnitOfMeasure")]
	[SPUpdate("usp_UpdateBaseUnitOfMeasure")]
	[SPDelete("usp_DeleteBaseUnitOfMeasure")]
	[SPLoad("usp_LoadBaseUnitOfMeasure")]
	[TableMapping("BaseUnitOfMeasure","baseUnitOfMeasureId")]
	public class BaseUnitOfMeasure : BaseLookupWithCode
	{
		[NonSerialized]
		private BaseUnitOfMeasureCollection parentBaseUnitOfMeasureCollection;
		[ColumnMapping("BaseUnitOfMeasureId",StereoType=DataStereoType.FK)]
		private int baseUnitOfMeasureId;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public BaseUnitOfMeasure()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public BaseUnitOfMeasure(int baseUnitOfMeasureId, string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.baseUnitOfMeasureId = baseUnitOfMeasureId;
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int BaseUnitOfMeasureId
		{
			get { return this.baseUnitOfMeasureId; }
			set { this.baseUnitOfMeasureId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int baseUnitOfMeasureId)
		{
			return base.Load(baseUnitOfMeasureId);
		}

		/// <summary>
		/// Parent BaseUnitOfMeasureCollection that contains this element
		/// </summary>
		public BaseUnitOfMeasureCollection ParentBaseUnitOfMeasureCollection
		{
			get
			{
				return this.parentBaseUnitOfMeasureCollection;
			}
			set
			{
				this.parentBaseUnitOfMeasureCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of BaseUnitOfMeasure objects
	/// </summary>
	[ElementType(typeof(BaseUnitOfMeasure))]
	public class BaseUnitOfMeasureCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_BaseUnitOfMeasureId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(BaseUnitOfMeasure elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentBaseUnitOfMeasureCollection = this;
			else
				elem.ParentBaseUnitOfMeasureCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (BaseUnitOfMeasure elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public BaseUnitOfMeasure this[int index]
		{
			get
			{
				return (BaseUnitOfMeasure)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((BaseUnitOfMeasure)oldValue, false);
			SetParentOnElem((BaseUnitOfMeasure)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads the collection with base unit of measures either active or inactive
		/// </summary>
		public int LoadBaseUnitOfMeasuresByActive(int maxRecords, bool active)
		{
			return SqlData.SPExecReadCol("usp_GetBaseUnitOfMeasuresByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared BaseUnitOfMeasureCollection which is cached in NSGlobal
		/// </summary>
		public static BaseUnitOfMeasureCollection ActiveBaseUnitOfMeasures
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				BaseUnitOfMeasureCollection col = (BaseUnitOfMeasureCollection)NSGlobal.EnsureCachedObject("ActiveBaseUnitOfMeasures", typeof(BaseUnitOfMeasureCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadBaseUnitOfMeasuresByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Load all Base Unit of Measures into collection
		/// </summary>
		public override void LoadAll()
		{
			SqlData.SPExecReadCol("usp_GetAllBaseUnitOfMeasures", -1, this, false);
		}

		/// <summary>
		/// Searches for Base Unit Of Measures matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchBaseUnitOfMeasures", -1, this, false, code, description, active);
		}

		/// <summary>
		/// Hashtable based index on baseUnitOfMeasureId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_BaseUnitOfMeasureId
		{
			get
			{
				if (this.indexBy_BaseUnitOfMeasureId == null)
					this.indexBy_BaseUnitOfMeasureId = new CollectionIndexer(this, new string[] { "baseUnitOfMeasureId" }, true);
				return this.indexBy_BaseUnitOfMeasureId;
			}
			
		}

		/// <summary>
		/// Looks up by baseUnitOfMeasureId and returns Description value.  Uses the IndexBy_BaseUnitOfMeasureId indexer.
		/// </summary>
		public string Lookup_DescriptionByBaseUnitOfMeasureId(int baseUnitOfMeasureId)
		{
			return this.IndexBy_BaseUnitOfMeasureId.LookupStringMember("Description", baseUnitOfMeasureId);
		}
	}
}
