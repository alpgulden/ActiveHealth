using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PlanTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllPlanTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetPlanTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertPlanType")]
	[SPUpdate("usp_UpdatePlanType")]
	[SPDelete("usp_DeletePlanType")]
	[SPLoad("usp_LoadPlanType")]
	[TableMapping("PlanType","planTypeId")]
	public class PlanType : BaseLookup
	{
		[NonSerialized]
		private PlanTypeCollection parentPlanTypeCollection;
		[ColumnMapping("PlanTypeId",StereoType=DataStereoType.FK)]
		private int planTypeId;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public PlanType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PlanType(int planTypeId, string description)
		{
			this.NewRecord(); // initialize record state
			this.planTypeId = planTypeId;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PlanTypeId
		{
			get { return this.planTypeId; }
			set { this.planTypeId = value; }
		}

		/// <summary>
		/// Parent PlanTypeCollection that contains this element
		/// </summary>
		public PlanTypeCollection ParentPlanTypeCollection
		{
			get
			{
				return this.parentPlanTypeCollection;
			}
			set
			{
				this.parentPlanTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int planTypeId)
		{
			return base.Load(planTypeId);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of PlanType objects
	/// </summary>
	[ElementType(typeof(PlanType))]
	public class PlanTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PlanType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPlanTypeCollection = this;
			else
				elem.ParentPlanTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PlanType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PlanType this[int index]
		{
			get
			{
				return (PlanType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PlanType)oldValue, false);
			SetParentOnElem((PlanType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPlanTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPlanTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PlanTypeCollection which is cached in NSGlobal
		/// </summary>
		public static PlanTypeCollection ActivePlanTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PlanTypeCollection col = (PlanTypeCollection)NSGlobal.EnsureCachedObject("ActivePlanTypes", typeof(PlanTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPlanTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Loads all Plan Types into collection.
		/// </summary>
		public override void LoadAll()
		{
			SqlData.SPExecReadCol("usp_GetAllPlanTypes", -1, this, false);
		}

		/// <summary>
		/// Searches for Plan Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchPlanTypes", -1, this, false, description, active);
		}
	}
}
