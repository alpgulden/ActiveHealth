using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PlanContacts]
	/// </summary>
	[SPInsert("usp_InsertPlanContact")]
	[SPLoad("usp_LoadPlanContact")]
	[TableMapping("PlanContact","planID,contactID",true)]
	[TableLinkageAttribute(typeof(Plan), "planID", typeof(Contact), "contactID")]
	public class PlanContact : BaseLinkageClass
	{
		[NonSerialized]
		private PlanContactCollection parentPlanContactCollection;
		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
		private int planID;
		[ColumnMapping("ContactID",StereoType=DataStereoType.FK)]
		private int contactID;
	
		public PlanContact()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PlanID
		{
			get { return this.planID; }
			set { this.planID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ContactID
		{
			get { return this.contactID; }
			set { this.contactID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent PlanContactCollection that contains this element
		/// </summary>
		public PlanContactCollection ParentPlanContactCollection
		{
			get
			{
				return this.parentPlanContactCollection;
			}
			set
			{
				this.parentPlanContactCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PlanContact objects
	/// </summary>
	[ElementType(typeof(PlanContact))]
	public class PlanContactCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PlanContact elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPlanContactCollection = this;
			else
				elem.ParentPlanContactCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PlanContact elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PlanContact this[int index]
		{
			get
			{
				return (PlanContact)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PlanContact)oldValue, false);
			SetParentOnElem((PlanContact)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Plan that contains this collection
		/// </summary>
		public Plan ParentPlan
		{
			get { return this.ParentDataObject as Plan; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Plan */ }
		}
	}
}
