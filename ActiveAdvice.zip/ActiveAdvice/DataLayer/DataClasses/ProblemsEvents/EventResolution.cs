using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EventResolution]
	/// </summary>
	[SPAutoGen("usp_GetAllEventResolutions","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetEventResolutionsByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertEventResolution")]
	[SPUpdate("usp_UpdateEventResolution")]
	[SPDelete("usp_DeleteEventResolution")]
	[SPLoad("usp_LoadEventResolution")]
	[TableMapping("EventResolution","eventResolutionID")]
	public class EventResolution : BaseLookupWithCode
	{
		[NonSerialized]
		private EventResolutionCollection parentEventResolutionCollection;
		[ColumnMapping("EventResolutionID",StereoType=DataStereoType.FK)]
		private int eventResolutionID;
		[ColumnMapping("UB92Disposition")]
		private string uB92Disposition;
		[ColumnMapping("Notepad")]
		private string notepad;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
	
		public EventResolution()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EventResolutionID
		{
			get { return this.eventResolutionID; }
			set { this.eventResolutionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string UB92Disposition
		{
			get { return this.uB92Disposition; }
			set { this.uB92Disposition = value; }
		}

		public int UB92DispositionAsInt
		{
			get 
			{
				return int.Parse(this.uB92Disposition);
			}
			set 
			{ 
				this.uB92Disposition = value.ToString();
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Parent EventResolutionCollection that contains this element
		/// </summary>
		public EventResolutionCollection ParentEventResolutionCollection
		{
			get
			{
				return this.parentEventResolutionCollection;
			}
			set
			{
				this.parentEventResolutionCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of EventResolution objects
	/// </summary>
	[ElementType(typeof(EventResolution))]
	public class EventResolutionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_EventResolutionID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EventResolution elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEventResolutionCollection = this;
			else
				elem.ParentEventResolutionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EventResolution elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EventResolution this[int index]
		{
			get
			{
				return (EventResolution)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EventResolution)oldValue, false);
			SetParentOnElem((EventResolution)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadEventResolutionsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetEventResolutionsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared EventResolutionCollection which is cached in NSGlobal
		/// </summary>
		public static EventResolutionCollection ActiveEventResolutions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				EventResolutionCollection col = (EventResolutionCollection)NSGlobal.EnsureCachedObject("ActiveEventResolutions", typeof(EventResolutionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadEventResolutionsByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on eventResolutionID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_EventResolutionID
		{
			get
			{
				if (this.indexBy_EventResolutionID == null)
					this.indexBy_EventResolutionID = new CollectionIndexer(this, new string[] { "eventResolutionID" }, true);
				return this.indexBy_EventResolutionID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on eventResolutionID fields returns the object.  Uses the IndexBy_EventResolutionID indexer.
		/// </summary>
		public EventResolution FindBy(int eventResolutionID)
		{
			return (EventResolution)this.IndexBy_EventResolutionID.GetObject(eventResolutionID);
		}
	}
}
