using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EventReferralProcedure]
	/// 
	/// These objects are owned by Event, CMS or Referral as a child collection.
	/// They are manipulated in the UI using an intermediary collection ProcedureSelectionCollection.
	/// </summary>
	[SPInsert("usp_InsertEventReferralProcedure")]
	[SPUpdate("usp_UpdateEventReferralProcedure")]
	[SPDelete("usp_DeleteEventReferralProcedure")]
	[SPLoad("usp_LoadEventReferralProcedure")]
	[TableMapping("EventReferralProcedure","eventProcedureID")]
	public class EventReferralProcedure : BaseData
	{
		[NonSerialized]
		private EventReferralProcedureCollection parentEventReferralProcedureCollection;
		[ColumnMapping("EventProcedureID",StereoType=DataStereoType.FK)]
		private int eventProcedureID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("ProcedureCode")]
		private string procedureCode;
		[ColumnMapping("ProcedureType")]
		private string procedureType;
		[ColumnMapping("Modifier1")]
		private string modifier1;
		[ColumnMapping("Modifier2")]
		private string modifier2;
		[ColumnMapping("Modifier3")]
		private string modifier3;
		[ColumnMapping("ScheduledDate")]
		private DateTime scheduledDate;
		[ColumnMapping("ReferralId",StereoType=DataStereoType.FK)]
		private int referralId;
		[ColumnMapping("CMSId",StereoType=DataStereoType.FK)]
		private int cMSId;
		[ColumnMapping("Sequence",StereoType=DataStereoType.FK)]
		private int sequence;
		[ColumnMapping("LinkedPxType")]
		private string linkedPxType;
		[ColumnMapping("LinkedPxCode")]
		private string linkedPxCode;
		[ColumnMapping("CMTrigger")]
		private bool cMTrigger;
		[ColumnMapping("DMTrigger")]
		private bool dMTrigger;
		[ColumnMapping("OPReview")]
		private bool oPReview;
		[ColumnMapping("IPReview")]
		private bool iPReview;
		[ColumnMapping("OPReviewOther")]
		private bool oPReviewOther;
		[ColumnMapping("IPReviewOther")]
		private bool iPReviewOther;
		[ColumnMapping("Referral")]
		private bool referral;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public EventReferralProcedure()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public EventReferralProcedure(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public void CopyMembersFromSelection(ProcedureSelect sel)
		{
			this.procedureType = sel.CodeType;
			this.procedureCode = sel.CodeValue;
			this.modifier1 = sel.Modifier1;
			this.modifier2 = sel.Modifier2;
			this.modifier3 = sel.Modifier3;
			this.linkedPxType = sel.LinkedPxType;
			this.linkedPxCode = sel.LinkedPxCode;
			this.scheduledDate = sel.Scheduled;
			this.sequence = sel.Sequence;
			this.Flags = sel.Flags;

			// copy flags
			this.IsMarkedForDeletion = sel.IsMarkedForDeletion;
			this.IsNew = sel.IsNew;
			this.IsDirty = sel.IsDirty;
		}

		public void CopyMembersToSelection(ProcedureSelect sel)
		{
			sel.Scheduled = this.scheduledDate;
			sel.Modifier1 = this.modifier1;
			sel.Modifier2 = this.modifier2;
			sel.Modifier3 = this.modifier3;
			sel.LinkedPxType = this.linkedPxType;
			sel.LinkedPxCode = this.linkedPxCode;
			sel.Sequence = this.sequence;
			sel.Flags = this.Flags;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EventProcedureID
		{
			get { return this.eventProcedureID; }
			set { this.eventProcedureID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=7)]
		public string ProcedureCode
		{
			get { return this.procedureCode; }
			set { this.procedureCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string ProcedureType
		{
			get { return this.procedureType; }
			set { this.procedureType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string Modifier1
		{
			get { return this.modifier1; }
			set { this.modifier1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string Modifier2
		{
			get { return this.modifier2; }
			set { this.modifier2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string Modifier3
		{
			get { return this.modifier3; }
			set { this.modifier3 = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ScheduledDate
		{
			get { return this.scheduledDate; }
			set { this.scheduledDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralId
		{
			get { return this.referralId; }
			set { this.referralId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSId
		{
			get { return this.cMSId; }
			set { this.cMSId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Sequence
		{
			get { return this.sequence; }
			set { this.sequence = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string LinkedPxType
		{
			get { return this.linkedPxType; }
			set { this.linkedPxType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string LinkedPxCode
		{
			get { return this.linkedPxCode; }
			set { this.linkedPxCode = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool CMTrigger
		{
			get { return this.cMTrigger; }
			set { this.cMTrigger = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool DMTrigger
		{
			get { return this.dMTrigger; }
			set { this.dMTrigger = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool OPReview
		{
			get { return this.oPReview; }
			set { this.oPReview = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool IPReview
		{
			get { return this.iPReview; }
			set { this.iPReview = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool OPReviewOther
		{
			get { return this.oPReviewOther; }
			set { this.oPReviewOther = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool IPReviewOther
		{
			get { return this.iPReviewOther; }
			set { this.iPReviewOther = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		public EnumDxPxFlag Flags
		{
			get { return DxPxSelect.MakeDxPxFlags(this.cMTrigger, this.dMTrigger, this.oPReview, this.iPReview, this.oPReviewOther, this.iPReviewOther, this.referral); }
			set { DxPxSelect.ExtractDxPxFlags(value, ref this.cMTrigger, ref this.dMTrigger, ref this.oPReview, ref this.iPReview, ref this.oPReviewOther, ref this.iPReviewOther, ref this.referral); }
		}

		public string ProcedureTypeAndCode
		{
			get
			{
				if (this.procedureType == null && this.procedureCode == null)
					return null;
				else
					return String.Format("{0}-{1}", this.procedureType , this.procedureCode);
			}
		}

		/// <summary>
		/// Loads and returns the procedure object referred.
		/// </summary>
		/// <returns></returns>
		public BaseDxPx GetProcedureObject()
		{
			return DxPxCodeClassFactory.CreateAndLoadDxPxInstance(this.procedureType, this.procedureCode, BaseDxPx.DxPxProcedure);
		}

		/// <summary>
		/// Loads and returns the linked procedure object referred.
		/// </summary>
		/// <returns></returns>
		public BaseDxPx GetLinkedProcedureObject()
		{
			return DxPxCodeClassFactory.CreateAndLoadDxPxInstance(this.linkedPxType, this.linkedPxCode, BaseDxPx.DxPxProcedure);
		}

		public string ProcedureDescription
		{
			get
			{
				BaseDxPx dxPxCode = GetProcedureObject();
				return dxPxCode.CodeDescription;
			}
		}

		public string ProcedureFullDescription
		{
			get
			{
				BaseDxPx dxPxCode = GetProcedureObject();
				return String.Format("{0} {1}-{2}", dxPxCode.CodeType, dxPxCode.CodeValue, dxPxCode.CodeDescription);
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eventProcedureID)
		{
			return base.Load(eventProcedureID);
		}

		/// <summary>
		/// Parent EventReferralProcedureCollection that contains this element
		/// </summary>
		public EventReferralProcedureCollection ParentEventReferralProcedureCollection
		{
			get
			{
				return this.parentEventReferralProcedureCollection;
			}
			set
			{
				this.parentEventReferralProcedureCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Referral
		{
			get { return this.referral; }
			set { this.referral = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of EventReferralProcedure objects
	/// </summary>
	[ElementType(typeof(EventReferralProcedure))]
	public class EventReferralProcedureCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EventReferralProcedure elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEventReferralProcedureCollection = this;
			else
				elem.ParentEventReferralProcedureCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EventReferralProcedure elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EventReferralProcedure this[int index]
		{
			get
			{
				return (EventReferralProcedure)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EventReferralProcedure)oldValue, false);
			SetParentOnElem((EventReferralProcedure)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Event ParentEvent
		{
			get { return this.ParentDataObject as Event; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}

		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Referral ParentReferral
		{
			get { return this.ParentDataObject as Referral; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}

		public void SyncFromSelections(ProcedureSelectCollection procedures)
		{
			for (int i = 0; i < procedures.Count; i++)
			{
				ProcedureSelect sel = procedures[i];
				EventReferralProcedure proc = null;
				if (sel.ParentSelectionIndex < 0)		// this is just a linked element used for display purpose.
				{
					if (sel.IsNew)
					{
						proc = new EventReferralProcedure(true);
						this.AddRecord(proc);
					}
					else
					{
						if (sel.SourceCollectionIndex < 0)
							throw new ActiveAdviceException(AAExceptionAction.None, "Source collection index is not on the selection, can't update back");
						proc = this[sel.SourceCollectionIndex];
					}
					if (proc != null)
						proc.CopyMembersFromSelection(sel);
				}

			}
		}

		/// <summary>
		/// Creates a selection collection that is manipulated by the ZippyCoder.
		/// After the ZippyCoder is done, it calls SyncProcedureCodes to 
		/// get the changes back to the actual EventProcedures.
		/// </summary>
		/// <returns></returns>
		public ProcedureSelectCollection CreateSelectionCollection()
		{
			ProcedureSelectCollection selections = new ProcedureSelectCollection();
			
			for (int i = 0; i < this.Count; i++)
			{
				int index = selections.Add(this[i], i);
				/*ProcedureSelect procSelect = selections[index];
				// check if there are any linked (mapped) and associated the index
				foreach (ProcedureSelect existingProcSelect in selections)
				{
					if (procSelect != existingProcSelect)
					{
						if (existingProcSelect.LinkedPxType != null && existingProcSelect.LinkedPxCode != null)
						{
							procSelect.ParentSelectionIndex = existingProcSelect.SourceCollectionIndex;
							break;
						}
					}
				}*/

			}

			return selections;
		}

		public EventReferralProcedure PrimaryProcedure
		{
			get
			{
				if (this.Count > 0)
					return this[0];
				else
					return null;
			}
		}

		public EventReferralProcedure SecondaryProcedure
		{
			get
			{
				if (this.Count > 1)
					return this[1];
				else
					return null;
			}
		}

	}
}
