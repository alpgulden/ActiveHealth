using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EventType]
	/// </summary>
	[SPAutoGen("usp_GetEventTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetEventTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertEventType")]
	[SPUpdate("usp_UpdateEventType")]
	[SPDelete("usp_DeleteEventType")]
	[SPLoad("usp_LoadEventType")]
	[TableMapping("EventType","eventTypeID")]
	public class EventType : BaseLookupWithCode
	{
		[NonSerialized]
		private EventTypeCollection parentEventTypeCollection;
		[ColumnMapping("EventTypeID",StereoType=DataStereoType.FK)]
		private int eventTypeID;
		[ColumnMapping("HEDISRptType")]
		private string hEDISRptType;
		[ColumnMapping("HEDISRptAcuity")]
		private string hEDISRptAcuity;
		[ColumnMapping("Notepad")]
		private string notepad;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public EventType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EventTypeID
		{
			get { return this.eventTypeID; }
			set { this.eventTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=20)]
		public string HEDISRptType
		{
			get { return this.hEDISRptType; }
			set { this.hEDISRptType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=10)]
		public string HEDISRptAcuity
		{
			get { return this.hEDISRptAcuity; }
			set { this.hEDISRptAcuity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eventTypeID)
		{
			return base.Load(eventTypeID);
		}

		/// <summary>
		/// Parent EventTypeCollection that contains this element
		/// </summary>
		public EventTypeCollection ParentEventTypeCollection
		{
			get
			{
				return this.parentEventTypeCollection;
			}
			set
			{
				this.parentEventTypeCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of EventType objects
	/// </summary>
	[ElementType(typeof(EventType))]
	public class EventTypeCollection : BaseLookupWithCodeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		[NonSerialized]
		private CollectionIndexer indexBy_EventTypeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EventType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEventTypeCollection = this;
			else
				elem.ParentEventTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EventType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EventType this[int index]
		{
			get
			{
				return (EventType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EventType)oldValue, false);
			SetParentOnElem((EventType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Load the collection with active/inactive event types.
		/// </summary>
		public int LoadEventTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetEventTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared EventTypeCollection which is cached in NSGlobal
		/// </summary>
		public static EventTypeCollection ActiveEventTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				EventTypeCollection col = (EventTypeCollection)NSGlobal.EnsureCachedObject("ActiveEventTypes", typeof(EventTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadEventTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on eventTypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_EventTypeID
		{
			get
			{
				if (this.indexBy_EventTypeID == null)
					this.indexBy_EventTypeID = new CollectionIndexer(this, new string[] { "eventTypeID" }, true);
				return this.indexBy_EventTypeID;
			}
			
		}

		/// <summary>
		/// Looks up by eventTypeID and returns Description value.  Uses the IndexBy_EventTypeID indexer.
		/// </summary>
		public string Lookup_DescriptionByEventTypeID(int eventTypeID)
		{
			return this.IndexBy_EventTypeID.LookupStringMember("Description", eventTypeID);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns EventTypeID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_EventTypeIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("EventTypeID", code);
		}
	}
}
