using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ClinicalReviewDecision]
	/// </summary>
	[SPAutoGen("usp_GetLastDecisionForEvent","JoinWithParentFilterParentLoadChild.sptpl",
			"ClinicalReviewRequest, clinicalReviewRequestID, clinicalReviewRequestID, eventID",
			InjectPreOperation="SET ROWCOUNT 1  -- top record",
			InjectOrderBy="ORDER BY [ClinicalReviewDecision].[ClinicalReviewDecisionID] DESC"
		 )]
	[SPInsert("usp_InsertClinicalReviewDecision")]
	[SPUpdate("usp_UpdateClinicalReviewDecision")]
	[SPDelete("usp_DeleteClinicalReviewDecision")]
	[SPLoad("usp_LoadClinicalReviewDecision")]
	[TableMapping("ClinicalReviewDecision","clinicalReviewDecisionID")]
	public class ClinicalReviewDecision : BaseDataWithUserDefined
	{
		[NonSerialized]
		private ClinicalReviewDecisionCollection parentClinicalReviewDecisionCollection;
		[ColumnMapping("ClinicalReviewDecisionID",StereoType=DataStereoType.FK)]
		private int clinicalReviewDecisionID;
		[ColumnMapping("ClinicalReviewRequestID",StereoType=DataStereoType.FK)]
		private int clinicalReviewRequestID;
		[ColumnMapping("EventProcedureID",StereoType=DataStereoType.FK)]
		private int eventProcedureID;
		[ColumnMapping("ClinicalReviewDecisionTypeID",StereoType=DataStereoType.FK)]		// lookup
		private int clinicalReviewDecisionTypeID;
		[ColumnMapping("ClinicalReviewDecisionReasonID",StereoType=DataStereoType.FK)]	// lookup
		private int clinicalReviewDecisionReasonID;
		[ColumnMapping("DecAmount")]
		private int decAmount;
		[ColumnMapping("DecUOMID",StereoType=DataStereoType.FK)]
		private int decUOMID;
		[ColumnMapping("Comment")]
		private string comment;
		[ColumnMapping("ActualEndDate")]
		private DateTime actualEndDate;
		[ColumnMapping("ClinicalReviewDescriptionID",StereoType=DataStereoType.FK)]		// lookup
		private int clinicalReviewDescriptionID;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("ActualAmount")]
		private int actualAmount;
		[ColumnMapping("UnitCost")]
		private Decimal unitCost;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("PercentUnitDisc")]
		private int percentUnitDisc;
		[ColumnMapping("FreqUOMID",StereoType=DataStereoType.FK)]	// lookup
		private int freqUOMID;
		[ColumnMapping("FreqAmount")]
		private int freqAmount;
		[ColumnMapping("DurationAmount")]
		private int durationAmount;
		[ColumnMapping("DurationUOMID",StereoType=DataStereoType.FK)]		// lookup
		private int durationUOMID;
		[ColumnMapping("LinkedProcedureType")]
		private string linkedProcedureType;
		[ColumnMapping("LinkedProcedureCode")]
		private string linkedProcedureCode;
		[ColumnMapping("ClinicalRationale")]
		private string clinicalRationale;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		
		private Event eventObj;				// the event object that's in the context

		public ClinicalReviewDecision()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ClinicalReviewDecision(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@DECISIONID@")]
		public int ClinicalReviewDecisionID
		{
			get { return this.clinicalReviewDecisionID; }
			set { this.clinicalReviewDecisionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]	
		public int ClinicalReviewRequestID
		{
			get { return this.clinicalReviewRequestID; }
			set { this.clinicalReviewRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EventProcedureID
		{
			get { return this.eventProcedureID; }
			set { this.eventProcedureID = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewDecisionTypeID", "ClinicalReviewDecisionTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@DECISIONTYPE@")]
		public int ClinicalReviewDecisionTypeID
		{
			get { return this.clinicalReviewDecisionTypeID; }
			set { this.clinicalReviewDecisionTypeID = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewDecisionReasonID", "ClinicalReviewDecisionReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@DECISIONREASON@")]
		public int ClinicalReviewDecisionReasonID
		{
			get { return this.clinicalReviewDecisionReasonID; }
			set { this.clinicalReviewDecisionReasonID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int DecAmount
		{
			get { return this.decAmount; }
			set { this.decAmount = value; }
		}

		[FieldValuesMember("LookupOf_DecUOMID", "ClinicalReviewUnitID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int DecUOMID
		{
			get { return this.decUOMID; }
			set { this.decUOMID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Comment
		{
			get { return this.comment; }
			set { this.comment = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ActualEndDate
		{
			get { return this.actualEndDate; }
			set { this.actualEndDate = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewDescriptionID", "ClinicalReviewDescriptionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@DESCRIPTION@")]
		public int ClinicalReviewDescriptionID
		{
			get { return this.clinicalReviewDescriptionID; }
			set { this.clinicalReviewDescriptionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ActualAmount
		{
			get { return this.actualAmount; }
			set { this.actualAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		public decimal UnitCost
		{
			get { return this.unitCost; }
			set { this.unitCost = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PercentUnitDisc
		{
			get { return this.percentUnitDisc; }
			set { this.percentUnitDisc = value; }
		}

		[FieldValuesMember("LookupOf_FreqUOMID", "ClinicalReviewFreqUnitID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int FreqUOMID
		{
			get { return this.freqUOMID; }
			set { this.freqUOMID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int FreqAmount
		{
			get { return this.freqAmount; }
			set { this.freqAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DurationAmount
		{
			get { return this.durationAmount; }
			set { this.durationAmount = value; }
		}

		[FieldValuesMember("LookupOf_DurationUOMID", "ClinicalReviewDurUnitID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int DurationUOMID
		{
			get { return this.durationUOMID; }
			set { this.durationUOMID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string LinkedProcedureType
		{
			get { return this.linkedProcedureType; }
			set { this.linkedProcedureType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string LinkedProcedureCode
		{
			get { return this.linkedProcedureCode; }
			set { this.linkedProcedureCode = value; }
		}

		[FieldValuesMember("LookupOf_LinkedProcedureTypeAndCode", "ProcedureTypeAndCode", "ProcedureFullDescription")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		[FieldDescription("@LINKEDPROCEDURECODE@")]
		public string LinkedProcedureTypeAndCode
		{
			get
			{
				return String.Format("{0}-{1}", this.linkedProcedureType , this.linkedProcedureCode);
			}
			set
			{
				this.linkedProcedureType = null;
				this.linkedProcedureCode = null;
				if (value != null)
				{
					int i = value.IndexOf('-');
					if (i >= 0)
					{
						this.linkedProcedureType = value.Substring(0, i);		// before -
						this.linkedProcedureCode = value.Substring(i + 1);		// after -
					}
				}
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string ClinicalRationale
		{
			get { return this.clinicalRationale; }
			set { this.clinicalRationale = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		

		/*/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}*/

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int clinicalReviewDecisionID)
		{
			return base.Load(clinicalReviewDecisionID);
		}

		/// <summary>
		/// Parent ClinicalReviewDecisionCollection that contains this element
		/// </summary>
		public ClinicalReviewDecisionCollection ParentClinicalReviewDecisionCollection
		{
			get
			{
				return this.parentClinicalReviewDecisionCollection;
			}
			set
			{
				this.parentClinicalReviewDecisionCollection = value; // parent is set when added to a collection
			}
		}

		public ClinicalReviewDecisionTypeCollection LookupOf_ClinicalReviewDecisionTypeID
		{
			get
			{
				return ClinicalReviewDecisionTypeCollection.ActiveClinicalReviewDecisionTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDecisionReasonCollection LookupOf_ClinicalReviewDecisionReasonID
		{
			get
			{
				return ClinicalReviewDecisionReasonCollection.ActiveClinicalReviewDecisionReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDescriptionCollection LookupOf_ClinicalReviewDescriptionID
		{
			get
			{
				return ClinicalReviewDescriptionCollection.ActiveClinicalReviewDescriptions; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewFreqUnitCollection LookupOf_FreqUOMID
		{
			get
			{
				return ClinicalReviewFreqUnitCollection.ActiveClinicalReviewFreqUnits; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDurUnitCollection LookupOf_DurationUOMID
		{
			get
			{
				return ClinicalReviewDurUnitCollection.ActiveClinicalReviewDurUnits; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewUnitCollection LookupOf_DecUOMID
		{
			get
			{
				return ClinicalReviewUnitCollection.ActiveClinicalReviewUnits; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// The Event object to be used in the context of this object
		/// </summary>
		public ActiveAdvice.DataLayer.Event EventObj
		{
			get 
			{ 
				if (this.eventObj == null)
				{
					// try getting it from the parents
					ClinicalReviewDecisionCollection decisions = this.parentClinicalReviewDecisionCollection;
					if (decisions != null && decisions.ParentClinicalReviewRequest != null)
					{
						ClinicalReviewRequestCollection requests = decisions.ParentClinicalReviewRequest.ParentClinicalReviewRequestCollection;
						if (requests != null)
							this.eventObj = requests.ParentEvent;
					}
				}
				return this.eventObj; 
			}
			set { this.eventObj = value; }
		}

		public EventReferralProcedureCollection LookupOf_LinkedProcedureTypeAndCode
		{
			get
			{
				if (this.EventObj == null)
					return null;

				this.EventObj.LoadEventProcedures(false);
				return this.EventObj.EventReferralProcedures;
			}
		}

		/// <summary>
		/// Load the last decision for an event
		/// </summary>
		public bool LoadLastDecisionForEvent(int eventID)
		{
			return SqlData.SPExecReadObj("usp_GetLastDecisionForEvent", new object[] { this /*, other objects to be filled */ }, false, new object[] { eventID });
		}

	}

	/// <summary>
	/// Strongly typed collection of ClinicalReviewDecision objects
	/// </summary>
	[ElementType(typeof(ClinicalReviewDecision))]
	public class ClinicalReviewDecisionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClinicalReviewDecision elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClinicalReviewDecisionCollection = this;
			else
				elem.ParentClinicalReviewDecisionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClinicalReviewDecision elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClinicalReviewDecision this[int index]
		{
			get
			{
				return (ClinicalReviewDecision)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClinicalReviewDecision)oldValue, false);
			SetParentOnElem((ClinicalReviewDecision)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent ClinicalReviewRequest that contains this collection
		/// </summary>
		public ClinicalReviewRequest ParentClinicalReviewRequest
		{
			get { return this.ParentDataObject as ClinicalReviewRequest; }
			set { this.ParentDataObject = value; /* parent is set when contained by a ClinicalReviewRequest */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ClinicalReviewDecision elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ClinicalReviewDecision)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
