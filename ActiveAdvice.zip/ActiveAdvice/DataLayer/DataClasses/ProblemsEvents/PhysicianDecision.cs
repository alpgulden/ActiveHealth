using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianDecision]
	/// </summary>
	[SPInsert("usp_InsertPhysicianDecision")]
	[SPUpdate("usp_UpdatePhysicianDecision")]
	[SPDelete("usp_DeletePhysicianDecision")]
	[SPLoad("usp_LoadPhysicianDecision")]
	[TableMapping("PhysicianDecision","physicianDecisionID")]
	public class PhysicianDecision : BaseDataWithUserDefined
	{
		[NonSerialized]
		private PhysicianDecisionCollection parentPhysicianDecisionCollection;
		[ColumnMapping("PhysicianDecisionID",StereoType=DataStereoType.FK)]
		private int physicianDecisionID;
		[ColumnMapping("ProviderNetworkID",StereoType=DataStereoType.FK)]							// pick
		private int providerNetworkID;
		[ColumnMapping("PhysicianRequestID",StereoType=DataStereoType.FK)]
		private int physicianRequestID;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]							// pick
		private int providerLocationID;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]									// pick
		private int providerID;
		[ColumnMapping("ProviderSpecialtyID",StereoType=DataStereoType.FK)]
		private int providerSpecialtyID;
		[ColumnMapping("PhysicianDecisionRoleID",StereoType=DataStereoType.FK)]			// lookup
		private int physicianDecisionRoleID;
		[ColumnMapping("PhysicianReviewDecisionID",StereoType=DataStereoType.FK)]		// lookup
		private int physicianReviewDecisionID;
		[ColumnMapping("PhysicianDecisionReasonID",StereoType=DataStereoType.FK)]		// lookup
		private int physicianDecisionReasonID;
		[ColumnMapping("PhysicianReviewRequestDetailTypeID",StereoType=DataStereoType.FK)]	// lookup
		private int physicianReviewRequestDetailTypeID;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("SpokeToProvider")]
		private bool spokeToProvider;
		[ColumnMapping("ExplainedAppealsProcess")]
		private bool explainedAppealsProcess;
		[ColumnMapping("MinutesSpent")]
		private int minutesSpent;
		[ColumnMapping("TransactionNumber")]
		private string transactionNumber;
		[ColumnMapping("CheckNumber")]
		private string checkNumber;
		[ColumnMapping("GeneratePayable")]
		private bool generatePayable;
		[ColumnMapping("GeneratePayableDate")]
		private DateTime generatePayableDate;
		[ColumnMapping("CheckAmount")]
		private Decimal checkAmount;
		[ColumnMapping("DateGenerated")]
		private DateTime dateGenerated;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public PhysicianDecision()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianDecision(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@DECISIONID@")]
		public int PhysicianDecisionID
		{
			get { return this.physicianDecisionID; }
			set { this.physicianDecisionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)0)]
		public int ProviderNetworkID
		{
			get { return this.providerNetworkID; }
			set { this.providerNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PhysicianRequestID
		{
			get { return this.physicianRequestID; }
			set { this.physicianRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)0)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)0)]
		public int ProviderSpecialtyID
		{
			get { return this.providerSpecialtyID; }
			set { this.providerSpecialtyID = value; }
		}

		// this is not in the table!!!
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderNetworkStatusID
		{
			get { return 0; }
			set { }
		}

		[FieldDescription("@PROVIDER@")]
		public string ProviderName
		{
			get 
			{
				return Provider.GetProviderFullNameByID(this.providerID);
			}
		}

		[FieldDescription("@SPECIALTY@")]
		public string SpecialtyName
		{
			get 
			{
				return ProviderSpecialty.GetProviderSpecialtyDescriptionByID(this.providerID);
			}
		}

		[FieldValuesMember("LookupOf_PhysicianDecisionRoleID", "PhysicianDecisionRoleID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int PhysicianDecisionRoleID
		{
			get { return this.physicianDecisionRoleID; }
			set { this.physicianDecisionRoleID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewDecisionID", "PhysicianReviewDecisionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@DECISION@")]
		public int PhysicianReviewDecisionID
		{
			get { return this.physicianReviewDecisionID; }
			set { this.physicianReviewDecisionID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianDecisionReasonID", "PhysicianDecisionReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@DECISIONREASON@")]
		public int PhysicianDecisionReasonID
		{
			get { return this.physicianDecisionReasonID; }
			set { this.physicianDecisionReasonID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewRequestDetailTypeID", "PhysicianReviewRequestDetailTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@DECISIONTYPE@")]
		public int PhysicianReviewRequestDetailTypeID
		{
			get { return this.physicianReviewRequestDetailTypeID; }
			set { this.physicianReviewRequestDetailTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool SpokeToProvider
		{
			get { return this.spokeToProvider; }
			set { this.spokeToProvider = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ExplainedAppealsProcess
		{
			get { return this.explainedAppealsProcess; }
			set { this.explainedAppealsProcess = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int MinutesSpent
		{
			get { return this.minutesSpent; }
			set { this.minutesSpent = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string TransactionNumber
		{
			get { return this.transactionNumber; }
			set { this.transactionNumber = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string CheckNumber
		{
			get { return this.checkNumber; }
			set { this.checkNumber = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool GeneratePayable
		{
			get { return this.generatePayable; }
			set { this.generatePayable = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime GeneratePayableDate
		{
			get { return this.generatePayableDate; }
			set { this.generatePayableDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal CheckAmount
		{
			get { return this.checkAmount; }
			set { this.checkAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DateGenerated
		{
			get { return this.dateGenerated; }
			set { this.dateGenerated = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int physicianDecisionID)
		{
			return base.Load(physicianDecisionID);
		}

		/// <summary>
		/// Parent PhysicianDecisionCollection that contains this element
		/// </summary>
		public PhysicianDecisionCollection ParentPhysicianDecisionCollection
		{
			get
			{
				return this.parentPhysicianDecisionCollection;
			}
			set
			{
				this.parentPhysicianDecisionCollection = value; // parent is set when added to a collection
			}
		}

		public PhysicianDecisionRoleCollection LookupOf_PhysicianDecisionRoleID
		{
			get
			{
				return PhysicianDecisionRoleCollection.ActivePhysicianDecisionRoles; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewDecisionCollection LookupOf_PhysicianReviewDecisionID
		{
			get
			{
				return PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianDecisionReasonCollection LookupOf_PhysicianDecisionReasonID
		{
			get
			{
				return PhysicianDecisionReasonCollection.ActivePhysicianDecisionReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewRequestDetailTypeCollection LookupOf_PhysicianReviewRequestDetailTypeID
		{
			get
			{
				return PhysicianReviewRequestDetailTypeCollection.ActivePhysicianReviewRequestDetailTypes; // Acquire a shared instance from the static member of collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PhysicianDecision objects
	/// </summary>
	[ElementType(typeof(PhysicianDecision))]
	public class PhysicianDecisionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianDecision elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianDecisionCollection = this;
			else
				elem.ParentPhysicianDecisionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianDecision elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianDecision this[int index]
		{
			get
			{
				return (PhysicianDecision)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianDecision)oldValue, false);
			SetParentOnElem((PhysicianDecision)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent PhysicianRequest that contains this collection
		/// </summary>
		public PhysicianRequest ParentPhysicianRequest
		{
			get { return this.ParentDataObject as PhysicianRequest; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PhysicianRequest */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PhysicianDecision elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PhysicianDecision)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
