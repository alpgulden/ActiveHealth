using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianReview]
	/// </summary>
	[SPInsert("usp_InsertPhysicianReview")]
	[SPUpdate("usp_UpdatePhysicianReview")]
	[SPDelete("usp_DeletePhysicianReview")]
	[SPLoad("usp_LoadPhysicianReview")]
	[TableMapping("PhysicianReview","physicianReviewID")]
	public class PhysicianReview : BaseDataWithUserDefined
	{
		[NonSerialized]
		private PhysicianReviewCollection parentPhysicianReviewCollection;
		[ColumnMapping("PhysicianReviewID",StereoType=DataStereoType.FK)]
		private int physicianReviewID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("PhysicianReviewRequestReasonID",StereoType=DataStereoType.FK)]			// lookup
		private int physicianReviewRequestReasonID;
		[ColumnMapping("PhysicianReviewDecisionID",StereoType=DataStereoType.FK)]				// lookup
		private int physicianReviewDecisionID;
		[ColumnMapping("StatusID",StereoType=DataStereoType.FK)]									// lookup
		private int statusID;
		[ColumnMapping("StatusChangedBy",StereoType=DataStereoType.FK)]
		private int statusChangedBy;
		[ColumnMapping("StatusChangeTime")]
		private DateTime statusChangeTime;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		private int patientID;
		[ColumnMapping("ProblemID",StereoType=DataStereoType.FK)]
		private int problemID;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		private int referralDetailID;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ClinicalReviewDecisionID",StereoType=DataStereoType.FK)]		// what's this???  is it physicianReviewDecisionID?
		private int clinicalReviewDecisionID;
		
		private int statusIDWhenLoaded;
		private PhysicianRequestCollection physicianRequests;				// keeps track of the changes in status
	
		public PhysicianReview()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianReview(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// track the change of statusID.
			this.statusIDWhenLoaded = this.statusID;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			if (this.IsNew || this.statusID != this.statusIDWhenLoaded)
			{
				// status changed.
				this.SetStatusChangingUser();
			}

			base.InternalSave();
			// Save the child collections here.

			// save child tables that are managed in-memory
			this.SavePhysicianRequests();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@REVIEWID@")]
		public int PhysicianReviewID
		{
			get { return this.physicianReviewID; }
			set { this.physicianReviewID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewRequestReasonID", "PhysicianReviewRequestReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@REQUESTREASON@")]
		public int PhysicianReviewRequestReasonID
		{
			get { return this.physicianReviewRequestReasonID; }
			set { this.physicianReviewRequestReasonID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewDecisionID", "PhysicianReviewDecisionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@DECISION@")]
		public int PhysicianReviewDecisionID
		{
			get { return this.physicianReviewDecisionID; }
			set { this.physicianReviewDecisionID = value; }
		}

		[FieldValuesMember("LookupOf_StatusID", "StatusId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int StatusID
		{
			get { return this.statusID; }
			set { this.statusID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime StatusChangeTime
		{
			get { return this.statusChangeTime; }
			set { this.statusChangeTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProblemID
		{
			get { return this.problemID; }
			set { this.problemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		// what's this?
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ClinicalReviewDecisionID
		{
			get { return this.clinicalReviewDecisionID; }
			set { this.clinicalReviewDecisionID = value; }
		}

		

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int physicianReviewID)
		{
			return base.Load(physicianReviewID);
		}

		/// <summary>
		/// Parent PhysicianReviewCollection that contains this element
		/// </summary>
		public PhysicianReviewCollection ParentPhysicianReviewCollection
		{
			get
			{
				return this.parentPhysicianReviewCollection;
			}
			set
			{
				this.parentPhysicianReviewCollection = value; // parent is set when added to a collection
			}
		}

		public PhysicianReviewRequestReasonCollection LookupOf_PhysicianReviewRequestReasonID
		{
			get
			{
				return PhysicianReviewRequestReasonCollection.ActivePhysicianReviewRequestReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewDecisionCollection LookupOf_PhysicianReviewDecisionID
		{
			get
			{
				return PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions; // Acquire a shared instance from the static member of collection
			}
		}

		public SystemStatusCollection LookupOf_StatusID
		{
			get
			{
				return SystemStatusCollection.ActiveSystemStatuses; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Child PhysicianRequests mapped to related rows of table PhysicianRequest where [PhysicianReviewID] = [PhysicianReviewID]
		/// </summary>
		[SPLoadChild("usp_LoadPhysicianReviewRequests", "physicianReviewID")]
		public PhysicianRequestCollection PhysicianRequests
		{
			get { return this.physicianRequests; }
			set
			{
				this.physicianRequests = value;
				if (value != null)
					value.ParentPhysicianReview = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PhysicianRequests collection
		/// </summary>
		public void LoadPhysicianRequests(bool forceReload)
		{
			this.physicianRequests = (PhysicianRequestCollection)PhysicianRequestCollection.LoadChildCollection("PhysicianRequests", this, typeof(PhysicianRequestCollection), physicianRequests, forceReload, null);
		}

		/// <summary>
		/// Saves the PhysicianRequests collection
		/// </summary>
		public void SavePhysicianRequests()
		{
			PhysicianRequestCollection.SaveChildCollection(this.physicianRequests, true);
		}

		/// <summary>
		/// Synchronizes the PhysicianRequests collection
		/// </summary>
		public void SynchronizePhysicianRequests()
		{
			PhysicianRequestCollection.SynchronizeChildCollection(this.physicianRequests, true);
		}
	}

	/// <summary>
	/// Strongly typed collection of PhysicianReview objects
	/// </summary>
	[ElementType(typeof(PhysicianReview))]
	public class PhysicianReviewCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianReview elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianReviewCollection = this;
			else
				elem.ParentPhysicianReviewCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianReview elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianReview this[int index]
		{
			get
			{
				return (PhysicianReview)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianReview)oldValue, false);
			SetParentOnElem((PhysicianReview)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Event ParentEvent
		{
			get { return this.ParentDataObject as Event; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PhysicianReview elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PhysicianReview)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
