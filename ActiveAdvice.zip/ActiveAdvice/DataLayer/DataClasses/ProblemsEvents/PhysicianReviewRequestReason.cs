using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianReviewRequestReason]
	/// </summary>
	[SPAutoGen("usp_GetPhysicianReviewRequestReasons","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetPhysicianReviewRequestReasonsByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertPhysicianReviewRequestReason")]
	[SPUpdate("usp_UpdatePhysicianReviewRequestReason")]
	[SPDelete("usp_DeletePhysicianReviewRequestReason")]
	[SPLoad("usp_LoadPhysicianReviewRequestReason")]
	[TableMapping("PhysicianReviewRequestReason","physicianReviewRequestReasonID")]
	public class PhysicianReviewRequestReason : BaseLookupStandard
	{
		[NonSerialized]
		private PhysicianReviewRequestReasonCollection parentPhysicianReviewRequestReasonCollection;
		[ColumnMapping("PhysicianReviewRequestReasonID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestReasonID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public PhysicianReviewRequestReason()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianReviewRequestReason(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PhysicianReviewRequestReasonID
		{
			get { return this.physicianReviewRequestReasonID; }
			set { this.physicianReviewRequestReasonID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int physicianReviewRequestReasonID)
		{
			return base.Load(physicianReviewRequestReasonID);
		}

		/// <summary>
		/// Parent PhysicianReviewRequestReasonCollection that contains this element
		/// </summary>
		public PhysicianReviewRequestReasonCollection ParentPhysicianReviewRequestReasonCollection
		{
			get
			{
				return this.parentPhysicianReviewRequestReasonCollection;
			}
			set
			{
				this.parentPhysicianReviewRequestReasonCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PhysicianReviewRequestReason objects
	/// </summary>
	[ElementType(typeof(PhysicianReviewRequestReason))]
	public class PhysicianReviewRequestReasonCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianReviewRequestReason elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianReviewRequestReasonCollection = this;
			else
				elem.ParentPhysicianReviewRequestReasonCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianReviewRequestReason elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianReviewRequestReason this[int index]
		{
			get
			{
				return (PhysicianReviewRequestReason)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianReviewRequestReason)oldValue, false);
			SetParentOnElem((PhysicianReviewRequestReason)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPhysicianReviewRequestReasonsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPhysicianReviewRequestReasonsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PhysicianReviewRequestReasonCollection which is cached in NSGlobal
		/// </summary>
		public static PhysicianReviewRequestReasonCollection ActivePhysicianReviewRequestReasons
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PhysicianReviewRequestReasonCollection col = (PhysicianReviewRequestReasonCollection)NSGlobal.EnsureCachedObject("ActivePhysicianReviewRequestReasons", typeof(PhysicianReviewRequestReasonCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPhysicianReviewRequestReasonsByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
