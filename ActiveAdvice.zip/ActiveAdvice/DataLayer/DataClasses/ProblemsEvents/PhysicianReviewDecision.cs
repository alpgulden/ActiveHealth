using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianReviewDecision]
	/// </summary>
	[SPAutoGen("usp_GetPhysicianReviewDecisions","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetPhysicianReviewDecisionsByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertPhysicianReviewDecision")]
	[SPUpdate("usp_UpdatePhysicianReviewDecision")]
	[SPDelete("usp_DeletePhysicianReviewDecision")]
	[SPLoad("usp_LoadPhysicianReviewDecision")]
	[TableMapping("PhysicianReviewDecision","physicianReviewDecisionID")]
	public class PhysicianReviewDecision : BaseLookupStandard
	{
		[NonSerialized]
		private PhysicianReviewDecisionCollection parentPhysicianReviewDecisionCollection;
		[ColumnMapping("PhysicianReviewDecisionID",StereoType=DataStereoType.FK)]
		private int physicianReviewDecisionID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public PhysicianReviewDecision()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianReviewDecision(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PhysicianReviewDecisionID
		{
			get { return this.physicianReviewDecisionID; }
			set { this.physicianReviewDecisionID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int physicianReviewDecisionID)
		{
			return base.Load(physicianReviewDecisionID);
		}

		/// <summary>
		/// Parent PhysicianReviewDecisionCollection that contains this element
		/// </summary>
		public PhysicianReviewDecisionCollection ParentPhysicianReviewDecisionCollection
		{
			get
			{
				return this.parentPhysicianReviewDecisionCollection;
			}
			set
			{
				this.parentPhysicianReviewDecisionCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PhysicianReviewDecision objects
	/// </summary>
	[ElementType(typeof(PhysicianReviewDecision))]
	public class PhysicianReviewDecisionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianReviewDecision elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianReviewDecisionCollection = this;
			else
				elem.ParentPhysicianReviewDecisionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianReviewDecision elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianReviewDecision this[int index]
		{
			get
			{
				return (PhysicianReviewDecision)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianReviewDecision)oldValue, false);
			SetParentOnElem((PhysicianReviewDecision)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPhysicianReviewDecisionsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPhysicianReviewDecisionsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PhysicianReviewDecisionCollection which is cached in NSGlobal
		/// </summary>
		public static PhysicianReviewDecisionCollection ActivePhysicianReviewDecisions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PhysicianReviewDecisionCollection col = (PhysicianReviewDecisionCollection)NSGlobal.EnsureCachedObject("ActivePhysicianReviewDecisions", typeof(PhysicianReviewDecisionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPhysicianReviewDecisionsByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
