using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EventConsultingProvider]
	/// </summary>
	[SPInsert("usp_InsertEventConsultingProvider")]
	[SPUpdate("usp_UpdateEventConsultingProvider")]
	[SPDelete("usp_DeleteEventConsultingProvider")]
	[SPLoad("usp_LoadEventConsultingProvider")]
	[TableMapping("EventConsultingProvider","consultingProviderID")]
	public class EventConsultingProvider : BaseDataWithUserDefined
	{
		[NonSerialized]
		private EventConsultingProviderCollection parentEventConsultingProviderCollection;
		[ColumnMapping("ConsultingProviderID",StereoType=DataStereoType.FK)]
		private int consultingProviderID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]
		private int providerID;
		[ColumnMapping("ProviderSpecialtyID",StereoType=DataStereoType.FK)]
		private int providerSpecialtyID;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("ProviderLocationNetworkID",StereoType=DataStereoType.FK)]
		private int providerLocationNetworkID;
		[ColumnMapping("ProviderNetworkStatusID",StereoType=DataStereoType.FK)]
		private int providerNetworkStatusID;
		[ColumnMapping("RoleID",StereoType=DataStereoType.FK)]
		private int roleID;
		[ColumnMapping("ServiceDate")]
		private DateTime serviceDate;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		[ColumnMapping("ProviderFirstName", JoinColumn="FirstName", JoinRelation="EventConsultingProvider.ProviderID = [Provider].ProviderID")]
		private string providerFirstName;
		[ColumnMapping("ProviderLastName", JoinColumn="LastName", JoinRelation="EventConsultingProvider.ProviderID = [Provider].ProviderID")]
		private string providerLastName;

		private string providerName;

		public EventConsultingProvider()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public EventConsultingProvider(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ConsultingProviderID
		{
			get { return this.consultingProviderID; }
			set { this.consultingProviderID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)0)]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderSpecialtyID
		{
			get { return this.providerSpecialtyID; }
			set { this.providerSpecialtyID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderLocationNetworkID
		{
			get { return this.providerLocationNetworkID; }
			set { this.providerLocationNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProviderNetworkStatusID
		{
			get { return this.providerNetworkStatusID; }
			set { this.providerNetworkStatusID = value; }
		}

		[FieldValuesMember("LookupOf_RoleID", "RoleID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int RoleID
		{
			get { return this.roleID; }
			set { this.roleID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ServiceDate
		{
			get { return this.serviceDate; }
			set { this.serviceDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int consultingProviderID)
		{
			return base.Load(consultingProviderID);
		}

		/// <summary>
		/// Parent EventConsultingProviderCollection that contains this element
		/// </summary>
		public EventConsultingProviderCollection ParentEventConsultingProviderCollection
		{
			get
			{
				return this.parentEventConsultingProviderCollection;
			}
			set
			{
				this.parentEventConsultingProviderCollection = value; // parent is set when added to a collection
			}
		}

		public RoleCollection LookupOf_RoleID
		{
			get
			{
				return RoleCollection.ProviderLocationRoles; // Acquire a shared instance from the static member of collection
			}
		}

		public string ProviderName
		{
			get 
			{
				if (this.providerName == null)
				{
					if (this.providerFirstName == null)
						this.providerName = Provider.GetProviderFullNameByID(this.providerID);
					else
						this.providerName = providerFirstName + " " + providerLastName;
				}
				return this.providerName;
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of EventConsultingProvider objects
	/// </summary>
	[ElementType(typeof(EventConsultingProvider))]
	public class EventConsultingProviderCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EventConsultingProvider elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEventConsultingProviderCollection = this;
			else
				elem.ParentEventConsultingProviderCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EventConsultingProvider elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EventConsultingProvider this[int index]
		{
			get
			{
				return (EventConsultingProvider)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EventConsultingProvider)oldValue, false);
			SetParentOnElem((EventConsultingProvider)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(EventConsultingProvider elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((EventConsultingProvider)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Event ParentEvent
		{
			get { return this.ParentDataObject as Event; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}
	}
}
