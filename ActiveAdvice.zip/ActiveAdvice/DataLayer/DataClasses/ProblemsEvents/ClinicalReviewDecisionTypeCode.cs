using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ClinicalReviewDecisionTypeCode]
	/// </summary>
	[SPAutoGen("usp_GetClinicalReviewDecisionTypeCodes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetClinicalReviewDecisionTypeCodesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertClinicalReviewDecisionTypeCode")]
	[SPUpdate("usp_UpdateClinicalReviewDecisionTypeCode")]
	[SPDelete("usp_DeleteClinicalReviewDecisionTypeCode")]
	[SPLoad("usp_LoadClinicalReviewDecisionTypeCode")]
	[TableMapping("ClinicalReviewDecisionTypeCode","clinicalReviewDecisionTypeCodeID")]
	public class ClinicalReviewDecisionTypeCode : BaseLookupStandard
	{
		[NonSerialized]
		private ClinicalReviewDecisionTypeCodeCollection parentClinicalReviewDecisionTypeCodeCollection;
		[ColumnMapping("ClinicalReviewDecisionTypeCodeID",StereoType=DataStereoType.FK)]
		private int clinicalReviewDecisionTypeCodeID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public ClinicalReviewDecisionTypeCode()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ClinicalReviewDecisionTypeCode(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ClinicalReviewDecisionTypeCodeID
		{
			get { return this.clinicalReviewDecisionTypeCodeID; }
			set { this.clinicalReviewDecisionTypeCodeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int clinicalReviewDecisionTypeCodeID)
		{
			return base.Load(clinicalReviewDecisionTypeCodeID);
		}

		/// <summary>
		/// Parent ClinicalReviewDecisionTypeCodeCollection that contains this element
		/// </summary>
		public ClinicalReviewDecisionTypeCodeCollection ParentClinicalReviewDecisionTypeCodeCollection
		{
			get
			{
				return this.parentClinicalReviewDecisionTypeCodeCollection;
			}
			set
			{
				this.parentClinicalReviewDecisionTypeCodeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ClinicalReviewDecisionTypeCode objects
	/// </summary>
	[ElementType(typeof(ClinicalReviewDecisionTypeCode))]
	public class ClinicalReviewDecisionTypeCodeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClinicalReviewDecisionTypeCode elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClinicalReviewDecisionTypeCodeCollection = this;
			else
				elem.ParentClinicalReviewDecisionTypeCodeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClinicalReviewDecisionTypeCode elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClinicalReviewDecisionTypeCode this[int index]
		{
			get
			{
				return (ClinicalReviewDecisionTypeCode)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClinicalReviewDecisionTypeCode)oldValue, false);
			SetParentOnElem((ClinicalReviewDecisionTypeCode)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadClinicalReviewDecisionTypeCodesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetClinicalReviewDecisionTypeCodesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ClinicalReviewDecisionTypeCodeCollection which is cached in NSGlobal
		/// </summary>
		public static ClinicalReviewDecisionTypeCodeCollection ActiveClinicalReviewDecisionTypeCodes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ClinicalReviewDecisionTypeCodeCollection col = (ClinicalReviewDecisionTypeCodeCollection)NSGlobal.EnsureCachedObject("ActiveClinicalReviewDecisionTypeCodes", typeof(ClinicalReviewDecisionTypeCodeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadClinicalReviewDecisionTypeCodesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
