using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [EventReferralDiagnose]
	/// 
	/// These objects are owned by Event, CMS or Referral as a child collection.
	/// They are manipulated in the UI using an intermediary collection DiagnosticSelectionCollection.
	/// </summary>
	[SPInsert("usp_InsertEventReferralDiagnose")]
	[SPUpdate("usp_UpdateEventReferralDiagnose")]
	[SPDelete("usp_DeleteEventReferralDiagnose")]
	[SPLoad("usp_LoadEventReferralDiagnose")]
	[TableMapping("EventReferralDiagnose","eventDiagnosisID")]
	public class EventReferralDiagnose : BaseData
	{
		[NonSerialized]
		private EventReferralDiagnoseCollection parentEventReferralDiagnoseCollection;
		[ColumnMapping("EventDiagnosisID",StereoType=DataStereoType.FK)]
		private int eventDiagnosisID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("DSM4Axis",StereoType=DataStereoType.FK)]
		private int dSM4Axis;
		[ColumnMapping("DiagnosisType")]
		private string diagnosisType;
		[ColumnMapping("DiagnosisCode")]
		private string diagnosisCode;
		[ColumnMapping("ReferralId",StereoType=DataStereoType.FK)]
		private int referralId;
		[ColumnMapping("CMSId",StereoType=DataStereoType.FK)]
		private int cMSId;
		[ColumnMapping("CMTrigger")]
		private bool cMTrigger;
		[ColumnMapping("DMTrigger")]
		private bool dMTrigger;
		[ColumnMapping("OPReview")]
		private bool oPReview;
		[ColumnMapping("IPReview")]
		private bool iPReview;
		[ColumnMapping("OPReviewOther")]
		private bool oPReviewOther;
		[ColumnMapping("IPReviewOther")]
		private bool iPReviewOther;
		[ColumnMapping("Referral")]
		private bool referral;
		[ColumnMapping("Sequence",StereoType=DataStereoType.FK)]
		private int sequence;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public EventReferralDiagnose()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public EventReferralDiagnose(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public void CopyMembersFromSelection(DiagnosticSelect sel)
		{
			this.diagnosisType = sel.CodeType;
			this.diagnosisCode = sel.CodeValue;
			this.dSM4Axis = sel.Axis;
			this.sequence = sel.Sequence;
			this.Flags = sel.Flags;
			
			// copy flags
			this.IsMarkedForDeletion = sel.IsMarkedForDeletion;
			this.IsNew = sel.IsNew;
			this.IsDirty = sel.IsDirty;
		}

		public void CopyMembersToSelection(DiagnosticSelect sel)
		{
			sel.Axis = this.dSM4Axis;
			sel.Sequence = this.sequence;
			sel.Flags = this.Flags;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EventDiagnosisID
		{
			get { return this.eventDiagnosisID; }
			set { this.eventDiagnosisID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DSM4Axis
		{
			get { return this.dSM4Axis; }
			set { this.dSM4Axis = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string DiagnosisType
		{
			get { return this.diagnosisType; }
			set { this.diagnosisType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=7)]
		public string DiagnosisCode
		{
			get { return this.diagnosisCode; }
			set { this.diagnosisCode = value; }
		}

		/// <summary>
		/// Diagnostic code for display.  
		/// For DSM4, the first 6 characters if 7 characters or more found.
		/// Otherwise returns all characters.
		/// </summary>
		public string DisplayCode
		{
			get 
			{ 
				if (this.diagnosisType != BaseDxPx.CodeTypeDSM4)
					return this.diagnosisCode;

				// if DSM4, return only first 6 characters.
				if (this.diagnosisCode == null)
					return null;
				if (this.diagnosisCode.Length < 7)
					return this.diagnosisCode;
				return this.diagnosisCode.Substring(0, 6);		// only first 6 chars.
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralId
		{
			get { return this.referralId; }
			set { this.referralId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSId
		{
			get { return this.cMSId; }
			set { this.cMSId = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool CMTrigger
		{
			get { return this.cMTrigger; }
			set { this.cMTrigger = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool DMTrigger
		{
			get { return this.dMTrigger; }
			set { this.dMTrigger = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool OPReview
		{
			get { return this.oPReview; }
			set { this.oPReview = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool IPReview
		{
			get { return this.iPReview; }
			set { this.iPReview = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool OPReviewOther
		{
			get { return this.oPReviewOther; }
			set { this.oPReviewOther = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool IPReviewOther
		{
			get { return this.iPReviewOther; }
			set { this.iPReviewOther = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int Sequence
		{
			get { return this.sequence; }
			set { this.sequence = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		public EnumDxPxFlag Flags
		{
			get { return DxPxSelect.MakeDxPxFlags(this.cMTrigger, this.dMTrigger, this.oPReview, this.iPReview, this.oPReviewOther, this.iPReviewOther, this.referral); }
			set { DxPxSelect.ExtractDxPxFlags(value, ref this.cMTrigger, ref this.dMTrigger, ref this.oPReview, ref this.iPReview, ref this.oPReviewOther, ref this.iPReviewOther, ref this.referral); }
		}

		/// <summary>
		/// Loads and returns the diagnostic object referred.
		/// </summary>
		/// <returns></returns>
		public BaseDxPx GetLinkedDiagnosticObject()
		{
			return DxPxCodeClassFactory.CreateAndLoadDxPxInstance(this.diagnosisType, this.diagnosisCode, BaseDxPx.DxPxDiagnostic);
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eventDiagnosisID)
		{
			return base.Load(eventDiagnosisID);
		}

		/// <summary>
		/// Parent EventReferralDiagnoseCollection that contains this element
		/// </summary>
		public EventReferralDiagnoseCollection ParentEventReferralDiagnoseCollection
		{
			get
			{
				return this.parentEventReferralDiagnoseCollection;
			}
			set
			{
				this.parentEventReferralDiagnoseCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "	eventDiagnosisID= '" + ReflectionHelper.GetMemberValueAsString(this, "eventDiagnosisID") + "'\r\n";
			s += "	diagnosisType= '" + ReflectionHelper.GetMemberValueAsString(this, "diagnosisType") + "'\r\n";
			s += "	diagnosisCode= '" + ReflectionHelper.GetMemberValueAsString(this, "diagnosisCode") + "'\r\n";
			s += "}\r\n";
			return s;

		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Referral
		{
			get { return this.referral; }
			set { this.referral = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of EventReferralDiagnose objects
	/// </summary>
	[ElementType(typeof(EventReferralDiagnose))]
	public class EventReferralDiagnoseCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(EventReferralDiagnose elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEventReferralDiagnoseCollection = this;
			else
				elem.ParentEventReferralDiagnoseCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (EventReferralDiagnose elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public EventReferralDiagnose this[int index]
		{
			get
			{
				return (EventReferralDiagnose)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((EventReferralDiagnose)oldValue, false);
			SetParentOnElem((EventReferralDiagnose)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Event ParentEvent
		{
			get { return this.ParentDataObject as Event; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}

		/// <summary>
		/// Parent Referral that contains this collection
		/// </summary>
		public Referral ParentReferral
		{
			get { return this.ParentDataObject as Referral; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Referral */ }
		}

		//public void SyncFromSelection(DiagnosticSelect selection)
		//{
		//	this.
		//}

		public void SyncFromSelections(DiagnosticSelectCollection diagnostics)
		{
			// Set the admitting diagnostics value to the event.
			if (this.ParentEvent != null)	// set the admitting diagnosis type and code for event
			{
				this.ParentEvent.AdmittingDiagnosisType = diagnostics.Data.AdmittingDiagnosisType;
				this.ParentEvent.AdmittingDiagnosisCode = diagnostics.Data.AdmittingDiagnosisCode;
				this.ParentEvent.DSM4Axis5Best = diagnostics.Data.DSM4Axis5Best;
				this.ParentEvent.DSM4Axis5Current = diagnostics.Data.DSM4Axis5Current;
				this.ParentEvent.DSM4Axis5Start = diagnostics.Data.DSM4Axis5Start;
			}
			else if (this.ParentReferral != null)
			{
				this.ParentReferral.AdmittingDxType = diagnostics.Data.AdmittingDiagnosisType;
				this.ParentReferral.AdmittingDxCode = diagnostics.Data.AdmittingDiagnosisCode;
				this.ParentReferral.Dsm4Axis5Best = diagnostics.Data.DSM4Axis5Best;
				this.ParentReferral.Dsm4Axis5Current = diagnostics.Data.DSM4Axis5Current;
				this.ParentReferral.Dsm4Axis5Start = diagnostics.Data.DSM4Axis5Start;
			}

			for (int i = 0; i < diagnostics.Count; i++)
			{
				DiagnosticSelect sel = diagnostics[i];
				EventReferralDiagnose diag = null;
				if (sel.ParentSelectionIndex < 0)		// this is just a linked element used for display purpose.
				{
					if (sel.IsNew)
					{
						diag = new EventReferralDiagnose(true);
						this.AddRecord(diag);
					}
					else
					{
						if (sel.SourceCollectionIndex < 0)
							throw new ActiveAdviceException(AAExceptionAction.None, "Source collection index is not on the selection, can't update back");
						diag = this[sel.SourceCollectionIndex];
					}

					if (diag != null)
						diag.CopyMembersFromSelection(sel);
				}
			}

		}

		public EventReferralDiagnose PrimaryDiagnose
		{
			get
			{
				if (this.Count > 0)
					return this[0];
				else
					return null;
			}
		}

		public EventReferralDiagnose SecondaryDiagnose
		{
			get
			{
				if (this.Count > 1)
					return this[1];
				else
					return null;
			}
		}

		/// <summary>
		/// Creates a selection collection that is manipulated by the ZippyCoder.
		/// After the ZippyCoder is done, it calls SyncDiagnosticCodes to 
		/// get the changes back to the actual EventDiagnoses.
		/// </summary>
		/// <returns></returns>
		public DiagnosticSelectCollection CreateSelectionCollection()
		{
			DiagnosticSelectCollection selections = new DiagnosticSelectCollection();

			if (this.ParentEvent != null)	// get the admitting diagnosis type and code for event
			{
				selections.Data.AdmittingDiagnosisType = this.ParentEvent.AdmittingDiagnosisType;
				selections.Data.AdmittingDiagnosisCode = this.ParentEvent.AdmittingDiagnosisCode;
				selections.Data.DSM4Axis5Best = this.ParentEvent.DSM4Axis5Best;
				selections.Data.DSM4Axis5Current = this.ParentEvent.DSM4Axis5Current;
				selections.Data.DSM4Axis5Start = this.ParentEvent.DSM4Axis5Start;
			}
			else if (this.ParentReferral != null)
			{
				selections.Data.AdmittingDiagnosisType = this.ParentReferral.AdmittingDxType;
				selections.Data.AdmittingDiagnosisCode = this.ParentReferral.AdmittingDxCode;
				selections.Data.DSM4Axis5Best = this.ParentReferral.Dsm4Axis5Best;
				selections.Data.DSM4Axis5Current = this.ParentReferral.Dsm4Axis5Current;
				selections.Data.DSM4Axis5Start = this.ParentReferral.Dsm4Axis5Start;
			}

			for (int i = 0; i < this.Count; i++)
			{
				selections.Add(this[i], i);
			}

			return selections;
		}

		


	}
}
