using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OutcomeType]
	/// </summary>
	[SPAutoGen("usp_GetOutcomeTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetOutcomeTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertOutcomeType")]
	[SPUpdate("usp_UpdateOutcomeType")]
	[SPDelete("usp_DeleteOutcomeType")]
	[SPLoad("usp_LoadOutcomeType")]
	[TableMapping("OutcomeType","outcomeTypeID")]
	public class OutcomeType : BaseLookupStandard
	{
		[NonSerialized]
		private OutcomeTypeCollection parentOutcomeTypeCollection;
		[ColumnMapping("OutcomeTypeID",StereoType=DataStereoType.FK)]
		private int outcomeTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public OutcomeType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public OutcomeType(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OutcomeTypeID
		{
			get { return this.outcomeTypeID; }
			set { this.outcomeTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int outcomeTypeID)
		{
			return base.Load(outcomeTypeID);
		}

		/// <summary>
		/// Parent OutcomeTypeCollection that contains this element
		/// </summary>
		public OutcomeTypeCollection ParentOutcomeTypeCollection
		{
			get
			{
				return this.parentOutcomeTypeCollection;
			}
			set
			{
				this.parentOutcomeTypeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of OutcomeType objects
	/// </summary>
	[ElementType(typeof(OutcomeType))]
	public class OutcomeTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OutcomeType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOutcomeTypeCollection = this;
			else
				elem.ParentOutcomeTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OutcomeType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OutcomeType this[int index]
		{
			get
			{
				return (OutcomeType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OutcomeType)oldValue, false);
			SetParentOnElem((OutcomeType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadOutcomeTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOutcomeTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared OutcomeTypeCollection which is cached in NSGlobal
		/// </summary>
		public static OutcomeTypeCollection ActiveOutcomeTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				OutcomeTypeCollection col = (OutcomeTypeCollection)NSGlobal.EnsureCachedObject("ActiveOutcomeTypes", typeof(OutcomeTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadOutcomeTypesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
