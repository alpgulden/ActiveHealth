using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OutcomeIndicatorSubIndicator]
	/// </summary>
	[SPInsert("usp_InsertOutcomeIndicatorSubIndicator")]
	[SPUpdate("usp_UpdateOutcomeIndicatorSubIndicator")]
	[SPDelete("usp_DeleteOutcomeIndicatorSubIndicator")]
	[SPLoad("usp_LoadOutcomeIndicatorSubIndicator")]
	[TableMapping("OutcomeIndicatorSubIndicator","outcomeIndicatorSubIndicatorId")]
	public class OutcomeIndicatorSubIndicator : BaseData
	{
		[NonSerialized]
		private OutcomeIndicatorSubIndicatorCollection parentOutcomeIndicatorSubIndicatorCollection;
		[ColumnMapping("OutcomeIndicatorSubIndicatorId",StereoType=DataStereoType.FK)]
		private int outcomeIndicatorSubIndicatorId;
		[ColumnMapping("OutcomeIndicatorId")]
		private int outcomeIndicatorId;
		[ColumnMapping("OutcomeSubIndicatorId")]
		private int outcomeSubIndicatorId;
	
		public OutcomeIndicatorSubIndicator()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public OutcomeIndicatorSubIndicator(int outcomeIndicatorId, int outcomeSubIndicatorId)
		{
			this.NewRecord(); // initialize record state
			this.outcomeIndicatorId = outcomeIndicatorId;
			this.outcomeSubIndicatorId = outcomeSubIndicatorId;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OutcomeIndicatorSubIndicatorId
		{
			get { return this.outcomeIndicatorSubIndicatorId; }
			set { this.outcomeIndicatorSubIndicatorId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OutcomeIndicatorId
		{
			get { return this.outcomeIndicatorId; }
			set { this.outcomeIndicatorId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OutcomeSubIndicatorId
		{
			get { return this.outcomeSubIndicatorId; }
			set { this.outcomeSubIndicatorId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int outcomeIndicatorSubIndicatorId)
		{
			return base.Load(outcomeIndicatorSubIndicatorId);
		}

		/// <summary>
		/// Parent OutcomeIndicatorSubIndicatorCollection that contains this element
		/// </summary>
		public OutcomeIndicatorSubIndicatorCollection ParentOutcomeIndicatorSubIndicatorCollection
		{
			get
			{
				return this.parentOutcomeIndicatorSubIndicatorCollection;
			}
			set
			{
				this.parentOutcomeIndicatorSubIndicatorCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of OutcomeIndicatorSubIndicator objects
	/// </summary>
	[ElementType(typeof(OutcomeIndicatorSubIndicator))]
	public class OutcomeIndicatorSubIndicatorCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OutcomeIndicatorSubIndicator elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOutcomeIndicatorSubIndicatorCollection = this;
			else
				elem.ParentOutcomeIndicatorSubIndicatorCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OutcomeIndicatorSubIndicator elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OutcomeIndicatorSubIndicator this[int index]
		{
			get
			{
				return (OutcomeIndicatorSubIndicator)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OutcomeIndicatorSubIndicator)oldValue, false);
			SetParentOnElem((OutcomeIndicatorSubIndicator)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}
}
