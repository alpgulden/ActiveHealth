using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ClinicalReviewDecisionType]
	/// </summary>
	[SPAutoGen("usp_GetClinicalReviewDecisionTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetClinicalReviewDecisionTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertClinicalReviewDecisionType")]
	[SPUpdate("usp_UpdateClinicalReviewDecisionType")]
	[SPDelete("usp_DeleteClinicalReviewDecisionType")]
	[SPLoad("usp_LoadClinicalReviewDecisionType")]
	[TableMapping("ClinicalReviewDecisionType","clinicalReviewDecisionTypeID")]
	public class ClinicalReviewDecisionType : BaseLookupStandard
	{
		[NonSerialized]
		private ClinicalReviewDecisionTypeCollection parentClinicalReviewDecisionTypeCollection;
		[ColumnMapping("ClinicalReviewDecisionTypeID",StereoType=DataStereoType.FK)]
		private int clinicalReviewDecisionTypeID;
		[ColumnMapping("ClinicalReviewDecisionTypeCodeID")]
		private int clinicalReviewDecisionTypeCodeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public ClinicalReviewDecisionType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ClinicalReviewDecisionType(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ClinicalReviewDecisionTypeID
		{
			get { return this.clinicalReviewDecisionTypeID; }
			set { this.clinicalReviewDecisionTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ClinicalReviewDecisionTypeCodeID
		{
			get { return this.clinicalReviewDecisionTypeCodeID; }
			set { this.clinicalReviewDecisionTypeCodeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int clinicalReviewDecisionTypeID)
		{
			return base.Load(clinicalReviewDecisionTypeID);
		}

		/// <summary>
		/// Parent ClinicalReviewDecisionTypeCollection that contains this element
		/// </summary>
		public ClinicalReviewDecisionTypeCollection ParentClinicalReviewDecisionTypeCollection
		{
			get
			{
				return this.parentClinicalReviewDecisionTypeCollection;
			}
			set
			{
				this.parentClinicalReviewDecisionTypeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ClinicalReviewDecisionType objects
	/// </summary>
	[ElementType(typeof(ClinicalReviewDecisionType))]
	public class ClinicalReviewDecisionTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClinicalReviewDecisionType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClinicalReviewDecisionTypeCollection = this;
			else
				elem.ParentClinicalReviewDecisionTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClinicalReviewDecisionType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClinicalReviewDecisionType this[int index]
		{
			get
			{
				return (ClinicalReviewDecisionType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClinicalReviewDecisionType)oldValue, false);
			SetParentOnElem((ClinicalReviewDecisionType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadClinicalReviewDecisionTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetClinicalReviewDecisionTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ClinicalReviewDecisionTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ClinicalReviewDecisionTypeCollection ActiveClinicalReviewDecisionTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ClinicalReviewDecisionTypeCollection col = (ClinicalReviewDecisionTypeCollection)NSGlobal.EnsureCachedObject("ActiveClinicalReviewDecisionTypes", typeof(ClinicalReviewDecisionTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadClinicalReviewDecisionTypesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
