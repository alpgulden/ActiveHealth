using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Problem]
	/// 
	/// The problem object saves itself only in the context of a patient.
	/// When it's saved it also creates the Patient-Problem link.
	/// 
	/// Problems form the nucleus of the Active Advice health management system. 
	/// A Problem is always associated with a Patient and reflects a health issue that 
	/// the Patient is experiencing. Not all Problems represent a deficit in Patient health, 
	/// a Patient�s Problem may be �wellness�, in which case the system is providing the service 
	/// of monitoring a patient�s health and taking proactive steps in increasing a patient�s well being.
	/// 
	/// Health care events (such as inpatient hospitalization, outpatient surgery, home care, and 
	/// provision of DME) and referrals are linked to Problems.
	/// 
	/// Problems can be created manually by the user, in response to data received from external sources 
	/// (i.e ICM scoring load) or as a response to a Resolution selection in Intake.
	/// 
    /// </summary>
	[SPAutoGen("usp_GetLinkedPatientProblemsByDescID","SelectRelatedFromLinkedTableWithFilter.sptpl","PatientProblem, problemId, patientId, problemDescriptionID")]
	[SPAutoGen("usp_GetLinkedReferralProblems","SelectRelatedFromLinkedTable.sptpl","ProblemReferral, problemId, referralId")]
	[SPAutoGen("usp_GetLinkedCMSProblems","SelectRelatedFromLinkedTable.sptpl","CMSProblem, problemId, cMSId")]
	[SPAutoGen("usp_GetLinkedPatientProblem","SelectRelatedFromLinkedTableWithFilter.sptpl","PatientProblem, problemId, patientId, problemID")]
	[SPAutoGen("usp_GetLinkedPatientProblems","SelectRelatedFromLinkedTable.sptpl","PatientProblem, problemId, patientId")]
	[SPInsert("usp_InsertProblem")]
	[SPUpdate("usp_UpdateProblem")]
	[SPDelete("usp_DeleteProblem")]
	[SPLoad("usp_LoadProblem")]
	[TableMapping("Problem","problemID")]
	public class Problem : BaseDataWithUserDefined
	{
		[NonSerialized]
		private ProblemCollection parentProblemCollection;
		[ColumnMapping("ProblemID",StereoType=DataStereoType.FK)]
		private int problemID;
		[ColumnMapping("AssignedUserID",StereoType=DataStereoType.FK)]
		private int assignedUserID;
		[ColumnMapping("AssignedTeamID",StereoType=DataStereoType.FK)]
		private int assignedTeamID;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("ProblemStatusID",StereoType=DataStereoType.FK)]
		private int problemStatusID;
		[ColumnMapping("DiagnosticCode")]
		private string diagnosticCode;
		[ColumnMapping("DxType")]
		private string dxType;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("DSM4axis",StereoType=DataStereoType.FK)]
		private int dSM4axis;
		[ColumnMapping("StatusChangeTime")]
		private DateTime statusChangeTime;
		[ColumnMapping("StatusChangedBy",StereoType=DataStereoType.FK)]
		private int statusChangedBy;
		[ColumnMapping("OtherPlanDescription")]
		private string otherPlanDescription;
		[ColumnMapping("ProblemDescription")]
		private string problemDescription;
		[ColumnMapping("ProblemDescriptionID",StereoType=DataStereoType.FK)]
		private int problemDescriptionID;
		[ColumnMapping("PatientSubscriberLogID",StereoType=DataStereoType.FK)]
		private int patientSubscriberLogID;
		[ColumnMapping("PlanSORGLogID",StereoType=DataStereoType.FK)]
		private int planSORGLogID;
		[ColumnMapping("ProviderID",StereoType=DataStereoType.FK)]
		private int providerID;
		[ColumnMapping("ProviderNetworkID",StereoType=DataStereoType.FK)]
		private int providerNetworkID;
		[ColumnMapping("ProviderSpecialtyID",StereoType=DataStereoType.FK)]
		private int providerSpecialtyID;
		[ColumnMapping("ProviderLocationID",StereoType=DataStereoType.FK)]
		private int providerLocationID;
		[ColumnMapping("ProviderNetworkStatus",StereoType=DataStereoType.FK)]
		private int providerNetworkStatus;
		[ColumnMapping("ProviderGroupID",StereoType=DataStereoType.FK)]
		private int providerGroupID;
		[ColumnMapping("ProviderGroupTypeID",StereoType=DataStereoType.FK)]
		private int providerGroupTypeID;
		[ColumnMapping("ProviderGroupLocationID",StereoType=DataStereoType.FK)]
		private int providerGroupLocationID;
		[ColumnMapping("ProviderGroupNetworkID",StereoType=DataStereoType.FK)]
		private int providerGroupNetworkID;
		[ColumnMapping("ProviderGroupNetworkStatus",StereoType=DataStereoType.FK)]
		private int providerGroupNetworkStatus;
		
		private PatientProblemCollection patients;
		// Assuming a problem can be linked to a single patient
		private Patient patient;
		private PatientSubscriberLog patSubLog;	// cached patsub log object which
		private PlanSORGLog planSorgLog;	// cached plansorg log object which
		private ProblemEventCollection problemEvents;
		private CMSProblemCollection problemCMSes;
		private ProblemReferralCollection problemReferrals;
		//private PatientCoverage patCov;		// the selected patient-coverage of this patient
		private bool isERCLinked; // true if Even/Referral/CMS is linked with this problem
		private bool isPrimary;   // true if this problem is Primary in the context of Even/Referral/CMS

		public Problem()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Problem(Patient patient) // PatientCoverage patCov)
		{
			if (patient == null)
				throw new Exception("A problem can be created in the context of a patient");
			//if (patCov == null)
				//throw new Exception("A problem can be created in the context of a patient-subscriber-coverage");
			this.NewRecord();
			this.patient = patient;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ProblemID
		{
			get { return this.problemID; }
			set { this.problemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedUserID
		{
			get { return this.assignedUserID; }
			set { this.assignedUserID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedTeamID
		{
			get { return this.assignedTeamID; }
			set { this.assignedTeamID = value; }
		}

		public string AssignedTeamAndUserDisplay
		{
			get { return FormatTeamAndUserForDisplay( this.assignedTeamID, this.assignedUserID); }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[FieldValuesMember("LookupOf_ProblemStatusID", "StatusId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int ProblemStatusID
		{
			get { return this.problemStatusID; }
			set { this.problemStatusID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=16)]
		public string DiagnosticCode
		{
			get { return this.diagnosticCode; }
			set { this.diagnosticCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DxType
		{
			get { return this.dxType; }
			set { this.dxType = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@LINKED@")]
		public bool IsERCLinked
		{
			get { return this.isERCLinked; }
			set { this.isERCLinked = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@PRIMARYPROBLEMID@")]
		public bool IsPrimary
		{
			get { return this.isPrimary; }
			set { this.isPrimary = value; }
		}

		/*/// <summary>
		/// This property helps representing the dxType, diagId, dsm4axis values at the client
		/// and mapping them back to members.  In the client, there's going to be a single hidden
		/// textbox for it, and a description textbox.
		/// </summary>
		public string DiagnosticComposite
		{
			get { return this.MakeCompositeDiagnosticIdentifier(this.dxType, this.diagnosticID, this.dSM4axis); }
			set { this.ParseCompositeDiagnosticIdentifier(value, ref this.dxType, ref this.diagnosticID, ref this.dSM4axis); }
		}*/

		/// <summary>
		/// This property helps representing the dxType and diagId for display.
		/// </summary>
		public string DiagnosticDisplay
		{
			get { return this.FormatDiagnosticCodeForDisplay(this.dxType, this.diagnosticCode); }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DSM4axis
		{
			get { return this.dSM4axis; }
			set { this.dSM4axis = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string OtherPlanDescription
		{
			get { return this.otherPlanDescription; }
			set { this.otherPlanDescription = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string ProblemDescription
		{
			get { return this.problemDescription; }
			set { this.problemDescription = value; }
		}

		[FieldValuesMember("LookupOf_ProblemDescriptionID", "CodeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int ProblemDescriptionID
		{
			get { return this.problemDescriptionID; }
			set { this.problemDescriptionID = value; }
		}

		/// <summary>
		/// Display problem id or the problem desc, whichever exists.
		/// </summary>
		[FieldDescription("@PROBLEMDESCRIPTION@")]
		public string ProblemDescriptionToDisplay
		{
			get 
			{ 
				if (this.problemDescription != null)
					return this.problemDescription;
				else
					return this.Fmt_ProblemDescriptionID;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PatientSubscriberLogID
		{
			get { return this.patientSubscriberLogID; }
			set { this.patientSubscriberLogID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PlanSORGLogID
		{
			get { return this.planSORGLogID; }
			set { this.planSORGLogID = value; }
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			if (this.IsNew)
				throw new Exception("You must pass a patient-subscriber-coverage to save a new Problem");
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// This method must be used only when the problem is new and so it must 
		/// be created in the context of a patient-coverage.
		/// </summary>
		/// <param name="patCov"></param>
		public void Save(PatientCoverage patCov)
		{
			if (!this.IsNew || patCov == null)
				throw new Exception("A new problem can be saved in the context of a patient-coverage");

			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				// Link the problem to the last log entries (PlanSORGLog, PatientSubscriberLog)

				PlanSORGLog lastPlanSORGLog = PlanSORGLog.GetLastPlanSORGLogEntry(patCov.Plan, patCov.SORG);
				if (lastPlanSORGLog == null)
					throw new ActiveAdviceException( AAExceptionAction.DisableUI,
						"No plan-sorg-log entry found for PlanID={0}, SORGID={1}", patCov.PlanID, patCov.SORGID);
				this.planSORGLogID = lastPlanSORGLog.PlanSorgLogId;

				PatientSubscriberLog lastPatSubLog = PatientSubscriberLog.GetLastPatientSubscriberLogEntry(this.SqlData.Transaction, this.patient, patCov);
				if (lastPatSubLog == null)
					throw new ActiveAdviceException(AAExceptionAction.DisableUI,
						"No patient-subscriber-log entry found for PatientID={0}, PatientCoverageID={1}", patient.PatientId, patCov.PatientCoverageID);
				this.patientSubscriberLogID = lastPatSubLog.PatientSubscriberLogId;

				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int problemID)
		{
			return base.Load(problemID);
		}

		/// <summary>
		/// Load the given patient's, given problem
		/// </summary>
		public bool Load(int patientID, int problemID)
		{
			return SqlData.SPExecReadObj("usp_GetLinkedPatientProblem", this, false, patientID, problemID);
		}

		/// <summary>
		/// Loads the problem for a specific patient
		/// </summary>
		public bool Load(Patient patient, int problemID)
		{
			this.patient = patient;
			if (this.patient != null)
				return Load(this.patient.PatientId, problemID);	// load patient's problem
			else
				return Load(problemID);	// access the problem with its id directly
		}

		/// <summary>
		/// Parent ProblemCollection that contains this element
		/// </summary>
		public ProblemCollection ParentProblemCollection
		{
			get
			{
				return this.parentProblemCollection;
			}
			set
			{
				this.parentProblemCollection = value; // parent is set when added to a collection
			}
		}

		public ProblemDescriptionCollection LookupOf_ProblemDescriptionID
		{
			get
			{
				return ProblemDescriptionCollection.ActiveProblemDescriptions; // Acquire a shared instance from the static member of collection
			}
		}

		public string Fmt_ProblemDescriptionID
		{
			get { return ProblemDescriptionCollection.ActiveProblemDescriptions.Lookup_DescriptionByCodeId(this.problemDescriptionID); }
		}

		public SystemStatusCollection LookupOf_ProblemStatusID
		{
			get
			{
				return SystemStatusCollection.ActiveSystemStatuses; // Acquire a shared instance from the static member of collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StatusChangeTime
		{
			get { return this.statusChangeTime; }
			set { this.statusChangeTime = value; }
		}

		/// <summary>
		/// String to be displayed for status changed date and user.
		/// </summary>
		public string StatusChangedDisplay
		{
			get { return this.FormatStatusChangeForDisplay(this.statusChangeTime, this.statusChangedBy); }
		}

		/// <summary>
		/// Child Patients mapped to related rows of table PatientProblem where [ProblemID] = [ProblemId]
		/// </summary>
		[SPLoadChild("usp_LoadProblemPatients", "problemId")]
		private PatientProblemCollection Patients
		{
			get { return this.patients; }
			set
			{
				this.patients = value;
				if (value != null)
					value.ParentProblem = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Patients collection
		/// </summary>
		private void LoadPatients(bool forceReload)
		{
			this.patients = (PatientProblemCollection)PatientProblemCollection.LoadChildCollection("Patients", this, typeof(PatientProblemCollection), patients, forceReload, null);
		}

		/// <summary>
		/// Saves the Patients collection
		/// </summary>
		private void SavePatients()
		{
			PatientProblemCollection.SaveChildCollection(this.patients, true);
		}

		/// <summary>
		/// Synchronizes the Patients collection
		/// </summary>
		private void SynchronizePatients()
		{
			PatientProblemCollection.SynchronizeChildCollection(this.patients, true);
		}

		public PatientProblem PatientProblem
		{
			get
			{
				LoadPatients(false);
				if (this.patients.Count > 0)
				{
					if (this.patients.Count > 1)
						throw new Exception(
							String.Format("This problem is linked to more than one patient! (ProblemID={0})", this.problemDescriptionID));
					return this.patients[0];
				}

				return null;		// no patient-problem link
			}
		}

		/// <summary>
		/// Return the linked patient.  This problem must be linked to a single patient only.
		/// If there are more than 1 patients linked, this is an invalid case, and this
		/// property will throw an exception.
		/// </summary>
		public Patient Patient
		{
			get
			{
				// The patient was either given at the construction of this problem as a new problem
				// or loaded from the db.
				if (this.patient == null)
				{
					PatientProblem patProb = this.PatientProblem;
					if (patProb != null)
						this.patient = patProb.Patient;
				}
				return this.patient;
			}
			set
			{
				if (this.patient != null)
					throw new Exception("An existing link to a patient can't be changed on the Problem object");
				this.patient = value;
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();

			if (this.IsNew || this.IsNewlyInsertedInDB)
			{
				// create a Patient-problem link
				PatientProblem patProblem = new PatientProblem(this.patient, this);
				patProblem.SqlData.Transaction = this.SqlData.Transaction;
				patProblem.Save();
			}

			// Save the child collections here.
		}

		/// <summary>
		/// Child ProblemEvents mapped to related rows of table ProblemEvent where [ProblemID] = [ProblemId]
		/// </summary>
		[SPLoadChild("usp_LoadProblemEvents", "problemId")]
		public ProblemEventCollection ProblemEvents
		{
			get { return this.problemEvents; }
			set
			{
				this.problemEvents = value;
				if (value != null)
					value.ParentProblem = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ProblemEvents collection
		/// </summary>
		public void LoadProblemEvents(bool forceReload)
		{
			this.problemEvents = (ProblemEventCollection)ProblemEventCollection.LoadChildCollection("ProblemEvents", this, typeof(ProblemEventCollection), problemEvents, forceReload, null);
		}

		/// <summary>
		/// Saves the ProblemEvents collection
		/// </summary>
		public void SaveProblemEvents()
		{
			ProblemEventCollection.SaveChildCollection(this.problemEvents, true);
		}

		/// <summary>
		/// Synchronizes the ProblemEvents collection
		/// </summary>
		public void SynchronizeProblemEvents()
		{
			ProblemEventCollection.SynchronizeChildCollection(this.problemEvents, true);
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFieldOnNewLine(this, "ProblemDescriptionToDisplay", "@PROBLEM@");
			}
		}

		/// <summary>
		/// Child ProblemCMSes mapped to related rows of table CMSProblem where [ProblemID] = [ProblemId]
		/// </summary>
		[SPLoadChild("usp_LoadProblemCMSes", "problemId")]
		public CMSProblemCollection ProblemCMSes
		{
			get { return this.problemCMSes; }
			set
			{
				this.problemCMSes = value;
				if (value != null)
					value.ParentProblem = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ProblemCMSes collection
		/// </summary>
		public void LoadProblemCMSes(bool forceReload)
		{
			this.problemCMSes = (CMSProblemCollection)CMSProblemCollection.LoadChildCollection("ProblemCMSes", this, typeof(CMSProblemCollection), problemCMSes, forceReload, null);
		}

		/// <summary>
		/// Saves the ProblemCMSes collection
		/// </summary>
		public void SaveProblemCMSes()
		{
			CMSProblemCollection.SaveChildCollection(this.problemCMSes, true);
		}

		/// <summary>
		/// Synchronizes the ProblemCMSes collection
		/// </summary>
		public void SynchronizeProblemCMSes()
		{
			CMSProblemCollection.SynchronizeChildCollection(this.problemCMSes, true);
		}

		/// <summary>
		/// Child ProblemReferrals mapped to related rows of table ProblemReferral where [ProblemID] = [ProblemId]
		/// </summary>
		[SPLoadChild("usp_LoadProblemReferrals", "problemId")]
		public ProblemReferralCollection ProblemReferrals
		{
			get { return this.problemReferrals; }
			set
			{
				this.problemReferrals = value;
				if (value != null)
					value.ParentProblem = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ProblemReferrals collection
		/// </summary>
		public void LoadProblemReferrals(bool forceReload)
		{
			this.problemReferrals = (ProblemReferralCollection)ProblemReferralCollection.LoadChildCollection("ProblemReferrals", this, typeof(ProblemReferralCollection), problemReferrals, forceReload, null);
		}

		/// <summary>
		/// Saves the ProblemReferrals collection
		/// </summary>
		public void SaveProblemReferrals()
		{
			ProblemReferralCollection.SaveChildCollection(this.problemReferrals, true);
		}

		/// <summary>
		/// Synchronizes the ProblemReferrals collection
		/// </summary>
		public void SynchronizeProblemReferrals()
		{
			ProblemReferralCollection.SynchronizeChildCollection(this.problemReferrals, true);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.startDate = DateTime.Today;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderID
		{
			get { return this.providerID; }
			set { this.providerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderNetworkID
		{
			get { return this.providerNetworkID; }
			set { this.providerNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderSpecialtyID
		{
			get { return this.providerSpecialtyID; }
			set { this.providerSpecialtyID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderLocationID
		{
			get { return this.providerLocationID; }
			set { this.providerLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderNetworkStatus
		{
			get { return this.providerNetworkStatus; }
			set { this.providerNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderGroupID
		{
			get { return this.providerGroupID; }
			set { this.providerGroupID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderGroupTypeID
		{
			get { return this.providerGroupTypeID; }
			set { this.providerGroupTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderGroupLocationID
		{
			get { return this.providerGroupLocationID; }
			set { this.providerGroupLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderGroupNetworkID
		{
			get { return this.providerGroupNetworkID; }
			set { this.providerGroupNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProviderGroupNetworkStatus
		{
			get { return this.providerGroupNetworkStatus; }
			set { this.providerGroupNetworkStatus = value;}
		}

		/// <summary>
		/// Loads and retuns the linked patient subscriber log entry
		/// </summary>
		/// <returns></returns>
		public PatientSubscriberLog GetPatientSubscriberLog()
		{
			if (this.patientSubscriberLogID == 0)
				return null;
			PatientSubscriberLog patSubLog = new PatientSubscriberLog();
			if (patSubLog.Load(this.patientSubscriberLogID))
				return patSubLog;
			else
				return null;
		}

		/// <summary>
		/// Returns the loaded and cached patient subscriber log entry
		/// </summary>
		public PatientSubscriberLog PatientSubscriberLog
		{
			get
			{
				if (this.patSubLog == null)
					this.patSubLog = GetPatientSubscriberLog();
				return this.patSubLog;
			}
		}

		/// <summary>
		/// Returns the loaded and cached plan sorg log entry
		/// </summary>
		public PlanSORGLog PlanSORGLog
		{
			get
			{
				if (this.planSorgLog == null)
					this.planSorgLog = GetPlanSorgLog();
				return this.planSorgLog;
			}
		}

		/// <summary>
		/// Loads and retuns the linked plan sorg log entry
		/// </summary>
		/// <returns></returns>
		public PlanSORGLog GetPlanSorgLog()
		{
			if (this.planSORGLogID == 0)
				return null;
			PlanSORGLog planSorgLog = new PlanSORGLog();
			if (planSorgLog.Load(this.planSORGLogID))
				return planSorgLog;
			else
				return null;
		}
	}

	/// <summary>
	/// Strongly typed collection of Problem objects
	/// </summary>
	[ElementType(typeof(Problem))]
	public class ProblemCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Problem elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentProblemCollection = this;
			else
				elem.ParentProblemCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Problem elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Problem this[int index]
		{
			get
			{
				return (Problem)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Problem)oldValue, false);
			SetParentOnElem((Problem)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPatientProblems(int maxRecords, int patientId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetLinkedPatientProblems", maxRecords, this, false, patientId);
		}

		public int LoadLinkedPatientProblems(Patient patient)
		{
			if (patient == null)
				throw new Exception("No patient was specified to LoadPatientProblems");

			if (patient.IsNew)
			{
				this.Clear();
				return 0;
			}

			int count = LoadPatientProblems(-1, patient.PatientId);
			for (int i = 0; i < this.Count; i++)
			{
				this[i].Patient = patient;
			}
			return count;
		}

		/// <summary>
		/// Load a problems of a patient with the given DescID
		/// </summary>
		public int LoadLinkedPatientProblemsByDescID(Patient patient, int problemDescriptionID)
		{
			this.Clear();
			int count = SqlData.SPExecReadCol("usp_GetLinkedPatientProblemsByDescID", -1, this, false, 
				new object[] { patient.PatientId, problemDescriptionID });
			foreach (Problem p in this)
				p.Patient = patient;
			return count;
		}

	}
}
