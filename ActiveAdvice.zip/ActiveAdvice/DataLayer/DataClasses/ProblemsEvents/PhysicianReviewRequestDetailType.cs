using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianReviewRequestDetailType]
	/// </summary>
	[SPAutoGen("usp_GetPhysicianReviewRequestDetailTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetPhysicianReviewRequestDetailTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertPhysicianReviewRequestDetailType")]
	[SPUpdate("usp_UpdatePhysicianReviewRequestDetailType")]
	[SPDelete("usp_DeletePhysicianReviewRequestDetailType")]
	[SPLoad("usp_LoadPhysicianReviewRequestDetailType")]
	[TableMapping("PhysicianReviewRequestDetailType","physicianReviewRequestDetailTypeID")]
	public class PhysicianReviewRequestDetailType : BaseLookupStandard
	{
		[NonSerialized]
		private PhysicianReviewRequestDetailTypeCollection parentPhysicianReviewRequestDetailTypeCollection;
		[ColumnMapping("PhysicianReviewRequestDetailTypeID",StereoType=DataStereoType.FK)]
		private int physicianReviewRequestDetailTypeID;
		[ColumnMapping("IsAppealRequest")]
		private bool isAppealRequest;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public PhysicianReviewRequestDetailType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianReviewRequestDetailType(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PhysicianReviewRequestDetailTypeID
		{
			get { return this.physicianReviewRequestDetailTypeID; }
			set { this.physicianReviewRequestDetailTypeID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IsAppealRequest
		{
			get { return this.isAppealRequest; }
			set { this.isAppealRequest = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int physicianReviewRequestDetailTypeID)
		{
			return base.Load(physicianReviewRequestDetailTypeID);
		}

		/// <summary>
		/// Parent PhysicianReviewRequestDetailTypeCollection that contains this element
		/// </summary>
		public PhysicianReviewRequestDetailTypeCollection ParentPhysicianReviewRequestDetailTypeCollection
		{
			get
			{
				return this.parentPhysicianReviewRequestDetailTypeCollection;
			}
			set
			{
				this.parentPhysicianReviewRequestDetailTypeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PhysicianReviewRequestDetailType objects
	/// </summary>
	[ElementType(typeof(PhysicianReviewRequestDetailType))]
	public class PhysicianReviewRequestDetailTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianReviewRequestDetailType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianReviewRequestDetailTypeCollection = this;
			else
				elem.ParentPhysicianReviewRequestDetailTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianReviewRequestDetailType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianReviewRequestDetailType this[int index]
		{
			get
			{
				return (PhysicianReviewRequestDetailType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianReviewRequestDetailType)oldValue, false);
			SetParentOnElem((PhysicianReviewRequestDetailType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPhysicianReviewRequestDetailTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetPhysicianReviewRequestDetailTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared PhysicianReviewRequestDetailTypeCollection which is cached in NSGlobal
		/// </summary>
		public static PhysicianReviewRequestDetailTypeCollection ActivePhysicianReviewRequestDetailTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PhysicianReviewRequestDetailTypeCollection col = (PhysicianReviewRequestDetailTypeCollection)NSGlobal.EnsureCachedObject("ActivePhysicianReviewRequestDetailTypes", typeof(PhysicianReviewRequestDetailTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadPhysicianReviewRequestDetailTypesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
