using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OutcomeCode]
	/// </summary>
	[SPAutoGen("usp_GetOutcomeCodes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetOutcomeCodesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertOutcomeCode")]
	[SPUpdate("usp_UpdateOutcomeCode")]
	[SPDelete("usp_DeleteOutcomeCode")]
	[SPLoad("usp_LoadOutcomeCode")]
	[TableMapping("OutcomeCode","outcomeCodeID")]
	public class OutcomeCode : BaseLookupStandard
	{
		[NonSerialized]
		private OutcomeCodeCollection parentOutcomeCodeCollection;
		[ColumnMapping("OutcomeCodeID",StereoType=DataStereoType.FK)]
		private int outcomeCodeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public OutcomeCode()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public OutcomeCode(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int OutcomeCodeID
		{
			get { return this.outcomeCodeID; }
			set { this.outcomeCodeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int outcomeCodeID)
		{
			return base.Load(outcomeCodeID);
		}

		/// <summary>
		/// Parent OutcomeCodeCollection that contains this element
		/// </summary>
		public OutcomeCodeCollection ParentOutcomeCodeCollection
		{
			get
			{
				return this.parentOutcomeCodeCollection;
			}
			set
			{
				this.parentOutcomeCodeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of OutcomeCode objects
	/// </summary>
	[ElementType(typeof(OutcomeCode))]
	public class OutcomeCodeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OutcomeCode elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOutcomeCodeCollection = this;
			else
				elem.ParentOutcomeCodeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OutcomeCode elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OutcomeCode this[int index]
		{
			get
			{
				return (OutcomeCode)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OutcomeCode)oldValue, false);
			SetParentOnElem((OutcomeCode)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadOutcomeCodesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOutcomeCodesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared OutcomeCodeCollection which is cached in NSGlobal
		/// </summary>
		public static OutcomeCodeCollection ActiveOutcomeCodes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				OutcomeCodeCollection col = (OutcomeCodeCollection)NSGlobal.EnsureCachedObject("ActiveOutcomeCodes", typeof(OutcomeCodeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadOutcomeCodesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
