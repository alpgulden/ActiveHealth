using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ClinicalReviewType]
	/// </summary>
	[SPAutoGen("usp_GetClinicalReviewTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetClinicalReviewTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertClinicalReviewType")]
	[SPUpdate("usp_UpdateClinicalReviewType")]
	[SPDelete("usp_DeleteClinicalReviewType")]
	[SPLoad("usp_LoadClinicalReviewType")]
	[TableMapping("ClinicalReviewType","clinicalReviewTypeID")]
	public class ClinicalReviewType : BaseLookupStandard
	{
		[NonSerialized]
		private ClinicalReviewTypeCollection parentClinicalReviewTypeCollection;
		[ColumnMapping("ClinicalReviewTypeID",StereoType=DataStereoType.FK)]
		private int clinicalReviewTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
	
		public ClinicalReviewType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ClinicalReviewType(string code, string description)
		{
			this.NewRecord(); // initialize record state
			this.code = code;
			this.description = description;
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ClinicalReviewTypeID
		{
			get { return this.clinicalReviewTypeID; }
			set { this.clinicalReviewTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int clinicalReviewTypeID)
		{
			return base.Load(clinicalReviewTypeID);
		}

		/// <summary>
		/// Parent ClinicalReviewTypeCollection that contains this element
		/// </summary>
		public ClinicalReviewTypeCollection ParentClinicalReviewTypeCollection
		{
			get
			{
				return this.parentClinicalReviewTypeCollection;
			}
			set
			{
				this.parentClinicalReviewTypeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ClinicalReviewType objects
	/// </summary>
	[ElementType(typeof(ClinicalReviewType))]
	public class ClinicalReviewTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClinicalReviewType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClinicalReviewTypeCollection = this;
			else
				elem.ParentClinicalReviewTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClinicalReviewType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClinicalReviewType this[int index]
		{
			get
			{
				return (ClinicalReviewType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClinicalReviewType)oldValue, false);
			SetParentOnElem((ClinicalReviewType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadClinicalReviewTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetClinicalReviewTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared ClinicalReviewTypeCollection which is cached in NSGlobal
		/// </summary>
		public static ClinicalReviewTypeCollection ActiveClinicalReviewTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ClinicalReviewTypeCollection col = (ClinicalReviewTypeCollection)NSGlobal.EnsureCachedObject("ActiveClinicalReviewTypes", typeof(ClinicalReviewTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadClinicalReviewTypesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
