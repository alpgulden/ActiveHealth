using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PhysicianRequest]
	/// </summary>
	[SPInsert("usp_InsertPhysicianRequest")]
	[SPUpdate("usp_UpdatePhysicianRequest")]
	[SPDelete("usp_DeletePhysicianRequest")]
	[SPLoad("usp_LoadPhysicianRequest")]
	[TableMapping("PhysicianRequest","physicianRequestID")]
	public class PhysicianRequest : BaseDataWithUserDefined
	{
		[NonSerialized]
		private PhysicianRequestCollection parentPhysicianRequestCollection;
		[ColumnMapping("PhysicianRequestID",StereoType=DataStereoType.FK)]
		private int physicianRequestID;
		[ColumnMapping("PhysicianReviewID",StereoType=DataStereoType.FK)]
		private int physicianReviewID;
		[ColumnMapping("PhysicianReviewRequestDetailTypeID",StereoType=DataStereoType.FK)]			// lookup
		private int physicianReviewRequestDetailTypeID;
		[ColumnMapping("PhysicianReviewDecisionID",StereoType=DataStereoType.FK)]					// lookup
		private int physicianReviewDecisionID;
		[ColumnMapping("AuthFormReceivedDate")]
		private DateTime authFormReceivedDate;
		[ColumnMapping("MedRecordReleaseSentDate")]
		private DateTime medRecordReleaseSentDate;
		[ColumnMapping("MedRecordReceivedDate")]
		private DateTime medRecordReceivedDate;
		[ColumnMapping("AppealRequestedByTypeID",StereoType=DataStereoType.FK)]					// lookup
		private int appealRequestedByTypeID;
		[ColumnMapping("AppealStartDate")]
		private DateTime appealStartDate;
		[ColumnMapping("AppealEndDate")]
		private DateTime appealEndDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		private PhysicianDecisionCollection physicianDecisions;
	
		public PhysicianRequest()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PhysicianRequest(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@REQUESTID@")]
		public int PhysicianRequestID
		{
			get { return this.physicianRequestID; }
			set { this.physicianRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PhysicianReviewID
		{
			get { return this.physicianReviewID; }
			set { this.physicianReviewID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewRequestDetailTypeID", "PhysicianReviewRequestDetailTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@REQUESTTYPE@")]
		public int PhysicianReviewRequestDetailTypeID
		{
			get { return this.physicianReviewRequestDetailTypeID; }
			set { this.physicianReviewRequestDetailTypeID = value; }
		}

		[FieldValuesMember("LookupOf_PhysicianReviewDecisionID", "PhysicianReviewDecisionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@DECISION@")]
		public int PhysicianReviewDecisionID
		{
			get { return this.physicianReviewDecisionID; }
			set { this.physicianReviewDecisionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AuthFormReceivedDate
		{
			get { return this.authFormReceivedDate; }
			set { this.authFormReceivedDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MedRecordReleaseSentDate
		{
			get { return this.medRecordReleaseSentDate; }
			set { this.medRecordReleaseSentDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MedRecordReceivedDate
		{
			get { return this.medRecordReceivedDate; }
			set { this.medRecordReceivedDate = value; }
		}

		[FieldValuesMember("LookupOf_AppealRequestedByTypeID", "PhysicianReviewAppealRequestByTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@REQUESTEDBY@")]
		public int AppealRequestedByTypeID
		{
			get { return this.appealRequestedByTypeID; }
			set { this.appealRequestedByTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime AppealStartDate
		{
			get { return this.appealStartDate; }
			set { this.appealStartDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AppealEndDate
		{
			get { return this.appealEndDate; }
			set { this.appealEndDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int physicianRequestID)
		{
			return base.Load(physicianRequestID);
		}

		/// <summary>
		/// Parent PhysicianRequestCollection that contains this element
		/// </summary>
		public PhysicianRequestCollection ParentPhysicianRequestCollection
		{
			get
			{
				return this.parentPhysicianRequestCollection;
			}
			set
			{
				this.parentPhysicianRequestCollection = value; // parent is set when added to a collection
			}
		}

		public PhysicianReviewRequestDetailTypeCollection LookupOf_PhysicianReviewRequestDetailTypeID
		{
			get
			{
				return PhysicianReviewRequestDetailTypeCollection.ActivePhysicianReviewRequestDetailTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewDecisionCollection LookupOf_PhysicianReviewDecisionID
		{
			get
			{
				return PhysicianReviewDecisionCollection.ActivePhysicianReviewDecisions; // Acquire a shared instance from the static member of collection
			}
		}

		public PhysicianReviewAppealRequestByTypeCollection LookupOf_AppealRequestedByTypeID
		{
			get
			{
				return PhysicianReviewAppealRequestByTypeCollection.ActivePhysicianReviewAppealRequestByTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Child PhysicianDecisions mapped to related rows of table PhysicianDecision where [PhysicianRequestID] = [PhysicianRequestID]
		/// </summary>
		[SPLoadChild("usp_LoadPhysicianReviewDecisions", "physicianRequestID")]
		public PhysicianDecisionCollection PhysicianDecisions
		{
			get { return this.physicianDecisions; }
			set
			{
				this.physicianDecisions = value;
				if (value != null)
					value.ParentPhysicianRequest = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PhysicianDecisions collection
		/// </summary>
		public void LoadPhysicianDecisions(bool forceReload)
		{
			this.physicianDecisions = (PhysicianDecisionCollection)PhysicianDecisionCollection.LoadChildCollection("PhysicianDecisions", this, typeof(PhysicianDecisionCollection), physicianDecisions, forceReload, null);
		}

		/// <summary>
		/// Saves the PhysicianDecisions collection
		/// </summary>
		public void SavePhysicianDecisions()
		{
			PhysicianDecisionCollection.SaveChildCollection(this.physicianDecisions, true);
		}

		/// <summary>
		/// Synchronizes the PhysicianDecisions collection
		/// </summary>
		public void SynchronizePhysicianDecisions()
		{
			PhysicianDecisionCollection.SynchronizeChildCollection(this.physicianDecisions, true);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.

			// save child tables that are managed in-memory
			this.SavePhysicianDecisions();
		}
	}

	/// <summary>
	/// Strongly typed collection of PhysicianRequest objects
	/// </summary>
	[ElementType(typeof(PhysicianRequest))]
	public class PhysicianRequestCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PhysicianRequest elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPhysicianRequestCollection = this;
			else
				elem.ParentPhysicianRequestCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PhysicianRequest elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PhysicianRequest this[int index]
		{
			get
			{
				return (PhysicianRequest)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PhysicianRequest)oldValue, false);
			SetParentOnElem((PhysicianRequest)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent PhysicianReview that contains this collection
		/// </summary>
		public PhysicianReview ParentPhysicianReview
		{
			get { return this.ParentDataObject as PhysicianReview; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PhysicianReview */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PhysicianRequest elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PhysicianRequest)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
