using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ClinicalReviewRequest]
	/// </summary>
	[SPInsert("usp_InsertClinicalReviewRequest")]
	[SPUpdate("usp_UpdateClinicalReviewRequest")]
	[SPDelete("usp_DeleteClinicalReviewRequest")]
	[SPLoad("usp_LoadClinicalReviewRequest")]
	[TableMapping("ClinicalReviewRequest","clinicalReviewRequestID")]
	public class ClinicalReviewRequest : BaseData
	{
		[NonSerialized]
		private ClinicalReviewRequestCollection parentClinicalReviewRequestCollection;
		[ColumnMapping("ClinicalReviewRequestID",StereoType=DataStereoType.FK)]
		private int clinicalReviewRequestID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
		[ColumnMapping("ProblemID",StereoType=DataStereoType.FK)]
		private int problemID;
		[ColumnMapping("ReqAmount",StereoType=DataStereoType.FK)]
		private int reqAmount;
		[ColumnMapping("ReqUOMID",StereoType=DataStereoType.FK)]		// lookup
		private int reqUOMID;
		[ColumnMapping("FreqAmount")]	
		private int freqAmount;
		[ColumnMapping("FreqUOMID",StereoType=DataStereoType.FK)]	// lookup
		private int freqUOMID = 1;				// temporarily set to 1
		[ColumnMapping("DurAmount",StereoType=DataStereoType.FK)]
		private int durAmount;
		[ColumnMapping("DurUOMID",StereoType=DataStereoType.FK)]		// lookup
		private int durUOMID;
		[ColumnMapping("UnitCost")]
		private Decimal unitCost;
		[ColumnMapping("Savings")]
		private Decimal savings;
		[ColumnMapping("ClinicalReviewTypeID",StereoType=DataStereoType.FK)]		// lookup
		private int clinicalReviewTypeID;
		[ColumnMapping("Closed")]
		private bool closed;
		[ColumnMapping("DateLastClosed")]			// check if closed changed and set this
		private DateTime dateLastClosed;
		[ColumnMapping("AuthFirstSessionDate")]
		private DateTime authFirstSessionDate;
		[ColumnMapping("EDILogDetailID",StereoType=DataStereoType.FK)]		// don't know how to use!
		private int eDILogDetailID;
		[ColumnMapping("DMEUse",StereoType=DataStereoType.FK)]				// don't know how to use!
		private int dMEUse;
		[ColumnMapping("ClinicalReviewDescriptionID",StereoType=DataStereoType.FK)]		// lookup
		private int clinicalReviewDescriptionID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;

		private bool wasClosedWhenLoaded;
		private ClinicalReviewDecisionCollection clinicalReviewDecisions;		// this keeps track of the change of closed
	
		public ClinicalReviewRequest()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ClinicalReviewRequest(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@REQUESTID@")]
		public int ClinicalReviewRequestID
		{
			get { return this.clinicalReviewRequestID; }
			set { this.clinicalReviewRequestID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ProblemID
		{
			get { return this.problemID; }
			set { this.problemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		[FieldDescription("@REQAMOUNT@")]
		public int ReqAmount
		{
			get { return this.reqAmount; }
			set { this.reqAmount = value; }
		}

		[FieldValuesMember("LookupOf_ReqUOMID", "ClinicalReviewUnitID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int ReqUOMID
		{
			get { return this.reqUOMID; }
			set { this.reqUOMID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int FreqAmount
		{
			get { return this.freqAmount; }
			set { this.freqAmount = value; }
		}

		[FieldValuesMember("LookupOf_FreqUOMID", "ClinicalReviewFreqUnitID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int FreqUOMID
		{
			get { return this.freqUOMID; }
			set { this.freqUOMID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DurAmount
		{
			get { return this.durAmount; }
			set { this.durAmount = value; }
		}

		[FieldValuesMember("LookupOf_DurUOMID", "ClinicalReviewDurUnitID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int DurUOMID
		{
			get { return this.durUOMID; }
			set { this.durUOMID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency, IsRequired=true)]
		public decimal UnitCost
		{
			get { return this.unitCost; }
			set { this.unitCost = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Currency)]
		public decimal Savings
		{
			get { return this.savings; }
			set { this.savings = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewTypeID", "ClinicalReviewTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@REVIEWTYPE@")]
		public int ClinicalReviewTypeID
		{
			get { return this.clinicalReviewTypeID; }
			set { this.clinicalReviewTypeID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Closed
		{
			get { return this.closed; }
			set { this.closed = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DateLastClosed
		{
			get { return this.dateLastClosed; }
			set { this.dateLastClosed = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AuthFirstSessionDate
		{
			get { return this.authFirstSessionDate; }
			set { this.authFirstSessionDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EDILogDetailID
		{
			get { return this.eDILogDetailID; }
			set { this.eDILogDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DMEUse
		{
			get { return this.dMEUse; }
			set { this.dMEUse = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewDescriptionID", "ClinicalReviewDescriptionID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@DESCRIPTION@")]
		public int ClinicalReviewDescriptionID
		{
			get { return this.clinicalReviewDescriptionID; }
			set { this.clinicalReviewDescriptionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/*/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}*/

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int clinicalReviewRequestID)
		{
			return base.Load(clinicalReviewRequestID);
		}

		/// <summary>
		/// Parent ClinicalReviewRequestCollection that contains this element
		/// </summary>
		public ClinicalReviewRequestCollection ParentClinicalReviewRequestCollection
		{
			get
			{
				return this.parentClinicalReviewRequestCollection;
			}
			set
			{
				this.parentClinicalReviewRequestCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			this.wasClosedWhenLoaded = this.closed;		// keep the value of closed to detect change
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			// if new or just closed, save the time
			if (this.IsNew || (!this.wasClosedWhenLoaded && this.closed))
				this.dateLastClosed = DateTime.Now;

			if (this.parentClinicalReviewRequestCollection == null || this.parentClinicalReviewRequestCollection.ParentEvent == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "The clinical review request can only be saved in the child collection");

			Event parentEvent = this.parentClinicalReviewRequestCollection.ParentEvent;
			
			/*if (parentEvent.ParentPatient == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "The clinical review request can't access the event's parent patient");

			PatientProblem selectedProblem = this.parentClinicalReviewRequestCollection.ParentEvent.ParentPatient.SelectedPatientProblem;
			if (selectedProblem == null)
				throw new ActiveAdviceException(AAExceptionAction.None, "The clinical review request can't find the selected problem for patient");
			
			this.problemID = selectedProblem.ProblemId;*/
			this.eventID = parentEvent.EventID;

			base.InternalSave();

			// save child tables that are managed in-memory
			this.SaveClinicalReviewDecisions();
		}

		/// <summary>
		/// Child ClinicalReviewDecisions mapped to related rows of table ClinicalReviewDecision where [ClinicalReviewRequestID] = [ClinicalReviewRequestID]
		/// </summary>
		[SPLoadChild("usp_LoadClinicalReviewRequestDecisions", "clinicalReviewRequestID")]
		public ClinicalReviewDecisionCollection ClinicalReviewDecisions
		{
			get { return this.clinicalReviewDecisions; }
			set
			{
				this.clinicalReviewDecisions = value;
				if (value != null)
					value.ParentClinicalReviewRequest = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ClinicalReviewDecisions collection
		/// </summary>
		public void LoadClinicalReviewDecisions(bool forceReload)
		{
			this.clinicalReviewDecisions = (ClinicalReviewDecisionCollection)ClinicalReviewDecisionCollection.LoadChildCollection("ClinicalReviewDecisions", this, typeof(ClinicalReviewDecisionCollection), clinicalReviewDecisions, forceReload, null);
		}

		/// <summary>
		/// Saves the ClinicalReviewDecisions collection
		/// </summary>
		public void SaveClinicalReviewDecisions()
		{
			ClinicalReviewDecisionCollection.SaveChildCollection(this.clinicalReviewDecisions, true);
		}

		/// <summary>
		/// Synchronizes the ClinicalReviewDecisions collection
		/// </summary>
		public void SynchronizeClinicalReviewDecisions()
		{
			ClinicalReviewDecisionCollection.SynchronizeChildCollection(this.clinicalReviewDecisions, true);
		}

		public ClinicalReviewUnitCollection LookupOf_ReqUOMID
		{
			get
			{
				return ClinicalReviewUnitCollection.ActiveClinicalReviewUnits; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewFreqUnitCollection LookupOf_FreqUOMID
		{
			get
			{
				return ClinicalReviewFreqUnitCollection.ActiveClinicalReviewFreqUnits; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDurUnitCollection LookupOf_DurUOMID
		{
			get
			{
				return ClinicalReviewDurUnitCollection.ActiveClinicalReviewDurUnits; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewTypeCollection LookupOf_ClinicalReviewTypeID
		{
			get
			{
				return ClinicalReviewTypeCollection.ActiveClinicalReviewTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDescriptionCollection LookupOf_ClinicalReviewDescriptionID
		{
			get
			{
				return ClinicalReviewDescriptionCollection.ActiveClinicalReviewDescriptions; // Acquire a shared instance from the static member of collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ClinicalReviewRequest objects
	/// </summary>
	[ElementType(typeof(ClinicalReviewRequest))]
	public class ClinicalReviewRequestCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClinicalReviewRequest elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClinicalReviewRequestCollection = this;
			else
				elem.ParentClinicalReviewRequestCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClinicalReviewRequest elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClinicalReviewRequest this[int index]
		{
			get
			{
				return (ClinicalReviewRequest)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClinicalReviewRequest)oldValue, false);
			SetParentOnElem((ClinicalReviewRequest)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Event that contains this collection
		/// </summary>
		public Event ParentEvent
		{
			get { return this.ParentDataObject as Event; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Event */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ClinicalReviewRequest elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ClinicalReviewRequest)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
