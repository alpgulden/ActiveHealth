using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPractices]
	/// </summary>
	[SPExists("usp_ExistsGroupPractice")]
	//[SPAutoGen("usp_SearchGroupPractices","SearchGroupPractice.sptpl","")]
	[SPInsert("usp_InsertGroupPractice")]
	[SPUpdate("usp_UpdateGroupPractice")]
	[SPDelete("usp_DeleteGroupPractice")]
	[SPLoad("usp_LoadGroupPractice")]
	[TableMapping("GroupPractice","groupPracticeID")]
	public class GroupPractice : BaseDataWithUserDefined
	{
		public enum EnumDeliveryMethod
		{
			None = 0,
			Mail = 1,
			Email = 2,
			Fax = 3
		}

		[NonSerialized]
		private GroupPracticeCollection parentGroupPracticeCollection;
		[ColumnMapping("AlternateID")]
		private string alternateID;
		[ColumnMapping("Name")]
		private string name;
		[ColumnMapping("TypeID",StereoType=DataStereoType.FK)]
		private int typeID;

		[ColumnMapping("Email")]
		private string email;
		[ColumnMapping("AddedOnTheFly")]
		private bool addedOnTheFly;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("GroupPracticeID",StereoType=DataStereoType.FK)]
		private int groupPracticeID;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("StatusChangeTime")]
		private DateTime statusChangeTime;
		[ColumnMapping("StatusChangedBy",StereoType=DataStereoType.FK)]
		private int statusChangedBy;
		[ColumnMapping("DeliveryMethod")]
		private string deliveryMethod;
		[ColumnMapping("FaxNumber",StereoType=DataStereoType.USPhoneNumber)]
		private string faxNumber;
		private GroupPracticeLocationCollection groupPracticeLocations;
		private GroupPracticeFocusCollection focuses;
		private GroupPracticeProviderLinkCollection providerLinks;
		private ProviderCollection	providers;

		private bool activeStatusWhenLoaded;

		[ColumnMapping("ModifiedByName", JoinColumn="LoginName", JoinRelation="GroupPractice.ModifiedBy = [AAUser].UserId")]
		private string modifiedByStr;
		[ColumnMapping("CreatedByName", JoinColumn="LoginName", JoinRelation="GroupPractice.CreatedBy = [AAUser].UserId")]
		private string createdByStr;
		[ColumnMapping("StatusChangedByName", JoinColumn="LoginName", JoinRelation="GroupPractice.StatusChangedBy = [AAUser].UserId")]
		private string statusChangedByStr;

		[FieldDescription("@MODIFIEDBY@")]
		public string ModifiedByStr
		{
			get { return this.modifiedByStr; }
		}

		[FieldDescription("@CREATEDBY@")]
		public string CreatedByStr
		{
			get { return this.createdByStr; }
		}

		[FieldDescription("@USERID@")]
		public string StatusChangedByStr
		{
			get { return this.statusChangedByStr; }
		}

		public GroupPractice()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public GroupPractice(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}


		//[ControlType(EnumControlTypes.TextBox,ValueForNull=(int)0)]
		[FieldDescription("@GROUPPRACTICEID@")]
		public int GroupPracticeID
		{
			get { return this.groupPracticeID; }
			set { this.groupPracticeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		[FieldDescription("@ALTERNATEID@")]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		[FieldDescription("@NAME@")]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		[FieldValuesMember("LookupOf_TypeID", "GroupPracticeTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup,ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@GROUPPRACTICETYPEID@")]
		public int TypeID
		{
			get { return this.typeID; }
			set { this.typeID = value; }
		}

		[ValidatorMember("vldEmail")]
		[ControlType(Macro=EnumControlTypeMacros.Email, MaxLength=255)]
		[FieldDescription("@EMAIL@")]
		public string Email
		{
			get { return this.email; }
			set { this.email = value; }
		}


		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@ADDEDONFLY@")]
		public bool AddedOnTheFly
		{
			get { return this.addedOnTheFly; }
			set { this.addedOnTheFly = value; }
		}

		public string Type
		{
			get 
			{
				GroupPracticeType gpType = new GroupPracticeType();
				gpType.Load(this.TypeID);
				return gpType.Description;
			}
		}
		


		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@ACTIVE@")]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@CREATEDBY@")]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@CREATETIME@")]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@MODIFYTIME@")]
		public System.DateTime ModifiedTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@MODIFYBY@")]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		[FieldDescription("@NOTE@")]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}
		
		
		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}
		
		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			
			if (GroupPracticeID == 0)
				return;
			
			writer.AddFieldsOnNewLine(this, "GroupPracticeID",  "Name");			
		}


		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public void LoadProviders()
		{
			ProviderCollection gpCol = new ProviderCollection();
			gpCol.SqlData.SPExecReadCol("usp_LoadGroupPracticeProvider", -1, gpCol,  true,new object[] { this.groupPracticeID } );

			// for all MarkDel GPLink check the group practice ID if matches remove from collection
			for (int j=0; j < gpCol.Count; j++)
			{
				bool removeCurrentGP = true;
				for (int i=0; i < this.ProviderLinks.Count; i++)
				{
					if (ProviderLinks[i].ProviderID == gpCol[j].ProviderID )
					{
						if (ProviderLinks[i].IsMarkedForDeletion && removeCurrentGP)
							removeCurrentGP = true;
						else
							removeCurrentGP = false;
					}
				}
				if (removeCurrentGP)
					gpCol.MarkDirty(j);
			}

			foreach (Provider gp in gpCol)
			{
				if (gp.IsDirty)
					gpCol.Remove (gp);
			}
			

			this.Providers = gpCol;
		}	

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// track the change of statusID.
			this.activeStatusWhenLoaded = this.active;
		}

		protected override void InternalSave()
		{
			try
			{
				if (this.GroupPracticeID != 0) // update
				{
					//this.SqlData.EnsureTransaction();
					try
					{
						//this.statusID != this.statusIDWhenLoaded
						if (this.active != this.activeStatusWhenLoaded)
						{
							// status changed.
							this.SetStatusChangingUser();
						}

						base.InternalSave();
			
						if (this.ProviderLinks  != null)
						{
							this.providerLinks.SqlData.Transaction = this.SqlData.Transaction;
							this.ProviderLinks.Save();
						}

						this.SaveGroupPracticeLocations();
						//if (this.Locations != null)
						//{
						//	this.groupPracticeLocations.SqlData.Transaction = this.SqlData.Transaction;
						//	//this.groupPracticeLocations.SqlData.UseTransaction(this.sqlData.Transaction);
						//	this.Locations.Save();
						//}
						//this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
					}
					catch(Exception ex)
					{
						//this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
						// Failure handling code here
						throw; // always re-throw exception to notify the client
					}	
				}
				else // New Record
				{
					try
					{
						
						base.InternalSave();
						//this.SqlData.EnsureTransaction();
						this.LoadLocations(false);
						// Add New Location
						AddEmptyLocation();
						this.Locations[0].GroupPracticeID = this.GroupPracticeID;
						
						this.SaveGroupPracticeLocations();
						//this.Locations.Save();


						if (Focuses != null)
						{
							// Update Focuses
							for (int i=0; i < this.Focuses.Count; i++)
								focuses[i].GroupPracticeID = this.GroupPracticeID;
						

							// Use the following method.  note that you must refer to this.SqlData not this.sqlData
							//this.focuses.SqlData.Transaction = this.SqlData.Transaction;
							this.SaveFocuses();
							//this.focuses.Save();
						}
						//this.sqlData.CommitTransaction();
						/*this.groupPracticeLinks.SqlData.UseTransaction(this.sqlData.Transaction);
						this.groupPracticeLinks.Save();*/
					}
					catch (Exception ex)
					{
						//this.sqlData.RollbackTransaction();
						throw;
					}
				}
				
			}
			catch (Exception ex)
			{
				throw new Exception("An error occured while updating Group Practice: " + ex.Message);
			}
		}

		/// <summary>
		///  Adds a new, empty location to Locations collection.
		///  It is used for newly inserted Providers (must have one location).
		/// </summary>
		private void AddEmptyLocation()
		{
			try
			{
				Address servAddr = new Address();
				Address billAddr = new Address();
				Address mailAddr = new Address();
				Location loc = new Location();
				loc.New();
				
				loc.BillingAddress = billAddr;
				loc.BillingAddress.New();
				loc.ServiceAddress = servAddr;
				loc.ServiceAddress.New();
				loc.MailingAddress = mailAddr;
				loc.MailingAddress.New();
				// Created By Info. Replace the 1 with actual code.
				loc.CreateTime	   = DateTime.Now;
				loc.CreatedBy	   = 1;

				GroupPracticeLocation gpLoc = new GroupPracticeLocation();
				gpLoc.New();
				// Created By Info. Replace the 1 with actual code.
				gpLoc.CreateTime		 = DateTime.Now;
				gpLoc.CreatedBy		 = 1;
				gpLoc.Location = loc;
				
				gpLoc.Location.CreatedBy = 1;
				gpLoc.Location.CreateTime = DateTime.Now;
				this.Locations.Add(gpLoc);
			}
			catch(Exception Ex)
			{
				throw ;
			}
		}


	



		/// <summary>
		/// Retrieve the group Practice Type Information and returns the GroupPracticeType object 
		/// </summary>
		/// <returns></returns>
		public GroupPracticeType GetGroupPracticeType() // still Coding 
		{
			if (this.typeID == 0)
				return null;

			GroupPracticeTypeCollection gpType = new GroupPracticeTypeCollection();
			gpType.GetAllGroupPracticeTypesByTypeID(-1,this.typeID);
			
			if (gpType.Count == 0)
				return null;

			if (gpType.Count > 1)
				throw new ActiveAdviceException(AAExceptionAction.None, "There are more than 1 Group Practice type for chosen Group Practice{0}", groupPracticeID);

			return gpType[0];
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Reads multiple objects of this type from source data reader into the given collection
		/// </summary>
		public int ReadCollection(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords, System.Collections.IList collection)
		{
			return SqlData.ReadCollection(sourceReader, maxRecords, collection, typeof(GroupPractice), true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}


		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPracticeID)
		{
			bool result = false;
			result = base.Load(groupPracticeID);
			this.LoadLocations(false);
			return result;
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupPracticeID)
		{
			base.Delete(groupPracticeID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Child GroupPracticeLocations mapped to related rows of table GroupPracticeLocations where [GroupPracticeID] = [GroupPracticeID]
		/// </summary>
		[SPLoadChild("usp_LoadGroupPracticeGroupPracticeLocations", "groupPracticeID")]
		public GroupPracticeLocationCollection Locations
		{
			get { return this.groupPracticeLocations; }
			set
			{
				this.groupPracticeLocations = value;
				value.ParentGroupPractice = this; // set this as a parent of the child collection
			}
		}

		/*/// <summary>
		/// Loads the GroupPracticeLocations collection
		/// </summary>
		public void LoadLocations()
		{
			GroupPracticeLocationCollection locations = new GroupPracticeLocationCollection();
			locations.Load("GroupPracticeID=" + this.GroupPracticeID.ToString(),"LocationID");
			this.Locations	= locations ;
		}*/

		/// <summary>
		/// Loads the GroupPracticeLocations collection
		/// </summary>
		public void LoadLocations(bool forceReload)
		{
			
			this.groupPracticeLocations = (GroupPracticeLocationCollection)GroupPracticeLocationCollection.LoadChildCollection("Locations", this, typeof(GroupPracticeLocationCollection), groupPracticeLocations, forceReload, null);
		}

		/// <summary>
		/// Saves the GroupPracticeLocations collection
		/// </summary>
		public void SaveGroupPracticeLocations()
		{
			GroupPracticeLocationCollection.SaveChildCollection(this.groupPracticeLocations, true);
		}

		/// <summary>
		/// Synchronizes the GroupPracticeLocations collection
		/// </summary>
		public void SynchronizeGroupPracticeLocations()
		{
			GroupPracticeLocationCollection.SynchronizeChildCollection(this.groupPracticeLocations, true);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.CreateTime = DateTime.Now;
			this.active		= true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Child Focuses mapped to related rows of table GroupPracticeFocuses where [GroupPracticeID] = [GroupPracticeID]
		/// </summary>
		[SPLoadChild("usp_LoadGroupPracticeGroupPracticeFocuses", "groupPracticeID")]
		public GroupPracticeFocusCollection Focuses
		{
			get { return this.focuses; }
			set
			{
				this.focuses = value;
				value.ParentGroupPractice = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Focuses collection
		/// </summary>
		public void LoadFocuses(bool forceReload)
		{
			this.focuses = (GroupPracticeFocusCollection)GroupPracticeFocusCollection.LoadChildCollection("Focuses", this, typeof(GroupPracticeFocusCollection), focuses, forceReload, null);
		}

		/// <summary>
		/// Saves the Focuses collection
		/// </summary>
		public void SaveFocuses()
		{
			GroupPracticeFocusCollection.SaveChildCollection(this.focuses, true);
		}

		/// <summary>
		/// Synchronizes the Focuses collection
		/// </summary>
		public void SynchronizeFocuses()
		{
			GroupPracticeFocusCollection.SynchronizeChildCollection(this.focuses, true);
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string DeliveryMethod
		{
			get { return this.deliveryMethod; }
			set { this.deliveryMethod = value; }
		}

		[FieldValuesMember("ValuesOf_DeliveryMethodStr")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		[FieldDescription("@DELIVERYMETHOD@")]
		public string DeliveryMethodStr
		{
			get { return this.deliveryMethod; }
			set { this.deliveryMethod = value; }
		}
		/// <summary>
		/// Returns all possible values and descriptions for delivery methods
		/// </summary>
		public string[,] ValuesOf_DeliveryMethodStr
		{
			get
			{
				return new string[,] { 
					{ "E", EnumDeliveryMethod.Email.ToString() },
					{ "F", EnumDeliveryMethod.Fax.ToString() },
					{ "M", EnumDeliveryMethod.Mail.ToString() } }; // return possible field values
			}
		}

		public ProviderCollection Providers
		{
			set { this.providers  = value; } 
			get { return this.providers; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StatusChangeTime
		{
			get { return this.statusChangeTime; }
			set { this.statusChangeTime = value; }
		}

		public GroupPracticeTypeCollection LookupOf_TypeID
		{
			get
			{
				return GroupPracticeTypeCollection.ActiveGroupPracticeTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}
		
		/// <summary>
		/// Child GroupPractices mapped to related rows of table GroupPracticeProviders where [GroupPracticeID] = [GroupPracticeID]
		/// </summary>
		[SPLoadChild("usp_LoadGroupPracticesProvider", "GroupPracticeID")]
		public GroupPracticeProviderLinkCollection ProviderLinks
		{
			get { return this.providerLinks; }
			set
			{
				this.providerLinks = value;
				value.ParentGroupPractice  = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the GroupPractices collection
		/// </summary>
		public void LoadProviderLinks(bool forceReload)
		{
			this.providerLinks = (GroupPracticeProviderLinkCollection)GroupPracticeProviderLinkCollection.LoadChildCollection("ProviderLinks", this, typeof(GroupPracticeProviderLinkCollection), providerLinks, forceReload, null);
		}

		/// <summary>
		/// Saves the GroupPractices collection
		/// </summary>
		public void SaveProviderLinks()
		{
			GroupPracticeProviderLinkCollection.SaveChildCollection(this.providerLinks, true);
		}

		/// <summary>
		/// Parent GroupPracticeCollection that contains this element
		/// </summary>
		public GroupPracticeCollection ParentGroupPracticeCollection
		{
			get
			{
				return this.parentGroupPracticeCollection;
			}
			set
			{
				this.parentGroupPracticeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		/// <summary>
		/// Returns the Group Practice name for the given group practice ID.
		/// </summary>
		/// <param name="facilityID"></param>
		/// <returns></returns>
		public static string GetGroupPracticeNameByID(int groupPracticeID)
		{
			if (groupPracticeID == 0)
				return null;
			GroupPractice groupPractice = new GroupPractice();
			if (groupPractice.Load(groupPracticeID))
				return groupPractice.Name;
			else
				return null;
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=10)]
		public string FaxNumber
		{
			get { return this.faxNumber; }
			set { this.faxNumber = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

	}

	/// <summary>
	/// Strongly typed collection of GroupPractice objects
	/// </summary>
	[ElementType(typeof(GroupPractice))]
	public class GroupPracticeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPractice elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeCollection = this;
			else
				elem.ParentGroupPracticeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPractice elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPractice this[int index]
		{
			get
			{
				return (GroupPractice)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPractice)oldValue, false);
			SetParentOnElem((GroupPractice)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, GroupPractice elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GroupPractice)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GroupPractice elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPractice elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPractice)value, false);
			base.OnRemoveComplete (index, value);		
		}

		public void SearchGroupPractices(GroupPractice groupPractice,NetworkPlanLink netPlan, GroupPracticeLocationNetworkLink network, GroupPracticeLocationService service, GroupPracticeLocation gploc, Location loc,Address address)
		{
			object [] prams = { groupPractice, address, network, loc, gploc, service };
			this.Clear();
			if (netPlan.PlanId == 0)
				//SqlData.SPExecReadCol("usp_SearchGroupPractices", -1,this, prams, true);
				
				SqlData.SPExecReadCol("usp_SearchGroupPractices", -1,this, prams, true,
					new string[] { "typeID","networkID","alternateID" },
					//new string[] { "email","languageID","networkID","alternateID" },
					new object[] { groupPractice.GetDB("typeID") , network.GetDB("networkID"), groupPractice.GetDB("alternateID") });
					//new object[] { providerInfo.GetDB("email"),providerLanguage.GetDB("languageID"),providerNetwork.GetDB("networkID"),providerInfo.GetDB("alternateID") });
			else
				SqlData.SPExecReadCol("usp_SearchGroupPracticesByPlanID", -1,this, prams, true);
		}
	}
}
