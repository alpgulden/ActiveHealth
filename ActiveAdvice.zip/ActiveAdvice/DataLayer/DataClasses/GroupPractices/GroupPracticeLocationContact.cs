using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeLocationContact]
	/// </summary>
	[SPInsert("usp_InsertGroupPracticeLocationContact")]
	[SPLoad("usp_LoadGroupPracticeLocationContact")]
	[TableMapping("GroupPracticeLocationContact","groupPracticeLocationID,contactID",true)]
	[TableLinkageAttribute(typeof(GroupPracticeLocation), "groupPracticeLocationID", typeof(Contact), "contactID")]
	public class GroupPracticeLocationContact : BaseLinkageClass
	{
		[NonSerialized]
		private GroupPracticeLocationContactCollection parentGroupPracticeLocationContactCollection;
		[ColumnMapping("GroupPracticeLocationID",StereoType=DataStereoType.FK)]
		private int groupPracticeLocationID;
		[ColumnMapping("ContactID",StereoType=DataStereoType.FK)]
		private int contactID;
	
		public GroupPracticeLocationContact()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GroupPracticeLocationID
		{
			get { return this.groupPracticeLocationID; }
			set { this.groupPracticeLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ContactID
		{
			get { return this.contactID; }
			set { this.contactID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent GroupPracticeLocationContactCollection that contains this element
		/// </summary>
		public GroupPracticeLocationContactCollection ParentGroupPracticeLocationContactCollection
		{
			get
			{
				return this.parentGroupPracticeLocationContactCollection;
			}
			set
			{
				this.parentGroupPracticeLocationContactCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of GroupPracticeLocationContact objects
	/// </summary>
	[ElementType(typeof(GroupPracticeLocationContact))]
	public class GroupPracticeLocationContactCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPracticeLocationContact elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeLocationContactCollection = this;
			else
				elem.ParentGroupPracticeLocationContactCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPracticeLocationContact elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPracticeLocationContact this[int index]
		{
			get
			{
				return (GroupPracticeLocationContact)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPracticeLocationContact)oldValue, false);
			SetParentOnElem((GroupPracticeLocationContact)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent GroupPracticeLocation that contains this collection
		/// </summary>
		public GroupPracticeLocation ParentGroupPracticeLocation
		{
			get { return this.ParentDataObject as GroupPracticeLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GroupPracticeLocation */ }
		}
	}
}
