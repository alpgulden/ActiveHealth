using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeFocuses]
	/// </summary>
	[SPInsert("usp_InsertGroupPracticeFocus")]
	[SPUpdate("usp_UpdateGroupPracticeFocus")]
	[SPDelete("usp_DeleteGroupPracticeFocus")]
	[SPLoad("usp_LoadGroupPracticeFocus")]
	[TableMapping("GroupPracticeFocus","groupPracticeFocusID")]
	public class GroupPracticeFocus : BaseDataClass
	{
		[NonSerialized]
		private GroupPracticeFocusCollection parentGroupPracticeFocusCollection;
		[ColumnMapping("GroupPracticeFocusID",StereoType=DataStereoType.FK)]
		private int groupPracticeFocusID;
		[ColumnMapping("GroupPracticeID",StereoType=DataStereoType.FK)]
		private int groupPracticeID;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		
		
		[ColumnMapping("GroupPracticeFocusTypeID",StereoType=DataStereoType.FK)]
		private int groupPracticeFocusTypeID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		

		private GroupPracticeFocusType type;
	
		public GroupPracticeFocus()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public GroupPracticeFocus(int addedBy, DateTime addTime)
		{
			//this.addedBy	= addedBy;
			//this.addTime	= addTime;
		}

		public GroupPracticeFocus(int groupPracticeFocusID)
		{
			this.Load(groupPracticeFocusID);
		}


		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@GROUPPRACTICEFOCUS@")]
		public int GroupPracticeFocusID
		{
			get { return this.groupPracticeFocusID; }
			set { this.groupPracticeFocusID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@GROUPPRACTICEID@")]
		public int GroupPracticeID
		{
			get { return this.groupPracticeID; }
			set { this.groupPracticeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@CREATETIME@")]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@CREATEDBY@")]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		

		[FieldDescription("@CODE@")]
		public string Code
		{
			get 
			{
				GroupPracticeFocusType gpFocusType = new GroupPracticeFocusType();
				gpFocusType.Load(this.GroupPracticeFocusTypeID);
				return gpFocusType.Code;
			}
		}

		public string Description
		{
			get 
			{
				return "aa";//GroupPracticeFocus
			}
		}

		[FieldValuesMember("LookupOf_GroupPracticeFocusTypeID", "GroupPracticeFocusTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@GROUPPRACTICEFOCUS@")]
		public int GroupPracticeFocusTypeID
		{
			get { return this.groupPracticeFocusTypeID; }
			set { this.groupPracticeFocusTypeID = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		/// <summary>
		/// Reads multiple objects of this type from source data reader into the given collection
		/// </summary>
		public int ReadCollection(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords, System.Collections.IList collection)
		{
			return SqlData.ReadCollection(sourceReader, maxRecords, collection, typeof(GroupPracticeFocus), true, false);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			if (this.type != null)
				this.type.Save();
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPracticeFocusID)
		{
			bool result = true;
			if (this.groupPracticeFocusTypeID != 0)
				result	= this.type.Load(this.groupPracticeFocusTypeID);
			return result && base.Load(groupPracticeFocusID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupPracticeFocusID)
		{
			base.Delete(groupPracticeFocusID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Parent GroupPracticeFocusCollection that contains this element
		/// </summary>
		public GroupPracticeFocusCollection ParentGroupPracticeFocusCollection
		{
			get
			{
				return this.parentGroupPracticeFocusCollection;
			}
			set
			{
				this.parentGroupPracticeFocusCollection = value; // parent is set when added to a collection
			}
		}


		/// <summary>
		///  Updates the status of the current focus to inactive and then updates
		///  the database.
		/// </summary>
		/// <param name="userID">ID of user that inactivated the focus.</param>
		/// <param name="inactiveDate">Date on which focus was inactiavated</param>
		public void Inactivate()
		{
			try
			{
				this.active			= false;
				// base.SetInactivatingUser();
				this.Save();
			}
			catch (Exception ex)
			{
				throw new Exception("Could not update Group Practice Focus status: " + ex.Message);
			}
		}


		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.CreateTime					= DateTime.Now;
			this.groupPracticeFocusID		= 0;
			this.groupPracticeFocusTypeID	= 0;
			this.groupPracticeID			= 0;
			this.createdBy					= 0;
			this.active						= true;

			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}


		/// <summary>
		/// Contained Type object
		/// </summary>
		[Contained]
		public GroupPracticeFocusType Type
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.type = (GroupPracticeFocusType)GroupPracticeFocusType.EnsureContainedDataObject(this, typeof(GroupPracticeFocusType), type, false, groupPracticeFocusID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.type;
			}
			set
			{
				this.type = value;
				if (value != null) value.ParentGroupPracticeFocus = this; // set this as a parent of the child data class
			}
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

	

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		public GroupPracticeFocusTypeCollection LookupOf_GroupPracticeFocusTypeID
		{
			get
			{
				return GroupPracticeFocusTypeCollection.ActiveGroupPracticeFocusTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of GroupPracticeFocus objects
	/// </summary>
	[ElementType(typeof(GroupPracticeFocus))]
	public class GroupPracticeFocusCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPracticeFocus elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeFocusCollection = this;
			else
				elem.ParentGroupPracticeFocusCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPracticeFocus elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPracticeFocus this[int index]
		{
			get
			{
				return (GroupPracticeFocus)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPracticeFocus)oldValue, false);
			SetParentOnElem((GroupPracticeFocus)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, GroupPracticeFocus elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeFocus)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GroupPracticeFocus elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPracticeFocus elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeFocus)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/* Don't use this.
		 * /// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(string filter, string sort)
		{
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForType(typeof(GroupPracticeFocus), filter, sort, true);
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}*/

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int SPLoad(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/* Don't use this.
		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL( object param)
		{
			SQLParser sql = new SQLParser("select * from [GroupPracticeFocuses] " +
			"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Parent GroupPractice that contains this collection
		/// </summary>
		public GroupPractice ParentGroupPractice
		{
			get { return this.ParentDataObject as GroupPractice; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GroupPractice */ }
		}
	}
}
