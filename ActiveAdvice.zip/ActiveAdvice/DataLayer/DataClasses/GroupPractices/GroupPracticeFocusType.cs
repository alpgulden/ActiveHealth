using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeFocusTypes]
	/// </summary>
	
	[SPAutoGen("usp_GetAllGroupPracticeFocusTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetGroupPracticeFocusTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertGroupPracticeFocusType")]
	[SPUpdate("usp_UpdateGroupPracticeFocusType")]
	[SPDelete("usp_DeleteGroupPracticeFocusType")]
	[SPLoad("usp_LoadGroupPracticeFocusType")]
	[TableMapping("GroupPracticeFocusType","groupPracticeFocusTypeID")]
	public class GroupPracticeFocusType : BaseLookupWithCode
	{
		[NonSerialized]
		private GroupPracticeFocusTypeCollection parentGroupPracticeFocusTypeCollection;
		[ColumnMapping("GroupPracticeFocusTypeID",StereoType=DataStereoType.FK)]
		private int groupPracticeFocusTypeID;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

	
		public GroupPracticeFocusType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[FieldValuesMember("LookupOf_GroupPracticeFocusTypeID", "GroupPracticeFocusTypeID", "Focus")]
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GroupPracticeFocusTypeID
		{
			get { return this.groupPracticeFocusTypeID; }
			set { this.groupPracticeFocusTypeID = value; }
		}


		/// <summary>
		/// Parent GroupPracticeFocusTypeCollection that contains this element
		/// </summary>
		public GroupPracticeFocusTypeCollection ParentGroupPracticeFocusTypeCollection
		{
			get
			{
				return this.parentGroupPracticeFocusTypeCollection;
			}
			set
			{
				this.parentGroupPracticeFocusTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPracticeFocusTypeID)
		{
			return base.Load(groupPracticeFocusTypeID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupPracticeFocusTypeID)
		{
			base.Delete(groupPracticeFocusTypeID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Parent GroupPracticeFocus that contains this object
		/// </summary>
		public GroupPracticeFocus ParentGroupPracticeFocus
		{
			get { return this.ParentDataObject as GroupPracticeFocus; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GroupPracticeFocus */ }
		}

		public GroupPracticeFocusTypeCollection LookupOf_GroupPracticeFocusTypeID
		{
			get
			{
				return GroupPracticeFocusTypeCollection.ActiveGroupPracticeFocusTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of GroupPracticeFocusType objects
	/// </summary>
	[ElementType(typeof(GroupPracticeFocusType))]
	public class GroupPracticeFocusTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPracticeFocusType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeFocusTypeCollection = this;
			else
				elem.ParentGroupPracticeFocusTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPracticeFocusType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPracticeFocusType this[int index]
		{
			get
			{
				return (GroupPracticeFocusType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPracticeFocusType)oldValue, false);
			SetParentOnElem((GroupPracticeFocusType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GroupPracticeFocusType elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeFocusType)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPracticeFocusType elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeFocusType)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/* Don't use this.
		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL( object param)
		{
			SQLParser sql = new SQLParser("select * from [GroupPracticeFocusTypes] " +
			"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadGroupPracticeFocusTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGroupPracticeFocusTypesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared GroupPracticeFocusTypeCollection which is cached in NSGlobal
		/// </summary>
		public static GroupPracticeFocusTypeCollection ActiveGroupPracticeFocusTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				GroupPracticeFocusTypeCollection col = (GroupPracticeFocusTypeCollection)NSGlobal.EnsureCachedObject("ActiveGroupPracticeFocusTypes", typeof(GroupPracticeFocusTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadGroupPracticeFocusTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Load All Group Practice Focus Types.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllGroupPracticeFocusTypes", -1, this, false);
		}

		/// <summary>
		/// Searches for Group Practice Focus Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchGroupPracticeFocusTypes", -1, this, false, code, description, active);
		}


	}
}
