using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllGroupPracticeTypesByTypeID","SelectAllByGivenArgs.sptpl","groupPracticeTypeID")]
	[SPAutoGen("usp_GetAllGroupPracticeTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllGroupPracticeTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertGroupPracticeType")]
	[SPUpdate("usp_UpdateGroupPracticeType")]
	[SPDelete("usp_DeleteGroupPracticeType")]
	[SPLoad("usp_LoadGroupPracticeType")]
	[TableMapping("GroupPracticeType","groupPracticeTypeID")]
	public class GroupPracticeType : BaseLookupWithCode
	{
		[NonSerialized]
		private GroupPracticeTypeCollection parentGroupPracticeTypeCollection;
		[ColumnMapping("GroupPracticeTypeID",StereoType=DataStereoType.FK)]
		private int groupPracticeTypeID;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

	
		public GroupPracticeType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GroupPracticeTypeID
		{
			get { return this.groupPracticeTypeID; }
			set { this.groupPracticeTypeID = value; }
		}



		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPracticeTypeID)
		{
			return base.Load(groupPracticeTypeID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupPracticeTypeID)
		{
			base.Delete(groupPracticeTypeID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			return this.Description;
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active = true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Parent GroupPracticeTypeCollection that contains this element
		/// </summary>
		public GroupPracticeTypeCollection ParentGroupPracticeTypeCollection
		{
			get
			{
				return this.parentGroupPracticeTypeCollection;
			}
			set
			{
				this.parentGroupPracticeTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		/// <summary>
		/// Returns the Group Practice type description for the given type ID.
		/// </summary>
		/// <param name="groupPracticeTypeID"></param>
		/// <returns></returns>
		public static string GetGroupPracticeTypeByID(int groupPracticeTypeID)
		{
			if (groupPracticeTypeID == 0)
				return null;
			GroupPracticeType groupPracticeType = new GroupPracticeType();
			if (groupPracticeType.Load(groupPracticeTypeID))
				return groupPracticeType.Description;
			else
				return null;
		}
	}

	/// <summary>
	/// Strongly typed collection of GroupPracticeType objects
	/// </summary>
	[ElementType(typeof(GroupPracticeType))]
	public class GroupPracticeTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPracticeType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeTypeCollection = this;
			else
				elem.ParentGroupPracticeTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPracticeType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPracticeType this[int index]
		{
			get
			{
				return (GroupPracticeType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPracticeType)oldValue, false);
			SetParentOnElem((GroupPracticeType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Returns true if the collection contains the given object
		/// </summary>
		public bool Contains(GroupPracticeType elem)
		{
			return List.Contains(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPracticeType elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeType)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGroupPracticeTypesByActive(int maxRecords, bool active)
		{
			return SqlData.SPExecReadCol("usp_GetAllGroupPracticeTypesByActive", maxRecords, this, false, new object[] { true});
		}

		/// <summary>
		/// Accessor to a shared GroupPracticeTypeCollection which is cached in NSGlobal
		/// </summary>
		public static GroupPracticeTypeCollection ActiveGroupPracticeTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				GroupPracticeTypeCollection col = (GroupPracticeTypeCollection)NSGlobal.EnsureCachedObject("ActiveGroupPracticeTypes", typeof(GroupPracticeTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadGroupPracticeTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllGroupPracticeTypes(int maxRecords)
		{
			return SqlData.SPExecReadCol("usp_GetAllGroupPracticeTypes", maxRecords, this, false);
		}

		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllGroupPracticeTypes", -1, this, false);
		}

		/// <summary>
		/// Searches for Group Practice Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchGroupPracticeTypes", -1, this, false, code, description, active);
		}

		/// <summary>
		/// Executes a stored procedure to extract type based on type id.
		/// </summary>
		public int GetAllGroupPracticeTypesByTypeID(int maxRecords, int groupPracticeTypeID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllGroupPracticeTypesByTypeID", maxRecords, this, false, groupPracticeTypeID);
		}

	}
}
