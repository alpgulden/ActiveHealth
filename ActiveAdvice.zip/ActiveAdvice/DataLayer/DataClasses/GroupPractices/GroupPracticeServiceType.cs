using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeServiceTypes]
	/// </summary>
	/// 
	[SPAutoGen("usp_GetAllGroupPracticeServiceTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetGroupPracticeServiceTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertGroupPracticeServiceType")]
	[SPUpdate("usp_UpdateGroupPracticeServiceType")]
	[SPDelete("usp_DeleteGroupPracticeServiceType")]
	[SPLoad("usp_LoadGroupPracticeServiceType")]
	[TableMapping("GroupPracticeServiceType","groupPracticeServiceTypeID")]
	public class GroupPracticeServiceType : BaseLookupWithCode
	{
		[NonSerialized]
		private GroupPracticeServiceTypeCollection parentGroupPracticeServiceTypeCollection;
		[ColumnMapping("GroupPracticeServiceTypeID",StereoType=DataStereoType.FK)]
		private int groupPracticeServiceTypeID;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

	
		public GroupPracticeServiceType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		//[FieldValuesMember("LookupOf_GroupPracticeServiceTypeID", "GroupPracticeServiceTypeID", "Service")]
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GroupPracticeServiceTypeID
		{
			get { return this.groupPracticeServiceTypeID; }
			set { this.groupPracticeServiceTypeID = value; }
		}


		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPracticeServiceTypeID)
		{
			return base.Load(groupPracticeServiceTypeID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupPracticeServiceTypeID)
		{
			base.Delete(groupPracticeServiceTypeID);		
		}

		/// <summary>
		/// Parent GroupPracticeServiceTypeCollection that contains this element
		/// </summary>
		public GroupPracticeServiceTypeCollection ParentGroupPracticeServiceTypeCollection
		{
			get
			{
				return this.parentGroupPracticeServiceTypeCollection;
			}
			set
			{
				this.parentGroupPracticeServiceTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active = true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		public GroupPracticeServiceTypeCollection LookupOf_GroupPracticeServiceTypeID
		{
			get
			{
				return GroupPracticeServiceTypeCollection.ActiveGroupPracticeServiceTypes; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of GroupPracticeServiceType objects
	/// </summary>
	[ElementType(typeof(GroupPracticeServiceType))]
	public class GroupPracticeServiceTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPracticeServiceType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeServiceTypeCollection = this;
			else
				elem.ParentGroupPracticeServiceTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPracticeServiceType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPracticeServiceType this[int index]
		{
			get
			{
				return (GroupPracticeServiceType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPracticeServiceType)oldValue, false);
			SetParentOnElem((GroupPracticeServiceType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, GroupPracticeServiceType elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeServiceType)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GroupPracticeServiceType elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPracticeServiceType elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeServiceType)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int LoadGroupPracticeServiceTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGroupPracticeServiceTypesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared GroupPracticeServiceTypeCollection which is cached in NSGlobal
		/// </summary>
		public static GroupPracticeServiceTypeCollection ActiveGroupPracticeServiceTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				GroupPracticeServiceTypeCollection col = (GroupPracticeServiceTypeCollection)NSGlobal.EnsureCachedObject("ActiveGroupPracticeServiceTypes", typeof(GroupPracticeServiceTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadGroupPracticeServiceTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Loads all Group Practice Service Types
		/// </summary>
		public override void LoadAll()
		{
			SqlData.SPExecReadCol("usp_GetAllGroupPracticeServiceTypes", -1, this, false);
		}

		/// <summary>
		/// Searches for Group Practice Service Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchGroupPracticeServiceTypes", -1, this, false, code, description, active);
		}
	}
}
