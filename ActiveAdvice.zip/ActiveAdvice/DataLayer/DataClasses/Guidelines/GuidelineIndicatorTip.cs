using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GuidelineIndicatorTip]
	/// </summary>
	[SPExists("usp_ExistsGuidelineIndicatorTip")]
	[SPInsert("usp_InsertGuidelineIndicatorTip")]
	[SPUpdate("usp_UpdateGuidelineIndicatorTip")]
	[SPDelete("usp_DeleteGuidelineIndicatorTip")]
	[SPLoad("usp_LoadGuidelineIndicatorTip")]
	[TableMapping("GuidelineIndicatorTip","guidelineIndicatorTipID")]
	public class GuidelineIndicatorTip : BaseData
	{
		[NonSerialized]
		private GuidelineIndicatorTipCollection parentGuidelineIndicatorTipCollection;
		[ColumnMapping("GuidelineIndicatorTipID",(int)0)]
		private int guidelineIndicatorTipID;
		[ColumnMapping("GuidelineIndicatorID",StereoType=DataStereoType.FK)]
		private int guidelineIndicatorID;
		[ColumnMapping("PageNumber",StereoType=DataStereoType.FK)]
		private int pageNumber;
		[ColumnMapping("Tip")]
		private string tip;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public GuidelineIndicatorTip()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public GuidelineIndicatorTip(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GuidelineIndicatorTipID
		{
			get { return this.guidelineIndicatorTipID; }
			set { this.guidelineIndicatorTipID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int GuidelineIndicatorID
		{
			get { return this.guidelineIndicatorID; }
			set { this.guidelineIndicatorID = value; }
		}

		
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PageNumber
		{
			get { return this.pageNumber; }
			set { this.pageNumber = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Tip
		{
			get { return this.tip; }
			set { this.tip = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent GuidelineIndicatorTipCollection that contains this element
		/// </summary>
		public GuidelineIndicatorTipCollection ParentGuidelineIndicatorTipCollection
		{
			get
			{
				return this.parentGuidelineIndicatorTipCollection;
			}
			set
			{
				this.parentGuidelineIndicatorTipCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int guidelineIndicatorTipID)
		{
			return base.Load(guidelineIndicatorTipID);
		}

		/// <summary>
		/// Parent GuidelineIndicator that contains this object
		/// </summary>
		public GuidelineIndicator ParentGuidelineIndicator
		{
			get { return this.ParentDataObject as GuidelineIndicator; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GuidelineIndicator */ }
		}

		
	}

	/// <summary>
	/// Strongly typed collection of GuidelineIndicatorTip objects
	/// </summary>
	[ElementType(typeof(GuidelineIndicatorTip))]
	public class GuidelineIndicatorTipCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Parent GuidelineIndicator that contains this collection
		/// </summary>
		public GuidelineIndicator ParentGuidelineIndicator
		{
			get { return this.ParentDataObject as GuidelineIndicator; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GuidelineIndicator */ }
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GuidelineIndicatorTip elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGuidelineIndicatorTipCollection = this;
			else
				elem.ParentGuidelineIndicatorTipCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GuidelineIndicatorTip elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GuidelineIndicatorTip this[int index]
		{
			get
			{
				return (GuidelineIndicatorTip)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GuidelineIndicatorTip)oldValue, false);
			SetParentOnElem((GuidelineIndicatorTip)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GuidelineIndicatorTip elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GuidelineIndicatorTip)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
