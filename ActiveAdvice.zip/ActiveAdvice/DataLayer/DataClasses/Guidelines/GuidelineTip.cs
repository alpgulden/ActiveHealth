using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GuidelineTip]
	/// </summary>
	[SPExists("usp_ExistsGuidelineTip")]
	[SPInsert("usp_InsertGuidelineTip")]
	[SPUpdate("usp_UpdateGuidelineTip")]
	[SPDelete("usp_DeleteGuidelineTip")]
	[SPLoad("usp_LoadGuidelineTip")]
	[TableMapping("GuidelineTip","guidelineTipID")]
	public class GuidelineTip : BaseData
	{
		[NonSerialized]
		private GuidelineTipCollection parentGuidelineTipCollection;
		
		
		[ColumnMapping("GuidelineTipID",(int)0)]
		private int guidelineTipID;
		[ColumnMapping("GuidelineID",StereoType=DataStereoType.FK)]
		private int guidelineID;
		[ColumnMapping("Tip")]
		private string tip;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public GuidelineTip()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public GuidelineTip(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GuidelineTipID
		{
			get { return this.guidelineTipID; }
			set { this.guidelineTipID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int GuidelineID
		{
			get { return this.guidelineID; }
			set { this.guidelineID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Tip
		{
			get { return this.tip; }
			set { this.tip = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		

		/// <summary>
		/// Parent GuidelineTipCollection that contains this element
		/// </summary>
		public GuidelineTipCollection ParentGuidelineTipCollection
		{
			get
			{
				return this.parentGuidelineTipCollection;
			}
			set
			{
				this.parentGuidelineTipCollection = value; // parent is set when added to a collection
			}
		}

	

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int guidelineTipID)
		{
			return base.Load(guidelineTipID);
		}

		/// <summary>
		/// Parent Guideline that contains this object
		/// </summary>
		public Guideline ParentGuideline
		{
			get { return this.ParentDataObject as Guideline; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Guideline */ }
		}

		
	}

	/// <summary>
	/// Strongly typed collection of GuidelineTip objects
	/// </summary>
	[ElementType(typeof(GuidelineTip))]
	public class GuidelineTipCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Parent Guideline that contains this collection
		/// </summary>
		public Guideline ParentGuideline
		{
			get { return this.ParentDataObject as Guideline; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Guideline */ }
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GuidelineTip elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGuidelineTipCollection = this;
			else
				elem.ParentGuidelineTipCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GuidelineTip elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GuidelineTip this[int index]
		{
			get
			{
				return (GuidelineTip)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GuidelineTip)oldValue, false);
			SetParentOnElem((GuidelineTip)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GuidelineTip elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GuidelineTip)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
