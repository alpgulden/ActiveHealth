using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [GuidelineProduct]
	/// </summary>
	[SPAutoGen("usp_GetAllGuidelineProducts","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetGuidelineProductsForCatGuidelineSS","SelectRelatedFromLinkedTable2ColBreakerFilter.sptpl","GuidelineProductCategoryLink, guidelineProductID, guidelineID, guidelineCategoryID, guidelineSourceSetID")]
	[SPAutoGen("usp_GetGuidelineProductsForCategoryGuideline","SelectRelatedFromLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineProductID, guidelineCategoryID, guidelineID")]
	[SPAutoGen("usp_GetGuidelineProductsForGuidelineSS","SearchLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineProductID, guidelineID, guidelineSourceSetID")]
	[SPAutoGen("usp_GetGuidelineProductForCategorySS","SearchLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineProductID, guidelineCategoryID, guidelineSourceSetID")]
	[SPAutoGen("usp_GetGuidelineProductForGuideline","SelectRelatedFromLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineProductID, guidelineID")]
	[SPAutoGen("usp_GetGuidelineProductForCategory","SelectRelatedFromLinkedTable.sptpl","GuidelineProductCategoryLink, guidelineProductID, guidelineCategoryID")]
	[SPAutoGen("usp_GetGuidelineProductsForSourceSet","SelectAllByGivenArgs.sptpl","guidelineSourceSetID")]
	[SPInsert("usp_InsertGuidelineProduct")]
	[SPUpdate("usp_UpdateGuidelineProduct")]
	[SPDelete("usp_DeleteGuidelineProduct")]
	[SPLoad("usp_LoadGuidelineProduct")]
	[TableMapping("GuidelineProduct","guidelineProductID")]
	public class GuidelineProduct : BaseData
	{
		[NonSerialized]
		private GuidelineProductCollection parentGuidelineProductCollection;
		
		[ColumnMapping("GuidelineProductID",(int)0)]
		private int guidelineProductID;
		[ColumnMapping("GuidelineSourceSetID",StereoType=DataStereoType.FK)]
		private int guidelineSourceSetID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public GuidelineProduct()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public GuidelineProduct(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GuidelineProductID
		{
			get { return this.guidelineProductID; }
			set { this.guidelineProductID = value; }
		}

		[FieldValuesMember("LookupOf_guidelineSourceSetID", "GuidelineSourceSetID", "Note")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int GuidelineSourceSetID
		{
			get { return this.guidelineSourceSetID; }
			set { this.guidelineSourceSetID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		
		

		/// <summary>
		/// Parent GuidelineProductCollection that contains this element
		/// </summary>
		public GuidelineProductCollection ParentGuidelineProductCollection
		{
			get
			{
				return this.parentGuidelineProductCollection;
			}
			set
			{
				this.parentGuidelineProductCollection = value; // parent is set when added to a collection
			}
		}



		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int guidelineProductID)
		{
			return base.Load(guidelineProductID);
		}

		
		public GuidelineSourceSetCollection LookupOf_guidelineSourceSetID
		{
			get
			{
				return GuidelineSourceSetCollection.ActiveGuidelineSourceSets; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of GuidelineProduct objects
	/// </summary>
	[ElementType(typeof(GuidelineProduct))]
	public class GuidelineProductCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Parent GuidelineSourceSet that contains this collection
		/// </summary>
		public GuidelineSourceSet ParentGuidelineSourceSet
		{
			get { return this.ParentDataObject as GuidelineSourceSet; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GuidelineSourceSet */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineProductsForSourceSet(int maxRecords, int guidelineSourceSetID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineProductsForSourceSet", maxRecords, this, false, new object[] { guidelineSourceSetID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineProductForCategory(int maxRecords,int guidelineCategoryID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineProductForCategory", maxRecords, this, false,new object[] {guidelineCategoryID});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineProductForGuideline(int maxRecords,int guidelineID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineProductForGuideline", maxRecords, this, false,new object[]{guidelineID});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineProductForCategorySS(int maxRecords, int guidelineSourceSetID, int guidelineCategoryID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineProductForCategorySS", maxRecords, this, false, new object[] { guidelineCategoryID,guidelineSourceSetID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineProductsForGuidelineSS(int maxRecords, int guidelineSourceSetID, int guidelineID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineProductsForGuidelineSS", maxRecords, this, false, new object[] {guidelineID, guidelineSourceSetID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineProductsForCategoryGuideline(int maxRecords,int guidelineCategoryID, int guidelineID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineProductsForCategoryGuideline", maxRecords, this, false,new object[]{guidelineCategoryID, guidelineID});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadGuidelineProductsForCatGuidelineSS(int maxRecords, int guidelineSourceSetID,int guidelineCategoryID, int guidelineID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetGuidelineProductsForCatGuidelineSS", maxRecords, this, false, new object[] { guidelineID,guidelineCategoryID,guidelineSourceSetID });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllGuidelineProducts(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllGuidelineProducts", maxRecords, this, false);
		}
	}
}
