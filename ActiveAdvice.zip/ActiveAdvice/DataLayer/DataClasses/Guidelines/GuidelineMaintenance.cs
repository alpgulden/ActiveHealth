using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for GuidelineMaintenance.
	/// </summary>
	[TableMapping(null)]
	public class GuidelineMaintenance
	{
 
		private int guidelineSourceSetID;
		public GuidelineMaintenance()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		[FieldValuesMember("LookupOf_GuidelineSourceSetID", "GuidelineSourceSetID", "Note")]
		[ControlType(EnumControlTypes.ComboBox, ValueForNull=(int)0)]
		public int GuidelineSourceSetID
		{
			get { return this.guidelineSourceSetID; }
			set { this.guidelineSourceSetID = value; }
		}

		public GuidelineSourceSetCollection LookupOf_GuidelineSourceSetID
		{
			get
			{
				return GuidelineSourceSetCollection.ActiveGuidelineSourceSets;
			}
		}
	}
}
