using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [DecisionReasons]
	/// </summary>
	[SPAutoGen("usp_GetDecisionReasonByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllDecisionReason","SelectAll.sptpl","")]
	[SPInsert("usp_InsertDecisionReason")]
	[SPUpdate("usp_UpdateDecisionReason")]
	[SPDelete("usp_DeleteDecisionReason")]
	[SPLoad("usp_LoadDecisionReason")]
	[TableMapping("DecisionReason","decisionReasonID")]
	public class DecisionReason : BaseLookupWithCode
	{
		[NonSerialized]
		private DecisionReasonCollection parentDecisionReasonCollection;
		[ColumnMapping("DecisionReasonID",StereoType=DataStereoType.FK)]
		private int decisionReasonID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public DecisionReason()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int DecisionReasonID
		{
			get { return this.decisionReasonID; }
			set { this.decisionReasonID = value; }
		}

		/// <summary>
		/// Parent DecisionReasonCollection that contains this element
		/// </summary>
		public DecisionReasonCollection ParentDecisionReasonCollection
		{
			get
			{
				return this.parentDecisionReasonCollection;
			}
			set
			{
				this.parentDecisionReasonCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of DecisionReason objects
	/// </summary>
	[ElementType(typeof(DecisionReason))]
	public class DecisionReasonCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(DecisionReason elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentDecisionReasonCollection = this;
			else
				elem.ParentDecisionReasonCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (DecisionReason elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public DecisionReason this[int index]
		{
			get
			{
				return (DecisionReason)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((DecisionReason)oldValue, false);
			SetParentOnElem((DecisionReason)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadDecisionReasonByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetDecisionReasonByActive", maxRecords, this, false, new object [] { active });
		}

		/// <summary>
		/// Accessor to a shared ReferralTypeCollection which is cached in NSGlobal
		/// </summary>
		public static DecisionReasonCollection ActiveDecisionReason
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				DecisionReasonCollection col = (DecisionReasonCollection)NSGlobal.EnsureCachedObject("ActiveDecisionReason", typeof(DecisionReasonCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					//col.GetFacilityFocusTypesByActive(-1, true);
					col.LoadDecisionReasonByActive(-1, true);
				}
				return col;
			}			
		}
	}
}
