using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Addresses]
	/// </summary>
	[SPInsert("usp_InsertAddress")]
	[SPUpdate("usp_UpdateAddress")]
	[SPDelete("usp_DeleteAddress")]
	[SPLoad("usp_LoadAddress")]
	[TableMapping("Address","addressID")]
	public class Address : NetsoftUSA.DataLayer.BaseDataClass
	{
		public enum EnumDeliveryMethod
		{
			None = 0,
			Mail = 1,
			Email = 2,
			Fax = 3
		}
		
		[Copiable(false)]
		[ColumnMapping("AddressID",StereoType=DataStereoType.FK)]
		protected int addressID; 
		[ColumnMapping("Line1")]
		protected string line1;
		[ColumnMapping("Line2")]
		protected string line2;
		[ColumnMapping("City")]
		protected string city;
		[ColumnMapping("State")]
		protected string state;
		[ColumnMapping("Zip")]
		protected string zip;
		[ColumnMapping("County")]
		protected string county;
		[ColumnMapping("Country")]
		protected string country;
		[ColumnMapping("PhoneNumber1", StereoType=DataStereoType.USPhoneNumber)]
		protected string phoneNumber1;
		[ColumnMapping("PhoneExt1")]
		protected string phoneExt1;
		[ColumnMapping("PhoneNumber2", StereoType=DataStereoType.USPhoneNumber)]
		protected string phoneNumber2;
		[ColumnMapping("PhoneExt2")]
		protected string phoneExt2;
		[ColumnMapping("PhoneNumber3", StereoType=DataStereoType.USPhoneNumber)]
		protected string phoneNumber3;
		[ColumnMapping("PhoneExt3")]
		protected string phoneExt3;
		[ColumnMapping("FaxNumber", StereoType=DataStereoType.USPhoneNumber)]
		protected string faxNumber;
		[ColumnMapping("DeliveryMethod")]
		protected string deliveryMethod;
		[ColumnMapping("Email", StereoType=DataStereoType.Email)]
		protected string email;
		[ColumnMapping("URL", StereoType=DataStereoType.URL)]
		protected string uRL;
		[ColumnMapping("Line3")]
		protected string line3;
		[ColumnMapping("FaxExtension")]
		protected string faxExtension;
		[ColumnMapping("BeeperNumber", StereoType=DataStereoType.USPhoneNumber)]
		protected string beeperNumber;
		[ColumnMapping("BeeperExt")]
		private string beeperExt;
		[ColumnMapping("AlternateID")]
		private string alternateID;
		[ColumnMapping("uuid")]
		private Guid uuid;
	
		public Address()
		{
				
		}

		[ControlType(EnumControlTypes.TextBox)]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}
		
		[FieldDescription("@STREETADDR1@")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=255, ClientScriptForConditionalRequired="GetElemValue('AddressControlDeliveryMethodStr') == 'M'", IsRequired=true)]
		public string Line1
		{
			get { return this.line1; }
			set { this.line1 = value; }
		}

		[FieldDescription("@STREETADDR2@")]
		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Line2
		{
			get { return this.line2; }
			set { this.line2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20, ClientScriptForConditionalRequired="GetElemValue('AddressControlDeliveryMethodStr') == 'M'", IsRequired=true)]
		[FieldDescription("@CITY@")]
		public string City
		{
			get { return this.city; }
			set { this.city = value; }
			
		}

		[ControlType(Macro=EnumControlTypeMacros.USState, MaxLength=2, ClientScriptForConditionalRequired="GetElemValue('AddressControlDeliveryMethodStr') == 'M'", IsRequired=true)]
		[FieldDescription("@STATE@")]
		public string State
		{
			get { return this.state; }
			set { this.state = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USZipCode, MaxLength=5, InputMask="#####-####", ClientScriptForConditionalRequired="GetElemValue('AddressControlDeliveryMethodStr') == 'M'", IsRequired=true)]
		[FieldDescription("@ZIPCODE@")]
		public string Zip
		{
			get { return this.zip; }
			set 
			{
				this.zip = value; 
				if (this.zip != null)
					if (Formatting.RemoveChars(this.zip, ' ', '-') == "")
						this.zip = null;
			}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		[FieldDescription("@COUNTY@")]
		public string County
		{
			get { return this.county; }
			set { this.county = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20, ClientScriptForConditionalRequired="GetElemValue('AddressControlDeliveryMethodStr') == 'M'", IsRequired=true)]
		[FieldDescription("@COUNTRY@")]
		public string Country
		{
			get { return this.country; }
			set { this.country = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=15)]
		[FieldDescription("@PHONE1@")]
		public string PhoneNumber1
		{
			get { return this.phoneNumber1; }
			set { this.phoneNumber1 = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=15)]
		[FieldDescription("@PHONE2@")]
		public string PhoneNumber2
		{
			get { return this.phoneNumber2; }
			set { this.phoneNumber2 = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=15)]
		[FieldDescription("@PHONE3@")]
		public string PhoneNumber3
		{
			get { return this.phoneNumber3; }
			set { this.phoneNumber3 = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=10, 
			 ClientScriptForConditionalRequired="GetElemValue('AddressControlDeliveryMethodStr') == 'F'", IsRequired=true)]
		[FieldDescription("@FAX@")]
		public string FaxNumber
		{
			get { return this.faxNumber; }
			set { this.faxNumber = value; }
		}

		[FieldValuesMember("ValuesOf_DeliveryMethodStr")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		[FieldDescription("@DELIVERYMETHOD@")]
		public string DeliveryMethodStr
		{
			get { return this.deliveryMethod; }
			set { this.deliveryMethod = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public EnumDeliveryMethod DeliveryMethod
		{
			get 
			{ 
				EnumDeliveryMethod method;
				
				switch (this.deliveryMethod)
				{
					case "E":
						method = EnumDeliveryMethod.Email;
						break;
					case "M":
						method = EnumDeliveryMethod.Mail;
						break;
					case "F":
						method = EnumDeliveryMethod.Fax;
						break;
					case "N":
					default:
						method = EnumDeliveryMethod.None;
						break;
				}
				return method;
			}
			set 
			{ 
				switch (value)
				{
					case EnumDeliveryMethod.Email:
						this.deliveryMethod = "E";
						break;
					case EnumDeliveryMethod.Fax:
						this.deliveryMethod = "F";
						break;
					case EnumDeliveryMethod.Mail:
						this.deliveryMethod = "M";
						break;
					default:
						this.deliveryMethod = "N";
						break;
					
				}
			}
		}

		public string Fmt_DeliveryMethod
		{
			get { return this.DeliveryMethod.ToString(); }
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int addressID)
		{
			return base.Load(addressID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int addressID)
		{
			base.Delete(addressID);		
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			base.Save();		
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			return
				this.line1 + "\r\n" +
				this.line2 + "\r\n" + 
				this.City + ", " + this.County + ", " + this.State + ", " + this.Zip + "\r\n" +
				this.Country + "\r\n" +
				this.Fmt_DeliveryMethod;
		}

		/// <summary>
		/// Returns all possible values and descriptions for delivery methods
		/// </summary>
		public string[,] ValuesOf_DeliveryMethodStr
		{
			get
			{
				return new string[,] { 
					{ "E", EnumDeliveryMethod.Email.ToString() },
					{ "F", EnumDeliveryMethod.Fax.ToString() },
					{ "M", EnumDeliveryMethod.Mail.ToString() } }; // return possible field values
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, MaxLength=5)]
		public string PhoneExt1
		{
			get { return this.phoneExt1; }
			set { this.phoneExt1 = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, MaxLength=5)]
		public string PhoneExt2
		{
			get { return this.phoneExt2; }
			set { this.phoneExt2 = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, MaxLength=5)]
		public string PhoneExt3
		{
			get { return this.phoneExt3; }
			set { this.phoneExt3 = value; }
		}

		/// <summary>
		/// Parent Organization that contains this object
		/// </summary>
		public Organization ParentOrganization
		{
			get { return this.ParentDataObject as Organization; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Subscriber */ }
		}

		/// <summary>
		/// Parent Subscriber that contains this object
		/// </summary>
		public Subscriber ParentSubscriber
		{
			get { return this.ParentDataObject as Subscriber; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Subscriber */ }
		}

		/// <summary>
		/// Parent Patient that contains this object
		/// </summary>
		public Patient ParentPatient
		{
			get { return this.ParentDataObject as Patient; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}
		
		/// <summary>
		/// Parent Patient that contains this object
		/// </summary>
		public Network ParentNetwork 
		{
			get { return this.ParentDataObject as Network; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Patient */ }
		}

		//[ValidatorMember("Vld_Email")]
		[ControlType(Macro=EnumControlTypeMacros.Email, MaxLength=255, 
			 ClientScriptForConditionalRequired="GetElemValue('AddressControlDeliveryMethodStr') == 'E'", IsRequired=true)]
		[FieldDescription("@EMAIL@")]
		public string Email
		{
			get { return this.email; }
			set { this.email = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.URL, MaxLength=255)]
		public string URL
		{
			get { return this.uRL; }
			set { this.uRL = value; }
		}

		/// <summary>
		/// Parent InsurancePayor that contains this object
		/// </summary>
		public InsurancePayor ParentInsurancePayor
		{
			get { return this.ParentDataObject as InsurancePayor; }
			set { this.ParentDataObject = value; /* parent is set when contained by a InsurancePayor */ }
		}

		/// <summary>
		/// Parent Contact that contains this object
		/// </summary>
		public Contact ParentContact
		{
			get { return this.ParentDataObject as Contact; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Contact */ }
		}

		/// <summary>
		/// Parent Plan that contains this object
		/// </summary>
		public Plan ParentPlan
		{
			get { return this.ParentDataObject as Plan; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Plan */ }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Line3
		{
			get { return this.line3; }
			set { this.line3 = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, MaxLength=5)]
		public string FaxExtension
		{
			get { return this.faxExtension; }
			set { this.faxExtension = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USPhoneNumber, MaxLength=15)]
		public string BeeperNumber
		{
			get { return this.beeperNumber; }
			set { this.beeperNumber = value; }
		}

		/// <summary>
		/// USE CASE ID: UC3.5
		/// TITLE: CREATE PATIENT COVERAGE
		/// REQUIREMENT ID: 1.8.4.6,1.8.4.7, 1.8.4.8
		/// Step 4.a.i
		/// </summary>
		/// <param name="elig"></param>
		public void ImportFromEligibility(Eligibility elig)
		{
			this.Line1 = elig.MemberAddress1;
			this.Line2 = elig.MemberAddress2;
			this.Line3 = elig.MemberAddress3;
			this.City = elig.MemberCity;
			this.County = elig.MemberCounty;
			this.Country = elig.MemberCountry;
			this.Zip = elig.MemberPostalCode;
			this.PhoneNumber1 = elig.HomePhoneNumber;
			this.PhoneNumber2 = elig.WorkPhoneNumber;
			this.PhoneExt2 = elig.WorkPhoneExtension;
			this.Email = elig.Email;
			this.FaxNumber = elig.Fax;
			this.FaxExtension = elig.FaxExtension;
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string BeeperExt
		{
			get { return this.beeperExt; }
			set { this.beeperExt = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}

		public System.Guid Uuid
		{
			get { return this.uuid; }
			set { this.uuid = value; }
		}

		/*[GenericScript("Vld_Email", "@DeliveryMethodStr@ == 'M' ? @Email@ != '' : true")]
		public string Vld_Email
		{
			get
			{
				//String.Format("{0} ? {1} : true")
				return "Email is required!"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
				if (false) // server side validation code here
					throw new ValidationException("Email", "Validation failed for Email");  // throw validation exception if failed (don't set the member) 
			}
		}*/

	}
}
