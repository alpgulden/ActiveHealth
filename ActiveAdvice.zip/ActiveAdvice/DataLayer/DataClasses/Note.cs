using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Note]
	/// </summary>
	[SPAutoGen("usp_SearchNotes","SearchByArgs.sptpl","patientId, eventID, problemId, referralId, physicianReviewID, cMSId, referralDetailID, physicianReviewDetailID, physicianRevIndPhyReviewID, noteTypeID, createdBy")]
	[SPInsert("usp_InsertNote")]
	[SPUpdate("usp_UpdateNote")]
	[SPDelete("usp_DeleteNote")]
	[SPLoad("usp_LoadNote")]
	[TableMapping("Note","noteID")]
	public class Note : BaseData
	{
		[NonSerialized]
		private NoteCollection parentNoteCollection;
		[ColumnMapping("NoteID",StereoType=DataStereoType.FK)]
		private int noteID;
		[ColumnMapping("PatientId")]
		private int patientId;
		[ColumnMapping("EventID")]
		private int eventID;
		[ColumnMapping("ProblemId")]
		private int problemId;
		[ColumnMapping("ReferralId")]
		private int referralId;
		[ColumnMapping("PhysicianReviewID")]
		private int physicianReviewID;
		[ColumnMapping("CMSId")]
		private int cMSId;
		[ColumnMapping("ReferralDetailID")]
		private int referralDetailID;
		[ColumnMapping("PhysicianReviewDetailID")]
		private int physicianReviewDetailID;
		[ColumnMapping("PhysicianRevIndPhyReviewID")]
		private int physicianRevIndPhyReviewID;
		[ColumnMapping("NoteDate")]
		private DateTime noteDate;
		[ColumnMapping("NoteTerminationReasonID")]
		private int noteTerminationReasonID;
		[ColumnMapping("NoteTypeID")]
		private int noteTypeID;
		[ColumnMapping("MedicalNoteBrief")]
		private string medicalNoteBrief;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("TerminatedBy")]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("AppendID")]
		private int appendID;
		[ColumnMapping("AppendDate")]
		private DateTime appendDate;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		private NotePageCollection notePages;
	
		public Note()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Create not for the given Patient
		/// </summary>
		/// <param name="patient"></param>
		/// <param name="initNew"></param>
		public Note(Patient patient, bool initNew)
		{
			if (initNew)
				this.NewRecord();
			this.patientId = patient.PatientId;
		}

		/*public Note(Event eventObj, bool initNew)
		{
			if (initNew)
				this.NewRecord();
			this.eventID = eventObj;
		}*/

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NoteID
		{
			get { return this.noteID; }
			set { this.noteID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientId
		{
			get { return this.patientId; }
			set { this.patientId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProblemId
		{
			get { return this.problemId; }
			set { this.problemId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralId
		{
			get { return this.referralId; }
			set { this.referralId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PhysicianReviewID
		{
			get { return this.physicianReviewID; }
			set { this.physicianReviewID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSId
		{
			get { return this.cMSId; }
			set { this.cMSId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PhysicianReviewDetailID
		{
			get { return this.physicianReviewDetailID; }
			set { this.physicianReviewDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PhysicianRevIndPhyReviewID
		{
			get { return this.physicianRevIndPhyReviewID; }
			set { this.physicianRevIndPhyReviewID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime NoteDate
		{
			get { return this.noteDate; }
			set { this.noteDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NoteTerminationReasonID
		{
			get { return this.noteTerminationReasonID; }
			set { this.noteTerminationReasonID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int NoteTypeID
		{
			get { return this.noteTypeID; }
			set { this.noteTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=128)]
		public string MedicalNoteBrief
		{
			get { return this.medicalNoteBrief; }
			set { this.medicalNoteBrief = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AppendID
		{
			get { return this.appendID; }
			set { this.appendID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AppendDate
		{
			get { return this.appendDate; }
			set { this.appendDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int noteID)
		{
			return base.Load(noteID);
		}

		/// <summary>
		/// Parent NoteCollection that contains this element
		/// </summary>
		public NoteCollection ParentNoteCollection
		{
			get
			{
				return this.parentNoteCollection;
			}
			set
			{
				this.parentNoteCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child NotePages mapped to related rows of table NotePage where [NoteID] = [NoteID]
		/// </summary>
		[SPLoadChild("usp_LoadNotePages", "noteID")]
		public NotePageCollection NotePages
		{
			get { return this.notePages; }
			set
			{
				this.notePages = value;
				if (value != null)
					value.ParentNote = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the NotePages collection
		/// </summary>
		public void LoadNotePages(bool forceReload)
		{
			this.notePages = (NotePageCollection)NotePageCollection.LoadChildCollection("NotePages", this, typeof(NotePageCollection), notePages, forceReload, null);
		}

		/// <summary>
		/// Saves the NotePages collection
		/// </summary>
		public void SaveNotePages()
		{
			NotePageCollection.SaveChildCollection(this.notePages, true);
		}

		/// <summary>
		/// Synchronizes the NotePages collection
		/// </summary>
		public void SynchronizeNotePages()
		{
			NotePageCollection.SynchronizeChildCollection(this.notePages, true);
		}
	}

	/// <summary>
	/// Strongly typed collection of Note objects
	/// </summary>
	[ElementType(typeof(Note))]
	public class NoteCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Note elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNoteCollection = this;
			else
				elem.ParentNoteCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Note elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Note this[int index]
		{
			get
			{
				return (Note)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Note)oldValue, false);
			SetParentOnElem((Note)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchNotes(int maxRecords, Note searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchNotes", maxRecords, this, searcher, false);
		}
	}
}
