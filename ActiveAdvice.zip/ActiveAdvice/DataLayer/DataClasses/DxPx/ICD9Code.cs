using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ICD9Code]
	/// 
	/// ICD9 code can be either Dx or Px.
	/// </summary>
	[SPAutoGen("usp_GetLinkedICD9CodesForCPTCode","SelectRelatedFromLinkedTable2ColFK.sptpl","ICD9toCPTMapping, iCD9Code, diagOrProc, iCD9Code, diagOrProc, cPTCode")]
	[SPAutoGen("usp_SearchICD9Codes",
		"SearchByArgs.sptpl","iCD9Code, diagOrProc, shortTitle",
		InjectPreOperation="SET ROWCOUNT @rowCount  -- limit the records returned",
		InjectWhere="AND (@sexFlag is NULL OR [ICD9Code].[SexSpecificFlag] is null OR [ICD9Code].[SexSpecificFlag]=@sexFlag) AND ([ICD9Code].[AgeSpecificFlag] is null OR [ICD9Code].[AgeSpecificFlag] in (@ageFlagB,@ageFlagA,@ageFlagM,@ageFlagP) ) AND  [ICD9Code].[ICD9Code] >= @startCode AND [ICD9Code].[DiagOrProc] >= @startDiagOrProc -- page start",
		InjectParameters="@rowCount int, @startCode varchar(20), @startDiagOrProc varchar(1), @sexFlag char(1), @ageFlagB char(1), @ageFlagA char(1), @ageFlagM char(1), @ageFlagP char(1)")]
	[SPAutoGen("usp_GetAllICD9Codes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertICD9Code")]
	[SPUpdate("usp_UpdateICD9Code")]
	[SPDelete("usp_DeleteICD9Code")]
	[SPLoad("usp_LoadICD9Code")]
	[TableMapping("ICD9Code","iCD9Code,diagOrProc",true)]
	public class ICD9Code : BaseDxPx
	{
		[NonSerialized]
		private ICD9CodeCollection parentICD9CodeCollection;
		[ColumnMapping("ICD9Code")]
		private string iCD9Code;
		[ColumnMapping("DiagOrProc")]
		private string diagOrProc;
		[ColumnMapping("Incomplete")]
		private bool incomplete;
		[ColumnMapping("CodeCategory")]
		private int codeCategory;
		[ColumnMapping("SexSpecificFlag")]
		private string sexSpecificFlag;
		[ColumnMapping("ShortTitle")]
		private string shortTitle;
		[ColumnMapping("LongTitle")]
		private string longTitle;
		[ColumnMapping("ProcedureClass")]
		private int procedureClass;
		[ColumnMapping("MajorDiagCatg")]
		private int majorDiagCatg;
		[ColumnMapping("ComorbidityFlag")]
		private int comorbidityFlag;
		[ColumnMapping("ComorbidityCheckCode")]
		private int comorbidityCheckCode;
		[ColumnMapping("AgeSpecificFlag")]
		private string ageSpecificFlag;
		[ColumnMapping("HCFADefined")]
		private bool hCFADefined;
		[ColumnMapping("LOSGroup")]
		private string lOSGroup;
		[ColumnMapping("ListABGroup")]
		private string listABGroup;
		[ColumnMapping("ICD9Tip")]
		private string iCD9Tip;
	
		public ICD9Code()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string Code
		{
			get { return this.iCD9Code; }
			set { this.iCD9Code = value; }
		}

		public ICD9Code(string iCD9Code, string diagOrProc, string shortTitle, string longTitle)
		{
			this.NewRecord(); // initialize record state
			this.iCD9Code = iCD9Code;
			this.diagOrProc = diagOrProc;
			this.shortTitle = shortTitle;
			this.longTitle = longTitle;
		}

		public ICD9Code(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		#region BaseDxPx overridables

		public override string CodeType
		{
			get { return CodeTypeICD9; }
			set { throw new ActiveAdviceException(AAExceptionAction.None, "You can't set code type for ICD9"); }
		}

		public override string DxOrPx
		{
			get { return this.diagOrProc; }
			set { this.diagOrProc = value; }		// Setting the diag/proc is valid for ICD9 codes
		}

		public override string CodeDescription
		{
			get { return this.shortTitle; }
			set { this.shortTitle = value; }
		}

		public override string CodeLongDescription
		{
			get { return this.longTitle; }
			set { this.longTitle = value; }
		}

		public override string CodeValue
		{
			get { return this.Code; }
			set { this.Code = value; }
		}

		#endregion

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string DiagOrProc
		{
			get { return this.diagOrProc; }
			set { this.diagOrProc = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public override bool Incomplete
		{
			get { return this.incomplete; }
			set { this.incomplete = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CodeCategory
		{
			get { return this.codeCategory; }
			set { this.codeCategory = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string SexSpecificFlag
		{
			get { return this.sexSpecificFlag; }
			set { this.sexSpecificFlag = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string ShortTitle
		{
			get { return this.shortTitle; }
			set { this.shortTitle = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string LongTitle
		{
			get { return this.longTitle; }
			set { this.longTitle = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ProcedureClass
		{
			get { return this.procedureClass; }
			set { this.procedureClass = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MajorDiagCatg
		{
			get { return this.majorDiagCatg; }
			set { this.majorDiagCatg = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ComorbidityFlag
		{
			get { return this.comorbidityFlag; }
			set { this.comorbidityFlag = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ComorbidityCheckCode
		{
			get { return this.comorbidityCheckCode; }
			set { this.comorbidityCheckCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string AgeSpecificFlag
		{
			get { return this.ageSpecificFlag; }
			set { this.ageSpecificFlag = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool HCFADefined
		{
			get { return this.hCFADefined; }
			set { this.hCFADefined = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string LOSGroup
		{
			get { return this.lOSGroup; }
			set { this.lOSGroup = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=7)]
		public string ListABGroup
		{
			get { return this.listABGroup; }
			set { this.listABGroup = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string ICD9Tip
		{
			get { return this.iCD9Tip; }
			set { this.iCD9Tip = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public override bool Load(string iCD9Code)
		{
			return base.Load(iCD9Code, this.diagOrProc);
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(string iCD9Code, string diagOrProc)
		{
			return base.Load(iCD9Code, diagOrProc);
		}

		/// <summary>
		/// Parent ICD9CodeCollection that contains this element
		/// </summary>
		public ICD9CodeCollection ParentICD9CodeCollection
		{
			get
			{
				return this.parentICD9CodeCollection;
			}
			set
			{
				this.parentICD9CodeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Return all the mapped CPT codes for this ICD9 code
		/// </summary>
		/// <returns></returns>
		public CPTCodeCollection GetMappedCPTCodes()
		{
			if (this.iCD9Code != null && this.diagOrProc != null)
			{
				CPTCodeCollection cptcol = new CPTCodeCollection();
				if (cptcol.LoadLinkedCPTCodesForICD9Code(-1, this.iCD9Code, this.diagOrProc) > 0)
					return cptcol;
			}
			return null;
		}
	}

	/// <summary>
	/// Strongly typed collection of ICD9Code objects
	/// </summary>
	[ElementType(typeof(ICD9Code))]
	public class ICD9CodeCollection : BaseDxPxCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ICD9Code elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentICD9CodeCollection = this;
			else
				elem.ParentICD9CodeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ICD9Code elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ICD9Code this[int index]
		{
			get
			{
				return (ICD9Code)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ICD9Code)oldValue, false);
			SetParentOnElem((ICD9Code)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllICD9Codes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllICD9Codes", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchICD9Codes(int maxRecords, string startCode, string startDiagOrgProc, string iCD9Code, string diagOrProc, string shortTitle)
		{
			this.Clear();
			//this.SqlData.Connection.
			string sexFlag = null;
			string ageFlagB = null, ageFlagA = null, ageFlagM = null, ageFlagP = null;

			int patientAge = 0;
			if (this.patient != null)
			{
				sexFlag = this.patient.Gender;
				patientAge = this.patient.AgeYears;
			}
			
			if (patientAge < 1)		// Newborn
				ageFlagB = "B";

			if (patientAge >= 15)	// Adult
				ageFlagA = "A";

			if (sexFlag == GenderCode.Female && patientAge >= 12 && patientAge <= 55)		// Maternal
				ageFlagM = "M";

			if (patientAge >= 1 && patientAge <= 17)		// Pediatric
				ageFlagP = "P";
			
			return SqlData.SPExecReadCol("usp_SearchICD9Codes", -1, this, false, 
				new object[] { 
					maxRecords < 0 ? 0 : maxRecords,
					startCode, startDiagOrgProc,
					SQLDataDirect.MakeDBValue(sexFlag), 
					SQLDataDirect.MakeDBValue(ageFlagB), SQLDataDirect.MakeDBValue(ageFlagA), SQLDataDirect.MakeDBValue(ageFlagM), SQLDataDirect.MakeDBValue(ageFlagP),

					SQLDataDirect.MakeDBValue(iCD9Code),
					SQLDataDirect.MakeDBValue(diagOrProc),
					SQLDataDirect.MakeDBValue(shortTitle) });
		}

		#region BaseDxPxCollection overrides

		public override int Search(string code, string diagOrProc, string description)
		{
			return this.SearchICD9Codes(BaseDxPxCollection.MAXRECORDS, "", "", code, diagOrProc, description);
		}

		public override int SearchNext(string code,string diagOrProc, string description)
		{
			if (this.Count > 0)
			{
				ICD9Code last = this[this.Count - 1];
				return this.SearchICD9Codes(BaseDxPxCollection.MAXRECORDS, last.Code, last.DiagOrProc, code, diagOrProc, description);
			}
			return 0;
		}

		#endregion

		/// <summary>
		/// For a given CPT code, finds all the linked ICD9 codes and loads them into the collection.
		/// </summary>
		public int LoadLinkedICD9CodesForCPTCode(int maxRecords, string cPTCode)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetLinkedICD9CodesForCPTCode", maxRecords, this, false, new object[] { cPTCode });
		}


	}


// -------------------------------------------------------------------------------------------------

	/// <summary>
	/// This class defines a mom or baby code range.
	/// </summary>
	[SPAutoGen("usp_FindDiagOrProcsForMomBabyRanges","FindDiagProcMomBabyRange.sptpl","")]
	[SPInsert("usp_InsertMomBabyCode")]
	[SPUpdate("usp_UpdateMomBabyCode")]
	[SPDelete("usp_DeleteMomBabyCode")]
	[SPLoad("usp_LoadMomBabyCode")]
	[TableMapping("MomBabyCode","momBabyCodeID")]
	public class MomBabyCode : BaseData
	{
		[NonSerialized]
		private MomBabyCodeCollection parentMomBabyCodeCollection;
		[ColumnMapping("MomBabyCodeID",StereoType=DataStereoType.PK)]
		private int momBabyCodeID;
		[ColumnMapping("RangeDescription")]
		private string rangeDescription;
		[ColumnMapping("DiagOrProc")]
		private string diagOrProc;
		[ColumnMapping("CodeType")]
		private string codeType;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("StartCode")]
		private string startCode;
		[ColumnMapping("EndCode")]
		private string endCode;
		[ColumnMapping("MomOrBaby")]
		private string momOrBaby;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;

		private DateTime termDateWhenLoaded;	// keep track of the change in term date.

		public MomBabyCode()
		{
		}

		/// <summary>
		/// Create a new mom or baby range.
		/// </summary>
		/// <param name="momOrBaby"></param>
		/// <param name="rangeDescription"></param>
		/// <param name="codeType"></param>
		/// <param name="startCode"></param>
		/// <param name="endCode"></param>
		public MomBabyCode(string momOrBaby, string rangeDescription, string codeType, string startCode, string endCode)
		{
			this.NewRecord();
			this.momOrBaby = momOrBaby;
			this.rangeDescription = rangeDescription;
			this.codeType = codeType;
			this.startCode = startCode;
			this.endCode = endCode;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int MomBabyCodeID
		{
			get { return this.momBabyCodeID; }
			set { this.momBabyCodeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string RangeDescription
		{
			get { return this.rangeDescription; }
			set { this.rangeDescription = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string DiagOrProc
		{
			get { return this.diagOrProc; }
			set { this.diagOrProc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string CodeType
		{
			get { return this.codeType; }
			set { this.codeType = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=16)]
		public string StartCode
		{
			get { return this.startCode; }
			set { this.startCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=16)]
		public string EndCode
		{
			get { return this.endCode; }
			set { this.endCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string MomOrBaby
		{
			get { return this.momOrBaby; }
			set { this.momOrBaby = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int momBabyCodeID)
		{
			return base.Load(momBabyCodeID);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.effectiveDate = DateTime.Today;
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}
			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Parent MomBabyCodeCollection that contains this element
		/// </summary>
		public MomBabyCodeCollection ParentMomBabyCodeCollection
		{
			get
			{
				return this.parentMomBabyCodeCollection;
			}
			set
			{
				this.parentMomBabyCodeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of MomBabyCode objects
	/// </summary>
	[ElementType(typeof(MomBabyCode))]
	public class MomBabyCodeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MomBabyCode elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMomBabyCodeCollection = this;
			else
				elem.ParentMomBabyCodeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MomBabyCode elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MomBabyCode this[int index]
		{
			get
			{
				return (MomBabyCode)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MomBabyCode)oldValue, false);
			SetParentOnElem((MomBabyCode)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}


		/// <summary>
		/// Load diagnoses that reside in the Mom-Baby code ranges for the given date.
		/// </summary>
		public bool FindMomBabyRanges(int eventID, int referralID, DateTime date, string dxOrPx, string momOrBaby)
		{
			return 
				Convert.ToBoolean(
				SqlData.SPExecScalar("usp_FindDiagOrProcsForMomBabyRanges",
				new object[] 
					{
						SQLDataDirect.MakeDBValue(eventID, (int)0), 
						SQLDataDirect.MakeDBValue(referralID, (int)0), 
						dxOrPx,
						momOrBaby,
						date
					})
				);
		}

		public string FindMomBabyRanges(int eventID, int referralID, DateTime date, string dxOrPx, bool checkMom, bool checkBaby)
		{
			string mb = null;

			if (checkMom)
				if (FindMomBabyRanges(eventID, referralID, date, dxOrPx, "M"))
					mb += "M";
			if (checkBaby)
				if (FindMomBabyRanges(eventID, referralID, date, dxOrPx, "B"))
					mb += "B";

			return mb;
		}

		public string FindMomBabyRangesForDiag(int eventID, int referralID, DateTime date, bool checkMom, bool checkBaby)
		{
			return FindMomBabyRanges(eventID, referralID, date, BaseDxPx.DxPxDiagnostic, checkMom, checkBaby);
		}

		public string FindMomBabyRangesForProc(int eventID, int referralID, DateTime date, bool checkMom, bool checkBaby)
		{
			return FindMomBabyRanges(eventID, referralID, date, BaseDxPx.DxPxProcedure, checkMom, checkBaby);
		}

		/// <summary>
		/// Find Mom-baby code ranges for the given event.
		/// </summary>
		/// <returns></returns>
		public string FindMomBabyRanges(BaseForEventCMSReferral erc, bool checkMom, bool checkBaby)
		{
			int eventID, referralID;
			if (erc is Event)
			{
				eventID = erc.ID;
				referralID = 0;
			}
			else if (erc is Referral)
			{
				eventID = 0;
				referralID = erc.ID;
			}
			else
			{
				throw new ActiveAdviceException("ERC type not supported by FindMomBabyRanges");
			}

			string momBaby = FindMomBabyRangesForDiag(eventID, referralID, erc.ERCStartDate, checkMom, checkBaby);
			momBaby += FindMomBabyRangesForProc(eventID, referralID, erc.ERCStartDate, checkMom, checkBaby);
			return momBaby;
		}
	}

}
