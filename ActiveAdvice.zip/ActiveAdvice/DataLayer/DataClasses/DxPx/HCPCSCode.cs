using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [HCPCSCode]
	/// </summary>
	[SPAutoGen("usp_SearchHCPCSCodes","SearchByArgs.sptpl","hCPCSCode, shortTitle",
		InjectPreOperation="SET ROWCOUNT @rowCount  -- limit the records returned",
		InjectWhere="AND [HCPCSCode].[HCPCSCode] >= @startCode -- page start",
		InjectParameters="@rowCount int, @startCode varchar(20)")]
	[SPAutoGen("usp_GetAllHCPCSCodes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertHCPCSCode")]
	[SPUpdate("usp_UpdateHCPCSCode")]
	[SPDelete("usp_DeleteHCPCSCode")]
	[SPLoad("usp_LoadHCPCSCode")]
	[TableMapping("HCPCSCode","hCPCSCode",true)]
	public class HCPCSCode : BaseDxPx
	{
		[NonSerialized]
		private HCPCSCodeCollection parentHCPCSCodeCollection;
		[ColumnMapping("HCPCSCode")]
		private string hCPCSCode;
		[ColumnMapping("ShortTitle")]
		private string shortTitle;
		[ColumnMapping("LongTitle")]
		private string longTitle;
		[ColumnMapping("HCPCSCoverage")]
		private string hCPCSCoverage;
		[ColumnMapping("HCPCSStatus")]
		private string hCPCSStatus;
		[ColumnMapping("HCPCSTip")]
		private string hCPCSTip;
	
		public HCPCSCode()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string Code
		{
			get { return this.hCPCSCode; }
			set { this.hCPCSCode = value; }
		}

		public HCPCSCode(string hCPCSCode, string shortTitle, string longTitle)
		{
			this.NewRecord(); // initialize record state
			this.hCPCSCode = hCPCSCode;
			this.shortTitle = shortTitle;
			this.longTitle = longTitle;
		}

		public HCPCSCode(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		#region BaseDxPx overridables

		public override string CodeType
		{
			get { return CodeTypeHCPCS; }
			set { throw new ActiveAdviceException(AAExceptionAction.None, "You can't set code type for DSM4"); }
		}

		public override string DxOrPx
		{
			get { return DxPxProcedure; }
			set { throw new ActiveAdviceException(AAExceptionAction.None, "You can't set dx/px for HCPCS"); }
		}

		public override string CodeDescription
		{
			get { return this.shortTitle; }
			set { this.shortTitle = value; }
		}

		public override string CodeLongDescription
		{
			get { return this.longTitle; }
			set { this.longTitle = value; }
		}

		public override string CodeValue
		{
			get { return this.Code; }
			set { this.Code = value; }
		}

		public override bool Incomplete
		{
			get { return false; }
			set { }
		}

		#endregion

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string ShortTitle
		{
			get { return this.shortTitle; }
			set { this.shortTitle = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string LongTitle
		{
			get { return this.longTitle; }
			set { this.longTitle = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string HCPCSCoverage
		{
			get { return this.hCPCSCoverage; }
			set { this.hCPCSCoverage = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string HCPCSStatus
		{
			get { return this.hCPCSStatus; }
			set { this.hCPCSStatus = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string HCPCSTip
		{
			get { return this.hCPCSTip; }
			set { this.hCPCSTip = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public override bool Load(string hCPCSCode)
		{
			return base.Load(hCPCSCode);
		}

		/// <summary>
		/// Parent HCPCSCodeCollection that contains this element
		/// </summary>
		public HCPCSCodeCollection ParentHCPCSCodeCollection
		{
			get
			{
				return this.parentHCPCSCodeCollection;
			}
			set
			{
				this.parentHCPCSCodeCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of HCPCSCode objects
	/// </summary>
	[ElementType(typeof(HCPCSCode))]
	public class HCPCSCodeCollection : BaseDxPxCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(HCPCSCode elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentHCPCSCodeCollection = this;
			else
				elem.ParentHCPCSCodeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (HCPCSCode elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public HCPCSCode this[int index]
		{
			get
			{
				return (HCPCSCode)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((HCPCSCode)oldValue, false);
			SetParentOnElem((HCPCSCode)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllHCPCSCodes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllHCPCSCodes", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchHCPCSCodes(int maxRecords, string startCode, string hCPCSCode, string shortTitle)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchHCPCSCodes", -1, this, false, 
				new object[] { 
					maxRecords < 0 ? 0 : maxRecords,
					startCode,
					SQLDataDirect.MakeDBValue(hCPCSCode), 
					SQLDataDirect.MakeDBValue(shortTitle) });
		}

		#region BaseDxPxCollection overrides

		public override int Search(string code, string diagOrProc, string description)
		{
			// ignore diagOrProc, HCPCS is always procedure
			return this.SearchHCPCSCodes(BaseDxPxCollection.MAXRECORDS, "", code, description);
		}

		public override int SearchNext(string code, string diagOrProc, string description)
		{
			if (this.Count > 0)
			{
				HCPCSCode last = this[this.Count - 1];
				return this.SearchHCPCSCodes(BaseDxPxCollection.MAXRECORDS, last.Code, code, description);
			}
			return 0;
		}

		#endregion
	}
}
