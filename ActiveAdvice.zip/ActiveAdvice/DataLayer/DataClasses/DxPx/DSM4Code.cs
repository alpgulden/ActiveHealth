using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [DSM4Code]
	/// </summary>
	[SPAutoGen("usp_SearchDSM4Codes","SearchByArgs.sptpl","dSM4Code, shortTitle",
		InjectPreOperation="SET ROWCOUNT @rowCount  -- limit the records returned",
		InjectWhere="AND [DSM4Code].[DSM4Code] >= @startCode -- page start",
		InjectParameters="@rowCount int, @startCode varchar(20)")]
	[SPAutoGen("usp_GetAllDSM4Codes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertDSM4Code")]
	[SPUpdate("usp_UpdateDSM4Code")]
	[SPDelete("usp_DeleteDSM4Code")]
	[SPLoad("usp_LoadDSM4Code")]
	[TableMapping("DSM4Code","dSM4Code",true)]
	public class DSM4Code : BaseDxPx
	{
		[NonSerialized]
		private DSM4CodeCollection parentDSM4CodeCollection;
		[ColumnMapping("DSM4Code")]
		private string dSM4Code;
		[ColumnMapping("Incomplete")]
		private bool incomplete;
		[ColumnMapping("ShortTitle")]
		private string shortTitle;
		[ColumnMapping("LongTitle")]
		private string longTitle;
		[ColumnMapping("DSM4Tip")]
		private string dSM4Tip;
	
		public DSM4Code()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public DSM4Code(string dSM4Code, string shortTitle, string longTitle)
		{
			this.NewRecord(); // initialize record state
			this.dSM4Code = dSM4Code;
			this.shortTitle = shortTitle;
			this.longTitle = longTitle;
		}

		public DSM4Code(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		#region BaseDxPx overridables

		public override string CodeType
		{
			get { return CodeTypeDSM4; }
			set { throw new ActiveAdviceException(AAExceptionAction.None, "You can't set code type for DSM4"); }
		}

		public override string DxOrPx
		{
			get { return DxPxDiagnostic; }
			set { throw new ActiveAdviceException(AAExceptionAction.None, "You can't set dx/px for DSM4"); }
		}

		public override string CodeDescription
		{
			get { return this.shortTitle; }
			set { this.shortTitle = value; }
		}

		public override string CodeLongDescription
		{
			get { return this.longTitle; }
			set { this.longTitle = value; }
		}

		public override string CodeValue
		{
			get { return this.Code; }
			set { this.Code = value; }
		}

		#endregion

		[ControlType(EnumControlTypes.TextBox)]
		public string Code
		{
			get { return this.dSM4Code; }
			set { this.dSM4Code = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public override bool Incomplete
		{
			get { return this.incomplete; }
			set { this.incomplete = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string ShortTitle
		{
			get { return this.shortTitle; }
			set { this.shortTitle = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string LongTitle
		{
			get { return this.longTitle; }
			set { this.longTitle = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string DSM4Tip
		{
			get { return this.dSM4Tip; }
			set { this.dSM4Tip = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public override bool Load(string dSM4Code)
		{
			return base.Load(dSM4Code);
		}

		/// <summary>
		/// Parent DSM4CodeCollection that contains this element
		/// </summary>
		public DSM4CodeCollection ParentDSM4CodeCollection
		{
			get
			{
				return this.parentDSM4CodeCollection;
			}
			set
			{
				this.parentDSM4CodeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of DSM4Code objects
	/// </summary>
	[ElementType(typeof(DSM4Code))]
	public class DSM4CodeCollection : BaseDxPxCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(DSM4Code elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentDSM4CodeCollection = this;
			else
				elem.ParentDSM4CodeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (DSM4Code elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public DSM4Code this[int index]
		{
			get
			{
				return (DSM4Code)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((DSM4Code)oldValue, false);
			SetParentOnElem((DSM4Code)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllDSM4Codes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllDSM4Codes", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchDSM4Codes(int maxRecords, string startCode, string dSM4Code, string shortTitle)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchDSM4Codes", -1, this, false, 
				new object[] { 
					maxRecords < 0 ? 0 : maxRecords,
					startCode,
					SQLDataDirect.MakeDBValue(dSM4Code), 
					SQLDataDirect.MakeDBValue(shortTitle) });
		}

		#region BaseDxPxCollection overrides

		public override int Search(string code, string diagOrProc, string description)
		{
			// ignore diagOrProc, DSM4 is always diagnostic
			return this.SearchDSM4Codes(BaseDxPxCollection.MAXRECORDS, "", code, description);
		}

		public override int SearchNext(string code, string diagOrProc, string description)
		{
			if (this.Count > 0)
			{
				DSM4Code last = this[this.Count - 1];
				//return this.SearchICD9Codes(BaseDxPxCollection.MAXRECORDS, last.Code, last.DiagOrProc, code, diagOrProc, description);
				return this.SearchDSM4Codes(BaseDxPxCollection.MAXRECORDS, last.Code, code, description);
			}
			return 0;	
		}

		#endregion

	}
}
