using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [DentalCode]
	/// </summary>
	[SPAutoGen("usp_SearchDentalCodes","SearchByArgs.sptpl","dentalCode, shortTitle",
		InjectPreOperation="SET ROWCOUNT @rowCount  -- limit the records returned",
		InjectWhere="AND [DentalCode].[DentalCode] >= @startCode -- page start",
		InjectParameters="@rowCount int, @startCode varchar(20)")]
	[SPAutoGen("usp_GetAllDentalCodes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertDentalCode")]
	[SPUpdate("usp_UpdateDentalCode")]
	[SPDelete("usp_DeleteDentalCode")]
	[SPLoad("usp_LoadDentalCode")]
	[TableMapping("DentalCode","dentalCode",true)]
	public class DentalCode : BaseDxPx
	{
		[NonSerialized]
		private DentalCodeCollection parentDentalCodeCollection;
		[ColumnMapping("DentalCode")]
		private string dentalCode;
		[ColumnMapping("ShortTitle")]
		private string shortTitle;
		[ColumnMapping("LongTitle")]
		private string longTitle;
		[ColumnMapping("CRIGroupID")]
		private int cRIGroupID;
		[ColumnMapping("DentalTip")]
		private string dentalTip;
	
		public DentalCode()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string Code
		{
			get { return this.dentalCode; }
			set { this.dentalCode = value; }
		}

		public DentalCode(string dentalCode, string shortTitle, string longTitle)
		{
			this.NewRecord(); // initialize record state
			this.dentalCode = dentalCode;
			this.shortTitle = shortTitle;
			this.longTitle = longTitle;
		}

		public DentalCode(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		#region BaseDxPx overridables

		public override string CodeType
		{
			get { return CodeTypeDENTAL; }
			set { throw new ActiveAdviceException(AAExceptionAction.None, "You can't set code type for DENTAL"); }
		}

		public override string DxOrPx
		{
			get { return DxPxProcedure; }
			set { throw new ActiveAdviceException(AAExceptionAction.None, "You can't set dx/px for DENTAL"); }
		}

		public override string CodeDescription
		{
			get { return this.shortTitle; }
			set { this.shortTitle = value; }
		}

		public override string CodeLongDescription
		{
			get { return this.longTitle; }
			set { this.longTitle = value; }
		}

		public override string CodeValue
		{
			get { return this.Code; }
			set { this.Code = value; }
		}

		public override bool Incomplete
		{
			get { return false; }
			set { }
		}


		#endregion

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string ShortTitle
		{
			get { return this.shortTitle; }
			set { this.shortTitle = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string LongTitle
		{
			get { return this.longTitle; }
			set { this.longTitle = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CRIGroupID
		{
			get { return this.cRIGroupID; }
			set { this.cRIGroupID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string DentalTip
		{
			get { return this.dentalTip; }
			set { this.dentalTip = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public override bool Load(string dentalCode)
		{
			return base.Load(dentalCode);
		}

		/// <summary>
		/// Parent DentalCodeCollection that contains this element
		/// </summary>
		public DentalCodeCollection ParentDentalCodeCollection
		{
			get
			{
				return this.parentDentalCodeCollection;
			}
			set
			{
				this.parentDentalCodeCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of DentalCode objects
	/// </summary>
	[ElementType(typeof(DentalCode))]
	public class DentalCodeCollection : BaseDxPxCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(DentalCode elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentDentalCodeCollection = this;
			else
				elem.ParentDentalCodeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (DentalCode elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public DentalCode this[int index]
		{
			get
			{
				return (DentalCode)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((DentalCode)oldValue, false);
			SetParentOnElem((DentalCode)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllDentalCodes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllDentalCodes", maxRecords, this, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchDentalCodes(int maxRecords, string startCode, string dentalCode, string shortTitle)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchDentalCodes", -1, this, false, 
				new object[] { 
					maxRecords < 0 ? 0 : maxRecords,
					startCode,
					SQLDataDirect.MakeDBValue(dentalCode), 
					SQLDataDirect.MakeDBValue(shortTitle) });
		}

		#region BaseDxPxCollection overrides

		public override int Search(string code, string diagOrProc, string description)
		{
			// ignore diagOrProc, DENTAL is always procedure
			return this.SearchDentalCodes(BaseDxPxCollection.MAXRECORDS, "", code, description);
		}

		public override int SearchNext(string code, string diagOrProc, string description)
		{
			if (this.Count > 0)
			{
				DentalCode last = this[this.Count - 1];
				return this.SearchDentalCodes(BaseDxPxCollection.MAXRECORDS, last.Code, code, description);
			}
			return 0;	
		}

		#endregion

	}
}
