using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ICD9toCPTMapping]
	/// </summary>
	[SPAutoGen("usp_GetCPTCodeMappingsForICD9Code","SelectAllByGivenArgs.sptpl","iCD9Code, diagOrProc")]
	[SPAutoGen("usp_GetICD9CodeMappingsForCPTCode","SelectAllByGivenArgs.sptpl","cPTCode")]
	[SPInsert("usp_InsertICD9toCPTMapping")]
	[SPUpdate("usp_UpdateICD9toCPTMapping")]
	[SPDelete("usp_DeleteICD9toCPTMapping")]
	[SPLoad("usp_LoadICD9toCPTMapping")]
	[TableMapping("ICD9toCPTMapping","iCD9Code,diagOrProc,cPTCode",true)]
	public class ICD9toCPTMapping : BaseData
	{
		[NonSerialized]
		private ICD9toCPTMappingCollection parentICD9toCPTMappingCollection;
		[ColumnMapping("ICD9Code")]
		private string iCD9Code;
		[ColumnMapping("DiagOrProc")]
		private string diagOrProc;
		[ColumnMapping("CPTCode")]
		private string cPTCode;
		[ColumnMapping("CPT_Indicator")]
		private string cptIndicator;
	
		public ICD9toCPTMapping()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ICD9toCPTMapping(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public ICD9toCPTMapping(string iCD9Code, string diagOrProc, string cPTCode)
		{
			this.NewRecord(); // initialize record state
			this.iCD9Code = iCD9Code;
			this.diagOrProc = diagOrProc;
			this.cPTCode = cPTCode;
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string ICD9Code
		{
			get { return this.iCD9Code; }
			set { this.iCD9Code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string DiagOrProc
		{
			get { return this.diagOrProc; }
			set { this.diagOrProc = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=5)]
		public string CPTCode
		{
			get { return this.cPTCode; }
			set { this.cPTCode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string CptIndicator
		{
			get { return this.cptIndicator; }
			set { this.cptIndicator = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(string iCD9Code)
		{
			return base.Load(iCD9Code);
		}

		/// <summary>
		/// Parent ICD9toCPTMappingCollection that contains this element
		/// </summary>
		public ICD9toCPTMappingCollection ParentICD9toCPTMappingCollection
		{
			get
			{
				return this.parentICD9toCPTMappingCollection;
			}
			set
			{
				this.parentICD9toCPTMappingCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Get the mapped ICD9 code.
		/// </summary>
		/// <returns></returns>
		public ICD9Code GetMappedICD9Code()
		{
			ICD9Code code = new ICD9Code();
			if (code.Load(this.iCD9Code, this.diagOrProc))
				return code;
			return null;
		}

		/// <summary>
		/// Get the mapped CPT code.
		/// </summary>
		/// <returns></returns>
		public CPTCode GetMappedCPTCode()
		{
			CPTCode code = new CPTCode();
			if (code.Load(this.cPTCode))
				return code;
			return null;
		}

	}

	/// <summary>
	/// Strongly typed collection of ICD9toCPTMapping objects
	/// </summary>
	[ElementType(typeof(ICD9toCPTMapping))]
	public class ICD9toCPTMappingCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ICD9toCPTMapping elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentICD9toCPTMappingCollection = this;
			else
				elem.ParentICD9toCPTMappingCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ICD9toCPTMapping elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ICD9toCPTMapping this[int index]
		{
			get
			{
				return (ICD9toCPTMapping)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ICD9toCPTMapping)oldValue, false);
			SetParentOnElem((ICD9toCPTMapping)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Load the ICD9 mappings corresponding to the given CPT code
		/// </summary>
		public int LoadICD9CodeMappingsForCPTCode(int maxRecords, string cPTCode)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetICD9CodeMappingsForCPTCode", maxRecords, this, false, new object[] { cPTCode });
		}

		/// <summary>
		/// Load the CPT mappings corresponding to the given ICD9 code
		/// </summary>
		public int LoadCPTCodeMappingsForICD9Code(int maxRecords, string iCD9Code)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetCPTCodeMappingsForICD9Code", maxRecords, this, false, new object[] { iCD9Code, "P" });	// the mapping is always a Procedure
		}
	}
}
