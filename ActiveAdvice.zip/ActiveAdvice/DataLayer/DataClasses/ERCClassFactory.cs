using System;

using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Creates either Event, Referral and CMS for the given ERC type.
	/// </summary>
	public class ERCClassFactory
	{
		public static BaseForEventCMSReferral CreateERC(EnumERCType ercType, Patient patient, bool initNew)
		{
			switch (ercType)
			{
				case EnumERCType.Event:
					return new Event(patient, initNew);
				case EnumERCType.CMS:
					return new CMS(initNew, patient);
				case EnumERCType.Referral:
					return new Referral(initNew);
				default:
					throw new ActiveAdviceException(AAExceptionAction.None, "Unknown ERC type specified to ERCClassFactory");
			}
		}

		public static BaseForEventCMSReferral CreateERCAndLoad(EnumERCType ercType, Patient patient, int ercID)
		{
			BaseForEventCMSReferral erc = CreateERC(ercType, patient, false);
			if (erc.LoadERC(ercID))
				return erc;
			else
				return null;
		}

	}
}
