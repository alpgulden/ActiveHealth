using System;

namespace ActiveAdvice.DataLayer
{

	public enum EntityType
	{
		Provider,
		Facility,
		GroupPractice,
		Network,
		Plan
	}

	public enum ContactOwnerType
	{
		Patient = 1,
        Organization = 2,
		ProviderLocation = 3,
		FacilityLocation = 4,
		GroupPracticeLocation = 5,
		Plan = 6,
		InsurancePayor = 7,
		Network = 8
	}


	/// <summary>
	/// Genger code is used in Gender fields. Instead of directly typing
	/// strings, you can use this class' constants like:  GenderCode.Male.
	/// </summary>
	public class GenderCode
	{
		public const string Male = "M";
		public const string Female = "F";

		//public static string Male = "M";
		//public static string Female = "F";
	}

}
