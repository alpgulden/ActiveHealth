using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LengthOfStayRegions]
	/// </summary>
	[SPAutoGen("usp_GetAllLengthOfStayRegions","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetLengthOfStayRegionsByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertLengthOfStayRegion")]
	[SPUpdate("usp_UpdateLengthOfStayRegion")]
	[SPDelete("usp_DeleteLengthOfStayRegion")]
	[SPLoad("usp_LoadLengthOfStayRegion")]
	[TableMapping("LengthOfStayRegion","hciaRegionid")]
	public class LengthOfStayRegion : BaseLookupWithCode
	{
		[NonSerialized]
		private LengthOfStayRegionCollection parentLengthOfStayRegionCollection;
		[ColumnMapping("HCIA_RegionId",StereoType=DataStereoType.FK)]
		private int hciaRegionid;
		[ColumnMapping("HCIA_Region")]
		private string hciaRegion;
		[ColumnMapping("Note")]
		private string note;
	
		public LengthOfStayRegion()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int HciaRegionid
		{
			get { return this.hciaRegionid; }
			set { this.hciaRegionid = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=1)]
		public string HciaRegion
		{
			get { return this.hciaRegion; }
			set { this.hciaRegion = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		/// <summary>
		/// Parent LengthOfStayRegionCollection that contains this element
		/// </summary>
		public LengthOfStayRegionCollection ParentLengthOfStayRegionCollection
		{
			get
			{
				return this.parentLengthOfStayRegionCollection;
			}
			set
			{
				this.parentLengthOfStayRegionCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of LengthOfStayRegion objects
	/// </summary>
	[ElementType(typeof(LengthOfStayRegion))]
	public class LengthOfStayRegionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LengthOfStayRegion elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLengthOfStayRegionCollection = this;
			else
				elem.ParentLengthOfStayRegionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LengthOfStayRegion elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LengthOfStayRegion this[int index]
		{
			get
			{
				return (LengthOfStayRegion)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LengthOfStayRegion)oldValue, false);
			SetParentOnElem((LengthOfStayRegion)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadLengthOfStayRegionsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetLengthOfStayRegionsByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared LengthOfStayRegionCollection which is cached in NSGlobal
		/// </summary>
		public static LengthOfStayRegionCollection ActiveLengthOfStayRegions
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LengthOfStayRegionCollection col = (LengthOfStayRegionCollection)NSGlobal.EnsureCachedObject("ActiveLengthOfStayRegions", typeof(LengthOfStayRegionCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadLengthOfStayRegionsByActive(-1, true);
				}
				return col;
			}
		}
	}
}