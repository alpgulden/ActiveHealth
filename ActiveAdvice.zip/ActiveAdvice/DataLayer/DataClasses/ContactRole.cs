using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ContactRoles]
	/// </summary>
	[SPDelete("usp_DeleteContactRole")]
	[SPInsert("usp_InsertContactRole")]
	[SPUpdate("usp_UpdateContactRole")]
	[SPLoad("usp_LoadContactRole")]
	[TableMapping("ContactRole","contactID,roleID",true)]
	public class ContactRole : BaseData
	{
		[NonSerialized]
		private ContactRoleCollection parentContactRoleCollection;
		[ColumnMapping("ContactID",StereoType=DataStereoType.FK)]
		private int contactID;
		[ColumnMapping("RoleID",StereoType=DataStereoType.FK)]
		private int roleID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public ContactRole() : base()
		{
		}

		public ContactRole(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public int ContactID
		{
			get { return this.contactID; }
			set { this.contactID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RoleID
		{
			get { return this.roleID; }
			set { this.roleID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int contactID)
		{
			return base.Load(contactID);
		}

		/// <summary>
		/// Parent ContactRoleCollection that contains this element
		/// </summary>
		public ContactRoleCollection ParentContactRoleCollection
		{
			get
			{
				return this.parentContactRoleCollection;
			}
			set
			{
				this.parentContactRoleCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}


	}

	/// <summary>
	/// Strongly typed collection of ContactRole objects
	/// </summary>
	[ElementType(typeof(ContactRole))]
	public class ContactRoleCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_RoleID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ContactRole elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentContactRoleCollection = this;
			else
				elem.ParentContactRoleCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ContactRole elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ContactRole this[int index]
		{
			get
			{
				return (ContactRole)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ContactRole)oldValue, false);
			SetParentOnElem((ContactRole)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, ContactRole elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((ContactRole)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(ContactRole elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Parent Contact that contains this collection
		/// </summary>
		public Contact ParentContact
		{
			get { return this.ParentDataObject as Contact; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Contact */ }
		}

		/// <summary>
		/// Hashtable based index on roleID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_RoleID
		{
			get
			{
				if (this.indexBy_RoleID == null)
					this.indexBy_RoleID = new CollectionIndexer(this, new string[] { "roleID" }, true);
				return this.indexBy_RoleID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on roleID fields returns the object.  Uses the IndexBy_RoleID indexer.
		/// </summary>
		public ContactRole FindBy(int roleID)
		{
			return (ContactRole)this.IndexBy_RoleID.GetObject(roleID);
		}


		public void SynchronizeRolesFromSelectableCollection(int contactID, RoleCollection roles)
		{
			foreach (Role role in roles)
			{
				if (((SelectableRole)role).Selected)
				{
					ContactRole existingRole = this.FindBy(role.RoleID);
					if (existingRole == null)
					{
						ContactRole contactRole = null;
						contactRole = new ContactRole(true);
						contactRole.ContactID = contactID;
						contactRole.RoleID = role.RoleID;
						//contactRole.Save();
						this.AddRecord(contactRole);
					}
					else if (existingRole.IsMarkedForDeletion)
					{
						existingRole.IsMarkedForDeletion = false;
					}
				}
			}

			foreach (ContactRole contactRole in this)
			{
				Role role = null;
				role = roles.FindBy(contactRole.RoleID);
				if (!((SelectableRole)role).Selected)
				{
					contactRole.MarkDel();
					//contactRole.Delete();
				}
			}
		}


		public override int AddRecord(BaseDataClass data)
		{
			int ret = base.AddRecord (data);
			// Rebuild indexers 
			// TODO: Remove this when the library automatically supports this feature
			indexBy_RoleID.Rebuild();
			return ret;
		}

	}
}
