using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	public enum SessionIndicator
	{
		Initial = 1,
		All		= 2 
	}

	public class BaseLetterMOSP : BaseAssessment
	{
		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
		protected int planID;
		[ColumnMapping("MorgID",StereoType=DataStereoType.FK)]
		protected int morgID;
		[ColumnMapping("OrgID",StereoType=DataStereoType.FK)]
		protected int orgID;
		[ColumnMapping("SorgID",StereoType=DataStereoType.FK)]
		protected int sorgID;

		protected int organizationId;
		protected string organizationPath;
		protected Organization organization;
		protected string planName;


		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@PLAN@")]
		public int PlanID
		{
			get { return this.planID; }
			set { this.planID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int MorgID
		{
			get { return this.morgID; }
			//set { this.morgID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int OrgID
		{
			get { return this.orgID; }
			//set { this.orgID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int SorgID
		{
			get { return this.sorgID; }
			//set { this.sorgID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string OrganizationPath
		{
			get { return this.organizationPath; }
			set { this.organizationPath = value; }
		}
		
		[FieldDescription("@ORGANIZATION@")]
		public string OrganizationNameGridDisplay
		{
			get
			{
				this.OrganizationId = this.OrganizationId; // sets OrganizationID and Loads Organization
				if (this.organization.OrganizationID > 0)
					return this.organization.Name + " (" + this.organization.OrganizationLevel.Code + ")";
				else
					return "All";
			}
		}

		[FieldDescription("@ORGANIZATION@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int OrganizationId
		{
			get 
			{ 
				if(this.sorgID > 0)
				{
					this.organizationId = this.sorgID;
				}
				else if(this.orgID > 0)
				{
					this.organizationId = this.orgID;
				}
				else if(this.morgID > 0)
				{
					this.organizationId = this.morgID;
				}
				if (this.organizationId > 0)
					return this.organizationId;
				else
					return 0;	
			}
			set 
			{ 
				this.organizationId = value; 
				//determine level of given Organization and set ID's accordingly
				this.organization = new Organization();
				if ( this.organizationId == 0)
				{
					this.morgID = 0;
					this.orgID = 0;
					this.sorgID = 0;
					return;
				}
				
				if (this.organization.Load(this.organizationId))
				{
					switch (this.organization.OrganizationLevel.Code)
					{
						case "MORG":
							this.morgID = this.organizationId;
							this.orgID = 0;
							this.sorgID = 0;
							break;
						case "ORG":
							this.morgID = this.organization.ParentOrganization.OrganizationID;
							this.orgID = this.organizationId;
							this.sorgID = 0;
							break;
						case "SORG":
							this.morgID = this.organization.ParentOrganization.ParentOrganization.OrganizationID;
							this.orgID = this.organization.ParentOrganization.OrganizationID;
							this.sorgID = this.organizationId;
							break;
						default:
							return;
					}
				}
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PlanName
		{
			get { return this.planName; }
			set { this.planName = value; }
		}
	}
	
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterMatrix]
	/// Uses customized version of
	/// ("usp_SearchLetterMatrix","SearchByArgs.sptpl","letterSetID, matrixTypeID, sessionIndicator, morgID, orgID, sorgID, planID, referralTypeID, eventTypeID, clinicalReviewDecisionTypeID, clinicalReviewDecisionReasonID, enrollmentID")]
	/// </summary>
	[SPInsert("usp_InsertLetterMatrix")]
	[SPUpdate("usp_UpdateLetterMatrix")]
	[SPLoad("usp_LoadLetterMatrix")]
	[TableMapping("LetterMatrix","matrixID")]
	public class LetterMatrix : BaseLetterMOSP
	{
		[NonSerialized]
		protected LetterMatrixCollection parentLetterMatrixCollection;
		[ColumnMapping("MatrixID",(int)0)]
		protected int matrixID;
		[ColumnMapping("MatrixTypeID",StereoType=DataStereoType.FK)]
		protected int matrixTypeID;
		[ColumnMapping("LetterSetID",StereoType=DataStereoType.FK)]
		protected int letterSetID;
//		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
//		protected int planID;
//		[ColumnMapping("MorgID",StereoType=DataStereoType.FK)]
//		protected int morgID;
//		[ColumnMapping("OrgID",StereoType=DataStereoType.FK)]
//		protected int orgID;
//		[ColumnMapping("SorgID",StereoType=DataStereoType.FK)]
//		protected int sorgID;
		[ColumnMapping("EnrollmentID",StereoType=DataStereoType.FK)]
		protected int enrollmentID;
		[ColumnMapping("TerminationDate")]
		protected DateTime terminationDate;
		[ColumnMapping("Description")]
		protected string description;
		[ColumnMapping("SessionIndicator",StereoType=DataStereoType.FK)]
		protected int sessionIndicator;
		[ColumnMapping("EventTypeID",StereoType=DataStereoType.FK)]
		protected int eventTypeID;
		[ColumnMapping("ClinicalReviewDecisionTypeID",StereoType=DataStereoType.FK)]
		protected int clinicalReviewDecisionTypeID;
		[ColumnMapping("ClinicalReviewDecisionReasonID",StereoType=DataStereoType.FK)]
		protected int clinicalReviewDecisionReasonID;
		[ColumnMapping("ReferralTypeID",StereoType=DataStereoType.FK)]
		protected int referralTypeID;
		[ColumnMapping("ReferralUnitID",StereoType=DataStereoType.FK)]
		protected int referralUnitID;
		[ColumnMapping("LetterTypeID",StereoType=DataStereoType.FK)]
		protected int letterTypeID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		protected int referralDetailID;
		[ColumnMapping("FacilityStateID",StereoType=DataStereoType.FK)]
		protected int facilityStateID;
		[ColumnMapping("ReviewNumber",StereoType=DataStereoType.FK)]
		protected int reviewNumber;
		[ColumnMapping("TerminateTime")]
		protected DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		protected int terminatedBy;
		[ColumnMapping("ReferralDetailText")]
		protected string referralDetailText;
		
//		private int organizationId;
//		private string organizationPath;
//		private Organization organization;
//		private string planName;

		private DateTime terminateDateWhenLoaded;
		private LetterMatrixExceptionCollection letterMatrixExceptions; // used to determine if LetterMatrix is being terminated
	
		public LetterMatrix()
		{
		}

		public LetterMatrix(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int MatrixID
		{
			get { return this.matrixID; }
			set { this.matrixID = value; }
		}

		[FieldValuesMember("LookupOf_MatrixTypeID", "MatrixTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true, ValueForNull=(int)0)]
		[FieldDescription("@MATRIXTYPE@")]
		public int MatrixTypeID
		{
			get { return this.matrixTypeID; }
			set { this.matrixTypeID = value; }
		}

		[FieldValuesMember("LookupOf_LetterSetID", "LetterSetID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true, ValueForNull=(int)0)]
		[FieldDescription("@LETTERSET@")]
		public int LetterSetID
		{
			get { return this.letterSetID; }
			set { this.letterSetID = value; }
		}

//		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
//		[FieldDescription("@PLAN@")]
//		public int PlanID
//		{
//			get { return this.planID; }
//			set { this.planID = value; }
//		}
//
//		[ControlType(Macro=EnumControlTypeMacros.Int)]
//		public int MorgID
//		{
//			get { return this.morgID; }
//			//set { this.morgID = value; }
//		}
//
//		[ControlType(Macro=EnumControlTypeMacros.Int)]
//		public int OrgID
//		{
//			get { return this.orgID; }
//			//set { this.orgID = value; }
//		}
//
//		[ControlType(Macro=EnumControlTypeMacros.Int)]
//		public int SorgID
//		{
//			get { return this.sorgID; }
//			//set { this.sorgID = value; }
//		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255, IsRequired=true)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@TERMINATIONDATE@")]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[FieldDescription("@ENROLLMENT@")]
		public string EnrollmentIDGridDisplay
		{
			get
			{
				if (this.enrollmentID == 0)
					return "All";
				else
					return EnrollmentCollection.AllEnrollmentsByValidDateRange.Lookup_DescriptionByEnrollmentID(this.enrollmentID);
				
			}
		}
		
		[FieldValuesMember("LookupOf_EnrollmentId", "EnrollmentID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@ENROLLMENT@")]
		public int EnrollmentID
		{
			get { return this.enrollmentID; }
			set { this.enrollmentID = value; }
		}
		
		[FieldValuesMember("ValuesOf_SessionIndicator")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@SESSIONINDICATOR@")]
		public int SessionIndicator
		{
			get { return this.sessionIndicator; }
			set { this.sessionIndicator = value; }
		}

		[FieldDescription("@SESSIONINDICATOR@")]
		public string SessionIndicatorGridDisplay
		{
			get
			{
				switch (this.sessionIndicator)
				{
					case (int)DataLayer.SessionIndicator.All:
						return "A";
					case (int)DataLayer.SessionIndicator.Initial:
						return "I";
					default:
						return " ";
				}
			}
		}

		[FieldValuesMember("LookupOf_EventTypeID", "EventTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int EventTypeID
		{
			get { return this.eventTypeID; }
			set { this.eventTypeID = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewDecisionTypeID", "ClinicalReviewDecisionTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@REVIEWDECISIONTYPEID@")]
		public int ClinicalReviewDecisionTypeID
		{
			get { return this.clinicalReviewDecisionTypeID; }
			set { this.clinicalReviewDecisionTypeID = value; }
		}

		[FieldValuesMember("LookupOf_ClinicalReviewDecisionReasonID", "ClinicalReviewDecisionReasonID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@REVIEWDECISIONREASONID@")]
		public int ClinicalReviewDecisionReasonID
		{
			get { return this.clinicalReviewDecisionReasonID; }
			set { this.clinicalReviewDecisionReasonID = value; }
		}

		[FieldValuesMember("LookupOf_ReferralTypeID", "ReferralTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@REFERRALTYPEID@")]
		public int ReferralTypeID
		{
			get { return this.referralTypeID; }
			set { this.referralTypeID = value; }
		}

		[FieldValuesMember("LookupOf_ReferralUnitID", "ReferralUnitTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@REFERRALUNITID@")]
		public int ReferralUnitID
		{
			get { return this.referralUnitID; }
			set { this.referralUnitID = value; }
		}

		[FieldValuesMember("LookupOf_LetterTypeID", "LetterMatrixTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int LetterTypeID
		{
			get { return this.letterTypeID; }
			set { this.letterTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[FieldValuesMember("LookupOf_FacilityStateID", "Code", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, MaxLength=2, ValueForNull=(int)0)]
		[FieldDescription("@STATEFACILITY@")]
		public int FacilityStateID
		{
			get { return this.facilityStateID; }
			set { this.facilityStateID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReviewNumber
		{
			get { return this.reviewNumber; }
			set { this.reviewNumber = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string ReferralDetailText
		{
			get { return this.referralDetailText; }
			set { this.referralDetailText = value; }
		}

//		[ControlType(EnumControlTypes.TextBox)]
//		public string OrganizationPath
//		{
//			get { return this.organizationPath; }
//			set { this.organizationPath = value; }
//		}
//		
//		[FieldDescription("@ORGANIZATION@")]
//		public string OrganizationNameGridDisplay
//		{
//			get
//			{
//				this.OrganizationId = this.OrganizationId; // sets OrganizationID and Loads Organization
//				if (this.organization.OrganizationID > 0)
//					return this.organization.Name + " (" + this.organization.OrganizationLevel.Code + ")";
//				else
//					return "All";
//			}
//		}
		
//		[FieldDescription("@ORGANIZATION@")]
//		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
//		public int OrganizationId
//		{
//			get 
//			{ 
//				if(this.sorgID > 0)
//				{
//					this.organizationId = this.sorgID;
//				}
//				else if(this.orgID > 0)
//				{
//					this.organizationId = this.orgID;
//				}
//				else if(this.morgID > 0)
//				{
//					this.organizationId = this.morgID;
//				}
//				if (this.organizationId > 0)
//					return this.organizationId;
//				else
//					return 0;	
//			}
//			set 
//			{ 
//				this.organizationId = value; 
//				//determine level of given Organization and set ID's accordingly
//				this.organization = new Organization();
//				if ( this.organizationId == 0)
//				{
//					this.morgID = 0;
//					this.orgID = 0;
//					this.sorgID = 0;
//					return;
//				}
//				
//				if (this.organization.Load(this.organizationId))
//				{
//					switch (this.organization.OrganizationLevel.Code)
//					{
//						case "MORG":
//							this.morgID = this.organizationId;
//							this.orgID = 0;
//							this.sorgID = 0;
//							break;
//						case "ORG":
//							this.morgID = this.organization.ParentOrganization.OrganizationID;
//							this.orgID = this.organizationId;
//							this.sorgID = 0;
//							break;
//						case "SORG":
//							this.morgID = this.organization.ParentOrganization.ParentOrganization.OrganizationID;
//							this.orgID = this.organization.ParentOrganization.OrganizationID;
//							this.sorgID = this.organizationId;
//							break;
//						default:
//							return;
//					}
//				}
//			}
//		}
//
//		[ControlType(EnumControlTypes.TextBox)]
//		public string PlanName
//		{
//			get { return this.planName; }
//			set { this.planName = value; }
//		}

		#region DB Methods
		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int matrixID)
		{
			return base.Load(matrixID);
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{	
			if (this.terminationDate != this.terminateDateWhenLoaded)
				this.SetTerminatingUser();  // If Termination Time was provided 
			else if(!this.isMarkedForDeletion)
			{  // DO NOT check for duplicate if Termination Time was changed
				if(this.HasDuplicate())
					throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Same Letter Matrix already exist. ");
			}
			base.InternalSave();
			// Save the child collections here.

			if(LetterMatrixExceptions != null)
			{
				LetterMatrixExceptions.SqlData.Transaction = this.SqlData.Transaction;
				SaveLetterMatrixExceptions();
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);
			this.terminateDateWhenLoaded = this.terminationDate;
		}
		#endregion

		/// <summary>
		/// Parent LetterMatrixCollection that contains this element
		/// </summary>
		public LetterMatrixCollection ParentLetterMatrixCollection
		{
			get
			{
				return this.parentLetterMatrixCollection;
			}
			set
			{
				this.parentLetterMatrixCollection = value; // parent is set when added to a collection
			}
		}

		#region Lookups
		public StateCollection LookupOf_FacilityStateID
		{
			get
			{
				return StateCollection.AllStates; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDecisionTypeCollection LookupOf_ClinicalReviewDecisionTypeID
		{
			get
			{
				ClinicalReviewDecisionTypeCollection col = new ClinicalReviewDecisionTypeCollection();
				ClinicalReviewDecisionType obj = new ClinicalReviewDecisionType();
					obj.ClinicalReviewDecisionTypeID = 0;
					obj.Description = "All";
				col.AddRecord(obj);
				col.CopyElementsFrom(ClinicalReviewDecisionTypeCollection.ActiveClinicalReviewDecisionTypes, true, false);
				return col;
				//return ClinicalReviewDecisionTypeCollection.ActiveClinicalReviewDecisionTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ClinicalReviewDecisionReasonCollection LookupOf_ClinicalReviewDecisionReasonID
		{
			get
			{
				ClinicalReviewDecisionReasonCollection col = new ClinicalReviewDecisionReasonCollection();
				ClinicalReviewDecisionReason obj = new ClinicalReviewDecisionReason();
					obj.ClinicalReviewDecisionReasonID = 0;
					obj.Description = "All";
				col.AddRecord(obj);
				col.CopyElementsFrom(ClinicalReviewDecisionReasonCollection.ActiveClinicalReviewDecisionReasons, true, false);
				return col;
				//return ClinicalReviewDecisionReasonCollection.ActiveClinicalReviewDecisionReasons; // Acquire a shared instance from the static member of collection
			}
		}

		public EventTypeCollection LookupOf_EventTypeID
		{
			get
			{
				EventTypeCollection col = new EventTypeCollection();
				EventType obj = new EventType();
					obj.EventTypeID = 0;
					obj.Description = "All";
				col.AddRecord(obj);
				col.CopyElementsFrom(EventTypeCollection.ActiveEventTypes, true, false);
				return col;
				//return EventTypeCollection.ActiveEventTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ReferralTypeCollection LookupOf_ReferralTypeID
		{
			get
			{
				ReferralTypeCollection col = new ReferralTypeCollection();
				ReferralType obj = new ReferralType();
					obj.ReferralTypeId = 0;
					obj.Description = "All";
				col.AddRecord(obj);
				col.CopyElementsFrom(ReferralTypeCollection.ActiveReferralTypes, true, false);
				return col;
				//return ReferralTypeCollection.ActiveReferralTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ReferralUnitTypeCollection LookupOf_ReferralUnitID
		{
			get
			{
				ReferralUnitTypeCollection col = new ReferralUnitTypeCollection();
				ReferralUnitType obj = new ReferralUnitType();
					obj.ReferralUnitTypeID = 0;
					obj.Description = "All";
				col.AddRecord(obj);
				col.CopyElementsFrom(ReferralUnitTypeCollection.ActiveReferralUnitTypes, true, false);
				return col;
				//return ReferralUnitTypeCollection.ActiveReferralUnitTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public LetterMatrixTypeCollection LookupOf_LetterTypeID
		{
			get
			{
				return LetterMatrixTypeCollection.ActiveLetterMatrixTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public MatrixTypeCollection LookupOf_MatrixTypeID
		{
			get
			{
				return MatrixTypeCollection.ActiveMatrixTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public object[,] ValuesOf_SessionIndicator
		{
			get
			{
				return new object[,] { { (int)DataLayer.SessionIndicator.All, "All"}, 
									   { (int)DataLayer.SessionIndicator.Initial, "Initial"}};
			}
		}

		public LetterSetCollection LookupOf_LetterSetID
		{
			get
			{
				return LetterSetCollection.ActiveLetterSets; // Acquire a shared instance from the static member of collection
			}
		}

		public EnrollmentCollection LookupOf_EnrollmentId
		{
			get
			{
				EnrollmentCollection col = new EnrollmentCollection();
				Enrollment e = new Enrollment();
					e.EnrollmentID = 0;
					e.Description = "All";
				col.AddRecord(e);
				col.CopyElementsFrom(EnrollmentCollection.AllEnrollmentsByValidDateRange, true, false);
				return col;
				//return EnrollmentCollection.AllEnrollmentsByValidDateRange; // Acquire a shared instance from the static member of collection
			}
		}
		#endregion

		/// <summary>
		/// Verifies if LetterMatrix already exist.
		/// </summary>
		/// <returns>true if duplicate found</returns>
		private bool HasDuplicate()
		{
			/*�	Check for active, duplicate matrices. A duplicate matrix will have the same:
				o	Letter Set ID
				o	Matrix Type
				o	Session Indicator
				o	Morg ID (if any)
				o	Org ID (if any)
				o	Sorg ID (if any)
				o	Plan ID (if any)
				o	Referral Type (if any)
				o	Event Type (if any)
				o	Decision Type (if any)
				o	Decision Reason (if any)*/
			
			LetterMatrixCollection col = LetterMatrixCollection.GetFromSearch(this);
			if (col.Count > 0)
				return true;
			else
				return false;
		}

		#region LetterMatrixExceptions
		/// <summary>
		/// Child LetterMatrixExceptions mapped to related rows of table LetterMatrixException where [MatrixID] = [MatrixID]
		/// </summary>
		[SPLoadChild("usp_LoadLetterMatrixLetterMatrixException", "matrixID")]
		public LetterMatrixExceptionCollection LetterMatrixExceptions
		{
			get { return this.letterMatrixExceptions; }
			set
			{
				this.letterMatrixExceptions = value;
				if (value != null)
					value.ParentLetterMatrix = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the LetterMatrixExceptions collection
		/// </summary>
		public void LoadLetterMatrixExceptions(bool forceReload)
		{
			this.letterMatrixExceptions = (LetterMatrixExceptionCollection)LetterMatrixExceptionCollection.LoadChildCollection("LetterMatrixExceptions", this, typeof(LetterMatrixExceptionCollection), letterMatrixExceptions, forceReload, null);
		}

		/// <summary>
		/// Saves the LetterMatrixExceptions collection
		/// </summary>
		public void SaveLetterMatrixExceptions()
		{
			LetterMatrixExceptionCollection.SaveChildCollection(this.letterMatrixExceptions, true);
		}

		/// <summary>
		/// Synchronizes the LetterMatrixExceptions collection
		/// </summary>
		public void SynchronizeLetterMatrixExceptions()
		{
			LetterMatrixExceptionCollection.SynchronizeChildCollection(this.letterMatrixExceptions, true);
		}
		#endregion
	}

	/// <summary>
	/// Strongly typed collection of LetterMatrix objects
	/// </summary>
	[ElementType(typeof(LetterMatrix))]
	public class LetterMatrixCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterMatrix elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterMatrixCollection = this;
			else
				elem.ParentLetterMatrixCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterMatrix elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterMatrix this[int index]
		{
			get
			{
				return (LetterMatrix)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterMatrix)oldValue, false);
			SetParentOnElem((LetterMatrix)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterMatrix elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterMatrix)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		///	BR01.34.1.3	System shall not delete a Letter Matrix. A Letter Matrix can be rendered inactive by setting its termination date.
		/// </summary>
		private int SearchLetterMatrix(int maxRecords, LetterMatrix searcher)
		{
			
			object activeWithAll = (object)searcher.ActiveWithAll;
			this.Clear();

			return SqlData.SPExecReadCol("usp_SearchLetterMatrix", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}

		public static LetterMatrixCollection GetFromSearch(LetterMatrix searcher)
		{
			LetterMatrixCollection col = new LetterMatrixCollection();
			col.SearchLetterMatrix(-1, searcher);
			return col;
		}
	}
}
