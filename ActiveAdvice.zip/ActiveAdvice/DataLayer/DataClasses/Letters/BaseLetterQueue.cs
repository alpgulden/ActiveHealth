using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	
	public class SelectableLetterQueue : BaseLetterMOSP
	{
		private bool selected;

		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}
	} 
	
	
	public enum LetterQueueType
	{
		Undefined  = 0,
		Printed	   = 1,
		NotPrinted = 2,
		Draft	   = 3
	}
	
	/// <summary>
	/// Summary description for BaseLetterQueue.
	/// Use this as a base for PrintedQueue and NotPrintedQueue
	/// </summary>
	[TableMapping("LetterNonPrintedQueue","queueGUID")]
	public class BaseLetterQueue : SelectableLetterQueue
	{
	
		[ColumnMapping("QueueGUID")]
		protected string queueGUID;
		[ColumnMapping("LetterTemplateID",StereoType=DataStereoType.FK)]
		protected int letterTemplateID;
		[ColumnMapping("UserID",StereoType=DataStereoType.FK)]
		protected int userID;
		[ColumnMapping("TeamID",StereoType=DataStereoType.FK)]
		protected int teamID;
		[ColumnMapping("ReceiverTypeID",StereoType=DataStereoType.FK)]
		protected int receiverTypeID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		protected int eventID;
		[ColumnMapping("ProblemID",StereoType=DataStereoType.FK)]
		protected int problemID;
		[ColumnMapping("RequestID",StereoType=DataStereoType.FK)]
		protected int requestID;
		[ColumnMapping("PatientID",StereoType=DataStereoType.FK)]
		protected int patientID;
		[ColumnMapping("ReferralDetailID",StereoType=DataStereoType.FK)]
		protected int referralDetailID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		protected int cMSID;
		[ColumnMapping("AssessmentGUID")]
		protected string assessmentGUID;
		[ColumnMapping("ClinicalReviewDecisionID",StereoType=DataStereoType.FK)]
		protected int clinicalReviewDecisionID;
		[ColumnMapping("Version",StereoType=DataStereoType.FK)]
		protected int version;
		[ColumnMapping("MatrixTypeID",StereoType=DataStereoType.FK)]
		protected int matrixTypeID;
		[ColumnMapping("AttributePriority",StereoType=DataStereoType.FK)]
		protected int attributePriority;
		
		
		protected DateTime dateFrom;
		protected DateTime dateTo;
		
		protected LetterTemplate letterTemplate;

		public BaseLetterQueue()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		public string QueueGUID
		{
			get { return this.queueGUID; }
			set { this.queueGUID = value; }
		}

		[FieldDescription("@LETTERTEMPLATE@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LetterTemplateID
		{
			get { return this.letterTemplateID; }
			set { this.letterTemplateID = value; }
		}

		[FieldDescription("@USER@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int UserID
		{
			get { return this.userID; }
			set { this.userID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int TeamID
		{
			get { return this.teamID; }
			set { this.teamID = value; }
		}

		
		[FieldValuesMember("LookupOf_ReceiverTypeID", "ReceiverTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int ReceiverTypeID
		{
			get { return this.receiverTypeID; }
			set { this.receiverTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ProblemID
		{
			get { return this.problemID; }
			set { this.problemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int RequestID
		{
			get { return this.requestID; }
			set { this.requestID = value; }
		}

		[FieldDescription("@PATIENT@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ReferralDetailID
		{
			get { return this.referralDetailID; }
			set { this.referralDetailID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int Version
		{
			get { return this.version; }
			set { this.version = value; }
		}

		[FieldValuesMember("LookupOf_MatrixTypeID", "MatrixTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int MatrixTypeID
		{
			get { return this.matrixTypeID; }
			set { this.matrixTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int AttributePriority
		{
			get { return this.attributePriority; }
			set { this.attributePriority = value; }
		}

		[FieldDescription("@STARTDATE@")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DateFrom
		{
			get { return this.dateFrom; }
			set { this.dateFrom = value; }
		}

		[FieldDescription("@ENDDATE@")]
		[ValidatorMember("Vld_DateTo")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime DateTo
		{
			get { return this.dateTo; }
			set { this.dateTo = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ClinicalReviewDecisionID
		{
			get { return this.clinicalReviewDecisionID; }
			set { this.clinicalReviewDecisionID = value; }
		}

		#region Virtual Properties & Methods
		public virtual LetterQueueType LQType
		{
			get { throw new Exception("No LetterQueueType"); }
		}

		[FieldDescription("@ID@")]
		public virtual string LQID
		{
			get { throw new Exception("No LetterQueueId"); }
		}

		[FieldDescription("@STATUS@")]
		public virtual string StatusGridDisplay
		{
			get { return " - "; }
		}

		public virtual bool LoadLetterQueue(string queueGUID)
		{
			throw new Exception("No LoadLetterQueue()");
		}
		#endregion

		#region Lookups
		public LetterReceiverTypeCollection LookupOf_ReceiverTypeID
		{
			get
			{
				return LetterReceiverTypeCollection.ActiveLetterReceiverTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public MatrixTypeCollection LookupOf_MatrixTypeID
		{
			get
			{
				return MatrixTypeCollection.ActiveMatrixTypes; // Acquire a shared instance from the static member of collection
			}
		}
		#endregion

		[GenericScript("Vld_DateTo", "@DateTo@ != null && @DateFrom@ != null && @DateTo@ > @DateFrom@;")]
		public string Vld_DateTo
		{
			get
			{
				return "Date To must greater than Date From!"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set {}
		}

		public ActiveAdvice.DataLayer.LetterTemplate LetterTemplate
		{
			get 
			{ 
				if(this.letterTemplate == null)
					this.letterTemplate = new LetterTemplate(this.LetterTemplateID);
				
				return this.letterTemplate; 
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of BaseLetterQueue objects
	/// This is a base Collection for LetterPrinted/LetterNotPrinted/LetterDraft Queues Collections
	/// </summary>
	[ElementType(typeof(BaseLetterQueue))]
	public abstract class BaseLetterQueueCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_QueueGUID;
	
		public abstract int LoadAllLetters(int maxRecords);
		public abstract void Save();
		

		public void SetSelectedFromCollection(BaseLetterQueueCollection selected)
		{
			BaseLetterQueue existing = null;
			foreach (BaseLetterQueue blq in this)
			{
				existing = selected.FindBy(blq.QueueGUID);
				if (existing != null && !existing.IsMarkedForDeletion)
					((SelectableLetterQueue)blq).Selected = true;
				else
					((SelectableLetterQueue)blq).Selected = false;
			}
		}

		public virtual BaseLetterQueueCollection GetFromSearch(BaseLetterQueue searcher)
		{
			throw new Exception("GetFromSearch() not implemented");
		}

		public virtual void CreateFromCollectionAndSave(BaseLetterQueueCollection toBePrinted, bool delivery)
		{
			throw new Exception("CreateFromCollectionAndSave() not implemented");
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public BaseLetterQueue this[int index]
		{
			get
			{
				return (BaseLetterQueue)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		/// <summary>
		/// Hashtable based index on queueGUID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QueueGUID
		{
			get
			{
				if (this.indexBy_QueueGUID == null)
					this.indexBy_QueueGUID = new CollectionIndexer(this, new string[] { "queueGUID" }, true);
				return this.indexBy_QueueGUID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on queueGUID fields returns the object.  Uses the IndexBy_QueueGUID indexer.
		/// </summary>
		public BaseLetterQueue FindBy(string queueGUID)
		{
			return (BaseLetterQueue)this.IndexBy_QueueGUID.GetObject(queueGUID);
		}

	}
}
