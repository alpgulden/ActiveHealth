using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	[SPAutoGen("usp_GetActiveLetterMergeFields","SelectAllByGivenArgs.sptpl","active, isComplex")]
	[SPInsert("usp_InsertLetterTemplateBody")]
	[SPUpdate("usp_UpdateLetterTemplateBody")]
	[SPDelete("usp_DeleteLetterTemplateBody")]
	[SPLoad("usp_LoadLetterTemplateBody")]
	[TableMapping("LetterMergeField","letterMergeFieldID")]
	public class LetterMergeField : BaseData
	{
		[NonSerialized]
		private LetterMergeFieldCollection parentLetterMergeFieldCollection;
		[ColumnMapping("LetterMergeFieldID",StereoType=DataStereoType.FK)]
		private int letterMergeFieldID;
		[ColumnMapping("Origin")]
		private string origin;
		[ColumnMapping("FieldName")]
		private string fieldName;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Shortcut")]
		private string shortcut;
		[ColumnMapping("Filter1")]
		private string filter1;
		[ColumnMapping("Filter2")]
		private string filter2;
		[ColumnMapping("Filter3")]
		private string filter3;
		[ColumnMapping("Filter4")]
		private string filter4;
		[ColumnMapping("Filter5")]
		private string filter5;
		[ColumnMapping("HeaderText")]
		private string headerText;
		[ColumnMapping("IsComplex")]
		private bool isComplex;
		[ColumnMapping("MatrixTypeID",StereoType=DataStereoType.FK)]
		private int matrixTypeID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		private LetterMergeSubFieldCollection letterMergeSubFields;
	
		public LetterMergeField()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LetterMergeFieldID
		{
			get { return this.letterMergeFieldID; }
			set { this.letterMergeFieldID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Origin
		{
			get { return this.origin; }
			set { this.origin = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		public string FieldName
		{
			get { return this.fieldName; }
			set { this.fieldName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		public string Shortcut
		{
			get { return this.shortcut; }
			set { this.shortcut = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Filter1
		{
			get { return this.filter1; }
			set { this.filter1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Filter2
		{
			get { return this.filter2; }
			set { this.filter2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Filter3
		{
			get { return this.filter3; }
			set { this.filter3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Filter4
		{
			get { return this.filter4; }
			set { this.filter4 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string Filter5
		{
			get { return this.filter5; }
			set { this.filter5 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=100)]
		public string HeaderText
		{
			get { return this.headerText; }
			set { this.headerText = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IsComplex
		{
			get { return this.isComplex; }
			set { this.isComplex = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MatrixTypeID
		{
			get { return this.matrixTypeID; }
			set { this.matrixTypeID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Child LetterMergeSubFields mapped to related rows of table LetterMergeSubField where [LetterMergeFieldID] = [LetterMergeFieldID]
		/// </summary>
		[SPLoadChild("usp_LoadLetterMergeSubFields", "letterMergeFieldID")]
		public LetterMergeSubFieldCollection LetterMergeSubFields
		{
			get { return this.letterMergeSubFields; }
			set
			{
				this.letterMergeSubFields = value;
				if (value != null)
					value.ParentLetterMergeField = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the LetterMergeSubFields collection
		/// </summary>
		public void LoadLetterMergeSubFields(bool forceReload)
		{
			this.letterMergeSubFields = (LetterMergeSubFieldCollection)LetterMergeSubFieldCollection.LoadChildCollection("LetterMergeSubFields", this, typeof(LetterMergeSubFieldCollection), letterMergeSubFields, forceReload, null);
		}

		/// <summary>
		/// Saves the LetterMergeSubFields collection
		/// </summary>
		public void SaveLetterMergeSubFields()
		{
			LetterMergeSubFieldCollection.SaveChildCollection(this.letterMergeSubFields, true);
		}

		/// <summary>
		/// Synchronizes the LetterMergeSubFields collection
		/// </summary>
		public void SynchronizeLetterMergeSubFields()
		{
			LetterMergeSubFieldCollection.SynchronizeChildCollection(this.letterMergeSubFields, true);
		}

		/// <summary>
		/// Parent LetterMergeFieldCollection that contains this element
		/// </summary>
		public LetterMergeFieldCollection ParentLetterMergeFieldCollection
		{
			get
			{
				return this.parentLetterMergeFieldCollection;
			}
			set
			{
				this.parentLetterMergeFieldCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of LetterMergeField objects
	/// </summary>
	[ElementType(typeof(LetterMergeField))]
	public class LetterMergeFieldCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_MatrixTypeID_Shortcut;
		[NonSerialized]
		private CollectionIndexer indexBy_LetterMergeFieldID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterMergeField elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterMergeFieldCollection = this;
			else
				elem.ParentLetterMergeFieldCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterMergeField elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterMergeField this[int index]
		{
			get
			{
				return (LetterMergeField)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterMergeField)oldValue, false);
			SetParentOnElem((LetterMergeField)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}




		/// <summary>
		/// Hashtable based index on letterMergeFieldID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_LetterMergeFieldID
		{
			get
			{
				if (this.indexBy_LetterMergeFieldID == null)
					this.indexBy_LetterMergeFieldID = new CollectionIndexer(this, new string[] { "letterMergeFieldID" }, true);
				return this.indexBy_LetterMergeFieldID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on letterMergeFieldID fields returns the object.  Uses the IndexBy_LetterMergeFieldID indexer.
		/// </summary>
		public LetterMergeField FindBy(int letterMergeFieldID)
		{
			return (LetterMergeField)this.IndexBy_LetterMergeFieldID.GetObject(letterMergeFieldID);
		}

		/// <summary>
		/// Hashtable based index on matrixTypeID, shortcut fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_MatrixTypeID_Shortcut
		{
			get
			{
				if (this.indexBy_MatrixTypeID_Shortcut == null)
					this.indexBy_MatrixTypeID_Shortcut = new CollectionIndexer(this, new string[] { "matrixTypeID", "shortcut" }, true);
				return this.indexBy_MatrixTypeID_Shortcut;
			}
			
		}

		/// <summary>
		/// Hashtable based search on matrixTypeID, shortcut fields returns the object.  Uses the IndexBy_MatrixTypeID_Shortcut indexer.
		/// </summary>
		public LetterMergeField FindBy(int matrixTypeID, string shortcut)
		{
			return (LetterMergeField)this.IndexBy_MatrixTypeID_Shortcut.GetObject(matrixTypeID, shortcut);
		}
	}
}
