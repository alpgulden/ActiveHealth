using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterDraftQueue]
	/// </summary>
	/*@dateFrom datetime, @dateTo datetime
	 * .................
	 * and	@dateFrom is null OR dbo.TruncDate(@dateFrom) <= dbo.TruncDate([LetterPrintedQueue].[CreateTime]) and @dateTo is null OR dbo.TruncDate([LetterPrintedQueue].[CreateTime]) <= dbo.TruncDate(@dateTo)
	 */
	[SPAutoGen("usp_SearchLettersDraftQueue","SearchByArgs.sptpl","userID, teamID, patientID, morgID, orgID, sorgID", InjectWhere="and	@dateFrom is null OR dbo.TruncDate(@dateFrom) <= dbo.TruncDate([LetterDraftQueue].[CreateTime]) and @dateTo is null OR dbo.TruncDate([LetterDraftQueue].[CreateTime]) <= dbo.TruncDate(@dateTo)")]
	[SPAutoGen("usp_GetAllLettersDraftQueue","SelectAll.sptpl","")]
	[SPInsert("usp_InsertLetterDraftQueue")]
	[SPUpdate("usp_UpdateLetterDraftQueue")]
	[SPDelete("usp_DeleteLetterDraftQueue")]
	[SPLoad("usp_LoadLetterDraftQueue")]
	[TableMapping("LetterDraftQueue","queueGUID")]
	public class LetterDraftQueue : BaseLetterQueue
	{
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		
		private LetterDraftQueueCollection parentLetterDraftQueueCollection;

		#region overriden methods from BaseLetterQueue
		public override string LQID
		{
			get { return this.queueGUID; }
		}

		public override LetterQueueType LQType
		{
			get { return LetterQueueType.Draft; }
		}

		public override bool LoadLetterQueue(string queueGUID)
		{
			return base.LoadLetterQueue (queueGUID);
		}
		#endregion

		public LetterDraftQueue()
		{
		}

		public LetterDraftQueue(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent LetterDraftQueueCollection that contains this element
		/// </summary>
		public LetterDraftQueueCollection ParentLetterDraftQueueCollection
		{
			get
			{
				return this.parentLetterDraftQueueCollection;
			}
			set
			{
				this.parentLetterDraftQueueCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of LetterDraftQueue objects
	/// </summary>
	[ElementType(typeof(LetterDraftQueue))]
	public class LetterDraftQueueCollection : BaseLetterQueueCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterDraftQueue elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterDraftQueueCollection = this;
			else
				elem.ParentLetterDraftQueueCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterDraftQueue elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterDraftQueue this[int index]
		{
			get
			{
				return (LetterDraftQueue)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterDraftQueue)oldValue, false);
			SetParentOnElem((LetterDraftQueue)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterDraftQueue elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterDraftQueue)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public override void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public override int LoadAllLetters(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLettersDraftQueue", maxRecords, this, false);
		}

		public void DeleteSelectedAndSave()
		{
			foreach(LetterDraftQueue ldf in this)
			{
				ldf.IsMarkedForDeletion = (((SelectableLetterQueue)ldf).Selected ? true : false);
			}
			this.Save();
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchLettersDraftQueue(int maxRecords, LetterDraftQueue searcher)
		{
			object dateFrom = (searcher.DateFrom == DateTime.MinValue? (object)null: (object)searcher.DateFrom);
			object dateTo = (searcher.DateTo == DateTime.MinValue? (object)null: (object)searcher.DateTo);
			this.Clear();
			
			return SqlData.SPExecReadCol("usp_SearchLettersDraftQueue", maxRecords, this, searcher, false,
				new string[] {"dateFrom", "dateTo"}, new object[] {dateFrom, dateTo});
		}

		public override BaseLetterQueueCollection GetFromSearch(BaseLetterQueue searcher)
		{
			this.SearchLettersDraftQueue(-1, searcher as LetterDraftQueue);
			return this;
		}

	}
}
