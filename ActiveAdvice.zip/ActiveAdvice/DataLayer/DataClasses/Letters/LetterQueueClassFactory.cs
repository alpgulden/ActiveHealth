using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for LetterQueueClassFactory.
	/// </summary>
	public class LetterQueueClassFactory
	{
		#region Object Factories
		public static BaseLetterQueue CreateLetterQueue(LetterQueueType letterQueueType, bool initNew)
		{
			switch(letterQueueType)
			{
				case LetterQueueType.Printed:
					return new LetterPrintedQueue(initNew);
				case LetterQueueType.NotPrinted:
					return new LetterNonPrintedQueue(initNew);
				case LetterQueueType.Draft:
					return new LetterDraftQueue(initNew);
				default:
					throw new ActiveAdviceException(AAExceptionAction.None, "Unknown  Letter Queue Type specified to LetterQueueClassFactory");
					
			}
		}

		public static BaseLetterQueue CreateLetterQueueAndLoad(LetterQueueType letterQueueType, string queueGUID)
		{
			BaseLetterQueue lq = CreateLetterQueue(letterQueueType, false);
			
			if (lq.LoadLetterQueue(queueGUID))
				return lq;
			else
				return null;
		}

		public static BaseLetterQueue CreateLetterQueueFromQueue(LetterQueueType letterQueueType, bool initNew)
		{
			switch(letterQueueType)
			{
				case LetterQueueType.Printed:
					return new LetterPrintedQueue(initNew);
				case LetterQueueType.NotPrinted:
					return new LetterPrintedQueue(initNew);
				case LetterQueueType.Draft:
					return new LetterNonPrintedQueue(initNew);
				default:
					throw new ActiveAdviceException(AAExceptionAction.None, "Unknown  Letter Queue Type specified to LetterQueueClassFactory");
					
			}
		}

		public static BaseLetterQueue CreateLetterQueueFromQueueAndLoad(LetterQueueType letterQueueType, string queueGUID)
		{
			BaseLetterQueue lq = CreateLetterQueueFromQueue(letterQueueType, false);
			
			if (lq.LoadLetterQueue(queueGUID))
				return lq;
			else
				return null;
		}
		#endregion

		#region Collection Factories
		public static BaseLetterQueueCollection CreateLetterQueueCollection(LetterQueueType letterQueueType)
		{
			switch(letterQueueType)
			{
				case LetterQueueType.Printed:
					return new LetterPrintedQueueCollection();
				case LetterQueueType.NotPrinted:
					return new LetterNonPrintedQueueCollection();
				case LetterQueueType.Draft:
					return new LetterDraftQueueCollection();
				default:
					throw new ActiveAdviceException(AAExceptionAction.None, "Unknown  Letter Queue Type specified to LetterQueueClassFactory");
			}
		}

		public static BaseLetterQueueCollection CreateLetterQueueCollectionAndLoad(LetterQueueType letterQueueType)
		{
			BaseLetterQueueCollection lqc = CreateLetterQueueCollection(letterQueueType);
			lqc.LoadAllLetters(-1);

			return lqc;
		}

		public static BaseLetterQueueCollection CreateLetterQueueCollectionFromCollection(LetterQueueType letterQueueType)
		{
			switch(letterQueueType)
			{
				case LetterQueueType.Printed:
					return new LetterPrintedQueueCollection();
				case LetterQueueType.NotPrinted:
					return new LetterPrintedQueueCollection();
				case LetterQueueType.Draft:
					return new LetterNonPrintedQueueCollection();
				default:
					throw new ActiveAdviceException(AAExceptionAction.None, "Unknown  Letter Queue Type specified to LetterQueueClassFactory");
			}
		}

		public static BaseLetterQueueCollection CreateLetterQueueCollectionFromCollectionAndLoad(LetterQueueType letterQueueType)
		{
			BaseLetterQueueCollection lqc = CreateLetterQueueCollectionFromCollection(letterQueueType);
			lqc.LoadAllLetters(-1);

			return lqc;
		}
		#endregion
	}
}
