using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterReceiverType]
	/// </summary>
	[SPAutoGen("usp_GetAllLetterReceiverTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertLetterReceiverType")]
	[SPUpdate("usp_UpdateLetterReceiverType")]
	[SPDelete("usp_DeleteLetterReceiverType")]
	[SPLoad("usp_LoadLetterReceiverType")]
	[TableMapping("LetterReceiverType","receiverTypeID")]
	public class LetterReceiverType : BaseLookupStandard
	{
		[NonSerialized]
		private LetterReceiverTypeCollection parentLetterReceiverTypeCollection;
		[ColumnMapping("ReceiverTypeID",(int)0)]
		private int receiverTypeID;
		[ColumnMapping("MatrixTypeID",StereoType=DataStereoType.FK)]
		private int matrixTypeID;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public LetterReceiverType()
		{

		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ReceiverTypeID
		{
			get { return this.receiverTypeID; }
			set { this.receiverTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MatrixTypeID
		{
			get { return this.matrixTypeID; }
			set { this.matrixTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent LetterReceiverTypeCollection that contains this element
		/// </summary>
		public LetterReceiverTypeCollection ParentLetterReceiverTypeCollection
		{
			get
			{
				return this.parentLetterReceiverTypeCollection;
			}
			set
			{
				this.parentLetterReceiverTypeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of LetterReceiverType objects
	/// </summary>
	[ElementType(typeof(LetterReceiverType))]
	public class LetterReceiverTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterReceiverType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterReceiverTypeCollection = this;
			else
				elem.ParentLetterReceiverTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterReceiverType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterReceiverType this[int index]
		{
			get
			{
				return (LetterReceiverType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterReceiverType)oldValue, false);
			SetParentOnElem((LetterReceiverType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllLetterReceiverTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLetterReceiverTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared LetterReceiverTypeCollection which is cached in NSGlobal
		/// </summary>
		public static LetterReceiverTypeCollection ActiveLetterReceiverTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LetterReceiverTypeCollection col = (LetterReceiverTypeCollection)NSGlobal.EnsureCachedObject("ActiveLetterReceiverTypes", typeof(LetterReceiverTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllLetterReceiverTypesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
