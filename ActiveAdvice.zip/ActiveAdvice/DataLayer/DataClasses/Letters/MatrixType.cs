using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [MatrixType]
	/// </summary>
	[SPAutoGen("usp_GetAllMatrixTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertMatrixType")]
	[SPUpdate("usp_UpdateMatrixType")]
	[SPDelete("usp_DeleteMatrixType")]
	[SPLoad("usp_LoadMatrixType")]
	[TableMapping("MatrixType","matrixTypeID")]
	public class MatrixType : BaseLookupStandard
	{
		[NonSerialized]
		private MatrixTypeCollection parentMatrixTypeCollection;
		[ColumnMapping("MatrixTypeID",(int)0)]
		private int matrixTypeID;
		[ColumnMapping("NotePad")]
		private string notePad;
		
		public const string CASEMANAGEMENT = "CM";
		public const string EVENT_CLINICALREVIEW = "E&CR";
		public const string REFERRAL = "REFR";
		


		public MatrixType()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int MatrixTypeID
		{
			get { return this.matrixTypeID; }
			set { this.matrixTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent MatrixTypeCollection that contains this element
		/// </summary>
		public MatrixTypeCollection ParentMatrixTypeCollection
		{
			get
			{
				return this.parentMatrixTypeCollection;
			}
			set
			{
				this.parentMatrixTypeCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of MatrixType objects
	/// </summary>
	[ElementType(typeof(MatrixType))]
	public class MatrixTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_MatrixTypeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MatrixType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMatrixTypeCollection = this;
			else
				elem.ParentMatrixTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MatrixType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MatrixType this[int index]
		{
			get
			{
				return (MatrixType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MatrixType)oldValue, false);
			SetParentOnElem((MatrixType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllMatrixTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllMatrixTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared MatrixTypeCollection which is cached in NSGlobal
		/// </summary>
		public static MatrixTypeCollection ActiveMatrixTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				MatrixTypeCollection col = (MatrixTypeCollection)NSGlobal.EnsureCachedObject("ActiveMatrixTypes", typeof(MatrixTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllMatrixTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on matrixTypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_MatrixTypeID
		{
			get
			{
				if (this.indexBy_MatrixTypeID == null)
					this.indexBy_MatrixTypeID = new CollectionIndexer(this, new string[] { "matrixTypeID" }, true);
				return this.indexBy_MatrixTypeID;
			}
			
		}

		/// <summary>
		/// Looks up by matrixTypeID and returns Code value.  Uses the IndexBy_MatrixTypeID indexer.
		/// </summary>
		public string Lookup_CodeByMatrixTypeID(int matrixTypeID)
		{
			return this.IndexBy_MatrixTypeID.LookupStringMember("Code", matrixTypeID);
		}

		
	}
}
