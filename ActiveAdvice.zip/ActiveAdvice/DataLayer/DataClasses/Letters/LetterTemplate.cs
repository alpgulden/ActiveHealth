using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterTemplate]
	/// Uses customized version of 
	/// ("usp_SearchLetterTemplates","SearchByArgs.sptpl","letterName, letterSetID, description, version, matrixTypeID, receiverTypeID, formTypeID")
	/// Uses customized version of [SPInsert("usp_InsertLetterTemplate")]
	/// Uses customized version of [SPUpdate("usp_UpdateLetterTemplate")]
	/// </summary>
	[SPUpdate("usp_UpdateLetterTemplate")] // DO NOT modify with tool !!!! 
	[SPInsert("usp_InsertLetterTemplate")] // DO NOT modify with tool !!!!
	[SPDelete("usp_DeleteLetterTemplate")] 
	[SPLoad("usp_LoadLetterTemplate")]
	[TableMapping("LetterTemplate","letterTemplateID")]
	public class LetterTemplate : BaseAssessment
	{
		[NonSerialized]
		protected LetterTemplateCollection parentLetterTemplateCollection;
		[ColumnMapping("LetterTemplateID",(int)0)]
		protected int letterTemplateID;
		[ColumnMapping("Version",StereoType=DataStereoType.FK)]
		protected int version;
		[ColumnMapping("LetterName")]
		protected string letterName;
		[ColumnMapping("LetterSetID",StereoType=DataStereoType.FK)]
		protected int letterSetID;
		[ColumnMapping("MatrixTypeID",StereoType=DataStereoType.FK)]
		protected int matrixTypeID;
		[ColumnMapping("FormTypeID",StereoType=DataStereoType.FK)]
		protected int formTypeID;
		[ColumnMapping("Description")]
		protected string description;
		[ColumnMapping("EffectiveDate")]
		protected DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		protected DateTime terminationDate;
		[ColumnMapping("Duplex")]
		protected bool duplex;
		[ColumnMapping("Envelope")]
		protected bool envelope;
		[ColumnMapping("IntroLetterNumber",StereoType=DataStereoType.FK)]
		protected int introLetterNumber;
		[ColumnMapping("ReceiverTypeID",StereoType=DataStereoType.FK)]
		protected int receiverTypeID;
		[ColumnMapping("LetterTemplateBodyID",StereoType=DataStereoType.FK)]
		private int letterTemplateBodyID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("TerminateTime")]
		protected DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		protected int terminatedBy;
		private LetterTemplateBody letterTemplateBody;
	
		
		public LetterTemplate()
		{
		}

		public LetterTemplate(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public LetterTemplate(int letterTemplateID)
		{
			if(letterTemplateID > 0)
				this.Load(letterTemplateID);
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int LetterTemplateID
		{
			get { return this.letterTemplateID; }
			set { this.letterTemplateID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int Version
		{
			get { return this.version; }
			set { this.version = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		public string LetterName
		{
			get { return this.letterName; }
			set { this.letterName = value; }
		}

		[FieldValuesMember("LookupOf_LetterSetID", "LetterSetID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true, ValueForNull=(int)0)]
		[FieldDescription("@LETTERSET@")]
		public int LetterSetID
		{
			get { return this.letterSetID; }
			set { this.letterSetID = value; }
		}

		[FieldValuesMember("LookupOf_MatrixTypeID", "MatrixTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true, ValueForNull=(int)0)]
		[FieldDescription("@MATRIXTYPE@")]
		public int MatrixTypeID
		{
			get { return this.matrixTypeID; }
			set { this.matrixTypeID = value; }
		}

		[FieldValuesMember("LookupOf_FormTypeID", "FormTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true, ValueForNull=(int)0)]
		[FieldDescription("@FORMTYPEID@")]
		public int FormTypeID
		{
			get { return this.formTypeID; }
			set { this.formTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255, IsRequired=true)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@DUPLEXPRINT@")]
		public bool Duplex
		{
			get { return this.duplex; }
			set { this.duplex = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@ICMENVELOPE@")]
		public bool Envelope
		{
			get { return this.envelope; }
			set { this.envelope = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@INTROLETTERNUMBER@")]
		public int IntroLetterNumber
		{
			get { return this.introLetterNumber; }
			set { this.introLetterNumber = value; }
		}

		[FieldValuesMember("LookupOf_ReceiverTypeID", "ReceiverTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@RECEIVERTYPEID@")]
		public int ReceiverTypeID
		{
			get { return this.receiverTypeID; }
			set { this.receiverTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		/// <summary>
		/// Parent LetterTemplateCollection that contains this element
		/// </summary>
		public LetterTemplateCollection ParentLetterTemplateCollection
		{
			get
			{
				return this.parentLetterTemplateCollection;
			}
			set
			{
				this.parentLetterTemplateCollection = value; // parent is set when added to a collection
			}
		}

		#region Lookups
		public LetterReceiverTypeCollection LookupOf_ReceiverTypeID
		{
			get
			{
				return LetterReceiverTypeCollection.ActiveLetterReceiverTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public MatrixTypeCollection LookupOf_MatrixTypeID
		{
			get
			{
				return MatrixTypeCollection.ActiveMatrixTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public LetterFormTypeCollection LookupOf_FormTypeID
		{
			get
			{
				LetterFormTypeCollection col = new LetterFormTypeCollection();
				
				string code;
				if(this.matrixTypeID < 1) // not set
					code = MatrixType.EVENT_CLINICALREVIEW; // default MatrixType
				else
					code = MatrixTypeCollection.ActiveMatrixTypes.Lookup_CodeByMatrixTypeID(this.matrixTypeID);
				
				if(code == MatrixType.EVENT_CLINICALREVIEW || code == MatrixType.REFERRAL) // these Matrix types trigger LetterForm combo to contain "Standard"
					col.AddRecord(LetterFormTypeCollection.ActiveLetterFormTypes.FindBy(LetterFormType.STANDARD));
				else
					col.AddRecord(LetterFormTypeCollection.ActiveLetterFormTypes.FindBy(LetterFormType.ASSESSMENT));

				col.AddRecord(LetterFormTypeCollection.ActiveLetterFormTypes.FindBy(LetterFormType.ENVELOPE));
				col.AddRecord(LetterFormTypeCollection.ActiveLetterFormTypes.FindBy(LetterFormType.FORM));
				return col;
				//return LetterFormTypeCollection.ActiveLetterFormTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public LetterSetCollection LookupOf_LetterSetID
		{
			get
			{
				return LetterSetCollection.ActiveLetterSets; // Acquire a shared instance from the static member of collection
			}
		}
		#endregion

		#region DB Methods
		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int letterTemplateID)
		{
			return base.Load(letterTemplateID);
		}
		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			 this.LetterTemplateBody.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			 if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			 {
				base.InternalSave();	// in that case, delete the base first
				LetterTemplateBody.MarkDel();	// then allow the deletion of the conatined object
			 }
			 LetterTemplateBody.Save();
			 this.letterTemplateBodyID = LetterTemplateBody.LetterTemplateBodyID; // set the fk if the contained object was newly created
			if(!this.IsMarkedForDeletion)
			{
				//this.version++; // BR01.34.3.1	System shall increment the version number of a letter each time it is modified.
				if(this.LetterName == null)
					// BR01.34.3.2	System shall create a default Letter Name if the User does not create one. The default Letter Name shall be constructed as follows:
					// Letter Name = Letter Set Id + Receiver Code 
					this.LetterName = this.letterSetID.ToString() + this.receiverTypeID.ToString();
			}
			if(this.IsNew)
				this.version = 1;
				
			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}
		#endregion

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				
				//writer.AddHeaderLabelandValue("Letter Template ID", LetterTemplateID.ToString());
				
				writer.AddField(this, "Version");
				writer.AddField(this, "LetterName");
			}
		}

		[GenericScript("Vld_TerminationDate", "@TerminationDate@ != null && @TerminationDate@ > @EffectiveDate@;")]
		public string Vld_TerminationDate
		{
			get
			{
				return Messages.LetterMessages.MessageIDs.ERRLETTERDATE; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LetterTemplateBodyID
		{
			get { return this.letterTemplateBodyID; }
			set { this.letterTemplateBodyID = value; }
		}

		/// <summary>
		/// Contained LetterTemplateBody object
		/// </summary>
		[Contained]
		public LetterTemplateBody LetterTemplateBody
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.letterTemplateBody = (LetterTemplateBody)LetterTemplateBody.EnsureContainedDataObject(this, typeof(LetterTemplateBody), letterTemplateBody, false, letterTemplateBodyID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.letterTemplateBody;
			}
			set
			{
				this.letterTemplateBody = value;
				if (value != null) value.ParentLetterTemplate = this; // set this as a parent of the child data class
			}
		}



		
	}

	/// <summary>
	/// Strongly typed collection of LetterTemplate objects
	/// </summary>
	[ElementType(typeof(LetterTemplate))]
	public class LetterTemplateCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterTemplate elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterTemplateCollection = this;
			else
				elem.ParentLetterTemplateCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterTemplate elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterTemplate this[int index]
		{
			get
			{
				return (LetterTemplate)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterTemplate)oldValue, false);
			SetParentOnElem((LetterTemplate)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterTemplate elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterTemplate)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent LetterSet that contains this collection
		/// </summary>
		public LetterSet ParentLetterSet
		{
			get { return this.ParentDataObject as LetterSet; }
			set { this.ParentDataObject = value; /* parent is set when contained by a LetterSet */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchLetterTemplates(int maxRecords, LetterTemplate searcher)
		{
			this.Clear();
			object activeWithAll = (object)searcher.ActiveWithAll;
			return SqlData.SPExecReadCol("usp_SearchLetterTemplates", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}

		public static LetterTemplateCollection GetFromSearch(LetterTemplate searcher)
		{
			LetterTemplateCollection col = new LetterTemplateCollection();
			col.SearchLetterTemplates(-1, searcher);
			return col;
		}
	}
}
