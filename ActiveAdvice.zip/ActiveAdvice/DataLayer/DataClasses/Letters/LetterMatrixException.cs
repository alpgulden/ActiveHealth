using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [LetterMatrixException]
	/// </summary>
	[SPInsert("usp_InsertLetterMatrixException")]
	[SPUpdate("usp_UpdateLetterMatrixException")]
	[SPLoad("usp_LoadLetterMatrixException")]
	[TableMapping("LetterMatrixException","exceptionID")]
	public class LetterMatrixException : BaseData
	{
		[NonSerialized]
		private LetterMatrixExceptionCollection parentLetterMatrixExceptionCollection;
		[ColumnMapping("ExceptionID",(int)0)]
		private int exceptionID;
		[ColumnMapping("MatrixID",StereoType=DataStereoType.FK)]
		private int matrixID;
		[ColumnMapping("PlanID",StereoType=DataStereoType.FK)]
		private int planID;
		[ColumnMapping("MorgID",StereoType=DataStereoType.FK)]
		private int morgID;
		[ColumnMapping("OrgID",StereoType=DataStereoType.FK)]
		private int orgID;
		[ColumnMapping("SorgID",StereoType=DataStereoType.FK)]
		private int sorgID;
		[ColumnMapping("EnrollmentID",StereoType=DataStereoType.FK)]
		private int enrollmentID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyBy",StereoType=DataStereoType.FK)]
		private int modifyBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

		private int organizationId;
		private string organizationPath;
		private Organization organization;
		private string planName;
	
		public LetterMatrixException()
		{
		}

		public LetterMatrixException(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int ExceptionID
		{
			get { return this.exceptionID; }
			set { this.exceptionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int MatrixID
		{
			get { return this.matrixID; }
			set { this.matrixID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@PLAN@")]
		public int PlanID
		{
			get { return this.planID; }
			set { this.planID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MorgID
		{
			get { return this.morgID; }
			//set { this.morgID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int OrgID
		{
			get { return this.orgID; }
			//set { this.orgID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SorgID
		{
			get { return this.sorgID; }
			//set { this.sorgID = value; }
		}

		[FieldDescription("@ENROLLMENT@")]
		public string EnrollmentIDGridDisplay
		{
			get
			{
				if (this.enrollmentID == 0)
					return "All";
				else
					return EnrollmentCollection.AllEnrollmentsByValidDateRange.Lookup_DescriptionByEnrollmentID(this.enrollmentID);
				
			}
		}
		
		[FieldValuesMember("LookupOf_EnrollmentId", "EnrollmentID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@ENROLLMENT@")]
		public int EnrollmentID
		{
			get { return this.enrollmentID; }
			set { this.enrollmentID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifyBy
		{
			get { return this.modifyBy; }
			set { this.modifyBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string OrganizationPath
		{
			get { return this.organizationPath; }
			set { this.organizationPath = value; }
		}
		
		[FieldDescription("@ORGANIZATION@")]
		public string OrganizationNameGridDisplay
		{
			get
			{
				this.OrganizationId = this.OrganizationId; // sets OrganizationID and Loads Organization
				if (this.organization.OrganizationID > 0)
					return this.organization.Name;
				else
					return "All";
			}
		}

		[FieldDescription("@ORGANIZATION@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int OrganizationId
		{
			get 
			{ 
				if(this.sorgID > 0)
				{
					this.organizationId = this.sorgID;
				}
				else if(this.orgID > 0)
				{
					this.organizationId = this.orgID;
				}
				else if(this.morgID > 0)
				{
					this.organizationId = this.morgID;
				}
				if (this.organizationId > 0)
					return this.organizationId;
				else
					return 0;	
			}
			set 
			{ 
				this.organizationId = value; 
				//determine level of given Organization and set ID's accordingly
				this.organization = new Organization();
				if ( this.organizationId == 0)
				{
					this.morgID = 0;
					this.orgID = 0;
					this.sorgID = 0;
					return;
				}
				
				if (this.organization.Load(this.organizationId))
				{
					switch (this.organization.OrganizationLevel.Code)
					{
						case "MORG":
							this.morgID = this.organizationId;
							this.orgID = 0;
							this.sorgID = 0;
							break;
						case "ORG":
							this.morgID = this.organization.ParentOrganization.OrganizationID;
							this.orgID = this.organizationId;
							this.sorgID = 0;
							break;
						case "SORG":
							this.morgID = this.organization.ParentOrganization.ParentOrganization.OrganizationID;
							this.orgID = this.organization.ParentOrganization.OrganizationID;
							this.sorgID = this.organizationId;
							break;
						default:
							return;
					}
				}
			}
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string PlanName
		{
			get { return this.planName; }
			set { this.planName = value; }
		}
		
		public EnrollmentCollection LookupOf_EnrollmentId
		{
			get
			{
				EnrollmentCollection col = new EnrollmentCollection();
				Enrollment e = new Enrollment();
					e.EnrollmentID = 0;
					e.Description = "All";
				col.AddRecord(e);
				col.CopyElementsFrom(EnrollmentCollection.AllEnrollmentsByValidDateRange, true, false);
				return col;
				
				//return EnrollmentCollection.AllEnrollmentsByValidDateRange; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Parent LetterMatrixExceptionCollection that contains this element
		/// </summary>
		public LetterMatrixExceptionCollection ParentLetterMatrixExceptionCollection
		{
			get
			{
				return this.parentLetterMatrixExceptionCollection;
			}
			set
			{
				this.parentLetterMatrixExceptionCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}
	}

	/// <summary>
	/// Strongly typed collection of LetterMatrixException objects
	/// </summary>
	[ElementType(typeof(LetterMatrixException))]
	public class LetterMatrixExceptionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LetterMatrixException elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLetterMatrixExceptionCollection = this;
			else
				elem.ParentLetterMatrixExceptionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LetterMatrixException elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LetterMatrixException this[int index]
		{
			get
			{
				return (LetterMatrixException)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LetterMatrixException)oldValue, false);
			SetParentOnElem((LetterMatrixException)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(LetterMatrixException elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((LetterMatrixException)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent LetterMatrix that contains this collection
		/// </summary>
		public LetterMatrix ParentLetterMatrix
		{
			get { return this.ParentDataObject as LetterMatrix; }
			set { this.ParentDataObject = value; /* parent is set when contained by a LetterMatrix */ }
		}

		
	}
}
