using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSPhases]
	/// </summary>
	[SPAutoGen("usp_SearchAllCMSPhases","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllCMSPhasesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllCMSPhases","SelectAll.sptpl","")]
	[SPInsert("usp_InsertCMSPhase")]
	[SPUpdate("usp_UpdateCMSPhase")]
	[SPDelete("usp_DeleteCMSPhase")]
	[SPLoad("usp_LoadCMSPhase")]
	[TableMapping("CMSPhase","phaseId")]
	public class CMSPhase : NetsoftUSA.DataLayer.BaseDataClass
	{
		[NonSerialized]
		private CMSPhaseCollection parentCMSPhaseCollection;
		[ColumnMapping("PhaseId",StereoType=DataStereoType.FK)]
		private int phaseId;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
	
		public CMSPhase()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PhaseId
		{
			get { return this.phaseId; }
			set { this.phaseId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=8)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Parent CMSPhaseCollection that contains this element
		/// </summary>
		public CMSPhaseCollection ParentCMSPhaseCollection
		{
			get
			{
				return this.parentCMSPhaseCollection;
			}
			set
			{
				this.parentCMSPhaseCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int phaseId)
		{
			return base.Load(phaseId);
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int phaseId)
		{
			base.Delete(phaseId);		
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active	= true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}


		/// <summary>
		/// Reads multiple objects of this type from source data reader into the given collection
		/// </summary>
		public int ReadCollection(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords, CMSPhaseCollection collection)
		{
			return SqlData.ReadCollection(sourceReader, maxRecords, collection, typeof(CMSPhase), true, false);
		}

		/// <summary>
		/// Use this function to test Load method
		/// </summary>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void TestLoad()
		{
			CMSPhase obj = new CMSPhase();
			obj.Load(1);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(2);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(3);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
		
		}
	}

	/// <summary>
	/// Strongly typed collection of CMSPhase objects
	/// </summary>
	[ElementType(typeof(CMSPhase))]
	public class CMSPhaseCollection : BaseTypeCollection
	{
		

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSPhase elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSPhaseCollection = this;
			else
				elem.ParentCMSPhaseCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSPhase elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSPhase this[int index]
		{
			get
			{
				return (CMSPhase)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSPhase)oldValue, false);
			SetParentOnElem((CMSPhase)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
		
		

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}
		
		/// <summary>
		///  Load all Facility Focus Types.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllCMSPhases", -1, this, false);
		}
		
		/// <summary>
		///  Searches for Focus Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchAllCMSPhases", -1, this, false, code, description, active);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllCMSPhasesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllCMSPhasesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared CMSPhaseCollection which is cached in NSGlobal
		/// </summary>
		public static CMSPhaseCollection ActiveCMSPhases
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				CMSPhaseCollection col = (CMSPhaseCollection)NSGlobal.EnsureCachedObject("ActiveCMSPhases", typeof(CMSPhaseCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllCMSPhasesByActive(-1, true);
				}
				return col;
			}
			
		}

		
	}
}
