using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSRisks]
	/// </summary>
	[SPAutoGen("usp_SearchCMSRisks","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllCMSRisksByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllCMSRisks","SelectAll.sptpl","")]
	[SPInsert("usp_InsertCMSRisk")]
	[SPUpdate("usp_UpdateCMSRisk")]
	[SPDelete("usp_DeleteCMSRisk")]
	[SPLoad("usp_LoadCMSRisk")]
	[TableMapping("CMSRisk","cMSRiskId")]
	public class CMSRisk : NetsoftUSA.DataLayer.BaseDataClass
	{
		[NonSerialized]
		private CMSRiskCollection parentCMSRiskCollection;
		[ColumnMapping("CMSRiskId",StereoType=DataStereoType.FK)]
		private int cMSRiskId;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
	
		public CMSRisk()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CMSRiskId
		{
			get { return this.cMSRiskId; }
			set { this.cMSRiskId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=8)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int cMSRiskId)
		{
			return base.Load(cMSRiskId);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int cMSRiskId)
		{
			base.Delete(cMSRiskId);		
		}

		/// <summary>
		/// Parent CMSRiskCollection that contains this element
		/// </summary>
		public CMSRiskCollection ParentCMSRiskCollection
		{
			get
			{
				return this.parentCMSRiskCollection;
			}
			set
			{
				this.parentCMSRiskCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active	= true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Use this function to test Load method
		/// </summary>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void TestLoad()
		{
			CMSRisk obj = new CMSRisk();
			obj.Load(1);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(2);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(3);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
		
		}
	}

	/// <summary>
	/// Strongly typed collection of CMSRisk objects
	/// </summary>
	[ElementType(typeof(CMSRisk))]
	public class CMSRiskCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_CMSRiskId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSRisk elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSRiskCollection = this;
			else
				elem.ParentCMSRiskCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSRisk elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSRisk this[int index]
		{
			get
			{
				return (CMSRisk)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSRisk)oldValue, false);
			SetParentOnElem((CMSRisk)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		
		

		/// <summary>
		///  Load all Facility Focus Types.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllCMSRisks", -1, this, false);
		}

		/// <summary>
		///  Searches for Focus Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchAllCMSRisks", -1, this, false, code, description, active);
		}

		

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllCMSRisksByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllCMSRisksByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared CMSRiskCollection which is cached in NSGlobal
		/// </summary>
		public static CMSRiskCollection ActiveCMSRisks
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				CMSRiskCollection col = (CMSRiskCollection)NSGlobal.EnsureCachedObject("ActiveCMSRisks", typeof(CMSRiskCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllCMSRisksByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on cMSRiskId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_CMSRiskId
		{
			get
			{
				if (this.indexBy_CMSRiskId == null)
					this.indexBy_CMSRiskId = new CollectionIndexer(this, new string[] { "cMSRiskId" }, true);
				return this.indexBy_CMSRiskId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on cMSRiskId fields returns the object.  Uses the IndexBy_CMSRiskId indexer.
		/// </summary>
		public CMSRisk FindBy(int cMSRiskId)
		{
			return (CMSRisk)this.IndexBy_CMSRiskId.GetObject(cMSRiskId);
		}
	}
}
