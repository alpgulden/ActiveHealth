using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PackingListItemTrigger]
	/// </summary>
	
	
	[SPAutoGen("usp_LoadPackingListItemTriggerByPackingListItemId","SelectAllByGivenArgs.sptpl","packingListItemId")]
	[SPAutoGen("usp_GetAllPackingListItemTriggers","SelectAll.sptpl","", InjectOrderBy="ORDER BY [PackingListItemTrigger].[SortOrder]")]
	[SPAutoGen("usp_GetPLItemTriggerByPLItemIdMorgOrgSorgPlanEnrollment","","packingListItemId, mORGId, oRGId, sORGId, planId, enrollmentId, logicId, questionnaireID")]
	[SPInsert("usp_InsertPackingListItemTrigger")]
	[SPUpdate("usp_UpdatePackingListItemTrigger")]
	[SPDelete("usp_DeletePackingListItemTrigger")]
	[SPLoad("usp_LoadPackingListItemTrigger")]
	[TableMapping("PackingListItemTrigger","packingListItemTriggerId")]
	public class PackingListItemTrigger : BaseData
	{
		[NonSerialized]
		private PackingListItemTriggerCollection parentPackingListItemTriggerCollection;
		[ColumnMapping("PackingListItemTriggerId",StereoType=DataStereoType.FK)]
		private int packingListItemTriggerId;
		[ColumnMapping("PackingListItemId")]
		private int packingListItemId;
		[ColumnMapping("MORGId",StereoType=DataStereoType.FK)]
		private int mORGId;
		[ColumnMapping("ORGId",StereoType=DataStereoType.FK)]
		private int oRGId;
		[ColumnMapping("SORGId",StereoType=DataStereoType.FK)]
		private int sORGId;
		[ColumnMapping("PlanId",StereoType=DataStereoType.FK)]
		private int planId;
		[ColumnMapping("EnrollmentId",StereoType=DataStereoType.FK)]
		private int enrollmentId;
		[ColumnMapping("LogicId",StereoType=DataStereoType.FK)]
		private int logicId;
		[ColumnMapping("QuestionnaireID",StereoType=DataStereoType.FK)]
		private int questionnaireID;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreationTime")]
		private DateTime creationTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModificationTime")]
		private DateTime modificationTime;
		[ColumnMapping("DefaultItem")]
		private bool defaultItem;
		[ColumnMapping("SortOrder")]
		
		private int sortOrder;
		private Enrollment enrollment;
		private string logicDescription;
		private int organizationId;
		private string organizationPath;
		private string planName;
	
		public PackingListItemTrigger()
		{
		}

		public PackingListItemTrigger(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PackingListItemTriggerId
		{
			get { return this.packingListItemTriggerId; }
			set { this.packingListItemTriggerId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PackingListItemId
		{
			get { return this.packingListItemId; }
			set { this.packingListItemId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int MORGId
		{
			get { return this.mORGId; }
			//set { this.mORGId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ORGId
		{
			get { return this.oRGId; }
			//set { this.oRGId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int SORGId
		{
			get { return this.sORGId; }
			//set { this.sORGId = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string OrganizationPath
		{
			get { return this.organizationPath; }
			set { this.organizationPath = value; }
		}
		
		[FieldDescription("@ORGANIZATIONID@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int OrganizationId
		{
			get { return this.organizationId; }
			set 
			{ 
				this.organizationId = value; 
				//determine level of given Organization and set ID's accordingly
				Organization o = new Organization();
				if ( this.organizationId < 1)
					return;
				if (o.Load(this.organizationId))
				{
					switch (o.OrganizationLevel.Code)
					{
						case "MORG":
							this.mORGId = this.organizationId;
							this.oRGId = 0;
							this.sORGId = 0;
							break;
						case "ORG":
							this.mORGId = 0;
							this.oRGId = this.organizationId;
							this.sORGId = 0;
							break;
						case "SORG":
							this.mORGId = 0;
							this.oRGId = 0;
							this.sORGId = this.organizationId;
							break;
						default:
							return;
					}
				}
			}
		}
		
		[ControlType(EnumControlTypes.TextBox)]
		public string PlanName
		{
			get { return this.planName; }
			set { this.planName = value; }
		}

		[FieldDescription("@PLAN@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}

		[FieldDescription("@LOGIC@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int LogicId
		{
			get { return this.logicId; }
			set { this.logicId = value; }
		}

		[FieldDescription("@QUESTIONNAIRE@")]
		[FieldValuesMember("LookupOf_QuestionnaireID", "QuestionnaireID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool DefaultItem
		{
			get { return this.defaultItem; }
			set { this.defaultItem = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreationTime
		{
			get { return this.creationTime; }
			set { this.creationTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModificationTime
		{
			get { return this.modificationTime; }
			set { this.modificationTime = value; }
		}

		[FieldDescription("@ENROLLMENT@")]
		[FieldValuesMember("LookupOf_EnrollmentId", "EnrollmentID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		public int EnrollmentId
		{
			get { return this.enrollmentId; }
			set { this.enrollmentId = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string LogicDescription
		{
			get { return this.logicDescription; }
			set { this.logicDescription = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int packingListItemTriggerId)
		{
			return base.Load(packingListItemTriggerId);
		}

		/// <summary>
		/// Parent PackingListItemTriggerCollection that contains this element
		/// </summary>
		public PackingListItemTriggerCollection ParentPackingListItemTriggerCollection
		{
			get
			{
				return this.parentPackingListItemTriggerCollection;
			}
			set
			{
				this.parentPackingListItemTriggerCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool GetPLItemTriggerByPLItemIdMorgOrgSorgPlanEnrollment(int packingListItemId, PackingListItemTrigger trigger)
		{
			return SqlData.SPExecReadObj("usp_GetPLItemTriggerByPLItemIdMorgOrgSorgPlanEnrollment", this, trigger, false, new string[] { "packingListItemId" }, new object[] { packingListItemId } );	
		}

		/// <summary>
		/// Contained Enrollment object
		/// </summary>
		public Enrollment Enrollment
		{
			get
			{
				if (enrollmentId == 0)
					return null;
				if (this.enrollment != null)
					return this.enrollment;
				if (enrollmentId > 0)
				{
					if (this.enrollment.Load(enrollmentId))
						return this.enrollment;
					else
						return null;
				}
				return null;
			}
			set
			{
				this.enrollment = value;
				if (value != null) 
				{
					value.ParentPackingListItemTrigger = this; // set this as a parent of the child data class
					enrollmentId = value.EnrollmentID;
				}
			}
		}

		public EnrollmentCollection LookupOf_EnrollmentId
		{
			get
			{
				return EnrollmentCollection.AllEnrollmentsByValidDateRange; // Acquire a shared instance from the static member of collection
			}
		}

		public QuestionnaireCollection LookupOf_QuestionnaireID
		{
			get
			{
				return QuestionnaireCollection.ActiveQuestionnaires; // Acquire a shared instance from the static member of collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of PackingListItemTrigger objects
	/// </summary>
	[ElementType(typeof(PackingListItemTrigger))]
	public class PackingListItemTriggerCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PackingListItemTriggerId;
		[NonSerialized]
		private CollectionIndexer indexBy_PackingListItemId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PackingListItemTrigger elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPackingListItemTriggerCollection = this;
			else
				elem.ParentPackingListItemTriggerCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PackingListItemTrigger elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PackingListItemTrigger this[int index]
		{
			get
			{
				return (PackingListItemTrigger)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PackingListItemTrigger)oldValue, false);
			SetParentOnElem((PackingListItemTrigger)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PackingListItemTrigger elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PackingListItemTrigger)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Returns true if the collection contains the given object
		/// </summary>
		public bool Contains(PackingListItemTrigger elem)
		{
			return List.Contains(elem);
			
		}

		/// <summary>
		/// Sorts the collection elements by the given members
		/// </summary>
		public void SortByMembers(bool ascending, bool ignoreCase, params string[] memberNames)
		{
			CollectionUtil.SortBy(this, ascending, ignoreCase, memberNames);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllPackingListItemTriggers(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPackingListItemTriggers", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared PackingListItemTriggerCollection which is cached in NSGlobal
		/// </summary>
		public static PackingListItemTriggerCollection AllPackingListItemTriggers
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				PackingListItemTriggerCollection col = (PackingListItemTriggerCollection)NSGlobal.EnsureCachedObject("AllPackingListItemTriggers", typeof(PackingListItemTriggerCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllPackingListItemTriggers(-1);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadPackingListItemTriggersByPackingListItemId(int packingListItemId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadPackingListItemTriggerByPackingListItemId", -1, this, false, packingListItemId);
		}

		/// <summary>
		/// Parent PackingListItem that contains this collection
		/// </summary>
		public PackingListItem ParentPackingListItem
		{
			get { return this.ParentDataObject as PackingListItem; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PackingListItem */ }
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Hashtable based index on packingListItemTriggerId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PackingListItemTriggerId
		{
			get
			{
				if (this.indexBy_PackingListItemTriggerId == null)
					this.indexBy_PackingListItemTriggerId = new CollectionIndexer(this, new string[] { "packingListItemTriggerId" }, true);
				return this.indexBy_PackingListItemTriggerId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on packingListItemTriggerId fields returns the object.  Uses the IndexBy_PackingListItemTriggerId indexer.
		/// </summary>
		public PackingListItemTrigger FindBy(int packingListItemTriggerId)
		{
			return (PackingListItemTrigger)this.IndexBy_PackingListItemTriggerId.GetObject(packingListItemTriggerId);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(PackingListItemTrigger elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((PackingListItemTrigger)value, false);
			base.OnRemoveComplete (index, value);		
		}
	}
}
