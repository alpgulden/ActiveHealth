using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSFacility]
	/// </summary>
	[SPInsert("usp_InsertCMSFacility")]
	[SPUpdate("usp_UpdateCMSFacility")]
	[SPDelete("usp_DeleteCMSFacility")]
	[SPLoad("usp_LoadCMSFacility")]
	[TableMapping("CMSFacility","cMSFacilityID")]
	public class CMSFacility : BaseData
	{
		[NonSerialized]
		private CMSFacilityCollection parentCMSFacilityCollection;
		[ColumnMapping("CMSFacilityID",(int)0)]
		private int cMSFacilityID;
		[ColumnMapping("CMSID",StereoType=DataStereoType.FK)]
		private int cMSID;
		[ColumnMapping("FacilityLocationID",StereoType=DataStereoType.FK)]
		private int facilityLocationID;
		[ColumnMapping("FacilityID",StereoType=DataStereoType.FK)]
		private int facilityID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

		private int facilityTypeID;
		private int facilityLocationNetworkID;
		private bool facilityNetworkStatus;
		private System.DateTime startDate;
	
		public CMSFacility()
		{
		}

		public CMSFacility(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int CMSFacilityID
		{
			get { return this.cMSFacilityID; }
			set { this.cMSFacilityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int FacilityLocationID
		{
			get { return this.facilityLocationID; }
			set { this.facilityLocationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int FacilityID
		{
			get { return this.facilityID; }
			set { this.facilityID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			set { this.modifyTime = value; }
		}

		#region Not mapped properties
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@FACILITYTYPEID@")]
		public int FacilityTypeID
		{
			get { return this.facilityTypeID; }
			set { this.facilityTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@FACILITYLOCATIONNETWORKID@")]
		public int FacilityLocationNetworkID
		{
			get { return this.facilityLocationNetworkID; }
			set { this.facilityLocationNetworkID = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int FacilityNetworkStatusInt
		{
			get { return (this.facilityNetworkStatus ? 1 : 0); }
			set { this.facilityNetworkStatus = (value == 1 ? true : false);}
		}
		
		[ControlType(EnumControlTypes.CheckBox)]
		public bool FacilityNetworkStatus
		{
			get { return this.facilityNetworkStatus; }
			set { this.facilityNetworkStatus = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}
		#endregion
		

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent CMSFacilityCollection that contains this element
		/// </summary>
		public CMSFacilityCollection ParentCMSFacilityCollection
		{
			get
			{
				return this.parentCMSFacilityCollection;
			}
			set
			{
				this.parentCMSFacilityCollection = value; // parent is set when added to a collection
			}
		}

		
	}

	/// <summary>
	/// Strongly typed collection of CMSFacility objects
	/// </summary>
	[ElementType(typeof(CMSFacility))]
	public class CMSFacilityCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSFacility elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSFacilityCollection = this;
			else
				elem.ParentCMSFacilityCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSFacility elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSFacility this[int index]
		{
			get
			{
				return (CMSFacility)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSFacility)oldValue, false);
			SetParentOnElem((CMSFacility)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(CMSFacility elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((CMSFacility)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}
	}
}
