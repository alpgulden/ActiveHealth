using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [POCGoalTerm]
	/// </summary>
	[SPAutoGen("usp_SearchPOCGoalTermsByCodeDescriptionActive","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllPOCGoalTermsByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllPOCGoalTerms","SelectAll.sptpl","")]
	[SPInsert("usp_InsertPOCGoalTerm")]
	[SPUpdate("usp_UpdatePOCGoalTerm")]
	[SPDelete("usp_DeletePOCGoalTerm")]
	[SPLoad("usp_LoadPOCGoalTerm")]
	[TableMapping("POCGoalTerm","goalTermId")]
	public class POCGoalTerm : BaseLookupWithCode
	{
		[NonSerialized]
		private POCGoalTermCollection parentPOCGoalTermCollection;
		[ColumnMapping("GoalTermId",StereoType=DataStereoType.FK)]
		private int goalTermId;

		public static string GOALTERMSHORT = "POCGTS";
	
		public POCGoalTerm()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GoalTermId
		{
			get { return this.goalTermId; }
			set { this.goalTermId = value; }
		}

		/// <summary>
		/// Parent POCGoalTermCollection that contains this element
		/// </summary>
		public POCGoalTermCollection ParentPOCGoalTermCollection
		{
			get
			{
				return this.parentPOCGoalTermCollection;
			}
			set
			{
				this.parentPOCGoalTermCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of POCGoalTerm objects
	/// </summary>
	[ElementType(typeof(POCGoalTerm))]
	public class POCGoalTermCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(POCGoalTerm elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPOCGoalTermCollection = this;
			else
				elem.ParentPOCGoalTermCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (POCGoalTerm elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public POCGoalTerm this[int index]
		{
			get
			{
				return (POCGoalTerm)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((POCGoalTerm)oldValue, false);
			SetParentOnElem((POCGoalTerm)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllPOCGoalTermsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPOCGoalTermsByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared POCGoalTermCollection which is cached in NSGlobal
		/// </summary>
		public static POCGoalTermCollection ActivePOCGoalTerms
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				POCGoalTermCollection col = (POCGoalTermCollection)NSGlobal.EnsureCachedObject("ActivePOCGoalTerms", typeof(POCGoalTermCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllPOCGoalTermsByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns GoalTermId value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_GoalTermIdByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("GoalTermId", code);
		}
	}
}
