using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [POCGoalType]
	/// </summary>
	
	[SPAutoGen("usp_SearchPOCGoalTypesByCodeDescriptionActive","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllPOCGoalTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllPOCGoalTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertPOCGoalType")]
	[SPUpdate("usp_UpdatePOCGoalType")]
	[SPDelete("usp_DeletePOCGoalType")]
	[SPLoad("usp_LoadPOCGoalType")]
	[TableMapping("POCGoalType","goalTypeId")]
	public class POCGoalType : BaseLookupWithCode
	{
		[NonSerialized]
		private POCGoalTypeCollection parentPOCGoalTypeCollection;
		[ColumnMapping("GoalTypeId",StereoType=DataStereoType.FK)]
		private int goalTypeId;
	
		public POCGoalType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GoalTypeId
		{
			get { return this.goalTypeId; }
			set { this.goalTypeId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int goalTypeId)
		{
			return base.Load(goalTypeId);
		}

		/// <summary>
		/// Parent POCGoalTypeCollection that contains this element
		/// </summary>
		public POCGoalTypeCollection ParentPOCGoalTypeCollection
		{
			get
			{
				return this.parentPOCGoalTypeCollection;
			}
			set
			{
				this.parentPOCGoalTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool SearchPOCGoalTypesByCodeDescriptionActive(string code, string description, bool active)
		{
			return SqlData.SPExecReadObj("usp_SearchPOCGoalTypesByCodeDescriptionActive", this, false, code, description, active);
		}
	}

	/// <summary>
	/// Strongly typed collection of POCGoalType objects
	/// </summary>
	[ElementType(typeof(POCGoalType))]
	public class POCGoalTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_GoalTypeId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(POCGoalType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPOCGoalTypeCollection = this;
			else
				elem.ParentPOCGoalTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (POCGoalType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public POCGoalType this[int index]
		{
			get
			{
				return (POCGoalType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((POCGoalType)oldValue, false);
			SetParentOnElem((POCGoalType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllPOCGoalTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPOCGoalTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared POCGoalTypeCollection which is cached in NSGlobal
		/// </summary>
		public static POCGoalTypeCollection ActivePOCGoalTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				POCGoalTypeCollection col = (POCGoalTypeCollection)NSGlobal.EnsureCachedObject("ActivePOCGoalTypes", typeof(POCGoalTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllPOCGoalTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on goalTypeId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_GoalTypeId
		{
			get
			{
				if (this.indexBy_GoalTypeId == null)
					this.indexBy_GoalTypeId = new CollectionIndexer(this, new string[] { "goalTypeId" }, true);
				return this.indexBy_GoalTypeId;
			}
			
		}

		/// <summary>
		/// Looks up by goalTypeId and returns Description value.  Uses the IndexBy_GoalTypeId indexer.
		/// </summary>
		public string Lookup_DescriptionByGoalTypeId(int goalTypeId)
		{
			return this.IndexBy_GoalTypeId.LookupStringMember("Description", goalTypeId);
		}
	}
}
