using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [POCDeficitPriority]
	/// </summary>
	[SPAutoGen("usp_SearchPOCDeficitPrioritiesByCodeDescriptionActive","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllPOCDeficitPrioritiesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllPOCDeficitPriorities","SelectAll.sptpl","")]
	[SPInsert("usp_InsertPOCDeficitPriority")]
	[SPUpdate("usp_UpdatePOCDeficitPriority")]
	[SPDelete("usp_DeletePOCDeficitPriority")]
	[SPLoad("usp_LoadPOCDeficitPriority")]
	[TableMapping("POCDeficitPriority","deficitPriorityId")]
	public class POCDeficitPriority : BaseLookupWithCode
	{
		[NonSerialized]
		private POCDeficitPriorityCollection parentPOCDeficitPriorityCollection;
		[ColumnMapping("DeficitPriorityId",StereoType=DataStereoType.FK)]
		private int deficitPriorityId;
	
		public POCDeficitPriority()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int DeficitPriorityId
		{
			get { return this.deficitPriorityId; }
			set { this.deficitPriorityId = value; }
		}

		/// <summary>
		/// Parent POCDeficitPriorityCollection that contains this element
		/// </summary>
		public POCDeficitPriorityCollection ParentPOCDeficitPriorityCollection
		{
			get
			{
				return this.parentPOCDeficitPriorityCollection;
			}
			set
			{
				this.parentPOCDeficitPriorityCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool SearchPOCDeficitPrioritiesByCodeDescriptionActive(string code, string description, bool active)
		{
			return SqlData.SPExecReadObj("usp_SearchPOCDeficitPrioritiesByCodeDescriptionActive", this, false, code, description, active);
		}
	}

	/// <summary>
	/// Strongly typed collection of POCDeficitPriority objects
	/// </summary>
	[ElementType(typeof(POCDeficitPriority))]
	public class POCDeficitPriorityCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(POCDeficitPriority elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPOCDeficitPriorityCollection = this;
			else
				elem.ParentPOCDeficitPriorityCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (POCDeficitPriority elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public POCDeficitPriority this[int index]
		{
			get
			{
				return (POCDeficitPriority)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((POCDeficitPriority)oldValue, false);
			SetParentOnElem((POCDeficitPriority)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllPOCDeficitPrioritiesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPOCDeficitPrioritiesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared POCDeficitPriorityCollection which is cached in NSGlobal
		/// </summary>
		public static POCDeficitPriorityCollection ActivePOCDeficitPriorities
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				POCDeficitPriorityCollection col = (POCDeficitPriorityCollection)NSGlobal.EnsureCachedObject("ActivePOCDeficitPriorities", typeof(POCDeficitPriorityCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllPOCDeficitPrioritiesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
