using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [POCGoalReason]
	/// </summary>
	[SPAutoGen("usp_SearchPOCGoalReasonsByCodeDescriptionActive","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllPOCGoalReasonsByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllPOCGoalReasons","SelectAll.sptpl","")]
	[SPInsert("usp_InsertPOCGoalReason")]
	[SPUpdate("usp_UpdatePOCGoalReason")]
	[SPDelete("usp_DeletePOCGoalReason")]
	[SPLoad("usp_LoadPOCGoalReason")]
	[TableMapping("POCGoalReason","goalReasonId")]
	public class POCGoalReason : BaseLookupWithCode
	{
		[NonSerialized]
		private POCGoalReasonCollection parentPOCGoalReasonCollection;
		[ColumnMapping("GoalReasonId",StereoType=DataStereoType.FK)]
		private int goalReasonId;
	
		public POCGoalReason()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int GoalReasonId
		{
			get { return this.goalReasonId; }
			set { this.goalReasonId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int goalReasonId)
		{
			return base.Load(goalReasonId);
		}

		/// <summary>
		/// Parent POCGoalReasonCollection that contains this element
		/// </summary>
		public POCGoalReasonCollection ParentPOCGoalReasonCollection
		{
			get
			{
				return this.parentPOCGoalReasonCollection;
			}
			set
			{
				this.parentPOCGoalReasonCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool SearchPOCGoalReasonsByCodeDescriptionActive(string code, string description, bool active)
		{
			return SqlData.SPExecReadObj("usp_SearchPOCGoalReasonsByCodeDescriptionActive", this, false, code, description, active);
		}
	}

	/// <summary>
	/// Strongly typed collection of POCGoalReason objects
	/// </summary>
	[ElementType(typeof(POCGoalReason))]
	public class POCGoalReasonCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(POCGoalReason elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPOCGoalReasonCollection = this;
			else
				elem.ParentPOCGoalReasonCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (POCGoalReason elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public POCGoalReason this[int index]
		{
			get
			{
				return (POCGoalReason)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((POCGoalReason)oldValue, false);
			SetParentOnElem((POCGoalReason)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllPOCGoalReasonsByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPOCGoalReasonsByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared POCGoalReasonCollection which is cached in NSGlobal
		/// </summary>
		public static POCGoalReasonCollection ActivePOCGoalReasons
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				POCGoalReasonCollection col = (POCGoalReasonCollection)NSGlobal.EnsureCachedObject("ActivePOCGoalReasons", typeof(POCGoalReasonCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllPOCGoalReasonsByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
