using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [POCIntervention]
	/// </summary>
	[SPInsert("usp_InsertPOCIntervention")]
	[SPUpdate("usp_UpdatePOCIntervention")]
	[SPDelete("usp_DeletePOCIntervention")]
	[SPLoad("usp_LoadPOCIntervention")]
	[TableMapping("POCIntervention","pOCInterventionID")]
	public class POCIntervention : BaseData
	{
		[NonSerialized]
		private POCInterventionCollection parentPOCInterventionCollection;
		[ColumnMapping("POCInterventionID",StereoType=DataStereoType.FK)]
		private int pOCInterventionID;
		[ColumnMapping("GoalID")]
		private int goalID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("DueDate")]
		private DateTime dueDate;
		[ColumnMapping("AssignedUserID",StereoType=DataStereoType.FK)]
		private int assignedUserID;
		[ColumnMapping("AssignedTeamID",StereoType=DataStereoType.FK)]
		private int assignedTeamID;
		[ColumnMapping("InterventionTypeID",StereoType=DataStereoType.FK)]
		private int interventionTypeID;

		private int activityPrimaryTypeID;

		[ColumnMapping("InterventionStatusID",StereoType=DataStereoType.FK)]
		private int interventionStatusID;
		[ColumnMapping("Comment")]
		private string comment;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ActivityID",StereoType=DataStereoType.FK)]
		private int activityID;
		[ColumnMapping("ManagementServiceItemID")]
		private int managementServiceItemID;

		private ManagementServiceItem managementServiceItem;
		
		
		[ColumnMapping("InterventionAmount",StereoType=DataStereoType.FK)]
		private int interventionAmount;
		[ColumnMapping("BaseUOMID",StereoType=DataStereoType.FK)]
		private int baseUOMID;
		[ColumnMapping("ManagementServiceRate")]
		private Decimal managementServiceRate;
		[ColumnMapping("IsBillable")]
		private bool isBillable;
		[ColumnMapping("BillableAmount")]
		private Decimal billableAmount;
		[ColumnMapping("ConversionUnitOfMeasureID")]
		private int conversionUnitOfMeasureID;
		
		[ColumnMapping("CompletionID",StereoType=DataStereoType.FK)]
		private int completionID;
		[ColumnMapping("CompletionDate")]
		private DateTime completionDate;
		[ColumnMapping("BaseAmount")]
		private Decimal baseAmount;
		[ColumnMapping("ExtendedAmount")]
		private Decimal extendedAmount;
		[ColumnMapping("BaseConversionMultiplier")]
		private Decimal baseConversionMultiplier;
		[ColumnMapping("BaseConversionDivider")]
		private Decimal baseConversionDivider;
		[ColumnMapping("ActivitySubTypeID",StereoType=DataStereoType.FK)]
		private int activitySubTypeID;
		[ColumnMapping("StatusChangedBy",StereoType=DataStereoType.FK)]
		private int statusChangedBy;
		[ColumnMapping("StatusDate")]
		private DateTime statusDate;

		public static string COMPLETE = "POCINCM"; // POCInterventionStatus code for Complete
	
		public POCIntervention()
		{
			 
		}

		public POCIntervention(bool initNew)
		{
			//ManagementServiceItem managementServiceItem = new ManagementServiceItem();
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int POCInterventionID
		{
			get { return this.pOCInterventionID; }
			set { this.pOCInterventionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int GoalID
		{
			get { return this.goalID; }
			set { this.goalID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=500)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DUEDATE@")]
		public System.DateTime DueDate
		{
			get { return this.dueDate; }
			set { this.dueDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@ASSIGNEDUSER@")]
		public int AssignedUserID
		{
			get { return this.assignedUserID; }
			set { this.assignedUserID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@ASSIGNEDTEAM@")]
		public int AssignedTeamID
		{
			get { return this.assignedTeamID; }
			set { this.assignedTeamID = value; }
		}

		
		[FieldValuesMember("LookupOf_InterventionTypeID", "ActivityTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@INTERVENTIONTYPEID@")]
		public int InterventionTypeID
		{
			get { return this.interventionTypeID; }
			set { this.interventionTypeID = value; }
		}

		
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldValuesMember("LookupOf_ActivityPrimaryTypeID", "ActivityPrimaryTypeID", "Description")]
		[FieldDescription("@PRIMARYTYPE@")]
		public int ActivityPrimaryTypeID
		{
			get { return this.activityPrimaryTypeID; }
			set { this.activityPrimaryTypeID = value; }
		}

		[FieldValuesMember("LookupOf_InterventionStatusID", "InterventionStatusId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@STATUS@")]
		public int InterventionStatusID
		{
			get { return this.interventionStatusID; }
			set { this.interventionStatusID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string Comment
		{
			get { return this.comment; }
			set { this.comment = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ActivityID
		{
			get { return this.activityID; }
			set { this.activityID = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@AMOUNT@")]
		public int InterventionAmount
		{
			get { return this.interventionAmount; }
			set { this.interventionAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@BASEUOMID@")]
		public int BaseUOMID
		{
			get { return this.baseUOMID; }
			set { this.baseUOMID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal ManagementServiceRate
		{
			get { return this.managementServiceRate; }
			set { this.managementServiceRate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@BILLABLE@")]
		public bool IsBillable
		{
			get { return this.isBillable; }
			set { this.isBillable = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		[FieldDescription("@TOTAL@")]
		public decimal BillableAmount
		{
			get { return this.billableAmount; }
			set { this.billableAmount = value; }
		}

		
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CompletionID
		{
			get { return this.completionID; }
			set { this.completionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@COMPLETIONDATE@")]
		public System.DateTime CompletionDate
		{
			get { return this.completionDate; }
			set { this.completionDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@RATE@")]
		public decimal BaseAmount
		{
			get { return this.baseAmount; }
			set { this.baseAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public decimal ExtendedAmount
		{
			get { return this.extendedAmount; }
			set { this.extendedAmount = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal BaseConversionMultiplier
		{
			get { return this.baseConversionMultiplier; }
			set { this.baseConversionMultiplier = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal BaseConversionDivider
		{
			get { return this.baseConversionDivider; }
			set { this.baseConversionDivider = value; }
		}

		[FieldValuesMember("LookupOf_ActivitySubTypeID", "ActivitySubtypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@ACTIVITYSUBTYPEID@")]
		public int ActivitySubTypeID
		{
			get { return this.activitySubTypeID; }
			set { this.activitySubTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int StatusChangedBy
		{
			get { return this.statusChangedBy; }
			set { this.statusChangedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime StatusDate
		{
			get { return this.statusDate; }
			set { this.statusDate = value; }
		}

		[FieldValuesMember("LookupOf_ManagementServiceItemID", "ManagementServiceItemId", "ServiceTypeDescription")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@MANAGEMENTSERVICETYPEID@")]
		public int ManagementServiceItemID
		{
			get { return this.managementServiceItemID; }
			set { this.managementServiceItemID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@UNITQUANTITY@")]
		public int ConversionUnitOfMeasureID
		{
			get { return this.conversionUnitOfMeasureID; }
			set { this.conversionUnitOfMeasureID = value; }
		}

		public POCInterventionStatusCollection LookupOf_InterventionStatusID
		{
			get
			{
				return POCInterventionStatusCollection.ActivePOCInterventionStatuses; // Acquire a shared instance from the static member of collection
			}
		}

		
		public ActiveAdvice.DataLayer.ManagementServiceItem ManagementServiceItem
		{
			get 
			{ 
				if (this.managementServiceItem == null)
					this.managementServiceItem = new ManagementServiceItem();
				return this.managementServiceItem; 
			}
			set 
			{ 
				if (value != null)
				{
					this.managementServiceItem = value; 

					this.BaseUOMID = value.BaseUnitOfMeasureId;
					this.conversionUnitOfMeasureID = value.ConversionUnitOfMeasureId;
					this.isBillable = value.Billable;
					this.managementServiceRate = value.Rate;
					this.baseConversionMultiplier = value.Multiplier;
					this.baseConversionDivider = value.Divider;
				}
				
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int pOCInterventionID)
		{
			return base.Load(pOCInterventionID);
		}

		/// <summary>
		/// Parent POCInterventionCollection that contains this element
		/// </summary>
		public POCInterventionCollection ParentPOCInterventionCollection
		{
			get
			{
				return this.parentPOCInterventionCollection;
			}
			set
			{
				this.parentPOCInterventionCollection = value; // parent is set when added to a collection
			}
		}

		

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.
		}

		public ActivityTypeCollection LookupOf_InterventionTypeID
		{
			get
			{
				if (this.activityPrimaryTypeID == 0)
					return ActivityTypeCollection.ActiveActivityTypes; // Acquire a shared instance from the static member of collection
				else
				{	//return ActivityTypes for selected ActivityTypeID	
					ActivityTypeCollection col = new ActivityTypeCollection();
					col.GetAllActivityTypesByPrimaryTypeIDActive(-1, activityPrimaryTypeID, true);
					return col;
				}
			}
		}

		public ActivitySubTypeCollection LookupOf_ActivitySubTypeID
		{
			get
			{
				return ActivitySubTypeCollection.ActiveActivitySubTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ActivityPrimaryTypeCollection LookupOf_ActivityPrimaryTypeID
		{
			get
			{
				return ActivityPrimaryTypeCollection.ActiveActivityPrimaryTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public ManagementServiceItemCollection LookupOf_ManagementServiceItemID
		{
			get
			{
				try
				{
					
					ManagementService mgmtSvc = ParentPOCInterventionCollection.ParentPOCGoal.ParentPOCGoalCollection.ParentPOCDeficit.ParentPOCDeficitCollection.ParentCMS.Plan.ManagementService;
					mgmtSvc.LoadManagementServiceItems(false);
					return mgmtSvc.ManagementServiceItems;
				}
				catch
				{
					//System.Diagnostics.Debug.WriteLine(ex);
					return null;
				}
			}
		}

		public bool Calculate()
		{
			bool result = true;
			if (this.managementServiceItem == null)
				return false;
			if (baseConversionDivider == 0 || baseConversionMultiplier == 0 || baseUOMID == 0
				|| conversionUnitOfMeasureID == 0 || managementServiceRate == 0)
				return false;
			decimal total;
			total = managementServiceRate / baseConversionDivider * baseConversionMultiplier * interventionAmount;
			baseAmount = total;
			extendedAmount = total;
			if (this.isBillable)
			{
				billableAmount = total;
			}
			else
			{
				billableAmount = 0;
			}
			return result;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]	
		public string Fmt_InterventionStatusID
		{
			get { return POCInterventionStatusCollection.ActivePOCInterventionStatuses.Lookup_CodeByInterventionStatusId(this.interventionStatusID); }
			set { this.interventionStatusID = POCInterventionStatusCollection.ActivePOCInterventionStatuses.Lookup_InterventionStatusIdByCode(value); }
		}

		
		public string Fmt_BaseUOMID
		{
			get 
			{ 
				if(this.baseUOMID == 0)
					return "";
				BaseUnitOfMeasureCollection.ActiveBaseUnitOfMeasures.IndexBy_BaseUnitOfMeasureId.Rebuild();
				return BaseUnitOfMeasureCollection.ActiveBaseUnitOfMeasures.Lookup_DescriptionByBaseUnitOfMeasureId(this.baseUOMID); 
			}
		}
		
		
		public string Fmt_ConversionUnitOfMeasureDescriptionByID
		{
			get 
			{
				if(this.conversionUnitOfMeasureID == 0)
					return "";
				ConversionUnitOfMeasureCollection.ActiveConversionUnitOfMeasures.IndexBy_ConversionUnitOfMeasureId.Rebuild();
				return ConversionUnitOfMeasureCollection.ActiveConversionUnitOfMeasures.Lookup_DescriptionByConversionUnitOfMeasureId(this.conversionUnitOfMeasureID); 
			}
		}
		
		
	}

	/// <summary>
	/// Strongly typed collection of POCIntervention objects
	/// </summary>
	[ElementType(typeof(POCIntervention))]
	public class POCInterventionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(POCIntervention elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPOCInterventionCollection = this;
			else
				elem.ParentPOCInterventionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (POCIntervention elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public POCIntervention this[int index]
		{
			get
			{
				return (POCIntervention)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((POCIntervention)oldValue, false);
			SetParentOnElem((POCIntervention)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(POCIntervention elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((POCIntervention)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Returns true if the collection contains the given object
		/// </summary>
		public bool Contains(POCIntervention elem)
		{
			return List.Contains(elem);
		}

		/// <summary>
		/// Parent POCGoal that contains this collection
		/// </summary>
		public POCGoal ParentPOCGoal
		{
			get { return this.ParentDataObject as POCGoal; }
			set { this.ParentDataObject = value; /* parent is set when contained by a POCGoal */ }
		}

		public bool IsPOCInterventionTypeInCollection(POCIntervention intrv, int type)
		{
			bool result = false;
			if (this.Count == 0)
				return false;
			if (type == 0)
				return false;
			for (int i = 0; i < this.Count; i++)
			{
				if ( !this[i].Equals(intrv))
				{
					if (this[i].InterventionTypeID == type)
						return true;
					else
						result = false;
				}
			}
			return result;
		}
	}
}
