using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [POCDeficit]
	/// </summary>
	[SPInsert("usp_InsertPOCDeficit")]
	[SPUpdate("usp_UpdatePOCDeficit")]
	[SPDelete("usp_DeletePOCDeficit")]
	[SPLoad("usp_LoadPOCDeficit")]
	[TableMapping("POCDeficit","deficitId")]
	public class POCDeficit : BaseData
	{
		[NonSerialized]
		private POCDeficitCollection parentPOCDeficitCollection;
		[ColumnMapping("DeficitId",StereoType=DataStereoType.FK)]
		private int deficitId;
		[ColumnMapping("CMSId")]
		private int cMSId;
		[ColumnMapping("DeficitPriorityId",StereoType=DataStereoType.FK)]
		private int deficitPriorityId;
		[ColumnMapping("DeficitStatusId",StereoType=DataStereoType.FK)]
		private int deficitStatusId;
		[ColumnMapping("DeficitSourceId",StereoType=DataStereoType.FK)]
		private int deficitSourceId;
		[ColumnMapping("Comment")]
		private string comment;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("DeficitTypeID",StereoType=DataStereoType.FK)]
		private int deficitTypeID;
		[ColumnMapping("DeficitTypeFFRM")]
		private string deficitTypeFFRM;
		private POCGoalCollection pOCGoals;
		
		
		private static string DEFICITSOURCESYSTEM = "POCDSSYS";
		private static string DEFICITSOURCEUSER = "POCDSUSR";

		public POCDeficit()
		{

		}

		public POCDeficit(bool initNew, bool fromAssessment)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			if(fromAssessment)
				this.DeficitSourceId = POCDeficitSourceCollection.ActivePOCDeficitSources.Lookup_IDByCode(DEFICITSOURCESYSTEM);
			else
				this.DeficitSourceId = POCDeficitSourceCollection.ActivePOCDeficitSources.Lookup_IDByCode(DEFICITSOURCEUSER);
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int DeficitId
		{
			get { return this.deficitId; }
			set { this.deficitId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		public int CMSId
		{
			get { return this.cMSId; }
			set { this.cMSId = value; }
		}

		[FieldValuesMember("LookupOf_DeficitPriorityId", "DeficitPriorityId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@PRIORITY@")]
		public int DeficitPriorityId
		{
			get { return this.deficitPriorityId; }
			set { this.deficitPriorityId = value; }
		}

		[FieldValuesMember("LookupOf_DeficitStatusId", "DeficitStatusId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, ValueForNull=(int)0)]
		[FieldDescription("@STATUS@")]
		public int DeficitStatusId
		{
			get { return this.deficitStatusId; }
			set { this.deficitStatusId = value; }
		}

		[FieldDescription("@CASESOURCEID@")]
		public string DeficitSourceDisplayOnly
		{
			get { return POCDeficitSourceCollection.ActivePOCDeficitSources.Lookup_DescriptionByDeficitSourceId(this.DeficitSourceId); }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@CASESOURCEID@")]
		public int DeficitSourceId
		{
			get { return this.deficitSourceId; }
			set { this.deficitSourceId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=200)]
		[FieldDescription("@COMMENT@")]
		public string Comment
		{
			get { return this.comment; }
			set { this.comment = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[FieldValuesMember("LookupOf_DeficitTypeID", "POCDeficitTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, ValueForNull=(int)0, IsRequired=true)]
		[FieldDescription("@DEFICITTYPEID@")]
		public int DeficitTypeID
		{
			get { return this.deficitTypeID; }
			set { this.deficitTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string DeficitTypeFFRM
		{
			get { return this.deficitTypeFFRM; }
			set { this.deficitTypeFFRM = value; }
		}

		[FieldDescription("@DEFICITTYPEID@")]
		public string DeficitType
		{
			get
			{
				if (this.deficitTypeID == 0)
					return deficitTypeFFRM;
				else
					return POCDeficitTypeCollection.ActivePOCDeficitTypes.Lookup_DescriptionByPOCDeficitTypeID(deficitTypeID);
			}
		}

		public POCDeficitPriorityCollection LookupOf_DeficitPriorityId
		{
			get
			{
				return POCDeficitPriorityCollection.ActivePOCDeficitPriorities; // Acquire a shared instance from the static member of collection
			}
		}

		public POCDeficitStatusCollection LookupOf_DeficitStatusId
		{
			get
			{
				return POCDeficitStatusCollection.ActivePOCDeficitStatuses; // Acquire a shared instance from the static member of collection
			}
		}

		public POCDeficitTypeCollection LookupOf_DeficitTypeID
		{
			get
			{
				return POCDeficitTypeCollection.ActivePOCDeficitTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int deficitId)
		{
			return base.Load(deficitId);
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			
		}

		/// <summary>
		/// Parent POCDeficitCollection that contains this element
		/// </summary>
		public POCDeficitCollection ParentPOCDeficitCollection
		{
			get
			{
				return this.parentPOCDeficitCollection;
			}
			set
			{
				this.parentPOCDeficitCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.
			//pOCGoals.SqlData.Transaction = this.SqlData.Transaction;
			SavePOCGoals();
		}

		/// <summary>
		/// Child POCGoals mapped to related rows of table POCGoal where [DeficitId] = [DeficitId]
		/// </summary>
		[SPLoadChild("usp_LoadPOCDeficitPOCGoal", "deficitId")]
		public POCGoalCollection POCGoals
		{
			get { return this.pOCGoals; }
			set
			{
				this.pOCGoals = value;
				if (value != null)
					value.ParentPOCDeficit = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the POCGoals collection
		/// </summary>
		public void LoadPOCGoals(bool forceReload)
		{
			this.pOCGoals = (POCGoalCollection)POCGoalCollection.LoadChildCollection("POCGoals", this, typeof(POCGoalCollection), pOCGoals, forceReload, null);
		}

		/// <summary>
		/// Saves the POCGoals collection
		/// </summary>
		public void SavePOCGoals()
		{
			POCGoalCollection.SaveChildCollection(this.pOCGoals, true);
		}

		/// <summary>
		/// Synchronizes the POCGoals collection
		/// </summary>
		public void SynchronizePOCGoals()
		{
			POCGoalCollection.SynchronizeChildCollection(this.pOCGoals, true);
		}

	
	}

	/// <summary>
	/// Strongly typed collection of POCDeficit objects
	/// </summary>
	[ElementType(typeof(POCDeficit))]
	public class POCDeficitCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_DeficitId;
		
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(POCDeficit elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPOCDeficitCollection = this;
			else
				elem.ParentPOCDeficitCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (POCDeficit elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public POCDeficit this[int index]
		{
			get
			{
				return (POCDeficit)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((POCDeficit)oldValue, false);
			SetParentOnElem((POCDeficit)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((POCDeficit)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(POCDeficit elem)
		{
			return AddRecord(elem);	
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}


		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}

		/// <summary>
		/// Returns true if the collection contains the given object
		/// </summary>
		public bool Contains(POCDeficit elem)
		{
			return List.Contains(elem);
		}

		public bool IsPOCDeficitTypeInCollection(POCDeficit def, int type)
		{
			bool result = false;
			if (this.Count == 0)
				return false;
			if (type == 0)
				return false;
			for (int i = 0; i < this.Count; i++)
			{
				if ( !this[i].Equals(def))
				{
					if (this[i].DeficitTypeID == type)
						return true;
					else
						result = false;
				}
			}
			return result;
		}

		
	}
}
