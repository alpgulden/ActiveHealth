using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PackingListItemSent]
	/// </summary>
	
	[SPAutoGen("usp_GetAllPackingListItemsSentByCMSid","SelectAllByGivenArgs.sptpl","cMSId")]
	
	[SPInsert("usp_InsertPackingListItemSent")]
	[SPUpdate("usp_UpdatePackingListItemSent")]
	[SPDelete("usp_DeletePackingListItemSent")]
	[SPLoad("usp_LoadPackingListItemSent")]
	[TableMapping("PackingListItemSent","packingListItemSentId")]
	public class PackingListItemSent : BaseData
	{
		[NonSerialized]
		private PackingListItemSentCollection parentPackingListItemSentCollection;
		[ColumnMapping("PackingListItemSentId",StereoType=DataStereoType.FK)]
		private int packingListItemSentId;
		[ColumnMapping("CMSId")]
		private int cMSId;
		[ColumnMapping("PackingListItemId")]
		private int packingListItemId;
		[ColumnMapping("AssessmentGUID")]
		private string assessmentGUID;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreationTime")]
		private DateTime creationTime;
	
		public static int COLUMNSLIMIT = 6;

		public PackingListItemSent()
		{
		}

		public PackingListItemSent(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int PackingListItemSentId
		{
			get { return this.packingListItemSentId; }
			set { this.packingListItemSentId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSId
		{
			get { return this.cMSId; }
			set { this.cMSId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PackingListItemId
		{
			get { return this.packingListItemId; }
			set { this.packingListItemId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreationTime
		{
			get { return this.creationTime; }
			set { this.creationTime = value; }
		}

		public string Description
		{
			get
			{
				PackingListItem item = new PackingListItem();
				item.Load(this.PackingListItemId);
				if (item != null)
					return item.Description;
				else
					return "Item not found.";
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int packingListItemSentId)
		{
			return base.Load(packingListItemSentId);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Parent PackingListItemSentCollection that contains this element
		/// </summary>
		public PackingListItemSentCollection ParentPackingListItemSentCollection
		{
			get
			{
				return this.parentPackingListItemSentCollection;
			}
			set
			{
				this.parentPackingListItemSentCollection = value; // parent is set when added to a collection
			}
		}
	}


	/// <summary>
	/// Strongly typed collection of PackingListItemSent objects
	/// </summary>
	[ElementType(typeof(PackingListItemSent))]
	public class PackingListItemSentCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_CreationTime;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PackingListItemSent elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPackingListItemSentCollection = this;
			else
				elem.ParentPackingListItemSentCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PackingListItemSent elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PackingListItemSent this[int index]
		{
			get
			{
				return (PackingListItemSent)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PackingListItemSent)oldValue, false);
			SetParentOnElem((PackingListItemSent)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set 
			{ 
				this.ParentDataObject = value; /* parent is set when contained by a CMS */ 
				foreach (PackingListItemSent item in this)
				{
					item.CMSId = value.CMSID;
				}
			}
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(PackingListItemSent elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((PackingListItemSent)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllPackingListItemsSentByCMSid(int cMSId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPackingListItemsSentByCMSid", -1, this, false, cMSId);
		}

		public void GetAllDistinctDatesFromCollection(PackingListItemSentCollection col)
		{
			this.Clear();
			if (col.Count > 0)
			{
				DateTime dt = col[0].CreationTime;
				this.Add(col[0]);
				for (int i = 1; i < col.Count; i++)
				{
					if (dt != col[i].CreationTime)
					{
						dt = col[i].CreationTime;
						this.Add(col[i]);
					}
				}
			}
		}

		public bool ContainsItemWithIdCreateTime(int id, DateTime createTime)
		{
			bool result = false;
			foreach (PackingListItemSent item in this)
			{
				if ( item.PackingListItemId == id & item.CreationTime == createTime)
					return true;
				else
					result = false;
			}
			return result;
		}

		/// <summary>
		/// Sorts the collection elements by the given members
		/// </summary>
		public void SortByMembers(bool ascending, bool ignoreCase, params string[] memberNames)
		{
			CollectionUtil.SortBy(this, ascending, ignoreCase, memberNames);		
		}

		

		
	}
}
