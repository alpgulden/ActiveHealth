using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSStatusHistory]
	/// </summary>

	[SPAutoGen("usp_GetMostRecentCMSStatusHistoryByCMSId","SelectTop1.sptpl","createTime, DESC, cMSId")]
	[SPInsert("usp_InsertCMSStatusHistory")]
	[SPUpdate("usp_UpdateCMSStatusHistory")]
	[SPDelete("usp_DeleteCMSStatusHistory")]
	[SPLoad("usp_LoadCMSStatusHistory")]
	[TableMapping("CMSStatusHistory","cMSStatusId")]
	public class CMSStatusHistory : BaseData
	{
		[NonSerialized]
		private CMSStatusHistoryCollection parentCMSStatusHistoryCollection;
		[ColumnMapping("CMSStatusId",StereoType=DataStereoType.FK)]
		private int cMSStatusId;
		[ColumnMapping("CMSId")]
		private int cMSId;
		[ColumnMapping("CMSRiskId",StereoType=DataStereoType.FK)]
		private int cMSRiskId;
		[ColumnMapping("AcuityId",StereoType=DataStereoType.FK)]
		private int acuityId;
		[ColumnMapping("PhaseId",StereoType=DataStereoType.FK)]
		private int phaseId;
		[ColumnMapping("IntensityId",StereoType=DataStereoType.FK)]
		private int intensityId;
		[ColumnMapping("AssignedUserId",StereoType=DataStereoType.FK)]
		private int assignedUserId;
		[ColumnMapping("AssignedTeamId",StereoType=DataStereoType.FK)]
		private int assignedTeamId;
		//[ValidatorMember("Vld_StatusId")]
		[ColumnMapping("StatusId")]
		private int statusId;
		[ColumnMapping("CMSStatusChangeTime")]
		private DateTime cMSStatusChangeTime;
		[ColumnMapping("StatusTypeId",StereoType=DataStereoType.FK)]
		private int statusTypeId;
		[ColumnMapping("StatusText")]
		private string statusText;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("Prognosis")]
		private string prognosis;

		//these members should be excluded when two objects are being compared
		public static string[] EXCLUDEDMEMBERS = 
			new string[] {"cMSStatusId", "cMSId", "cMSStatusChangeTime",
						  "createdBy", "createTime"};
	
		public CMSStatusHistory()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CMSStatusId
		{
			get { return this.cMSStatusId; }
			set { this.cMSStatusId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSId
		{
			get { return this.cMSId; }
			set { this.cMSId = value; }
		}

		[FieldValuesMember("LookupOf_CMSRiskId", "CMSRiskId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@RISK@")]
		public int CMSRiskId
		{
			get { return this.cMSRiskId; }
			set { this.cMSRiskId = value; }
		}

		[FieldValuesMember("LookupOf_AcuityId", "AcuityId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@ACUITY@")]
		public int AcuityId
		{
			get { return this.acuityId; }
			set { this.acuityId = value; }
		}

		[FieldValuesMember("LookupOf_PhaseId", "PhaseId", "Description")]
		[FieldDescription("@PHASE@")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int PhaseId
		{
			get { return this.phaseId; }
			set { this.phaseId = value; }
		}

		[FieldValuesMember("LookupOf_IntensityId", "IntensityId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@INTENSITY@")]
		public int IntensityId
		{
			get { return this.intensityId; }
			set { this.intensityId = value; }
		}

		[FieldDescription("@ASSIGNEDUSER@")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedUserId
		{
			get { return this.assignedUserId; }
			set { this.assignedUserId = value; }
		}

		[FieldDescription("@ASSIGNEDTEAM@")]
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssignedTeamId
		{
			get { return this.assignedTeamId; }
			set { this.assignedTeamId = value; }
		}

		[FieldValuesMember("LookupOf_StatusId", "StatusId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@STATUS@")]
		public int StatusId
		{
			get { return this.statusId; }
			set { this.statusId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CMSStatusChangeTime
		{
			get { return this.cMSStatusChangeTime; }
			set { this.cMSStatusChangeTime = value; }
		}		

		[FieldValuesMember("LookupOf_StatusTypeId", "StatusTypeId", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@TYPE@")]
		public int StatusTypeId
		{
			get { return this.statusTypeId; }
			set { this.statusTypeId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string StatusText
		{
			get { return this.statusText; }
			set { this.statusText = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=50)]
		[FieldDescription("@PROGNOSIS@")]
		public string Prognosis
		{
			get { return this.prognosis; }
			set { this.prognosis = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int cMSStatusId)
		{
			return base.Load(cMSStatusId);
		}

		/// <summary>
		/// Parent CMSStatusHistoryCollection that contains this element
		/// </summary>
		public CMSStatusHistoryCollection ParentCMSStatusHistoryCollection
		{
			get
			{
				return this.parentCMSStatusHistoryCollection;
			}
			set
			{
				this.parentCMSStatusHistoryCollection = value; // parent is set when added to a collection
			}
		}

		public CMSStatusTypeCollection LookupOf_StatusTypeId
		{
			get
			{
				return CMSStatusTypeCollection.ActiveCMSStatusTypes; // Acquire a shared instance from the static member of collection
			}
		}

		public CMSAcuityCollection LookupOf_AcuityId
		{
			get
			{
				return CMSAcuityCollection.ActiveCMSAcuities; // Acquire a shared instance from the static member of collection
			}
		}

		public CMSPhaseCollection LookupOf_PhaseId
		{
			get
			{
				return CMSPhaseCollection.ActiveCMSPhases; // Acquire a shared instance from the static member of collection
			}
		}

		public CMSIntensityCollection LookupOf_IntensityId
		{
			get
			{
				return CMSIntensityCollection.ActiveCMSIntensities; // Acquire a shared instance from the static member of collection
			}
		}

		public CMSRiskCollection LookupOf_CMSRiskId
		{
			get
			{
				return CMSRiskCollection.ActiveCMSRisks; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		public SystemStatusCollection LookupOf_StatusId
		{
			get
			{
				return SystemStatusCollection.ActiveSystemStatuses; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool GetMostRecentCMSStatusHistoryByCMSId(int cMSId)
		{
			return SqlData.SPExecReadObj("usp_GetMostRecentCMSStatusHistoryByCMSId", this, false, cMSId);
		}

		public string StatusCode
		{
			get { return SystemStatusCollection.ActiveSystemStatuses.Lookup_CodeByStatusId(this.statusId); }
			set { this.statusId = SystemStatusCollection.ActiveSystemStatuses.Lookup_StatusIdByCode(value); }
		}

		

		
		

		
		
	}

	/// <summary>
	/// Strongly typed collection of CMSStatusHistory objects
	/// </summary>
	[ElementType(typeof(CMSStatusHistory))]
	public class CMSStatusHistoryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_CMSStatusId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSStatusHistory elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSStatusHistoryCollection = this;
			else
				elem.ParentCMSStatusHistoryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSStatusHistory elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSStatusHistory this[int index]
		{
			get
			{
				return (CMSStatusHistory)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSStatusHistory)oldValue, false);
			SetParentOnElem((CMSStatusHistory)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}
		
		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Hashtable based index on cMSStatusId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_CMSStatusId
		{
			get
			{
				if (this.indexBy_CMSStatusId == null)
					this.indexBy_CMSStatusId = new CollectionIndexer(this, new string[] { "cMSStatusId" }, true);
				return this.indexBy_CMSStatusId;
			}
			
		}



		
	}
}
