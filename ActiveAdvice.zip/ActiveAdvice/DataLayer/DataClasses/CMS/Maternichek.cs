using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Maternichek]
	/// </summary>
	[SPAutoGen("usp_LoadMaternichekByCMSid","SelectAllByGivenArgs.sptpl","cMSId")]
	[SPInsert("usp_InsertMaternichek")]
	[SPUpdate("usp_UpdateMaternichek")]
	[SPDelete("usp_DeleteMaternichek")]
	[SPLoad("usp_LoadMaternichek")]
	[TableMapping("Maternichek","maternichekId")]
	public class Maternichek : BaseDataWithUserDefined
	{
		[ColumnMapping("MaternichekId",StereoType=DataStereoType.FK)]
		private int maternichekId;
		[ColumnMapping("CMSId")]
		private int cMSId;
		[ColumnMapping("LMPdate")]
		private DateTime lMPdate;
		[ColumnMapping("EDCdate")]
		private DateTime eDCdate;
		[ColumnMapping("GestationAge")]
		private int gestationAge;
		[ColumnMapping("DeliveryDate")]
		private DateTime deliveryDate;
		[ColumnMapping("FirstPrenatalVisit")]
		private DateTime firstPrenatalVisit;
		[ColumnMapping("FirstPostpartumVisit")]
		private DateTime firstPostpartumVisit;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;

		
		private bool isCalculated = false;
		private int daysOpen;
		
		private CMS cMS;
		
		public const string CMSTYPE = "MAT" ;
		public Maternichek()
		{
		}

		public Maternichek(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int MaternichekId
		{
			get { return this.maternichekId; }
			set { this.maternichekId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSId
		{
			get { return this.cMSId; }
			set { this.cMSId = value; }
		}
		
		public static int CMSTypeCodeId
		{
			get
			{
				return CMSTypeCollection.ActiveCMSTypes.Lookup_CMSTypeIDByCode(CMSTYPE);
			}
		}
	
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]//, IsRequired=true,
			//ClientScriptForConditionalRequired="GetElemValue('EDCdate') == null")]
		[FieldDescription("@LMP@")]
		public System.DateTime LMPdate
		{	//�	If EDC is entered, and LMP is blank, then LMP is set as EDC � 280 days. 
			get 
			{ 
				if ( this.eDCdate > DateTime.MinValue & this.lMPdate == DateTime.MinValue)
					this.lMPdate = this.eDCdate.AddDays(-280);
				return this.lMPdate; 
			}
			set 
			{ 
				if (value > DateTime.MinValue)
				{	
					this.lMPdate = value; 
					this.eDCdate = DateTime.MinValue;
					DateTime dt = EDCdate;
					isCalculated = true;
				}
				else
					isCalculated = false;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]//, IsRequired=true)]
		[FieldDescription("@EDC@")]
		public System.DateTime EDCdate
		{	//�	If LMP is entered, and EDC is blank, EDC is set as LMP date plus 280 days
			get 
			{ 
				if ( this.lMPdate > DateTime.MinValue & this.eDCdate == DateTime.MinValue)
					this.eDCdate = this.lMPdate.AddDays(280);
				return this.eDCdate; 
			}
			set 
			{ 
				if (!isCalculated)
				{
					this.eDCdate = value; 
					this.lMPdate = DateTime.MinValue;
					DateTime dt = LMPdate;
				}
			}
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@GESTAGE@")]
		public int GestationAge
		{	//�	If the Delivery date field is blank, and EDC is filled (even if generated) 
			//	then Gestational age is determined as system date � EDC
			//�	If the Delivery date field is filled in, gestational age is determined as Delivery Date � EDC
			get 
			{ 
				if (this.deliveryDate == DateTime.MinValue && this.eDCdate > DateTime.MinValue)
					this.gestationAge = DateTime.Now.Subtract(this.eDCdate).Days;
				else if (this.deliveryDate > DateTime.MinValue)
					this.gestationAge = this.deliveryDate.Subtract(this.eDCdate).Days;
				return this.gestationAge; 
			}
		}
		
		[FieldDescription("@DELIVERYAGE@")]
		public string DeliveryAge //mothers age at delivery date
		{	//mothers age at delivery date
			// �	If delivery date is filled in, then Delivery age is calculated
			// If delivery date is empty: Delivery age = EDC - patient's DOB
			get 
			{ 
				if (this.CMS.Patient.DateOfBirth == DateTime.MinValue)
					return "@UNKNOWN@";
				int years = 0, months = 0;
				bool isCalculated = false;
				if (this.deliveryDate == DateTime.MinValue && CMS.Patient != null)
				{
					base.CalculateYearsMonths(this.CMS.Patient.DateOfBirth, this.eDCdate, ref years, ref months);
					isCalculated = true;
				}
				else if (this.deliveryDate > DateTime.MinValue && CMS.Patient != null)
				{
					base.CalculateYearsMonths(this.CMS.Patient.DateOfBirth, this.deliveryDate, ref years, ref months);
					isCalculated = true;
				}
				
				if(isCalculated)
					return String.Format("{0} {1} {2} {3}", years, Messages.CMSMessages.MessageIDs.YEARS, months, Messages.CMSMessages.MessageIDs.MONTHS);
				else
					 return "@UNKNOWN@";
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@DELIVERYDATE@")]
		public System.DateTime DeliveryDate
		{
			get { return this.deliveryDate; }
			set { this.deliveryDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@FIRSTPRENATALVISIT@")]
		public System.DateTime FirstPrenatalVisit
		{
			get { return this.firstPrenatalVisit; }
			set { this.firstPrenatalVisit = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@FIRSTPOSTPARTUMVISIT@")]
		public System.DateTime FirstPostpartumVisit
		{
			get { return this.firstPostpartumVisit; }
			set { this.firstPostpartumVisit = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int maternichekId)
		{
			return base.Load(maternichekId);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			// Save the child collections here.
		}

		

		/// <summary>
		/// Contained CMS object
		/// </summary>
		public CMS CMS
		{
			get
			{
				return this.cMS;
			}
			set
			{
				this.cMS = value;
			}
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadMaternichekByCMSid(int cMSId)
		{
			return SqlData.SPExecReadObj("usp_LoadMaternichekByCMSid", this, false, cMSId);
		}

		
		
	}
}
