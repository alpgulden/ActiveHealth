using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSTypes]
	/// </summary>
	[SPAutoGen("usp_SearchCMSTypes","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllCMSTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllCMSTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertCMSType")]
	[SPUpdate("usp_UpdateCMSType")]
	[SPDelete("usp_DeleteCMSType")]
	[SPLoad("usp_LoadCMSType")]
	[TableMapping("CMSType","cMSTypeID")]
	public class CMSType : NetsoftUSA.DataLayer.BaseDataClass
	{
		[NonSerialized]
		private CMSTypeCollection parentCMSTypeCollection;
		[ColumnMapping("CMSTypeID",StereoType=DataStereoType.FK)]
		private int cMSTypeID;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
	
		public CMSType()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CMSTypeID
		{
			get { return this.cMSTypeID; }
			set { this.cMSTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Parent CMSTypeCollection that contains this element
		/// </summary>
		public CMSTypeCollection ParentCMSTypeCollection
		{
			get
			{
				return this.parentCMSTypeCollection;
			}
			set
			{
				this.parentCMSTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int cMSTypeID)
		{
			return base.Load(cMSTypeID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int cMSTypeID)
		{
			base.Delete(cMSTypeID);		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active	= true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Use this function to test Load method
		/// </summary>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void TestLoad()
		{
			CMSType obj = new CMSType();
			obj.Load(1);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(2);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(3);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool SearchCMSTypes(string code, string description, bool active)
		{
			return SqlData.SPExecReadObj("usp_SearchCMSTypes", this, false, code, description, active);
		}
	}

	/// <summary>
	/// Strongly typed collection of CMSType objects
	/// </summary>
	[ElementType(typeof(CMSType))]
	public class CMSTypeCollection : BaseTypeCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		[NonSerialized]
		private CollectionIndexer indexBy_CMSTypeID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSTypeCollection = this;
			else
				elem.ParentCMSTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSType this[int index]
		{
			get
			{
				return (CMSType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSType)oldValue, false);
			SetParentOnElem((CMSType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		///  Load all Facility Focus Types.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllCMSTypes", -1, this, false);
		}

		/// <summary>
		///  Searches for Focus Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchAllCMSTypes", -1, this, false, code, description, active);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllCMSTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllCMSTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared CMSTypeCollection which is cached in NSGlobal
		/// </summary>
		public static CMSTypeCollection ActiveCMSTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				CMSTypeCollection col = (CMSTypeCollection)NSGlobal.EnsureCachedObject("ActiveCMSTypes", typeof(CMSTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllCMSTypesByActive(-1, true);
				}
				return col;
			}
		}

		/// <summary>
		/// Hashtable based index on cMSTypeID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_CMSTypeID
		{
			get
			{
				if (this.indexBy_CMSTypeID == null)
					this.indexBy_CMSTypeID = new CollectionIndexer(this, new string[] { "cMSTypeID" }, true);
				return this.indexBy_CMSTypeID;
			}
			
		}

		/// <summary>
		/// Looks up by cMSTypeID and returns Description value.  Uses the IndexBy_CMSTypeID indexer.
		/// </summary>
		public string Lookup_DescriptionByCMSTypeID(int cMSTypeID)
		{
			return this.IndexBy_CMSTypeID.LookupStringMember("Description", cMSTypeID);
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns CMSTypeID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_CMSTypeIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("CMSTypeID", code);
		}

	}
}
