using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSProblems]
	/// </summary>
	[SPAutoGen("usp_LoadAllByCMSId","SelectAllByGivenArgs.sptpl","cMSId")]
	[SPAutoGen("usp_CountProblemCMS","CountAllByGivenArgs.sptpl","problemId, cMSId")]
	[SPInsert("usp_InsertCMSProblem")]
	[SPDelete("usp_DeleteCMSProblem")]
	[SPLoad("usp_LoadCMSProblem")]
	[TableMapping("CMSProblem","cMSId,problemId",true)]
	public class CMSProblem : BaseERCProblemLink
	{
		[NonSerialized]
		private BaseERCProblemLinkCollection parentBaseERCProblemLinkCollection;

		[ColumnMapping("CMSId",StereoType=DataStereoType.FK)]
		private int cMSId;
		[ColumnMapping("ProblemId",StereoType=DataStereoType.FK)]
		private int problemId;

		#region BaseERCProblemLink abstract methods overridden
		public override int ERCId
		{
			get { return this.cMSId; }
			//set { this.cMSId = value; }
		}
		
		public override int ProblemId
		{
			get { return this.problemId; }
			//set { this.problemId = value; }
		}

		public override BaseERCProblemLinkCollection ParentBaseERCProblemLinkCollection
		{
			get
			{
				return this.parentBaseERCProblemLinkCollection;
			}
			set
			{
				this.parentBaseERCProblemLinkCollection = (CMSProblemCollection)value; // parent is set when added to a collection
			}
		}
		#endregion
		
		public CMSProblem()
		{
		}
		
		public CMSProblem(int cMSid, int problemid, bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
			this.cMSId = cMSid;
			this.problemId = problemid;
		}

		public CMSProblem(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

//		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
//		public int CMSId
//		{
//			get { return this.cMSId; }
//			set { this.cMSId = value; }
//		}
//
//		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
//		public int ProblemId
//		{
//			get { return this.problemId; }
//			set { this.problemId = value; }
//		}

//		/// <summary>
//		/// Parent CMSProblemCollection that contains this element
//		/// </summary>
//		public CMSProblemCollection ParentCMSProblemCollection
//		{
//			get
//			{
//				return this.parentCMSProblemCollection;
//			}
//			set
//			{
//				this.parentCMSProblemCollection = value; // parent is set when added to a collection
//			}
//		}


		/// <summary>
		/// Checks the existence of problem-CMS in the db.
		/// </summary>
		public bool ProblemCMSExists()
		{
			return (int)SqlData.SPExecScalar("usp_CountProblemCMS", this.problemId, this.cMSId) > 0;
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete()
		{
			base.Delete(this.cMSId, this.problemId);		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load()
		{
			return base.Load(this.cMSId, this.problemId);
		}
	}

	/// <summary>
	/// Strongly typed collection of CMSProblem objects
	/// </summary>
	[ElementType(typeof(CMSProblem))]
	public class CMSProblemCollection : BaseERCProblemLinkCollection
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ProblemId;
		
		[NonSerialized]
		private CollectionIndexer indexBy_CMSId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(BaseERCProblemLink elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentBaseERCProblemLinkCollection = this;
			else
				elem.ParentBaseERCProblemLinkCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSProblem elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSProblem this[int index]
		{
			get
			{
				return (CMSProblem)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSProblem)oldValue, false);
			SetParentOnElem((CMSProblem)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}

		/// <summary>
		/// Parent Problem that contains this collection
		/// </summary>
		public Problem ParentProblem
		{
			get { return this.ParentDataObject as Problem; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Problem */ }
		}

		/// <summary>
		/// Hashtable based index on cMSId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_CMSId
		{
			get
			{
				if (this.indexBy_CMSId == null)
					this.indexBy_CMSId = new CollectionIndexer(this, new string[] { "cMSId" }, true);
				return this.indexBy_CMSId;
			}
		}

		/// <summary>
		/// Hashtable based search on cMSId fields returns the object.  Uses the IndexBy_CMSId indexer.
		/// </summary>
		public CMSProblem FindByCMSID(int cMSId)
		{
			return (CMSProblem)this.IndexBy_CMSId.GetObject(cMSId);
		}

		/// <summary>
		/// Hashtable based index on problemId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ProblemId
		{
			get
			{
				if (this.indexBy_ProblemId == null)
					this.indexBy_ProblemId = new CollectionIndexer(this, new string[] { "problemId" }, true);
				return this.indexBy_ProblemId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on problemId fields returns the object.  Uses the IndexBy_ProblemId indexer.
		/// </summary>
		public CMSProblem FindByProblemId(int problemId)
		{
			return (CMSProblem)this.IndexBy_ProblemId.GetObject(problemId);
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(CMSProblem elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((CMSProblem)value, true);
			base.OnInsertComplete (index, value);		
		}

		#region Overrides BaseERCProblemLinkCollection
		public override void DetermineLinkedProblems(ProblemCollection problems)
		{
			this.IndexBy_ProblemId.Rebuild();
			foreach (Problem problem in problems)
			{
				if (FindByProblemId(problem.ProblemID) == null)
					problem.IsERCLinked = false;
				else
				{
					problem.IsERCLinked = true;
					if (this.ParentCMS.PrimaryProblemID == problem.ProblemID)
						problem.IsPrimary = true;
					else
						problem.IsPrimary = false;
				}
			}
		}

		public override void SynchronizeFromProblems(ProblemCollection problems)
		{
			this.IndexBy_ProblemId.Rebuild();
			foreach (Problem problem in problems)
			{ //Update Linkages based on problem 
				CMSProblem cmsProblem = FindByProblemId(problem.ProblemID);
				if (problem.IsERCLinked)
				{
					if (cmsProblem == null)
					{	// If no linkage exists - create new one
						// otherwise do nothing
						cmsProblem = new CMSProblem(this.ParentCMS.CMSID, problem.ProblemID, true);
						this.Add(cmsProblem);
					}
				}
				if (!problem.IsERCLinked)
				{	
					if (cmsProblem != null) // If linkage exists - delete it, otherwise do nothing
					{	// don't unlik primary problem
						if (this.ParentCMS.PrimaryProblemID != problem.ProblemID)
							cmsProblem.MarkDel();
						else
							throw new ActiveAdviceException(AAExceptionAction.None, "Primary problem cannot be unlinked.");
					}
				}
			}// end of foreach
		}

		public override void SetPrimaryProblem(Problem problem)
		{
			this.ParentCMS.PrimaryProblemID = problem.ProblemID;
			problem.IsPrimary = true;
			this.IndexBy_ProblemId.Rebuild();
			if (FindByProblemId(problem.ProblemID) == null)
			{	//Create link if it wasn't there
				CMSProblem cmsProblem = new CMSProblem(this.ParentCMS.CMSID, problem.ProblemID, true);
				this.Add(cmsProblem);
				this.SaveElements();
			}
			this.ParentCMS.Update();
		}
		#endregion
	}
}
