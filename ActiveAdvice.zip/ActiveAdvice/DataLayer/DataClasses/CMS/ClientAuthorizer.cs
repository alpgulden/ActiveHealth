using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ClientAuthorizer]
	/// </summary>
	[SPAutoGen("usp_SearchClientAuthorizers","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllClientAuthorizersByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllClientAuthorizers","SelectAll.sptpl","")]
	[SPInsert("usp_InsertClientAuthorizer")]
	[SPUpdate("usp_UpdateClientAuthorizer")]
	[SPDelete("usp_DeleteClientAuthorizer")]
	[SPLoad("usp_LoadClientAuthorizer")]
	[TableMapping("ClientAuthorizer","clientAuthorizerId")]
	public class ClientAuthorizer : BaseLookupWithCode
	{
		[NonSerialized]
		private ClientAuthorizerCollection parentClientAuthorizerCollection;
		[ColumnMapping("ClientAuthorizerId",StereoType=DataStereoType.FK)]
		private int clientAuthorizerId;
	
		public ClientAuthorizer()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ClientAuthorizerId
		{
			get { return this.clientAuthorizerId; }
			set { this.clientAuthorizerId = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int clientAuthorizerId)
		{
			return base.Load(clientAuthorizerId);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int clientAuthorizerId)
		{
			base.Delete(clientAuthorizerId);		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Parent ClientAuthorizerCollection that contains this element
		/// </summary>
		public ClientAuthorizerCollection ParentClientAuthorizerCollection
		{
			get
			{
				return this.parentClientAuthorizerCollection;
			}
			set
			{
				this.parentClientAuthorizerCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ClientAuthorizer objects
	/// </summary>
	[ElementType(typeof(ClientAuthorizer))]
	public class ClientAuthorizerCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ClientAuthorizer elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentClientAuthorizerCollection = this;
			else
				elem.ParentClientAuthorizerCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ClientAuthorizer elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ClientAuthorizer this[int index]
		{
			get
			{
				return (ClientAuthorizer)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ClientAuthorizer)oldValue, false);
			SetParentOnElem((ClientAuthorizer)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllClientAuthorizersByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllClientAuthorizersByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared ClientAuthorizerCollection which is cached in NSGlobal
		/// </summary>
		public static ClientAuthorizerCollection ActiveClientAuthorizers
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				ClientAuthorizerCollection col = (ClientAuthorizerCollection)NSGlobal.EnsureCachedObject("ActiveClientAuthorizers", typeof(ClientAuthorizerCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllClientAuthorizersByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}
