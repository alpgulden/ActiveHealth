using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSEvents]
	/// </summary>
	[SPInsert("usp_InsertCMSEvent")]
	[SPUpdate("usp_UpdateCMSEvent")]
	[SPDelete("usp_DeleteCMSEvent")]
	[SPLoad("usp_LoadCMSEvent")]
	[TableMapping("CMSEvent","eventID")]
	public class CMSEvent : NetsoftUSA.DataLayer.BaseDataClass
	{
		[NonSerialized]
		private CMSEventCollection parentCMSEventCollection;
		[ColumnMapping("CMSID")]
		private int cMSID;
		[ColumnMapping("EventID",StereoType=DataStereoType.FK)]
		private int eventID;
	
		public CMSEvent()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eventID)
		{
			return base.Load(eventID);
		}

		/// <summary>
		/// Parent CMSEventCollection that contains this element
		/// </summary>
		public CMSEventCollection ParentCMSEventCollection
		{
			get
			{
				return this.parentCMSEventCollection;
			}
			set
			{
				this.parentCMSEventCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of CMSEvent objects
	/// </summary>
	[ElementType(typeof(CMSEvent))]
	public class CMSEventCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSEvent elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSEventCollection = this;
			else
				elem.ParentCMSEventCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSEvent elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSEvent this[int index]
		{
			get
			{
				return (CMSEvent)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSEvent)oldValue, false);
			SetParentOnElem((CMSEvent)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}
	}
}
