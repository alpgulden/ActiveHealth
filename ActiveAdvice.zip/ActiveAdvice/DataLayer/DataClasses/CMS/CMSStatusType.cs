using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [CMSStatusTypes]
	/// </summary>
	
	[SPAutoGen("usp_SearchCMSStatusTypes","SearchByArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllCMSStatusTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllCMSStatusTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertCMSStatusType")]
	[SPUpdate("usp_UpdateCMSStatusType")]
	[SPDelete("usp_DeleteCMSStatusType")]
	[SPLoad("usp_LoadCMSStatusType")]
	[TableMapping("CMSStatusType","statusTypeId")]
	public class CMSStatusType : NetsoftUSA.DataLayer.BaseDataClass
	{
		[NonSerialized]
		private CMSStatusTypeCollection parentCMSStatusTypeCollection;
		[ColumnMapping("StatusTypeId",StereoType=DataStereoType.FK)]
		private int statusTypeId;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
	
		public CMSStatusType()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int StatusTypeId
		{
			get { return this.statusTypeId; }
			set { this.statusTypeId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=8)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Parent CMSStatusTypeCollection that contains this element
		/// </summary>
		public CMSStatusTypeCollection ParentCMSStatusTypeCollection
		{
			get
			{
				return this.parentCMSStatusTypeCollection;
			}
			set
			{
				this.parentCMSStatusTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int statusTypeId)
		{
			return base.Load(statusTypeId);
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int statusTypeId)
		{
			base.Delete(statusTypeId);		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.active	= true;
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Use this function to test Load method
		/// </summary>
		[System.Diagnostics.Conditional("DEBUG")]
		public static void TestLoad()
		{
			CMSStatusType obj = new CMSStatusType();
			obj.Load(1);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(2);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
			obj.Load(3);
			System.Diagnostics.Debug.WriteLine(obj.Code); // access any fields/properties
		
		}
	}

	/// <summary>
	/// Strongly typed collection of CMSStatusType objects
	/// </summary>
	[ElementType(typeof(CMSStatusType))]
	public class CMSStatusTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(CMSStatusType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentCMSStatusTypeCollection = this;
			else
				elem.ParentCMSStatusTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (CMSStatusType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public CMSStatusType this[int index]
		{
			get
			{
				return (CMSStatusType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((CMSStatusType)oldValue, false);
			SetParentOnElem((CMSStatusType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		

		/// <summary>
		///  Load all Facility Focus Types.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllCMSStatusTypes", -1, this, false);
		}

		/// <summary>
		///  Searches for Focus Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchAllCMSStatusTypes", -1, this, false, code, description, active);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllCMSStatusTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllCMSStatusTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared CMSStatusTypeCollection which is cached in NSGlobal
		/// </summary>
		public static CMSStatusTypeCollection ActiveCMSStatusTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				CMSStatusTypeCollection col = (CMSStatusTypeCollection)NSGlobal.EnsureCachedObject("CMSStatusTypes", typeof(CMSStatusTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllCMSStatusTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		
	}
}
