using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [DateActualProjected]
	/// </summary>
	[SPAutoGen("usp_GetDateActualProjectedByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPAutoGen("usp_GetAllDateActualProjected","SelectAll.sptpl","")]
	[SPInsert("usp_InsertDateActualProjected")]
	[SPUpdate("usp_UpdateDateActualProjected")]
	[SPDelete("usp_DeleteDateActualProjected")]
	[SPLoad("usp_LoadDateActualProjected")]
	[TableMapping("DateActualProjected","dateActualProjectedID")]
	public class DateActualProjected : BaseLookupWithCode
	{
		#region Code Constants

		public const string ACTUAL = "A";
		public const string PROJECTED = "P";

		#endregion

		[NonSerialized]
		private DateActualProjectedCollection parentDateActualProjectedCollection;
		[ColumnMapping("DateActualProjectedID",StereoType=DataStereoType.FK)]
		private int dateActualProjectedID;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public DateActualProjected()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int DateActualProjectedID
		{
			get { return this.dateActualProjectedID; }
			set { this.dateActualProjectedID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int dateActualProjectedID)
		{
			return base.Load(dateActualProjectedID);
		}

		/// <summary>
		/// Parent DateActualProjectedCollection that contains this element
		/// </summary>
		public DateActualProjectedCollection ParentDateActualProjectedCollection
		{
			get
			{
				return this.parentDateActualProjectedCollection;
			}
			set
			{
				this.parentDateActualProjectedCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of DateActualProjected objects
	/// </summary>
	[ElementType(typeof(DateActualProjected))]
	public class DateActualProjectedCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_DateActualProjectedID;
		[NonSerialized]
		private CollectionIndexer indexBy_Code;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(DateActualProjected elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentDateActualProjectedCollection = this;
			else
				elem.ParentDateActualProjectedCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (DateActualProjected elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public DateActualProjected this[int index]
		{
			get
			{
				return (DateActualProjected)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((DateActualProjected)oldValue, false);
			SetParentOnElem((DateActualProjected)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadDateActualProjectedByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetDateActualProjectedByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared DateActualProjectedCollection which is cached in NSGlobal
		/// </summary>
		public static DateActualProjectedCollection ActiveDateActualProjectedCodes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				DateActualProjectedCollection col = (DateActualProjectedCollection)NSGlobal.EnsureCachedObject("ActiveDateActualProjectedCodes", typeof(DateActualProjectedCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadDateActualProjectedByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on code fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_Code
		{
			get
			{
				if (this.indexBy_Code == null)
					this.indexBy_Code = new CollectionIndexer(this, new string[] { "code" }, true);
				return this.indexBy_Code;
			}
			
		}

		/// <summary>
		/// Looks up by code and returns DateActualProjectedID value.  Uses the IndexBy_Code indexer.
		/// </summary>
		public int Lookup_DateActualProjectedIDByCode(string code)
		{
			return this.IndexBy_Code.LookupIntMember("DateActualProjectedID", code);
		}

		/// <summary>
		/// Hashtable based index on dateActualProjectedID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_DateActualProjectedID
		{
			get
			{
				if (this.indexBy_DateActualProjectedID == null)
					this.indexBy_DateActualProjectedID = new CollectionIndexer(this, new string[] { "dateActualProjectedID" }, true);
				return this.indexBy_DateActualProjectedID;
			}
			
		}

		/// <summary>
		/// Looks up by dateActualProjectedID and returns Code value.  Uses the IndexBy_DateActualProjectedID indexer.
		/// </summary>
		public string Lookup_CodeByDateActualProjectedID(int dateActualProjectedID)
		{
			return this.IndexBy_DateActualProjectedID.LookupStringMember("Code", dateActualProjectedID);
		}

	}
}
