using System;

using NetsoftUSA.DataLayer;
using ActiveAdvice.Messages;

namespace ActiveAdvice.DataLayer
{	
	/// <summary>
	/// Data class that wraps the entity access functionality to table [MeasurementType]
	/// </summary>
	[SPAutoGen("usp_GetAllMeasurementTypesByActive","SelectAllByGivenArgsOrderBy.sptpl","sortOrder, ASC, active")]
	[SPAutoGen("usp_GetAllMeasurementTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertMeasurementType")]
	[SPUpdate("usp_UpdateMeasurementType")]
	[SPDelete("usp_DeleteMeasurementType")]
	[SPLoad("usp_LoadMeasurementType")]
	[TableMapping("MeasurementType","codeId")]
	public class MeasurementType : BaseLookupWithCode
	{
		[NonSerialized]
		private MeasurementTypeCollection parentMeasurementTypeCollection;
		[ColumnMapping("CodeId",(int)0)]
		private int codeId;
		[ColumnMapping("UnitOfMeasureText")]
		private string unitOfMeasureText;
		[ColumnMapping("RangeLow")]
		private int rangeLow = int.MinValue;
		[ColumnMapping("RangeHigh")]
		private int rangeHigh = int.MinValue;
		[ColumnMapping("SortOrder",(int)0)]
		private int sortOrder;
		[ColumnMapping("NormalLow")]
		private int normalLow = int.MinValue;
		[ColumnMapping("NormalHigh")]
		private int normalHigh = int.MinValue;
		[ColumnMapping("Formula")]
		private string formula;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("PickList")]
		private bool pickList;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		private MeasurementLevelOfDiseaseCollection measurementLevelOfDiseases;
		private MeasurementTypePickListCollection measurementTypePickLists;

		public const string BMI = "BMI";
		public const string WT = "WT";
		public const string HT = "HT";
		

		public MeasurementType()
		{

		}

		public MeasurementType(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public MeasurementType(int codeId)
		{
			this.NewRecord(); // initialize record state
			this.Load(codeId);
		}
				

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int CodeId
		{
			get { return this.codeId; }
			set { this.codeId = value; }
		} 

		[ControlType(EnumControlTypes.TextBox, MaxLength=10, IsRequired=true)]
		[FieldDescription("@UNITMEASURE@")]
		public string UnitOfMeasureText
		{
			get { return this.unitOfMeasureText; }
			set { this.unitOfMeasureText = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)int.MinValue)]
		[FieldDescription("@RANGE@"+" "+"@LOW@")]
		public int RangeLow
		{
			get { return this.rangeLow; }
			set { this.rangeLow = value; }
		}

		[ValidatorMember("Vld_RangeHigh")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)int.MinValue)]
		[FieldDescription("@RANGE@"+" "+"@HIGH@")]
		public int RangeHigh
		{
			get { return this.rangeHigh; }
			set { this.rangeHigh = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)0)]
		[FieldDescription("@SORTORDER@")]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)int.MinValue)]
		[FieldDescription("@NORMALS@"+" "+"@LOW@")]
		public int NormalLow
		{
			get { return this.normalLow; }
			set { this.normalLow = value; }
		}

		[ValidatorMember("Vld_NormalHigh")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true, ValueForNull=(int)int.MinValue)]
		[FieldDescription("@NORMALS@"+" "+"@HIGH@")]
		public int NormalHigh
		{
			get { return this.normalHigh; }
			set { this.normalHigh = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=200)]
		[FieldDescription("@FORMULA@")]
		public string Formula
		{
			get { return this.formula; }
			set { this.formula = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		[FieldDescription("@INSTRUCTIONTEXT@")]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		[FieldDescription("@RESULTISNUMERIC@")]
		public bool PickList
		{
			get { return this.pickList; }
			set { this.pickList = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		/// <summary>
		/// Parent MeasurementTypeCollection that contains this element
		/// </summary>
		public MeasurementTypeCollection ParentMeasurementTypeCollection
		{
			get
			{
				return this.parentMeasurementTypeCollection;
			}
			set
			{
				this.parentMeasurementTypeCollection = value; // parent is set when added to a collection
			}
		}

		#region MeasurementLevelOfDiseases
		/// <summary>
		/// Child MeasurementLevelOfDiseases mapped to related rows of table MeasurementLevelOfDisease where [CodeId] = [MeasurementTypeID]
		/// </summary>
		[SPLoadChild("usp_LoadMeasurementTypeMeasurementLevelOfDisease", "measurementTypeID")]
		public MeasurementLevelOfDiseaseCollection MeasurementLevelOfDiseases
		{
			get { return this.measurementLevelOfDiseases; }
			set
			{
				this.measurementLevelOfDiseases = value;
				if (value != null)
					value.ParentMeasurementType = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the MeasurementLevelOfDiseases collection
		/// </summary>
		public void LoadMeasurementLevelOfDiseases(bool forceReload)
		{
			this.measurementLevelOfDiseases = (MeasurementLevelOfDiseaseCollection)MeasurementLevelOfDiseaseCollection.LoadChildCollection("MeasurementLevelOfDiseases", this, typeof(MeasurementLevelOfDiseaseCollection), measurementLevelOfDiseases, forceReload, null);
		}

		/// <summary>
		/// Saves the MeasurementLevelOfDiseases collection
		/// </summary>
		public void SaveMeasurementLevelOfDiseases()
		{
			MeasurementLevelOfDiseaseCollection.SaveChildCollection(this.measurementLevelOfDiseases, true);
		}

		/// <summary>
		/// Synchronizes the MeasurementLevelOfDiseases collection
		/// </summary>
		public void SynchronizeMeasurementLevelOfDiseases()
		{
			MeasurementLevelOfDiseaseCollection.SynchronizeChildCollection(this.measurementLevelOfDiseases, true);
		}
		#endregion

		#region MeasurementTypePickLists
		/// <summary>
		// Child MeasurementTypePickLists mapped to related rows of table MeasurementTypePickList where [CodeId] = [MeasurementTypeId]
		/// </summary>
		[SPLoadChild("usp_LoadMeasurementTypeMeasurementTypePickList", "measurementTypeId")]
		public MeasurementTypePickListCollection MeasurementTypePickLists
		{
			get { return this.measurementTypePickLists; }
			set
			{
				this.measurementTypePickLists = value;
				if (value != null)
					value.ParentMeasurementType = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the MeasurementTypePickLists collection
		/// </summary>
		public void LoadMeasurementTypePickLists(bool forceReload)
		{
			this.measurementTypePickLists = (MeasurementTypePickListCollection)MeasurementTypePickListCollection.LoadChildCollection("MeasurementTypePickLists", this, typeof(MeasurementTypePickListCollection), measurementTypePickLists, forceReload, null);
		}

		/// <summary>
		/// Saves the MeasurementTypePickLists collection
		/// </summary>
		public void SaveMeasurementTypePickLists()
		{
			MeasurementTypePickListCollection.SaveChildCollection(this.measurementTypePickLists, true);
		}

		/// <summary>
		/// Synchronizes the MeasurementTypePickLists collection
		/// </summary>
		public void SynchronizeMeasurementTypePickLists()
		{
			MeasurementTypePickListCollection.SynchronizeChildCollection(this.measurementTypePickLists, true);
		}
		#endregion

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created
			base.InternalSave();
			if(MeasurementLevelOfDiseases != null && MeasurementLevelOfDiseases.Count > 0)
			{
				MeasurementLevelOfDiseases.ParentMeasurementType = this;
				MeasurementLevelOfDiseases.SqlData.Transaction = this.sqlData.Transaction;
				SaveMeasurementLevelOfDiseases();
			}

			if(MeasurementTypePickLists != null && MeasurementTypePickLists.Count > 0)
			{
				MeasurementTypePickLists.ParentMeasurementType = this;
				MeasurementTypePickLists.SqlData.Transaction = this.sqlData.Transaction;
				SaveMeasurementTypePickLists();
			}
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int codeId)
		{
			return base.Load(codeId);
		}

		[GenericScript("Vld_RangeHigh", "@RangeHigh@ != null && @RangeHigh@ > @RangeLow@;")]
		public string Vld_RangeHigh
		{
			get
			{
				return "@RANGE@"+" "+"@HIGH@" + " " + MeasurementMessages.MessageIDs.ERRLODTHHIGH + " " + "@RANGE@"+" "+"@LOW@";
			}
			set
			{}
		}

		[GenericScript("Vld_NormalHigh", "@NormalHigh@ != null && @NormalHigh@ > @NormalLow@;")]
		public string Vld_NormalHigh
		{
			get
			{
				return "@NORMALS@"+" "+"@HIGH@" + " " + MeasurementMessages.MessageIDs.ERRLODTHHIGH + " " + "@NORMALS@"+" "+"@LOW@";
			}
			set
			{}
		}
	}

	/// <summary>
	/// Strongly typed collection of MeasurementType objects
	/// </summary>
	[ElementType(typeof(MeasurementType))]
	public class MeasurementTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_CodeId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(MeasurementType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentMeasurementTypeCollection = this;
			else
				elem.ParentMeasurementTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (MeasurementType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public MeasurementType this[int index]
		{
			get
			{
				return (MeasurementType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((MeasurementType)oldValue, false);
			SetParentOnElem((MeasurementType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(MeasurementType elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((MeasurementType)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllMeasurementTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllMeasurementTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared MeasurementTypeCollection which is cached in NSGlobal
		/// </summary>
		public static MeasurementTypeCollection ActiveMeasurementTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				MeasurementTypeCollection col = (MeasurementTypeCollection)NSGlobal.EnsureCachedObject("ActiveMeasurementTypes", typeof(MeasurementTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllMeasurementTypesByActive(-1, true);
				}
				return col;
			}
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllMeasurementTypes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllMeasurementTypes", maxRecords, this, false);
		}

		/// <summary>
		/// Parent MeasurementType that contains this collection
		/// </summary>
		public MeasurementType ParentMeasurementType
		{
			get { return this.ParentDataObject as MeasurementType; }
			set { this.ParentDataObject = value; /* parent is set when contained by a MeasurementType */ }
		}

		/// <summary>
		/// Hashtable based index on codeId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_CodeId
		{
			get
			{
				if (this.indexBy_CodeId == null)
					this.indexBy_CodeId = new CollectionIndexer(this, new string[] { "codeId" }, true);
				return this.indexBy_CodeId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on codeId fields returns the object.  Uses the IndexBy_CodeId indexer.
		/// </summary>
		public MeasurementType FindBy(int codeId)
		{
			return (MeasurementType)this.IndexBy_CodeId.GetObject(codeId);
		}

		/// <summary>
		/// Looks up by codeId and returns Description value.  Uses the IndexBy_CodeId indexer.
		/// </summary>
		public string Lookup_DescriptionByCodeId(int codeId)
		{
			return this.IndexBy_CodeId.LookupStringMember("Description", codeId);
		}
	}
}
