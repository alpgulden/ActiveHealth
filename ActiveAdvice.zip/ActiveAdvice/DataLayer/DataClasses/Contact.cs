using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Contacts]
	/// </summary>
	[SPAutoGen("usp_SearchOrganizationContacts","SearchAndJoinByArgs.sptpl","OrganizationContact, contactID, organizationID, firstName, lastName")]
	[SPAutoGen("usp_SearchPatientContacts","SearchAndJoinByArgs.sptpl","PatientContact, contactID, patientID, firstName, lastName")]
	[SPAutoGen("usp_SearchProviderLocationContacts","SearchAndJoinByArgs.sptpl","ProviderLocationContact, contactID, providerLocationID, firstName, lastName")]
	[SPAutoGen("usp_SearchFacilityLocationContacts","SearchAndJoinByArgs.sptpl","FacilityLocationContact, contactID, facilityLocationID, firstName, lastName")]
	[SPAutoGen("usp_SearchGroupPracticeLocationContacts","SearchAndJoinByArgs.sptpl","GroupPracticeLocationContact, contactID, groupPracticeLocationID, firstName, lastName")]
	[SPAutoGen("usp_SearchPlanContacts","SearchAndJoinByArgs.sptpl","PlanContact, contactID, planID, firstName, lastName")]
	[SPAutoGen("usp_SearchInsurancePayorContacts","SearchAndJoinByArgs.sptpl","InsurancePayorContact, contactID, insurancePayorID, firstName, lastName")]
	[SPAutoGen("usp_SearchNetworkContacts","SearchAndJoinByArgs.sptpl","NetworkContact, contactID, networkID, firstName, lastName")]
	[SPAutoGen("usp_SearchContacts","SelectAllByGivenArgs.sptpl","lastName, firstName")]
	[SPInsert("usp_InsertContact")]
	[SPUpdate("usp_UpdateContact")]
	[SPDelete("usp_DeleteContact")]
	[SPLoad("usp_LoadContact")]
	[TableMapping("Contact","contactID")]
	public class Contact : BaseDataWithUserDefined
	{
		[NonSerialized]
		private ContactCollection parentContactCollection;
		[ColumnMapping("ContactID",StereoType=DataStereoType.FK)]
		private int contactID;
		[ColumnMapping("LastName")]
		private string lastName;
		[ColumnMapping("FirstName")]
		private string firstName;
		[ColumnMapping("MiddleInitial")]
		private string middleInitial;
		[ColumnMapping("NamePrefixID",StereoType=DataStereoType.FK)]
		private int namePrefixID;
		[ColumnMapping("Title")]
		private string title;
		[ColumnMapping("Company")]
		private string company;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("AddressID")]
		private int addressID;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("TerminatedBy")]
		
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("NameSuffix")]
		private string nameSuffix;
		private Address address;
	
		private DateTime termDateWhenLoaded;	// keep track of the change in term date.
		private ContactRoleCollection contactRoles;

		public Contact()
		{
		}

		public Contact(int contactID)
		{
			this.NewRecord(); // initialize record state
			this.contactID = contactID;
		}

		public Contact(string lastName, string firstName)
		{
			this.NewRecord(); // initialize record state
			this.lastName = lastName;
			this.firstName = firstName;
		}

		public Contact(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}
	
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@CONTACTID@")]
		public int ContactID
		{
			get { return this.contactID; }
			set { this.contactID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@LASTNAME@")]
		public string LastName
		{
			get { return this.lastName; }
			set { this.lastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		[FieldDescription("@FIRSTNAME@")]
		public string FirstName
		{
			get { return this.firstName; }
			set { this.firstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		[FieldDescription("@NAME@")]
		public string Name
		{
			get { return this.LastName + ", " + this.FirstName; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=16)]
		[FieldDescription("@TITLE@")]
		public string Title
		{
			get { return this.title; }
			set { this.title = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=128)]
		[FieldDescription("@COMPANY@")]
		public string Company
		{
			get { return this.company; }
			set { this.company = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1000)]
		[FieldDescription("@NOTE@")]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@ADDRESS@")]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@CREATETIME@")]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@CREATEDBY@")]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@MODIFYTIME@")]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@MODIFYBY@")]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		[FieldDescription("@MIDDLEINITIAL@")]
		public string MiddleInitial
		{
			get { return this.middleInitial; }
			set { this.middleInitial = value; }
		}

		[FieldValuesMember("LookupOf_namePrefixID", "NamePrefixId", "Prefix")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@NAMEPREFIX@")]
		public int NamePrefixID
		{
			get { return this.namePrefixID; }
			set { this.namePrefixID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@EFFDATE@")]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@TERMDATE@")]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@TERMINATEDBY@")]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@TERMINATETIME@")]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		[FieldDescription("@NAMESUFFIX@")]
		public string NameSuffix
		{
			get { return this.nameSuffix; }
			set { this.nameSuffix = value; }
		}

		public NamePrefixCollection LookupOf_namePrefixID
		{
			get
			{
				return NamePrefixCollection.ActiveNamePrefixes; // Acquire a shared instance from the static member of collection
			}
		}


		public void Save(IContactOwner contactOwner)
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			//this.SqlData.EnsureTransaction();
			try
			{
				if (this.IsNew)
				{
					base.Save();
					// Create a linkage
					BaseLinkageClass element = (BaseLinkageClass)contactOwner.GetContacts().NewRecord(true);
					element.SetFKMemberFor(typeof(Contact), contactID);
					element.SaveLinkage();
				}
				else
					base.Save();

				//this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				//this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}	
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			 this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int contactID)
		{
			return base.Load(contactID);
		}


		


		/// <summary>
		/// Contained Address object
		/// </summary>
		[Contained]
		public Address Address
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.address = (Address)Address.EnsureContainedDataObject(this, typeof(Address), address, false, addressID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.address;
			}
			set
			{
				this.address = value;
				if (value != null) value.ParentContact = this; // set this as a parent of the child data class
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.effectiveDate = DateTime.Today;
			this.addressID = 0;
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New(string lastName, string firstName)
		{
			this.NewRecord(); // initialize record state
			this.lastName = lastName;
			this.firstName = firstName;
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state
		}


		public void NewForSearch()
		{
			this.NewRecord();
			this.SetMembersNull(true, true);
		}


		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			this.Address.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			{
				base.InternalSave();	// in that case, delete the base first
				Address.MarkDel();	// then allow the deletion of the conatined object
			}
			Address.IsNew = this.IsNew;	// make sure the contained object is new if the containing object is new
			Address.Save();
			this.addressID = Address.AddressID; // set the fk if the contained object was newly created
			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}
			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		/// <summary>
		/// Override this function to load child and other objects that must be loaded with this object.
		/// </summary>
		protected override bool InternalLoad(params object[] keys)
		{
			// Do pre-load operations here.
			bool result = base.InternalLoad(keys);
			// Do post-load operations here.
			return result;
		}

		/// <summary>
		/// Parent ContactCollection that contains this element
		/// </summary>
		public ContactCollection ParentContactCollection
		{
			get
			{
				return this.parentContactCollection;
			}
			set
			{
				this.parentContactCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child ContactRoles mapped to related rows of table ContactRoles where [ContactID] = [ContactID]
		/// </summary>
		[SPLoadChild("usp_LoadContactRoles", "contactID")]
		public ContactRoleCollection ContactRoles
		{
			get { return this.contactRoles; }
			set
			{
				this.contactRoles = value;
				value.ParentContact = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ContactRoles collection
		/// </summary>
		public void LoadContactRoles(bool forceReload)
		{
			this.contactRoles = (ContactRoleCollection)ContactRoleCollection.LoadChildCollection("ContactRoles", this, typeof(ContactRoleCollection), contactRoles, forceReload, null);
		}

		/// <summary>
		/// Saves the ContactRoles collection
		/// </summary>
		public void SaveContactRoles()
		{
			ContactRoleCollection.SaveChildCollection(this.contactRoles, true);
		}

		/// <summary>
		/// Synchronizes the ContactRoles collection
		/// </summary>
		public void SynchronizeContactRoles()
		{
			ContactRoleCollection.SynchronizeChildCollection(this.contactRoles, true);
		}

		public void GetContactRolesForSelection(IContactOwner contactOwner)
		{
			RoleCollection allRoles = new RoleCollection();
			allRoles.GetRolesByContactOwnerType(-1, contactOwner.ContactOwnerType, true);
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{
				writer.AddHeaderLabelandValue("Contact", Name);
				//writer.AddFieldsOnNewLine(this, "ContactID", "LastName", "FirstName");
			}
		}



	}

	/// <summary>
	/// Strongly typed collection of Contact objects
	/// </summary>
	[ElementType(typeof(Contact))]
	public class ContactCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Contact elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentContactCollection = this;
			else
				elem.ParentContactCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Contact elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Contact this[int index]
		{
			get
			{
				return (Contact)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Contact)oldValue, false);
			SetParentOnElem((Contact)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}


		public int SearchContacts(int maxRecords, Contact contactSearcher, IContactOwner contactOwner)
		{
			System.Reflection.MethodInfo mi = this.GetType().GetMethod("Search" + contactOwner.ContactOwnerType.ToString() + "Contacts");
			
			// If the search method exists invoke it
			if (mi != null)
			{
				return (int)mi.Invoke(this, new object[] {maxRecords, contactSearcher, (int)((BaseDataClass)contactOwner).PK[0]});
			}
			else
				return -1;		
		}

		/// <summary>
		/// These are the contact search methods for different entities
		/// </summary>
		public int SearchOrganizationContacts(int maxRecords, Contact contactSearcher, int organizationID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchOrganizationContacts", maxRecords, this, new object[] { contactSearcher }, false, 
				new string[] {"organizationID"},
				new object[] {organizationID});
		}

		public int SearchPatientContacts(int maxRecords, Contact contactSearcher, int patientID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchPatientContacts", maxRecords, this, new object[] { contactSearcher }, false, 
				new string[] {"patientID"},
				new object[] {patientID});
		}			

		public int SearchPlanContacts(int maxRecords, Contact contactSearcher, int planID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchPlanContacts", maxRecords, this, new object[] { contactSearcher }, false, 
				new string[] {"planID"},
				new object[] {planID});
		}			

		public int SearchProviderLocationContacts(int maxRecords, Contact contactSearcher, int providerLocationID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchProviderLocationContacts", maxRecords, this, new object[] { contactSearcher }, false, 
				new string[] {"providerLocationID"},
				new object[] {providerLocationID});
		}	

		public int SearchFacilityLocationContacts(int maxRecords, Contact contactSearcher, int facilityLocationID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchFacilityLocationContacts", maxRecords, this, new object[] { contactSearcher }, false, 
				new string[] {"facilityLocationID"},
				new object[] {facilityLocationID});
		}	

		public int SearchGroupPracticeLocationContacts(int maxRecords, Contact contactSearcher, int groupPracticeLocationID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchGroupPracticeLocationContacts", maxRecords, this, new object[] { contactSearcher }, false, 
				new string[] {"groupPracticeLocationID"},
				new object[] {groupPracticeLocationID});
		}	

		public int SearchInsurancePayorContacts(int maxRecords, Contact contactSearcher, int insurancePayorID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchInsurancePayorContacts", maxRecords, this, new object[] { contactSearcher }, false, 
				new string[] {"insurancePayorID"},
				new object[] {insurancePayorID});
		}	

		public int SearchNetworkContacts(int maxRecords, Contact contactSearcher, int networkID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchNetworkContacts", maxRecords, this, new object[] { contactSearcher }, false, 
				new string[] {"networkID"},
				new object[] {networkID});
		}	
	}


}
